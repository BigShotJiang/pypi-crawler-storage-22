#!/usr/bin/env python3
"""
Kabyle stopword generation from corpus text.
"""

import re
import logging
from collections import Counter
from typing import Set, Optional

from .kab_charset import normalize, tokenize_kabyle

logger = logging.getLogger(__name__)

DEFAULT_EXCLUDE = {"mary", "john", "paul", "jesus"}


def create_stopwords(
    input_filename: str,
    output_filename: str,
    *,
    rel_cutoff: float = 0.005,
    min_count: int = 5,
    max_words: Optional[int] = None,
    exclude: Optional[Set[str]] = None,
    min_length: int = 1
) -> list:
    """
    Generate stopword list from corpus.
    
    Args:
        input_filename: Source text file
        output_filename: Where to write stopwords
        rel_cutoff: Minimum relative frequency
        min_count: Minimum absolute frequency
        max_words: Maximum stopwords to return
        exclude: Set of words to exclude
        min_length: Minimum word length
    
    Returns:
        List of stopwords sorted by frequency
    """
    if exclude is None:
        exclude = DEFAULT_EXCLUDE
    
    exclude = {w.lower() for w in exclude}
    
    logger.info(f"Reading {input_filename}...")
    
    with open(input_filename, "r", encoding="utf-8") as f:
        text = f.read()
    
    text = normalize(text, fix=True)
    tokens = tokenize_kabyle(text, lower=True)
    tokens = [t for t in tokens if len(t) >= min_length and t not in exclude]
    
    freq = Counter(tokens)
    total_tokens = sum(freq.values())
    
    logger.info(f"Total tokens: {total_tokens:,}, unique: {len(freq):,}")
    
    candidates = []
    for word, count in freq.most_common():
        meets_rel = (rel_cutoff == 0) or (count / total_tokens >= rel_cutoff)
        meets_abs = (min_count == 0) or (count >= min_count)
        
        if meets_rel or meets_abs:
            candidates.append(word)
        
        if max_words and len(candidates) >= max_words:
            break
    
    with open(output_filename, "w", encoding="utf-8") as f:
        for word in candidates:
            f.write(word + "\n")
    
    logger.info(f"Wrote {len(candidates)} stopwords to {output_filename}")
    return candidates


def show_top_words(input_filename: str, n: int = 20,
                   exclude: Optional[Set[str]] = None) -> None:
    """Display top words with frequencies."""
    if exclude is None:
        exclude = DEFAULT_EXCLUDE
    
    with open(input_filename, "r", encoding="utf-8") as f:
        text = normalize(f.read(), fix=True)
    
    tokens = tokenize_kabyle(text, lower=True)
    tokens = [t for t in tokens if t not in exclude]
    
    freq = Counter(tokens)
    total = sum(freq.values())
    
    print(f"\nTop {n} words by frequency:")
    print("-" * 40)
    print(f"{'Word':<15} {'Count':>10} {'%':>8}")
    print("-" * 40)
    
    for word, count in freq.most_common(n):
        pct = (count / total) * 100
        marker = " *" if word in exclude else ""
        print(f"{word:<15} {count:>10,} {pct:>7.2f}%{marker}")
    
    print("-" * 40)
    print("* = in exclusion list")
