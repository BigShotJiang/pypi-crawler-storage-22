#!/usr/bin/env python3
"""
Language-specific character profiles for Kabyle and Occitan.
"""

from typing import Dict, Set, Optional
from dataclasses import dataclass


@dataclass
class LanguageProfile:
    """Language profile with character set information."""
    
    iso_code: str
    name: str
    base_alphabet: str
    extended_chars: str
    common_confusables: Dict[str, str]
    
    @property
    def full_alphabet(self) -> Set[str]:
        """Return all allowed characters including uppercase."""
        all_chars = self.base_alphabet + self.extended_chars
        return set(all_chars + all_chars.upper())


# Language profiles registry
PROFILES = {
    "kab": LanguageProfile(
        iso_code="kab",
        name="Kabyle",
        base_alphabet="abcdefghijklmnopqrstuvwxyz",
        extended_chars="čḍɛǧɣḥṛṣṭẓ",
        common_confusables={
            "ε": "ɛ",      # Greek epsilon → Latin epsilon
            "ϵ": "ɛ",      # Greek lunate epsilon → Latin epsilon
            "γ": "ɣ",      # Greek gamma → Latin gamma
            "Γ": "Ɣ",      # Greek capital Gamma → Latin capital Gamma
            "Σ": "Ɛ",      # Greek capital Sigma → Latin capital Epsilon
            "Ԑ": "Ɛ",      # Cyrillic epsilon → Latin epsilon
            "ţ": "t",      # Romanian t-comma → plain t
            "ț": "t",      # Romanian t-cedilla → plain t
            "Ţ": "T",
            "Ț": "T",
            "ş": "ṣ",      # Turkish s-cedilla → s with dot below
            "Ş": "Ṣ",
            "ğ": "ǧ",      # Turkish g-breve → g with caron
            "Ğ": "Ǧ",
        }
    ),
    
    "oci": LanguageProfile(
        iso_code="oci",
        name="Occitan",
        base_alphabet="abcdefghijklmnopqrstuvwxyz",
        extended_chars="áàäâéèëêíìïîóòöôúùüûçñ",
        common_confusables={
            "ó": "ò",      # Normalize to grave accent (preferred in Occitan)
            "á": "à",
            "é": "è",
            "í": "ì",
            "ú": "ù",
            "ü": "u",      # German umlaut → plain u
            "ä": "a",
            "ö": "o",
            "ï": "i",
            "ç": "c",      # c-cedilla → plain c (if needed)
        }
    ),
}


def get_profile(lang_code: str) -> Optional[LanguageProfile]:
    """
    Get language profile by ISO code.
    
    Args:
        lang_code: ISO 639-1 or ISO 639-2 language code
        
    Returns:
        LanguageProfile if found, None otherwise
        
    Example:
        >>> profile = get_profile("kab")
        >>> profile.name
        'Kabyle'
    """
    return PROFILES.get(lang_code.lower())


def get_charset(lang_code: str) -> Set[str]:
    """
    Get allowed characters for a language.
    
    Args:
        lang_code: ISO language code
        
    Returns:
        Set of allowed characters
        
    Example:
        >>> 'č' in get_charset("kab")
        True
    """
    profile = get_profile(lang_code)
    if profile:
        return profile.full_alphabet
    # Fallback to basic Latin
    return set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")


def get_fixes(lang: str, strictness: str = "standard") -> Dict[str, str]:
    """
    Get character fixes based on strictness level.
    
    Args:
        lang: Language code
        strictness: One of "minimal", "standard", "aggressive"
        
    Returns:
        Dictionary mapping bad characters to replacements
        
    Example:
        >>> get_fixes("kab")["ε"]
        'ɛ'
    """
    profile = get_profile(lang)
    if not profile:
        return {}
    
    if strictness == "minimal":
        # Only obvious encoding errors
        if lang == "oci":
            return {"ü": "u", "ä": "a", "ö": "o", "ï": "i"}
        return {k: v for k, v in profile.common_confusables.items() 
                if k in "εϵγΓΣԐţțŢȚşŞğĞ"}
    
    elif strictness == "aggressive":
        # All fixes including more normalizations
        extra = {"ë": "e", "ê": "e", "ô": "o"} if lang == "oci" else {}
        return {**profile.common_confusables, **extra}
    
    else:  # standard
        return profile.common_confusables
