#!/usr/bin/env python3
"""
Sentence pairing utilities for parallel corpus creation.
"""

import csv
from typing import Dict, Set, Optional
from .extractor import iter_sentences, iter_links


def build_sentence_dict(tar_filename: str, lang: str) -> Dict[str, str]:
    """
    Build dictionary of sentences for a given language.
    
    Args:
        tar_filename: Path to sentences.tar.bz2
        lang: ISO language code
        
    Returns:
        Dictionary mapping sentence_id -> text
    """
    sentences = {}
    for sid, sentence_lang, text in iter_sentences(tar_filename):
        if sentence_lang == lang:
            sentences[sid] = text
    print(f"Found {len(sentences)} sentences in '{lang}'.")
    return sentences


def build_candidate_ids(
    links_tar_filename: str,
    ref_dict: Dict[str, str],
    other_lang: str
) -> Set[str]:
    """
    Collect sentence IDs paired with sentences in ref_dict.
    
    Args:
        links_tar_filename: Path to links.tar.bz2
        ref_dict: Reference dictionary of sentences
        other_lang: Target language code (for logging)
        
    Returns:
        Set of candidate sentence IDs
    """
    candidate_ids = set()
    for sid1, sid2 in iter_links(links_tar_filename):
        if sid1 in ref_dict and sid2 not in ref_dict:
            candidate_ids.add(sid2)
        elif sid2 in ref_dict and sid1 not in ref_dict:
            candidate_ids.add(sid1)
    print(f"Identified {len(candidate_ids)} candidates for '{other_lang}'.")
    return candidate_ids


def build_sentence_dict_from_ids(
    tar_filename: str,
    lang: str,
    id_set: Set[str]
) -> Dict[str, str]:
    """
    Build dictionary for specific sentence IDs.
    
    Args:
        tar_filename: Path to sentences.tar.bz2
        lang: ISO language code
        id_set: Set of sentence IDs to include
        
    Returns:
        Dictionary mapping sentence_id -> text
    """
    sentences = {}
    for sid, sentence_lang, text in iter_sentences(tar_filename):
        if sentence_lang == lang and sid in id_set:
            sentences[sid] = text
    print(f"Loaded {len(sentences)} sentences in '{lang}' from candidates.")
    return sentences


def write_sentence_pairs(
    links_tar_filename: str,
    dict_a: Dict[str, str],
    dict_b: Dict[str, str],
    output_filename: str,
    a_first: bool = True,
    lang_a_name: str = "LangA",
    lang_b_name: str = "LangB"
) -> int:
    """
    Write sentence pairs to TSV file.
    
    Args:
        links_tar_filename: Path to links.tar.bz2
        dict_a: First language dictionary
        dict_b: Second language dictionary
        output_filename: Output TSV path
        a_first: If True, output (a, b), else (b, a)
        lang_a_name: Header name for first language
        lang_b_name: Header name for second language
        
    Returns:
        Number of pairs written
    """
    seen = set()
    count = 0
    
    with open(output_filename, "w", encoding="utf-8", newline="") as f_out:
        writer = csv.writer(f_out, delimiter="\t")
        writer.writerow([lang_a_name, lang_b_name])
        
        for sid1, sid2 in iter_links(links_tar_filename):
            pair = None
            
            if sid1 in dict_a and sid2 in dict_b:
                key = tuple(sorted([sid1, sid2]))
                if key not in seen:
                    seen.add(key)
                    pair = (dict_a[sid1], dict_b[sid2]) if a_first else (dict_b[sid2], dict_a[sid1])
            
            elif sid2 in dict_a and sid1 in dict_b:
                key = tuple(sorted([sid1, sid2]))
                if key not in seen:
                    seen.add(key)
                    pair = (dict_a[sid2], dict_b[sid1]) if a_first else (dict_b[sid1], dict_a[sid2])
            
            if pair:
                writer.writerow(pair)
                count += 1
    
    print(f"Wrote {count} sentence pairs to {output_filename}.")
    return count
