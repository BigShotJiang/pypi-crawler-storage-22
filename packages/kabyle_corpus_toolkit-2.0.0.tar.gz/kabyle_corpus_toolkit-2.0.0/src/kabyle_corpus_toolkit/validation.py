#!/usr/bin/env python3
"""
Validation using GlotLID FastText model.
"""

import logging
import time
from collections import Counter
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# Language label mapping
LANG_LABELS = {
    "kab": "__label__kab_Latn",
    "oci": "__label__oci_Latn"
}


def load_glotlid_model():
    """Download and load GlotLID model."""
    try:
        import fasttext
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise ImportError(
            "Validation requires 'fasttext' and 'huggingface-hub'. "
            "Install with: pip install 'kabyle-corpus-toolkit[validation]'"
        )
    
    logger.info("Downloading/loading GlotLID model...")
    model_path = hf_hub_download(repo_id="cis-lmu/glotlid", filename="model.bin")
    model = fasttext.load_model(model_path)
    logger.info(f"Model loaded. Dimension: {model.get_dimension()}")
    return model


def validate_file(
    input_file: str,
    lang: str,
    confidence_threshold: float = 0.70,
    top_k: int = 3,
    sample_size: int = 100
) -> Dict:
    """
    Validate sentences and generate quality report.
    
    Args:
        input_file: Path to text file
        lang: Language code ('kab' or 'oci')
        confidence_threshold: Minimum confidence for "clean" classification
        top_k: Number of predictions to consider
        sample_size: Number of suspicious examples to keep
    
    Returns:
        Dictionary with validation statistics
    """
    if lang not in LANG_LABELS:
        raise ValueError(f"Language '{lang}' not supported. Use: {', '.join(LANG_LABELS.keys())}")
    
    expected_label = LANG_LABELS[lang]
    model = load_glotlid_model()
    
    stats = {
        "language": lang,
        "expected_label": expected_label,
        "confidence_threshold": confidence_threshold,
        "total": 0,
        "clean": 0,
        "uncertain": 0,
        "wrong_language": 0,
        "confidence_scores": [],
        "wrong_predictions": Counter()
    }
    
    uncertain_examples: List[Dict] = []
    wrong_examples: List[Dict] = []
    
    logger.info(f"Validating {input_file} as {lang}...")
    
    with open(input_file, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            sentence = line.strip()
            if not sentence:
                continue
            
            labels, scores = model.predict(sentence, k=top_k)
            primary_label = labels[0]
            primary_conf = float(scores[0])
            
            stats["total"] += 1
            stats["confidence_scores"].append(primary_conf)
            
            if primary_label == expected_label:
                if primary_conf >= confidence_threshold:
                    stats["clean"] += 1
                else:
                    stats["uncertain"] += 1
                    if len(uncertain_examples) < sample_size:
                        uncertain_examples.append({
                            "line": line_num,
                            "text": sentence[:100],
                            "confidence": round(primary_conf, 4),
                            "top_predictions": [
                                {"label": l, "score": round(float(s), 4)} 
                                for l, s in zip(labels, scores)
                            ]
                        })
            else:
                stats["wrong_language"] += 1
                stats["wrong_predictions"][primary_label] += 1
                
                if len(wrong_examples) < sample_size:
                    wrong_examples.append({
                        "line": line_num,
                        "text": sentence[:100],
                        "predicted": primary_label,
                        "confidence": round(primary_conf, 4),
                        "expected": expected_label
                    })
            
            if line_num % 10000 == 0:
                logger.info(f"Processed {stats['total']} sentences...")
    
    # Calculate statistics
    total = stats["total"]
    avg_conf = sum(stats["confidence_scores"]) / len(stats["confidence_scores"]) if stats["confidence_scores"] else 0
    
    report = {
        "validation_timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "file": input_file,
        "language": lang,
        "parameters": {
            "confidence_threshold": confidence_threshold,
            "top_k": top_k
        },
        "summary": {
            "total_sentences": total,
            "clean": {
                "count": stats["clean"],
                "percentage": round(100 * stats["clean"] / total, 2) if total else 0
            },
            "uncertain": {
                "count": stats["uncertain"],
                "percentage": round(100 * stats["uncertain"] / total, 2) if total else 0
            },
            "wrong_language": {
                "count": stats["wrong_language"],
                "percentage": round(100 * stats["wrong_language"] / total, 2) if total else 0
            },
            "average_confidence": round(avg_conf, 4)
        },
        "wrong_language_breakdown": dict(stats["wrong_predictions"].most_common(10)),
        "examples_uncertain": uncertain_examples,
        "examples_wrong": wrong_examples
    }
    
    return report


def print_report(report: Dict) -> None:
    """Print validation report to console."""
    s = report["summary"]
    
    print(f"\n{'='*60}")
    print("VALIDATION REPORT")
    print(f"{'='*60}")
    print(f"File: {report['file']}")
    print(f"Language: {report['language']}")
    print(f"Threshold: {report['parameters']['confidence_threshold']}")
    print()
    print(f"Total sentences: {s['total_sentences']:,}")
    print(f"  ✓ Clean (≥{report['parameters']['confidence_threshold']}): {s['clean']['count']:,} ({s['clean']['percentage']}%)")
    print(f"  ⚠ Uncertain: {s['uncertain']['count']:,} ({s['uncertain']['percentage']}%)")
    print(f"  ✗ Wrong language: {s['wrong_language']['count']:,} ({s['wrong_language']['percentage']}%)")
    print(f"\nAverage confidence: {s['average_confidence']:.4f}")
    
    if report["wrong_language_breakdown"]:
        print(f"\nMost common misclassifications:")
        for label, count in list(report["wrong_language_breakdown"].items())[:5]:
            print(f"  {label}: {count}")
    
    print(f"{'='*60}")
    
    clean_pct = s["clean"]["percentage"]
    if clean_pct >= 95:
        print("✓ Excellent quality")
    elif clean_pct >= 85:
        print("⚠ Good quality, review recommended")
    elif clean_pct >= 70:
        print("⚠⚠ Poor quality, investigation needed")
    else:
        print("✗✗ Critical quality issues")
    
    print(f"{'='*60}")
