#!/usr/bin/env python3
"""
Test script to verify the Kabyle toolkit works correctly.
"""

import sys


def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")
    
    try:
        from kabyle_corpus_toolkit.lang_profiles import get_profile, get_charset, get_fixes
        print("  ✓ lang_profiles")
    except Exception as e:
        print(f"  ✗ lang_profiles: {e}")
        assert False, f"Failed to import lang_profiles: {e}"
    
    try:
        from kabyle_corpus_toolkit.kab_charset import normalize, find_disallowed, tokenize_kabyle
        print("  ✓ kab_charset")
    except Exception as e:
        print(f"  ✗ kab_charset: {e}")
        assert False, f"Failed to import kab_charset: {e}"
    
    try:
        from kabyle_corpus_toolkit.downloader import download_file
        print("  ✓ downloader")
    except Exception as e:
        print(f"  ✗ downloader: {e}")
        assert False, f"Failed to import downloader: {e}"
    
    try:
        from kabyle_corpus_toolkit.extractor import iter_sentences, iter_links
        print("  ✓ extractor")
    except Exception as e:
        print(f"  ✗ extractor: {e}")
        assert False, f"Failed to import extractor: {e}"
    
    try:
        from kabyle_corpus_toolkit.pairing import build_sentence_dict, write_sentence_pairs
        print("  ✓ pairing")
    except Exception as e:
        print(f"  ✗ pairing: {e}")
        assert False, f"Failed to import pairing: {e}"


def test_kabyle_normalization():
    """Test Kabyle text normalization."""
    print("\nTesting Kabyle normalization...")
    
    from kabyle_corpus_toolkit.kab_charset import normalize, find_disallowed
    
    # Test Greek epsilon replacement
    test1 = normalize("εɛ", lang="kab", fix=True)
    assert test1 == "ɛɛ", f"Expected 'ɛɛ', got '{test1}'"
    print("  ✓ Greek epsilon replacement")
    
    # Test valid Kabyle text
    valid = "Axxam-iw d acebḥan."
    bad = find_disallowed(valid, lang="kab")
    assert len(bad) == 0, f"Found unexpected bad chars: {bad}"
    print("  ✓ Valid Kabyle text passes")
    
    # Test invalid characters
    invalid = "Hello ε world"
    bad = find_disallowed(invalid, lang="kab")
    assert "ε" in bad, f"Expected 'ε' in bad chars, got {bad}"
    print("  ✓ Invalid characters detected")


def test_tokenization():
    """Test tokenization."""
    print("\nTesting tokenization...")
    
    from kabyle_corpus_toolkit.kab_charset import tokenize_kabyle
    
    text = "Axxam-iw d acebḥan. Wa d anasiw!"
    tokens = tokenize_kabyle(text, lower=True)
    
    expected = ["axxam", "iw", "d", "acebḥan", "wa", "d", "anasiw"]
    assert tokens == expected, f"Expected {expected}, got {tokens}"
    print(f"  ✓ Tokenization: {tokens}")


def test_language_profiles():
    """Test language profiles."""
    print("\nTesting language profiles...")
    
    from kabyle_corpus_toolkit.lang_profiles import get_profile, get_charset
    
    # Test Kabyle profile
    kab = get_profile("kab")
    assert kab is not None, "Kabyle profile should not be None"
    assert kab.name == "Kabyle", f"Expected 'Kabyle', got '{kab.name}'"
    assert "č" in kab.extended_chars, "č should be in extended_chars"
    print("  ✓ Kabyle profile loaded")
    
    # Test Occitan profile
    oci = get_profile("oci")
    assert oci is not None, "Occitan profile should not be None"
    assert oci.name == "Occitan", f"Expected 'Occitan', got '{oci.name}'"
    print("  ✓ Occitan profile loaded")
    
    # Test charset
    kab_chars = get_charset("kab")
    assert "č" in kab_chars, "č should be in Kabyle charset"
    assert "Č" in kab_chars, "Č should be in Kabyle charset"
    print("  ✓ Character sets correct")


def main():
    print("=" * 60)
    print("Kabyle Corpus Toolkit Test Suite")
    print("=" * 60)
    
    all_passed = True
    
    try:
        test_imports()
    except AssertionError:
        all_passed = False
    
    try:
        test_kabyle_normalization()
    except AssertionError:
        all_passed = False
    
    try:
        test_tokenization()
    except AssertionError:
        all_passed = False
    
    try:
        test_language_profiles()
    except AssertionError:
        all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("✓ All tests passed!")
    else:
        print("✗ Some tests failed")
        sys.exit(1)
    print("=" * 60)


if __name__ == "__main__":
    main()
