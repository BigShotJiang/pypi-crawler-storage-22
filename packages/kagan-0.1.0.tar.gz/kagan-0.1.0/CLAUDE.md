Read AGENTS.md and follow the rules
