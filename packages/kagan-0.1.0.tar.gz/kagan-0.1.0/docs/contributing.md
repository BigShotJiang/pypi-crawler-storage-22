# Contributing

Kagan's user docs live here. For contributor guidance, please read the full
[CONTRIBUTING.md](https://github.com/aorumbayev/kagan/blob/main/CONTRIBUTING.md).

- GitHub repo: [github.com/aorumbayev/kagan](https://github.com/aorumbayev/kagan)
- Issues and pull requests are tracked in GitHub.
