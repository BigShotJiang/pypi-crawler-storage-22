"""Session management modules for Kagan."""

from __future__ import annotations

from kagan.sessions.manager import SessionManager

__all__ = ["SessionManager"]
