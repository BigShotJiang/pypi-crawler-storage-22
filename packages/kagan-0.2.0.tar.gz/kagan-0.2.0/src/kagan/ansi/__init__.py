"""ANSI terminal output processing."""

from __future__ import annotations

from kagan.ansi.cleaner import clean_terminal_output

__all__ = ["clean_terminal_output"]
