"""UI components for Kagan TUI."""
