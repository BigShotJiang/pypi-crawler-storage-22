"""Ticket details modal package."""

from kagan.ui.modals.ticket_details.modal import TicketDetailsModal

__all__ = ["TicketDetailsModal"]
