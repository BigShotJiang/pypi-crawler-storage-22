"""Kanban screen package."""

from kagan.ui.screens.kanban.screen import KanbanScreen

__all__ = ["KanbanScreen"]
