"""E2E test fixtures.

E2E tests use Textual's pilot for full application testing.
Fixtures from tests/conftest.py are automatically available via pytest's conftest discovery.
"""

from __future__ import annotations
