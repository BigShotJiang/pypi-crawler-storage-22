"""CLI utilities for Kagan."""

from __future__ import annotations
