from enum import Enum, auto


class ModalAction(Enum):
    DELETE = auto()
