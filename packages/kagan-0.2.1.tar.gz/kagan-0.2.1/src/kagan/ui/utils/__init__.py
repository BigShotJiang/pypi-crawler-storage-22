"""UI utilities package."""

from __future__ import annotations

from kagan.ui.utils.clipboard import copy_with_notification

__all__ = ["copy_with_notification"]
