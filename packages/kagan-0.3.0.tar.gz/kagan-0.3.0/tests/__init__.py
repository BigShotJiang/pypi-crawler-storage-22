"""Tests for Kagan."""
