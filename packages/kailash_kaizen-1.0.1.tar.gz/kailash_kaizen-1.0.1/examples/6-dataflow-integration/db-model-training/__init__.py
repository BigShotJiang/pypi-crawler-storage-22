"""Database-driven model training example package."""
