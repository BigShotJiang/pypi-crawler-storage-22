"""Kairo Image Generation Service — FLUX.1-dev on GPU (text2img + img2img)."""

import asyncio
import logging
import os
from io import BytesIO

import torch
from diffusers import FluxPipeline, FluxImg2ImgPipeline
from fastapi import FastAPI, Depends, HTTPException, Header, Form, UploadFile, File
from fastapi.responses import StreamingResponse
from PIL import Image
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Kairo Image Service")

API_KEY = os.environ.get("IMAGE_API_KEY", "")
pipe: FluxPipeline | None = None
img2img_pipe: FluxImg2ImgPipeline | None = None


# ── Schemas ──────────────────────────────────────────────────────────

class GenerateRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=2000)
    width: int = Field(default=1024, ge=256, le=2048)
    height: int = Field(default=1024, ge=256, le=2048)
    num_inference_steps: int = Field(default=25, ge=1, le=50)
    seed: int | None = None


# ── Auth ─────────────────────────────────────────────────────────────

async def verify_api_key(authorization: str = Header(default="")):
    if API_KEY and authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Invalid API key")


# ── Lifecycle ────────────────────────────────────────────────────────

@app.on_event("startup")
async def load_model():
    global pipe, img2img_pipe
    logger.info("Loading FLUX.1-dev with sequential CPU offloading...")
    pipe = FluxPipeline.from_pretrained(
        "black-forest-labs/FLUX.1-dev",
        torch_dtype=torch.bfloat16,
    )
    pipe.enable_sequential_cpu_offload()

    # Create img2img pipeline sharing all model components (zero extra VRAM)
    img2img_pipe = FluxImg2ImgPipeline(
        transformer=pipe.transformer,
        scheduler=pipe.scheduler,
        vae=pipe.vae,
        text_encoder=pipe.text_encoder,
        text_encoder_2=pipe.text_encoder_2,
        tokenizer=pipe.tokenizer,
        tokenizer_2=pipe.tokenizer_2,
    )

    logger.info("FLUX.1-dev loaded (text2img + img2img ready)")


# ── Helpers ──────────────────────────────────────────────────────────

def _snap_to_multiple(value: int, multiple: int = 16) -> int:
    """Round to nearest multiple (required by VAE)."""
    return max(multiple, round(value / multiple) * multiple)


def _run_pipeline(prompt: str, width: int, height: int, steps: int, seed: int | None):
    """Run text2img pipeline synchronously (called via asyncio.to_thread)."""
    generator = (
        torch.Generator("cuda").manual_seed(seed)
        if seed is not None
        else None
    )
    try:
        image = pipe(
            prompt=prompt,
            width=_snap_to_multiple(width),
            height=_snap_to_multiple(height),
            num_inference_steps=steps,
            generator=generator,
        ).images[0]
        buf = BytesIO()
        image.save(buf, format="PNG")
        buf.seek(0)
        return buf
    finally:
        torch.cuda.empty_cache()


def _run_img2img_pipeline(
    image: Image.Image,
    prompt: str,
    strength: float,
    steps: int,
    seed: int | None,
):
    """Run img2img pipeline synchronously (called via asyncio.to_thread)."""
    generator = (
        torch.Generator("cuda").manual_seed(seed)
        if seed is not None
        else None
    )
    try:
        # Resize to multiples of 16
        w = _snap_to_multiple(image.width)
        h = _snap_to_multiple(image.height)
        if (w, h) != image.size:
            image = image.resize((w, h), Image.LANCZOS)

        result = img2img_pipe(
            prompt=prompt,
            image=image,
            strength=strength,
            num_inference_steps=steps,
            generator=generator,
        ).images[0]
        buf = BytesIO()
        result.save(buf, format="PNG")
        buf.seek(0)
        return buf
    finally:
        torch.cuda.empty_cache()


# ── Routes ───────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok" if pipe is not None else "loading",
        "model": "flux-dev",
    }


@app.post("/generate", dependencies=[Depends(verify_api_key)])
async def generate(req: GenerateRequest):
    if pipe is None:
        raise HTTPException(status_code=503, detail="Model is still loading")

    logger.info("text2img: %s", req.prompt[:80])
    buf = await asyncio.to_thread(
        _run_pipeline, req.prompt, req.width, req.height, req.num_inference_steps, req.seed
    )
    logger.info("text2img complete")
    return StreamingResponse(buf, media_type="image/png")


@app.post("/img2img", dependencies=[Depends(verify_api_key)])
async def img2img(
    image: UploadFile = File(...),
    prompt: str = Form(..., min_length=1, max_length=2000),
    strength: float = Form(default=0.75, ge=0.0, le=1.0),
    num_inference_steps: int = Form(default=25, ge=1, le=50),
    seed: int | None = Form(default=None),
):
    if img2img_pipe is None:
        raise HTTPException(status_code=503, detail="Model is still loading")

    image_bytes = await image.read()
    try:
        pil_image = Image.open(BytesIO(image_bytes)).convert("RGB")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid image file")

    logger.info("img2img (strength=%.2f): %s", strength, prompt[:80])
    buf = await asyncio.to_thread(
        _run_img2img_pipeline, pil_image, prompt, strength, num_inference_steps, seed,
    )
    logger.info("img2img complete")
    return StreamingResponse(buf, media_type="image/png")
