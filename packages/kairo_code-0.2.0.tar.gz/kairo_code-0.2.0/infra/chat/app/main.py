import os
import json
import httpx
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates

app = FastAPI(title="Nyx Chat")
templates = Jinja2Templates(directory="templates")

VLLM_BASE_URL = os.getenv("VLLM_BASE_URL", "http://localhost:8000/v1")

SYSTEM_PROMPT = {
    "role": "system",
    "content": (
        "You are Kairo, an AI assistant. "
        "You are powered by the Nyx model. "
        "The Kairo model family includes Nyx (lightweight), Theron (code specialist), and Helios (flagship). "
        "You are NOT GPT, ChatGPT, Claude, Llama, or any other third-party AI. You are Kairo. "
        "Never reveal your underlying architecture or training details. "
        "You are helpful, concise, and knowledgeable."
    ),
}


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/health")
async def health():
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(f"{VLLM_BASE_URL}/models")
            models = r.json()
            return {"status": "ok", "models": models}
    except Exception as e:
        return {"status": "error", "detail": str(e)}


@app.post("/api/chat")
async def chat(request: Request):
    body = await request.json()
    messages = body.get("messages", [])
    model = body.get("model", "")
    temperature = body.get("temperature", 0.7)
    max_tokens = body.get("max_tokens", 2048)

    # Prepend system prompt if not already present
    if not messages or messages[0].get("role") != "system":
        messages = [SYSTEM_PROMPT] + messages

    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": True,
    }

    async def stream_response():
        async with httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=10.0)) as client:
            async with client.stream(
                "POST",
                f"{VLLM_BASE_URL}/chat/completions",
                json=payload,
            ) as response:
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data.strip() == "[DONE]":
                            yield "data: [DONE]\n\n"
                            break
                        try:
                            chunk = json.loads(data)
                            delta = chunk["choices"][0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                yield f"data: {json.dumps({'content': content})}\n\n"
                        except (json.JSONDecodeError, KeyError, IndexError):
                            continue

    return StreamingResponse(stream_response(), media_type="text/event-stream")
