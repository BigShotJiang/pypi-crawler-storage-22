from fastapi import APIRouter, Depends

from backend.core.admin_auth import require_role

from backend.api.admin.users import router as users_router
from backend.api.admin.stats import router as stats_router
from backend.api.admin.system import router as system_router
from backend.api.admin.content import router as content_router
from backend.api.admin.audit import router as audit_router
from backend.api.admin.incidents import router as incidents_router

router = APIRouter(
    prefix="/admin",
    tags=["admin"],
    dependencies=[Depends(require_role("admin"))],
)

router.include_router(users_router)
router.include_router(stats_router)
router.include_router(system_router)
router.include_router(content_router)
router.include_router(audit_router)
router.include_router(incidents_router)
