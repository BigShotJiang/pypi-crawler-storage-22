import logging
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.admin_auth import require_role
from backend.core.database import get_db
from backend.schemas.admin.audit import AuditLogEntry
from backend.services.admin.audit_service import AuditService

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/audit-logs",
    tags=["admin-audit"],
    dependencies=[Depends(require_role("superadmin"))],
)


@router.get("")
async def list_audit_logs(
    admin_id: str | None = Query(None),
    action: str | None = Query(None),
    target_type: str | None = Query(None),
    result: str | None = Query(None),
    date_from: datetime | None = Query(None),
    date_to: datetime | None = Query(None),
    cursor: str | None = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    filters = {}
    if admin_id:
        filters["admin_id"] = admin_id
    if action:
        filters["action"] = action
    if target_type:
        filters["target_type"] = target_type
    if result:
        filters["result"] = result
    if date_from:
        filters["date_from"] = date_from
    if date_to:
        filters["date_to"] = date_to

    svc = AuditService(db)
    logs = await svc.list_logs(filters=filters or None, cursor=cursor, limit=limit + 1)
    has_more = len(logs) > limit
    if has_more:
        logs = logs[:limit]
    items = [AuditLogEntry.model_validate(log) for log in logs]
    next_cursor = logs[-1].id if has_more and logs else None
    return {"items": items, "next_cursor": next_cursor}
