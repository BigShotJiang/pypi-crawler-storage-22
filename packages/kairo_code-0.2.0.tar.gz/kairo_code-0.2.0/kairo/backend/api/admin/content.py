import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.admin_auth import require_role
from backend.core.database import get_db
from backend.models.user import User
from backend.schemas.admin.content import (
    AdminConversationDetail,
    AdminConversationListItem,
    AdminImageListItem,
    ContentDeleteRequest,
)
from backend.services.admin.audit_service import AuditService
from backend.services.admin.content_service import AdminContentService

logger = logging.getLogger(__name__)

router = APIRouter(
    tags=["admin-content"],
    dependencies=[Depends(require_role("moderator"))],
)


def _get_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _get_ua(request: Request) -> str:
    return request.headers.get("user-agent", "")


@router.get("/conversations")
async def list_conversations(
    search: str | None = Query(None),
    user_id: str | None = Query(None),
    cursor: str | None = Query(None),
    limit: int = Query(25, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminContentService(db)
    data = await svc.list_conversations(search=search, user_id=user_id, cursor=cursor, limit=limit + 1)
    has_more = len(data) > limit
    if has_more:
        data = data[:limit]
    items = [AdminConversationListItem(**item) for item in data]
    next_cursor = data[-1]["id"] if has_more and data else None
    return {"items": items, "next_cursor": next_cursor}


@router.get("/conversations/{conversation_id}", response_model=AdminConversationDetail)
async def get_conversation_detail(
    conversation_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("moderator")),
):
    svc = AdminContentService(db)
    data = await svc.get_conversation_detail(conversation_id)
    if not data:
        raise HTTPException(status_code=404, detail="Conversation not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="content.conversation_viewed",
        target_type="conversation",
        target_id=conversation_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return AdminConversationDetail(**data)


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: str,
    body: ContentDeleteRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("moderator")),
):
    svc = AdminContentService(db)
    deleted = await svc.delete_conversation(conversation_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Conversation not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="content.conversation_deleted",
        target_type="conversation",
        target_id=conversation_id,
        details={"reason": body.reason},
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return {"message": "Conversation deleted"}


@router.get("/images/recent")
async def list_recent_images(
    user_id: str | None = Query(None),
    cursor: str | None = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminContentService(db)
    images = await svc.list_recent_images(user_id=user_id, cursor=cursor, limit=limit + 1)
    has_more = len(images) > limit
    if has_more:
        images = images[:limit]
    items = [AdminImageListItem.model_validate(img) for img in images]
    next_cursor = images[-1].id if has_more and images else None
    return {"items": items, "next_cursor": next_cursor}


@router.delete("/images/{image_id}")
async def delete_image(
    image_id: str,
    body: ContentDeleteRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("moderator")),
):
    svc = AdminContentService(db)
    deleted = await svc.delete_image(image_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Image not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="content.image_deleted",
        target_type="image",
        target_id=image_id,
        details={"reason": body.reason},
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return {"message": "Image deleted"}
