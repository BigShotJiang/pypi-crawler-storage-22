import logging
from datetime import datetime, UTC

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.admin_auth import require_role
from backend.core.database import get_db
from backend.models.user import User
from backend.schemas.status import (
    CreateIncidentRequest,
    IncidentSummary,
    UpdateIncidentRequest,
)
from backend.services.admin.audit_service import AuditService
from backend.services.admin.incident_service import IncidentService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/incidents", tags=["admin-incidents"])


def _incident_to_summary(incident) -> dict:
    return {
        "id": incident.id,
        "title": incident.title,
        "description": incident.description,
        "severity": incident.severity,
        "component": incident.component,
        "status": incident.status,
        "started_at": incident.started_at.isoformat(),
        "resolved_at": incident.resolved_at.isoformat() if incident.resolved_at else None,
    }


@router.post("", response_model=IncidentSummary)
async def create_incident(
    body: CreateIncidentRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    """Create a new incident."""
    svc = IncidentService(db)
    incident = await svc.create_incident(
        title=body.title,
        description=body.description,
        severity=body.severity,
        component=body.component,
    )

    # Audit log
    audit = AuditService(db)
    ip = request.client.host if request.client else "unknown"
    ua = request.headers.get("user-agent", "")
    await audit.log(
        admin_user_id=admin.id,
        action="incident.created",
        target_type="incident",
        target_id=incident.id,
        details={"title": body.title, "component": body.component, "severity": body.severity},
        ip_address=ip,
        user_agent=ua,
    )

    return IncidentSummary(**_incident_to_summary(incident))


@router.get("", response_model=list[IncidentSummary])
async def list_incidents(
    limit: int = Query(default=50, le=200),
    include_resolved: bool = Query(default=False),
    db: AsyncSession = Depends(get_db),
):
    """List incidents. Defaults to active (unresolved) incidents only."""
    svc = IncidentService(db)
    incidents = await svc.list_incidents(limit=limit, include_resolved=include_resolved)
    return [IncidentSummary(**_incident_to_summary(i)) for i in incidents]


@router.patch("/{incident_id}", response_model=IncidentSummary)
async def update_incident(
    incident_id: str,
    body: UpdateIncidentRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    """Update an incident's fields."""
    svc = IncidentService(db)

    update_data = body.model_dump(exclude_unset=True)
    # Parse resolved_at if provided as ISO string
    if "resolved_at" in update_data and update_data["resolved_at"] is not None:
        try:
            update_data["resolved_at"] = datetime.fromisoformat(update_data["resolved_at"])
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid resolved_at format. Use ISO 8601.")

    incident = await svc.update_incident(incident_id, **update_data)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")

    # Audit log
    audit = AuditService(db)
    ip = request.client.host if request.client else "unknown"
    ua = request.headers.get("user-agent", "")
    await audit.log(
        admin_user_id=admin.id,
        action="incident.updated",
        target_type="incident",
        target_id=incident_id,
        details=update_data,
        ip_address=ip,
        user_agent=ua,
    )

    return IncidentSummary(**_incident_to_summary(incident))


@router.post("/{incident_id}/resolve", response_model=IncidentSummary)
async def resolve_incident(
    incident_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    """Mark an incident as resolved."""
    svc = IncidentService(db)
    incident = await svc.resolve_incident(incident_id)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")

    # Audit log
    audit = AuditService(db)
    ip = request.client.host if request.client else "unknown"
    ua = request.headers.get("user-agent", "")
    await audit.log(
        admin_user_id=admin.id,
        action="incident.resolved",
        target_type="incident",
        target_id=incident_id,
        details={},
        ip_address=ip,
        user_agent=ua,
    )

    return IncidentSummary(**_incident_to_summary(incident))
