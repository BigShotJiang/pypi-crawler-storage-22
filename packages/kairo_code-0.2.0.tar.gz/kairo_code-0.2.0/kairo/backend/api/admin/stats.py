import logging

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.schemas.admin.stats import (
    DailyCountResponse,
    DailyTokensResponse,
    OverviewStats,
    PlanDistributionResponse,
    RevenueStats,
    TopUserAnalyticsResponse,
    TopUserEntry,
    UsageStatsEntry,
    UserGrowthEntry,
)
from backend.services.admin.stats_service import AdminStatsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/stats", tags=["admin-stats"])


@router.get("/overview", response_model=OverviewStats)
async def get_overview(db: AsyncSession = Depends(get_db)):
    svc = AdminStatsService(db)
    data = await svc.get_overview()
    return OverviewStats(**data)


@router.get("/users", response_model=list[UserGrowthEntry])
async def get_user_growth(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminStatsService(db)
    data = await svc.get_user_growth(days=days)
    return [UserGrowthEntry(**entry) for entry in data]


@router.get("/usage", response_model=list[UsageStatsEntry])
async def get_usage_stats(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminStatsService(db)
    data = await svc.get_usage_stats(days=days)
    return [UsageStatsEntry(**entry) for entry in data]


@router.get("/revenue", response_model=RevenueStats)
async def get_revenue_stats(db: AsyncSession = Depends(get_db)):
    svc = AdminStatsService(db)
    data = await svc.get_revenue_stats()
    return RevenueStats(**data)


@router.get("/top-users", response_model=list[TopUserEntry])
async def get_top_users(
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminStatsService(db)
    data = await svc.get_top_users(limit=limit)
    return [TopUserEntry(**entry) for entry in data]


# ------------------------------------------------------------------ #
#  Analytics chart / table endpoints                                  #
# ------------------------------------------------------------------ #


@router.get("/signups", response_model=DailyCountResponse)
async def get_signups(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
):
    """Daily signup counts for the past N days (zero-filled)."""
    svc = AdminStatsService(db)
    data = await svc.get_daily_signups(days=days)
    return DailyCountResponse(data=data)


@router.get("/active-users", response_model=DailyCountResponse)
async def get_active_users(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
):
    """Daily active user counts (users with usage records) for the past N days."""
    svc = AdminStatsService(db)
    data = await svc.get_daily_active_users(days=days)
    return DailyCountResponse(data=data)


@router.get("/usage-over-time", response_model=DailyTokensResponse)
async def get_usage_over_time(
    days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
):
    """Daily total tokens used for the past N days (zero-filled)."""
    svc = AdminStatsService(db)
    data = await svc.get_usage_over_time(days=days)
    return DailyTokensResponse(data=data)


@router.get("/plan-distribution", response_model=PlanDistributionResponse)
async def get_plan_distribution(
    db: AsyncSession = Depends(get_db),
):
    """Current count of users per plan."""
    svc = AdminStatsService(db)
    data = await svc.get_plan_distribution()
    return PlanDistributionResponse(data=data)


@router.get("/top-users/analytics", response_model=TopUserAnalyticsResponse)
async def get_top_users_analytics(
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """Top N users by token usage with conversation and image counts."""
    svc = AdminStatsService(db)
    data = await svc.get_top_users_analytics(limit=limit)
    return TopUserAnalyticsResponse(data=data)
