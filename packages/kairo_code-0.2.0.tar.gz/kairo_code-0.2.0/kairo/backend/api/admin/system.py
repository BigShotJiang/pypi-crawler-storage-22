import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.admin_auth import require_role
from backend.core.database import get_db
from backend.models.user import User
from backend.schemas.admin.system import (
    ConfigEntry,
    ConfigResponse,
    FeatureFlagItem,
    FeatureFlagResponse,
    FeatureFlagUpdate,
    HealthStatus,
)
from backend.services.admin.audit_service import AuditService
from backend.services.admin.system_service import AdminSystemService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/system", tags=["admin-system"])


@router.get("/health", response_model=HealthStatus)
async def get_health(db: AsyncSession = Depends(get_db)):
    svc = AdminSystemService(db)
    data = await svc.get_health()
    return HealthStatus(**data)


@router.get("/feature-flags", response_model=FeatureFlagResponse)
async def get_feature_flags(db: AsyncSession = Depends(get_db)):
    svc = AdminSystemService(db)
    flags = await svc.get_feature_flags()
    items = []
    for f in flags:
        items.append(FeatureFlagItem(
            key=f.key,
            enabled=f.enabled,
            updated_by=f.updated_by,
            updated_at=f.updated_at.isoformat() if f.updated_at else None,
        ))
    return FeatureFlagResponse(flags=items)


@router.patch(
    "/feature-flags/{key}",
    dependencies=[Depends(require_role("superadmin"))],
)
async def toggle_feature_flag(
    key: str,
    body: FeatureFlagUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("superadmin")),
):
    svc = AdminSystemService(db)
    flag = await svc.toggle_feature_flag(key, body.enabled, admin.id)
    if not flag:
        raise HTTPException(status_code=404, detail="Feature flag not found")

    audit = AuditService(db)
    ip = request.client.host if request.client else "unknown"
    ua = request.headers.get("user-agent", "")
    await audit.log(
        admin_user_id=admin.id,
        action="system.feature_flag_toggled",
        target_type="feature_flag",
        target_id=key,
        details={"enabled": body.enabled, "reason": body.reason},
        ip_address=ip,
        user_agent=ua,
    )
    return FeatureFlagItem(
        key=flag.key,
        enabled=flag.enabled,
        updated_by=flag.updated_by,
        updated_at=flag.updated_at.isoformat() if flag.updated_at else None,
    )


@router.get("/config", response_model=ConfigResponse)
async def get_config(db: AsyncSession = Depends(get_db)):
    svc = AdminSystemService(db)
    entries = await svc.get_config()
    return ConfigResponse(config=[ConfigEntry(**e) for e in entries])
