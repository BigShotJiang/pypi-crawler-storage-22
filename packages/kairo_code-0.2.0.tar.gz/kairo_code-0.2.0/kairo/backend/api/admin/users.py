import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.admin_auth import require_role
from backend.core.database import get_db
from backend.models.user import User
from backend.schemas.admin.users import (
    AdminUserDetailResponse,
    AdminUserListItem,
    PlanChangeRequest,
    RoleChangeRequest,
    StatusChangeRequest,
)
from backend.services.admin.audit_service import AuditService
from backend.services.admin.user_service import AdminUserService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/users", tags=["admin-users"])


def _get_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _get_ua(request: Request) -> str:
    return request.headers.get("user-agent", "")


@router.get("")
async def list_users(
    search: str | None = Query(None),
    plan: str | None = Query(None),
    status: str | None = Query(None),
    cursor: str | None = Query(None),
    limit: int = Query(25, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    svc = AdminUserService(db)
    users = await svc.list_users(search=search, plan=plan, status=status, cursor=cursor, limit=limit + 1)
    has_more = len(users) > limit
    if has_more:
        users = users[:limit]
    items = [AdminUserListItem.model_validate(u) for u in users]
    next_cursor = users[-1].id if has_more else None
    return {"items": items, "next_cursor": next_cursor}


@router.get("/{user_id}", response_model=AdminUserDetailResponse)
async def get_user_detail(
    user_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    user = await svc.get_user_detail(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Audit the read
    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.detail_viewed",
        target_type="user",
        target_id=user_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return AdminUserDetailResponse.model_validate(user)


@router.patch("/{user_id}/plan", response_model=AdminUserDetailResponse)
async def change_user_plan(
    user_id: str,
    body: PlanChangeRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    old_user = await svc.get_user_detail(user_id)
    if not old_user:
        raise HTTPException(status_code=404, detail="User not found")

    old_plan = old_user.plan
    user = await svc.change_plan(user_id, body.plan)

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.plan_changed",
        target_type="user",
        target_id=user_id,
        details={"old_plan": old_plan, "new_plan": body.plan, "reason": body.reason},
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return AdminUserDetailResponse.model_validate(user)


@router.patch("/{user_id}/status", response_model=AdminUserDetailResponse)
async def change_user_status(
    user_id: str,
    body: StatusChangeRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    old_user = await svc.get_user_detail(user_id)
    if not old_user:
        raise HTTPException(status_code=404, detail="User not found")

    old_status = getattr(old_user, "status", "active")
    user = await svc.change_status(user_id, body.status)

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.status_changed",
        target_type="user",
        target_id=user_id,
        details={"old_status": old_status, "new_status": body.status, "reason": body.reason},
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return AdminUserDetailResponse.model_validate(user)


@router.patch(
    "/{user_id}/role",
    response_model=AdminUserDetailResponse,
    dependencies=[Depends(require_role("superadmin"))],
)
async def change_user_role(
    user_id: str,
    body: RoleChangeRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("superadmin")),
):
    svc = AdminUserService(db)
    old_user = await svc.get_user_detail(user_id)
    if not old_user:
        raise HTTPException(status_code=404, detail="User not found")

    old_role = getattr(old_user, "role", "user")
    user = await svc.change_role(user_id, body.role)

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.role_changed",
        target_type="user",
        target_id=user_id,
        details={"old_role": old_role, "new_role": body.role, "reason": body.reason},
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return AdminUserDetailResponse.model_validate(user)


@router.get("/{user_id}/usage")
async def get_user_usage(
    user_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    user = await svc.get_user_detail(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.usage_viewed",
        target_type="user",
        target_id=user_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return await svc.get_user_usage(user_id)


@router.get("/{user_id}/conversations")
async def get_user_conversations(
    user_id: str,
    request: Request,
    cursor: str | None = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    user = await svc.get_user_detail(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.conversations_viewed",
        target_type="user",
        target_id=user_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )

    conversations = await svc.get_user_conversations(user_id, cursor=cursor, limit=limit)
    return [
        {
            "id": c.id,
            "title": c.title,
            "model": c.model,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
        for c in conversations
    ]


@router.get("/{user_id}/images")
async def get_user_images(
    user_id: str,
    request: Request,
    cursor: str | None = Query(None),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    user = await svc.get_user_detail(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.images_viewed",
        target_type="user",
        target_id=user_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )

    from backend.schemas.admin.content import AdminImageListItem

    images = await svc.get_user_images(user_id, cursor=cursor, limit=limit)
    return [AdminImageListItem.model_validate(img) for img in images]


@router.get("/{user_id}/api-keys")
async def get_user_api_keys(
    user_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_role("admin")),
):
    svc = AdminUserService(db)
    user = await svc.get_user_detail(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    audit = AuditService(db)
    await audit.log(
        admin_user_id=admin.id,
        action="user.api_keys_viewed",
        target_type="user",
        target_id=user_id,
        ip_address=_get_ip(request),
        user_agent=_get_ua(request),
    )
    return await svc.get_user_api_keys(user_id)
