from datetime import datetime, UTC

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.core.api_key_auth import get_api_key_user
from backend.core.database import get_db
from backend.core.dependencies import get_current_user
from backend.models.api_key import ApiKey
from backend.models.user import User
from backend.schemas.agent import (
    AgentHeartbeatRequest,
    AgentHeartbeatResponse,
    AgentResponse,
    AgentListResponse,
    RegisterAgentRequest,
    UpdateAgentRequest,
    AgentMetricsResponse,
    AgentEventResponse,
    IssueCommandRequest,
    CommandResponse,
    CreateAlertConfigRequest,
    UpdateAlertConfigRequest,
    AlertConfigResponse,
    AlertHistoryResponse,
    SetupTokenResponse,
    AgentRegistrationRequest,
    AgentRegistrationResponse,
    TelemetryBatchRequest,
    TelemetryBatchResponse,
    AgentCommand,
)
from backend.services.agent_service import AgentService

router = APIRouter(prefix="/agents", tags=["Agents"])


def _check_enabled():
    if not settings.FEATURE_KAIRO_AGENTS_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo Agents is coming soon.")


# ─── CRUD ─────────────────────────────────────────────────────────────────────

@router.post("/", response_model=AgentResponse)
async def register_agent(
    req: RegisterAgentRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new agent."""
    _check_enabled()
    svc = AgentService(db)
    agent = await svc.register(user.id, req)
    return agent


@router.get("/", response_model=list[AgentListResponse])
async def list_agents(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all agents with 24h summary metrics."""
    _check_enabled()
    svc = AgentService(db)
    agents = await svc.list_agents_with_metrics(user.id)
    return agents


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get agent details."""
    _check_enabled()
    svc = AgentService(db)
    agent = await svc.get_agent(user.id, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.patch("/{agent_id}", response_model=AgentResponse)
async def update_agent(
    agent_id: str,
    req: UpdateAgentRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update agent configuration."""
    _check_enabled()
    svc = AgentService(db)
    agent = await svc.update_agent(user.id, agent_id, req)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.delete("/{agent_id}")
async def delete_agent(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete an agent (soft delete)."""
    _check_enabled()
    svc = AgentService(db)
    deleted = await svc.delete_agent(user.id, agent_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"deleted": True}


# ─── Setup & Registration ─────────────────────────────────────────────────────

@router.post("/{agent_id}/setup-token", response_model=SetupTokenResponse)
async def generate_setup_token(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Generate a one-time setup token for agent registration."""
    _check_enabled()
    svc = AgentService(db)
    result = await svc.generate_setup_token(user.id, agent_id)
    if not result:
        raise HTTPException(status_code=404, detail="Agent not found")
    token, expires_at = result
    return SetupTokenResponse(token=token, expires_at=expires_at, agent_id=agent_id)


@router.post("/register", response_model=AgentRegistrationResponse)
async def register_with_token(
    req: AgentRegistrationRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Register an agent using a setup token. Returns agent config and API key."""
    _check_enabled()
    client_ip = request.client.host if request.client else None
    svc = AgentService(db)

    # Consume token
    agent = await svc.consume_setup_token(req.setup_token, client_ip)
    if not agent:
        raise HTTPException(status_code=401, detail="Invalid or expired setup token")

    # Update SDK version
    agent.sdk_version = req.sdk_version
    if req.host_info:
        agent.host_info = req.host_info.model_dump()
    await db.commit()

    # Create agent-scoped API key
    api_key, _ = await svc.create_agent_api_key(agent.user_id, agent.id, agent.name)

    return AgentRegistrationResponse(
        agent_id=agent.id,
        name=agent.name,
        model_preference=agent.model_preference,
        system_prompt=agent.system_prompt,
        api_key=api_key,
    )


@router.get("/{agent_id}/connection-status")
async def get_connection_status(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Poll for agent connection status (for wizard verification step)."""
    _check_enabled()
    svc = AgentService(db)
    agent = await svc.get_agent(user.id, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {
        "connected": agent.first_connected_at is not None,
        "state": agent.state,
        "first_connected_at": agent.first_connected_at,
        "sdk_version": agent.sdk_version,
        "host_info": agent.host_info,
    }


# ─── Heartbeat ────────────────────────────────────────────────────────────────

@router.post("/heartbeat", response_model=AgentHeartbeatResponse)
async def agent_heartbeat(
    req: AgentHeartbeatRequest,
    request: Request,
    auth: tuple[User, ApiKey] = Depends(get_api_key_user),
    db: AsyncSession = Depends(get_db),
):
    """Agent heartbeat — authenticated via API key. Returns pending commands."""
    _check_enabled()
    user, _api_key = auth
    client_ip = request.client.host if request.client else None

    svc = AgentService(db)
    agent, commands = await svc.heartbeat(req.agent_id, user.id, req, client_ip)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found or not owned by this key's user")

    return AgentHeartbeatResponse(
        acknowledged=True,
        server_time=datetime.now(UTC),
        commands=[
            AgentCommand(
                command_id=cmd["command_id"],
                type=cmd["type"],
                payload=cmd["payload"],
                issued_at=cmd["issued_at"],
                expires_at=cmd["expires_at"],
                signature=cmd["signature"],
            )
            for cmd in commands
        ],
    )


# ─── Commands ─────────────────────────────────────────────────────────────────

@router.post("/{agent_id}/restart", response_model=CommandResponse)
async def restart_agent(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Request agent restart."""
    _check_enabled()
    svc = AgentService(db)
    req = IssueCommandRequest(command_type="restart")
    command = await svc.issue_command(user.id, agent_id, req)
    if not command:
        raise HTTPException(status_code=404, detail="Agent not found")
    return command


@router.post("/{agent_id}/stop", response_model=CommandResponse)
async def stop_agent(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Request agent stop."""
    _check_enabled()
    svc = AgentService(db)
    req = IssueCommandRequest(command_type="stop")
    command = await svc.issue_command(user.id, agent_id, req)
    if not command:
        raise HTTPException(status_code=404, detail="Agent not found")
    return command


@router.post("/{agent_id}/command", response_model=CommandResponse)
async def issue_command(
    agent_id: str,
    req: IssueCommandRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Issue a command to an agent."""
    _check_enabled()
    svc = AgentService(db)
    command = await svc.issue_command(user.id, agent_id, req)
    if not command:
        raise HTTPException(status_code=404, detail="Agent not found")
    return command


# ─── Metrics ──────────────────────────────────────────────────────────────────

@router.get("/{agent_id}/metrics", response_model=AgentMetricsResponse)
async def get_agent_metrics(
    agent_id: str,
    range: str = Query("24h", pattern="^(1h|6h|24h|7d|30d)$"),
    granularity: str = Query("auto", pattern="^(auto|1m|1h|1d)$"),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get agent metrics for a time range."""
    _check_enabled()
    svc = AgentService(db)
    metrics = await svc.get_metrics(user.id, agent_id, range, granularity)
    if metrics is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return metrics


# ─── Events ───────────────────────────────────────────────────────────────────

@router.get("/{agent_id}/events", response_model=list[AgentEventResponse])
async def get_agent_events(
    agent_id: str,
    event_type: str | None = Query(None),
    limit: int = Query(50, ge=1, le=500),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get agent events."""
    _check_enabled()
    svc = AgentService(db)
    events = await svc.get_events(user.id, agent_id, event_type, limit)
    if events is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return events


# ─── Alerts ───────────────────────────────────────────────────────────────────

@router.get("/{agent_id}/alerts", response_model=list[AlertConfigResponse])
async def get_alert_configs(
    agent_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get alert configurations for an agent."""
    _check_enabled()
    svc = AgentService(db)
    configs = await svc.get_alert_configs(user.id, agent_id)
    if configs is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return configs


@router.post("/{agent_id}/alerts", response_model=AlertConfigResponse)
async def create_alert_config(
    agent_id: str,
    req: CreateAlertConfigRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create an alert configuration."""
    _check_enabled()
    svc = AgentService(db)
    config = await svc.create_alert_config(user.id, agent_id, req)
    if not config:
        raise HTTPException(status_code=404, detail="Agent not found")
    return config


@router.patch("/{agent_id}/alerts/{config_id}", response_model=AlertConfigResponse)
async def update_alert_config(
    agent_id: str,
    config_id: str,
    req: UpdateAlertConfigRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an alert configuration."""
    _check_enabled()
    svc = AgentService(db)
    config = await svc.update_alert_config(user.id, agent_id, config_id, req)
    if not config:
        raise HTTPException(status_code=404, detail="Alert config not found")
    return config


@router.delete("/{agent_id}/alerts/{config_id}")
async def delete_alert_config(
    agent_id: str,
    config_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete an alert configuration."""
    _check_enabled()
    svc = AgentService(db)
    deleted = await svc.delete_alert_config(user.id, agent_id, config_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Alert config not found")
    return {"deleted": True}


@router.get("/{agent_id}/alerts/history", response_model=list[AlertHistoryResponse])
async def get_alert_history(
    agent_id: str,
    limit: int = Query(50, ge=1, le=500),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get alert history for an agent."""
    _check_enabled()
    svc = AgentService(db)
    history = await svc.get_alert_history(user.id, agent_id, limit)
    if history is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return history


# ─── SDK Telemetry ────────────────────────────────────────────────────────────

@router.post("/telemetry/batch", response_model=TelemetryBatchResponse)
async def submit_telemetry_batch(
    req: TelemetryBatchRequest,
    auth: tuple[User, ApiKey] = Depends(get_api_key_user),
    db: AsyncSession = Depends(get_db),
):
    """Submit a batch of telemetry events from the SDK."""
    _check_enabled()
    user, api_key = auth

    # Verify agent belongs to user
    svc = AgentService(db)
    agent = await svc.get_agent(user.id, req.agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    accepted, rejected, errors = await svc.process_telemetry_batch(req.agent_id, req)
    return TelemetryBatchResponse(accepted=accepted, rejected=rejected, errors=errors)
