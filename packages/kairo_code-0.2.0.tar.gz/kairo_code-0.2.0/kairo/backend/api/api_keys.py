from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.core.database import get_db
from backend.core.dependencies import get_current_user
from backend.models.user import User
from backend.schemas.api_key import (
    ApiKeyCreatedResponse,
    ApiKeyResponse,
    CreateApiKeyRequest,
    RevokeApiKeyResponse,
)
from backend.services.api_key_service import ApiKeyService
from backend.services.api_usage_service import ApiUsageService

router = APIRouter(prefix="/api-keys", tags=["API Keys"])


@router.post("/", response_model=ApiKeyCreatedResponse)
async def create_api_key(
    req: CreateApiKeyRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_KAIRO_API_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo API is coming soon.")
    svc = ApiKeyService(db)
    api_key, raw_key = await svc.create_key(user.id, req.name, req.expires_in_days)
    return ApiKeyCreatedResponse(
        id=api_key.id,
        name=api_key.name,
        key_prefix=api_key.key_prefix,
        is_active=api_key.is_active,
        last_used_at=api_key.last_used_at,
        created_at=api_key.created_at,
        expires_at=api_key.expires_at,
        full_key=raw_key,
    )


@router.get("/", response_model=list[ApiKeyResponse])
async def list_api_keys(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_KAIRO_API_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo API is coming soon.")
    svc = ApiKeyService(db)
    keys = await svc.list_keys(user.id)
    return keys


@router.delete("/{key_id}", response_model=RevokeApiKeyResponse)
async def revoke_api_key(
    key_id: str,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_KAIRO_API_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo API is coming soon.")
    svc = ApiKeyService(db)
    revoked = await svc.revoke_key(user.id, key_id)
    if not revoked:
        raise HTTPException(status_code=404, detail="API key not found")
    return RevokeApiKeyResponse(id=key_id, revoked=True)


@router.get("/{key_id}/usage")
async def get_key_usage(
    key_id: str,
    days: int = 30,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_KAIRO_API_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo API is coming soon.")
    # Verify key belongs to user
    key_svc = ApiKeyService(db)
    keys = await key_svc.list_keys(user.id)
    if not any(k.id == key_id for k in keys):
        raise HTTPException(status_code=404, detail="API key not found")
    usage_svc = ApiUsageService(db)
    history = await usage_svc.get_key_usage_summary(key_id, days)
    return {"usage": history}
