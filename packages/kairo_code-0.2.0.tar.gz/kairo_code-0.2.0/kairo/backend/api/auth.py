import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException

from backend.core.dependencies import get_auth_service, get_current_user, get_email_service
from backend.core.rate_limit import rate_limit_auth
from backend.core.security import create_access_token
from backend.models.user import User

logger = logging.getLogger(__name__)

from backend.schemas.auth import (
    ForgotPasswordRequest,
    LoginRequest,
    RegisterRequest,
    ResetPasswordRequest,
    TokenResponse,
    UserResponse,
    VerifyEmailRequest,
)
from backend.services.auth_service import AuthService
from backend.services.email_service import EmailService

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=TokenResponse, status_code=201, dependencies=[Depends(rate_limit_auth)])
async def register(
    body: RegisterRequest,
    auth_service: AuthService = Depends(get_auth_service),
    email_service: EmailService = Depends(get_email_service),
):
    user = await auth_service.register(body.email, body.password)
    if not user:
        raise HTTPException(status_code=409, detail="Email already registered")
    if user.email_verification_token:
        try:
            await asyncio.to_thread(
                email_service.send_verification_email, user.email, user.email_verification_token
            )
        except Exception:
            logger.exception("Failed to send verification email to %s", user.email)
    token = create_access_token(user.id)
    return TokenResponse(
        access_token=token,
        user=UserResponse.model_validate(user),
    )


@router.post("/login", response_model=TokenResponse, dependencies=[Depends(rate_limit_auth)])
async def login(
    body: LoginRequest,
    auth_service: AuthService = Depends(get_auth_service),
):
    user = await auth_service.authenticate(body.email, body.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token(user.id)
    return TokenResponse(
        access_token=token,
        user=UserResponse.model_validate(user),
    )


@router.get("/me", response_model=UserResponse)
async def get_me(user: User = Depends(get_current_user)):
    return UserResponse.model_validate(user)


@router.post("/verify-email", dependencies=[Depends(rate_limit_auth)])
async def verify_email(
    body: VerifyEmailRequest,
    auth_service: AuthService = Depends(get_auth_service),
):
    user = await auth_service.verify_email(body.token)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired verification token")
    return {"message": "Email verified successfully"}


@router.post("/forgot-password", dependencies=[Depends(rate_limit_auth)])
async def forgot_password(
    body: ForgotPasswordRequest,
    auth_service: AuthService = Depends(get_auth_service),
    email_service: EmailService = Depends(get_email_service),
):
    """Always returns 200 to prevent email enumeration."""
    token = await auth_service.request_password_reset(body.email)
    if token:
        await asyncio.to_thread(email_service.send_password_reset_email, body.email, token)
    return {"message": "If that email exists, a reset link has been sent"}


@router.post("/reset-password", dependencies=[Depends(rate_limit_auth)])
async def reset_password(
    body: ResetPasswordRequest,
    auth_service: AuthService = Depends(get_auth_service),
):
    success = await auth_service.reset_password(body.token, body.password)
    if not success:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    return {"message": "Password reset successfully"}


@router.post("/resend-verification", dependencies=[Depends(rate_limit_auth)])
async def resend_verification(
    user: User = Depends(get_current_user),
    auth_service: AuthService = Depends(get_auth_service),
    email_service: EmailService = Depends(get_email_service),
):
    token = await auth_service.regenerate_verification_token(user.id)
    if not token:
        return {"message": "Email already verified"}
    await asyncio.to_thread(email_service.send_verification_email, user.email, token)
    return {"message": "Verification email sent"}
