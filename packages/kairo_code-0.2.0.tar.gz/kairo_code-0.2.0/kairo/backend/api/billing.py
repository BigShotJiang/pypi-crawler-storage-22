from fastapi import APIRouter, Depends, HTTPException

from backend.core.dependencies import get_current_user, get_stripe_service
from backend.models.user import User
from backend.schemas.auth import BillingPortalResponse, BillingStatusResponse, CheckoutResponse
from backend.services.stripe_service import StripeService

router = APIRouter(prefix="/billing", tags=["billing"])


@router.post("/create-checkout", response_model=CheckoutResponse)
async def create_checkout(
    user: User = Depends(get_current_user),
    stripe_service: StripeService = Depends(get_stripe_service),
):
    if user.plan == "pro":
        raise HTTPException(status_code=400, detail="Already on Pro plan")
    checkout_url, customer_id = stripe_service.create_checkout_session(
        user.id, user.email, user.stripe_customer_id
    )
    return CheckoutResponse(checkout_url=checkout_url)


@router.post("/portal", response_model=BillingPortalResponse)
async def billing_portal(
    user: User = Depends(get_current_user),
    stripe_service: StripeService = Depends(get_stripe_service),
):
    if not user.stripe_customer_id:
        raise HTTPException(status_code=400, detail="No billing account found")
    portal_url = stripe_service.create_billing_portal_session(user.stripe_customer_id)
    return BillingPortalResponse(portal_url=portal_url)


@router.get("/status", response_model=BillingStatusResponse)
async def billing_status(user: User = Depends(get_current_user)):
    return BillingStatusResponse(
        plan=user.plan,
        stripe_customer_id=user.stripe_customer_id,
        stripe_subscription_id=user.stripe_subscription_id,
    )
