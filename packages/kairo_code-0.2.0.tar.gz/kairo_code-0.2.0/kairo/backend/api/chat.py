from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from starlette.responses import StreamingResponse

from backend.core.dependencies import get_chat_service, get_conversation_service
from backend.core.rate_limit import rate_limit_chat
from backend.schemas.chat import ChatRequest
from backend.services.chat_service import ChatService
from backend.services.conversation_service import ConversationService

router = APIRouter()


@router.post("/chat", dependencies=[Depends(rate_limit_chat)])
async def chat(
    request: ChatRequest,
    chat_service: ChatService = Depends(get_chat_service),
):
    return StreamingResponse(
        chat_service.stream_response(
            message=request.message,
            model=request.model,
            conversation_id=request.conversation_id,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            project_id=request.project_id,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


class EditMessageRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=32000)


@router.put("/chat/messages/{message_id}")
async def edit_message(
    message_id: str,
    request: EditMessageRequest,
    service: ConversationService = Depends(get_conversation_service),
):
    msg = await service.edit_message(message_id, request.content)
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")
    return {
        "id": msg.id,
        "conversation_id": msg.conversation_id,
        "role": msg.role,
        "content": msg.content,
        "created_at": msg.created_at,
    }


@router.post("/chat/regenerate/{conversation_id}", dependencies=[Depends(rate_limit_chat)])
async def regenerate(
    conversation_id: str,
    chat_service: ChatService = Depends(get_chat_service),
):
    return StreamingResponse(
        chat_service.regenerate_response(conversation_id=conversation_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
