import json

from fastapi import APIRouter, Depends, HTTPException, Query
from starlette.responses import Response

from backend.core.dependencies import get_conversation_service
from backend.schemas.conversation import (
    ConversationDetail,
    ConversationRename,
    ConversationSummary,
    MessageSchema,
)
from backend.services.conversation_service import ConversationService

router = APIRouter()


@router.get("/")
async def list_conversations(
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    q: str = Query(default="", max_length=200),
    project_id: str | None = Query(default=None),
    service: ConversationService = Depends(get_conversation_service),
):
    if q.strip():
        items, total = await service.search(q.strip(), limit=limit, offset=offset)
    else:
        items, total = await service.list_all(limit=limit, offset=offset, project_id=project_id)
    return {"items": items, "total": total}


@router.get("/search-messages")
async def search_messages(
    q: str = Query(..., min_length=2, max_length=200),
    limit: int = Query(default=20, ge=1, le=50),
    offset: int = Query(default=0, ge=0),
    service: ConversationService = Depends(get_conversation_service),
):
    results = await service.search_messages(q, limit=limit, offset=offset)
    return {"results": results}


@router.get("/{conversation_id}", response_model=ConversationDetail)
async def get_conversation(
    conversation_id: str,
    service: ConversationService = Depends(get_conversation_service),
):
    conv = await service.get(conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv


@router.delete("/{conversation_id}", status_code=204)
async def delete_conversation(
    conversation_id: str,
    service: ConversationService = Depends(get_conversation_service),
):
    deleted = await service.delete(conversation_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Conversation not found")


@router.patch("/{conversation_id}")
async def rename_conversation(
    conversation_id: str,
    body: ConversationRename,
    service: ConversationService = Depends(get_conversation_service),
):
    conv = await service.rename(conversation_id, body.title)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"id": conv.id, "title": conv.title}


@router.get("/{conversation_id}/export")
async def export_conversation(
    conversation_id: str,
    format: str = Query(default="md", pattern="^(md|json)$"),
    service: ConversationService = Depends(get_conversation_service),
):
    conv = await service.get(conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")

    messages = sorted(conv.messages, key=lambda m: m.created_at)
    safe_title = conv.title.replace(" ", "_").replace("/", "-")[:50]

    if format == "json":
        data = {
            "title": conv.title,
            "model": conv.model,
            "created_at": str(conv.created_at),
            "updated_at": str(conv.updated_at),
            "messages": [
                {
                    "role": m.role,
                    "content": m.content,
                    "created_at": str(m.created_at),
                }
                for m in messages
            ],
        }
        return Response(
            content=json.dumps(data, indent=2, ensure_ascii=False),
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="{safe_title}.json"'},
        )

    # Markdown format
    lines = [f"# {conv.title}\n"]
    lines.append(f"**Model:** {conv.model}  ")
    lines.append(f"**Date:** {conv.created_at}\n")
    lines.append("---\n")
    for m in messages:
        label = "User" if m.role == "user" else "Assistant"
        lines.append(f"## {label}\n")
        lines.append(f"{m.content}\n")
    content = "\n".join(lines)
    return Response(
        content=content,
        media_type="text/markdown",
        headers={"Content-Disposition": f'attachment; filename="{safe_title}.md"'},
    )
