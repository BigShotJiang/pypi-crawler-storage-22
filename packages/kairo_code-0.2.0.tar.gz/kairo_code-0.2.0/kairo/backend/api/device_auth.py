from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.core.database import get_db
from backend.core.dependencies import get_current_user
from backend.core.rate_limit import rate_limit_auth
from backend.models.user import PlanType, User
from backend.schemas.device_auth import (
    DeviceApproveRequest,
    DeviceApproveResponse,
    DeviceCodeRequest,
    DeviceCodeResponse,
    DeviceTokenRequest,
    DeviceTokenResponse,
)
from backend.services.device_auth_service import DeviceAuthService

router = APIRouter(prefix="/auth/device", tags=["Device Auth"])

_ERROR_DESCRIPTIONS = {
    "authorization_pending": "The user has not yet approved the request.",
    "slow_down": "Polling too frequently. Increase interval.",
    "expired_token": "The device code has expired. Please restart authentication.",
    "access_denied": "The user denied the request or does not have a Max plan.",
}


@router.post(
    "/code",
    response_model=DeviceCodeResponse,
    dependencies=[Depends(rate_limit_auth)],
)
async def request_device_code(
    body: DeviceCodeRequest,
    db: AsyncSession = Depends(get_db),
):
    """Initiate the device code flow (RFC 8628). Called by the CLI."""
    svc = DeviceAuthService(db)
    device = await svc.create_device_code(body.client_name)

    base_url = settings.APP_BASE_URL.rstrip("/")
    return DeviceCodeResponse(
        device_code=device.device_code,
        user_code=device.user_code,
        verification_uri=f"{base_url}/cli-auth",
        verification_uri_complete=f"{base_url}/cli-auth?code={device.user_code}",
        expires_in=DeviceAuthService.EXPIRY_MINUTES * 60,
        interval=device.interval,
    )


@router.post("/token")
async def poll_device_token(
    body: DeviceTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    """Poll for the access token. Called by the CLI at the configured interval."""
    svc = DeviceAuthService(db)
    status, user_info = await svc.poll_token(body.device_code)

    if status == "approved" and user_info:
        return DeviceTokenResponse(
            access_token=user_info["raw_key"],
            plan=user_info["plan"],
            email=user_info["email"],
        )

    # RFC 8628: return 400 with structured error for non-success states
    raise HTTPException(
        status_code=400,
        detail={
            "error": status,
            "error_description": _ERROR_DESCRIPTIONS.get(status, "Unknown error"),
        },
    )


@router.post("/approve", response_model=DeviceApproveResponse)
async def approve_device(
    body: DeviceApproveRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Approve a pending device code. Called from the web UI by a logged-in user."""
    if user.plan != PlanType.MAX.value:
        raise HTTPException(
            status_code=403,
            detail="Kairo Code requires a Max plan.",
        )

    svc = DeviceAuthService(db)
    result = await svc.approve(body.user_code, user)
    if not result:
        raise HTTPException(status_code=404, detail="Invalid or expired code.")

    return DeviceApproveResponse(
        approved=True,
        message="CLI authorized successfully.",
    )
