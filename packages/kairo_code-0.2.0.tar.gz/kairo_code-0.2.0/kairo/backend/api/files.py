import logging
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel

from backend.core.dependencies import get_current_user
from backend.models.user import User

logger = logging.getLogger(__name__)

router = APIRouter()

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

TEXT_EXTENSIONS = {
    ".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".css", ".html",
    ".json", ".yaml", ".yml", ".xml", ".csv", ".sh", ".bash", ".zsh",
    ".rb", ".go", ".rs", ".java", ".c", ".cpp", ".h", ".hpp", ".swift",
    ".kt", ".scala", ".r", ".sql", ".toml", ".ini", ".cfg", ".conf",
    ".env", ".gitignore", ".dockerfile", ".makefile",
}

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}


class FileUploadResponse(BaseModel):
    filename: str
    text: str
    type: str


@router.post("/files/upload", response_model=FileUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided.")

    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File too large. Maximum size is 10 MB.")

    ext = Path(file.filename).suffix.lower()

    if ext in TEXT_EXTENSIONS:
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            try:
                text = content.decode("latin-1")
            except Exception:
                raise HTTPException(status_code=400, detail="Could not decode file as text.")
        return FileUploadResponse(filename=file.filename, text=text, type="text")

    if ext in IMAGE_EXTENSIONS:
        return FileUploadResponse(
            filename=file.filename,
            text=f"[Image: {file.filename} ({len(content) // 1024} KB)]",
            type="image",
        )

    if ext == ".pdf":
        return FileUploadResponse(
            filename=file.filename,
            text=f"[PDF: {file.filename} ({len(content) // 1024} KB)]",
            type="pdf",
        )

    if ext in (".doc", ".docx"):
        return FileUploadResponse(
            filename=file.filename,
            text=f"[Document: {file.filename} ({len(content) // 1024} KB)]",
            type="document",
        )

    # Fallback: try to read as text
    try:
        text = content.decode("utf-8")
        return FileUploadResponse(filename=file.filename, text=text, type="text")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {ext}")
