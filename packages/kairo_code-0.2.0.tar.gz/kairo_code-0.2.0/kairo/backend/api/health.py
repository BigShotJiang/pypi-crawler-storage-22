from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.core.dependencies import get_llm_service
from backend.schemas.status import StatusPageResponse
from backend.services.llm_service import LLMService
from backend.services.status_service import StatusService

router = APIRouter()


@router.get("/health")
async def health(llm_service: LLMService = Depends(get_llm_service)):
    vllm_ok = await llm_service.check_health()
    return {
        "status": "ok",
        "vllm": "connected" if vllm_ok else "disconnected",
    }


@router.get("/models")
async def list_models(llm_service: LLMService = Depends(get_llm_service)):
    models = await llm_service.list_available_models()
    return {"models": models}


@router.get("/status", response_model=StatusPageResponse)
async def get_status_page(
    db: AsyncSession = Depends(get_db),
    llm_service: LLMService = Depends(get_llm_service),
):
    """Public status page endpoint. No authentication required."""
    svc = StatusService(db, llm_service)
    data = await svc.get_status_page()
    return StatusPageResponse(**data)
