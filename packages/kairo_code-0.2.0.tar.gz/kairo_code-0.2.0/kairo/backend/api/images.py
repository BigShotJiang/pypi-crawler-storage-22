import logging

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.core.dependencies import get_current_user, get_db
from backend.models.user import User
from backend.schemas.image import ImageGenerateRequest, ImageGenerateResponse
from backend.services.image_service import ImageService

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/images/generate", response_model=ImageGenerateResponse)
async def generate_image(
    request: ImageGenerateRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_IMAGE_GEN_ENABLED:
        raise HTTPException(status_code=404, detail="Image generation is not available.")

    service = ImageService(db, user_id=user.id)

    allowed, reason = await service.check_access()
    if not allowed:
        raise HTTPException(status_code=403, detail=reason)

    try:
        result = await service.generate(
            prompt=request.prompt,
            conversation_id=request.conversation_id,
            width=request.width,
            height=request.height,
        )
        return ImageGenerateResponse(**result)
    except Exception:
        logger.exception("Image generation failed")
        raise HTTPException(status_code=500, detail="Image generation failed. Please try again.")


@router.post("/images/img2img", response_model=ImageGenerateResponse)
async def img2img(
    image: UploadFile = File(...),
    prompt: str = Form(..., min_length=1, max_length=2000),
    conversation_id: str | None = Form(default=None),
    strength: float = Form(default=0.75, ge=0.0, le=1.0),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not settings.FEATURE_IMAGE_GEN_ENABLED:
        raise HTTPException(status_code=404, detail="Image generation is not available.")

    service = ImageService(db, user_id=user.id)

    allowed, reason = await service.check_access()
    if not allowed:
        raise HTTPException(status_code=403, detail=reason)

    if image.content_type not in ("image/png", "image/jpeg", "image/webp"):
        raise HTTPException(status_code=400, detail="Image must be PNG, JPEG, or WebP.")

    image_bytes = await image.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Image too large. Maximum 10 MB.")

    try:
        result = await service.generate_img2img(
            image_bytes=image_bytes,
            prompt=prompt,
            conversation_id=conversation_id,
            strength=strength,
        )
        return ImageGenerateResponse(**result)
    except Exception:
        logger.exception("img2img generation failed")
        raise HTTPException(status_code=500, detail="Image generation failed. Please try again.")
