"""OpenAI-compatible API endpoint — mounted at /v1/ for SDK compatibility."""

import json
import logging
import time
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.core.api_key_auth import get_api_key_user
from backend.core.database import get_db
from backend.core.rate_limit import rate_limit_api
from backend.models.api_key import ApiKey
from backend.models.user import User
from backend.schemas.openai_compat import (
    ChatCompletionChunk,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionChoice,
    ChatMessage,
    ChoiceDelta,
    StreamChoice,
    UsageInfo,
)
from backend.services.api_usage_service import ApiUsageService
from backend.services.llm_service import LLMService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v1", tags=["OpenAI Compatible"])


def _get_llm_service(request: Request) -> LLMService:
    return request.app.state.llm_service


@router.post("/chat/completions")
async def chat_completions(
    req: ChatCompletionRequest,
    request: Request,
    auth: tuple[User, ApiKey] = Depends(get_api_key_user),
    db: AsyncSession = Depends(get_db),
    llm_service: LLMService = Depends(_get_llm_service),
    _rate: None = Depends(rate_limit_api),
):
    if not settings.FEATURE_KAIRO_API_ENABLED:
        raise HTTPException(status_code=503, detail="Kairo API is coming soon.")

    user, api_key = auth

    # Check API usage limits
    usage_svc = ApiUsageService(db)
    allowed, reason = await usage_svc.check_limits(user.id)
    if not allowed:
        raise HTTPException(status_code=429, detail=reason)

    # Resolve model
    model_id = llm_service.resolve_model(req.model)
    client, base_url, resolved_model, _is_fallback = llm_service._select_backend(req.model)

    # Build vLLM payload — serialize full request, override model with resolved name
    payload = req.model_dump(exclude_none=True)
    payload["model"] = resolved_model

    request_id = f"chatcmpl-{uuid.uuid4().hex[:24]}"
    created = int(time.time())

    if req.stream:
        payload["stream_options"] = {"include_usage": True}
        return StreamingResponse(
            _stream_proxy(
                client, base_url, payload, request_id, created, resolved_model,
                api_key.id, user.id, db,
            ),
            media_type="text/event-stream",
        )
    else:
        # Non-streaming: proxy full request
        try:
            resp = await client.post(f"{base_url}/v1/chat/completions", json=payload)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.error("vLLM proxy error: %s", e)
            raise HTTPException(status_code=502, detail="Inference backend unavailable")

        # Record usage
        usage = data.get("usage", {})
        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        await usage_svc.record(
            api_key_id=api_key.id, user_id=user.id, model=resolved_model,
            prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
            endpoint="/v1/chat/completions",
        )

        # Reformat as our response — forward all message fields including tool_calls
        choices = []
        for c in data.get("choices", []):
            msg = c.get("message", {})
            choices.append(ChatCompletionChoice(
                index=c.get("index", 0),
                message=ChatMessage(
                    role=msg.get("role", "assistant"),
                    content=msg.get("content"),
                    name=msg.get("name"),
                    tool_calls=msg.get("tool_calls"),
                    tool_call_id=msg.get("tool_call_id"),
                ),
                finish_reason=c.get("finish_reason"),
            ))

        return ChatCompletionResponse(
            id=request_id, created=created, model=resolved_model,
            choices=choices,
            usage=UsageInfo(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=prompt_tokens + completion_tokens,
            ) if usage else None,
        )


async def _stream_proxy(
    client, base_url, payload, request_id, created, model,
    api_key_id, user_id, db,
):
    """Stream SSE from vLLM, relay in OpenAI format, record usage at end."""
    prompt_tokens = 0
    completion_tokens = 0

    try:
        async with client.stream("POST", f"{base_url}/v1/chat/completions", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data_str)
                    # Capture usage
                    if "usage" in chunk and chunk["usage"]:
                        prompt_tokens = chunk["usage"].get("prompt_tokens", 0)
                        completion_tokens = chunk["usage"].get("completion_tokens", 0)

                    choices = chunk.get("choices", [])
                    if not choices:
                        # Emit usage-only final chunk if present
                        if prompt_tokens or completion_tokens:
                            usage_chunk = ChatCompletionChunk(
                                id=request_id, created=created, model=model,
                                choices=[],
                                usage=UsageInfo(
                                    prompt_tokens=prompt_tokens,
                                    completion_tokens=completion_tokens,
                                    total_tokens=prompt_tokens + completion_tokens,
                                ),
                            )
                            yield f"data: {usage_chunk.model_dump_json()}\n\n"
                        continue

                    # Forward all choices, including tool_calls deltas
                    stream_choices = []
                    for c in choices:
                        delta = c.get("delta", {})
                        stream_choices.append(StreamChoice(
                            index=c.get("index", 0),
                            delta=ChoiceDelta(
                                role=delta.get("role"),
                                content=delta.get("content"),
                                tool_calls=delta.get("tool_calls"),
                            ),
                            finish_reason=c.get("finish_reason"),
                        ))
                    out = ChatCompletionChunk(
                        id=request_id, created=created, model=model,
                        choices=stream_choices,
                    )
                    yield f"data: {out.model_dump_json()}\n\n"
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue

        yield "data: [DONE]\n\n"
    except Exception as e:
        logger.error("Stream proxy error: %s", e)
        yield f"data: {json.dumps({'error': 'Inference backend error'})}\n\n"
        yield "data: [DONE]\n\n"

    # Record usage after stream completes
    if prompt_tokens or completion_tokens:
        try:
            usage_svc = ApiUsageService(db)
            await usage_svc.record(
                api_key_id=api_key_id, user_id=user_id, model=model,
                prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
                endpoint="/v1/chat/completions",
            )
        except Exception as e:
            logger.error("Failed to record API usage: %s", e)


@router.get("/models")
async def list_models(
    llm_service: LLMService = Depends(_get_llm_service),
):
    """List available models — public endpoint, no auth required."""
    models = await llm_service.list_available_models()
    return {
        "object": "list",
        "data": [
            {
                "id": m["id"],
                "object": "model",
                "owned_by": "kairon-labs",
                "permission": [],
            }
            for m in models
            if m.get("available", True)
        ],
    }
