from fastapi import APIRouter, Depends, HTTPException

from backend.core.dependencies import get_project_service
from backend.schemas.project import ProjectCreate, ProjectUpdate, ProjectResponse
from backend.services.project_service import ProjectService

router = APIRouter()


@router.post("/", response_model=ProjectResponse)
async def create_project(
    body: ProjectCreate,
    service: ProjectService = Depends(get_project_service),
):
    project = await service.create(body.name)
    return {
        "id": project.id,
        "name": project.name,
        "instructions": project.instructions,
        "conversation_count": 0,
        "created_at": project.created_at,
        "updated_at": project.updated_at,
    }


@router.get("/", response_model=list[ProjectResponse])
async def list_projects(
    service: ProjectService = Depends(get_project_service),
):
    return await service.list_all()


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: str,
    service: ProjectService = Depends(get_project_service),
):
    project = await service.get(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return {
        "id": project.id,
        "name": project.name,
        "instructions": project.instructions,
        "conversation_count": len(project.conversations),
        "created_at": project.created_at,
        "updated_at": project.updated_at,
    }


@router.patch("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    body: ProjectUpdate,
    service: ProjectService = Depends(get_project_service),
):
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    project = await service.update(project_id, **updates)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return {
        "id": project.id,
        "name": project.name,
        "instructions": project.instructions,
        "conversation_count": len(project.conversations),
        "created_at": project.created_at,
        "updated_at": project.updated_at,
    }


@router.delete("/{project_id}", status_code=204)
async def delete_project(
    project_id: str,
    service: ProjectService = Depends(get_project_service),
):
    deleted = await service.delete(project_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Project not found")


@router.post("/{project_id}/conversations/{conversation_id}", status_code=204)
async def add_conversation_to_project(
    project_id: str,
    conversation_id: str,
    service: ProjectService = Depends(get_project_service),
):
    added = await service.add_conversation(project_id, conversation_id)
    if not added:
        raise HTTPException(status_code=404, detail="Project or conversation not found")


@router.delete("/{project_id}/conversations/{conversation_id}", status_code=204)
async def remove_conversation_from_project(
    project_id: str,
    conversation_id: str,
    service: ProjectService = Depends(get_project_service),
):
    removed = await service.remove_conversation(conversation_id)
    if not removed:
        raise HTTPException(status_code=404, detail="Conversation not found")
