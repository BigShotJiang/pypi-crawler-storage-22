from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.core.dependencies import get_current_user
from backend.models.user import User
from backend.schemas.usage import UsageSummaryResponse, UsageHistoryResponse, UsageHistoryEntry
from backend.services.usage_service import UsageService

router = APIRouter(prefix="/usage", tags=["usage"])


@router.get("/summary", response_model=UsageSummaryResponse)
async def usage_summary(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    service = UsageService(db)
    return await service.get_usage_summary(user.id)


@router.get("/history", response_model=UsageHistoryResponse)
async def usage_history(
    days: int = Query(default=30, ge=1, le=365),
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    service = UsageService(db)
    entries = await service.get_usage_history(user.id, days=days)
    return UsageHistoryResponse(
        entries=[UsageHistoryEntry(**e) for e in entries]
    )
