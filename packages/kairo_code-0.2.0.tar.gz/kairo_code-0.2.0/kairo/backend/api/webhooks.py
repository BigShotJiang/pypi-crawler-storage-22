import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.models.user import PlanType, User
from backend.services.stripe_service import StripeService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("/stripe")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")

    stripe_service = StripeService()
    try:
        result = stripe_service.handle_webhook_event(payload, sig)
    except Exception as e:
        logger.warning("Webhook signature verification failed: %s", e)
        raise HTTPException(status_code=400, detail="Invalid signature")

    action = result.get("action")

    if action == "upgrade":
        customer_id = result["customer_id"]
        subscription_id = result["subscription_id"]
        user_id = result.get("user_id")

        user = None
        if user_id:
            user = await db.get(User, user_id)
        if not user:
            stmt = select(User).where(User.stripe_customer_id == customer_id)
            res = await db.execute(stmt)
            user = res.scalar_one_or_none()
        if user:
            user.plan = PlanType.PRO.value
            user.stripe_customer_id = customer_id
            user.stripe_subscription_id = subscription_id
            await db.commit()
            logger.info("User %s upgraded to Pro", user.id)
        else:
            logger.error("Webhook upgrade: no user found for customer=%s user_id=%s", customer_id, user_id)

    elif action == "downgrade":
        customer_id = result["customer_id"]
        stmt = select(User).where(User.stripe_customer_id == customer_id)
        res = await db.execute(stmt)
        user = res.scalar_one_or_none()
        if user:
            user.plan = PlanType.FREE.value
            user.stripe_subscription_id = None
            await db.commit()
            logger.info("User %s downgraded to Free", user.id)
        else:
            logger.error("Webhook downgrade: no user found for customer=%s", customer_id)

    elif action == "sync_active":
        customer_id = result["customer_id"]
        subscription_id = result["subscription_id"]
        stmt = select(User).where(User.stripe_customer_id == customer_id)
        res = await db.execute(stmt)
        user = res.scalar_one_or_none()
        if user:
            user.plan = PlanType.PRO.value
            user.stripe_subscription_id = subscription_id
            await db.commit()

    elif action == "payment_failed":
        customer_id = result["customer_id"]
        logger.warning("Payment failed for customer %s", customer_id)

    return {"received": True}
