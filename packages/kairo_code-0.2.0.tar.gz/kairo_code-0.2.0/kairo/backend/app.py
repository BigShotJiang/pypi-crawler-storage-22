import asyncio
import logging
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import Response
from starlette.types import ASGIApp, Receive, Scope, Send

from backend.core.database import init_db
from backend.core.logging import setup_logging
from backend.api.auth import router as auth_router
from backend.api.billing import router as billing_router
from backend.api.chat import router as chat_router
from backend.api.conversations import router as conversations_router
from backend.api.health import router as health_router
from backend.api.projects import router as projects_router
from backend.api.usage import router as usage_router
from backend.api.webhooks import router as webhooks_router
from backend.api.api_keys import router as api_keys_router
from backend.api.agents import router as agents_router
from backend.api.images import router as images_router
from backend.api.openai_compat import router as openai_compat_router
from backend.api.admin import router as admin_router
from backend.api.device_auth import router as device_auth_router
from backend.api.files import router as files_router

logger = logging.getLogger(__name__)

# Regex to redact passwords from DB URLs
_DB_URL_RE = re.compile(r"(://\w+:)[^@]+(@)")


def _redact_url(url: str) -> str:
    return _DB_URL_RE.sub(r"\1***\2", url)


class RequestLoggingMiddleware:
    """Pure ASGI middleware — does not wrap StreamingResponse body."""

    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        start = time.perf_counter()
        status_code = 0

        async def send_wrapper(message):
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
            await send(message)

        path = scope.get("path", "")
        await self.app(scope, receive, send_wrapper)

        if path.startswith("/api"):
            elapsed_ms = (time.perf_counter() - start) * 1000
            method = scope.get("method", "?")
            logger.info(
                "%s %s → %d (%.0fms)", method, path, status_code, elapsed_ms,
            )


@asynccontextmanager
async def lifespan(app: FastAPI):
    from backend.config import settings

    setup_logging(settings.LOG_LEVEL)

    # Ensure data directory exists
    Path(settings.DATA_DIR).mkdir(parents=True, exist_ok=True)

    logger.info("Kairo starting up")
    logger.info("Data dir: %s", Path(settings.DATA_DIR).resolve())
    logger.info("Database: %s", _redact_url(settings.DATABASE_URL))
    logger.info("vLLM: %s", settings.VLLM_BASE_URL)
    if settings.VLLM_LITE_BASE_URL:
        logger.info("vLLM Lite: %s", settings.VLLM_LITE_BASE_URL)
    await init_db()
    logger.info("Database initialized")

    # Shared LLM client
    from backend.services.llm_service import LLMService
    app.state.llm_service = LLMService()
    logger.info("LLM client initialized")

    # Background health checker for primary and lite vLLM
    async def _health_check_loop():
        llm: LLMService = app.state.llm_service
        while True:
            try:
                await llm.check_primary_health()
                await llm.check_lite_health()
            except Exception as e:
                logger.warning("Health check loop error: %s", e)
            await asyncio.sleep(30)

    health_task = asyncio.create_task(_health_check_loop())
    logger.info("vLLM health check started (primary + lite, 30s interval)")

    # Background task to mark stale agents as offline
    async def _agent_staleness_loop():
        from backend.core.database import async_session
        from backend.services.agent_service import AgentService
        while True:
            try:
                async with async_session() as db:
                    svc = AgentService(db)
                    await svc.mark_stale_agents_offline(settings.AGENT_OFFLINE_THRESHOLD_SECONDS)
            except Exception as e:
                logger.warning("Agent staleness check error: %s", e)
            await asyncio.sleep(60)

    agent_task = asyncio.create_task(_agent_staleness_loop())
    logger.info("Agent staleness checker started (60s interval)")

    # Background task for hourly metrics rollup
    async def _metrics_rollup_hourly_loop():
        from backend.core.database import async_session
        from backend.services.agent_service import AgentService
        # Wait 5 minutes after startup before first run
        await asyncio.sleep(300)
        while True:
            try:
                async with async_session() as db:
                    svc = AgentService(db)
                    await svc.rollup_1m_to_1h()
            except Exception as e:
                logger.warning("Hourly metrics rollup error: %s", e)
            await asyncio.sleep(3600)  # Every hour

    metrics_hourly_task = asyncio.create_task(_metrics_rollup_hourly_loop())
    logger.info("Hourly metrics rollup started (3600s interval)")

    # Background task for daily metrics rollup
    async def _metrics_rollup_daily_loop():
        from backend.core.database import async_session
        from backend.services.agent_service import AgentService
        # Wait 10 minutes after startup before first run
        await asyncio.sleep(600)
        while True:
            try:
                async with async_session() as db:
                    svc = AgentService(db)
                    await svc.rollup_1h_to_daily()
                    await svc.cleanup_old_metrics()
                    await svc.cleanup_old_events()
            except Exception as e:
                logger.warning("Daily metrics rollup error: %s", e)
            await asyncio.sleep(86400)  # Every 24 hours

    metrics_daily_task = asyncio.create_task(_metrics_rollup_daily_loop())
    logger.info("Daily metrics rollup started (86400s interval)")

    # Background task for alert evaluation
    async def _alert_evaluation_loop():
        from backend.core.database import async_session
        from backend.services.agent_service import AgentService
        while True:
            try:
                async with async_session() as db:
                    svc = AgentService(db)
                    await svc.evaluate_alerts()
            except Exception as e:
                logger.warning("Alert evaluation error: %s", e)
            await asyncio.sleep(60)  # Every minute

    alert_task = asyncio.create_task(_alert_evaluation_loop())
    logger.info("Alert evaluation started (60s interval)")

    # Background task to clean up expired device codes
    async def _device_code_cleanup_loop():
        from backend.core.database import async_session
        from backend.services.device_auth_service import DeviceAuthService
        while True:
            try:
                async with async_session() as db:
                    svc = DeviceAuthService(db)
                    await svc.cleanup_expired()
            except Exception as e:
                logger.warning("Device code cleanup error: %s", e)
            await asyncio.sleep(300)  # every 5 minutes

    device_cleanup_task = asyncio.create_task(_device_code_cleanup_loop())
    logger.info("Device code cleanup started (300s interval)")

    # Background task to record uptime snapshots every hour
    async def _uptime_recording_loop():
        import uuid
        from datetime import date as date_type, datetime as dt, UTC as utc_tz
        from sqlalchemy import select
        from backend.core.database import async_session as uptime_session
        from backend.models.uptime_record import UptimeRecord

        # Wait 60s on startup before first snapshot
        await asyncio.sleep(60)

        while True:
            try:
                llm: LLMService = app.state.llm_service
                today = date_type.today()

                # Determine current component health
                components = {
                    "API": True,  # If this code is running, API is up
                    "Models": getattr(llm, "primary_healthy", False) or getattr(llm, "lite_healthy", False),
                    "Database": True,  # If we can write records, DB is up
                }

                # Check image generation health
                if settings.FEATURE_IMAGE_GEN_ENABLED and settings.FLUX_BASE_URL:
                    try:
                        async with httpx.AsyncClient(timeout=5.0) as hc:
                            resp = await hc.get(f"{settings.FLUX_BASE_URL}/health")
                            components["Image Generation"] = resp.status_code == 200
                    except Exception:
                        components["Image Generation"] = False
                else:
                    components["Image Generation"] = False

                async with uptime_session() as db:
                    for comp_name, is_healthy in components.items():
                        # Check if a record already exists for this component+date
                        stmt = (
                            select(UptimeRecord)
                            .where(UptimeRecord.component == comp_name, UptimeRecord.date == today)
                        )
                        result = await db.execute(stmt)
                        record = result.scalar_one_or_none()

                        if record:
                            # Update: running average of uptime checks
                            # Each check is either 100% (healthy) or 0% (down)
                            # We weight the new check into the existing average
                            check_value = 100.0 if is_healthy else 0.0
                            # Simple exponential moving average with ~24 samples/day
                            record.uptime_percent = round(
                                record.uptime_percent * 0.96 + check_value * 0.04, 2
                            )
                        else:
                            # First record for this component+date
                            record = UptimeRecord(
                                id=str(uuid.uuid4()),
                                component=comp_name,
                                date=today,
                                uptime_percent=100.0 if is_healthy else 0.0,
                                incidents_count=0,
                                created_at=dt.now(utc_tz),
                            )
                            db.add(record)

                    await db.commit()
                    logger.debug("Uptime snapshot recorded for %s", today)

            except Exception as e:
                logger.warning("Uptime recording loop error: %s", e)

            await asyncio.sleep(3600)  # Every hour

    uptime_task = asyncio.create_task(_uptime_recording_loop())
    logger.info("Uptime recording started (3600s interval)")

    yield

    health_task.cancel()
    agent_task.cancel()
    device_cleanup_task.cancel()
    uptime_task.cancel()
    metrics_hourly_task.cancel()
    metrics_daily_task.cancel()
    alert_task.cancel()
    await app.state.llm_service.close()
    logger.info("Kairo shutting down")


def create_app() -> FastAPI:
    from backend.config import settings

    app = FastAPI(title="Kairo", version="0.1.0", lifespan=lifespan)

    # GZip compression for responses > 500 bytes
    app.add_middleware(GZipMiddleware, minimum_size=500)

    # CORS — configurable via env
    origins = [o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Pure ASGI logging middleware (safe for SSE streaming)
    app.add_middleware(RequestLoggingMiddleware)

    # Global error handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error("Unhandled error on %s %s: %s", request.method, request.url.path, exc)
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    # API routes
    app.include_router(auth_router, prefix="/api")
    app.include_router(billing_router, prefix="/api")
    app.include_router(chat_router, prefix="/api")
    app.include_router(conversations_router, prefix="/api/conversations")
    app.include_router(projects_router, prefix="/api/projects")
    app.include_router(health_router, prefix="/api")
    app.include_router(usage_router, prefix="/api")
    app.include_router(webhooks_router, prefix="/api")
    app.include_router(api_keys_router, prefix="/api")
    app.include_router(agents_router, prefix="/api")
    app.include_router(images_router, prefix="/api")
    app.include_router(openai_compat_router)  # mounted at /v1, no /api prefix
    app.include_router(admin_router, prefix="/api")
    app.include_router(device_auth_router, prefix="/api")
    app.include_router(files_router, prefix="/api")

    # Serve static frontend build with proper cache headers
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        # Custom middleware to add cache headers for assets
        class CachedStaticFiles(StaticFiles):
            async def __call__(self, scope, receive, send):
                async def send_with_cache(message):
                    if message["type"] == "http.response.start":
                        headers = list(message.get("headers", []))
                        # Hashed assets are immutable - cache for 1 year
                        headers.append((b"cache-control", b"public, max-age=31536000, immutable"))
                        message["headers"] = headers
                    await send(message)
                await super().__call__(scope, receive, send_with_cache)

        app.mount("/assets", CachedStaticFiles(directory=static_dir / "assets"), name="assets")

        @app.get("/{full_path:path}")
        async def serve_spa(full_path: str):
            file_path = (static_dir / full_path).resolve()
            # Path traversal guard
            if not str(file_path).startswith(str(static_dir.resolve())):
                return FileResponse(
                    static_dir / "index.html",
                    headers={"Cache-Control": "no-cache, must-revalidate"}
                )
            if file_path.is_file():
                return FileResponse(file_path)
            return FileResponse(
                static_dir / "index.html",
                headers={"Cache-Control": "no-cache, must-revalidate"}
            )

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    from backend.config import settings

    uvicorn.run("backend.app:app", host=settings.HOST, port=settings.PORT, reload=True)
