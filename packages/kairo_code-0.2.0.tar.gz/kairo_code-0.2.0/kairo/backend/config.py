import logging
import os
import secrets

from pydantic_settings import BaseSettings

_logger = logging.getLogger(__name__)


def _stable_jwt_secret(data_dir: str = "./data") -> str:
    """Return a stable JWT secret: env var > file > generate-and-persist."""
    env_val = os.environ.get("KAIRO_JWT_SECRET_KEY")
    if env_val:
        return env_val
    os.makedirs(data_dir, exist_ok=True)
    secret_path = os.path.join(data_dir, ".jwt_secret")
    try:
        with open(secret_path) as f:
            return f.read().strip()
    except FileNotFoundError:
        secret = secrets.token_urlsafe(32)
        with open(secret_path, "w") as f:
            f.write(secret)
        os.chmod(secret_path, 0o600)
        _logger.info("Generated new JWT secret at %s", secret_path)
        return secret


class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+asyncpg://kairo:kairo@localhost:5432/kairo"
    VLLM_BASE_URL: str = "http://localhost:8000"
    VLLM_LITE_BASE_URL: str = ""
    VLLM_API_KEY: str = ""
    HOST: str = "0.0.0.0"
    PORT: int = 3000
    LOG_LEVEL: str = "INFO"
    DATA_DIR: str = "./data"

    # Auth
    JWT_SECRET_KEY: str = ""
    JWT_EXPIRE_HOURS: int = 24

    # Usage limits (Free tier defaults)
    DEFAULT_DAILY_TOKEN_LIMIT: int = 100_000
    DEFAULT_MONTHLY_TOKEN_LIMIT: int = 2_000_000

    # Pro tier limits
    PRO_DAILY_TOKEN_LIMIT: int = 1_000_000
    PRO_MONTHLY_TOKEN_LIMIT: int = 30_000_000

    # Max tier limits
    MAX_DAILY_TOKEN_LIMIT: int = 5_000_000
    MAX_MONTHLY_TOKEN_LIMIT: int = 150_000_000

    # API token rates (per 1M tokens, in cents)
    API_RATE_NYX_INPUT: int = 100       # $1.00 per 1M
    API_RATE_NYX_OUTPUT: int = 300      # $3.00 per 1M
    API_RATE_NYX_LITE_INPUT: int = 50   # $0.50 per 1M
    API_RATE_NYX_LITE_OUTPUT: int = 150 # $1.50 per 1M
    API_MAX_DISCOUNT_PERCENT: int = 50  # Max tier gets 50% off

    # API tier limits (separate pool from chat)
    API_DAILY_TOKEN_LIMIT: int = 500_000
    API_MONTHLY_TOKEN_LIMIT: int = 10_000_000
    API_PRO_DAILY_TOKEN_LIMIT: int = 5_000_000
    API_PRO_MONTHLY_TOKEN_LIMIT: int = 100_000_000

    # CLI usage limits (separate from chat/API)
    CLI_DAILY_TOKEN_LIMIT: int = 10_000_000
    CLI_MONTHLY_TOKEN_LIMIT: int = 300_000_000

    # Image generation
    FLUX_BASE_URL: str = ""
    FLUX_API_KEY: str = ""
    S3_IMAGES_BUCKET: str = ""
    S3_IMAGES_REGION: str = "us-east-1"

    # Image limits (per plan)
    PRO_DAILY_IMAGE_LIMIT: int = 20
    PRO_MONTHLY_IMAGE_LIMIT: int = 200
    MAX_DAILY_IMAGE_LIMIT: int = 100
    MAX_MONTHLY_IMAGE_LIMIT: int = 1000

    # Feature flags
    FEATURE_KAIRO_API_ENABLED: bool = False
    FEATURE_KAIRO_AGENTS_ENABLED: bool = False
    FEATURE_IMAGE_GEN_ENABLED: bool = False

    # Admin
    ADMIN_FEATURE_FLAG_ALLOWLIST: list[str] = [
        "FEATURE_KAIRO_API_ENABLED",
        "FEATURE_KAIRO_AGENTS_ENABLED",
        "FEATURE_IMAGE_GEN_ENABLED",
    ]

    # Agent heartbeat
    AGENT_OFFLINE_THRESHOLD_SECONDS: int = 120

    # Stripe
    STRIPE_SECRET_KEY: str = ""
    STRIPE_PUBLISHABLE_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    STRIPE_PRO_PRICE_ID: str = ""

    # SMTP (Gmail app password)
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = ""
    SMTP_FROM_NAME: str = "Kairo"

    # App
    APP_BASE_URL: str = "http://localhost:3000"

    # CORS
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000,http://kaironlabs.io,https://kaironlabs.io,http://app.kaironlabs.io,https://app.kaironlabs.io,http://www.kaironlabs.io,https://www.kaironlabs.io"

    # Context window limits per model (in estimated tokens).
    # Reserve space for system prompt + response.
    # Small models (nyx-lite) get tighter limits to leave room for output
    # and trigger earlier compression for better quality.
    CONTEXT_LIMITS: dict[str, int] = {
        "nyx": 6000,       # 8k context, reserve 2k for response
        "nyx-lite": 3000,  # 8k context, aggressive reserve for 14B quality
        "theron": 14000,   # 16k+ context
        "helios": 14000,   # 16k+ context
    }
    SUMMARY_TRIGGER_TOKENS: int = 3000  # Summarize history when it exceeds this (lower for quality)

    MODEL_MAP: dict[str, str] = {
        "nyx": "nyx",
        "nyx-lite": "nyx-lite",
    }

    MODEL_INFO: list[dict] = [
        {"id": "nyx", "name": "Nyx 1.0", "description": "Fast, lightweight"},
        {"id": "nyx-lite", "name": "Nyx Lite", "description": "Lightweight fallback"},
    ]

    _NYX_SYSTEM_PROMPT: str = (
        "You are Kairo, a helpful AI assistant powered by {model_label}, a model developed by Kairon Labs. "
            "IMPORTANT RULES:\n"
            "1. Only respond to what the user actually asked. Never assume or invent what the user wants.\n"
            "2. You are the ASSISTANT. Never generate text as if you are the user. Never put words in the user's mouth.\n"
            "3. If the user asks a general question like 'what can you do', explain your capabilities briefly.\n"
            "4. Answer directly and concisely. Provide concrete answers, code, or explanations.\n"
            "5. Do not hedge or refuse without strong reason.\n"
            "6. If asked about your model or architecture, say you are {model_label} by Kairon Labs. Do not claim to be GPT, Claude, Llama, Mistral, or any other AI.\n"
            "7. NEVER fabricate API endpoints, URLs, library functions, or documentation. Do NOT invent URLs to documentation, "
            "readthedocs pages, Postman collections, or other resources. If you want to reference a URL, use your web_search tool "
            "to find the real URL first. Only share URLs you have verified through search results.\n"
            "8. You have access to a web_search tool. Use it when you need current information, real-time data, recent events, "
            "or to verify facts you are unsure about. When search results are returned, use them as your primary source of truth. "
            "Do not make up search results or pretend to search — use the tool.\n"
            "9. YOUR TRAINING DATA MAY BE OUTDATED. For any question about current events, politics, people in office, "
            "recent news, prices, scores, or anything that changes over time — ALWAYS use your web_search tool first. "
            "NEVER rely on your training knowledge for time-sensitive facts. When search results contradict your training data, "
            "the search results are correct. Do not mix outdated training knowledge with fresh search results.\n"
            "10. When a user asks about a specific third-party API, service, library, or tool — ALWAYS use your web_search tool "
            "to look up the actual documentation BEFORE answering. Do NOT guess how an API works, whether it requires signup, "
            "whether it costs money, or what its endpoints are. Search first, then answer based on what you find.\n"
            "11. NEVER repeat or duplicate content within a single response. If you have already shown a code block, "
            "do NOT paste it again at the end. Each piece of information or code should appear exactly once.\n"
            "12. ALWAYS respond entirely in English unless the user explicitly requests another language. "
            "Never mix languages within a response."
    )

    @property
    def SYSTEM_PROMPTS(self) -> dict[str, str]:
        return {
            "nyx": self._NYX_SYSTEM_PROMPT.format(model_label="Nyx 1.0"),
            "nyx-lite": self._NYX_SYSTEM_PROMPT.format(model_label="Nyx Lite"),
        }

    model_config = {"env_prefix": "KAIRO_"}


settings = Settings()
if not settings.JWT_SECRET_KEY:
    settings.JWT_SECRET_KEY = _stable_jwt_secret(settings.DATA_DIR)
