from fastapi import Depends, HTTPException

from backend.core.dependencies import get_current_user
from backend.models.user import User

ROLE_HIERARCHY = {"user": 0, "moderator": 1, "admin": 2, "superadmin": 3}


def require_role(minimum_role: str):
    """FastAPI dependency factory that enforces a minimum role level.

    Usage:
        dependencies=[Depends(require_role("admin"))]
    """
    minimum_level = ROLE_HIERARCHY.get(minimum_role, 0)

    async def _check_role(user: User = Depends(get_current_user)) -> User:
        user_role = getattr(user, "role", "user")
        user_level = ROLE_HIERARCHY.get(user_role, 0)
        if user_level < minimum_level:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user

    return _check_role
