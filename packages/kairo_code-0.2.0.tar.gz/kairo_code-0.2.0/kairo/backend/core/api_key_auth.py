import hashlib
from datetime import datetime, UTC

from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.models.api_key import ApiKey
from backend.models.user import User


_KEY_PREFIX = "sk-kairo-"
_PREFIX_LEN = 20  # enough chars for unique DB lookup


def hash_api_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def extract_prefix(raw_key: str) -> str:
    return raw_key[:_PREFIX_LEN]


async def get_api_key_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> tuple[User, ApiKey]:
    """Authenticate via API key in Authorization header. Returns (user, api_key)."""
    auth = request.headers.get("Authorization", "")
    if not auth.startswith(f"Bearer {_KEY_PREFIX}"):
        raise HTTPException(status_code=401, detail="Invalid API key")

    raw_key = auth[len("Bearer "):]
    prefix = extract_prefix(raw_key)
    key_hash = hash_api_key(raw_key)

    stmt = select(ApiKey).where(ApiKey.key_prefix == prefix, ApiKey.is_active.is_(True))
    result = await db.execute(stmt)
    api_key = result.scalar_one_or_none()

    if not api_key or api_key.key_hash != key_hash:
        raise HTTPException(status_code=401, detail="Invalid API key")

    if api_key.expires_at and api_key.expires_at < datetime.now(UTC):
        raise HTTPException(status_code=401, detail="API key expired")

    user = await db.get(User, api_key.user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")

    api_key.last_used_at = datetime.now(UTC)
    await db.commit()

    return user, api_key
