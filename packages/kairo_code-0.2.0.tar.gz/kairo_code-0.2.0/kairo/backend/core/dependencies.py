from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.core.security import decode_token
from backend.models.user import User
from backend.services.auth_service import AuthService
from backend.services.conversation_service import ConversationService
from backend.services.email_service import EmailService
from backend.services.llm_service import LLMService
from backend.services.chat_service import ChatService
from backend.services.project_service import ProjectService
from backend.services.stripe_service import StripeService

_bearer = HTTPBearer()


async def get_auth_service(db: AsyncSession = Depends(get_db)) -> AuthService:
    return AuthService(db)


def get_email_service() -> EmailService:
    return EmailService()


def get_stripe_service() -> StripeService:
    return StripeService()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    db: AsyncSession = Depends(get_db),
) -> User:
    user_id = decode_token(credentials.credentials)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    auth_service = AuthService(db)
    user = await auth_service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    if getattr(user, "status", "active") != "active":
        raise HTTPException(status_code=403, detail="Account suspended")
    return user


async def get_llm_service(request: Request) -> LLMService:
    return request.app.state.llm_service


async def get_conversation_service(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
) -> ConversationService:
    return ConversationService(db, user_id=user.id)


async def get_project_service(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
) -> ProjectService:
    return ProjectService(db, user_id=user.id)


async def get_chat_service(
    db: AsyncSession = Depends(get_db),
    llm_service: LLMService = Depends(get_llm_service),
    user: User = Depends(get_current_user),
) -> ChatService:
    return ChatService(db, llm_service, user_id=user.id)
