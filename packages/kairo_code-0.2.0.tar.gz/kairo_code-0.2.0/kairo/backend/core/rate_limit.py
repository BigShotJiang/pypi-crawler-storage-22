import time
from collections import defaultdict

from fastapi import HTTPException, Request

# IPs of known reverse proxies (e.g., nginx on localhost, Docker bridge)
_TRUSTED_PROXIES = {"127.0.0.1", "::1", "172.17.0.1", "172.18.0.1"}


class SlidingWindowRateLimiter:
    """In-memory sliding window rate limiter."""

    def __init__(self, max_requests: int, window_seconds: int):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(list)

    def _clean(self, key: str, now: float) -> None:
        cutoff = now - self.window_seconds
        self._requests[key] = [t for t in self._requests[key] if t > cutoff]
        if not self._requests[key]:
            del self._requests[key]

    def check(self, key: str) -> bool:
        now = time.monotonic()
        self._clean(key, now)
        if len(self._requests.get(key, [])) >= self.max_requests:
            return False
        self._requests[key].append(now)
        return True


# 10 requests/minute per IP for auth endpoints
_auth_limiter = SlidingWindowRateLimiter(max_requests=10, window_seconds=60)

# 30 requests/minute per IP for chat endpoints
_chat_limiter = SlidingWindowRateLimiter(max_requests=30, window_seconds=60)


def _client_ip(request: Request) -> str:
    """Get client IP, only trusting X-Forwarded-For from known proxies."""
    real_ip = request.client.host if request.client else "unknown"
    if real_ip in _TRUSTED_PROXIES:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            return forwarded.split(",")[0].strip()
    return real_ip


async def rate_limit_auth(request: Request) -> None:
    key = f"auth:{_client_ip(request)}"
    if not _auth_limiter.check(key):
        raise HTTPException(status_code=429, detail="Too many requests. Try again later.")


async def rate_limit_chat(request: Request) -> None:
    key = f"chat:{_client_ip(request)}"
    if not _chat_limiter.check(key):
        raise HTTPException(status_code=429, detail="Too many requests. Try again later.")


# 60 requests/minute per API key
_api_limiter = SlidingWindowRateLimiter(max_requests=60, window_seconds=60)


async def rate_limit_api(request: Request) -> None:
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer sk-kairo-"):
        key = f"api:{auth[7:27]}"  # use key prefix
    else:
        key = f"api:{_client_ip(request)}"
    if not _api_limiter.check(key):
        raise HTTPException(status_code=429, detail="API rate limit exceeded.")
