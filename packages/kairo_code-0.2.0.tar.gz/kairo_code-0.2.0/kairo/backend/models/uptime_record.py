import uuid
from datetime import date, datetime, UTC

from sqlalchemy import Date, DateTime, Float, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database import Base


class UptimeRecord(Base):
    __tablename__ = "uptime_records"
    __table_args__ = (
        Index("ix_uptime_records_component_date", "component", "date", unique=True),
    )

    id: Mapped[str] = mapped_column(primary_key=True, default=lambda: str(uuid.uuid4()))
    component: Mapped[str] = mapped_column(String, index=True)
    date: Mapped[date] = mapped_column(Date, index=True)
    uptime_percent: Mapped[float] = mapped_column(Float, default=100.0)
    incidents_count: Mapped[int] = mapped_column(Integer, default=0)
    avg_latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(UTC)
    )
