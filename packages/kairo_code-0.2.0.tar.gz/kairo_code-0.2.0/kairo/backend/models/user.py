import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from backend.core.database import Base


class PlanType(str, enum.Enum):
    FREE = "free"
    PRO = "pro"
    MAX = "max"


class RoleType(str, enum.Enum):
    USER = "user"
    MODERATOR = "moderator"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(primary_key=True, default=lambda: str(uuid.uuid4()))
    email: Mapped[str] = mapped_column(unique=True)
    hashed_password: Mapped[str] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    daily_token_limit: Mapped[int] = mapped_column(Integer, default=100_000)
    monthly_token_limit: Mapped[int] = mapped_column(Integer, default=2_000_000)

    # Plan & Stripe
    plan: Mapped[str] = mapped_column(String, default=PlanType.FREE.value)
    stripe_customer_id: Mapped[str | None] = mapped_column(String, nullable=True, unique=True, index=True)
    stripe_subscription_id: Mapped[str | None] = mapped_column(String, nullable=True)

    # Role & Status
    role: Mapped[str] = mapped_column(String, default=RoleType.USER.value)
    status: Mapped[str] = mapped_column(String, default="active")

    # Email verification
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    email_verification_token: Mapped[str | None] = mapped_column(String, nullable=True)

    # Password reset
    password_reset_token: Mapped[str | None] = mapped_column(String, nullable=True)
    password_reset_expires: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
