from datetime import datetime

from pydantic import BaseModel


class AuditLogEntry(BaseModel):
    id: str
    admin_user_id: str
    action: str
    target_type: str
    target_id: str | None = None
    details: dict | None = None
    result: str
    ip_address: str | None = None
    user_agent: str | None = None
    session_id: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class AuditLogFilter(BaseModel):
    admin_id: str | None = None
    action: str | None = None
    target_type: str | None = None
    result: str | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
