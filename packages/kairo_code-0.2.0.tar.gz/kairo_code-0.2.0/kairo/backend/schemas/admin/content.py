from datetime import datetime

from pydantic import BaseModel, Field


class AdminConversationListItem(BaseModel):
    id: str
    title: str
    model: str
    user_id: str | None = None
    message_count: int = 0
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AdminMessageItem(BaseModel):
    id: str
    role: str
    content: str
    image_url: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class AdminConversationDetail(BaseModel):
    id: str
    title: str
    model: str
    user_id: str | None = None
    created_at: datetime
    updated_at: datetime
    messages: list[AdminMessageItem] = []

    model_config = {"from_attributes": True}


class AdminImageListItem(BaseModel):
    id: str
    user_id: str
    prompt: str
    image_url: str
    width: int
    height: int
    created_at: datetime

    model_config = {"from_attributes": True}


class ContentDeleteRequest(BaseModel):
    reason: str = Field(..., min_length=1, max_length=1000)
