from pydantic import BaseModel


class OverviewStats(BaseModel):
    total_users: int
    active_today: int
    active_7d: int
    active_30d: int
    pro_subscribers: int
    max_subscribers: int
    mrr: int
    conversations_today: int
    images_today: int


class UserGrowthEntry(BaseModel):
    date: str
    signups: int


class UsageStatsEntry(BaseModel):
    date: str
    total_tokens: int


class RevenueStats(BaseModel):
    free_count: int
    pro_count: int
    max_count: int


class TopUserEntry(BaseModel):
    user_id: str
    email: str
    total_tokens: int


# --- Analytics endpoint schemas ---


class DailyCountEntry(BaseModel):
    date: str
    count: int


class DailyCountResponse(BaseModel):
    data: list[DailyCountEntry]


class DailyTokensEntry(BaseModel):
    date: str
    tokens: int


class DailyTokensResponse(BaseModel):
    data: list[DailyTokensEntry]


class PlanDistributionEntry(BaseModel):
    plan: str
    count: int


class PlanDistributionResponse(BaseModel):
    data: list[PlanDistributionEntry]


class TopUserAnalyticsEntry(BaseModel):
    email: str
    plan: str
    total_tokens: int
    conversations: int
    images: int


class TopUserAnalyticsResponse(BaseModel):
    data: list[TopUserAnalyticsEntry]
