from datetime import datetime

from pydantic import BaseModel


class ServiceHealth(BaseModel):
    name: str
    status: str  # "healthy" | "degraded" | "down"
    latency_ms: int | None = None
    message: str | None = None


class HealthStatus(BaseModel):
    overall: str  # "healthy" | "degraded" | "down"
    services: list[ServiceHealth]
    checked_at: str


class FeatureFlagItem(BaseModel):
    key: str
    enabled: bool
    updated_by: str | None = None
    updated_at: str | None = None

    model_config = {"from_attributes": True}


class FeatureFlagResponse(BaseModel):
    flags: list[FeatureFlagItem]


class FeatureFlagUpdate(BaseModel):
    key: str
    enabled: bool
    reason: str = ""


class ConfigEntry(BaseModel):
    key: str
    value: str


class ConfigResponse(BaseModel):
    config: list[ConfigEntry]
