from datetime import datetime

from pydantic import BaseModel, Field


class AdminUserListItem(BaseModel):
    id: str
    email: str
    role: str
    status: str
    plan: str
    email_verified: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class AdminUserDetailResponse(BaseModel):
    """Allowlisted fields only — never expose hashed_password, tokens, etc."""

    id: str
    email: str
    role: str
    status: str
    plan: str
    created_at: datetime
    email_verified: bool
    stripe_customer_id: str | None = None
    stripe_subscription_id: str | None = None
    daily_token_limit: int
    monthly_token_limit: int

    model_config = {"from_attributes": True}


class PlanChangeRequest(BaseModel):
    plan: str = Field(..., description="New plan: free, pro, or max")
    reason: str = Field(..., min_length=1, max_length=1000)


class StatusChangeRequest(BaseModel):
    status: str = Field(..., description="New status: active, suspended, or banned")
    reason: str = Field(..., min_length=1, max_length=1000)


class RoleChangeRequest(BaseModel):
    role: str = Field(..., description="New role: user, moderator, admin, or superadmin")
    reason: str = Field(..., min_length=1, max_length=1000)
