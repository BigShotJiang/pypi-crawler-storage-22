from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


# ─── Agent CRUD ───────────────────────────────────────────────────────────────

class RegisterAgentRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str | None = Field(None, max_length=500)
    system_prompt: str | None = Field(None, max_length=10000)
    model_preference: str = "nyx"
    agent_type: str = Field("sdk", pattern="^(sdk|container)$")
    tools: list[str] | None = None


class UpdateAgentRequest(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=100)
    description: str | None = None
    system_prompt: str | None = Field(None, max_length=10000)
    model_preference: str | None = None
    tools: list[str] | None = None


class AgentResponse(BaseModel):
    id: str
    name: str
    description: str | None = None
    model_preference: str
    agent_type: str
    state: str
    status: str  # Legacy
    sdk_version: str | None = None
    host_info: dict | None = None
    last_heartbeat_at: datetime | None = None
    last_online_at: datetime | None = None
    first_connected_at: datetime | None = None
    restart_count: int = 0
    last_error_at: datetime | None = None
    last_error_message: str | None = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AgentListResponse(BaseModel):
    """Agent list item with summary metrics"""
    id: str
    name: str
    description: str | None = None
    model_preference: str
    agent_type: str
    state: str
    sdk_version: str | None = None
    last_heartbeat_at: datetime | None = None
    created_at: datetime
    # Summary metrics (last 24h)
    requests_24h: int = 0
    errors_24h: int = 0
    tokens_24h: int = 0
    error_rate: float = 0.0

    model_config = {"from_attributes": True}


# ─── Heartbeat ────────────────────────────────────────────────────────────────

class HostInfo(BaseModel):
    hostname: str | None = None
    ip: str | None = None
    os: str | None = None
    memory_mb: int | None = None
    memory_used_percent: float | None = None


class ProcessInfo(BaseModel):
    pid: int | None = None
    uptime_seconds: int | None = None
    memory_rss_mb: int | None = None
    cpu_percent: float | None = None
    thread_count: int | None = None


class MetricsSinceLastHeartbeat(BaseModel):
    requests_completed: int = 0
    requests_failed: int = 0
    total_latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    tool_calls: int = 0
    tool_errors: int = 0


class AgentHeartbeatRequest(BaseModel):
    agent_id: str
    status: str = Field("online", pattern="^(online|busy|idle|error)$")
    sdk_version: str | None = None
    host_info: HostInfo | None = None
    process_info: ProcessInfo | None = None
    metrics_since_last_heartbeat: MetricsSinceLastHeartbeat | None = None
    queue_depth: int | None = None
    active_request: bool = False
    last_error: dict | None = None


class AgentCommand(BaseModel):
    command_id: str
    type: str
    payload: dict | None = None
    issued_at: datetime
    expires_at: datetime
    signature: str


class AgentHeartbeatResponse(BaseModel):
    acknowledged: bool
    server_time: datetime
    commands: list[AgentCommand] = []


# ─── Metrics ──────────────────────────────────────────────────────────────────

class AgentMetricsQuery(BaseModel):
    range: str = Field("24h", pattern="^(1h|6h|24h|7d|30d)$")
    granularity: str = Field("auto", pattern="^(auto|1m|1h|1d)$")


class MetricDataPoint(BaseModel):
    timestamp: datetime
    request_count: int = 0
    error_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    avg_latency_ms: float | None = None
    p99_latency_ms: int | None = None
    tool_calls: int = 0


class AgentMetricsResponse(BaseModel):
    agent_id: str
    range: str
    granularity: str
    data: list[MetricDataPoint]
    summary: dict


# ─── Events ───────────────────────────────────────────────────────────────────

class AgentEventResponse(BaseModel):
    id: str
    event_type: str
    event_data: dict | None = None
    error_type: str | None = None
    error_message: str | None = None
    client_ip: str | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class AgentEventsQuery(BaseModel):
    event_type: str | None = None
    limit: int = Field(50, ge=1, le=500)
    cursor: str | None = None


# ─── Commands ─────────────────────────────────────────────────────────────────

class IssueCommandRequest(BaseModel):
    command_type: str = Field(..., pattern="^(restart|stop|config_refresh)$")
    payload: dict | None = None


class CommandResponse(BaseModel):
    id: str
    command_type: str
    status: str
    created_at: datetime
    expires_at: datetime

    model_config = {"from_attributes": True}


# ─── Alerts ───────────────────────────────────────────────────────────────────

class CreateAlertConfigRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    alert_type: str = Field(..., pattern="^(offline|error_rate|latency|token_budget)$")
    metric: str
    condition: str = Field(..., pattern="^(gt|lt|gte|lte|eq)$")
    threshold: float
    window_seconds: int = Field(300, ge=60, le=86400)
    cooldown_seconds: int = Field(3600, ge=60, le=604800)
    severity: str = Field("warning", pattern="^(info|warning|critical)$")
    channels: list[str] = ["email"]


class UpdateAlertConfigRequest(BaseModel):
    name: str | None = None
    threshold: float | None = None
    window_seconds: int | None = None
    cooldown_seconds: int | None = None
    severity: str | None = None
    channels: list[str] | None = None
    is_enabled: bool | None = None


class AlertConfigResponse(BaseModel):
    id: str
    name: str
    alert_type: str
    metric: str
    condition: str
    threshold: float
    window_seconds: int
    cooldown_seconds: int
    severity: str
    channels: list[str]
    is_enabled: bool
    last_triggered_at: datetime | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


class AlertHistoryResponse(BaseModel):
    id: str
    alert_type: str
    severity: str
    status: str
    message: str | None = None
    trigger_value: float | None = None
    threshold_value: float | None = None
    acknowledged_at: datetime | None = None
    resolved_at: datetime | None = None
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Setup Token ──────────────────────────────────────────────────────────────

class SetupTokenResponse(BaseModel):
    token: str  # Only shown once!
    expires_at: datetime
    agent_id: str


class AgentRegistrationRequest(BaseModel):
    setup_token: str
    sdk_version: str
    host_info: HostInfo | None = None


class AgentRegistrationResponse(BaseModel):
    agent_id: str
    name: str
    model_preference: str
    system_prompt: str | None = None
    api_key: str  # Agent-scoped API key, shown once


# ─── Telemetry Batch ──────────────────────────────────────────────────────────

class TelemetryEvent(BaseModel):
    request_id: str
    timestamp_start: datetime
    timestamp_end: datetime
    latency_ms: int
    input_tokens: int
    output_tokens: int
    model: str
    status: str = Field(..., pattern="^(success|error|timeout)$")
    error_type: str | None = None
    tool_calls: list[dict] | None = None


class TelemetryBatchRequest(BaseModel):
    agent_id: str
    events: list[TelemetryEvent]
    idempotency_key: str | None = None


class TelemetryBatchResponse(BaseModel):
    accepted: int
    rejected: int
    errors: list[str] = []
