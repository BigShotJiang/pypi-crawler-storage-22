from datetime import datetime

from pydantic import BaseModel, Field


class CreateApiKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    expires_in_days: int | None = Field(None, ge=1, le=365)


class ApiKeyResponse(BaseModel):
    id: str
    name: str
    key_prefix: str
    is_active: bool
    last_used_at: datetime | None = None
    created_at: datetime
    expires_at: datetime | None = None
    key_type: str = "api"  # api, agent
    agent_id: str | None = None
    agent_name: str | None = None

    model_config = {"from_attributes": True}


class ApiKeyCreatedResponse(ApiKeyResponse):
    """Returned only once on creation — includes the full key."""
    full_key: str


class RevokeApiKeyResponse(BaseModel):
    id: str
    revoked: bool
