from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class RegisterRequest(BaseModel):
    email: EmailStr = Field(..., max_length=254)
    password: str = Field(..., min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr = Field(..., max_length=254)
    password: str = Field(..., max_length=128)


class VerifyEmailRequest(BaseModel):
    token: str = Field(..., max_length=128)


class ForgotPasswordRequest(BaseModel):
    email: EmailStr = Field(..., max_length=254)


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., max_length=128)
    password: str = Field(..., min_length=8, max_length=128)


class UserResponse(BaseModel):
    id: str
    email: str
    created_at: datetime
    plan: str = "free"
    email_verified: bool = False
    role: str = "user"

    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class CheckoutResponse(BaseModel):
    checkout_url: str


class BillingPortalResponse(BaseModel):
    portal_url: str


class BillingStatusResponse(BaseModel):
    plan: str
    stripe_customer_id: str | None = None
    stripe_subscription_id: str | None = None
