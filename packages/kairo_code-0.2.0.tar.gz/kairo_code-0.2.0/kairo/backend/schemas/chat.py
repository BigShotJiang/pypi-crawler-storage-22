from pydantic import BaseModel, Field, field_validator

from backend.config import settings


class ChatRequest(BaseModel):
    conversation_id: str | None = None
    message: str = Field(..., min_length=1, max_length=32000)
    model: str = "nyx"
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=2048, ge=1, le=16384)
    project_id: str | None = None

    @field_validator("model")
    @classmethod
    def model_must_be_allowed(cls, v: str) -> str:
        allowed = set(settings.MODEL_MAP.keys())
        if v not in allowed:
            raise ValueError(f"model must be one of: {', '.join(sorted(allowed))}")
        return v


class StreamChunk(BaseModel):
    type: str  # "meta", "content", "error"
    conversation_id: str | None = None
    content: str | None = None
