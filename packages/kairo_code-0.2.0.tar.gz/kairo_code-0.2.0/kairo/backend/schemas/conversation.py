from datetime import datetime
from pydantic import BaseModel, Field


class MessageSchema(BaseModel):
    id: str
    role: str
    content: str
    created_at: datetime
    image_url: str | None = None

    model_config = {"from_attributes": True}


class ConversationSummary(BaseModel):
    id: str
    title: str
    model: str
    updated_at: datetime
    message_count: int
    project_id: str | None = None

    model_config = {"from_attributes": True}


class ConversationDetail(BaseModel):
    id: str
    title: str
    model: str
    created_at: datetime
    updated_at: datetime
    project_id: str | None = None
    messages: list[MessageSchema]

    model_config = {"from_attributes": True}


class ConversationRename(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
