from pydantic import BaseModel, Field


class DeviceCodeRequest(BaseModel):
    client_name: str = Field("kairo-code", max_length=100)


class DeviceCodeResponse(BaseModel):
    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int
    interval: int


class DeviceTokenRequest(BaseModel):
    device_code: str
    grant_type: str = "urn:ietf:params:oauth:grant-type:device_code"


class DeviceTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    plan: str
    email: str


class DeviceTokenErrorResponse(BaseModel):
    error: str  # authorization_pending, slow_down, expired_token, access_denied
    error_description: str


class DeviceApproveRequest(BaseModel):
    user_code: str


class DeviceApproveResponse(BaseModel):
    approved: bool
    message: str
