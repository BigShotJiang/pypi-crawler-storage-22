from datetime import datetime

from pydantic import BaseModel, Field


class ProjectCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)


class ProjectUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    instructions: str | None = None


class ProjectResponse(BaseModel):
    id: str
    name: str
    instructions: str | None
    conversation_count: int
    created_at: datetime
    updated_at: datetime
