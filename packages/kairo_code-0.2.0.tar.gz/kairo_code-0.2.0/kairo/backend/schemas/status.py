from pydantic import BaseModel, field_validator


class ComponentStatus(BaseModel):
    name: str
    status: str  # operational, degraded, down
    latency_ms: int | None = None
    uptime_24h: float | None = None


class IncidentSummary(BaseModel):
    id: str
    title: str
    description: str | None = None
    severity: str
    component: str
    status: str
    started_at: str
    resolved_at: str | None = None


class UptimeEntry(BaseModel):
    date: str
    uptime_percent: float


class StatusPageResponse(BaseModel):
    status: str  # operational, degraded, outage
    overall_uptime: float
    checked_at: str
    components: list[ComponentStatus]
    recent_incidents: list[IncidentSummary]
    uptime_history: list[UptimeEntry]


VALID_SEVERITIES = {"info", "warning", "critical"}
VALID_COMPONENTS = {"api", "chat", "models", "images", "database"}
VALID_STATUSES = {"investigating", "identified", "monitoring", "resolved"}


class CreateIncidentRequest(BaseModel):
    title: str
    description: str | None = None
    severity: str = "warning"
    component: str

    @field_validator("severity")
    @classmethod
    def validate_severity(cls, v: str) -> str:
        if v not in VALID_SEVERITIES:
            raise ValueError(f"severity must be one of {VALID_SEVERITIES}")
        return v

    @field_validator("component")
    @classmethod
    def validate_component(cls, v: str) -> str:
        if v not in VALID_COMPONENTS:
            raise ValueError(f"component must be one of {VALID_COMPONENTS}")
        return v


class UpdateIncidentRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    severity: str | None = None
    status: str | None = None
    resolved_at: str | None = None

    @field_validator("severity")
    @classmethod
    def validate_severity(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_SEVERITIES:
            raise ValueError(f"severity must be one of {VALID_SEVERITIES}")
        return v

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str | None) -> str | None:
        if v is not None and v not in VALID_STATUSES:
            raise ValueError(f"status must be one of {VALID_STATUSES}")
        return v
