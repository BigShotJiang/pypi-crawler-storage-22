from pydantic import BaseModel


class UsageSummaryResponse(BaseModel):
    daily_percent: float
    monthly_percent: float


class UsageHistoryEntry(BaseModel):
    date: str
    usage_percent: float


class UsageHistoryResponse(BaseModel):
    entries: list[UsageHistoryEntry]
