import logging
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.audit_log import AuditLog

logger = logging.getLogger(__name__)


class AuditService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def log(
        self,
        admin_user_id: str,
        action: str,
        target_type: str,
        target_id: str | None = None,
        details: dict | None = None,
        result: str = "success",
        ip_address: str | None = None,
        user_agent: str | None = None,
        session_id: str | None = None,
    ) -> AuditLog:
        entry = AuditLog(
            admin_user_id=admin_user_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            details=details,
            result=result,
            ip_address=ip_address,
            user_agent=user_agent,
            session_id=session_id,
        )
        self.db.add(entry)
        await self.db.commit()
        await self.db.refresh(entry)
        logger.info(
            "Audit: admin=%s action=%s target=%s/%s result=%s",
            admin_user_id, action, target_type, target_id, result,
        )
        return entry

    async def list_logs(
        self,
        filters: dict | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[AuditLog]:
        stmt = select(AuditLog).order_by(AuditLog.created_at.desc())

        if filters:
            if filters.get("admin_id"):
                stmt = stmt.where(AuditLog.admin_user_id == filters["admin_id"])
            if filters.get("action"):
                stmt = stmt.where(AuditLog.action == filters["action"])
            if filters.get("target_type"):
                stmt = stmt.where(AuditLog.target_type == filters["target_type"])
            if filters.get("result"):
                stmt = stmt.where(AuditLog.result == filters["result"])
            if filters.get("date_from"):
                stmt = stmt.where(AuditLog.created_at >= filters["date_from"])
            if filters.get("date_to"):
                stmt = stmt.where(AuditLog.created_at <= filters["date_to"])

        if cursor:
            # Cursor is the id of the last item seen; fetch older entries
            cursor_log = await self.db.get(AuditLog, cursor)
            if cursor_log:
                stmt = stmt.where(AuditLog.created_at < cursor_log.created_at)

        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())
