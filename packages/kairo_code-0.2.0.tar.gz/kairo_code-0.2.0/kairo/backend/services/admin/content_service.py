import logging

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models.conversation import Conversation, Message
from backend.models.image_generation import ImageGeneration

logger = logging.getLogger(__name__)


class AdminContentService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list_conversations(
        self,
        search: str | None = None,
        user_id: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        stmt = select(
            Conversation,
            func.count(Message.id).label("message_count"),
        ).outerjoin(Message).group_by(Conversation.id).order_by(Conversation.updated_at.desc())

        if search:
            stmt = stmt.where(Conversation.title.ilike(f"%{search}%"))
        if user_id:
            stmt = stmt.where(Conversation.user_id == user_id)

        if cursor:
            cursor_conv = await self.db.get(Conversation, cursor)
            if cursor_conv:
                stmt = stmt.where(Conversation.updated_at < cursor_conv.updated_at)

        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        rows = result.all()
        return [
            {
                "id": conv.id,
                "title": conv.title,
                "model": conv.model,
                "user_id": conv.user_id,
                "message_count": msg_count,
                "created_at": conv.created_at,
                "updated_at": conv.updated_at,
            }
            for conv, msg_count in rows
        ]

    async def get_conversation_detail(self, conversation_id: str) -> dict | None:
        stmt = (
            select(Conversation)
            .options(selectinload(Conversation.messages))
            .where(Conversation.id == conversation_id)
        )
        result = await self.db.execute(stmt)
        conv = result.scalar_one_or_none()
        if not conv:
            return None
        return {
            "id": conv.id,
            "title": conv.title,
            "model": conv.model,
            "user_id": conv.user_id,
            "created_at": conv.created_at,
            "updated_at": conv.updated_at,
            "messages": [
                {
                    "id": m.id,
                    "role": m.role,
                    "content": m.content,
                    "image_url": m.image_url,
                    "created_at": m.created_at,
                }
                for m in conv.messages
            ],
        }

    async def delete_conversation(self, conversation_id: str) -> bool:
        conv = await self.db.get(Conversation, conversation_id)
        if not conv:
            return False
        await self.db.delete(conv)
        await self.db.commit()
        logger.info("Conversation %s deleted", conversation_id)
        return True

    async def list_recent_images(
        self,
        user_id: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[ImageGeneration]:
        stmt = select(ImageGeneration).order_by(ImageGeneration.created_at.desc())

        if user_id:
            stmt = stmt.where(ImageGeneration.user_id == user_id)
        if cursor:
            cursor_img = await self.db.get(ImageGeneration, cursor)
            if cursor_img:
                stmt = stmt.where(ImageGeneration.created_at < cursor_img.created_at)

        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def delete_image(self, image_id: str) -> bool:
        img = await self.db.get(ImageGeneration, image_id)
        if not img:
            return False
        await self.db.delete(img)
        await self.db.commit()
        logger.info("Image %s deleted", image_id)
        return True
