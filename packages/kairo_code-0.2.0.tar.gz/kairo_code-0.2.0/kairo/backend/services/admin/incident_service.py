import logging
import uuid
from datetime import datetime, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.incident import Incident

logger = logging.getLogger(__name__)


class IncidentService:
    """Admin service for CRUD operations on incidents."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_incident(
        self,
        title: str,
        component: str,
        description: str | None = None,
        severity: str = "warning",
    ) -> Incident:
        """Create a new incident."""
        incident = Incident(
            id=str(uuid.uuid4()),
            title=title,
            description=description,
            severity=severity,
            component=component,
            status="investigating",
            started_at=datetime.now(UTC),
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        self.db.add(incident)
        await self.db.commit()
        await self.db.refresh(incident)
        logger.info("Incident created: id=%s title=%s component=%s severity=%s", incident.id, title, component, severity)
        return incident

    async def update_incident(self, incident_id: str, **kwargs) -> Incident | None:
        """Update an existing incident's fields."""
        incident = await self.get_incident(incident_id)
        if not incident:
            return None

        allowed_fields = {"title", "description", "severity", "status", "resolved_at"}
        for key, value in kwargs.items():
            if key in allowed_fields and value is not None:
                setattr(incident, key, value)

        # Auto-set resolved_at when status changes to resolved
        if kwargs.get("status") == "resolved" and not incident.resolved_at:
            incident.resolved_at = datetime.now(UTC)

        incident.updated_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(incident)
        logger.info("Incident updated: id=%s fields=%s", incident_id, list(kwargs.keys()))
        return incident

    async def resolve_incident(self, incident_id: str) -> Incident | None:
        """Mark an incident as resolved."""
        incident = await self.get_incident(incident_id)
        if not incident:
            return None

        incident.status = "resolved"
        incident.resolved_at = datetime.now(UTC)
        incident.updated_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(incident)
        logger.info("Incident resolved: id=%s", incident_id)
        return incident

    async def list_incidents(
        self, limit: int = 50, include_resolved: bool = False
    ) -> list[Incident]:
        """List incidents, optionally including resolved ones."""
        stmt = select(Incident).order_by(Incident.started_at.desc())
        if not include_resolved:
            stmt = stmt.where(Incident.status != "resolved")
        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_incident(self, incident_id: str) -> Incident | None:
        """Get a single incident by ID."""
        stmt = select(Incident).where(Incident.id == incident_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
