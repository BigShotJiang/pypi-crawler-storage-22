import logging
from datetime import date, datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.conversation import Conversation
from backend.models.image_generation import ImageGeneration
from backend.models.usage import UsageRecord
from backend.models.user import User

logger = logging.getLogger(__name__)


def _fill_daily_counts(
    rows: list[tuple], days: int, value_key: str = "count"
) -> list[dict]:
    """Fill gaps so every date in the range has an entry (zero if missing).

    ``rows`` must be an iterable of objects with ``.date`` and a numeric
    attribute whose name matches *value_key*.  Returns a list of dicts
    sorted by date ascending with keys ``date`` (str) and *value_key*.
    """
    today = date.today()
    start = today - timedelta(days=days - 1)

    lookup: dict[str, int] = {}
    for r in rows:
        # r.date may already be a date object or a string
        d = str(r.date) if not isinstance(r.date, str) else r.date
        lookup[d] = getattr(r, value_key, 0) or 0

    result: list[dict] = []
    current = start
    while current <= today:
        key = current.isoformat()
        result.append({"date": key, value_key: lookup.get(key, 0)})
        current += timedelta(days=1)
    return result


class AdminStatsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_overview(self) -> dict:
        now = datetime.now(timezone.utc)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)

        # Total users
        total_result = await self.db.execute(select(func.count(User.id)))
        total_users = total_result.scalar() or 0

        # Active users by time window (users with usage records)
        active_today = await self._count_active_users(start_of_day)
        active_7d = await self._count_active_users(now - timedelta(days=7))
        active_30d = await self._count_active_users(now - timedelta(days=30))

        # Plan counts
        pro_result = await self.db.execute(
            select(func.count(User.id)).where(User.plan == "pro")
        )
        pro_subscribers = pro_result.scalar() or 0

        max_result = await self.db.execute(
            select(func.count(User.id)).where(User.plan == "max")
        )
        max_subscribers = max_result.scalar() or 0

        # Estimated MRR (Pro=$20, Max=$50)
        mrr = (pro_subscribers * 20) + (max_subscribers * 50)

        # Conversations created today
        conv_result = await self.db.execute(
            select(func.count(Conversation.id)).where(Conversation.created_at >= start_of_day)
        )
        conversations_today = conv_result.scalar() or 0

        # Images generated today
        img_result = await self.db.execute(
            select(func.count(ImageGeneration.id)).where(ImageGeneration.created_at >= start_of_day)
        )
        images_today = img_result.scalar() or 0

        return {
            "total_users": total_users,
            "active_today": active_today,
            "active_7d": active_7d,
            "active_30d": active_30d,
            "pro_subscribers": pro_subscribers,
            "max_subscribers": max_subscribers,
            "mrr": mrr,
            "conversations_today": conversations_today,
            "images_today": images_today,
        }

    async def _count_active_users(self, since: datetime) -> int:
        result = await self.db.execute(
            select(func.count(func.distinct(UsageRecord.user_id))).where(
                UsageRecord.created_at >= since
            )
        )
        return result.scalar() or 0

    async def get_user_growth(self, days: int = 30) -> list[dict]:
        since = datetime.now(timezone.utc) - timedelta(days=days)
        stmt = (
            select(
                func.date(User.created_at).label("date"),
                func.count(User.id).label("signups"),
            )
            .where(User.created_at >= since)
            .group_by(func.date(User.created_at))
            .order_by(func.date(User.created_at))
        )
        result = await self.db.execute(stmt)
        return [{"date": str(r.date), "signups": r.signups} for r in result.all()]

    async def get_usage_stats(self, days: int = 30) -> list[dict]:
        since = datetime.now(timezone.utc) - timedelta(days=days)
        stmt = (
            select(
                func.date(UsageRecord.created_at).label("date"),
                func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens).label("total_tokens"),
            )
            .where(UsageRecord.created_at >= since)
            .group_by(func.date(UsageRecord.created_at))
            .order_by(func.date(UsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        return [{"date": str(r.date), "total_tokens": r.total_tokens or 0} for r in result.all()]

    async def get_revenue_stats(self) -> dict:
        free_result = await self.db.execute(
            select(func.count(User.id)).where(User.plan == "free")
        )
        pro_result = await self.db.execute(
            select(func.count(User.id)).where(User.plan == "pro")
        )
        max_result = await self.db.execute(
            select(func.count(User.id)).where(User.plan == "max")
        )
        return {
            "free_count": free_result.scalar() or 0,
            "pro_count": pro_result.scalar() or 0,
            "max_count": max_result.scalar() or 0,
        }

    async def get_top_users(self, limit: int = 20) -> list[dict]:
        stmt = (
            select(
                UsageRecord.user_id,
                User.email,
                func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens).label("total_tokens"),
            )
            .join(User, UsageRecord.user_id == User.id)
            .group_by(UsageRecord.user_id, User.email)
            .order_by(func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens).desc())
            .limit(limit)
        )
        result = await self.db.execute(stmt)
        return [
            {"user_id": r.user_id, "email": r.email, "total_tokens": r.total_tokens or 0}
            for r in result.all()
        ]

    # ------------------------------------------------------------------ #
    #  Analytics endpoints                                                #
    # ------------------------------------------------------------------ #

    async def get_daily_signups(self, days: int = 30) -> list[dict]:
        """Daily signup counts for the past *days* days, zero-filled."""
        since = datetime.now(timezone.utc) - timedelta(days=days - 1)
        stmt = (
            select(
                func.date(User.created_at).label("date"),
                func.count(User.id).label("count"),
            )
            .where(User.created_at >= since)
            .group_by(func.date(User.created_at))
            .order_by(func.date(User.created_at))
        )
        result = await self.db.execute(stmt)
        return _fill_daily_counts(result.all(), days, "count")

    async def get_daily_active_users(self, days: int = 30) -> list[dict]:
        """Daily active user counts (distinct users with usage records)."""
        since = datetime.now(timezone.utc) - timedelta(days=days - 1)
        stmt = (
            select(
                func.date(UsageRecord.created_at).label("date"),
                func.count(func.distinct(UsageRecord.user_id)).label("count"),
            )
            .where(UsageRecord.created_at >= since)
            .group_by(func.date(UsageRecord.created_at))
            .order_by(func.date(UsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        return _fill_daily_counts(result.all(), days, "count")

    async def get_usage_over_time(self, days: int = 30) -> list[dict]:
        """Daily total tokens (prompt + completion) for the past *days* days."""
        since = datetime.now(timezone.utc) - timedelta(days=days - 1)
        stmt = (
            select(
                func.date(UsageRecord.created_at).label("date"),
                func.sum(
                    UsageRecord.prompt_tokens + UsageRecord.completion_tokens
                ).label("tokens"),
            )
            .where(UsageRecord.created_at >= since)
            .group_by(func.date(UsageRecord.created_at))
            .order_by(func.date(UsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        return _fill_daily_counts(result.all(), days, "tokens")

    async def get_plan_distribution(self) -> list[dict]:
        """Current count of users grouped by plan."""
        stmt = (
            select(
                User.plan.label("plan"),
                func.count(User.id).label("count"),
            )
            .group_by(User.plan)
            .order_by(func.count(User.id).desc())
        )
        result = await self.db.execute(stmt)
        return [{"plan": r.plan, "count": r.count} for r in result.all()]

    async def get_top_users_analytics(self, limit: int = 20) -> list[dict]:
        """Top N users by total token usage with conversation and image counts.

        Uses correlated scalar sub-selects for conversations and images to
        avoid row multiplication from multiple JOINs.
        """
        # Subquery: conversation count per user
        conv_sub = (
            select(func.count(Conversation.id))
            .where(Conversation.user_id == UsageRecord.user_id)
            .correlate(UsageRecord)
            .scalar_subquery()
        )
        # Subquery: image generation count per user
        img_sub = (
            select(func.count(ImageGeneration.id))
            .where(ImageGeneration.user_id == UsageRecord.user_id)
            .correlate(UsageRecord)
            .scalar_subquery()
        )

        stmt = (
            select(
                User.email,
                User.plan,
                func.sum(
                    UsageRecord.prompt_tokens + UsageRecord.completion_tokens
                ).label("total_tokens"),
                conv_sub.label("conversations"),
                img_sub.label("images"),
            )
            .join(User, UsageRecord.user_id == User.id)
            .group_by(UsageRecord.user_id, User.email, User.plan)
            .order_by(
                func.sum(
                    UsageRecord.prompt_tokens + UsageRecord.completion_tokens
                ).desc()
            )
            .limit(limit)
        )
        result = await self.db.execute(stmt)
        return [
            {
                "email": r.email,
                "plan": r.plan,
                "total_tokens": r.total_tokens or 0,
                "conversations": r.conversations or 0,
                "images": r.images or 0,
            }
            for r in result.all()
        ]
