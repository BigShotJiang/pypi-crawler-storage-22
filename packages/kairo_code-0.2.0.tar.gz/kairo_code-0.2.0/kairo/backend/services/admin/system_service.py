import logging
import time
from datetime import datetime, timezone

import httpx
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.models.feature_flag import FeatureFlag

logger = logging.getLogger(__name__)


class AdminSystemService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_health(self) -> dict:
        services = []

        # Database check
        try:
            t0 = time.monotonic()
            await self.db.execute(text("SELECT 1"))
            latency = int((time.monotonic() - t0) * 1000)
            services.append({"name": "Database", "status": "healthy", "latency_ms": latency})
        except Exception as e:
            services.append({"name": "Database", "status": "down", "message": str(e)[:100]})

        async with httpx.AsyncClient(timeout=5.0) as client:
            # vLLM check
            try:
                t0 = time.monotonic()
                resp = await client.get(f"{settings.VLLM_BASE_URL}/health")
                latency = int((time.monotonic() - t0) * 1000)
                status = "healthy" if resp.status_code == 200 else "degraded"
                services.append({"name": "vLLM", "status": status, "latency_ms": latency})
            except Exception:
                services.append({"name": "vLLM", "status": "down", "message": "Connection failed"})

            # vLLM Lite check
            if settings.VLLM_LITE_BASE_URL:
                try:
                    t0 = time.monotonic()
                    resp = await client.get(f"{settings.VLLM_LITE_BASE_URL}/health")
                    latency = int((time.monotonic() - t0) * 1000)
                    status = "healthy" if resp.status_code == 200 else "degraded"
                    services.append({"name": "vLLM Lite", "status": status, "latency_ms": latency})
                except Exception:
                    services.append({"name": "vLLM Lite", "status": "down", "message": "Connection failed"})

            # FLUX check
            if settings.FLUX_BASE_URL:
                try:
                    t0 = time.monotonic()
                    resp = await client.get(f"{settings.FLUX_BASE_URL}/health")
                    latency = int((time.monotonic() - t0) * 1000)
                    status = "healthy" if resp.status_code == 200 else "degraded"
                    services.append({"name": "FLUX Image", "status": status, "latency_ms": latency})
                except Exception:
                    services.append({"name": "FLUX Image", "status": "down", "message": "Connection failed"})

        # Determine overall status
        statuses = [s["status"] for s in services]
        if all(s == "healthy" for s in statuses):
            overall = "healthy"
        elif any(s == "down" for s in statuses):
            overall = "degraded"
        else:
            overall = "degraded"

        return {
            "overall": overall,
            "services": services,
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }

    async def get_feature_flags(self) -> list[FeatureFlag]:
        stmt = select(FeatureFlag).order_by(FeatureFlag.key)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def toggle_feature_flag(
        self, key: str, enabled: bool, admin_user_id: str
    ) -> FeatureFlag | None:
        stmt = select(FeatureFlag).where(FeatureFlag.key == key)
        result = await self.db.execute(stmt)
        flag = result.scalar_one_or_none()
        if not flag:
            return None
        flag.enabled = enabled
        flag.updated_by = admin_user_id
        flag.updated_at = datetime.now(timezone.utc)
        await self.db.commit()
        await self.db.refresh(flag)
        logger.info("Feature flag %s set to %s by %s", key, enabled, admin_user_id)
        return flag

    async def get_config(self) -> list[dict]:
        """Return allowlisted non-secret config values."""
        allowlist = [
            "VLLM_BASE_URL",
            "VLLM_LITE_BASE_URL",
            "HOST",
            "PORT",
            "LOG_LEVEL",
            "JWT_EXPIRE_HOURS",
            "DEFAULT_DAILY_TOKEN_LIMIT",
            "DEFAULT_MONTHLY_TOKEN_LIMIT",
            "PRO_DAILY_TOKEN_LIMIT",
            "PRO_MONTHLY_TOKEN_LIMIT",
            "MAX_DAILY_TOKEN_LIMIT",
            "MAX_MONTHLY_TOKEN_LIMIT",
            "PRO_DAILY_IMAGE_LIMIT",
            "PRO_MONTHLY_IMAGE_LIMIT",
            "MAX_DAILY_IMAGE_LIMIT",
            "MAX_MONTHLY_IMAGE_LIMIT",
            "AGENT_OFFLINE_THRESHOLD_SECONDS",
            "S3_IMAGES_REGION",
        ]
        entries = []
        for key in allowlist:
            if hasattr(settings, key):
                entries.append({"key": key, "value": str(getattr(settings, key))})
        return entries
