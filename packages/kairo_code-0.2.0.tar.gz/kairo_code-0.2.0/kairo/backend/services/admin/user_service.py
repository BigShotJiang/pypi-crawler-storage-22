import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.api_key import ApiKey
from backend.models.conversation import Conversation
from backend.models.image_generation import ImageGeneration
from backend.models.usage import UsageRecord
from backend.models.user import User

logger = logging.getLogger(__name__)


class AdminUserService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list_users(
        self,
        search: str | None = None,
        plan: str | None = None,
        status: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[User]:
        stmt = select(User).order_by(User.created_at.desc())

        if search:
            stmt = stmt.where(User.email.ilike(f"%{search}%"))
        if plan:
            stmt = stmt.where(User.plan == plan)
        if status:
            stmt = stmt.where(User.status == status)

        if cursor:
            cursor_user = await self.db.get(User, cursor)
            if cursor_user:
                stmt = stmt.where(User.created_at < cursor_user.created_at)

        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_user_detail(self, user_id: str) -> User | None:
        return await self.db.get(User, user_id)

    async def change_plan(self, user_id: str, new_plan: str) -> User | None:
        user = await self.db.get(User, user_id)
        if not user:
            return None
        user.plan = new_plan
        await self.db.commit()
        await self.db.refresh(user)
        logger.info("User %s plan changed to %s", user_id, new_plan)
        return user

    async def change_status(self, user_id: str, new_status: str) -> User | None:
        user = await self.db.get(User, user_id)
        if not user:
            return None
        user.status = new_status
        await self.db.commit()
        await self.db.refresh(user)
        logger.info("User %s status changed to %s", user_id, new_status)
        return user

    async def change_role(self, user_id: str, new_role: str) -> User | None:
        user = await self.db.get(User, user_id)
        if not user:
            return None
        user.role = new_role
        await self.db.commit()
        await self.db.refresh(user)
        logger.info("User %s role changed to %s", user_id, new_role)
        return user

    async def get_user_usage(self, user_id: str) -> list[dict]:
        now = datetime.now(timezone.utc)
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        # Daily usage for the past 30 days
        from datetime import timedelta

        start_30d = now - timedelta(days=30)
        stmt = (
            select(
                func.date(UsageRecord.created_at).label("date"),
                func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens).label("total_tokens"),
            )
            .where(UsageRecord.user_id == user_id)
            .where(UsageRecord.created_at >= start_30d)
            .group_by(func.date(UsageRecord.created_at))
            .order_by(func.date(UsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        return [{"date": str(r.date), "total_tokens": r.total_tokens or 0} for r in result.all()]

    async def get_user_conversations(
        self,
        user_id: str,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[Conversation]:
        stmt = (
            select(Conversation)
            .where(Conversation.user_id == user_id)
            .order_by(Conversation.updated_at.desc())
        )
        if cursor:
            cursor_conv = await self.db.get(Conversation, cursor)
            if cursor_conv:
                stmt = stmt.where(Conversation.updated_at < cursor_conv.updated_at)
        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_user_images(
        self,
        user_id: str,
        cursor: str | None = None,
        limit: int = 50,
    ) -> list[ImageGeneration]:
        stmt = (
            select(ImageGeneration)
            .where(ImageGeneration.user_id == user_id)
            .order_by(ImageGeneration.created_at.desc())
        )
        if cursor:
            cursor_img = await self.db.get(ImageGeneration, cursor)
            if cursor_img:
                stmt = stmt.where(ImageGeneration.created_at < cursor_img.created_at)
        stmt = stmt.limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_user_api_keys(self, user_id: str) -> list[dict]:
        stmt = (
            select(ApiKey)
            .where(ApiKey.user_id == user_id)
            .order_by(ApiKey.created_at.desc())
        )
        result = await self.db.execute(stmt)
        keys = result.scalars().all()
        # Return masked keys — only show key_prefix
        return [
            {
                "id": k.id,
                "name": k.name,
                "key_prefix": k.key_prefix,
                "is_active": k.is_active,
                "last_used_at": k.last_used_at.isoformat() if k.last_used_at else None,
                "created_at": k.created_at.isoformat(),
                "expires_at": k.expires_at.isoformat() if k.expires_at else None,
            }
            for k in keys
        ]
