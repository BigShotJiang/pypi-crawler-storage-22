"""
Agent services module.

This module provides modular, focused services for agent management:

Core Services:
- AgentService: Main composite service (backward compatible API)
- AgentCrudService: CRUD operations for agents
- AgentHeartbeatService: Heartbeat processing and state management
- AgentCommandsService: Command issuing and acknowledgment
- AgentSetupService: Setup tokens and API key creation
- AgentEventsService: Event logging and queries

Metrics Services:
- AgentMetricsService: Metrics queries and telemetry processing
- AgentMetricsRollupService: Background rollup and cleanup jobs

Alerts Services:
- AgentAlertsService: Alert configuration CRUD
- AgentAlertsEvaluationService: Background alert evaluation

The main AgentService class composes all sub-services and maintains
backward compatibility with the original monolithic API.
"""

from backend.services.agent.agent_service import AgentService
from backend.services.agent.agent_crud_service import AgentCrudService
from backend.services.agent.agent_heartbeat_service import AgentHeartbeatService
from backend.services.agent.agent_commands_service import AgentCommandsService
from backend.services.agent.agent_metrics_service import AgentMetricsService
from backend.services.agent.agent_metrics_rollup_service import AgentMetricsRollupService
from backend.services.agent.agent_alerts_service import AgentAlertsService
from backend.services.agent.agent_alerts_evaluation_service import AgentAlertsEvaluationService
from backend.services.agent.agent_setup_service import AgentSetupService
from backend.services.agent.agent_events_service import AgentEventsService

__all__ = [
    # Main composite service
    "AgentService",
    # Core services
    "AgentCrudService",
    "AgentHeartbeatService",
    "AgentCommandsService",
    "AgentSetupService",
    "AgentEventsService",
    # Metrics services
    "AgentMetricsService",
    "AgentMetricsRollupService",
    # Alerts services
    "AgentAlertsService",
    "AgentAlertsEvaluationService",
]
