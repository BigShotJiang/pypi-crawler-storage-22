"""
Agent alerts evaluation service.

Handles alert condition evaluation and triggering.
This is a background job service that runs periodically.
"""

import logging
from datetime import datetime, timedelta, UTC

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentAlertConfig, AgentAlertHistory, AgentMetrics1m
from backend.services.agent.agent_events_service import AgentEventsService

logger = logging.getLogger(__name__)


class AgentAlertsEvaluationService:
    """Service for evaluating and triggering alerts."""

    def __init__(self, db: AsyncSession):
        self.db = db
        self._events_service = AgentEventsService(db)

    async def evaluate_alerts(self) -> int:
        """Evaluate all active alert configs and trigger if conditions met."""
        now = datetime.now(UTC)
        triggered_count = 0

        configs = await self._get_enabled_configs()

        for config in configs:
            try:
                if self._is_in_cooldown(config, now):
                    continue

                agent = await self._get_agent(config.agent_id)
                if not agent or agent.deleted_at:
                    continue

                should_trigger, trigger_value = await self._evaluate_config(config, agent, now)

                if should_trigger:
                    await self._trigger_alert(config, trigger_value)
                    triggered_count += 1

            except Exception as e:
                logger.warning("Error evaluating alert config %s: %s", config.id, e)

        if triggered_count > 0:
            await self.db.commit()
            logger.info("Triggered %d alerts", triggered_count)

        return triggered_count

    async def _get_enabled_configs(self) -> list[AgentAlertConfig]:
        """Get all enabled alert configurations."""
        stmt = select(AgentAlertConfig).where(AgentAlertConfig.is_enabled == True)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    def _is_in_cooldown(self, config: AgentAlertConfig, now: datetime) -> bool:
        """Check if config is still in cooldown period."""
        if not config.last_triggered_at:
            return False
        cooldown_end = config.last_triggered_at + timedelta(seconds=config.cooldown_seconds)
        return now < cooldown_end

    async def _get_agent(self, agent_id: str) -> Agent | None:
        """Get agent by ID."""
        stmt = select(Agent).where(Agent.id == agent_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def _evaluate_config(
        self,
        config: AgentAlertConfig,
        agent: Agent,
        now: datetime
    ) -> tuple[bool, float | None]:
        """Evaluate a single alert config. Returns (should_trigger, trigger_value)."""
        evaluators = {
            "offline": self._evaluate_offline_alert,
            "error_rate": self._evaluate_error_rate_alert,
            "latency": self._evaluate_latency_alert,
            "token_budget": self._evaluate_token_budget_alert,
        }

        evaluator = evaluators.get(config.alert_type)
        if not evaluator:
            return False, None

        if config.alert_type == "offline":
            return evaluator(agent)
        return await evaluator(config, now)

    def _evaluate_offline_alert(self, agent: Agent) -> tuple[bool, float | None]:
        """Evaluate offline alert condition."""
        if agent.state in ("offline", "stale"):
            return True, 1.0
        return False, None

    async def _evaluate_error_rate_alert(
        self,
        config: AgentAlertConfig,
        now: datetime
    ) -> tuple[bool, float | None]:
        """Evaluate error rate alert condition."""
        window_start = now - timedelta(seconds=config.window_seconds)
        stmt = (
            select(
                func.sum(AgentMetrics1m.request_count).label("requests"),
                func.sum(AgentMetrics1m.error_count).label("errors"),
            )
            .where(AgentMetrics1m.agent_id == config.agent_id)
            .where(AgentMetrics1m.bucket_time >= window_start)
        )
        result = await self.db.execute(stmt)
        row = result.one_or_none()

        if row and row.requests and row.requests > 0:
            error_rate = (row.errors or 0) / row.requests * 100
            should_trigger = self._check_condition(error_rate, config.condition, config.threshold)
            return should_trigger, error_rate
        return False, None

    async def _evaluate_latency_alert(
        self,
        config: AgentAlertConfig,
        now: datetime
    ) -> tuple[bool, float | None]:
        """Evaluate latency alert condition."""
        window_start = now - timedelta(seconds=config.window_seconds)
        stmt = (
            select(
                func.sum(AgentMetrics1m.request_count).label("requests"),
                func.sum(AgentMetrics1m.total_latency_ms).label("latency"),
            )
            .where(AgentMetrics1m.agent_id == config.agent_id)
            .where(AgentMetrics1m.bucket_time >= window_start)
        )
        result = await self.db.execute(stmt)
        row = result.one_or_none()

        if row and row.requests and row.requests > 0:
            avg_latency = (row.latency or 0) / row.requests
            should_trigger = self._check_condition(avg_latency, config.condition, config.threshold)
            return should_trigger, avg_latency
        return False, None

    async def _evaluate_token_budget_alert(
        self,
        config: AgentAlertConfig,
        now: datetime
    ) -> tuple[bool, float | None]:
        """Evaluate token budget alert condition."""
        window_start = now - timedelta(seconds=config.window_seconds)
        stmt = (
            select(
                func.sum(AgentMetrics1m.input_tokens + AgentMetrics1m.output_tokens).label("tokens"),
            )
            .where(AgentMetrics1m.agent_id == config.agent_id)
            .where(AgentMetrics1m.bucket_time >= window_start)
        )
        result = await self.db.execute(stmt)
        row = result.one_or_none()

        if row and row.tokens:
            should_trigger = self._check_condition(row.tokens, config.condition, config.threshold)
            return should_trigger, float(row.tokens)
        return False, None

    def _check_condition(self, value: float, condition: str, threshold: float) -> bool:
        """Check if value meets condition against threshold."""
        conditions = {
            "gt": lambda v, t: v > t,
            "gte": lambda v, t: v >= t,
            "lt": lambda v, t: v < t,
            "lte": lambda v, t: v <= t,
            "eq": lambda v, t: v == t,
        }
        checker = conditions.get(condition)
        return checker(value, threshold) if checker else False

    async def _trigger_alert(
        self,
        config: AgentAlertConfig,
        trigger_value: float | None
    ) -> None:
        """Trigger an alert and create history record."""
        now = datetime.now(UTC)

        alert = AgentAlertHistory(
            config_id=config.id,
            agent_id=config.agent_id,
            alert_type=config.alert_type,
            severity=config.severity,
            status="triggered",
            message=f"{config.name}: {config.metric} {config.condition} {config.threshold}",
            trigger_value=trigger_value,
            threshold_value=config.threshold,
        )
        self.db.add(alert)

        config.last_triggered_at = now

        await self._events_service.log_event(
            agent_id=config.agent_id,
            event_type="alert_triggered",
            event_data={
                "config_id": config.id,
                "alert_type": config.alert_type,
                "severity": config.severity,
                "trigger_value": trigger_value,
                "threshold": config.threshold,
            },
        )

        logger.info(
            "Alert triggered: agent=%s type=%s severity=%s value=%s threshold=%s",
            config.agent_id, config.alert_type, config.severity, trigger_value, config.threshold
        )
