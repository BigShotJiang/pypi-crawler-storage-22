"""
Agent alerts service.

Handles alert configuration CRUD and history queries.
For alert evaluation and triggering, see agent_alerts_evaluation_service.py.
"""

import logging
from datetime import datetime, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentAlertConfig, AgentAlertHistory
from backend.schemas.agent import CreateAlertConfigRequest, UpdateAlertConfigRequest
from backend.services.agent.agent_alerts_evaluation_service import AgentAlertsEvaluationService

logger = logging.getLogger(__name__)


class AgentAlertsService:
    """Service for alert configuration management."""

    def __init__(self, db: AsyncSession):
        self.db = db
        self._evaluation = AgentAlertsEvaluationService(db)

    # ─── Alert Config CRUD ─────────────────────────────────────────────────────

    async def create_alert_config(
        self,
        agent_id: str,
        user_id: str,
        req: CreateAlertConfigRequest
    ) -> AgentAlertConfig:
        """Create alert configuration."""
        config = AgentAlertConfig(
            agent_id=agent_id,
            user_id=user_id,
            name=req.name,
            alert_type=req.alert_type,
            metric=req.metric,
            condition=req.condition,
            threshold=req.threshold,
            window_seconds=req.window_seconds,
            cooldown_seconds=req.cooldown_seconds,
            severity=req.severity,
            channels=req.channels,
        )
        self.db.add(config)
        await self.db.commit()
        await self.db.refresh(config)
        return config

    async def get_alert_configs(self, agent_id: str) -> list[AgentAlertConfig]:
        """Get alert configurations for an agent."""
        stmt = (
            select(AgentAlertConfig)
            .where(AgentAlertConfig.agent_id == agent_id)
            .order_by(AgentAlertConfig.created_at)
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_alert_configs_for_user(
        self,
        user_id: str,
        agent_id: str
    ) -> list[AgentAlertConfig] | None:
        """Get configs for an agent owned by a user. Returns None if agent not found."""
        if not await self._verify_agent_ownership(user_id, agent_id):
            return None
        return await self.get_alert_configs(agent_id)

    async def update_alert_config(
        self,
        agent_id: str,
        config_id: str,
        req: UpdateAlertConfigRequest
    ) -> AgentAlertConfig | None:
        """Update alert configuration."""
        config = await self._get_config(agent_id, config_id)
        if not config:
            return None

        self._apply_config_updates(config, req)
        config.updated_at = datetime.now(UTC)

        await self.db.commit()
        await self.db.refresh(config)
        return config

    def _apply_config_updates(
        self,
        config: AgentAlertConfig,
        req: UpdateAlertConfigRequest
    ) -> None:
        """Apply update request fields to config."""
        if req.name is not None:
            config.name = req.name
        if req.threshold is not None:
            config.threshold = req.threshold
        if req.window_seconds is not None:
            config.window_seconds = req.window_seconds
        if req.cooldown_seconds is not None:
            config.cooldown_seconds = req.cooldown_seconds
        if req.severity is not None:
            config.severity = req.severity
        if req.channels is not None:
            config.channels = req.channels
        if req.is_enabled is not None:
            config.is_enabled = req.is_enabled

    async def update_alert_config_for_user(
        self,
        user_id: str,
        agent_id: str,
        config_id: str,
        req: UpdateAlertConfigRequest
    ) -> AgentAlertConfig | None:
        """Update config for an agent owned by a user. Returns None if not found."""
        if not await self._verify_agent_ownership(user_id, agent_id):
            return None
        return await self.update_alert_config(agent_id, config_id, req)

    async def delete_alert_config(self, agent_id: str, config_id: str) -> bool:
        """Delete alert configuration."""
        config = await self._get_config(agent_id, config_id)
        if not config:
            return False

        await self.db.delete(config)
        await self.db.commit()
        return True

    async def delete_alert_config_for_user(
        self,
        user_id: str,
        agent_id: str,
        config_id: str
    ) -> bool:
        """Delete config for an agent owned by a user."""
        if not await self._verify_agent_ownership(user_id, agent_id):
            return False
        return await self.delete_alert_config(agent_id, config_id)

    # ─── Alert History ─────────────────────────────────────────────────────────

    async def get_alert_history(self, agent_id: str, limit: int = 50) -> list[AgentAlertHistory]:
        """Get alert history for an agent."""
        stmt = (
            select(AgentAlertHistory)
            .where(AgentAlertHistory.agent_id == agent_id)
            .order_by(AgentAlertHistory.created_at.desc())
            .limit(limit)
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_alert_history_for_user(
        self,
        user_id: str,
        agent_id: str,
        limit: int = 50
    ) -> list[AgentAlertHistory] | None:
        """Get history for an agent owned by a user. Returns None if not found."""
        if not await self._verify_agent_ownership(user_id, agent_id):
            return None
        return await self.get_alert_history(agent_id, limit)

    # ─── Delegated Evaluation ──────────────────────────────────────────────────

    async def evaluate_alerts(self) -> int:
        """Evaluate all active alert configs and trigger if conditions met."""
        return await self._evaluation.evaluate_alerts()

    # ─── Private Helpers ───────────────────────────────────────────────────────

    async def _get_config(
        self,
        agent_id: str,
        config_id: str
    ) -> AgentAlertConfig | None:
        """Get a specific alert config."""
        stmt = (
            select(AgentAlertConfig)
            .where(AgentAlertConfig.id == config_id)
            .where(AgentAlertConfig.agent_id == agent_id)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def _verify_agent_ownership(self, user_id: str, agent_id: str) -> bool:
        """Verify that a user owns an agent."""
        stmt = (
            select(Agent)
            .where(Agent.id == agent_id, Agent.user_id == user_id)
            .where(Agent.deleted_at.is_(None))
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None
