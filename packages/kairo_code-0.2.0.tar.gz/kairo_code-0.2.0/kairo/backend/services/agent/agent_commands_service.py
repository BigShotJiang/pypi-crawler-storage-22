"""
Agent commands service.

Handles command issuing, signing, dispatch, and acknowledgment.
"""

import hashlib
import hmac
import json
import logging
from datetime import datetime, timedelta, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentCommand
from backend.schemas.agent import IssueCommandRequest
from backend.services.agent.constants import COMMAND_SIGNING_KEY, DEFAULT_COMMAND_TTL_MINUTES

logger = logging.getLogger(__name__)


class AgentCommandsService:
    """Service for agent command management."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def issue_command(
        self,
        agent: Agent,
        user_id: str,
        req: IssueCommandRequest
    ) -> AgentCommand:
        """
        Issue a command to an agent.

        Args:
            agent: The target agent
            user_id: The user issuing the command
            req: The command request data

        Returns:
            The created command
        """
        now = datetime.now(UTC)
        expires_at = now + timedelta(minutes=DEFAULT_COMMAND_TTL_MINUTES)

        command = AgentCommand(
            agent_id=agent.id,
            command_type=req.command_type,
            payload=req.payload,
            issued_by=user_id,
            expires_at=expires_at,
        )
        self.db.add(command)

        # If restart, update restart tracking
        if req.command_type == "restart":
            agent.restart_count += 1
            agent.last_restart_at = now
            agent.last_restart_reason = "user_requested"

        await self.db.commit()
        await self.db.refresh(command)
        logger.info("Command issued: agent=%s type=%s", agent.id, req.command_type)
        return command

    async def get_pending_commands(self, agent_id: str) -> list[dict]:
        """
        Get and dispatch pending commands for an agent.

        Returns signed commands ready for dispatch.
        """
        now = datetime.now(UTC)

        stmt = (
            select(AgentCommand)
            .where(AgentCommand.agent_id == agent_id)
            .where(AgentCommand.status == "pending")
            .where(AgentCommand.expires_at > now)
            .order_by(AgentCommand.created_at)
        )
        result = await self.db.execute(stmt)
        commands = list(result.scalars().all())

        signed_commands = []
        for cmd in commands:
            command_data = {
                "command_id": cmd.id,
                "type": cmd.command_type,
                "payload": cmd.payload,
                "issued_at": cmd.created_at.isoformat(),
                "expires_at": cmd.expires_at.isoformat(),
            }
            signature = self._sign_command(command_data)

            signed_commands.append({
                "command_id": cmd.id,
                "type": cmd.command_type,
                "payload": cmd.payload,
                "issued_at": cmd.created_at,
                "expires_at": cmd.expires_at,
                "signature": signature,
            })

            # Mark as dispatched
            cmd.status = "dispatched"
            cmd.dispatched_at = now

        if commands:
            await self.db.commit()

        return signed_commands

    async def acknowledge_command(self, agent_id: str, command_id: str) -> bool:
        """Mark command as acknowledged by agent."""
        stmt = (
            select(AgentCommand)
            .where(AgentCommand.id == command_id)
            .where(AgentCommand.agent_id == agent_id)
        )
        result = await self.db.execute(stmt)
        command = result.scalar_one_or_none()

        if not command:
            return False

        command.status = "acknowledged"
        command.acknowledged_at = datetime.now(UTC)
        await self.db.commit()
        return True

    def _sign_command(self, command_data: dict) -> str:
        """Sign command using HMAC-SHA256."""
        message = json.dumps(command_data, sort_keys=True, default=str).encode()
        return hmac.new(COMMAND_SIGNING_KEY, message, hashlib.sha256).hexdigest()

    def verify_command_signature(self, command_data: dict, signature: str) -> bool:
        """Verify a command signature."""
        expected = self._sign_command(command_data)
        return hmac.compare_digest(expected, signature)
