"""
Agent CRUD operations service.

Handles registration, listing, retrieval, updating, and deletion of agents.
"""

import json
import logging
from datetime import datetime, timedelta, UTC

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentMetrics1m
from backend.schemas.agent import RegisterAgentRequest, UpdateAgentRequest

logger = logging.getLogger(__name__)


class AgentCrudService:
    """Service for agent CRUD operations."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def register(self, user_id: str, req: RegisterAgentRequest) -> Agent:
        """Register a new agent."""
        agent = Agent(
            user_id=user_id,
            name=req.name,
            description=req.description,
            system_prompt=req.system_prompt,
            model_preference=req.model_preference,
            agent_type=req.agent_type,
            tools_config=json.dumps(req.tools) if req.tools else None,
            state="created",
        )
        self.db.add(agent)
        await self.db.commit()
        await self.db.refresh(agent)
        logger.info("Agent registered: user=%s name=%s id=%s", user_id, req.name, agent.id)
        return agent

    async def list_agents(self, user_id: str) -> list[Agent]:
        """List all agents for a user."""
        stmt = (
            select(Agent)
            .where(Agent.user_id == user_id)
            .where(Agent.deleted_at.is_(None))
            .order_by(Agent.created_at.desc())
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def list_agents_with_metrics(self, user_id: str) -> list[dict]:
        """List agents with 24h summary metrics."""
        agents = await self.list_agents(user_id)
        cutoff = datetime.now(UTC) - timedelta(hours=24)

        result = []
        for agent in agents:
            metrics_stmt = (
                select(
                    func.sum(AgentMetrics1m.request_count).label("requests"),
                    func.sum(AgentMetrics1m.error_count).label("errors"),
                    func.sum(AgentMetrics1m.input_tokens + AgentMetrics1m.output_tokens).label("tokens"),
                )
                .where(AgentMetrics1m.agent_id == agent.id)
                .where(AgentMetrics1m.bucket_time >= cutoff)
            )
            metrics_result = await self.db.execute(metrics_stmt)
            row = metrics_result.one_or_none()

            requests_24h = row.requests or 0 if row else 0
            errors_24h = row.errors or 0 if row else 0
            tokens_24h = row.tokens or 0 if row else 0
            error_rate = (errors_24h / requests_24h * 100) if requests_24h > 0 else 0.0

            result.append({
                "id": agent.id,
                "name": agent.name,
                "description": agent.description,
                "model_preference": agent.model_preference,
                "agent_type": agent.agent_type,
                "state": agent.state,
                "sdk_version": agent.sdk_version,
                "last_heartbeat_at": agent.last_heartbeat_at,
                "created_at": agent.created_at,
                "requests_24h": requests_24h,
                "errors_24h": errors_24h,
                "tokens_24h": tokens_24h,
                "error_rate": round(error_rate, 2),
            })

        return result

    async def get_agent(self, user_id: str, agent_id: str) -> Agent | None:
        """Get agent by ID for a specific user."""
        stmt = (
            select(Agent)
            .where(Agent.id == agent_id, Agent.user_id == user_id)
            .where(Agent.deleted_at.is_(None))
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_agent_by_id(self, agent_id: str) -> Agent | None:
        """Get agent by ID only (for SDK auth)."""
        stmt = select(Agent).where(Agent.id == agent_id).where(Agent.deleted_at.is_(None))
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def update_agent(
        self,
        user_id: str,
        agent_id: str,
        req: UpdateAgentRequest
    ) -> Agent | None:
        """Update agent properties."""
        agent = await self.get_agent(user_id, agent_id)
        if not agent:
            return None

        if req.name is not None:
            agent.name = req.name
        if req.description is not None:
            agent.description = req.description
        if req.system_prompt is not None:
            agent.system_prompt = req.system_prompt
        if req.model_preference is not None:
            agent.model_preference = req.model_preference
        if req.tools is not None:
            agent.tools_config = json.dumps(req.tools)

        agent.updated_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(agent)
        return agent

    async def delete_agent(self, user_id: str, agent_id: str) -> bool:
        """Soft delete agent."""
        agent = await self.get_agent(user_id, agent_id)
        if not agent:
            return False

        agent.deleted_at = datetime.now(UTC)
        agent.state = "disabled"
        await self.db.commit()
        logger.info("Agent deleted: id=%s user=%s", agent_id, user_id)
        return True
