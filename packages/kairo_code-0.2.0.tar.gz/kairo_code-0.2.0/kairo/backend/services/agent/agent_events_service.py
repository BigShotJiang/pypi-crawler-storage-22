"""
Agent events service.

Handles event logging and querying for agent activity tracking.
"""

import logging
from datetime import datetime, timedelta, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentEvent
from backend.services.agent.constants import DEFAULT_EVENTS_RETENTION_DAYS

logger = logging.getLogger(__name__)


class AgentEventsService:
    """Service for agent event management."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def log_event(
        self,
        agent_id: str,
        event_type: str,
        event_data: dict | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        client_ip: str | None = None,
    ) -> AgentEvent:
        """Log an agent event."""
        event = AgentEvent(
            agent_id=agent_id,
            event_type=event_type,
            event_data=event_data,
            error_type=error_type,
            error_message=error_message,
            client_ip=client_ip,
        )
        self.db.add(event)
        return event

    async def get_events(
        self,
        agent_id: str,
        event_type: str | None = None,
        limit: int = 50,
    ) -> list[AgentEvent]:
        """Get agent events with optional type filter."""
        stmt = (
            select(AgentEvent)
            .where(AgentEvent.agent_id == agent_id)
            .order_by(AgentEvent.created_at.desc())
            .limit(limit)
        )
        if event_type:
            stmt = stmt.where(AgentEvent.event_type == event_type)

        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_events_for_user(
        self,
        user_id: str,
        agent_id: str,
        event_type: str | None = None,
        limit: int = 50,
    ) -> list[AgentEvent] | None:
        """Get events for an agent owned by a user. Returns None if agent not found."""
        # Verify agent ownership
        agent_stmt = (
            select(Agent)
            .where(Agent.id == agent_id, Agent.user_id == user_id)
            .where(Agent.deleted_at.is_(None))
        )
        agent_result = await self.db.execute(agent_stmt)
        if not agent_result.scalar_one_or_none():
            return None

        return await self.get_events(agent_id, event_type, limit)

    async def cleanup_old_events(
        self,
        retention_days: int = DEFAULT_EVENTS_RETENTION_DAYS
    ) -> int:
        """Clean up old events based on retention policy."""
        cutoff = datetime.now(UTC) - timedelta(days=retention_days)
        stmt = select(AgentEvent).where(AgentEvent.created_at < cutoff)
        result = await self.db.execute(stmt)
        events = list(result.scalars().all())
        count = len(events)

        for event in events:
            await self.db.delete(event)

        if count > 0:
            await self.db.commit()
            logger.info("Cleaned up %d old events", count)

        return count
