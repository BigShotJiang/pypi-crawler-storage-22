"""
Agent heartbeat service.

Handles heartbeat processing, agent state management, and background state checks.
"""

import logging
from datetime import datetime, timedelta, UTC

from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentMetrics1m
from backend.schemas.agent import AgentHeartbeatRequest
from backend.services.agent.agent_events_service import AgentEventsService
from backend.services.agent.agent_commands_service import AgentCommandsService
from backend.services.agent.constants import (
    DEFAULT_HEARTBEAT_TIMEOUT_SECONDS,
    DEFAULT_STALE_AGENT_DAYS,
)

logger = logging.getLogger(__name__)


class AgentHeartbeatService:
    """Service for agent heartbeat processing and state management."""

    def __init__(self, db: AsyncSession):
        self.db = db
        self._events_service = AgentEventsService(db)
        self._commands_service = AgentCommandsService(db)

    async def heartbeat(
        self,
        agent: Agent,
        req: AgentHeartbeatRequest,
        client_ip: str | None = None
    ) -> tuple[Agent, list[dict]]:
        """
        Process heartbeat and return agent + pending commands.

        Args:
            agent: The agent to process heartbeat for
            req: The heartbeat request data
            client_ip: Optional client IP address

        Returns:
            Tuple of (updated agent, list of pending commands)
        """
        now = datetime.now(UTC)
        is_first_connection = agent.first_connected_at is None

        # Update agent status
        agent.status = req.status
        agent.last_heartbeat_at = now

        # Update state based on status
        self._update_agent_state(agent, req, now, is_first_connection)

        # Update SDK info
        if req.sdk_version:
            agent.sdk_version = req.sdk_version
        if req.host_info:
            agent.host_info = req.host_info.model_dump()

        # Record metrics if provided
        if req.metrics_since_last_heartbeat:
            await self._record_metrics(agent.id, req.metrics_since_last_heartbeat)

        # Log event
        await self._events_service.log_event(
            agent_id=agent.id,
            event_type="heartbeat",
            event_data={
                "status": req.status,
                "sdk_version": req.sdk_version,
                "queue_depth": req.queue_depth,
                "active_request": req.active_request,
            },
            client_ip=client_ip,
        )

        agent.updated_at = now
        await self.db.commit()
        await self.db.refresh(agent)

        # Get pending commands
        commands = await self._commands_service.get_pending_commands(agent.id)

        return agent, commands

    def _update_agent_state(
        self,
        agent: Agent,
        req: AgentHeartbeatRequest,
        now: datetime,
        is_first_connection: bool
    ) -> None:
        """Update agent state based on heartbeat status."""
        if req.status in ("online", "busy", "idle"):
            agent.state = "online" if req.status == "online" else req.status
            agent.last_online_at = now
            if is_first_connection:
                agent.first_connected_at = now
        elif req.status == "error":
            agent.state = "error"
            if req.last_error:
                agent.last_error_at = now
                agent.last_error_message = req.last_error.get("message", "Unknown error")

    async def _record_metrics(self, agent_id: str, metrics) -> None:
        """Record metrics in 1-minute bucket."""
        now = datetime.now(UTC)
        bucket_time = now.replace(second=0, microsecond=0)

        stmt = select(AgentMetrics1m).where(
            AgentMetrics1m.agent_id == agent_id,
            AgentMetrics1m.bucket_time == bucket_time
        )
        result = await self.db.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            existing.request_count += metrics.requests_completed + metrics.requests_failed
            existing.error_count += metrics.requests_failed
            existing.input_tokens += metrics.input_tokens
            existing.output_tokens += metrics.output_tokens
            existing.total_latency_ms += metrics.total_latency_ms
            existing.tool_calls += metrics.tool_calls
            existing.tool_errors += metrics.tool_errors
        else:
            new_metrics = AgentMetrics1m(
                agent_id=agent_id,
                bucket_time=bucket_time,
                request_count=metrics.requests_completed + metrics.requests_failed,
                error_count=metrics.requests_failed,
                input_tokens=metrics.input_tokens,
                output_tokens=metrics.output_tokens,
                total_latency_ms=metrics.total_latency_ms,
                tool_calls=metrics.tool_calls,
                tool_errors=metrics.tool_errors,
            )
            self.db.add(new_metrics)

    async def mark_stale_agents_offline(
        self,
        threshold_seconds: int = DEFAULT_HEARTBEAT_TIMEOUT_SECONDS
    ) -> int:
        """Mark agents as offline if no heartbeat within threshold."""
        cutoff = datetime.now(UTC) - timedelta(seconds=threshold_seconds)
        stmt = (
            select(Agent)
            .where(Agent.state.in_(["online", "busy", "idle"]))
            .where(Agent.deleted_at.is_(None))
            .where(
                or_(
                    Agent.last_heartbeat_at < cutoff,
                    Agent.last_heartbeat_at.is_(None)
                )
            )
        )
        result = await self.db.execute(stmt)
        agents = list(result.scalars().all())

        for agent in agents:
            old_state = agent.state
            agent.state = "offline"
            agent.status = "offline"
            agent.updated_at = datetime.now(UTC)

            await self._events_service.log_event(
                agent_id=agent.id,
                event_type="state_change",
                event_data={
                    "from": old_state,
                    "to": "offline",
                    "reason": "heartbeat_timeout"
                },
            )

        if agents:
            await self.db.commit()
            logger.info("Marked %d agents as offline", len(agents))

        return len(agents)

    async def mark_stale_agents(self, days: int = DEFAULT_STALE_AGENT_DAYS) -> int:
        """Mark offline agents as stale after days."""
        cutoff = datetime.now(UTC) - timedelta(days=days)
        stmt = (
            select(Agent)
            .where(Agent.state == "offline")
            .where(Agent.deleted_at.is_(None))
            .where(Agent.last_online_at < cutoff)
        )
        result = await self.db.execute(stmt)
        agents = list(result.scalars().all())

        for agent in agents:
            agent.state = "stale"
            agent.updated_at = datetime.now(UTC)

        if agents:
            await self.db.commit()
            logger.info("Marked %d agents as stale", len(agents))

        return len(agents)
