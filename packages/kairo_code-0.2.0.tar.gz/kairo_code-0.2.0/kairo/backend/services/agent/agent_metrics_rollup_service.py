"""
Agent metrics rollup and maintenance service.

Handles metrics rollups (1m -> 1h -> daily) and cleanup operations.
These are background job operations that run periodically.
"""

import logging
from datetime import datetime, timedelta, date, UTC

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import AgentMetrics1m, AgentMetrics1h, AgentMetricsDaily
from backend.services.agent.constants import (
    DEFAULT_METRICS_1M_RETENTION_DAYS,
    DEFAULT_METRICS_1H_RETENTION_DAYS,
)

logger = logging.getLogger(__name__)


class AgentMetricsRollupService:
    """Service for metrics rollup and maintenance operations."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def rollup_1m_to_1h(self) -> int:
        """Rollup 1-minute metrics into hourly buckets. Run every hour."""
        now = datetime.now(UTC)
        hour_start = (now - timedelta(hours=2)).replace(minute=0, second=0, microsecond=0)
        hour_end = hour_start + timedelta(hours=1)

        agent_ids = await self._get_agents_with_1m_data(hour_start, hour_end)

        count = 0
        for agent_id in agent_ids:
            if await self._hourly_bucket_exists(agent_id, hour_start):
                continue

            row = await self._aggregate_1m_data(agent_id, hour_start, hour_end)

            if row.request_count and row.request_count > 0:
                self._create_hourly_bucket(agent_id, hour_start, row)
                count += 1

        if count > 0:
            await self.db.commit()
            logger.info("Rolled up %d hourly metric buckets", count)

        return count

    async def rollup_1h_to_daily(self) -> int:
        """Rollup hourly metrics into daily buckets. Run once per day."""
        now = datetime.now(UTC)
        yesterday = (now - timedelta(days=1)).date()
        day_start = datetime.combine(yesterday, datetime.min.time()).replace(tzinfo=UTC)
        day_end = day_start + timedelta(days=1)

        agent_ids = await self._get_agents_with_hourly_data(day_start, day_end)

        count = 0
        for agent_id in agent_ids:
            if await self._daily_bucket_exists(agent_id, yesterday):
                continue

            row = await self._aggregate_1h_data(agent_id, day_start, day_end)

            if row.request_count and row.request_count > 0:
                self._create_daily_bucket(agent_id, yesterday, row)
                count += 1

        if count > 0:
            await self.db.commit()
            logger.info("Rolled up %d daily metric buckets", count)

        return count

    async def cleanup_old_metrics(
        self,
        retention_days_1m: int = DEFAULT_METRICS_1M_RETENTION_DAYS,
        retention_days_1h: int = DEFAULT_METRICS_1H_RETENTION_DAYS
    ) -> tuple[int, int]:
        """Clean up old metrics based on retention policy."""
        now = datetime.now(UTC)

        deleted_1m = await self._cleanup_metrics_table(
            AgentMetrics1m,
            now - timedelta(days=retention_days_1m)
        )

        deleted_1h = await self._cleanup_metrics_table(
            AgentMetrics1h,
            now - timedelta(days=retention_days_1h)
        )

        if deleted_1m > 0 or deleted_1h > 0:
            await self.db.commit()
            logger.info("Cleaned up metrics: %d 1m records, %d 1h records", deleted_1m, deleted_1h)

        return deleted_1m, deleted_1h

    # ─── Private Helpers ───────────────────────────────────────────────────────

    async def _get_agents_with_1m_data(
        self,
        start: datetime,
        end: datetime
    ) -> list[str]:
        """Get list of agent IDs with 1m data in the time range."""
        stmt = (
            select(AgentMetrics1m.agent_id)
            .where(AgentMetrics1m.bucket_time >= start)
            .where(AgentMetrics1m.bucket_time < end)
            .distinct()
        )
        result = await self.db.execute(stmt)
        return [row[0] for row in result.all()]

    async def _get_agents_with_hourly_data(
        self,
        start: datetime,
        end: datetime
    ) -> list[str]:
        """Get list of agent IDs with hourly data."""
        stmt = (
            select(AgentMetrics1h.agent_id)
            .where(AgentMetrics1h.bucket_time >= start)
            .where(AgentMetrics1h.bucket_time < end)
            .distinct()
        )
        result = await self.db.execute(stmt)
        return [row[0] for row in result.all()]

    async def _hourly_bucket_exists(self, agent_id: str, hour_start: datetime) -> bool:
        """Check if hourly bucket already exists."""
        stmt = select(AgentMetrics1h).where(
            AgentMetrics1h.agent_id == agent_id,
            AgentMetrics1h.bucket_time == hour_start
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def _daily_bucket_exists(self, agent_id: str, day: date) -> bool:
        """Check if daily bucket already exists."""
        stmt = select(AgentMetricsDaily).where(
            AgentMetricsDaily.agent_id == agent_id,
            AgentMetricsDaily.date == day
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None

    async def _aggregate_1m_data(self, agent_id: str, start: datetime, end: datetime):
        """Aggregate 1-minute data for a time range."""
        stmt = (
            select(
                func.sum(AgentMetrics1m.request_count).label("request_count"),
                func.sum(AgentMetrics1m.error_count).label("error_count"),
                func.sum(AgentMetrics1m.timeout_count).label("timeout_count"),
                func.sum(AgentMetrics1m.input_tokens).label("input_tokens"),
                func.sum(AgentMetrics1m.output_tokens).label("output_tokens"),
                func.sum(AgentMetrics1m.total_latency_ms).label("total_latency_ms"),
                func.min(AgentMetrics1m.min_latency_ms).label("min_latency_ms"),
                func.max(AgentMetrics1m.max_latency_ms).label("max_latency_ms"),
                func.sum(AgentMetrics1m.tool_calls).label("tool_calls"),
                func.sum(AgentMetrics1m.tool_errors).label("tool_errors"),
            )
            .where(AgentMetrics1m.agent_id == agent_id)
            .where(AgentMetrics1m.bucket_time >= start)
            .where(AgentMetrics1m.bucket_time < end)
        )
        result = await self.db.execute(stmt)
        return result.one()

    async def _aggregate_1h_data(self, agent_id: str, start: datetime, end: datetime):
        """Aggregate hourly data for a time range."""
        stmt = (
            select(
                func.sum(AgentMetrics1h.request_count).label("request_count"),
                func.sum(AgentMetrics1h.error_count).label("error_count"),
                func.sum(AgentMetrics1h.timeout_count).label("timeout_count"),
                func.sum(AgentMetrics1h.input_tokens).label("input_tokens"),
                func.sum(AgentMetrics1h.output_tokens).label("output_tokens"),
                func.sum(AgentMetrics1h.total_latency_ms).label("total_latency_ms"),
                func.min(AgentMetrics1h.min_latency_ms).label("min_latency_ms"),
                func.max(AgentMetrics1h.max_latency_ms).label("max_latency_ms"),
                func.sum(AgentMetrics1h.tool_calls).label("tool_calls"),
                func.sum(AgentMetrics1h.tool_errors).label("tool_errors"),
            )
            .where(AgentMetrics1h.agent_id == agent_id)
            .where(AgentMetrics1h.bucket_time >= start)
            .where(AgentMetrics1h.bucket_time < end)
        )
        result = await self.db.execute(stmt)
        return result.one()

    def _create_hourly_bucket(self, agent_id: str, hour_start: datetime, row) -> None:
        """Create an hourly metrics bucket."""
        hourly = AgentMetrics1h(
            agent_id=agent_id,
            bucket_time=hour_start,
            request_count=row.request_count or 0,
            error_count=row.error_count or 0,
            timeout_count=row.timeout_count or 0,
            input_tokens=row.input_tokens or 0,
            output_tokens=row.output_tokens or 0,
            total_latency_ms=row.total_latency_ms or 0,
            min_latency_ms=row.min_latency_ms,
            max_latency_ms=row.max_latency_ms,
            tool_calls=row.tool_calls or 0,
            tool_errors=row.tool_errors or 0,
        )
        self.db.add(hourly)

    def _create_daily_bucket(self, agent_id: str, day: date, row) -> None:
        """Create a daily metrics bucket."""
        avg_latency = None
        if row.request_count and row.request_count > 0 and row.total_latency_ms:
            avg_latency = int(row.total_latency_ms / row.request_count)

        daily = AgentMetricsDaily(
            agent_id=agent_id,
            date=day,
            request_count=row.request_count or 0,
            error_count=row.error_count or 0,
            timeout_count=row.timeout_count or 0,
            input_tokens=row.input_tokens or 0,
            output_tokens=row.output_tokens or 0,
            total_latency_ms=row.total_latency_ms or 0,
            min_latency_ms=row.min_latency_ms,
            max_latency_ms=row.max_latency_ms,
            avg_latency_ms=avg_latency,
            tool_calls=row.tool_calls or 0,
            tool_errors=row.tool_errors or 0,
        )
        self.db.add(daily)

    async def _cleanup_metrics_table(self, model, cutoff: datetime) -> int:
        """Delete old records from a metrics table."""
        stmt = select(model).where(model.bucket_time < cutoff)
        result = await self.db.execute(stmt)
        records = list(result.scalars().all())

        for record in records:
            await self.db.delete(record)

        return len(records)
