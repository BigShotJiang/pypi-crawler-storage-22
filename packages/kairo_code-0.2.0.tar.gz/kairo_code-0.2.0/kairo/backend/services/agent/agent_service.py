"""
Main agent service - composes all sub-services.

This class maintains backward compatibility with the original monolithic API
by delegating to focused sub-services while exposing the same interface.
"""

import logging
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import (
    Agent, AgentCommand, AgentAlertConfig, AgentAlertHistory, AgentEvent
)
from backend.models.api_key import ApiKey
from backend.schemas.agent import (
    RegisterAgentRequest, UpdateAgentRequest, AgentHeartbeatRequest,
    CreateAlertConfigRequest, UpdateAlertConfigRequest, IssueCommandRequest,
    TelemetryBatchRequest
)
from backend.services.agent.agent_crud_service import AgentCrudService
from backend.services.agent.agent_heartbeat_service import AgentHeartbeatService
from backend.services.agent.agent_commands_service import AgentCommandsService
from backend.services.agent.agent_metrics_service import AgentMetricsService
from backend.services.agent.agent_alerts_service import AgentAlertsService
from backend.services.agent.agent_setup_service import AgentSetupService
from backend.services.agent.agent_events_service import AgentEventsService

logger = logging.getLogger(__name__)


class AgentService:
    """
    Composite agent service maintaining backward compatibility.

    This class composes all sub-services and delegates calls to them,
    ensuring the existing API contracts remain intact.
    """

    def __init__(self, db: AsyncSession):
        self.db = db

        # Initialize sub-services
        self._crud = AgentCrudService(db)
        self._heartbeat = AgentHeartbeatService(db)
        self._commands = AgentCommandsService(db)
        self._metrics = AgentMetricsService(db)
        self._alerts = AgentAlertsService(db)
        self._setup = AgentSetupService(db)
        self._events = AgentEventsService(db)

    # ─── CRUD Operations ───────────────────────────────────────────────────────

    async def register(self, user_id: str, req: RegisterAgentRequest) -> Agent:
        """Register a new agent."""
        return await self._crud.register(user_id, req)

    async def list_agents(self, user_id: str) -> list[Agent]:
        """List all agents for a user."""
        return await self._crud.list_agents(user_id)

    async def list_agents_with_metrics(self, user_id: str) -> list[dict]:
        """List agents with 24h summary metrics."""
        return await self._crud.list_agents_with_metrics(user_id)

    async def get_agent(self, user_id: str, agent_id: str) -> Agent | None:
        """Get agent by ID for a specific user."""
        return await self._crud.get_agent(user_id, agent_id)

    async def get_agent_by_id(self, agent_id: str) -> Agent | None:
        """Get agent by ID only (for SDK auth)."""
        return await self._crud.get_agent_by_id(agent_id)

    async def update_agent(
        self,
        user_id: str,
        agent_id: str,
        req: UpdateAgentRequest
    ) -> Agent | None:
        """Update agent properties."""
        return await self._crud.update_agent(user_id, agent_id, req)

    async def delete_agent(self, user_id: str, agent_id: str) -> bool:
        """Soft delete agent."""
        return await self._crud.delete_agent(user_id, agent_id)

    # ─── Heartbeat ─────────────────────────────────────────────────────────────

    async def heartbeat(
        self,
        agent_id: str,
        user_id: str,
        req: AgentHeartbeatRequest,
        client_ip: str | None = None
    ) -> tuple[Agent | None, list[dict]]:
        """Process heartbeat and return agent + pending commands."""
        agent = await self.get_agent(user_id, agent_id)
        if not agent:
            return None, []
        return await self._heartbeat.heartbeat(agent, req, client_ip)

    async def mark_stale_agents_offline(self, threshold_seconds: int = 90) -> int:
        """Mark agents as offline if no heartbeat within threshold."""
        return await self._heartbeat.mark_stale_agents_offline(threshold_seconds)

    async def mark_stale_agents(self, days: int = 7) -> int:
        """Mark offline agents as stale after days."""
        return await self._heartbeat.mark_stale_agents(days)

    # ─── Commands ──────────────────────────────────────────────────────────────

    async def issue_command(
        self,
        user_id: str,
        agent_id: str,
        req: IssueCommandRequest
    ) -> AgentCommand | None:
        """Issue a command to an agent."""
        agent = await self.get_agent(user_id, agent_id)
        if not agent:
            return None

        command = await self._commands.issue_command(agent, user_id, req)

        # Log command_issued event
        await self._events.log_event(
            agent_id=agent_id,
            event_type="command_issued",
            event_data={"command_type": req.command_type, "command_id": command.id},
        )
        await self.db.commit()

        return command

    async def acknowledge_command(self, agent_id: str, command_id: str) -> bool:
        """Mark command as acknowledged by agent."""
        return await self._commands.acknowledge_command(agent_id, command_id)

    # ─── Metrics ───────────────────────────────────────────────────────────────

    async def get_metrics(
        self,
        user_id: str,
        agent_id: str,
        range_str: str = "24h",
        granularity: str = "auto"
    ) -> dict | None:
        """Get agent metrics for a time range."""
        return await self._metrics.get_metrics_for_user(
            user_id, agent_id, range_str, granularity
        )

    async def process_telemetry_batch(
        self,
        agent_id: str,
        req: TelemetryBatchRequest
    ) -> tuple[int, int, list[str]]:
        """Process a batch of telemetry events."""
        return await self._metrics.process_telemetry_batch(agent_id, req)

    async def rollup_1m_to_1h(self) -> int:
        """Rollup 1-minute metrics into hourly buckets."""
        return await self._metrics.rollup_1m_to_1h()

    async def rollup_1h_to_daily(self) -> int:
        """Rollup hourly metrics into daily buckets."""
        return await self._metrics.rollup_1h_to_daily()

    async def cleanup_old_metrics(
        self,
        retention_days_1m: int = 30,
        retention_days_1h: int = 365
    ) -> tuple[int, int]:
        """Clean up old metrics based on retention policy."""
        return await self._metrics.cleanup_old_metrics(
            retention_days_1m, retention_days_1h
        )

    # ─── Events ────────────────────────────────────────────────────────────────

    async def get_events(
        self,
        user_id: str,
        agent_id: str,
        event_type: str | None = None,
        limit: int = 50,
    ) -> list[AgentEvent] | None:
        """Get agent events."""
        return await self._events.get_events_for_user(
            user_id, agent_id, event_type, limit
        )

    async def cleanup_old_events(self, retention_days: int = 90) -> int:
        """Clean up old events based on retention policy."""
        return await self._events.cleanup_old_events(retention_days)

    # ─── Setup Tokens ──────────────────────────────────────────────────────────

    async def generate_setup_token(
        self,
        user_id: str,
        agent_id: str,
        ttl_minutes: int = 15
    ) -> tuple[str, datetime] | None:
        """Generate a one-time setup token."""
        return await self._setup.generate_setup_token_for_user(
            user_id, agent_id, ttl_minutes
        )

    async def consume_setup_token(
        self,
        token: str,
        client_ip: str | None = None
    ) -> Agent | None:
        """Consume a setup token and return the agent."""
        return await self._setup.consume_setup_token(token, client_ip)

    async def create_agent_api_key(
        self,
        user_id: str,
        agent_id: str,
        agent_name: str
    ) -> tuple[str, ApiKey]:
        """Create an API key scoped to an agent."""
        return await self._setup.create_agent_api_key(user_id, agent_id, agent_name)

    # ─── Alerts ────────────────────────────────────────────────────────────────

    async def create_alert_config(
        self,
        user_id: str,
        agent_id: str,
        req: CreateAlertConfigRequest
    ) -> AgentAlertConfig | None:
        """Create alert configuration."""
        agent = await self.get_agent(user_id, agent_id)
        if not agent:
            return None
        return await self._alerts.create_alert_config(agent_id, user_id, req)

    async def get_alert_configs(
        self,
        user_id: str,
        agent_id: str
    ) -> list[AgentAlertConfig] | None:
        """Get alert configurations for an agent."""
        return await self._alerts.get_alert_configs_for_user(user_id, agent_id)

    async def update_alert_config(
        self,
        user_id: str,
        agent_id: str,
        config_id: str,
        req: UpdateAlertConfigRequest
    ) -> AgentAlertConfig | None:
        """Update alert configuration."""
        return await self._alerts.update_alert_config_for_user(
            user_id, agent_id, config_id, req
        )

    async def delete_alert_config(
        self,
        user_id: str,
        agent_id: str,
        config_id: str
    ) -> bool:
        """Delete alert configuration."""
        return await self._alerts.delete_alert_config_for_user(
            user_id, agent_id, config_id
        )

    async def get_alert_history(
        self,
        user_id: str,
        agent_id: str,
        limit: int = 50
    ) -> list[AgentAlertHistory] | None:
        """Get alert history for an agent."""
        return await self._alerts.get_alert_history_for_user(user_id, agent_id, limit)

    async def evaluate_alerts(self) -> int:
        """Evaluate all active alert configs and trigger if conditions met."""
        return await self._alerts.evaluate_alerts()

    # ─── Internal helpers (for sub-services that need event logging) ──────────

    async def _log_event(
        self,
        agent_id: str,
        event_type: str,
        event_data: dict | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        client_ip: str | None = None,
    ) -> None:
        """Log an agent event. For internal use by legacy code paths."""
        await self._events.log_event(
            agent_id=agent_id,
            event_type=event_type,
            event_data=event_data,
            error_type=error_type,
            error_message=error_message,
            client_ip=client_ip,
        )

    async def _record_metrics(self, agent_id: str, metrics) -> None:
        """Record metrics. For internal use by legacy code paths."""
        # This delegates to heartbeat service's internal method
        # In practice, metrics should be recorded via heartbeat or telemetry
        pass

    async def _get_pending_commands(self, agent_id: str) -> list[dict]:
        """Get pending commands. For internal use by legacy code paths."""
        return await self._commands.get_pending_commands(agent_id)
