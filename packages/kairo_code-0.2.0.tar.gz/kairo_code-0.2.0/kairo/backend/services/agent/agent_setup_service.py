"""
Agent setup service.

Handles setup tokens, registration via tokens, and API key creation.
"""

import hashlib
import logging
import secrets
from datetime import datetime, timedelta, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent, AgentSetupToken
from backend.models.api_key import ApiKey
from backend.services.agent.constants import DEFAULT_SETUP_TOKEN_TTL_MINUTES

logger = logging.getLogger(__name__)


class AgentSetupService:
    """Service for agent setup and registration."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def generate_setup_token(
        self,
        agent_id: str,
        user_id: str,
        ttl_minutes: int = DEFAULT_SETUP_TOKEN_TTL_MINUTES
    ) -> tuple[str, datetime]:
        """
        Generate a one-time setup token for an agent.

        Args:
            agent_id: The agent to generate token for
            user_id: The user who owns the agent
            ttl_minutes: Token time-to-live in minutes

        Returns:
            Tuple of (token, expiration datetime)
        """
        token = f"kairo_setup_{secrets.token_urlsafe(32)}"
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        expires_at = datetime.now(UTC) + timedelta(minutes=ttl_minutes)

        setup_token = AgentSetupToken(
            agent_id=agent_id,
            user_id=user_id,
            token_hash=token_hash,
            expires_at=expires_at,
        )
        self.db.add(setup_token)
        await self.db.commit()

        logger.info("Setup token generated: agent=%s", agent_id)
        return token, expires_at

    async def generate_setup_token_for_user(
        self,
        user_id: str,
        agent_id: str,
        ttl_minutes: int = DEFAULT_SETUP_TOKEN_TTL_MINUTES
    ) -> tuple[str, datetime] | None:
        """
        Generate a setup token for an agent owned by a user.

        Returns None if the agent is not found or not owned by the user.
        """
        if not await self._verify_agent_ownership(user_id, agent_id):
            return None
        return await self.generate_setup_token(agent_id, user_id, ttl_minutes)

    async def consume_setup_token(
        self,
        token: str,
        client_ip: str | None = None
    ) -> Agent | None:
        """
        Consume a setup token and return the agent.

        Marks the token as used and activates the agent.

        Args:
            token: The setup token to consume
            client_ip: Optional client IP address

        Returns:
            The agent if token is valid, None otherwise
        """
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        now = datetime.now(UTC)

        stmt = (
            select(AgentSetupToken)
            .where(AgentSetupToken.token_hash == token_hash)
            .where(AgentSetupToken.used == False)
            .where(AgentSetupToken.expires_at > now)
        )
        result = await self.db.execute(stmt)
        setup_token = result.scalar_one_or_none()

        if not setup_token:
            return None

        # Mark as used
        setup_token.used = True
        setup_token.used_at = now
        setup_token.used_from_ip = client_ip

        # Get and activate agent
        agent = await self._get_agent_by_id(setup_token.agent_id)
        if agent:
            agent.state = "online"
            agent.first_connected_at = now
            agent.last_online_at = now

        await self.db.commit()
        logger.info("Setup token consumed: agent=%s", setup_token.agent_id)
        return agent

    async def create_agent_api_key(
        self,
        user_id: str,
        agent_id: str,
        agent_name: str
    ) -> tuple[str, ApiKey]:
        """
        Create an API key scoped to an agent.

        Args:
            user_id: The user who owns the agent
            agent_id: The agent to create key for
            agent_name: The agent name for key naming

        Returns:
            Tuple of (raw key, ApiKey model)
        """
        from argon2 import PasswordHasher

        # Generate key
        key_raw = secrets.token_urlsafe(32)
        key = f"kairo_agent_{key_raw}"
        key_prefix = key[:20]

        # Hash
        ph = PasswordHasher()
        key_hash = ph.hash(key)

        api_key = ApiKey(
            user_id=user_id,
            agent_id=agent_id,
            name=f"Agent: {agent_name}",
            key_prefix=key_prefix,
            key_hash=key_hash,
            key_type="agent",
        )
        self.db.add(api_key)
        await self.db.commit()
        await self.db.refresh(api_key)

        return key, api_key

    async def _get_agent_by_id(self, agent_id: str) -> Agent | None:
        """Get agent by ID."""
        stmt = select(Agent).where(Agent.id == agent_id).where(Agent.deleted_at.is_(None))
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def _verify_agent_ownership(self, user_id: str, agent_id: str) -> bool:
        """Verify that a user owns an agent."""
        stmt = (
            select(Agent)
            .where(Agent.id == agent_id, Agent.user_id == user_id)
            .where(Agent.deleted_at.is_(None))
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none() is not None
