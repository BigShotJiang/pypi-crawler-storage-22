"""
Shared constants for agent services.
"""

import secrets

# Command signing key (in production, load from secrets manager)
COMMAND_SIGNING_KEY = secrets.token_bytes(32)

# Default thresholds
DEFAULT_HEARTBEAT_TIMEOUT_SECONDS = 90
DEFAULT_STALE_AGENT_DAYS = 7
DEFAULT_COMMAND_TTL_MINUTES = 5
DEFAULT_SETUP_TOKEN_TTL_MINUTES = 15

# Retention policies
DEFAULT_METRICS_1M_RETENTION_DAYS = 30
DEFAULT_METRICS_1H_RETENTION_DAYS = 365
DEFAULT_EVENTS_RETENTION_DAYS = 90

# Time range mappings for metrics queries
TIME_RANGE_MAP = {
    "1h": 1,       # hours
    "6h": 6,       # hours
    "24h": 24,     # hours
    "7d": 168,     # hours (7 * 24)
    "30d": 720,    # hours (30 * 24)
}
