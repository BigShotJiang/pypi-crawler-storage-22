"""
Agent service - backward compatibility re-export.

This module re-exports the AgentService class and related constants
from the new modular structure for backward compatibility with existing imports.

The actual implementation has been refactored into focused sub-services:
- agent_crud_service.py - CRUD operations
- agent_heartbeat_service.py - Heartbeat processing and state management
- agent_commands_service.py - Command issuing and acknowledgment
- agent_metrics_service.py - Metrics queries and rollups
- agent_alerts_service.py - Alert configuration and evaluation
- agent_setup_service.py - Setup tokens and API key creation
- agent_events_service.py - Event logging and queries

See backend.services.agent for the modular implementation.
"""

# Re-export for backward compatibility
from backend.services.agent import AgentService
from backend.services.agent.constants import COMMAND_SIGNING_KEY

__all__ = ["AgentService", "COMMAND_SIGNING_KEY"]
