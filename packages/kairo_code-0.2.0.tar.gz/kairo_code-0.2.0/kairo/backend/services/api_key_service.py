import hashlib
import logging
import uuid
from datetime import datetime, timedelta, UTC

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models.api_key import ApiKey
from backend.models.agent import Agent

logger = logging.getLogger(__name__)


def _generate_raw_key() -> str:
    return f"sk-kairo-{uuid.uuid4().hex}"


class ApiKeyService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_key(
        self, user_id: str, name: str, expires_in_days: int | None = None
    ) -> tuple[ApiKey, str]:
        """Create an API key. Returns (record, raw_key). Raw key shown only once."""
        raw_key = _generate_raw_key()
        prefix = raw_key[:20]
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        expires_at = (
            datetime.now(UTC) + timedelta(days=expires_in_days)
            if expires_in_days
            else None
        )

        api_key = ApiKey(
            user_id=user_id,
            name=name,
            key_prefix=prefix,
            key_hash=key_hash,
            expires_at=expires_at,
        )
        self.db.add(api_key)
        await self.db.commit()
        await self.db.refresh(api_key)
        logger.info("API key created: user=%s name=%s prefix=%s", user_id, name, prefix)
        return api_key, raw_key

    async def list_keys(self, user_id: str) -> list[dict]:
        """List keys with agent names for agent-scoped keys."""
        stmt = (
            select(ApiKey, Agent.name.label("agent_name"))
            .outerjoin(Agent, ApiKey.agent_id == Agent.id)
            .where(ApiKey.user_id == user_id)
            .order_by(ApiKey.created_at.desc())
        )
        result = await self.db.execute(stmt)
        keys = []
        for row in result.all():
            key = row[0]
            agent_name = row[1] if len(row) > 1 else None
            keys.append({
                "id": key.id,
                "name": key.name,
                "key_prefix": key.key_prefix,
                "is_active": key.is_active,
                "last_used_at": key.last_used_at,
                "created_at": key.created_at,
                "expires_at": key.expires_at,
                "key_type": key.key_type,
                "agent_id": key.agent_id,
                "agent_name": agent_name,
            })
        return keys

    async def revoke_key(self, user_id: str, key_id: str) -> bool:
        stmt = select(ApiKey).where(ApiKey.id == key_id, ApiKey.user_id == user_id)
        result = await self.db.execute(stmt)
        api_key = result.scalar_one_or_none()
        if not api_key:
            return False
        api_key.is_active = False
        await self.db.commit()
        logger.info("API key revoked: key=%s user=%s", key_id, user_id)
        return True
