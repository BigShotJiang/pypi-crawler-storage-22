import logging
from datetime import datetime, timezone, timedelta

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.models.api_usage import ApiUsageRecord
from backend.models.user import PlanType, User

logger = logging.getLogger(__name__)

API_PLAN_LIMITS: dict[str, dict[str, int]] = {
    PlanType.FREE.value: {
        "daily": settings.API_DAILY_TOKEN_LIMIT,
        "monthly": settings.API_MONTHLY_TOKEN_LIMIT,
    },
    PlanType.PRO.value: {
        "daily": settings.API_PRO_DAILY_TOKEN_LIMIT,
        "monthly": settings.API_PRO_MONTHLY_TOKEN_LIMIT,
    },
}


def _get_api_limits(plan: str) -> tuple[int, int]:
    limits = API_PLAN_LIMITS.get(plan, API_PLAN_LIMITS[PlanType.FREE.value])
    return limits["daily"], limits["monthly"]


class ApiUsageService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def record(
        self,
        api_key_id: str,
        user_id: str,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        endpoint: str,
        agent_id: str | None = None,
    ) -> ApiUsageRecord:
        record = ApiUsageRecord(
            api_key_id=api_key_id,
            user_id=user_id,
            agent_id=agent_id,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            endpoint=endpoint,
        )
        self.db.add(record)
        await self.db.commit()
        await self.db.refresh(record)
        logger.info(
            "API usage recorded: key=%s user=%s prompt=%d completion=%d",
            api_key_id, user_id, prompt_tokens, completion_tokens,
        )
        return record

    async def get_daily_usage(self, user_id: str) -> int:
        now = datetime.now(timezone.utc)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        stmt = (
            select(
                func.coalesce(
                    func.sum(ApiUsageRecord.prompt_tokens + ApiUsageRecord.completion_tokens), 0
                )
            )
            .where(ApiUsageRecord.user_id == user_id)
            .where(ApiUsageRecord.created_at >= start_of_day)
        )
        result = await self.db.execute(stmt)
        return result.scalar() or 0

    async def get_monthly_usage(self, user_id: str) -> int:
        now = datetime.now(timezone.utc)
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        stmt = (
            select(
                func.coalesce(
                    func.sum(ApiUsageRecord.prompt_tokens + ApiUsageRecord.completion_tokens), 0
                )
            )
            .where(ApiUsageRecord.user_id == user_id)
            .where(ApiUsageRecord.created_at >= start_of_month)
        )
        result = await self.db.execute(stmt)
        return result.scalar() or 0

    async def check_limits(self, user_id: str) -> tuple[bool, str]:
        user = await self.db.get(User, user_id)
        if not user:
            return False, "User not found"

        daily_limit, monthly_limit = _get_api_limits(user.plan)

        daily = await self.get_daily_usage(user_id)
        if daily >= daily_limit:
            return False, "API daily token limit reached."

        monthly = await self.get_monthly_usage(user_id)
        if monthly >= monthly_limit:
            return False, "API monthly token limit reached."

        return True, ""

    async def get_key_usage_summary(self, api_key_id: str, days: int = 30) -> list[dict]:
        start = datetime.now(timezone.utc) - timedelta(days=days)
        stmt = (
            select(
                func.date(ApiUsageRecord.created_at).label("date"),
                func.sum(ApiUsageRecord.prompt_tokens + ApiUsageRecord.completion_tokens).label("total_tokens"),
                func.count().label("request_count"),
            )
            .where(ApiUsageRecord.api_key_id == api_key_id)
            .where(ApiUsageRecord.created_at >= start)
            .group_by(func.date(ApiUsageRecord.created_at))
            .order_by(func.date(ApiUsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        return [
            {"date": str(r.date), "total_tokens": r.total_tokens or 0, "requests": r.request_count}
            for r in result.all()
        ]
