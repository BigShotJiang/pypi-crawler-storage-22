import logging
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.security import hash_password, verify_password
from backend.models.user import User

logger = logging.getLogger(__name__)


class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def register(self, email: str, password: str) -> User | None:
        """Create a new user with a verification token. Returns None if email taken."""
        existing = await self._get_by_email(email)
        if existing:
            return None
        token = secrets.token_urlsafe(32)
        user = User(
            email=email,
            hashed_password=hash_password(password),
            email_verification_token=token,
        )
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        logger.info("Registered user %s (id=%s)", email, user.id)
        return user

    async def authenticate(self, email: str, password: str) -> User | None:
        """Verify credentials. Returns User or None."""
        user = await self._get_by_email(email)
        if not user or not verify_password(password, user.hashed_password):
            return None
        return user

    async def get_user_by_id(self, user_id: str) -> User | None:
        result = await self.db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    async def verify_email(self, token: str) -> User | None:
        """Mark email as verified if token is valid. Returns user or None."""
        result = await self.db.execute(
            select(User).where(User.email_verification_token == token)
        )
        user = result.scalar_one_or_none()
        if not user:
            return None
        user.email_verified = True
        user.email_verification_token = None
        await self.db.commit()
        await self.db.refresh(user)
        logger.info("Email verified for user %s", user.email)
        return user

    async def request_password_reset(self, email: str) -> str | None:
        """Generate a reset token with 1hr expiry. Returns token or None if no user."""
        user = await self._get_by_email(email)
        if not user:
            return None
        token = secrets.token_urlsafe(32)
        user.password_reset_token = token
        user.password_reset_expires = datetime.now(timezone.utc) + timedelta(hours=1)
        await self.db.commit()
        return token

    async def reset_password(self, token: str, new_password: str) -> bool:
        """Reset password using token. Returns True on success."""
        result = await self.db.execute(
            select(User).where(User.password_reset_token == token)
        )
        user = result.scalar_one_or_none()
        if not user:
            return False
        if not user.password_reset_expires or user.password_reset_expires < datetime.now(timezone.utc):
            return False
        user.hashed_password = hash_password(new_password)
        user.password_reset_token = None
        user.password_reset_expires = None
        await self.db.commit()
        logger.info("Password reset for user %s", user.email)
        return True

    async def regenerate_verification_token(self, user_id: str) -> str | None:
        """Generate a new verification token for resending. Returns token or None."""
        user = await self.get_user_by_id(user_id)
        if not user or user.email_verified:
            return None
        token = secrets.token_urlsafe(32)
        user.email_verification_token = token
        await self.db.commit()
        return token

    async def _get_by_email(self, email: str) -> User | None:
        result = await self.db.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()
