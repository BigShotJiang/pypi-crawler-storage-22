import logging

from sqlalchemy import select, func, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models.conversation import Conversation, Message

logger = logging.getLogger(__name__)


class ConversationService:
    def __init__(self, db: AsyncSession, user_id: str | None = None):
        self.db = db
        self.user_id = user_id

    async def create(self, model: str = "nyx", title: str = "New Conversation", project_id: str | None = None) -> Conversation:
        conv = Conversation(model=model, title=title, user_id=self.user_id, project_id=project_id)
        self.db.add(conv)
        await self.db.commit()
        await self.db.refresh(conv)
        return conv

    async def list_all(self, limit: int = 50, offset: int = 0, project_id: str | None = None) -> tuple[list[dict], int]:
        base = select(Conversation).where(Conversation.user_id == self.user_id) if self.user_id else select(Conversation)

        # Count
        count_stmt = select(func.count()).select_from(base.subquery())
        total = (await self.db.execute(count_stmt)).scalar() or 0

        # Data
        stmt = (
            select(
                Conversation.id,
                Conversation.title,
                Conversation.model,
                Conversation.updated_at,
                Conversation.project_id,
                func.count(Message.id).label("message_count"),
            )
            .outerjoin(Message)
            .group_by(Conversation.id)
            .order_by(Conversation.updated_at.desc())
            .limit(limit)
            .offset(offset)
        )
        if self.user_id:
            stmt = stmt.where(Conversation.user_id == self.user_id)
        if project_id is not None:
            stmt = stmt.where(Conversation.project_id == project_id)

        result = await self.db.execute(stmt)
        rows = result.all()
        items = [
            {
                "id": r.id,
                "title": r.title,
                "model": r.model,
                "updated_at": r.updated_at,
                "message_count": r.message_count,
                "project_id": r.project_id,
            }
            for r in rows
        ]
        return items, total

    async def search(self, query: str, limit: int = 50, offset: int = 0) -> tuple[list[dict], int]:
        """Search conversations by title or message content."""
        pattern = f"%{query}%"

        # Find matching conversation IDs
        matching_ids_stmt = (
            select(Conversation.id)
            .outerjoin(Message)
            .where(
                (Conversation.title.ilike(pattern)) | (Message.content.ilike(pattern))
            )
            .group_by(Conversation.id)
        )
        if self.user_id:
            matching_ids_stmt = matching_ids_stmt.where(Conversation.user_id == self.user_id)

        # Count
        count_stmt = select(func.count()).select_from(matching_ids_stmt.subquery())
        total = (await self.db.execute(count_stmt)).scalar() or 0

        # Data
        stmt = (
            select(
                Conversation.id,
                Conversation.title,
                Conversation.model,
                Conversation.updated_at,
                Conversation.project_id,
                func.count(Message.id).label("message_count"),
            )
            .outerjoin(Message)
            .where(Conversation.id.in_(matching_ids_stmt))
            .group_by(Conversation.id)
            .order_by(Conversation.updated_at.desc())
            .limit(limit)
            .offset(offset)
        )
        if self.user_id:
            stmt = stmt.where(Conversation.user_id == self.user_id)

        result = await self.db.execute(stmt)
        rows = result.all()
        items = [
            {
                "id": r.id,
                "title": r.title,
                "model": r.model,
                "updated_at": r.updated_at,
                "message_count": r.message_count,
                "project_id": r.project_id,
            }
            for r in rows
        ]
        return items, total

    async def get(self, conversation_id: str) -> Conversation | None:
        stmt = (
            select(Conversation)
            .options(selectinload(Conversation.messages), selectinload(Conversation.project))
            .where(Conversation.id == conversation_id)
        )
        if self.user_id:
            stmt = stmt.where(Conversation.user_id == self.user_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def get_fresh(self, conversation_id: str) -> Conversation | None:
        """Get conversation with fresh data, bypassing the identity map cache."""
        stmt = (
            select(Conversation)
            .options(selectinload(Conversation.messages), selectinload(Conversation.project))
            .where(Conversation.id == conversation_id)
            .execution_options(populate_existing=True)
        )
        if self.user_id:
            stmt = stmt.where(Conversation.user_id == self.user_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def delete(self, conversation_id: str) -> bool:
        conv = await self.get(conversation_id)
        if not conv:
            return False
        await self.db.delete(conv)
        await self.db.commit()
        return True

    async def rename(self, conversation_id: str, title: str) -> Conversation | None:
        conv = await self.get(conversation_id)
        if not conv:
            return None
        conv.title = title
        await self.db.commit()
        await self.db.refresh(conv)
        return conv

    async def add_message(self, conversation_id: str, role: str, content: str, image_url: str | None = None) -> Message:
        msg = Message(conversation_id=conversation_id, role=role, content=content, image_url=image_url)
        self.db.add(msg)
        await self.db.commit()
        await self.db.refresh(msg)
        return msg

    async def get_message(self, message_id: str) -> Message | None:
        stmt = select(Message).where(Message.id == message_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def edit_message(self, message_id: str, new_content: str) -> Message | None:
        """Edit a message and delete all subsequent messages in the conversation."""
        msg = await self.get_message(message_id)
        if not msg:
            return None

        # Verify user owns this conversation
        conv = await self.get(msg.conversation_id)
        if not conv:
            return None

        # Delete all messages after this one
        await self.db.execute(
            delete(Message).where(
                Message.conversation_id == msg.conversation_id,
                Message.created_at > msg.created_at,
            )
        )

        # Update the message content
        msg.content = new_content
        await self.db.commit()
        await self.db.refresh(msg)
        return msg

    async def search_messages(self, query: str, limit: int = 20, offset: int = 0) -> list[dict]:
        """Search message content and return snippets with conversation context."""
        pattern = f"%{query}%"
        stmt = (
            select(
                Message.id,
                Message.role,
                Message.content,
                Message.created_at,
                Conversation.id.label("conversation_id"),
                Conversation.title.label("conversation_title"),
            )
            .join(Conversation, Message.conversation_id == Conversation.id)
            .where(Message.content.ilike(pattern))
            .order_by(Message.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        if self.user_id:
            stmt = stmt.where(Conversation.user_id == self.user_id)

        result = await self.db.execute(stmt)
        rows = result.all()
        items = []
        for r in rows:
            # Build snippet: ~100 chars around first match
            content = r.content
            lower_content = content.lower()
            idx = lower_content.find(query.lower())
            if idx >= 0:
                start = max(0, idx - 50)
                end = min(len(content), idx + len(query) + 50)
                snippet = ("..." if start > 0 else "") + content[start:end] + ("..." if end < len(content) else "")
            else:
                snippet = content[:100] + ("..." if len(content) > 100 else "")
            items.append({
                "message_id": r.id,
                "role": r.role,
                "snippet": snippet,
                "created_at": r.created_at,
                "conversation_id": r.conversation_id,
                "conversation_title": r.conversation_title,
            })
        return items

    async def delete_last_assistant_message(self, conversation_id: str) -> bool:
        """Delete the last assistant message in a conversation for regeneration."""
        conv = await self.get(conversation_id)
        if not conv or not conv.messages:
            return False

        # Find last assistant message
        messages = sorted(conv.messages, key=lambda m: m.created_at)
        last_assistant = None
        for m in reversed(messages):
            if m.role == "assistant":
                last_assistant = m
                break

        if not last_assistant:
            return False

        await self.db.delete(last_assistant)
        await self.db.commit()
        return True
