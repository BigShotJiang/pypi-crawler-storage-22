"""Deep search service.

Unlike web_search which only returns DuckDuckGo snippets, deep_search:
1. Searches the web for the query
2. Fetches the top 2 result pages
3. Extracts meaningful text content
4. Returns the actual page content to the model
"""

import logging
import re
from html import unescape
from urllib.parse import unquote

import httpx

logger = logging.getLogger(__name__)

_STRIP_TAGS = re.compile(
    r"<(script|style|nav|footer|header|noscript|iframe|svg|aside)[^>]*>.*?</\1>",
    re.DOTALL | re.IGNORECASE,
)
_HTML_TAG = re.compile(r"<[^>]+>")
_MULTI_NEWLINE = re.compile(r"\n{3,}")
_MULTI_SPACE = re.compile(r"[ \t]{2,}")


def _html_to_text(html: str) -> str:
    """Extract readable text from HTML, stripping scripts/styles/nav."""
    text = _STRIP_TAGS.sub("", html)
    text = re.sub(r"<(br|hr|/p|/div|/li|/tr|/h[1-6])[^>]*>", "\n", text, flags=re.IGNORECASE)
    text = _HTML_TAG.sub("", text)
    text = unescape(text)
    text = _MULTI_SPACE.sub(" ", text)
    text = _MULTI_NEWLINE.sub("\n\n", text)
    return text.strip()


def _extract_main_content(text: str, max_chars: int = 3000) -> str:
    """Extract the most informative portion of page text."""
    lines = text.split("\n")
    content_lines = []
    char_count = 0
    for line in lines:
        line = line.strip()
        if len(line) < 20:
            if not line and content_lines and content_lines[-1]:
                content_lines.append("")
            continue
        content_lines.append(line)
        char_count += len(line)
        if char_count >= max_chars:
            break
    return "\n".join(content_lines)


async def _fetch_page(url: str, client: httpx.AsyncClient) -> str | None:
    """Fetch a page and return extracted text content."""
    try:
        resp = await client.get(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html,application/xhtml+xml",
            },
            follow_redirects=True,
        )
        resp.raise_for_status()
        content_type = resp.headers.get("content-type", "")
        if "text/html" not in content_type and "application/xhtml" not in content_type:
            return None
        html = resp.text
        text = _html_to_text(html)
        return _extract_main_content(text)
    except Exception as e:
        logger.warning("Failed to fetch %s: %s", url, e)
        return None


async def _search_ddg(query: str, client: httpx.AsyncClient) -> list[dict]:
    """Search DuckDuckGo and return results with URLs."""
    results = []
    try:
        resp = await client.post(
            "https://html.duckduckgo.com/html/",
            data={"q": query, "b": ""},
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            },
        )
        resp.raise_for_status()
        html = resp.text

        link_pattern = re.compile(
            r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_pattern = re.compile(
            r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
            re.DOTALL,
        )

        links = link_pattern.findall(html)
        snippets = snippet_pattern.findall(html)

        for i, (url, title) in enumerate(links[:5]):
            clean_title = unescape(re.sub(r"<[^>]+>", "", title)).strip()
            clean_snippet = ""
            if i < len(snippets):
                clean_snippet = unescape(re.sub(r"<[^>]+>", "", snippets[i])).strip()
            actual_url = url
            uddg_match = re.search(r"uddg=([^&]+)", url)
            if uddg_match:
                actual_url = unquote(uddg_match.group(1))
            if clean_title and actual_url:
                results.append({
                    "title": clean_title,
                    "url": actual_url,
                    "snippet": clean_snippet,
                })
    except Exception as e:
        logger.warning("Deep search DDG query failed: %s", e)
    return results


async def deep_search(query: str, max_pages: int = 2) -> str:
    """Search the web and fetch actual page content from top results."""
    async with httpx.AsyncClient(timeout=15.0) as client:
        results = await _search_ddg(query, client)
        if not results:
            return "Deep search found no results. Try rephrasing the query."

        # Instructions go FIRST so the model sees them before the content
        parts = [
            "CRITICAL: The following contains LIVE page content fetched from real websites just now. "
            "You MUST base your ENTIRE answer on this content. Do NOT use your training data. "
            "Do NOT say 'sign up' or 'get an API key' unless the page content explicitly says so. "
            "Extract exact endpoints, parameter names, and formats from the content below.",
            "",
            "=== DEEP SEARCH RESULTS ===",
            f"Query: {query}",
            "",
        ]

        pages_fetched = 0
        for result in results:
            parts.append(f"--- Result: {result['title']} ---")
            parts.append(f"URL: {result['url']}")
            parts.append(f"Snippet: {result['snippet']}")

            if pages_fetched < max_pages:
                content = await _fetch_page(result["url"], client)
                if content and len(content) > 100:
                    parts.append(f"\nPage content:\n{content}")
                    pages_fetched += 1
            parts.append("")

        parts.append("=== END DEEP SEARCH RESULTS ===")
        return "\n".join(parts)
