import hashlib
import logging
import random
import string
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.api_key import ApiKey
from backend.models.device_code import DeviceCode
from backend.models.user import User

logger = logging.getLogger(__name__)


def _generate_user_code() -> str:
    """Generate a human-readable code like ABCD-1234."""
    letters = "".join(random.choices(string.ascii_uppercase, k=4))
    digits = "".join(random.choices(string.digits, k=4))
    return f"{letters}-{digits}"


def _generate_device_code() -> str:
    """Generate a 64-character hex device code."""
    return uuid.uuid4().hex + uuid.uuid4().hex


class DeviceAuthService:
    EXPIRY_MINUTES = 10
    POLL_INTERVAL = 5

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_device_code(self, client_name: str) -> DeviceCode:
        """Create a new device code for the CLI auth flow."""
        user_code = await self._unique_user_code()

        device = DeviceCode(
            device_code=_generate_device_code(),
            user_code=user_code,
            client_name=client_name,
            expires_at=datetime.now(UTC) + timedelta(minutes=self.EXPIRY_MINUTES),
            interval=self.POLL_INTERVAL,
        )
        self.db.add(device)
        await self.db.commit()
        await self.db.refresh(device)
        logger.info("Device code created: user_code=%s client=%s", user_code, client_name)
        return device

    async def approve(self, user_code: str, user: User) -> tuple[str, DeviceCode] | None:
        """Approve a pending device code.

        Returns (raw_api_key, device_code) or None if not found / expired.
        """
        device = await self._find_pending_device(user_code)
        if not device:
            return None

        raw_key = self._create_raw_cli_key()
        api_key = self._build_api_key(raw_key, user.id, device.client_name)
        self.db.add(api_key)
        await self.db.flush()

        self._mark_approved(device, user.id, api_key.id, raw_key)
        await self.db.commit()

        logger.info("Device code approved: user_code=%s user=%s", user_code, user.id)
        return raw_key, device

    async def poll_token(
        self, device_code: str
    ) -> tuple[str, dict | None]:
        """Poll for token status.

        Returns (status, user_info_or_none).
        status: authorization_pending | expired_token | access_denied | approved
        user_info: {"raw_key": ..., "plan": ..., "email": ...} when approved.
        """
        device = await self._find_device_by_code(device_code)
        if not device:
            return "expired_token", None

        if self._is_expired_pending(device):
            device.status = "expired"
            await self.db.commit()
            return "expired_token", None

        if device.status in ("denied", "expired"):
            status = "access_denied" if device.status == "denied" else "expired_token"
            return status, None

        if device.status == "pending":
            return "authorization_pending", None

        if device.status == "approved" and device.cli_token:
            return await self._consume_approved_token(device)

        return "authorization_pending", None

    async def cleanup_expired(self) -> int:
        """Delete device codes older than 1 hour."""
        cutoff = datetime.now(UTC) - timedelta(hours=1)
        stmt = delete(DeviceCode).where(DeviceCode.created_at < cutoff)
        result = await self.db.execute(stmt)
        await self.db.commit()
        deleted = result.rowcount or 0
        if deleted:
            logger.info("Cleaned up %d expired device codes", deleted)
        return deleted

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _unique_user_code(self) -> str:
        """Generate a user code that does not collide with pending codes."""
        for _ in range(5):
            user_code = _generate_user_code()
            stmt = select(DeviceCode).where(
                DeviceCode.user_code == user_code,
                DeviceCode.status == "pending",
            )
            result = await self.db.execute(stmt)
            if not result.scalar_one_or_none():
                return user_code
        # Extremely unlikely fallback
        return _generate_user_code()

    async def _find_pending_device(self, user_code: str) -> DeviceCode | None:
        stmt = select(DeviceCode).where(
            DeviceCode.user_code == user_code,
            DeviceCode.status == "pending",
            DeviceCode.expires_at > datetime.now(UTC),
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def _find_device_by_code(self, device_code: str) -> DeviceCode | None:
        stmt = select(DeviceCode).where(DeviceCode.device_code == device_code)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    def _create_raw_cli_key() -> str:
        return f"sk-kairo-cli-{uuid.uuid4().hex}"

    @staticmethod
    def _build_api_key(raw_key: str, user_id: str, client_name: str | None) -> ApiKey:
        prefix = raw_key[:24]
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        return ApiKey(
            user_id=user_id,
            name=f"Kairo Code CLI ({client_name or 'cli'})",
            key_prefix=prefix,
            key_hash=key_hash,
            key_type="cli",
        )

    @staticmethod
    def _mark_approved(
        device: DeviceCode, user_id: str, api_key_id: str, raw_key: str
    ) -> None:
        device.status = "approved"
        device.user_id = user_id
        device.cli_api_key_id = api_key_id
        device.cli_token = raw_key
        device.approved_at = datetime.now(UTC)

    @staticmethod
    def _is_expired_pending(device: DeviceCode) -> bool:
        return device.expires_at < datetime.now(UTC) and device.status == "pending"

    async def _consume_approved_token(
        self, device: DeviceCode
    ) -> tuple[str, dict | None]:
        """Return the token and clear it (single-use retrieval)."""
        raw_key = device.cli_token
        device.cli_token = None  # single-use: clear after first poll
        await self.db.commit()

        user = await self.db.get(User, device.user_id)
        if not user:
            return "access_denied", None

        return "approved", {
            "raw_key": raw_key,
            "plan": user.plan,
            "email": user.email,
        }
