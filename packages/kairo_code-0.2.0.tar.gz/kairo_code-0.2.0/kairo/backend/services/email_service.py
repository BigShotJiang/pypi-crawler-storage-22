"""
Email service for Kairo transactional and notification emails.

Handles all outbound email including:
- Transactional (verification, password reset, welcome)
- Billing (subscription confirmations, payment failures)
- Alerts (agent offline, usage warnings)
- Sales (enterprise inquiries)
- Security (API key creation, new login alerts)
"""

import asyncio
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape

from backend.config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# From-address aliases (configured in Google Workspace)
# ---------------------------------------------------------------------------
DOMAIN = "kaironlabs.io"
FROM_NOREPLY = f"Kairo <noreply@{DOMAIN}>"
FROM_BILLING = f"Kairo Billing <billing@{DOMAIN}>"
FROM_ALERTS = f"Kairo Alerts <alerts@{DOMAIN}>"
FROM_SALES = f"Kairon Labs <sales@{DOMAIN}>"
FROM_SECURITY = f"Kairo Security <security@{DOMAIN}>"

SITE_URL = "https://kaironlabs.io"

# ---------------------------------------------------------------------------
# Brand colors (matching kaironlabs.io)
# ---------------------------------------------------------------------------
BRAND_ACCENT = "#f97066"       # Coral/salmon - primary brand color
BRAND_ACCENT_HOVER = "#e85d4a" # Darker coral for dark mode
BRAND_BG = "#0a0a0a"           # Dark background
BRAND_CARD_BG = "#141414"      # Card background
BRAND_BORDER = "#262626"       # Border color
BRAND_TEXT = "#fafafa"         # Light text
BRAND_TEXT_MUTED = "#a3a3a3"   # Muted text


# ---------------------------------------------------------------------------
# Template helpers
# ---------------------------------------------------------------------------

def _base_html(body: str) -> str:
    """
    Branded email template matching kaironlabs.io dark theme.
    - Dark background with light text
    - Coral accent color (#f97066)
    - Professional footer with compliance links
    """
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="color-scheme" content="dark">
  <title>Kairo</title>
</head>
<body style="margin:0;padding:0;background-color:{BRAND_BG};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:{BRAND_BG};">
    <tr>
      <td align="center" style="padding:40px 20px;">
        <!-- Main card -->
        <table role="presentation" width="560" cellpadding="0" cellspacing="0" border="0"
               style="max-width:560px;width:100%;background-color:{BRAND_CARD_BG};border-radius:12px;border:1px solid {BRAND_BORDER};">

          <!-- Header with logo -->
          <tr>
            <td style="padding:32px 32px 24px;">
              <span style="font-size:28px;font-weight:800;color:{BRAND_ACCENT};letter-spacing:-0.5px;">KAIRO</span>
            </td>
          </tr>

          <!-- Body content -->
          <tr>
            <td style="padding:0 32px 32px;color:{BRAND_TEXT};font-size:15px;line-height:1.6;">
              {body}
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:24px 32px;border-top:1px solid {BRAND_BORDER};">
              <p style="margin:0 0 8px;font-size:12px;color:{BRAND_TEXT_MUTED};">
                &copy; Kairon Labs &middot;
                <a href="{SITE_URL}" style="color:{BRAND_TEXT_MUTED};text-decoration:underline;">kaironlabs.io</a>
              </p>
              <p style="margin:0;font-size:12px;color:{BRAND_TEXT_MUTED};">
                <a href="{SITE_URL}/settings/notifications" style="color:{BRAND_TEXT_MUTED};text-decoration:underline;">Email preferences</a>
                &middot;
                <a href="{SITE_URL}/settings/notifications" style="color:{BRAND_TEXT_MUTED};text-decoration:underline;">Unsubscribe</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>'''


def _btn(url: str, label: str) -> str:
    """Branded button with coral accent color, Outlook-compatible."""
    return f'''<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0;">
  <tr>
    <td style="background:{BRAND_ACCENT};border-radius:8px;">
      <a href="{url}" target="_blank"
         style="display:inline-block;padding:14px 32px;background:{BRAND_ACCENT};color:#ffffff;
                text-decoration:none;border-radius:8px;font-weight:600;font-size:15px;text-align:center;">
        {label}
      </a>
    </td>
  </tr>
</table>'''


def _secondary_btn(url: str, label: str) -> str:
    """Secondary outlined button."""
    return f'''<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:16px 0;">
  <tr>
    <td style="border:1px solid {BRAND_BORDER};border-radius:8px;">
      <a href="{url}" target="_blank"
         style="display:inline-block;padding:12px 24px;color:{BRAND_TEXT};
                text-decoration:none;border-radius:8px;font-weight:500;font-size:14px;text-align:center;">
        {label}
      </a>
    </td>
  </tr>
</table>'''


def _link(url: str, text: str) -> str:
    """Inline link with brand color."""
    return f'<a href="{url}" style="color:{BRAND_ACCENT};text-decoration:underline;">{text}</a>'


def _muted(text: str) -> str:
    """Muted text styling."""
    return f'<p style="font-size:13px;color:{BRAND_TEXT_MUTED};margin:16px 0;">{text}</p>'


def _heading(text: str) -> str:
    """Heading with brand styling."""
    return f'<h2 style="margin:0 0 16px;font-size:24px;font-weight:700;color:{BRAND_TEXT};">{text}</h2>'


def _code(text: str) -> str:
    """Inline code styling."""
    return f'<code style="background:{BRAND_BG};padding:3px 8px;border-radius:4px;font-family:monospace;font-size:13px;color:{BRAND_ACCENT};">{text}</code>'


def _product_item(name: str, desc: str) -> str:
    """Product list item for welcome email."""
    return f'''<tr>
  <td style="padding:12px 0;border-bottom:1px solid {BRAND_BORDER};">
    <strong style="color:{BRAND_TEXT};font-size:15px;">{name}</strong>
    <p style="margin:4px 0 0;color:{BRAND_TEXT_MUTED};font-size:14px;">{desc}</p>
  </td>
</tr>'''


# ---------------------------------------------------------------------------
# Email Service
# ---------------------------------------------------------------------------

class EmailService:
    """Service for sending transactional and notification emails."""

    # -----------------------------------------------------------------------
    # Transactional (noreply@)
    # -----------------------------------------------------------------------

    def send_verification_email(self, to: str, token: str) -> None:
        """Send email verification link. Expires in 24 hours."""
        link = f"{settings.APP_BASE_URL}/verify-email?token={token}"
        html = _base_html(
            f'{_heading("Verify your email")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">Thanks for signing up for Kairo. Click below to verify your email address.</p>'
            f'{_muted("This link expires in 24 hours.")}'
            f'{_btn(link, "Verify Email")}'
            f'{_muted(f"Or copy this link: {_link(link, link)}")}'
            f'{_muted("If you didn\'t create a Kairo account, you can ignore this email.")}'
        )
        self._send(to, "Verify your Kairo email", html, FROM_NOREPLY)

    def send_password_reset_email(self, to: str, token: str) -> None:
        """Send password reset link. Expires in 1 hour."""
        link = f"{settings.APP_BASE_URL}/reset-password?token={token}"
        html = _base_html(
            f'{_heading("Reset your password")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">We received a request to reset your password.</p>'
            f'{_muted("This link expires in 1 hour.")}'
            f'{_btn(link, "Reset Password")}'
            f'{_muted(f"Or copy this link: {_link(link, link)}")}'
            f'{_muted("If you didn\'t request this, you can safely ignore this email.")}'
        )
        self._send(to, "Reset your Kairo password", html, FROM_NOREPLY)

    def send_welcome_email(self, to: str) -> None:
        """Welcome email after verification with all products."""
        html = _base_html(
            f'{_heading("Welcome to Kairo")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 24px;">Your email is verified and your account is ready. Here\'s what you can do with Kairo:</p>'

            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:24px;">'
            f'{_product_item("Kairo Desktop", "AI workspace with multi-provider support. Bring your own API keys.")}'
            f'{_product_item("Kairo Web", "Chat with Nyx and other models instantly in your browser.")}'
            f'{_product_item("Kairo Code", "AI coding assistant in your terminal. Context-aware generation.")}'
            f'{_product_item("Kairo Agents", "Deploy autonomous agents on your own infrastructure.")}'
            f'{_product_item("Kairo API", "OpenAI-compatible endpoint for programmatic access.")}'
            f'<tr><td style="padding:12px 0;">'
            f'<strong style="color:{BRAND_TEXT};font-size:15px;">Nyx</strong>'
            f'<p style="margin:4px 0 0;color:{BRAND_TEXT_MUTED};font-size:14px;">Our flagship model, optimized for code and reasoning.</p>'
            f'</td></tr>'
            f'</table>'

            f'{_btn(settings.APP_BASE_URL, "Get Started")}'
        )
        self._send(to, "Welcome to Kairo", html, FROM_NOREPLY)

    def send_usage_limit_warning(self, to: str, percent: int, limit_type: str, current: int, limit: int) -> None:
        """Usage limit warning at 80% and 100% thresholds."""
        if percent >= 100:
            urgency = "at"
            urgency_text = "You've reached your limit. Requests will be paused until it resets."
        elif percent >= 90:
            urgency = "nearly at"
            urgency_text = "You're about to hit your limit."
        else:
            urgency = "approaching"
            urgency_text = "Consider upgrading for higher limits."

        html = _base_html(
            f'{_heading(f"You\'re {urgency} your {limit_type} limit")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'You\'ve used <strong style="color:{BRAND_ACCENT};">{percent}%</strong> of your {limit_type} token allowance.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT_MUTED};font-size:14px;margin:0 0 16px;">'
            f'{current:,} / {limit:,} tokens used'
            f'</p>'
            f'{_muted(urgency_text)}'
            f'{_btn(SITE_URL + "/pricing", "View Plans")}'
        )
        self._send(to, f"Kairo — {percent}% of {limit_type} limit used", html, FROM_NOREPLY)

    # -----------------------------------------------------------------------
    # Billing (billing@)
    # -----------------------------------------------------------------------

    def send_subscription_confirmed(self, to: str, plan: str) -> None:
        """Subscription confirmation email."""
        html = _base_html(
            f'{_heading("Subscription confirmed")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'You\'re now on the <strong style="color:{BRAND_ACCENT};">Kairo {plan}</strong> plan.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">Your new limits are active immediately.</p>'
            f'{_muted("A receipt has been sent to this email. Manage your subscription anytime from account settings.")}'
            f'{_btn(settings.APP_BASE_URL + "/settings", "Account Settings")}'
        )
        self._send(to, f"Kairo {plan} — subscription confirmed", html, FROM_BILLING)

    def send_subscription_cancelled(self, to: str) -> None:
        """Subscription cancellation confirmation."""
        html = _base_html(
            f'{_heading("Subscription cancelled")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'Your Kairo subscription has been cancelled as requested.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">'
            f'You\'ll continue to have access to your current plan until the end of your billing period. '
            f'After that, your account will revert to the Free plan.'
            f'</p>'
            f'{_muted("Your conversations and data will remain intact.")}'
            f'{_muted("Changed your mind?")}'
            f'{_secondary_btn(SITE_URL + "/pricing", "View Plans")}'
        )
        self._send(to, "Kairo — subscription cancelled", html, FROM_BILLING)

    def send_payment_failed(self, to: str) -> None:
        """Payment failure notification with 7-day deadline."""
        html = _base_html(
            f'{_heading("Payment failed")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'We couldn\'t process your latest payment for Kairo.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">'
            f'Please update your payment method within <strong style="color:{BRAND_ACCENT};">7 days</strong> to keep your subscription active.'
            f'</p>'
            f'{_btn(settings.APP_BASE_URL + "/settings/billing", "Update Payment Method")}'
            f'{_muted("We\'ll retry automatically. If not updated, your account will be downgraded to Free.")}'
        )
        self._send(to, "Kairo — payment failed", html, FROM_BILLING)

    # -----------------------------------------------------------------------
    # Alerts (alerts@)
    # -----------------------------------------------------------------------

    def send_agent_offline_alert(self, to: str, agent_name: str, agent_id: str, offline_since: str = None) -> None:
        """Agent offline notification."""
        time_info = f'<p style="color:{BRAND_TEXT_MUTED};font-size:13px;margin:8px 0;">Last seen: {offline_since}</p>' if offline_since else ''

        html = _base_html(
            f'{_heading("Agent offline")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 8px;">'
            f'Your agent <strong>{escape(agent_name)}</strong> ({_code(agent_id[:8] + "...")}) '
            f'has stopped responding and was marked offline.'
            f'</p>'
            f'{time_info}'
            f'<p style="color:{BRAND_TEXT};margin:16px 0 8px;">Please verify:</p>'
            f'<ul style="color:{BRAND_TEXT_MUTED};margin:0;padding-left:20px;">'
            f'<li>The agent process is running</li>'
            f'<li>The host can reach the Kairo API</li>'
            f'</ul>'
            f'{_btn(settings.APP_BASE_URL + "/agents", "View Agents")}'
        )
        self._send(to, f'Kairo — agent "{agent_name}" went offline', html, FROM_ALERTS)

    async def send_agent_offline_alert_async(self, to: str, agent_name: str, agent_id: str, offline_since: str = None) -> None:
        """Async version that doesn't block the event loop."""
        await asyncio.to_thread(self.send_agent_offline_alert, to, agent_name, agent_id, offline_since)

    # -----------------------------------------------------------------------
    # Sales (sales@)
    # -----------------------------------------------------------------------

    def send_enterprise_inquiry_confirmation(self, to: str, name: str) -> None:
        """Confirmation email to enterprise inquiry sender."""
        html = _base_html(
            f'{_heading("Thanks for reaching out")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">Hi {escape(name)},</p>'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'We received your inquiry about Kairo Enterprise. Our team will review your request '
            f'and respond within 1 business day.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT};margin:0 0 24px;">'
            f'In the meantime, explore our products at {_link(SITE_URL, "kaironlabs.io")}.'
            f'</p>'
            f'<p style="color:{BRAND_TEXT_MUTED};margin:24px 0 0;">— The Kairon Labs Team</p>'
        )
        self._send(to, "Kairon Labs — we received your inquiry", html, FROM_SALES)

    def send_enterprise_inquiry_internal(self, name: str, email: str, company: str, message: str) -> None:
        """Internal notification for enterprise inquiries (sent to sales@)."""
        html = _base_html(
            f'{_heading("New Enterprise Inquiry")}'
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">'
            f'<tr><td style="padding:8px 0;color:{BRAND_TEXT_MUTED};width:80px;">Name</td>'
            f'<td style="padding:8px 0;color:{BRAND_TEXT};">{escape(name)}</td></tr>'
            f'<tr><td style="padding:8px 0;color:{BRAND_TEXT_MUTED};">Email</td>'
            f'<td style="padding:8px 0;">{_link("mailto:" + escape(email), escape(email))}</td></tr>'
            f'<tr><td style="padding:8px 0;color:{BRAND_TEXT_MUTED};">Company</td>'
            f'<td style="padding:8px 0;color:{BRAND_TEXT};">{escape(company) or "—"}</td></tr>'
            f'</table>'
            f'<p style="color:{BRAND_TEXT_MUTED};margin:24px 0 8px;font-size:13px;">MESSAGE</p>'
            f'<div style="background:{BRAND_BG};padding:16px;border-radius:8px;border:1px solid {BRAND_BORDER};">'
            f'<p style="color:{BRAND_TEXT};margin:0;white-space:pre-wrap;">{escape(message)}</p>'
            f'</div>'
        )
        self._send(f"sales@{DOMAIN}", f"Enterprise inquiry from {escape(name)}", html, FROM_SALES)

    # -----------------------------------------------------------------------
    # Security (security@)
    # -----------------------------------------------------------------------

    def send_api_key_created(self, to: str, key_name: str, key_prefix: str) -> None:
        """Security notification when an API key is created."""
        html = _base_html(
            f'{_heading("New API key created")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'A new API key was created on your Kairo account.'
            f'</p>'
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="background:{BRAND_BG};padding:16px;border-radius:8px;border:1px solid {BRAND_BORDER};margin:16px 0;">'
            f'<tr><td style="padding:4px 0;color:{BRAND_TEXT_MUTED};width:60px;">Name</td>'
            f'<td style="padding:4px 0;color:{BRAND_TEXT};">{escape(key_name)}</td></tr>'
            f'<tr><td style="padding:4px 0;color:{BRAND_TEXT_MUTED};">Key</td>'
            f'<td style="padding:4px 0;">{_code(key_prefix + "...")}</td></tr>'
            f'</table>'
            f'{_muted("If you didn\'t create this key, please revoke it immediately and change your password.")}'
            f'{_btn(settings.APP_BASE_URL + "/settings", "Manage API Keys")}'
        )
        self._send(to, "Kairo — new API key created", html, FROM_SECURITY)

    def send_new_login_alert(self, to: str, device: str, location: str, time: str) -> None:
        """Security alert for login from a new device."""
        html = _base_html(
            f'{_heading("New login detected")}'
            f'<p style="color:{BRAND_TEXT};margin:0 0 16px;">'
            f'Your Kairo account was accessed from a new device.'
            f'</p>'
            f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="background:{BRAND_BG};padding:16px;border-radius:8px;border:1px solid {BRAND_BORDER};margin:16px 0;">'
            f'<tr><td style="padding:4px 0;color:{BRAND_TEXT_MUTED};width:80px;">Device</td>'
            f'<td style="padding:4px 0;color:{BRAND_TEXT};">{escape(device)}</td></tr>'
            f'<tr><td style="padding:4px 0;color:{BRAND_TEXT_MUTED};">Location</td>'
            f'<td style="padding:4px 0;color:{BRAND_TEXT};">{escape(location)}</td></tr>'
            f'<tr><td style="padding:4px 0;color:{BRAND_TEXT_MUTED};">Time</td>'
            f'<td style="padding:4px 0;color:{BRAND_TEXT};">{escape(time)}</td></tr>'
            f'</table>'
            f'{_muted("If this was you, no action is needed.")}'
            f'{_muted("If you don\'t recognize this login, secure your account immediately.")}'
            f'{_btn(settings.APP_BASE_URL + "/settings", "Review Account Security")}'
        )
        self._send(to, "Kairo — new login from new device", html, FROM_SECURITY)

    # -----------------------------------------------------------------------
    # Core send methods
    # -----------------------------------------------------------------------

    def _send(self, to: str, subject: str, html_body: str, from_header: str = None) -> None:
        """Synchronous email send."""
        if not settings.SMTP_USERNAME:
            logger.warning("SMTP not configured, skipping email to %s", to)
            return

        if from_header is None:
            from_header = FROM_NOREPLY

        # Extract bare email from "Name <email>" format
        if "<" in from_header:
            from_email = from_header.split("<")[1].rstrip(">")
        else:
            from_email = from_header

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = from_header
        msg["To"] = to
        msg["Reply-To"] = f"support@{DOMAIN}"
        msg.attach(MIMEText(html_body, "html"))

        try:
            with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
                server.starttls()
                server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
                server.sendmail(from_email, to, msg.as_string())
            logger.info("Email sent to %s: %s", to, subject)
        except Exception:
            logger.exception("Failed to send email to %s", to)
            raise

    async def _send_async(self, to: str, subject: str, html_body: str, from_header: str = None) -> None:
        """Async email send using thread pool."""
        await asyncio.to_thread(self._send, to, subject, html_body, from_header)
