"""Dynamic few-shot example injection for small models.

Provides relevant examples based on query type to improve response
quality for 14B parameter models like Nyx Lite.
"""

import logging

logger = logging.getLogger(__name__)

# Code examples for different languages/contexts
_PYTHON_CODE_EXAMPLE = """
<example>
User: Write a function to validate email addresses
Assistant: Here's a function to validate email addresses:

```python
import re

def validate_email(email: str) -> bool:
    \"\"\"Validate email address format.\"\"\"
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

# Usage
print(validate_email("test@example.com"))  # True
print(validate_email("invalid"))           # False
```

The regex checks for: local part + @ + domain + TLD (2+ chars).
</example>
"""

_JAVASCRIPT_CODE_EXAMPLE = """
<example>
User: Create a debounce function in JavaScript
Assistant: Here's a debounce function:

```javascript
function debounce(func, delay) {
    let timeoutId;
    return function(...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

// Usage
const debouncedSearch = debounce((query) => {
    console.log('Searching:', query);
}, 300);
```

This delays execution until `delay` ms after the last call.
</example>
"""

_API_USAGE_EXAMPLE = """
<example>
User: How do I fetch data from an API in Python?
Assistant: [Uses deep_search to verify API documentation]

Here's how to fetch data from an API:

```python
import requests

response = requests.get(
    "https://api.example.com/data",
    headers={"Authorization": "Bearer YOUR_TOKEN"},
    params={"limit": 10}
)

if response.status_code == 200:
    data = response.json()
    print(data)
else:
    print(f"Error: {response.status_code}")
```

Always check the status code before parsing the response.
</example>
"""

_DEBUGGING_EXAMPLE = """
<example>
User: I get TypeError: 'NoneType' object is not subscriptable
Assistant: This error occurs when you try to access an index or key on a `None` value.

**Common causes:**
1. Function returning `None` instead of expected value
2. Dictionary key doesn't exist (`.get()` returns `None`)
3. API returning empty response

**Fix:** Add None checks:

```python
result = get_data()
if result is not None:
    value = result['key']
else:
    value = default_value

# Or use .get() with default:
value = data.get('key', default_value)
```
</example>
"""

_FACTUAL_EXAMPLE = """
<example>
User: What is the difference between REST and GraphQL?
Assistant: **REST vs GraphQL:**

| Aspect | REST | GraphQL |
|--------|------|---------|
| Endpoints | Multiple (one per resource) | Single endpoint |
| Data fetching | Fixed response structure | Client specifies exact fields |
| Over-fetching | Common problem | Avoided by design |
| Versioning | URL versioning (v1, v2) | Schema evolution |

**Use REST when:** Simple CRUD, caching is critical, team familiarity.
**Use GraphQL when:** Complex data relationships, mobile apps need minimal data.
</example>
"""

# Trigger words for each example type
_EXAMPLE_TRIGGERS = {
    "python": {
        "triggers": ["python", "py", "django", "flask", "fastapi", "pip"],
        "example": _PYTHON_CODE_EXAMPLE,
    },
    "javascript": {
        "triggers": ["javascript", "js", "node", "react", "vue", "typescript", "npm"],
        "example": _JAVASCRIPT_CODE_EXAMPLE,
    },
    "api": {
        "triggers": ["api", "endpoint", "rest", "http", "fetch", "request", "curl"],
        "example": _API_USAGE_EXAMPLE,
    },
    "debug": {
        "triggers": ["error", "bug", "fix", "debug", "not working", "issue", "traceback", "exception"],
        "example": _DEBUGGING_EXAMPLE,
    },
    "factual": {
        "triggers": ["what is", "difference between", "compare", "vs", "versus", "explain"],
        "example": _FACTUAL_EXAMPLE,
    },
}


def get_few_shot_examples(message: str, model: str) -> str:
    """Get relevant few-shot examples based on query type.

    Args:
        message: The user's message
        model: The model being used (only injects for small models)

    Returns:
        Examples string to inject into system prompt, or empty string.
    """
    # Only inject for small models
    if model not in ("nyx-lite",):
        return ""

    msg_lower = message.lower()
    examples = []

    for category, data in _EXAMPLE_TRIGGERS.items():
        if any(trigger in msg_lower for trigger in data["triggers"]):
            examples.append(data["example"])
            if len(examples) >= 2:  # Max 2 examples to save context
                break

    if not examples:
        return ""

    result = "\n".join(examples)
    logger.debug("Injecting %d few-shot examples for query type", len(examples))
    return result


def get_output_format_instructions(message: str, model: str) -> str:
    """Get explicit output format instructions based on query type.

    Args:
        message: The user's message
        model: The model being used

    Returns:
        Format instructions string, or empty string.
    """
    if model not in ("nyx-lite",):
        return ""

    msg_lower = message.lower()

    # Code queries
    if any(w in msg_lower for w in ["code", "function", "implement", "write", "create a"]):
        return """
[Output Format]
1. Brief explanation (1-2 sentences)
2. Code in fenced block with language tag
3. Usage example
Do NOT repeat code blocks."""

    # Debugging queries
    if any(w in msg_lower for w in ["error", "bug", "fix", "not working"]):
        return """
[Output Format]
1. Identify the problem
2. Explain the cause
3. Provide the solution with code
4. Explain why it works"""

    # Comparison queries
    if any(w in msg_lower for w in ["compare", "difference", "vs", "versus"]):
        return """
[Output Format]
Use a comparison table when appropriate.
Be concise and direct."""

    return ""
