import logging
import uuid
from datetime import datetime, timezone

import boto3
import httpx
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.models.image_generation import ImageGeneration
from backend.models.user import PlanType, User
from backend.services.conversation_service import ConversationService

logger = logging.getLogger(__name__)

IMAGE_LIMITS: dict[str, dict[str, int]] = {
    PlanType.PRO.value: {
        "daily": settings.PRO_DAILY_IMAGE_LIMIT,
        "monthly": settings.PRO_MONTHLY_IMAGE_LIMIT,
    },
    PlanType.MAX.value: {
        "daily": settings.MAX_DAILY_IMAGE_LIMIT,
        "monthly": settings.MAX_MONTHLY_IMAGE_LIMIT,
    },
}


class ImageService:
    def __init__(self, db: AsyncSession, user_id: str):
        self.db = db
        self.user_id = user_id
        self.conv_service = ConversationService(db, user_id=user_id)

    async def check_access(self) -> tuple[bool, str]:
        """Check plan tier and image usage limits."""
        user = await self.db.get(User, self.user_id)
        if not user:
            return False, "User not found."

        if user.plan not in (PlanType.PRO.value, PlanType.MAX.value):
            return False, "Image generation requires a Pro or Max plan."

        limits = IMAGE_LIMITS.get(user.plan)
        if not limits:
            return False, "No image limits configured for your plan."

        now = datetime.now(timezone.utc)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        daily_count = (await self.db.execute(
            select(func.count())
            .where(ImageGeneration.user_id == self.user_id)
            .where(ImageGeneration.created_at >= start_of_day)
        )).scalar() or 0

        if daily_count >= limits["daily"]:
            return False, "Daily image generation limit reached."

        monthly_count = (await self.db.execute(
            select(func.count())
            .where(ImageGeneration.user_id == self.user_id)
            .where(ImageGeneration.created_at >= start_of_month)
        )).scalar() or 0

        if monthly_count >= limits["monthly"]:
            return False, "Monthly image generation limit reached."

        return True, ""

    async def _save_result(
        self,
        image_bytes: bytes,
        prompt: str,
        conversation_id: str | None,
        width: int = 1024,
        height: int = 1024,
    ) -> dict:
        """Upload image to S3, save to conversation, record usage."""
        # Upload to S3
        image_id = str(uuid.uuid4())
        s3_key = f"generated/{image_id}.png"
        s3 = boto3.client("s3", region_name=settings.S3_IMAGES_REGION)
        s3.put_object(
            Bucket=settings.S3_IMAGES_BUCKET,
            Key=s3_key,
            Body=image_bytes,
            ContentType="image/png",
        )
        image_url = f"https://{settings.S3_IMAGES_BUCKET}.s3.{settings.S3_IMAGES_REGION}.amazonaws.com/{s3_key}"

        # Get or create conversation
        conv = None
        if conversation_id:
            conv = await self.conv_service.get(conversation_id)
        if not conv:
            conv = await self.conv_service.create(model="flux-dev")

        # Save user message (the prompt)
        await self.conv_service.add_message(conv.id, "user", prompt)

        # Save assistant message with image_url
        msg = await self.conv_service.add_message(
            conv.id, "assistant", f"![Generated image]({image_url})",
            image_url=image_url,
        )
        msg_id = msg.id

        # Record in image_generations table
        record = ImageGeneration(
            user_id=self.user_id,
            conversation_id=conv.id,
            prompt=prompt,
            image_url=image_url,
            width=width,
            height=height,
        )
        self.db.add(record)
        await self.db.commit()

        # Auto-title if new conversation
        if conv.title == "New Conversation":
            title = prompt[:47] + "..." if len(prompt) > 50 else prompt
            await self.conv_service.rename(conv.id, title)

        return {
            "image_url": image_url,
            "message_id": msg_id,
            "conversation_id": conv.id,
            "prompt": prompt,
        }

    async def generate(
        self,
        prompt: str,
        conversation_id: str | None,
        width: int = 1024,
        height: int = 1024,
    ) -> dict:
        """Call FLUX text2img service, upload to S3, save to conversation."""
        base_url = settings.FLUX_BASE_URL.rstrip("/")
        headers = {}
        if settings.FLUX_API_KEY:
            headers["Authorization"] = f"Bearer {settings.FLUX_API_KEY}"

        async with httpx.AsyncClient(timeout=httpx.Timeout(300.0, connect=10.0)) as client:
            resp = await client.post(
                f"{base_url}/generate",
                json={"prompt": prompt, "width": width, "height": height},
                headers=headers,
            )
            resp.raise_for_status()
            image_bytes = resp.content

        return await self._save_result(image_bytes, prompt, conversation_id, width, height)

    async def generate_img2img(
        self,
        image_bytes: bytes,
        prompt: str,
        conversation_id: str | None,
        strength: float = 0.75,
    ) -> dict:
        """Call FLUX img2img service, upload to S3, save to conversation."""
        base_url = settings.FLUX_BASE_URL.rstrip("/")
        headers = {}
        if settings.FLUX_API_KEY:
            headers["Authorization"] = f"Bearer {settings.FLUX_API_KEY}"

        async with httpx.AsyncClient(timeout=httpx.Timeout(300.0, connect=10.0)) as client:
            resp = await client.post(
                f"{base_url}/img2img",
                files={"image": ("input.png", image_bytes, "image/png")},
                data={"prompt": prompt, "strength": str(strength)},
                headers=headers,
            )
            resp.raise_for_status()
            result_bytes = resp.content

        return await self._save_result(result_bytes, prompt, conversation_id)
