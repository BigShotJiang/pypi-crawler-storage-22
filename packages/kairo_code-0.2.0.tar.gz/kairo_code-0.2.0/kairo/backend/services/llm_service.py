import json
import logging
from collections.abc import AsyncGenerator

import httpx

from backend.config import settings

logger = logging.getLogger(__name__)


class LLMService:
    def __init__(self):
        self.base_url = settings.VLLM_BASE_URL.rstrip("/")
        self.lite_base_url = settings.VLLM_LITE_BASE_URL.rstrip("/") if settings.VLLM_LITE_BASE_URL else ""
        self.model_map = settings.MODEL_MAP
        headers = {}
        if settings.VLLM_API_KEY:
            headers["Authorization"] = f"Bearer {settings.VLLM_API_KEY}"
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(120.0, connect=10.0),
            headers=headers,
        )
        self._lite_client: httpx.AsyncClient | None = None
        if self.lite_base_url:
            self._lite_client = httpx.AsyncClient(
                timeout=httpx.Timeout(120.0, connect=10.0),
                headers=headers,
            )
        self.primary_healthy = True
        self.lite_healthy = False

    async def close(self):
        await self._client.aclose()
        if self._lite_client:
            await self._lite_client.aclose()

    def resolve_model(self, name: str) -> str:
        return self.model_map.get(name, name)

    async def check_primary_health(self) -> bool:
        try:
            resp = await self._client.get(f"{self.base_url}/health")
            healthy = resp.status_code == 200
            if self.primary_healthy != healthy:
                logger.info("Primary vLLM health changed: %s → %s", self.primary_healthy, healthy)
            self.primary_healthy = healthy
            return healthy
        except httpx.HTTPError:
            if self.primary_healthy:
                logger.warning("Primary vLLM became unhealthy")
            self.primary_healthy = False
            return False

    async def check_lite_health(self) -> bool:
        if not self._lite_client or not self.lite_base_url:
            self.lite_healthy = False
            return False
        try:
            resp = await self._lite_client.get(f"{self.lite_base_url}/health")
            healthy = resp.status_code == 200
            if self.lite_healthy != healthy:
                logger.info("Lite vLLM health changed: %s → %s", self.lite_healthy, healthy)
            self.lite_healthy = healthy
            return healthy
        except httpx.HTTPError:
            if self.lite_healthy:
                logger.warning("Lite vLLM became unhealthy")
            self.lite_healthy = False
            return False

    def _select_backend(self, model: str) -> tuple[httpx.AsyncClient, str, str, bool]:
        """Select the best available backend for the given model.
        Returns (client, base_url, model_id, is_fallback).
        """
        # User explicitly selected nyx-lite
        if model == "nyx-lite" and self._lite_client and self.lite_base_url:
            return self._lite_client, self.lite_base_url, "nyx-lite", False
        # Auto-fallback: nyx requested but primary is down
        if model == "nyx" and not self.primary_healthy and self._lite_client and self.lite_base_url:
            return self._lite_client, self.lite_base_url, "nyx-lite", True
        return self._client, self.base_url, self.resolve_model(model), False

    async def stream_chat(
        self,
        messages: list[dict],
        model: str,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        tools: list[dict] | None = None,
    ) -> AsyncGenerator[str | dict, None]:
        client, base_url, model_id, is_fallback = self._select_backend(model)

        if is_fallback:
            yield {"type": "fallback", "model": "nyx-lite"}

        payload = {
            "model": model_id,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        logger.info("LLM request: model=%s (resolved=%s fallback=%s) msgs=%d temp=%.1f tools=%s",
                     model, model_id, is_fallback, len(messages), temperature, bool(tools))

        async with client.stream(
            "POST",
            f"{base_url}/v1/chat/completions",
            json=payload,
        ) as response:
            response.raise_for_status()
            usage_data = None
            tool_calls_acc: dict[int, dict] = {}
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:]
                if data.strip() == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                    # Capture usage from final chunk
                    if "usage" in chunk and chunk["usage"]:
                        usage_data = chunk["usage"]
                    if not chunk.get("choices"):
                        continue
                    choice = chunk["choices"][0]
                    delta = choice.get("delta", {})

                    # Accumulate tool calls across streaming deltas
                    if "tool_calls" in delta:
                        for tc in delta["tool_calls"]:
                            idx = tc["index"]
                            if idx not in tool_calls_acc:
                                tool_calls_acc[idx] = {"id": "", "name": "", "arguments": ""}
                            if tc.get("id"):
                                tool_calls_acc[idx]["id"] = tc["id"]
                            func = tc.get("function", {})
                            if func.get("name"):
                                tool_calls_acc[idx]["name"] = func["name"]
                            if func.get("arguments"):
                                tool_calls_acc[idx]["arguments"] += func["arguments"]

                    content = delta.get("content")
                    if content:
                        yield content

                    # Check finish reason for tool calls
                    finish_reason = choice.get("finish_reason")
                    if finish_reason == "tool_calls" and tool_calls_acc:
                        yield {"type": "tool_calls", "calls": list(tool_calls_acc.values())}
                        tool_calls_acc = {}
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue
            # Yield usage as a special sentinel dict (not a string)
            if usage_data:
                yield usage_data  # type: ignore[misc]

    async def check_health(self) -> bool:
        try:
            resp = await self._client.get(f"{self.base_url}/health")
            ok = resp.status_code == 200
            if not ok:
                logger.warning("vLLM health check failed: status %d", resp.status_code)
            return ok
        except httpx.HTTPError as e:
            logger.warning("vLLM health check error: %s", e)
            return False

    async def list_available_models(self) -> list[dict]:
        primary_ok = await self.check_health()
        lite_ok = await self.check_lite_health()
        result = []
        for info in settings.MODEL_INFO:
            if info["id"] == "nyx-lite":
                if self._lite_client:
                    result.append({**info, "available": lite_ok})
            else:
                result.append({**info, "available": primary_ok})
        return result
