"""Post-processor for LLM responses.

Validates generated code against tool results to catch hallucinated
endpoints, parameters, and URLs. Runs after the model generates a
response but before it's sent to the user.

Enhanced with:
- Code syntax validation (unclosed brackets, incomplete imports)
- Duplicate code detection
- Placeholder detection
- Claims verification against sources
"""

import logging
import re

logger = logging.getLogger(__name__)


def _extract_urls_from_text(text: str) -> set[str]:
    """Extract all URLs from text."""
    return set(re.findall(r'https?://[^\s\'"<>\)]+', text))


def _extract_code_blocks(text: str) -> list[str]:
    """Extract code from fenced code blocks."""
    blocks = re.findall(r'```[\w]*\n(.*?)```', text, re.DOTALL)
    return blocks


def _extract_urls_from_code(code_blocks: list[str]) -> set[str]:
    """Extract URLs used in code blocks."""
    urls = set()
    for block in code_blocks:
        # Match string literals containing URLs
        urls.update(re.findall(r'["\']+(https?://[^\s\'"<>\)]+)["\']', block))
        # Match f-string URLs
        urls.update(re.findall(r'f["\']+(https?://[^"\'{}]+)', block))
    return urls


def _extract_param_names(code_blocks: list[str]) -> set[str]:
    """Extract parameter names from request params/dicts in code."""
    params = set()
    for block in code_blocks:
        # Match dict keys in params-like structures: {'key': value} or {"key": value}
        params.update(re.findall(r'["\'](\w+)["\']\s*:', block))
    return params


def _validate_code_syntax(code_blocks: list[str]) -> list[str]:
    """Validate code block syntax and return issues.

    Checks for common problems small models make:
    - Unclosed brackets/parentheses/braces
    - Incomplete import statements
    - Placeholder values
    - Unterminated strings
    """
    issues = []

    for i, block in enumerate(code_blocks):
        block_issues = []

        # Check for unclosed brackets/parentheses/braces
        open_parens = block.count('(') - block.count(')')
        open_brackets = block.count('[') - block.count(']')
        open_braces = block.count('{') - block.count('}')

        if open_parens > 0:
            block_issues.append(f"{open_parens} unclosed parenthesis")
        elif open_parens < 0:
            block_issues.append(f"{-open_parens} extra closing parenthesis")

        if open_brackets > 0:
            block_issues.append(f"{open_brackets} unclosed bracket")
        elif open_brackets < 0:
            block_issues.append(f"{-open_brackets} extra closing bracket")

        if open_braces > 0:
            block_issues.append(f"{open_braces} unclosed brace")
        elif open_braces < 0:
            block_issues.append(f"{-open_braces} extra closing brace")

        # Check for incomplete imports (ending with comma or nothing after 'import')
        lines = block.split('\n')
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('import ') and stripped.endswith(','):
                block_issues.append("incomplete import statement")
                break
            if stripped == 'import' or stripped == 'from':
                block_issues.append("incomplete import statement")
                break

        # Check for placeholder patterns that shouldn't be in final code
        placeholders = re.findall(
            r'YOUR_[A-Z_]+|<[A-Z_]+>|REPLACE_THIS|TODO:|FIXME:|XXX:',
            block
        )
        if placeholders:
            unique_placeholders = list(set(placeholders))[:3]  # Limit display
            block_issues.append(f"placeholder values: {', '.join(unique_placeholders)}")

        # Check for ellipsis used as placeholder (common in small model output)
        if '...' in block and 'range(' not in block and 'slice' not in block:
            # Check if ... is used as code placeholder vs legitimate use
            ellipsis_lines = [l for l in lines if '...' in l and not l.strip().startswith('#')]
            if ellipsis_lines:
                # Check context - if it looks like placeholder code
                for el in ellipsis_lines:
                    if el.strip() == '...' or el.strip().endswith('...'):
                        block_issues.append("incomplete code (ellipsis placeholder)")
                        break

        if block_issues:
            issues.extend(block_issues)

    return issues[:5]  # Limit to 5 issues


def _detect_duplicate_code(code_blocks: list[str]) -> bool:
    """Detect if there are duplicate code blocks."""
    if len(code_blocks) < 2:
        return False

    seen_normalized = set()
    for block in code_blocks:
        # Normalize: collapse whitespace, lowercase
        normalized = ' '.join(block.lower().split())
        if len(normalized) < 50:
            continue  # Skip very short blocks

        if normalized in seen_normalized:
            return True

        # Also check for substantial overlap (80%+)
        for seen in seen_normalized:
            shorter = min(len(normalized), len(seen))
            if shorter > 100:
                # Compare first N chars
                if normalized[:shorter] == seen[:shorter]:
                    return True

        seen_normalized.add(normalized)

    return False


def _verify_claims_against_sources(response: str, tool_results: str) -> list[str]:
    """Identify claims in response that aren't supported by sources."""
    warnings = []
    response_lower = response.lower()
    tool_lower = tool_results.lower()

    # Check for statistics/numbers that should come from sources
    stat_patterns = [
        (r'(\d{1,3}(?:,\d{3})*)\s*(?:users?|customers?|downloads?|stars?)', "user/download count"),
        (r'(?:costs?|pricing?|price)\s*(?:is\s*)?\$(\d+)', "pricing"),
        (r'(\d+)%\s*(?:faster|slower|better|improvement)', "performance claim"),
    ]

    for pattern, claim_type in stat_patterns:
        matches = re.findall(pattern, response_lower)
        for match in matches:
            # Check if this number appears in the sources
            if match not in tool_lower:
                warnings.append(f"{claim_type} ({match}) not found in sources")

    # Check for requirement claims
    if 'require' in response_lower or 'must have' in response_lower or 'need to' in response_lower:
        # Check if sources mention it's free/no signup
        if 'free' in tool_lower and 'no' in tool_lower and ('signup' in tool_lower or 'registration' in tool_lower):
            if 'sign up' in response_lower or 'register' in response_lower:
                warnings.append("response mentions signup but sources indicate it may be free/no signup required")

    return warnings[:3]  # Limit warnings


def validate_response(response: str, tool_results: str | None) -> str:
    """Validate a model response against tool results.

    If the response contains code with API calls that contradict
    the tool results, append a correction note.

    Args:
        response: The model's generated response
        tool_results: The raw tool result text (from deep_search/web_search), or None

    Returns:
        The response, potentially with a correction appended.
    """
    if not response:
        return response

    code_blocks = _extract_code_blocks(response)
    corrections = []

    # CODE SYNTAX VALIDATION (always run, even without tool results)
    if code_blocks:
        syntax_issues = _validate_code_syntax(code_blocks)
        for issue in syntax_issues:
            corrections.append(f"**Code issue:** {issue}")

        # Duplicate detection
        if _detect_duplicate_code(code_blocks):
            corrections.append("**Note:** Duplicate code block detected - please use only the final version")

    # TOOL RESULT VALIDATION (only if we have tool results)
    if tool_results and code_blocks:
        # Extract URLs from tool results and code
        tool_urls = _extract_urls_from_text(tool_results)
        code_urls = _extract_urls_from_code(code_blocks)

        # Check for fabricated base URLs in code that don't appear in tool results
        if code_urls and tool_urls:
            # Normalize to base domains for comparison
            def base_domain(url: str) -> str:
                match = re.match(r'https?://([^/]+)', url)
                return match.group(1) if match else url

            tool_domains = {base_domain(u) for u in tool_urls}
            for url in code_urls:
                domain = base_domain(url)
                # Skip common/known domains
                if domain in ('api.openweathermap.org', 'api.github.com', 'jsonplaceholder.typicode.com',
                              'api.example.com', 'example.com', 'localhost'):
                    continue
                if domain not in tool_domains and not any(domain in td or td in domain for td in tool_domains):
                    # Check if the full URL path was fabricated
                    url_base = url.split('?')[0]
                    if not any(url_base in tr for tr in tool_urls):
                        corrections.append(
                            f"**Verify:** The URL `{url}` was not found in the documentation. "
                            f"Please confirm this endpoint exists."
                        )

        # Verify claims against sources
        claim_warnings = _verify_claims_against_sources(response, tool_results)
        for warning in claim_warnings:
            corrections.append(f"**Verify:** {warning}")

    # Check date format patterns in code
    if tool_results:
        for block in code_blocks:
            # Wrong date format: %Y%m%d when docs show YYYY-MM-DD
            if '%Y%m%d' in block and 'YYYY-MM-DD' in tool_results:
                corrections.append(
                    "**Correction:** The date format should be `YYYY-MM-DD` (use `strftime('%Y-%m-%d')`), "
                    "not `YYYYMMDD`, according to the API documentation."
                )
                break

    if corrections:
        # Deduplicate corrections
        unique_corrections = list(dict.fromkeys(corrections))
        correction_text = "\n\n---\n**Review Notes:**\n" + "\n".join(f"- {c}" for c in unique_corrections)
        logger.info("Post-processor added %d corrections", len(unique_corrections))
        return response + correction_text

    return response
