import logging

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models.conversation import Conversation
from backend.models.project import Project

logger = logging.getLogger(__name__)


class ProjectService:
    def __init__(self, db: AsyncSession, user_id: str):
        self.db = db
        self.user_id = user_id

    async def create(self, name: str) -> Project:
        project = Project(name=name, user_id=self.user_id)
        self.db.add(project)
        await self.db.commit()
        await self.db.refresh(project)
        return project

    async def get(self, project_id: str) -> Project | None:
        stmt = (
            select(Project)
            .options(selectinload(Project.conversations))
            .where(Project.id == project_id, Project.user_id == self.user_id)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()

    async def list_all(self) -> list[dict]:
        stmt = (
            select(
                Project.id,
                Project.name,
                Project.instructions,
                Project.created_at,
                Project.updated_at,
                func.count(Conversation.id).label("conversation_count"),
            )
            .outerjoin(Conversation, Conversation.project_id == Project.id)
            .where(Project.user_id == self.user_id)
            .group_by(Project.id)
            .order_by(Project.updated_at.desc())
        )
        result = await self.db.execute(stmt)
        rows = result.all()
        return [
            {
                "id": r.id,
                "name": r.name,
                "instructions": r.instructions,
                "created_at": r.created_at,
                "updated_at": r.updated_at,
                "conversation_count": r.conversation_count,
            }
            for r in rows
        ]

    async def update(self, project_id: str, **kwargs) -> Project | None:
        project = await self.get(project_id)
        if not project:
            return None
        for key, value in kwargs.items():
            if hasattr(project, key):
                setattr(project, key, value)
        await self.db.commit()
        await self.db.refresh(project)
        return project

    async def delete(self, project_id: str) -> bool:
        project = await self.get(project_id)
        if not project:
            return False
        await self.db.delete(project)
        await self.db.commit()
        return True

    async def add_conversation(self, project_id: str, conversation_id: str) -> bool:
        project = await self.get(project_id)
        if not project:
            return False
        stmt = (
            select(Conversation)
            .where(Conversation.id == conversation_id, Conversation.user_id == self.user_id)
        )
        result = await self.db.execute(stmt)
        conv = result.scalar_one_or_none()
        if not conv:
            return False
        conv.project_id = project_id
        await self.db.commit()
        return True

    async def remove_conversation(self, conversation_id: str) -> bool:
        stmt = (
            select(Conversation)
            .where(Conversation.id == conversation_id, Conversation.user_id == self.user_id)
        )
        result = await self.db.execute(stmt)
        conv = result.scalar_one_or_none()
        if not conv:
            return False
        conv.project_id = None
        await self.db.commit()
        return True
