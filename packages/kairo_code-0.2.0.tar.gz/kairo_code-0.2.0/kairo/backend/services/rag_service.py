"""RAG service for looking up internal documentation.

Loads curated JSON knowledge bases and returns relevant docs
when the model calls the lookup_kairo_docs tool.
"""

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

_DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"
_DOCS_CACHE: dict | None = None


def _load_docs() -> dict:
    """Load and cache the API docs JSON."""
    global _DOCS_CACHE
    if _DOCS_CACHE is not None:
        return _DOCS_CACHE

    docs_path = _DATA_DIR / "kairo_docs.json"
    if not docs_path.exists():
        logger.warning("kairo_docs.json not found at %s", docs_path)
        return {}

    with open(docs_path) as f:
        _DOCS_CACHE = json.load(f)
    logger.info("Loaded RAG docs from %s", docs_path)
    return _DOCS_CACHE


def lookup_kairo_docs(topic: str) -> str:
    """Look up Kairo API documentation by topic.

    Args:
        topic: What the user is asking about (e.g. "chat completions",
               "authentication", "models", "streaming", "python sdk")

    Returns:
        Formatted documentation string with all relevant Kairo API info.
    """
    docs = _load_docs()
    if not docs:
        return "No internal documentation available."

    kairo = docs.get("kairo", {})
    auth = kairo.get("auth", {})
    endpoints = kairo.get("endpoints", [])
    models = kairo.get("models", [])
    notes = kairo.get("notes", [])

    topic_lower = topic.lower()

    # Determine if user wants streaming or specific language examples
    want_streaming = any(w in topic_lower for w in ("stream", "sse", "realtime"))
    want_js = any(w in topic_lower for w in ("javascript", "js", "node", "typescript"))
    want_curl = any(w in topic_lower for w in ("curl", "bash", "shell", "http"))

    parts = []

    # Strong instruction header so the model uses this data
    parts.append(
        "IMPORTANT: The following is OFFICIAL Kairo API documentation. "
        "You MUST use ONLY the information below when answering about the Kairo API. "
        "Do NOT use your training data for Kairo API details. The code examples below "
        "are verified and correct — use them as-is or adapt them to the user's request."
    )
    parts.append("")
    parts.append("=== KAIRO API DOCUMENTATION ===")
    parts.append(f"Query: {topic}")
    parts.append("")

    # Auth
    parts.append("## Authentication")
    parts.append(f"- Method: {auth.get('method', 'N/A')}")
    parts.append(f"- Header: {auth.get('header', 'N/A')}")
    parts.append(f"- Key format: {auth.get('key_format', 'N/A')}")
    parts.append(f"- How to get a key: {auth.get('how_to_get_key', 'N/A')}")
    rl = kairo.get("rate_limits", {})
    parts.append(f"- Rate limit: {rl.get('requests_per_minute', 'N/A')} requests/min per key")
    parts.append("")

    # Models
    parts.append("## Available Models")
    for m in models:
        parts.append(f"- {m['id']} ({m['name']}): {m['description']} | Context: {m['context_window']} tokens")
    parts.append("")

    # Chat completions endpoint (always include — it's the main endpoint)
    for ep in endpoints:
        if ep["path"] == "/v1/chat/completions":
            parts.append(f"## {ep['method']} {ep['path']}")
            parts.append(ep["description"])
            parts.append("")
            parts.append("Request body parameters:")
            for param, desc in ep["request_body"].items():
                parts.append(f"  - {param}: {desc}")
            parts.append("")

            # Always include Python example (primary use case)
            if not want_curl or want_js:
                parts.append("### Python Example (CORRECT — use this pattern)")
                parts.append("```python")
                parts.append(ep["example_python"])
                parts.append("```")
                parts.append("")

            if want_streaming:
                parts.append("### Python Streaming Example")
                parts.append("```python")
                parts.append(ep["example_streaming"])
                parts.append("```")
                parts.append("")

            if want_js:
                parts.append("### JavaScript/Node.js Example")
                parts.append("```javascript")
                parts.append(ep["example_javascript"])
                parts.append("```")
                parts.append("")

            if want_curl:
                parts.append("### cURL Example")
                parts.append("```bash")
                parts.append(ep["example_curl"])
                parts.append("```")
                parts.append("")

    # Other endpoints
    for ep in endpoints:
        if ep["path"] != "/v1/chat/completions":
            parts.append(f"## {ep['method']} {ep['path']}")
            parts.append(ep["description"])
            if "example_curl" in ep:
                parts.append(f"Example: {ep['example_curl']}")
            parts.append("")

    # Notes
    parts.append("## Important Notes")
    for note in notes:
        parts.append(f"- {note}")

    parts.append("")
    parts.append("=== END KAIRO API DOCUMENTATION ===")

    result = "\n".join(parts)
    logger.info("lookup_kairo_docs(%s) returned %d chars", topic, len(result))
    return result
