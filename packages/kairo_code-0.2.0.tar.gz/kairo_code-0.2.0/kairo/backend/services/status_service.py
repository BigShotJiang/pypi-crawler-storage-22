import logging
import time
from collections import defaultdict
from datetime import datetime, timedelta, UTC

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.models.incident import Incident
from backend.models.uptime_record import UptimeRecord
from backend.services.llm_service import LLMService

logger = logging.getLogger(__name__)


class StatusService:
    """Public-facing service that aggregates health data for the status page."""

    def __init__(self, db: AsyncSession, llm_service: LLMService):
        self.db = db
        self.llm = llm_service

    async def get_status_page(self) -> dict:
        """Aggregate all status data for the public status page."""
        components = await self._get_component_statuses()
        incidents = await self._get_recent_incidents(limit=10)
        uptime = await self._get_uptime_history(days=90)
        overall = self._determine_overall_status(components)
        overall_uptime = self._calculate_overall_uptime(uptime)

        return {
            "status": overall,
            "overall_uptime": overall_uptime,
            "checked_at": datetime.now(UTC).isoformat(),
            "components": components,
            "recent_incidents": incidents,
            "uptime_history": uptime,
        }

    async def _get_component_statuses(self) -> list[dict]:
        """Check each component's current health status."""
        components = []

        # API/Chat -- if this code is executing, the API is up
        components.append({"name": "API", "status": "operational", "latency_ms": None})

        # Models (vLLM primary + lite)
        primary_ok = getattr(self.llm, "primary_healthy", False)
        lite_ok = getattr(self.llm, "lite_healthy", False)
        if primary_ok:
            model_status = "operational"
        elif lite_ok:
            model_status = "degraded"
        else:
            model_status = "down"
        components.append({"name": "Models", "status": model_status, "latency_ms": None})

        # Image Generation
        if settings.FEATURE_IMAGE_GEN_ENABLED and settings.FLUX_BASE_URL:
            try:
                async with httpx.AsyncClient(timeout=5.0) as client:
                    t0 = time.monotonic()
                    resp = await client.get(f"{settings.FLUX_BASE_URL}/health")
                    latency = int((time.monotonic() - t0) * 1000)
                    if resp.status_code == 200:
                        components.append({"name": "Image Generation", "status": "operational", "latency_ms": latency})
                    else:
                        components.append({"name": "Image Generation", "status": "degraded", "latency_ms": latency})
            except Exception:
                components.append({"name": "Image Generation", "status": "down", "latency_ms": None})
        else:
            components.append({"name": "Image Generation", "status": "down", "latency_ms": None})

        # Database -- if we got this far, DB is operational
        components.append({"name": "Database", "status": "operational", "latency_ms": None})

        # Check for any active (unresolved) incidents that override component status
        active_incidents = await self._get_active_incidents()
        component_map = {
            "api": "API",
            "chat": "API",
            "models": "Models",
            "images": "Image Generation",
            "database": "Database",
        }
        for incident in active_incidents:
            comp_name = component_map.get(incident.component)
            if not comp_name:
                continue
            for comp in components:
                if comp["name"] == comp_name:
                    # Escalate status based on incident severity
                    if incident.severity == "critical":
                        comp["status"] = "down"
                    elif incident.severity == "warning" and comp["status"] == "operational":
                        comp["status"] = "degraded"

        return components

    async def _get_active_incidents(self) -> list[Incident]:
        """Get all unresolved incidents."""
        stmt = (
            select(Incident)
            .where(Incident.status != "resolved")
            .order_by(Incident.started_at.desc())
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def _get_recent_incidents(self, limit: int = 10) -> list[dict]:
        """Get recent incidents ordered by started_at descending."""
        stmt = (
            select(Incident)
            .order_by(Incident.started_at.desc())
            .limit(limit)
        )
        result = await self.db.execute(stmt)
        return [
            {
                "id": i.id,
                "title": i.title,
                "description": i.description,
                "severity": i.severity,
                "component": i.component,
                "status": i.status,
                "started_at": i.started_at.isoformat(),
                "resolved_at": i.resolved_at.isoformat() if i.resolved_at else None,
            }
            for i in result.scalars().all()
        ]

    async def _get_uptime_history(self, days: int = 90) -> list[dict]:
        """Get daily uptime percentages for the last N days, averaged across components."""
        start = datetime.now(UTC) - timedelta(days=days)
        stmt = (
            select(UptimeRecord)
            .where(UptimeRecord.date >= start.date())
            .order_by(UptimeRecord.date.desc())
        )
        result = await self.db.execute(stmt)

        # Group by date, average across all components
        date_uptimes: dict[str, list[float]] = defaultdict(list)
        for r in result.scalars().all():
            date_uptimes[str(r.date)].append(r.uptime_percent)

        return [
            {"date": d, "uptime_percent": round(sum(vals) / len(vals), 2)}
            for d, vals in sorted(date_uptimes.items(), reverse=True)
        ]

    def _determine_overall_status(self, components: list[dict]) -> str:
        """Determine overall system status from component statuses."""
        statuses = [c["status"] for c in components]
        if any(s == "down" for s in statuses):
            return "outage"
        if any(s == "degraded" for s in statuses):
            return "degraded"
        return "operational"

    def _calculate_overall_uptime(self, history: list[dict]) -> float:
        """Calculate overall uptime percentage from history entries."""
        if not history:
            return 100.0
        return round(sum(h["uptime_percent"] for h in history) / len(history), 2)
