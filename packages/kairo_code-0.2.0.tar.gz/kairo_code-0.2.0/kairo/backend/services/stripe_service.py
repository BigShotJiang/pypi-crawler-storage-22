import logging

import stripe

from backend.config import settings

logger = logging.getLogger(__name__)


class StripeService:
    def __init__(self) -> None:
        stripe.api_key = settings.STRIPE_SECRET_KEY

    def create_checkout_session(self, user_id: str, email: str, stripe_customer_id: str | None) -> tuple[str, str]:
        """Create a Stripe Checkout session. Returns (checkout_url, customer_id)."""
        if stripe_customer_id:
            customer_id = stripe_customer_id
        else:
            customer = stripe.Customer.create(email=email, metadata={"kairo_user_id": user_id})
            customer_id = customer.id

        session = stripe.checkout.Session.create(
            customer=customer_id,
            mode="subscription",
            line_items=[{"price": settings.STRIPE_PRO_PRICE_ID, "quantity": 1}],
            success_url=f"{settings.APP_BASE_URL}/account?checkout=success",
            cancel_url=f"{settings.APP_BASE_URL}/pricing?checkout=cancelled",
            metadata={"kairo_user_id": user_id},
        )
        if not session.url:
            raise RuntimeError("Stripe did not return a checkout URL")
        return session.url, customer_id

    def create_billing_portal_session(self, stripe_customer_id: str) -> str:
        """Create a Stripe Billing Portal session. Returns the portal URL."""
        session = stripe.billing_portal.Session.create(
            customer=stripe_customer_id,
            return_url=f"{settings.APP_BASE_URL}/account",
        )
        return session.url

    def handle_webhook_event(self, payload: bytes, sig: str) -> dict:
        """Verify and parse a Stripe webhook event. Returns action dict."""
        event = stripe.Webhook.construct_event(payload, sig, settings.STRIPE_WEBHOOK_SECRET)
        event_type = event["type"]
        data = event["data"]["object"]

        if event_type == "checkout.session.completed":
            customer_id = data["customer"]
            subscription_id = data["subscription"]
            user_id = data.get("metadata", {}).get("kairo_user_id")
            logger.info("Checkout completed: customer=%s user=%s", customer_id, user_id)
            return {
                "action": "upgrade",
                "customer_id": customer_id,
                "subscription_id": subscription_id,
                "user_id": user_id,
            }

        if event_type == "customer.subscription.updated":
            customer_id = data["customer"]
            status = data["status"]
            logger.info("Subscription updated: customer=%s status=%s", customer_id, status)
            if status == "active":
                return {"action": "sync_active", "customer_id": customer_id, "subscription_id": data["id"]}
            return {"action": "noop"}

        if event_type == "customer.subscription.deleted":
            customer_id = data["customer"]
            logger.info("Subscription deleted: customer=%s", customer_id)
            return {"action": "downgrade", "customer_id": customer_id}

        if event_type == "invoice.payment_failed":
            customer_id = data["customer"]
            logger.warning("Payment failed: customer=%s", customer_id)
            return {"action": "payment_failed", "customer_id": customer_id}

        return {"action": "noop"}
