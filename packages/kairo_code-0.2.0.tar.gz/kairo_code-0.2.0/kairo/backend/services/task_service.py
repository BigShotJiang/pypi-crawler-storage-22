import logging
from datetime import datetime, UTC

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models.agent import Agent
from backend.models.task import Task

logger = logging.getLogger(__name__)


class TaskService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_task(self, user_id: str, input_data: dict, agent_id: str | None = None) -> Task:
        """Create a new task for a user, optionally targeting a specific agent."""
        # If agent_id specified, verify the agent belongs to this user
        if agent_id:
            stmt = select(Agent).where(Agent.id == agent_id, Agent.user_id == user_id)
            result = await self.db.execute(stmt)
            if not result.scalar_one_or_none():
                raise ValueError("Agent not found or not owned by user")

        task = Task(
            user_id=user_id,
            agent_id=agent_id,
            input=input_data,
            status="pending",
        )
        self.db.add(task)
        await self.db.commit()
        await self.db.refresh(task)
        logger.info("Task created: id=%s user=%s agent=%s", task.id, user_id, agent_id)
        return task

    async def claim_task(self, agent_id: str, user_id: str) -> Task | None:
        """Claim the oldest pending task for this user's agent.

        Uses FOR UPDATE SKIP LOCKED to prevent race conditions
        when multiple agents poll simultaneously.
        """
        # Verify agent belongs to this user
        agent_stmt = select(Agent).where(Agent.id == agent_id, Agent.user_id == user_id)
        agent_result = await self.db.execute(agent_stmt)
        agent = agent_result.scalar_one_or_none()
        if not agent:
            return None

        # Find oldest pending task: either targeted to this agent or unassigned
        stmt = (
            select(Task)
            .where(
                Task.user_id == user_id,
                Task.status == "pending",
                (Task.agent_id == agent_id) | (Task.agent_id.is_(None)),
            )
            .order_by(Task.created_at.asc())
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        result = await self.db.execute(stmt)
        task = result.scalar_one_or_none()

        if not task:
            return None

        task.agent_id = agent_id
        task.status = "running"
        task.claimed_at = datetime.now(UTC)
        task.updated_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(task)
        logger.info("Task claimed: id=%s agent=%s", task.id, agent_id)
        return task

    async def update_task(
        self, task_id: str, user_id: str, status: str,
        output: dict | None = None, error: str | None = None,
    ) -> Task | None:
        """Update a task's status, output, or error."""
        stmt = select(Task).where(Task.id == task_id, Task.user_id == user_id)
        result = await self.db.execute(stmt)
        task = result.scalar_one_or_none()
        if not task:
            return None

        task.status = status
        task.updated_at = datetime.now(UTC)

        if output is not None:
            task.output = output
        if error is not None:
            task.error = error
        if status in ("completed", "failed"):
            task.completed_at = datetime.now(UTC)

        await self.db.commit()
        await self.db.refresh(task)
        logger.info("Task updated: id=%s status=%s", task_id, status)
        return task

    async def list_tasks(
        self, user_id: str, status: str | None = None, limit: int = 50,
    ) -> list[Task]:
        """List tasks for a user, optionally filtered by status."""
        stmt = select(Task).where(Task.user_id == user_id)
        if status:
            stmt = stmt.where(Task.status == status)
        stmt = stmt.order_by(Task.created_at.desc()).limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_task(self, task_id: str, user_id: str) -> Task | None:
        """Get a single task by ID, scoped to user."""
        stmt = select(Task).where(Task.id == task_id, Task.user_id == user_id)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
