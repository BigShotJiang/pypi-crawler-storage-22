import logging
from datetime import datetime, timezone, timedelta

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import settings
from backend.models.usage import UsageRecord
from backend.models.user import PlanType, User

logger = logging.getLogger(__name__)

PLAN_LIMITS: dict[str, dict[str, int]] = {
    PlanType.FREE.value: {
        "daily": settings.DEFAULT_DAILY_TOKEN_LIMIT,
        "monthly": settings.DEFAULT_MONTHLY_TOKEN_LIMIT,
    },
    PlanType.PRO.value: {
        "daily": settings.PRO_DAILY_TOKEN_LIMIT,
        "monthly": settings.PRO_MONTHLY_TOKEN_LIMIT,
    },
    PlanType.MAX.value: {
        "daily": settings.MAX_DAILY_TOKEN_LIMIT,
        "monthly": settings.MAX_MONTHLY_TOKEN_LIMIT,
    },
}


def _get_plan_limits(plan: str) -> tuple[int, int]:
    limits = PLAN_LIMITS.get(plan, PLAN_LIMITS[PlanType.FREE.value])
    return limits["daily"], limits["monthly"]


class UsageService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def record_usage(
        self,
        user_id: str,
        conversation_id: str | None,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> UsageRecord:
        record = UsageRecord(
            user_id=user_id,
            conversation_id=conversation_id,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )
        self.db.add(record)
        await self.db.commit()
        await self.db.refresh(record)
        logger.info(
            "Usage recorded: user=%s prompt=%d completion=%d",
            user_id, prompt_tokens, completion_tokens,
        )
        return record

    async def get_daily_usage(self, user_id: str) -> int:
        now = datetime.now(timezone.utc)
        start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
        stmt = (
            select(
                func.coalesce(
                    func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens), 0
                )
            )
            .where(UsageRecord.user_id == user_id)
            .where(UsageRecord.created_at >= start_of_day)
        )
        result = await self.db.execute(stmt)
        return result.scalar() or 0

    async def get_monthly_usage(self, user_id: str) -> int:
        now = datetime.now(timezone.utc)
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        stmt = (
            select(
                func.coalesce(
                    func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens), 0
                )
            )
            .where(UsageRecord.user_id == user_id)
            .where(UsageRecord.created_at >= start_of_month)
        )
        result = await self.db.execute(stmt)
        return result.scalar() or 0

    async def check_limits(self, user_id: str) -> tuple[bool, str]:
        """Returns (allowed, reason). allowed=True if under limits."""
        user = await self.db.get(User, user_id)
        if not user:
            return False, "User not found"

        daily_limit, monthly_limit = _get_plan_limits(user.plan)

        daily = await self.get_daily_usage(user_id)
        if daily >= daily_limit:
            return False, "Daily token limit reached. Try again tomorrow."

        monthly = await self.get_monthly_usage(user_id)
        if monthly >= monthly_limit:
            return False, "Monthly token limit reached."

        return True, ""

    async def get_usage_summary(self, user_id: str) -> dict:
        user = await self.db.get(User, user_id)
        daily_used = await self.get_daily_usage(user_id)
        monthly_used = await self.get_monthly_usage(user_id)

        daily_limit, monthly_limit = _get_plan_limits(user.plan if user else PlanType.FREE.value)

        daily_pct = round((daily_used / daily_limit) * 100, 1) if daily_limit else 0
        monthly_pct = round((monthly_used / monthly_limit) * 100, 1) if monthly_limit else 0

        return {
            "daily_percent": min(100, daily_pct),
            "monthly_percent": min(100, monthly_pct),
        }

    async def get_usage_history(self, user_id: str, days: int = 30) -> list[dict]:
        user = await self.db.get(User, user_id)
        daily_limit, _ = _get_plan_limits(user.plan if user else PlanType.FREE.value)

        start = datetime.now(timezone.utc) - timedelta(days=days)
        stmt = (
            select(
                func.date(UsageRecord.created_at).label("date"),
                func.sum(UsageRecord.prompt_tokens + UsageRecord.completion_tokens).label("total_tokens"),
            )
            .where(UsageRecord.user_id == user_id)
            .where(UsageRecord.created_at >= start)
            .group_by(func.date(UsageRecord.created_at))
            .order_by(func.date(UsageRecord.created_at))
        )
        result = await self.db.execute(stmt)
        rows = result.all()
        return [
            {
                "date": str(r.date),
                "usage_percent": round(
                    min(100, ((r.total_tokens or 0) / daily_limit) * 100), 1
                ) if daily_limit else 0,
            }
            for r in rows
        ]
