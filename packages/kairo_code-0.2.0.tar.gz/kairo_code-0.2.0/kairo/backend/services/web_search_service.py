import logging
import re
from html import unescape

import httpx

logger = logging.getLogger(__name__)


async def web_search(query: str, max_results: int = 5) -> list[dict]:
    """Search the web via DuckDuckGo HTML and return results."""
    results = []

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                "https://html.duckduckgo.com/html/",
                data={"q": query, "b": ""},
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                },
            )
            resp.raise_for_status()
            html = resp.text

        # Parse results using regex (avoid BeautifulSoup dependency)
        # DuckDuckGo HTML results have class="result__a" for links and class="result__snippet" for snippets
        link_pattern = re.compile(
            r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_pattern = re.compile(
            r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
            re.DOTALL,
        )

        links = link_pattern.findall(html)
        snippets = snippet_pattern.findall(html)

        for i, (url, title) in enumerate(links[:max_results]):
            # Clean HTML tags and decode entities
            clean_title = unescape(re.sub(r"<[^>]+>", "", title)).strip()
            clean_snippet = ""
            if i < len(snippets):
                clean_snippet = unescape(re.sub(r"<[^>]+>", "", snippets[i])).strip()

            # DuckDuckGo uses redirect URLs - extract actual URL
            actual_url = url
            uddg_match = re.search(r"uddg=([^&]+)", url)
            if uddg_match:
                from urllib.parse import unquote
                actual_url = unquote(uddg_match.group(1))

            if clean_title and actual_url:
                results.append({
                    "title": clean_title,
                    "url": actual_url,
                    "snippet": clean_snippet,
                })

    except Exception as e:
        logger.warning("Web search failed for '%s': %s", query, e)

    return results


def format_search_results(results: list[dict]) -> str:
    """Format search results for injection into the LLM context."""
    if not results:
        return ""

    parts = [
        "=== WEB SEARCH RESULTS (AUTHORITATIVE — USE THESE AS YOUR PRIMARY SOURCE) ===",
        "",
    ]
    for i, r in enumerate(results, 1):
        parts.append(f"Result {i}: {r['title']}")
        if r.get("snippet"):
            parts.append(f"  Summary: {r['snippet']}")
        parts.append(f"  URL: {r['url']}")
        parts.append("")

    parts.append("=== END OF SEARCH RESULTS ===")
    parts.append("")
    parts.append(
        "CRITICAL INSTRUCTIONS FOR USING THESE RESULTS:\n"
        "1. Base your ENTIRE answer on the search results above. They are FRESH and AUTHORITATIVE.\n"
        "2. Your training data is OUTDATED and UNRELIABLE for this topic. Do NOT fall back to it.\n"
        "3. If search results say something is FREE or does NOT require signup, trust them — do NOT claim otherwise.\n"
        "4. If search results show an API works a certain way, describe it EXACTLY as shown — do NOT invent parameters, "
        "endpoints, headers, or authentication requirements that are not mentioned in the results.\n"
        "5. Do NOT fabricate URLs. Only share URLs that appear in the search results above.\n"
        "6. If the search results do not contain enough information, say so honestly. Do NOT guess or fill gaps with training data.\n"
        "7. Integrate the information naturally into your response. Do NOT use [Source N] citations."
    )
    return "\n".join(parts)
