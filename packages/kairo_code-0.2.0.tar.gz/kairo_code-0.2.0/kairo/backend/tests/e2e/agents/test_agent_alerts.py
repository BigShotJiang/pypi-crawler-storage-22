"""
End-to-end tests for Agent Alerts functionality.

Tests cover:
- Create alert config
- Update alert config
- Delete alert config
- Get alert history
"""

import pytest
import uuid
from datetime import datetime, timedelta, UTC
from httpx import AsyncClient
from sqlalchemy import select

from backend.models.agent import Agent, AgentAlertConfig, AgentAlertHistory


class TestCreateAlertConfig:
    """Tests for POST /api/agents/{agent_id}/alerts"""

    @pytest.mark.asyncio
    async def test_create_alert_config_success(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should create an alert configuration."""
        payload = {
            "name": "High Error Rate Alert",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
            "window_seconds": 300,
            "cooldown_seconds": 3600,
            "severity": "warning",
            "channels": ["email"],
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "High Error Rate Alert"
        assert data["alert_type"] == "error_rate"
        assert data["metric"] == "error_rate"
        assert data["condition"] == "gt"
        assert data["threshold"] == 10.0
        assert data["window_seconds"] == 300
        assert data["cooldown_seconds"] == 3600
        assert data["severity"] == "warning"
        assert data["channels"] == ["email"]
        assert data["is_enabled"] is True
        assert "id" in data
        assert "created_at" in data

    @pytest.mark.asyncio
    async def test_create_offline_alert(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should create an offline detection alert."""
        payload = {
            "name": "Agent Offline Alert",
            "alert_type": "offline",
            "metric": "heartbeat",
            "condition": "gt",
            "threshold": 120,  # seconds without heartbeat
            "window_seconds": 60,
            "severity": "critical",
            "channels": ["email", "slack"],
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["alert_type"] == "offline"
        assert data["severity"] == "critical"
        assert "slack" in data["channels"]

    @pytest.mark.asyncio
    async def test_create_latency_alert(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should create a latency threshold alert."""
        payload = {
            "name": "High Latency Alert",
            "alert_type": "latency",
            "metric": "avg_latency_ms",
            "condition": "gte",
            "threshold": 5000,  # 5 seconds
            "window_seconds": 600,  # 10 minutes
            "severity": "warning",
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["alert_type"] == "latency"
        assert data["threshold"] == 5000

    @pytest.mark.asyncio
    async def test_create_token_budget_alert(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should create a token budget alert."""
        payload = {
            "name": "Daily Token Limit Alert",
            "alert_type": "token_budget",
            "metric": "daily_tokens",
            "condition": "gt",
            "threshold": 100000,
            "window_seconds": 86400,  # 24 hours
            "severity": "info",
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["alert_type"] == "token_budget"

    @pytest.mark.asyncio
    async def test_create_alert_validation_errors(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should reject invalid alert configuration."""
        # Invalid alert_type
        payload = {
            "name": "Test Alert",
            "alert_type": "invalid_type",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_alert_invalid_condition(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should reject invalid condition operator."""
        payload = {
            "name": "Test Alert",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "invalid",
            "threshold": 10.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_alert_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())
        payload = {
            "name": "Test Alert",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
        }

        response = await client.post(
            f"/api/agents/{fake_id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 404


class TestGetAlertConfigs:
    """Tests for GET /api/agents/{agent_id}/alerts"""

    @pytest.mark.asyncio
    async def test_get_alerts_empty(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return empty list when no alerts configured."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data == []

    @pytest.mark.asyncio
    async def test_get_alerts_with_configs(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return list of alert configurations."""
        await agent_factory.create_alert_config(
            test_agent.id, name="Error Rate Alert", alert_type="error_rate"
        )
        await agent_factory.create_alert_config(
            test_agent.id, name="Latency Alert", alert_type="latency"
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    @pytest.mark.asyncio
    async def test_get_alerts_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.get(
            f"/api/agents/{fake_id}/alerts", headers=auth_headers
        )

        assert response.status_code == 404


class TestUpdateAlertConfig:
    """Tests for PATCH /api/agents/{agent_id}/alerts/{config_id}"""

    @pytest.mark.asyncio
    async def test_update_alert_threshold(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should update alert threshold."""
        config = await agent_factory.create_alert_config(
            test_agent.id, threshold=10.0
        )

        payload = {"threshold": 20.0}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert data["threshold"] == 20.0

    @pytest.mark.asyncio
    async def test_update_alert_name(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should update alert name."""
        config = await agent_factory.create_alert_config(
            test_agent.id, name="Original Name"
        )

        payload = {"name": "Updated Name"}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert response.json()["name"] == "Updated Name"

    @pytest.mark.asyncio
    async def test_update_alert_disable(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should disable an alert."""
        config = await agent_factory.create_alert_config(
            test_agent.id, is_enabled=True
        )

        payload = {"is_enabled": False}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert response.json()["is_enabled"] is False

    @pytest.mark.asyncio
    async def test_update_alert_channels(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should update alert notification channels."""
        config = await agent_factory.create_alert_config(
            test_agent.id, channels=["email"]
        )

        payload = {"channels": ["email", "slack", "webhook"]}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert set(response.json()["channels"]) == {"email", "slack", "webhook"}

    @pytest.mark.asyncio
    async def test_update_alert_severity(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should update alert severity."""
        config = await agent_factory.create_alert_config(
            test_agent.id, severity="warning"
        )

        payload = {"severity": "critical"}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert response.json()["severity"] == "critical"

    @pytest.mark.asyncio
    async def test_update_alert_multiple_fields(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should update multiple fields at once."""
        config = await agent_factory.create_alert_config(test_agent.id)

        payload = {
            "name": "Updated Alert",
            "threshold": 50.0,
            "window_seconds": 600,
            "severity": "info",
        }

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{config.id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Alert"
        assert data["threshold"] == 50.0
        assert data["window_seconds"] == 600
        assert data["severity"] == "info"

    @pytest.mark.asyncio
    async def test_update_alert_not_found(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return 404 for non-existent alert config."""
        fake_id = str(uuid.uuid4())
        payload = {"threshold": 20.0}

        response = await client.patch(
            f"/api/agents/{test_agent.id}/alerts/{fake_id}",
            json=payload,
            headers=auth_headers,
        )

        assert response.status_code == 404


class TestDeleteAlertConfig:
    """Tests for DELETE /api/agents/{agent_id}/alerts/{config_id}"""

    @pytest.mark.asyncio
    async def test_delete_alert_success(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory, db_session
    ):
        """Should delete an alert configuration."""
        config = await agent_factory.create_alert_config(test_agent.id)
        config_id = config.id

        response = await client.delete(
            f"/api/agents/{test_agent.id}/alerts/{config_id}",
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert response.json()["deleted"] is True

        # Verify deleted
        stmt = select(AgentAlertConfig).where(AgentAlertConfig.id == config_id)
        result = await db_session.execute(stmt)
        assert result.scalar_one_or_none() is None

    @pytest.mark.asyncio
    async def test_delete_alert_not_found(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return 404 for non-existent alert config."""
        fake_id = str(uuid.uuid4())

        response = await client.delete(
            f"/api/agents/{test_agent.id}/alerts/{fake_id}",
            headers=auth_headers,
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_alert_wrong_agent(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory, db_session, test_user
    ):
        """Should return 404 when config belongs to different agent."""
        # Create another agent
        other_agent = Agent(
            id=str(uuid.uuid4()),
            user_id=test_user.id,
            name="Other Agent",
        )
        db_session.add(other_agent)
        await db_session.commit()

        # Create config for other agent
        other_config = AgentAlertConfig(
            id=str(uuid.uuid4()),
            agent_id=other_agent.id,
            user_id=test_user.id,
            name="Other Alert",
            alert_type="error_rate",
            metric="error_rate",
            condition="gt",
            threshold=10.0,
        )
        db_session.add(other_config)
        await db_session.commit()

        # Try to delete using test_agent's endpoint
        response = await client.delete(
            f"/api/agents/{test_agent.id}/alerts/{other_config.id}",
            headers=auth_headers,
        )

        assert response.status_code == 404


class TestAlertHistory:
    """Tests for GET /api/agents/{agent_id}/alerts/history"""

    @pytest.mark.asyncio
    async def test_get_alert_history_empty(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return empty list when no alerts have triggered."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts/history", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data == []

    @pytest.mark.asyncio
    async def test_get_alert_history_with_entries(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return alert history entries."""
        config = await agent_factory.create_alert_config(test_agent.id)

        # Create history entries
        await agent_factory.create_alert_history(
            config.id,
            test_agent.id,
            alert_type="error_rate",
            severity="warning",
            message="Error rate exceeded 10%",
        )
        await agent_factory.create_alert_history(
            config.id,
            test_agent.id,
            alert_type="error_rate",
            severity="warning",
            status="resolved",
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts/history", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2

    @pytest.mark.asyncio
    async def test_alert_history_fields(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return expected fields in history entry."""
        config = await agent_factory.create_alert_config(test_agent.id)

        await agent_factory.create_alert_history(
            config.id,
            test_agent.id,
            alert_type="latency",
            severity="critical",
            status="triggered",
            message="Latency exceeded 5000ms",
            trigger_value=6500.0,
            threshold_value=5000.0,
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts/history", headers=auth_headers
        )

        data = response.json()
        entry = data[0]

        assert "id" in entry
        assert entry["alert_type"] == "latency"
        assert entry["severity"] == "critical"
        assert entry["status"] == "triggered"
        assert entry["message"] == "Latency exceeded 5000ms"
        assert entry["trigger_value"] == 6500.0
        assert entry["threshold_value"] == 5000.0
        assert "created_at" in entry

    @pytest.mark.asyncio
    async def test_alert_history_ordered_desc(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory, db_session
    ):
        """Should return history in descending time order."""
        config = await agent_factory.create_alert_config(test_agent.id)
        now = datetime.now(UTC)

        # Create entries with different times
        for i in range(3):
            history = AgentAlertHistory(
                id=str(uuid.uuid4()),
                config_id=config.id,
                agent_id=test_agent.id,
                alert_type="error_rate",
                severity="warning",
                status="triggered",
            )
            db_session.add(history)
            await db_session.commit()
            history.created_at = now - timedelta(hours=i)
            await db_session.commit()

        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts/history", headers=auth_headers
        )

        data = response.json()
        timestamps = [entry["created_at"] for entry in data]

        # Should be in descending order (newest first)
        assert timestamps == sorted(timestamps, reverse=True)

    @pytest.mark.asyncio
    async def test_alert_history_limit(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should respect limit parameter."""
        config = await agent_factory.create_alert_config(test_agent.id)

        # Create 20 history entries
        for _ in range(20):
            await agent_factory.create_alert_history(
                config.id, test_agent.id
            )

        response = await client.get(
            f"/api/agents/{test_agent.id}/alerts/history?limit=5",
            headers=auth_headers,
        )

        assert response.status_code == 200
        assert len(response.json()) == 5

    @pytest.mark.asyncio
    async def test_alert_history_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.get(
            f"/api/agents/{fake_id}/alerts/history", headers=auth_headers
        )

        assert response.status_code == 404


class TestAlertConditions:
    """Tests for different alert condition operators."""

    @pytest.mark.asyncio
    async def test_create_alert_condition_gt(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'gt' (greater than) condition."""
        payload = {
            "name": "Test",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["condition"] == "gt"

    @pytest.mark.asyncio
    async def test_create_alert_condition_lt(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'lt' (less than) condition."""
        payload = {
            "name": "Test",
            "alert_type": "error_rate",
            "metric": "uptime_percent",
            "condition": "lt",
            "threshold": 99.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["condition"] == "lt"

    @pytest.mark.asyncio
    async def test_create_alert_condition_gte(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'gte' (greater than or equal) condition."""
        payload = {
            "name": "Test",
            "alert_type": "latency",
            "metric": "avg_latency_ms",
            "condition": "gte",
            "threshold": 1000.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["condition"] == "gte"

    @pytest.mark.asyncio
    async def test_create_alert_condition_lte(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'lte' (less than or equal) condition."""
        payload = {
            "name": "Test",
            "alert_type": "error_rate",
            "metric": "requests_per_minute",
            "condition": "lte",
            "threshold": 5.0,
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["condition"] == "lte"

    @pytest.mark.asyncio
    async def test_create_alert_condition_eq(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'eq' (equal) condition."""
        payload = {
            "name": "Test",
            "alert_type": "offline",
            "metric": "state",
            "condition": "eq",
            "threshold": 0.0,  # offline = 0
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["condition"] == "eq"


class TestAlertSeverityLevels:
    """Tests for alert severity levels."""

    @pytest.mark.asyncio
    async def test_create_alert_severity_info(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'info' severity."""
        payload = {
            "name": "Test",
            "alert_type": "token_budget",
            "metric": "tokens",
            "condition": "gt",
            "threshold": 50000,
            "severity": "info",
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["severity"] == "info"

    @pytest.mark.asyncio
    async def test_create_alert_severity_warning(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'warning' severity."""
        payload = {
            "name": "Test",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
            "severity": "warning",
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["severity"] == "warning"

    @pytest.mark.asyncio
    async def test_create_alert_severity_critical(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should accept 'critical' severity."""
        payload = {
            "name": "Test",
            "alert_type": "offline",
            "metric": "heartbeat",
            "condition": "gt",
            "threshold": 300,
            "severity": "critical",
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["severity"] == "critical"

    @pytest.mark.asyncio
    async def test_create_alert_invalid_severity(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should reject invalid severity level."""
        payload = {
            "name": "Test",
            "alert_type": "error_rate",
            "metric": "error_rate",
            "condition": "gt",
            "threshold": 10.0,
            "severity": "emergency",  # invalid
        }

        response = await client.post(
            f"/api/agents/{test_agent.id}/alerts", json=payload, headers=auth_headers
        )

        assert response.status_code == 422
