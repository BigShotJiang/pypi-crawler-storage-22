"""
End-to-end tests for Agent CRUD operations.

Tests cover:
- Create agent with all fields
- List agents (empty, with agents)
- Get agent by ID
- Update agent fields
- Delete agent (soft delete)
- 404 for non-existent agent
"""

import pytest
import uuid
from httpx import AsyncClient

from backend.models.agent import Agent


class TestCreateAgent:
    """Tests for POST /api/agents/"""

    @pytest.mark.asyncio
    async def test_create_agent_with_all_fields(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should create an agent with all optional fields specified."""
        payload = {
            "name": "My Production Agent",
            "description": "Handles customer support queries",
            "system_prompt": "You are a helpful customer support assistant.",
            "model_preference": "nyx",
            "agent_type": "sdk",
            "tools": ["web_search", "file_read"],
        }

        response = await client.post(
            "/api/agents/", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == payload["name"]
        assert data["description"] == payload["description"]
        assert data["model_preference"] == payload["model_preference"]
        assert data["agent_type"] == payload["agent_type"]
        assert data["state"] == "created"
        assert data["status"] == "offline"
        assert "id" in data
        assert "created_at" in data
        assert "updated_at" in data

    @pytest.mark.asyncio
    async def test_create_agent_minimal_fields(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should create an agent with only required fields."""
        payload = {"name": "Minimal Agent"}

        response = await client.post(
            "/api/agents/", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Minimal Agent"
        assert data["model_preference"] == "nyx"  # default
        assert data["agent_type"] == "sdk"  # default
        assert data["description"] is None

    @pytest.mark.asyncio
    async def test_create_agent_validation_error_empty_name(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should reject agent creation with empty name."""
        payload = {"name": ""}

        response = await client.post(
            "/api/agents/", json=payload, headers=auth_headers
        )

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_agent_validation_error_name_too_long(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should reject agent creation with name exceeding 100 chars."""
        payload = {"name": "x" * 101}

        response = await client.post(
            "/api/agents/", json=payload, headers=auth_headers
        )

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_agent_invalid_agent_type(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should reject agent creation with invalid agent_type."""
        payload = {"name": "Test Agent", "agent_type": "invalid"}

        response = await client.post(
            "/api/agents/", json=payload, headers=auth_headers
        )

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_create_agent_requires_auth(self, client: AsyncClient):
        """Should require authentication to create agent."""
        payload = {"name": "Test Agent"}

        response = await client.post("/api/agents/", json=payload)

        assert response.status_code == 403  # No auth header


class TestListAgents:
    """Tests for GET /api/agents/"""

    @pytest.mark.asyncio
    async def test_list_agents_empty(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return empty list when user has no agents."""
        response = await client.get("/api/agents/", headers=auth_headers)

        assert response.status_code == 200
        data = response.json()
        assert data == []

    @pytest.mark.asyncio
    async def test_list_agents_with_agents(
        self, client: AsyncClient, auth_headers: dict, agent_factory
    ):
        """Should return list of user's agents with summary metrics."""
        # Create multiple agents
        await agent_factory.create_agent(name="Agent 1", state="online")
        await agent_factory.create_agent(name="Agent 2", state="offline")
        await agent_factory.create_agent(name="Agent 3", state="idle")

        response = await client.get("/api/agents/", headers=auth_headers)

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

        # Verify all expected fields are present
        for agent in data:
            assert "id" in agent
            assert "name" in agent
            assert "state" in agent
            assert "model_preference" in agent
            assert "agent_type" in agent
            assert "created_at" in agent
            # Summary metrics should be present (may be 0)
            assert "requests_24h" in agent
            assert "errors_24h" in agent
            assert "tokens_24h" in agent
            assert "error_rate" in agent

    @pytest.mark.asyncio
    async def test_list_agents_excludes_deleted(
        self, client: AsyncClient, auth_headers: dict, agent_factory, db_session
    ):
        """Should not return soft-deleted agents."""
        from datetime import datetime, UTC

        agent = await agent_factory.create_agent(name="To Delete")
        agent.deleted_at = datetime.now(UTC)
        await db_session.commit()

        response = await client.get("/api/agents/", headers=auth_headers)

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 0

    @pytest.mark.asyncio
    async def test_list_agents_isolation(
        self, client: AsyncClient, auth_headers: dict, db_session, agent_factory
    ):
        """Should only return agents belonging to the authenticated user."""
        from argon2 import PasswordHasher
        from backend.models.user import User

        # Create another user with their own agent
        ph = PasswordHasher()
        other_user = User(
            id=str(uuid.uuid4()),
            email="other@example.com",
            hashed_password=ph.hash("password"),
            email_verified=True,
        )
        db_session.add(other_user)
        await db_session.commit()

        other_agent = Agent(
            id=str(uuid.uuid4()),
            user_id=other_user.id,
            name="Other User Agent",
            state="online",
        )
        db_session.add(other_agent)
        await db_session.commit()

        # Create agent for test user
        await agent_factory.create_agent(name="My Agent")

        response = await client.get("/api/agents/", headers=auth_headers)

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "My Agent"


class TestGetAgent:
    """Tests for GET /api/agents/{agent_id}"""

    @pytest.mark.asyncio
    async def test_get_agent_success(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return agent details for valid ID."""
        response = await client.get(
            f"/api/agents/{test_agent.id}", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == test_agent.id
        assert data["name"] == test_agent.name
        assert data["description"] == test_agent.description
        assert data["state"] == test_agent.state

    @pytest.mark.asyncio
    async def test_get_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent ID."""
        fake_id = str(uuid.uuid4())

        response = await client.get(
            f"/api/agents/{fake_id}", headers=auth_headers
        )

        assert response.status_code == 404
        assert response.json()["detail"] == "Agent not found"

    @pytest.mark.asyncio
    async def test_get_agent_wrong_user(
        self, client: AsyncClient, db_session, test_user
    ):
        """Should return 404 when accessing another user's agent."""
        from argon2 import PasswordHasher
        from backend.core.security import create_access_token
        from backend.models.user import User

        # Create another user
        ph = PasswordHasher()
        other_user = User(
            id=str(uuid.uuid4()),
            email="other@example.com",
            hashed_password=ph.hash("password"),
            email_verified=True,
        )
        db_session.add(other_user)

        # Create agent for other user
        other_agent = Agent(
            id=str(uuid.uuid4()),
            user_id=other_user.id,
            name="Other Agent",
            state="online",
        )
        db_session.add(other_agent)
        await db_session.commit()

        # Try to access with test_user's token
        token = create_access_token(test_user.id)
        headers = {"Authorization": f"Bearer {token}"}

        response = await client.get(
            f"/api/agents/{other_agent.id}", headers=headers
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_get_deleted_agent_returns_404(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, db_session
    ):
        """Should return 404 for soft-deleted agent."""
        from datetime import datetime, UTC

        test_agent.deleted_at = datetime.now(UTC)
        await db_session.commit()

        response = await client.get(
            f"/api/agents/{test_agent.id}", headers=auth_headers
        )

        assert response.status_code == 404


class TestUpdateAgent:
    """Tests for PATCH /api/agents/{agent_id}"""

    @pytest.mark.asyncio
    async def test_update_agent_name(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should update agent name."""
        payload = {"name": "Updated Agent Name"}

        response = await client.patch(
            f"/api/agents/{test_agent.id}", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Updated Agent Name"

    @pytest.mark.asyncio
    async def test_update_agent_multiple_fields(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should update multiple agent fields at once."""
        payload = {
            "name": "New Name",
            "description": "New description",
            "model_preference": "nyx-lite",
            "system_prompt": "New system prompt",
        }

        response = await client.patch(
            f"/api/agents/{test_agent.id}", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "New Name"
        assert data["description"] == "New description"
        assert data["model_preference"] == "nyx-lite"

    @pytest.mark.asyncio
    async def test_update_agent_partial(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should allow partial updates without affecting other fields."""
        original_name = test_agent.name
        payload = {"description": "Only updating description"}

        response = await client.patch(
            f"/api/agents/{test_agent.id}", json=payload, headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["name"] == original_name
        assert data["description"] == "Only updating description"

    @pytest.mark.asyncio
    async def test_update_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())
        payload = {"name": "New Name"}

        response = await client.patch(
            f"/api/agents/{fake_id}", json=payload, headers=auth_headers
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_update_agent_empty_name_rejected(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should reject update with empty name."""
        payload = {"name": ""}

        response = await client.patch(
            f"/api/agents/{test_agent.id}", json=payload, headers=auth_headers
        )

        assert response.status_code == 422


class TestDeleteAgent:
    """Tests for DELETE /api/agents/{agent_id}"""

    @pytest.mark.asyncio
    async def test_delete_agent_success(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, db_session
    ):
        """Should soft delete an agent."""
        response = await client.delete(
            f"/api/agents/{test_agent.id}", headers=auth_headers
        )

        assert response.status_code == 200
        assert response.json()["deleted"] is True

        # Verify soft delete (agent still exists but has deleted_at set)
        await db_session.refresh(test_agent)
        assert test_agent.deleted_at is not None

    @pytest.mark.asyncio
    async def test_delete_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.delete(
            f"/api/agents/{fake_id}", headers=auth_headers
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_agent_idempotent(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return 404 when trying to delete already deleted agent."""
        # First delete
        response1 = await client.delete(
            f"/api/agents/{test_agent.id}", headers=auth_headers
        )
        assert response1.status_code == 200

        # Second delete should return 404 (agent is now "deleted")
        response2 = await client.delete(
            f"/api/agents/{test_agent.id}", headers=auth_headers
        )
        assert response2.status_code == 404

    @pytest.mark.asyncio
    async def test_deleted_agent_not_in_list(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should not include deleted agent in list response."""
        # Delete the agent
        await client.delete(f"/api/agents/{test_agent.id}", headers=auth_headers)

        # List should be empty
        response = await client.get("/api/agents/", headers=auth_headers)

        assert response.status_code == 200
        assert len(response.json()) == 0
