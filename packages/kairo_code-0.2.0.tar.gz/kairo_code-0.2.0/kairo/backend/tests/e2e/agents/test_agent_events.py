"""
End-to-end tests for Agent Events functionality.

Tests cover:
- Get events
- Filter by event type
- Event logging on actions
"""

import pytest
import uuid
from datetime import datetime, timedelta, UTC
from httpx import AsyncClient
from sqlalchemy import select

from backend.models.agent import Agent, AgentEvent


class TestGetEvents:
    """Tests for GET /api/agents/{agent_id}/events"""

    @pytest.mark.asyncio
    async def test_get_events_empty(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return empty list for agent with no events."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/events", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data == []

    @pytest.mark.asyncio
    async def test_get_events_with_data(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return events for agent."""
        # Create some events
        await agent_factory.create_event(
            test_agent.id, event_type="heartbeat", event_data={"status": "online"}
        )
        await agent_factory.create_event(
            test_agent.id, event_type="connection", event_data={"action": "connected"}
        )
        await agent_factory.create_event(
            test_agent.id, event_type="error", error_message="Connection timeout"
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/events", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 3

    @pytest.mark.asyncio
    async def test_get_events_returns_expected_fields(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return events with all expected fields."""
        await agent_factory.create_event(
            test_agent.id,
            event_type="heartbeat",
            event_data={"status": "busy", "queue_depth": 5},
            client_ip="192.168.1.100",
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/events", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        event = data[0]

        assert "id" in event
        assert event["event_type"] == "heartbeat"
        assert event["event_data"]["status"] == "busy"
        assert event["event_data"]["queue_depth"] == 5
        assert event["client_ip"] == "192.168.1.100"
        assert "created_at" in event

    @pytest.mark.asyncio
    async def test_get_events_ordered_by_time_desc(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, db_session
    ):
        """Should return events in descending time order (newest first)."""
        now = datetime.now(UTC)

        # Create events with different timestamps
        for i, event_type in enumerate(["event_a", "event_b", "event_c"]):
            event = AgentEvent(
                id=str(uuid.uuid4()),
                agent_id=test_agent.id,
                event_type=event_type,
            )
            db_session.add(event)
            await db_session.commit()

            # Manually set created_at to control ordering
            event.created_at = now - timedelta(minutes=i)
            await db_session.commit()

        response = await client.get(
            f"/api/agents/{test_agent.id}/events", headers=auth_headers
        )

        data = response.json()
        event_types = [e["event_type"] for e in data]

        # event_a is newest, event_c is oldest
        assert event_types == ["event_a", "event_b", "event_c"]

    @pytest.mark.asyncio
    async def test_get_events_agent_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.get(
            f"/api/agents/{fake_id}/events", headers=auth_headers
        )

        assert response.status_code == 404


class TestFilterEventsByType:
    """Tests for event type filtering."""

    @pytest.mark.asyncio
    async def test_filter_by_event_type(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should filter events by event_type parameter."""
        # Create different event types
        await agent_factory.create_event(test_agent.id, event_type="heartbeat")
        await agent_factory.create_event(test_agent.id, event_type="heartbeat")
        await agent_factory.create_event(test_agent.id, event_type="error")
        await agent_factory.create_event(test_agent.id, event_type="connection")

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=heartbeat",
            headers=auth_headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        assert all(e["event_type"] == "heartbeat" for e in data)

    @pytest.mark.asyncio
    async def test_filter_by_error_type(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should filter by error event type."""
        await agent_factory.create_event(
            test_agent.id,
            event_type="error",
            error_type="LLM_ERROR",
            error_message="Model unavailable",
        )
        await agent_factory.create_event(test_agent.id, event_type="heartbeat")

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=error",
            headers=auth_headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["error_type"] == "LLM_ERROR"
        assert data[0]["error_message"] == "Model unavailable"

    @pytest.mark.asyncio
    async def test_filter_returns_empty_for_no_match(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return empty list when no events match filter."""
        await agent_factory.create_event(test_agent.id, event_type="heartbeat")

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=error",
            headers=auth_headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 0


class TestEventsLimit:
    """Tests for event limit parameter."""

    @pytest.mark.asyncio
    async def test_default_limit_50(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should return max 50 events by default."""
        # Create 60 events
        for _ in range(60):
            await agent_factory.create_event(test_agent.id, event_type="heartbeat")

        response = await client.get(
            f"/api/agents/{test_agent.id}/events", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 50

    @pytest.mark.asyncio
    async def test_custom_limit(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent, agent_factory
    ):
        """Should respect custom limit parameter."""
        for _ in range(20):
            await agent_factory.create_event(test_agent.id, event_type="heartbeat")

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?limit=10", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 10

    @pytest.mark.asyncio
    async def test_limit_max_500(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should enforce maximum limit of 500."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/events?limit=1000", headers=auth_headers
        )

        # Should reject limit > 500
        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_limit_min_1(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should enforce minimum limit of 1."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/events?limit=0", headers=auth_headers
        )

        assert response.status_code == 422


class TestEventLoggingOnActions:
    """Tests for automatic event logging on agent actions."""

    @pytest.mark.asyncio
    async def test_heartbeat_logs_event(
        self, client: AsyncClient, api_key_headers: dict, auth_headers: dict,
        test_agent: Agent
    ):
        """Should log heartbeat event when heartbeat is received."""
        # Send heartbeat
        heartbeat_payload = {
            "agent_id": test_agent.id,
            "status": "online",
            "sdk_version": "1.0.0",
        }

        await client.post(
            "/api/agents/heartbeat", json=heartbeat_payload, headers=api_key_headers
        )

        # Check events
        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=heartbeat",
            headers=auth_headers,
        )

        data = response.json()
        assert len(data) >= 1

        event = data[0]
        assert event["event_type"] == "heartbeat"
        assert event["event_data"]["status"] == "online"
        assert event["event_data"]["sdk_version"] == "1.0.0"

    @pytest.mark.asyncio
    async def test_command_issued_logs_event(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should log command_issued event when command is created."""
        # Issue restart command
        await client.post(
            f"/api/agents/{test_agent.id}/restart", headers=auth_headers
        )

        # Check events
        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=command_issued",
            headers=auth_headers,
        )

        data = response.json()
        assert len(data) >= 1

        event = data[0]
        assert event["event_type"] == "command_issued"
        assert event["event_data"]["command_type"] == "restart"

    @pytest.mark.asyncio
    async def test_error_heartbeat_logs_error_details(
        self, client: AsyncClient, api_key_headers: dict, auth_headers: dict,
        test_agent: Agent
    ):
        """Should log error details in heartbeat event."""
        heartbeat_payload = {
            "agent_id": test_agent.id,
            "status": "error",
            "last_error": {
                "message": "Failed to connect to database",
                "code": "DB_CONNECTION_ERROR",
            },
        }

        await client.post(
            "/api/agents/heartbeat", json=heartbeat_payload, headers=api_key_headers
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=heartbeat",
            headers=auth_headers,
        )

        data = response.json()
        event = data[0]
        assert event["event_data"]["status"] == "error"


class TestEventWithClientIP:
    """Tests for client IP tracking in events."""

    @pytest.mark.asyncio
    async def test_heartbeat_event_includes_client_ip(
        self, client: AsyncClient, api_key_headers: dict, auth_headers: dict,
        test_agent: Agent
    ):
        """Should include client IP in heartbeat event."""
        heartbeat_payload = {
            "agent_id": test_agent.id,
            "status": "online",
        }

        await client.post(
            "/api/agents/heartbeat", json=heartbeat_payload, headers=api_key_headers
        )

        response = await client.get(
            f"/api/agents/{test_agent.id}/events?event_type=heartbeat",
            headers=auth_headers,
        )

        data = response.json()
        # In test environment, client IP should be captured
        # (actual value depends on test setup)
        assert "client_ip" in data[0]


class TestEventCleanup:
    """Tests for event cleanup functionality."""

    @pytest.mark.asyncio
    async def test_cleanup_old_events(self, db_session, test_user, test_agent):
        """Should clean up events older than retention period."""
        from backend.services.agent_service import AgentService

        # Create old event (100 days ago)
        old_event = AgentEvent(
            id=str(uuid.uuid4()),
            agent_id=test_agent.id,
            event_type="heartbeat",
        )
        db_session.add(old_event)
        await db_session.commit()

        # Manually set old timestamp
        old_event.created_at = datetime.now(UTC) - timedelta(days=100)
        await db_session.commit()

        # Create recent event
        recent_event = AgentEvent(
            id=str(uuid.uuid4()),
            agent_id=test_agent.id,
            event_type="heartbeat",
        )
        db_session.add(recent_event)
        await db_session.commit()

        # Run cleanup with 90-day retention
        svc = AgentService(db_session)
        count = await svc.cleanup_old_events(retention_days=90)

        assert count == 1

        # Old event should be deleted
        stmt = select(AgentEvent).where(AgentEvent.id == old_event.id)
        result = await db_session.execute(stmt)
        assert result.scalar_one_or_none() is None

        # Recent event should remain
        stmt = select(AgentEvent).where(AgentEvent.id == recent_event.id)
        result = await db_session.execute(stmt)
        assert result.scalar_one_or_none() is not None
