"""
End-to-end tests for Agent Setup Flow.

Tests cover:
- Generate setup token
- Token expiry validation
- Consume setup token successfully
- Reject used/expired tokens
- Agent transitions to "online" state after registration
- API key is created with type="agent"
"""

import hashlib
import pytest
import uuid
from datetime import datetime, timedelta, UTC
from httpx import AsyncClient

from backend.models.agent import Agent, AgentSetupToken
from backend.models.api_key import ApiKey


class TestGenerateSetupToken:
    """Tests for POST /api/agents/{agent_id}/setup-token"""

    @pytest.mark.asyncio
    async def test_generate_setup_token_success(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should generate a valid setup token for an agent."""
        response = await client.post(
            f"/api/agents/{test_agent.id}/setup-token", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert "token" in data
        assert data["token"].startswith("kairo_setup_")
        assert "expires_at" in data
        assert data["agent_id"] == test_agent.id

    @pytest.mark.asyncio
    async def test_setup_token_expiry_in_future(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should set token expiry in the future (default 15 minutes)."""
        response = await client.post(
            f"/api/agents/{test_agent.id}/setup-token", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()

        expires_at = datetime.fromisoformat(data["expires_at"].replace("Z", "+00:00"))
        now = datetime.now(UTC)

        # Token should expire within 10-20 minutes from now
        assert expires_at > now + timedelta(minutes=10)
        assert expires_at < now + timedelta(minutes=20)

    @pytest.mark.asyncio
    async def test_generate_token_for_nonexistent_agent(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.post(
            f"/api/agents/{fake_id}/setup-token", headers=auth_headers
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_generate_multiple_tokens(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should allow generating multiple tokens (old ones remain valid until used/expired)."""
        response1 = await client.post(
            f"/api/agents/{test_agent.id}/setup-token", headers=auth_headers
        )
        response2 = await client.post(
            f"/api/agents/{test_agent.id}/setup-token", headers=auth_headers
        )

        assert response1.status_code == 200
        assert response2.status_code == 200

        token1 = response1.json()["token"]
        token2 = response2.json()["token"]
        assert token1 != token2


class TestConsumeSetupToken:
    """Tests for POST /api/agents/register"""

    @pytest.mark.asyncio
    async def test_consume_token_success(
        self, client: AsyncClient, test_agent: Agent, agent_factory, db_session
    ):
        """Should successfully register agent with valid token."""
        # Generate a setup token
        token, _ = await agent_factory.create_setup_token(test_agent.id)

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
            "host_info": {
                "hostname": "test-machine",
                "ip": "192.168.1.100",
                "os": "linux",
                "memory_mb": 8192,
            },
        }

        response = await client.post("/api/agents/register", json=payload)

        assert response.status_code == 200
        data = response.json()
        assert data["agent_id"] == test_agent.id
        assert data["name"] == test_agent.name
        assert data["model_preference"] == test_agent.model_preference
        assert "api_key" in data
        assert data["api_key"].startswith("kairo_agent_")

    @pytest.mark.asyncio
    async def test_agent_state_transitions_to_online(
        self, client: AsyncClient, test_agent: Agent, agent_factory, db_session
    ):
        """Should transition agent state to 'online' after registration."""
        token, _ = await agent_factory.create_setup_token(test_agent.id)

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
        }

        await client.post("/api/agents/register", json=payload)

        # Refresh agent from database
        await db_session.refresh(test_agent)

        assert test_agent.state == "online"
        assert test_agent.first_connected_at is not None
        assert test_agent.last_online_at is not None
        assert test_agent.sdk_version == "1.0.0"

    @pytest.mark.asyncio
    async def test_api_key_created_with_agent_type(
        self, client: AsyncClient, test_agent: Agent, agent_factory, db_session
    ):
        """Should create API key with type='agent' after registration."""
        from sqlalchemy import select

        token, _ = await agent_factory.create_setup_token(test_agent.id)

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
        }

        response = await client.post("/api/agents/register", json=payload)
        data = response.json()

        # Find the created API key
        stmt = select(ApiKey).where(ApiKey.agent_id == test_agent.id)
        result = await db_session.execute(stmt)
        api_key = result.scalar_one_or_none()

        assert api_key is not None
        assert api_key.key_type == "agent"
        assert api_key.is_active is True
        assert f"Agent: {test_agent.name}" in api_key.name

    @pytest.mark.asyncio
    async def test_reject_used_token(
        self, client: AsyncClient, test_agent: Agent, agent_factory
    ):
        """Should reject a token that has already been used."""
        # Create a used token
        token, setup_token = await agent_factory.create_setup_token(
            test_agent.id, used=True
        )

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
        }

        response = await client.post("/api/agents/register", json=payload)

        assert response.status_code == 401
        assert "Invalid or expired" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_reject_expired_token(
        self, client: AsyncClient, test_agent: Agent, db_session
    ):
        """Should reject a token that has expired."""
        import secrets

        # Create an expired token directly
        token = f"kairo_setup_{secrets.token_urlsafe(32)}"
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        expires_at = datetime.now(UTC) - timedelta(hours=1)  # Expired

        setup_token = AgentSetupToken(
            id=str(uuid.uuid4()),
            agent_id=test_agent.id,
            user_id=test_agent.user_id,
            token_hash=token_hash,
            expires_at=expires_at,
            used=False,
        )
        db_session.add(setup_token)
        await db_session.commit()

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
        }

        response = await client.post("/api/agents/register", json=payload)

        assert response.status_code == 401
        assert "Invalid or expired" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_reject_invalid_token(self, client: AsyncClient):
        """Should reject an invalid token format."""
        payload = {
            "setup_token": "invalid_token_format",
            "sdk_version": "1.0.0",
        }

        response = await client.post("/api/agents/register", json=payload)

        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_reject_nonexistent_token(self, client: AsyncClient):
        """Should reject a token that does not exist in database."""
        import secrets

        payload = {
            "setup_token": f"kairo_setup_{secrets.token_urlsafe(32)}",
            "sdk_version": "1.0.0",
        }

        response = await client.post("/api/agents/register", json=payload)

        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_token_marked_as_used_after_consumption(
        self, client: AsyncClient, test_agent: Agent, agent_factory, db_session
    ):
        """Should mark token as used after successful consumption."""
        token, setup_token = await agent_factory.create_setup_token(test_agent.id)

        payload = {
            "setup_token": token,
            "sdk_version": "1.0.0",
        }

        await client.post("/api/agents/register", json=payload)

        # Refresh token from database
        await db_session.refresh(setup_token)

        assert setup_token.used is True
        assert setup_token.used_at is not None

    @pytest.mark.asyncio
    async def test_host_info_stored_on_agent(
        self, client: AsyncClient, test_agent: Agent, agent_factory, db_session
    ):
        """Should store host_info on the agent after registration."""
        token, _ = await agent_factory.create_setup_token(test_agent.id)

        host_info = {
            "hostname": "production-server",
            "ip": "10.0.0.50",
            "os": "ubuntu-22.04",
            "memory_mb": 16384,
        }

        payload = {
            "setup_token": token,
            "sdk_version": "2.0.0",
            "host_info": host_info,
        }

        await client.post("/api/agents/register", json=payload)

        await db_session.refresh(test_agent)

        assert test_agent.host_info is not None
        assert test_agent.host_info["hostname"] == "production-server"
        assert test_agent.host_info["os"] == "ubuntu-22.04"


class TestConnectionStatus:
    """Tests for GET /api/agents/{agent_id}/connection-status"""

    @pytest.mark.asyncio
    async def test_connection_status_not_connected(
        self, client: AsyncClient, auth_headers: dict, test_agent: Agent
    ):
        """Should return connected=false for unregistered agent."""
        response = await client.get(
            f"/api/agents/{test_agent.id}/connection-status", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["connected"] is False
        assert data["state"] == "created"
        assert data["first_connected_at"] is None

    @pytest.mark.asyncio
    async def test_connection_status_connected(
        self, client: AsyncClient, auth_headers: dict, online_agent: Agent
    ):
        """Should return connected=true for registered online agent."""
        response = await client.get(
            f"/api/agents/{online_agent.id}/connection-status", headers=auth_headers
        )

        assert response.status_code == 200
        data = response.json()
        assert data["connected"] is True
        assert data["state"] == "online"
        assert data["first_connected_at"] is not None
        assert data["sdk_version"] == "1.0.0"
        assert data["host_info"] is not None

    @pytest.mark.asyncio
    async def test_connection_status_not_found(
        self, client: AsyncClient, auth_headers: dict
    ):
        """Should return 404 for non-existent agent."""
        fake_id = str(uuid.uuid4())

        response = await client.get(
            f"/api/agents/{fake_id}/connection-status", headers=auth_headers
        )

        assert response.status_code == 404
