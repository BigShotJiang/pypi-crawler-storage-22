"""Usage tracking and indexes

Revision ID: 002
Revises: 001
Create Date: 2025-01-15 00:00:00.000000
"""

from alembic import op
import sqlalchemy as sa

revision = "002"
down_revision = "001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # usage_records table
    op.create_table(
        "usage_records",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "conversation_id",
            sa.String(),
            sa.ForeignKey("conversations.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("model", sa.String(), nullable=False),
        sa.Column("prompt_tokens", sa.Integer(), nullable=False),
        sa.Column("completion_tokens", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    # Add limit columns to users
    op.add_column(
        "users",
        sa.Column("daily_token_limit", sa.Integer(), nullable=False, server_default="100000"),
    )
    op.add_column(
        "users",
        sa.Column("monthly_token_limit", sa.Integer(), nullable=False, server_default="2000000"),
    )

    # Performance indexes
    op.create_index("ix_conversations_user_id", "conversations", ["user_id"])
    op.create_index("ix_messages_conversation_id", "messages", ["conversation_id"])
    op.create_index("ix_messages_created_at", "messages", ["created_at"])
    op.create_index("ix_usage_records_user_id", "usage_records", ["user_id"])
    op.create_index("ix_usage_records_user_date", "usage_records", ["user_id", "created_at"])


def downgrade() -> None:
    op.drop_index("ix_usage_records_user_date")
    op.drop_index("ix_usage_records_user_id")
    op.drop_index("ix_messages_created_at")
    op.drop_index("ix_messages_conversation_id")
    op.drop_index("ix_conversations_user_id")
    op.drop_column("users", "monthly_token_limit")
    op.drop_column("users", "daily_token_limit")
    op.drop_table("usage_records")
