"""Rename username to email

Revision ID: 003
Revises: 002
Create Date: 2026-01-27 00:00:00.000000
"""

from alembic import op

revision = "003"
down_revision = "002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column("users", "username", new_column_name="email")


def downgrade() -> None:
    op.alter_column("users", "email", new_column_name="username")
