"""Add image generation support

Revision ID: 006
Revises: 005
Create Date: 2026-01-29 12:00:00.000000
"""

from alembic import op
import sqlalchemy as sa

revision = "006"
down_revision = "005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add image_url to messages
    op.add_column(
        "messages",
        sa.Column("image_url", sa.String(), nullable=True),
    )

    # Create image_generations table
    op.create_table(
        "image_generations",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column(
            "user_id",
            sa.String(),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "conversation_id",
            sa.String(),
            sa.ForeignKey("conversations.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("prompt", sa.Text(), nullable=False),
        sa.Column("image_url", sa.String(), nullable=False),
        sa.Column("width", sa.Integer(), nullable=False, server_default="1024"),
        sa.Column("height", sa.Integer(), nullable=False, server_default="1024"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    op.create_index(
        "ix_image_generations_user_id", "image_generations", ["user_id"]
    )
    op.create_index(
        "ix_image_generations_created_at", "image_generations", ["created_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_image_generations_created_at", table_name="image_generations")
    op.drop_index("ix_image_generations_user_id", table_name="image_generations")
    op.drop_table("image_generations")
    op.drop_column("messages", "image_url")
