"""Add device code auth flow (RFC 8628)

Revision ID: 008
Revises: 007
Create Date: 2026-01-31 00:00:00.000000
"""

from alembic import op
import sqlalchemy as sa

revision = "008"
down_revision = "007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create device_codes table
    op.create_table(
        "device_codes",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("device_code", sa.String(), nullable=False, unique=True),
        sa.Column("user_code", sa.String(), nullable=False, unique=True),
        sa.Column(
            "user_id",
            sa.String(),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=True,
        ),
        sa.Column("status", sa.String(), nullable=False, server_default="pending"),
        sa.Column(
            "cli_api_key_id",
            sa.String(),
            sa.ForeignKey("api_keys.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("approved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("client_name", sa.String(), nullable=True),
        sa.Column("cli_token", sa.String(), nullable=True),
        sa.Column("interval", sa.Integer(), nullable=False, server_default="5"),
    )
    op.create_index("ix_device_codes_device_code", "device_codes", ["device_code"], unique=True)
    op.create_index("ix_device_codes_user_code", "device_codes", ["user_code"], unique=True)
    op.create_index("ix_device_codes_user_id", "device_codes", ["user_id"])
    op.create_index("ix_device_codes_status", "device_codes", ["status"])

    # Add key_type to api_keys
    op.add_column(
        "api_keys",
        sa.Column("key_type", sa.String(), nullable=False, server_default="api"),
    )

    # Add source to usage_records
    op.add_column(
        "usage_records",
        sa.Column("source", sa.String(), nullable=False, server_default="chat"),
    )
    op.create_index("ix_usage_records_source", "usage_records", ["source"])


def downgrade() -> None:
    op.drop_index("ix_usage_records_source", table_name="usage_records")
    op.drop_column("usage_records", "source")
    op.drop_column("api_keys", "key_type")
    op.drop_index("ix_device_codes_status", table_name="device_codes")
    op.drop_index("ix_device_codes_user_id", table_name="device_codes")
    op.drop_index("ix_device_codes_user_code", table_name="device_codes")
    op.drop_index("ix_device_codes_device_code", table_name="device_codes")
    op.drop_table("device_codes")
