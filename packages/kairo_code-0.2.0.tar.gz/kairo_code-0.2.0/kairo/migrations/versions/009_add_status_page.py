"""Add status page tables (incidents, uptime_records)

Revision ID: 009
Revises: 008
Create Date: 2026-01-31 00:00:00.000000
"""

from alembic import op
import sqlalchemy as sa

revision = "009"
down_revision = "008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create incidents table
    op.create_table(
        "incidents",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("title", sa.String(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("severity", sa.String(), nullable=False, server_default="warning"),
        sa.Column("component", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="investigating"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_incidents_component", "incidents", ["component"])
    op.create_index("ix_incidents_status", "incidents", ["status"])
    op.create_index("ix_incidents_started_at", "incidents", ["started_at"])

    # Create uptime_records table
    op.create_table(
        "uptime_records",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("component", sa.String(), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("uptime_percent", sa.Float(), nullable=False, server_default="100.0"),
        sa.Column("incidents_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("avg_latency_ms", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_uptime_records_component", "uptime_records", ["component"])
    op.create_index("ix_uptime_records_date", "uptime_records", ["date"])
    op.create_index(
        "ix_uptime_records_component_date",
        "uptime_records",
        ["component", "date"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_uptime_records_component_date", table_name="uptime_records")
    op.drop_index("ix_uptime_records_date", table_name="uptime_records")
    op.drop_index("ix_uptime_records_component", table_name="uptime_records")
    op.drop_table("uptime_records")
    op.drop_index("ix_incidents_started_at", table_name="incidents")
    op.drop_index("ix_incidents_status", table_name="incidents")
    op.drop_index("ix_incidents_component", table_name="incidents")
    op.drop_table("incidents")
