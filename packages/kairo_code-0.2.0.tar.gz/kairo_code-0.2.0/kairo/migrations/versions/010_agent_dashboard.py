"""Add agent dashboard tables and extend agents

Revision ID: 010
Revises: 009
Create Date: 2026-02-03 00:00:00.000000
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

revision = "010"
down_revision = "009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Extend agents table with dashboard fields
    op.add_column("agents", sa.Column("state", sa.String(), server_default="created"))
    op.add_column("agents", sa.Column("agent_type", sa.String(), server_default="sdk"))
    op.add_column("agents", sa.Column("sdk_version", sa.String(), nullable=True))
    op.add_column("agents", sa.Column("host_info", JSONB, nullable=True))
    op.add_column("agents", sa.Column("last_online_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("agents", sa.Column("first_connected_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("agents", sa.Column("restart_count", sa.Integer(), server_default="0"))
    op.add_column("agents", sa.Column("last_restart_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("agents", sa.Column("last_restart_reason", sa.String(), nullable=True))
    op.add_column("agents", sa.Column("last_error_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("agents", sa.Column("last_error_message", sa.Text(), nullable=True))
    op.add_column("agents", sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True))

    op.create_index("ix_agents_state", "agents", ["state"])
    op.create_index("ix_agents_user_state", "agents", ["user_id", "state"])

    # Add agent_id to api_keys for agent-scoped keys
    op.add_column("api_keys", sa.Column(
        "agent_id",
        sa.String(),
        sa.ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=True
    ))
    op.create_index("ix_api_keys_agent_id", "api_keys", ["agent_id"])

    # Agent metrics - 1 minute granularity (30 day retention)
    op.create_table(
        "agent_metrics_1m",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("bucket_time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("request_count", sa.Integer(), server_default="0"),
        sa.Column("error_count", sa.Integer(), server_default="0"),
        sa.Column("timeout_count", sa.Integer(), server_default="0"),
        sa.Column("input_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("output_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("total_latency_ms", sa.BigInteger(), server_default="0"),
        sa.Column("min_latency_ms", sa.Integer(), nullable=True),
        sa.Column("max_latency_ms", sa.Integer(), nullable=True),
        sa.Column("tool_calls", sa.Integer(), server_default="0"),
        sa.Column("tool_errors", sa.Integer(), server_default="0"),
        sa.Column("tool_breakdown", JSONB, nullable=True),
        sa.Column("model_breakdown", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_metrics_1m_agent_time", "agent_metrics_1m", ["agent_id", "bucket_time"])
    op.create_index("ix_agent_metrics_1m_bucket_time", "agent_metrics_1m", ["bucket_time"])

    # Agent metrics - 1 hour granularity (1 year retention)
    op.create_table(
        "agent_metrics_1h",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("bucket_time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("request_count", sa.Integer(), server_default="0"),
        sa.Column("error_count", sa.Integer(), server_default="0"),
        sa.Column("timeout_count", sa.Integer(), server_default="0"),
        sa.Column("input_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("output_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("total_latency_ms", sa.BigInteger(), server_default="0"),
        sa.Column("min_latency_ms", sa.Integer(), nullable=True),
        sa.Column("max_latency_ms", sa.Integer(), nullable=True),
        sa.Column("p50_latency_ms", sa.Integer(), nullable=True),
        sa.Column("p99_latency_ms", sa.Integer(), nullable=True),
        sa.Column("tool_calls", sa.Integer(), server_default="0"),
        sa.Column("tool_errors", sa.Integer(), server_default="0"),
        sa.Column("tool_breakdown", JSONB, nullable=True),
        sa.Column("model_breakdown", JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_metrics_1h_agent_time", "agent_metrics_1h", ["agent_id", "bucket_time"])
    op.create_index("ix_agent_metrics_1h_bucket_time", "agent_metrics_1h", ["bucket_time"])

    # Agent metrics - daily granularity (2 year retention)
    op.create_table(
        "agent_metrics_daily",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("request_count", sa.Integer(), server_default="0"),
        sa.Column("error_count", sa.Integer(), server_default="0"),
        sa.Column("timeout_count", sa.Integer(), server_default="0"),
        sa.Column("input_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("output_tokens", sa.BigInteger(), server_default="0"),
        sa.Column("total_latency_ms", sa.BigInteger(), server_default="0"),
        sa.Column("min_latency_ms", sa.Integer(), nullable=True),
        sa.Column("max_latency_ms", sa.Integer(), nullable=True),
        sa.Column("avg_latency_ms", sa.Integer(), nullable=True),
        sa.Column("p50_latency_ms", sa.Integer(), nullable=True),
        sa.Column("p99_latency_ms", sa.Integer(), nullable=True),
        sa.Column("tool_calls", sa.Integer(), server_default="0"),
        sa.Column("tool_errors", sa.Integer(), server_default="0"),
        sa.Column("tool_breakdown", JSONB, nullable=True),
        sa.Column("model_breakdown", JSONB, nullable=True),
        sa.Column("uptime_seconds", sa.Integer(), server_default="0"),
        sa.Column("downtime_seconds", sa.Integer(), server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_metrics_daily_agent_date", "agent_metrics_daily", ["agent_id", "date"], unique=True)
    op.create_index("ix_agent_metrics_daily_date", "agent_metrics_daily", ["date"])

    # Agent events log
    op.create_table(
        "agent_events",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_type", sa.String(), nullable=False),
        sa.Column("event_data", JSONB, nullable=True),
        sa.Column("error_type", sa.String(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("session_id", sa.String(), nullable=True),
        sa.Column("client_ip", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_events_agent_time", "agent_events", ["agent_id", "created_at"])
    op.create_index("ix_agent_events_agent_type", "agent_events", ["agent_id", "event_type"])
    op.create_index("ix_agent_events_created_at", "agent_events", ["created_at"])

    # Agent alert configurations
    op.create_table(
        "agent_alert_configs",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.String(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("alert_type", sa.String(), nullable=False),
        sa.Column("metric", sa.String(), nullable=False),
        sa.Column("condition", sa.String(), nullable=False),
        sa.Column("threshold", sa.Float(), nullable=False),
        sa.Column("window_seconds", sa.Integer(), server_default="300"),
        sa.Column("cooldown_seconds", sa.Integer(), server_default="3600"),
        sa.Column("severity", sa.String(), server_default="'warning'"),
        sa.Column("channels", JSONB, server_default="'[\"email\"]'"),
        sa.Column("is_enabled", sa.Boolean(), server_default="true"),
        sa.Column("last_triggered_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_alert_configs_agent", "agent_alert_configs", ["agent_id"])
    op.create_index("ix_agent_alert_configs_user", "agent_alert_configs", ["user_id"])

    # Agent alert history
    op.create_table(
        "agent_alert_history",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("config_id", sa.String(), sa.ForeignKey("agent_alert_configs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("alert_type", sa.String(), nullable=False),
        sa.Column("severity", sa.String(), nullable=False),
        sa.Column("status", sa.String(), server_default="'triggered'"),
        sa.Column("message", sa.Text(), nullable=True),
        sa.Column("trigger_value", sa.Float(), nullable=True),
        sa.Column("threshold_value", sa.Float(), nullable=True),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("acknowledged_by", sa.String(), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_alert_history_agent", "agent_alert_history", ["agent_id"])
    op.create_index("ix_agent_alert_history_config", "agent_alert_history", ["config_id"])
    op.create_index("ix_agent_alert_history_status", "agent_alert_history", ["status"])
    op.create_index("ix_agent_alert_history_created", "agent_alert_history", ["created_at"])

    # Agent setup tokens (one-time tokens for guided wizard)
    op.create_table(
        "agent_setup_tokens",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.String(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_hash", sa.String(), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("used", sa.Boolean(), server_default="false"),
        sa.Column("used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("used_from_ip", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_setup_tokens_agent", "agent_setup_tokens", ["agent_id"])
    op.create_index("ix_agent_setup_tokens_token_hash", "agent_setup_tokens", ["token_hash"], unique=True)

    # Agent pending commands (for restart/stop via heartbeat)
    op.create_table(
        "agent_commands",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("agent_id", sa.String(), sa.ForeignKey("agents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("command_type", sa.String(), nullable=False),
        sa.Column("payload", JSONB, nullable=True),
        sa.Column("issued_by", sa.String(), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("status", sa.String(), server_default="'pending'"),
        sa.Column("dispatched_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_agent_commands_agent_status", "agent_commands", ["agent_id", "status"])
    op.create_index("ix_agent_commands_expires", "agent_commands", ["expires_at"])


def downgrade() -> None:
    # Drop all new tables
    op.drop_table("agent_commands")
    op.drop_table("agent_setup_tokens")
    op.drop_table("agent_alert_history")
    op.drop_table("agent_alert_configs")
    op.drop_table("agent_events")
    op.drop_table("agent_metrics_daily")
    op.drop_table("agent_metrics_1h")
    op.drop_table("agent_metrics_1m")

    # Remove api_keys.agent_id
    op.drop_index("ix_api_keys_agent_id", table_name="api_keys")
    op.drop_column("api_keys", "agent_id")

    # Remove agents columns
    op.drop_index("ix_agents_user_state", table_name="agents")
    op.drop_index("ix_agents_state", table_name="agents")
    op.drop_column("agents", "deleted_at")
    op.drop_column("agents", "last_error_message")
    op.drop_column("agents", "last_error_at")
    op.drop_column("agents", "last_restart_reason")
    op.drop_column("agents", "last_restart_at")
    op.drop_column("agents", "restart_count")
    op.drop_column("agents", "first_connected_at")
    op.drop_column("agents", "last_online_at")
    op.drop_column("agents", "host_info")
    op.drop_column("agents", "sdk_version")
    op.drop_column("agents", "agent_type")
    op.drop_column("agents", "state")
