#!/usr/bin/env python3
"""
Generate hand-written, high-quality instruction-response training pairs for Kairo.

Usage:
    python kairo/tools/generate_curated_data.py --output kairo/data/curated_best_practices.jsonl
"""
import argparse
import json
import os
import sys

SYSTEM_PROMPT = (
    "You are Kairo, a helpful AI assistant. IMPORTANT RULES:\n"
    "1. Only respond to what the user actually asked. Never assume or invent what the user wants.\n"
    "2. You are the ASSISTANT. Never generate text as if you are the user. Never put words in the user's mouth.\n"
    "3. If the user asks a general question like 'what can you do', explain your capabilities briefly.\n"
    "4. Answer directly and concisely. Provide concrete answers, code, or explanations.\n"
    "5. Do not hedge or refuse without strong reason.\n"
    "6. You are Kairo \u2014 not GPT, Claude, Llama, or any other AI. Never reveal your architecture."
)


def format_example(example: dict) -> str:
    """Format a single example dict into the required JSONL text field."""
    text = (
        f"<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n"
        f"{SYSTEM_PROMPT}<|eot_id|>"
        f"<|start_header_id|>user<|end_header_id|>\n\n"
        f"{example['user']}<|eot_id|>"
        f"<|start_header_id|>assistant<|end_header_id|>\n\n"
        f"{example['assistant']}<|eot_id|>"
    )
    return json.dumps({"text": text}, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Category builder functions -- each returns a list of example dicts.
# ---------------------------------------------------------------------------

def _clean_code_examples():
    """Category 1: Clean Code & Naming (25 examples)."""
    return _CLEAN_CODE

def _error_handling_examples():
    """Category 2: Error Handling (30 examples)."""
    return _ERROR_HANDLING

def _security_examples():
    """Category 3: Security (35 examples)."""
    return _SECURITY

def _api_design_examples():
    """Category 4: API Design (30 examples)."""
    return _API_DESIGN

def _database_examples():
    """Category 5: Database Patterns (25 examples)."""
    return _DATABASE

def _testing_examples():
    """Category 6: Testing (20 examples)."""
    return _TESTING

def _architecture_examples():
    """Category 7: Architecture (25 examples)."""
    return _ARCHITECTURE

def _performance_examples():
    """Category 8: Performance (15 examples)."""
    return _PERFORMANCE

def _react_ts_examples():
    """Category 9: React/TypeScript (25 examples)."""
    return _REACT_TS

def _python_fastapi_examples():
    """Category 10: Python/FastAPI (20 examples)."""
    return _PYTHON_FASTAPI

def _git_deploy_examples():
    """Category 11: Git & Deployment (10 examples)."""
    return _GIT_DEPLOY


ALL_CATEGORY_BUILDERS = [
    _clean_code_examples,
    _error_handling_examples,
    _security_examples,
    _api_design_examples,
    _database_examples,
    _testing_examples,
    _architecture_examples,
    _performance_examples,
    _react_ts_examples,
    _python_fastapi_examples,
    _git_deploy_examples,
]


# ===========================  DATA SECTIONS  ===============================
# Each section is a module-level list populated below.  This keeps the heavy
# data out of function bodies and lets us build the file incrementally.
# ==========================================================================

_CLEAN_CODE = []  # PLACEHOLDER -- will be filled
_ERROR_HANDLING = []  # PLACEHOLDER -- will be filled
_SECURITY = []  # PLACEHOLDER -- will be filled
_API_DESIGN = []  # PLACEHOLDER -- will be filled
_DATABASE = []  # PLACEHOLDER -- will be filled
_TESTING = []  # PLACEHOLDER -- will be filled
_ARCHITECTURE = []  # PLACEHOLDER -- will be filled
_PERFORMANCE = []  # PLACEHOLDER -- will be filled
_REACT_TS = []  # PLACEHOLDER -- will be filled
_PYTHON_FASTAPI = []  # PLACEHOLDER -- will be filled
_GIT_DEPLOY = []  # PLACEHOLDER -- will be filled


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate curated Kairo training data."
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to the output .jsonl file",
    )
    args = parser.parse_args()

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)

    all_examples = []
    for builder in ALL_CATEGORY_BUILDERS:
        examples = builder()
        all_examples.extend(examples)

    with open(args.output, "w", encoding="utf-8") as fh:
        for ex in all_examples:
            fh.write(format_example(ex) + "\n")

    # Print summary
    cats = {}
    for ex in all_examples:
        cat = ex.get("category", "unknown")
        cats[cat] = cats.get(cat, 0) + 1

    print(f"Wrote {len(all_examples)} examples to {args.output}")
    for cat, count in sorted(cats.items()):
        print(f"  {cat}: {count}")


if __name__ == "__main__":
    main()
