#!/usr/bin/env python3
"""Combine filtered Claude data with curated best-practices data into final training set.

Steps:
1. Load both datasets
2. Deduplicate by Jaccard similarity of user messages (threshold 0.85)
3. Shuffle with seed for reproducibility
4. Split 90/10 train/val
5. Write output

Usage:
    python kairo/tools/mix_training_data.py \
        --curated kairo/data/curated_best_practices.jsonl \
        --filtered kairo/data/claude_filtered.jsonl \
        --output-dir kairo/data \
        --val-ratio 0.1 \
        --seed 42
"""

import argparse
import json
import math
import os
import random
import re
import sys


def load_jsonl(path: str) -> list[dict]:
    """Load a JSONL file into a list of dicts."""
    examples = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                examples.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return examples


def extract_user_messages(text: str) -> str:
    """Extract concatenated user messages from a Llama 3.1 formatted example."""
    parts = re.split(
        r"<\|start_header_id\|>(user|assistant|system)<\|end_header_id\|>\n\n", text
    )
    user_texts = []
    i = 1
    while i + 1 < len(parts):
        role = parts[i]
        content = parts[i + 1].replace("<|eot_id|>", "").strip()
        if role == "user" and content:
            user_texts.append(content)
        i += 2
    return " ".join(user_texts)


def tokenize(text: str) -> set[str]:
    """Simple word-level tokenization for Jaccard similarity."""
    return set(re.findall(r"\w+", text.lower()))


def jaccard_similarity(a: set[str], b: set[str]) -> float:
    """Compute Jaccard similarity between two token sets."""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def deduplicate(examples: list[dict], threshold: float = 0.85) -> list[dict]:
    """Remove near-duplicate examples based on Jaccard similarity of user messages.

    Uses a simple O(n^2) approach which is fine for <1000 examples.
    """
    if not examples:
        return []

    # Pre-compute user message tokens for each example
    tokenized = []
    for ex in examples:
        text = ex.get("text", "")
        user_msg = extract_user_messages(text)
        tokens = tokenize(user_msg)
        tokenized.append(tokens)

    kept_indices = []
    for i in range(len(examples)):
        is_dup = False
        for j in kept_indices:
            sim = jaccard_similarity(tokenized[i], tokenized[j])
            if sim >= threshold:
                is_dup = True
                break
        if not is_dup:
            kept_indices.append(i)

    return [examples[i] for i in kept_indices]


def write_jsonl(path: str, examples: list[dict]) -> None:
    """Write examples to a JSONL file."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for ex in examples:
            f.write(json.dumps(ex) + "\n")


def detect_category(text: str) -> str:
    """Try to detect the category of a curated example from content signals."""
    text_lower = text.lower()

    category_signals = [
        ("security", ["sql injection", "xss", "csrf", "auth", "password", "hash",
                       "sanitiz", "owasp", "vulnerab", "token", "jwt", "cors"]),
        ("error_handling", ["try", "except", "exception", "error handling",
                            "error boundar", "graceful", "retry"]),
        ("api_design", ["rest", "endpoint", "status code", "pagination",
                         "pydantic", "fastapi", "router", "http method"]),
        ("database", ["sqlalchemy", "migration", "alembic", "query", "index",
                       "n+1", "transaction", "connection pool"]),
        ("testing", ["pytest", "test_", "mock", "fixture", "assert",
                      "coverage", "test client"]),
        ("architecture", ["solid", "separation of concerns", "dependency injection",
                           "repository pattern", "service layer", "clean arch"]),
        ("performance", ["cache", "async", "batch", "optimi", "profil",
                          "lazy load", "background task"]),
        ("react_typescript", ["react", "component", "usestate", "useeffect",
                               "typescript", "interface", "props", "hook"]),
        ("python_fastapi", ["type hint", "pydantic", "fastapi", "middleware",
                             "lifespan", "depends"]),
        ("git_deployment", ["commit", "branch", "docker", "ci/cd", "deploy",
                             "dockerfile", "health check"]),
        ("clean_code", ["naming", "dry", "readab", "refactor", "function length",
                         "single responsib", "magic number"]),
    ]

    for category, signals in category_signals:
        matches = sum(1 for s in signals if s in text_lower)
        if matches >= 2:
            return category

    return "other"


def main():
    parser = argparse.ArgumentParser(
        description="Mix filtered Claude data with curated best-practices data"
    )
    parser.add_argument(
        "--curated",
        default="kairo/data/curated_best_practices.jsonl",
        help="Curated best-practices JSONL file",
    )
    parser.add_argument(
        "--filtered",
        default="kairo/data/claude_filtered.jsonl",
        help="Filtered Claude training JSONL file",
    )
    parser.add_argument(
        "--output-dir",
        default="kairo/data",
        help="Output directory (default: kairo/data)",
    )
    parser.add_argument(
        "--val-ratio",
        type=float,
        default=0.1,
        help="Validation set ratio (default: 0.1)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for shuffling (default: 42)",
    )
    parser.add_argument(
        "--dedup-threshold",
        type=float,
        default=0.85,
        help="Jaccard similarity threshold for deduplication (default: 0.85)",
    )
    args = parser.parse_args()

    # Load datasets
    curated = load_jsonl(args.curated)
    filtered = load_jsonl(args.filtered)
    print(f"Loaded {len(curated)} curated examples from {args.curated}")
    print(f"Loaded {len(filtered)} filtered examples from {args.filtered}")

    # Tag source for stats
    for ex in curated:
        ex["_source"] = "curated"
    for ex in filtered:
        ex["_source"] = "filtered"

    # Combine
    combined = curated + filtered
    print(f"Combined: {len(combined)} examples")

    # Deduplicate
    deduped = deduplicate(combined, threshold=args.dedup_threshold)
    removed = len(combined) - len(deduped)
    print(f"After dedup (threshold={args.dedup_threshold}): {len(deduped)} ({removed} removed)")

    # Shuffle
    rng = random.Random(args.seed)
    rng.shuffle(deduped)

    # Split
    val_count = max(1, math.floor(len(deduped) * args.val_ratio))
    val_set = deduped[:val_count]
    train_set = deduped[val_count:]

    # Collect stats before stripping metadata
    source_counts = {"curated": 0, "filtered": 0}
    category_counts = {}
    for ex in deduped:
        src = ex.get("_source", "unknown")
        source_counts[src] = source_counts.get(src, 0) + 1
        cat = detect_category(ex.get("text", ""))
        category_counts[cat] = category_counts.get(cat, 0) + 1

    train_sources = {"curated": 0, "filtered": 0}
    for ex in train_set:
        src = ex.get("_source", "unknown")
        train_sources[src] = train_sources.get(src, 0) + 1

    val_sources = {"curated": 0, "filtered": 0}
    for ex in val_set:
        src = ex.get("_source", "unknown")
        val_sources[src] = val_sources.get(src, 0) + 1

    # Strip internal metadata before writing
    for ex in deduped:
        ex.pop("_source", None)

    # Write output
    train_path = os.path.join(args.output_dir, "final_train.jsonl")
    val_path = os.path.join(args.output_dir, "final_val.jsonl")
    stats_path = os.path.join(args.output_dir, "mixing_stats.json")

    write_jsonl(train_path, train_set)
    write_jsonl(val_path, val_set)

    # Write stats
    stats = {
        "input": {
            "curated": len(curated),
            "filtered": len(filtered),
            "combined": len(combined),
        },
        "deduplication": {
            "threshold": args.dedup_threshold,
            "removed": removed,
            "after_dedup": len(deduped),
        },
        "split": {
            "seed": args.seed,
            "val_ratio": args.val_ratio,
            "train_count": len(train_set),
            "val_count": len(val_set),
        },
        "source_distribution": {
            "total": source_counts,
            "train": train_sources,
            "val": val_sources,
        },
        "category_distribution": {
            k: v for k, v in sorted(category_counts.items(), key=lambda x: -x[1])
        },
    }

    os.makedirs(os.path.dirname(stats_path) or ".", exist_ok=True)
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

    # Print summary
    print(f"\nMixing complete!")
    print(f"  Train: {len(train_set)} examples → {train_path}")
    print(f"  Val:   {len(val_set)} examples → {val_path}")
    print(f"  Stats: {stats_path}")
    print(f"\nSource distribution:")
    print(f"  Curated:  {source_counts.get('curated', 0)}")
    print(f"  Filtered: {source_counts.get('filtered', 0)}")
    print(f"\nCategory distribution:")
    for cat, count in sorted(category_counts.items(), key=lambda x: -x[1]):
        print(f"  {cat}: {count}")


if __name__ == "__main__":
    main()
