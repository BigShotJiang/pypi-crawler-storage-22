"""Kairo Code - AI Coding Assistant by Kairon Labs"""

__version__ = "0.3.0"
