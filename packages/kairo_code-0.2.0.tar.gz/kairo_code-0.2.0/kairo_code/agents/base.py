"""Base agent class with robust tool loop execution"""

import hashlib
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Generator, Callable
from enum import Enum

from ..llm import LLM
from ..config import Config
from ..tools.base import (
    ToolRegistry, parse_tool_calls, ToolResult,
    format_tool_error, ToolParseResult, ParsedToolCall
)
from ..logging_config import get_agent_logger, log_tool_call

logger = get_agent_logger()


class AgentStatus(Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    ERROR = "error"
    MAX_ITERATIONS = "max_iterations"


@dataclass
class AgentEvent:
    """Structured event from agent execution."""
    type: str  # "thinking", "tool_start", "tool_result", "text", "error", "done"
    content: str = ""
    tool_name: str | None = None
    tool_params: dict | None = None
    success: bool = True


@dataclass
class AgentMessage:
    """A message in the agent's conversation."""
    role: str  # "user", "assistant", "tool", "error"
    content: str
    tool_name: str | None = None
    tool_result: ToolResult | None = None
    thinking: str | None = None


@dataclass
class AgentState:
    """Current state of an agent execution."""
    messages: list[AgentMessage] = field(default_factory=list)
    tool_calls_made: int = 0
    failed_parses: int = 0
    retries: int = 0
    status: AgentStatus = AgentStatus.RUNNING
    final_response: str = ""
    thinking_log: list[str] = field(default_factory=list)

    # Context tracking (approximate)
    estimated_tokens: int = 0

    # Track recent tool calls to prevent loops: (tool_name, key_param) -> success
    recent_tool_calls: dict[tuple[str, str], bool] = field(default_factory=dict)

    # Track recent file writes to detect identical content loops
    recent_file_hashes: dict[str, str] = field(default_factory=dict)  # path -> content_hash


class Agent(ABC):
    """
    Base agent class that can execute multi-step tasks using tools.

    Features:
    - Robust tool parsing with multiple format support
    - Retry mechanism with error feedback
    - Thinking/scratchpad extraction
    - Context window tracking
    - Configurable confirmation for destructive actions
    """

    name: str = "base_agent"
    description: str = "Base agent"
    max_iterations: int = 10
    max_retries: int = 3  # Retries per malformed tool call
    max_context_tokens: int = 6000  # Conservative limit for 7B models

    # Override in subclasses
    require_confirmation: list[str] = ["write_file", "bash"]

    def __init__(
        self,
        llm: LLM,
        tools: ToolRegistry,
        on_confirm: Callable[[str], bool] | None = None
    ):
        self.llm = llm
        self.tools = tools
        self.on_confirm = on_confirm  # Callback for confirmation prompts
        self.state = AgentState()
        self.config = Config()  # Load config for safety settings

    @abstractmethod
    def get_system_prompt(self) -> str:
        """Get the system prompt for this agent."""
        pass

    def get_tool_examples(self) -> str:
        """Get few-shot examples of tool usage. Override in subclasses."""
        return ""

    def run_events(self, task: str) -> Generator[AgentEvent, None, None]:
        """
        Run the agent and yield structured events.

        This is the preferred method for UI rendering - it yields clean events
        instead of raw LLM chunks.
        """
        logger.info(f"=== Agent '{self.name}' starting task ===")
        logger.info(f"Task: {task[:200]}...")

        self.state = AgentState()
        self.state.messages.append(AgentMessage(role="user", content=task))
        self._update_token_estimate()

        consecutive_failures = 0
        max_iter = self.config.max_iterations or self.max_iterations
        accumulated_text = []

        iteration = 0
        while iteration < max_iter:
            iteration += 1
            logger.info(f"--- Iteration {iteration}/{max_iter} ---")

            # Check context limits
            if self.state.estimated_tokens > self.max_context_tokens:
                logger.warning(f"Context limit approaching: {self.state.estimated_tokens} tokens")
                self._summarize_history()

            # Build messages for LLM
            messages = self._build_messages()

            # Notify UI that we're waiting for LLM
            yield AgentEvent(type="thinking", content=f"Thinking... (iteration {iteration})")

            # Get LLM response (don't stream to UI - collect it)
            response_chunks = []
            llm_start = time.time()
            try:
                for chunk in self.llm.chat(messages, stream=True):
                    response_chunks.append(chunk)
                llm_elapsed = time.time() - llm_start
                logger.info(f"LLM response received in {llm_elapsed:.2f}s")
            except Exception as e:
                logger.error(f"LLM Error: {e}")
                yield AgentEvent(type="error", content=str(e))
                self.state.status = AgentStatus.ERROR
                break

            full_response = "".join(response_chunks)

            # Parse the response for tool calls and thinking
            parse_result = parse_tool_calls(full_response)

            # Add assistant message to state
            self.state.messages.append(
                AgentMessage(
                    role="assistant",
                    content=full_response,
                    thinking=parse_result.thinking_content if parse_result.has_thinking else None
                )
            )

            # Handle parse errors
            if parse_result.parse_errors and not parse_result.calls:
                consecutive_failures += 1
                if consecutive_failures >= self.max_retries:
                    yield AgentEvent(type="error", content="Max retries reached")
                    self.state.status = AgentStatus.ERROR
                    break
                error_msg = format_tool_error(f"Failed to parse: {parse_result.parse_errors}")
                self.state.messages.append(AgentMessage(role="error", content=error_msg))
                continue

            # No tool calls - agent is done
            if not parse_result.calls:
                # Clean the response and yield as final text
                cleaned = self._clean_response_text(full_response)
                yield AgentEvent(type="text", content=cleaned)
                self.state.status = AgentStatus.COMPLETED
                self.state.final_response = full_response
                break

            # Reset failures on successful parse
            consecutive_failures = 0

            # Execute tool calls
            for call in parse_result.calls:
                # Yield tool start event
                yield AgentEvent(
                    type="tool_start",
                    tool_name=call.tool_name,
                    tool_params=call.params
                )

                result = self._execute_tool_call(call)

                if result is None:
                    yield AgentEvent(type="error", content="Action cancelled by user")
                    continue

                # Yield tool result event
                yield AgentEvent(
                    type="tool_result",
                    tool_name=call.tool_name,
                    content=result.output[:500] if result.output else "",
                    success=result.success
                )

                # Add result to messages
                if result.success:
                    content = result.output
                else:
                    content = f"Error: {result.error}"
                    if result.output:
                        content += f"\n\nOutput:\n{result.output}"

                self.state.messages.append(
                    AgentMessage(
                        role="tool",
                        content=content,
                        tool_name=call.tool_name,
                        tool_result=result,
                    )
                )

            self._update_token_estimate()

        # Check if we hit max iterations
        if iteration >= max_iter and self.state.status == AgentStatus.RUNNING:
            self.state.status = AgentStatus.MAX_ITERATIONS
            yield AgentEvent(type="error", content="Max iterations reached")

        yield AgentEvent(type="done")

    def _clean_response_text(self, text: str) -> str:
        """Remove tool calls and thinking from response text."""
        import re
        # Remove thinking blocks
        text = re.sub(r'<thinking>.*?</thinking>', '', text, flags=re.DOTALL)
        # Remove tool calls
        text = re.sub(r'<tool>.*?</tool>\s*<params>.*?</params>', '', text, flags=re.DOTALL)
        # Clean up extra whitespace
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()

    def _execute_tool_call(self, call: ParsedToolCall) -> ToolResult | None:
        """Execute a single tool call with optional confirmation."""
        logger.info(f"Executing tool: {call.tool_name}")
        logger.debug(f"Tool params: {call.params}")

        # Check for duplicate tool calls (especially web_search loops)
        key_param = self._get_tool_key_param(call)
        call_signature = (call.tool_name, key_param)

        # Check if this is a duplicate
        if call_signature in self.state.recent_tool_calls:
            prev_success = self.state.recent_tool_calls[call_signature]

            # For web_search: always block duplicates (main source of loops)
            # For bash: allow retry if previous attempt failed/timed out
            if call.tool_name == "web_search" or prev_success:
                logger.warning(f"Duplicate tool call detected: {call.tool_name}({key_param})")
                return ToolResult(
                    success=True,
                    output=f"[Already executed {call.tool_name} with similar parameters. Move on to the next step - output your results or plan.]",
                    error=None
                )
            else:
                logger.info(f"Allowing retry of failed {call.tool_name}({key_param})")

        tool = self.tools.get(call.tool_name)

        if not tool:
            # Try to suggest correct tool name
            available = self.tools.get_tool_names()
            suggestion = f"Available tools: {', '.join(available)}"
            logger.error(f"Unknown tool: {call.tool_name}")
            return ToolResult(
                success=False,
                output="",
                error=f"Unknown tool '{call.tool_name}'. {suggestion}"
            )

        # Safety check for bash commands
        if call.tool_name == "bash":
            command = call.params.get("command", "")
            allowed, reason = self.config.is_command_allowed(command)
            if not allowed:
                logger.warning(f"Blocked bash command: {command} - {reason}")
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Command blocked: {reason}"
                )

        # Check for identical file content (writing same thing repeatedly)
        if call.tool_name == "write_file":
            path = call.params.get("path", "")
            content = call.params.get("content", "")
            content_hash = hashlib.md5(content.encode()).hexdigest()

            if path in self.state.recent_file_hashes:
                if self.state.recent_file_hashes[path] == content_hash:
                    logger.warning(f"Identical content write detected for {path}")
                    return ToolResult(
                        success=True,
                        output=f"[File {path} already has this exact content. Make DIFFERENT changes or move to the next step.]",
                        error=None
                    )

            # Track the content hash
            self.state.recent_file_hashes[path] = content_hash

        # Check if confirmation is required (respecting auto_approve settings)
        needs_confirm = tool.name in self.require_confirmation
        auto_approved = self.config.should_auto_approve(tool.name)

        if self.on_confirm and needs_confirm and not auto_approved:
            params_preview = str(call.params)[:100]
            logger.debug(f"Requesting user confirmation for {tool.name}")
            if not self.on_confirm(f"Execute {tool.name}({params_preview})?"):
                logger.info(f"User denied execution of {tool.name}")
                return None

        # Execute the tool
        try:
            self.state.tool_calls_made += 1
            start_time = time.time()
            logger.debug(f"Starting tool execution: {tool.name}")
            result = tool.execute(**call.params)
            elapsed = time.time() - start_time
            logger.info(f"Tool {tool.name} completed in {elapsed:.2f}s (success={result.success})")
            log_tool_call(tool.name, call.params, result)

            # Track success for duplicate detection (allows retry on failure)
            self.state.recent_tool_calls[call_signature] = result.success
            return result
        except TypeError as e:
            # Wrong parameters
            logger.error(f"Invalid parameters for {tool.name}: {e}")
            self.state.recent_tool_calls[call_signature] = False
            return ToolResult(
                success=False,
                output="",
                error=f"Invalid parameters for {tool.name}: {e}"
            )
        except Exception as e:
            logger.error(f"Tool execution failed: {e}")
            self.state.recent_tool_calls[call_signature] = False
            return ToolResult(
                success=False,
                output="",
                error=f"Tool execution failed: {e}"
            )

    def _get_tool_key_param(self, call: ParsedToolCall) -> str:
        """Extract the key parameter for duplicate detection.

        Only dedupe tools that cause loops when repeated:
        - web_search: same query is definitely a loop
        - bash: same command might be intentional retry, but limit it

        Don't dedupe:
        - write_file: updating same file with different content is normal
        - read_file: re-reading files is often needed
        """
        params = call.params

        # Only dedupe web_search (the main source of loops)
        if call.tool_name == "web_search":
            query = params.get("query", "")
            return query.lower().strip()

        # For bash, only dedupe exact same command
        if call.tool_name == "bash":
            cmd = params.get("command", "")
            return cmd.strip()

        # Don't dedupe other tools - return unique value each time
        import time
        return f"{call.tool_name}_{time.time()}"

    def _build_messages(self) -> list[dict]:
        """Build message list for LLM with system prompt and examples."""
        system_content = self.get_system_prompt()

        # Add tool examples if available
        examples = self.get_tool_examples()
        if examples:
            system_content += f"\n\n## Examples\n{examples}"

        messages = [{"role": "system", "content": system_content}]

        # Critical instruction reminder to prepend to first user message
        # (Some models ignore system prompts, so repeat key rules here)
        instruction_reminder = """[INSTRUCTION: You MUST use tools. Do NOT write code in markdown blocks.
Use this format: <tool>tool_name</tool><params>{"key": "value"}</params>
Do ONE web_search at most, then immediately start writing code with write_file.]

"""

        for i, msg in enumerate(self.state.messages):
            if msg.role == "tool":
                # Format tool results clearly
                content = f"[Tool Result: {msg.tool_name}]\n{msg.content}"
                messages.append({"role": "user", "content": content})
            elif msg.role == "error":
                # Error feedback
                messages.append({"role": "user", "content": msg.content})
            elif msg.role == "user" and i == 0:
                # Prepend instruction reminder to first user message
                messages.append({"role": "user", "content": instruction_reminder + msg.content})
            else:
                messages.append({"role": msg.role, "content": msg.content})

        return messages

    def _update_token_estimate(self) -> None:
        """Estimate current context size (rough approximation)."""
        total_chars = sum(len(msg.content) for msg in self.state.messages)
        # Rough estimate: 4 chars per token
        self.state.estimated_tokens = total_chars // 4

    def _summarize_history(self) -> None:
        """Summarize older messages to reduce context size."""
        if len(self.state.messages) <= 4:
            return

        # Keep first message (original task) and last 3 messages
        # Summarize the middle
        to_summarize = self.state.messages[1:-3]

        if not to_summarize:
            return

        # Create a summary
        summary_parts = []
        for msg in to_summarize:
            if msg.role == "tool":
                summary_parts.append(f"- Used {msg.tool_name}")
            elif msg.role == "assistant" and msg.thinking:
                summary_parts.append(f"- Thought: {msg.thinking[:100]}...")

        summary = "[Previous actions summary]\n" + "\n".join(summary_parts)

        # Replace middle messages with summary
        self.state.messages = (
            [self.state.messages[0]]
            + [AgentMessage(role="user", content=summary)]
            + self.state.messages[-3:]
        )

        self._update_token_estimate()
