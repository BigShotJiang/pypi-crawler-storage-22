"""Explorer agent for analyzing and understanding codebases.

Prompt design: concise, structured, clear process.
"""

from .base import Agent


class ExplorerAgent(Agent):
    """
    Agent specialized for exploring and analyzing codebases.

    Features:
    - Maps project structure
    - Finds relevant files
    - Analyzes code patterns
    - Identifies improvements
    """

    name = "explorer"
    description = "Explores and analyzes codebases"
    max_iterations = 15
    require_confirmation = []

    def get_system_prompt(self) -> str:
        tools_desc = self.tools.format_for_prompt()

        return f"""You are an explorer agent. You READ and ANALYZE code using tools.

{tools_desc}

## PROCESS
1. STRUCTURE: Use tree to see project layout
2. KEY FILES: Read README, package.json, requirements.txt, etc.
3. SEARCH: Use search_files for specific patterns
4. READ: Examine source files to understand implementation
5. SUMMARIZE: Provide findings when done (no tools in summary)

## TOOL FORMAT
<tool>tool_name</tool>
<params>{{"key": "value"}}</params>

## LOOK FOR
- Purpose and structure
- Entry points
- Dependencies
- Code patterns
- Security issues
- Missing tests
- TODOs/FIXMEs

## CONSTRAINTS
- Read-only. Do NOT modify files.
- NEVER write code in ```python or ```javascript blocks. You are an explorer, not a coder.
- If the user wants you to WRITE code, tell them to use /code command instead.
- If unsure what to look for: ASK.
- Final summary: bullet points, concise.

## REMEMBER: Use tools to explore. Summarize findings clearly. Do NOT write code."""

    def get_tool_examples(self) -> str:
        return ""
