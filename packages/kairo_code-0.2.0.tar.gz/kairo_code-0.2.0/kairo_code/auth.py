"""Browser-based authentication for Kairo Code CLI.

Implements RFC 8628 Device Code flow:
1. Request a device code from the Kairo backend
2. Open browser for user approval
3. Poll for token until approved/denied/expired
4. Save credentials locally with restrictive permissions
"""

import sys
import time
import webbrowser
from pathlib import Path
from typing import Any

import httpx
import yaml
from rich.console import Console
from rich.panel import Panel

console = Console()

CREDENTIALS_DIR = Path.home() / ".kairo_code"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.yaml"


# ---------------------------------------------------------------------------
# Credential storage
# ---------------------------------------------------------------------------

def load_credentials() -> dict[str, Any] | None:
    """Load saved CLI credentials. Returns dict with api_key, email, plan or None."""
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        with open(CREDENTIALS_FILE) as f:
            data = yaml.safe_load(f)
        if data and data.get("api_key"):
            return data
    except Exception:
        pass
    return None


def save_credentials(api_key: str, email: str, plan: str) -> None:
    """Save CLI credentials with restrictive permissions (0600)."""
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    data = {"api_key": api_key, "email": email, "plan": plan}
    with open(CREDENTIALS_FILE, "w") as f:
        yaml.dump(data, f, default_flow_style=False)
    CREDENTIALS_FILE.chmod(0o600)


def clear_credentials() -> None:
    """Delete saved credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_api_key() -> str | None:
    """Get saved API key, or None if not authenticated."""
    creds = load_credentials()
    return creds["api_key"] if creds else None


# ---------------------------------------------------------------------------
# Device code authentication flow
# ---------------------------------------------------------------------------

def _derive_base_url(cloud_endpoint: str) -> str:
    """Strip /v1 suffix to get the base API URL."""
    base_url = cloud_endpoint.rstrip("/")
    if base_url.endswith("/v1"):
        base_url = base_url[:-3]
    return base_url


def _request_device_code(base_url: str) -> dict | None:
    """POST /api/auth/device/code to obtain a device code."""
    try:
        resp = httpx.post(
            f"{base_url}/api/auth/device/code",
            json={"client_name": "kairo-code"},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        console.print(f"[red]Failed to start authentication: {e}[/]")
        return None


def _display_verification_prompt(verification_uri_complete: str, user_code: str) -> None:
    """Show the verification URL and user code, then open the browser."""
    console.print()
    console.print(Panel(
        f"[bold]To authenticate, open this URL:[/]\n\n"
        f"  [cyan underline]{verification_uri_complete}[/]\n\n"
        f"[bold]Then confirm this code:[/]  [bold yellow]{user_code}[/]",
        title="[bold]Kairo Code -- Authentication[/]",
        border_style="cyan",
        padding=(1, 3),
    ))
    console.print()

    try:
        webbrowser.open(verification_uri_complete)
        console.print("[dim]Browser opened. If it didn't open, copy the URL above.[/]")
    except Exception:
        console.print("[dim]Copy the URL above and open it in your browser.[/]")


def _poll_for_token(base_url: str, device_code: str, expires_in: int, interval: int) -> dict | None:
    """Poll /api/auth/device/token until approval, denial, or timeout.

    Returns the token response dict on success, or None on failure.
    """
    console.print("[dim]Waiting for approval... (press Ctrl+C to cancel)[/]\n")
    deadline = time.time() + expires_in

    try:
        while time.time() < deadline:
            time.sleep(interval)

            try:
                resp = httpx.post(
                    f"{base_url}/api/auth/device/token",
                    json={"device_code": device_code},
                    timeout=10,
                )
            except Exception:
                continue  # Network error, retry

            if resp.status_code == 200:
                return resp.json()

            if resp.status_code == 400:
                error_code = _extract_error_code(resp)

                if error_code == "authorization_pending":
                    continue
                elif error_code == "slow_down":
                    interval += 1
                    continue
                elif error_code == "expired_token":
                    console.print("[red]Authentication expired. Please try again.[/]")
                    return None
                elif error_code == "access_denied":
                    console.print("[red]Access denied. Kairo Code requires a Max plan.[/]")
                    return None

        console.print("[red]Authentication timed out. Please try again.[/]")
        return None

    except KeyboardInterrupt:
        console.print("\n[dim]Authentication cancelled.[/]")
        return None


def _extract_error_code(resp: httpx.Response) -> str:
    """Extract the error code string from a 400 response."""
    try:
        error_data = resp.json()
        error = error_data.get("detail", {})
        if isinstance(error, dict):
            return error.get("error", "")
        return str(error)
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def authenticate(cloud_endpoint: str) -> str | None:
    """Run the full device code auth flow.

    Returns the API key on success, or None on failure/cancellation.
    """
    base_url = _derive_base_url(cloud_endpoint)

    # Step 1: Request device code
    data = _request_device_code(base_url)
    if data is None:
        return None

    device_code = data["device_code"]
    user_code = data["user_code"]
    verification_uri_complete = data["verification_uri_complete"]
    expires_in = data["expires_in"]
    interval = data["interval"]

    # Step 2: Display prompt and open browser
    _display_verification_prompt(verification_uri_complete, user_code)

    # Step 3: Poll for approval
    token_data = _poll_for_token(base_url, device_code, expires_in, interval)
    if token_data is None:
        return None

    api_key = token_data["access_token"]
    email = token_data.get("email", "")
    plan = token_data.get("plan", "max")

    save_credentials(api_key, email, plan)
    console.print(f"[green bold]Authenticated as {email}[/]")
    console.print()
    return api_key


def ensure_authenticated(cloud_endpoint: str) -> str | None:
    """Check for saved credentials or trigger auth flow. Returns api_key or None."""
    creds = load_credentials()
    if creds and creds.get("api_key"):
        base_url = _derive_base_url(cloud_endpoint)
        try:
            resp = httpx.get(
                f"{base_url}/v1/models",
                headers={"Authorization": f"Bearer {creds['api_key']}"},
                timeout=5,
            )
            if resp.status_code == 200:
                console.print(f"[dim]Authenticated as {creds.get('email', 'unknown')}[/]")
                return creds["api_key"]
        except Exception:
            pass

        console.print("[yellow]Saved credentials are invalid. Re-authenticating...[/]")
        clear_credentials()

    return authenticate(cloud_endpoint)
