"""Configuration loader for Kairo Code"""

import os
from pathlib import Path
from typing import Any

import yaml


def find_config() -> Path:
    """Find config.yaml in current directory or parent directories."""
    current = Path.cwd()

    # Check current and parent directories
    for path in [current] + list(current.parents):
        config_path = path / "config.yaml"
        if config_path.exists():
            return config_path

    # Fall back to package directory
    package_dir = Path(__file__).parent.parent
    config_path = package_dir / "config.yaml"
    if config_path.exists():
        return config_path

    raise FileNotFoundError("config.yaml not found")


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load configuration from YAML file."""
    if config_path is None:
        config_path = find_config()

    with open(config_path) as f:
        config = yaml.safe_load(f)

    # Override with environment variables if set
    if os.getenv("KAIRO_CLOUD_ENDPOINT"):
        config.setdefault("cloud", {})["endpoint"] = os.getenv("KAIRO_CLOUD_ENDPOINT")

    if os.getenv("KAIRO_CLOUD_API_KEY"):
        config.setdefault("cloud", {})["api_key"] = os.getenv("KAIRO_CLOUD_API_KEY")

    if os.getenv("KAIRO_ROUTER_MODEL"):
        config["models"]["router"] = os.getenv("KAIRO_ROUTER_MODEL")

    if os.getenv("KAIRO_CODER_MODEL"):
        config["models"]["coder"] = os.getenv("KAIRO_CODER_MODEL")

    return config


class Config:
    """Configuration singleton for easy access throughout the app."""

    _instance: "Config | None" = None

    def __new__(cls) -> "Config":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._config = load_config()
        return cls._instance

    @property
    def router_model(self) -> str:
        return self._config["models"]["router"]

    @property
    def coder_model(self) -> str:
        return self._config["models"]["coder"]

    @property
    def chat_model(self) -> str:
        return self._config["models"]["chat"]

    @property
    def cloud_endpoint(self) -> str:
        return self._config.get("cloud", {}).get("endpoint", "http://localhost:8000/v1")

    @property
    def cloud_api_key(self) -> str:
        # Priority: env var / config file > saved CLI credentials > placeholder
        key = self._config.get("cloud", {}).get("api_key", "")
        if key:
            return key
        # Check saved CLI credentials
        from kairo_code.auth import get_api_key
        cli_key = get_api_key()
        if cli_key:
            return cli_key
        # OpenAI client requires a non-empty string
        return "not-needed"

    @property
    def cloud_timeout(self) -> int:
        return self._config.get("cloud", {}).get("timeout", 120)

    @property
    def search_max_results(self) -> int:
        return self._config["search"]["max_results"]

    @property
    def max_history(self) -> int:
        return self._config["conversation"]["max_history"]

    @property
    def system_prompt(self) -> str:
        return self._config["conversation"]["system_prompt"]

    @property
    def router_prompt(self) -> str:
        return self._config["router"]["system_prompt"]

    # Safety settings
    @property
    def auto_approve(self) -> bool:
        return self._config.get("safety", {}).get("auto_approve", False)

    @property
    def auto_approve_tools(self) -> list[str]:
        return self._config.get("safety", {}).get("auto_approve_tools", [])

    @property
    def blocked_commands(self) -> list[str]:
        return self._config.get("safety", {}).get("blocked_commands", [])

    @property
    def allowed_commands(self) -> list[str]:
        return self._config.get("safety", {}).get("allowed_commands", [])

    @property
    def max_file_lines(self) -> int:
        return self._config.get("safety", {}).get("max_file_lines", 500)

    @property
    def max_iterations(self) -> int:
        return self._config.get("safety", {}).get("max_iterations", 12)

    def should_auto_approve(self, tool_name: str) -> bool:
        """Check if a tool should be auto-approved."""
        if self.auto_approve:
            return True
        return tool_name in self.auto_approve_tools

    def is_command_allowed(self, command: str) -> tuple[bool, str]:
        """Check if a bash command is allowed. Returns (allowed, reason)."""
        cmd_lower = command.lower().strip()

        # Check blocked commands
        for blocked in self.blocked_commands:
            if blocked.lower() in cmd_lower:
                return False, f"Command contains blocked pattern: {blocked}"

        # Check allowed commands (if whitelist is set)
        if self.allowed_commands:
            for allowed in self.allowed_commands:
                if cmd_lower.startswith(allowed.lower()):
                    return True, ""
            return False, "Command not in allowed list"

        return True, ""

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by dot-notation key."""
        keys = key.split(".")
        value = self._config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value
