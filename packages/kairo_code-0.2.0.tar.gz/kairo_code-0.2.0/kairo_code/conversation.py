"""Conversation manager for maintaining chat history with local persistence."""

import json
import os
import re
import stat
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import Config


CONVERSATIONS_DIR = Path.home() / ".kairo" / "conversations"

# Only allow alphanumeric + hyphens for conversation IDs (no path traversal)
_SAFE_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


def _validate_conversation_id(cid: str) -> str:
    """Validate conversation ID to prevent path traversal."""
    if not _SAFE_ID_RE.match(cid):
        raise ValueError(
            f"Invalid conversation ID: {cid!r}. "
            "Only alphanumeric characters, hyphens, and underscores are allowed (max 64 chars)."
        )
    return cid


@dataclass
class Message:
    """A single message in the conversation."""
    role: str  # "user", "assistant", "system"
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


class Conversation:
    """Manages conversation history with context window limits and local persistence."""

    def __init__(self, system_prompt: str | None = None, conversation_id: str | None = None):
        self.config = Config()
        self.system_prompt = system_prompt or self.config.system_prompt
        self.messages: list[Message] = []
        self.id = _validate_conversation_id(conversation_id) if conversation_id else uuid.uuid4().hex[:12]
        self.created_at = datetime.now(timezone.utc).isoformat()

    def add_user(self, content: str) -> None:
        """Add a user message."""
        self.messages.append(Message(role="user", content=content))
        self._trim_history()
        self._auto_save()

    def add_assistant(self, content: str) -> None:
        """Add an assistant message."""
        self.messages.append(Message(role="assistant", content=content))
        self._trim_history()
        self._auto_save()

    def add_system(self, content: str) -> None:
        """Add a system message."""
        self.messages.append(Message(role="system", content=content))

    def _trim_history(self) -> None:
        """Trim history to stay within max_history limit."""
        max_messages = self.config.max_history
        if len(self.messages) > max_messages:
            self.messages = self.messages[-max_messages:]

    def to_messages(self) -> list[dict[str, str]]:
        """Convert to format expected by OpenAI-compatible API."""
        result = [{"role": "system", "content": self.system_prompt}]
        for msg in self.messages:
            result.append({"role": msg.role, "content": msg.content})
        return result

    def clear(self) -> None:
        """Clear conversation history."""
        self.messages = []

    def get_context_summary(self) -> str:
        """Get a brief summary of the conversation context."""
        if not self.messages:
            return "No conversation history"
        return f"{len(self.messages)} messages in history"

    # ── Persistence ──────────────────────────────────────────────

    def _auto_save(self) -> None:
        """Auto-save after each message."""
        try:
            self.save()
        except Exception:
            pass  # Don't break the conversation if save fails

    def save(self) -> Path:
        """Save conversation to disk with secure permissions."""
        CONVERSATIONS_DIR.mkdir(parents=True, exist_ok=True)
        # Secure the directory: owner-only access
        try:
            os.chmod(CONVERSATIONS_DIR, stat.S_IRWXU)  # 0700
        except OSError:
            pass  # Windows doesn't support Unix permissions
        path = CONVERSATIONS_DIR / f"{self.id}.json"
        data = {
            "id": self.id,
            "created_at": self.created_at,
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "system_prompt": self.system_prompt,
            "messages": [asdict(m) for m in self.messages],
        }
        path.write_text(json.dumps(data, indent=2))
        # Secure the file: owner read/write only
        try:
            os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except OSError:
            pass
        return path

    @classmethod
    def load(cls, conversation_id: str) -> "Conversation":
        """Load a conversation from disk."""
        _validate_conversation_id(conversation_id)
        path = CONVERSATIONS_DIR / f"{conversation_id}.json"
        if not path.exists():
            raise FileNotFoundError(f"Conversation {conversation_id} not found")

        data = json.loads(path.read_text())
        conv = cls(
            system_prompt=data.get("system_prompt"),
            conversation_id=data["id"],
        )
        conv.created_at = data.get("created_at", conv.created_at)
        conv.messages = [
            Message(
                role=m["role"],
                content=m["content"],
                metadata=m.get("metadata", {}),
            )
            for m in data.get("messages", [])
        ]
        return conv

    @staticmethod
    def list_saved() -> list[dict[str, str]]:
        """List all saved conversations (id, created_at, preview)."""
        if not CONVERSATIONS_DIR.exists():
            return []

        conversations = []
        for path in sorted(CONVERSATIONS_DIR.glob("*.json"), reverse=True):
            try:
                data = json.loads(path.read_text())
                # Get first user message as preview
                preview = ""
                for m in data.get("messages", []):
                    if m.get("role") == "user":
                        preview = m["content"][:80]
                        break

                conversations.append({
                    "id": data["id"],
                    "created_at": data.get("created_at", ""),
                    "updated_at": data.get("updated_at", ""),
                    "preview": preview,
                    "message_count": str(len(data.get("messages", []))),
                })
            except Exception:
                continue

        return conversations
