"""Agent heartbeat for Kairo Code CLI.

Sends periodic heartbeat to the Kairo backend to register this CLI
instance as an active agent. Requires a valid API key and agent ID.
"""

import threading
import time
import logging

import httpx

logger = logging.getLogger(__name__)

HEARTBEAT_INTERVAL = 30  # seconds
BACKEND_URL = "https://app.kaironlabs.io"


class Heartbeat:
    """Background heartbeat sender."""

    def __init__(self, api_key: str, agent_id: str):
        self.api_key = api_key
        self.agent_id = agent_id
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start the heartbeat background thread."""
        if not self.api_key or not self.agent_id:
            return

        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("Heartbeat started for agent %s", self.agent_id)

    def stop(self) -> None:
        """Stop the heartbeat."""
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Heartbeat stopped")

    def _loop(self) -> None:
        """Heartbeat loop running in background thread."""
        while not self._stop.is_set():
            self._stop.wait(HEARTBEAT_INTERVAL)
            if self._stop.is_set():
                break

            try:
                resp = httpx.post(
                    f"{BACKEND_URL}/agents/heartbeat",
                    json={"agent_id": self.agent_id, "status": "online"},
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=10,
                )
                if resp.status_code == 200:
                    logger.debug("Heartbeat OK for agent %s", self.agent_id)
                else:
                    logger.warning("Heartbeat returned %s", resp.status_code)
            except Exception as e:
                logger.warning("Heartbeat failed: %s", e)
