"""Cloud LLM wrapper with streaming support via OpenAI-compatible API (vLLM)"""

import time
from typing import Generator, Any

from openai import OpenAI

from .config import Config
from .logging_config import get_llm_logger, log_model_selection

logger = get_llm_logger()


class LLM:
    """Wrapper around OpenAI-compatible API (vLLM) with streaming and model switching."""

    def __init__(self):
        self.config = Config()
        self.client = OpenAI(
            base_url=self.config.cloud_endpoint,
            api_key=self.config.cloud_api_key,
        )
        self._available_models: list[str] | None = None
        # Don't cache resolved models - always re-resolve from config
        self._resolved_models: dict[str, str] = {}

    def check_health(self) -> bool:
        """Check if the vLLM backend is reachable."""
        import httpx
        try:
            base = self.config.cloud_endpoint.rstrip("/v1").rstrip("/")
            resp = httpx.get(f"{base}/health", timeout=5.0)
            return resp.status_code == 200
        except Exception:
            return False

    def clear_cache(self):
        """Clear model cache to force re-resolution."""
        self._available_models = None
        self._resolved_models = {}

    def _get_available_models(self) -> list[str]:
        """Get list of available models (cached)."""
        if self._available_models is None:
            self._available_models = self.list_models()
        return self._available_models

    def _model_matches(self, available: str, wanted: str) -> bool:
        """Check if an available model matches a wanted model name."""
        # Exact match
        if available == wanted:
            return True
        # Partial match (e.g., "deepseek-coder-33b" matches "deepseek")
        if available.startswith(wanted) or wanted in available:
            return True
        return False

    def select_model(self, category: str) -> str:
        """
        Select the best available model for a category.

        Args:
            category: One of 'coder', 'router', 'chat'

        Returns:
            The best available model name
        """
        logger.debug(f"Selecting model for category: {category}")

        # Check cache first
        if category in self._resolved_models:
            logger.debug(f"Using cached model: {self._resolved_models[category]}")
            return self._resolved_models[category]

        # Get configured model for this category
        configured = self.config.get(f"models.{category}", "auto")
        logger.debug(f"Configured model: {configured}")

        # If not "auto", use the configured model directly
        if configured != "auto":
            self._resolved_models[category] = configured
            logger.info(f"Model selection: {category} -> {configured} (explicit)")
            return configured

        # Auto-select from preferences
        preferences = self.config.get(f"models.preferences.{category}", [])
        available = self._get_available_models()
        logger.debug(f"Available models: {available}")
        logger.debug(f"Preferences for {category}: {preferences}")

        for preferred in preferences:
            for avail in available:
                if self._model_matches(avail, preferred):
                    self._resolved_models[category] = avail
                    logger.info(f"Model selection: {category} -> {avail} (matched {preferred})")
                    log_model_selection(category, avail, available)
                    return avail

        # Fallback: use any available model
        if available:
            fallback = available[0]
            self._resolved_models[category] = fallback
            logger.warning(f"Model selection: {category} -> {fallback} (fallback)")
            return fallback

        # Ultimate fallback: use default model from config
        default_model = self.config.get("cloud.default_model", "deepseek-ai/deepseek-coder-33b-instruct")
        self._resolved_models[category] = default_model
        logger.warning(f"Model selection: {category} -> {default_model} (default)")
        return default_model

    def generate(
        self,
        prompt: str,
        model: str | None = None,
        system: str | None = None,
        stream: bool = True,
    ) -> Generator[str, None, None] | str:
        """
        Generate a response from the LLM.

        Args:
            prompt: The user prompt
            model: Model to use (defaults to coder model)
            system: System prompt (defaults to config system prompt)
            stream: Whether to stream the response

        Returns:
            Generator of tokens if streaming, otherwise full response string
        """
        model = model or self.select_model("coder")
        system = system or self.config.system_prompt

        # Convert to chat format for OpenAI API
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        if stream:
            return self._stream_chat(messages, model)
        else:
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=self.config.get("cloud.max_tokens", 4096),
                temperature=self.config.get("cloud.temperature", 0.1),
            )
            return response.choices[0].message.content

    def _stream_generate(
        self,
        prompt: str,
        model: str,
        system: str,
    ) -> Generator[str, None, None]:
        """Stream tokens from the LLM."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        return self._stream_chat(messages, model)

    def chat(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        stream: bool = True,
    ) -> Generator[str, None, None] | str:
        """
        Chat with conversation history.

        Args:
            messages: List of message dicts with 'role' and 'content'
            model: Model to use (defaults to coder model)
            stream: Whether to stream the response

        Returns:
            Generator of tokens if streaming, otherwise full response string
        """
        model = model or self.select_model("coder")

        if stream:
            return self._stream_chat(messages, model)
        else:
            response = self.client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=self.config.get("cloud.max_tokens", 4096),
                temperature=self.config.get("cloud.temperature", 0.1),
            )
            return response.choices[0].message.content

    def _stream_chat(
        self,
        messages: list[dict[str, str]],
        model: str,
    ) -> Generator[str, None, None]:
        """Stream chat response."""
        logger.info(f"Starting streaming chat with model: {model}")
        logger.debug(f"Message count: {len(messages)}")
        if messages:
            last_msg = messages[-1]
            logger.debug(f"Last message ({last_msg.get('role')}): {last_msg.get('content', '')[:200]}...")

        start_time = time.time()
        token_count = 0

        try:
            logger.debug("Calling cloud API...")
            stream = self.client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=self.config.get("cloud.max_tokens", 4096),
                temperature=self.config.get("cloud.temperature", 0.1),
                stream=True,
            )

            logger.debug("Stream started, receiving tokens...")
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    token_count += 1
                    yield chunk.choices[0].delta.content

            elapsed = time.time() - start_time
            logger.info(f"Chat completed: {token_count} chunks in {elapsed:.2f}s")

        except Exception as e:
            elapsed = time.time() - start_time
            logger.error(f"Chat failed after {elapsed:.2f}s: {e}")
            raise

    def classify(self, prompt: str, categories: list[str] | None = None) -> str:
        """
        Use the router model to classify intent.

        Args:
            prompt: The user's input to classify
            categories: Optional list of valid categories

        Returns:
            The classified intent category
        """
        logger.info(f"Classifying intent for: {prompt[:100]}...")
        system = self.config.router_prompt
        router_model = self.select_model("router")

        start_time = time.time()
        logger.debug(f"Calling router model: {router_model}")

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]

        response = self.client.chat.completions.create(
            model=router_model,
            messages=messages,
            max_tokens=50,
            temperature=0.0,
        )

        elapsed = time.time() - start_time
        result = response.choices[0].message.content.strip().lower()
        logger.info(f"Classification result: '{result}' (took {elapsed:.2f}s)")

        # Validate against categories if provided
        if categories:
            for cat in categories:
                if cat.lower() in result:
                    return cat.lower()
            # Default to chat if no match
            return "chat"

        return result

    def list_models(self) -> list[str]:
        """List available models from the cloud endpoint."""
        try:
            result = self.client.models.list()
            return [m.id for m in result.data]
        except Exception as e:
            logger.warning(f"Failed to list models: {e}")
            # Return default model if listing fails
            return [self.config.get("cloud.default_model", "deepseek-ai/deepseek-coder-33b-instruct")]

    def check_model(self, model: str) -> bool:
        """Check if a model is available."""
        available = self.list_models()
        return any(model in m for m in available)
