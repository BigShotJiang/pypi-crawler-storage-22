"""Logging configuration for Kairo Code"""

import logging
import os
import stat
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


# Log directory
LOG_DIR = Path.home() / ".kairo_code" / "logs"


def setup_logging(
    level: int = logging.DEBUG,
    console_level: int = logging.WARNING,
    log_file: Optional[Path] = None,
) -> logging.Logger:
    """
    Setup logging for Kairo Code.

    Args:
        level: File logging level (default DEBUG for full detail)
        console_level: Console logging level (default WARNING to not clutter output)
        log_file: Optional custom log file path

    Returns:
        Configured logger instance
    """
    # Create log directory with secure permissions
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(LOG_DIR, stat.S_IRWXU)  # 0700 — owner only
    except OSError:
        pass

    # Create session log file with timestamp
    if log_file is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = LOG_DIR / f"kairo_{timestamp}.log"

    # Get or create logger
    logger = logging.getLogger("kairo_code")
    logger.setLevel(logging.DEBUG)  # Capture everything, handlers filter

    # Clear existing handlers
    logger.handlers.clear()

    # File handler - detailed logging
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(level)
    file_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s.%(funcName)s:%(lineno)d | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # Console handler - only warnings/errors (to not clutter UI)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(console_level)
    console_formatter = logging.Formatter("[%(levelname)s] %(message)s")
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)

    # Store log file path for reference
    logger.log_file = log_file

    logger.info(f"=== Kairo Code Session Started ===")
    logger.info(f"Log file: {log_file}")

    return logger


def get_logger(name: str = "kairo_code") -> logging.Logger:
    """Get a logger instance (child of main kairo_code logger)."""
    return logging.getLogger(name)


# Convenience loggers for different components
def get_llm_logger() -> logging.Logger:
    return logging.getLogger("kairo_code.llm")

def get_tool_logger() -> logging.Logger:
    return logging.getLogger("kairo_code.tools")

def get_agent_logger() -> logging.Logger:
    return logging.getLogger("kairo_code.agents")

def get_router_logger() -> logging.Logger:
    return logging.getLogger("kairo_code.router")


class LogContext:
    """Context manager for logging sections with clear boundaries."""

    def __init__(self, logger: logging.Logger, section: str, level: int = logging.DEBUG):
        self.logger = logger
        self.section = section
        self.level = level

    def __enter__(self):
        self.logger.log(self.level, f">>> START: {self.section}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.logger.error(f"<<< END: {self.section} (ERROR: {exc_val})")
        else:
            self.logger.log(self.level, f"<<< END: {self.section}")
        return False


def log_tool_call(tool_name: str, params: dict, result: "Any") -> None:
    """Log a tool call with its parameters and result."""
    logger = get_tool_logger()
    logger.info(f"TOOL CALL: {tool_name}")
    logger.debug(f"  Params: {params}")
    if result.success:
        logger.debug(f"  Result: SUCCESS")
        # Truncate long output
        output = result.output[:500] + "..." if len(result.output) > 500 else result.output
        logger.debug(f"  Output: {output}")
    else:
        logger.warning(f"  Result: FAILED - {result.error}")


def log_llm_request(model: str, messages: list, system: str = None) -> None:
    """Log an LLM request."""
    logger = get_llm_logger()
    logger.info(f"LLM REQUEST: model={model}")
    if system:
        logger.debug(f"  System prompt: {system[:200]}...")
    logger.debug(f"  Messages: {len(messages)} total")
    for i, msg in enumerate(messages[-3:]):  # Log last 3 messages
        content = msg.get('content', '')[:200]
        logger.debug(f"  [{i}] {msg.get('role')}: {content}...")


def log_llm_response(model: str, response: str, tokens: int = None) -> None:
    """Log an LLM response."""
    logger = get_llm_logger()
    truncated = response[:500] + "..." if len(response) > 500 else response
    logger.info(f"LLM RESPONSE: model={model}, length={len(response)}")
    logger.debug(f"  Content: {truncated}")
    if tokens:
        logger.debug(f"  Tokens: {tokens}")


def log_model_selection(category: str, selected: str, available: list) -> None:
    """Log model auto-selection."""
    logger = get_llm_logger()
    logger.info(f"MODEL SELECTION: {category} -> {selected}")
    logger.debug(f"  Available models: {available}")
