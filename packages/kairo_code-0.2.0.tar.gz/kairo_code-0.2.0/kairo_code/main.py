"""Kairo Code CLI - Main entry point"""

import sys
import time
import shutil
import subprocess
from pathlib import Path

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.live import Live
from rich.prompt import Confirm
from rich.status import Status
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory

from .config import Config
from .llm import LLM
from .conversation import Conversation
from .router import Router, Intent
from .tools import create_default_registry, create_readonly_registry
from .agents import (
    ExplorerAgent, CoderAgent, PlannerAgent, AgentEvent,
    SecurityAgent, ReviewerAgent, AuditAgent, TestingAgent,
    UiUxAgent, GuardianAgent, DocsAgent, ArchitectAgent,
    DatabaseAgent, TerraformAgent,
)
from .sandbox import init_sandbox, get_sandbox
from .ui import OutputFormatter, print_tool_call, print_tool_result, print_status, print_welcome_banner
from .logging_config import setup_logging, get_logger
from .settings import (
    load_user_settings, prompt_auto_approve_settings,
    show_settings_menu, should_auto_approve
)
from .heartbeat import Heartbeat


console = Console()
logger = None  # Initialized in main()


def check_python() -> dict:
    """
    Check Python availability and return status info.
    Returns dict with 'available', 'command', 'version', and 'install_hint'.
    """
    result = {
        "available": False,
        "command": None,
        "version": None,
        "install_hint": None,
    }

    # Try python3 first (preferred on Linux/macOS), then python
    for cmd in ["python3", "python"]:
        if shutil.which(cmd):
            try:
                proc = subprocess.run(
                    [cmd, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if proc.returncode == 0:
                    result["available"] = True
                    result["command"] = cmd
                    result["version"] = proc.stdout.strip() or proc.stderr.strip()
                    return result
            except Exception:
                continue

    # Python not found - provide install hints based on system
    import platform
    system = platform.system().lower()

    if "linux" in system:
        # Check for common distros
        if shutil.which("apt-get"):
            result["install_hint"] = "sudo apt-get install python3"
        elif shutil.which("dnf"):
            result["install_hint"] = "sudo dnf install python3"
        elif shutil.which("pacman"):
            result["install_hint"] = "sudo pacman -S python"
        elif shutil.which("apk"):
            result["install_hint"] = "apk add python3"
        else:
            result["install_hint"] = "Install Python 3 using your package manager"
    elif "darwin" in system:
        result["install_hint"] = "brew install python3"
    elif "windows" in system:
        result["install_hint"] = "Download from https://python.org or: winget install Python.Python.3"
    else:
        result["install_hint"] = "Download from https://python.org"

    return result


def make_confirm_callback(user_settings: dict):
    """Create a confirmation callback that respects user settings."""
    def confirm_action(message: str) -> bool:
        """Ask user to confirm an action (respects auto-approve settings)."""
        # Extract tool name from message like "Execute write_file(...)?"
        tool_name = None
        if "write_file" in message:
            tool_name = "write_file"
        elif "bash" in message:
            tool_name = "bash"

        # Check if auto-approved
        if tool_name and should_auto_approve(tool_name, user_settings):
            console.print(f"[dim][auto-approved][/]")
            return True

        return Confirm.ask(f"[yellow]{message}[/]", default=True)

    return confirm_action


class KairoCode:
    """Main Kairo Code application."""

    def __init__(self):
        self.config = Config()
        self.llm = LLM()

        # Check Python availability BEFORE creating tools (BashTool reads KAIRO_PYTHON_CMD)
        self.python_status = check_python()
        if self.python_status["available"]:
            import os
            os.environ["KAIRO_PYTHON_CMD"] = self.python_status["command"]

        self.tools = create_default_registry()
        self.conversation = Conversation()
        self.router = Router(self.llm)

        # Load user settings
        self.user_settings = load_user_settings()

        # Initialize sandbox for safe file operations
        self.sandbox = init_sandbox()

        # Create confirmation callback that respects user settings
        self.confirm_callback = make_confirm_callback(self.user_settings)

        # Create read-only registry for non-execution agents
        self.readonly_tools = create_readonly_registry()

        # Initialize agents with appropriate tool registries
        self.agents = {
            # Core agents
            "explore": ExplorerAgent(self.llm, self.readonly_tools),
            "code": CoderAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
            "plan": PlannerAgent(self.llm, self.readonly_tools),
            # Specialist agents (read-only analysis)
            "security": SecurityAgent(self.llm, self.readonly_tools),
            "review": ReviewerAgent(self.llm, self.readonly_tools),
            "audit": AuditAgent(self.llm, self.readonly_tools),
            "uiux": UiUxAgent(self.llm, self.readonly_tools),
            "guardian": GuardianAgent(self.llm, self.readonly_tools),
            # Specialist agents (can write files)
            "test": TestingAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
            "docs": DocsAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
            "architect": ArchitectAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
            "database": DatabaseAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
            "terraform": TerraformAgent(self.llm, self.tools, on_confirm=self.confirm_callback),
        }

        # Output formatter for clean display
        self.formatter = OutputFormatter()

    def print_welcome(self) -> None:
        """Print welcome banner in Claude Code style."""
        sandbox_path = str(self.sandbox.root)

        # Get resolved model names (handles "auto" selection)
        try:
            coder_model = self.llm.select_model("coder")
            router_model = self.llm.select_model("router")
        except RuntimeError as e:
            console.print(f"[red]Error: {e}[/]")
            coder_model = "none"
            router_model = "none"

        print_welcome_banner(coder_model, router_model, sandbox_path)

        # Check backend connectivity
        if not self.llm.check_health():
            console.print("[yellow]Warning: Kairo backend unreachable. Check your connection or API key.[/]")
            console.print(f"[dim]Endpoint: {self.config.cloud_endpoint}[/]\n")

    def handle_command(self, user_input: str) -> bool:
        """
        Handle special commands.
        Returns True if command was handled.
        """
        parts = user_input.strip().split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd in ("/exit", "/quit", "/q"):
            console.print("[dim]Goodbye![/]")
            sys.exit(0)

        if cmd == "/clear":
            self.conversation.clear()
            console.print("[dim]Conversation cleared.[/]")
            return True

        if cmd == "/help":
            self._print_help()
            return True

        if cmd == "/login":
            from kairo_code.auth import authenticate, clear_credentials
            clear_credentials()
            key = authenticate(self.config.cloud_endpoint)
            if key:
                Config._instance = None
                self.config = Config()
                console.print("[green]Re-authenticated successfully.[/]")
            return True

        if cmd == "/logout":
            from kairo_code.auth import clear_credentials
            clear_credentials()
            console.print("[dim]Logged out. Restart to re-authenticate.[/]")
            return True

        if cmd == "/whoami":
            from kairo_code.auth import load_credentials
            creds = load_credentials()
            if creds:
                console.print(f"[cyan]{creds.get('email', 'Unknown')}[/] ({creds.get('plan', 'unknown')} plan)")
            else:
                console.print("[dim]Not authenticated.[/]")
            return True

        if cmd == "/explore":
            task = arg or "Explore this codebase and provide a summary"
            self._run_agent("explore", task)
            return True

        if cmd == "/code":
            if not arg:
                console.print("[red]Usage: /code <task>[/]")
                return True
            self._run_agent("code", arg)
            return True

        if cmd == "/plan":
            if not arg:
                console.print("[red]Usage: /plan <task>[/]")
                return True
            self._run_agent("plan", arg)
            return True

        # Specialist agent commands
        specialist_cmds = {
            "/security": ("security", "Run a security audit"),
            "/review": ("review", "Review code for quality issues"),
            "/audit": ("audit", "Comprehensive codebase health assessment"),
            "/test": ("test", "Generate or review tests"),
            "/uiux": ("uiux", "Evaluate UI/UX and accessibility"),
            "/guardian": ("guardian", "Verify architectural alignment"),
            "/docs": ("docs", "Create or review documentation"),
            "/architect": ("architect", "Design modular architecture"),
            "/database": ("database", "Database design and optimization"),
            "/terraform": ("terraform", "Generate Terraform IaC"),
        }

        if cmd in specialist_cmds:
            agent_key, desc = specialist_cmds[cmd]
            task = arg or f"{desc} for this project"
            self._run_agent(agent_key, task)
            return True

        if cmd == "/search":
            if not arg:
                console.print("[red]Usage: /search <query>[/]")
                return True
            self._do_search(arg)
            return True

        if cmd == "/read":
            if not arg:
                console.print("[red]Usage: /read <file>[/]")
                return True
            self._read_file(arg)
            return True

        if cmd == "/tree":
            self._show_tree(arg or ".")
            return True

        if cmd == "/models":
            self._show_models()
            return True

        if cmd == "/logs":
            self._show_logs(arg)
            return True

        if cmd == "/settings":
            self._show_settings()
            return True

        if cmd == "/history":
            self._show_history()
            return True

        if cmd == "/resume":
            if not arg:
                console.print("[red]Usage: /resume <conversation-id>[/]")
                return True
            self._resume_conversation(arg)
            return True

        return False

    def _print_help(self) -> None:
        """Print help information."""
        help_text = """
## How to Use

**Just describe what you want!** Kairo Code will automatically:
- Plan first if it's a complex task
- Then implement the solution

## Core Agents

| Agent | Description |
|-------|-------------|
| `/explore [task]` | Explore and analyze codebase |
| `/code <task>` | Write or modify code (skips auto-planning) |
| `/plan <task>` | Create a plan only (no implementation) |

## Specialist Agents

| Agent | Description |
|-------|-------------|
| `/security [task]` | Security audit — vulnerabilities, OWASP, secrets |
| `/review [task]` | Code review — bugs, quality, architecture |
| `/audit [task]` | Codebase health assessment (KEEP/REFACTOR/REWRITE) |
| `/test [task]` | Generate or review tests |
| `/uiux [task]` | UI/UX and accessibility evaluation |
| `/guardian [task]` | Verify architectural alignment |
| `/docs [task]` | Create or review documentation |
| `/architect [task]` | Design modular architecture |
| `/database [task]` | Schema design, query optimization |
| `/terraform [task]` | Generate Terraform infrastructure code |

## Utilities

| Command | Description |
|---------|-------------|
| `/search <query>` | Search the web |
| `/read <file>` | Read a file |
| `/tree [path]` | Show directory tree |
| `/models` | Show available models |
| `/history` | List saved conversations |
| `/resume <id>` | Resume a past conversation |
| `/settings` | Configure auto-approve |
| `/login` | Re-authenticate with Kairo |
| `/logout` | Clear saved credentials |
| `/whoami` | Show current account |
| `/clear` | Clear conversation |
| `/exit` | Exit Kairo Code |

## Examples

```
I want to create an app that tracks my tasks with a UI
/security audit the authentication module
/review check the code I wrote today
/test generate tests for the API endpoints
/architect refactor utils.py into modules
/terraform create an S3 bucket with versioning
```

## Tips

- Complex tasks (apps, APIs, UIs) → auto-plans first, then implements
- Simple tasks (fix bug, add function) → implements directly
- Use specialist agents for focused analysis (security, review, testing, etc.)
"""
        console.print(Markdown(help_text))

    def _run_agent(self, agent_name: str, task: str) -> None:
        """Run a specialized agent with clean event-based output."""
        agent = self.agents.get(agent_name)
        if not agent:
            console.print(f"[red]Unknown agent: {agent_name}[/]")
            return

        # Claude Code style header
        max_iter = self.config.max_iterations or 20
        console.print(f"\n[bold cyan]▶ {agent_name.title()}[/]\n")

        # Tool display names
        tool_names = {
            "read_file": "Read", "write_file": "Write", "edit_file": "Edit",
            "list_files": "Glob", "search_files": "Grep", "tree": "Tree",
            "bash": "Bash", "web_search": "WebSearch", "web_fetch": "WebFetch",
            "git_status": "Git_Status", "git_diff": "Git_Diff",
        }

        full_response = ""
        start_time = time.time()
        tool_count = 0
        spinner = None  # Active Status spinner, if any

        try:
            for event in agent.run_events(task):
                if event.type == "thinking":
                    # Show a spinner while waiting for LLM
                    if spinner:
                        spinner.stop()
                    spinner = Status(f"[dim]{event.content}[/]", console=console, spinner="dots")
                    spinner.start()

                elif event.type == "tool_start":
                    if spinner:
                        spinner.stop()
                        spinner = None
                    tool_count += 1
                    # Show tool call with parameter preview and progress
                    display_name = tool_names.get(event.tool_name, event.tool_name)
                    param_preview = self._get_param_preview(event.tool_name, event.tool_params or {})
                    console.print(f"\n[dim][{tool_count}][/] [cyan]● {display_name}[/][dim]({param_preview})[/]")

                elif event.type == "tool_result":
                    # Show result summary
                    if event.success:
                        # Truncate long results
                        content = event.content
                        if len(content) > 200:
                            lines = content.split('\n')
                            if len(lines) > 3:
                                content = '\n'.join(lines[:3]) + f"\n  ... +{len(lines)-3} more lines"
                            else:
                                content = content[:200] + "..."
                        console.print(f"  [dim]⎿  {content}[/]")
                    else:
                        console.print(f"  [red]⎿  Error: {event.content[:150]}[/]")

                elif event.type == "text":
                    if spinner:
                        spinner.stop()
                        spinner = None
                    # Final response - print as a clean block
                    full_response = event.content
                    if event.content.strip():
                        console.print()  # Blank line before text
                        console.print(Markdown(event.content))

                elif event.type == "error":
                    if spinner:
                        spinner.stop()
                        spinner = None
                    console.print(f"\n[red]⚠ {event.content}[/]")

                elif event.type == "done":
                    if spinner:
                        spinner.stop()
                        spinner = None
                    elapsed = time.time() - start_time
                    if elapsed < 60:
                        console.print(f"\n[dim]✻ Completed in {elapsed:.1f}s[/]")
                    else:
                        mins = int(elapsed // 60)
                        secs = int(elapsed % 60)
                        console.print(f"\n[dim]✻ Completed in {mins}m {secs}s[/]")

        except KeyboardInterrupt:
            if spinner:
                spinner.stop()
            console.print("\n[yellow]⚠ Interrupted[/]")

        # Add to conversation history
        self.conversation.add_user(f"[{agent_name}] {task}")
        self.conversation.add_assistant(full_response)

    def _get_param_preview(self, tool_name: str, params: dict) -> str:
        """Get a concise parameter preview for tool display."""
        return self.formatter._get_param_preview(tool_name, params)

    def _do_search(self, query: str) -> None:
        """Perform a web search and display results."""
        from .tools import web_search, format_search_results

        console.print(f"[cyan]Searching: {query}[/]\n")

        try:
            results = web_search(query)
            formatted = format_search_results(results)
            console.print(Markdown(formatted))
        except Exception as e:
            console.print(f"[red]Search error: {e}[/]")

    def _read_file(self, path: str) -> None:
        """Read and display a file."""
        from .tools import read_file

        try:
            content = read_file(path)
            console.print(Markdown(f"```\n{content}\n```"))
        except Exception as e:
            console.print(f"[red]Error: {e}[/]")

    def _show_tree(self, path: str) -> None:
        """Show directory tree."""
        from .tools import tree

        try:
            output = tree(path)
            console.print(output)
        except Exception as e:
            console.print(f"[red]Error: {e}[/]")

    def _show_models(self) -> None:
        """Show available Ollama models."""
        try:
            models = self.llm.list_models()
            coder = self.llm.select_model("coder")
            router = self.llm.select_model("router")
            console.print("[bold]Available Models:[/]")
            for model in models:
                marker = ""
                if model == coder or coder in model:
                    marker = " [cyan](coder)[/]"
                elif model == router or router in model:
                    marker = " [yellow](router)[/]"
                console.print(f"  - {model}{marker}")
        except Exception as e:
            console.print(f"[red]Error listing models: {e}[/]")

    def _show_logs(self, lines_arg: str = "") -> None:
        """Show recent log entries."""
        from .logging_config import LOG_DIR
        import subprocess

        try:
            # Find most recent log file
            log_files = sorted(LOG_DIR.glob("kairo_*.log"), reverse=True)
            if not log_files:
                console.print("[yellow]No log files found.[/]")
                return

            current_log = log_files[0]
            lines = int(lines_arg) if lines_arg.isdigit() else 50

            console.print(f"[bold]Recent logs ({current_log.name}):[/]")
            result = subprocess.run(
                ["tail", "-n", str(lines), str(current_log)],
                capture_output=True,
                text=True
            )
            console.print(result.stdout)
            console.print(f"\n[dim]Full log: {current_log}[/]")
        except Exception as e:
            console.print(f"[red]Error reading logs: {e}[/]")

    def _show_settings(self) -> None:
        """Show and modify settings."""
        self.user_settings = show_settings_menu()
        # Update the confirm callback with new settings
        self.confirm_callback = make_confirm_callback(self.user_settings)
        # Update all agents that have confirmation callbacks
        for agent in self.agents.values():
            if hasattr(agent, 'on_confirm'):
                agent.on_confirm = self.confirm_callback

    def _show_history(self) -> None:
        """Show saved conversations."""
        conversations = Conversation.list_saved()
        if not conversations:
            console.print("[dim]No saved conversations.[/]")
            return

        console.print("[bold]Saved Conversations:[/]\n")
        for conv in conversations[:20]:  # Show last 20
            preview = conv["preview"] or "(empty)"
            console.print(
                f"  [cyan]{conv['id']}[/]  "
                f"[dim]{conv['created_at'][:10]}[/]  "
                f"{conv['message_count']} msgs  "
                f"[dim]{preview}[/]"
            )
        console.print(f"\n[dim]Use /resume <id> to continue a conversation.[/]")

    def _resume_conversation(self, conversation_id: str) -> None:
        """Resume a saved conversation."""
        try:
            self.conversation = Conversation.load(conversation_id)
            count = len(self.conversation.messages)
            console.print(f"[green]Resumed conversation {conversation_id} ({count} messages)[/]")
        except FileNotFoundError:
            console.print(f"[red]Conversation {conversation_id} not found.[/]")
        except Exception as e:
            console.print(f"[red]Error loading conversation: {e}[/]")

    def _prompt_first_run_settings(self) -> None:
        """Prompt for settings on first run."""
        if not self.user_settings["auto_approve"].get("prompted"):
            self.user_settings = prompt_auto_approve_settings()
            # Update the confirm callback with new settings
            self.confirm_callback = make_confirm_callback(self.user_settings)
            # Update all agents that have confirmation callbacks
            for agent in self.agents.values():
                if hasattr(agent, 'on_confirm'):
                    agent.on_confirm = self.confirm_callback

    def _is_complex_task(self, task: str) -> bool:
        """Check if a task is complex enough to need planning first."""
        task_lower = task.lower()
        # Complex indicators
        complex_keywords = [
            "app", "application", "create", "build", "implement",
            "multiple", "features", "ui", "interface", "api",
            "database", "authentication", "with a", "that can",
            "schedule", "daily", "weekly", "notifications"
        ]
        # Count how many complex indicators are present
        matches = sum(1 for kw in complex_keywords if kw in task_lower)
        return matches >= 2  # 2 or more indicators = complex

    def _run_autonomous(self, task: str) -> None:
        """Run autonomous workflow: plan if complex, then implement."""
        if self._is_complex_task(task):
            console.print("[dim]Complex task detected - planning first...[/]\n")

            # Step 1: Plan
            self._run_agent("plan", task)

            # Step 2: Implement (pass the original task, coder will see the plan context)
            console.print("\n[dim]Implementing plan...[/]\n")
            self._run_agent("code", f"Implement the following task based on the plan above: {task}")
        else:
            # Simple task - just code directly
            self._run_agent("code", task)

    def chat(self, user_input: str) -> None:
        """Handle a regular chat message with smart routing."""
        # Route the intent
        routed = self.router.route(user_input)
        console.print(f"[dim][{routed.intent.value}][/]")

        # Handle based on intent
        if routed.intent == Intent.SEARCH:
            self._do_search(user_input)
            return

        if routed.intent == Intent.EXPLORE:
            self._run_agent("explore", user_input)
            return

        if routed.intent == Intent.PLAN:
            # Explicit /plan - just plan, don't implement
            self._run_agent("plan", user_input)
            return

        if routed.intent == Intent.CODE:
            # Autonomous: plan if complex, then code
            self._run_autonomous(user_input)
            return

        if routed.intent == Intent.FILE_READ:
            path = routed.extracted_params.get("path", "")
            if path:
                self._read_file(path)
            else:
                # Ask LLM to help find the file
                self._run_agent("code", user_input)
            return

        if routed.intent == Intent.FILE_LIST:
            pattern = routed.extracted_params.get("pattern", "**/*")
            self._show_tree(".")
            return

        if routed.intent == Intent.FILE_WRITE:
            self._run_agent("code", user_input)
            return

        # Default: regular chat
        self.conversation.add_user(user_input)
        messages = self.conversation.to_messages()
        self._stream_response(messages)

    def _stream_response(self, messages: list[dict], model: str | None = None) -> None:
        """Stream and display LLM response with a thinking spinner."""
        full_response = ""
        first_chunk = True
        spinner = Status("[dim]Thinking...[/]", console=console, spinner="dots")

        try:
            spinner.start()

            with Live(console=console, refresh_per_second=10, auto_refresh=False) as live:
                buffer = ""
                for chunk in self.llm.chat(messages, model=model, stream=True):
                    if first_chunk:
                        spinner.stop()
                        first_chunk = False
                    buffer += chunk
                    full_response += chunk
                    live.update(Markdown(buffer))
                    live.refresh()

            if first_chunk:
                spinner.stop()

            self.conversation.add_assistant(full_response)
            console.print()

        except Exception as e:
            if first_chunk:
                spinner.stop()
            console.print(f"[red]Error: {e}[/]")

    def run(self) -> None:
        """Main run loop."""
        self.print_welcome()

        # Prompt for auto-approve settings on first run
        self._prompt_first_run_settings()

        # Authenticate with Kairo cloud
        from kairo_code.auth import ensure_authenticated
        api_key = self.config.cloud_api_key
        if not api_key or api_key == "not-needed":
            api_key = ensure_authenticated(self.config.cloud_endpoint)
            if not api_key:
                console.print("[red]Authentication required to use Kairo Code.[/]")
                console.print("[dim]Visit https://app.kaironlabs.io/pricing to upgrade to Max plan.[/]")
                sys.exit(1)
            # Reset config singleton so the new key is picked up
            Config._instance = None
            self.config = Config()

        # Check if models were resolved (auto-selection already handles this, but warn if no models)
        try:
            coder_model = self.llm.select_model("coder")
            if not self.llm.check_model(coder_model):
                console.print(f"[yellow]Warning: Model {coder_model} not found.[/]")
                console.print(f"[yellow]Run: ollama pull {coder_model}[/]\n")
        except RuntimeError as e:
            console.print(f"[red]{e}[/]")
            console.print("[yellow]Run: ollama pull llama3 to download a model[/]\n")

        # Check if Python is available
        if not self.python_status["available"]:
            console.print("[yellow]Warning: Python not found on this system.[/]")
            console.print(f"[yellow]Install: {self.python_status['install_hint']}[/]")
            console.print("[dim]Python is required to run generated scripts.[/]\n")

        # Start heartbeat if API key is configured
        self._heartbeat = None
        api_key = self.config.cloud_api_key
        if api_key and api_key != "not-needed":
            agent_id = self.config.get("cloud.agent_id", "")
            if agent_id:
                self._heartbeat = Heartbeat(api_key, agent_id)
                self._heartbeat.start()

        # Setup prompt with history
        history_file = Path.home() / ".kairo_code_history"
        session = PromptSession(history=FileHistory(str(history_file)))

        while True:
            try:
                user_input = session.prompt("\n> ").strip()

                if not user_input:
                    continue

                # Check for commands
                if user_input.startswith("/"):
                    if self.handle_command(user_input):
                        continue

                # Regular chat with smart routing
                self.chat(user_input)

            except KeyboardInterrupt:
                console.print("\n[dim]Use /exit to quit[/]")
            except EOFError:
                break
            except Exception as e:
                console.print(f"[red]Error: {e}[/]")


def main():
    """Entry point."""
    global logger

    # Initialize logging first
    logger = setup_logging()
    logger.info("Kairo Code starting up...")

    try:
        logger.info("Initializing Kairo Code application...")
        app = KairoCode()
        logger.info("Starting main run loop...")
        app.run()
    except KeyboardInterrupt:
        logger.info("User interrupted with Ctrl+C")
        console.print("\n[dim]Goodbye![/]")
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        console.print(f"[red]Fatal error: {e}[/]")
        console.print(f"[dim]Check logs at: {logger.log_file}[/]")
        sys.exit(1)


if __name__ == "__main__":
    main()
