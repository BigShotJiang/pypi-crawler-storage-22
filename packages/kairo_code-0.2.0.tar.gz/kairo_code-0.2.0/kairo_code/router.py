"""Intent router using small LLM for classification with few-shot examples"""

from dataclasses import dataclass
from enum import Enum
import re

from .llm import LLM


class Intent(Enum):
    SEARCH = "search"
    CODE = "code"
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_LIST = "file_list"
    EXPLORE = "explore"
    PLAN = "plan"
    CHAT = "chat"


@dataclass
class RoutedIntent:
    intent: Intent
    confidence: str  # "high", "medium", "low"
    extracted_params: dict


# Few-shot examples for the router
ROUTER_EXAMPLES = """
## Examples

Input: "What's the weather like today?"
Output: search

Input: "Write a Python function to sort a list"
Output: code

Input: "Show me what's in config.py"
Output: file_read

Input: "Create a new file called utils.py with a helper function"
Output: file_write

Input: "What files are in the src directory?"
Output: file_list

Input: "Analyze this codebase for improvements"
Output: explore

Input: "How should I implement user authentication?"
Output: plan

Input: "What's the capital of France?"
Output: chat

Input: "Search for the latest Python 3.12 features"
Output: search

Input: "Fix the bug in main.py line 42"
Output: code

Input: "Read the README file"
Output: file_read

Input: "Save this code to server.py"
Output: file_write

Input: "Find all Python files in this project"
Output: file_list

Input: "Explore how the API endpoints work"
Output: explore

Input: "Plan out how to refactor the database layer"
Output: plan

Input: "Hello, how are you?"
Output: chat

Input: "Create a tool with a UI that pulls data from an API"
Output: code

Input: "Build me an app that tracks my tasks"
Output: code
"""

ROUTER_SYSTEM_PROMPT = f"""You are a classifier. Classify the user's intent into exactly ONE category.

Categories:
- search: User wants current/real-time information from the web
- code: User wants to write, modify, fix, or generate code
- file_read: User wants to see contents of a specific file
- file_write: User wants to create or save a file
- file_list: User wants to list or find files
- explore: User wants to analyze or understand a codebase
- plan: User wants to plan a complex task before implementing
- chat: General conversation, questions, or explanations

{ROUTER_EXAMPLES}

Respond with ONLY the category name, nothing else.
"""


class Router:
    """Routes user input to the appropriate handler using few-shot classification."""

    INTENT_CATEGORIES = [i.value for i in Intent]

    def __init__(self, llm: LLM):
        self.llm = llm

    def route(self, user_input: str) -> RoutedIntent:
        """
        Classify user input and extract relevant parameters.
        Uses few-shot examples for better accuracy with small models.
        """
        # First try rule-based classification for common patterns
        rule_based = self._rule_based_classify(user_input)
        if rule_based:
            return rule_based

        # Fall back to LLM classification
        from .config import Config
        config = Config()
        system = config.router_prompt + "\n" + ROUTER_EXAMPLES + "\nRespond with ONLY the category name, nothing else."
        response = self.llm.generate(
            prompt=f"Input: {user_input}\nOutput:",
            model=self.llm.select_model("router"),
            system=system,
            stream=False,
        )

        # Parse the response
        intent_str = response.strip().lower()

        # Find matching intent
        intent = Intent.CHAT  # Default
        for cat in self.INTENT_CATEGORIES:
            if cat in intent_str:
                try:
                    intent = Intent(cat)
                except ValueError:
                    pass
                break

        # Extract params based on intent
        params = self._extract_params(user_input, intent)

        return RoutedIntent(
            intent=intent,
            confidence="high" if intent_str in self.INTENT_CATEGORIES else "medium",
            extracted_params=params,
        )

    def _rule_based_classify(self, user_input: str) -> RoutedIntent | None:
        """Fast rule-based classification for common patterns."""
        lower = user_input.lower().strip()

        # Search patterns
        search_keywords = ["weather", "latest", "current", "today's", "news", "price of"]
        if any(kw in lower for kw in search_keywords):
            return RoutedIntent(Intent.SEARCH, "high", {})

        # File read patterns
        if re.match(r"^(show|read|cat|display|what'?s in|open)\s+.+\.(py|js|ts|json|yaml|yml|md|txt)", lower):
            # Extract filename
            match = re.search(r'[\w./\\-]+\.\w+', user_input)
            path = match.group(0) if match else ""
            return RoutedIntent(Intent.FILE_READ, "high", {"path": path})

        # File list patterns
        if re.match(r"^(list|find|show|what)\s+(files?|all)", lower):
            return RoutedIntent(Intent.FILE_LIST, "high", {})

        # Explore patterns
        if any(phrase in lower for phrase in ["explore", "analyze", "understand", "how does", "explain the code"]):
            return RoutedIntent(Intent.EXPLORE, "high", {})

        # Plan patterns
        if any(phrase in lower for phrase in ["plan", "how should i", "how to implement", "design"]):
            return RoutedIntent(Intent.PLAN, "high", {})

        # Code patterns
        code_keywords = ["write", "create", "fix", "modify", "add", "implement", "refactor", "update", "change", "build", "make"]
        code_context = ["function", "class", "method", "code", "script", "bug", "error", "tool", "app", "application", "program", "ui", "gui", "api"]
        if any(kw in lower for kw in code_keywords) and any(ctx in lower for ctx in code_context):
            return RoutedIntent(Intent.CODE, "high", {})

        # Greeting patterns
        greetings = ["hello", "hi", "hey", "good morning", "good afternoon"]
        if any(lower.startswith(g) for g in greetings):
            return RoutedIntent(Intent.CHAT, "high", {})

        return None  # Fall back to LLM

    def _extract_params(self, user_input: str, intent: Intent) -> dict:
        """Extract relevant parameters from user input based on intent."""
        params = {}

        if intent in (Intent.FILE_READ, Intent.FILE_WRITE):
            # Extract file path
            path_match = re.search(r'[\w./\\-]+\.\w+', user_input)
            if path_match:
                params["path"] = path_match.group(0)

        if intent == Intent.FILE_LIST:
            # Extract glob pattern if present
            pattern_match = re.search(r'\*+\.?\w*', user_input)
            if pattern_match:
                params["pattern"] = pattern_match.group(0)

        if intent == Intent.SEARCH:
            # The whole input is basically the search query
            params["query"] = user_input

        return params
