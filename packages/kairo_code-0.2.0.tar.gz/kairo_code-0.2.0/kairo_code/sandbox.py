"""Sandbox and safety controls for Kairo Code - prevents unauthorized file access"""

import os
from pathlib import Path
from typing import Optional
from dataclasses import dataclass


@dataclass
class SandboxConfig:
    """Configuration for the sandbox."""
    # Root directory for all file operations (usually project dir)
    root_dir: Path
    # Allow operations outside root (dangerous!)
    allow_escape: bool = False
    # Paths that are always blocked (even with allow_escape)
    blocked_paths: tuple = (
        "/etc", "/usr", "/bin", "/sbin", "/boot", "/root",
        "/sys", "/proc", "/dev", "/var/log",
        "~/.ssh", "~/.gnupg", "~/.aws", "~/.config",
    )
    # File extensions that require extra confirmation
    sensitive_extensions: tuple = (
        ".env", ".pem", ".key", ".crt", ".p12",
        ".password", ".secret", ".credentials",
    )
    # Max file size to write (prevents filling disk)
    max_file_size: int = 10 * 1024 * 1024  # 10MB


class Sandbox:
    """
    Sandbox for safe file operations.

    Restricts file access to a root directory and blocks sensitive paths.
    Similar to Claude Code's sandboxing.
    """

    def __init__(self, config: Optional[SandboxConfig] = None):
        if config is None:
            # Default: use current working directory as root
            config = SandboxConfig(root_dir=Path.cwd())

        self.config = config
        self.root = config.root_dir.resolve()

        # Expand blocked paths
        self._blocked = set()
        for p in config.blocked_paths:
            expanded = Path(p).expanduser()
            self._blocked.add(str(expanded.resolve()))

    def validate_path(self, path: str, operation: str = "access") -> tuple[bool, str, Path]:
        """
        Validate a path for safety.

        Args:
            path: The path to validate
            operation: The operation being performed (read, write, delete)

        Returns:
            (is_valid, error_message, resolved_path)
        """
        try:
            # Resolve the path
            target = Path(path).expanduser()

            # Make absolute if relative
            if not target.is_absolute():
                target = self.root / target

            resolved = target.resolve()

            # Check if path escapes sandbox
            if not self.config.allow_escape:
                try:
                    resolved.relative_to(self.root)
                except ValueError:
                    return (
                        False,
                        f"Path '{path}' is outside project directory. "
                        f"Only paths within '{self.root}' are allowed.",
                        resolved
                    )

            # Check blocked paths
            resolved_str = str(resolved)
            for blocked in self._blocked:
                if resolved_str.startswith(blocked):
                    return (
                        False,
                        f"Access to '{path}' is blocked for security reasons.",
                        resolved
                    )

            # Check for path traversal attempts
            if ".." in path:
                # Re-verify after resolution
                try:
                    resolved.relative_to(self.root)
                except ValueError:
                    return (
                        False,
                        f"Path traversal detected in '{path}'.",
                        resolved
                    )

            # Check sensitive extensions for write operations
            if operation == "write" and resolved.suffix in self.config.sensitive_extensions:
                return (
                    False,
                    f"Writing to sensitive file type '{resolved.suffix}' requires manual confirmation.",
                    resolved
                )

            return (True, "", resolved)

        except Exception as e:
            return (False, f"Invalid path: {e}", Path(path))

    def validate_content(self, content: str, path: str) -> tuple[bool, str]:
        """
        Validate content being written.

        Args:
            content: The content to write
            path: The target path

        Returns:
            (is_valid, error_message)
        """
        # Check size
        size = len(content.encode('utf-8'))
        if size > self.config.max_file_size:
            return (
                False,
                f"Content too large ({size / 1024 / 1024:.1f}MB). "
                f"Max allowed: {self.config.max_file_size / 1024 / 1024:.0f}MB"
            )

        # Check for suspicious content patterns
        suspicious_patterns = [
            ("#!/", "Script with shebang"),
            ("rm -rf", "Destructive command"),
            ("sudo ", "Sudo command"),
            ("eval(", "Eval statement"),
            ("exec(", "Exec statement"),
            ("__import__", "Dynamic import"),
        ]

        warnings = []
        for pattern, description in suspicious_patterns:
            if pattern in content:
                warnings.append(description)

        if warnings:
            # Don't block, just warn
            return (True, f"Warning: Content contains: {', '.join(warnings)}")

        return (True, "")

    def safe_read(self, path: str) -> str:
        """Safely read a file with validation."""
        valid, error, resolved = self.validate_path(path, "read")
        if not valid:
            raise PermissionError(error)

        if not resolved.exists():
            raise FileNotFoundError(f"File not found: {path}")

        if not resolved.is_file():
            raise IsADirectoryError(f"Not a file: {path}")

        return resolved.read_text()

    def safe_write(self, path: str, content: str) -> str:
        """Safely write a file with validation."""
        valid, error, resolved = self.validate_path(path, "write")
        if not valid:
            raise PermissionError(error)

        valid, warning = self.validate_content(content, path)
        if not valid:
            raise ValueError(warning)

        # Create parent directories if needed
        resolved.parent.mkdir(parents=True, exist_ok=True)

        # Write the file
        resolved.write_text(content)

        line_count = content.count('\n') + 1
        result = f"File written: {resolved.relative_to(self.root)} ({line_count} lines)"

        if warning:
            result += f"\n{warning}"

        return result

    def safe_delete(self, path: str) -> str:
        """Safely delete a file with validation."""
        valid, error, resolved = self.validate_path(path, "delete")
        if not valid:
            raise PermissionError(error)

        if not resolved.exists():
            raise FileNotFoundError(f"File not found: {path}")

        if resolved.is_dir():
            raise IsADirectoryError(f"Cannot delete directory: {path}. Use bash for that.")

        resolved.unlink()
        return f"Deleted: {resolved.relative_to(self.root)}"

    def list_allowed_paths(self) -> list[str]:
        """List paths that are allowed for access."""
        return [str(self.root)]

    def get_relative_path(self, path: str) -> str:
        """Get path relative to sandbox root."""
        try:
            resolved = Path(path).resolve()
            return str(resolved.relative_to(self.root))
        except ValueError:
            return path


# Global sandbox instance (initialized when Kairo Code starts)
_sandbox: Optional[Sandbox] = None


def init_sandbox(root: Optional[Path] = None, allow_escape: bool = False) -> Sandbox:
    """Initialize the global sandbox."""
    global _sandbox
    config = SandboxConfig(
        root_dir=root or Path.cwd(),
        allow_escape=allow_escape
    )
    _sandbox = Sandbox(config)
    return _sandbox


def get_sandbox() -> Sandbox:
    """Get the global sandbox, initializing if needed."""
    global _sandbox
    if _sandbox is None:
        _sandbox = Sandbox()
    return _sandbox
