"""User settings management with interactive prompts."""

import os
from pathlib import Path
from typing import Any

import yaml
from rich.console import Console
from rich.prompt import Confirm, Prompt

console = Console()

# User settings directory
SETTINGS_DIR = Path.home() / ".kairo_code"
SETTINGS_FILE = SETTINGS_DIR / "settings.yaml"

DEFAULT_SETTINGS = {
    "auto_approve": {
        "enabled": False,
        "write_file": False,
        "bash": False,
        "prompted": False,  # Whether we've asked the user yet
    },
    "verbose": False,
}


def load_user_settings() -> dict[str, Any]:
    """Load user settings from ~/.kairo_code/settings.yaml"""
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)

    if not SETTINGS_FILE.exists():
        return DEFAULT_SETTINGS.copy()

    try:
        with open(SETTINGS_FILE) as f:
            settings = yaml.safe_load(f) or {}
        # Merge with defaults for any missing keys
        merged = DEFAULT_SETTINGS.copy()
        _deep_merge(merged, settings)
        return merged
    except Exception:
        return DEFAULT_SETTINGS.copy()


def save_user_settings(settings: dict[str, Any]) -> None:
    """Save user settings to ~/.kairo_code/settings.yaml"""
    SETTINGS_DIR.mkdir(parents=True, exist_ok=True)

    with open(SETTINGS_FILE, "w") as f:
        yaml.dump(settings, f, default_flow_style=False)


def _deep_merge(base: dict, override: dict) -> None:
    """Recursively merge override into base."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value


def prompt_auto_approve_settings(force: bool = False) -> dict[str, Any]:
    """
    Interactively prompt user for auto-approve settings.
    Only prompts on first run unless force=True.
    Returns the updated settings.
    """
    settings = load_user_settings()

    # Skip if already prompted (unless forced)
    if settings["auto_approve"].get("prompted") and not force:
        return settings

    console.print("\n[bold cyan]═══ Auto-Approve Settings ═══[/]\n")
    console.print("[dim]Kairo Code can auto-approve certain actions to speed up your workflow.[/]")
    console.print("[dim]You can change these settings anytime with /settings[/]\n")

    # Ask about file writes
    settings["auto_approve"]["write_file"] = Confirm.ask(
        "[yellow]?[/] Auto-approve [bold]file writes[/] (create/modify files without asking)?",
        default=False
    )

    # Ask about bash commands
    console.print("\n[dim]⚠ Bash commands can modify your system. Auto-approve with caution.[/]")
    settings["auto_approve"]["bash"] = Confirm.ask(
        "[yellow]?[/] Auto-approve [bold]bash commands[/] (run shell commands without asking)?",
        default=False
    )

    # Set enabled if any are true
    settings["auto_approve"]["enabled"] = (
        settings["auto_approve"]["write_file"] or
        settings["auto_approve"]["bash"]
    )

    # Mark as prompted
    settings["auto_approve"]["prompted"] = True

    # Save settings
    save_user_settings(settings)

    # Show summary
    console.print("\n[bold]Settings saved![/]")
    _print_current_settings(settings)
    console.print()

    return settings


def _print_current_settings(settings: dict[str, Any]) -> None:
    """Print current auto-approve settings."""
    auto = settings["auto_approve"]

    write_status = "[green]✓ Yes[/]" if auto.get("write_file") else "[red]✗ No[/]"
    bash_status = "[green]✓ Yes[/]" if auto.get("bash") else "[red]✗ No[/]"

    console.print(f"  • Auto-approve file writes: {write_status}")
    console.print(f"  • Auto-approve bash commands: {bash_status}")


def show_settings_menu() -> dict[str, Any]:
    """Show settings menu and allow user to change settings."""
    settings = load_user_settings()

    console.print("\n[bold cyan]═══ Kairo Code Settings ═══[/]\n")
    console.print("[bold]Current settings:[/]")
    _print_current_settings(settings)

    console.print("\n[bold]Options:[/]")
    console.print("  [cyan]1[/] - Toggle auto-approve file writes")
    console.print("  [cyan]2[/] - Toggle auto-approve bash commands")
    console.print("  [cyan]3[/] - Enable all auto-approve")
    console.print("  [cyan]4[/] - Disable all auto-approve")
    console.print("  [cyan]q[/] - Back to chat")

    choice = Prompt.ask("\n[yellow]?[/] Select option", choices=["1", "2", "3", "4", "q"], default="q")

    if choice == "1":
        settings["auto_approve"]["write_file"] = not settings["auto_approve"]["write_file"]
        console.print(f"[green]File writes auto-approve: {'enabled' if settings['auto_approve']['write_file'] else 'disabled'}[/]")
    elif choice == "2":
        settings["auto_approve"]["bash"] = not settings["auto_approve"]["bash"]
        console.print(f"[green]Bash auto-approve: {'enabled' if settings['auto_approve']['bash'] else 'disabled'}[/]")
    elif choice == "3":
        settings["auto_approve"]["write_file"] = True
        settings["auto_approve"]["bash"] = True
        settings["auto_approve"]["enabled"] = True
        console.print("[green]All auto-approve enabled[/]")
    elif choice == "4":
        settings["auto_approve"]["write_file"] = False
        settings["auto_approve"]["bash"] = False
        settings["auto_approve"]["enabled"] = False
        console.print("[green]All auto-approve disabled[/]")

    # Update enabled flag
    settings["auto_approve"]["enabled"] = (
        settings["auto_approve"]["write_file"] or
        settings["auto_approve"]["bash"]
    )

    save_user_settings(settings)
    return settings


def should_auto_approve(tool_name: str, settings: dict[str, Any] | None = None) -> bool:
    """Check if a tool should be auto-approved based on user settings."""
    if settings is None:
        settings = load_user_settings()

    auto = settings.get("auto_approve", {})

    if tool_name == "write_file":
        return auto.get("write_file", False)
    elif tool_name == "bash":
        return auto.get("bash", False)

    # Read-only tools are always auto-approved
    if tool_name in ("read_file", "list_files", "tree", "search_files", "web_search"):
        return True

    return False
