"""Kairo Code Tools - File operations, search, and code generation"""

from .base import (
    Tool,
    ToolResult,
    ToolRegistry,
    FunctionTool,
    parse_tool_calls,
    format_tool_error,
    ParsedToolCall,
    ToolParseResult,
)
from .files import (
    read_file,
    write_file,
    edit_file,
    list_files,
    search_files,
    tree,
)
from .search import web_search, format_search_results
from .code import extract_code_blocks, build_code_prompt, build_explain_prompt
from .definitions import create_default_registry, create_readonly_registry

__all__ = [
    # Base classes
    "Tool",
    "ToolResult",
    "ToolRegistry",
    "FunctionTool",
    "parse_tool_calls",
    "format_tool_error",
    "ParsedToolCall",
    "ToolParseResult",
    "create_default_registry",
    "create_readonly_registry",
    # File tools
    "read_file",
    "write_file",
    "edit_file",
    "list_files",
    "search_files",
    "tree",
    # Search
    "web_search",
    "format_search_results",
    # Code
    "extract_code_blocks",
    "build_code_prompt",
    "build_explain_prompt",
]
