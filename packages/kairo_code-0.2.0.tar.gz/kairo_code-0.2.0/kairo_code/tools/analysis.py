"""Code analysis and review tools for Kairo Code"""

import subprocess
import json
import os
from pathlib import Path
from typing import Any

from .base import Tool, ToolResult


class LintTool(Tool):
    """Run linters on code to find issues."""

    name = "lint"
    description = "Run linters (flake8/pylint for Python, eslint for JS) to find code issues"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to lint"},
            "fix": {"type": "boolean", "description": "Auto-fix issues if possible (default: False)"},
        },
        "required": ["path"],
    }

    def execute(self, path: str, fix: bool = False) -> ToolResult:
        path = Path(path)

        if not path.exists():
            return ToolResult(success=False, output="", error=f"Path not found: {path}")

        # Detect language and run appropriate linter
        if path.suffix == ".py" or (path.is_dir() and list(path.glob("**/*.py"))):
            return self._lint_python(path, fix)
        elif path.suffix in (".js", ".ts", ".jsx", ".tsx") or (path.is_dir() and list(path.glob("**/*.js"))):
            return self._lint_javascript(path, fix)
        else:
            return ToolResult(success=False, output="", error="Unsupported file type for linting")

    def _lint_python(self, path: Path, fix: bool) -> ToolResult:
        # Try ruff first (fast), then flake8, then pylint
        for linter in ["ruff", "flake8", "pylint"]:
            try:
                if linter == "ruff":
                    cmd = ["ruff", "check", str(path)]
                    if fix:
                        cmd.append("--fix")
                elif linter == "flake8":
                    cmd = ["flake8", "--max-line-length=100", str(path)]
                else:
                    cmd = ["pylint", "--output-format=text", "--score=no", str(path)]

                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

                output = result.stdout or result.stderr or "No issues found"

                # Count issues
                lines = output.strip().split("\n") if output.strip() else []
                issue_count = len([l for l in lines if l.strip() and not l.startswith("*")])

                return ToolResult(
                    success=True,
                    output=f"[{linter}] Found {issue_count} issues:\n\n{output[:5000]}"
                )
            except FileNotFoundError:
                continue
            except Exception as e:
                return ToolResult(success=False, output="", error=str(e))

        return ToolResult(
            success=False,
            output="",
            error="No Python linter found. Install: pip install ruff flake8 pylint"
        )

    def _lint_javascript(self, path: Path, fix: bool) -> ToolResult:
        try:
            cmd = ["npx", "eslint", str(path), "--format=stylish"]
            if fix:
                cmd.append("--fix")

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            output = result.stdout or result.stderr or "No issues found"

            return ToolResult(success=True, output=output[:5000])
        except FileNotFoundError:
            return ToolResult(success=False, output="", error="eslint not found. Run: npm install eslint")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class TypeCheckTool(Tool):
    """Run type checkers on code."""

    name = "typecheck"
    description = "Run type checker (mypy for Python, tsc for TypeScript) to find type errors"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to type check"},
            "strict": {"type": "boolean", "description": "Use strict mode (default: False)"},
        },
        "required": ["path"],
    }

    def execute(self, path: str, strict: bool = False) -> ToolResult:
        path = Path(path)

        if not path.exists():
            return ToolResult(success=False, output="", error=f"Path not found: {path}")

        if path.suffix == ".py" or (path.is_dir() and list(path.glob("**/*.py"))):
            return self._typecheck_python(path, strict)
        elif path.suffix == ".ts" or (path.is_dir() and list(path.glob("**/*.ts"))):
            return self._typecheck_typescript(path, strict)
        else:
            return ToolResult(success=False, output="", error="Unsupported file type")

    def _typecheck_python(self, path: Path, strict: bool) -> ToolResult:
        try:
            cmd = ["mypy", str(path)]
            if strict:
                cmd.append("--strict")

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            output = result.stdout or result.stderr

            # Parse results
            lines = output.strip().split("\n") if output.strip() else []
            error_count = len([l for l in lines if ": error:" in l])

            return ToolResult(
                success=result.returncode == 0,
                output=f"Found {error_count} type errors:\n\n{output[:5000]}",
                error=None if result.returncode == 0 else f"Type check failed with {error_count} errors"
            )
        except FileNotFoundError:
            return ToolResult(success=False, output="", error="mypy not found. Install: pip install mypy")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))

    def _typecheck_typescript(self, path: Path, strict: bool) -> ToolResult:
        try:
            cmd = ["npx", "tsc", "--noEmit", str(path)]
            if strict:
                cmd.append("--strict")

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            output = result.stdout or result.stderr or "No type errors found"

            return ToolResult(success=result.returncode == 0, output=output[:5000])
        except FileNotFoundError:
            return ToolResult(success=False, output="", error="TypeScript not found. Run: npm install typescript")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class RunTestsTool(Tool):
    """Run tests and show results."""

    name = "run_tests"
    description = "Run tests (pytest for Python, jest/vitest for JS) and show results"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Test file/directory (default: auto-detect)"},
            "verbose": {"type": "boolean", "description": "Show verbose output (default: False)"},
            "filter": {"type": "string", "description": "Only run tests matching this pattern"},
        },
        "required": [],
    }

    def execute(self, path: str = ".", verbose: bool = False, filter: str = None) -> ToolResult:
        # Auto-detect test framework
        cwd = Path(path) if Path(path).is_dir() else Path(".")

        # Check for Python tests
        if list(cwd.glob("**/test_*.py")) or list(cwd.glob("**/*_test.py")) or (cwd / "pytest.ini").exists():
            return self._run_pytest(path, verbose, filter)

        # Check for JS tests
        if (cwd / "package.json").exists():
            return self._run_js_tests(cwd, verbose, filter)

        return ToolResult(success=False, output="", error="No test framework detected")

    def _run_pytest(self, path: str, verbose: bool, filter: str) -> ToolResult:
        try:
            cmd = ["pytest", path, "--tb=short"]
            if verbose:
                cmd.append("-v")
            if filter:
                cmd.extend(["-k", filter])

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            output = result.stdout + "\n" + result.stderr

            # Parse summary
            passed = output.count(" passed")
            failed = output.count(" failed")

            return ToolResult(
                success=result.returncode == 0,
                output=f"Tests: {passed} passed, {failed} failed\n\n{output[:8000]}",
                error=None if result.returncode == 0 else f"{failed} tests failed"
            )
        except FileNotFoundError:
            return ToolResult(success=False, output="", error="pytest not found. Install: pip install pytest")
        except subprocess.TimeoutExpired:
            return ToolResult(success=False, output="", error="Tests timed out after 5 minutes")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))

    def _run_js_tests(self, cwd: Path, verbose: bool, filter: str) -> ToolResult:
        try:
            # Try npm test first
            cmd = ["npm", "test", "--"]
            if filter:
                cmd.extend(["--testNamePattern", filter])

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, cwd=cwd)
            output = result.stdout + "\n" + result.stderr

            return ToolResult(
                success=result.returncode == 0,
                output=output[:8000]
            )
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class SecurityScanTool(Tool):
    """Scan code for security vulnerabilities."""

    name = "security_scan"
    description = "Scan code for security issues (bandit for Python, npm audit for JS)"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to scan"},
            "severity": {"type": "string", "description": "Minimum severity: low, medium, high (default: medium)"},
        },
        "required": ["path"],
    }

    def execute(self, path: str, severity: str = "medium") -> ToolResult:
        path = Path(path)
        results = []

        # Python security scan
        if path.suffix == ".py" or list(path.glob("**/*.py") if path.is_dir() else []):
            py_result = self._scan_python(path, severity)
            if py_result:
                results.append(py_result)

        # Check for requirements.txt vulnerabilities
        req_files = list(path.glob("**/requirements*.txt") if path.is_dir() else [])
        if req_files or (path / "requirements.txt").exists():
            dep_result = self._scan_python_deps(path)
            if dep_result:
                results.append(dep_result)

        # Node.js security scan
        if (path / "package.json").exists() if path.is_dir() else False:
            js_result = self._scan_javascript(path)
            if js_result:
                results.append(js_result)

        if not results:
            return ToolResult(success=True, output="No security issues found (or no scanners available)")

        return ToolResult(
            success=all(r.get("success", True) for r in results),
            output="\n\n".join(r.get("output", "") for r in results)[:8000]
        )

    def _scan_python(self, path: Path, severity: str) -> dict | None:
        try:
            sev_map = {"low": "l", "medium": "m", "high": "h"}
            cmd = ["bandit", "-r", str(path), "-f", "txt", f"-l{sev_map.get(severity, 'm')}"]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
            output = result.stdout or "No issues found"

            return {"success": True, "output": f"[Bandit Python Security Scan]\n{output}"}
        except FileNotFoundError:
            return None
        except Exception:
            return None

    def _scan_python_deps(self, path: Path) -> dict | None:
        try:
            cmd = ["safety", "check", "-r", str(path / "requirements.txt")]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            output = result.stdout or result.stderr or "No vulnerable dependencies found"

            return {"success": result.returncode == 0, "output": f"[Dependency Security]\n{output}"}
        except FileNotFoundError:
            return None
        except Exception:
            return None

    def _scan_javascript(self, path: Path) -> dict | None:
        try:
            result = subprocess.run(
                ["npm", "audit", "--json"],
                capture_output=True, text=True, timeout=60, cwd=path
            )

            try:
                audit_data = json.loads(result.stdout)
                vulns = audit_data.get("metadata", {}).get("vulnerabilities", {})
                summary = f"Critical: {vulns.get('critical', 0)}, High: {vulns.get('high', 0)}, Medium: {vulns.get('moderate', 0)}"
                return {"success": True, "output": f"[npm audit]\n{summary}\n\n{result.stdout[:2000]}"}
            except json.JSONDecodeError:
                return {"success": True, "output": f"[npm audit]\n{result.stdout[:2000]}"}
        except Exception:
            return None


class CodeComplexityTool(Tool):
    """Analyze code complexity."""

    name = "complexity"
    description = "Analyze code complexity (cyclomatic complexity, lines of code, etc.)"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to analyze"},
        },
        "required": ["path"],
    }

    def execute(self, path: str) -> ToolResult:
        path = Path(path)

        if not path.exists():
            return ToolResult(success=False, output="", error=f"Path not found: {path}")

        try:
            # Try radon for Python
            cmd = ["radon", "cc", str(path), "-s", "-a"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

            if result.returncode == 0:
                output = result.stdout or "No complexity data"

                # Also get maintainability index
                mi_result = subprocess.run(
                    ["radon", "mi", str(path), "-s"],
                    capture_output=True, text=True, timeout=60
                )

                output += f"\n\n[Maintainability Index]\n{mi_result.stdout}"

                return ToolResult(success=True, output=output[:5000])
            else:
                return ToolResult(success=False, output="", error=result.stderr)

        except FileNotFoundError:
            # Fallback: basic line count analysis
            return self._basic_analysis(path)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))

    def _basic_analysis(self, path: Path) -> ToolResult:
        """Basic code analysis without external tools."""
        stats = {"files": 0, "lines": 0, "code_lines": 0, "comment_lines": 0, "blank_lines": 0}

        files = [path] if path.is_file() else list(path.rglob("*.py"))

        for f in files:
            try:
                with open(f) as fp:
                    for line in fp:
                        stats["lines"] += 1
                        stripped = line.strip()
                        if not stripped:
                            stats["blank_lines"] += 1
                        elif stripped.startswith("#"):
                            stats["comment_lines"] += 1
                        else:
                            stats["code_lines"] += 1
                stats["files"] += 1
            except Exception:
                continue

        output = f"""Basic Code Analysis:
Files: {stats['files']}
Total Lines: {stats['lines']}
Code Lines: {stats['code_lines']}
Comment Lines: {stats['comment_lines']}
Blank Lines: {stats['blank_lines']}
Comment Ratio: {stats['comment_lines'] / max(stats['code_lines'], 1) * 100:.1f}%
"""
        return ToolResult(success=True, output=output)


class FindDeadCodeTool(Tool):
    """Find unused/dead code."""

    name = "find_dead_code"
    description = "Find unused imports, variables, and functions"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to analyze"},
        },
        "required": ["path"],
    }

    def execute(self, path: str) -> ToolResult:
        try:
            # Try vulture for Python dead code detection
            result = subprocess.run(
                ["vulture", path, "--min-confidence", "80"],
                capture_output=True, text=True, timeout=120
            )

            output = result.stdout or "No dead code found"
            lines = output.strip().split("\n") if output.strip() else []
            count = len([l for l in lines if l.strip()])

            return ToolResult(
                success=True,
                output=f"Found {count} potential dead code issues:\n\n{output[:5000]}"
            )
        except FileNotFoundError:
            # Fallback: use pyflakes
            try:
                result = subprocess.run(
                    ["pyflakes", path],
                    capture_output=True, text=True, timeout=60
                )
                output = result.stdout or "No issues found"
                return ToolResult(success=True, output=f"[pyflakes]\n{output[:5000]}")
            except FileNotFoundError:
                return ToolResult(
                    success=False, output="",
                    error="No dead code detector found. Install: pip install vulture pyflakes"
                )
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GetDiagnosticsTool(Tool):
    """Get all diagnostics for a file/project."""

    name = "get_diagnostics"
    description = "Get all code diagnostics (errors, warnings) for a file or project"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "File or directory to check"},
        },
        "required": ["path"],
    }

    def execute(self, path: str) -> ToolResult:
        path_obj = Path(path)
        diagnostics = []

        # Python syntax check
        if path_obj.suffix == ".py" or path_obj.is_dir():
            py_files = [path_obj] if path_obj.is_file() else list(path_obj.rglob("*.py"))
            for f in py_files[:20]:  # Limit to 20 files
                try:
                    result = subprocess.run(
                        ["python3", "-m", "py_compile", str(f)],
                        capture_output=True, text=True, timeout=10
                    )
                    if result.returncode != 0:
                        diagnostics.append(f"[ERROR] {f}: {result.stderr.strip()}")
                except Exception:
                    pass

        # Run quick lint
        try:
            result = subprocess.run(
                ["ruff", "check", path, "--output-format=text"],
                capture_output=True, text=True, timeout=60
            )
            if result.stdout:
                for line in result.stdout.strip().split("\n")[:50]:
                    if line.strip():
                        diagnostics.append(f"[WARN] {line}")
        except FileNotFoundError:
            # Try flake8
            try:
                result = subprocess.run(
                    ["flake8", path, "--max-line-length=100"],
                    capture_output=True, text=True, timeout=60
                )
                if result.stdout:
                    for line in result.stdout.strip().split("\n")[:50]:
                        if line.strip():
                            diagnostics.append(f"[WARN] {line}")
            except FileNotFoundError:
                pass
        except Exception:
            pass

        if not diagnostics:
            return ToolResult(success=True, output="No diagnostics found - code looks clean!")

        return ToolResult(
            success=True,
            output=f"Found {len(diagnostics)} diagnostics:\n\n" + "\n".join(diagnostics[:100])
        )
