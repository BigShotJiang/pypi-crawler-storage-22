"""Code generation and parsing utilities"""

import re


def extract_code_blocks(text: str) -> list[dict]:
    """
    Extract code blocks from markdown-formatted text.

    Returns:
        List of dicts with 'language' and 'code' keys
    """
    pattern = r"```(\w*)\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)

    return [
        {"language": lang or "text", "code": code.strip()}
        for lang, code in matches
    ]


def build_code_prompt(
    request: str,
    context: str | None = None,
    language: str | None = None,
) -> str:
    """
    Build a prompt for code generation.

    Args:
        request: What the user wants
        context: Additional context (file contents, search results)
        language: Preferred programming language

    Returns:
        Formatted prompt string
    """
    parts = []

    if context:
        parts.append(f"Context:\n{context}\n")

    if language:
        parts.append(f"Language: {language}\n")

    parts.append(f"Request: {request}")

    return "\n".join(parts)


def build_explain_prompt(code: str, question: str | None = None) -> str:
    """Build a prompt for code explanation."""
    prompt = f"Explain this code:\n\n```\n{code}\n```"

    if question:
        prompt += f"\n\nSpecifically: {question}"

    return prompt
