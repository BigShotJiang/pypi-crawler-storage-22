"""Concrete tool definitions for Kairo Code"""

import os
import re
import shutil
import subprocess
import shlex

from .base import Tool, ToolResult, ToolRegistry
from .files import read_file, write_file, edit_file, list_files, search_files, tree
from .search import web_search, web_fetch, format_search_results

# Import new analysis and review tools
from .analysis import (
    LintTool,
    TypeCheckTool,
    RunTestsTool,
    SecurityScanTool,
    CodeComplexityTool,
    FindDeadCodeTool,
    GetDiagnosticsTool,
)
from .review import (
    CodeReviewTool,
    ModularityCheckTool,
    DependencyGraphTool,
)


class ReadFileTool(Tool):
    name = "read_file"
    description = "Read the contents of a file with line numbers. Use offset/limit for large files."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to the file to read"},
            "offset": {"type": "integer", "description": "Line number to start from (0-indexed)"},
            "limit": {"type": "integer", "description": "Max lines to read (default 500)"},
        },
        "required": ["path"],
    }

    def execute(self, path: str, offset: int = 0, limit: int = None) -> ToolResult:
        try:
            content = read_file(path, offset=offset, limit=limit)
            return ToolResult(success=True, output=content)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class WriteFileTool(Tool):
    name = "write_file"
    description = "Write content to a file, creating it if needed. For modifications, prefer edit_file instead."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to write the file"},
            "content": {"type": "string", "description": "Content to write"},
        },
        "required": ["path", "content"],
    }

    def execute(self, path: str = None, content: str = None) -> ToolResult:
        # Validate required parameters
        if not path:
            return ToolResult(
                success=False,
                output="",
                error="Missing 'path' parameter. Usage: write_file({\"path\": \"filename.py\", \"content\": \"code here\"})"
            )
        if content is None:
            return ToolResult(
                success=False,
                output="",
                error="Missing 'content' parameter. You MUST provide the file content. Usage: write_file({\"path\": \"filename.py\", \"content\": \"your code here\"})"
            )

        # Convert literal \n to actual newlines if needed
        if '\\n' in content and '\n' not in content:
            content = content.replace('\\n', '\n')
            content = content.replace('\\t', '\t')
            content = content.replace('\\"', '"')

        # Strip trailing incomplete escape sequences
        while content.endswith('\\') and not content.endswith('\\\\'):
            content = content[:-1]

        try:
            result = write_file(path, content)
            return ToolResult(success=True, output=result)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class EditFileTool(Tool):
    name = "edit_file"
    description = "Make targeted edits by replacing old_string with new_string. PREFERRED over write_file for modifications."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to the file to edit"},
            "old_string": {"type": "string", "description": "Exact string to find (must be unique in file)"},
            "new_string": {"type": "string", "description": "String to replace it with"},
        },
        "required": ["path", "old_string", "new_string"],
    }

    def execute(self, path: str, old_string: str, new_string: str) -> ToolResult:
        try:
            result = edit_file(path, old_string, new_string)
            return ToolResult(success=True, output=result)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class ListFilesTool(Tool):
    name = "list_files"
    description = "List files matching a glob pattern (e.g., '*.py', '**/*.js')"
    parameters = {
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Glob pattern to match"},
            "root": {"type": "string", "description": "Root directory (optional, defaults to cwd)"},
        },
        "required": ["pattern"],
    }

    def execute(self, pattern: str, root: str | None = None) -> ToolResult:
        try:
            files = list_files(pattern, root)
            output = "\n".join(files) if files else "No files found"
            return ToolResult(success=True, output=output)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class SearchFilesTool(Tool):
    name = "search_files"
    description = "Search for text within files (like grep). Returns matching lines with file and line number."
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Text to search for (case-insensitive)"},
            "pattern": {"type": "string", "description": "File glob pattern (default: **/*)"},
            "context_lines": {"type": "integer", "description": "Lines of context around match (default: 0)"},
        },
        "required": ["query"],
    }

    def execute(self, query: str, pattern: str = "**/*", context_lines: int = 0) -> ToolResult:
        try:
            results = search_files(query, pattern, context_lines=context_lines)
            if not results:
                return ToolResult(success=True, output="No matches found")

            output_lines = []
            for r in results:
                if "context" in r:
                    output_lines.append(f"\n{r['file']}:{r['line']}:")
                    output_lines.append(r["context"])
                else:
                    output_lines.append(f"{r['file']}:{r['line']}: {r['content']}")

            return ToolResult(success=True, output="\n".join(output_lines))
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class TreeTool(Tool):
    name = "tree"
    description = "Show directory structure as a tree view"
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Directory to show (default: current directory)"},
            "max_depth": {"type": "integer", "description": "Maximum depth to traverse (default: 3)"},
        },
        "required": [],
    }

    def execute(self, path: str = ".", max_depth: int = 3) -> ToolResult:
        try:
            output = tree(path, max_depth=max_depth)
            return ToolResult(success=True, output=output)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class WebSearchTool(Tool):
    name = "web_search"
    description = "Search the web for current information using DuckDuckGo"
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
        },
        "required": ["query"],
    }

    def execute(self, query: str) -> ToolResult:
        try:
            results = web_search(query, max_results=5)
            output = format_search_results(results)
            return ToolResult(success=True, output=output)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class WebFetchTool(Tool):
    name = "web_fetch"
    description = "Fetch a URL and extract its text content. Use this to read API documentation, articles, etc."
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "URL to fetch"},
        },
        "required": ["url"],
    }

    def execute(self, url: str) -> ToolResult:
        try:
            content = web_fetch(url, max_chars=8000)
            return ToolResult(success=True, output=content)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class BashTool(Tool):
    name = "bash"
    description = "Execute a shell command. Use for git, npm, pip, etc. Be careful with destructive commands."
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell command to execute"},
        },
        "required": ["command"],
    }

    # Comprehensive blocklist for dangerous commands
    BLOCKED_PATTERNS = [
        # Destructive file operations
        "rm -rf /", "rm -rf /*", "rm -rf ~", "rm -rf $HOME",
        "rm -rf .", "rm -r /",
        # System damage
        "mkfs", "dd if=", "> /dev/sd", "> /dev/null",
        "chmod 777 /", "chmod -R 777 /",
        "chown -R", ":(){:|:&};:",  # Fork bomb
        # Downloading and executing
        "curl | bash", "curl | sh", "wget | bash", "wget | sh",
        "curl -s | bash", "wget -q | sh",
        # Network attacks
        "nmap", "masscan",
        # History/credential theft
        "history -c", "> ~/.bash_history",
        # Privilege escalation
        "sudo rm", "sudo dd", "sudo mkfs",
    ]

    # Commands that need extra caution (will show warning)
    WARN_PATTERNS = [
        "rm -rf", "rm -r",
        "git push --force", "git push -f",
        "git reset --hard",
        "drop table", "drop database",
        "truncate",
    ]

    # Python command patterns that may fail if Python isn't installed
    PYTHON_PATTERNS = ["python ", "python3 ", "python.exe"]

    def _get_python_command(self) -> str | None:
        """Get the available Python command, preferring python3."""
        # Check environment variable set by main.py
        env_cmd = os.environ.get("KAIRO_PYTHON_CMD")
        if env_cmd and shutil.which(env_cmd):
            return env_cmd
        # Fallback: check directly
        for cmd in ["python3", "python"]:
            if shutil.which(cmd):
                return cmd
        return None

    def _get_python_install_hint(self) -> str:
        """Get platform-specific Python install instructions."""
        import platform
        system = platform.system().lower()
        if "linux" in system:
            if shutil.which("apt-get"):
                return "sudo apt-get install python3"
            elif shutil.which("dnf"):
                return "sudo dnf install python3"
            elif shutil.which("pacman"):
                return "sudo pacman -S python"
            return "Install Python 3 using your package manager"
        elif "darwin" in system:
            return "brew install python3"
        elif "windows" in system:
            return "winget install Python.Python.3"
        return "Download from https://python.org"

    def _is_python_command(self, command: str) -> bool:
        """Check if command is trying to run Python."""
        cmd_lower = command.lower().strip()
        return any(cmd_lower.startswith(p) for p in self.PYTHON_PATTERNS)

    def _rewrite_python_command(self, command: str) -> str:
        """Rewrite 'python' to 'python3' if needed."""
        python_cmd = self._get_python_command()
        if not python_cmd:
            return command  # Can't help, let it fail with good error

        # Replace 'python ' with the correct command
        if command.strip().startswith("python "):
            return python_cmd + command[6:]
        return command

    def _make_noninteractive(self, command: str) -> str:
        """Add flags to make commands non-interactive (prevents hangs)."""
        # apt/apt-get install needs -y for non-interactive mode
        # Match apt-get install or apt install without -y
        if re.search(r'\b(apt-get|apt)\s+install\b', command) and ' -y' not in command:
            # Insert -y after install
            command = re.sub(
                r'\b(apt-get|apt)\s+install\b',
                r'\1 install -y',
                command
            )
        # pip install with --yes doesn't exist, but pip is non-interactive by default
        return command

    def execute(self, command: str) -> ToolResult:
        # Check for blocked commands
        command_lower = command.lower()
        for pattern in self.BLOCKED_PATTERNS:
            if pattern.lower() in command_lower:
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Command blocked for safety: contains '{pattern}'"
                )

        # Check for warning patterns (still execute but warn)
        warnings = []
        for pattern in self.WARN_PATTERNS:
            if pattern.lower() in command_lower:
                warnings.append(f"Warning: command contains '{pattern}'")

        # Check if this is a Python command and handle accordingly
        is_python_cmd = self._is_python_command(command)
        if is_python_cmd:
            python_cmd = self._get_python_command()
            if not python_cmd:
                # Python not installed at all
                hint = self._get_python_install_hint()
                return ToolResult(
                    success=False,
                    output="",
                    error=f"Python is not installed on this system.\n"
                          f"Install it with: {hint}\n"
                          f"Then try running the command again."
                )
            # Rewrite 'python' to the correct command (e.g., 'python3')
            command = self._rewrite_python_command(command)

        # Make interactive commands non-interactive (prevents hangs)
        command = self._make_noninteractive(command)

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
                cwd=None,  # Use current directory
            )

            output = result.stdout
            if result.stderr:
                output += f"\n[stderr]: {result.stderr}"

            if warnings:
                output = "\n".join(warnings) + "\n\n" + output

            # Special handling for exit code 127 (command not found)
            if result.returncode == 127:
                error_msg = f"Exit code: 127 (command not found)"
                if is_python_cmd:
                    hint = self._get_python_install_hint()
                    error_msg += f"\nPython may not be installed. Install with: {hint}"
                return ToolResult(
                    success=False,
                    output=output[:10000],
                    error=error_msg,
                )

            return ToolResult(
                success=result.returncode == 0,
                output=output[:10000],  # Limit output size
                error=None if result.returncode == 0 else f"Exit code: {result.returncode}",
            )

        except subprocess.TimeoutExpired:
            return ToolResult(
                success=False,
                output="",
                error="Command timed out after 120 seconds"
            )
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GitStatusTool(Tool):
    name = "git_status"
    description = "Show git status (staged, unstaged, untracked files)"
    parameters = {
        "type": "object",
        "properties": {},
        "required": [],
    }

    def execute(self) -> ToolResult:
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain", "-b"],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                return ToolResult(
                    success=False,
                    output="",
                    error=result.stderr or "Not a git repository"
                )

            return ToolResult(success=True, output=result.stdout)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GitDiffTool(Tool):
    name = "git_diff"
    description = "Show git diff (unstaged changes, or staged with --staged)"
    parameters = {
        "type": "object",
        "properties": {
            "staged": {"type": "boolean", "description": "Show staged changes only"},
            "file": {"type": "string", "description": "Specific file to diff (optional)"},
        },
        "required": [],
    }

    def execute(self, staged: bool = False, file: str = None) -> ToolResult:
        try:
            cmd = ["git", "diff"]
            if staged:
                cmd.append("--staged")
            if file:
                cmd.append(file)

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )

            output = result.stdout or "(no changes)"
            return ToolResult(success=True, output=output[:10000])
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GitCommitTool(Tool):
    name = "git_commit"
    description = "Stage files and create a git commit"
    parameters = {
        "type": "object",
        "properties": {
            "message": {"type": "string", "description": "Commit message"},
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to stage (use ['.'] for all)",
            },
        },
        "required": ["message"],
    }

    def execute(self, message: str, files: list[str] | None = None) -> ToolResult:
        try:
            # Stage files
            stage_files = files or ["."]
            result = subprocess.run(
                ["git", "add"] + stage_files,
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return ToolResult(success=False, output="", error=f"git add failed: {result.stderr}")

            # Commit
            result = subprocess.run(
                ["git", "commit", "-m", message],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return ToolResult(success=False, output="", error=result.stderr or "Nothing to commit")

            return ToolResult(success=True, output=result.stdout)
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


class GitPushTool(Tool):
    name = "git_push"
    description = "Push commits to remote repository"
    parameters = {
        "type": "object",
        "properties": {
            "remote": {"type": "string", "description": "Remote name (default: origin)"},
            "branch": {"type": "string", "description": "Branch name (default: current branch)"},
        },
        "required": [],
    }

    def execute(self, remote: str = "origin", branch: str | None = None) -> ToolResult:
        try:
            cmd = ["git", "push", remote]
            if branch:
                cmd.append(branch)

            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=60,
            )
            output = result.stdout + result.stderr
            if result.returncode != 0:
                return ToolResult(success=False, output="", error=output or "Push failed")

            return ToolResult(success=True, output=output or "Push successful")
        except Exception as e:
            return ToolResult(success=False, output="", error=str(e))


def create_default_registry() -> ToolRegistry:
    """Create a registry with all default tools."""
    registry = ToolRegistry()

    # File tools
    registry.register(ReadFileTool())
    registry.register(WriteFileTool())
    registry.register(EditFileTool())
    registry.register(ListFilesTool())
    registry.register(SearchFilesTool())
    registry.register(TreeTool())

    # Web tools
    registry.register(WebSearchTool())
    registry.register(WebFetchTool())

    # Shell tools
    registry.register(BashTool())

    # Git tools
    registry.register(GitStatusTool())
    registry.register(GitDiffTool())
    registry.register(GitCommitTool())
    registry.register(GitPushTool())

    # Code analysis tools
    registry.register(LintTool())
    registry.register(TypeCheckTool())
    registry.register(RunTestsTool())
    registry.register(SecurityScanTool())
    registry.register(CodeComplexityTool())
    registry.register(FindDeadCodeTool())
    registry.register(GetDiagnosticsTool())

    # Code review tools
    registry.register(CodeReviewTool())
    registry.register(ModularityCheckTool())
    registry.register(DependencyGraphTool())

    return registry


def create_readonly_registry() -> ToolRegistry:
    """Create a registry with only read-only tools (for planning/exploring)."""
    registry = ToolRegistry()

    # Read-only file tools
    registry.register(ReadFileTool())
    registry.register(ListFilesTool())
    registry.register(SearchFilesTool())
    registry.register(TreeTool())

    # Web tools (read-only)
    registry.register(WebSearchTool())
    registry.register(WebFetchTool())

    # Git tools (read-only)
    registry.register(GitStatusTool())
    registry.register(GitDiffTool())

    # Code analysis tools (read-only — they inspect but don't modify)
    registry.register(LintTool())
    registry.register(TypeCheckTool())
    registry.register(SecurityScanTool())
    registry.register(CodeComplexityTool())
    registry.register(FindDeadCodeTool())
    registry.register(GetDiagnosticsTool())
    registry.register(CodeReviewTool())
    registry.register(ModularityCheckTool())
    registry.register(DependencyGraphTool())

    return registry
