"""File operation tools for Kairo Code"""

import os
from pathlib import Path
from glob import glob

from ..sandbox import get_sandbox


# Constants for file operations
MAX_READ_LINES = 500
MAX_LINE_LENGTH = 1000
TRUNCATION_WARNING = "\n... [File truncated. Use offset/limit to read more] ..."


def read_file(
    path: str,
    offset: int = 0,
    limit: int | None = None,
    show_line_numbers: bool = True
) -> str:
    """
    Read and return file contents with line numbers.

    Args:
        path: Path to the file
        offset: Line number to start from (0-indexed)
        limit: Maximum number of lines to read (default: MAX_READ_LINES)
        show_line_numbers: Whether to prefix lines with numbers

    Returns:
        File contents with optional line numbers
    """
    # Validate path through sandbox
    sandbox = get_sandbox()
    valid, error, filepath = sandbox.validate_path(path, "read")
    if not valid:
        raise PermissionError(error)

    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {path}")

    if not filepath.is_file():
        raise ValueError(f"Not a file: {path}")

    # Check file size first
    file_size = filepath.stat().st_size
    if file_size > 10 * 1024 * 1024:  # 10MB
        raise ValueError(f"File too large ({file_size // 1024 // 1024}MB). Max is 10MB.")

    limit = limit or MAX_READ_LINES

    with open(filepath, 'r', errors='replace') as f:
        lines = f.readlines()

    total_lines = len(lines)

    # Apply offset and limit
    selected_lines = lines[offset:offset + limit]
    truncated = len(lines) > offset + limit

    # Format output
    output_lines = []

    # Add file info header
    output_lines.append(f"# File: {filepath}")
    output_lines.append(f"# Lines: {offset + 1}-{min(offset + len(selected_lines), total_lines)} of {total_lines}")
    output_lines.append("")

    for i, line in enumerate(selected_lines, start=offset + 1):
        # Truncate long lines
        line = line.rstrip('\n\r')
        if len(line) > MAX_LINE_LENGTH:
            line = line[:MAX_LINE_LENGTH] + "... [line truncated]"

        if show_line_numbers:
            output_lines.append(f"{i:4d} | {line}")
        else:
            output_lines.append(line)

    if truncated:
        output_lines.append(TRUNCATION_WARNING)
        output_lines.append(f"# To continue: read_file(\"{path}\", offset={offset + limit})")

    return "\n".join(output_lines)


def write_file(path: str, content: str) -> str:
    """Write content to a file. Creates parent directories if needed."""
    # Use sandbox for safe writes
    sandbox = get_sandbox()
    return sandbox.safe_write(path, content)


def edit_file(path: str, old_string: str, new_string: str) -> str:
    """
    Make a targeted edit to a file by replacing old_string with new_string.

    This is the PREFERRED way to modify files - more reliable than full rewrites.

    Args:
        path: Path to the file
        old_string: Exact string to find and replace (must be unique in file)
        new_string: String to replace it with

    Returns:
        Confirmation message with diff preview
    """
    sandbox = get_sandbox()
    valid, error, filepath = sandbox.validate_path(path, "write")
    if not valid:
        raise PermissionError(error)

    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {path}")

    content = filepath.read_text()

    # Check that old_string exists and is unique
    count = content.count(old_string)

    if count == 0:
        # Try to provide helpful feedback
        lines = content.split('\n')
        for i, line in enumerate(lines, 1):
            if old_string[:50] in line:  # Check partial match
                raise ValueError(
                    f"Exact match not found, but similar content at line {i}. "
                    f"Make sure old_string matches exactly including whitespace."
                )
        raise ValueError(f"old_string not found in file. Read the file first to see current content.")

    if count > 1:
        raise ValueError(
            f"old_string appears {count} times in file. "
            f"Provide more context to make it unique."
        )

    # Perform the replacement
    new_content = content.replace(old_string, new_string, 1)
    filepath.write_text(new_content)

    # Generate a simple diff preview
    old_preview = old_string[:100] + ("..." if len(old_string) > 100 else "")
    new_preview = new_string[:100] + ("..." if len(new_string) > 100 else "")

    return f"""Edit successful: {filepath}

Changed:
- {old_preview}
+ {new_preview}
"""


def list_files(pattern: str, root: str | None = None, max_results: int = 100) -> list[str]:
    """
    List files matching a glob pattern.

    Args:
        pattern: Glob pattern (e.g., "*.py", "**/*.js")
        root: Root directory to search from (defaults to cwd)
        max_results: Maximum number of results to return

    Returns:
        List of matching file paths
    """
    root_path = Path(root).resolve() if root else Path.cwd()
    matches = glob(str(root_path / pattern), recursive=True)

    # Sort by modification time (newest first) and limit
    matches.sort(key=lambda x: os.path.getmtime(x), reverse=True)

    return matches[:max_results]


def search_files(
    query: str,
    pattern: str = "**/*",
    root: str | None = None,
    context_lines: int = 0,
    max_results: int = 50
) -> list[dict]:
    """
    Search for text in files matching a pattern.

    Args:
        query: Text to search for (case-insensitive)
        pattern: Glob pattern for files to search
        root: Root directory
        context_lines: Number of lines of context before/after match
        max_results: Maximum number of matches to return

    Returns:
        List of dicts with file, line_number, content, and context
    """
    root_path = Path(root).resolve() if root else Path.cwd()
    results = []

    # Skip binary and large files
    skip_extensions = {'.pyc', '.pyo', '.so', '.dylib', '.dll', '.exe', '.bin',
                       '.jpg', '.jpeg', '.png', '.gif', '.ico', '.pdf', '.zip',
                       '.tar', '.gz', '.node', '.woff', '.woff2', '.ttf'}

    for filepath in glob(str(root_path / pattern), recursive=True):
        path = Path(filepath)

        if not path.is_file():
            continue

        if path.suffix.lower() in skip_extensions:
            continue

        # Skip large files
        try:
            if path.stat().st_size > 1024 * 1024:  # 1MB
                continue
        except OSError:
            continue

        try:
            lines = path.read_text(errors='replace').splitlines()

            for i, line in enumerate(lines):
                if query.lower() in line.lower():
                    result = {
                        "file": str(path),
                        "line": i + 1,
                        "content": line.strip()[:200]
                    }

                    # Add context if requested
                    if context_lines > 0:
                        start = max(0, i - context_lines)
                        end = min(len(lines), i + context_lines + 1)
                        result["context"] = "\n".join(
                            f"{j + 1}: {lines[j]}"
                            for j in range(start, end)
                        )

                    results.append(result)

                    if len(results) >= max_results:
                        return results

        except (UnicodeDecodeError, PermissionError, OSError):
            continue

    return results


def tree(path: str = ".", max_depth: int = 3, max_files: int = 100) -> str:
    """
    Generate a tree view of directory structure.

    Args:
        path: Root directory to display
        max_depth: Maximum depth to traverse
        max_files: Maximum number of files to show

    Returns:
        Formatted tree string
    """
    root_path = Path(path).expanduser().resolve()

    if not root_path.exists():
        raise FileNotFoundError(f"Directory not found: {path}")

    if not root_path.is_dir():
        raise ValueError(f"Not a directory: {path}")

    output = [f"{root_path.name}/"]
    file_count = 0

    def _tree_recursive(current_path: Path, prefix: str, depth: int) -> None:
        nonlocal file_count

        if depth > max_depth or file_count >= max_files:
            return

        # Get contents, sorted (directories first, then files)
        try:
            contents = sorted(
                current_path.iterdir(),
                key=lambda p: (not p.is_dir(), p.name.lower())
            )
        except PermissionError:
            output.append(f"{prefix}[permission denied]")
            return

        # Skip hidden and common ignore patterns
        ignore_patterns = {'.git', '__pycache__', 'node_modules', '.venv', 'venv',
                          '.idea', '.vscode', '.pytest_cache', 'dist', 'build'}

        contents = [p for p in contents
                    if p.name not in ignore_patterns
                    and not p.name.startswith('.')]

        for i, item in enumerate(contents):
            if file_count >= max_files:
                output.append(f"{prefix}... [truncated, {max_files} items shown]")
                return

            is_last = i == len(contents) - 1
            connector = "└── " if is_last else "├── "
            next_prefix = prefix + ("    " if is_last else "│   ")

            if item.is_dir():
                output.append(f"{prefix}{connector}{item.name}/")
                _tree_recursive(item, next_prefix, depth + 1)
            else:
                output.append(f"{prefix}{connector}{item.name}")
                file_count += 1

    _tree_recursive(root_path, "", 1)
    return "\n".join(output)
