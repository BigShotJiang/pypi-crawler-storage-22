"""Web search and fetch tools"""

import ipaddress
import socket
import requests
from html.parser import HTMLParser
from urllib.parse import urlparse

try:
    from ddgs import DDGS  # New package name
except ImportError:
    from duckduckgo_search import DDGS  # Fallback to old name


# ── SSRF protection ────────────────────────────────────────────

_BLOCKED_SCHEMES = {"file", "ftp", "gopher", "data", "javascript"}

def _is_private_ip(ip_str: str) -> bool:
    """Check if an IP address is private/reserved (SSRF protection)."""
    try:
        addr = ipaddress.ip_address(ip_str)
        return (
            addr.is_private
            or addr.is_loopback
            or addr.is_reserved
            or addr.is_link_local
            or addr.is_multicast
        )
    except ValueError:
        return False


def _validate_url(url: str) -> None:
    """Validate a URL is safe to fetch (blocks private IPs, bad schemes)."""
    parsed = urlparse(url)

    # Block dangerous schemes
    if parsed.scheme.lower() in _BLOCKED_SCHEMES:
        raise ValueError(f"Blocked URL scheme: {parsed.scheme}")

    # Only allow http/https
    if parsed.scheme.lower() not in ("http", "https"):
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}")

    hostname = parsed.hostname
    if not hostname:
        raise ValueError("URL has no hostname")

    # Resolve hostname and check all IPs
    try:
        addrs = socket.getaddrinfo(hostname, parsed.port or 443)
        for family, _type, _proto, _canonname, sockaddr in addrs:
            ip = sockaddr[0]
            if _is_private_ip(ip):
                raise ValueError(
                    f"Blocked: {hostname} resolves to private/reserved IP {ip}"
                )
    except socket.gaierror:
        raise ValueError(f"Cannot resolve hostname: {hostname}")


class HTMLTextExtractor(HTMLParser):
    """Extract text content from HTML, removing scripts and styles."""

    def __init__(self):
        super().__init__()
        self.text_parts = []
        self.skip_data = False
        self.skip_tags = {'script', 'style', 'nav', 'footer', 'header'}

    def handle_starttag(self, tag, attrs):
        if tag in self.skip_tags:
            self.skip_data = True

    def handle_endtag(self, tag):
        if tag in self.skip_tags:
            self.skip_data = False

    def handle_data(self, data):
        if not self.skip_data:
            text = data.strip()
            if text:
                self.text_parts.append(text)

    def get_text(self) -> str:
        return ' '.join(self.text_parts)


def web_search(query: str, max_results: int = 5) -> list[dict]:
    """
    Search the web using DuckDuckGo.

    Args:
        query: Search query
        max_results: Maximum number of results to return

    Returns:
        List of search results with title, url, and body
    """
    with DDGS() as ddgs:
        results = list(ddgs.text(query, max_results=max_results))

    return [
        {
            "title": r.get("title", ""),
            "url": r.get("href", ""),
            "snippet": r.get("body", ""),
        }
        for r in results
    ]


def format_search_results(results: list[dict]) -> str:
    """Format search results for LLM context."""
    if not results:
        return "No search results found."

    formatted = []
    for i, r in enumerate(results, 1):
        formatted.append(
            f"{i}. **{r['title']}**\n"
            f"   URL: {r['url']}\n"
            f"   {r['snippet']}\n"
        )

    return "\n".join(formatted)


def web_fetch(url: str, max_chars: int = 8000) -> str:
    """
    Fetch a URL and extract text content.

    Args:
        url: The URL to fetch
        max_chars: Maximum characters to return (default 8000)

    Returns:
        Extracted text content from the page
    """
    # SSRF protection: validate URL before fetching
    _validate_url(url)

    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        # Follow redirects manually so we can validate each hop
        max_redirects = 5
        current_url = url
        response = None
        for _ in range(max_redirects):
            response = requests.get(current_url, headers=headers, timeout=30, allow_redirects=False)
            if response.is_redirect and "Location" in response.headers:
                current_url = response.headers["Location"]
                _validate_url(current_url)
                continue
            break
        response.raise_for_status()

        content_type = response.headers.get('content-type', '')

        # If it's JSON, return formatted JSON
        if 'application/json' in content_type:
            import json
            try:
                data = response.json()
                return json.dumps(data, indent=2)[:max_chars]
            except Exception:
                return response.text[:max_chars]

        # If it's HTML, extract text
        if 'text/html' in content_type:
            extractor = HTMLTextExtractor()
            extractor.feed(response.text)
            text = extractor.get_text()
            return text[:max_chars]

        # Otherwise return raw text
        return response.text[:max_chars]

    except requests.exceptions.Timeout:
        raise TimeoutError("Request timed out fetching URL")
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Error fetching URL: {e}") from e
