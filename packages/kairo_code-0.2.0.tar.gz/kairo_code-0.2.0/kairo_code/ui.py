"""Claude Code-inspired UI formatting for Kairo Code"""

import re
import time
from dataclasses import dataclass, field
from typing import Generator, Optional
from rich.console import Console, Group
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich.live import Live
from rich.spinner import Spinner
from rich.table import Table
from rich.box import ROUNDED, SIMPLE
from rich.rule import Rule
from rich.style import Style
from rich.padding import Padding


console = Console()


@dataclass
class ToolExecution:
    """Tracks a tool execution for display."""
    tool_name: str
    params: dict
    start_time: float = field(default_factory=time.time)
    result: Optional[str] = None
    success: bool = True
    end_time: Optional[float] = None

    @property
    def duration(self) -> float:
        end = self.end_time or time.time()
        return end - self.start_time

    @property
    def duration_str(self) -> str:
        d = self.duration
        if d < 1:
            return f"{d*1000:.0f}ms"
        elif d < 60:
            return f"{d:.1f}s"
        else:
            mins = int(d // 60)
            secs = int(d % 60)
            return f"{mins}m {secs}s"


class OutputFormatter:
    """
    Formats agent output in Claude Code style.

    Features:
    - Boxed tool calls with bullet points
    - Collapsible long output
    - Diff view for file edits
    - Timing information
    - Spinners during execution
    """

    TOOL_PATTERN = re.compile(r'<tool>(\w+)</tool>')
    PARAMS_PATTERN = re.compile(r'<params>(.*?)</params>', re.DOTALL)
    THINKING_PATTERN = re.compile(r'<thinking>(.*?)</thinking>', re.DOTALL)

    # Tool display names (Claude Code style)
    TOOL_NAMES = {
        "read_file": "Read",
        "write_file": "Write",
        "edit_file": "Edit",
        "list_files": "Glob",
        "search_files": "Grep",
        "tree": "Tree",
        "bash": "Bash",
        "web_search": "WebSearch",
        "web_fetch": "WebFetch",
        "lint": "Lint",
        "typecheck": "TypeCheck",
        "run_tests": "Test",
        "security_scan": "Security",
        "code_review": "Review",
    }

    def __init__(self):
        self.in_tool_call = False
        self.current_tool: Optional[ToolExecution] = None
        self.buffer = ""
        self.session_start = time.time()
        self.collapsed_lines = 6  # Show this many lines before collapsing

    def format_tool_header(self, tool_name: str, params: dict) -> Text:
        """Format tool call header like Claude Code: ● Bash(command)"""
        display_name = self.TOOL_NAMES.get(tool_name, tool_name.title())

        # Build parameter preview
        param_preview = self._get_param_preview(tool_name, params)

        text = Text()
        text.append("● ", style="cyan bold")
        text.append(display_name, style="cyan bold")
        text.append(f"({param_preview})", style="dim")

        return text

    def _get_param_preview(self, tool_name: str, params: dict) -> str:
        """Get a concise parameter preview for tool header."""
        if tool_name in ("read_file", "write_file", "edit_file"):
            path = params.get("path", params.get("file", ""))
            return self._truncate(path, 50)
        elif tool_name == "bash":
            cmd = params.get("command", "")
            return self._truncate(cmd, 60)
        elif tool_name == "list_files":
            return params.get("pattern", "*")
        elif tool_name == "search_files":
            query = params.get("query", params.get("pattern", ""))
            return f'"{self._truncate(query, 40)}"'
        elif tool_name == "web_search":
            return f'"{self._truncate(params.get("query", ""), 40)}"'
        elif tool_name == "web_fetch":
            return self._truncate(params.get("url", ""), 50)
        else:
            # Generic: show first param value
            for v in params.values():
                if isinstance(v, str):
                    return self._truncate(v, 40)
            return "..."

    def _truncate(self, text: str, max_len: int) -> str:
        """Truncate text with ellipsis."""
        text = text.replace("\n", " ").strip()
        if len(text) > max_len:
            return text[:max_len-1] + "…"
        return text

    def format_tool_output(self, output: str, success: bool = True) -> Text:
        """Format tool output with collapsing for long content."""
        if not output:
            return Text("  ⎿  (No content)", style="dim")

        lines = output.split("\n")
        text = Text()

        if not success:
            text.append("  ⎿  ", style="dim")
            text.append("Error: ", style="red bold")
            text.append(self._truncate(output, 100), style="red")
            return text

        # Show output with collapse indicator
        if len(lines) <= self.collapsed_lines:
            # Short output - show all
            for i, line in enumerate(lines):
                text.append("  ⎿  " if i == 0 else "     ", style="dim")
                text.append(self._truncate(line, 100) + "\n", style="dim")
        else:
            # Long output - show preview with collapse hint
            for i, line in enumerate(lines[:3]):
                text.append("  ⎿  " if i == 0 else "     ", style="dim")
                text.append(self._truncate(line, 100) + "\n", style="dim")
            text.append(f"     … +{len(lines) - 3} lines (ctrl+o to expand)\n", style="dim italic")

        return text

    def format_file_diff(self, old_content: str, new_content: str, path: str) -> Text:
        """Format a file edit as a diff view."""
        text = Text()
        text.append("  ⎿  ", style="dim")

        old_lines = old_content.split("\n") if old_content else []
        new_lines = new_content.split("\n") if new_content else []

        added = len(new_lines) - len(old_lines)
        if added > 0:
            text.append(f"Added {added} line{'s' if added != 1 else ''}", style="green")
        elif added < 0:
            text.append(f"Removed {-added} line{'s' if -added != 1 else ''}", style="red")
        else:
            text.append("Modified", style="yellow")

        return text

    def format_edit_preview(self, old_str: str, new_str: str) -> Text:
        """Format an edit operation showing old vs new."""
        text = Text()

        old_lines = old_str.strip().split("\n")
        new_lines = new_str.strip().split("\n")

        # Show a few lines of context
        max_preview = 4

        for i, line in enumerate(old_lines[:max_preview]):
            text.append("      ", style="dim")
            text.append(f"{i+1:4} ", style="dim")
            text.append("-", style="red")
            text.append(self._truncate(line, 70) + "\n", style="red dim")

        for i, line in enumerate(new_lines[:max_preview]):
            text.append("      ", style="dim")
            text.append(f"{i+1:4} ", style="dim")
            text.append("+", style="green")
            text.append(self._truncate(line, 70) + "\n", style="green")

        if len(old_lines) > max_preview or len(new_lines) > max_preview:
            text.append(f"      … more changes\n", style="dim italic")

        return text

    def format_session_time(self) -> str:
        """Format total session time like 'Churned for 1m 28s'."""
        elapsed = time.time() - self.session_start

        verbs = ["Crunched", "Churned", "Processed", "Computed"]
        verb = verbs[int(elapsed) % len(verbs)]

        if elapsed < 60:
            return f"✻ {verb} for {elapsed:.0f}s"
        else:
            mins = int(elapsed // 60)
            secs = int(elapsed % 60)
            return f"✻ {verb} for {mins}m {secs}s"

    def stream_formatted(self, raw_stream: Generator[str, None, str]) -> Generator[str, None, None]:
        """Transform raw agent stream into Claude Code-style output."""
        buffer = ""
        in_thinking = False

        for chunk in raw_stream:
            buffer += chunk

            while "\n" in buffer:
                idx = buffer.find("\n")
                line = buffer[:idx]
                buffer = buffer[idx + 1:]

                result = self._process_line(line, in_thinking)

                if "<thinking>" in line:
                    in_thinking = True
                if "</thinking>" in line:
                    in_thinking = False

                if result:
                    yield result

        if buffer.strip():
            result = self._process_line(buffer, in_thinking)
            if result:
                yield result

        # Add session timing at end
        yield f"\n[dim]{self.format_session_time()}[/]\n"

    def _process_line(self, line: str, in_thinking: bool) -> str:
        """Process a single line and return formatted output."""
        import json

        # Skip thinking content
        if in_thinking or "<thinking>" in line:
            return ""

        # Handle tool calls
        if "<tool>" in line and "</tool>" in line:
            match = self.TOOL_PATTERN.search(line)
            if match:
                tool_name = match.group(1)
                params_match = self.PARAMS_PATTERN.search(line)
                params = {}
                if params_match:
                    try:
                        params = json.loads(params_match.group(1))
                    except:
                        pass

                header = self.format_tool_header(tool_name, params)
                self.current_tool = ToolExecution(tool_name, params)
                return f"\n{header}\n"

        # Handle params on separate line
        if "<params>" in line and "</params>" in line:
            return ""

        # Handle tool markers from agent
        if line.startswith("[Tool:"):
            return ""

        if line.startswith("[Result:"):
            result = line[8:].rstrip("]").strip()
            if self.current_tool:
                self.current_tool.end_time = time.time()
                output = self.format_tool_output(result, success=True)
                return str(output)
            return ""

        if line.startswith("[Error:"):
            error = line[7:].rstrip("]").strip()
            if self.current_tool:
                self.current_tool.end_time = time.time()
                self.current_tool.success = False
            # Show more of the error (200 chars instead of 80) for debugging
            return f"  ⎿  [red]Error: {self._truncate(error, 200)}[/]\n"

        if line.startswith("[Output:"):
            output = line[8:].rstrip("]").strip()
            if self.current_tool:
                self.current_tool.success = False
            # Show command output on failure (helps with debugging)
            return f"  ⎿  [yellow]{self._truncate(output, 300)}[/]\n"

        # Skip other internal markers
        if line.startswith("[") and line.endswith("]"):
            if any(x in line for x in ["iterations", "Parse error", "retry", "Context"]):
                return f"[dim]{line}[/]\n"
            return ""

        # Regular text
        cleaned = self._clean_text(line)
        if cleaned:
            return cleaned + "\n"

        return ""

    def _clean_text(self, text: str) -> str:
        """Clean text by removing markers."""
        text = re.sub(r'</?tool>', '', text)
        text = re.sub(r'</?params>', '', text)
        text = re.sub(r'</?thinking>', '', text)
        text = re.sub(r'\[Tool:.*?\]', '', text)
        text = re.sub(r'\[Result:.*?\]', '', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text.strip()


def print_tool_call(tool_name: str, params: dict, timeout: Optional[str] = None) -> None:
    """Print a tool call in Claude Code style."""
    formatter = OutputFormatter()
    header = formatter.format_tool_header(tool_name, params)

    timeout_str = f" timeout: {timeout}" if timeout else ""
    console.print(f"\n{header}[dim]{timeout_str}[/]")


def print_tool_result(result: str, success: bool = True, show_full: bool = False) -> None:
    """Print a tool result with optional expansion."""
    formatter = OutputFormatter()
    output = formatter.format_tool_output(result, success)
    console.print(output)


def print_update(path: str, added: int, removed: int) -> None:
    """Print file update summary like Claude Code."""
    text = Text()
    text.append("  ⎿  ", style="dim")

    if added > 0 and removed > 0:
        text.append(f"Added {added} line{'s' if added != 1 else ''}, ", style="green")
        text.append(f"removed {removed} line{'s' if removed != 1 else ''}", style="red")
    elif added > 0:
        text.append(f"Added {added} line{'s' if added != 1 else ''}", style="green")
    elif removed > 0:
        text.append(f"Removed {removed} line{'s' if removed != 1 else ''}", style="red")

    console.print(text)


def print_status(message: str, style: str = "dim") -> None:
    """Print a status message."""
    console.print(f"[{style}]{message}[/]")


def print_file_written(path: str, lines: int) -> None:
    """Print file written confirmation."""
    console.print(f"  ⎿  [green]Wrote {path} ({lines} lines)[/]")


def print_file_read(path: str, lines: int) -> None:
    """Print file read confirmation."""
    console.print(f"  ⎿  [dim]Read {path} ({lines} lines)[/]")


def create_progress_table(items: list[tuple[str, str, str]]) -> Table:
    """Create a progress table for multi-step operations."""
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column("Status", width=3)
    table.add_column("Step")
    table.add_column("Details", style="dim")

    for status, step, details in items:
        if status == "done":
            table.add_row("[green]✓[/]", step, details)
        elif status == "current":
            table.add_row("[cyan]●[/]", f"[bold]{step}[/]", details)
        elif status == "error":
            table.add_row("[red]✗[/]", step, details)
        else:
            table.add_row("[dim]○[/]", f"[dim]{step}[/]", details)

    return table


def create_spinner(message: str = "Working") -> Spinner:
    """Create a spinner for long operations."""
    return Spinner("dots", text=Text(f" {message}...", style="cyan"))


def print_welcome_banner(coder_model: str, router_model: str, sandbox_path: str) -> None:
    """Print welcome banner in Claude Code style."""
    console.print()
    from . import __version__
    console.print(f"[bold cyan]Kairo Code[/] v{__version__} - AI Coding Assistant by Kairon Labs")
    console.print(f"[dim]Model: {coder_model}[/]")
    console.print(f"[dim]Sandbox: {sandbox_path}[/]")
    console.print()
    console.print("[dim]Just describe what you want - Kairo Code will plan and implement automatically.[/]")
    console.print("[dim]Agents: /explore, /code, /plan | Utils: /search, /settings, /help, /exit[/]")
    console.print()
