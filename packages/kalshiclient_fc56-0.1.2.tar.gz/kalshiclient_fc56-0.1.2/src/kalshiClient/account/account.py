class account_client:
    def __init__(self,parent):
        self.parent=parent
    def get_account_api_limits(self) -> dict:
        return self.parent.request(method="GET",path="/trade-api/v2/account/limits")