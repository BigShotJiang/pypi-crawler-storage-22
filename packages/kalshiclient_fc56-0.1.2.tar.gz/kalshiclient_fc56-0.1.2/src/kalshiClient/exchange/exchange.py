class exchange_client:
    def __init__(self,parent):
        self.parent=parent
    def status(self) -> dict:
        return self.parent.request(method="GET",path="/trade-api/v2/exchange/status")

    def announcements(self) -> dict:
        return self.parent.request(method="GET",path="/trade-api/v2/exchange/announcements")

    def series_fee_changes(self,ticker: str, historical: bool = False) -> dict:
        params = {
            "ticker": ticker,
            "historical": historical
        }
        return self.parent.request(method="GET",path="/trade-api/v2/series/fee_changes", params=params)

    def schedule(self) -> dict:
        return self.parent.request(method="GET",path="/trade-api/v2/exchange/schedule")

    def user_data_timestamp(self) -> dict:
        return self.parent.request(method="GET",path="/trade-api/v2/exchange/user_data_timestamp")