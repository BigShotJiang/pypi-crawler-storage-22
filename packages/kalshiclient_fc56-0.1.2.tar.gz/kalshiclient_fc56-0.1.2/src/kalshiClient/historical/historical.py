class historical_client:
    def __init__(self,parent):
        self.parent=parent
    def get_historical_cutoff_timestamps(self):
        return self.parent.reqeust(method="GET",path="/trade-api/v2/historical/cutoff")