import requests
from pathlib import Path
from src.kalshiClient.signature import create_signature
import time
class KalshiClient:
    def __init__(self, api_key: str, key_path: str = None):
        self.api_key = api_key
        self.base_url = "https://api.elections.kalshi.com"
        if key_path is None:
            self.key_path = Path(__file__).resolve().parent / "Kalshi.pem"
        else:
            self.key_path = Path(key_path)
        self.session = requests.Session()
        from exchange.exchange import exchange_client
        self.exchange = exchange_client(self)
        from orders.orders import orders_client
        self.orders = orders_client(self)
        from historical.historical import historical_client
        self.historical = historical_client(self)
        from account.account import account_client
        self.account = account_client(self)
    def request(self, method: str, path: str, params: dict = None, json: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        timestamp  = str(int(time.time() * 1000))
        signature = create_signature(self.key_path, timestamp, method, path)
        headers = {
                "KALSHI-ACCESS-KEY": self.api_key,
                "KALSHI-ACCESS-SIGNATURE": signature,
                "KALSHI-ACCESS-TIMESTAMP": timestamp,
                "Content-Type": "application/json"
            }
        try:
            response = self.session.request(
                method, url, headers=headers, params=params, timeout=10, json=json
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            print(f"API Error ({response.status_code}): {response.text}")
            raise e