class orders_client:
    def __init__(self,parent):
        self.parent=parent
    def get_orders(self,ticker: str = None, event_ticker: str = None, min_ts: int = None, max_ts: int = None, status: str = None, limit: int = 100, cursor: str = None, subaccount: int = None) -> dict:
        raw_params = {
            "ticker": ticker,
            "event_ticker": event_ticker,
            "min_ts": min_ts,
            "max_ts": max_ts,
            "status": status,
            "limit": limit,
            "cursor": cursor,
            "subaccount": subaccount
        }
        params = {k: v for k, v in raw_params.items() if v is not None}
        return self.parent.request(method="GET",path="/trade-api/v2/portfolio/orders",params=params)
    def create_order(self, ticker: str, side: str, action: str, count: int, price: int, client_order_id: str = None, time_in_force: str = "good_till_canceled", post_only: bool = False, reduce_only: bool = False, subaccount: int = 0) -> dict:
        payload = {
        "ticker": ticker,
        "side": side.lower(),
        "action": action.lower(),
        "count": count,
        "yes_price": price if side.lower() == "yes" else None,
        "no_price": price if side.lower() == "no" else None,
        "client_order_id": client_order_id,
        "time_in_force": time_in_force,
        "post_only": post_only,
        "reduce_only": reduce_only,
        "subaccount": subaccount
        }

        json_data = {k: v for k, v in payload.items() if v is not None}

        return self.parent.request(
        method="POST", 
        path="/trade-api/v2/portfolio/orders", 
        json=json_data
        )
    def get_order(self, order_id: str) -> dict:
        if not order_id:
            raise ValueError("order_id is required to fetch a specific order.")

        path = f"/trade-api/v2/portfolio/orders/{order_id}"

        return self.parent.request(method="GET", path=path)
def cancel_order(self, order_id: str, subaccount: int = None) -> dict:
    if not order_id:
        raise ValueError("order_id is required to cancel an order.")
    path = f"/trade-api/v2/portfolio/orders/{order_id}"
    params = {}
    if subaccount is not None:
        params["subaccount"] = subaccount

    return self.parent.request(
        method="DELETE", 
        path=path, 
        params=params
    )
def batch_create_orders(self, orders_list: list) -> dict:
    if not orders_list:
        raise ValueError("The orders_list cannot be empty.")
    
    if len(orders_list) > 20:
        raise ValueError("Kalshi limits batch orders to a maximum of 20 per request.")

    cleaned_orders = []
    for order in orders_list:
        if 'price' in order:
            side = order.get('side', '').lower()
            order["yes_price"] = order['price'] if side == "yes" else None
            order["no_price"] = order['price'] if side == "no" else None
            del order['price']

        cleaned_orders.append({k: v for k, v in order.items() if v is not None})
    payload = {"orders": cleaned_orders}

    return self.parent.request(
        method="POST", 
        path="/trade-api/v2/portfolio/orders/batched", 
        json=payload
    )