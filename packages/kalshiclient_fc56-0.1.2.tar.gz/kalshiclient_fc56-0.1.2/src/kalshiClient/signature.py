import base64
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def create_signature(private_key_path: str, timestamp: str, method: str, path: str):
    with open(private_key_path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None
        )

    path_without_query = path.split('?')[0]
    
    message = f"{timestamp}{method}{path_without_query}".encode('utf-8')

    signature = private_key.sign(
    message,
    padding.PSS(
        mgf=padding.MGF1(hashes.SHA256()),
        salt_length=hashes.SHA256().digest_size # Use the digest size directly
    ),
    hashes.SHA256()
)
    
    # 5. Return as base64 string
    return base64.b64encode(signature).decode('utf-8')