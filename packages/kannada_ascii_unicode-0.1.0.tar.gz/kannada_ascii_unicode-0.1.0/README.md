# Kannada ASCII ↔ Unicode Converter

A lightweight Python SDK to convert Kannada text between
ASCII-based encoding and Unicode.

⚠️ **Note**  
This is a **basic mapping-based converter (v0.1.x)**.
Advanced conjunct handling and full round-trip accuracy
are under active development.

## Installation

```bash
pip install kannada-ascii-unicode
from kannada_converter import ascii_to_unicode, unicode_to_ascii

print(ascii_to_unicode("kannaDa"))
print(unicode_to_ascii("ಕನ್ನಡ"))
```