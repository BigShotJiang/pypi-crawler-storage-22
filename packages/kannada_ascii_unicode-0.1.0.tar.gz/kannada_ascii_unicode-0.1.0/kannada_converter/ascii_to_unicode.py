from .utils import load_mapping, apply_mapping

# Lazy-loaded mapping (loaded once)
_ASCII_TO_UNICODE = None


def ascii_to_unicode(text: str) -> str:
    """
    Convert Kannada ASCII encoded text to Unicode.
    """
    global _ASCII_TO_UNICODE

    if _ASCII_TO_UNICODE is None:
        _ASCII_TO_UNICODE = load_mapping("ascii_to_unicode.json")

    return apply_mapping(text, _ASCII_TO_UNICODE)
