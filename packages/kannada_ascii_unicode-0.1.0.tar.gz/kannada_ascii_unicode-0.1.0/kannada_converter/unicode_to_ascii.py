from .utils import load_mapping, apply_mapping

# Lazy-loaded mapping
_UNICODE_TO_ASCII = None


def unicode_to_ascii(text: str) -> str:
    """
    Convert Kannada Unicode text to ASCII encoding.
    """
    global _UNICODE_TO_ASCII

    if _UNICODE_TO_ASCII is None:
        _UNICODE_TO_ASCII = load_mapping("unicode_to_ascii.json")

    return apply_mapping(text, _UNICODE_TO_ASCII)
