import json
import os
from typing import Dict, List, Tuple


# Section priority (TOP → BOTTOM)
# Earlier sections are applied first
SECTION_ORDER: List[str] = [
    "vowels",
    "consonants",
    "vattakshara",
    "matras",
    "symbols",
    "digits",
]


def load_mapping(filename: str) -> Dict[str, str]:
    """
    Load a sectioned JSON mapping file and flatten it
    respecting Kannada-specific section order.
    """
    base_dir = os.path.dirname(__file__)
    mapping_path = os.path.join(base_dir, "mappings", filename)

    with open(mapping_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    ordered_pairs: List[Tuple[str, str]] = []

    # 1️⃣ Apply known sections in defined order
    for section in SECTION_ORDER:
        section_map = data.get(section)
        if isinstance(section_map, dict):
            ordered_pairs.extend(section_map.items())

    # 2️⃣ Apply any unknown sections (future-proofing)
    for section, section_map in data.items():
        if section not in SECTION_ORDER and isinstance(section_map, dict):
            ordered_pairs.extend(section_map.items())

    # 3️⃣ Longest-key-first within section order
    ordered_pairs.sort(key=lambda x: len(x[0]), reverse=True)

    return dict(ordered_pairs)


def apply_mapping(text: str, mapping: Dict[str, str]) -> str:
    """
    Apply a mapping dictionary to the input text.
    Mapping must already be ordered correctly.
    """
    if not text:
        return text

    for key, value in mapping.items():
        text = text.replace(key, value)

    return text
