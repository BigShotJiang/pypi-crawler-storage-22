from kannada_converter import ascii_to_unicode

print(ascii_to_unicode("ka"))     # ಕ
print(ascii_to_unicode("kA"))     # ಕಾ
print(ascii_to_unicode("kna"))    # ಕ್ನ
print(ascii_to_unicode("kaM"))    # ಕಂ
