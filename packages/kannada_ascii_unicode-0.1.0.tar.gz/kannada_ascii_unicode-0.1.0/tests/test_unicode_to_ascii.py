from kannada_converter import ascii_to_unicode, unicode_to_ascii

print(ascii_to_unicode("kaM"))   # ಕಂ
print(ascii_to_unicode("kax"))   # ಕ್
print(unicode_to_ascii("ಕಂ"))    # kaM
