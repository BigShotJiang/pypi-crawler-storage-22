//! Intermediate Representation (IR) for compiled Identity Plans.
//!
//! These types are the single source of truth for compiled plan structures.
//! Both cannon-core's engine and all downstream consumers import from here.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityPlan {
    pub entity: String,
    pub plan_hash: String,
    pub identity_version: String,
    pub sources: Vec<ResolvedSource>,
    pub blocking: CompiledBlocking,
    pub match_graph: MatchGraph,
    pub survivorship: SurvivorshipPolicy,
    pub decision: DecisionConfig,
    pub reference_identifiers: Vec<CompiledReferenceIdentifier>,
    pub relations: Vec<CompiledRelation>,
    #[serde(default)]
    pub exclusions: Vec<CompiledExclusion>,
    #[serde(default)]
    pub compliance: Option<CompiledCompliance>,
    #[serde(default)]
    pub hierarchy: Option<CompiledHierarchy>,
    #[serde(default)]
    pub audit: Option<CompiledAudit>,
    #[serde(default)]
    pub metadata: Option<PlanMetadata>,
    #[serde(default)]
    pub governance: Option<CompiledGovernance>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResolvedSource {
    pub name: String,
    #[serde(alias = "system")]
    pub adapter: String,
    #[serde(alias = "table")]
    pub location: String,
    pub id_field: String,
    pub field_mappings: HashMap<String, String>,
    pub temporal: Option<TemporalConfig>,
    #[serde(default)]
    pub freshness: Option<CompiledFreshness>,
    #[serde(default)]
    pub schema: Option<HashMap<String, CompiledFieldSchema>>,
    #[serde(default)]
    pub sampling: Option<CompiledSampling>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub pii_fields: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemporalConfig {
    pub valid_from_field: String,
    pub valid_to_field: Option<String>,
    pub strategy: TemporalStrategy,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum TemporalStrategy {
    #[default]
    LatestOnly,
    PointInTime,
    BiTemporal,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledBlocking {
    pub strategy: BlockingStrategy,
    pub keys: Vec<BlockingKey>,
    pub fallback_sample_rate: Option<f64>,
    pub lsh_bands: Option<usize>,
    pub lsh_rows: Option<usize>,
    pub neighborhood_window: Option<usize>,
    pub sort_fields: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum BlockingStrategy {
    Single,
    #[default]
    Composite,
    Lsh,
    MlPredicted,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockingKey {
    pub fields: Vec<String>,
    pub transformations: Vec<BlockingTransformation>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BlockingTransformation {
    Lowercase,
    FirstInitial,
    Soundex,
    AreaCode,
    Last4,
    Trigrams,
    DoubleMetaphone,
    NormalizePhone,
    NormalizeEmail,
    NormalizeName,
    NormalizeDomain,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchGraph {
    pub rules: Vec<CompiledRule>,
    pub leaf_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledRule {
    pub name: String,
    pub rule_type: CompiledRuleType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum CompiledRuleType {
    Exact {
        field: String,
        weight: f64,
        case_insensitive: bool,
        normalize: bool,
        #[serde(default)]
        normalizer: Option<String>,
    },
    Similarity {
        field: String,
        algorithm: SimilarityAlgorithm,
        threshold: f64,
        weight: f64,
        #[serde(default)]
        normalizer: Option<String>,
    },
    Range {
        field: String,
        tolerance: f64,
        weight: f64,
        #[serde(default)]
        normalizer: Option<String>,
    },
    Composite {
        operator: CompositeOperator,
        children: Vec<CompiledRule>,
    },
    Ml {
        model_id: String,
        features: Vec<String>,
        threshold: f64,
        weight: f64,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum SimilarityAlgorithm {
    JaroWinkler,
    Levenshtein,
    Soundex,
    Metaphone,
    Cosine,
    Haversine,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum CompositeOperator {
    And,
    Or,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurvivorshipPolicy {
    pub default_strategy: SurvivorshipStrategy,
    pub field_policies: HashMap<String, FieldSurvivorshipPolicy>,
}

impl Default for SurvivorshipPolicy {
    fn default() -> Self {
        Self {
            default_strategy: SurvivorshipStrategy::default(),
            field_policies: HashMap::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum SurvivorshipStrategy {
    #[default]
    MostRecent,
    MostComplete,
    SourcePriority,
    Aggregate,
    Custom,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FieldSurvivorshipPolicy {
    pub strategy: SurvivorshipStrategy,
    pub source_priority: Option<Vec<String>>,
    pub aggregate_fn: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecisionConfig {
    pub match_threshold: f64,
    pub review_threshold: Option<f64>,
    pub reject_threshold: Option<f64>,
    pub conflict_strategy: ConflictStrategy,
    pub review_webhook: Option<String>,
    #[serde(default)]
    pub scoring_method: ScoringMethod,
    #[serde(default)]
    pub ml_ensemble_config: Option<CompiledMlEnsembleConfig>,
    #[serde(default)]
    pub custom_scoring_config: Option<CompiledCustomScoringConfig>,
    #[serde(default)]
    pub fellegi_sunter: Option<CompiledFellegiSunterPlan>,
    /// Tie-breaking rules for deterministic ordering of equal-confidence pairs
    #[serde(default)]
    pub tie_breaking: Vec<CompiledTieBreaker>,
}

/// Compiled tie-breaking rule for deterministic pair ordering.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum CompiledTieBreaker {
    ExactMatchPriority,
    LowestEntityId,
    EarliestTimestamp,
}

/// Compiled ML ensemble (logistic regression) scoring configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledMlEnsembleConfig {
    pub coefficients: HashMap<String, f64>,
    pub bias: f64,
}

/// Compiled custom expression-based scoring configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledCustomScoringConfig {
    pub expression: String,
}

// ============================================================================
// Fellegi-Sunter IR types
// ============================================================================

/// A single field in a compiled Fellegi-Sunter plan with precomputed log-likelihood weights.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledFsField {
    pub name: String,
    pub comparator: FsComparatorType,
    pub weight: f64,
    pub m_probability: f64,
    pub u_probability: f64,
    /// Precomputed: ln(m/u) * weight — log-likelihood ratio when fields agree
    pub w_agree: f64,
    /// Precomputed: ln((1-m)/(1-u)) * weight — log-likelihood ratio when fields disagree
    pub w_disagree: f64,
    /// Optional normalizer applied before comparison: "email", "phone", "name", "domain", "generic"
    #[serde(default)]
    pub normalizer: Option<String>,
}

/// Comparator type for Fellegi-Sunter fields, mapped from spec-level FsComparator.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum FsComparatorType {
    Exact,
    JaroWinkler,
    Levenshtein,
    Soundex,
    Metaphone,
    Cosine,
}

/// A compiled Fellegi-Sunter probabilistic matching plan.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledFellegiSunterPlan {
    pub fields: Vec<CompiledFsField>,
    pub match_threshold: f64,
    pub possible_threshold: f64,
    pub non_match_threshold: f64,
    /// Theoretical maximum composite score: sum of all w_agree
    pub max_composite: f64,
    /// Theoretical minimum composite score: sum of all w_disagree
    pub min_composite: f64,
    /// Whether m/u should be estimated via EM before scoring
    #[serde(default)]
    pub em_training: Option<CompiledEmTraining>,
}

/// EM training configuration compiled from spec.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledEmTraining {
    pub max_iterations: usize,
    pub convergence_threshold: f64,
    /// "random_sampling" to estimate u from random pairs before EM
    #[serde(default)]
    pub estimate_u: Option<String>,
    /// Maximum random pairs for u estimation
    #[serde(default = "default_max_random_pairs")]
    pub max_random_pairs: usize,
}

fn default_max_random_pairs() -> usize { 1_000_000 }

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ConflictStrategy {
    #[default]
    PreferHighConfidence,
    PreferRecent,
    ManualReview,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ScoringMethod {
    #[default]
    WeightedSum,
    MlEnsemble,
    Custom,
    FellegiSunter,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledReferenceIdentifier {
    pub name: String,
    pub id_type: ReferenceIdType,
    pub authority: Option<String>,
    pub field: String,
    pub match_weight: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum ReferenceIdType {
    External,
    Internal,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledRelation {
    pub name: String,
    pub from_entity: String,
    pub to_entity: String,
    pub join_key: String,
    pub cardinality: Cardinality,
    pub propagate_match: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[derive(schemars::JsonSchema)]
#[serde(rename_all = "snake_case")]
pub enum Cardinality {
    OneToOne,
    OneToMany,
    ManyToOne,
    ManyToMany,
}

// ============================================================================
// Enterprise IR types
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum CompiledExclusion {
    FieldValue { field: String, operator: String, value: serde_json::Value },
    ExplicitPair { left_id: String, right_id: String },
    CrossTenant { enabled: bool },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledCompliance {
    pub frameworks: Vec<String>,
    pub pii_fields: Vec<String>,
    pub audit_required: bool,
    pub retention_days: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledFreshness {
    pub max_age_seconds: u64,
    pub warn_after_seconds: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledFieldSchema {
    pub field_type: String,
    pub pii: bool,
    pub nullable: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledSampling {
    pub strategy: String,
    pub rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledGovernance {
    pub require_freshness: bool,
    pub require_schema: bool,
    pub required_tags: Vec<String>,
    #[serde(default)]
    pub log_probabilities: bool,
    #[serde(default)]
    pub require_shadow_on_threshold_change: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledHierarchy {
    pub parent_field: String,
    pub max_depth: u8,
    pub inherited_fields: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompiledAudit {
    pub log_all_comparisons: bool,
    pub log_decisions: bool,
    pub log_conflicts: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[cfg_attr(feature = "server", derive(utoipa::ToSchema))]
pub struct PlanMetadata {
    pub name: Option<String>,
    pub description: Option<String>,
    pub owner: Option<String>,
    #[serde(default)]
    pub tags: Vec<String>,
}

impl IdentityPlan {
    pub fn compute_hash(&self) -> String {
        let json = serde_json::to_string(self).expect("Failed to serialize plan");
        let mut hasher = Sha256::new();
        hasher.update(json.as_bytes());
        let result = hasher.finalize();
        hex::encode(result)
    }
}
