from adam.commands import validate_args
from adam.commands.command import Command
from adam.commands.devices.devices import device
from adam.repl_state import ReplState, RequiredState

class Head(Command):
    COMMAND = 'head'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(Head, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return Head.COMMAND

    def required(self):
        return [RequiredState.CLUSTER_OR_POD, RequiredState.APP_APP, ReplState.P]

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (args, state):
            with validate_args(args, state, name='file') as args:
                return device(state).bash(state, state, ['head', '-n', '10', args])

    def completion(self, state: ReplState):
        return super().completion(state, lambda: {f: None for f in device(state).files(state)}, pods=device(state).pods(state, '-'), auto='jit')

    def help(self, state: ReplState):
        return super().help(state, 'run head command on the pod', args='<file>')