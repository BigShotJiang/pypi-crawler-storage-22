import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser

class TestAppCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion_athena(self):
        completer = LarkCompleter(expandables={
            'hosts': lambda x: ['@c3-a'],
            'bash-commands': lambda x: ['ls', 'cat', 'head'],
            'direct-dirs': lambda x: ['abc']
        }, variant=ReplState.A, debug=True)
        LarkParser.show_returns = True

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['@c3-a']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()