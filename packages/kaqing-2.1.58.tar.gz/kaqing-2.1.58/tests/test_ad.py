import base64
import json
import os
import re
import unittest
import jwt
import requests
import urllib

class TestAd(unittest.TestCase):
    def test_authn(self):
        ms = 'https://login.microsoftonline.com'
        tenant_id = '53ad779a-93e7-485c-ba20-ac8290d7252b'
        params = {
            'response_type': 'id_token',
            'response_mode': 'form_post',
            'client_id': '00ff94a8-6b0a-4715-98e0-95490012d818',
            'scope': 'openid email profile',
            'redirect_uri': 'https://plat.c3ci.cloud/c3/c3/oidc/login',
            'nonce': base64.urlsafe_b64encode(os.urandom(32)).decode('utf-8').rstrip('='),
            'state': 'EMPTY'
        }
        authz = f'{ms}/{tenant_id}/oauth2/v2.0/authorize?{urllib.parse.urlencode(params)}'

        session = requests.Session()
        r = session.get(authz)
        print(f'{r.status_code} {authz}')
        self.assertEqual(200, r.status_code)
        config = extract_config_object(r.text)

        login = f'{ms}/{tenant_id}/login'
        body = {
            'login': os.getenv('TEST_USERNAME'),
            'passwd': os.getenv('TEST_PASSWORD'),
            'ctx': config['sCtx'],
            'hpgrequestid': config['sessionId'],
            'flowToken': config['sFT']
        }
        r = session.post(login, data=body, headers={
            'Content-Type': 'application/x-www-form-urlencoded'
        })
        print(f'{r.status_code} {login}')
        self.assertEqual(200, r.status_code)

        config = extract_config_object(r.text)

        kmsi = f'{ms}/kmsi'
        body = {
            'ctx': config['sCtx'],
            'hpgrequestid': config['sessionId'],
            'flowToken': config['sFT'],
        }
        r = session.post(kmsi, data=body, headers={
            'Content-Type': 'application/x-www-form-urlencoded'
        })
        print(f'{r.status_code} {kmsi}')
        self.assertEqual(200, r.status_code)

        id_token = None
        for l in r.text.split('\n'):
            groups = re.match(r'.*name=\"id_token\" value=\"(.*?)\".*', l)
            if groups:
                id_token = groups[1]
        self.assertIsNotNone(id_token)

        jwks_url = f"{ms}/common/discovery/keys"
        jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=360)
        signing_key = jwks_client.get_signing_key_from_jwt(id_token)
        data = jwt.decode(
            id_token,
            signing_key.key,
            algorithms=["RS256"],
            options={
                "verify_signature": True,
                "verify_exp": True,
                "verify_nbf": True,
                "verify_iat": True,
                "verify_aud": False,
                "verify_iss": True,
            },
        )
        print(json.dumps(data, indent=4))

def extract_config_object(text: str):
    for line in text.split('\n'):
        groups = re.match(r'.*\$Config=\s*(\{.*)', line)
        if groups:
            js = groups[1].replace(';', '')
            return json.loads(js)

    raise Exception('NOT MATCHING!')

if __name__ == '__main__':
    unittest.main()