import unittest

from adam.commands.postgres import completions_p
from adam.commands.postgres.utils_postgres import TestPG
from prompt_toolkit.completion import CompleteEvent, NestedCompleter
from prompt_toolkit.document import Document

class TestAnyCompleter(unittest.TestCase):
    def test_completion(self):
        global TestPG
        TestPG[0] = True

        completer = NestedCompleter.from_nested_dict(completions_p.completions_p('azops88', 'azops88-c3-c3-k8spg-cs-001/azops88_c3ai_c3'))
        cs = list(completer.get_completions(Document('select any '), CompleteEvent(text_inserted=True)))
        self.assertEqual(1, len(cs))
        for c in cs:
            self.assertEqual('from', c.text)
            self.assertEqual(0, c.start_position)

        cs = list(completer.get_completions(Document('select any from C3_2_UNKNOWN where unknown = '), CompleteEvent(text_inserted=True)))
        self.assertEqual(1, len(cs))
        for c in cs:
            self.assertEqual("'id'", c.text)
            self.assertEqual(0, c.start_position)

        cs = list(completer.get_completions(Document("select any from C3_2_UNKNOWN where unknown = 'value' "), CompleteEvent(text_inserted=True)))
        self.assertEqual(1, len(cs))
        for c in cs:
            self.assertEqual("limit", c.text)
            self.assertEqual(0, c.start_position)

if __name__ == '__main__':
    unittest.main()