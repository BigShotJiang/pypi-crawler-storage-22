import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.commands.bash.bash import BashCompleter

class TestBashCompleter(unittest.TestCase):
    def test_completion(self):
        completer = BashCompleter(lambda: ['pod-0', 'pod-1'], debug=True)
        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['pod-0', 'pod-1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '>', '2>', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('cat /tmp/hello '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '>', '2>', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls |'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls | '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls > '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls > /tmp/xyz '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '2>', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls > /tmp/out 2> /tmp/err '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls &'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['&', '&&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls &&'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['&&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls & '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls & || '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls & || touch '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '>', '2>', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('pod-0 ls & || touch '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['|', '>', '2>', '<', '&', '&&', '||']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('ls && '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()