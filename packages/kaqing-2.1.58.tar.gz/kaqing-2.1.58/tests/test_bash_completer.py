import unittest

from prompt_toolkit.completion import Completer, CompleteEvent
from prompt_toolkit.document import Document

from adam.commands.postgres.completions_p import completions_p
from adam.sql.lark_completer import LarkCompleter, Variant
from adam.sql.lark_parser import LarkParser
from tests.repl_handler import repl

class TestBashCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion(self):
        completer = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'columns': lambda x: ['x.', 'z.', 'id', 'y.'],
                'column-names': lambda x: ['id'],
                'column-aliases': lambda x: ['x', 'y', 'z'],
                'limits': lambda x: ['1'],
                'hosts': lambda x: ['@cs-0'],
                'bash-commands': lambda x: ['ls', 'cat'],
            }, variant=Variant.PSQL, debug=True)
        LarkParser.show_returns = True

        # print(completer.completions_for_nesting())

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'preview', 'bash', '@cs-0']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('bash '), CompleteEvent(text_inserted=True)))
        self.a(set(['ls', 'cat']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('@'), CompleteEvent(text_inserted=True)))
        self.a(set(['@cs-0']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('@cs-0 '), CompleteEvent(text_inserted=True)))
        self.a(set(['ls', 'cat']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('@cs-0 ls -arlt '), CompleteEvent(text_inserted=True)))
        self.a(set(['&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('@cs-0 cat syz '), CompleteEvent(text_inserted=True)))
        self.a(set(['&']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()