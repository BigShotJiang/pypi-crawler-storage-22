import unittest
from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser

class TestCqlCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion_cql(self):
        completer = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'columns': lambda x: ['x.', 'z.', 'id', 'y.'],
                'keyspaces': lambda x: ['ks1'],
                'table-props': lambda x: {'GC_GRACE_SECONDS':['1000']},
                'table-props-value': lambda x: {'GC_GRACE_SECONDS':['1000']}[x],
                'export-databases': lambda x: ['s123'],
                'export-sessions': lambda x: ['c123'],
                'export-sessions-incomplete': lambda x: ['c124'],
                'consistencies': lambda x: ['quorum','all','serial','one','each_quorum','local_quorum','any','local_one','two','three','local_serial'],
                'export-database-types': lambda x: ['athena', 'sqlite', 'csv'],
                'nodetool-subcommands': lambda x: ['status'],
                'backup-names': lambda x: ['backup-001'],
            # }, variant=SqlVariant.CQL, debug=True).completions_for_nesting()['download']
            }, variant=ReplState.C, debug=True)
        LarkParser.show_returns = True

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'consistency', 'export', 'import',
                              'drop', 'clean']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select '), CompleteEvent(text_inserted=True)))
        self.a(set(['x.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter '), CompleteEvent(text_inserted=True)))
        self.a(set(['table', 'tables']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['add', 'drop', 'with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 with '), CompleteEvent(text_inserted=True)))
        self.a(set(['GC_GRACE_SECONDS']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 with GC_GRACE_SECONDS = '), CompleteEvent(text_inserted=True)))
        self.a(set(['1000']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter tables '), CompleteEvent(text_inserted=True)))
        self.a(set(['with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter tables with '), CompleteEvent(text_inserted=True)))
        self.a(set(['GC_GRACE_SECONDS']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter tables with GC_GRACE_SECONDS = '), CompleteEvent(text_inserted=True)))
        self.a(set(['1000']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('describe '), CompleteEvent(text_inserted=True)))
        self.a(set(['table', 'tables', 'keyspace', 'keyspaces', 'schema']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('describe keyspace '), CompleteEvent(text_inserted=True)))
        self.a(set(['ks1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('describe tables '), CompleteEvent(text_inserted=True)))
        self.a(set(['&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9', '*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9( '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a, '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export DB.C3_2_XYZ9( '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'with', '(', ',', 'to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 with consistency '), CompleteEvent(text_inserted=True)))
        self.a(set(['quorum', 'all', 'serial', 'one', 'each_quorum', 'local_quorum', 'any', 'local_one', 'two', 'three', 'local_serial']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 as t '), CompleteEvent(text_inserted=True)))
        self.a(set(['with', 'to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 as t to '), CompleteEvent(text_inserted=True)))
        self.a(set(['athena', 'sqlite', 'csv']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a) '), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a) with '), CompleteEvent(text_inserted=True)))
        self.a(set(['consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * '), CompleteEvent(text_inserted=True)))
        self.a(set(['with', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export to '), CompleteEvent(text_inserted=True)))
        self.a(set(['sqlite', 'csv', 'athena']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * in '), CompleteEvent(text_inserted=True)))
        self.a(set(['ks1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * in ks1 '), CompleteEvent(text_inserted=True)))
        self.a(set(['with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * with '), CompleteEvent(text_inserted=True)))
        self.a(set(['consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show export session '), CompleteEvent(text_inserted=True)))
        self.a(set(['c123']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import session '), CompleteEvent(text_inserted=True)))
        self.a(set(['c124']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv, '), CompleteEvent(text_inserted=True)))
        self.a(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv '), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv as d.t '), CompleteEvent(text_inserted=True)))
        self.a(set(['to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency '), CompleteEvent(text_inserted=True)))
        self.a(set(['quorum', 'all', 'serial', 'one', 'each_quorum', 'local_quorum', 'any', 'local_one', 'two', 'three', 'local_serial']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency quorum; '), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'consistency', 'import', 'export',
                              'drop', 'clean']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency quorum; select '), CompleteEvent(text_inserted=True)))
        self.a(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop '), CompleteEvent(text_inserted=True)))
        self.a(set(['all', 'export']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop all export '), CompleteEvent(text_inserted=True)))
        self.a(set(['databases']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop export database '), CompleteEvent(text_inserted=True)))
        self.a(set(['s123']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean '), CompleteEvent(text_inserted=True)))
        self.a(set(['up']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up '), CompleteEvent(text_inserted=True)))
        self.a(set(['all', 'export']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up all export '), CompleteEvent(text_inserted=True)))
        self.a(set(['sessions']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up export sessions '), CompleteEvent(text_inserted=True)))
        self.a(set(['c123']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('download '), CompleteEvent(text_inserted=True)))
        self.a(set(['export']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('download export session '), CompleteEvent(text_inserted=True)))
        self.a(set(['c124']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('use '), CompleteEvent(text_inserted=True)))
        self.a(set(['s123']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()