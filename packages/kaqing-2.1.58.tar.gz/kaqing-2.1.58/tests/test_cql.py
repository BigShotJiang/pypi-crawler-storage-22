import unittest

from adam.commands.command import InvalidStateException
from adam.commands.cql.cqlsh import Cqlsh
from adam.repl_state import ReplState
from adam.utils import ConfigHolder, ConfigReadable
from tests.repl_handler import repl

class TestCql(unittest.TestCase):
    def test_cql(self):
        ConfigHolder.is_display_help = False

        with self.assertRaises(InvalidStateException):
            with repl(debug=False, device=ReplState.C, pod=False) as (state, _):
                Cqlsh().run('cql select * from azops88_db.analyticscontainer_dfeevalhistory', state)

if __name__ == '__main__':
    unittest.main()