import unittest

from adam.commands.cql.utils_cql import ColumnSpec, parse_cql_desc_table

class TestCqlUtils(unittest.TestCase):
    def test_parse_desc_table(self):
        out = """
CREATE TABLE azops88_db.analyticscontainer_dfeevalhistory (
    id text,
    columnname text,
    version bigint static,
    contentb blob,
    contentbool boolean,
    contentn double,
    contents text,
    PRIMARY KEY (id, columnname)
) WITH CLUSTERING ORDER BY (columnname ASC)
    AND additional_write_policy = '99p'
    AND bloom_filter_fp_chance = 0.1
    AND caching = {'keys': 'ALL', 'rows_per_partition': 'NONE'}
    AND cdc = false
    AND comment = ''
    AND compaction = {'class': 'org.apache.cassandra.db.compaction.LeveledCompactionStrategy', 'max_threshold': '32', 'min_threshold': '4'}
    AND compression = {'chunk_length_in_kb': '16', 'class': 'org.apache.cassandra.io.compress.SnappyCompressor'}
    AND memtable = 'default'
    AND crc_check_chance = 1.0
    AND default_time_to_live = 0
    AND extensions = {}
    AND gc_grace_seconds = 3600
    AND max_index_interval = 2048
    AND memtable_flush_period_in_ms = 0
    AND min_index_interval = 128
    AND read_repair = 'BLOCKING'
    AND speculative_retry = '99p';"
        """
        table = parse_cql_desc_table(out)
        self.assertEqual('id', table.row_key())
        self.assertEqual(['id', 'columnname'], table.keys())
        self.assertEquals(ColumnSpec('id', 'text', 0), table.columns[0])

if __name__ == '__main__':
    unittest.main()