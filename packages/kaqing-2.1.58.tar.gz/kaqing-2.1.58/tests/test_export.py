import unittest

from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec
from tests.repl_handler import repl

class TestExport(unittest.TestCase):
    # def test_export_importer_conflict(self):
    #     with repl() as (state, _):
    #         state.export_session = 'e123'
    #         tables, _ = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'sqlite'], state)
    #         self.assertEqual([], tables)

    # def test_export_csv_db_bound(self):
    #     with repl() as (state, _):
    #         spec: ExportSpec = None

    #         state.export_session = 'e123'
    #         tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'csv'], state)
    #         self.assertEqual(['pending_import'], tables)
    #         self.assertEqual('c123', spec.session)
    #         self.assertEqual('e123', state.export_session)

    def test_export(self):
        with repl(debug=True) as (state, _):
            spec: ExportSpec = None

            tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory'], state)
            self.assertEqual(['done'], tables)
            self.assertEqual(spec.session, state.export_session)

    # def test_export_db_bound(self):
    #     with repl() as (state, _):
    #         spec: ExportSpec = None

    #         state.export_session = 'e123'
    #         tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory'], state)
    #         self.assertEqual(['done'], tables)
    #         self.assertEqual('e123', spec.session)
    #         self.assertEqual('e123', state.export_session)

if __name__ == '__main__':
    unittest.main()