import unittest

from adam.commands.export.export_databases import ExportDatabases
from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec, ExportTableStatus
from tests.repl_handler import repl

class TestExportAs(unittest.TestCase):
    def test_export_as(self):
        with repl() as (state, _):
            tables, _ = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'as', 'dfeevalhistory'], state)
            print(tables)
            self.assertEqual(['done'], tables)
            tables, _ = ExportTableStatus.from_session(state.sts, state.pod, state.namespace, state.export_session)
            self.assertEqual([ExportTableStatus('azops88_db', 'dfeevalhistory', 'done', 'dfeevalhistory')], tables)
            ExportDatabases.run_query('select * from dfeevalhistory limit 10', state.export_session)

    def test_import_to_sqlite(self):
        with repl() as (state, sessions):
            spec: ExportSpec = None

            tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'as', 'dfeevalhistory', 'to', 'sqlite'], state, export_only=True)
            self.assertEqual(['pending_import'], tables)
            spec_session = spec.session
            sessions.add(spec.session)
            self.assertTrue(spec_session.startswith('s'))
            self.assertEqual(spec_session, state.export_session)
            tables, _ = ExportTableStatus.from_session(state.sts, state.pod, state.namespace, state.export_session)
            self.assertEqual([ExportTableStatus('azops88_db', 'dfeevalhistory', 'pending_import', 'analyticscontainer_dfeevalhistory')], tables)

            tables, spec = Exporter.import_session([spec_session], state)
            self.assertEqual(spec_session, state.export_session)

            tables, _ = ExportTableStatus.from_session(state.sts, state.pod, state.namespace, state.export_session)
            self.assertEqual([ExportTableStatus('azops88_db', 'dfeevalhistory', 'done', 'dfeevalhistory')], tables)
            ExportDatabases.run_query('select * from dfeevalhistory limit 10', state.export_session)

if __name__ == '__main__':
    unittest.main()