import unittest

from adam.commands.export.export_databases import ExportDatabases
from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec, ExportTableStatus
from tests.repl_handler import repl

class TestExportAthena(unittest.TestCase):
    def test_export(self):
        with repl() as (state, _):
            spec: ExportSpec = None

            tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'athena'], state)
            self.assertEqual(['done'], tables)
            self.assertEqual(spec.session, state.export_session)
            tables, _ = ExportTableStatus.from_session(state.sts, state.pod, state.namespace, state.export_session)
            self.assertEqual([ExportTableStatus('azops88_db', 'analyticscontainer_dfeevalhistory', 'done', 'analyticscontainer_dfeevalhistory')], tables)
            t: ExportTableStatus = tables[0]
            self.assertEqual([f'{state.export_session}_{t.keyspace}.{t.target_table}'], ExportDatabases.table_names(state.export_session))
            ExportDatabases.run_query(f'select * from {state.export_session}_azops88_db.analyticscontainer_dfeevalhistory limit 10', state.export_session, show_query=True)

    # def test_import(self):
    #     with repl() as (state, sessions):
    #         spec: ExportSpec = None

    #         tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'csv'], state)
    #         self.assertEqual(['pending_import'], tables)
    #         spec_session = spec.session
    #         sessions.add(spec.session)
    #         self.assertTrue(spec_session.startswith('c'))
    #         self.assertIsNone(state.export_session)

    #         tables, spec = Exporter.import_session([spec_session, 'to', 'athena'], state)
    #         self.assertEqual(spec_session.replace('c', 'e'), state.export_session)

    #         tables, _ = ExportTableStatus.from_session(state.sts, state.pod, state.namespace, state.export_session)
    #         self.assertEqual([ExportTableStatus('azops88_db', 'analyticscontainer_dfeevalhistory', 'done', 'analyticscontainer_dfeevalhistory')], tables)

if __name__ == '__main__':
    unittest.main()