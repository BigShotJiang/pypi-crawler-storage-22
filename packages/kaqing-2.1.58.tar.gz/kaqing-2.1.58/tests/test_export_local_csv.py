import unittest

from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec
from tests.repl_handler import repl

class TestExportLocalCSV(unittest.TestCase):
    def test_export(self):
        with repl(debug=False) as (state, _):
            spec: ExportSpec = None

            state.export_session = 'c123'

            tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'local-csv'], state)
            self.assertEqual(['done'], tables)
            self.assertIsNone(state.export_session)

if __name__ == '__main__':
    unittest.main()