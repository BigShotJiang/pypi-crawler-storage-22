import unittest
from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser
from adam.utils_repl.repl_completer import completion_to_bnf, merge_completions

class TestGenCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_merge_completions(self):
        bnf = completion_to_bnf({'check': {'cpu': None, 'storage': {'-s': None}}})
        print(bnf)

        bnf = completion_to_bnf({'check': {lambda x: ['cpu', 'storage']: {'-s': None}}})
        print(bnf)

    def _test_completion(self):
        completions = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'columns': lambda x: ['x.', 'z.', 'id', 'y.'],
                'keyspaces': lambda x: ['ks1'],
                'table-props': lambda x: {'GC_GRACE_SECONDS':['1000']},
                'table-props-value': lambda x: {'GC_GRACE_SECONDS':['1000']}[x],
                'export-databases': lambda x: ['s123'],
                'export-sessions': lambda x: ['c123'],
                'export-sessions-incomplete': lambda x: ['c124'],
                'consistencies': lambda x: ['quorum','all','serial','one','each_quorum','local_quorum','any','local_one','two','three','local_serial'],
                'export-database-types': lambda x: ['athena', 'sqlite', 'csv'],
                'nodetool-subcommands': lambda x: ['status'],
                'backup-names': lambda x: ['backup-001'],
            }, variant=ReplState.C, debug=True).completions_for_nesting()

        print('SEAN', completions.keys())
        merge_completions(completions, {'show': {'new-command': None}})

if __name__ == '__main__':
    unittest.main()