import getpass
import unittest

class TestGetPass(unittest.TestCase):
    def test_getpass(self):
        p = getpass.getpass('')
        print(p.encode().hex())

if __name__ == '__main__':
    unittest.main()