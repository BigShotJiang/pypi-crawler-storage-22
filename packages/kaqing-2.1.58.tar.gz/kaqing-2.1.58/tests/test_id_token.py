import json
import os
from pathlib import Path
import re
import threading
import time
import unittest
import jwt
from oktaloginwrapper import OktaLoginWrapper as OLW
from dotenv import load_dotenv
import requests
from urllib.parse import urlparse, parse_qs
from okta_jwt_verifier import BaseJWTVerifier

from adam.app_session import AppSession

class TestIdToken(unittest.TestCase):
    def test_decode(self):
        host = 'c3energy.okta.com'
        OKTA_ORG_URL = f"https://{host}"
        oidc_config_url = f"{OKTA_ORG_URL}/oauth2/default/.well-known/openid-configuration"
        oidc_config = requests.get(oidc_config_url).json()
        print('SEAN', oidc_config)

        # if not jwt.algorithms.has_crypto:
        #     print("No crypto support for JWT, please install the cryptography dependency")
        #     return False

        # jwks_url = "https://{okta_host}/oauth2/default/v1/keys"
        # try:
        #     jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=360)
        #     signing_key = jwks_client.get_signing_key_from_jwt(access_token)
        # except jwt.exception.PyJWTError as err:
        #     print(f"Error: {err}")
        #     return False

        # OKTA_ORG_URL = f"https://{okta_host}"
        # CLIENT_ID = params.get('client_id', [''])[0]
        # ID_TOKEN = id_token

        # # Fetch JWKS
        # oidc_config_url = f"{OKTA_ORG_URL}/oauth2/default/.well-known/openid-configuration"
        # oidc_config = requests.get(oidc_config_url).json()
        # print('SEAN', oidc_config)
        # jwks_uri = oidc_config["jwks_uri"]
        # jwks = requests.get(jwks_uri).json()

        # # Decode and verify the ID token
        # # try:
        #     # For simplicity, assuming the first key in JWKS is the correct one for now.
        #     # In a real application, you'd match the 'kid' from the ID token header.
        # public_key = jwks["keys"][0]
        # for j in jwks["keys"]:
        #     print('pk', j)

        # # jwt.algorithms.
        # public_key = jwt.algorithms.RSAAlgorithm.from_jwk(public_key)

        # decoded_token = jwt.decode(
        #     ID_TOKEN,
        #     public_key,
        #     algorithms=["RS256"],  # Or other algorithms used by your Okta setup
        #     audience=CLIENT_ID,
        #     issuer=oidc_config["issuer"],
        #     options={}
        #     # options={"verify_exp": True, "verify_aud": True, "verify_iss": True}
        # )
        # print("ID Token decoded and validated successfully:")
        # print(decoded_token)
        # except jwt.exceptions.PyJWTError as e:
        #     print(f"ID Token validation failed: {e}")

        if not jwt.algorithms.has_crypto:
            print("No crypto support for JWT, please install the cryptography dependency")
            return False

        app_host = 'azops88.c3.ai'
        ass = AppSession(host=app_host, env='c3')
        login = ass.login_to_idp('sean.ahn@c3iot.com')
        print('id_token', login.id)

        # https://c3energy.okta.com/oauth2/v1/keys
        okta_auth_server = f"https://{host}/oauth2"
        jwks_url = f"{okta_auth_server}/v1/keys"
        # okta_auth_server = f"https://{host}/oauth2/default"
        # jwks_url = f"{okta_auth_server}/v1/keys"
        print(jwks_url)
        # try:
        jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=360)
        signing_key = jwks_client.get_signing_key_from_jwt(login.id)
        print('key', signing_key)
        data = jwt.decode(
            login.id,
            signing_key.key,
            algorithms=["RS256"],
            issuer=okta_auth_server,
            audience=f"vpn_auth_server",
            options={
                "verify_signature": True,
                "verify_exp": False,
                "verify_nbf": True,
                "verify_iat": True,
                "verify_aud": False,
                "verify_iss": False,
            },
            leeway=10
        )
        print(data)
        if f'{app_host}/C3.ClusterAdmin' in data['groups']:
            print('Valid Admin User')

        return data
        # except jwt.exceptions.PyJWTError as err:
        #     print(f"Error: {err}")
        #     return False

if __name__ == '__main__':
    unittest.main()
