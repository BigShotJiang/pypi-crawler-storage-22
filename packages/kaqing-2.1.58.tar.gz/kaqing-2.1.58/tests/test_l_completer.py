import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.config import Config
from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser

class TestAuditCompleter(unittest.TestCase):
    Config()

    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion_athena(self):
        completer = LarkCompleter(expandables={
            'tables': lambda x: ['C3_2_XYZ9'],
            'columns': lambda x: ['line', 'c', 'y', 'm', 'd'],
            'export-databases': lambda x: ['s123'],
            'partition-columns': lambda x: ['c', 'y', 'm', 'd'],
            'topn-counts': lambda x: ['10'],
            'topn-types': lambda x: ['slow', 'frequent'],
            'topn-windows': lambda x: ['day'],
        }, variant=ReplState.L, debug=True)
        LarkParser.show_returns = True

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'drop']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9', '(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_X'), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table cluster '), CompleteEvent(text_inserted=True)))
        self.a(set(['add', 'drop']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['add', 'drop']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add '), CompleteEvent(text_inserted=True)))
        self.a(set(['partition']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add partition '), CompleteEvent(text_inserted=True)))
        self.a(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add partition( '), CompleteEvent(text_inserted=True)))
        self.a(set(['c', 'y', 'm', 'd']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("alter table C3_2_XYZ9 add partition(c= "), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("alter table C3_2_XYZ9 add partition(c='v', "), CompleteEvent(text_inserted=True)))
        self.a(set(['c', 'y', 'm', 'd']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("show top "), CompleteEvent(text_inserted=True)))
        self.a(set(['10']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("show last "), CompleteEvent(text_inserted=True)))
        self.a(set(['10']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("show top 10 "), CompleteEvent(text_inserted=True)))
        self.a(set(['over']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("show top 10 over "), CompleteEvent(text_inserted=True)))
        self.a(set(['day']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()