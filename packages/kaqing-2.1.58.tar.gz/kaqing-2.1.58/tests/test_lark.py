import unittest

from teddy.lark_parser import GNode, GPath, LarkParser, State

def choose(paths: list[GPath], token: str):
    print(f'\n{token}\t-----------------------------')
    ps = set()
    for p in paths:
        l = f'{p.token()}'.strip('"')
        if l == token:
            ps.add(p)

        for p in p.reductions:
            p.count = 1

    return ps

class TestLark(unittest.TestCase):
    grammar = """
        start: expression
        expression: term (("+" | "-") term)*
        term: factor (("*" | "/") factor)*
        factor: NUMBER | "(" expression ")"
        NUMBER: /[0-9]+/
        %ignore " "
    """

    def test_simple(self):
        parser = LarkParser()
        LarkParser.reduction_enabled = False
        LarkParser.show_returns = True

        # for t, v in parser.children_by_choices(parser.rules['factor'], debug=True).items():
        #     print(t, v)

        # for t, v in parser.trees_by_choices(LarkParser.build_path('factor'), debug=True).items():
        #     print(t, type(v), v)

        # parser.find_next_terminals('start', debug=True)
        parser.visit_next(LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-1-0'), debug=False)
        # parser.find_next_terminals(LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-0-0'), debug=True)

        # print('SEAN', parser.tree_by_choices(LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-0')))

        # self.assertEqual(set(['*', '-', '+', '/', ')']), parser.parse('4 + 8 * ( 7 - 3', debug=False))
        # self.assertEqual(set(['*', '-', '+', '/', ')']), parser.parse('4 + ( 7 - 3', debug=False))
        # self.assertEqual(set(['*', '-', '+', '/', ')']), parser.parse('( 7 * 3', debug=False))
        # self.assertEqual(set(['*', '-', '+', '/', ')']), parser.parse('4 + ( 7 * ( 3 - 4 )', debug=False))

if __name__ == '__main__':
    unittest.main()