import unittest

from lark_sqlpp import *

from adam.sql.lark_parser import LarkParser

class TestLark(unittest.TestCase):
    def test_simple(self):
        dir_path = os.path.dirname(os.path.realpath(__file__))
        with open(dir_path + "/../teddy/cql.lark") as f:
            grammar = f.read()

            parser = LarkParser(grammar, {
                'alter_table_stmt.properties.property.property_value.literal.nbr.digit': 'table-props',
                'alter_tables_stmt.properties.property.property_value.literal.nbr.digit': 'table-props'
            })

            # print(parser.rules['digit'])

            # parser = Lark(grammar)
            # start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-4-0.where_clause-0-1.cond-0-0.expr-0-0-0-1-0-0-0.comparison_term-0-0.relational_expr-1-0-0-0.EQUAL
            # print(parser.parser.parse('select * from x').pretty())

            LarkParser.show_returns = True

            # print(parser.token_name_for_value('s'))

            # for t in parser.parser.lex("select * from x where id = 'ab''cd"):
            #     print(t, t.type, parser.token_type_for_value(t))

# TerminalDef('__ANON_15', '[0-9]')
# 3 __ANON_15


# choose AS AS start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0.AS
# <-  IDENTIFIER 		 start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0.IDENTIFIER []

            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0.AS'
            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0.IDENTIFIER'
            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0'
            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0'
            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-4-0.where_clause-0-1.cond-0-0.expr-0-0-0-1-0-0-0.comparison_term-0-0.relational_expr-1-0-0-1.expr-0-0-0-0-3-0.literal-1-0.nbr-0-0-0.digit'

            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-4-0.where_clause-0-1.cond-0-0.expr-0-0-0-1-0-0-0.comparison_term-0-0.relational_expr-1-0-0-0.EQUAL'
            # for t in parser.find_next_terminals(p, debug=True):
            #     print(t.terminal())

            # for t in parser.find_next_terminals('start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0.IDENTIFIER'):
            #                                      start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0
            # for t in parser.find_next_terminals('start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-1.select_clause-0-2.projection-0-1-0-0.result_expr-1-1-0-0-1.alias-0-0.identifier_ref-0-0'):
            #     print(t)

            # p = 'start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-4-0.where_clause-0-1.cond-0-0.expr-0-0-0-1-0-0-0.comparison_term-0-0.relational_expr-1-0-0-1.expr-0-0-0-0-3-0.literal-0-0.str-1-0.single_quoted_string-0-2'
            # for t in parser.find_next_terminals(p, debug=True):
            #     print(t.terminal())
            # print(parser.next_terminals('select * from x where a = ', debug=False, print_terminals=True))

            # print(parser.find_next_terminals('single_quoted_string'))
            # print(parser.parser.parse("select * from x where a = 'sx'").pretty())
            # for token in parser.parser.lex('select * from x where a = "x y"', dont_ignore=True):
            #     print(token, token.type, type(token.type))

            # print(parser.next_terminals("select * from x where a = 'sx'", debug=True))

            # print(parser.find_next_terminals('start-0-0.statement_sequence-0-0.statement-3-0.dql_statement-0-0.select_statement-0-0.select_term-0-0.subselect-0-0.select_from-0-4-0.where_clause-0-1.cond-0-0.expr-0-0-0-1-0-0-0.comparison_term-0-0.relational_expr-1-0-0-1.expr-0-0-0-0-3-0.literal-1-0.nbr-0-0-0.digit-0-0', debug=True))

            # self.assertTrue(set(['select', 'insert', 'update', 'delete', 'alter']).issubset(parser.next_terminals('', debug=False, print_terminals=True)))
            self.assertTrue(set(['index', 'table']).issubset(parser.next_terminals('alter ', debug=False, print_terminals=True)))
            self.assertTrue(set(['`IDENTIFIER']).issubset(parser.next_terminals('alter table ', debug=False, print_terminals=True)))
            self.assertTrue(set(['with']).issubset(parser.next_terminals('alter table x ', debug=False, print_terminals=True)))
            self.assertTrue(set(['=']).issubset(parser.next_terminals('alter table x with GC_GRACE_SECONDS ', debug=False, print_terminals=True)))
            self.assertTrue(set(['`table-props']).issubset(parser.next_terminals('alter table x with GC_GRACE_SECONDS = ', debug=False, print_terminals=True)))
            self.assertTrue(set(['`table-props']).issubset(parser.next_terminals('alter tables with GC_GRACE_SECONDS = ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['`IDENTIFIER', 'all', '*']).issubset(parser.next_terminals('select ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['from']).issubset(parser.next_terminals('select * ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['from', ',', 'as']).issubset(parser.next_terminals('select a ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['as']).issubset(parser.next_terminals('select a as', debug=False, print_terminals=True)))
            # self.assertTrue(set(['from']).issubset(parser.next_terminals("select a as a1 ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['from', 'where']).issubset(parser.next_terminals("select a as a1, b ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['`IDENTIFIER']).issubset(parser.next_terminals("select a as a1, b where ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['=', 'like', 'in']).issubset(parser.next_terminals("select a as a1, b where a1 ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['"']).issubset(parser.next_terminals("select a as a1, b where a1 = ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['and', 'or', '+', ';']).issubset(parser.next_terminals("select a as a1, b where a1 = 33 ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['`IDENTIFIER', '(']).issubset(parser.next_terminals("select a as a1, b where a1 in ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['`IDENTIFIER']).issubset(parser.next_terminals("select a as a1, b where a1 in (select ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['from']).issubset(parser.next_terminals("select a as a1, b where a1 in (select a ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['and', 'or']).issubset(parser.next_terminals("select * from x where a = 'abc' ", debug=False, print_terminals=True)))
            # self.assertTrue(set(['`IDENTIFIER']).issubset(parser.next_terminals('select a, b,', debug=False, print_terminals=True)))
            # self.assertTrue(set(['from']).issubset(parser.next_terminals('select a as c ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['limit']).issubset(parser.next_terminals('select a as c from x ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['`__ANON_20']).issubset(parser.next_terminals('select * from x limit ', debug=False, print_terminals=True)))
            # self.assertTrue(set(['and', 'or', '+', ';']).issubset(parser.next_terminals("select * from x where id = 'ab\\'c\\\\d'", debug=False, print_terminals=True)))
            # self.assertTrue(set(['and', 'or', '+', ';']).issubset(parser.next_terminals("select * from x where id = 'ab''cd' ", debug=False, print_terminals=True)))

            # print(parser.rules['__ANON_20'])

if __name__ == '__main__':
    unittest.main()