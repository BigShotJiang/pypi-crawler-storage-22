import unittest

from teddy.lark_parser import GNode, GPath, LarkParser, State

def choose(paths: list[GPath], token: str):
    print(f'\n{token}\t-----------------------------')
    ps = set()
    for p in paths:
        l = f'{p.token()}'.strip('"')
        if l == token:
            ps.add(p)

        for p in p.reductions:
            p.count = 1

    return ps

class TestLark(unittest.TestCase):
    grammar = """
        start: expression
        expression: term (("+" | "-") term)*
        term: factor (("*" | "/") factor)*
        factor: NUMBER | "(" expression ")"
        NUMBER: /[0-9]+/
        %ignore " "
    """

    # def test_find_terminals(self):
        # parser = LarkParser()
        # path = LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-0-0')
        # tree = parser.find(path)
        # print(tree)

    def _test_lark_move_up_and_next(self):
        parser = LarkParser()
        path = LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-0-0')
        parser.find_terminals(path)
        terminals = parser.find_next(path)
        print(terminals)

        for p in terminals:
            parser.find_terminals(p)

    def _test_start_with_number(self):
        parser = LarkParser()
        path = LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-0-0')
        tree = parser.find_next_terminals(path)
        print(tree)

    def _test_start(self):
        parser = LarkParser()
        path = LarkParser.build_path('start')
        # terminals = parser.find_terminals(path)
        # new_terminals = set()
        # for t in terminals:
        #     print('SEAN t', t)
        new_terminals = parser.find_next(path)

        print(new_terminals)

    def _test_start0(self):
        parser = LarkParser()
        path = LarkParser.build_path('start')
        terminals = parser.find_next_terminals(path)
        print(terminals)
        # terminals = parser.find_terminals(path)
        # new_terminals = set()
        # for t in terminals:
        #     new_terminals |= parser.find_next_terminals(t)

        # print(new_terminals)

    def _test_find_next_after_wildcard(self):
        parser = LarkParser()
        terminlas = parser.find_next_terminals('start-0-0.expression-0-1-0-0-0-0')
        print(terminlas)

    def _test_reduce(self):
        # n = 'a_b_c_d_e_f_f_f_f_f_f_g'
        n = 'a_b_c_d_e_f_g_c_d_e_f_g'
        l = n.split('_')

        for s in range(1, int(len(l) / 2)):
            reduced = -1
            # cnt = 0
            while(reduced):
                reduced = 0
                for i in range(0, len(l) - s - 1):
                    s0 = l[i:s + i]
                    s0s = '_'.join(s0)
                    s1 = l[i+s:]
                    s1s = '_'.join(s1)
                    if s1s and s1s.startswith(s0s):
                        l0s = f'{s0s}_{s1s.replace(s0s, "", 1).strip("_")}'.strip('_')
                        l = l[:i]
                        if l0s:
                            l.extend(l0s.split('_'))
                        reduced += 1

                    # if s1s:
                    #     print(f'{s1s}.startswith({s0s}) -> {l}')
                    # cnt += 1
                    # if cnt > 40:
                    #     break
        print('l', '_'.join(l))

        # parser = LarkParser()
        # path = parser.build_path('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-0-0.NUMBER')
        # print(path.reduce())

    def _test_print_expression(self):
        parser = LarkParser()
        LarkParser.reduction_enabled = True

        p = choose(parser.find_next_terminals('start'), '(')
        # print('------------')
        p = choose(parser.find_next_terminals(p), '(')
        # print('------------')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        # print('------------')
        p = choose(parser.find_next_terminals(p), ')')
        # print('------------')
        p = choose(parser.find_next_terminals(p), ')')
        # print('------------')
        print("p =", p)
        # parser.find_next_terminals('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-0-0')
        # print('------------')
        # parser.find_next_terminals('start-0-0.expression-0-0.term-0-0.factor-1-2.NUMBER')


        # print(parser.rules['expression'].pretty())

    def _test_wtf(self):
        parser = LarkParser()
        LarkParser.reduction_enabled = True

        # (_NUMBER_*_(_NUMBER_+_NUMBER_*_(_NUMBER_*_NUMBER_))
        p = choose(parser.find_next_terminals('start'), '(')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), '*')
        p = choose(parser.find_next_terminals(p), '(')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), '+')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), '*')
        p = choose(parser.find_next_terminals(p), '(')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), '*')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), ')')
        p = choose(parser.find_next_terminals(p), ')')
        p = choose(parser.find_next_terminals(p), ')')
        # p = set(['start-0-0.expression-0-0.term-0-0.factor-1-2', 'start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-1-0-1.factor-1-2'])
        # p = choose(parser.find_next_terminals(p), ')')
        # p = choose(parser.find_next_terminals(p), ')')
        print('p =', p)

    def _test_wtf2(self):
        parser = LarkParser()
        LarkParser.reduction_enabled = True

        # (_NUMBER_*_(_NUMBER_+_NUMBER_*_(_NUMBER_*_NUMBER_))
        p = choose(parser.find_next_terminals('start'), '(')
        p = choose(parser.find_next_terminals(p), '(')
        p = choose(parser.find_next_terminals(p), 'NUMBER')
        p = choose(parser.find_next_terminals(p), ')')
        p = choose(parser.find_next_terminals(p), ')')
        # p = set(['start-0-0.expression-0-0.term-0-0.factor-1-2', 'start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-1-0-1.factor-1-2'])
        # p = choose(parser.find_next_terminals(p), ')')
        # p = choose(parser.find_next_terminals(p), ')')
        print('p =', p)

    def _test_find_next_transions(self):
        parser = LarkParser()
        states = parser.find_next_state_transion()
        print(states)
        for _ in range(1, 4):
            for s in states:
                states = parser.find_next_state_transion(s)
                print(states)

    max_trail = 0

    def test_find_next_terminals_repeat(self):
        parser = LarkParser()

        paths_by_state: dict[str, State] = {}
        state_by_paths_hash: dict[int, str] = {}

        # path = LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-1-0')
        # print(path)

        # parser.find_terminals('start-0-0.expression-0-0.term-0-0.factor-1-1')

        def next(p: GPath, trail: list = []):
            if TestLark.max_trail < len(trail):
                TestLark.max_trail = len(trail)

            state = '_'.join([t.strip('"') for t in trail])
            print('-------------------', state)
            has_reductions = False
            paths = parser.find_next_terminals(p, debug=False)
            for p in paths:
                if p.reductions:
                    has_reductions = True
                    break

            g_state = State(state, paths)
            h = g_state.paths_hash()
            if h in state_by_paths_hash:
            # if isinstance(p, GPath) and p.terminal() == '"("' and h in state_by_paths_hash:
            #     # stop
                print('found an rewirable state', state_by_paths_hash[h])
                if state not in paths_by_state:
                    target = state_by_paths_hash[h]
                    paths_by_state[state] = State(state, paths, target, paths_by_state[target].paths_hash())
                    print('aliased state', state, target)

                    return set()
                else:
                    for p in paths:
                        paths_by_state[state].paths.add(p)
                    print('un-aliased state', state, paths_by_state[state].alias)
                    paths_by_state[state].alias = None

                return set()
            else:
                if state not in paths_by_state:
                    paths_by_state[state] = State(state, paths)

                state_by_paths_hash[h] = state

            tuples = []
            for p in paths:
                t = trail + [p.terminal()]
                tuples.append((p.clone(), t))
            return tuples
            # return paths, trail + [p.terminal()]

                # if len(trail) < 6:
                #     for p in paths:
                #         next(p, trail + [p.terminal()])

            # return paths

        trail = []
        paths = 'start'
        ls = next(paths, trail)

        for _ in range(0, 40):
            nls = []
            for l in ls:
                nls += next(l[0], l[1])
                ls = nls

        for name, state in paths_by_state.items():
            if not state.alias:
                print(f'{name}' if name else '[START]')
            else:
                print(f'{name} -> {state.alias}')

            for path in state.paths:
                print(f'  {path}, {path.reductions}')

        print()
        print('max_trail', TestLark.max_trail)

    def _test_find_next(self):
        parser = LarkParser()

        # path = LarkParser.build_path('start-0-0.expression-0-0.term-0-0.factor-1-0')
        # print(path)

        # parser.find_terminals('start-0-0.expression-0-0.term-0-0.factor-1-1')

        paths = parser.find_next_terminals('start')
        print(paths)

        print('-------------------')

        paths = parser.find_next_terminals('start-0-0.expression-0-0.term-0-0.factor-1-0')
        print(paths)

        print('-------------------')

        paths = parser.find_next_terminals('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-0-0')
        print(paths)

        print('-------------------')

        paths = parser.find_next_terminals('start-0-0.expression-0-0.term-0-0.factor-1-2')
        print(paths)

    def _est_iterate_a_few(self):
        parser = LarkParser()
        path = LarkParser.build_path('start')
        terminals = parser.find_terminals(path)
        print('----')
        next_terminals = set()
        for t in terminals:
            next_terminals |= parser.find_next(t)
        print(next_terminals)

        terminals = set()
        for t in next_terminals:
            terminals |= parser.find_terminals(t)
        print(terminals)

        print('----')

        next_terminals = parser.find_next(LarkParser.build_path('start-0-0.expression-0-0.term-0-1-0-0-0-0'))
        print(terminals)


    def _test_lark_0(self):
        paths = LarkParser().find_next('start-0-0.expression-0-0.term-0-0.factor-0-0')
        print('SEAN', paths)

    def _test_lark0(self):
        paths = LarkParser().visit('start-0-0.expression-0-0.term-0-1', next=True)
        print('SEAN', paths)

    def _test_lark1(self):
        LarkParser().visit('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-1-1', next=True)

    def _test_lark2(self):
        paths = LarkParser().visit('start')
        conn: GPath = None
        for path in paths:
            print("emitted = ", path, path.token())
            if path.token().token.value == '"("':
                conn = path

        print('---------------------------------------')
        print('-> ', conn.token().pname())
        paths = LarkParser().find_next(conn)

    def _test_lark3(self):
        paths = LarkParser().visit('start')
        conn: GPath = None
        for path in paths:
            print("emitted = ", path, path.token())
            if path.token().token.value == '"("':
                conn = path
                print('<- ', path)

        print('---------------------------------------')
        print('-> ', conn.token().pname())
        paths = LarkParser().find_next(conn)

        new_paths = set()
        print('---------------------------------------')
        for path in paths:
            print('-> ', path.token().pname())
            paths = LarkParser().find_next(path)
            new_paths |= paths
        paths = new_paths

        print('---------------------------------------')
        for path in paths:
            print('-> ', path.token().pname())
            paths = LarkParser().find_next(path)

    def _test_term(self):
        paths = LarkParser().find_next('start-0-0.expression-0-0.term-0-0.factor-0-0.NUMBER-0-0')

    def _test_term2(self):
        paths = LarkParser().find_next('start-0-0.expression-0-1-0-0-1-0')
        # paths = LarkParser().visit_next('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-1-0-0-1-0')

    def _test_lark4(self):
        # LarkParser().visit_next('start-0-0.expression-0-0.term-0-0.factor-1-0')
        LarkParser().find_next('start-0-0.expression-0-0.term-0-0.factor-1-1.expression-0-0.term-0-0.factor-1-0')


    def _test_lark0(self):
        # grammar = """
        #     start: expression
        #     expression: term (("+" | "-") term)*
        #     term: factor (("*" | "/") factor)*
        #     factor: NUMBER | "(" expression ")"
        #     NUMBER: /[0-9]+/
        #     %ignore " "
        # """

        # parser = Lark(grammar, start='start')

        # print('TEST parsing', parser.parse('(56)'))

        # # print(parser.grammar.term_defs)

        # for rule in parser.grammar.rule_defs + parser.grammar.term_defs:
        #     lhv = rule[0]
        #     print(f'{lhv} :=')
        #     print(rule[1])
        #     if len(rule) > 2:
        #         tree = rule[2]
        #         print(f'{tree.pretty()}')
        #         print(rule[3])

        # rules_by_name = {rule_def[0]: rule_def[2] for rule_def in parser.grammar.rule_defs}
        # terminals = {rule_def[0]: rule_def[1] for rule_def in parser.grammar.term_defs}
        # self.rules_by_name1 = {rule_def[0]: rule_def[1] for rule_def in parser.grammar.rule_defs}
        # self.rules_by_name2 = {rule_def[0]: rule_def[3] for rule_def in parser.grammar.rule_defs}
        path = GPath([GNode('start')])
        # paths = self.expand(rules_by_name, terminals, path)

        paths = LarkParser().visit(path)

        # print('whole paths', paths)

        conn: GPath = None
        for path in paths:
            print("emitted = ", path, path.token())
            if path.token().token.value == '"("':
                conn = path

        print('---------------------------------------')
        print('-> ', conn.token().pname())
        paths = self.visit_next(conn)
        print('---------------------------------------')
        conn = list(paths)[0]
        print('-> ', conn.token().pname())
        paths = self.visit_next(conn)

if __name__ == '__main__':
    unittest.main()