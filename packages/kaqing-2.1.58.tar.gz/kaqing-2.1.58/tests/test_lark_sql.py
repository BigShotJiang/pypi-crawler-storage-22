import re
import unittest

from teddy.lark_parser import GNode, GPath, LarkParser, State
from lark.lexer import Token

from lark_sqlpp import *

def choose(paths: list[GPath], token: str):
    print(f'\n{token}\t-----------------------------')
    ps = set()
    for p in paths:
        l = f'{p.token()}'.strip('"')
        if l == token:
            ps.add(p)

        for p in p.reductions:
            p.count = 1

    return ps

class TestLark(unittest.TestCase):
    grammar = """
        start: select
        select: "SELECT"i columns "FROM"i table ("WHERE"i condition)? ";"

        columns: column ("," column)*
        column: IDENTIFIER

        table: IDENTIFIER

        condition: IDENTIFIER operator value

        operator: "=" | "<" | ">" | "<=" | ">=" | "<>" | "!="

        value: INTEGER | STRING

        // Define terminals using regex or built-in common ones
        IDENTIFIER: ("a".."z" | "A".."Z" | "_") ("a".."z" | "A".."Z" | "_" | "0".."9")*
        INTEGER: "0".."9"+
        STRING: /".*?"/ | /'.*?'/

        // Import common terminals and ignore whitespace
        %import common.WS
        %ignore WS
    """

    def test_simple(self):
        parse_sqlpp("SELECT 1")

        parser = LarkParser(TestLark.grammar)
        LarkParser.reduction_enabled = False
        LarkParser.show_returns = False

        self.assertEqual(set(['SELECT']), parser.parse('', debug=False))
        self.assertEqual(set(['IDENTIFIER']), parser.parse('select', debug=False))
        self.assertEqual(set(['IDENTIFIER']), parser.parse('select ', debug=False))
        self.assertEqual(set(['FROM', 'COMMA', 'IDENTIFIER']), parser.parse('select a', debug=False))
        self.assertEqual(set(['IDENTIFIER']), parser.parse('select a from ', debug=False))
        self.assertEqual(set(['WHERE', 'SEMICOLON']), parser.parse('select a from x', debug=False))
        self.assertEqual(set(['IDENTIFIER']), parser.parse('select a from x where', debug=False))
        self.assertEqual(set(['EQUAL', 'LESSTHAN', 'MORETHAN', '__ANON_1', '__ANON_2', '__ANON_0', '__ANON_3']), parser.parse('select a from x where i', debug=False))
        self.assertEqual(set(['STRING', 'INTEGER']), parser.parse('select a from x where i=', debug=False))

if __name__ == '__main__':
    unittest.main()