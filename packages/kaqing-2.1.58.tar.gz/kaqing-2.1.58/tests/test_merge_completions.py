import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser
from adam.utils_repl.repl_completer import merge_completions

class TestMergeCompletions(unittest.TestCase):
    # def a(self, s0: set, s1: set):
    #     try:
    #         self.assertTrue(s0.issubset(s1))
    #     except Exception as e:
    #         print(s0)
    #         print(s1)
    #         print('missing', s0 - s1)
    #         raise e

    def test_completion_athena(self):
        cs = merge_completions({'reaper': {'show': {'runs': None}}}, {'reaper': {'show': {'schedules': None}}})
        print(cs)

if __name__ == '__main__':
    unittest.main()