import unittest
from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.utils_repl.repl_completer import ReplCompleter, merge_completions

class TestNestedCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion(self):
        completions = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'columns': lambda x: ['x.', 'z.', 'id', 'y.'],
                'keyspaces': lambda x: ['ks1'],
                'table-props': lambda x: {'GC_GRACE_SECONDS':['1000']},
                'table-props-value': lambda x: {'GC_GRACE_SECONDS':['1000']}[x],
                'export-databases': lambda x: ['s123'],
                'export-sessions': lambda x: ['c123'],
                'export-sessions-incomplete': lambda x: ['c124'],
                'consistencies': lambda x: ['quorum','all','serial','one','each_quorum','local_quorum','any','local_one','two','three','local_serial'],
                'export-database-types': lambda x: ['athena', 'sqlite', 'csv'],
                'nodetool-subcommands': lambda x: ['status'],
                'backup-names': lambda x: ['backup-001'],
            }, variant=ReplState.C, debug=True).completions_for_nesting()
        completions = merge_completions(completions, {'show': {'test': {'parameters': lambda: {'p0': None, 'p1': None}}}})
        completer = ReplCompleter.from_nested_dict(completions)

        cs = list(completer.get_completions(Document('show '), CompleteEvent(text_inserted=True)))
        self.a(set(['export', 'login', 'test']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show export '), CompleteEvent(text_inserted=True)))
        self.a(set(['session']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show test '), CompleteEvent(text_inserted=True)))
        self.a(set(['parameters']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show test parameters '), CompleteEvent(text_inserted=True)))
        self.a(set(['p0', 'p1']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()