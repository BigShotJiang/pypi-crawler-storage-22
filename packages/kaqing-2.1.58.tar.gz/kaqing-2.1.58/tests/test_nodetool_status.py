import unittest

from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec
from adam.commands.nodetool import NodeTool
from tests.repl_handler import repl

class TestNodetoolStatus(unittest.TestCase):
    def test_nodetool(self):
        with repl(debug=False) as (state, _):
            NodeTool()._run('status', state)

if __name__ == '__main__':
    unittest.main()