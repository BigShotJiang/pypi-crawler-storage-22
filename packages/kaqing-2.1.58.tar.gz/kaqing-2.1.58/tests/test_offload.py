from concurrent.futures import as_completed
import time
import unittest

from adam.config import Config
from adam.utils_concurrent import offload

class TestOffload(unittest.TestCase):
    Config()

    def test_offloaded(self):
        def xyz0():
            def fn(a: str, b: str):
                print(f'a:{a}, b:{b}')
                return b

            with offload(msg='Begin|End') as submit:
                return [submit(lambda: fn('1', 'offloaded'))]

        self.assertEqual(['offloaded'], [f.result() for f in as_completed(xyz0())])

        def xyz1():
            def f():
                time.sleep(2)

            # return [exec.submit(f)]
            with offload(msg='Begin|End') as submit:
                return [submit(f)]

        t0 = time.time()
        xyz1()
        print('time', int(time.time() - t0))

        def xyz2(t0):
            def f():
                time.sleep(2)

            # return [exec.submit(f)]
            with offload(msg='Begin|End', name='offload') as submit:
                return [submit(f)]

        t0 = time.time()
        xyz2(t0)
        print('time', int(time.time() - t0))

if __name__ == '__main__':
    unittest.main()