import json
import os
import re
import threading
import time
import unittest
import jwt
import requests
from urllib.parse import urlparse, parse_qs

class TestOkta(unittest.TestCase):
    def test_authn(self):
        c3_uri = 'https://azops88.c3.ai'
        # c3_uri = 'https://stgawsscpsr.c3.ai'

        session = requests.Session()
        console_uri = f'{c3_uri}/c3/c3/static/console'
        r = session.get(console_uri)
        print(f'{r.status_code} {console_uri}')
        self.assertEqual(200, r.status_code)

        okta_url = urlparse(r.url)
        params = parse_qs(okta_url.query)
        state_token = params.get('state', [''])[0]
        redirect_uri = params.get('redirect_uri', [''])[0]

        authn_uri = f"https://{okta_url.hostname}/api/v1/authn"
        r = session.post(authn_uri, json={
            "username": os.getenv("TEST_USERNAME"),
            "password": os.getenv("TEST_PASSWORD")
        })
        print(f'{r.status_code} {authn_uri}')
        self.assertEqual(200, r.status_code)
        session_token = r.json()['sessionToken']

        authorize_uri = f'{okta_url.geturl()}&sessionToken={session_token}'
        r = session.get(authorize_uri)
        print(f'{r.status_code} {authorize_uri}')
        self.assertEqual(200, r.status_code)

        id_token = None
        for l in r.text.split('\n'):
            groups = re.match('.*name=\"id_token\" value=\"(.*?)\".*', l)
            if groups:
                id_token = groups[1]
        self.assertIsNotNone(id_token)

        jwks_url = f"https://{okta_url.hostname}/oauth2/v1/keys"
        jwks_client = jwt.PyJWKClient(jwks_url, cache_jwk_set=True, lifespan=360)
        signing_key = jwks_client.get_signing_key_from_jwt(id_token)
        data = jwt.decode(
            id_token,
            signing_key.key,
            algorithms=["RS256"],
            options={
                "verify_signature": True,
                "verify_exp": False,
                "verify_nbf": True,
                "verify_iat": True,
                "verify_aud": False,
                "verify_iss": False,
            },
        )
        print(f'200 {jwks_url}')
        print(json.dumps(data, indent=2))

        def login():
            r = session.post(redirect_uri, headers={
                'Content-Type': 'application/x-www-form-urlencoded',
            }, data={
                'state': state_token,
                'id_token': id_token
            }, timeout=5)
            print(f'{r.status_code} {redirect_uri}')
            self.assertEqual(200, r.status_code)

        redirect_thread = threading.Thread(target=login, daemon=True)
        redirect_thread.start()
        time.sleep(1)

        echo_uri = f'{c3_uri}/c3/c3/api/8/Echo/echoStatic'
        r = session.post(echo_uri, headers={
            'Content-Type': 'application/x-www-form-urlencoded',
        })
        print(f'{r.status_code} {echo_uri}')
        self.assertEqual(200, r.status_code)

        print(r.json()['message'])

if __name__ == '__main__':
    unittest.main()