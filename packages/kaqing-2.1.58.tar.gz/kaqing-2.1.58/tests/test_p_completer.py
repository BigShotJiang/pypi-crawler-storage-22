import unittest

from prompt_toolkit.completion import Completer, CompleteEvent
from prompt_toolkit.document import Document

from adam.commands.postgres.completions_p import completions_p
from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser
from tests.repl_handler import repl

class TestPsqlCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion(self):
        completer = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'columns': lambda x: ['x.', 'z.', 'id', 'y.'],
                'column-names': lambda x: ['id'],
                'column-aliases': lambda x: ['x', 'y', 'z'],
                'limits': lambda x: ['1'],
                'direct-dirs': lambda x: ['child-dir'],
            }, variant=ReplState.P, debug=True)
        LarkParser.show_returns = True

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'preview']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('vacuum '), CompleteEvent(text_inserted=True)))
        self.a(set(['full', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('vacuum full '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('vacuum full C3_2_XYZ9( '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('preview '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        # cs = list(completer.get_completions(Document('cd '), CompleteEvent(text_inserted=True)))
        # self.a(set(['child-dir']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('sel'), CompleteEvent(text_inserted=True)))
        self.a(set(['select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select '), CompleteEvent(text_inserted=True)))
        self.a(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id'), CompleteEvent(text_inserted=True)))
        self.a(set(), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id '), CompleteEvent(text_inserted=True)))
        self.a(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, '), CompleteEvent(text_inserted=True)))
        self.a(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, '), CompleteEvent(text_inserted=True)))
        self.a(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name '), CompleteEvent(text_inserted=True)))
        self.a(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from'), CompleteEvent(text_inserted=True)))
        self.a(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from '), CompleteEvent(text_inserted=True)))
        self.a(set(['(', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from '), CompleteEvent(text_inserted=True)))
        self.a(set(['(', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from C3_2'), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from db.C3_2 '), CompleteEvent(text_inserted=True)))
        self.a(set(['where']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from (select '), CompleteEvent(text_inserted=True)))
        self.a(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9) '), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'where', 'inner', 'left', 'right', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from audit '), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'where', 'inner', 'left', 'right', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as '), CompleteEvent(text_inserted=True)))
        self.a(set(['x', 'y', 'z']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x, '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x, C3_2_XYZ10 '), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'where', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x '), CompleteEvent(text_inserted=True)))
        self.a(set(['where', 'inner', 'left', 'right', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9, '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where i'), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where C3_2_XYZ9.'), CompleteEvent(text_inserted=True)))
        self.a(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9, C3_2_XYZ10 where '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id '), CompleteEvent(text_inserted=True)))
        self.a(set(['=', '<', '<=', '>', '>=', '<>', 'like', 'not', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id= '), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not '), CompleteEvent(text_inserted=True)))
        self.a(set(['like', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id in '), CompleteEvent(text_inserted=True)))
        self.a(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in( "), CompleteEvent(text_inserted=True)))
        self.a(set(["'", 'select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in(select "), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in(select id from C3_2_XYZ9) "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        # TODO in bnf is broken
        # cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in(1, "), CompleteEvent(text_inserted=True)))
        # self.a(set(["'"]), {c.text for c in cs})

        # cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v', "), CompleteEvent(text_inserted=True)))
        # self.a(set(["'"]), {c.text for c in cs})

        # cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v', "), CompleteEvent(text_inserted=True)))
        # self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v') "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        # TODO in bnf is broken
        # cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v', 'w') "), CompleteEvent(text_inserted=True)))
        # self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not in '), CompleteEvent(text_inserted=True)))
        self.a(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not like '), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where (id = 'v' or id = 'w') "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 3 "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 3.1 "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where id = 'v') "), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where (id = 'v')) "), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where (id = 'v') ) "), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' limit "), CompleteEvent(text_inserted=True)))
        self.a(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from (select * from C3_2_XYZ9 where id = 'v' limit 1) "), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from "), CompleteEvent(text_inserted=True)))
        self.a(set(['(', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from C3_2_XYZ9 where id = 'v' "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and id2 = 'w' "), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', 'group', 'order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 limit '), CompleteEvent(text_inserted=True)))
        self.a(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group '), CompleteEvent(text_inserted=True)))
        self.a(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id from C3_2_XYZ9 where id=v group by '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9 group by a) '), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a, '), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a '), CompleteEvent(text_inserted=True)))
        self.a(set(['order', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a limit '), CompleteEvent(text_inserted=True)))
        self.a(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9 group by a limit 1) '), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from C3_2_XYZ9 where id = 'v' group "), CompleteEvent(text_inserted=True)))
        self.a(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order "), CompleteEvent(text_inserted=True)))
        self.a(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a "), CompleteEvent(text_inserted=True)))
        self.a(set(['desc', 'asc', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a, "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a, "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a desc "), CompleteEvent(text_inserted=True)))
        self.a(set(['limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join "), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 as x "), CompleteEvent(text_inserted=True)))
        self.a(set(['on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a "), CompleteEvent(text_inserted=True)))
        self.a(set(['=']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a= "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b "), CompleteEvent(text_inserted=True)))
        self.a(set(['where', 'inner', 'left', 'right', 'order', 'group', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b) "), CompleteEvent(text_inserted=True)))
        self.a(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b inner join "), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b inner join C3_2_XYZ11 "), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left "), CompleteEvent(text_inserted=True)))
        self.a(set(['outer']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left outer "), CompleteEvent(text_inserted=True)))
        self.a(set(['join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left outer join "), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join "), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right "), CompleteEvent(text_inserted=True)))
        self.a(set(['outer']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right outer "), CompleteEvent(text_inserted=True)))
        self.a(set(['join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join "), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.a(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.a(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9( '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        # column name bnf is broken
        # cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a, '), CompleteEvent(text_inserted=True)))
        # self.a(set(['id']), {c.text for c in cs})

        # cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) '), CompleteEvent(text_inserted=True)))
        # self.a(set(['values(', 'select']), {c.text for c in cs})

        # cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) select '), CompleteEvent(text_inserted=True)))
        # self.a(set(['*']), {c.text for c in cs})

        # cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) values( '), CompleteEvent(text_inserted=True)))
        # self.a(set(["'"]), {c.text for c in cs})

        # cs = list(completer.get_completions(Document("insert into C3_2_XYZ9(a,b) values('x','y') "), CompleteEvent(text_inserted=True)))
        # self.a(set(["&"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['set']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a= '), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v, '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v '), CompleteEvent(text_inserted=True)))
        self.a(set(['where', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v,b=w where '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v,b=w where id=v '), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v where id not '), CompleteEvent(text_inserted=True)))
        self.a(set(['in', 'like']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v where id not like '), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete '), CompleteEvent(text_inserted=True)))
        self.a(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where '), CompleteEvent(text_inserted=True)))
        self.a(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id '), CompleteEvent(text_inserted=True)))
        self.a(set(['=', '<', '<=', '>', '>=', '<>', 'like', 'not', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id= '), CompleteEvent(text_inserted=True)))
        self.a(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id=a '), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in( ' ), CompleteEvent(text_inserted=True)))
        self.a(set(["'", 'select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in(select id from '), CompleteEvent(text_inserted=True)))
        self.a(set(['(', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in(select id from C3_2_XYZ9) '), CompleteEvent(text_inserted=True)))
        self.a(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter '), CompleteEvent(text_inserted=True)))
        self.a(set(['table']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.a(set(['add', 'drop', 'rename']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from C3_2_XYZ9; '), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'insert', 'update', 'delete', 'alter', 'preview']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()