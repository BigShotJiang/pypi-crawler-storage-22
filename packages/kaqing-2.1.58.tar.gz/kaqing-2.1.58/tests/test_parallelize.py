from concurrent.futures import as_completed
import time
import unittest

from adam.config import Config
from adam.utils_concurrent import parallelize

class TestParallelize(unittest.TestCase):
    Config()

    def test_parallelize(self):
        def xyz2(t0):
            def f(i):
                time.sleep(2)

            # return [exec.submit(f)]
            with parallelize(['a', 'b'], msg='Begin|End') as exec:
                return exec.as_completed(f)

        t0 = time.time()
        xyz2(t0)
        print('time', int(time.time() - t0))

if __name__ == '__main__':
    unittest.main()