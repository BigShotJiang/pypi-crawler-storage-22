from typing import Callable
import unittest

from adam.commands.export.export_databases import ExportDatabases
from adam.commands.export.exporter import Exporter
from adam.commands.export.utils_export import ExportSpec, ExportTableSpec
from adam.config import Config
from adam.repl_state import ReplState
from adam.utils_k8s.kube_context import KubeContext
from adam.utils_k8s.pods import Pods
from adam.utils_k8s.statefulsets import StatefulSets

class ReplHandler:
    def __enter__(self):
        KubeContext.init_config()
        sts, ns = StatefulSets.list_sts_name_and_ns()[0]
        self.state = ReplState(sts=sts, pod=f'{sts}-0', namespace=ns)
        # Config().set('debug', 'true')

        return self.state

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.state and self.state.export_session:
            Exporter.clean_up_session(self.state.sts, self.state.pod, self.state.namespace, self.state.export_session)

        return False

def repl():
    return ReplHandler()

class TestPods(unittest.TestCase):
    def test_export_csv(self):
        with repl() as state:
            Pods.exec(state.pod, 'cassandra', state.namespace, 'ls', show_out=True, background=True)
            # spec: ExportSpec = None

            # Config().set('debug', 'true')
            # tables, spec = Exporter.export_tables(['azops88_db.analyticscontainer_dfeevalhistory', 'to', 'csv'], state)
            # self.assertEqual(['pending_import'], tables)
            # spec_session = spec.session
            # self.assertTrue(spec_session.startswith('c'))
            # self.assertIsNone(state.export_session)

            # tables, spec = Exporter.import_session([spec_session], state)
            # self.assertEqual(spec_session.replace('c', 's'), spec.session)

if __name__ == '__main__':
    unittest.main()