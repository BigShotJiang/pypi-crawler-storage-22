import time
import traceback
from typing import Iterator
import unittest

from adam.repl_state import ReplState
from adam.utils_concurrent import parallelize
from tests.repl_handler import repl

class TestPodsParallelize(unittest.TestCase):
    def test_parallelize(self):
        def sleep(s: int):
            try:
                time.sleep(s)
                return s
            except:
                traceback.print_stack()

        samples = 2
        t0 = time.time()
        with repl(debug=False, device=ReplState.C, pod=False) as (state, _):
            with parallelize([1, 2, 5]) as exec:
                rs: Iterator[int] = exec.sample(lambda pod: sleep(pod), [1, 2, 5], samples=2)
                for r in rs:
                    print('r', r)
                    samples -= 1
                    if not samples:
                        break

        print('time', time.time() - t0)

if __name__ == '__main__':
    unittest.main()