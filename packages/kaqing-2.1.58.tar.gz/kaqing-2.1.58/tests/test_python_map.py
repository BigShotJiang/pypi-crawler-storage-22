import time
import unittest
import concurrent

class TestPythonMap(unittest.TestCase):
    def test_completion_athena(self):
        def task(item):
            time.sleep(item)
            return item

        items = [1, 2, 10]

        # Use a context manager to manage the thread pool life cycle
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            results = executor.map(task, items)
            for r in results:
                print(r)

        print(list(results)) # Output: [1, 4, 9, 16, 25]

if __name__ == '__main__':
    unittest.main()