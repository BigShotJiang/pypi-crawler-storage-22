import unittest
from prompt_toolkit.document import Document

from adam.commands.reaper.utils_reaper import Reapers
from adam.repl_state import ReplState
from adam.utils import ConfigHolder, ConfigReadable
from adam.utils_repl.repl_completer import AsyncExecutor, ReplCompleter
from tests.repl_handler import repl

class TestReaperShowRuns(unittest.TestCase):
    def test_cql(self):
        ConfigHolder.is_display_help = False

        with repl(debug=False, device=ReplState.C, pod=True) as (state, _):
            # ReaperRuns().run('reaper show runs', state)

            completions = {'run': AsyncExecutor(lambda: {id: None for id in Reapers.cached_schedule_ids(state)})}
            completer = ReplCompleter.from_nested_dict(completions)
            n = completer.get_completions(Document('run '), None)
            print(list(n))

            # completer = ReplCompleter.from_nested_dict(completions)
            # n = completer.get_completions(Document('run '), None)
            # print(list(n))

if __name__ == '__main__':
    unittest.main()