from pathlib import Path
import sys
import time
import unittest

from adam.repl_state import ReplState
from adam.utils_color import Color
from adam.utils_cassandra.node_restartability import NodeRestartability
from adam.utils_cassandra.node_restart_scheduler import NodeRestartScheduler
from adam.utils_k8s.statefulsets import StatefulSets
from repl_handler import repl
from adam.commands.nodetool.utils_nodetools import NodeTools
from adam.config import Config
from adam.utils_cassandra.cassandra_status import AddressTable, CassandraStatus
from adam.utils_context import Context

class TestRestart(unittest.TestCase):
    def _test_restartings(self):
        NodeRestartScheduler._in_restartings[('x', 'y')] = time.time()
        self.assertTrue(1, len(NodeRestartScheduler.restartings(timeout=1)))
        time.sleep(2)
        self.assertEqual({}, NodeRestartScheduler.restartings(timeout=1))

    def test_restart(self):
        Config()
        Config().set('debugs.timings', 'on')
        Config().set('cassandra.restart.check-tokens-dup-hosting', False)

        with repl() as (state, _):
            ctx = Context.new(show_out=True)

            pod1 = 'cs-a7b13e29bd-cs-a7b13e29bd-default-sts-1'
            print(f'============= restarting {pod1} ==============')

            node: NodeRestartability = NodeRestartability.probe(state, pod1, in_restartings=[], ctx=ctx.copy(show_out=False, background=False))
            self.assertTrue(node.restartable())

            NodeRestartScheduler.restart_node(pod1, state.namespace, ctx)
            self.assertEqual(set([(pod1, state.namespace)]), set(NodeRestartScheduler.restartings()))

            pod2 = 'cs-a7b13e29bd-cs-a7b13e29bd-default-sts-2'
            print(f'============= restarting {pod2} ==============')

            node: NodeRestartability = NodeRestartability.probe(state, pod2, in_restartings=NodeRestartScheduler.restartings(), ctx=ctx.copy(show_out=False, background=False))
            node.log(ctx.copy(text_color=Color.gray))

            self.assertFalse(node.restartable())
            time.sleep(3)

            print('in_restarts', NodeRestartScheduler.restartings())
            node: NodeRestartability = NodeRestartability.probe(state, pod2, in_restartings=NodeRestartScheduler.restartings(), ctx=ctx.copy(show_out=False, background=False))
            node.log(ctx.copy(text_color=Color.gray))

            self.assertFalse(node.restartable())

            # for faster testing, time out in_restarts as soon as pod1 is back online
            print('waiting for node to come back', pod1)
            while pod1 not in StatefulSets.running_pods(state.sts, state.namespace):
                time.sleep(1)
            print('pod is back online', pod1)

            # sometimes, even when pod returns 'Running', the actual cassandra node's status is still in 'DN'
            while TestRestart.nodetool_status(state, pod1, ctx) != 'UN':
                time.sleep(1)
            print('node is back online', pod1)

            node: NodeRestartability = NodeRestartability.probe(state, pod2, in_restartings=NodeRestartScheduler.restartings(), ctx=ctx.copy(show_out=False, background=False))
            node.log(ctx.copy(text_color=Color.gray))

            self.assertFalse(node.restartable())
            time.sleep(1)

            pod2 = 'cs-a7b13e29bd-cs-a7b13e29bd-default-sts-2'
            print(f'============= timed out in_restart manually, restarting {pod2} ==============')

            node: NodeRestartability = NodeRestartability.probe(state, pod2, in_restartings=NodeRestartScheduler.restartings(timeout=1), ctx=ctx.copy(show_out=False, background=False))
            node.log(ctx.copy(text_color=Color.gray))

            self.assertTrue(node.restartable())

    def nodetool_status(state: ReplState, pod: str, ctx: Context = Context.NULL) -> str:
        if pod not in AddressTable.host_ids_by_pod:
            return 'Uknown'

        host_id = AddressTable.host_ids_by_pod[pod]

        status = CassandraStatus.snapshot(state, samples=Config().get('nodetool.samples', sys.maxsize), ctx=ctx.copy(show_out=False)).status
        status_by_host_id = {s['host_id']: s for s in status}

        if host_id not in status_by_host_id:
            return 'Unknown'

        return status_by_host_id[host_id]['status']

    def _test_96(self):
        p = f'{Path(__file__).resolve().parent}/data/nodetool_ring.out'
        print(p)
        with open(p) as f:
            out = f.read()
            ring = NodeTools.parse_nodetool_ring(out)
            ip = ring[1]['address']
            print(ip)

            addrs = {r['address'] for r in ring[2:]}

            replica_ips, my_tokens = CassandraStatus.replica_ips(ip, out)
            # # of ip addresses should be 32 - 1(myself)
            self.assertEqual(31, len(replica_ips))

            # # of token ranges should be 16
            tokens = set()
            for token in replica_ips.values():
                tokens |= token

            self.assertEqual(16, len(tokens))
            self.assertEqual(16, len(my_tokens))

            self.assertEqual(my_tokens, tokens)

            downs = {ip}
            addrs.remove(ip)

            # addrs = {r['address'] for r in ring[2:]}
            yes = 0
            no = 0
            for ip0 in addrs:
                # ip = r['address']
                replica_ips, my_tokens = CassandraStatus.replica_ips(ip0, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 1', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            # downs.add(ring[2]['address'])
            # addrs.remove(ring[2]['address'])

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = CassandraStatus.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 2', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = CassandraStatus.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 3', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = CassandraStatus.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 4', yes, no)

if __name__ == '__main__':
    unittest.main()