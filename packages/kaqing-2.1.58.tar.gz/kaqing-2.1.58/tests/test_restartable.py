from pathlib import Path
import unittest

from adam.commands.nodetool.utils_nodetools import NodeTools
from adam.utils_cassandra.cassandra import Cassandra

class TestRestartable(unittest.TestCase):
#     def test_restartable(self):
#         Config()
#         with repl() as (state, _):
#             ctx = Context.new(show_out=True)
#             node = Cassandra.restartable(state, 'cs-a7b13e29bd-cs-a7b13e29bd-default-sts-1')
#             node.log(ctx)

    def test_96(self):
        p = f'{Path(__file__).resolve().parent}/data/nodetool_ring.out'
        print(p)
        with open(p) as f:
            out = f.read()
            ring = NodeTools.parse_nodetool_ring(out)
            ip = ring[1]['address']
            print(ip)

            addrs = {r['address'] for r in ring[2:]}

            replica_ips, my_tokens = Cassandra.replica_ips(ip, out)
            # # of ip addresses should be 32 - 1(myself)
            self.assertEqual(31, len(replica_ips))

            # # of token ranges should be 16
            tokens = set()
            for token in replica_ips.values():
                tokens |= token

            self.assertEqual(16, len(tokens))
            self.assertEqual(16, len(my_tokens))

            self.assertEqual(my_tokens, tokens)

            downs = {ip}
            addrs.remove(ip)

            # addrs = {r['address'] for r in ring[2:]}
            yes = 0
            no = 0
            for ip0 in addrs:
                # ip = r['address']
                replica_ips, my_tokens = Cassandra.replica_ips(ip0, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 1', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            # downs.add(ring[2]['address'])
            # addrs.remove(ring[2]['address'])

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = Cassandra.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 2', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = Cassandra.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 3', yes, no)

            ip = list(addrs)[0]
            downs.add(ip)
            addrs.remove(ip)

            yes = 0
            no = 0
            for ip in addrs:
                # ip = r['address']
                replica_ips, my_tokens = Cassandra.replica_ips(ip, out)

                restartable = True
                for i in replica_ips.keys():
                    if i in downs:
                        restartable = False
                        break

                if restartable:
                    yes += 1
                else:
                    no +=1

            print('restartables 4', yes, no)

if __name__ == '__main__':
    unittest.main()