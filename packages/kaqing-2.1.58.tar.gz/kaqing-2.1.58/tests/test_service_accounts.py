import base64
import json
import os
import re
import unittest
import jwt
import requests
import urllib

from kubernetes import config
from adam.utils_k8s.service_accounts import ServiceAccounts

class TestServiceAccounts(unittest.TestCase):
    def test_service_accounts(self):
        config.load_kube_config()

        namespace = 'azops88'
        # ServiceAccounts.get_role_bindings('azops88', 'c3')
        ServiceAccounts.delete(namespace, 'c3-ops=azops88')
        ServiceAccounts.replicate('ops', namespace, 'c3', labels={'c3-ops': namespace}, add_cluster_roles=['c3aiops-k8ssandra-operator'])

if __name__ == '__main__':
    unittest.main()