import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.utils_repl.set_completer import SetCompleter

class TestSetCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion_set(self):
        completer = SetCompleter(words=['abc', 'def', 'ghi'], options={'-s': {'&': None}})

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['abc', 'def', 'ghi']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('a'), CompleteEvent(text_inserted=True)))
        self.a(set(['abc']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, '), CompleteEvent(text_inserted=True)))
        self.a(set(['def', 'ghi']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, def, '), CompleteEvent(text_inserted=True)))
        self.a(set(['ghi']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, def, ghi '), CompleteEvent(text_inserted=True)))
        self.a(set(['-s']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, def, ghi -s '), CompleteEvent(text_inserted=True)))
        self.a(set(['&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, def, ghi -s & '), CompleteEvent(text_inserted=True)))
        self.a(set([]), {c.text for c in cs})

    def test_completion_set_no_options(self):
        completer = SetCompleter(words=['abc', 'def', 'ghi'])

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['abc', 'def', 'ghi']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('abc, '), CompleteEvent(text_inserted=True)))
        self.a(set(['def', 'ghi']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()