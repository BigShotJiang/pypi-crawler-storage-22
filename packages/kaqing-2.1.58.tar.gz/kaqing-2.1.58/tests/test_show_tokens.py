import unittest

from adam.commands.cassandra.show_tokens import ShowTokens
from repl_handler import repl
from adam.config import Config
from adam.utils_context import Context

class TestShowTokens(unittest.TestCase):
    def test_show_tokens(self):
        Config()

        with repl() as (state, _):
            ctx = Context.new(show_out=True)

            st = ShowTokens()
            c = st.completion(state)
            print(c)

if __name__ == '__main__':
    unittest.main()