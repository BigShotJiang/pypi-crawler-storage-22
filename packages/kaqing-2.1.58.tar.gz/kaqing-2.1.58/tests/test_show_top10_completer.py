import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.commands.audit.utils_show_top10 import ShowTop10StateMachine
from adam.commands.bash.bash import BashStateMachine
from adam.utils_repl.automata_completer import AutomataCompleter

class TestShowTop10Completer(unittest.TestCase):
    def test_completion(self):
        completer = AutomataCompleter(ShowTop10StateMachine(debug=True), debug=True)
        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['top', 'slow', 'last']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show top '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['10']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show top 20 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['over']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('show top 20 over '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['day', 'month']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()