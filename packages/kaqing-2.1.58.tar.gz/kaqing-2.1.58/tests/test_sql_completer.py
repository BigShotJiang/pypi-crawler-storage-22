import unittest

from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.sql.sql_completer import SqlCompleter, SqlVariant

class TestSqlCompleter(unittest.TestCase):
    def test_completion(self):
        completer = SqlCompleter(lambda: ['C3_2_XYZ9'], debug=True)
        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select', 'insert', 'update', 'delete', 'alter', 'preview']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('sel'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from'), CompleteEvent(text_inserted=True)))
        self.assertEqual(0, len(cs))

        cs = list(completer.get_completions(Document('select id, name from '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(select', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(select', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from C3_2'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from (select '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'where', 'inner join', 'left outer join', 'right outer join', 'full outer join', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from audit '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'where', 'inner join', 'left outer join', 'right outer join', 'full outer join', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['x', 'y', 'z']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x, C3_2_XYZ10 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'where', 'inner join', 'left outer join', 'right outer join', 'full outer join', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 as x '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['where', 'inner join', 'left outer join', 'right outer join', 'full outer join', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where i'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where C3_2_XYZ9.'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9, C3_2_XYZ10 where '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['=', '<', '<=', '>', '>=', '<>', 'like', 'not', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id='), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['like', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id in'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in("), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'", 'select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in(select "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in(select id from C3_2_XYZ9) "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v',"), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v', "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v') "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id in('v', 'w') "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not in'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 where id not like '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where (id = 'v' or id = 'w') "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 3 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 3.1 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where id = 'v') "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where (id = 'v')) "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 where (id = 'v') ) "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' limit "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from (select * from C3_2_XYZ9 where id = 'v' limit 1) "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(select', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from C3_2_XYZ9 where id = 'v' "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select id, name from C3_2_XYZ9 where id = 'v' and id2 = 'w' "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', 'group by', 'order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id, name from C3_2_XYZ9 limit '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select id from C3_2_XYZ9 where id=v group by '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9 group by a) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['order by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select name, count(*) from C3_2_XYZ9 group by a limit '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from (select * from C3_2_XYZ9 group by a limit 1) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select count(id) from C3_2_XYZ9 where id = 'v' group "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['by']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['desc', 'asc', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a,"), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a, "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 order by a desc "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 as x "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['=']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a="), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['where', 'inner join', 'left outer join', 'right outer join', 'full outer join', 'order by', 'group by', 'limit', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from (select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b) "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b inner join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 inner join C3_2_XYZ10 on x.a=y.b inner join C3_2_XYZ11 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['outer join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left outer "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left outer join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 left join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['outer join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right outer "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join C3_2_XYZ10 "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'on']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 right join C3_2_XYZ10 on "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 full "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['outer join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 full outer "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['join']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("select * from C3_2_XYZ9 full outer join "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b)'), CompleteEvent(text_inserted=True)))
        self.assertEqual(0, len(cs))

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['values(', 'select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) select '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('insert into C3_2_XYZ9(a,b) values('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("insert into C3_2_XYZ9(a,b) values('x','y') "), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["&"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['set']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a='), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['where', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v,b=w where '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v,b=w where id=v '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v where id not '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['in', 'like']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('update C3_2_XYZ9 set a=v where id not like '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['from']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['=', '<', '<=', '>', '>=', '<>', 'like', 'not', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id='), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id=a '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'", 'select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in(select id from '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(select', 'C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('delete from C3_2_XYZ9 where id in(select id from C3_2_XYZ9) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['and', 'or', '&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['table']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['add', 'add constraint', 'drop column', 'drop constraint', 'rename to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from C3_2_XYZ9; '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select', 'insert', 'update', 'delete', 'alter', 'preview']), {c.text for c in cs})

    def test_completion_cql(self):
        completer = SqlCompleter(lambda: ['C3_2_XYZ9'], expandables={
            'keyspaces': lambda: ['ks1'], 'table-props': lambda: {'GC_GRACE_SECONDS':['1000']}, 'export-dbs': lambda: ['s123'], 'export-sessions': lambda: ['s123']},
            variant=SqlVariant.CQL, debug=True)
        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'consistency', 'export', 'import',
                              'drop', 'clean']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['table', 'tables']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['add', 'drop', 'with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 with '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['GC_GRACE_SECONDS']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 with GC_GRACE_SECONDS='), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['1000']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter tables '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['with']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('describe '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['table', 'tables', 'keyspace', 'keyspaces', 'schema']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('describe tables '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['&']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9', '*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a,'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export DB.C3_2_XYZ9('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['id', 'x.', 'y.', 'z.']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'with consistency', '(', ',', 'to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 with consistency '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['quorum', 'all', 'serial', 'one', 'each_quorum', 'local_quorum', 'any', 'local_one', 'two', 'three', 'local_serial']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 as t '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['with consistency', 'to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9 as t to '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['athena', 'sqlite', 'csv']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a) '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as', 'with consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export C3_2_XYZ9(a) with '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['with', 'in']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * in '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['ks1']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * in ks1 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['with consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('export * with '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['consistency']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv, '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set([]), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['as']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('import files a.csv as d.t '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['to']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['quorum', 'all', 'serial', 'one', 'each_quorum', 'local_quorum', 'any', 'local_one', 'two', 'three', 'local_serial']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency quorum; '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'consistency', 'import', 'export',
                              'drop', 'clean']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('consistency quorum; select '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['*']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['all export databases', 'export database']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop all export '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['databases']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop export database '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['s123']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['up all export sessions', 'up export session']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['all export sessions', 'export sessions']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up all export '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['sessions']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('clean up export sessions '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['s123']), {c.text for c in cs})

    def test_completion_athena(self):
        completer = SqlCompleter(lambda: ['C3_2_XYZ9'], expandables={
            'columns': lambda x: ['line', 'c', 'y', 'm', 'd'], 'export-dbs': lambda: ['s123'],
            'partition-columns': lambda x: ['c', 'y', 'm', 'd']}, variant=SqlVariant.ATHENA, debug=True)
        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['select', 'insert', 'update', 'delete', 'alter', 'describe', 'preview', 'drop']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('.select * from '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9', '(select']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_X'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table cluster '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['add partition', 'drop partition']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['add partition', 'drop partition']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['partition']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add partition '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['(']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('alter table C3_2_XYZ9 add partition('), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['c', 'y', 'm', 'd']), {c.text for c in cs})

        cs = list(completer.get_completions(Document("alter table C3_2_XYZ9 add partition(c="), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(["'"]), {c.text for c in cs})

        cs = list(completer.get_completions(Document("alter table C3_2_XYZ9 add partition(c='v',"), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['c', 'y', 'm', 'd']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop export database '), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['s123']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()