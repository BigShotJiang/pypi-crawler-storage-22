import unittest

from adam.commands.export.utils_export import ExportSpec, ExportTableSpec

class TestUtilsExport(unittest.TestCase):
    def test_parse(self):
        spec: ExportSpec = ExportSpec.parse_specs('')
        self.assertEqual(None, spec.keyspace)
        self.assertEqual(None, spec.consistency)
        self.assertEqual(None, spec.tables)

        spec: ExportSpec = ExportSpec.parse_specs('*')
        self.assertEqual('*', spec.keyspace)
        self.assertEqual(None, spec.consistency)
        self.assertEqual(None, spec.tables)

        spec: ExportSpec = ExportSpec.parse_specs('* in k1')
        self.assertEqual('k1', spec.keyspace)
        self.assertEqual(None, spec.consistency)
        self.assertEqual(None, spec.tables)

        spec: ExportSpec = ExportSpec.parse_specs('* in k1 with consistency quorum')
        self.assertEqual('k1', spec.keyspace)
        self.assertEqual('quorum', spec.consistency)
        self.assertEqual(None, spec.tables)

        spec: ExportSpec = ExportSpec.parse_specs('X.C3_2_XYZ9 with consistency quorum')
        self.assertEqual(None, spec.keyspace)
        self.assertEqual('quorum', spec.consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ9')], spec.tables)

    def test_extract_consisteny(self):
        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ9(id,columnname)')
        self.assertIsNone(consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ9', 'id,columnname')], specs)

        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ8(id,columnname),X.C3_2_XYZ9(id,columnname)')
        self.assertIsNone(consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ8', 'id,columnname'), ExportTableSpec('X', 'C3_2_XYZ9', 'id,columnname')], specs)

        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ8, X.C3_2_XYZ9(id,columnname)')
        self.assertIsNone(consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ8'), ExportTableSpec('X', 'C3_2_XYZ9', 'id,columnname')], specs)

        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ8, X.C3_2_XYZ9 with consistency quorum')
        self.assertEqual('quorum', consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ8'), ExportTableSpec('X', 'C3_2_XYZ9')], specs)

        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ8 as a1, X.C3_2_XYZ9(id,columnname) as a2 with consistency quorum')
        self.assertEqual('quorum', consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ8', None, 'a1'), ExportTableSpec('X', 'C3_2_XYZ9', 'id,columnname', 'a2')], specs)

        consistency, specs = ExportSpec._extract_consisteny('X.C3_2_XYZ8 with consistency quorum')
        self.assertEqual('quorum', consistency)
        self.assertEqual([ExportTableSpec('X', 'C3_2_XYZ8')], specs)

if __name__ == '__main__':
    unittest.main()