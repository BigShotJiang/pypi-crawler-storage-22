import re
import unittest

from prompt_toolkit.completion import CompleteEvent, WordCompleter
from prompt_toolkit.document import Document

class TestWordCompleter(unittest.TestCase):
    def test_completion(self):
        completer = WordCompleter(['x.y'], pattern=re.compile("([a-zA-Z0-9_\.]+|[^a-zA-Z0-9_\.\s]+)"))
        cs = list(completer.get_completions(Document('x'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['x.y']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('x.'), CompleteEvent(text_inserted=True)))
        self.assertEqual(set(['x.y']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()