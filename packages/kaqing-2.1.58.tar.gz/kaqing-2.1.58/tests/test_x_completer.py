import unittest
from prompt_toolkit.completion import CompleteEvent
from prompt_toolkit.document import Document

from adam.repl_state import ReplState
from adam.sql.lark_completer import LarkCompleter
from adam.sql.lark_parser import LarkParser

class TestExportCompleter(unittest.TestCase):
    def a(self, s0: set, s1: set):
        try:
            self.assertTrue(s0.issubset(s1))
        except Exception as e:
            print(s0)
            print(s1)
            print('missing', s0 - s1)
            raise e

    def test_completion_cql(self):
        completer = LarkCompleter(expandables={
                'tables': lambda x: ['C3_2_XYZ9'],
                'export-databases': lambda x: ['s123'],
                'columns': lambda _: ['id'],
            }, variant=ReplState.X, debug=True)
        LarkParser.show_returns = True

        cs = list(completer.get_completions(Document(''), CompleteEvent(text_inserted=True)))
        self.a(set(['select', 'drop']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('drop export database '), CompleteEvent(text_inserted=True)))
        self.a(set(['s123']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('select * from '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

        cs = list(completer.get_completions(Document('xelect * from '), CompleteEvent(text_inserted=True)))
        self.a(set(['C3_2_XYZ9']), {c.text for c in cs})

if __name__ == '__main__':
    unittest.main()