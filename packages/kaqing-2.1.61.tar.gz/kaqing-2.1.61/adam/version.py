#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = "2.1.61"  #: the working version
__release__ = "1.0.0"  #: the release version