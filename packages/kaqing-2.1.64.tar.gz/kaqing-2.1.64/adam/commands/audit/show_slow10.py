from adam.commands.audit.utils_show_top10 import run_configured_query
from adam.commands.command import Command
from adam.utils_repl.repl_state import ReplState

class ShowSlow10(Command):
    COMMAND = 'show slow'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ShowSlow10, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ShowSlow10.COMMAND

    def required(self):
        return ReplState.L

    def backgrounable(self):
        return True

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (args, state):
            with self.context(args) as (args, ctx):
                run_configured_query('audit.queries.slow10', args, ctx=ctx)

                return state

    def completion(self, _: ReplState):
        return {}

    def help(self, state: ReplState):
        # shown by show_top10
        return None