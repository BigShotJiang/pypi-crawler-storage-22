from adam.commands import validate_args
from adam.commands.command import Command
from adam.commands.reaper.utils_reaper import Reapers, reaper
from adam.utils_repl.repl_state import ReplState, RequiredState

class ReaperScheduleStop(Command):
    COMMAND = 'reaper stop schedule'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ReaperScheduleStop, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ReaperScheduleStop.COMMAND

    def required(self):
        return RequiredState.CLUSTER

    def run(self, cmd: str, state: ReplState):
        if not(args := self.args(cmd)):
            return super().run(cmd, state)

        with self.validate(args, state) as (args, state):
            with self.context(args) as (args, ctx):
                with validate_args(args, state, name='schedule') as schedule_id:
                    with reaper(state) as http:
                        http.put(f'repair_schedule/{schedule_id}?state=PAUSED')
                        Reapers.show_schedule(state, schedule_id, ctx=ctx)

                    return schedule_id

    def completion(self, state: ReplState):
        return super().completion(state, lambda: {id: None for id in Reapers.cached_schedule_ids(state)}, auto_key='reaper.schedules')

    def help(self, state: ReplState):
        return super().help(state, 'pause reaper schedule', args='<schedule-id>')