from karrio.providers.colissimo.shipment.create import (
    parse_shipment_response,
    shipment_request,
)
