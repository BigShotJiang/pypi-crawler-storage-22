
from karrio.providers.dpd_meta.shipment.create import (
    parse_shipment_response,
    shipment_request,
)
