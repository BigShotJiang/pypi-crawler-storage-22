"""Karrio GLS Group mapper module."""
from karrio.mappers.gls.mapper import Mapper
from karrio.mappers.gls.proxy import Proxy
from karrio.mappers.gls.settings import Settings
