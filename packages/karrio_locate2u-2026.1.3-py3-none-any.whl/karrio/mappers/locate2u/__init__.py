from karrio.mappers.locate2u.mapper import Mapper
from karrio.mappers.locate2u.proxy import Proxy
from karrio.mappers.locate2u.settings import Settings
