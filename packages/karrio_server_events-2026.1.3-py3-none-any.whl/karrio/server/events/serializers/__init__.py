from karrio.server.events.serializers.base import *
