import logging

logging.disable(logging.CRITICAL)

from karrio.server.orders.tests.test_orders import *
