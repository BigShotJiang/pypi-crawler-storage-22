"""Karrio USPS schedule pickup implementation."""

import karrio.schemas.usps_international.pickup_request as usps
import karrio.schemas.usps_international.pickup_response as pickup

import typing
import karrio.lib as lib
import karrio.core.units as units
import karrio.core.models as models
import karrio.providers.usps_international.error as error
import karrio.providers.usps_international.utils as provider_utils
import karrio.providers.usps_international.units as provider_units


def parse_pickup_response(
    _response: lib.Deserializable[dict],
    settings: provider_utils.Settings,
) -> typing.Tuple[typing.List[models.PickupDetails], typing.List[models.Message]]:
    response = _response.deserialize()

    messages = error.parse_error_response(response, settings)
    pickup = (
        _extract_details(response, settings)
        if "confirmationNumber" in response
        else None
    )

    return pickup, messages


def _extract_details(
    data: dict,
    settings: provider_utils.Settings,
) -> models.PickupDetails:
    details = lib.to_object(pickup.PickupResponseType, data)

    return models.PickupDetails(
        carrier_id=settings.carrier_id,
        carrier_name=settings.carrier_name,
        confirmation_number=details.confirmationNumber,
        pickup_date=lib.fdate(details.pickupDate),
    )


def pickup_request(
    payload: models.PickupRequest,
    settings: provider_utils.Settings,
) -> lib.Serializable:
    # USPS International only supports one-time pickups via API
    pickup_type = getattr(payload, "pickup_type", "one_time") or "one_time"
    if pickup_type not in ("one_time", None):
        raise lib.exceptions.FieldError({
            "pickup_type": f"USPS International only supports 'one_time' pickups via API. Received: '{pickup_type}'. "
            "For daily/recurring pickups, please contact USPS to set up a regular pickup schedule."
        })

    address = lib.to_address(payload.address)
    packages = lib.to_packages(payload.parcels)
    options = lib.units.Options(
        payload.options,
        option_type=lib.units.create_enum(
            "PickupOptions",
            # fmt: off
            {
                "usps_package_type": lib.OptionEnum("usps_package_type"),
            },
            # fmt: on
        ),
    )

    # map data to convert karrio model to usps specific type
    request = usps.PickupRequestType(
        pickupDate=lib.fdate(payload.pickup_date),
        pickupAddress=usps.PickupAddressType(
            firstName=address.person_name,
            lastName=None,
            firm=address.company_name,
            address=usps.AddressType(
                streetAddress=address.address_line1,
                secondaryAddress=address.address_line2,
                city=address.city,
                state=address.state,
                ZIPCode=lib.to_zip5(address.postal_code),
                ZIPPlus4=lib.to_zip4(address.postal_code) or "",
                urbanization=None,
            ),
            contact=[
                usps.ContactType(email=address.email)
                for _ in [address.email]
                if _ is not None
            ],
        ),
        packages=[
            usps.PackageType(
                packageType=options.usps_package_type.state or "OTHER",
                packageCount=len(packages),
            )
        ],
        estimatedWeight=packages.weight.LB,
        pickupLocation=lib.identity(
            usps.PickupLocationType(
                packageLocation=payload.package_location,
                specialInstructions=payload.instruction,
            )
            if any([payload.package_location, payload.instruction])
            else None
        ),
    )

    return lib.Serializable(request, lib.to_dict)
