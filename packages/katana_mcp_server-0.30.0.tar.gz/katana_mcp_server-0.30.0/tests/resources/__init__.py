"""Tests for MCP resources."""
