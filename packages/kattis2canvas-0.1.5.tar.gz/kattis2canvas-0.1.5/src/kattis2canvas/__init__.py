"""kattis2canvas - CLI tool to integrate Kattis offerings with Canvas LMS courses."""

__version__ = "0.1.4"
