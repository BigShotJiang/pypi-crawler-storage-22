"""The configuration models for ESQL dimensions and metrics."""
