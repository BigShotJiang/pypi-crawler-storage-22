"""Lens column chart components."""
