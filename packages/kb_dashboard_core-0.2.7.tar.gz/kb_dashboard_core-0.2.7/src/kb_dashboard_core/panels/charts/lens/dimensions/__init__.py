"""Define dimensions for Lens panels in the dashboard compiler."""

from .config import LensDimensionTypes

__all__ = [
    'LensDimensionTypes',
]
