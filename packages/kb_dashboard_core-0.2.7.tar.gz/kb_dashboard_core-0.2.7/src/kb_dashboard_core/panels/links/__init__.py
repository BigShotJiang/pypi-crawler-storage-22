"""Module for links."""

from .config import LinksPanel

__all__ = [
    'LinksPanel',
]
