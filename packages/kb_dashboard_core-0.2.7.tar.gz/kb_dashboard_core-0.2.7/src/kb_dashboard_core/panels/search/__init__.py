"""Search Panel."""

from .config import SearchPanel

__all__ = [
    'SearchPanel',
]
