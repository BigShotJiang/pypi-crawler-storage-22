"""Sample data module for bundling data with dashboards."""
