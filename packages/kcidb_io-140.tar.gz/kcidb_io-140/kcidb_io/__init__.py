"""Kernel CI reporting I/O data"""

from kcidb_io import schema, misc # noqa Silence flake8 "imported but unused" warning
