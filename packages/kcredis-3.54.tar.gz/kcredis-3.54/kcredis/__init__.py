# -*- coding: utf-8 -*-
__version__ = '3.54'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()