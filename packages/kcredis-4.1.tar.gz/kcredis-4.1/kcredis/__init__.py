# -*- coding: utf-8 -*-
__version__ = '4.1'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()