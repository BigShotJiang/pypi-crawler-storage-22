# -*- coding: utf-8 -*-
__version__ = '3.54'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()