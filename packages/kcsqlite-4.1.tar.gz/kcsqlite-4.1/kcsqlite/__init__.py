# -*- coding: utf-8 -*-
__version__ = '4.1'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()