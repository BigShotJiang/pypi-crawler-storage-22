# -*- coding: utf-8 -*-
__version__ = '4.1'
try:
    from .app import web
except:pass
    # print('警告：from .app import web导入失败')
# from . import config
kcwsinfo={}
kcwsinfo['name']='kcwapi'                             #项目的名称
kcwsinfo['version']=__version__							#项目版本
kcwsinfo['description']='kcwapi'       #项目的简单描述
kcwsinfo['long_description']='kcwapi'     #项目详细描述
kcwsinfo['license']='MIT License'                    #开源协议   mit开源
kcwsinfo['url']='https://docs.kwebapp.cn/index/index/2'
kcwsinfo['author']='百里-坤坤'  					 #名字
kcwsinfo['author_email']='kcwebs@kwebapp.cn' 	     #邮件地址
kcwsinfo['maintainer']='坤坤' 						 #维护人员的名字
kcwsinfo['maintainer_email']='1402936534@qq.com'    #维护人员的邮件地址