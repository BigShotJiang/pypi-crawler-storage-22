# -*- coding: utf-8 -*-
__version__ = '3.29'
from .cacheclass import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
cache=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()