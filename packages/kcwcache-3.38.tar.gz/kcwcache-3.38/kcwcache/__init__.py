# -*- coding: utf-8 -*-
__version__ = '3.38'
from .cacheclass import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
cache=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()