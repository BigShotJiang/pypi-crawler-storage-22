from .app import *
from .. import kcwebpinfo as kcwebp


fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=kcwebp['name'] #不要修改改参数，否则无法上传模块和插件

