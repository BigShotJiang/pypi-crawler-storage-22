# -*- coding: utf-8 -*-
from kcwweb.config import *