try:
    from .common import *
except Exception as e:
    if 'unable to open database file' in str(e):
        print('该命令仅支持运行kcwebp项目',e)
        exit()
    else:
        print('e',e)
from kcwweb import kcwweb
def cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr='kcwebp'):
        "脚本入口"
        cmd_par=kcwweb.kcwapi.get_cmd_par(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        if cmd_par and not cmd_par['project']:
            cmd_par['project']='kcwebp'
        if cmd_par and cmd_par['server'] and not cmd_par['help']:#启动web服务
            try:
                Queues.delwhere("code in (2,3)")
            except:pass
            #执行kcwebp自启项
            # try:
            #     import kcsqlite
            #     startdata=kcsqlite.sqlite.connect(model_app_path).where("types='kcwebp'").table("start").order("id asc").select()
            # except Exception as e:
            #     print("需要在kcwebp项目中执行",e)
            #     exit()
            import kcsqlite
            startdata=kcsqlite.sqlite.connect(model_app_path).where("types='kcwebp'").table("start").order("id asc").select()
            for teml in startdata:
                os.system(teml['value'])
            if get_sysinfo()['uname'][0]=='Linux':
                system_start.insert_Boot_up(cmd='cd /kcwebp && bash server.sh',name='kcwebp自启',icon='https://img.kwebapp.cn/icon/kcwweb.png')
                os.system('nohup kcwebp index/index/pub/clistartplan --cli > app/runtime/log/server.log 2>&1 &')
        if cmd_par and cmd_par['install'] and not cmd_par['help']:#插入 应用、模块、插件
            if cmd_par['appname']:
                remppath=os.path.split(os.path.realpath(__file__))[0]
                if not os.path.exists(cmd_par['project']+'/'+cmd_par['appname']) and not os.path.exists(cmd_par['appname']):
                    shutil.copytree(remppath+'/tempfile/kcwebp',cmd_par['project'])
                    if get_sysinfo()['uname'][0]=='Linux':
                        try:
                            os.remove(cmd_par['project']+"/server.bat")
                        except:pass
                    elif get_sysinfo()['uname'][0]=='Windows':
                        try:
                            os.remove(cmd_par['project']+"/server.sh")
                        except:pass
                    print('kcwebp项目创建成功')
                else:
                    t=kcwweb.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
            else:
                t=kcwweb.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        elif cmd_par:
            t=kcwweb.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)