from kcwebp.common import *
# from app import config