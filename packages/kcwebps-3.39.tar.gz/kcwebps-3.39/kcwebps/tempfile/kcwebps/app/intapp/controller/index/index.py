from .common import *
class index:
    def index():
        return successjson('成功')