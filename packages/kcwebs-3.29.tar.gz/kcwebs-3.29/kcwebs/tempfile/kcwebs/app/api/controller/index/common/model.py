# -*- coding: utf-8 -*-
from .autoload import *
# 可以在这里初始化数据库
model_intapp_index_path=os.path.split(os.path.realpath(__file__))[0]+"/file/sqlite/intappindex" #数据存放目录
