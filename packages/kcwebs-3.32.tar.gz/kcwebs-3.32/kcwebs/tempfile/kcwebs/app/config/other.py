# -*- coding: utf-8 -*-
from kcwebs.config import *