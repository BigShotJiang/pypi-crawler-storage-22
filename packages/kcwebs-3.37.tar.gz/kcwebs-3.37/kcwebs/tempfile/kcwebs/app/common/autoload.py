from kcwebs.common import *
from app import config
G=globals.G