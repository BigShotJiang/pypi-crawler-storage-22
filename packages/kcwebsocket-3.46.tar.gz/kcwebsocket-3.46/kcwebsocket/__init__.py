# -*- coding: utf-8 -*-
__version__ = '3.46'
from .rfdszbfnbxrdfgvxrhbdtxrhtbs import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
client=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()