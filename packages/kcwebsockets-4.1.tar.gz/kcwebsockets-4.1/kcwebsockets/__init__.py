# -*- coding: utf-8 -*-
__version__ = '4.1'
from .rfdszbfnbxrdfgvxrhbdtxrhtbs import vsregrsgtrdhbrhtrsgrshydtrsegregsresgr
client=vsregrsgtrdhbrhtrsgrshydtrsegregsresgr()