# -*- coding: utf-8 -*-
__version__ = '3.38'
from .mysqlclass import grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre
mysql=grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre()