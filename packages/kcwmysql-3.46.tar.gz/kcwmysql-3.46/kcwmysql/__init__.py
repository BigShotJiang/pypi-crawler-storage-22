# -*- coding: utf-8 -*-
__version__ = '3.46'
from .mysqlclass import grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre
mysql=grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre()