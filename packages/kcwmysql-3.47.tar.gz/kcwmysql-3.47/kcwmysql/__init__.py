# -*- coding: utf-8 -*-
__version__ = '3.47'
from .mysqlclass import grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre
mysql=grsegrsezgrgtrdrgregrsgrgssrgrdfrsgregsregre()