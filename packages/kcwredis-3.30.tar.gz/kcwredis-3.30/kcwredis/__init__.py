# -*- coding: utf-8 -*-
__version__ = '3.30'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()