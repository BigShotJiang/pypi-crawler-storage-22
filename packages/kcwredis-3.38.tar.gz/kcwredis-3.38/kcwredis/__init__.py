# -*- coding: utf-8 -*-
__version__ = '3.38'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()