# -*- coding: utf-8 -*-
__version__ = '3.50'
from .redisclass import gtrdhersreegreshtrdhtrdhtr
redis=gtrdhersreegreshtrdhtrdhtr()