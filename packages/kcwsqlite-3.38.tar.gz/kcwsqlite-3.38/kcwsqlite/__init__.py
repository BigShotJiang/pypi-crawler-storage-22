# -*- coding: utf-8 -*-
__version__ = '3.38'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()