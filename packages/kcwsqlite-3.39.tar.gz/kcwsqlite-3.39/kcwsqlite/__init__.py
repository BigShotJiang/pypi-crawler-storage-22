# -*- coding: utf-8 -*-
__version__ = '3.39'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()