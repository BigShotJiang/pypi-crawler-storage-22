# -*- coding: utf-8 -*-
__version__ = '3.50'
from .sqliteclass import sqliteclass
sqlite=sqliteclass()