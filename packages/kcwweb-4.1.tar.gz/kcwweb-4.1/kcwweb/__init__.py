# -*- coding: utf-8 -*-
__version__ = '4.1'

kcwwebinfo={}
kcwwebinfo['name']='kcwweb'                             #项目的名称
kcwwebinfo['version']=__version__							#项目版本
kcwwebinfo['description']='kcwweb作为web开发而设计的高性能框架'       #项目的简单描述
kcwwebinfo['long_description']='kcwweb作为web开发而设计的高性能框架，采用全新的架构思想，注重易用性。遵循MIT开源许可协议发布，意味着个人和企业可以免费使用kcwweb，甚至允许把你基于kcwweb开发的应用开源或商业产品发布或销售。完整文档请访问：https://docs.kwebapp.cn/index/index/2'     #项目详细描述
kcwwebinfo['license']='MIT License'                    #开源协议   mit开源
kcwwebinfo['url']='https://docs.kwebapp.cn/index/index/2'
kcwwebinfo['author']='百里-坤坤'  					 #名字
kcwwebinfo['author_email']='kcweb@kwebapp.cn' 	     #邮件地址
kcwwebinfo['maintainer']='坤坤' 						 #维护人员的名字
kcwwebinfo['maintainer_email']='fk1402936534@qq.com'    #维护人员的邮件地址
kcwwebinfo['username']=''
kcwwebinfo['password']=''