from .common import *
from kcwapi import kcwapi
import os,shutil
def cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr='kcwweb'):
    "脚本入口"
    
    cmd_par=kcwapi.get_cmd_par(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
    if cmd_par and not cmd_par['project']:
        cmd_par['project']='kcwweb'
    if cmd_par and cmd_par['install'] and not cmd_par['help']:#插入 应用、模块、插件
        if cmd_par['appname']:
            remppath=os.path.split(os.path.realpath(__file__))[0]
            if not os.path.exists(cmd_par['project']+'/'+cmd_par['appname']) and not os.path.exists(cmd_par['appname']):
                shutil.copytree(remppath+'/tempfile/kcwweb',cmd_par['project'])
                print('kcwweb项目创建成功')
            else:
                return kcwapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
        else:
            return kcwapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)
    elif cmd_par:
        return kcwapi.cill_start(fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr=fdgrsgrsegsrsgrsbsdbftbrsbfdrtrtbdfsrsgr)