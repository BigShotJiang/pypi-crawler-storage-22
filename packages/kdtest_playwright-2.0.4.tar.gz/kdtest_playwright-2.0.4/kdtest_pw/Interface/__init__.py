"""Interface 接口测试模块

提供 YAML 批量接口执行功能。
"""

from .common_Interface_Class import CommonInterfaceClass

__all__ = ['CommonInterfaceClass']
