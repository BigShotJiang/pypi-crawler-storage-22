"""公共接口类 - YAML批量接口执行

基于 kdtest 原版迁移，适配 kdtest_pw (Playwright版)。
支持从 InterfaceData.yaml 文件批量执行接口测试。
"""

# Third_party
import requests
from ruamel.yaml import YAML
from tqdm import tqdm

# built_in
import re as re_object
import os
import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

# custom
from ..reference import GSTORE, GSDSTORE, INFO
from ..common import PROJECTROOT
from ..utils.public_script import isLogicMethodClass


class CommonInterfaceClass:
    """公共接口类

    用于批量执行 YAML 格式定义的接口测试用例。

    Attributes:
        yaml: YAML 解析器
        CODE: 接口编码，默认 utf-8
        COOKIE: 当前会话 Cookie
        RESULT: 接口响应结果缓存
    """

    def __repr__(self) -> str:
        return '公共接口类'

    def __init__(self) -> None:
        self.yaml = YAML()
        self.logicFunction_Object = isLogicMethodClass()
        self.CODE = 'utf-8'  # 接口编码
        self.MAPPING_DATA: Optional[Dict] = None

        # 使用 pathlib 处理跨平台路径
        project_root = Path(PROJECTROOT) if PROJECTROOT else Path.cwd()
        cache_dir = project_root / 'data' / 'cache'
        cache_dir.mkdir(parents=True, exist_ok=True)

        self.COOKIE_FILE = cache_dir / 'cookie.txt'
        self.RESULT_FILE = cache_dir / 'response_result.txt'

        # 初始化缓存文件
        self.COOKIE = self._read_cache_file(self.COOKIE_FILE)
        self.RESULT = self._read_cache_file(self.RESULT_FILE)

    def _read_cache_file(self, file_path: Path) -> Dict:
        """读取缓存文件"""
        if file_path.exists():
            content = file_path.read_text(encoding='utf-8').strip()
            if content:
                try:
                    return json.loads(content)
                except json.JSONDecodeError:
                    return {}
        return {}

    def _write_cache_file(self, file_path: Path, data: Any, mode: str = 'w') -> None:
        """写入缓存文件"""
        if data is None:
            file_path.write_text('', encoding='utf-8')
        elif isinstance(data, (dict, list)):
            file_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        else:
            file_path.write_text(str(data), encoding='utf-8')

    def __call__(self, file_src: str) -> bool:
        """执行接口测试

        Args:
            file_src: InterfaceData.yaml 文件路径

        Returns:
            bool: 执行是否成功
        """
        self.FILE_SRC = Path(file_src)
        mapping_file_src = self._handleMappingFile()
        execute = self._readInterfaceData()

        if execute:
            # 清空缓存文件
            self._write_cache_file(self.COOKIE_FILE, None)
            self._write_cache_file(self.RESULT_FILE, None)

            # 删除映射文件
            if mapping_file_src.exists():
                mapping_file_src.unlink()
            return True
        else:
            return False

    def _errorSave(self) -> None:
        """接口执行错误时保存关键数据"""
        mapping_src = self.FILE_SRC.with_name(
            self.FILE_SRC.name.replace('InterfaceData.yaml', '_InterfaceData.yaml')
        )

        # 使用 shutil 复制文件（跨平台兼容）
        shutil.copy(str(self.FILE_SRC), str(mapping_src))

        # 保存 YAML 数据
        self.logicFunction_Object.raw_YamlTxt(str(mapping_src), 'w', self.MAPPING_DATA)

        # 保存缓存数据
        self._write_cache_file(self.COOKIE_FILE, self.COOKIE)
        self._write_cache_file(self.RESULT_FILE, self.RESULT)

    def _handleMappingFile(self) -> Path:
        """处理接口数据映射文件

        Returns:
            Path: 映射文件路径
        """
        mapping_src = self.FILE_SRC.with_name(
            self.FILE_SRC.name.replace('InterfaceData.yaml', '_InterfaceData.yaml')
        )

        if mapping_src.exists():
            mapping_data = self.logicFunction_Object.raw_YamlTxt(str(mapping_src))

            # 删除已执行的数据
            pop_keys = [key for key in mapping_data.keys() if mapping_data[key].get('_RS') is True]
            for key in pop_keys:
                mapping_data.pop(key)

            # 源文件数据同步
            source_data = self.logicFunction_Object.raw_YamlTxt(str(self.FILE_SRC))
            for i_key in source_data.keys():
                if i_key in mapping_data:
                    mapping_data[i_key] = source_data[i_key]
            self.MAPPING_DATA = mapping_data
        else:
            self.MAPPING_DATA = self.logicFunction_Object.raw_YamlTxt(str(self.FILE_SRC))

        return mapping_src

    def _extractCacheData(self, data: Optional[Dict] = None, code_type: str = 'result') -> Dict:
        """提取接口缓存数据

        Args:
            data: 要处理的接口请求数据
            code_type: 数据类型 (cookie 或 result)

        Returns:
            Dict: 处理后的数据
        """
        cache_data = self.RESULT if code_type == 'result' else self.COOKIE
        eval_content = cache_data if cache_data else {}

        if not data:
            return eval_content.copy() if isinstance(eval_content, dict) else {}

        # 预处理数据
        processed_data = self.logicFunction_Object.beforehand(json.dumps(data, ensure_ascii=False))
        try:
            data = json.loads(processed_data)
        except json.JSONDecodeError:
            pass

        # 处理 cache 引用
        for key in data.keys():
            value = data[key]
            if isinstance(value, str) and 'cache' in value:
                # 安全地处理 cache 引用
                try:
                    # 解析 cache 引用路径，如 cache['key'] 或 cache.get('key')
                    data[key] = self._resolve_cache_reference(value, eval_content)
                except Exception as e:
                    INFO(f"解析缓存引用失败: {value}, 错误: {e}", "WARNING")
                    data[key] = value

        return data

    def _resolve_cache_reference(self, expression: str, cache_data: Dict) -> Any:
        """安全解析 cache 引用

        Args:
            expression: cache 引用表达式，如 "cache['key']" 或 "cache.get('key')"
            cache_data: 缓存数据字典

        Returns:
            解析后的值
        """
        # 匹配 cache['key'] 或 cache["key"]
        match = re_object.search(r"cache\[[\'\"](.+?)[\'\"]\]", expression)
        if match:
            key = match.group(1)
            return cache_data.get(key, expression)

        # 匹配 cache.get('key') 或 cache.get("key")
        match = re_object.search(r"cache\.get\([\'\"](.+?)[\'\"]\)", expression)
        if match:
            key = match.group(1)
            return cache_data.get(key, expression)

        # 匹配嵌套路径 cache['key1']['key2']
        matches = re_object.findall(r"\[[\'\"](.+?)[\'\"]\]", expression)
        if matches:
            result = cache_data
            for key in matches:
                if isinstance(result, dict):
                    result = result.get(key)
                else:
                    return expression
            return result

        return expression

    def _handleCallbackData(
        self,
        data_list: List,
        response: requests.Response,
        regular: Optional[str]
    ) -> Any:
        """处理接口回调数据

        Args:
            data_list: 需要缓存的数据列表
            response: requests 响应对象
            regular: 正则表达式

        Returns:
            处理后的回调数据
        """
        callback_data = None

        try:
            callback_data = response.json()
        except json.JSONDecodeError:
            if regular:
                callback_data = "".join(re_object.findall(regular, response.text))
            else:
                callback_data = response.text

        for item in data_list:
            if item == 'cookie':
                # 追加更新 Cookie
                cookies = requests.utils.dict_from_cookiejar(response.cookies)
                source_cookies = self._extractCacheData(code_type='cookie')
                source_cookies.update(cookies)
                self.COOKIE = source_cookies
            else:
                result = {}
                if isinstance(item, list) and len(item) >= 2:
                    # [key, regex] 格式
                    result[item[0]] = "".join(
                        re_object.findall(item[1], response.text.replace('\n', ''))
                    )
                else:
                    result[item] = callback_data

                source_result = self._extractCacheData(code_type='result')
                source_result.update(result)
                self.RESULT = source_result

        return callback_data

    def _callInterface(
        self,
        method: str,
        url: str,
        header: Optional[Dict] = None,
        data: Optional[Dict] = None,
        para: Optional[Dict] = None,
        file: Optional[Union[List, str]] = None,
        code: Optional[str] = None,
        cache: Optional[List] = None,
        re: Optional[str] = None
    ) -> Any:
        """接口调用封装

        Args:
            method: 请求类型 (GET, POST, PUT, DELETE等)
            url: 接口地址
            header: 请求头
            data: 请求参数 (不需要URL解码)
            para: 请求参数 (需要URL解码)
            file: 文件参数 [key, name, path, type]
            code: 请求参数编码
            cache: 需要缓存的回调数据列表
            re: 正则表达式筛选

        Returns:
            接口响应数据
        """
        cache = cache if cache is not None else []
        cookie = self._extractCacheData(code_type='cookie')

        # 处理 URL
        if not re_object.search(r'http[s]?://+', url):
            base_url = GSDSTORE.get('START', {}).get('url', '')
            url = f"{base_url}/{url}"

        if code:
            self.CODE = code
        if data:
            data = self._extractCacheData(data)
        if para:
            para = self._extractCacheData(para)

        # 处理文件上传
        files_data = None
        if file:
            processed_file = self.logicFunction_Object.beforehand(json.dumps(file, ensure_ascii=False))
            try:
                file_list = json.loads(processed_file)
            except json.JSONDecodeError:
                file_list = file

            if not isinstance(file_list[0], list):
                file_list = [file_list]

            files_data = {}
            for item in file_list:
                if len(item) >= 4:
                    key, name, src, file_type = item[:4]
                    files_data[key] = (name, open(src, 'rb'), file_type)

        # 发送请求
        response = requests.request(
            method=method.upper(),
            url=url,
            data=data,
            params=para,
            headers=header,
            files=files_data,
            cookies=cookie
        )

        return self._handleCallbackData(cache, response, re)

    def _readInterfaceData(self) -> bool:
        """读取并执行接口数据

        Returns:
            bool: 执行是否成功
        """
        pbar = tqdm([key for key in self.MAPPING_DATA.keys()])

        for key in pbar:
            pbar.set_description(f"\r 接口执行: {key}")

            interface_config = self.MAPPING_DATA[key].get('_RA', {})
            result = self._callInterface(**interface_config)

            if not self._resultComparison(key, self.MAPPING_DATA, result):
                return False

        return True

    def _resultComparison(
        self,
        interface_key: str,
        interface_data: Dict,
        result: Any
    ) -> bool:
        """接口响应结果比对

        Args:
            interface_key: 当前执行的接口 key
            interface_data: 接口映射数据
            result: 接口回调结果

        Returns:
            bool: 比对是否通过
        """
        outcome = False

        if '_RE' in interface_data[interface_key]:
            expect_result = interface_data[interface_key]['_RE']

            if isinstance(result, dict) and isinstance(expect_result, dict):
                # 字典比对
                for key in expect_result.keys():
                    if key in result and expect_result[key] == result[key]:
                        outcome = True
                    else:
                        outcome = False
                        break
            else:
                # 字符串包含比对
                outcome = self.logicFunction_Object.mutual_in(str(result), str(expect_result))

            if not outcome:
                INFO(f'接口执行终止 --- [{interface_key}] 响应结果出错:', "ERROR")
                INFO(f"实际: {result}", "ERROR")
                INFO(f"预期: {expect_result}", "ERROR")
                self._errorSave()
                return False
        else:
            outcome = True  # 无需断言

        # 更新运行状态
        interface_data[interface_key]['_RS'] = outcome
        return outcome
