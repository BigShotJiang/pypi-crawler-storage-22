"""KDTest-Playwright 关键字驱动测试框架

基于 Playwright 的关键字驱动测试框架，专为 Element Plus/Vue3 优化。
"""

from .product import __version__, __author__, __description__
from .reference import (
    GSTORE,
    GSDSTORE,
    MODULEDATA,
    PRIVATEDATA,
    CASESDATA,
    INFO,
    get_global,
    set_global,
    get_element_value,
    set_element_value,
    clear_element_values,
)
from .common import (
    DEFAULT_CONFIG,
    BROWSER_TYPES,
    LOCATOR_TYPES,
    KEY_MAP,
    PROJECTROOT,
)

__all__ = [
    # 版本信息
    '__version__',
    '__author__',
    '__description__',
    # 全局存储
    'GSTORE',
    'GSDSTORE',
    'MODULEDATA',
    'PRIVATEDATA',
    'CASESDATA',
    # 工具函数
    'INFO',
    'get_global',
    'set_global',
    'get_element_value',
    'set_element_value',
    'clear_element_values',
    # 常量
    'DEFAULT_CONFIG',
    'BROWSER_TYPES',
    'LOCATOR_TYPES',
    'KEY_MAP',
    'PROJECTROOT',
]
