# -*- coding: utf-8 -*-
"""kdtest_pw 包入口点 - 支持 python -m kdtest_pw 运行"""

from .cli.run import main

if __name__ == '__main__':
    main()
