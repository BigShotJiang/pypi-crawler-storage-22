"""CLI 入口 - 命令行运行测试"""

import argparse
import sys
import shutil
from pathlib import Path
from typing import Optional, List

from ..product import __version__
from ..core.browser_manager import BrowserManager
from ..core.config_loader import ConfigLoader
from ..action.key_retrieval import KeyRetrieval
from ..cases.case_collector import CaseCollector
from ..cases.case_executor import CaseExecutor
from ..cases.read.cell_handler import CellHandler
from ..plugins.plugin_loader import PluginLoader
from ..plugins.legacy_adapter import is_legacy_plugin
from ..reference import GSTORE, GSDSTORE, INFO
from ..utils.log.html_report import HtmlReporter


# ==================== 插件管理功能 ====================

def get_plugins_dir() -> Path:
    """获取插件目录（项目内置插件目录）"""
    # 使用项目的 plugins 目录
    plugins_dir = Path(__file__).parent.parent / "plugins"
    plugins_dir.mkdir(parents=True, exist_ok=True)
    return plugins_dir


def unit_new(plugin_name: str) -> int:
    """创建新插件模板

    Args:
        plugin_name: 插件名称

    Returns:
        int: 0 成功, 1 失败
    """
    plugins_dir = get_plugins_dir()
    plugin_dir = plugins_dir / plugin_name

    if plugin_dir.exists():
        print(f"错误: 插件目录已存在: {plugin_dir}")
        return 1

    # 创建目录结构 (与原版 kdtest 一致)
    plugin_dir.mkdir(parents=True)
    (plugin_dir / "elementData").mkdir()
    (plugin_dir / "utils").mkdir()

    # 创建 __init__.py
    init_content = f'''"""
{plugin_name} 插件包
"""
from .{plugin_name} import {plugin_name}

__all__ = ['{plugin_name}']
'''
    (plugin_dir / "__init__.py").write_text(init_content, encoding='utf-8')

    # 创建 my.ini (原版 kdtest 格式)
    ini_content = f'''[Information]
NAME = {plugin_name}
DETAILE = "{plugin_name} 插件描述"
STATE = finish
'''
    (plugin_dir / "my.ini").write_text(ini_content, encoding='utf-8')

    # 创建 {plugin_name}.py (原版 kdtest 主模块命名格式)
    module_content = f'''# -*- coding: utf-8 -*-
"""
{plugin_name} 插件主模块
"""


class {plugin_name}:
    """插件主类 - 类名需与 my.ini 中的 NAME 一致"""

    def __init__(self):
        self.page = None  # Playwright Page 实例将被自动注入
        self.driver = None  # 兼容原版 Selenium driver

    def example_keyword(self, content: str) -> str:
        """示例关键字方法

        Args:
            content: 输入内容

        Returns:
            str: 处理结果
        """
        # 在这里实现您的关键字逻辑
        print(f"[{{self.__class__.__name__}}] example_keyword: {{content}}")
        return content

    def click_element(self, targeting: str, element: str):
        """点击元素示例

        Args:
            targeting: 定位方式 (xpath, css, id等)
            element: 定位表达式
        """
        if self.page:
            if targeting == 'xpath':
                self.page.locator(f'xpath={{element}}').click()
            elif targeting == 'css':
                self.page.locator(element).click()
            else:
                self.page.locator(element).click()

    def input_text(self, targeting: str, element: str, content: str):
        """输入文本示例

        Args:
            targeting: 定位方式
            element: 定位表达式
            content: 输入内容
        """
        if self.page:
            if targeting == 'xpath':
                self.page.locator(f'xpath={{element}}').fill(content)
            else:
                self.page.locator(element).fill(content)
'''
    (plugin_dir / f"{plugin_name}.py").write_text(module_content, encoding='utf-8')

    # 创建 elementData/elementData.yaml
    yaml_content = f'''# {plugin_name} 元素数据
# 格式: 模块名/元素名: [定位方式, 定位表达式]

{plugin_name.lower()}:
  exampleButton:
    - xpath
    - //button[@id='example']
  exampleInput:
    - css
    - input.example-input
'''
    (plugin_dir / "elementData" / "elementData.yaml").write_text(yaml_content, encoding='utf-8')

    # 创建 elementData/modularInformation.json
    json_content = f'''{{
    "moduleName": "{plugin_name}",
    "description": "{plugin_name} 模块信息",
    "elements": {{}}
}}
'''
    (plugin_dir / "elementData" / "modularInformation.json").write_text(json_content, encoding='utf-8')

    # 创建 utils/__init__.py
    (plugin_dir / "utils" / "__init__.py").write_text('', encoding='utf-8')

    # 创建 utils/tool.py (示例工具文件)
    tool_content = f'''# -*- coding: utf-8 -*-
"""
{plugin_name} 辅助工具
"""


def helper_function(data):
    """示例辅助函数

    Args:
        data: 输入数据

    Returns:
        处理后的数据
    """
    return data
'''
    (plugin_dir / "utils" / "tool.py").write_text(tool_content, encoding='utf-8')

    print(f"[OK] 插件创建成功: {plugin_dir}")
    print(f"\n目录结构:")
    print(f"  {plugin_name}/")
    print(f"  |-- __init__.py")
    print(f"  |-- my.ini                   # 插件配置")
    print(f"  |-- {plugin_name}.py         # 插件主模块")
    print(f"  |-- elementData/")
    print(f"  |   |-- elementData.yaml     # 元素数据")
    print(f"  |   +-- modularInformation.json")
    print(f"  +-- utils/")
    print(f"      +-- tool.py              # 辅助工具")
    print(f"\n提示: 编辑 {plugin_name}.py 添加您的关键字方法")
    return 0


def unit_install(source_path: str) -> int:
    """安装插件

    Args:
        source_path: 插件源路径

    Returns:
        int: 0 成功, 1 失败
    """
    source = Path(source_path)
    if not source.exists():
        print(f"错误: 路径不存在: {source}")
        return 1

    if not source.is_dir():
        print(f"错误: 不是目录: {source}")
        return 1

    # 检查是否是有效插件
    ini_file = source / "my.ini"
    plugin_files = list(source.glob("*_plugin.py"))
    # 原版 kdtest 格式：my.ini + {NAME}.py
    # kdtest-pw 格式：*_plugin.py

    # 检查原版格式：有 my.ini 并且有同名 .py 文件
    has_legacy_format = ini_file.exists()
    # 检查新版格式：有 *_plugin.py 文件
    has_new_format = len(plugin_files) > 0

    if not (has_legacy_format or has_new_format):
        print(f"错误: 无效的插件目录")
        print(f"  - 原版格式需要: my.ini 文件")
        print(f"  - 新版格式需要: *_plugin.py 文件")
        return 1

    plugin_name = source.name
    plugins_dir = get_plugins_dir()
    target = plugins_dir / plugin_name

    if target.exists():
        print(f"警告: 插件已存在，将覆盖: {target}")
        shutil.rmtree(target)

    # 复制插件
    shutil.copytree(source, target)

    # 检测插件格式
    if is_legacy_plugin(target):
        print(f"[OK] 安装成功 (原版 kdtest 格式): {plugin_name}")
    else:
        print(f"[OK] 安装成功 (kdtest-pw 格式): {plugin_name}")

    print(f"  位置: {target}")
    return 0


def unit_uninstall(plugin_name: str) -> int:
    """卸载插件

    Args:
        plugin_name: 插件名称

    Returns:
        int: 0 成功, 1 失败
    """
    plugins_dir = get_plugins_dir()
    plugin_dir = plugins_dir / plugin_name

    if not plugin_dir.exists():
        print(f"错误: 插件不存在: {plugin_name}")
        print(f"  插件目录: {plugins_dir}")
        return 1

    shutil.rmtree(plugin_dir)
    print(f"[OK] 卸载成功: {plugin_name}")
    return 0


def unit_show() -> int:
    """显示已安装的插件

    Returns:
        int: 0 成功
    """
    import configparser

    plugins_dir = get_plugins_dir()
    print(f"插件目录: {plugins_dir}\n")

    plugins = []
    for item in plugins_dir.iterdir():
        if item.is_dir() and not item.name.startswith('_'):
            plugin_info = {
                'name': item.name,
                'path': item,
                'format': 'unknown',
                'description': '',
                'state': 'unknown',
            }

            # 检查格式并读取信息
            ini_file = item / "my.ini"
            if ini_file.exists():
                config = configparser.ConfigParser()
                try:
                    config.read(str(ini_file), encoding='utf-8')
                except:
                    try:
                        config.read(str(ini_file), encoding='gbk')
                    except:
                        pass

                if 'Information' in config.sections():
                    # 原版 kdtest 格式
                    plugin_info['format'] = 'legacy (kdtest)'
                    plugin_info['name'] = config.get('Information', 'NAME', fallback=item.name)
                    plugin_info['description'] = config.get('Information', 'DETAILE', fallback='').strip('"')
                    plugin_info['state'] = config.get('Information', 'STATE', fallback='finish').strip('"')
                elif 'plugin' in config.sections():
                    # kdtest-pw 新格式
                    plugin_info['format'] = 'kdtest-pw'
                    plugin_info['name'] = config.get('plugin', 'name', fallback=item.name)
                    plugin_info['description'] = config.get('plugin', 'description', fallback='')
                    plugin_info['state'] = 'enabled'

            # 检查是否有 *_plugin.py 文件
            if list(item.glob("*_plugin.py")):
                plugin_info['format'] = 'kdtest-pw'

            plugins.append(plugin_info)

    if not plugins:
        print("未安装任何插件")
        print(f"\n提示: 使用 --unit_new <名称> 创建新插件")
        return 0

    print(f"已安装 {len(plugins)} 个插件:\n")
    print(f"{'名称':<20} {'格式':<15} {'状态':<10} 描述")
    print("-" * 70)

    for p in plugins:
        state_icon = "[OK]" if p['state'] in ('finish', 'enabled') else "[X]" if p['state'] == 'disabled' else "?"
        desc = p['description'][:30] + "..." if len(p['description']) > 30 else p['description']
        print(f"{p['name']:<20} {p['format']:<15} {state_icon:<10} {desc}")

    print(f"\n提示:")
    print(f"  --unit_install <路径>   安装插件")
    print(f"  --unit_uninstall <名称> 卸载插件")
    return 0


class KDTestRunner:
    """KDTest Playwright 测试运行器"""

    def __init__(self, config_path: Optional[str] = None):
        """初始化运行器

        Args:
            config_path: 配置文件路径
        """
        self._config_loader: Optional[ConfigLoader] = None
        self._browser_manager: Optional[BrowserManager] = None
        self._key_retrieval: Optional[KeyRetrieval] = None
        self._plugin_loader: Optional[PluginLoader] = None
        self._case_collector: Optional[CaseCollector] = None
        self._case_executor: Optional[CaseExecutor] = None
        self._reporter: Optional[HtmlReporter] = None

        if config_path:
            self.load_config(config_path)

    def load_config(self, config_path: str) -> None:
        """加载配置文件

        Args:
            config_path: 配置文件路径
        """
        self._config_loader = ConfigLoader(config_path)
        INFO(f"配置已加载: {config_path}")

    def setup(self) -> None:
        """初始化测试环境"""
        if not self._config_loader:
            raise RuntimeError("请先加载配置文件")

        config = self._config_loader.config

        # 初始化浏览器管理器
        self._browser_manager = BrowserManager()

        # 启动浏览器
        page = self._browser_manager.launch(
            browser_type=self._config_loader.browser,
            headless=self._config_loader.headless,
            slow_mo=self._config_loader.slow_mo,
            trace=self._config_loader.trace,
            video=self._config_loader.video,
            timeout=self._config_loader.timeout,
        )

        # 初始化关键字分发器
        self._key_retrieval = KeyRetrieval(page)

        # 初始化插件加载器（自动加载 plugins 目录下的所有插件）
        self._plugin_loader = PluginLoader(page)
        self._plugin_loader.load_builtin_plugins()

        # 合并插件关键字和元素数据
        self._key_retrieval.register_plugin_keywords(
            self._plugin_loader.get_all_keywords()
        )

        # 加载插件元素数据
        element_data = self._plugin_loader.get_all_element_data()

        # 自动加载测试用例目录中的 elementData.yaml 文件
        case_element_data = self._load_case_element_data()
        element_data.update(case_element_data)

        self._key_retrieval.set_element_data(element_data)

        # 初始化单元格处理器
        cell_handler = CellHandler(
            self._config_loader.self_defined_parameters
        )

        # 初始化用例执行器
        self._case_executor = CaseExecutor(
            key_retrieval=self._key_retrieval,
            cell_handler=cell_handler,
            retry_count=self._config_loader.retry_count if self._config_loader.retry_switch else 0,
            screenshot_on_fail=True,
        )

        # 初始化用例收集器
        self._case_collector = CaseCollector(config)

        # 初始化报告生成器
        self._reporter = HtmlReporter()

        # 导航到起始 URL
        if self._config_loader.url:
            page.goto(self._config_loader.url)

        INFO("测试环境初始化完成")

    def _load_case_element_data(self) -> dict:
        """从测试用例目录加载 elementData.yaml 文件

        自动发现与测试用例 Excel 文件同目录的 elementData.yaml 并加载。

        Returns:
            dict: 合并后的元素数据字典
        """
        import yaml

        element_data = {}
        loaded_paths = set()

        # 遍历配置中的测试用例文件
        for case_file in self._config_loader.test_case_files:
            case_path = Path(case_file.get('caseFilePath', ''))

            # 获取用例文件所在目录
            if case_path.is_absolute():
                case_dir = case_path.parent
            else:
                # 相对路径，基于配置文件目录
                config_dir = Path(GSDSTORE['WORKPATH'].get('config_dir', '.'))
                case_dir = (config_dir / case_path).parent

            # 查找该目录下的 elementData.yaml
            element_file = case_dir / 'elementData.yaml'
            if not element_file.exists():
                element_file = case_dir / 'elementData.yml'

            if element_file.exists() and str(element_file) not in loaded_paths:
                try:
                    with open(element_file, 'r', encoding='utf-8') as f:
                        data = yaml.safe_load(f) or {}
                        element_data.update(data)
                        loaded_paths.add(str(element_file))
                        INFO(f"加载元素数据: {element_file}")
                except Exception as e:
                    INFO(f"加载元素数据失败: {element_file} - {e}", "WARNING")

        # 也尝试从 casesAggregate 目录递归加载所有 elementData.yaml
        config_dir = Path(GSDSTORE['WORKPATH'].get('config_dir', '.'))
        cases_aggregate_dir = config_dir / 'casesAggregate'

        if cases_aggregate_dir.exists():
            for element_file in cases_aggregate_dir.rglob('elementData.yaml'):
                if str(element_file) not in loaded_paths:
                    try:
                        with open(element_file, 'r', encoding='utf-8') as f:
                            data = yaml.safe_load(f) or {}
                            element_data.update(data)
                            loaded_paths.add(str(element_file))
                            INFO(f"加载元素数据: {element_file}")
                    except Exception as e:
                        INFO(f"加载元素数据失败: {element_file} - {e}", "WARNING")

            for element_file in cases_aggregate_dir.rglob('elementData.yml'):
                if str(element_file) not in loaded_paths:
                    try:
                        with open(element_file, 'r', encoding='utf-8') as f:
                            data = yaml.safe_load(f) or {}
                            element_data.update(data)
                            loaded_paths.add(str(element_file))
                            INFO(f"加载元素数据: {element_file}")
                    except Exception as e:
                        INFO(f"加载元素数据失败: {element_file} - {e}", "WARNING")

        return element_data

    def run(
        self,
        include_sheets: List[str] = None,
        exclude_sheets: List[str] = None,
        case_ids: List[str] = None,
        case_pattern: str = None,
    ) -> dict:
        """运行测试

        Args:
            include_sheets: 只执行这些 Sheet
            exclude_sheets: 排除这些 Sheet
            case_ids: 只执行这些用例 ID
            case_pattern: 用例名称匹配模式

        Returns:
            dict: 执行摘要
        """
        # 收集用例
        all_cases = self._case_collector.collect()

        # 过滤用例
        cases = self._case_collector.filter_cases(
            include_sheets=include_sheets,
            exclude_sheets=exclude_sheets,
            include_ids=case_ids,
            name_pattern=case_pattern,
        )

        INFO(f"过滤后用例数: {len(cases)}")

        # 执行用例
        results = self._case_executor.execute_cases(cases)

        # 生成报告
        if self._reporter:
            report_path = self._reporter.generate(results)
            INFO(f"测试报告: {report_path}")

        return self._case_executor.summary

    def teardown(self, save_trace: str = None) -> None:
        """清理测试环境

        Args:
            save_trace: trace 文件保存路径
        """
        # 卸载插件
        if self._plugin_loader:
            self._plugin_loader.unload_all()

        # 关闭浏览器
        if self._browser_manager:
            trace_path = save_trace or (
                'result/trace/trace.zip' if self._config_loader and self._config_loader.trace else None
            )
            self._browser_manager.close(save_trace=trace_path)

        INFO("测试环境已清理")

    def __enter__(self) -> 'KDTestRunner':
        self.setup()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.teardown()


def parse_args() -> argparse.Namespace:
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        prog='kdtest-pw',
        description='KDTest Playwright - 关键字驱动测试框架',
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version=f'kdtest-pw {__version__}'
    )

    parser.add_argument(
        '-c', '--config',
        type=str,
        default='parameters.json',
        help='配置文件路径 (默认: parameters.json)'
    )

    parser.add_argument(
        '-s', '--sheets',
        type=str,
        nargs='+',
        help='只执行指定的 Sheet'
    )

    parser.add_argument(
        '-x', '--exclude',
        type=str,
        nargs='+',
        help='排除指定的 Sheet'
    )

    parser.add_argument(
        '-i', '--ids',
        type=str,
        nargs='+',
        help='只执行指定的用例 ID'
    )

    parser.add_argument(
        '-p', '--pattern',
        type=str,
        help='用例名称匹配模式 (支持通配符)'
    )

    parser.add_argument(
        '--browser',
        type=str,
        choices=['chromium', 'firefox', 'webkit'],
        help='覆盖配置中的浏览器类型'
    )

    parser.add_argument(
        '--headless',
        action='store_true',
        help='无头模式运行'
    )

    parser.add_argument(
        '--trace',
        action='store_true',
        help='开启 trace 录制'
    )

    parser.add_argument(
        '--video',
        action='store_true',
        help='开启视频录制'
    )

    parser.add_argument(
        '--slow-mo',
        type=int,
        help='操作延迟 (毫秒)'
    )

    # ==================== 插件管理参数 ====================
    plugin_group = parser.add_argument_group('插件管理')

    plugin_group.add_argument(
        '--unit_new',
        type=str,
        metavar='NAME',
        help='创建新插件模板'
    )

    plugin_group.add_argument(
        '--unit_install',
        type=str,
        metavar='PATH',
        help='安装插件 (从指定路径)'
    )

    plugin_group.add_argument(
        '--unit_uninstall',
        type=str,
        metavar='NAME',
        help='卸载插件'
    )

    plugin_group.add_argument(
        '--unit_show',
        action='store_true',
        help='显示已安装的插件'
    )

    plugin_group.add_argument(
        '--plugins_dir',
        type=str,
        help='自定义插件目录路径'
    )

    return parser.parse_args()


def main() -> int:
    """主入口函数"""
    args = parse_args()

    # ==================== 插件管理命令 ====================
    # 这些命令独立于测试运行，直接返回

    if args.unit_new:
        return unit_new(args.unit_new)

    if args.unit_install:
        return unit_install(args.unit_install)

    if args.unit_uninstall:
        return unit_uninstall(args.unit_uninstall)

    if args.unit_show:
        return unit_show()

    # ==================== 测试运行 ====================

    # 检查配置文件
    config_path = Path(args.config)
    if not config_path.exists():
        print(f"错误: 配置文件不存在: {config_path}")
        return 1

    runner = KDTestRunner(str(config_path))

    # 覆盖配置
    if args.browser:
        runner._config_loader.set('browser', args.browser)
    if args.headless:
        runner._config_loader.set('headless', True)
    if args.trace:
        runner._config_loader.set('trace', True)
    if args.video:
        runner._config_loader.set('video', True)
    if args.slow_mo:
        runner._config_loader.set('slowMo', args.slow_mo)

    try:
        runner.setup()
        summary = runner.run(
            include_sheets=args.sheets,
            exclude_sheets=args.exclude,
            case_ids=args.ids,
            case_pattern=args.pattern,
        )

        # 输出摘要
        print("\n" + "=" * 50)
        print("测试执行摘要")
        print("=" * 50)
        print(f"总用例数: {summary['total']}")
        print(f"通过: {summary['passed']}")
        print(f"失败: {summary['failed']}")
        print(f"跳过: {summary['skipped']}")
        print(f"通过率: {summary['pass_rate']:.1f}%")
        print(f"执行时间: {summary['duration']:.2f}s")
        print("=" * 50)

        return 0 if summary['failed'] == 0 else 1

    except KeyboardInterrupt:
        print("\n测试被中断")
        return 130
    except Exception as e:
        print(f"执行错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    finally:
        runner.teardown()


if __name__ == '__main__':
    sys.exit(main())
