"""常量和数据存储模块"""

from typing import Dict, Any, List
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent

# 兼容原版 kdtest 的 PROJECTROOT 变量名
PROJECTROOT = str(PROJECT_ROOT)

# 默认配置
DEFAULT_CONFIG: Dict[str, Any] = {
    'browser': 'chromium',
    'headless': False,
    'slowMo': 0,
    'timeout': 30000,
    'trace': False,
    'video': False,
    'retrySwitch': False,
    'retryCount': 1,
    'parallel': False,
}

# 支持的浏览器类型
BROWSER_TYPES: List[str] = ['chromium', 'firefox', 'webkit']

# 定位器类型映射
LOCATOR_TYPES: Dict[str, str] = {
    'id': 'id',
    'name': 'name',
    'class': 'class_name',
    'class_name': 'class_name',
    'className': 'class_name',
    'css': 'css',
    'css_selector': 'css',
    'css_selectors': 'css',
    'xpath': 'xpath',
    'xpaths': 'xpath',
    'text': 'text',
    'role': 'role',
    'data_testid': 'data_testid',
    'placeholder': 'placeholder',
    'link_text': 'text',
    'linkText': 'text',
    'partial_link_text': 'text',
    'partialLinkText': 'text',
    # JavaScript DOM 定位类型（兼容原版 kdtest）
    'document.getElementById': 'js_id',
    'document.getElementsByClassName': 'js_class',
    'document.getElementsByName': 'js_name',
    'document.querySelector': 'js_css',
    'document.querySelectorAll': 'js_css',
}

# 键盘键映射 (Selenium Keys -> Playwright)
KEY_MAP: Dict[str, str] = {
    'Keys.ENTER': 'Enter',
    'Keys.TAB': 'Tab',
    'Keys.BACK_SPACE': 'Backspace',
    'Keys.BACKSPACE': 'Backspace',
    'Keys.ESCAPE': 'Escape',
    'Keys.DELETE': 'Delete',
    'Keys.ARROW_UP': 'ArrowUp',
    'Keys.ARROW_DOWN': 'ArrowDown',
    'Keys.ARROW_LEFT': 'ArrowLeft',
    'Keys.ARROW_RIGHT': 'ArrowRight',
    'Keys.HOME': 'Home',
    'Keys.END': 'End',
    'Keys.PAGE_UP': 'PageUp',
    'Keys.PAGE_DOWN': 'PageDown',
    'Keys.SPACE': 'Space',
    'Keys.CONTROL': 'Control',
    'Keys.ALT': 'Alt',
    'Keys.SHIFT': 'Shift',
    'Keys.F1': 'F1',
    'Keys.F2': 'F2',
    'Keys.F3': 'F3',
    'Keys.F4': 'F4',
    'Keys.F5': 'F5',
    'Keys.F6': 'F6',
    'Keys.F7': 'F7',
    'Keys.F8': 'F8',
    'Keys.F9': 'F9',
    'Keys.F10': 'F10',
    'Keys.F11': 'F11',
    'Keys.F12': 'F12',
    # 组合键
    'Keys.CONTROL+a': 'Control+a',
    'Keys.CONTROL+c': 'Control+c',
    'Keys.CONTROL+v': 'Control+v',
    'Keys.CONTROL+x': 'Control+x',
    'Keys.CONTROL+z': 'Control+z',
    'Keys.CONTROL+s': 'Control+s',
}

# 断言模式
ASSERT_MODES: List[str] = ['equals', 'contains', 'regex', 'gt', 'lt', 'gte', 'lte']

# 元素等待状态
WAIT_STATES: List[str] = ['visible', 'hidden', 'attached', 'detached']

# 结果目录
RESULT_DIRS: Dict[str, str] = {
    'report': 'result/report',
    'log': 'result/log',
    'trace': 'result/trace',
    'video': 'result/video',
    'screenshot': 'result/screenshot',
}

# Excel列映射
EXCEL_COLUMNS: Dict[str, int] = {
    'case_id': 0,       # A列 - 用例ID
    'case_name': 1,     # B列 - 用例名称
    'description': 2,   # C列 - 步骤描述
    'keyword': 3,       # D列 - 关键字
    'locator_start': 4, # E列开始 - 定位信息
    'locator_end': 13,  # N列结束 - 定位信息
    'value': 14,        # O列 - 操作值
}
