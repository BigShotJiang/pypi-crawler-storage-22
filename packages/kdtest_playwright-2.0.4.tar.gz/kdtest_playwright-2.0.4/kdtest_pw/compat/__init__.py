"""kdtest 兼容层

提供原版 kdtest 的接口兼容，使旧插件可以在 kdtest-pw 中运行。
"""

from .kdtest_compat import *
