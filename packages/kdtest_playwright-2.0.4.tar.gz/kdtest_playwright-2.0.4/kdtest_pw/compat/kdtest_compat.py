"""kdtest 兼容模块

模拟原版 kdtest 的接口，使旧插件可以在 kdtest-pw 中运行。
这个模块会被注册为 'kdtest' 以兼容 `from kdtest import ...` 语句。
"""

import sys
from typing import Any, Dict

# 导入 kdtest-pw 的全局存储
from ..reference import (
    GSTORE, GSDSTORE, MODULEDATA, PRIVATEDATA, CASESDATA, INFO,
    setup_file_logging, set_log_level
)

# 兼容原版的函数
def reset_implicitlyWait(timeout: int = 10):
    """兼容原版的隐式等待重置函数

    在 Playwright 中，这个函数主要用于设置默认超时。
    可以作为普通函数调用，也可以作为装饰器使用。

    用法:
        reset_implicitlyWait(10)  # 普通调用

        @reset_implicitlyWait(1)  # 装饰器用法
        def some_method(self):
            pass
    """
    def decorator(func):
        """装饰器：在函数执行前重置等待时间"""
        def wrapper(*args, **kwargs):
            page = GSTORE.get('page')
            if page:
                page.set_default_timeout(timeout * 1000)
            return func(*args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    # 检查是否作为普通函数调用（无参数或参数是数字）
    if callable(timeout):
        # reset_implicitlyWait(func) - 作为无参装饰器
        func = timeout
        timeout = 10
        return decorator(func)

    # reset_implicitlyWait(10) 或 @reset_implicitlyWait(10)
    # 返回装饰器
    return decorator


def set_implicitlyWait(timeout: int = 10):
    """设置隐式等待（兼容）"""
    page = GSTORE.get('page')
    if page:
        page.set_default_timeout(timeout * 1000)


# 导出所有兼容接口
__all__ = [
    'GSTORE',
    'GSDSTORE',
    'MODULEDATA',
    'PRIVATEDATA',
    'CASESDATA',
    'INFO',
    'reset_implicitlyWait',
    'set_implicitlyWait',
    'setup_file_logging',
    'set_log_level',
]


def register_kdtest_module():
    """将此模块注册为 'kdtest'，使 `from kdtest import ...` 可以工作"""
    # 创建一个模块对象
    import types
    kdtest_module = types.ModuleType('kdtest')
    kdtest_module.GSTORE = GSTORE
    kdtest_module.GSDSTORE = GSDSTORE
    kdtest_module.MODULEDATA = MODULEDATA
    kdtest_module.PRIVATEDATA = PRIVATEDATA
    kdtest_module.CASESDATA = CASESDATA
    kdtest_module.INFO = INFO
    kdtest_module.reset_implicitlyWait = reset_implicitlyWait
    kdtest_module.set_implicitlyWait = set_implicitlyWait
    kdtest_module.setup_file_logging = setup_file_logging
    kdtest_module.set_log_level = set_log_level

    # 注册到 sys.modules
    sys.modules['kdtest'] = kdtest_module

    return kdtest_module


# 自动注册
register_kdtest_module()
