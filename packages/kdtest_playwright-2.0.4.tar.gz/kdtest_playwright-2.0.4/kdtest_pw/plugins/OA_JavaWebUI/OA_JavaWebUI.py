# -*- coding: utf-8 -*-
'''
OA_JavaWebUI 插件 - Playwright 版本
公共UI操作方法库，支持验证码识别、人员选择、菜单导航等功能
完整兼容原版 kdtest Selenium 插件的所有方法
'''
from kdtest_pw import GSTORE, INFO
from kdtest_pw.compat.kdtest_compat import reset_implicitlyWait
import re
import os
import time
from typing import Optional, List, Dict, Any, Union

# 延迟导入 ddddocr（可能未安装）
try:
    import ddddocr
    HAS_DDDDOCR = True
except ImportError:
    HAS_DDDDOCR = False


class OA_JavaWebUI:
    """公共UI操作方法库 - Playwright版本（完整兼容原版）"""

    def __repr__(self) -> str:
        return '公共UI操作方法库 (Playwright)'

    def __init__(self) -> None:
        self.__CDCG = {}  # 全局数据缓存
        self.page = None  # Playwright Page 实例，由框架注入
        self.ocr = None   # OCR 引擎实例
        self._current_frame = None  # 当前 frame 上下文

        # 读取元素数据配置
        from .utils.tool import isToolClass
        self.__logicFunction_Object = isToolClass()

        element_data_path = os.path.join(os.path.dirname(__file__), 'elementData', 'elementData.yaml')
        self.__elementNode_Data = self.__logicFunction_Object.raw_YamlTxt(element_data_path) or {}

        # 读取并解析 JSON 菜单配置
        modular_info_path = os.path.join(os.path.dirname(__file__), 'elementData', 'modularInformation.json')
        try:
            import json
            with open(modular_info_path, 'r', encoding='utf-8') as f:
                self.__ModularNode_Information = json.load(f)
        except Exception as e:
            INFO(f"加载菜单配置失败: {e}", "WARNING")
            self.__ModularNode_Information = {}

        # 初始化 OCR 引擎
        if HAS_DDDDOCR:
            try:
                self.ocr = ddddocr.DdddOcr(show_ad=False)
            except Exception as e:
                INFO(f"ddddocr 初始化失败: {e}", "WARNING")

    def _get_page(self):
        """获取当前 page 实例"""
        if self.page:
            return self.page
        return GSTORE.get('page')

    def _get_keyword(self):
        """获取关键字对象"""
        return GSTORE.get('keyWord')

    def _locator(self, targeting: str, element: str):
        """统一定位器方法"""
        page = self._get_page()
        base = self._current_frame if self._current_frame else page

        if targeting in ['xpath', 'xpaths']:
            return base.locator(f'xpath={element}')
        elif targeting in ['css', 'css_selector', 'css_selectors']:
            return base.locator(element)
        elif targeting == 'id':
            return base.locator(f'#{element}')
        elif targeting == 'name':
            return base.locator(f'[name="{element}"]')
        elif targeting in ['class_name', 'class_names']:
            return base.locator(f'.{element}')
        elif targeting in ['tag_name', 'tag_names']:
            return base.locator(element)
        elif targeting == 'text':
            return base.get_by_text(element)
        else:
            return base.locator(element)

    # ==================== 验证码相关 ====================

    def getCaptchaImg(self) -> str:
        """
        获取并识别验证码图片

        Returns:
            str: 识别出的验证码文本
        """
        if not HAS_DDDDOCR or not self.ocr:
            INFO("ddddocr 未安装或初始化失败，无法识别验证码", "ERROR")
            return ""

        page = self._get_page()

        # 创建验证码保存目录
        captcha_folder = os.path.join(os.getcwd(), 'captcha_folder')
        if not os.path.exists(captcha_folder):
            os.makedirs(captcha_folder)

        try:
            # 获取验证码图片元素定位信息
            captcha_info = self.__elementNode_Data.get('login', {}).get('captcha_image')
            if not captcha_info:
                INFO("elementData.yaml 中未配置 login.captcha_image", "ERROR")
                return ""
            targeting, element = captcha_info[0], captcha_info[1]

            # 定位验证码图片
            captcha_image = self._locator(targeting, element)
            captcha_image.wait_for(state='visible', timeout=10000)

            # 截取验证码图片
            captcha_image_path = os.path.join(captcha_folder, 'captcha.png')
            captcha_image.screenshot(path=captcha_image_path)

            # 读取并识别验证码
            with open(captcha_image_path, 'rb') as f:
                img = f.read()

            result = self.ocr.classification(img)
            INFO(f"验证码识别结果: {result}")
            return result

        except Exception as error:
            INFO(f"验证码识别失败: {error}", "ERROR")
            return ""

    def inputCaptcha(self):
        """
        识别并输入验证码

        在 Excel 中使用: [OA_JavaWebUI]inputCaptcha
        """
        page = self._get_page()
        result = self.getCaptchaImg()

        if not result:
            INFO("验证码识别失败，跳过输入", "WARNING")
            return

        try:
            captcha_input_info = self.__elementNode_Data.get('login', {}).get('captcha_input')
            if not captcha_input_info:
                INFO("elementData.yaml 中未配置 login.captcha_input", "ERROR")
                return
            targeting, element = captcha_input_info[0], captcha_input_info[1]

            captcha_input = self._locator(targeting, element)
            captcha_input.fill('')
            captcha_input.fill(result)
            INFO(f"已输入验证码: {result}")

        except Exception as error:
            INFO(f"验证码输入失败: {error}", "ERROR")

    def inputCaptchaWithRetry(self, max_retries: int = 5) -> bool:
        """
        带重试机制的验证码输入

        Args:
            max_retries: 最大重试次数

        在 Excel 中使用: [OA_JavaWebUI]inputCaptchaWithRetry | | | 5
        """
        page = self._get_page()

        for attempt in range(max_retries):
            self.inputCaptcha()
            page.wait_for_timeout(1000)

            try:
                error_msg = page.locator("xpath=//div[contains(@class,'el-message')]//p")
                error_msg.wait_for(state='visible', timeout=3000)

                if error_msg.is_visible():
                    INFO(f"第{attempt + 1}次验证码错误，重试...")

                    # 点击验证码图片刷新
                    captcha_info = self.__elementNode_Data.get('login', {}).get('captcha_image')
                    if captcha_info:
                        self._locator(captcha_info[0], captcha_info[1]).click()
                    page.wait_for_timeout(1000)
                    continue
            except:
                INFO("验证码输入成功")
                return True

        INFO(f"验证码重试{max_retries}次仍失败", "ERROR")
        return False

    # ==================== 用户登录相关 ====================

    def userLogin(self, userName: str = None, userPassword: str = None):
        """
        用户登录（含验证码自动识别）

        Args:
            userName: 用户名
            userPassword: 密码

        在 Excel 中使用: [OA_JavaWebUI]userLogin | | | 用户名,密码
        """
        page = self._get_page()
        KEYWORD = self._get_keyword()

        try:
            if userName:
                user_info = self.__elementNode_Data.get('login', {}).get('userName')
                if not user_info:
                    INFO("elementData.yaml 中未配置 login.userName", "ERROR")
                    return
                # 先清空再输入
                user_input = self._locator(user_info[0], user_info[1])
                user_input.fill('')
                user_input.fill(userName)

            if userPassword:
                pwd_info = self.__elementNode_Data.get('login', {}).get('password')
                if not pwd_info:
                    INFO("elementData.yaml 中未配置 login.password", "ERROR")
                    return
                pwd_input = self._locator(pwd_info[0], pwd_info[1])
                pwd_input.fill('')
                pwd_input.fill(userPassword)

            # 输入验证码
            self.inputCaptcha()
            page.wait_for_timeout(1000)

            # 点击登录按钮
            submit_info = self.__elementNode_Data.get('login', {}).get('submit')
            if not submit_info:
                INFO("elementData.yaml 中未配置 login.submit", "ERROR")
                return
            self._locator(submit_info[0], submit_info[1]).click()

        except Exception as error:
            INFO(f"登录失败: {error}", "ERROR")

    def userLogout(self):
        """
        用户注销

        在 Excel 中使用: [OA_JavaWebUI]userLogout
        """
        page = self._get_page()
        self.frame_default()  # 先返回主文档

        try:
            avatar_info = self.__elementNode_Data.get('logout', {}).get('logout_avater')
            if not avatar_info:
                INFO("elementData.yaml 中未配置 logout.logout_avater", "ERROR")
                return
            self._locator(avatar_info[0], avatar_info[1]).hover()
            page.wait_for_timeout(500)

            btn_info = self.__elementNode_Data.get('logout', {}).get('logout_btn')
            if not btn_info:
                INFO("elementData.yaml 中未配置 logout.logout_btn", "ERROR")
                return
            self._locator(btn_info[0], btn_info[1]).click()

            # 处理可能的确认弹窗
            self.errorHandle(True)

        except Exception as error:
            INFO(f"注销失败: {error}", "ERROR")

    def adminConsole(self):
        """
        切换管理后台

        在 Excel 中使用: [OA_JavaWebUI]adminConsole
        """
        page = self._get_page()

        try:
            # 鼠标移动到用户名
            uname_info = self.__elementNode_Data.get('aConsole', {}).get('Uname')
            if not uname_info:
                INFO("elementData.yaml 中未配置 aConsole.Uname", "ERROR")
                return
            self._locator(uname_info[0], uname_info[1]).hover()
            page.wait_for_timeout(500)

            # 点击系统后台
            panel_info = self.__elementNode_Data.get('aConsole', {}).get('panel')
            if not panel_info:
                INFO("elementData.yaml 中未配置 aConsole.panel", "ERROR")
                return
            self._locator(panel_info[0], panel_info[1]).click()

        except Exception as error:
            INFO(f"切换管理后台失败: {error}", "ERROR")

    # ==================== Frame 操作 ====================

    def jumpFrame(self, Hierarchy: List):
        """
        frame 跳转封装

        Args:
            Hierarchy: [层级数, [frame标识列表]]
                frame标识可以是: 标签ID、标签索引、标签src属性值

        示例:
            jumpFrame([1, ['main']])  # 跳转到 id='main' 的 iframe
            jumpFrame([2, ['main', 'content']])  # 多层嵌套

        在 Excel 中使用: [OA_JavaWebUI]jumpFrame | | | [1,['main']]
        """
        page = self._get_page()
        self.frame_default()  # 先返回主文档

        operFrameList = Hierarchy[1] if len(Hierarchy) > 1 else Hierarchy

        for item in operFrameList:
            try:
                # 尝试作为索引
                frame_index = int(item)
                frames = page.frames
                if frame_index < len(frames):
                    self._current_frame = page.frame_locator(f'iframe >> nth={frame_index}')
            except (ValueError, TypeError):
                # 不是索引，尝试其他方式
                if re.search(r'[http\[s\]?://]?([/]|[\\]|[a-zA-Z0-9]\.[a-zA-Z])+', str(item)):
                    # src 属性匹配
                    self._current_frame = page.frame_locator(f'iframe[src*="{item}"]')
                else:
                    # ID 或 name 匹配
                    self._current_frame = page.frame_locator(f'iframe#{item}, iframe[name="{item}"]')

    def frame_default(self):
        """
        返回主文档

        在 Excel 中使用: [OA_JavaWebUI]frame_default
        """
        self._current_frame = None

    def switch_frame(self, frame_locator: str):
        """
        切换到指定 frame

        Args:
            frame_locator: frame 定位表达式

        在 Excel 中使用: [OA_JavaWebUI]switch_frame | | | #main-iframe
        """
        page = self._get_page()
        self._current_frame = page.frame_locator(frame_locator)

    # ==================== 错误/弹窗处理 ====================

    def errorHandle(self, accept: bool = False, prompt_input: str = None) -> Optional[str]:
        """
        错误处理封装 - 处理 alert/系统提示/右上角弹框

        Args:
            accept: True 点击确定，False 点击取消
            prompt_input: prompt 弹框输入内容

        Returns:
            str: 提示信息文本

        在 Excel 中使用: [OA_JavaWebUI]errorHandle | | | true
        """
        page = self._get_page()
        return_info = None

        # 1. 处理 JavaScript alert/confirm/prompt
        try:
            # 设置 dialog 处理器
            def handle_dialog(dialog):
                nonlocal return_info
                return_info = dialog.message
                if prompt_input:
                    dialog.accept(prompt_input)
                elif accept:
                    dialog.accept()
                else:
                    dialog.dismiss()

            page.once('dialog', handle_dialog)
            page.wait_for_timeout(500)

            if return_info:
                INFO(f'Alert提示: {return_info}')
                return return_info
        except:
            pass

        # 2. 处理系统提示信息弹框
        try:
            tips_selector = self.__elementNode_Data.get('error', {}).get('TIPS')
            if tips_selector:
                tips_ele = page.locator(tips_selector)

                # 使用 wait_for 替代 is_visible(timeout=...)
                tips_ele.wait_for(state='visible', timeout=1000)
                if tips_ele.is_visible():
                    return_info = tips_ele.text_content()

                    # 点击确定或取消按钮
                    el_btns_primary = self.__elementNode_Data.get('elMessageBox', {}).get('btns_primary', '.el-message-box__btns .el-button--primary')
                    el_btns = self.__elementNode_Data.get('elMessageBox', {}).get('btns', '.el-message-box__btns .el-button')
                    if accept:
                        tips_ele.locator(el_btns_primary).click()
                    else:
                        tips_ele.locator(el_btns + ':not(.el-button--primary)').first.click()

                    INFO(f'系统提示: {return_info}')
                    return return_info
        except:
            pass

        # 3. 处理右上角消息弹框 (el-message)
        try:
            bounced_selector = self.__elementNode_Data.get('error', {}).get('BOUNCED')
            if bounced_selector:
                bounced = page.locator(bounced_selector)

                # 使用 wait_for 替代 is_visible(timeout=...)
                bounced.first.wait_for(state='visible', timeout=1000)
                if bounced.first.is_visible():
                    return_info = bounced.first.text_content()
                    # 等待自动消失或点击关闭
                    try:
                        close_btn = self.__elementNode_Data.get('elMessage', {}).get('close_btn', '.el-message__closeBtn')
                        bounced.first.locator(close_btn).click()
                    except:
                        pass
                    INFO(f'消息提示: {return_info}')
                    return return_info
        except:
            pass

        return return_info

    def WeakHint(self) -> Optional[str]:
        """
        文本弱提示处理

        Returns:
            str: 弱提示文本

        在 Excel 中使用: [OA_JavaWebUI]WeakHint
        """
        page = self._get_page()

        try:
            weak_selector = self.__elementNode_Data.get('WeakHint', {}).get('Weak')
            if not weak_selector:
                # 尝试从 elForm 获取
                weak_selector = self.__elementNode_Data.get('elForm', {}).get('error')
            if not weak_selector:
                INFO("elementData.yaml 中未配置 WeakHint.Weak 或 elForm.error", "WARNING")
                return None
            weak_ele = page.locator(weak_selector).first

            # 使用 wait_for 替代 is_visible(timeout=...)
            weak_ele.wait_for(state='visible', timeout=2000)
            if weak_ele.is_visible():
                text = weak_ele.text_content() or ''
                # 提取中文和数字
                result = ''.join(re.findall(r'[0-9\u4e00-\u9fa5]', text))
                INFO(f'弱提示文本: {result}')
                return result
        except:
            INFO('无弱提示')

        return None

    # ==================== 人员选择 ====================

    def personnelChoice(self, type: str, dataList: list = None, name: str = '', department: str = ''):
        """
        人员选择逻辑封装

        Args:
            type: 添加方式 '0'部门 '1'角色 '2'分组 '3'在线 '4'检索 '5'已选
            dataList: 部门/角色/分组方式时传入 [目录名, 人员姓名] 或 [[多级目录], 人员姓名]
            name: 在线/检索/已选方式时传入人员姓名
            department: 部门全选时传入部门名称

        在 Excel 中使用: [OA_JavaWebUI]personnelChoice | | | {'type':'0','dataList':['综合部','张三']}
        """
        page = self._get_page()
        KEYWORD = self._get_keyword()

        # 点击导航按钮
        nav_info = self.__elementNode_Data.get('personnel', {}).get('NAV_ITEM', {}).get(type)
        if nav_info:
            self._locator(nav_info[0], nav_info[1]).click()
            page.wait_for_timeout(300)

        if type in ['3', '4', '5']:
            # 在线、检索、已选方式
            if type == '4' and name:
                # 输入搜索关键字
                search_info = self.__elementNode_Data.get('personnel', {}).get('search')
                if search_info:
                    self._locator(search_info[0], search_info[1]).fill(name)
                    page.wait_for_timeout(500)

            # 点击目标人员
            if name:
                person_selector = f"//span[contains(text(),'{name}')]"
                page.locator(f'xpath={person_selector}').first.click()
        else:
            # 部门、角色、分组方式
            if department:
                # 部门全选
                checkbox_selector = f"//span[contains(text(),'{department}')]/preceding-sibling::span[contains(@class,'checkbox')]"
                page.locator(f'xpath={checkbox_selector}').click()
            elif dataList:
                # 展开目录
                if isinstance(dataList[0], list):
                    # 多级目录
                    for item in dataList[0]:
                        dir_selector = f"//span[contains(text(),'{item}')]"
                        page.locator(f'xpath={dir_selector}').first.click()
                        page.wait_for_timeout(300)
                else:
                    # 单级目录
                    dir_selector = f"//span[contains(text(),'{dataList[0]}')]"
                    page.locator(f'xpath={dir_selector}').first.click()
                    page.wait_for_timeout(300)

                # 点击人员
                person_name = dataList[-1]
                person_selector = f"//span[contains(text(),'{person_name}')]"
                page.locator(f'xpath={person_selector}').first.click()

        # 组件关闭处理
        try:
            confirm_selector = self.__elementNode_Data.get('personnel', {}).get('confirm')
            if confirm_selector:
                confirm_btn = page.locator(confirm_selector)
                # 使用 wait_for 替代 is_visible(timeout=...)
                confirm_btn.wait_for(state='visible', timeout=1000)
                if confirm_btn.is_visible():
                    confirm_btn.click()
        except:
            pass

    # ==================== 日期选择 ====================

    def setDate(self, expectDate: str):
        """
        日期选择（传统日期控件）

        Args:
            expectDate: 日期格式 YYYY-MM-DD 如 2024-01-15

        在 Excel 中使用: [OA_JavaWebUI]setDate | | | 2024-01-15
        """
        page = self._get_page()

        # 解析日期
        year, month, day = map(int, expectDate.split('-'))

        try:
            # 如果有iframe，先切换
            frame_src = self.__elementNode_Data.get('setDate', {}).get('frameSrc')
            if frame_src:
                self.jumpFrame([1, [frame_src]])

            # 从配置获取选择器
            el_date = self.__elementNode_Data.get('elDatePicker', {})
            year_btn_selector = el_date.get('year_btn', '.el-date-picker__header-label')
            year_table_selector = el_date.get('year_table', '.el-year-table td')
            month_table_selector = el_date.get('month_table', '.el-month-table td')
            date_table_selector = el_date.get('date_table', '.el-date-table td.available')

            # 点击年份选择
            year_btn = page.locator(year_btn_selector).first
            year_btn.click()
            page.wait_for_timeout(300)

            # 选择年份
            page.locator(f'{year_table_selector}:has-text("{year}")').click()
            page.wait_for_timeout(300)

            # 选择月份
            page.locator(month_table_selector).nth(month - 1).click()
            page.wait_for_timeout(300)

            # 选择日期
            page.locator(f'{date_table_selector}:has-text("{day}")').first.click()

            # 返回主文档
            self.frame_default()

        except Exception as error:
            INFO(f"日期选择失败: {error}", "ERROR")
            self.frame_default()

    def el_datepicker(self, date: str):
        """
        Element Plus 日期选择（输入方式）

        Args:
            date: 日期字符串 YYYY-MM-DD

        在 Excel 中使用: [OA_JavaWebUI]el_datepicker | | | 2024-01-15
        """
        page = self._get_page()
        page.keyboard.type(date)
        page.keyboard.press('Enter')
        INFO(f"输入日期: {date}")

    def el_daterange(self, start_date: str, end_date: str):
        """
        Element Plus 日期范围选择

        Args:
            start_date: 开始日期
            end_date: 结束日期

        在 Excel 中使用: [OA_JavaWebUI]el_daterange | | | 2024-01-01,2024-12-31
        """
        page = self._get_page()

        # 从配置获取选择器
        el_date = self.__elementNode_Data.get('elDatePicker', {})
        range_panel_selector = el_date.get('range_panel', '.el-date-range-picker')
        confirm_btn_selector = el_date.get('confirm_btn', '.el-picker-panel__footer .el-button--primary')

        # 等待日期范围面板
        panel = page.locator(f'{range_panel_selector}:visible')
        panel.wait_for(state='visible')

        # 输入开始和结束日期
        inputs = panel.locator('input')
        inputs.nth(0).fill(start_date)
        inputs.nth(1).fill(end_date)

        # 确认
        panel.locator(confirm_btn_selector).click()
        INFO(f"选择日期范围: {start_date} 至 {end_date}")

    # ==================== 提示弹框处理 ====================

    def TipsSpringFrame(self, type: str = 'readAll'):
        """
        系统右上角提示信息弹框处理

        Args:
            type: 'exit' 关闭弹框, 'readAll' 已阅全部

        在 Excel 中使用: [OA_JavaWebUI]TipsSpringFrame | | | readAll
        """
        page = self._get_page()

        try:
            tips_selector = self.__elementNode_Data.get('TSFrame', {}).get(
                'tispElements', '.notification-list .notification-item'
            )
            tips_elements = page.locator(tips_selector)

            if tips_elements.count() == 0:
                INFO('界面无消息提示框')
                return 0

            for i in range(tips_elements.count()):
                tips_elements.nth(i).hover()
                page.wait_for_timeout(300)

                if type == 'exit':
                    close_btn = tips_elements.nth(i).locator('.close-btn, .el-icon-close')
                    if close_btn.is_visible():
                        close_btn.click()
                else:
                    # 已阅全部或忽略全部
                    mark_btn = tips_elements.nth(i).locator('.mark-read, .ignore-all')
                    if mark_btn.is_visible():
                        mark_btn.click()
                        break

            return 1

        except Exception as error:
            INFO(f'提示弹框处理失败: {error}', "WARNING")
            return 0

    # ==================== 表单输入 ====================

    def FormInput(self, Parent: str, operationStep: Dict):
        """
        表单信息输入逻辑封装

        Args:
            Parent: 父级表单的 CSS 选择器
            operationStep: 操作流程字典
                {
                    'input': [值1, 值2, ...] 或 [[name, 值], ...],
                    'textarea': [...],
                    'checkbox': [True/False, ...],
                    'radio': [True/False, ...],
                    'select': [[name, 值], ...]
                }

        在 Excel 中使用: [OA_JavaWebUI]FormInput | | | {'Parent':'.form','operationStep':{...}}
        """
        page = self._get_page()
        parent_ele = page.locator(Parent)

        for step_key in operationStep:
            if step_key == 'select':
                # 下拉列表框
                for item in operationStep[step_key]:
                    select_name, select_value = item[0], item[1]
                    select_ele = parent_ele.locator(f'select[name="{select_name}"]')

                    if isinstance(select_value, int):
                        select_ele.select_option(index=select_value)
                    else:
                        select_ele.select_option(label=select_value)

            elif step_key in ['input', 'textarea', 'pass']:
                # 输入框
                if step_key == 'pass':
                    inputs = parent_ele.locator('input[type="password"]')
                elif step_key == 'textarea':
                    inputs = parent_ele.locator('textarea')
                else:
                    inputs = parent_ele.locator('input:not([type="checkbox"]):not([type="radio"]):not([type="password"])')

                for i, value in enumerate(operationStep[step_key]):
                    if value is None:
                        continue

                    if isinstance(value, list):
                        # 指定 name 操作
                        target = parent_ele.locator(f'[name="{value[0]}"]')
                        actual_value = value[1]
                    else:
                        # 顺序操作
                        if i >= inputs.count():
                            break
                        target = inputs.nth(i)
                        actual_value = value

                    target.fill('')
                    if actual_value != 'clear':
                        target.fill(str(actual_value))

            elif step_key in ['checkbox', 'radio']:
                # 复选框/单选框
                selector = f'input[type="{step_key}"]'
                elements = parent_ele.locator(selector)

                for i, value in enumerate(operationStep[step_key]):
                    if value is None:
                        continue

                    if isinstance(value, list):
                        target = parent_ele.locator(f'[name="{value[0]}"]')
                        should_check = value[1]
                    else:
                        if i >= elements.count():
                            break
                        target = elements.nth(i)
                        should_check = value

                    is_checked = target.is_checked()
                    if is_checked != should_check:
                        target.click()

    # ==================== 菜单导航 ====================

    def goto_Modular(self, firstIden: str = None, secondIden: str = None,
                     thirdIden: str = None, tagIden: int = None, localSwitch: bool = False):
        """
        全局系统模块菜单跳转操作封装

        Args:
            firstIden: 一级模块标识 (对应 modularInformation.json 中的 key)
            secondIden: 二级模块标识 (对应 subordinate 中的 key)
            thirdIden: 三级模块标识（可选，对应 submodule 中的 key）
            tagIden: tag 标签页索引（可选，对应 tagPage 数组索引）
            localSwitch: 局部操作开关 (True 时不刷新页面，使用缓存的标识)

        在 Excel 中使用: [OA_JavaWebUI]goto_Modular | | | {'firstIden':'Organization','secondIden':'UserMgt'}
        """
        page = self._get_page()

        # 获取模块配置（已在 __init__ 中解析）
        modular_dict = self.__ModularNode_Information
        if not modular_dict:
            INFO("模块配置未加载", "ERROR")
            return

        # 缓存模块标识
        if firstIden and not localSwitch:
            self.__CDCG['firstIden'] = firstIden
        if secondIden and not localSwitch:
            self.__CDCG['secondIden'] = secondIden
        if thirdIden and not localSwitch:
            self.__CDCG['thirdIden'] = thirdIden

        try:
            # 返回主文档
            self.frame_default()

            if not localSwitch:
                # 刷新页面
                page.reload()
                page.wait_for_load_state('networkidle')
            else:
                # 局部操作，获取缓存的标识
                firstIden = self.__CDCG.get('firstIden', firstIden)
                secondIden = self.__CDCG.get('secondIden', secondIden)
                thirdIden = self.__CDCG.get('thirdIden', thirdIden)

                if not tagIden:
                    # 点击任务栏关闭当前标签
                    taskbar_info = self.__elementNode_Data.get('gotoModular', {}).get('taskbar')
                    if taskbar_info:
                        self._locator(taskbar_info[0], taskbar_info[1]).click()

            second_info = {}

            if firstIden and firstIden in modular_dict:
                # 点击一级菜单
                first_loc = modular_dict[firstIden].get('selfLocatin')
                if first_loc:
                    self._locator(first_loc[0], first_loc[1]).click()
                    page.wait_for_timeout(300)
                    INFO(f"点击一级菜单: {modular_dict[firstIden].get('displayName', firstIden)}")

                # 点击二级菜单
                if secondIden and 'subordinate' in modular_dict[firstIden]:
                    second_info = modular_dict[firstIden]['subordinate'].get(secondIden, {})
                    second_loc = second_info.get('locatingNodes')
                    if second_loc:
                        self._locator(second_loc[0], second_loc[1]).click()
                        page.wait_for_timeout(300)
                        INFO(f"点击二级菜单: {second_info.get('displayName', secondIden)}")

                        # 处理 iframe 切换
                        iframe_name = second_info.get('iframe')
                        if iframe_name:
                            self._current_frame = page.frame_locator(f'iframe[name="{iframe_name}"], iframe#{iframe_name}, #{iframe_name}')
                            INFO(f"切换到 iframe: {iframe_name}")

                    # 处理三级菜单
                    if thirdIden and second_info.get('submodule'):
                        third_info = second_info['submodule'].get(thirdIden, {})
                        third_loc = third_info.get('locatingNodes')  # 修正: locatinExpression -> locatingNodes
                        if third_loc:
                            self._locator(third_loc[0], third_loc[1]).click()
                            page.wait_for_timeout(300)
                            INFO(f"点击三级菜单: {third_info.get('displayName', thirdIden)}")

                            # 三级菜单可能有自己的 iframe
                            third_iframe = third_info.get('thisIframe')
                            if third_iframe:
                                self._current_frame = page.frame_locator(f'iframe[name="{third_iframe}"], iframe#{third_iframe}, #{third_iframe}')
                                INFO(f"切换到 iframe: {third_iframe}")

            # 处理 tag 标签页
            if tagIden is not None:
                tag_pages = second_info.get('tagPage')
                if tag_pages and isinstance(tag_pages, list) and tagIden < len(tag_pages):
                    tag_loc = tag_pages[tagIden]
                    if tag_loc and len(tag_loc) >= 2:
                        self._locator(tag_loc[0], tag_loc[1]).click()
                        page.wait_for_timeout(300)
                        INFO(f"点击标签页: 索引 {tagIden}")

        except Exception as error:
            INFO(f"模块导航失败: {error}", "ERROR")

    def goto_Menu(self, menu_path: str):
        """
        简化版菜单导航 - 基于中文菜单名称

        Args:
            menu_path: 菜单路径 "一级/二级/三级"

        在 Excel 中使用: [OA_JavaWebUI]goto_Menu | | | 系统管理/用户管理
        """
        page = self._get_page()
        if page is None:
            INFO("页面实例未设置", "ERROR")
            return

        levels = [level.strip() for level in menu_path.split('/')]
        INFO(f"菜单导航: {menu_path}")

        # 从配置获取选择器
        el_menu = self.__elementNode_Data.get('elMenu', {})
        submenu_selector = el_menu.get('submenu', '.el-sub-menu')
        submenu_title_selector = el_menu.get('submenu_title', '.el-sub-menu__title')
        menu_item_selector = el_menu.get('menu_item', '.el-menu-item')

        for i, menu_text in enumerate(levels):
            if i < len(levels) - 1:
                # 展开子菜单
                submenu = page.locator(f'{submenu_selector}:has-text("{menu_text}")')
                try:
                    # 先等待元素可见，再获取属性
                    submenu.first.wait_for(state='visible', timeout=2000)
                    class_attr = submenu.first.get_attribute('class') or ''
                    if 'is-opened' not in class_attr:
                        submenu.locator(submenu_title_selector).first.click()
                        page.wait_for_timeout(300)
                except:
                    page.locator(f'{menu_item_selector}:has-text("{menu_text}")').first.click()
                    page.wait_for_timeout(300)
            else:
                # 点击菜单项
                page.locator(f'{menu_item_selector}:has-text("{menu_text}")').first.click()
                page.wait_for_timeout(500)

        INFO(f"已导航到: {menu_path}")

    def click_tab(self, tab_text: str):
        """
        点击标签页

        在 Excel 中使用: [OA_JavaWebUI]click_tab | | | 待处理
        """
        page = self._get_page()

        # 从配置获取选择器
        el_menu = self.__elementNode_Data.get('elMenu', {})
        tabs_item_selector = el_menu.get('tabs_item', '.el-tabs__item')

        tab = page.locator(f'{tabs_item_selector}:has-text("{tab_text}")').first
        tab.click()
        page.wait_for_timeout(300)
        INFO(f"点击标签页: {tab_text}")

    # ==================== Element Plus 组件 ====================

    def el_select(self, option_text: str):
        """
        Element Plus 下拉选择

        在 Excel 中使用: [OA_JavaWebUI]el_select | | | 选项文本
        """
        page = self._get_page()

        # 从配置获取选择器
        el_select = self.__elementNode_Data.get('elSelect', {})
        dropdown_selector = el_select.get('dropdown', '.el-select-dropdown:visible, .el-popper:visible')
        dropdown_item_selector = el_select.get('dropdown_item', '.el-select-dropdown__item')

        dropdown = page.locator(dropdown_selector)
        dropdown.wait_for(state='visible', timeout=5000)
        dropdown.locator(f'{dropdown_item_selector}:has-text("{option_text}")').click()
        INFO(f"选择: {option_text}")

    def el_dialog_confirm(self, button_text: str = '确定'):
        """点击对话框确认按钮"""
        page = self._get_page()

        # 从配置获取选择器
        el_dialog = self.__elementNode_Data.get('elDialog', {})
        dialog_selector = el_dialog.get('dialog', '.el-dialog:visible, .el-overlay:visible')
        footer_btn_selector = el_dialog.get('footer_btn', '.el-dialog__footer .el-button')

        dialog = page.locator(dialog_selector)
        dialog.locator(f'{footer_btn_selector}:has-text("{button_text}")').click()
        INFO(f"点击: {button_text}")

    def el_dialog_cancel(self, button_text: str = '取消'):
        """点击对话框取消按钮"""
        page = self._get_page()

        # 从配置获取选择器
        el_dialog = self.__elementNode_Data.get('elDialog', {})
        dialog_selector = el_dialog.get('dialog', '.el-dialog:visible, .el-overlay:visible')
        footer_btn_selector = el_dialog.get('footer_btn', '.el-dialog__footer .el-button')

        dialog = page.locator(dialog_selector)
        dialog.locator(f'{footer_btn_selector}:has-text("{button_text}")').click()
        INFO(f"点击: {button_text}")

    def el_message_box_confirm(self, accept: bool = True):
        """处理 MessageBox"""
        page = self._get_page()

        # 从配置获取选择器
        el_msg_box = self.__elementNode_Data.get('elMessageBox', {})
        box_selector = el_msg_box.get('box', '.el-message-box:visible')
        btns_primary_selector = el_msg_box.get('btns_primary', '.el-message-box__btns .el-button--primary')
        btns_selector = el_msg_box.get('btns', '.el-message-box__btns .el-button')

        box = page.locator(box_selector)
        box.wait_for(state='visible')

        if accept:
            box.locator(btns_primary_selector).click()
        else:
            box.locator(btns_selector).first.click()

    def wait_loading(self, timeout: int = 30000):
        """等待 loading 消失"""
        page = self._get_page()

        # 从配置获取选择器
        el_loading = self.__elementNode_Data.get('elLoading', {})
        mask_selector = el_loading.get('mask', '.el-loading-mask')

        loading = page.locator(mask_selector)
        if loading.count() > 0:
            loading.wait_for(state='hidden', timeout=timeout)
            INFO("Loading 已消失")

    # ==================== 数据库操作 ====================

    def intervention_Mysql(self, information: Dict):
        """
        OA 数据库操作

        Args:
            information: 数据库操作信息
                {
                    'localhost': 'host',
                    'port': 3306,
                    'user': 'root',
                    'password': 'password',
                    'charset': 'utf8',
                    'database': 'db_name',
                    'table': 'table_name',
                    'operation': 'delete/update/insert',
                    'where': '条件表达式',
                    'instructString': {'字段': '值'}
                }

        在 Excel 中使用: [OA_JavaWebUI]intervention_Mysql | | | {...}
        """
        # 尝试从配置获取数据库信息
        try:
            start_config = GSTORE.get('START', {})
            self_params = start_config.get('selfDefinedParameter', {})

            db_info = {
                'localhost': self_params.get('sql_host', information.get('localhost')),
                'port': self_params.get('sql_port', information.get('port', 3306)),
                'user': self_params.get('sql_user', information.get('user')),
                'password': self_params.get('sql_password', information.get('password')),
                'charset': self_params.get('sql_charset', information.get('charset', 'utf8')),
                'database': self_params.get('sql_db', information.get('database')),
            }
            db_info.update(information)
        except:
            db_info = information

        # 构建 SQL 语句
        operation = db_info.get('operation', '').strip()
        table = db_info.get('table')
        where = db_info.get('where', '')
        instruct = db_info.get('instructString', {})

        if operation == 'delete':
            sql = f"DELETE FROM `{table}`"
            if where:
                sql += f" WHERE {where}"
            sql += ";"

        elif operation == 'update':
            set_clause = ", ".join([f"`{k}`='{v}'" for k, v in instruct.items()])
            sql = f"UPDATE `{table}` SET {set_clause}"
            if where:
                sql += f" WHERE {where}"
            sql += ";"

        elif operation == 'insert':
            fields = ", ".join([f"`{k}`" for k in instruct.keys()])
            values = ", ".join([f"'{v}'" for v in instruct.values()])
            sql = f"INSERT INTO `{table}` ({fields}) VALUES ({values});"
        else:
            INFO(f"不支持的操作: {operation}", "ERROR")
            return

        # 执行 SQL
        try:
            import pymysql
            conn = pymysql.connect(
                host=db_info['localhost'],
                port=int(db_info['port']),
                user=db_info['user'],
                password=db_info['password'],
                charset=db_info['charset'],
                db=db_info['database']
            )
            cursor = conn.cursor()
            cursor.execute(sql)
            conn.commit()
            INFO(f"SQL 执行成功: {sql}")
        except ImportError:
            INFO("pymysql 未安装，无法执行数据库操作", "ERROR")
        except Exception as error:
            INFO(f"SQL 执行失败: {error}", "ERROR")
        finally:
            try:
                cursor.close()
                conn.close()
            except:
                pass
