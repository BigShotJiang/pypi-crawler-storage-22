'''
Playwright工具使用示例
打开百度网站http://www.baidu.com 并搜索刘德华
'''

import asyncio
from playwright.async_api import async_playwright


async def search_baidu_liudehua():
    """
    使用Playwright打开百度网站并搜索"刘德华"
    """
    async with async_playwright() as p:
        browser = None
        try:
            # 启动浏览器（设置headless=False可以看到浏览器操作界面）
            print("正在启动浏览器...")
            browser = await p.chromium.launch(
                headless=False, 
                args=['--no-sandbox', '--disable-blink-features=AutomationControlled']
            )
            page = await browser.new_page()
            
            # 访问百度首页
            print("正在打开百度网站...")
            await page.goto('http://www.baidu.com')
            print("已成功打开百度网站")
            
            # 等待搜索框加载
            await page.wait_for_selector('#kw', timeout=10000)
            print("搜索框已加载")
            
            # 输入搜索关键词"刘德华"
            search_keyword = "刘德华"
            print(f"正在搜索关键词: {search_keyword}")
            await page.fill('#kw', search_keyword)
            
            # 点击搜索按钮
            await page.click('#su')
            print("正在执行搜索...")
            
            # 等待搜索结果加载
            await page.wait_for_selector('#content_left', timeout=10000)
            print("搜索结果已加载完成")
            
            # 保持页面打开一段时间以便查看结果
            await page.wait_for_timeout(5000)
            
        except Exception as e:
            print(f"发生错误: {str(e)}")
            if browser:
                await browser.close()
            raise
        finally:
            # 关闭浏览器
            if browser:
                await browser.close()
                print("浏览器已关闭")


def main():
    """
    主函数，执行百度搜索
    """
    print("开始执行百度搜索刘德华...")
    try:
        asyncio.run(search_baidu_liudehua())
        print("搜索任务完成！")
    except Exception as e:
        print(f"程序执行失败: {str(e)}")


if __name__ == "__main__":
    main()