"""
菜单配置转换工具

将旧的 XPath 绝对路径定位转换为基于 Element Plus 组件的通用定位。
需要提供菜单名称映射表。
"""

import json
import os
from pathlib import Path


# ========== 菜单名称映射表 ==========
# 请根据您的 T20 OA 系统填写中文菜单名称
# 格式: "英文标识符": "中文菜单名称"

FIRST_LEVEL_MENU_NAMES = {
    # 一级菜单映射
    "Organization": "组织架构",      # 请修改为实际名称
    "COP": "协同办公",               # 请修改为实际名称
    "personalAffairs": "个人事务",   # 请修改为实际名称
    "administrativeOffice": "行政办公",
    "documentManagement": "文档管理",
    "projectManagement": "项目管理",
    "humanResources": "人力资源",
    "assetManagement": "资产管理",
    "systemManagement": "系统管理",
    # ... 添加更多一级菜单
}

SECOND_LEVEL_MENU_NAMES = {
    # 二级菜单映射 (格式: "一级_二级": "中文名称")
    "Organization_Multid_Org": "多维组织",
    "Organization_Org_Chart": "组织架构图",
    "Organization_Org_Management": "组织管理",
    "Organization_User_Group_Management": "用户组管理",
    "Organization_Position_Management": "岗位管理",
    "Organization_Job_Management": "职务管理",
    "Organization_Role_Management": "角色管理",
    "Organization_User_Management": "用户管理",
    "Organization_Matrix_Management": "矩阵管理",

    "COP_Diary": "工作日志",
    "COP_Project_Hangup": "项目挂接",
    "COP_My_Task": "我的任务",
    # ... 添加更多二级菜单
}

TAG_PAGE_NAMES = {
    # 标签页映射 (格式: "一级_二级_索引": "中文名称")
    "Organization_Org_Chart_0": "消息中心",
    "Organization_Org_Chart_1": "提醒中心",
    "Organization_Org_Chart_2": "离线文件",
    "Organization_Org_Chart_3": "即时群组",
    "Organization_Org_Chart_4": "离线群组",
    # ... 添加更多标签页
}


def convert_first_level_locator(menu_id: str) -> list:
    """转换一级菜单定位"""
    menu_name = FIRST_LEVEL_MENU_NAMES.get(menu_id, menu_id)
    # Element Plus 菜单定位
    return ["css", f".el-menu > .el-sub-menu:has-text('{menu_name}') > .el-sub-menu__title"]


def convert_second_level_locator(first_id: str, second_id: str) -> list:
    """转换二级菜单定位"""
    key = f"{first_id}_{second_id}"
    menu_name = SECOND_LEVEL_MENU_NAMES.get(key, second_id)
    # Element Plus 菜单项定位
    return ["css", f".el-menu-item:has-text('{menu_name}')"]


def convert_tag_page_locator(first_id: str, second_id: str, index: int, old_locator: list) -> list:
    """转换标签页定位"""
    key = f"{first_id}_{second_id}_{index}"
    tag_name = TAG_PAGE_NAMES.get(key)

    if tag_name:
        # 使用 Element Plus 标签页定位
        return ["css", f".el-tabs__item:has-text('{tag_name}')"]
    else:
        # 保留原始定位（如果没有映射）
        return old_locator


def convert_config(input_file: str, output_file: str):
    """转换配置文件"""
    data = load_json_with_single_quotes(input_file)

    new_data = {}

    for first_id, first_config in data.items():
        first_name = FIRST_LEVEL_MENU_NAMES.get(first_id, first_id)

        new_first = {
            "displayName": first_name,  # 添加显示名称
            "selfLocatin": convert_first_level_locator(first_id),
            "subordinate": {}
        }

        subordinate = first_config.get("subordinate", {})
        for second_id, second_config in subordinate.items():
            second_name = SECOND_LEVEL_MENU_NAMES.get(f"{first_id}_{second_id}", second_id)

            new_second = {
                "displayName": second_name,  # 添加显示名称
                "iframe": second_config.get("iframe", ""),
                "locatingNodes": convert_second_level_locator(first_id, second_id),
                "submodule": second_config.get("submodule"),
                "tagPage": None
            }

            # 转换标签页
            tag_pages = second_config.get("tagPage")
            if tag_pages:
                new_tag_pages = []
                for i, tag_locator in enumerate(tag_pages):
                    new_tag_pages.append(
                        convert_tag_page_locator(first_id, second_id, i, tag_locator)
                    )
                new_second["tagPage"] = new_tag_pages

            new_first["subordinate"][second_id] = new_second

        new_data[first_id] = new_first

    # 保存转换后的配置
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(new_data, f, ensure_ascii=False, indent=4)

    print(f"转换完成！输出文件: {output_file}")
    print(f"请检查并补充菜单名称映射表中缺失的中文名称。")


def load_json_with_single_quotes(file_path: str) -> dict:
    """加载包含单引号的 JSON 文件"""
    import re

    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 将单引号替换为双引号（但保留字符串内部的单引号）
    # 使用 Python 的 eval（因为原文件实际上是有效的 Python dict 字面量）
    try:
        # 尝试作为 Python 字面量解析
        import ast
        data = ast.literal_eval(content)
        return data
    except:
        pass

    # 如果失败，尝试手动处理
    # 替换键值对中的单引号
    content = re.sub(r"'([^']*)'(\s*:\s*)", r'"\1"\2', content)
    content = re.sub(r":\s*'([^']*)'", r': "\1"', content)
    content = re.sub(r"\[\s*'([^']*)'", r'["\1"', content)
    content = re.sub(r"'([^']*)'\s*\]", r'"\1"]', content)
    content = re.sub(r"'([^']*)'\s*,", r'"\1",', content)
    content = content.replace("null", "null")

    return json.loads(content)


def generate_mapping_template(input_file: str, output_file: str):
    """从原始配置生成映射模板"""
    data = load_json_with_single_quotes(input_file)

    first_level = {}
    second_level = {}
    tag_pages = {}

    for first_id, first_config in data.items():
        first_level[first_id] = f"TODO: {first_id} 的中文名称"

        subordinate = first_config.get("subordinate", {})
        for second_id, second_config in subordinate.items():
            key = f"{first_id}_{second_id}"
            second_level[key] = f"TODO: {second_id} 的中文名称"

            tag_page_list = second_config.get("tagPage")
            if tag_page_list:
                for i, _ in enumerate(tag_page_list):
                    tag_key = f"{first_id}_{second_id}_{i}"
                    tag_pages[tag_key] = f"TODO: 第{i+1}个标签页的中文名称"

    template = {
        "说明": "请将 TODO 替换为实际的中文菜单名称",
        "一级菜单": first_level,
        "二级菜单": second_level,
        "标签页": tag_pages
    }

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(template, f, ensure_ascii=False, indent=4)

    print(f"映射模板已生成: {output_file}")
    print(f"请编辑该文件，将 TODO 替换为实际的中文菜单名称。")


if __name__ == "__main__":
    base_dir = Path(__file__).parent.parent / "elementData"
    input_file = base_dir / "modularInformation.json"
    output_file = base_dir / "modularInformation_new.json"
    mapping_file = base_dir / "menu_name_mapping.json"

    # 1. 先生成映射模板
    print("=" * 50)
    print("步骤 1: 生成菜单名称映射模板")
    print("=" * 50)
    generate_mapping_template(str(input_file), str(mapping_file))

    print("\n" + "=" * 50)
    print("步骤 2: 转换配置文件")
    print("=" * 50)
    print("请先编辑 menu_name_mapping.json 填写中文名称，")
    print("然后取消下面代码的注释并重新运行。")
    # convert_config(str(input_file), str(output_file))
