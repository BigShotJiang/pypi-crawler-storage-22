"""原版 kdtest 插件兼容适配器"""

import configparser
import importlib.util
import sys
from pathlib import Path
from typing import Dict, Any, Optional, List

from playwright.sync_api import Page

from .plugin_base import PluginBase
from ..reference import INFO

# 注册 kdtest 兼容模块，使 `from kdtest import ...` 可以工作
try:
    from ..compat import kdtest_compat
except ImportError:
    pass


class LegacyPluginAdapter(PluginBase):
    """原版 kdtest 插件适配器

    将原版 kdtest 插件格式适配为 kdtest-pw 格式。

    原版格式:
    plugin_name/
    ├── __init__.py
    ├── my.ini                 # [Information] NAME, DETAILE, STATE
    ├── {plugin_name}.py       # 主模块，类名与 NAME 一致
    ├── other_module.py        # 其他模块（可选）
    ├── elementData/
    │   ├── elementData.yaml
    │   └── modularInformation.json
    └── utils/
        └── tool.py
    """

    def __init__(self, page: Page = None):
        super().__init__(page)
        self._legacy_instance = None
        self._legacy_class = None
        self._plugin_dir: Optional[Path] = None

    def load_legacy_plugin(self, plugin_dir: Path) -> bool:
        """加载原版 kdtest 插件

        Args:
            plugin_dir: 插件目录

        Returns:
            bool: 是否加载成功
        """
        self._plugin_dir = plugin_dir

        # 1. 读取 my.ini 配置
        ini_path = plugin_dir / "my.ini"
        if not ini_path.exists():
            INFO(f"未找到配置文件: {ini_path}", "WARNING")
            return False

        config = configparser.ConfigParser()
        try:
            config.read(str(ini_path), encoding='utf-8')
        except:
            # 尝试其他编码
            config.read(str(ini_path), encoding='gbk')

        # 检查是否是原版格式
        if 'Information' not in config.sections():
            return False

        info = config['Information']

        # 获取插件信息
        self.name = info.get('NAME', plugin_dir.name)
        self.description = info.get('DETAILE', '').strip('"')
        state = info.get('STATE', 'finish').strip('"')

        # 检查状态
        if state == 'disabled':
            INFO(f"[{self.name}] 插件已禁用")
            return False

        self.version = "1.0.0"  # 原版没有版本号

        # 2. 加载主模块
        # 原版 kdtest 主模块文件名为 {NAME}.py 或 {目录名}.py
        module_path = None
        possible_names = [
            plugin_dir / f"{self.name}.py",           # 与 NAME 同名
            plugin_dir / f"{plugin_dir.name}.py",     # 与目录名同名
            plugin_dir / "module.py",                 # 兼容 module.py
        ]

        for path in possible_names:
            if path.exists():
                module_path = path
                break

        if module_path is None:
            INFO(f"[{self.name}] 未找到主模块文件 ({self.name}.py)", "WARNING")
            return False

        try:
            # 将插件父目录添加到 sys.path 以支持作为包导入
            plugin_dir_str = str(plugin_dir)
            plugin_parent_str = str(plugin_dir.parent)
            if plugin_parent_str not in sys.path:
                sys.path.insert(0, plugin_parent_str)

            # 确保 utils 目录有 __init__.py
            utils_dir = plugin_dir / "utils"
            if utils_dir.exists():
                utils_init = utils_dir / "__init__.py"
                if not utils_init.exists():
                    utils_init.write_text('', encoding='utf-8')

            # 确保插件目录有 __init__.py
            init_path = plugin_dir / "__init__.py"
            if not init_path.exists():
                init_path.write_text('', encoding='utf-8')

            # 使用 importlib 作为包导入（支持相对导入）
            import importlib
            package_name = plugin_dir.name  # 使用目录名作为包名
            module_name = f"{package_name}.{module_path.stem}"

            # 清除可能的旧缓存
            for mod_name in list(sys.modules.keys()):
                if mod_name.startswith(package_name):
                    del sys.modules[mod_name]

            # 导入模块
            module = importlib.import_module(module_name)

            # 查找与 NAME 同名的类
            if hasattr(module, self.name):
                self._legacy_class = getattr(module, self.name)
                self._legacy_instance = self._legacy_class()
            else:
                # 尝试查找第一个类
                for name in dir(module):
                    obj = getattr(module, name)
                    if isinstance(obj, type) and obj.__module__ == module.__name__:
                        self._legacy_class = obj
                        self._legacy_instance = obj()
                        break

            if self._legacy_instance is None:
                INFO(f"[{self.name}] 未找到插件类", "WARNING")
                return False

        except Exception as e:
            INFO(f"[{self.name}] 加载主模块失败: {e}", "ERROR")
            return False

        # 3. 加载元素数据
        element_data_dir = plugin_dir / "elementData"
        if element_data_dir.exists():
            self._load_element_data_dir(element_data_dir)

        # 4. 加载 utils (作为辅助方法)
        utils_dir = plugin_dir / "utils"
        if utils_dir.exists():
            self._load_utils_dir(utils_dir)

        INFO(f"[{self.name}] 加载原版 kdtest 插件成功")
        return True

    def _load_element_data_dir(self, element_data_dir: Path) -> None:
        """加载元素数据目录

        支持的文件:
        - elementData.yaml / *.yaml / *.yml
        - modularInformation.json
        """
        import yaml
        import json

        # 加载 YAML 文件
        for yaml_file in element_data_dir.glob("*.yaml"):
            try:
                with open(yaml_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f) or {}
                    self._element_data.update(data)
            except Exception as e:
                INFO(f"[{self.name}] 加载 {yaml_file.name} 失败: {e}", "WARNING")

        for yml_file in element_data_dir.glob("*.yml"):
            try:
                with open(yml_file, 'r', encoding='utf-8') as f:
                    data = yaml.safe_load(f) or {}
                    self._element_data.update(data)
            except Exception as e:
                INFO(f"[{self.name}] 加载 {yml_file.name} 失败: {e}", "WARNING")

        # 加载 JSON 文件 (modularInformation.json 等)
        for json_file in element_data_dir.glob("*.json"):
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f) or {}
                    # modularInformation.json 可能有特殊格式，尝试合并
                    if isinstance(data, dict):
                        self._element_data.update(data)
            except Exception as e:
                INFO(f"[{self.name}] 加载 {json_file.name} 失败: {e}", "WARNING")

    def _load_utils_dir(self, utils_dir: Path) -> None:
        """加载 utils 目录中的辅助方法"""
        for py_file in utils_dir.glob("*.py"):
            if py_file.name.startswith('_'):
                continue

            try:
                module_name = f"kdtest_legacy_{self.name}_utils_{py_file.stem}"
                spec = importlib.util.spec_from_file_location(module_name, py_file)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = module
                    spec.loader.exec_module(module)
            except Exception as e:
                INFO(f"[{self.name}] 加载 utils/{py_file.name} 失败: {e}", "WARNING")

    def setup(self) -> None:
        """初始化插件 - 将原版方法注册为关键字"""
        if self._legacy_instance is None:
            return

        # 获取原版插件的所有公开方法并注册为关键字
        for method_name in dir(self._legacy_instance):
            if method_name.startswith('_'):
                continue
            if method_name in ('__init__', '__call__', '__repr__', '__str__'):
                continue

            method = getattr(self._legacy_instance, method_name)
            if callable(method):
                # 包装方法以适配 kdtest-pw 的调用方式
                wrapped = self._wrap_legacy_method(method, method_name)
                self._keywords[method_name] = wrapped

    def _wrap_legacy_method(self, method, method_name: str):
        """包装原版方法以适配 kdtest-pw

        原版 kdtest 的方法签名可能不同，需要适配
        """
        def wrapper(*args, **kwargs):
            try:
                # 尝试直接调用
                return method(*args, **kwargs)
            except TypeError:
                # 如果参数不匹配，尝试调整
                # 原版可能使用不同的参数格式
                if 'content' in kwargs:
                    # 尝试将 content 作为第一个参数
                    return method(kwargs['content'], *args)
                raise

        wrapper.__name__ = method_name
        wrapper.__doc__ = method.__doc__
        return wrapper

    def set_page(self, page: Page) -> None:
        """设置 Page 实例"""
        super().set_page(page)

        # 尝试将 page 注入到原版插件实例
        if self._legacy_instance:
            if hasattr(self._legacy_instance, 'page'):
                self._legacy_instance.page = page
            if hasattr(self._legacy_instance, '_page'):
                self._legacy_instance._page = page
            if hasattr(self._legacy_instance, 'driver'):
                # 原版使用 driver (Selenium)，这里无法直接兼容
                # 但可以提供一个适配器
                pass


def is_legacy_plugin(plugin_dir: Path) -> bool:
    """检查是否是原版 kdtest 插件格式

    Args:
        plugin_dir: 插件目录

    Returns:
        bool: 是否是原版格式
    """
    ini_path = plugin_dir / "my.ini"
    if not ini_path.exists():
        return False

    config = configparser.ConfigParser()
    try:
        config.read(str(ini_path), encoding='utf-8')
    except:
        try:
            config.read(str(ini_path), encoding='gbk')
        except:
            return False

    # 检查是否有 [Information] 节
    return 'Information' in config.sections()


def load_legacy_plugin(plugin_dir: Path, page: Page = None) -> Optional[LegacyPluginAdapter]:
    """加载原版 kdtest 插件

    Args:
        plugin_dir: 插件目录
        page: Playwright Page 实例

    Returns:
        LegacyPluginAdapter: 插件适配器实例，加载失败返回 None
    """
    adapter = LegacyPluginAdapter(page)
    if adapter.load_legacy_plugin(plugin_dir):
        adapter.initialize()
        return adapter
    return None
