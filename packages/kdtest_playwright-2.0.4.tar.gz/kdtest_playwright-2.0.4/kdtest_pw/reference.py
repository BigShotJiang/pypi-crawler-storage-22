"""全局存储模块

提供全局变量存储，用于在模块间共享数据。
"""

import logging
import sys
from typing import Any, Dict, Optional
from pathlib import Path

# ==================== 日志配置 ====================

# 创建 logger
_logger = logging.getLogger('kdtest_pw')
_logger.setLevel(logging.DEBUG)

# 控制台处理器
_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setLevel(logging.INFO)
_console_formatter = logging.Formatter(
    '[%(levelname)s] %(message)s'
)
_console_handler.setFormatter(_console_formatter)
_logger.addHandler(_console_handler)

# 文件处理器（延迟初始化）
_file_handler: Optional[logging.FileHandler] = None


def setup_file_logging(log_dir: str = 'result/log', log_level: int = logging.DEBUG) -> None:
    """设置文件日志

    Args:
        log_dir: 日志目录
        log_level: 日志级别
    """
    global _file_handler

    # 创建日志目录
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    # 生成日志文件名
    from datetime import datetime
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = log_path / f'kdtest_{timestamp}.log'

    # 移除旧的文件处理器
    if _file_handler:
        _logger.removeHandler(_file_handler)

    # 添加新的文件处理器
    _file_handler = logging.FileHandler(str(log_file), encoding='utf-8')
    _file_handler.setLevel(log_level)
    _file_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    _file_handler.setFormatter(_file_formatter)
    _logger.addHandler(_file_handler)


def set_log_level(level: str) -> None:
    """设置控制台日志级别

    Args:
        level: 日志级别 (DEBUG, INFO, WARNING, ERROR)
    """
    level_map = {
        'DEBUG': logging.DEBUG,
        'INFO': logging.INFO,
        'WARNING': logging.WARNING,
        'ERROR': logging.ERROR,
    }
    log_level = level_map.get(level.upper(), logging.INFO)
    _console_handler.setLevel(log_level)

# 全局存储 - 核心组件引用
GSTORE: Dict[str, Any] = {
    'browser': None,      # Browser实例
    'context': None,      # BrowserContext实例
    'page': None,         # 当前Page实例
    'keyWord': None,      # KeyWordTest实例
}

# 全局系统数据存储
GSDSTORE: Dict[str, Any] = {
    'START': {},          # 启动参数
    'WORKPATH': {},       # 工作路径
}

# 模块数据存储 - 插件数据
MODULEDATA: Dict[str, Any] = {}

# 私有数据存储
PRIVATEDATA: Dict[str, Any] = {
    'PAGES': [],          # 多页面列表
    'ELEVALUE': {},       # 元素值缓存
    'CURRENT_CASE': None, # 当前用例名称
}

# 用例统计数据
CASESDATA: Dict[str, int] = {
    'total': 0,
    'passed': 0,
    'failed': 0,
    'skipped': 0,
}


def INFO(message: str, level: str = "INFO") -> None:
    """统一日志输出

    Args:
        message: 日志消息
        level: 日志级别 (INFO, WARNING, ERROR, DEBUG)
    """
    level_map = {
        'DEBUG': _logger.debug,
        'INFO': _logger.info,
        'WARNING': _logger.warning,
        'ERROR': _logger.error,
    }
    log_func = level_map.get(level.upper(), _logger.info)
    log_func(message)


def get_global(key: str, default: Any = None) -> Any:
    """获取全局存储的值

    Args:
        key: 键名
        default: 默认值

    Returns:
        存储的值或默认值
    """
    return GSTORE.get(key, default)


def set_global(key: str, value: Any) -> None:
    """设置全局存储的值

    Args:
        key: 键名
        value: 值
    """
    GSTORE[key] = value


def get_element_value(key: str, default: Any = None) -> Any:
    """获取缓存的元素值

    Args:
        key: 键名
        default: 默认值

    Returns:
        缓存的元素值或默认值
    """
    return PRIVATEDATA['ELEVALUE'].get(key, default)


def set_element_value(key: str, value: Any) -> None:
    """设置元素值缓存

    Args:
        key: 键名
        value: 值
    """
    PRIVATEDATA['ELEVALUE'][key] = value


def clear_element_values() -> None:
    """清除所有元素值缓存"""
    PRIVATEDATA['ELEVALUE'].clear()
