"""公共逻辑方法"""

import os
import re
import json
import hashlib
from typing import Any, Dict, List, Optional
from pathlib import Path

from ruamel.yaml import YAML

from ..reference import INFO, GSDSTORE
from .built_in_function import BuiltInFunction


class PublicScript:
    """公共脚本工具类

    提供文件操作、数据处理等公共方法。
    """

    # ==================== 文件操作 ====================

    @staticmethod
    def read_file(file_path: str, encoding: str = 'utf-8') -> str:
        """读取文件内容

        Args:
            file_path: 文件路径
            encoding: 编码

        Returns:
            str: 文件内容
        """
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()

    @staticmethod
    def write_file(file_path: str, content: str, encoding: str = 'utf-8') -> None:
        """写入文件

        Args:
            file_path: 文件路径
            content: 内容
            encoding: 编码
        """
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding=encoding) as f:
            f.write(content)

    @staticmethod
    def append_file(file_path: str, content: str, encoding: str = 'utf-8') -> None:
        """追加写入文件

        Args:
            file_path: 文件路径
            content: 内容
            encoding: 编码
        """
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'a', encoding=encoding) as f:
            f.write(content)

    @staticmethod
    def read_json(file_path: str) -> Any:
        """读取 JSON 文件

        Args:
            file_path: 文件路径

        Returns:
            解析后的 JSON 数据
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    @staticmethod
    def write_json(file_path: str, data: Any, indent: int = 2) -> None:
        """写入 JSON 文件

        Args:
            file_path: 文件路径
            data: 数据
            indent: 缩进
        """
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)

    @staticmethod
    def read_yaml(file_path: str) -> Any:
        """读取 YAML 文件

        Args:
            file_path: 文件路径

        Returns:
            解析后的 YAML 数据
        """
        import yaml
        with open(file_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    @staticmethod
    def write_yaml(file_path: str, data: Any) -> None:
        """写入 YAML 文件

        Args:
            file_path: 文件路径
            data: 数据
        """
        import yaml
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True)

    @staticmethod
    def file_exists(file_path: str) -> bool:
        """检查文件是否存在

        Args:
            file_path: 文件路径

        Returns:
            bool: 是否存在
        """
        return Path(file_path).exists()

    @staticmethod
    def delete_file(file_path: str) -> bool:
        """删除文件

        Args:
            file_path: 文件路径

        Returns:
            bool: 是否成功
        """
        try:
            Path(file_path).unlink(missing_ok=True)
            return True
        except Exception:
            return False

    @staticmethod
    def list_files(directory: str, pattern: str = '*') -> List[str]:
        """列出目录下的文件

        Args:
            directory: 目录路径
            pattern: 匹配模式

        Returns:
            List[str]: 文件路径列表
        """
        return [str(p) for p in Path(directory).glob(pattern)]

    # ==================== 数据处理 ====================

    @staticmethod
    def dict_get(data: Dict, key_path: str, default: Any = None) -> Any:
        """从嵌套字典获取值

        Args:
            data: 字典
            key_path: 键路径 (用点分隔)
            default: 默认值

        Returns:
            值
        """
        keys = key_path.split('.')
        value = data

        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            elif isinstance(value, list) and key.isdigit():
                index = int(key)
                value = value[index] if 0 <= index < len(value) else None
            else:
                return default

            if value is None:
                return default

        return value

    @staticmethod
    def dict_set(data: Dict, key_path: str, value: Any) -> None:
        """设置嵌套字典的值

        Args:
            data: 字典
            key_path: 键路径
            value: 值
        """
        keys = key_path.split('.')

        for key in keys[:-1]:
            if key not in data:
                data[key] = {}
            data = data[key]

        data[keys[-1]] = value

    @staticmethod
    def merge_dicts(*dicts: Dict) -> Dict:
        """合并多个字典

        Args:
            *dicts: 要合并的字典

        Returns:
            Dict: 合并后的字典
        """
        result = {}
        for d in dicts:
            result.update(d)
        return result

    @staticmethod
    def list_to_dict(data: List[Dict], key: str) -> Dict:
        """将列表转换为字典

        Args:
            data: 字典列表
            key: 作为键的字段名

        Returns:
            Dict: 转换后的字典
        """
        return {item[key]: item for item in data if key in item}

    # ==================== 加密工具 ====================

    @staticmethod
    def md5(text: str) -> str:
        """MD5 加密

        Args:
            text: 原文

        Returns:
            str: MD5 值
        """
        return hashlib.md5(text.encode()).hexdigest()

    @staticmethod
    def sha256(text: str) -> str:
        """SHA256 加密

        Args:
            text: 原文

        Returns:
            str: SHA256 值
        """
        return hashlib.sha256(text.encode()).hexdigest()

    @staticmethod
    def base64_encode(text: str) -> str:
        """Base64 编码

        Args:
            text: 原文

        Returns:
            str: 编码后的字符串
        """
        import base64
        return base64.b64encode(text.encode()).decode()

    @staticmethod
    def base64_decode(text: str) -> str:
        """Base64 解码

        Args:
            text: 编码字符串

        Returns:
            str: 解码后的字符串
        """
        import base64
        return base64.b64decode(text.encode()).decode()

    # ==================== 环境变量 ====================

    @staticmethod
    def get_env(name: str, default: str = '') -> str:
        """获取环境变量

        Args:
            name: 变量名
            default: 默认值

        Returns:
            str: 环境变量值
        """
        return os.environ.get(name, default)

    @staticmethod
    def set_env(name: str, value: str) -> None:
        """设置环境变量

        Args:
            name: 变量名
            value: 值
        """
        os.environ[name] = value

    # ==================== 验证工具 ====================

    @staticmethod
    def is_email(text: str) -> bool:
        """验证邮箱格式

        Args:
            text: 文本

        Returns:
            bool: 是否有效
        """
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, text))

    @staticmethod
    def is_phone(text: str) -> bool:
        """验证手机号格式

        Args:
            text: 文本

        Returns:
            bool: 是否有效
        """
        import re
        pattern = r'^1[3-9]\d{9}$'
        return bool(re.match(pattern, text))

    @staticmethod
    def is_url(text: str) -> bool:
        """验证 URL 格式

        Args:
            text: 文本

        Returns:
            bool: 是否有效
        """
        import re
        pattern = r'^https?://[^\s/$.?#].[^\s]*$'
        return bool(re.match(pattern, text, re.IGNORECASE))

    @staticmethod
    def is_json(text: str) -> bool:
        """验证 JSON 格式

        Args:
            text: 文本

        Returns:
            bool: 是否有效
        """
        try:
            json.loads(text)
            return True
        except (json.JSONDecodeError, TypeError):
            return False


class isLogicMethodClass:
    """逻辑方法类 - 兼容原版 kdtest

    提供 YAML 文件操作和数据预处理功能。
    """

    def __init__(self):
        self.BI_function_Obj = BuiltInFunction()
        self.YAML = YAML()
        self._init_contrast()

    def _init_contrast(self):
        """初始化预处理数据筛查字典"""
        self.CONTRAST = {
            'FUNCTION': [
                'today', 'now', 'timestamp',
                'random_int', 'random_string', 'random_phone',
                'random_email', 'random_name', 'uuid4',
                # 兼容原版函数名
                'get_PrestoreData', 'System_date', 'get_thisWeek',
                'get_thisMonth', 'get_thisYear', 'Increasing_date',
                'Intercept_date', 'Mktime_date'
            ],
            'PATH': [
                'WORK_PATH-ROOT', 'WORK_PATH-PACKET', 'WORK_PATH-CASES'
            ],
            'SDPI': []
        }
        # 动态获取自定义参数
        try:
            start_params = GSDSTORE.get('START', {})
            if 'selfDefinedParameter' in start_params:
                self.CONTRAST['SDPI'] = list(start_params['selfDefinedParameter'].keys())
        except Exception:
            pass

    def judge_specialOperator(self, content: Any) -> Any:
        """验证值是否包含特殊运算符

        Args:
            content: 内容

        Returns:
            处理后的内容或 False
        """
        if isinstance(content, str) and content and content[0] == "*" and content[-1] == "*":
            return content[1:-1]
        return False

    def raw_YamlTxt(self, file_src: str, oper: str = 'r', write_data: Any = None) -> Any:
        """YAML/TXT 文件数据读写

        Args:
            file_src: 文件路径
            oper: 操作方法 (r读、w写、a追加)
            write_data: 需要写入的数据

        Returns:
            读取的数据 (仅读操作返回)
        """
        file_path = Path(file_src)
        is_yaml = file_path.suffix.lower() in ['.yaml', '.yml']

        read_data = None

        if oper in ['w', 'a']:
            # 写入操作
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_src, mode=oper, encoding='utf-8') as f:
                if write_data is not None:
                    if is_yaml:
                        self.YAML.dump(write_data, f)
                    else:
                        f.write(str(write_data))
        else:
            # 读取操作
            if file_path.exists():
                with open(file_src, mode='r', encoding='utf-8') as f:
                    if is_yaml:
                        read_data = self.YAML.load(f)
                    else:
                        read_data = f.read()

        return read_data

    def mutual_in(self, former: str, latter: str) -> bool:
        """两值互相包含检查

        Args:
            former: 比对字符串1
            latter: 比对字符串2

        Returns:
            bool: 是否互相包含
        """
        try:
            former = str(former).strip()
            latter = str(latter).strip()
        except Exception:
            return False

        if former and latter:
            return (former in latter) or (latter in former)
        return False

    def Regular_takeData(self, operation_text: str, data_type: str = 'date') -> List[str]:
        """正则表达式数据提取

        Args:
            operation_text: 操作字符串
            data_type: 数据类型 (date, time, dateTime, int, text)

        Returns:
            List[str]: 匹配的数据列表
        """
        patterns = {
            'date': r'(\d{4}-\d{1,2}-\d{1,2})',
            'time': r'(\d{1,2}:\d{1,2}:\d{1,2})',
            'dateTime': r'(\d{4}-\d{1,2}-\d{1,2}\s\d{1,2}:\d{1,2}:\d{1,2})',
            'int': r'(\d+\.?\d*)',
            'text': r'[\u4e00-\u9fa5]+',
        }
        pattern = re.compile(patterns.get(data_type, patterns['date']))
        return pattern.findall(operation_text)

    def beforehand(self, data_text: str) -> str:
        """用例步骤操作值预处理

        处理内置函数调用、工作路径替换、自定义参数替换。

        Args:
            data_text: 待处理字符串

        Returns:
            str: 处理后的字符串
        """
        if not isinstance(data_text, str):
            return str(data_text)

        # 重新初始化对比字典（确保获取最新的自定义参数）
        self._init_contrast()

        # 筛选匹配项
        function_list = [f for f in self.CONTRAST['FUNCTION'] if f in data_text]
        workpath_list = [p for p in self.CONTRAST['PATH'] if p in data_text]
        identity_list = [i for i in self.CONTRAST['SDPI'] if i in data_text]

        def interpolation(p_string: str, emb: str, new: str) -> str:
            """内嵌函数替换"""
            tran_string = p_string[p_string.find(emb):]
            end_pos = tran_string.find(')') + 1
            tran = tran_string[:end_pos] if end_pos > 0 else tran_string
            if emb in tran:
                p_string = p_string.replace(tran, str(new))
            return p_string

        if function_list or identity_list or workpath_list:
            # 处理内置函数
            for fun in function_list:
                if hasattr(self.BI_function_Obj, fun):
                    function_obj = getattr(self.BI_function_Obj, fun)
                    for _ in range(data_text.count(fun)):
                        tran_string = data_text[data_text.find(fun):]
                        par_text = tran_string[:tran_string.find(')') + 1]
                        res = re.findall(r'[(](.*?)[)]', par_text)
                        if res and res[0]:
                            # 有参数调用
                            try:
                                params = res[0].split(',')
                                params = [p.strip().strip('"\'') for p in params]
                                result = function_obj(*params) if params[0] else function_obj()
                                data_text = interpolation(data_text, fun, result)
                            except Exception:
                                data_text = interpolation(data_text, fun, function_obj())
                        else:
                            # 无参数调用
                            data_text = interpolation(data_text, fun, function_obj())

            # 处理工作路径
            if workpath_list:
                workpath_data = GSDSTORE.get('WORKPATH', {})
                for path in workpath_list:
                    iden = path.split("-")[-1]
                    if iden in workpath_data:
                        data_text = data_text.replace(path, workpath_data[iden])
                        data_text = data_text.replace('\\', '\\\\')

            # 处理自定义参数
            if identity_list:
                start_params = GSDSTORE.get('START', {})
                self_defined = start_params.get('selfDefinedParameter', {})
                for iden in identity_list:
                    if iden in self_defined:
                        data_text = data_text.replace(iden, str(self_defined[iden]))

        return data_text
