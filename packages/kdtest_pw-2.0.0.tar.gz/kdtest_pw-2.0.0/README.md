# KDTest-Playwright

基于 Playwright 的关键字驱动测试框架，专为 Element Plus/Vue3 优化。

## 安装

```bash
# 从 PyPI 安装
pip install kdtest-pw

# 安装 Playwright 浏览器
playwright install chromium
```

## 快速开始

### 1. 创建配置文件 `parameters.json`

```json
{
    "testCaseFile": [
        {
            "caseFilePath": "testCases.xlsx",
            "caseItem": ["Sheet1"]
        }
    ],
    "browser": "chromium",
    "url": "http://localhost:8080",
    "headless": false,
    "timeout": 30000
}
```

### 2. 创建 Excel 测试用例

| 用例ID | 用例名称 | 描述 | 关键字 | 定位信息 | 操作值 |
|--------|----------|------|--------|----------|--------|
| TC001 | 登录测试 | | | | |
| | | 打开网站 | driver_get | | http://localhost |
| | | 输入用户名 | input_text | xpath | //input[@placeholder='账号'] | admin |
| | | 点击登录 | click_btn | css | .el-button--primary | |

### 3. 运行测试

```bash
# 命令行运行
kdtest-pw -c parameters.json

# 或在 Python 中使用
from kdtest_pw.cli import KDTestRunner

runner = KDTestRunner("parameters.json")
runner.setup()
runner.run()
runner.teardown()
```

## 核心关键字

### 浏览器操作
- `driver_get` - 导航到 URL
- `driver_back` - 后退
- `driver_refresh` - 刷新
- `driver_close` - 关闭页面

### 输入操作
- `input_text` - 输入文本（清除后输入）
- `input_append` - 追加输入
- `input_clear` - 清除输入

### 点击操作
- `click_btn` - 点击元素
- `double_click` - 双击
- `right_click` - 右键点击
- `hover` - 鼠标悬停

### 断言
- `text_assert` - 文本断言
- `title_assert` - 标题断言
- `element_visible_assert` - 可见性断言
- `element_count_assert` - 数量断言

### Element Plus 组件
- `el_select` - 下拉选择
- `el_datepicker` - 日期选择
- `el_dialog_confirm` - 对话框确认
- `el_table_click_row` - 表格行点击
- `el_tree_click_node` - 树节点点击
- `el_cascader` - 级联选择
- `el_upload` - 文件上传
- `el_form_input` - 表单输入

### 菜单导航
- `menu_load_data` - 加载菜单配置
- `menu_navigate` - 导航到菜单
- `menu_switch_iframe` - 切换 iframe
- `menu_exit_iframe` - 退出 iframe

## 变量和内置函数

### 变量引用
```
${varName}           # 从缓存获取
${self.param}        # 自定义参数
${env.NAME}          # 环境变量
```

### 内置函数
```
@today()             # 今天日期
@now()               # 当前时间
@random(1,100)       # 随机数
@random_phone()      # 随机手机号
@uuid()              # UUID
```

## 与 kdtest (Selenium) 的区别

| 特性 | kdtest (Selenium) | kdtest-pw (Playwright) |
|------|-------------------|------------------------|
| 浏览器驱动 | 需要下载 WebDriver | 内置浏览器 |
| 等待机制 | 显式/隐式等待 | 自动等待 |
| Element Plus | 需要额外处理 | 原生支持 |
| 多标签页 | 需要切换句柄 | 原生支持 |
| 录制回放 | 无 | 支持 Trace |
| 视频录制 | 无 | 原生支持 |

## License

MIT
