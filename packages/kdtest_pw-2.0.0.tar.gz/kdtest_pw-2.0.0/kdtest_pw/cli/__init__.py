"""CLI 模块"""

from .run import main, KDTestRunner

__all__ = ['main', 'KDTestRunner']
