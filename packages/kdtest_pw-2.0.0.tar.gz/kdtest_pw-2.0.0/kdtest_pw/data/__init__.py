"""数据模块"""

from .init_data import InitData

__all__ = ['InitData']
