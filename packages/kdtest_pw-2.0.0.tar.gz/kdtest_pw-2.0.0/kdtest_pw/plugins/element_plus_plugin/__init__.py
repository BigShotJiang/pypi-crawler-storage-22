"""Element Plus 内置插件"""

from .element_plus_plugin import ElementPlusPlugin

__all__ = ['ElementPlusPlugin']
