"""KDTest-Playwright 版本信息"""

__version__ = "2.0.0"
__author__ = "KDTest Team"
__description__ = "KDTest Playwright Edition - 关键字驱动测试框架"
