"""全局存储模块

提供全局变量存储，用于在模块间共享数据。
"""

from typing import Any, Dict, Optional

# 全局存储 - 核心组件引用
GSTORE: Dict[str, Any] = {
    'browser': None,      # Browser实例
    'context': None,      # BrowserContext实例
    'page': None,         # 当前Page实例
    'keyWord': None,      # KeyWordTest实例
}

# 全局系统数据存储
GSDSTORE: Dict[str, Any] = {
    'START': {},          # 启动参数
    'WORKPATH': {},       # 工作路径
}

# 模块数据存储 - 插件数据
MODULEDATA: Dict[str, Any] = {}

# 私有数据存储
PRIVATEDATA: Dict[str, Any] = {
    'PAGES': [],          # 多页面列表
    'ELEVALUE': {},       # 元素值缓存
    'CURRENT_CASE': None, # 当前用例名称
}

# 用例统计数据
CASESDATA: Dict[str, int] = {
    'total': 0,
    'passed': 0,
    'failed': 0,
    'skipped': 0,
}


def INFO(message: str, level: str = "INFO") -> None:
    """统一日志输出

    Args:
        message: 日志消息
        level: 日志级别 (INFO, WARNING, ERROR, DEBUG)
    """
    print(f"[{level}] {message}")


def get_global(key: str, default: Any = None) -> Any:
    """获取全局存储的值

    Args:
        key: 键名
        default: 默认值

    Returns:
        存储的值或默认值
    """
    return GSTORE.get(key, default)


def set_global(key: str, value: Any) -> None:
    """设置全局存储的值

    Args:
        key: 键名
        value: 值
    """
    GSTORE[key] = value


def get_element_value(key: str, default: Any = None) -> Any:
    """获取缓存的元素值

    Args:
        key: 键名
        default: 默认值

    Returns:
        缓存的元素值或默认值
    """
    return PRIVATEDATA['ELEVALUE'].get(key, default)


def set_element_value(key: str, value: Any) -> None:
    """设置元素值缓存

    Args:
        key: 键名
        value: 值
    """
    PRIVATEDATA['ELEVALUE'][key] = value


def clear_element_values() -> None:
    """清除所有元素值缓存"""
    PRIVATEDATA['ELEVALUE'].clear()
