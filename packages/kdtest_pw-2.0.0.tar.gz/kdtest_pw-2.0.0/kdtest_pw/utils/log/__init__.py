"""日志模块"""

from .logger import Logger
from .html_report import HtmlReporter

__all__ = ['Logger', 'HtmlReporter']
