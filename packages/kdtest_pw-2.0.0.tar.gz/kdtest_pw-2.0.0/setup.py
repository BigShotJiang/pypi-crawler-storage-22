"""KDTest-Playwright 安装配置"""

from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

# 读取版本
version = "2.0.0"

setup(
    name="kdtest-pw",
    version=version,
    author="KDTest Team",
    author_email="kdtest@example.com",
    description="KDTest Playwright Edition - 关键字驱动测试框架，专为 Element Plus/Vue3 优化",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/kdtest/kdtest-pw",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "kdtest_pw": [
            "data/static/*.json",
            "data/static/*.yaml",
            "data/static/*.xlsx",
            "plugins/element_plus_plugin/*.ini",
            "plugins/element_plus_plugin/elementData/*.yaml",
        ],
    },
    install_requires=[
        "playwright>=1.40.0",
        "openpyxl>=3.1.0",
        "PyYAML>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-playwright>=0.4.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "kdtest-pw=kdtest_pw.cli.run:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Testing",
    ],
    python_requires=">=3.8",
    keywords="testing, automation, playwright, keyword-driven, element-plus, vue3",
)
