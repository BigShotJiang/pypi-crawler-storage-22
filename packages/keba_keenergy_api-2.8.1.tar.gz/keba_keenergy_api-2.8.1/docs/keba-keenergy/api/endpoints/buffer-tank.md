# Buffer tanks

::: keba_keenergy_api.endpoints.BufferTankEndpoints
