# Hot water tanks

::: keba_keenergy_api.endpoints.HotWaterTankEndpoints
