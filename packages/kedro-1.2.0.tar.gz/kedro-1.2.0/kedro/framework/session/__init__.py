"""``kedro.framework.session`` provides access to KedroSession responsible for
project lifecycle.
"""

from .session import KedroSession

__all__ = ["KedroSession"]
