"""
This is a boilerplate pipeline '{{ cookiecutter.pipeline_name }}'
generated using Kedro {{ cookiecutter.kedro_version }}
"""

from kedro.pipeline import Node, Pipeline  # noqa


def create_pipeline(**kwargs) -> Pipeline:
    return Pipeline([])
