# Keeper Secrets Manager Helper

The Keeper Secrets Manager helper for creating and managing records. To be used with keeper-secrets-manager-core.

For more information see our official documentation page https://docs.keeper.io/secrets-manager/secrets-manager

## Recent Changes

### Version 1.0.7
- Updated dependency: `keeper-secrets-manager-core>=17.1.0` (includes fixes for CVE-2026-23949 and CVE-2026-24049)
