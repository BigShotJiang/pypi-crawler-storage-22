# -*- coding: utf-8 -*-

class FileSyntaxException(Exception):
    pass
