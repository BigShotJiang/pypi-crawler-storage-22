# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from Kekik.cli     import konsol, cikis_yap, hata_salla, log_salla, hata_yakala, bellek_temizle, temizle
from .pypi_kontrol import pypi_kontrol_guncelle