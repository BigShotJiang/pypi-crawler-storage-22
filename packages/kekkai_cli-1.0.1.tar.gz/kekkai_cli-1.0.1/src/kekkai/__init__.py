from __future__ import annotations

from .cli import main
from .output import VERSION

__version__ = VERSION
__all__ = ["main", "__version__"]
