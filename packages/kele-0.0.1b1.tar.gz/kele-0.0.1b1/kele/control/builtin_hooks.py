from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Protocol

from kele.utils import format_mapping

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from kele.grounder.grounded_rule_ds._nodes import _AssertionNode
    from kele.syntax import CompoundTerm, Constant, Rule, Variable, Assertion

logger = logging.getLogger(__name__)


class AssertionCheckHookMatch(Protocol):
    """the protocol of output func (on_match in register_assertion_check_hook) in assertion check hook"""
    def __call__(self, rule: Rule, assertion: Assertion, combination: dict[Variable, Constant | CompoundTerm], *, result: bool) \
            -> None: ...  # noqa: D102


def register_assertion_check_hook(
    *,
    rule_name: str | None = None,
    vars_filter: Mapping[str, str] | None = None,
    on_match: AssertionCheckHookMatch | None = None,
    break_on_match: bool = False,
) -> None:
    """
    Register a built-in hook that observes assertion check results.

    This is a user-facing inspection hook: it lets you capture whether a specific
    assertion evaluation (for a given variable binding) is True/False, and optionally
    stop on matches for deep debugging.

    Example:
        def log_match(rule, assertion, combination, result):
            print(rule.name, assertion.content, combination, result)

        register_assertion_check_hook(
            rule_name="rule_3",
            vars_filter={"p1": "f", "p2": "a", "p13": "b", "p14": "c"},
            on_match=log_match,
            break_on_match=True,
        )
    """
    normalized_vars_filter = dict(vars_filter) if vars_filter is not None else None

    def _hook(
        *,
        rule: Rule,
        assertion: _AssertionNode,
        combination: dict[Variable, Constant | CompoundTerm],
        result: bool,
    ) -> None:
        if rule_name and rule.name != rule_name:
            return

        combination_str = {str(k): str(v) for k, v in combination.items()}
        if normalized_vars_filter:
            for key, value in normalized_vars_filter.items():
                if combination_str.get(key) != str(value):
                    return

        if on_match is None:
            logger.debug(
                "Assertion check hook: rule=%s content=%s combination=%s result=%s",
                rule,
                assertion.content,
                format_mapping(combination_str),
                result,
            )
        else:
            on_match(rule, assertion.content, combination, result=result)

        if break_on_match:
            breakpoint()  # noqa: T100

    from kele.grounder import GroundedRule  # noqa: PLC0415

    GroundedRule.register_class_hook("assertion_check", _hook)


class BuiltinHookEnabler:
    """
    Enabler for built-in hooks by name.

    This class does not register hooks by itself. Create an instance and call
    ``enable`` to attach a built-in hook to every grounded rule instance.

    Example:
        hooks = BuiltinHookEnabler()
        hooks.enable(
            "assertion_check",
            rule_name="rule_3",
            vars_filter={"p1": "f"},
        )
    """

    def __init__(self) -> None:
        self._hooks: dict[str, Callable[..., None]] = {
            "assertion_check": register_assertion_check_hook,
        }

    def available_hooks(self) -> list[str]:
        """
        Return the names of available built-in hooks.
        """
        return sorted(self._hooks)

    def enable(self, name: str, **kwargs: object) -> None:
        """
        Enable a built-in hook by name.
        """
        if name not in self._hooks:
            raise KeyError(f"Unknown built-in hook: {name}")
        self._hooks[name](**kwargs)

    def enable_many(self, names: list[str], **kwargs: object) -> None:
        """
        Enable multiple built-in hooks by name.
        """
        for hook_name in names:
            self.enable(hook_name, **kwargs)
