## 默认strategy

### SequentialCyclic
按顺序逐个选择规则，每次选1条。

### SequentialCyclicWithPriority
根据规则的priority排序后，按顺序逐个选择规则，每次选1条。

## 创建自己的strategy
1. 创建一个py文件，命名要求为`_<name>_strategy.py`；
2. 继承RuleSelectionStrategy类，并至少声明此Protocol要求的函数；
3. 从`kele.control`导入并使用`@register.rule_selector('<name>')`注册你的策略类，后续即可通过`grounding_rule_strategy`使用策略；
4. 注意调整`grounding_rule_strategy`的类型标注（增加Literal的候选值）。

示例：
```python
from kele.control import register
from kele.control.grounding_selector._rule_strategies.strategy_protocol import RuleSelectionStrategy


@register.rule_selector("MyRuleStrategy")
class MyRuleStrategy:
    def __init__(self) -> None:
        self._rules = []

    def set_rules(self, rules):
        self._rules = list(rules)

    def reset(self) -> None:
        self._rules = []

    def select_next(self):
        return self._rules[:1]

    def on_feedback(self, feedback):
        return None
```
