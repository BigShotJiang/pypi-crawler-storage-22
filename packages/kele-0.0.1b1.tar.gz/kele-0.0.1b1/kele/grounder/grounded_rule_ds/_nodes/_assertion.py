from __future__ import annotations

import logging
from functools import partial, reduce
from itertools import product
from typing import TYPE_CHECKING, cast

import polars as pl

from kele.syntax import Assertion, CompoundTerm, Concept, Constant, FlatCompoundTerm, Variable

from ._conn import _ConnectiveNode
from ._tftable import TfTables
from ._tupletable import _TupleTable

if TYPE_CHECKING:
    from kele.syntax.base_classes import GROUNDED_TYPE
    from collections.abc import Generator

    from kele.grounder import GroundedRule
    from kele.syntax import TERM_TYPE

    from ._rule import _RuleNode

logger = logging.getLogger(__name__)


class _AssertionPastTable:
    """Store and query per-Assertion past tables.

    We separate past tables into three parts:
    - true:    checked and evaluated to True
    - unknown: not checked yet
    - false:   checked and evaluated to False (store depends on keep_table)

    Semi-naive should use: kept_checked_past (decided by keep_table) + unknown.
    """

    def __init__(self, *, column_name: tuple[Variable, ...]) -> None:
        # Checked-and-true bindings accumulated across rounds; used by semi-naive.
        self.true: _TupleTable = _TupleTable(column_name=column_name)
        # Not-checked-yet bindings; updated in update(), used by get_semi_naive_past_table().
        self.unknown: _TupleTable = _TupleTable(column_name=column_name)
        # Checked-and-false bindings accumulated across rounds; stored only if keep_table allows.
        self.false: _TupleTable = _TupleTable(column_name=column_name)

    def update(
        self,
        *,
        keep_table: bool | None,
        new_grounding_table: _TupleTable,
        checked_grounding_table: _TupleTable,
        checked_true_grounding_table: _TupleTable,
        checked_false_grounding_table: _TupleTable,
    ) -> None:
        """Update past tables after one `exec_check()` round."""
        # unknown: add new, then remove items checked in this round
        self.unknown = (self.unknown.concat_table(new_grounding_table).
                        anti_join(checked_grounding_table))

        # true/false are stored based on keep_table, used later in get_semi_naive_past_table().
        if self._should_store_true(keep_table=keep_table):
            self.true = self.true.concat_table(checked_true_grounding_table)

        if self._should_store_false(keep_table=keep_table):
            self.false = self.false.concat_table(checked_false_grounding_table)

    def get_semi_naive_past_table(self, *, keep_table: bool | None) -> _TupleTable:
        """单独拎出来是因为此刻的设计方案（先semi join再exec check）时存在unknown。
        但如果先exec check再semi join，将不需要unknown。为了这一步，所以单独设计一个get_semi_naive的函数，
        以在可能需要的时候决定保留or移除concat unknown
        """
        # checked part (true/false) is filtered by keep_table, then unioned with unknown.
        return (self._kept_checked(self.true, self.false, keep_table=keep_table).
                        concat_table(self.unknown))

    @staticmethod
    def _should_store_false(*, keep_table: bool | None) -> bool:
        # keep_table=True: only True is needed -> False past can be dropped
        # keep_table=False/None: False part is needed -> store it
        return keep_table is None or keep_table is False

    @staticmethod
    def _should_store_true(*, keep_table: bool | None) -> bool:
        # True part is needed if keep_table is True or not specified.
        return keep_table is None or keep_table is True

    @staticmethod
    def _kept_checked(true_table: _TupleTable, false_table: _TupleTable, *, keep_table: bool | None) -> _TupleTable:
        # Choose which checked part(s) to expose for semi-naive usage.
        if keep_table is True:
            return true_table
        if keep_table is False:
            return false_table
        # keep_table is None: keep both
        return true_table.concat_table(false_table)


class _AssertionNode:
    """
    负责断言节点的 join 与 check 执行。

    - join：合并来自 term 节点的变量候选表；
    - check：基于当前断言的候选表执行真假判断；
    - action assertion：计算 action term 并将结果写回事实。
    """

    def __init__(self, content: Assertion,
                 grounded_rule: GroundedRule,
                 *,
                 negated_assertion: bool) -> None:

        self.content: Assertion = content
        self.rule_or_connective_children: list[_ConnectiveNode | _RuleNode] = []  # 亦或者应该统一叫children，然后不要next_node函数。  # 我们此刻的图
        # 这里不是list，就是一个ConnectiveNode，但考虑到共享不妨留一下。另外init里估计要传这个参数
        # 还需要一个标记是否有匹配结果的标记符
        self.grounded_rule = grounded_rule
        self._is_concept_compatible = partial(
            Concept.is_compatible,
            fuzzy_match=self.grounded_rule.args.grounder.conceptual_fuzzy_unification,
        )
        # TODO: Consider refactoring concept-compatibility configuration for cleaner ownership.

        self.tf_table: TfTables
        self.all_freevar_table: list[_TupleTable] = []
        self._freevar_table: _TupleTable
        self.grounding_arguments: set[Variable]
        self._action_result: list[Assertion] = []  # FIXME: 这里返回的是含有action_op的Assertion，后续有待进一步讨论这里的格式

        if negated_assertion:
            # 否定assertion的初始化
            self.grounding_arguments = set()
            self.action_assertion = self.content.is_action_assertion
        elif self.content.is_action_assertion:
            # 非否定但是action_assertion的初始化
            self.action_assertion = True
            self.grounding_arguments = set()
            for term in (content.lhs, content.rhs):
                if not term.is_action_term:
                    self.grounding_arguments.update(term.free_variables)
        else:
            # 其他情况的初始化
            self.action_assertion = False
            self.grounding_arguments = set(self.content.free_variables)
        self.past_freevar_table: _AssertionPastTable = _AssertionPastTable(column_name=tuple(self.grounding_arguments))
        # 过往freevar_table，每次都会通过concat将当前freevar_table加入记忆中

        self.keep_table: bool | None = None  # 基于SAT solver的结果，确定需要保留的table
        # true 保留true table, false保留false table，None表示均保留
        self.negated_assertion: bool = negated_assertion  # 记录了当前assertion是否被not算子影响。
        # 受到not算子影响的Assertion不会进入grounding, join流程，也不会建立CompoundTerm节点
        # 记录了最后合并得到的大表/待检查表
        self.to_be_check_table: _TupleTable | None = None
        self.total_table: _TupleTable | None = None

        self._freevar_table_sig: tuple[tuple[int, int], ...] | None = None

    def __str__(self) -> str:
        return str(self.content)

    def add_child(self, node: _ConnectiveNode | _RuleNode) -> None:
        self.rule_or_connective_children.append(node)

    def _exec_join(self) -> _TupleTable:
        """
        内部 join：合并来自子节点的候选表，并缓存到 _freevar_table。

        该函数只应在有 grounding arguments 的节点上触发；因此 all_freevar_table 为空视为错误。
        """
        if not self.all_freevar_table:
            raise ValueError("Assertion node join requires non-empty all_freevar_table.")

        merged = reduce(lambda x, y: x.union_table(y), self.all_freevar_table)
        merged = self._drop_invalid_bindings(merged)
        self._freevar_table = merged
        if logger.isEnabledFor(logging.DEBUG):
            input_summaries = [table.debug_summary() for table in self.all_freevar_table]
            logger.debug(
                "Assertion node merged freevar tables: assertion is '%s' inputs=%s merged=%s",
                self.content,
                input_summaries,
                self._freevar_table.debug_summary(),
            )

        return self._freevar_table

    @property
    def freevar_table(self) -> _TupleTable:
        """
        Lazy join：访问时根据 all_freevar_table 是否变化决定是否重新 join。
        """
        sig = tuple((id(t), t.version) for t in self.all_freevar_table)  # 关于这里只用id不行的原因： clear操作是原地的，
        # 可能和term的freevar_table有关（我倒也没仔细确认，但应该比较合理）
        if sig != self._freevar_table_sig:
            self._exec_join()
            self._freevar_table_sig = sig
        return self._freevar_table

    def exec_check(self) -> None:
        """
        检查每个可能的赋值，并传递 true/false 索引表。
        """
        # 对于无变量的assertion而言，只需要判断和传递自身的True/False
        if not self.content.free_variables:
            self._check_self()  # 判断当前assertion是否为真
            return

        small_table = self._get_correct_small_table()
        # TODO: 本意希望将exec_action的执行放在这里，但此时由于action是分先后两轮的，不太方面在exec_check获取，因此暂时还是得在grounded class里面写

        tf_list: list[bool] = []

        for combination in small_table.iter_rows():
            result = (
                self._check_single_action_assertion(combination)
                if self.action_assertion
                else self._check_single(combination)
            )

            self.grounded_rule.run_hooks(  # HACK: 这里也许有更利于编译器优化的写法，比如某个if statement，以期可以直接删除这一段
                "assertion_check",
                rule=self.grounded_rule.rule,
                assertion=self,
                combination=combination,
                result=result,
            )

            tf_list.append(result)

        true_table, false_table = small_table.get_true_false_table(tf_list, keep_table=self.keep_table)

        self.tf_table = TfTables(true=true_table, false=false_table)

        if not self.only_substitution:
            # tf index 仅增加一致性检查；这里记录完整的 past。
            self._update_past_freevar_table(small_table, true_table, false_table)

    def get_semi_naive_past_table(self) -> _TupleTable:
        """Return past table used by semi-naive: (kept checked) + unknown.

        - checked part is selected by keep_table: True / False / (True+False)
        - unknown always participates
        """
        return self.past_freevar_table.get_semi_naive_past_table(keep_table=self.keep_table)

    def exec_action(self, binding_table: _TupleTable) -> None:
        """
        执行 action 操作，将结果写入 _action_result。

        :param binding_table: 当前 assertion 实例化后的变量绑定表
        :type binding_table: _TupleTable
        """
        for combination in binding_table.iter_rows():
            if isinstance(self.content.lhs, CompoundTerm) and self.content.lhs.is_action_term:
                replaced_lhs = self.content.lhs.replace_variable(combination)
                value = self._exec_implement_func(replaced_lhs)
                if value is not None:
                    self._action_result.append(Assertion.from_parts(replaced_lhs, value))  # 记录计算出来的值，这个值将在后续加入事实库中

            if isinstance(self.content.rhs, CompoundTerm) and self.content.rhs.is_action_term:
                replaced_rhs = self.content.rhs.replace_variable(combination)
                value = self._exec_implement_func(replaced_rhs)
                if value is not None:
                    self._action_result.append(Assertion.from_parts(replaced_rhs, value))  # 记录计算出来的值，这个值将在后续加入事实库中

    def _check_self(self) -> None:
        """
        对于无变量的assertion而言，检查自身是否为真。

        :raise ValueError: grounding_arguments不为空时，combination不能为None
        """
        empty_table = _TupleTable(column_name=tuple(self.content.free_variables))  # check操作是验证assertion实例化正确性的，
        # 需要和assertion本身相关的变量。而grounding_arguments则用于判断参与unify过程的判断

        if self.grounding_arguments:
            raise ValueError("Assertion with grounding arguments must be checked with combination")

        check_result = self._ask_equivalence(self.content) or self._ask_sk_system(self.content)

        if check_result and (self.keep_table is None or self.keep_table is True):  # 如果为真，且当前Assertion也有为真的解释，则保留
            self.tf_table = TfTables(true=_TupleTable.create_empty_table_with_emptyset(), false=empty_table)
            # 保留用空列的table表示，即不参与table的运算。
            # 因此空列table与其他table做cross时，将直接返回另一个table。不保留则用空行table表示，因为空行意味着某个变量组合没有合法替换方案。
        elif not check_result and (self.keep_table is None or self.keep_table is False):
            self.tf_table = TfTables(true=empty_table, false=_TupleTable.create_empty_table_with_emptyset())
        else:
            # 如果keep_table与自身检查结果不匹配（例如自身为True，但是keep_table为False），那么两个表都是空
            self.tf_table = TfTables(true=empty_table, false=empty_table)

        self.grounded_rule.run_hooks(  # HACK: 这里也许有更利于编译器优化的写法，比如某个if statement，以期可以直接删除这一段
            "assertion_check",
            rule=self.grounded_rule.rule,
            assertion=self,
            combination={},
            result=check_result,
        )

    def _exec_implement_func(self, term: CompoundTerm) -> CompoundTerm | Constant | None:
        """
        给定 action_term 计算结果并返回。
        """
        implement_func = term.operator.implement_func
        if implement_func is None:
            return None

        equivalence = self.grounded_rule.equivalence

        candidate_arguments: list[list[GROUNDED_TYPE]] = []
        for arg in term.arguments:
            if TYPE_CHECKING:
                arg = cast("CompoundTerm | Constant", arg)
            equiv_items = list(equivalence.get_equiv_item(arg))
            candidate_arguments.append(equiv_items)  # 这里get_equiv_item已经把元素自身加入进去了，同时去重操作也已经进行过了
        # 获得符合条件的所有参数的组合（写成list[list[TERM_TYPE]]，每个list对应每个参数的的equiv_items）

        for arguments in product(*candidate_arguments):
            candidate_term = FlatCompoundTerm.from_parts(term.operator, arguments)
            try:
                result = implement_func(candidate_term)
                if TYPE_CHECKING:
                    result = cast("CompoundTerm | Constant", result)
            except TypeError:  # HACK: 这里except TypeError的实质是处理无法计算的情况，将在进一步确定implement_func的格式之后修改这里的代码
                continue  # 如果计算失败，尝试下一个参数组合，否则将会直接返回结果
            else:
                return result

        return None

    def _check_single_action_assertion(self, combination: dict[Variable, Constant | CompoundTerm]) -> bool:
        """执行 action assertion：先计算 action term，再进行真假判断。"""
        assertion = self.content.replace_variable(combination)
        if isinstance(assertion.lhs, CompoundTerm) and assertion.lhs.is_action_term:
            value = self._exec_implement_func(assertion.lhs)
            if value is not None:
                assertion = Assertion.from_parts(value, assertion.rhs)
            # value为None时，意味着implement_func无法计算，此时不再替换assertion.lhs

        if isinstance(assertion.rhs, CompoundTerm) and assertion.rhs.is_action_term:
            value = self._exec_implement_func(assertion.rhs)
            if value is not None:
                assertion = Assertion.from_parts(assertion.lhs, value)

        return self._ask_equivalence(assertion) or self._ask_sk_system(assertion)

    def _check_single(self, combination: dict[Variable, Constant | CompoundTerm]) -> bool:
        """
        对实例化候选进行检查，并返回真假结果。TODO: 暂且没有和GroundedRule交互用到一些缓存，以后可以优化

        :param combination: 变量替换表
        """
        assertion = self.content.replace_variable(combination)
        # 变量表，每个Variable只用唯一一个指针的话，这里的时空开销会更低，不过并行难度会加大。但暂时这个级别的优化似乎意义不大
        if self._ask_equivalence(assertion):
            return True
        if self._ask_sk_system(assertion):  # noqa: SIM103
            return True

        return False

    def _drop_invalid_bindings(self, table: _TupleTable) -> _TupleTable:
        """
        移除 concept mismatch 的绑定，避免将不合法的替换传播到 join/check。
        极致优化时可考虑在 exec_check 中惰性过滤以减少重复 replace，但易引入错误。
        """
        if table.height == 0:
            return table

        lhs = self.content.lhs
        rhs = self.content.rhs

        if not isinstance(lhs, Variable) or not isinstance(rhs, Variable):  # 如果有非变量的，说明它被约束了，不需要单独drop
            return table

        if self.grounded_rule.rule.get_variable_concept_constraints(lhs) or \
            self.grounded_rule.rule.get_variable_concept_constraints(rhs):  # 如果变量本身含约束，也不需要单独drop。且任一含就都含
            return table

        valid_mask: list[bool] = []
        for combination in table.iter_rows():
            lhs_concepts = self._binding_concepts(lhs, combination)
            rhs_concepts = self._binding_concepts(rhs, combination)
            valid_mask.append(self._is_concept_compatible(lhs_concepts, rhs_concepts))

        if all(valid_mask):
            return table

        table.make_table_ready()
        filtered_table = _TupleTable(table.raw_column)
        mask_series = pl.Series(valid_mask, dtype=pl.Boolean)
        filtered_table.set_base_df(table.base_df.filter(mask_series))
        return filtered_table

    @staticmethod
    def _binding_concepts(
        term: Constant | CompoundTerm | Variable,
        combination: dict[Variable, Constant | CompoundTerm],
    ) -> set[Concept]:
        if isinstance(term, Variable):
            bound = combination[term]
            return _AssertionNode._binding_concepts(bound, combination)
        if isinstance(term, Constant):
            return term.belong_concepts
        return {term.operator.output_concept}

    def _ask_equivalence(self, assertion: Assertion) -> bool:
        """查询等价关系是否能证明该断言成立。"""
        return (self.grounded_rule.equivalence is not None and
                self.grounded_rule.equivalence.query_equivalence(assertion))

    def _ask_sk_system(self, assertion: Assertion) -> bool:
        return (self.grounded_rule.sk_system_handler is not None and
                len(self.grounded_rule.sk_system_handler.query_assertion(assertion)) > 0)

    def _update_past_freevar_table(self,
                                   checked_grounding_table: _TupleTable,
                                   checked_true_grounding_table: _TupleTable,
                                   checked_false_grounding_table: _TupleTable) -> None:
        new_grounding_table = self.freevar_table  # cur_new_table.
        # 这里需要单独取一次，因为上面small_table是针对content.free_vars，用于替换的，且可能经过了一致性去重；
        # 原则上这里可以取self.freevar_table.get_small_table(tuple(self.grounding_arguments))，但这俩应该是一样的

        self.past_freevar_table.update(
            keep_table=self.keep_table,
            new_grounding_table=new_grounding_table,
            checked_grounding_table=checked_grounding_table,
            checked_true_grounding_table=checked_true_grounding_table,
            checked_false_grounding_table=checked_false_grounding_table,
        )

        # 注：self.past_freevar_table = self.past_freevar_table.concat_table(self.freevar_table)  # HACK: 存past的时候，
        # 就可以区分T/F，因为一般来说，潜在的新事实的atom term是会被取出的旧的，False事实的组合不太需要考虑（不过严谨来说，也是根据
        # keep_table参数决定的，因为False事实可能起到True的作用。但是如果考虑False事实的时候，这里要注意False是需要二次check的，
        # True不需要，直接semi。好的一面是，False转True的时候，相关事实会在new里面被取出，所以可能False的二次check，可以直接改为
        # False部分需要anti new）

    def broadcast_total_table(self, total_table: _TupleTable) -> None:
        """
        广播 total_table，为规则级别的变量候选总表。

        :params: total_freevar (_TupleTable)
        """
        self.total_table = total_table

    def query_for_children(self, term: TERM_TYPE | CompoundTerm | None = None) -> Generator[_ConnectiveNode | _RuleNode]:
        """
        Yields:
            ConnectiveNode | RuleNode: 跳转到下一级节点，对应嵌套的ConnectiveNode或最终的RuleNode
        """
        yield from self.rule_or_connective_children

    def pass_tf_index(self, table: _TupleTable | None = None) -> None:
        """
        传递自身节点的 true/false table 到子节点。
        """
        # 在一次传递之后，立即移除本身的tf_indexs，防止反复执行时重复传递
        if table is not None:  # HACK: 这一处改动的原因是：此时exec_check在total table前面，将导致self.tf_tables里面其实并没有
            # 记录total table的所有问题，而只是相当于new_table的部分，会漏解，似乎只会导致non-action grounding nodes出问题
            # 因为action grounding的确获得了non...nodes的total，而它里面本来还有一次union freevars_table的操作，但是past
            # freevars似乎还是不免需要的？反正我还是也把total传进去了
            # 而substitution本来用的就是total
            small_table = table.get_small_table(tuple(self.content.free_variables))
            if self.keep_table is True:
                empty_table = _TupleTable(small_table.raw_column)
                self.tf_table = TfTables(true=small_table, false=empty_table)
            elif self.keep_table is False:
                empty_table = _TupleTable(small_table.raw_column)
                self.tf_table = TfTables(true=empty_table, false=small_table)
            else:
                raise NotImplementedError("pass_tf_index with table and keep_table=None is not implemented yet.")

        for child in self.query_for_children():
            if not hasattr(child, "left_table"):
                child.left_table = self.tf_table
            elif isinstance(child, _ConnectiveNode):
                child.right_table = self.tf_table
        del self.tf_table

    def get_action_result(self) -> Generator[Assertion]:
        """
        获取 action assertion 计算得到的结果。

        :yield: 执行的结果
        :rtype: Assertion
        """
        yield from self._action_result
        self._action_result.clear()

    @property
    def ready_to_execute(self) -> bool:
        """
        AssertionNode 总是执行队列中的起点，因此始终处于 ready 状态。
        """
        return True

    @property
    def only_substitution(self) -> bool:
        """
        TODO：safety稳定后更新注释
        """
        return self.negated_assertion or not self.grounding_arguments

    def get_all_children(self) -> Generator[_ConnectiveNode | _RuleNode]:
        yield from self.rule_or_connective_children

    def _get_correct_small_table(self) -> _TupleTable:
        # Domain to check in this round (broadcast by GroundedRule):
        # - to_be_check_table: semi join output for non-action / action grounding nodes（预留）
        # - total_table: action/substitution nodes使用
        # - freevar_table: 无semi join时的non-action grounding节点 fallback

        if self.to_be_check_table is not None:
            small_table = self.to_be_check_table  # 默认已经取过free_variables了
        elif self.total_table is not None:
            replaced_variables = set(self.content.free_variables) & set(self.total_table.raw_column)
            small_table = self.total_table.get_small_table(tuple(replaced_variables))  # TODO: 这里封装有待提高，replaced_variables怪怪的
            # 这里replaced其实是action term的variables + 可能有可能没有的 其他term的variables
        else:
            small_table = self.freevar_table.concat_table(self.past_freevar_table.unknown)  # TODO: 长远来看，这里concat的是
            # unknown里面能通过semi naive的部分

        if self.action_assertion and not self.only_substitution:  # HACK: 这里有个小问题是：无free_var也算only_substitution，
            # 而不是自然兼容空列的table
            small_table = small_table.union_table(self.freevar_table)  # .concat_table(self.past_freevar_table.unknown)
            # 如果有to be check的话，这里也应该union这个
            # HACK: 这里还存在一些问题需要后续优化。比如action nodes每个独立进行union似乎并不优雅（虽然可以看做是每个action assertion
            # 独立unification之后，似乎在term level合并时也的确就是独立union）
            # 另一方面，action并没有记录历史的匹配，只记录了grounding arguments，导致其不易concat unknown，这在后续加入semi join
            # 的时候需要谨慎对待

        return small_table

    def reset(self) -> None:
        self.to_be_check_table = None
        self.total_table = None
        if hasattr(self, 'tf_table'):
            del self.tf_table

        self.all_freevar_table.clear()
