# Contributing

Thank you for taking the time to contribute to this project!

## Code of Conduct

This project adheres to the Contributor Covenant [code of conduct](CODE_OF_CONDUCT.md).
By participating, you are expected to uphold this code.
Please report unacceptable behavior to the [kFinance Maintainers](kfinance-maintainers@kensho.com).

## Style Guide

https://google.github.io/styleguide/pyguide.html
