# Kenya Address Parser

Parse Kenyan addresses into structured data.

## Installation 

```bash
$ pip install pycounts
```

## Usage

`kenya-address-parser` is used to parse informal, descriptive Kenyan addresses **(e.g., "Kileleshwa, behind Shell")** and convert them into standardized formats for databases.

## Contributing

Interested in contributing? Check out the contributing guidelines. 
Please note that this project is released with a Code of Conduct. 
By contributing to this project, you agree to abide by its terms.


### `CONDUCT.md`
Use the Contributor Covenant (standard in open source). (Don’t overthink it.)

# Security Policy

## Reporting a Vulnerability
Please do not open public issues for security reports.
Email: hello@kenmwangi.com
We will respond as soon as possible.


## License

- MIT

`kenya-address-parser` was created by Ken Mwangi. It is licensed under the terms
of the MIT license.

## Credits