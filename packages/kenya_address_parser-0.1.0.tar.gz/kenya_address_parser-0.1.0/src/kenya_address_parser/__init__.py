def hello() -> str:
    return "Hello from kenya-address-parser!"
