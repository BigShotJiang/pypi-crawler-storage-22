from keplemon._keplemon.exceptions import (  # type: ignore
    SAALError,
)

__all__ = ["SAALError"]
