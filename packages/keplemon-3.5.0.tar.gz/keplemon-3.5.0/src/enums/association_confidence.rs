#[derive(Debug, Clone, Copy, PartialEq)]
pub enum AssociationConfidence {
    High,
    Medium,
    Low,
}
