"""SAM3 model preset configurations."""

# Metadata for loading pretrained model weights.
backbone_presets = {}
