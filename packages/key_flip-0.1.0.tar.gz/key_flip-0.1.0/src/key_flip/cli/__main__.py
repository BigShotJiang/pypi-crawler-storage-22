import typer


def main() -> None:
    pass


if __name__ == "__main__":
    typer.run(main)
