key-transform
=============

Transforms an OpenPGP key to PKCS#8 and OpenSSH key format.

Supports RSA, ECDSA and ED25519 keys.

## Installation

Install via pipx or uv tool

```shell
uv tool install key-transform
# OR
pipx install key-transform
```

## Usage

```shell
# Lookup secret key(s) and note key fingerprint
gpg -K
~/.gnupg/pubring.kbx
-------------------------------------------------------------
sec   ed25519 2026-02-06 [SC]
      972ACF51A09C0259060CFA035432496985998071
uid           [ultimate] Test Key <test@example.com>
ssb   cv25519 2026-02-06 [E]
ssb   rsa3072 2026-02-06 [A]
ssb   ed25519 2026-02-06 [A]
ssb   nistp256 2026-02-06 [A]

# Export the key
gpg --export-secret-key 972ACF51A09C0259060CFA035432496985998071 > secret_key.gpg

# Transform the key, output will be PKCS#8 and OpenSSH format
key-transform transform secret_key.gpg

#################### PGP Private Key 3F745041AAFE4699CB6FB57F3E311D69E96ADFDD RSAEncryptOrSign 3072 ####################
# SSH Pubkey:
ssh-rsa AAAAB3NzaC1yc2[...]

# PKCS8 Private Key:
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIHdTBfBgkqhkiG9w0BBQ0wUjAxBgkqhkiG9w0BBQwwJAQQmv1ATOwwehUv7yd6
[...]
Nu6faDf4tiJQCfrBP0OL8Rt4yJTSHk79IZe8tysYfYVc01jl119v3Cc=
-----END ENCRYPTED PRIVATE KEY-----

# OpenSSH Private Key:
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAACmFlczI1Ni1jdHIAAAAGYmNyeXB0AAAAGAAAABC4U2kyj10gkOYW
[...]
OxarmihrTQIcdQpD0Ts1NrV9A/eg3Pua+FRmuVVzfY+fT8bP5+ztIQ5SDmcxmDwNLGDY5vD6jcR0
q2Sf5Fl7k1uKj1QmPA==
-----END OPENSSH PRIVATE KEY-----

########################################################################################################################
############### PGP Private Key 82080A5C69729B254E767F10030959F32C2268B7 EdDSA EllipticCurveOID.Ed25519 ################
# SSH Pubkey:
ssh-ed25519 AAAAC3Nza[...]

# PKCS8 Private Key:
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIGjMF8GCSqGSIb3DQEFDTBSMDEGCSqGSIb3DQEFDDAkBBB+N0mJLilE1jtYvYNO
[...]
FmvKKIRiopWgsjUIgcPLRyoDWLdzKg==
-----END ENCRYPTED PRIVATE KEY-----

# OpenSSH Private Key:
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAACmFlczI1Ni1jdHIAAAAGYmNyeXB0AAAAGAAAABCUuri5leG0RFKe
[...]
K5+JAItSAMQnM9LV5g4PT6nn56VtsSaM3dF+PM0lSoeJDNkR/6pZ7LLyphCwKQ==
-----END OPENSSH PRIVATE KEY-----

########################################################################################################################
############## PGP Private Key 963E77E42934A3BD5EDB2139527CD0C853415507 ECDSA EllipticCurveOID.NIST_P256 ###############
# SSH Pubkey:
ecdsa-sha2-nistp256 AAAAE2VjZH[...]

# PKCS8 Private Key:
-----BEGIN ENCRYPTED PRIVATE KEY-----
MIH0MF8GCSqGSIb3DQEFDTBSMDEGCSqGSIb3DQEFDDAkBBA1GnMpIItB3JYv51b9
[...]
PZn5p3E77Q==
-----END ENCRYPTED PRIVATE KEY-----

# OpenSSH Private Key:
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAACmFlczI1Ni1jdHIAAAAGYmNyeXB0AAAAGAAAABCqT2tcZRsyufkT
[...]
bg==
-----END OPENSSH PRIVATE KEY-----

########################################################################################################################
```
