from __future__ import annotations

from typing import IO

import click
import pgpy
import pgpy.constants
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    BestAvailableEncryption,
    Encoding,
    PrivateFormat,
    PublicFormat,
)
from pgpy.constants import KeyFlags


class TransformError(Exception):
    pass


@click.group(context_settings={"max_content_width": 120})
def cli() -> None:
    pass


def output_ssh_key(
    pgp_key: pgpy.PGPKey, key: ec.EllipticCurvePrivateKey | Ed25519PrivateKey | rsa.RSAPrivateKey, export_password: str
) -> None:
    pubkey = key.public_key()
    pubkey_format = pubkey.public_bytes(encoding=Encoding.OpenSSH, format=PublicFormat.OpenSSH)
    privkey_format_pkcs8 = key.private_bytes(
        encoding=Encoding.PEM,
        format=PrivateFormat.PKCS8,
        encryption_algorithm=BestAvailableEncryption(export_password.encode()),
    )
    privkey_format_openssh = key.private_bytes(
        encoding=Encoding.PEM,
        format=PrivateFormat.OpenSSH,
        encryption_algorithm=BestAvailableEncryption(export_password.encode()),
    )
    print(f" PGP Private Key {pgp_key.fingerprint} {pgp_key.key_algorithm.name} {pgp_key.key_size!s} ".center(120, "#"))
    print(f"# SSH Pubkey:\n{pubkey_format.decode('ascii')}\n")
    print("# PKCS8 Private Key:")
    print(privkey_format_pkcs8.decode("ascii"))
    print("# OpenSSH Private Key:")
    print(privkey_format_openssh.decode("ascii"))
    print("#" * 120)


def _transform_ecdsa(privkey: pgpy.PGPKey) -> ec.EllipticCurvePrivateKey:
    keymaterial = privkey.__key__
    return ec.derive_private_key(keymaterial.s, keymaterial.oid.curve())


def _transform_ed25519(privkey: pgpy.PGPKey) -> Ed25519PrivateKey:
    keymaterial = privkey.__key__
    return Ed25519PrivateKey.from_private_bytes(keymaterial.p.x)


def _transform_rsa(privkey: pgpy.PGPKey) -> rsa.RSAPrivateKey:
    keymaterial = privkey.__key__
    dmp1 = rsa.rsa_crt_dmp1(keymaterial.d, keymaterial.p)
    dmq1 = rsa.rsa_crt_dmq1(keymaterial.d, keymaterial.q)
    iqmp = rsa.rsa_crt_iqmp(keymaterial.p, keymaterial.q)
    public_numbers = rsa.RSAPublicNumbers(e=keymaterial.e, n=keymaterial.n)
    privkey_numbers = rsa.RSAPrivateNumbers(
        p=keymaterial.p,
        q=keymaterial.q,
        d=keymaterial.d,
        dmp1=dmp1,
        dmq1=dmq1,
        iqmp=iqmp,
        public_numbers=public_numbers,
    )
    return privkey_numbers.private_key()


def parse_subkeys(privkey: pgpy.PGPKey, export_password: str) -> None:
    for k in privkey.subkeys.values():
        for sig in k.self_signatures:
            if KeyFlags.Authentication in sig.key_flags:
                if k.key_algorithm == pgpy.constants.PubKeyAlgorithm.ECDSA:
                    output_ssh_key(k, _transform_ecdsa(k), export_password)
                elif (
                    k.key_algorithm == pgpy.constants.PubKeyAlgorithm.EdDSA
                    and k.key_size == pgpy.constants.EllipticCurveOID.Ed25519
                ):
                    output_ssh_key(k, _transform_ed25519(k), export_password)
                elif k.key_algorithm in [
                    pgpy.constants.PubKeyAlgorithm.RSAEncryptOrSign,
                    pgpy.constants.PubKeyAlgorithm.RSAEncrypt,
                    pgpy.constants.PubKeyAlgorithm.RSASign,
                ]:
                    output_ssh_key(k, _transform_rsa(k), export_password)


@cli.command()
@click.argument("pgp-key", type=click.File("rb"))
@click.option(
    "--export-password",
    prompt=True,
    hide_input=True,
    confirmation_prompt=True,
    envvar="EXPORT_PASSWORD",
    help="Password for the exported SSL/SSH private key.",
    show_envvar=True,
)
@click.option(
    "--import-password",
    prompt=True,
    hide_input=True,
    confirmation_prompt=True,
    envvar="IMPORT_PASSWORD",
    help="Password for the imported PGP key.",
    show_envvar=True,
)
def transform(pgp_key: IO, export_password: str, import_password: str) -> None:
    """
    Transforms an OpenPGP key to OpenSSL / OpenSSH

    To provide an OpenPGP key, use `gpg --export-ssh-key <keyid>`.

    This tool will extract all subkeys with the "Authentication" flag set.
    """
    keyblob = pgp_key.read()
    try:
        privkey, _ = pgpy.PGPKey.from_blob(keyblob)
    except ValueError:
        msg = "Input is not a valid PGP key"
        raise TransformError(msg) from None
    if privkey.is_public:
        msg = "Input needs to be a private key"
        raise TransformError(msg)
    if privkey.is_protected:
        if not import_password:
            import_password = click.prompt("PGP Key Password", hide_input=True)
        with privkey.unlock(import_password):
            parse_subkeys(privkey, export_password)
    else:
        parse_subkeys(privkey, export_password)


if __name__ == "__main__":
    cli()
