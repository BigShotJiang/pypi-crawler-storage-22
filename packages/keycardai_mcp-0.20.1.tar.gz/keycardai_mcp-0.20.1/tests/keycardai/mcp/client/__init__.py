"""Tests for MCP client."""

