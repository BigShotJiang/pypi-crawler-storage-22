"""
kheavyhash: Python implementation of the kHeavyHash Proof-of-Work algorithm.

This package provides a pure Python implementation of kHeavyHash with optional
performance extensions via Cython/C.
"""

__version__ = "0.1.0"

# Try to import the optimized C extension, fall back to pure Python
try:
    from kheavyhash._c_ext import kheavyhash
except ImportError:
    from kheavyhash.kheavyhash_python import kheavyhash

__all__ = ["kheavyhash"]
