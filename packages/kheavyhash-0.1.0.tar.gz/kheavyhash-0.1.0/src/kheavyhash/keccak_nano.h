#ifndef KECCAK_NANO_H
#define KECCAK_NANO_H

#include <stdint.h>
#include <stdlib.h>

/**
 * cSHAKE256 hash function with customization string.
 * 
 * This function implements cSHAKE256 as specified in NIST SP 800-185,
 * using a customization string. The output length is fixed at 32 bytes.
 * 
 * @param out Output buffer (must be at least 32 bytes)
 * @param customization_str Customization string (null-terminated)
 * @param in Input data to hash
 * @param inlen Length of input data in bytes
 * @return 0 on success, -1 on error
 */
int cshake256(uint8_t *out, const char *customization_str, const uint8_t *in, size_t inlen);

#endif
