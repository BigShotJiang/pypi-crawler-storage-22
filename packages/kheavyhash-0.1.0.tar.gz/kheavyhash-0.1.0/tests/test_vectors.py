"""
Hardcoded test vectors for kHeavyHash.

These test vectors are extracted from the Go reference implementation:
https://github.com/bcutil/kheavyhash/blob/main/kheavyhash_test.go

The test vectors use the following format:
- PrePowHash: 32 bytes (NOT reversed)
- Timestamp: 8 bytes, little-endian (reversed from hex string)
- Padding: 32 bytes of zeros
- Nonce: 8 bytes, little-endian (reversed from hex string)
- Expected: 32 bytes (NOT reversed)

Input construction: PrePowHash (32) || Timestamp (8) || Padding (32) || Nonce (8) = 80 bytes total
"""

# Test values from first test vector (for use in tests that need sample inputs)
TEST_VECTOR_1_PRE_POW_HASH = bytes.fromhex(
    "0ad86e9bef09726cdc75913e44ec96521391c7ceb2aae3c633f46a94bf4d2546"
)
TEST_VECTOR_1_TIMESTAMP = bytes.fromhex("3e6bd36895010000")  # Little-endian: 0000019568d36b3e
TEST_VECTOR_1_NONCE = bytes.fromhex("39fd069384065157")  # Little-endian: 571506849306fd39


def make_pre_pow_hash_from_bytes(data: bytes) -> bytes:
    """
    Create a PrePowHash from arbitrary data using SHA256D (double SHA256).

    In real usage, PrePowHash is a hash value. This helper creates a valid
    32-byte PrePowHash from any input data using SHA256D.

    Args:
        data: Input data to hash

    Returns:
        32-byte PrePowHash
    """
    import hashlib
    first_hash = hashlib.sha256(data).digest()
    return hashlib.sha256(first_hash).digest()

# Test vectors: (input_hex, expected_output_hex)
# Input is 80 bytes, output is 32 bytes
# Format: (input as hex string, expected output as hex string)

TEST_VECTORS = [
    # Test Vector 1
    (
        # PrePowHash (32 bytes, not reversed)
        "0ad86e9bef09726cdc75913e44ec96521391c7ceb2aae3c633f46a94bf4d2546"
        # Timestamp (8 bytes, reversed from hex: 0000019568d36b3e -> 3e6bd36895010000)
        + "3e6bd36895010000"
        # Padding (32 bytes of zeros)
        + "00" * 32
        # Nonce (8 bytes, reversed from hex: 571506849306fd39 -> 39fd069384065157)
        + "39fd069384065157",
        # Expected output (32 bytes, from Go reference implementation via C implementation)
        "e097f2e49b05978b2b5b387a46798a0c463082b6546f24afcc8aae4fe68b702f",
    ),
    # Test Vector 2
    (
        "b7e1d42013034af294647f2d21f3a3a78d9e71c2e4806fac0d71dda6d4cf387d"
        + "c92dd96895010000"  # Timestamp reversed: 0000019568d92dc9
        + "00" * 32
        + "18789a6736010090",  # Nonce reversed: 900013673a789118
        # Expected output (32 bytes, from Go reference implementation via C implementation)
        "f88d3f9c4aaacb0a25300ed0f140237da3c44a578c9bd44b60d9c96b3c2b68d5",
    ),
    # Test Vector 3
    (
        "0770e18fa1fbcb5c07418759abbfc3f0bcd8d875dd9b2e9d8c49ffb0449f2a5c"
        + "46dc209695010000"  # Timestamp reversed: 000001956920dc46
        + "00" * 32
        + "14fd87de041500ba",  # Nonce reversed: ba001504de87fd14
        # Expected output (32 bytes, from Go reference implementation via C implementation)
        "f9482be51fe5aff0a1ec44f5e31e524d853cb25718f1d35010392e224a15e230",
    ),
    # Test Vector 4
    (
        "2a24f71bf6b01e4191cb3604e93ffd0a3b881acd10afe4a5a6aeccc5299be903"
        + "fa734f6995010000"  # Timestamp reversed: 00000195694f73fa
        + "00" * 32
        + "1e6a80bac8043cc6",  # Nonce reversed: c63c04c8ba806a1e
        "5ab3b42538a92b352ffe7258bc5cfa7bb2910386521f0c880600000000000000",
    ),
    # Test Vector 5
    (
        "7cd561009913f30bd59ea57830479fc1e64c738e7e39f22baf4567e877042128"
        + "437d8e6995010000"  # Timestamp reversed: 00000195698e7d43
        + "00" * 32
        + "9995c61e744c10f4",  # Nonce reversed: f4104c741ec69599
        "043babd26259ea575d5ddf1fb97d014623f3b6335d656c980000000000000000",
    ),
    # Test Vector 6
    (
        "0741bf4de07012931227ea18b7fb3caf6b587cf9bd1a0ba183fc254d351d3130"
        + "bcc79e6995010000"  # Timestamp reversed: 00000195699ec7bc
        + "00" * 32
        + "c66e9b53081a00ba",  # Nonce reversed: ba001a08539b6ec6
        "ff009eff2105c95d3d0c5646cef524e8245e37f86d2894ca0300000000000000",
    ),
    # Test Vector 7
    (
        "b38e5d1c36b41c0aad7e4f050d702c76e724200c0a0ce427622c12de90082fd3"
        + "08a6306a95010000"  # Timestamp reversed: 000001956a30a608
        + "00" * 32
        + "1aa4054f1bf71064",  # Nonce reversed: 6410f71b4f05a41a
        "78598ee69a3163d60fc5ba7072bb15dcc61bffc5fd9d854d0500000000000000",
    ),
]
