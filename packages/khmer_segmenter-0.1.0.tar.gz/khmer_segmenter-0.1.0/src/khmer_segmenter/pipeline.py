import warnings


warnings.filterwarnings('ignore')

from .utils import get_char_type, sent2features, export_vocab
from .util.data import load_simple_data
from . import crf

import re


def _preprocess(sent):
    sent = sent.strip()
    sent = re.sub(r'\u200b', '', sent)
    sent = re.sub(r'\s+', ' ', sent)

    X = []
    y = []
    for i in range(0, len(sent)):
        char = sent[i]
        prev_char = sent[i - 1] if i > 1 else ''
        next_char = sent[i + 1] if i < len(sent) - 1 else ''

        if char.isspace():
            continue

        type_ = get_char_type(prev_char, char, next_char)
        label = '1' if next_char == ' ' else '0'

        X.append((char, type_))
        y.append(label)

    return X, y


def _load_data(files: list):
    dataset = load_simple_data(files, _preprocess)
    X, y = zip(*dataset)
    return X, y


def _data2features(data):
    return sent2features(data)

