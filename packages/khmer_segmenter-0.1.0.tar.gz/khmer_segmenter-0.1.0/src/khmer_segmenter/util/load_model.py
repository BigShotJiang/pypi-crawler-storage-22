from importlib.resources import files

def get_model_path(name: str):
    return files("khmer_segmenter.models").joinpath(name)
