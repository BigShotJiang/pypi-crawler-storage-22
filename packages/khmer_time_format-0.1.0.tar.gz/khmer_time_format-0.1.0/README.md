# khmer-time-format (Python)

Format 12-hour / 24-hour time (e.g. `1:22 PM`, `13:22`) into Khmer with **two options**:

1) **Khmer numerals (digits)**  
`ម៉ោង១ និង ២២ នាទី រសៀល`

2) **Khmer words (no digits)**  
`ម៉ោងមួយ និង ម្ភៃពីរ នាទី រសៀល`

## Install

```bash
pip install khmer-time-format
```

## Usage

```python
from khmer_time_format import format_time

print(format_time("1:22 PM", mode="digits"))
print(format_time("13:22", mode="words"))
```

## Development

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -e ".[dev]"
pytest
ruff check .
mypy src
```

## Build & publish (PyPI)

```bash
python -m build
python -m twine check dist/*
```

Push a version tag to publish to PyPI via GitHub Actions:

```bash
# tag value becomes package version
git tag v0.1.0
git push origin v0.1.0
```

Tag pushes matching `v*` trigger `.github/workflows/publish.yml`.

With this setup, you do not need to edit the version in `pyproject.toml` for each release.
