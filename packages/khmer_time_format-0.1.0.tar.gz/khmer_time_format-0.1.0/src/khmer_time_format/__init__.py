from importlib.metadata import PackageNotFoundError, version

from .formatter import format_time

__all__ = ["format_time", "__version__"]

try:
    __version__ = version("khmer-time-format")
except PackageNotFoundError:
    __version__ = "0.0.0"
