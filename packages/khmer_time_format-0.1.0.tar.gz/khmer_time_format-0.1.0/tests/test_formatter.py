from khmer_time_format import format_time

def test_digits_12h_pm():
    assert format_time("1:22 PM", mode="digits") == "ម៉ោង១ និង ២២ នាទី រសៀល"

def test_words_12h_pm():
    assert format_time("1:22 PM", mode="words") == "ម៉ោងមួយ និង ម្ភៃពីរ នាទី រសៀល"

def test_digits_24h():
    assert format_time("13:22", mode="digits") == "ម៉ោង១ និង ២២ នាទី រសៀល"

def test_words_24h():
    assert format_time("13:22", mode="words") == "ម៉ោងមួយ និង ម្ភៃពីរ នាទី រសៀល"
