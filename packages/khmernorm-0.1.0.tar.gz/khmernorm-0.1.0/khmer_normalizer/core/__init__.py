from __future__ import annotations

import re
import json
import unicodedata
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Pattern, Tuple, Any


# =========================
# Core types
# =========================

Label = str

@dataclass(frozen=True)
class Span:
    start: int
    end: int
    label: Label
    raw: str
    meta: Dict[str, Any]
    detector_id: int

    @property
    def length(self) -> int:
        return self.end - self.start


# =========================
# Unicode normalization
# =========================

_HYPHENS = "\u2010\u2011\u2012\u2013\u2014\u2212"  # various hyphens/dashes/minus
_HYPHEN_RE = re.compile(f"[{_HYPHENS}]")

def normalize_unicode(text: str) -> str:
    # NFC is typical for Khmer
    text = unicodedata.normalize("NFC", text)
    # Normalize hyphens to ASCII '-'
    text = _HYPHEN_RE.sub("-", text)
    # Normalize non-breaking space to space
    text = text.replace("\u00A0", " ")
    return text


# =========================
# Khmer digit handling
# =========================

KM_DIGITS = "០១២៣៤៥៦៧៨៩"
LAT_DIGITS = "0123456789"
KM2LAT = str.maketrans({k: v for k, v in zip(KM_DIGITS, LAT_DIGITS)})
LAT2KM = str.maketrans({v: k for k, v in zip(KM_DIGITS, LAT_DIGITS)})

def km_digits_to_latin(s: str) -> str:
    return s.translate(KM2LAT)

def latin_digits_to_km(s: str) -> str:
    return s.translate(LAT2KM)

def is_all_digits_mixed(s: str) -> bool:
    s2 = km_digits_to_latin(s)
    return bool(s2) and all(ch.isdigit() for ch in s2)

def parse_int_mixed(s: str) -> int:
    s2 = km_digits_to_latin(s)
    return int(s2)

def parse_float_mixed(s: str) -> float:
    s2 = km_digits_to_latin(s)
    return float(s2)


# =========================
# Khmer number verbalization (deterministic)
# =========================
# Khmer number words (common TTS-friendly forms).
# Note: There are variant readings; choose one consistent standard.

ONES = {
    0: "សូន្យ",
    1: "មួយ",
    2: "ពីរ",
    3: "បី",
    4: "បួន",
    5: "ប្រាំ",
    6: "ប្រាំមួយ",
    7: "ប្រាំពីរ",
    8: "ប្រាំបី",
    9: "ប្រាំបួន",
}

TENS = {
    10: "ដប់",
    11: "ដប់មួយ",
    12: "ដប់ពីរ",
    13: "ដប់បី",
    14: "ដប់បួន",
    15: "ដប់ប្រាំ",
    16: "ដប់ប្រាំមួយ",
    17: "ដប់ប្រាំពីរ",
    18: "ដប់ប្រាំបី",
    19: "ដប់ប្រាំបួន",
    20: "ម្ភៃ",
    30: "សាមសិប",
    40: "សែសិប",
    50: "ហាសិប",
    60: "ហុកសិប",
    70: "ចិតសិប",
    80: "ប៉ែតសិប",
    90: "កៅសិប",
}

SCALES = [
    (10**9, "ពាន់លាន"),
    (10**6, "លាន"),
    (10**3, "ពាន់"),
    (10**2, "រយ"),
]

def int_to_khmer_words(n: int) -> str:
    if n < 0:
        return "លើសសូន្យ"  # avoid negative; can be extended
    if n < 10:
        return ONES[n]
    if n < 20:
        return TENS[n]
    if n < 100:
        tens = (n // 10) * 10
        rem = n % 10
        if rem == 0:
            return TENS[tens]
        return f"{TENS[tens]} {ONES[rem]}"
    # 100+
    parts = []
    remaining = n
    for value, name in SCALES:
        if remaining >= value:
            q = remaining // value
            remaining = remaining % value
            if value == 100:
                # e.g., 300 -> "បី រយ"
                parts.append(f"{int_to_khmer_words(q)} {name}")
            else:
                parts.append(f"{int_to_khmer_words(q)} {name}")
    if remaining > 0:
        parts.append(int_to_khmer_words(remaining))
    return " ".join(parts)

def digits_to_khmer_words(digits: str) -> str:
    # Read digit-by-digit (for IDs/phone)
    out = []
    for ch in km_digits_to_latin(digits):
        if ch.isdigit():
            out.append(ONES[int(ch)])
        else:
            out.append(ch)
    return " ".join(out)

def decimal_to_khmer_words(num_str: str) -> str:
    # Support "." or "," decimal separator (we normalize commas only if clearly decimal)
    s = num_str.strip()
    s = km_digits_to_latin(s)
    if "." in s:
        a, b = s.split(".", 1)
        a_int = int(a) if a else 0
        # decimal part read digit by digit
        return f"{int_to_khmer_words(a_int)} ចុច {digits_to_khmer_words(b)}"
    if "," in s:
        a, b = s.split(",", 1)
        a_int = int(a) if a else 0
        return f"{int_to_khmer_words(a_int)} ចុច {digits_to_khmer_words(b)}"
    return int_to_khmer_words(int(s))


# =========================
# Resources (abbrev/units/currency)
# =========================

DEFAULT_ABBREVIATIONS = {
    "USA": "សហរដ្ឋអាមេរិក",
    "UK": "ចក្រភពអង់គ្លេស",
    "UN": "អង្គការសហប្រជា���ាតិ",
    "CEO": "នាយកប្រតិបត្តិ",
    "GDP": "ផលិតផលក្នុងស្រុកសរុប",
    "AI": "អេអាយ",
    "NLP": "អិនអិលភី",
    "TTS": "ធីធីអេស",
}

DEFAULT_UNITS = {
    "kg": "គីឡូក្រាម",
    "g": "ក្រាម",
    "mg": "មីលីក្រាម",
    "km": "គីឡូម៉ែត្រ",
    "m": "ម៉ែត្រ",
    "cm": "សង់ទីម៉ែត្រ",
    "mm": "មីលីម៉ែត្រ",
    "L": "លីត្រ",
    "ml": "មីលីលីត្រ",
    "°C": "អង្សាសេ",
    "C": "អង្សាសេ",
}

DEFAULT_CURRENCY = {
    "$": "ដុល្លារ",
    "USD": "ដុល្លារ​អាមេរិក",
    "៛": "រៀល",
    "KHR": "រៀល",
    "€": "អឺរ៉ូ",
}


# =========================
# Detector base
# =========================

class Detector:
    label: Label
    def detect(self, text: str, detector_id: int) -> List[Span]:
        raise NotImplementedError


class RegexDetector(Detector):
    def __init__(self, label: Label, pattern: Pattern[str], build_meta: Optional[Callable[[re.Match], Dict[str, Any]]] = None):
        self.label = label
        self.pattern = pattern
        self.build_meta = build_meta or (lambda m: {})

    def detect(self, text: str, detector_id: int) -> List[Span]:
        spans: List[Span] = []
        for m in self.pattern.finditer(text):
            spans.append(Span(
                start=m.start(),
                end=m.end(),
                label=self.label,
                raw=m.group(0),
                meta=self.build_meta(m),
                detector_id=detector_id
            ))
        return spans


# =========================
# Verbalizer base
# =========================

class Verbalizer:
    label: Label
    def verbalize(self, span: Span) -> str:
        raise NotImplementedError


# =========================
# Label implementations
# =========================

DIG = r"[0-9០-៩]"
DIGPLUS = r"[0-9០-៩]+"

# EMAIL
EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")
class EmailVerbalizer(Verbalizer):
    label = "EMAIL"
    def verbalize(self, span: Span) -> str:
        # TTS-safe: read as "user at domain dot tld"
        s = span.raw
        s = s.replace("@", " អេត ")
        s = s.replace(".", " ដុត ")
        s = s.replace("-", " ដាស ")
        s = s.replace("_", " អាន់ដាសខ័រ ")
        return s

# TELEPHONE (simple; tuned for Cambodia typical lengths)
TEL_RE = re.compile(rf"\b(?:\+?{DIG}{{1,3}}[\s\-]?)?(?:{DIG}[\s\-]?){7,12}\b")
class TelephoneVerbalizer(Verbalizer):
    label = "TELEPHONE"
    def verbalize(self, span: Span) -> str:
        # Speak digit-by-digit
        digits = re.sub(r"[^\d០-៩]", "", span.raw)
        return digits_to_khmer_words(digits)

# DATE (supports: YYYY-MM-DD, DD/MM/YYYY, YYYY/MM/DD)
DATE_RE = re.compile(
    rf"\b(?P<y>{DIG}{{4}})[\-\/](?P<m>{DIG}{{1,2}})[\-\/](?P<d>{DIG}{{1,2}})\b"
    rf"|\b(?P<d2>{DIG}{{1,2}})[\-\/](?P<m2>{DIG}{{1,2}})[\-\/](?P<y2>{DIG}{{4}})\b"
)
class DateVerbalizer(Verbalizer):
    label = "DATE"
    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        if m.group("y"):
            y = parse_int_mixed(m.group("y"))
            mo = parse_int_mixed(m.group("m"))
            d = parse_int_mixed(m.group("d"))
        else:
            y = parse_int_mixed(m.group("y2"))
            mo = parse_int_mixed(m.group("m2"))
            d = parse_int_mixed(m.group("d2"))
        # Deterministic template
        return f"ថ្ងៃទី {int_to_khmer_words(d)} ខែ {int_to_khmer_words(mo)} ឆ្នាំ {int_to_khmer_words(y)}"

def _date_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# TIME (HH:MM[:SS] + optional am/pm)
TIME_RE = re.compile(rf"\b(?P<h>{DIG}{{1,2}}):(?P<min>{DIG}{{2}})(?::(?P<s>{DIG}{{2}}))?\b")
class TimeVerbalizer(Verbalizer):
    label = "TIME"
    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        h = parse_int_mixed(m.group("h"))
        mi = parse_int_mixed(m.group("min"))
        ss = m.group("s")
        if ss is not None:
            s = parse_int_mixed(ss)
            return f"ម៉ោង {int_to_khmer_words(h)} នាទី {int_to_khmer_words(mi)} វិនាទី {int_to_khmer_words(s)}"
        return f"ម៉ោង {int_to_khmer_words(h)} នាទី {int_to_khmer_words(mi)}"

def _time_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# DURATION (e.g., 2h30m, 1h, 15m, 3d)
DUR_RE = re.compile(rf"\b(?P<n1>{DIGPLUS})(?P<u1>h|m|s|d)(?:(?P<n2>{DIGPLUS})(?P<u2>h|m|s))?\b", re.IGNORECASE)
DUR_UNITS = {"h": "ម៉ោង", "m": "នាទី", "s": "វិនាទី", "d": "ថ្ងៃ"}
class DurationVerbalizer(Verbalizer):
    label = "DURATION"
    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        n1 = int_to_khmer_words(parse_int_mixed(m.group("n1")))
        u1 = DUR_UNITS[m.group("u1").lower()]
        if m.group("n2"):
            n2 = int_to_khmer_words(parse_int_mixed(m.group("n2")))
            u2 = DUR_UNITS[m.group("u2").lower()]
            return f"{n1} {u1} {n2} {u2}"
        return f"{n1} {u1}"

def _dur_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# MONEY (e.g., $12.50, ៛10000, 12 USD)
MONEY_RE = re.compile(
    rf"\b(?P<sym>[$៛€])\s?(?P<amt>{DIGPLUS}(?:[.,]{DIGPLUS})?)\b"
    rf"|\b(?P<amt2>{DIGPLUS}(?:[.,]{DIGPLUS})?)\s?(?P<cur>USD|KHR|EUR)\b",
    re.IGNORECASE
)
class MoneyVerbalizer(Verbalizer):
    label = "MONEY"
    def __init__(self, currency_map: Dict[str, str]):
        self.currency_map = {**DEFAULT_CURRENCY, **currency_map}

    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        if m.group("sym"):
            cur = self.currency_map.get(m.group("sym"), m.group("sym"))
            amt = m.group("amt")
        else:
            cur = self.currency_map.get(m.group("cur").upper(), m.group("cur").upper())
            amt = m.group("amt2")
        # Determine decimal vs integer
        if re.search(r"[.,]", amt):
            spoken_amt = decimal_to_khmer_words(amt)
        else:
            spoken_amt = int_to_khmer_words(parse_int_mixed(amt))
        return f"{spoken_amt} {cur}"

def _money_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# PERCENT (e.g., 12%, 12.5 %)
PCT_RE = re.compile(rf"\b(?P<n>{DIGPLUS}(?:[.,]{DIGPLUS})?)\s?%\b")
class PercentVerbalizer(Verbalizer):
    label = "PERCENT"
    def verbalize(self, span: Span) -> str:
        n = span.meta["match"].group("n")
        spoken = decimal_to_khmer_words(n) if re.search(r"[.,]", n) else int_to_khmer_words(parse_int_mixed(n))
        return f"{spoken} ភាគរយ"

def _pct_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# MEASURE (e.g., 10kg, 2.5L, 30 °C)
MEAS_RE = re.compile(rf"\b(?P<n>{DIGPLUS}(?:[.,]{DIGPLUS})?)\s?(?P<u>kg|g|mg|km|cm|mm|m|L|ml|°C|C)\b")
class MeasureVerbalizer(Verbalizer):
    label = "MEASURE"
    def __init__(self, unit_map: Dict[str, str]):
        self.unit_map = {**DEFAULT_UNITS, **unit_map}

    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        n = m.group("n")
        u = m.group("u")
        spoken_n = decimal_to_khmer_words(n) if re.search(r"[.,]", n) else int_to_khmer_words(parse_int_mixed(n))
        spoken_u = self.unit_map.get(u, u)
        return f"{spoken_n} {spoken_u}"

def _meas_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# RANGE (e.g., 10-20, ១០-២០)
RANGE_RE = re.compile(rf"\b(?P<a>{DIGPLUS}(?:[.,]{DIGPLUS})?)\s?-\s?(?P<b>{DIGPLUS}(?:[.,]{DIGPLUS})?)\b")
class RangeVerbalizer(Verbalizer):
    label = "RANGE"
    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        a = m.group("a")
        b = m.group("b")
        def speak(x: str) -> str:
            return decimal_to_khmer_words(x) if re.search(r"[.,]", x) else int_to_khmer_words(parse_int_mixed(x))
        return f"{speak(a)} ដល់ {speak(b)}"

def _range_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# FRACTION (e.g., 1/2)
FRACT_RE = re.compile(rf"\b(?P<a>{DIGPLUS})\s?/\s?(?P<b>{DIGPLUS})\b")
class FractionVerbalizer(Verbalizer):
    label = "FRACTION"
    def verbalize(self, span: Span) -> str:
        m = span.meta["match"]
        a = int_to_khmer_words(parse_int_mixed(m.group("a")))
        b = int_to_khmer_words(parse_int_mixed(m.group("b")))
        return f"{a} ភាគ {b}"

def _fract_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# DECIMAL (standalone, e.g., 3.14)
DEC_RE = re.compile(rf"\b(?P<n>{DIGPLUS}[.,]{DIGPLUS})\b")
class DecimalVerbalizer(Verbalizer):
    label = "DECIMAL"
    def verbalize(self, span: Span) -> str:
        return decimal_to_khmer_words(span.meta["match"].group("n"))

def _dec_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# ORDINAL (Khmer "ទី" prefix + number)
ORD_RE = re.compile(rf"\bទី\s?(?P<n>{DIGPLUS})\b")
class OrdinalVerbalizer(Verbalizer):
    label = "ORDINAL"
    def verbalize(self, span: Span) -> str:
        n = int_to_khmer_words(parse_int_mixed(span.meta["match"].group("n")))
        return f"ទី {n}"

def _ord_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# YEAR (heuristic: 4 digits 1000-2999; avoid dates already captured by DATE)
YEAR_RE = re.compile(rf"\b(?P<y>{DIG}{{4}})\b")
class YearVerbalizer(Verbalizer):
    label = "YEAR"
    def verbalize(self, span: Span) -> str:
        y = parse_int_mixed(span.meta["match"].group("y"))
        return f"ឆ្នាំ {int_to_khmer_words(y)}"

def _year_meta(match: re.Match) -> Dict[str, Any]:
    y = parse_int_mixed(match.group("y"))
    return {"match": match, "y": y}

# ID (alphanumeric IDs; speak digits individually, keep letters as-is separated)
ID_RE = re.compile(r"\b(?=[A-Za-z0-9\-]{6,}\b)(?:[A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9\-]*\b")
class IDVerbalizer(Verbalizer):
    label = "ID"
    def verbalize(self, span: Span) -> str:
        # Deterministic: letters chunk as letters, digits chunk digit-by-digit, hyphen as "ដាស"
        s = span.raw
        parts = []
        i = 0
        while i < len(s):
            ch = s[i]
            if ch.isdigit():
                j = i
                while j < len(s) and s[j].isdigit():
                    j += 1
                parts.append(digits_to_khmer_words(s[i:j]))
                i = j
            elif ch.isalpha():
                j = i
                while j < len(s) and s[j].isalpha():
                    j += 1
                # spell letters one by one (simple)
                parts.append(" ".join(list(s[i:j].upper())))
                i = j
            elif ch == "-":
                parts.append("ដាស")
                i += 1
            else:
                parts.append(ch)
                i += 1
        return " ".join(parts)

# ABBREVIATION (dictionary-based; all-caps words 2-6)
ABBR_RE = re.compile(r"\b[A-Z]{2,6}\b")
class AbbreviationVerbalizer(Verbalizer):
    label = "ABBREVIATION"
    def __init__(self, abbrev_map: Dict[str, str]):
        self.abbrev_map = {**DEFAULT_ABBREVIATIONS, **abbrev_map}

    def verbalize(self, span: Span) -> str:
        return self.abbrev_map.get(span.raw, " ".join(list(span.raw)))

# CARDINAL (plain integers)
CARD_RE = re.compile(rf"\b(?P<n>{DIGPLUS})\b")
class CardinalVerbalizer(Verbalizer):
    label = "CARDINAL"
    def verbalize(self, span: Span) -> str:
        n = parse_int_mixed(span.meta["match"].group("n"))
        return int_to_khmer_words(n)

def _card_meta(match: re.Match) -> Dict[str, Any]:
    return {"match": match}

# Placeholder label types required but not fully expanded in patterns:
# - TIME implemented
# - DATE implemented
# - DURATION implemented
# - YEAR implemented
# - MONEY/PERCENT/MEASURE implemented
# Remaining labels in requirements:
# FRACTION/DECIMAL/RANGE/ORDINAL/CARDINAL/TELEPHONE/EMAIL/ID/ABBREVIATION implemented
# Note: You can extend DATE to Khmer month names, and add more date formats safely.


# =========================
# Span resolver (priority + longest-match)
# =========================

def resolve_spans(spans: List[Span], priority: Dict[Label, int]) -> List[Span]:
    def key(s: Span):
        return (-priority.get(s.label, 0), -s.length, s.start, s.detector_id)

    spans_sorted = sorted(spans, key=key)
    chosen: List[Span] = []
    occupied: List[Tuple[int, int]] = []

    def overlaps(a: Span, bstart: int, bend: int) -> bool:
        return not (a.end <= bstart or a.start >= bend)

    for sp in spans_sorted:
        conflict = False
        for (os, oe) in occupied:
            if not (sp.end <= os or sp.start >= oe):
                conflict = True
                break
        if not conflict:
            chosen.append(sp)
            occupied.append((sp.start, sp.end))

    return sorted(chosen, key=lambda s: s.start)


# =========================
# Normalizer
# =========================

DEFAULT_PRIORITY = {
    "EMAIL": 110,
    "TELEPHONE": 105,
    "DATE": 100,
    "TIME": 95,
    "DURATION": 92,
    "MONEY": 90,
    "PERCENT": 88,
    "MEASURE": 86,
    "RANGE": 80,
    "FRACTION": 78,
    "DECIMAL": 76,
    "ORDINAL": 70,
    "YEAR": 60,
    "ID": 55,
    "ABBREVIATION": 50,
    "CARDINAL": 10,
}

class KhmerTextNormalizer:
    def __init__(
        self,
        abbreviations: Optional[Dict[str, str]] = None,
        units: Optional[Dict[str, str]] = None,
        currency: Optional[Dict[str, str]] = None,
        priority: Optional[Dict[Label, int]] = None,
    ):
        abbreviations = abbreviations or {}
        units = units or {}
        currency = currency or {}
        self.priority = {**DEFAULT_PRIORITY, **(priority or {})}

        # Build detectors (order matters only for final tie-breaker)
        self.detectors: List[Detector] = [
            RegexDetector("EMAIL", EMAIL_RE),
            RegexDetector("TELEPHONE", TEL_RE),
            RegexDetector("DATE", DATE_RE, _date_meta),
            RegexDetector("TIME", TIME_RE, _time_meta),
            RegexDetector("DURATION", DUR_RE, _dur_meta),
            RegexDetector("MONEY", MONEY_RE, _money_meta),
            RegexDetector("PERCENT", PCT_RE, _pct_meta),
            RegexDetector("MEASURE", MEAS_RE, _meas_meta),
            RegexDetector("RANGE", RANGE_RE, _range_meta),
            RegexDetector("FRACTION", FRACT_RE, _fract_meta),
            RegexDetector("DECIMAL", DEC_RE, _dec_meta),
            RegexDetector("ORDINAL", ORD_RE, _ord_meta),
            # YEAR: keep but we will filter by plausible range in meta
            RegexDetector("YEAR", YEAR_RE, _year_meta),
            RegexDetector("ID", ID_RE),
            RegexDetector("ABBREVIATION", ABBR_RE),
            RegexDetector("CARDINAL", CARD_RE, _card_meta),
        ]

        # Verbalizers
        self.verbalizers: Dict[Label, Verbalizer] = {
            "EMAIL": EmailVerbalizer(),
            "TELEPHONE": TelephoneVerbalizer(),
            "DATE": DateVerbalizer(),
            "TIME": TimeVerbalizer(),
            "DURATION": DurationVerbalizer(),
            "MONEY": MoneyVerbalizer(currency),
            "PERCENT": PercentVerbalizer(),
            "MEASURE": MeasureVerbalizer(units),
            "RANGE": RangeVerbalizer(),
            "FRACTION": FractionVerbalizer(),
            "DECIMAL": DecimalVerbalizer(),
            "ORDINAL": OrdinalVerbalizer(),
            "YEAR": YearVerbalizer(),
            "ID": IDVerbalizer(),
            "ABBREVIATION": AbbreviationVerbalizer(abbreviations),
            "CARDINAL": CardinalVerbalizer(),
        }

    def _post_filter(self, spans: List[Span]) -> List[Span]:
        # Filter YEAR to plausible values and avoid turning every 4-digit into year.
        out = []
        for sp in spans:
            if sp.label == "YEAR":
                y = sp.meta.get("y")
                if not (1000 <= int(y) <= 2999):
                    continue
            out.append(sp)
        return out

    def normalize(self, text: str) -> str:
        text_n = normalize_unicode(text)

        # detect
        all_spans: List[Span] = []
        for i, det in enumerate(self.detectors):
            all_spans.extend(det.detect(text_n, detector_id=i))

        all_spans = self._post_filter(all_spans)

        # resolve overlaps
        chosen = resolve_spans(all_spans, self.priority)

        # render replacements
        pieces = []
        last = 0
        for sp in chosen:
            pieces.append(text_n[last:sp.start])
            verbalizer = self.verbalizers.get(sp.label)
            if verbalizer is None:
                # safety: if no verbalizer, keep raw
                pieces.append(sp.raw)
            else:
                pieces.append(verbalizer.verbalize(sp))
            last = sp.end
        pieces.append(text_n[last:])
        return "".join(pieces)


# Central API-friendly function
_default_normalizer = KhmerTextNormalizer()

def normalize(text: str) -> str:
    return _default_normalizer.normalize(text)


# =========================
# Simple CLI demo (optional)
# =========================
if __name__ == "__main__":
    samples = [
        "សូមទូរស័ព្ទទៅ 012-345-678 នៅម៉ោង 14:30។",
        "ថ្ងៃនេះគឺ 2026-02-14 និងតម្លៃ $12.50 ឬ ៛10000។",
        "បញ្ចុះតម្លៃ 12% និងទំងន់ 2.5kg។",
        "ចន្លោះ 10-20 និងប្រភាគ 1/2។",
        "លំដាប់ទី 3 និងឆ្នាំ 1998។",
        "Email: rom.need@example.com",
        "ID: AB12-9007",
        "I work on NLP and TTS in USA.",
    ]
    for s in samples:
        print(s)
        print(normalize(s))
        print("---")