from __future__ import annotations
import re

# Conservative Khmer cluster normalization:
# - Normalize ordering of combining marks within Khmer clusters
# - Do not add/remove characters (only reorder)
# - Intended to fix visually-correct but non-canonical encoding that breaks matching/TTS

_KHMER_RUN_RE = re.compile(r"[\u1780-\u17FF]+")

COENG = "\u17D2"  # Khmer sign COENG

# Dependent vowels: U+17B6–U+17C5
_DEP_VOWEL_RE = re.compile(r"[\u17B6-\u17C5]")
# Diacritics/signs: U+17C6–U+17D1 plus U+17DD (Atthacan)
_DIACRITIC_RE = re.compile(r"[\u17C6-\u17D1\u17DD]")

# Base letters: consonants + independent vowels
_BASE_RE = re.compile(r"[\u1780-\u17A2\u17A3-\u17B3]")


def _is_base(ch: str) -> bool:
    return bool(_BASE_RE.fullmatch(ch))


def _class_priority(ch: str) -> int:
    """
    Deterministic order for Khmer cluster marks.
    Lower number = earlier.
      0: COENG
      1: dependent vowels
      2: diacritics/signs
      3: other
    """
    if ch == COENG:
        return 0
    if _DEP_VOWEL_RE.fullmatch(ch):
        return 1
    if _DIACRITIC_RE.fullmatch(ch):
        return 2
    return 3


def normalize_khmer_cluster_order(text: str) -> str:
    out = []
    i = 0
    n = len(text)

    while i < n:
        ch = text[i]
        if not ("\u1780" <= ch <= "\u17FF"):
            out.append(ch)
            i += 1
            continue

        m = _KHMER_RUN_RE.match(text, i)
        run = m.group(0)
        out.append(_normalize_khmer_run(run))
        i = m.end()

    return "".join(out)


def _normalize_khmer_run(run: str) -> str:
    clusters = []
    i = 0
    L = len(run)

    while i < L:
        if _is_base(run[i]):
            base = run[i]
            i += 1
            marks = []
            while i < L and not _is_base(run[i]):
                marks.append(run[i])
                i += 1
            marks_sorted = sorted(marks, key=_class_priority)
            clusters.append(base + "".join(marks_sorted))
        else:
            # malformed run starting with mark: keep as-is
            clusters.append(run[i])
            i += 1

    return "".join(clusters)