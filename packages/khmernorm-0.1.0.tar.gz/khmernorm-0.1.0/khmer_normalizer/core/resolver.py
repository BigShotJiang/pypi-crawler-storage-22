from __future__ import annotations
from typing import Dict, List, Tuple

from .types import Span


def resolve_spans(spans: List[Span], priority: Dict[str, int]) -> List[Span]:
    spans_sorted = sorted(
        spans,
        key=lambda s: (-priority.get(s.label, 0), -s.length, s.start, s.module_order),
    )

    chosen: List[Span] = []
    occupied: List[Tuple[int, int]] = []

    for sp in spans_sorted:
        overlaps = any(not (sp.end <= os or sp.start >= oe) for os, oe in occupied)
        if overlaps:
            continue
        chosen.append(sp)
        occupied.append((sp.start, sp.end))

    return sorted(chosen, key=lambda s: s.start)