from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class Span:
    start: int
    end: int
    label: str
    match: str
    meta: Dict[str, Any]
    module: str
    module_order: int

    @property
    def length(self) -> int:
        return self.end - self.start