from __future__ import annotations
import re
import unicodedata

from .khmer_orthography import normalize_khmer_cluster_order

_HYPHENS = "\u2010\u2011\u2012\u2013\u2014\u2212"
_HYPHEN_RE = re.compile(f"[{_HYPHENS}]")


def normalize_unicode(text: str) -> str:
    # Canonical composition for Khmer sequences
    text = unicodedata.normalize("NFC", text)

    # Safe punctuation normalization
    text = _HYPHEN_RE.sub("-", text)
    text = text.replace("\u00A0", " ")

    # Khmer encoding/ordering normalization (conservative)
    text = normalize_khmer_cluster_order(text)

    return text