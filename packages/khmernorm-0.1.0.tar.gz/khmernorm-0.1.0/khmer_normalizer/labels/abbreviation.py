from __future__ import annotations
import re
from typing import Dict, List

LABEL = "ABBREVIATION"
_ABBR_RE = re.compile(r"\b[A-Z]{2,6}\b")

# Deterministic dictionary. Production: load from JSON.
_ABBREV = {
    "USA": "សហរដ្ឋអាមេរិក",
    "UK": "ចក្រភពអង់គ្លេស",
    "UN": "អង្គការសហប្រជាជាតិ",
    "CEO": "នាយកប្រតិបត្តិ",
    "GDP": "ផលិតផលក្នុងស្រុកសរុប",
    "AI": "អេអាយ",
    "NLP": "អិនអិលភី",
    "TTS": "ធីធីអេស",
}


def detect(text: str) -> List[Dict]:
    return [{"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {}} for m in _ABBR_RE.finditer(text)]


def normalize(match: str) -> str:
    return _ABBREV.get(match, " ".join(list(match)))