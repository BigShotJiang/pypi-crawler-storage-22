from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "CARDINAL"
_DIG = r"(?:[0-9]|[០-៩])"
_CARD_RE = re.compile(rf"\b(?P<n>{_DIG}+)\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"n": m.group("n")}}
        for m in _CARD_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _CARD_RE.fullmatch(match.strip())
    if not m:
        return match
    n = parse_int_mixed(m.group("n"))
    return int_to_khmer_words(n)