from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "DATE"
_DIG = r"(?:[0-9]|[០-៩])"

_MONTHS = {
    1: "មករា",
    2: "កុម្ភៈ",
    3: "មីនា",
    4: "មេសា",
    5: "ឧសភា",
    6: "មិថុនា",
    7: "កក្កដា",
    8: "សីហា",
    9: "កញ្ញា",
    10: "តុលា",
    11: "វិច្ឆិកា",
    12: "ធ្នូ",
}

_MONTH_ALT = "|".join(map(re.escape, _MONTHS.values()))

_DATE_NUM_RE = re.compile(
    rf"\b(?P<y>{_DIG}{{4}})[\-\/](?P<m>{_DIG}{{1,2}})[\-\/](?P<d>{_DIG}{{1,2}})\b"
    rf"|\b(?P<d2>{_DIG}{{1,2}})[\-\/](?P<m2>{_DIG}{{1,2}})[\-\/](?P<y2>{_DIG}{{4}})\b"
)

_DATE_KM_MONTH_RE = re.compile(
    rf"\b(?P<d>{_DIG}{{1,2}})\s*([\-\/]|\s)\s*(?P<mon>{_MONTH_ALT})\s*([\-\/]|\s)\s*(?P<y>{_DIG}{{4}})\b"
)


def detect(text: str) -> List[Dict]:
    spans: List[Dict] = []

    for m in _DATE_KM_MONTH_RE.finditer(text):
        spans.append(
            {
                "start": m.start(),
                "end": m.end(),
                "label": LABEL,
                "match": m.group(0),
                "meta": {"kind": "km_month", "groups": m.groupdict()},
            }
        )

    for m in _DATE_NUM_RE.finditer(text):
        spans.append(
            {
                "start": m.start(),
                "end": m.end(),
                "label": LABEL,
                "match": m.group(0),
                "meta": {"kind": "numeric", "groups": m.groupdict()},
            }
        )

    return spans


def normalize(match: str) -> str:
    s = match.strip()

    m = _DATE_KM_MONTH_RE.fullmatch(s)
    if m:
        d = parse_int_mixed(m.group("d"))
        y = parse_int_mixed(m.group("y"))
        mon_name = m.group("mon")

        if not (1 <= d <= 31):
            return match
        if mon_name not in _MONTHS.values():
            return match

        return f"ថ្ងៃទី {int_to_khmer_words(d)} ខែ {mon_name} ឆ្នាំ {int_to_khmer_words(y)}"

    m2 = _DATE_NUM_RE.fullmatch(s)
    if not m2:
        return match

    gd = m2.groupdict()
    if gd.get("y"):
        y = parse_int_mixed(gd["y"])
        mo = parse_int_mixed(gd["m"])
        d = parse_int_mixed(gd["d"])
    else:
        y = parse_int_mixed(gd["y2"])
        mo = parse_int_mixed(gd["m2"])
        d = parse_int_mixed(gd["d2"])

    if not (1 <= mo <= 12 and 1 <= d <= 31):
        return match

    mon_name = _MONTHS[mo]
    return f"ថ្ងៃទី {int_to_khmer_words(d)} ខែ {mon_name} ឆ្នាំ {int_to_khmer_words(y)}"