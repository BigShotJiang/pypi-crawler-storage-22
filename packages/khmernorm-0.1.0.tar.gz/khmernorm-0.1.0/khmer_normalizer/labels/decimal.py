from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import decimal_to_khmer_words

LABEL = "DECIMAL"
_DIG = r"(?:[0-9]|[០-៩])"
_DEC_RE = re.compile(rf"\b(?P<n>{_DIG}+[.,]{_DIG}+)\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}}
        for m in _DEC_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _DEC_RE.fullmatch(match.strip())
    if not m:
        return match
    return decimal_to_khmer_words(m.group("n"))