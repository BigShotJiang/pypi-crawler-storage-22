from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "DURATION"
_DIG = r"(?:[0-9]|[០-៩])"
_DUR_RE = re.compile(rf"\b(?P<n1>{_DIG}+)(?P<u1>h|m|s|d)(?:(?P<n2>{_DIG}+)(?P<u2>h|m|s))?\b", re.IGNORECASE)
_UNITS = {"h": "ម៉ោង", "m": "នាទី", "s": "វិនាទី", "d": "ថ្ងៃ"}


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}}
        for m in _DUR_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _DUR_RE.fullmatch(match.strip())
    if not m:
        return match
    gd = m.groupdict()
    n1 = int_to_khmer_words(parse_int_mixed(gd["n1"]))
    u1 = _UNITS[gd["u1"].lower()]
    if gd.get("n2"):
        n2 = int_to_khmer_words(parse_int_mixed(gd["n2"]))
        u2 = _UNITS[gd["u2"].lower()]
        return f"{n1} {u1} {n2} {u2}"
    return f"{n1} {u1}"