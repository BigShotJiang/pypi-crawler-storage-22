from __future__ import annotations
import re
from typing import Dict, List

LABEL = "EMAIL"
_EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {}}
        for m in _EMAIL_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    s = match
    s = s.replace("@", " អេត ")
    s = s.replace(".", " ដុត ")
    s = s.replace("-", " ដាស ")
    s = s.replace("_", " អាន់ដាសខ័រ ")
    return s