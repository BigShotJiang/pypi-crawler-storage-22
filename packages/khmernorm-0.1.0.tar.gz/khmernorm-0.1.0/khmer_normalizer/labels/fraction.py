from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "FRACTION"
_DIG = r"(?:[0-9]|[០-៩])"
_FRACT_RE = re.compile(rf"\b(?P<a>{_DIG}+)\s?/\s?(?P<b>{_DIG}+)\b")


def detect(text: str) -> List[Dict]:
    spans = []
    for m in _FRACT_RE.finditer(text):
        spans.append({"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}})
    return spans


def normalize(match: str) -> str:
    m = _FRACT_RE.fullmatch(match.strip())
    if not m:
        return match
    a = int_to_khmer_words(parse_int_mixed(m.group("a")))
    b = int_to_khmer_words(parse_int_mixed(m.group("b")))
    return f"{a} ភាគ {b}"