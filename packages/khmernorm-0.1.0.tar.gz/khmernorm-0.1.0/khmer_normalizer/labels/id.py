from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import digits_to_khmer_words

LABEL = "ID"
_ID_RE = re.compile(r"\b(?=[A-Za-z0-9\-]{6,}\b)(?:[A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9\-]*\b")


def detect(text: str) -> List[Dict]:
    return [{"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {}} for m in _ID_RE.finditer(text)]


def normalize(match: str) -> str:
    s = match
    parts = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch.isdigit():
            j = i
            while j < len(s) and s[j].isdigit():
                j += 1
            parts.append(digits_to_khmer_words(s[i:j]))
            i = j
        elif ch.isalpha():
            j = i
            while j < len(s) and s[j].isalpha():
                j += 1
            parts.append(" ".join(list(s[i:j].upper())))
            i = j
        elif ch == "-":
            parts.append("ដាស")
            i += 1
        else:
            parts.append(ch)
            i += 1
    return " ".join(parts)