from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import decimal_to_khmer_words, int_to_khmer_words, looks_decimal
from ..utils.digits import parse_int_mixed

LABEL = "MEASURE"
_DIG = r"(?:[0-9]|[០-៩])"
_MEAS_RE = re.compile(rf"\b(?P<n>{_DIG}+(?:[.,]{_DIG}+)?)\s?(?P<u>kg|g|mg|km|cm|mm|m|L|ml|°C|C)\b")

_UNITS = {
    "kg": "គីឡូក្រាម",
    "g": "ក្រាម",
    "mg": "មីលីក្រាម",
    "km": "គីឡូម៉ែត្រ",
    "m": "ម៉ែត្រ",
    "cm": "សង់ទីម៉ែត្រ",
    "mm": "មីលីម៉ែត្រ",
    "L": "លីត្រ",
    "ml": "មីលីលីត្រ",
    "°C": "អង្សាសេ",
    "C": "អង្សាសេ",
}


def detect(text: str) -> List[Dict]:
    spans = []
    for m in _MEAS_RE.finditer(text):
        spans.append({"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}})
    return spans


def normalize(match: str) -> str:
    m = _MEAS_RE.fullmatch(match.strip())
    if not m:
        return match
    n = m.group("n")
    u = m.group("u")
    spoken_n = decimal_to_khmer_words(n) if looks_decimal(n) else int_to_khmer_words(parse_int_mixed(n))
    spoken_u = _UNITS.get(u, u)
    return f"{spoken_n} {spoken_u}"