from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import decimal_to_khmer_words, int_to_khmer_words, looks_decimal
from ..utils.digits import parse_int_mixed

LABEL = "MONEY"
_DIG = r"(?:[0-9]|[០-៩])"
_MONEY_RE = re.compile(
    rf"\b(?P<sym>[$៛€])\s?(?P<amt>{_DIG}+(?:[.,]{_DIG}+)?)\b"
    rf"|\b(?P<amt2>{_DIG}+(?:[.,]{_DIG}+)?)\s?(?P<cur>USD|KHR|EUR)\b",
    re.IGNORECASE,
)

_CURRENCY = {
    "$": "ដុល្លារ",
    "USD": "ដុល្លារ​អាមេរិក",
    "៛": "រៀល",
    "KHR": "រៀល",
    "€": "អឺរ៉ូ",
    "EUR": "អឺរ៉ូ",
}


def detect(text: str) -> List[Dict]:
    spans = []
    for m in _MONEY_RE.finditer(text):
        spans.append({"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}})
    return spans


def normalize(match: str) -> str:
    m = _MONEY_RE.fullmatch(match.strip())
    if not m:
        return match
    gd = m.groupdict()
    if gd.get("sym"):
        cur = _CURRENCY.get(gd["sym"], gd["sym"])
        amt = gd["amt"]
    else:
        cur_code = gd["cur"].upper()
        cur = _CURRENCY.get(cur_code, cur_code)
        amt = gd["amt2"]

    if looks_decimal(amt):
        spoken_amt = decimal_to_khmer_words(amt)
    else:
        spoken_amt = int_to_khmer_words(parse_int_mixed(amt))
    return f"{spoken_amt} {cur}"