from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "ORDINAL"
_DIG = r"[0-9០-៩]"
_ORD_RE = re.compile(rf"\bទី\s?(?P<n>{_DIG}+)\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}}
        for m in _ORD_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _ORD_RE.fullmatch(match.strip())
    if not m:
        return match
    n = int_to_khmer_words(parse_int_mixed(m.group("n")))
    return f"ទី {n}"