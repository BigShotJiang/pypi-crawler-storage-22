from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import decimal_to_khmer_words, int_to_khmer_words, looks_decimal
from ..utils.digits import parse_int_mixed

LABEL = "PERCENT"
_DIG = r"(?:[0-9]|[០-៩])"
_PCT_RE = re.compile(rf"\b(?P<n>{_DIG}+(?:[.,]{_DIG}+)?)\s?%\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}}
        for m in _PCT_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _PCT_RE.fullmatch(match.strip())
    if not m:
        return match
    n = m.group("n")
    spoken = decimal_to_khmer_words(n) if looks_decimal(n) else int_to_khmer_words(parse_int_mixed(n))
    return f"{spoken} ភាគរយ"