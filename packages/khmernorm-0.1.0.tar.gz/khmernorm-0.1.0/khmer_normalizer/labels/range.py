from __future__ import annotations
import re
from typing import Dict, List

from ..utils.numbers_km import decimal_to_khmer_words, int_to_khmer_words, looks_decimal
from ..utils.digits import parse_int_mixed

LABEL = "RANGE"
_DIG = r"(?:[0-9]|[០-៩])"
_RANGE_RE = re.compile(rf"\b(?P<a>{_DIG}+(?:[.,]{_DIG}+)?)\s?-\s?(?P<b>{_DIG}+(?:[.,]{_DIG}+)?)\b")


def detect(text: str) -> List[Dict]:
    spans = []
    for m in _RANGE_RE.finditer(text):
        spans.append({"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}})
    return spans


def normalize(match: str) -> str:
    m = _RANGE_RE.fullmatch(match.strip())
    if not m:
        return match
    a = m.group("a")
    b = m.group("b")

    def speak(x: str) -> str:
        return decimal_to_khmer_words(x) if looks_decimal(x) else int_to_khmer_words(parse_int_mixed(x))

    return f"{speak(a)} ដល់ {speak(b)}"