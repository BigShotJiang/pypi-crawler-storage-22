from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import digits_only
from ..utils.numbers_km import digits_to_khmer_words

LABEL = "TELEPHONE"
_DIG = r"(?:[0-9]|[០-៩])"
_TEL_RE = re.compile(rf"\b(?:\+?{_DIG}{{1,3}}[\s\-]?)?(?:{_DIG}[\s\-]?){7,12}\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {}}
        for m in _TEL_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    d = digits_only(match)
    return digits_to_khmer_words(d)