from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "TIME"
_DIG = r"(?:[0-9]|[០-៩])"
_TIME_RE = re.compile(rf"\b(?P<h>{_DIG}{{1,2}}):(?P<min>{_DIG}{{2}})(?::(?P<s>{_DIG}{{2}}))?\b")


def detect(text: str) -> List[Dict]:
    return [
        {"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"groups": m.groupdict()}}
        for m in _TIME_RE.finditer(text)
    ]


def normalize(match: str) -> str:
    m = _TIME_RE.fullmatch(match.strip())
    if not m:
        return match
    gd = m.groupdict()
    h = parse_int_mixed(gd["h"])
    mi = parse_int_mixed(gd["min"])
    if gd.get("s"):
        s = parse_int_mixed(gd["s"])
        return f"ម៉ោង {int_to_khmer_words(h)} នាទី {int_to_khmer_words(mi)} វិនាទី {int_to_khmer_words(s)}"
    return f"ម៉ោង {int_to_khmer_words(h)} នាទី {int_to_khmer_words(mi)}"