from __future__ import annotations
import re
from typing import Dict, List

from ..utils.digits import parse_int_mixed
from ..utils.numbers_km import int_to_khmer_words

LABEL = "YEAR"
_DIG = r"(?:[0-9]|[០-៩])"
_YEAR_RE = re.compile(rf"\b(?P<y>{_DIG}{{4}})\b")


def detect(text: str) -> List[Dict]:
    spans = []
    for m in _YEAR_RE.finditer(text):
        y = parse_int_mixed(m.group("y"))
        if 1000 <= y <= 2999:
            spans.append({"start": m.start(), "end": m.end(), "label": LABEL, "match": m.group(0), "meta": {"y": y}})
    return spans


def normalize(match: str) -> str:
    m = _YEAR_RE.fullmatch(match.strip())
    if not m:
        return match
    y = parse_int_mixed(m.group("y"))
    if not (1000 <= y <= 2999):
        return match
    return f"ឆ្នាំ {int_to_khmer_words(y)}"