from __future__ import annotations

from typing import Dict, List

from .core.unicode_norm import normalize_unicode
from .core.types import Span
from .core.resolver import resolve_spans

# Import label modules (each exposes detect() and normalize())
from .labels import (
    email,
    telephone,
    date,
    time,
    duration,
    money,
    percent,
    measure,
    range as range_label,
    fraction,
    decimal,
    ordinal,
    year,
    id as id_label,
    abbreviation,
    cardinal,
)

# Module registry in deterministic order (tie-breaker)
MODULES = [
    email,
    telephone,
    date,
    time,
    duration,
    money,
    percent,
    measure,
    range_label,
    fraction,
    decimal,
    ordinal,
    year,
    id_label,
    abbreviation,
    cardinal,
]

PRIORITY: Dict[str, int] = {
    "EMAIL": 110,
    "TELEPHONE": 105,
    "DATE": 100,
    "TIME": 95,
    "DURATION": 92,
    "MONEY": 90,
    "PERCENT": 88,
    "MEASURE": 86,
    "RANGE": 80,
    "FRACTION": 78,
    "DECIMAL": 76,
    "ORDINAL": 70,
    "YEAR": 60,
    "ID": 55,
    "ABBREVIATION": 50,
    "CARDINAL": 10,
}


def _collect_spans(text: str) -> List[Span]:
    spans: List[Span] = []
    for idx, mod in enumerate(MODULES):
        mod_name = mod.__name__.split(".")[-1]
        detections = mod.detect(text)
        for d in detections:
            spans.append(
                Span(
                    start=d["start"],
                    end=d["end"],
                    label=d["label"],
                    match=d["match"],
                    meta=d.get("meta", {}),
                    module=mod_name,
                    module_order=idx,
                )
            )
    return spans


def normalize(text: str) -> str:
    """
    Central API-friendly deterministic normalization.
    Only replaces detected labeled spans; leaves other text unchanged.
    """
    text_n = normalize_unicode(text)

    candidates = _collect_spans(text_n)
    chosen = resolve_spans(candidates, PRIORITY)

    out_parts: List[str] = []
    cursor = 0

    module_by_name = {mod.__name__.split(".")[-1]: mod for mod in MODULES}

    for sp in chosen:
        out_parts.append(text_n[cursor:sp.start])
        mod = module_by_name.get(sp.module)
        if mod is None:
            out_parts.append(sp.match)  # safety
        else:
            out_parts.append(mod.normalize(sp.match))
        cursor = sp.end

    out_parts.append(text_n[cursor:])
    return "".join(out_parts)