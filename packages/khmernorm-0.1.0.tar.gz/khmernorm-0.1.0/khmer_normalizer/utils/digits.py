from __future__ import annotations

KM_DIGITS = "០១២៣៤៥៦៧៨៩"
LAT_DIGITS = "0123456789"
KM2LAT = str.maketrans({k: v for k, v in zip(KM_DIGITS, LAT_DIGITS)})


def km_digits_to_latin(s: str) -> str:
    return s.translate(KM2LAT)


def parse_int_mixed(s: str) -> int:
    return int(km_digits_to_latin(s))


def digits_only(s: str) -> str:
    out = []
    for ch in s:
        if ch.isdigit() or ch in KM_DIGITS:
            out.append(ch)
    return "".join(out)