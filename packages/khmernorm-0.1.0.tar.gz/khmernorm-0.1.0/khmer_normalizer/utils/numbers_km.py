from __future__ import annotations
import re

from .digits import km_digits_to_latin, parse_int_mixed

ONES = {
    0: "សូន្យ",
    1: "មួយ",
    2: "ពីរ",
    3: "បី",
    4: "បួន",
    5: "ប្រាំ",
    6: "ប្រាំមួយ",
    7: "ប្រាំពីរ",
    8: "ប្រាំបី",
    9: "ប្រាំបួន",
}

# Human-friendly tens reading (your preference)
TENS = {
    10: "ដប់",
    11: "ដប់មួយ",
    12: "ដប់ពីរ",
    13: "ដប់បី",
    14: "ដប់បួន",
    15: "ដប់ប្រាំ",
    16: "ដប់ប្រាំមួយ",
    17: "ដប់ប្រាំពីរ",
    18: "ដប់ប្រាំបី",
    19: "ដប់ប្រាំបួន",
    20: "ម្ភៃ",
    30: "សាមសិប",
    40: "សែសិប",
    50: "ហាសិប",
    60: "ហុកសិប",
    70: "ចិតសិប",
    80: "ប៉ែតសិប",
    90: "កៅសិប",
}

SCALES = [
    (10**9, "ពាន់លាន"),
    (10**6, "លាន"),
    (10**3, "ពាន់"),
    (10**2, "រយ"),
]


def int_to_khmer_words(n: int) -> str:
    if n < 0:
        return "លើសសូន្យ"

    if n < 10:
        return ONES[n]
    if n < 20:
        return TENS[n]
    if n < 100:
        tens = (n // 10) * 10
        rem = n % 10
        if rem == 0:
            return TENS[tens]
        return f"{TENS[tens]} {ONES[rem]}"

    parts = []
    remaining = n
    for value, name in SCALES:
        if remaining >= value:
            q = remaining // value
            remaining %= value
            parts.append(f"{int_to_khmer_words(q)} {name}")

    if remaining:
        parts.append(int_to_khmer_words(remaining))

    return " ".join(parts)


def digits_to_khmer_words(digits: str) -> str:
    s = km_digits_to_latin(digits)
    out = []
    for ch in s:
        if ch.isdigit():
            out.append(ONES[int(ch)])
        else:
            out.append(ch)
    return " ".join(out)


def decimal_to_khmer_words(num_str: str) -> str:
    # Your preference: decimal separator spoken as "ចុច"
    s = km_digits_to_latin(num_str.strip())
    if "." in s:
        a, b = s.split(".", 1)
        a_int = int(a) if a else 0
        return f"{int_to_khmer_words(a_int)} ចុច {digits_to_khmer_words(b)}"
    if "," in s:
        a, b = s.split(",", 1)
        a_int = int(a) if a else 0
        return f"{int_to_khmer_words(a_int)} ចុច {digits_to_khmer_words(b)}"
    return int_to_khmer_words(parse_int_mixed(s))


def looks_decimal(s: str) -> bool:
    return bool(re.search(r"[.,]", s))