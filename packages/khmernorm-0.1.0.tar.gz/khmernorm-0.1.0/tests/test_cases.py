from khmer_normalizer import normalize

def run():
    tests = [
        "សូមទូរស័ព្ទទៅ 012-345-678 នៅម៉ោង 14:30។",
        "ថ្ងៃនេះគឺ 2026-02-14 និងតម្លៃ $12.50 ឬ ៛10000។",
        "ជួបគ្នា 14 កុម្ភៈ 2026។",
        "បញ្ចុះតម្លៃ 12% និងទំងន់ 2.5kg។",
        "ចន្លោះ 10-20 និងប្រភាគ 1/2។",
        "លំដាប់ទី 3 និងឆ្នាំ 1998។",
        "Email: rom.need@example.com",
        "ID: AB12-9007",
        "I work on NLP and TTS in USA.",
    ]
    for t in tests:
        print("IN :", t)
        print("OUT:", normalize(t))
        print("---")

if __name__ == "__main__":
    run()