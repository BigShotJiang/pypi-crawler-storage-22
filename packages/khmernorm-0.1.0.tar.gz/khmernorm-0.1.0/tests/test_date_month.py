from khmer_normalizer import normalize

print(normalize("ថ្ងៃនេះគឺ 2026-02-14។"))
# Expected: "ថ្ងៃនេះគឺ ថ្ងៃទី ដប់បួន ខែ កុម្ភៈ ឆ្នាំ ពីរ ពាន់ ម្ភៃ ប្រាំមួយ។"

print(normalize("កំណត់ត្រា 14/02/2026"))
# Expected: "កំណត់ត្រា ថ្ងៃទី ដប់បួន ខែ កុម្ភៈ ឆ្នាំ ពីរ ពាន់ ម្ភៃ ប្រាំមួយ"