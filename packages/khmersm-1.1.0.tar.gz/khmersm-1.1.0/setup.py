from setuptools import setup, find_packages

setup(
    name="khmersm",
    version="1.1.0",
    description="Khmer Segmentation Model (ONNX)",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="",
    url="",
    packages=find_packages(include=["khmersm"]),
    include_package_data=True,
    package_data={"khmersm": ["config.json", "model.onnx"]},
    install_requires=[
        "numpy>=1.26.0",
        "onnxruntime>=1.23.2",
    ],
    python_requires=">=3.12",
)
