# khmersm
Fast Khmer word segmentation via ONNX.

## Install
```
pip install khmersm
```

## Usage
```python
from khmersm import segment

print(segment("ខ្ញុំស្រលាញ់កម្ពុជា i love Cambodia"))
```
