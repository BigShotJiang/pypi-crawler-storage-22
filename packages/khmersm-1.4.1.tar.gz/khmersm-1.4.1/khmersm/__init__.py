from .inference import Segmenter, segment

__all__ = ["Segmenter", "segment"]
