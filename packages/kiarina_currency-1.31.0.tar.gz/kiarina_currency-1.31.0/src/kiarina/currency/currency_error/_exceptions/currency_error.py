class CurrencyError(Exception):
    pass
