from typing import TypeAlias

RateProviderName: TypeAlias = str
