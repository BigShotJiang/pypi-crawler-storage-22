from importlib import import_module
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._models.static_rate_provider import StaticRateProvider
    from ._settings import StaticRateProviderSettings, settings_manager

__all__ = [
    # ._models
    "StaticRateProvider",
    # ._settings
    "StaticRateProviderSettings",
    "settings_manager",
]


def __getattr__(name: str) -> object:
    if name not in __all__:  # pragma: no cover
        raise AttributeError(f"module {__name__} has no attribute {name}")

    module_map = {
        # ._models
        "StaticRateProvider": "._models.static_rate_provider",
        # ._settings
        "StaticRateProviderSettings": "._settings",
        "settings_manager": "._settings",
    }

    globals()[name] = getattr(import_module(module_map[name], __name__), name)
    return globals()[name]
