from .currency_error import CurrencyError


class ExchangeRateNotFoundError(CurrencyError):
    pass
