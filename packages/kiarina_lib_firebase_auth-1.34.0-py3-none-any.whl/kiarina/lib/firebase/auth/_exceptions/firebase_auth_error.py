class FirebaseAuthError(Exception):
    """Base exception for Firebase Auth errors."""

    pass
