import httpx
import pytest

from kiarina.lib.firebase.auth import (
    FirebaseAPIError,
    InvalidRefreshTokenError,
    exchange_custom_token,
    refresh_id_token,
    settings_manager,
)


async def test_invalid_refresh_token(load_settings) -> None:
    settings = settings_manager.get_settings()

    with pytest.raises(InvalidRefreshTokenError):
        await refresh_id_token(
            refresh_token="invalid_refresh_token",
            api_key=settings.api_key.get_secret_value(),
        )


async def test_firebase_api_error() -> None:
    with pytest.raises(FirebaseAPIError):
        await refresh_id_token(
            refresh_token="invalid_refresh_token",
            api_key="invalid_api_key",
        )


async def test_httpx_reqest_error(monkeypatch) -> None:
    def mock_post(*args, **kwargs):
        raise httpx.RequestError("Network error")

    monkeypatch.setattr("httpx.AsyncClient.post", mock_post)

    with pytest.raises(FirebaseAPIError) as exc_info:
        await refresh_id_token(
            refresh_token="some_refresh_token",
            api_key="invalid_api_key",
        )

    assert "Request failed" in str(exc_info.value)


async def test_happy_path(firebase_app) -> None:
    auth = pytest.importorskip("firebase_admin.auth")

    custom_token = auth.create_custom_token("test").decode("utf-8")

    settings = settings_manager.get_settings()
    exchange_token_data = await exchange_custom_token(
        custom_token=custom_token,
        api_key=settings.api_key.get_secret_value(),
    )

    token_data = await refresh_id_token(
        refresh_token=exchange_token_data.refresh_token,
        api_key=settings.api_key.get_secret_value(),
    )

    assert token_data.id_token
    assert token_data.refresh_token
    assert token_data.expires_at
