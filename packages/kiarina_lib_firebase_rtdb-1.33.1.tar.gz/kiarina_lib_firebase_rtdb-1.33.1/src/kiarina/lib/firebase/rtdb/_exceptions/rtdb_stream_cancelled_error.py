class RTDBStreamCancelledError(Exception):
    """RTDB stream was cancelled by server."""

    pass
