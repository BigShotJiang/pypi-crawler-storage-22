"""KiCad Design Assistant - AI-powered design review and repair."""

__version__ = "2.0.0"
