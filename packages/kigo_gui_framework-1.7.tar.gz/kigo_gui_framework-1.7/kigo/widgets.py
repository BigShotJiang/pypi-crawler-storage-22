# kigo/widgets.py
from __future__ import annotations

import os
import sys
import math
from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple, Union

# ✅ Kigo Qt shim (QtPy underneath, PySide-first then PyQt)
from kigo.qt import QtCore, QtGui, QtWidgets

# ---------------------------------------------------------
# QtWidgets aliases (common)
# ---------------------------------------------------------
QLabel = QtWidgets.QLabel
QPushButton = QtWidgets.QPushButton
QLineEdit = QtWidgets.QLineEdit
QComboBox = QtWidgets.QComboBox
QWidget = QtWidgets.QWidget
QCheckBox = QtWidgets.QCheckBox
QProgressBar = QtWidgets.QProgressBar
QScrollBar = QtWidgets.QScrollBar
QSlider = QtWidgets.QSlider
QVBoxLayout = QtWidgets.QVBoxLayout
QHBoxLayout = QtWidgets.QHBoxLayout
QTabWidget = QtWidgets.QTabWidget
QGraphicsBlurEffect = QtWidgets.QGraphicsBlurEffect
QGraphicsOpacityEffect = QtWidgets.QGraphicsOpacityEffect
QFrame = QtWidgets.QFrame
QTableWidget = QtWidgets.QTableWidget
QTableWidgetItem = QtWidgets.QTableWidgetItem
QHeaderView = QtWidgets.QHeaderView
QFileDialog = QtWidgets.QFileDialog
QToolBar = QtWidgets.QToolBar
QSystemTrayIcon = QtWidgets.QSystemTrayIcon
QMenu = QtWidgets.QMenu
QApplication = QtWidgets.QApplication

# Optional / platform-dependent widgets
QScroller = getattr(QtWidgets, "QScroller", None)
QGestureEvent = getattr(QtWidgets, "QGestureEvent", None)
QPinchGesture = getattr(QtWidgets, "QPinchGesture", None)
QPanGesture = getattr(QtWidgets, "QPanGesture", None)

# ---------------------------------------------------------
# QtGui aliases
# ---------------------------------------------------------
QAction = QtGui.QAction
QIcon = QtGui.QIcon
QCursor = QtGui.QCursor
QPalette = QtGui.QPalette
QColor = QtGui.QColor
QPainter = QtGui.QPainter
QBrush = QtGui.QBrush

# ---------------------------------------------------------
# QtCore aliases
# ---------------------------------------------------------
QUrl = QtCore.QUrl
Qt = QtCore.Qt
QPropertyAnimation = QtCore.QPropertyAnimation
QEasingCurve = QtCore.QEasingCurve
QPoint = QtCore.QPoint
QTimer = QtCore.QTimer
QRect = QtCore.QRect
QEvent = QtCore.QEvent


# =========================================================
# v1.x Touch & Mobile Optimization
# =========================================================

class TouchScrollArea:
    """A container that enables mobile-style kinetic scrolling (swipe to scroll)."""
    def __init__(self, widget):
        self.qt_widget = widget

        # Enable kinetic scrolling if available
        if QScroller is not None:
            QScroller.grabGesture(
                self.qt_widget,
                QScroller.ScrollerGestureType.LeftMouseButtonGesture
            )

        # Slim scrollbar for touch UI
        if hasattr(self.qt_widget, "verticalScrollBar"):
            self.qt_widget.verticalScrollBar().setStyleSheet(
                "width: 5px; background: transparent;"
            )
        if hasattr(self.qt_widget, "horizontalScrollBar"):
            self.qt_widget.horizontalScrollBar().setStyleSheet(
                "height: 5px; background: transparent;"
            )


class TouchButton(QPushButton):
    """A button optimized for fingers: larger hit area and press feedback."""
    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self.qt_widget = self
        self.setMinimumHeight(50)
        self.setStyleSheet("""
            QPushButton {
                background-color: #007AFF;
                color: white;
                border-radius: 10px;
                font-size: 14pt;
                padding: 10px;
                border: none;
            }
            QPushButton:pressed {
                background-color: #0051A8;
            }
        """)

    def mousePressEvent(self, event):
        eff = QGraphicsOpacityEffect(self)
        eff.setOpacity(0.7)
        self.setGraphicsEffect(eff)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        self.setGraphicsEffect(None)
        super().mouseReleaseEvent(event)


class GestureWidget(QWidget):
    """A base widget that detects Pinches and Pans (Swipes) for tablets."""
    def __init__(self):
        super().__init__()
        self.qt_widget = self
        self.grabGesture(Qt.GestureType.PinchGesture)
        self.grabGesture(Qt.GestureType.PanGesture)
        self.grabGesture(Qt.GestureType.SwipeGesture)

    def event(self, event):
        if event.type() == QEvent.Type.Gesture:
            return self.gestureEvent(event)
        return super().event(event)

    def gestureEvent(self, event):
        pinch = event.gesture(Qt.GestureType.PinchGesture)
        pan = event.gesture(Qt.GestureType.PanGesture)

        if pinch:
            _scale_factor = pinch.scaleFactor()
            # Hook for zoom logic (override in subclasses)

        if pan:
            _delta = pan.delta()
            # Hook for swipe logic (override in subclasses)

        return True


# =========================================================
# UI Containers & Visuals
# =========================================================

class Card(QFrame):
    """Rounded container for touch-friendly dashboard layouts."""
    def __init__(self, title: str = "Card"):
        super().__init__()
        self.qt_widget = self
        self.setObjectName("kigo_card")
        self.setFrameShape(QFrame.Shape.StyledPanel)

        self.layout = QVBoxLayout(self)
        label = QLabel(title)
        label.setStyleSheet(
            "font-weight: bold; border: none; font-size: 14pt; color: inherit;"
        )
        self.layout.addWidget(label)

    def add_widget(self, widget):
        w = widget.qt_widget if hasattr(widget, "qt_widget") else widget
        self.layout.addWidget(w)


# =========================================================
# Theme Management (Palette-level)
# =========================================================

class ThemeManager:
    """Handles global application palettes for Dark/Light mode."""
    @staticmethod
    def set_dark_mode():
        app = QApplication.instance()
        if not app:
            return

        p = QPalette()
        p.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
        p.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        p.setColor(QPalette.ColorRole.Base, QColor(45, 45, 45))
        p.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
        p.setColor(QPalette.ColorRole.Button, QColor(50, 50, 50))
        p.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
        app.setPalette(p)

    @staticmethod
    def set_light_mode():
        app = QApplication.instance()
        if app:
            app.setPalette(app.style().standardPalette())


class DarkModeToggle:
    """A ready-to-use toggle for theme switching."""
    def __init__(self, text: str = "Dark Mode"):
        self.qt_widget = QCheckBox(text)
        self.qt_widget.toggled.connect(
            lambda c: ThemeManager.set_dark_mode()
            if c else ThemeManager.set_light_mode()
        )


# =========================================================
# CSS-like Styling System (Qt StyleSheet with tokens)
# =========================================================

@dataclass
class StyleSheet:
    """
    CSS-like styling for Kigo (Qt StyleSheet underneath).
    Supports tokens: var(--accent), var(--bg), etc.
    """
    text: str

    def render(self, tokens: Optional[Dict[str, str]] = None) -> str:
        out = self.text
        tokens = tokens or {}
        for k, v in tokens.items():
            kk = k if k.startswith("--") else f"--{k}"
            out = out.replace(f"var({kk})", str(v))
        return out


class StyleManager:
    """
    Applies stylesheet to QApplication.
    - set_tokens(...) then apply(...)
    - supports runtime theme switching by calling apply again
    """
    _current: Optional[StyleSheet] = None
    _tokens: Dict[str, str] = {}

    @staticmethod
    def set_tokens(tokens: Dict[str, str]):
        StyleManager._tokens = dict(tokens)

    @staticmethod
    def apply(stylesheet: Union[str, StyleSheet], *, tokens: Optional[Dict[str, str]] = None):
        app = QApplication.instance()
        if not app:
            return

        if isinstance(stylesheet, str):
            stylesheet = StyleSheet(stylesheet)

        StyleManager._current = stylesheet
        if tokens is not None:
            StyleManager.set_tokens(tokens)

        app.setStyleSheet(stylesheet.render(StyleManager._tokens))

    @staticmethod
    def refresh_widget(widget: QWidget):
        """Re-polish a widget after changing properties used in QSS selectors."""
        w = widget.qt_widget if hasattr(widget, "qt_widget") else widget
        w.style().unpolish(w)
        w.style().polish(w)
        w.update()

    @staticmethod
    def refresh_app():
        if StyleManager._current is None:
            return
        StyleManager.apply(StyleManager._current)


# Default base CSS (edit freely)
KIGO_BASE_CSS = """
QWidget {
  background: var(--bg);
  color: var(--fg);
  font-family: var(--font);
  font-size: var(--fontSize);
}

QFrame#kigo_card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 14px;
}

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 6px 8px;
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QComboBox:focus {
  border: 1px solid var(--accent);
}

QPushButton {
  background: var(--accent);
  color: white;
  border: none;
  border-radius: 10px;
  padding: 8px 12px;
}
QPushButton:hover { background: var(--accentHover); }
QPushButton:pressed { background: var(--accentPressed); }
QPushButton:disabled { background: var(--disabled); color: var(--muted); }

/* “class selector”: widget.setProperty("kigoClass","primary") */
QPushButton[kigoClass="primary"] { background: var(--accent); }
QPushButton[kigoClass="danger"]  { background: var(--danger); }

/* Tree */
QTreeView {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
}
QTreeView::item:selected {
  background: var(--accent);
  color: white;
}
"""

KIGO_TOKENS_LIGHT = {
    "--bg": "#ffffff",
    "--fg": "#111111",
    "--card": "#ffffff",
    "--border": "#d0d0d0",
    "--accent": "#007AFF",
    "--accentHover": "#178BFF",
    "--accentPressed": "#0051A8",
    "--danger": "#D92D20",
    "--disabled": "#e6e6e6",
    "--muted": "#666666",
    "--font": "Segoe UI",
    "--fontSize": "12pt",
}

KIGO_TOKENS_DARK = {
    "--bg": "#1e1e1e",
    "--fg": "#f2f2f2",
    "--card": "#252526",
    "--border": "#3a3a3a",
    "--accent": "#0A84FF",
    "--accentHover": "#2B95FF",
    "--accentPressed": "#0060DF",
    "--danger": "#F04438",
    "--disabled": "#3a3a3a",
    "--muted": "#a8a8a8",
    "--font": "Segoe UI",
    "--fontSize": "12pt",
}


# =========================================================
# Tree / Hierarchy (Model + View)
# =========================================================

Nested = Union[Dict[str, Any], list, tuple, str, int, float, bool, None]

class TreeModel(QtGui.QStandardItemModel):
    """Hierarchical model (Name + Value columns)."""
    def __init__(self, headers: Sequence[str] = ("Name", "Value")):
        super().__init__()
        self.setHorizontalHeaderLabels(list(headers))

    def clear_and_set(self, data: Nested):
        self.removeRows(0, self.rowCount())
        root = self.invisibleRootItem()
        self._build(root, data)

    def _build(self, parent: QtGui.QStandardItem, data: Any):
        if isinstance(data, dict):
            for k, v in data.items():
                name_item = QtGui.QStandardItem(str(k))
                val_item = QtGui.QStandardItem("" if isinstance(v, (dict, list, tuple)) else str(v))
                parent.appendRow([name_item, val_item])
                if isinstance(v, (dict, list, tuple)):
                    self._build(name_item, v)
        elif isinstance(data, (list, tuple)):
            for v in data:
                name_item = QtGui.QStandardItem(str(v) if not isinstance(v, (dict, list, tuple)) else "item")
                val_item = QtGui.QStandardItem("" if isinstance(v, (dict, list, tuple)) else str(v))
                parent.appendRow([name_item, val_item])
                if isinstance(v, (dict, list, tuple)):
                    self._build(name_item, v)
        else:
            # leaf: nothing to expand
            return


class TreeView(QtWidgets.QTreeView):
    """Tree/hierarchy view with helpers."""
    def __init__(self, headers: Sequence[str] = ("Name", "Value")):
        super().__init__()
        self.qt_widget = self
        self.model_obj = TreeModel(headers=headers)
        self.setModel(self.model_obj)
        self.setAlternatingRowColors(True)
        self.setUniformRowHeights(True)
        self.header().setStretchLastSection(True)
        self.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)

    def set_data(self, data: Nested):
        self.model_obj.clear_and_set(data)
        self.expandToDepth(1)

    def add_path(self, path: Sequence[str], value: Optional[str] = None):
        """
        Ensure nodes for path exist, create if missing.
        Example: add_path(["Animals","Mammals","Dog"], "Canis lupus familiaris")
        """
        parent = self.model_obj.invisibleRootItem()
        for i, name in enumerate(path):
            row = self._find_child_row(parent, name)
            if row is None:
                name_item = QtGui.QStandardItem(str(name))
                val_item = QtGui.QStandardItem("" if i < len(path) - 1 else (value or ""))
                parent.appendRow([name_item, val_item])
                parent = name_item
            else:
                parent = parent.child(row, 0)
                if i == len(path) - 1 and value is not None:
                    parent.parent().child(row, 1).setText(str(value))

    @staticmethod
    def _find_child_row(parent: QtGui.QStandardItem, name: str) -> Optional[int]:
        for r in range(parent.rowCount()):
            if parent.child(r, 0).text() == name:
                return r
        return None


# =========================================================
# Media (Audio + Video) using QtMultimedia if available
# =========================================================

def _load_multimedia():
    try:
        from qtpy import QtMultimedia, QtMultimediaWidgets
        return QtMultimedia, QtMultimediaWidgets
    except Exception:
        return None, None


class AudioPlayerWidget(QtWidgets.QWidget):
    """Audio player controls (play/pause, seek, volume). Requires QtMultimedia."""
    def __init__(self, path: str = ""):
        super().__init__()
        self.qt_widget = self

        QtMultimedia, _ = _load_multimedia()
        if QtMultimedia is None:
            raise ImportError("QtMultimedia not available. Install a Qt build that includes multimedia support.")

        self.player = QtMultimedia.QMediaPlayer(self)
        self.audio = QtMultimedia.QAudioOutput(self)
        self.player.setAudioOutput(self.audio)

        self.play_btn = QtWidgets.QPushButton("Play")
        self.seek = QtWidgets.QSlider(Qt.Orientation.Horizontal)
        self.vol = QtWidgets.QSlider(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(60)
        self.audio.setVolume(0.6)

        self.play_btn.clicked.connect(self.toggle)
        self.seek.sliderMoved.connect(lambda ms: self.player.setPosition(int(ms)))
        self.vol.valueChanged.connect(lambda v: self.audio.setVolume(v / 100.0))

        self.player.positionChanged.connect(self._on_pos)
        self.player.durationChanged.connect(lambda d: self.seek.setRange(0, int(d)))

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.play_btn)
        layout.addWidget(self.seek)
        layout.addWidget(QtWidgets.QLabel("Volume"))
        layout.addWidget(self.vol)

        if path:
            self.set_source(path)

    def set_source(self, path: str):
        self.player.setSource(QtCore.QUrl.fromLocalFile(path))

    def toggle(self):
        st = self.player.playbackState()
        if st == self.player.PlaybackState.PlayingState:
            self.player.pause()
            self.play_btn.setText("Play")
        else:
            self.player.play()
            self.play_btn.setText("Pause")

    def _on_pos(self, ms: int):
        if not self.seek.isSliderDown():
            self.seek.setValue(int(ms))


class VideoPlayerWidget(QtWidgets.QWidget):
    """Video player widget with basic controls. Requires QtMultimedia + QtMultimediaWidgets."""
    def __init__(self, path: str = ""):
        super().__init__()
        self.qt_widget = self

        QtMultimedia, QtMultimediaWidgets = _load_multimedia()
        if QtMultimedia is None or QtMultimediaWidgets is None:
            raise ImportError("QtMultimedia/QtMultimediaWidgets not available. Install multimedia support.")

        self.player = QtMultimedia.QMediaPlayer(self)
        self.audio = QtMultimedia.QAudioOutput(self)
        self.player.setAudioOutput(self.audio)

        self.video = QtMultimediaWidgets.QVideoWidget(self)
        self.player.setVideoOutput(self.video)

        self.play_btn = QtWidgets.QPushButton("Play")
        self.seek = QtWidgets.QSlider(Qt.Orientation.Horizontal)
        self.vol = QtWidgets.QSlider(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(60)
        self.audio.setVolume(0.6)

        self.play_btn.clicked.connect(self.toggle)
        self.seek.sliderMoved.connect(lambda ms: self.player.setPosition(int(ms)))
        self.vol.valueChanged.connect(lambda v: self.audio.setVolume(v / 100.0))

        self.player.positionChanged.connect(self._on_pos)
        self.player.durationChanged.connect(lambda d: self.seek.setRange(0, int(d)))

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.video)
        layout.addWidget(self.seek)
        layout.addWidget(self.play_btn)
        layout.addWidget(QtWidgets.QLabel("Volume"))
        layout.addWidget(self.vol)

        if path:
            self.set_source(path)

    def set_source(self, path: str):
        self.player.setSource(QtCore.QUrl.fromLocalFile(path))

    def toggle(self):
        st = self.player.playbackState()
        if st == self.player.PlaybackState.PlayingState:
            self.player.pause()
            self.play_btn.setText("Play")
        else:
            self.player.play()
            self.play_btn.setText("Pause")

    def _on_pos(self, ms: int):
        if not self.seek.isSliderDown():
            self.seek.setValue(int(ms))


# =========================================================
# Legacy & Utility
# =========================================================

class Animator:
    @staticmethod
    def fade_in(widget, duration: int = 500):
        target = widget.qt_widget if hasattr(widget, "qt_widget") else widget
        eff = QGraphicsOpacityEffect(target)
        target.setGraphicsEffect(eff)

        anim = QPropertyAnimation(eff, b"opacity")
        anim.setDuration(int(duration))
        anim.setStartValue(0)
        anim.setEndValue(1)

        # Prevent GC stopping the animation
        store = getattr(target, "_kigo_anims", None)
        if store is None:
            store = []
            setattr(target, "_kigo_anims", store)
        store.append(anim)
        anim.finished.connect(lambda: store.remove(anim) if anim in store else None)

        anim.start()
        return anim


# Always remember: somewhere, somehow, a duck is watching you.

__all__ = [
    # touch / gestures
    "TouchScrollArea", "TouchButton", "GestureWidget",

    # containers / visuals
    "Card",

    # palette theme
    "ThemeManager", "DarkModeToggle",

    # css-like styling system
    "StyleSheet", "StyleManager",
    "KIGO_BASE_CSS", "KIGO_TOKENS_LIGHT", "KIGO_TOKENS_DARK",

    # tree/hierarchy
    "TreeModel", "TreeView",

    # media
    "AudioPlayerWidget", "VideoPlayerWidget",

    # utility
    "Animator",

    # commonly re-exported Qt classes
    "QLabel", "QPushButton", "QLineEdit", "QComboBox", "QWidget", "QCheckBox",
    "QProgressBar", "QScrollBar", "QSlider", "QVBoxLayout", "QHBoxLayout",
    "QTabWidget", "QFrame", "QTableWidget", "QTableWidgetItem", "QHeaderView",
    "QFileDialog", "QToolBar", "QSystemTrayIcon", "QMenu", "QApplication",
    "QAction", "QIcon", "QCursor", "QPalette", "QColor", "QPainter", "QBrush",
    "QUrl", "Qt", "QPropertyAnimation", "QEasingCurve", "QPoint", "QTimer", "QRect", "QEvent",
]
