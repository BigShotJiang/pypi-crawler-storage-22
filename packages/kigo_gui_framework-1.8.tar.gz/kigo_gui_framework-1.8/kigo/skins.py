# kigo/skins.py
from __future__ import annotations

from typing import Dict, Tuple, Optional
from kigo.qt import QtCore

# We reuse your existing StyleManager from kigo.style
# (keeps one source of truth for "apply stylesheet + tokens")
from kigo.style import StyleManager, StyleSheet

Qt = QtCore.Qt


# ------------------------------------------------------------
# Base CSS (token-driven) — shared by all skins
# ------------------------------------------------------------
KIGO_BASE_CSS = r"""
/* Global */
QWidget {
  background: var(--bg);
  color: var(--fg);
  font-family: var(--font);
  font-size: var(--fontSize);
}

/* Cards / frames */
QFrame#kigo_card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
}

/* Inputs */
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit, QTimeEdit {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--radiusSmall);
  padding: 6px 8px;
  selection-background-color: var(--accent);
  selection-color: var(--onAccent);
}

QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus,
QSpinBox:focus, QComboBox:focus, QDateEdit:focus, QTimeEdit:focus {
  border: 1px solid var(--accent);
}

/* Buttons */
QPushButton {
  background: var(--accent);
  color: var(--onAccent);
  border: 1px solid var(--accentBorder);
  border-radius: var(--radiusSmall);
  padding: 8px 12px;
}

QPushButton:hover { background: var(--accentHover); }
QPushButton:pressed { background: var(--accentPressed); }
QPushButton:disabled { background: var(--disabled); color: var(--muted); border-color: var(--border); }

/* Optional “class selector”: widget.setProperty("kigoClass","primary") */
QPushButton[kigoClass="primary"] { background: var(--accent); }
QPushButton[kigoClass="danger"]  { background: var(--danger); border-color: var(--dangerBorder); }

/* Tree / hierarchy */
QTreeView {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--radiusSmall);
  alternate-background-color: var(--rowAlt);
}

QTreeView::item {
  padding: 4px 6px;
  border-radius: 6px;
}

QTreeView::item:selected {
  background: var(--accent);
  color: var(--onAccent);
}
"""


# ------------------------------------------------------------
# v1.8 Skins
# Each skin = (tokens, extra_css)
# ------------------------------------------------------------

# --- Neon: hacker aesthetic ---
NEON_TOKENS = {
    "--bg": "#050607",
    "--fg": "#C8FFD4",
    "--card": "#071012",
    "--border": "#0B3D2E",
    "--rowAlt": "#061517",

    "--accent": "#00FF9C",
    "--accentHover": "#2BFFB8",
    "--accentPressed": "#00C777",
    "--accentBorder": "#00FF9C",
    "--onAccent": "#02110B",

    "--danger": "#FF2E88",
    "--dangerBorder": "#FF2E88",

    "--disabled": "#1A1F20",
    "--muted": "#6CC9A1",

    "--font": "Consolas",
    "--fontSize": "12pt",
    "--radius": "14px",
    "--radiusSmall": "10px",
}

NEON_EXTRA_CSS = r"""
/* Neon vibe: crisp borders, bright focus */
QFrame#kigo_card {
  border: 1px solid var(--border);
}

QTreeView::item:selected {
  background: #00FF9C;
  color: #02110B;
}
"""


# --- Retro: classic early-2000s / XP-like vibe (inspired) ---
RETRO_TOKENS = {
    "--bg": "#E9F0FB",
    "--fg": "#0B1B2B",
    "--card": "#F6FAFF",
    "--border": "#7A9CC9",
    "--rowAlt": "#EAF2FF",

    "--accent": "#2B66D9",
    "--accentHover": "#3B7AF0",
    "--accentPressed": "#1F4FAF",
    "--accentBorder": "#1B4DA8",
    "--onAccent": "#FFFFFF",

    "--danger": "#D64545",
    "--dangerBorder": "#B93A3A",

    "--disabled": "#D6E2F5",
    "--muted": "#445C7A",

    "--font": "Tahoma",
    "--fontSize": "11pt",
    "--radius": "10px",
    "--radiusSmall": "6px",
}

RETRO_EXTRA_CSS = r"""
/* Retro bevel + gradients */
QFrame#kigo_card {
  background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
              stop:0 #FFFFFF, stop:1 #E7F0FF);
  border: 1px solid var(--border);
  border-radius: var(--radius);
}

QPushButton {
  background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
              stop:0 #FFFFFF, stop:1 #CFE1FF);
  color: #0B1B2B;
  border: 1px solid #6E8FBE;
  border-radius: var(--radiusSmall);
}

QPushButton:hover {
  background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
              stop:0 #FFFFFF, stop:1 #BFD7FF);
}

QPushButton:pressed {
  background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
              stop:0 #BFD7FF, stop:1 #FFFFFF);
}

/* Inputs: slightly inset */
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit, QTimeEdit {
  background: #FFFFFF;
  border: 1px solid #7A9CC9;
  border-top-color: #5E7FAE;
  border-left-color: #5E7FAE;
}
"""


# --- Glass: translucent / transparent look ---
GLASS_TOKENS = {
    "--bg": "rgba(10, 10, 14, 180)",
    "--fg": "#F4F7FF",
    "--card": "rgba(255, 255, 255, 40)",
    "--border": "rgba(255, 255, 255, 70)",
    "--rowAlt": "rgba(255, 255, 255, 25)",

    "--accent": "rgba(90, 170, 255, 210)",
    "--accentHover": "rgba(120, 190, 255, 230)",
    "--accentPressed": "rgba(60, 140, 230, 230)",
    "--accentBorder": "rgba(255, 255, 255, 90)",
    "--onAccent": "#081018",

    "--danger": "rgba(255, 80, 120, 220)",
    "--dangerBorder": "rgba(255, 255, 255, 90)",

    "--disabled": "rgba(255, 255, 255, 25)",
    "--muted": "rgba(240, 245, 255, 160)",

    "--font": "Segoe UI",
    "--fontSize": "12pt",
    "--radius": "16px",
    "--radiusSmall": "12px",
}

GLASS_EXTRA_CSS = r"""
/* Glass look: translucent surfaces and thin borders */
QFrame#kigo_card {
  background: rgba(255, 255, 255, 40);
  border: 1px solid rgba(255, 255, 255, 80);
}

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QDateEdit, QTimeEdit {
  background: rgba(255, 255, 255, 28);
  border: 1px solid rgba(255, 255, 255, 70);
  color: rgba(245, 248, 255, 235);
}

QTreeView {
  background: rgba(255, 255, 255, 22);
  border: 1px solid rgba(255, 255, 255, 70);
}

QTreeView::item:selected {
  background: rgba(90, 170, 255, 210);
  color: #081018;
}
"""


# Skin registry
KIGO_SKINS: Dict[str, Tuple[Dict[str, str], str]] = {
    "neon": (NEON_TOKENS, NEON_EXTRA_CSS),
    "retro": (RETRO_TOKENS, RETRO_EXTRA_CSS),
    "glass": (GLASS_TOKENS, GLASS_EXTRA_CSS),
}


class SkinManager:
    """
    v1.8 Skin manager for Kigo.

    Usage:
        SkinManager.apply("neon")
        SkinManager.apply("retro")
        SkinManager.apply("glass", window=app.root)   # enables translucent background
    """
    current: str = "neon"

    @staticmethod
    def apply(name: str, *, window=None):
        name = (name or "").strip().lower()
        if name not in KIGO_SKINS:
            raise ValueError(f"Unknown skin '{name}'. Available: {sorted(KIGO_SKINS)}")

        tokens, extra_css = KIGO_SKINS[name]
        css = KIGO_BASE_CSS + "\n" + extra_css

        StyleManager.apply(css, tokens=tokens)
        SkinManager.current = name

        if name == "glass" and window is not None:
            enable_glass_window(window)

    @staticmethod
    def available() -> list[str]:
        return sorted(KIGO_SKINS.keys())


def enable_glass_window(window_widget):
    """
    Best-effort translucency for a top-level window.
    This makes the window background transparent so Glass skin looks correct.
    """
    w = getattr(window_widget, "qt_widget", window_widget)
    w.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
    w.setAutoFillBackground(False)


# Convenience helpers
def apply_neon(window=None):  SkinManager.apply("neon", window=window)
def apply_retro(window=None): SkinManager.apply("retro", window=window)
def apply_glass(window=None): SkinManager.apply("glass", window=window)