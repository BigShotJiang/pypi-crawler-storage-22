"""Kikusan - Search and download music from YouTube Music with lyrics."""

from importlib.metadata import version

__version__ = version("kikusan")
