"""Kikusan web interface."""
