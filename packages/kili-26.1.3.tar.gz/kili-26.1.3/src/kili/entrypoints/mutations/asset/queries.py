"""Queries of asset mutations."""

from kili.entrypoints.mutations.project.fragments import PROJECT_FRAGMENT_ID

GQL_ASSIGN_ASSETS = """
mutation assignAssetsToLabelers(
    $where: AssetWhere!,
    $userIds: [String!]!
) {
    data: assignAssetsToLabelers(
        where: $where,
        userIds: $userIds
    ) {
      id
    }
  }
"""

GQL_UPDATE_PROPERTIES_IN_ASSETS = """
mutation(
    $whereArray: [AssetWhere!]!
    $dataArray: [AssetData!]!
) {
  data: updatePropertiesInAssets(
    where: $whereArray,
    data: $dataArray
  ) {
    id
  }
}
"""

GQL_DELETE_MANY_FROM_DATASET = f"""
mutation($where: AssetWhere!) {{
  data: deleteManyFromDataset(where: $where) {{
    {PROJECT_FRAGMENT_ID}
  }}
}}
"""

GQL_ADD_ALL_LABELED_ASSETS_TO_REVIEW = f"""
mutation($where: AssetWhere!) {{
  data: addAllLabeledAssetsToReview(where: $where) {{
    {PROJECT_FRAGMENT_ID}
  }}
}}
"""

GQL_SEND_BACK_ASSETS_TO_QUEUE = f"""
mutation($where: AssetWhere!) {{
  data: sendBackAssetsToQueue(where: $where) {{
    {PROJECT_FRAGMENT_ID}
  }}
}}
"""

GQL_SKIP_ASSET = """
mutation SkipAsset($reason: String!, $where: AssetWhere!) {
  skipAsset(reason: $reason, where: $where) {
    id
  }
}
"""

GQL_UNSKIP_ASSET = """
mutation UnskipAsset($projectId: ID!, $assetId: ID!) {
  unskipAsset(projectId: $projectId, assetId: $assetId)
}
"""
