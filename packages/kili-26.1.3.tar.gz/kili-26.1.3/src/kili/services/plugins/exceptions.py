"""Exceptions for the plugins module."""


class PluginCreationError(Exception):
    """Raised when the plugin creation failed."""
