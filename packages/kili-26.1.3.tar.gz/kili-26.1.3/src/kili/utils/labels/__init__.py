"""Set of utils to work with labels."""
