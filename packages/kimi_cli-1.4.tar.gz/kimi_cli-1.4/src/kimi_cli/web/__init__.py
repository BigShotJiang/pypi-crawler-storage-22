"""Kimi Code CLI Web Interface."""

from kimi_cli.web.app import create_app, run_web_server

__all__ = ["create_app", "run_web_server"]
