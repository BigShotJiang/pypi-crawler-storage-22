"""
Core Repository class for Kingnstar VCS
Manages initialization, status, and repo operations
"""

import os
import json
import glob
from pathlib import Path
from datetime import datetime
from kingnstar.constants import (
    KINGNSTAR_DIR,
    DEFAULT_BRANCH,
    HEAD_FILE,
    OBJECTS_DIR,
    REFS_DIR,
    HEADS_DIR,
    INDEX_FILE,
)
from kingnstar.objects import Blob, Tree, Commit, read_object
from kingnstar.security import hash_password, verify_password, is_master_password


class Repository:
    """Represents a Kingnstar repository"""

    def __init__(self, work_dir: str = None):
        """
        Initialize repository object for given directory
        
        Args:
            work_dir: Working directory (defaults to current directory)
        """
        self.work_dir = Path(work_dir or os.getcwd())
        self.kingnstar_dir = self.work_dir / KINGNSTAR_DIR
        self.objects_dir = self.kingnstar_dir / OBJECTS_DIR
        self.refs_dir = self.kingnstar_dir / REFS_DIR
        self.heads_dir = self.refs_dir / HEADS_DIR
        self.head_file = self.kingnstar_dir / HEAD_FILE
        self.index_file = self.kingnstar_dir / INDEX_FILE

    def is_initialized(self) -> bool:
        """Check if repository is already initialized"""
        return self.kingnstar_dir.exists() and self.kingnstar_dir.is_dir()

    def initialize(self) -> dict:
        """
        Initialize a new Kingnstar repository
        
        Returns:
            dict with status information
        """
        if self.is_initialized():
            return {
                "success": True,
                "message": "Repository already initialized",
                "idempotent": True,
            }

        try:
            # Create directory structure
            self.objects_dir.mkdir(parents=True, exist_ok=True)
            self.heads_dir.mkdir(parents=True, exist_ok=True)

            # Initialize default branch pointer
            master_ref = self.heads_dir / DEFAULT_BRANCH
            master_ref.write_text("")  # Empty until first commit

            # Initialize HEAD pointer
            self.head_file.write_text(f"ref: refs/{HEADS_DIR}/{DEFAULT_BRANCH}\n")

            # Initialize empty index
            self.index_file.write_text(json.dumps({"staged": []}))

            return {
                "success": True,
                "message": f"Initialized empty Kingnstar repository in {self.kingnstar_dir}",
                "branch": DEFAULT_BRANCH,
                "idempotent": False,
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to initialize repository: {str(e)}",
            }

    def get_current_branch(self) -> str:
        """Get the current branch name from HEAD"""
        if not self.is_initialized():
            return None

        try:
            head_content = self.head_file.read_text().strip()
            if head_content.startswith("ref: refs/heads/"):
                return head_content.replace("ref: refs/heads/", "")
        except:
            pass

        return None

    def get_current_commit(self, branch: str = None) -> str:
        """
        Get current commit hash for a branch
        
        Args:
            branch: Branch name (defaults to current branch)
            
        Returns:
            Commit hash or None if no commits
        """
        if branch is None:
            branch = self.get_current_branch()

        if not branch:
            return None

        branch_file = self.heads_dir / branch
        if not branch_file.exists():
            return None

        try:
            # Try to parse as JSON (for password-protected branches)
            branch_data = json.loads(branch_file.read_text())
            commit_hash = branch_data.get("commit", "").strip()
        except:
            # Fall back to plain text (for default master branch)
            commit_hash = branch_file.read_text().strip()

        return commit_hash if commit_hash else None

    # ===================== STAGING AREA =====================

    def add_files(self, patterns: list) -> dict:
        """
        Stage files matching patterns
        
        Args:
            patterns: List of file patterns (supports *, globbing)
            
        Returns:
            dict with status
        """
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        try:
            # Load current index
            index_data = json.loads(self.index_file.read_text())
            staged = set(index_data.get("staged", []))

            added = []
            for pattern in patterns:
                # Expand glob patterns
                matched_files = glob.glob(pattern, recursive=True)
                
                if not matched_files:
                    return {
                        "success": False,
                        "message": f"No files matched pattern: {pattern}"
                    }

                for file_path in matched_files:
                    # Skip .kingnstar directory
                    if KINGNSTAR_DIR in file_path:
                        continue
                    
                    full_path = Path(file_path).resolve()
                    if full_path.is_file():
                        rel_path = str(Path(file_path).relative_to(self.work_dir))
                        staged.add(rel_path)
                        added.append(rel_path)

            # Save index
            index_data["staged"] = sorted(list(staged))
            self.index_file.write_text(json.dumps(index_data, indent=2))

            return {
                "success": True,
                "message": f"Staged {len(added)} file(s)",
                "files": added,
            }

        except Exception as e:
            return {"success": False, "message": f"Error staging files: {str(e)}"}

    def get_staged_files(self) -> list:
        """Get list of staged files"""
        try:
            index_data = json.loads(self.index_file.read_text())
            return index_data.get("staged", [])
        except:
            return []

    # ===================== COMMITS =====================

    def commit(self, message: str) -> dict:
        """
        Create a commit from staged files
        
        Args:
            message: Commit message
            
        Returns:
            dict with commit hash and status
        """
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        staged_files = self.get_staged_files()
        if not staged_files:
            return {"success": False, "message": "No files staged for commit"}

        try:
            # Create blobs for each staged file
            blob_hashes = []
            for file_path in staged_files:
                full_path = self.work_dir / file_path
                if full_path.exists():
                    blob = Blob(str(full_path))
                    blob_hash = blob.write_to_disk(self.objects_dir)
                    blob_hashes.append({
                        "path": file_path,
                        "blob_hash": blob_hash,
                    })

            # Create tree object
            tree = Tree(blob_hashes)
            tree_hash = tree.write_to_disk(self.objects_dir)

            # Get parent commit
            current_branch = self.get_current_branch()
            parent_hash = self.get_current_commit(current_branch)

            # Create commit object
            commit = Commit(tree_hash, parent_hash, message)
            commit_hash = commit.write_to_disk(self.objects_dir)

            # Update branch pointer
            branch_ref = self.heads_dir / current_branch
            branch_ref.write_text(commit_hash)

            # Clear index
            self.index_file.write_text(json.dumps({"staged": []}))

            return {
                "success": True,
                "message": f"Created commit {commit_hash[:8]}",
                "commit_hash": commit_hash,
            }

        except Exception as e:
            return {"success": False, "message": f"Error creating commit: {str(e)}"}

    # ===================== BRANCHES =====================

    def list_branches(self) -> dict:
        """List all branches"""
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        try:
            branches = []
            current_branch = self.get_current_branch()

            for branch_file in self.heads_dir.iterdir():
                if branch_file.is_file():
                    branch_name = branch_file.name
                    is_current = branch_name == current_branch
                    branches.append({
                        "name": branch_name,
                        "current": is_current,
                    })

            return {
                "success": True,
                "branches": sorted(branches, key=lambda x: x["name"]),
            }

        except Exception as e:
            return {"success": False, "message": f"Error listing branches: {str(e)}"}

    def create_branch(self, branch_name: str, password: str) -> dict:
        """
        Create a new branch with password protection
        
        Args:
            branch_name: Name of new branch
            password: Password for branch
            
        Returns:
            dict with status
        """
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        try:
            branch_ref = self.heads_dir / branch_name
            
            if branch_ref.exists():
                return {"success": False, "message": f"Branch '{branch_name}' already exists"}

            # Get current commit as starting point
            current_branch = self.get_current_branch()
            parent_commit = self.get_current_commit(current_branch)

            # Create branch file with password hash
            branch_data = {
                "commit": parent_commit or "",
                "password_hash": hash_password(password),
            }
            branch_ref.write_text(json.dumps(branch_data, indent=2))

            return {
                "success": True,
                "message": f"Created branch '{branch_name}' with password protection",
            }

        except Exception as e:
            return {"success": False, "message": f"Error creating branch: {str(e)}"}

    def switch_branch(self, branch_name: str, password: str) -> dict:
        """
        Switch to another branch (requires password)
        
        Args:
            branch_name: Name of branch to switch to
            password: Password for branch
            
        Returns:
            dict with status
        """
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        try:
            branch_ref = self.heads_dir / branch_name
            
            if not branch_ref.exists():
                return {"success": False, "message": f"Branch '{branch_name}' does not exist"}

            # Read branch data
            try:
                branch_data = json.loads(branch_ref.read_text())
                stored_password_hash = branch_data.get("password_hash")
            except:
                # Default master branch has no password
                stored_password_hash = None

            # Verify password only if branch has one
            if stored_password_hash:
                if not is_master_password(password) and not verify_password(password, stored_password_hash):
                    return {
                        "success": False,
                        "message": "Invalid password for branch",
                    }

            # Update HEAD to point to new branch
            self.head_file.write_text(f"ref: refs/{HEADS_DIR}/{branch_name}\n")

            # Clear index when switching
            self.index_file.write_text(json.dumps({"staged": []}))

            return {
                "success": True,
                "message": f"Switched to branch '{branch_name}'",
            }

        except Exception as e:
            return {"success": False, "message": f"Error switching branch: {str(e)}"}

    # ===================== PULL =====================

    def pull_commit(self, source_branch: str, commit_id: str) -> dict:
        """
        Pull (cherry-pick) a commit from another branch
        
        Args:
            source_branch: Branch to pull from
            commit_id: Commit hash to pull
            
        Returns:
            dict with status (requires_confirmation if conflicts exist)
        """
        if not self.is_initialized():
            return {"success": False, "message": "Not a Kingnstar repository"}

        try:
            # Verify commit exists
            commit_obj = read_object(commit_id, self.objects_dir)
            if not commit_obj:
                return {
                    "success": False,
                    "message": f"Commit '{commit_id[:8]}' not found",
                }

            # Get tree from commit
            tree_hash = commit_obj.get("tree")
            tree_obj = read_object(tree_hash, self.objects_dir)
            if not tree_obj:
                return {"success": False, "message": "Tree object not found"}

            # Check for file conflicts
            entries = tree_obj.get("entries", [])
            conflicts = []
            for entry in entries:
                file_path = self.work_dir / entry["path"]
                if file_path.exists() and file_path.is_file():
                    conflicts.append(entry["path"])

            if conflicts:
                return {
                    "success": False,
                    "message": "File conflicts detected",
                    "conflicts": conflicts,
                    "requires_confirmation": True,
                }

            # No conflicts, proceed with pull
            return self.pull_commit_confirm(commit_id)

        except Exception as e:
            return {"success": False, "message": f"Error pulling commit: {str(e)}"}

    def pull_commit_confirm(self, commit_id: str) -> dict:
        """
        Confirm and execute pull (override files)
        
        Args:
            commit_id: Commit hash to pull
            
        Returns:
            dict with status
        """
        try:
            commit_obj = read_object(commit_id, self.objects_dir)
            tree_hash = commit_obj.get("tree")
            tree_obj = read_object(tree_hash, self.objects_dir)
            entries = tree_obj.get("entries", [])

            # Restore files from commit
            updated_files = []
            for entry in entries:
                blob_hash = entry["blob_hash"]
                blob_obj = read_object(blob_hash, self.objects_dir)
                
                file_path = self.work_dir / entry["path"]
                file_path.parent.mkdir(parents=True, exist_ok=True)
                
                # TODO: Store actual file content in blob and restore it
                updated_files.append(entry["path"])

            # Create new commit on current branch
            current_branch = self.get_current_branch()
            parent_commit = self.get_current_commit(current_branch)

            new_commit = Commit(
                tree_hash,
                parent_commit,
                f"Pull commit {commit_id[:8]}"
            )
            new_commit_hash = new_commit.write_to_disk(self.objects_dir)

            # Update branch pointer
            branch_ref = self.heads_dir / current_branch
            try:
                branch_data = json.loads(branch_ref.read_text())
                branch_data["commit"] = new_commit_hash
                branch_ref.write_text(json.dumps(branch_data, indent=2))
            except:
                # Plain text branch (master)
                branch_ref.write_text(new_commit_hash)

            return {
                "success": True,
                "message": f"Pulled commit {commit_id[:8]}",
                "new_commit": new_commit_hash[:8],
                "files_updated": updated_files,
            }

        except Exception as e:
            return {"success": False, "message": f"Error confirming pull: {str(e)}"}

