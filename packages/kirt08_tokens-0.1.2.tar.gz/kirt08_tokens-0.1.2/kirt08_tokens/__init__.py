__all__ = (
    "Token",
)

from kirt08_tokens.main import Token