import base64

class Base64Url:
    @staticmethod
    def str_encode(data: str) -> str:
        data = data.encode('utf-8')
        encoded = base64.urlsafe_b64encode(data)
        return encoded.rstrip(b'=').decode('ascii')

    @staticmethod
    def str_decode(data: str) -> str:
        padding = '=' * (-len(data) % 4)
        return base64.urlsafe_b64decode(data + padding).decode('utf-8')
