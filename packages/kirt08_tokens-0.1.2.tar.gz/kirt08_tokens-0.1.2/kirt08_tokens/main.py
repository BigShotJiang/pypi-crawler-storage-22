import datetime
import hashlib
import hmac


from kirt08_tokens.base64url import Base64Url

class Token:
    """
    This class contains function to work with tokens;
    token -> payload.iatPart.extPart.mac
    working with signaturing using sha256
    """
    def __init__(self, hmac_domain: str = "test", hmac_sep: str = "|", secret_key: str = "123456"):
        self._HMAC_DOMAIN = hmac_domain
        self._HMAC_SEP = hmac_sep
        self._secret_key = secret_key

    @property
    def time_now(self) -> int:
        return int(datetime.datetime.now(datetime.timezone.utc).timestamp() * 1000)
    
    def compute_hmac(self, data: str) -> str:
        return hmac.new(self._secret_key.encode("utf-8"), data.encode("utf-8"), hashlib.sha256).hexdigest()
    
    def serialize(self, payload: str, issuedAt: str, expiredAt: str) -> str:
        return self._HMAC_DOMAIN + self._HMAC_SEP + payload + self._HMAC_SEP + issuedAt + self._HMAC_SEP + expiredAt

    def generate_token(self, payload: str, ttl_ms: int) -> str:
        token_issuedAt = self.time_now
        token_expiredAt = token_issuedAt + ttl_ms

        token_payload = Base64Url.str_encode(payload)
        token_issuedAt = Base64Url.str_encode(str(token_issuedAt))
        token_expiredAt = Base64Url.str_encode(str(token_expiredAt))

        serialized = self.serialize(token_payload, token_issuedAt, token_expiredAt)
        mac = self.compute_hmac(serialized)

        return f"{token_payload}.{token_issuedAt}.{token_expiredAt}.{mac}"
    
    def verify_token(self, token: str):
        parts = token.split('.')
        if len(parts) != 4:
            return {"valid": False, "reason": "Invalid format"}

        payload, issuedAt, expiredAt, mac = parts

        serialized = self.serialize(payload, issuedAt, expiredAt)
        expected_mac = self.compute_hmac(serialized)
        if not hmac.compare_digest(expected_mac, mac):
            return {"valid": False, "reason": "Invalid signature"}
        
        try:
            iat = int(Base64Url.str_decode(issuedAt))
            if iat > self.time_now + 1000:
                return {"valid": False, "reason": "Issued in future"}
        except Exception:
            return {"valid": False, "reason": "Invalid payload(iat) encoding"}

        try:
            exp = int(Base64Url.str_decode(expiredAt))
            if self.time_now > exp:
                return {"valid": False, "reason": "Expired"}
        except Exception:
            return {"valid": False, "reason": "Invalid payload(exp) encoding"}
        
        return {"valid": True, "payload": Base64Url.str_decode(payload)}
