"""_summary_.

_extended_summary_

:return: _description_
:rtype: _type_
"""

from setuptools import setup

setup()
