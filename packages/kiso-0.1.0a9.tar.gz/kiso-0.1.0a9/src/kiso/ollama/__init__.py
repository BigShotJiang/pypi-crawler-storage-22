"""Ollama software installation."""
