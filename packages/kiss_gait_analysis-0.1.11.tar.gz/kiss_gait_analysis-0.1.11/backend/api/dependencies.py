"""
FastAPI 의존성 주입

FastAPI 엔드포인트를 위한 의존성 주입 함수를 제공합니다.
core.config 모듈의 중앙화된 설정을 사용합니다.
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

from pathlib import Path

from ..core.config import settings


def get_upload_dir() -> Path:
    """
    업로드 디렉토리 경로를 가져옵니다.

    Returns:
        Path: 업로드 디렉토리 경로 (존재하지 않으면 생성됨)
    """
    return settings.upload_dir


def get_results_dir() -> Path:
    """
    결과 디렉토리 경로를 가져옵니다.

    Returns:
        Path: 결과 디렉토리 경로 (존재하지 않으면 생성됨)
    """
    return settings.results_dir


def get_uploads_dir() -> Path:
    """
    업로드 디렉토리 경로를 가져옵니다 (get_upload_dir의 별칭).

    Returns:
        Path: 업로드 디렉토리 경로
    """
    return settings.upload_dir
