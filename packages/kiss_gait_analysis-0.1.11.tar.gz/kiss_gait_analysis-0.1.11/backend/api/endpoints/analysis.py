"""
분석 엔드포인트
보행 분석 실행을 처리합니다
"""

################################################################################
### 저작권/작성자 정보
################################################################################
__author__ = "김훈민"
__copyright__ = ""
__credits__ = [""]
__license__ = "MIT"
__maintainer__ = "김훈민"
__email__ = "hunminkim@kspo.or.kr"
__status__ = "Development"

import json
import logging
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException

from ...models.request_models import AnalysisRequest
from ...models.response_models import AnalysisResponse
from ...services.file_service import FileService
from ...services.gait_events_service import GaitEventsService
from ...services.gait_phase_service import GaitPhaseService
from ..dependencies import get_results_dir, get_upload_dir
from ...utils.gait_metrics import calculate_gait_variability_metrics

logger = logging.getLogger(__name__)

router = APIRouter()

# 서비스 인스턴스
file_service = FileService()
gait_events_service = GaitEventsService()
gait_phase_service = GaitPhaseService()


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_gait(
    request: AnalysisRequest,
    upload_dir: Path = Depends(get_upload_dir),
    results_dir: Path = Depends(get_results_dir),
):
    """
    업로드된 TRC 파일에 대한 보행 분석을 실행합니다.

    이 엔드포인트는 다음을 수행합니다:
    1. 보행 이벤트 탐지 (heel strike, toe off)
    2. 단계 분석 (stance, swing, double stance)
    3. 통계 계산
    4. 선택적 관절각 데이터 통합

    Args:
        request: 분석 설정 포함:
            - job_id: 업로드에서 받은 고유 작업 식별자
            - method: 탐지 방법 (forward_coordinates, height_coordinates, forward_velocity)
            - gait_direction: 보행 이동 방향 (X, -X, Y, -Y, Z, -Z)
            - up_direction: 수직 방향 (X, Y, Z)
            - height_threshold: 높이 임계값 cm (height_coordinates용)
            - velocity_threshold: 속도 임계값 m/s (forward_velocity용)

    Returns:
        AnalysisResponse 포함:
            - events: 탐지된 보행 이벤트 (heel strikes, toe offs)
            - phases: 보행 단계 (stance, swing, double stance)
            - statistics: 계산된 통계
            - timeline_data: 타임라인 시각화 데이터
            - trajectory_data: 마커 궤적 데이터
            - joint_angles: 선택적 관절각 데이터
            - subject_info: 선택적 피험자 정보
    """
    try:
        from ...utils.path_utils import get_subject_path
        
        # 업로드된 파일 경로 가져오기 (하위 폴더 검색 지원)
        file_path = file_service.find_job_file(upload_dir, request.job_id, ".trc")

        if not file_path or not file_path.exists():
            raise HTTPException(status_code=404, detail="Uploaded file not found")

        # 보행 이벤트 탐지 실행
        gait_events_result = gait_events_service.detect_events(
            trc_path=str(file_path),
            method=request.method,
            gait_direction=request.gait_direction,
            up_direction=request.up_direction,
            height_threshold=request.height_threshold,
            velocity_threshold=request.velocity_threshold,
        )

        events = gait_events_result["events"]
        trajectory_data = gait_events_result.get("trajectory_data")

        # 단계 분석 실행
        phases_data = gait_phase_service.analyze_phases(
            events=events,
            trc_path=str(file_path),
            trajectory_data=trajectory_data,
        )

        # 보행 변동성 지표 계산
        gait_variability_metrics = calculate_gait_variability_metrics(
            statistics=phases_data["statistics"],
            timeline_data=phases_data.get("timeline_data"),
            phases=phases_data["phases"],
            events=events,
        )

        # 사용 가능한 경우 관절각 데이터 로드
        joint_angles = None
        angle_path = file_service.find_job_file(upload_dir, request.job_id, "_angles.mot")
        if angle_path and angle_path.exists():
            try:
                joint_angles = file_service.parse_joint_angle_file(angle_path)
            except Exception as angle_error:
                logger.warning(f"Failed to parse joint angle file: {angle_error}")
                joint_angles = None

        # 결과 저장 위치 결정
        target_results_dir = get_subject_path(
            results_dir, 
            request.subject_name, 
            request.subject_date
        )

        # 피험자 정보 가져오기 - 요청에서 우선, 메타데이터 파일로 대체
        subject_info = None
        
        # 먼저, 요청에 subject_info가 제공되었는지 확인
        if request.subject_info:
            subject_info = request.subject_info.model_dump(exclude_none=True)
        
        # 제공되지 않았다면, 메타데이터 파일에서 로드 시도
        if not subject_info:
            metadata_path = file_service.find_job_file(results_dir, request.job_id, "_metadata.json")
            if not metadata_path:
                metadata_path = target_results_dir / f"{request.job_id}_metadata.json"

            if metadata_path.exists():
                try:
                    with open(metadata_path, "r", encoding="utf-8") as f:
                        metadata = json.load(f)
                        subject_info = metadata.get("subject_info")
                except Exception as metadata_error:
                    logger.warning(f"Failed to load metadata: {metadata_error}")

        # 결과 저장
        result_path = target_results_dir / f"{request.job_id}.json"
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "job_id": request.job_id,
                    "events": events,
                    "phases": phases_data["phases"],
                    "statistics": phases_data["statistics"],
                    "timeline_data": phases_data.get("timeline_data", {}),
                    "trajectory_data": trajectory_data,
                    "joint_angles": joint_angles,
                    "subject_info": subject_info,
                    "gait_variability_metrics": gait_variability_metrics,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

        return AnalysisResponse(
            job_id=request.job_id,
            status="completed",
            events=events,
            phases=phases_data["phases"],
            statistics=phases_data["statistics"],
            timeline_data=phases_data.get("timeline_data"),
            trajectory_data=trajectory_data,
            joint_angles=joint_angles,
            subject_info=subject_info,
            gait_variability_metrics=gait_variability_metrics,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
