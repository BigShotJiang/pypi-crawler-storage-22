"""
Core module for KISS Gait Analysis Backend
Contains configuration, exceptions, and shared utilities
"""

from .config import Settings, get_settings, settings

__all__ = ["Settings", "get_settings", "settings"]
