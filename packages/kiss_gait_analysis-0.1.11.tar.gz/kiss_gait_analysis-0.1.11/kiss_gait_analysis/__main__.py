"""
Entry point for running as module: python -m kiss_gait_analysis
"""

from .cli import main

if __name__ == "__main__":
    main()
