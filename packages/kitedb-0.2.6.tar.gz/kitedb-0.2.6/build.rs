fn main() {
  #[cfg(feature = "napi")]
  napi_build::setup();
}
