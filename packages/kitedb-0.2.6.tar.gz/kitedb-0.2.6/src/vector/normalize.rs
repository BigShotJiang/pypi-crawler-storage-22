//! Vector normalization utilities

// Re-exported from distance.rs
pub use super::distance::{is_normalized, l2_norm, normalize, normalize_in_place};
