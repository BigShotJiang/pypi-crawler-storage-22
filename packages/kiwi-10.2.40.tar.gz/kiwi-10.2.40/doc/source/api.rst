.. _api:
  
Python API
==========

.. note::

   This API documentation covers {kiwi} |version|

.. toctree::
   :maxdepth: 1

   api/kiwi
