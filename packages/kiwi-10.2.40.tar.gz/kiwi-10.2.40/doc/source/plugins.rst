KIWI Plugins
============

.. note::

   This document provides a list of the existing {kiwi-product} plugins
   which provides extended functionality for version |version|.

.. toctree::
   :maxdepth: 1

   plugins/self_contained
   plugins/stackbuild
