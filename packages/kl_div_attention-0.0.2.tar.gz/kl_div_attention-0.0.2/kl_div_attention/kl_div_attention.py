import torch
import torch.nn.functional as F
from torch import nn, einsum
from torch.nn import Module

from einops import rearrange

# helpers

def exists(val):
    return val is not None

def default(val, d):
    return val if exists(val) else d

def max_neg_value(t):
    return -torch.finfo(t.dtype).max

# class

class KLDivAttention(Module):
    def __init__(
        self,
        dim,
        heads = 8,
        dim_head = 64,
        causal = False,
        reverse_kl = False
    ):
        super().__init__()
        self.heads = heads
        self.causal = causal
        self.reverse_kl = reverse_kl
        self.scale = dim_head ** -0.5
        inner_dim = heads * dim_head

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Linear(inner_dim, dim, bias = False)

    def forward(self, x):
        device, n, h, causal, reverse_kl = x.device, x.shape[1], self.heads, self.causal, self.reverse_kl

        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = tuple(rearrange(t, 'b n (h d) -> b h n d', h = h) for t in qkv)

        # calculate KL divergence

        tgt_logits = q
        src_logits = k

        if reverse_kl:
            tgt_logits, src_logits = src_logits, tgt_logits

        target = tgt_logits.softmax(dim = -1)
        input = src_logits.log_softmax(dim = -1)

        target = rearrange(target, 'b h i d -> b h i 1 d')
        input = rearrange(input, 'b h j d -> b h 1 j d')

        kl = F.kl_div(input, target, reduction = 'none').sum(dim = -1)

        # attention scores are negative kl divergence

        dist = -kl

        # causal mask

        if causal:
            i, j = dist.shape[-2:]
            causal_mask = torch.ones((i, j), device = device, dtype = torch.bool).triu(j - i + 1)
            dist = dist.masked_fill(causal_mask, max_neg_value(dist))

        # attention

        attn = dist.softmax(dim = -1)

        # aggregate

        out = einsum('b h i j, b h j d -> b h i d', attn, v)

        # merge heads

        out = rearrange(out, 'b h n d -> b n (h d)')

        # combine heads

        return self.to_out(out)
