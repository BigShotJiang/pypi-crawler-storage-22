import pytest
param = pytest.mark.parametrize

import torch

@param('reverse_kl', [True, False])
@param('causal', [True, False])
def test_kl_div_attention(reverse_kl, causal):
    from kl_div_attention.kl_div_attention import KLDivAttention

    attn = KLDivAttention(
        dim = 512,
        reverse_kl = reverse_kl,
        causal = causal
    )
    tokens = torch.randn(1, 1024, 512)

    assert attn(tokens).shape == tokens.shape
