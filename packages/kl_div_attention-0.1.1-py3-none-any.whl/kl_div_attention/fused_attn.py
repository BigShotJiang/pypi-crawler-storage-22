from __future__ import annotations

import torch
from torch import Tensor
from torch.autograd import Function

import triton
import triton.language as tl

# helpers

def exists(v):
    return v is not None

def default(val, d):
    return val if exists(val) else d

# forward kernel with internal distributions (ultra-robust vectorized)

@triton.jit
def _fwd_similarity_kernel(
    Q, K, Mask, Out,
    stride_qb, stride_qh, stride_qi, stride_qd,
    stride_kb, stride_kh, stride_kj, stride_kd,
    stride_mb, stride_mj,
    stride_ob, stride_oh, stride_oi, stride_oj,
    n_heads, seq_q, seq_k, head_dim,
    IS_CAUSAL: tl.constexpr, HAS_MASK: tl.constexpr, REVERSE_KL: tl.constexpr,
    BLOCK_I: tl.constexpr, BLOCK_J: tl.constexpr, BLOCK_D: tl.constexpr,
):
    batch_head_idx = tl.program_id(0)
    i_block_idx = tl.program_id(1)
    j_block_idx = tl.program_id(2)

    batch_idx = batch_head_idx // n_heads
    head_idx = batch_head_idx % n_heads

    off_i = i_block_idx * BLOCK_I + tl.arange(0, BLOCK_I)
    off_j = j_block_idx * BLOCK_J + tl.arange(0, BLOCK_J)
    off_d = tl.arange(0, BLOCK_D)
    
    # 1. Prepare Query Distributions
    qp = Q + batch_idx * stride_qb + head_idx * stride_qh + off_i[:, None] * stride_qi + off_d[None, :] * stride_qd
    q = tl.load(qp, mask = (off_i[:, None] < seq_q) & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
    
    m_q = tl.max(q, 1, keep_dims = True)
    m_q_safe = tl.where(m_q == -float('inf'), 0.0, m_q)
    p_q_un = tl.exp(q - m_q_safe)
    p_q_un = tl.where((m_q == -float('inf')) | (off_d[None, :] >= head_dim), 0.0, p_q_un)
    s_q = tl.sum(p_q_un, 1, keep_dims = True)
    s_q_safe = tl.where(s_q > 0, s_q, 1.0)
    p_q = p_q_un / s_q_safe
    
    l_q = q - m_q_safe - tl.log(s_q_safe)
    l_q = tl.where(off_d[None, :] < head_dim, l_q, 0.0)
    e_q = -tl.sum(tl.where(p_q > 0, p_q * l_q, 0.0), 1, keep_dims = True)
    
    # 2. Prepare Key Distributions
    kp = K + batch_idx * stride_kb + head_idx * stride_kh + off_j[:, None] * stride_kj + off_d[None, :] * stride_kd
    k = tl.load(kp, mask = (off_j[:, None] < seq_k) & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
    
    m_k = tl.max(k, 1, keep_dims = True)
    m_k_safe = tl.where(m_k == -float('inf'), 0.0, m_k)
    p_k_un_dist = tl.exp(k - m_k_safe)
    p_k_un_dist = tl.where((m_k == -float('inf')) | (off_d[None, :] >= head_dim), 0.0, p_k_un_dist)
    s_k = tl.sum(p_k_un_dist, 1, keep_dims = True)
    s_k_safe = tl.where(s_k > 0, s_k, 1.0)
    p_k = p_k_un_dist / s_k_safe
    
    l_k = k - m_k_safe - tl.log(s_k_safe)
    l_k = tl.where(off_d[None, :] < head_dim, l_k, 0.0)
    e_k = -tl.sum(tl.where(p_k > 0, p_k * l_k, 0.0), 1, keep_dims = True)
    
    # 3. Compute Similarity Block (clamped log for float16 safety)
    if not REVERSE_KL:
        l_k_f16 = tl.maximum(l_k, -3e4).to(tl.float16)
        sim = tl.dot(p_q.to(tl.float16), tl.trans(l_k_f16)) + e_q
    else:
        l_q_f16 = tl.maximum(l_q, -3e4).to(tl.float16)
        sim = tl.dot(l_q_f16, tl.trans(p_k.to(tl.float16))) + tl.trans(e_k)
        
    # 4. Apply Masks
    if IS_CAUSAL:
        q_off = seq_k - seq_q
        sim = tl.where(q_off + off_i[:, None] >= off_j[None, :], sim, -float('inf'))
            
    if HAS_MASK:
        mask = tl.load(Mask + batch_idx * stride_mb + off_j * stride_mj, mask = off_j < seq_k, other = False)
        sim = tl.where(mask[None, :], sim, -float('inf'))
    
    # Store Block
    out_ptr = Out + batch_idx * stride_ob + head_idx * stride_oh + off_i[:, None] * stride_oi + off_j[None, :] * stride_oj
    tl.store(out_ptr, sim, mask = (off_i[:, None] < seq_q) & (off_j[None, :] < seq_k))

@triton.jit
def _bwd_similarity_kernel(
    DQ, DK, dS, Q, K,
    stride_dqb, stride_dqh, stride_dqi, stride_dqd,
    stride_dkb, stride_dkh, stride_dkj, stride_dkd,
    stride_sb, stride_sh, stride_si, stride_sj,
    stride_qb, stride_qh, stride_qi, stride_qd,
    stride_kb, stride_kh, stride_kj, stride_kd,
    n_heads, seq_q, seq_k, head_dim,
    REVERSE_KL: tl.constexpr,
    BLOCK_I: tl.constexpr, BLOCK_J: tl.constexpr, BLOCK_D: tl.constexpr,
):
    batch_head_idx = tl.program_id(0)
    batch_idx = batch_head_idx // n_heads
    head_idx = batch_head_idx % n_heads
    off_d = tl.arange(0, BLOCK_D)

    # 1. Compute DQ
    tile_idx_q = tl.program_id(1)
    off_i = tile_idx_q * BLOCK_I + tl.arange(0, BLOCK_I)
    mm = off_i < seq_q
    
    qp = Q + batch_idx * stride_qb + head_idx * stride_qh + off_i[:, None] * stride_qi + off_d[None, :] * stride_qd
    q = tl.load(qp, mask = mm[:, None] & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
    m_q = tl.max(q, 1, keep_dims = True)
    m_q_safe = tl.where(m_q == -float('inf'), 0.0, m_q)
    p_q_un = tl.exp(q - m_q_safe)
    p_q_un = tl.where(m_q == -float('inf'), 0.0, p_q_un)
    s_q = tl.sum(p_q_un, 1, keep_dims = True)
    s_q_safe = tl.where(s_q > 0, s_q, 1.0)
    p_q = p_q_un / s_q_safe
    l_q = q - m_q_safe - tl.log(s_q_safe)
    l_q = tl.where(off_d[None, :] < head_dim, l_q, 0.0)
    e_q = -tl.sum(tl.where(p_q > 0, p_q * l_q, 0.0), 1, keep_dims = True)
    
    dq = tl.zeros((BLOCK_I, BLOCK_D), dtype = tl.float32)
    for sn in range(0, seq_k, BLOCK_J):
        off_j = sn + tl.arange(0, BLOCK_J)
        mj = off_j < seq_k
        ds = tl.load(dS + batch_idx * stride_sb + head_idx * stride_sh + off_i[:, None] * stride_si + off_j[None, :] * stride_sj, mask = mm[:, None] & mj[None, :], other = 0.0)
        
        kp = K + batch_idx * stride_kb + head_idx * stride_kh + off_j[:, None] * stride_kj + off_d[None, :] * stride_kd
        k = tl.load(kp, mask = mj[:, None] & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
        m_k = tl.max(k, 1, keep_dims = True)
        m_k_safe = tl.where(m_k == -float('inf'), 0.0, m_k)
        p_k_un_dist = tl.exp(k - m_k_safe)
        p_k_un_dist = tl.where((m_k == -float('inf')) | (off_d[None, :] >= head_dim), 0.0, p_k_un_dist)
        sk_safe = tl.where(tl.sum(p_k_un_dist, 1, keep_dims = True) > 0, tl.sum(p_k_un_dist, 1, keep_dims = True), 1.0)
        l_k = k - m_k_safe - tl.log(sk_safe)
        l_k = tl.where(off_d[None, :] < head_dim, l_k, 0.0)
        
        if not REVERSE_KL:
            l_k_f16 = tl.maximum(l_k, -3e4).to(tl.float16)
            g_pq = tl.dot(ds.to(tl.float16), l_k_f16)
            g_eq = tl.sum(ds, 1, keep_dims = True)
            pq_dot = tl.sum(tl.where(p_q > 0, p_q * g_pq, 0.0), 1, keep_dims = True)
            dq += p_q * (g_pq - pq_dot) - g_eq * p_q * tl.where(p_q > 0, l_q + e_q, 0.0)
        else:
            p_k = p_k_un_dist / sk_safe
            g_lq = tl.dot(ds.to(tl.float16), p_k.to(tl.float16))
            dq += g_lq - p_q * tl.sum(g_lq, 1, keep_dims = True)

    tl.store(DQ + batch_idx * stride_dqb + head_idx * stride_dqh + off_i[:, None] * stride_dqi + off_d[None, :] * stride_dqd, dq, mask = mm[:, None] & (off_d[None, :] < head_dim))

    # 2. Compute DK
    tile_idx_k = tl.program_id(2)
    off_j = tile_idx_k * BLOCK_J + tl.arange(0, BLOCK_J)
    mj = off_j < seq_k
    
    kp = K + batch_idx * stride_kb + head_idx * stride_kh + off_j[:, None] * stride_kj + off_d[None, :] * stride_kd
    k = tl.load(kp, mask = mj[:, None] & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
    m_k = tl.max(k, 1, keep_dims = True)
    m_k_safe = tl.where(m_k == -float('inf'), 0.0, m_k)
    p_k_un_dist = tl.exp(k - m_k_safe)
    p_k_un_dist = tl.where((m_k == -float('inf')) | (off_d[None, :] >= head_dim), 0.0, p_k_un_dist)
    s_k = tl.sum(p_k_un_dist, 1, keep_dims = True)
    s_k_safe = tl.where(s_k > 0, s_k, 1.0)
    p_k = p_k_un_dist / s_k_safe
    l_k = k - m_k_safe - tl.log(s_k_safe)
    l_k = tl.where(off_d[None, :] < head_dim, l_k, 0.0)
    e_k = -tl.sum(tl.where(p_k > 0, p_k * l_k, 0.0), 1, keep_dims = True)
    
    dk = tl.zeros((BLOCK_J, BLOCK_D), dtype = tl.float32)
    for sm_idx in range(0, seq_q, BLOCK_I):
        off_i = sm_idx + tl.arange(0, BLOCK_I)
        mi = off_i < seq_q
        ds = tl.load(dS + batch_idx * stride_sb + head_idx * stride_sh + off_i[:, None] * stride_si + off_j[None, :] * stride_sj, mask = mi[:, None] & mj[None, :], other = 0.0)
        
        qp = Q + batch_idx * stride_qb + head_idx * stride_qh + off_i[:, None] * stride_qi + off_d[None, :] * stride_qd
        q = tl.load(qp, mask = mi[:, None] & (off_d[None, :] < head_dim), other = -float('inf')).to(tl.float32)
        m_q = tl.max(q, 1, keep_dims = True)
        m_q_safe = tl.where(m_q == -float('inf'), 0.0, m_q)
        p_q_un = tl.where((m_q == -float('inf')) | (off_d[None, :] >= head_dim), 0.0, tl.exp(q - m_q_safe))
        sq_safe = tl.where(tl.sum(p_q_un, 1, keep_dims = True) > 0, tl.sum(p_q_un, 1, keep_dims = True), 1.0)
        p_q = p_q_un / sq_safe
        
        if not REVERSE_KL:
            g_lk = tl.dot(tl.trans(ds.to(tl.float16)), p_q.to(tl.float16))
            dk += g_lk - p_k * tl.sum(g_lk, 1, keep_dims = True)
        else:
            l_q = q - m_q_safe - tl.log(sq_safe)
            l_q = tl.where(off_d[None, :] < head_dim, l_q, 0.0)
            l_q_f16 = tl.maximum(l_q, -3e4).to(tl.float16)
            g_pk = tl.dot(tl.trans(ds.to(tl.float16)), l_q_f16)
            g_ek = tl.sum(ds, 0, keep_dims = True)
            pk_dot = tl.sum(tl.where(p_k > 0, p_k * g_pk, 0.0), 1, keep_dims = True)
            dk += p_k * (g_pk - pk_dot) - tl.trans(g_ek) * p_k * tl.where(p_k > 0, l_k + e_k, 0.0)
            
    tl.store(DK + batch_idx * stride_dkb + head_idx * stride_dkh + off_j[:, None] * stride_dkj + off_d[None, :] * stride_dkd, dk, mask = mj[:, None] & (off_d[None, :] < head_dim))

# Autograd Wrapper

class FusedSimilarityFunction(Function):
    @staticmethod
    def forward(ctx, q, k, mask, causal, reverse_kl):
        batch, heads, seq_q, d = q.shape
        seq_k = k.shape[2]
        out = torch.empty((batch, heads, seq_q, seq_k), device = q.device, dtype = q.dtype)
        grid = (batch * heads, triton.cdiv(seq_q, 32), triton.cdiv(seq_k, 32))
        bd = triton.next_power_of_2(d)
        _fwd_similarity_kernel[grid](
            q, k, mask if exists(mask) else q, out,
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            mask.stride(0) if exists(mask) else 0, mask.stride(1) if exists(mask) else 0,
            out.stride(0), out.stride(1), out.stride(2), out.stride(3),
            heads, seq_q, seq_k, d, IS_CAUSAL = causal, HAS_MASK = exists(mask), REVERSE_KL = reverse_kl, BLOCK_I = 32, BLOCK_J = 32, BLOCK_D = bd
        )
        ctx.save_for_backward(q, k, mask)
        ctx.causal, ctx.reverse_kl = causal, reverse_kl
        return out

    @staticmethod
    def backward(ctx, grad_output):
        q, k, mask = ctx.saved_tensors
        batch, heads, seq_q, d = q.shape
        seq_k = k.shape[2]
        dq, dk = torch.empty_like(q), torch.empty_like(k)
        grad_output = grad_output.contiguous()
        bd = triton.next_power_of_2(d)
        grid = (batch * heads, triton.cdiv(seq_q, 32), triton.cdiv(seq_k, 32))
        _bwd_similarity_kernel[grid](
            dq, dk, grad_output, q, k,
            dq.stride(0), dq.stride(1), dq.stride(2), dq.stride(3),
            dk.stride(0), dk.stride(1), dk.stride(2), dk.stride(3),
            grad_output.stride(0), grad_output.stride(1), grad_output.stride(2), grad_output.stride(3),
            q.stride(0), q.stride(1), q.stride(2), q.stride(3),
            k.stride(0), k.stride(1), k.stride(2), k.stride(3),
            heads, seq_q, seq_k, d, REVERSE_KL = ctx.reverse_kl, BLOCK_I = 32, BLOCK_J = 32, BLOCK_D = bd
        )
        return dq, dk, None, None, None

def fused_compute_kl_div_similarity(q, k, mask = None, causal = False, reverse_kl = False):
    q, k = q.contiguous(), k.contiguous()
    return FusedSimilarityFunction.apply(q, k, mask, causal, reverse_kl)
