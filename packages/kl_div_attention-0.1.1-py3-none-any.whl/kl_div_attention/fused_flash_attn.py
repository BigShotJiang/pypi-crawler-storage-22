from __future__ import annotations

import torch
from torch import Tensor
from torch.autograd import Function

import triton
import triton.language as tl

# helpers

def exists(v):
    return v is not None

def default(val, d):
    return val if exists(val) else d

# full flash attention kernel with pre-computed distributions

@triton.heuristics({
    "EVEN_M": lambda args: args["seqlen_q"] % args["BM"] == 0,
    "EVEN_N": lambda args: args["seqlen_k"] % args["BN"] == 0,
    "EVEN_HEADDIM": lambda args: args["headdim"] == args["BLOCK_HEADDIM"],
})
@triton.jit
def _fwd_flash_kernel(
    PQ, LQ, EQ, PK, LK, EK, V, Out, Mask, LseA,
    stride_pqb, stride_pqh, stride_pqm, stride_pqd,
    stride_lqb, stride_lqh, stride_lqm, stride_lqd,
    stride_eqb, stride_eqh, stride_eqm,
    stride_pkb, stride_pkh, stride_pkn, stride_pkd,
    stride_lkb, stride_lkh, stride_lkn, stride_lkd,
    stride_ekb, stride_ekh, stride_ekn,
    SVB, SVH, SVN, SVD,
    SOB, SOH, SOM, SOD,
    SKMB, SKMN,
    SLAB, SLAH, SLAM,
    n_heads, seqlen_q, seqlen_k, headdim,
    IS_CAUSAL: tl.constexpr, HAS_MASK: tl.constexpr, REVERSE_KL: tl.constexpr,
    BLOCK_HEADDIM: tl.constexpr, EVEN_M: tl.constexpr, EVEN_N: tl.constexpr, EVEN_HEADDIM: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr,
):
    bh = tl.program_id(1)
    b, h = bh // n_heads, bh % n_heads
    sm = tl.program_id(0)

    om = sm * BM + tl.arange(0, BM)
    od = tl.arange(0, BLOCK_HEADDIM)
    on = tl.arange(0, BN)
    mm = om < seqlen_q
    md = od < headdim

    # 1. Load Query Distributions
    if not REVERSE_KL:
        # P_target = PQ, L_input = LK, E_target = EQ
        p_q_ptr = PQ + b * stride_pqb + h * stride_pqh + om[:, None] * stride_pqm + od[None, :] * stride_pqd
        p_q = tl.load(p_q_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
        e_q_ptr = EQ + b * stride_eqb + h * stride_eqh + om * stride_eqm
        e_q = tl.load(e_q_ptr, mask=mm, other=0.0)[:, None]
    else:
        # P_target = PK, L_input = LQ, E_target = EK
        l_q_ptr = LQ + b * stride_lqb + h * stride_lqh + om[:, None] * stride_lqm + od[None, :] * stride_lqd
        l_q = tl.load(l_q_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
        l_q = tl.maximum(l_q, -3e4) # Clamp for float16 safety if needed

    m_i = tl.zeros([BM, 1], tl.float32) - float("inf")
    l_i = tl.zeros([BM, 1], tl.float32)
    acc = tl.zeros([BM, BLOCK_HEADDIM], tl.float32)

    en = seqlen_k if not IS_CAUSAL else tl.minimum((sm + 1) * BM + (seqlen_k - seqlen_q), seqlen_k)

    for sn in range(0, en, BN):
        cn = sn + on
        mn = cn < seqlen_k

        # 2. Load Key Distributions
        if not REVERSE_KL:
            l_k_ptr = LK + b * stride_lkb + h * stride_lkh + cn[:, None] * stride_lkn + od[None, :] * stride_lkd
            l_k = tl.load(l_k_ptr, mask=mn[:, None] & md[None, :], other=-float('inf')).to(tl.float32)
            l_k = tl.maximum(l_k, -3e4).to(tl.float16)
            
            # Similarity S_ij = dot(p_q, trans(l_k)) + e_q
            qk = tl.dot(p_q.to(tl.float16), tl.trans(l_k)) + e_q
        else:
            p_k_ptr = PK + b * stride_pkb + h * stride_pkh + cn[:, None] * stride_pkn + od[None, :] * stride_pkd
            p_k = tl.load(p_k_ptr, mask=mn[:, None] & md[None, :], other=0.0).to(tl.float32)
            e_k_ptr = EK + b * stride_ekb + h * stride_ekh + cn * stride_ekn
            e_k = tl.load(e_k_ptr, mask=mn, other=0.0)[None, :]
            
            # Similarity S_ij = dot(l_q, trans(p_k)) + trans(e_k)
            qk = tl.dot(l_q.to(tl.float16), tl.trans(p_k.to(tl.float16))) + e_k

        if IS_CAUSAL:
            q_off = seqlen_k - seqlen_q
            qk = tl.where(q_off + om[:, None] >= cn[None, :], qk, -float('inf'))

        if HAS_MASK:
            mask = tl.load(Mask + b * SKMB + cn * SKMN, mask=mn, other=False)
            qk = tl.where(mask[None, :], qk, -float('inf'))

        if not EVEN_N:
            qk = tl.where(mn[None, :], qk, -float('inf'))

        # 3. Online Softmax and Value Accumulation
        mij = tl.max(qk, 1, keep_dims = True)
        mi_new = tl.maximum(m_i, mij)
        
        mi_safe_new = tl.where(mi_new == -float('inf'), 0.0, mi_new)
        mi_safe_old = tl.where(m_i == -float('inf'), 0.0, m_i)
        mi_safe_j = tl.where(mij == -float('inf'), 0.0, mij)
        
        al = tl.exp(mi_safe_old - mi_safe_new)
        be = tl.exp(mi_safe_j - mi_safe_new)
        al = tl.where(m_i == -float('inf'), 0.0, al)
        be = tl.where(mij == -float('inf'), 0.0, be)
        
        p_attn = tl.exp(qk - mi_safe_j)
        p_attn = tl.where(mij == -float('inf'), 0.0, p_attn)
        lij = tl.sum(p_attn, 1, keep_dims = True)

        acc *= al

        vp = V + b * SVB + h * SVH + cn[:, None] * SVN + od[None, :]
        v = tl.load(vp, mask=mn[:, None] & md[None, :], other=0.0).to(tl.float32)
        
        acc += tl.dot(p_attn.to(tl.float16), v.to(tl.float16)) * be

        l_i = l_i * al + lij * be
        m_i = mi_new

    li_safe = tl.where(l_i == 0.0, 1.0, l_i)
    acc /= li_safe

    out_ptr = Out + b * SOB + h * SOH + om[:, None] * SOM + od[None, :]
    tl.store(out_ptr, acc.to(Out.dtype.element_ty), mask=mm[:, None] & md[None, :])
    
    lse_a_ptr = LseA + b * SLAB + h * SLAH + om * SLAM
    tl.store(lse_a_ptr, tl.ravel(m_i + tl.log(li_safe)), mask=mm)

@triton.jit
def _bwd_flash_preprocess(
    Out, DO, Delta,
    SOB, SOH, SOM, SDB, SDH, SDM,
    SLAB, SLAH, SLAM,
    n_heads, seqlen_q, headdim,
    BLOCK_HEADDIM: tl.constexpr,
):
    idx = tl.program_id(0)
    bh = tl.program_id(1)
    b, h = bh // n_heads, bh % n_heads
    
    m = idx * 32 + tl.arange(0, 32)
    od = tl.arange(0, BLOCK_HEADDIM)
    mm, md = m < seqlen_q, od < headdim
    
    o_ptr = Out + b * SOB + h * SOH + m[:, None] * SOM + od[None, :]
    do_ptr = DO + b * SDB + h * SDH + m[:, None] * SDM + od[None, :]
    
    o = tl.load(o_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
    do = tl.load(do_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
    
    delta = tl.sum(o * do, 1, keep_dims = True)
    tl.store(Delta + b * SLAB + h * SLAH + m * SLAM, tl.ravel(delta), mask=mm)

@triton.heuristics({
    "EVEN_M": lambda args: args["seqlen_q"] % args["BM"] == 0,
    "EVEN_N": lambda args: args["seqlen_k"] % args["BN"] == 0,
    "EVEN_HEADDIM": lambda args: args["headdim"] == args["BLOCK_HEADDIM"],
})
@triton.jit
def _bwd_flash_kernel(
    PQ, LQ, EQ, PK, LK, EK, V, DO, DPQ, DLQ, DEQ, DPK, DLK, DEK, DV, LseA, Delta, Mask,
    stride_pqb, stride_pqh, stride_pqm, stride_pqd,
    stride_lqb, stride_lqh, stride_lqm, stride_lqd,
    stride_eqb, stride_eqh, stride_eqm,
    stride_pkb, stride_pkh, stride_pkn, stride_pkd,
    stride_lkb, stride_lkh, stride_lkn, stride_lkd,
    stride_ekb, stride_ekh, stride_ekn,
    SVB, SVH, SVN, SVD,
    SDB, SDH, SDM, SDD,
    sdpqb, sdpqh, sdpqm, sdpqd,
    sdlqb, sdlqh, sdlqm, sdlqd,
    sdeqb, sdeqh, sdeqm,
    sdpkb, sdpkh, sdpkn, sdpkd,
    sdlkb, sdlkh, sdlkn, sdlkd,
    sdekb, sdekh, sdekn,
    SDVB, SDVH, SDVN, SDVD,
    SKMB, SKMN, SLAB, SLAH, SLAM,
    n_heads, seqlen_q, seqlen_k, headdim,
    IS_CAUSAL: tl.constexpr, HAS_MASK: tl.constexpr, REVERSE_KL: tl.constexpr,
    BLOCK_HEADDIM: tl.constexpr, EVEN_M: tl.constexpr, EVEN_N: tl.constexpr, EVEN_HEADDIM: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr,
):
    bh = tl.program_id(1)
    b, h = bh // n_heads, bh % n_heads
    sm = tl.program_id(0)
    
    om = sm * BM + tl.arange(0, BM)
    od = tl.arange(0, BLOCK_HEADDIM)
    on = tl.arange(0, BN)
    mm = om < seqlen_q
    md = od < headdim
    
    # Load Q distributions
    if not REVERSE_KL:
        p_q_ptr = PQ + b * stride_pqb + h * stride_pqh + om[:, None] * stride_pqm + od[None, :] * stride_pqd
        p_q = tl.load(p_q_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
        e_q_ptr = EQ + b * stride_eqb + h * stride_eqh + om * stride_eqm
        e_q = tl.load(e_q_ptr, mask=mm, other=0.0)[:, None]
    else:
        l_q_ptr = LQ + b * stride_lqb + h * stride_lqh + om[:, None] * stride_lqm + od[None, :] * stride_lqd
        l_q = tl.load(l_q_ptr, mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)
        l_q = tl.maximum(l_q, -3e4)

    lse_a_raw = tl.load(LseA + b * SLAB + h * SLAH + om * SLAM, mask=mm, other=float("-inf")).to(tl.float32)
    lse_a = lse_a_raw[:, None]
    delta_raw = tl.load(Delta + b * SLAB + h * SLAH + om * SLAM, mask=mm, other=0.0).to(tl.float32)
    delta = delta_raw[:, None]
    do = tl.load(DO + b * SDB + h * SDH + om[:, None] * SDM + od[None, :], mask=mm[:, None] & md[None, :], other=0.0).to(tl.float32)

    dpq = tl.zeros([BM, BLOCK_HEADDIM], tl.float32)
    dlq = tl.zeros([BM, BLOCK_HEADDIM], tl.float32)
    deq = tl.zeros([BM, 1], tl.float32)

    for sn in range(0, seqlen_k, BN):
        cn = sn + on
        mn = cn < seqlen_k

        vp = V + b * SVB + h * SVH + cn[:, None] * SVN + od[None, :]
        v = tl.load(vp, mask=mn[:, None] & md[None, :], other=0.0).to(tl.float32)
        
        if not REVERSE_KL:
            l_k_ptr = LK + b * stride_lkb + h * stride_lkh + cn[:, None] * stride_lkn + od[None, :] * stride_lkd
            l_k = tl.load(l_k_ptr, mask=mn[:, None] & md[None, :], other=-float('inf')).to(tl.float32)
            l_k_f16 = tl.maximum(l_k, -3e4).to(tl.float16)

            qk = tl.dot(p_q.to(tl.float16), tl.trans(l_k_f16)) + e_q
        else:
            p_k_ptr = PK + b * stride_pkb + h * stride_pkh + cn[:, None] * stride_pkn + od[None, :] * stride_pkd
            p_k = tl.load(p_k_ptr, mask=mn[:, None] & md[None, :], other=0.0).to(tl.float32)
            e_k_ptr = EK + b * stride_ekb + h * stride_ekh + cn * stride_ekn
            e_k = tl.load(e_k_ptr, mask=mn, other=0.0)[None, :]
            
            qk = tl.dot(l_q.to(tl.float16), tl.trans(p_k.to(tl.float16))) + e_k

        if IS_CAUSAL:
            q_off = seqlen_k - seqlen_q
            qk = tl.where(om[:, None] + q_off >= cn[None, :], qk, -float('inf'))

        if HAS_MASK:
            mask = tl.load(Mask + b * SKMB + cn * SKMN, mask = mn, other = False)
            qk = tl.where(mask[None, :], qk, -float('inf'))

        lse_safe = tl.where(lse_a == -float('inf'), 0.0, lse_a)
        p_attn = tl.exp(qk - lse_safe)
        p_attn = tl.where((lse_a == -float('inf')) | (~mm[:, None]), 0.0, p_attn)

        # Flash Grad
        dv_contrib = tl.dot(tl.trans(p_attn.to(tl.float16)), do.to(tl.float16))
        tl.atomic_add(DV + b * SDVB + h * SDVH + cn[:, None] * SDVN + od[None, :], dv_contrib, mask = mn[:, None] & md[None, :])
        
        dp = tl.dot(do.to(tl.float16), tl.trans(v.to(tl.float16)))
        ds = p_attn * (dp - delta)

        # ds is grad wrt Similarity matrix S_ij
        if not REVERSE_KL:
            # sim = P_q * L_k + E_q
            dpq += tl.dot(ds.to(tl.float16), l_k_f16)
            dlk_contrib = tl.dot(tl.trans(ds.to(tl.float16)), p_q.to(tl.float16))
            tl.atomic_add(DLK + b * sdlkb + h * sdlkh + cn[:, None] * sdlkn + od[None, :], dlk_contrib, mask = mn[:, None] & md[None, :])
            deq += tl.sum(ds, 1, keep_dims = True)
        else:
            # sim = L_q * P_k + E_k
            dlq += tl.dot(ds.to(tl.float16), p_k.to(tl.float16))
            dpk_contrib = tl.dot(tl.trans(ds.to(tl.float16)), l_q.to(tl.float16))
            tl.atomic_add(DPK + b * sdpkb + h * sdpkh + cn[:, None] * sdpkn + od[None, :], dpk_contrib, mask = mn[:, None] & md[None, :])
            dek_contrib = tl.sum(ds, 0, keep_dims = True)
            tl.atomic_add(DEK + b * sdekb + h * sdekh + cn * sdekn, tl.ravel(dek_contrib), mask = mn)

    # Store DQ results
    if not REVERSE_KL:
        tl.store(DPQ + b * sdpqb + h * sdpqh + om[:, None] * sdpqm + od[None, :], dpq, mask = mm[:, None] & md[None, :])
        tl.store(DEQ + b * sdeqb + h * sdeqh + om * sdeqm, tl.ravel(deq), mask = mm)
    else:
        tl.store(DLQ + b * sdlqb + h * sdlqh + om[:, None] * sdlqm + od[None, :], dlq, mask = mm[:, None] & md[None, :])

class FusedFlashAttnFunction(Function):
    @staticmethod
    def forward(ctx, p_q, l_q, e_q, p_k, l_k, e_k, v, mask, causal, reverse_kl):
        batch, heads, seq_q, d = p_q.shape 
        seq_k = p_k.shape[2]

        lse_a = torch.empty((batch, heads, seq_q), device = p_q.device, dtype = torch.float32)
        o = torch.empty_like(p_q)

        BD = triton.next_power_of_2(d)
        BM, BN = (64, 32) if d <= 64 else (32, 32)
        grid = (triton.cdiv(seq_q, BM), batch * heads)

        _fwd_flash_kernel[grid](
            p_q, l_q, e_q, p_k, l_k, e_k, v, o,
            mask if exists(mask) else p_q, # dummy
            lse_a,
            p_q.stride(0), p_q.stride(1), p_q.stride(2), p_q.stride(3),
            l_q.stride(0), l_q.stride(1), l_q.stride(2), l_q.stride(3),
            e_q.stride(0), e_q.stride(1), e_q.stride(2),
            p_k.stride(0), p_k.stride(1), p_k.stride(2), p_k.stride(3),
            l_k.stride(0), l_k.stride(1), l_k.stride(2), l_k.stride(3),
            e_k.stride(0), e_k.stride(1), e_k.stride(2),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            o.stride(0), o.stride(1), o.stride(2), o.stride(3),
            mask.stride(0) if exists(mask) else 0,
            mask.stride(1) if exists(mask) else 0,
            lse_a.stride(0), lse_a.stride(1), lse_a.stride(2),
            heads, seq_q, seq_k, d,
            IS_CAUSAL = causal,
            HAS_MASK = exists(mask),
            REVERSE_KL = reverse_kl,
            BLOCK_HEADDIM = BD, 
            EVEN_M=(seq_q % BM == 0), EVEN_N=(seq_k % BN == 0), EVEN_HEADDIM=(d == BD), BM=BM, BN=BN
        )

        ctx.save_for_backward(p_q, l_q, e_q, p_k, l_k, e_k, v, o, lse_a, mask)
        ctx.causal, ctx.reverse_kl = causal, reverse_kl
        return o

    @staticmethod
    def backward(ctx, do):
        p_q, l_q, e_q, p_k, l_k, e_k, v, o, lse_a, mask = ctx.saved_tensors
        batch, heads, seq_q, d = p_q.shape
        seq_k = p_k.shape[2]
        
        dp_q = torch.zeros_like(p_q)
        dl_q = torch.zeros_like(l_q)
        de_q = torch.zeros_like(e_q)
        dp_k = torch.zeros_like(p_k)
        dl_k = torch.zeros_like(l_k)
        de_k = torch.zeros_like(e_k)
        dv = torch.zeros_like(v)
        
        delta = torch.empty_like(lse_a)
        
        BD = triton.next_power_of_2(d)
        _bwd_flash_preprocess[(triton.cdiv(seq_q, 32), batch * heads)](
            o, do, delta,
            o.stride(0), o.stride(1), o.stride(2),
            do.stride(0), do.stride(1), do.stride(2),
            delta.stride(0), delta.stride(1), delta.stride(2),
            heads, seq_q, d,
            BLOCK_HEADDIM = BD
        )

        BM, BN = (32, 32) if d <= 64 else (16, 16)
        _bwd_flash_kernel[(triton.cdiv(seq_q, BM), batch * heads)](
            p_q, l_q, e_q, p_k, l_k, e_k, v, do,
            dp_q, dl_q, de_q, dp_k, dl_k, de_k, dv,
            lse_a, delta,
            mask if exists(mask) else p_q, # dummy
            p_q.stride(0), p_q.stride(1), p_q.stride(2), p_q.stride(3),
            l_q.stride(0), l_q.stride(1), l_q.stride(2), l_q.stride(3),
            e_q.stride(0), e_q.stride(1), e_q.stride(2),
            p_k.stride(0), p_k.stride(1), p_k.stride(2), p_k.stride(3),
            l_k.stride(0), l_k.stride(1), l_k.stride(2), l_k.stride(3),
            e_k.stride(0), e_k.stride(1), e_k.stride(2),
            v.stride(0), v.stride(1), v.stride(2), v.stride(3),
            do.stride(0), do.stride(1), do.stride(2), do.stride(3),
            dp_q.stride(0), dp_q.stride(1), dp_q.stride(2), dp_q.stride(3),
            dl_q.stride(0), dl_q.stride(1), dl_q.stride(2), dl_q.stride(3),
            de_q.stride(0), de_q.stride(1), de_q.stride(2),
            dp_k.stride(0), dp_k.stride(1), dp_k.stride(2), dp_k.stride(3),
            dl_k.stride(0), dl_k.stride(1), dl_k.stride(2), dl_k.stride(3),
            de_k.stride(0), de_k.stride(1), de_k.stride(2),
            dv.stride(0), dv.stride(1), dv.stride(2), dv.stride(3),
            mask.stride(0) if exists(mask) else 0,
            mask.stride(1) if exists(mask) else 0,
            lse_a.stride(0), lse_a.stride(1), lse_a.stride(2),
            heads, seq_q, seq_k, d,
            IS_CAUSAL = ctx.causal,
            HAS_MASK = exists(mask),
            REVERSE_KL = ctx.reverse_kl,
            BLOCK_HEADDIM = BD,
            EVEN_M=(seq_q % BM == 0), EVEN_N=(seq_k % BN == 0), EVEN_HEADDIM=(d == BD), BM=BM, BN=BN
        )

        return dp_q, dl_q, de_q, dp_k, dl_k, de_k, dv, None, None, None

def fused_flash_attn(p_q, l_q, e_q, p_k, l_k, e_k, v, mask = None, causal = False, reverse_kl = False):
    return FusedFlashAttnFunction.apply(p_q, l_q, e_q, p_k, l_k, e_k, v, mask, causal, reverse_kl)
