from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn, einsum, Tensor
from torch.nn import Module
from typing import Literal

from einops import rearrange, repeat

# helpers

def exists(val):
    return val is not None

def default(val, d):
    return val if exists(val) else d

def max_neg_value(t):
    return -torch.finfo(t.dtype).max

# triton available

try:
    from .fused_attn import fused_compute_kl_div_similarity as triton_fused_compute_kl_div_similarity
    from .fused_flash_attn import fused_flash_attn as triton_fused_flash_attn
    CAN_USE_FUSED_ATTN = True
except ImportError:
    CAN_USE_FUSED_ATTN = False

# functions

def compute_kl_div_similarity(
    q: Tensor,
    k: Tensor,
    reverse_kl = False,
    head_dimension_at_first = True
):
    """
    Computes the negative KL-divergence similarity between softmax(q) and softmax(k).
    """
    if not head_dimension_at_first:
        q = rearrange(q, 'b n h d -> b h n d')
        k = rearrange(k, 'b n h d -> b h n d')

    tgt_logits = q
    src_logits = k

    if reverse_kl:
        tgt_logits, src_logits = src_logits, tgt_logits

    target = tgt_logits.softmax(dim = -1)
    inp = src_logits.log_softmax(dim = -1)

    target = rearrange(target, 'b h i d -> b h i 1 d')
    inp = rearrange(inp, 'b h j d -> b h 1 j d')

    kl = F.kl_div(inp, target, reduction = 'none').sum(dim = -1)
    return -kl

def fused_attn(
    q: Tensor,
    k: Tensor,
    v: Tensor,
    mask: Tensor | None = None,
    causal: bool = False,
    reverse_kl: bool = False,
    fused_mode: Literal['similarity', 'flash'] | None = None,
    head_dimension_at_first: bool = True
):
    if exists(fused_mode):
        assert fused_mode in {'similarity', 'flash'}, f"fused_mode must be one of 'similarity' or 'flash', but got {fused_mode}"

    is_cuda = q.is_cuda and k.is_cuda and v.is_cuda and (not exists(mask) or mask.is_cuda)
    
    if not head_dimension_at_first:
        q, k, v = tuple(rearrange(t, 'b n h d -> b h n d') for t in (q, k, v))

    if exists(fused_mode) and is_cuda and CAN_USE_FUSED_ATTN:
        if fused_mode == 'flash':
            # Pre-compute distributions for Flash Attention
            
            p_q = q.softmax(dim = -1)
            l_q = q.log_softmax(dim = -1)
            e_q = -(p_q * l_q).sum(dim = -1, keepdim = True)
            
            p_k = k.softmax(dim = -1)
            l_k = k.log_softmax(dim = -1)
            e_k = -(p_k * l_k).sum(dim = -1, keepdim = True)

            # Note: We pass raw q, k (or distributions) and handle the logic in the redefined triton_fused_flash_attn
            return triton_fused_flash_attn(
                p_q, l_q, e_q,
                p_k, l_k, e_k,
                v, mask = mask, causal = causal, reverse_kl = reverse_kl
            )
        
        if fused_mode == 'similarity':
            sim = triton_fused_compute_kl_div_similarity(q, k, mask = mask, causal = causal, reverse_kl = reverse_kl)
            attn = sim.softmax(dim = -1)
            return einsum('b h i j, b h j d -> b h i d', attn, v)

    # Fallback to manual path
    sim = compute_kl_div_similarity(q, k, reverse_kl = reverse_kl, head_dimension_at_first = True)

    if causal:
        i, j = sim.shape[-2:]
        causal_mask = torch.ones((i, j), device = q.device, dtype = torch.bool).triu(j - i + 1)
        sim = sim.masked_fill(causal_mask, max_neg_value(sim))

    if exists(mask):
        sim = sim.masked_fill(~rearrange(mask, 'b j -> b 1 1 j'), max_neg_value(sim))

    attn = sim.softmax(dim = -1)
    out = einsum('b h i j, b h j d -> b h i d', attn, v)

    if not head_dimension_at_first:
        out = rearrange(out, 'b h n d -> b n h d')

    return out

# class

class KLDivAttention(Module):
    def __init__(
        self,
        dim,
        heads = 8,
        dim_head = 64,
        causal = False,
        reverse_kl = False,
        prenorm = False,
        fused_mode: Literal['similarity', 'flash'] | None = None
    ):
        super().__init__()
        self.heads = heads
        self.causal = causal
        self.reverse_kl = reverse_kl
        self.fused_mode = fused_mode
        inner_dim = heads * dim_head

        self.norm = nn.RMSNorm(dim) if prenorm else nn.Identity()

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Linear(inner_dim, dim, bias = False)

    def forward(
        self,
        tokens,
        mask = None
    ):
        h = self.heads

        tokens = self.norm(tokens)

        qkv = self.to_qkv(tokens).chunk(3, dim = -1)
        q, k, v = tuple(rearrange(t, 'b n (h d) -> b h n d', h = h) for t in qkv)

        out = fused_attn(
            q, k, v,
            mask = mask,
            causal = self.causal,
            reverse_kl = self.reverse_kl,
            fused_mode = self.fused_mode,
            head_dimension_at_first = True
        )

        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)
