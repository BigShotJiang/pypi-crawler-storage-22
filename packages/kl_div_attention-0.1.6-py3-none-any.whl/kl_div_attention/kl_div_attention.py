from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn, einsum, Tensor
from torch.nn import Module
from typing import Literal

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

# helpers

def exists(val):
    return val is not None

def default(val, d):
    return val if exists(val) else d

def max_neg_value(t):
    return -torch.finfo(t.dtype).max

# triton available

try:
    from .fused_qk_kl_div_distance import fused_compute_kl_div_similarity as triton_fused_compute_kl_div_similarity
    from .fused_flash_attn import fused_flash_attn as triton_fused_flash_attn
    CAN_USE_FUSED_ATTN = True
except ImportError:
    CAN_USE_FUSED_ATTN = False

# functions

def compute_kl_div_similarity(
    q: Tensor,
    k: Tensor,
    reverse_kl = False,
    scale = 1.
):
    """
    Computes the negative KL-divergence similarity between softmax(q) and softmax(k).
    Expects head-first layout (B, H, N, D).
    """
    tgt_logits = q
    src_logits = k

    if reverse_kl:
        tgt_logits, src_logits = src_logits, tgt_logits

    target = tgt_logits.softmax(dim = -1)
    inp = src_logits.log_softmax(dim = -1)

    target = rearrange(target, 'b h i d -> b h i 1 d')
    inp = rearrange(inp, 'b h j d -> b h 1 j d')

    kl = F.kl_div(inp, target, reduction = 'none').sum(dim = -1)
    return -kl * scale

class KLDivAttention(Module):
    def __init__(
        self,
        dim,
        heads = 8,
        dim_head = 64,
        causal = False,
        reverse_kl = False,
        prenorm = False,
        fused_mode: Literal['similarity', 'flash'] | None = None
    ):
        super().__init__()
        self.heads = heads
        self.causal = causal
        self.reverse_kl = reverse_kl
        self.fused_mode = fused_mode
        self.scale = dim_head ** -0.5

        inner_dim = heads * dim_head

        self.norm = nn.RMSNorm(dim) if prenorm else nn.Identity()

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.split_heads_triton = Rearrange('b n (h d) -> b n h d', h = heads)
        self.split_heads_naive = Rearrange('b n (h d) -> b h n d', h = heads)

        self.merge_heads = Rearrange('b ... h d -> b ... (h d)')

        self.to_out = nn.Linear(inner_dim, dim, bias = False)

    def forward(
        self,
        tokens,
        mask = None
    ):
        heads = self.heads

        tokens = self.norm(tokens)

        qkv = self.to_qkv(tokens).chunk(3, dim = -1)
        
        is_cuda = tokens.is_cuda
        use_triton = exists(self.fused_mode) and is_cuda and CAN_USE_FUSED_ATTN

        if use_triton:
            q, k, v = tuple(self.split_heads_triton(t) for t in qkv)

            if self.fused_mode == 'flash':
                out = triton_fused_flash_attn(
                    q, k, v,
                    mask = mask, causal = self.causal, reverse_kl = self.reverse_kl, qk_scale = self.scale
                )
            
            elif self.fused_mode == 'similarity':
                sim = triton_fused_compute_kl_div_similarity(q, k, mask = mask, causal = self.causal, reverse_kl = self.reverse_kl, qk_scale = self.scale)
                attn = sim.softmax(dim = -1)
                out = einsum('b h i j, b j h d -> b i h d', attn, v)

            out = self.merge_heads(out)
        else:
            q, k = tuple(self.split_heads_naive(t) for t in (qkv[0], qkv[1]))
            v = self.split_heads_triton(qkv[2])
            
            sim = compute_kl_div_similarity(q, k, reverse_kl = self.reverse_kl, scale = self.scale)

            if self.causal:
                i, j = sim.shape[-2:]
                causal_mask = torch.ones((i, j), device = q.device, dtype = torch.bool).triu(j - i + 1)
                sim = sim.masked_fill(causal_mask, max_neg_value(sim))

            if exists(mask):
                sim = sim.masked_fill(~rearrange(mask, 'b j -> b 1 1 j'), max_neg_value(sim))

            attn = sim.softmax(dim = -1)
            out = einsum('b h i j, b j h d -> b i h d', attn, v)
            out = self.merge_heads(out)

        return self.to_out(out)
