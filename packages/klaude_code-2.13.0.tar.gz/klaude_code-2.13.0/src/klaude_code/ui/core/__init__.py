# Core UI abstractions
