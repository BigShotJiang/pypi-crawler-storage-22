#!/usr/bin/env python3

import getpass
import os
import sys
from typing import Union
from urllib.parse import quote

import requests
from simplejson.errors import JSONDecodeError as SimplejsonJSONDecodeError

from .config import Config
from .runners import Run
from .utils import error, get_parser, output, setup_url

try:
    from requests.exceptions import JSONDecodeError as RequestsJSONDecodeError
except ImportError:
    from requests.exceptions import InvalidJSONError as RequestsJSONDecodeError


class Knotctl:

    def __init__(self):
        self.conf = Config()
        self.config = self.get_config()
        self.config_filename = self.conf.config_filename
        self.runner = Run()

    def get_config(self):
        config = self.conf.get_config()
        if not config:
            print("You need to configure knotctl before proceeding")
            run_config()

        return config

    def run(self, url: str, args: dict, baseurl: str, parser: dict,
            username: str):
        try:
            if args.command == "add":
                self.runner.add(url, args.json)
            elif args.command == "delete":
                self.runner.delete(url, args.json)
            elif args.command == "list":
                self.runner.lister(url, args.json)
            elif args.command == "update":
                self.runner.update(url, args.json)
            elif args.command == "user":
                url = baseurl + f"/user/info/{username}"
                self.runner.lister(url, args.json)
            elif args.command == "auditlog":
                url = baseurl + "/user/auditlog"
                self.runner.log(url, args.json)
            elif args.command == "changelog":
                url = baseurl + f"/zones/changelog/{args.zone.rstrip('.')}"
                self.runner.log(url, args.json)
            elif args.command == "zone":
                url = baseurl + "/zones"
                self.runner.zone(url, args.json)
            elif args.command == "openstack-sync":
                self.runner.openstack_sync(args.cloud, args.name, args.zone,
                                           baseurl, args.json)
            else:
                parser.print_help(sys.stderr)
                return 2
        except requests.exceptions.RequestException as e:
            output(error(e, "Could not connect to server"))
        except (RequestsJSONDecodeError, SimplejsonJSONDecodeError):
            output(
                error("Could not decode api response as JSON",
                      "Could not decode"))
        return 0


def run_complete(shell: Union[None, str]):
    if not shell or shell in ["bash", "zsh"]:
        os.system("register-python-argcomplete knotctl")
    elif shell == "fish":
        os.system("register-python-argcomplete --shell fish knotctl")
    elif shell == "tcsh":
        os.system("register-python-argcomplete --shell tcsh knotctl")


def run_config(
    context: Union[None, str] = None,
    baseurl: Union[None, str] = None,
    list_config: bool = False,
    username: Union[None, str] = None,
    password: Union[None, str] = None,
    current: Union[None, str] = None,
):
    conf = Config()
    if current:
        print(conf.get_current())
        return
    config = {"baseurl": baseurl, "username": username, "password": password}
    needed = []
    if context:
        found = conf.set_context(context)
        if found:
            return
    if list_config:
        config_data = conf.get_config_data()
        output(config_data)
        return
    if not baseurl:
        needed.append("baseurl")
    if not username:
        needed.append("username")
    for need in needed:
        if need == "":
            output(
                error(
                    "Can not configure without {}".format(need),
                    "No {}".format(need),
                ))
            sys.exit(1)
        config[need] = input("Enter {}: ".format(need))

    if not password:
        try:
            config["password"] = getpass.getpass()
        except EOFError:
            output(error("Can not configure without password", "No password"))
            sys.exit(1)

    conf.set_config(config)


# Entry point to program
def main() -> int:
    parser = get_parser()
    args = parser.parse_args()
    if args.command == "completion":
        run_complete(args.shell)
        return 0

    knotctl = Knotctl()

    if args.command == "config":
        run_config(
            args.context,
            args.baseurl,
            args.list_config,
            args.username,
            args.password,
            args.current,
        )
        return 0

    config = knotctl.get_config()
    baseurl = config["baseurl"]
    token = knotctl.conf.get_token()
    if token == "":
        print("Could not get token, exiting")
        return 1

    # Route based on command
    url = ""
    ttl = None
    quotedata = None
    user = config["username"]
    if "ttl" in args:
        ttl = args.ttl
    if "data" in args and args.data is not None:
        quotedata = quote(args.data, safe="")
    if args.command != "update":
        args.argument = None
    if args.command == "add" and not ttl:
        if args.zone.endswith("."):
            zname = args.zone
        else:
            zname = args.zone + "."
        try:
            soa_url = setup_url(baseurl, None, None, zname, "SOA", None, args.zone)
            soa_json = knotctl.runner.lister(soa_url, True, ret=True)
            ttl = soa_json[0]["ttl"]
        except requests.exceptions.RequestException as e:
            output(error(e, "No permissions, or zone doesn't exist"))
            return 0

    if args.command == "user":
        if args.username:
            user = args.username
    if args.command in [
            "auditlog", "changelog", "openstack-sync", "user", "zone"
    ]:
        pass
    else:
        try:
            url = setup_url(
                baseurl,
                args.argument,
                quotedata,
                args.name,
                args.rtype,
                ttl,
                args.zone,
            )
        except AttributeError:
            parser.print_help(sys.stderr)
            return 1

    return knotctl.run(url, args, baseurl, parser, user)


if __name__ == "__main__":
    sys.exit(main())
