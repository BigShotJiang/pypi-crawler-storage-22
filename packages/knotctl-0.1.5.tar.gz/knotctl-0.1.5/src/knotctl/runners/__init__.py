from typing import Union

import requests

from ..config import Config
from ..openstack import get_openstack_addresses
from ..utils import output, setup_url, split_url


class Run():

    def __init__(self):
        conf = Config()
        self.headers = {"Authorization": f"Bearer {conf.get_token()}"}

    def add(self, url: str, jsonout: bool):
        parsed = split_url(url)
        response = requests.put(url, headers=self.headers)
        out = response.json()
        if isinstance(out, list):
            for record in out:
                if (record["data"] == parsed["data"]
                        and record["name"] == parsed["name"]
                        and record["rtype"] == parsed["rtype"]):
                    output(record, jsonout)
                    break
        else:
            output(out, jsonout)

    def delete(self, url: str, jsonout: bool):
        response = requests.delete(url, headers=self.headers)
        reply = response.json()
        if not reply and response.status_code == requests.codes.ok:
            reply = [{"Code": 200, "Description": "{} deleted".format(url)}]

        output(reply, jsonout)

    def log(self, url: str, jsonout: bool):
        response = requests.get(url, headers=self.headers)
        string = response.content.decode("utf-8")
        if jsonout:
            out = []
            lines = string.splitlines()
            index = 0
            text = ""
            timestamp = ""
            while index < len(lines):
                line = lines[index]
                index += 1
                cur_has_timestamp = line.startswith("[")
                next_has_timestamp = index < len(
                    lines) and lines[index].startswith("[")
                # Simple case, just one line with timestamp
                if cur_has_timestamp and next_has_timestamp:
                    timestamp = line.split("]")[0].split("[")[1]
                    text = line.split("]")[1].lstrip(":").strip()
                    out.append({"timestamp": timestamp, "text": text})
                    text = ""
                    timestamp = ""
                # Start of multiline
                elif cur_has_timestamp:
                    timestamp = line.split("]")[0].split("[")[1]
                    text = line.split("]")[1].lstrip(":").strip()
                # End of multiline
                elif next_has_timestamp:
                    text += f"\n{line.strip()}"
                    out.append({"timestamp": timestamp, "text": text})
                    text = ""
                    timestamp = ""
                # Middle of multiline
                else:
                    text += f"\n{line.strip()}"

        else:
            out = string

        output(out, jsonout)

    def update(self, url: str, jsonout: bool):
        response = requests.patch(url, headers=self.headers)
        output(response.json(), jsonout)

    def zone(self, url: str, jsonout: bool, ret=False) -> Union[None, str]:
        response = requests.get(url, headers=self.headers)
        zones = response.json()
        for zone in zones:
            del zone["records"]
        string = zones

        if ret:
            return string
        else:
            output(string, jsonout)

    def lister(self, url: str, jsonout: bool, ret=False) -> Union[None, str]:
        response = requests.get(url, headers=self.headers)
        string = response.json()
        if ret:
            return string
        else:
            output(string, jsonout)

    def add_records(self, openstack_addresses, baseurl, name, zone, url,
                    jsonout):
        for address in openstack_addresses:
            rtype = None
            if address["version"] == 4:
                rtype = "A"
            elif address["version"] == 6:
                rtype = "AAAA"
            if rtype:
                url = setup_url(
                    baseurl,
                    None,  # arguments,
                    address["addr"],  # data,
                    name,
                    rtype,
                    None,  # ttl,
                    zone,
                )
                self.add(url, jsonout)

    def update_records(self, openstack_addresses, current_records, baseurl,
                       name, zone, url, jsonout):
        previpv4 = False
        previpv6 = False
        curripv4 = False
        curripv6 = False
        for record in current_records:
            if record.type == "A":
                previpv4 = record.data
            elif record.type == "AAAA":
                previpv6 = record.data
            for address in openstack_addresses:
                rtype = None
                if address.version == 4:
                    rtype = "A"
                    curripv4 = True
                elif address.version == 6:
                    rtype = "AAAA"
                    curripv6 = True
                if rtype and record.type == rtype:
                    if record.data == address.addr:
                        continue
                    else:
                        url = setup_url(
                            baseurl,
                            None,  # arguments,
                            address.addr,  # data,
                            name,
                            record.type,
                            None,  # ttl,
                            zone,
                        )
                        self.update(url, jsonout)
        if previpv4 and not curripv4:
            url = setup_url(
                baseurl,
                None,  # arguments,
                previpv4,  # data,
                name,
                "A",
                None,  # ttl,
                zone,
            )
            self.delete(url, jsonout)
        if previpv6 and not curripv6:
            url = setup_url(
                baseurl,
                None,  # arguments,
                previpv6,  # data,
                name,
                "AAAA",
                None,  # ttl,
                zone,
            )
            self.delete(url, jsonout)
        if curripv4 and not previpv4:
            url = setup_url(
                baseurl,
                None,  # arguments,
                curripv4,  # data,
                name,
                "A",
                None,  # ttl,
                zone,
            )
            self.add(url, jsonout)
        if curripv6 and not previpv6:
            url = setup_url(
                baseurl,
                None,  # arguments,
                curripv6,  # data,
                name,
                "AAAA",
                None,  # ttl,
                zone,
            )
            self.add(url, jsonout)

    def openstack_sync(self, cloud: str, name: str, zone: str, baseurl: str,
                       jsonout: bool):
        url = setup_url(
            baseurl,
            None,  # arguments,
            None,  # data,
            name,
            None,  # rtype,
            None,  # ttl,
            zone,
        )
        current_records = self.lister(url, jsonout=True, ret=True)
        openstack_addresses = get_openstack_addresses(cloud, name)
        if current_records["Code"] == 404:
            self.add_records(openstack_addresses, baseurl, name, zone, url,
                             jsonout)
        else:
            self.update_records(openstack_addresses, current_records, baseurl,
                                name, zone, url, jsonout)
