"""know - Living documentation generator for codebases."""

__version__ = "0.1.0"
__author__ = "Vic"

from know.cli import main

__all__ = ["main", "__version__"]
