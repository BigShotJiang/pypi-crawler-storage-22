# know-cli Search Improvements

## Issues Found (Feb 8, 2026)

### 1. Duplicate Results
**Problem:** Same file appears multiple times in search results  
**Root cause:** TBD - need to investigate semantic_search.py  
**Fix:** Deduplicate by file path before returning results

### 2. Cross-Project Contamination
**Problem:** Searching in know-cli returns allconvert files  
**Root cause:** Project scoping exists but may not be working correctly  
**Fix:** Verify project_root isolation in EmbeddingCache

### 3. Missing --chunk Flag in CLI
**Problem:** Backend supports function-level search but CLI doesn't expose it  
**Root cause:** cli.py search command missing the --chunk option  
**Fix:** Add `--chunk` flag to `@cli.command() search`

### 4. Poor Preview Quality
**Problem:** Previews show first 200 chars of file, not the matching chunk  
**Root cause:** search_code() truncates file start instead of matching section  
**Fix:** For chunk search, show the actual function/class body

### 5. No Hybrid Search
**Problem:** Only uses vector embeddings, no keyword matching  
**Missing:** BM25 + vector combination like QMD does  
**Fix:** Implement hybrid_search() combining both approaches

---

## Phase 1: Quick Wins (Today)

- [x] Document issues
- [ ] Fix #1: Deduplicate results
- [ ] Fix #2: Verify project scoping
- [ ] Fix #3: Expose --chunk in CLI
- [ ] Fix #4: Better previews for chunk search
- [ ] Test all fixes on real codebases

## Phase 2: Power Features (Next)

- [ ] Hybrid search (BM25 + vector)
- [ ] Reranking with cross-encoder
- [ ] Query expansion (synonyms, related terms)
- [ ] Code-aware filters (complexity, recency, test vs prod)
- [ ] Caching improvements (faster repeat searches)

## Phase 3: Advanced (Later)

- [ ] Multi-modal search (code + docs + comments)
- [ ] Interactive refinement
- [ ] Code graph traversal ("find all callers of X")
- [ ] Diff-aware search ("what changed related to auth?")
- [ ] Natural language understanding ("how to validate JWT tokens")

---

## Testing Strategy

1. **Use on know-cli itself** - dogfood our own tool
2. **Test on video-pipeline** - real production codebase
3. **Test on remotion code** - TypeScript/React
4. **Benchmark** - compare speed before/after

## Success Metrics

- Search returns 0 duplicates
- Cross-project results = 0
- Function-level search available via CLI
- Previews show relevant code (not file start)
- Search time < 500ms for 100+ files
