"""know - Context Intelligence for codebases."""

from __future__ import annotations

__author__ = "Vic"


def _get_version() -> str:
    """Best-effort runtime version.

    Avoids hardcoding so `know --version` always matches the installed dist.
    """
    try:
        from importlib import metadata as _md  # py3.8+

        return _md.version("know-cli")
    except Exception:
        # Fallback for editable/dev installs or very old envs
        return "0.0.0"


__version__ = _get_version()

from know.cli import main  # noqa: E402

__all__ = ["main", "__version__"]
