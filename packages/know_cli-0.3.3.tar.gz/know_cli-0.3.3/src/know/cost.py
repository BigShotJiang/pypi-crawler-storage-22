"""Cost analytics for know-cli with robust fallback behavior."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from know.config import Config


class CostTracker:
    """Analyze context token usage and estimate cost from telemetry."""

    # Conservative fallback rates per 1K tokens (USD)
    EST_INPUT_USD_PER_1K = 0.003

    def __init__(self, config: Config):
        self.root = config.root
        self.stats_db_path = self.root / ".know" / "stats.db"
        self.cost_file = self.root / ".know" / "cost.json"

    def _load_budget(self) -> Optional[int]:
        if not self.cost_file.exists():
            return None
        try:
            data = json.loads(self.cost_file.read_text())
            budget = data.get("monthly_token_budget")
            return int(budget) if budget is not None else None
        except Exception:
            return None

    def set_budget(self, monthly_token_budget: int) -> Dict[str, Any]:
        self.cost_file.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "monthly_token_budget": int(monthly_token_budget),
            "updated_at": int(time.time()),
        }
        self.cost_file.write_text(json.dumps(payload, indent=2))
        return payload

    def _connect_stats(self) -> Optional[sqlite3.Connection]:
        if not self.stats_db_path.exists():
            return None
        conn = sqlite3.connect(str(self.stats_db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _base_metrics(self) -> Dict[str, Any]:
        conn = self._connect_stats()
        if conn is None:
            return {
                "queries": 0,
                "tokens_used": 0,
                "token_budget_requested": 0,
                "estimated_full_read_tokens": None,
                "estimated_saved_tokens": None,
                "estimated_cost_usd": None,
                "savings_ratio": None,
                "cost_model": "fallback_estimate",
                "unknown_fields": [
                    "estimated_full_read_tokens",
                    "estimated_saved_tokens",
                    "estimated_cost_usd",
                    "savings_ratio",
                ],
            }

        row = conn.execute(
            """
            SELECT
                COUNT(*) AS queries,
                COALESCE(SUM(tokens_used), 0) AS tokens_used,
                COALESCE(SUM(budget), 0) AS token_budget_requested
            FROM events
            WHERE event_type = 'context'
            """
        ).fetchone()

        queries = int(row["queries"])
        tokens_used = int(row["tokens_used"])
        budget_requested = int(row["token_budget_requested"])

        if queries == 0:
            return {
                "queries": 0,
                "tokens_used": 0,
                "token_budget_requested": 0,
                "estimated_full_read_tokens": None,
                "estimated_saved_tokens": None,
                "estimated_cost_usd": None,
                "savings_ratio": None,
                "cost_model": "fallback_estimate",
                "unknown_fields": [
                    "estimated_full_read_tokens",
                    "estimated_saved_tokens",
                    "estimated_cost_usd",
                    "savings_ratio",
                ],
            }

        # Fallback baseline: full read ~= requested budget when exact full-file telemetry absent.
        estimated_full_read_tokens = max(tokens_used, budget_requested)
        estimated_saved_tokens = max(0, estimated_full_read_tokens - tokens_used)
        savings_ratio = (
            round((estimated_saved_tokens / estimated_full_read_tokens) * 100, 2)
            if estimated_full_read_tokens > 0
            else 0.0
        )
        estimated_cost_usd = round((tokens_used / 1000) * self.EST_INPUT_USD_PER_1K, 6)

        return {
            "queries": queries,
            "tokens_used": tokens_used,
            "token_budget_requested": budget_requested,
            "estimated_full_read_tokens": estimated_full_read_tokens,
            "estimated_saved_tokens": estimated_saved_tokens,
            "estimated_cost_usd": estimated_cost_usd,
            "savings_ratio": savings_ratio,
            "cost_model": "fallback_estimate",
            "unknown_fields": [],
        }

    def summary(self) -> Dict[str, Any]:
        data = self._base_metrics()
        budget = self._load_budget()
        data["monthly_token_budget"] = budget
        if budget is not None:
            used = data["tokens_used"]
            data["budget_used_percent"] = round((used / budget) * 100, 2) if budget > 0 else 0.0
            data["budget_remaining_tokens"] = max(0, budget - used)
        else:
            data["budget_used_percent"] = None
            data["budget_remaining_tokens"] = None
            data["unknown_fields"] = sorted(set(data["unknown_fields"] + [
                "budget_used_percent",
                "budget_remaining_tokens",
            ]))
        return data

    def by_query(self, limit: int = 20) -> Dict[str, Any]:
        conn = self._connect_stats()
        if conn is None:
            return {"queries": [], "cost_model": "fallback_estimate", "unknown_fields": ["estimated_cost_usd"]}

        rows = conn.execute(
            """
            SELECT query,
                   COUNT(*) AS runs,
                   COALESCE(SUM(tokens_used), 0) AS tokens_used,
                   COALESCE(SUM(budget), 0) AS budget_requested,
                   COALESCE(AVG(duration_ms), 0) AS avg_duration_ms
            FROM events
            WHERE event_type = 'context'
            GROUP BY query
            ORDER BY tokens_used DESC
            LIMIT ?
            """,
            (max(1, limit),),
        ).fetchall()

        items: List[Dict[str, Any]] = []
        for r in rows:
            tokens = int(r["tokens_used"])
            items.append({
                "query": r["query"],
                "runs": int(r["runs"]),
                "tokens_used": tokens,
                "budget_requested": int(r["budget_requested"]),
                "avg_duration_ms": int(r["avg_duration_ms"]),
                "estimated_cost_usd": round((tokens / 1000) * self.EST_INPUT_USD_PER_1K, 6),
            })

        return {"queries": items, "cost_model": "fallback_estimate", "unknown_fields": []}

    def savings(self) -> Dict[str, Any]:
        metrics = self._base_metrics()
        return {
            "queries": metrics["queries"],
            "tokens_used": metrics["tokens_used"],
            "estimated_full_read_tokens": metrics["estimated_full_read_tokens"],
            "estimated_saved_tokens": metrics["estimated_saved_tokens"],
            "savings_ratio": metrics["savings_ratio"],
            "cost_model": metrics["cost_model"],
            "unknown_fields": metrics["unknown_fields"],
        }

    def budget(self) -> Dict[str, Any]:
        summary = self.summary()
        return {
            "monthly_token_budget": summary["monthly_token_budget"],
            "tokens_used": summary["tokens_used"],
            "budget_remaining_tokens": summary["budget_remaining_tokens"],
            "budget_used_percent": summary["budget_used_percent"],
            "cost_model": summary["cost_model"],
            "unknown_fields": summary["unknown_fields"],
        }
