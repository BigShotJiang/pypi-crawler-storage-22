"""Execution history tracking for know-cli."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from know.config import Config


@dataclass
class HistoryEntry:
    """A logged command execution entry."""

    id: int
    command: str
    result: str
    reason: str
    created_at: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "command": self.command,
            "result": self.result,
            "reason": self.reason,
            "timestamp": self.created_at,
        }


class HistoryTracker:
    """Project-local history store backed by SQLite."""

    def __init__(self, config: Config):
        self.root = config.root
        self.db_path = self.root / ".know" / "history.db"
        self._conn: Optional[sqlite3.Connection] = None
        self._ensure_db()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def _ensure_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                command TEXT NOT NULL,
                result TEXT NOT NULL,
                reason TEXT DEFAULT '',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_history_result ON history(result);
            CREATE INDEX IF NOT EXISTS idx_history_created_at ON history(created_at);
            """
        )
        conn.commit()

    def log(self, command: str, result: str, reason: str = "") -> int:
        conn = self._get_conn()
        cur = conn.execute(
            "INSERT INTO history (command, result, reason) VALUES (?, ?, ?)",
            (command.strip(), result.strip().lower(), reason.strip()),
        )
        conn.commit()
        return int(cur.lastrowid)

    def list(self, limit: int = 50) -> List[HistoryEntry]:
        conn = self._get_conn()
        rows = conn.execute(
            """
            SELECT id, command, result, reason, created_at
            FROM history
            ORDER BY id DESC
            LIMIT ?
            """,
            (max(1, limit),),
        ).fetchall()
        return [HistoryEntry(**dict(r)) for r in rows]

    def search(
        self,
        keyword: str,
        result: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 50,
    ) -> List[HistoryEntry]:
        conn = self._get_conn()

        filters = ["(command LIKE ? OR reason LIKE ?)"]
        params: List[Any] = [f"%{keyword}%", f"%{keyword}%"]

        if result:
            filters.append("result = ?")
            params.append(result.lower())

        if since:
            # Accept ISO date/datetime; fall back to raw string when parse fails.
            try:
                parsed = datetime.fromisoformat(since)
                since = parsed.isoformat(sep=" ", timespec="seconds")
            except ValueError:
                pass
            filters.append("created_at >= ?")
            params.append(since)

        params.append(max(1, limit))

        sql = (
            "SELECT id, command, result, reason, created_at FROM history "
            f"WHERE {' AND '.join(filters)} ORDER BY id DESC LIMIT ?"
        )

        rows = conn.execute(sql, params).fetchall()
        return [HistoryEntry(**dict(r)) for r in rows]

    def success_rate(self, keyword: Optional[str] = None) -> Dict[str, Any]:
        conn = self._get_conn()

        where = ""
        params: List[Any] = []
        if keyword:
            where = "WHERE command LIKE ?"
            params.append(f"%{keyword}%")

        total = conn.execute(
            f"SELECT COUNT(*) AS cnt FROM history {where}",
            params,
        ).fetchone()["cnt"]

        if total == 0:
            return {
                "keyword": keyword,
                "total": 0,
                "successes": 0,
                "failures": 0,
                "success_rate": 0.0,
            }

        success = conn.execute(
            f"SELECT COUNT(*) AS cnt FROM history {where} AND result = 'success'"
            if where
            else "SELECT COUNT(*) AS cnt FROM history WHERE result = 'success'",
            params,
        ).fetchone()["cnt"]

        failures = total - success
        rate = round((success / total) * 100, 2)
        return {
            "keyword": keyword,
            "total": int(total),
            "successes": int(success),
            "failures": int(failures),
            "success_rate": rate,
        }
