"""Import graph: tracks dependencies between project modules.

Stores import relationships as an adjacency list in index.db.
Supports queries for 'what does X import?' and 'what imports X?'.
Now supports Python + TypeScript/JavaScript import edges.
"""

import ast
import re
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, TYPE_CHECKING

from know.logger import get_logger

if TYPE_CHECKING:
    from know.config import Config

logger = get_logger()

_TS_EXTS = {".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"}
_PY_EXTS = {".py"}


class ImportGraph:
    """Builds and queries the import dependency graph for a project.

    Edges are stored in SQLite alongside the existing index.db.
    """

    def __init__(self, config: "Config"):
        self.config = config
        self.root = config.root
        self.db_path = config.root / ".know" / "cache" / "index.db"
        self._conn: Optional[sqlite3.Connection] = None
        self._ensure_table()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        return self._conn

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------
    def _ensure_table(self):
        conn = self._get_conn()
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS import_edges (
                source TEXT NOT NULL,
                target TEXT NOT NULL,
                import_type TEXT NOT NULL DEFAULT 'import',
                PRIMARY KEY (source, target)
            );
            CREATE INDEX IF NOT EXISTS idx_import_source ON import_edges(source);
            CREATE INDEX IF NOT EXISTS idx_import_target ON import_edges(target);
        """
        )
        conn.commit()

    # ------------------------------------------------------------------
    # Build graph from codebase
    # ------------------------------------------------------------------
    def build(self, modules: Optional[list] = None) -> int:
        """Build the full import graph from project modules.

        Args:
            modules: Optional list of ModuleInfo dicts/objects (from scanner).

        Returns:
            Number of edges inserted.
        """

        module_to_path: Dict[str, Path] = {}
        known_modules: Dict[str, str] = {}
        stem_index: Dict[str, Set[str]] = {}

        if modules:
            for m in modules:
                path_str = m["path"] if isinstance(m, dict) else str(m.path)
                name = m["name"] if isinstance(m, dict) else m.name
                path = self.root / path_str
                module_to_path[name] = path
                known_modules[name] = name

                stem = Path(path_str).stem
                stem_index.setdefault(stem, set()).add(name)
        else:
            for path in self.root.rglob("*"):
                if not path.is_file():
                    continue
                if path.suffix not in (_PY_EXTS | _TS_EXTS):
                    continue
                if any(p.startswith(".") or p in {"venv", "node_modules", "__pycache__", ".git"} for p in path.parts):
                    continue
                rel = path.relative_to(self.root)
                name = str(rel.with_suffix("")).replace("/", ".")
                module_to_path[name] = path
                known_modules[name] = name
                stem_index.setdefault(path.stem, set()).add(name)

        edges: List[Tuple[str, str, str]] = []

        for source_module, abs_path in module_to_path.items():
            if not abs_path.exists():
                continue

            try:
                text = abs_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if abs_path.suffix in _PY_EXTS:
                refs = self._extract_python_imports(text)
            elif abs_path.suffix in _TS_EXTS:
                refs = self._extract_ts_imports(text)
            else:
                refs = []

            for raw_target, import_type in refs:
                resolved = self._resolve_target(
                    raw_target=raw_target,
                    source_module=source_module,
                    source_path=abs_path,
                    known_modules=known_modules,
                    stem_index=stem_index,
                )
                if not resolved or resolved == source_module:
                    continue
                edges.append((source_module, resolved, import_type))

        conn = self._get_conn()
        conn.execute("DELETE FROM import_edges")
        if edges:
            conn.executemany(
                "INSERT OR REPLACE INTO import_edges (source, target, import_type) VALUES (?, ?, ?)",
                edges,
            )
        conn.commit()
        return len(edges)

    def _extract_python_imports(self, source: str) -> List[Tuple[str, str]]:
        refs: List[Tuple[str, str]] = []
        try:
            tree = ast.parse(source)
        except Exception:
            return refs

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    refs.append((alias.name, "import"))
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    if getattr(node, "level", 0) and node.level > 0:
                        dotted = "." * node.level + node.module
                        refs.append((dotted, "from"))
                    else:
                        refs.append((node.module, "from"))
        return refs

    def _extract_ts_imports(self, source: str) -> List[Tuple[str, str]]:
        refs: List[Tuple[str, str]] = []

        patterns = [
            r"import\s+(?:[^'\"]+?\s+from\s+)?['\"]([^'\"]+)['\"]",  # import ... from 'x' / import 'x'
            r"export\s+[^'\"]*?from\s+['\"]([^'\"]+)['\"]",          # export ... from 'x'
            r"require\(\s*['\"]([^'\"]+)['\"]\s*\)",                 # require('x')
            r"import\(\s*['\"]([^'\"]+)['\"]\s*\)",                  # import('x')
        ]

        seen: Set[str] = set()
        for pattern in patterns:
            for m in re.finditer(pattern, source):
                mod = m.group(1)
                if mod and mod not in seen:
                    seen.add(mod)
                    refs.append((mod, "import"))
        return refs

    def _resolve_target(
        self,
        raw_target: str,
        source_module: str,
        source_path: Path,
        known_modules: Dict[str, str],
        stem_index: Dict[str, Set[str]],
    ) -> Optional[str]:
        # Relative imports: ./foo, ../bar, .utils, ..pkg.mod
        if raw_target.startswith(("./", "../", ".")):
            rel_candidate = self._resolve_relative(raw_target, source_path)
            if rel_candidate:
                rel_mod = str(rel_candidate.relative_to(self.root).with_suffix("")).replace("/", ".")
                if rel_mod in known_modules:
                    return rel_mod
            return None

        # Exact module path known
        if raw_target in known_modules:
            return known_modules[raw_target]

        # Try dotted last token / package token
        token = raw_target.split("/")[-1].split(".")[-1]
        if token in stem_index and stem_index[token]:
            # Prefer shortest match (usually most local path)
            return sorted(stem_index[token], key=len)[0]

        return None

    def _resolve_relative(self, raw_target: str, source_path: Path) -> Optional[Path]:
        base = source_path.parent

        # Python dotted relative: .utils / ..pkg.mod
        if raw_target.startswith(".") and not raw_target.startswith("./") and "/" not in raw_target:
            level = len(raw_target) - len(raw_target.lstrip("."))
            tail = raw_target[level:]
            base_dir = source_path.parent
            for _ in range(max(level - 1, 0)):
                base_dir = base_dir.parent
            candidate = base_dir / tail.replace(".", "/")
        else:
            candidate = (base / raw_target).resolve()

        candidates = [
            candidate,
            candidate.with_suffix(".py"),
            candidate.with_suffix(".ts"),
            candidate.with_suffix(".tsx"),
            candidate.with_suffix(".js"),
            candidate.with_suffix(".jsx"),
            candidate / "__init__.py",
            candidate / "index.ts",
            candidate / "index.tsx",
            candidate / "index.js",
            candidate / "index.jsx",
        ]

        for c in candidates:
            try:
                if c.exists() and c.is_file() and self.root in c.parents:
                    return c
            except Exception:
                continue
        return None

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------
    def imports_of(self, module_name: str) -> List[str]:
        """What does *module_name* import? (outgoing edges)"""
        conn = self._get_conn()
        short = module_name.split(".")[-1]
        rows = conn.execute(
            "SELECT target FROM import_edges WHERE source = ? OR source LIKE ?",
            (module_name, f"%.{short}"),
        ).fetchall()
        return list({r[0] for r in rows})

    def imported_by(self, module_name: str) -> List[str]:
        """What modules import *module_name*? (incoming edges)"""
        conn = self._get_conn()
        short = module_name.split(".")[-1]
        rows = conn.execute(
            "SELECT source FROM import_edges WHERE target = ? OR target LIKE ?",
            (module_name, f"%.{short}"),
        ).fetchall()
        return list({r[0] for r in rows})

    def get_all_edges(self) -> List[Tuple[str, str]]:
        """Return all (source, target) edges."""
        conn = self._get_conn()
        rows = conn.execute("SELECT source, target FROM import_edges").fetchall()
        return [(r[0], r[1]) for r in rows]

    def file_for_module(self, module_name: str) -> Optional[Path]:
        """Resolve a module name to a file path under project root."""
        rel = module_name.replace(".", "/")
        candidates = [
            self.root / f"{rel}.py",
            self.root / f"{rel}.ts",
            self.root / f"{rel}.tsx",
            self.root / f"{rel}.js",
            self.root / f"{rel}.jsx",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate

        short = module_name.split(".")[-1]
        for ext in ["py", "ts", "tsx", "js", "jsx"]:
            for p in self.root.rglob(f"{short}.{ext}"):
                parts = p.relative_to(self.root).parts
                if any(part.startswith(".") or part in {"venv", "__pycache__", "node_modules", ".git"} for part in parts):
                    continue
                return p
        return None

    # ------------------------------------------------------------------
    # Pretty print
    # ------------------------------------------------------------------
    def format_graph(self, module_name: str) -> str:
        """Human-readable graph display for a single module."""
        imports = self.imports_of(module_name)
        imported = self.imported_by(module_name)

        lines = [f"# Import graph for: {module_name}", ""]

        if imports:
            lines.append("## Imports (dependencies)")
            for m in sorted(imports):
                lines.append(f"  → {m}")
        else:
            lines.append("## Imports: (none)")

        lines.append("")

        if imported:
            lines.append("## Imported by (dependents)")
            for m in sorted(imported):
                lines.append(f"  ← {m}")
        else:
            lines.append("## Imported by: (none)")

        return "\n".join(lines)
