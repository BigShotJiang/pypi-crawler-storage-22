"""SQLite FTS5 index for chunk-level lexical search.

This provides a lightweight BM25-based retrieval engine (like qmd's lexical leg)
without any external runtime dependencies.

The index lives in the project-local database:
  .know/cache/index.db

If the user's SQLite does not support FTS5, all operations become no-ops and
callers should fall back to vector-only search.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

from know.logger import get_logger

logger = get_logger()


@dataclass(frozen=True)
class LexicalHit:
    """A single lexical (FTS) hit."""

    rowid: int
    file_path: str
    name: str
    chunk_type: str
    start_line: int
    end_line: int
    text: str
    bm25: float


class ChunkFTSIndex:
    """Project-local FTS5 index over extracted chunks.

    Designed to be updated incrementally via :class:`know.index.CodebaseIndex`,
    but also provides a lightweight directory indexer for ad-hoc refresh.
    """

    TABLE = "chunks_fts"

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def available(self) -> bool:
        """True if FTS5 is available and the index can be created."""
        try:
            with self._connect() as conn:
                self._ensure_schema(conn)
            return True
        except sqlite3.OperationalError as e:
            # Common when SQLite is built without FTS5: "no such module: fts5"
            logger.debug(f"FTS5 unavailable: {e}")
            return False

    def _ensure_schema(self, conn: sqlite3.Connection) -> None:
        # Try to create FTS table. If FTS5 isn't compiled in, this raises.
        conn.execute(
            f"""
            CREATE VIRTUAL TABLE IF NOT EXISTS {self.TABLE}
            USING fts5(
                text,
                name,
                file_path UNINDEXED,
                chunk_type UNINDEXED,
                start_line UNINDEXED,
                end_line UNINDEXED,
                tokenize='porter'
            );
            """
        )

    # ------------------------------------------------------------------
    # Indexing
    # ------------------------------------------------------------------
    def delete_file(self, file_path: str) -> None:
        try:
            with self._connect() as conn:
                self._ensure_schema(conn)
                conn.execute(f"DELETE FROM {self.TABLE} WHERE file_path = ?", (file_path,))
                conn.commit()
        except sqlite3.OperationalError:
            return

    def upsert_chunks(self, chunks: Iterable[dict]) -> int:
        """Insert all chunks (after caller deletes existing rows for that file).

        Each chunk dict must contain: file_path, name, chunk_type, start_line, end_line, text
        """
        rows = [
            (
                c["text"],
                c.get("name", ""),
                c["file_path"],
                c.get("chunk_type", ""),
                int(c.get("start_line", 1)),
                int(c.get("end_line", 1)),
            )
            for c in chunks
        ]
        if not rows:
            return 0

        try:
            with self._connect() as conn:
                self._ensure_schema(conn)
                conn.executemany(
                    f"""INSERT INTO {self.TABLE}
                        (text, name, file_path, chunk_type, start_line, end_line)
                        VALUES (?, ?, ?, ?, ?, ?)""",
                    rows,
                )
                conn.commit()
            return len(rows)
        except sqlite3.OperationalError:
            return 0

    def index_directory(
        self,
        root: Path,
        extensions: Optional[List[str]] = None,
    ) -> int:
        """(Re)index a directory tree.

        This is a simple best-effort indexer used when the incremental scanner
        has not run yet. It extracts chunks with :func:`know.context_engine.extract_chunks_from_file`.
        """
        if extensions is None:
            extensions = [
                ".py",
                ".ts",
                ".tsx",
                ".js",
                ".jsx",
                ".go",
                ".rs",
                ".java",
                ".cpp",
                ".c",
                ".h",
                ".md",
            ]

        try:
            with self._connect() as conn:
                self._ensure_schema(conn)
        except sqlite3.OperationalError:
            return 0

        from know.context_engine import extract_chunks_from_file

        count = 0
        for ext in extensions:
            for fp in root.rglob(f"*{ext}"):
                if any(
                    part.startswith(".")
                    or part in {"node_modules", "__pycache__", "venv", ".git", "dist", "build", ".know"}
                    for part in fp.parts
                ):
                    continue

                try:
                    rel = str(fp.relative_to(root))
                except ValueError:
                    continue

                try:
                    chunks = extract_chunks_from_file(fp, root)
                except Exception:
                    continue

                self.delete_file(rel)
                payload = []
                for c in chunks:
                    payload.append(
                        {
                            "file_path": rel,
                            "name": c.name,
                            "chunk_type": c.chunk_type,
                            "start_line": c.line_start,
                            "end_line": c.line_end,
                            "text": c.body,
                        }
                    )
                count += self.upsert_chunks(payload)

        return count

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------
    def search(
        self,
        query: str,
        top_k: int = 20,
        path_prefix: Optional[str] = None,
        type_suffix: Optional[str] = None,
    ) -> List[LexicalHit]:
        if not query.strip():
            return []

        import re

        def _sanitize(q: str) -> str:
            cleaned = re.sub(r"[^A-Za-z0-9_]+", " ", q).strip()
            if not cleaned:
                return q
            # AND all terms for higher precision.
            return " ".join(cleaned.split())

        query_sanitized = _sanitize(query)

        try:
            with self._connect() as conn:
                self._ensure_schema(conn)

                def _run(q: str) -> List[sqlite3.Row]:
                    where = [f"{self.TABLE} MATCH ?"]
                    params: list[object] = [q]

                    if path_prefix:
                        where.append("file_path LIKE ?")
                        params.append(f"{path_prefix}%")

                    if type_suffix:
                        # Simple suffix match on file extension.
                        suffix = type_suffix if type_suffix.startswith(".") else f".{type_suffix}"
                        where.append("file_path LIKE ?")
                        params.append(f"%{suffix}")

                    where_sql = " AND ".join(where)

                    return conn.execute(
                        f"""
                        SELECT
                            rowid,
                            file_path,
                            name,
                            chunk_type,
                            start_line,
                            end_line,
                            text,
                            bm25({self.TABLE}) as bm25
                        FROM {self.TABLE}
                        WHERE {where_sql}
                        ORDER BY bm25 ASC
                        LIMIT ?
                        """,
                        (*params, int(top_k)),
                    ).fetchall()

                rows = _run(query_sanitized)
                if not rows and query_sanitized != query:
                    rows = _run(query)

                hits: list[LexicalHit] = []
                for r in rows:
                    bm25 = float(r["bm25"])
                    path = str(r["file_path"])
                    # Downweight docs/tests to reduce noise.
                    if path.startswith("docs/") or path.startswith("tests/"):
                        bm25 *= 1.5
                    hits.append(
                        LexicalHit(
                            rowid=int(r["rowid"]),
                            file_path=path,
                            name=str(r["name"] or ""),
                            chunk_type=str(r["chunk_type"] or ""),
                            start_line=int(r["start_line"] or 1),
                            end_line=int(r["end_line"] or 1),
                            text=str(r["text"] or ""),
                            bm25=bm25,
                        )
                    )
                # Resort after penalties (lower bm25 = better)
                hits.sort(key=lambda h: h.bm25)
                return hits
        except sqlite3.OperationalError:
            return []
