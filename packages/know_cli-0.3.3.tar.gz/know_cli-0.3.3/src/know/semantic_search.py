"""Semantic code search using real embeddings and vector similarity.

Supports both file-level (v1) and function-level (v2) embeddings.
Function-level uses AST to split Python files into individual chunks
(functions, classes, module summaries).
"""

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import numpy as np

try:
    import pathspec
except ImportError:
    pathspec = None


class EmbeddingCache:
    """Cache for code embeddings using binary storage with persistent connection support.
    
    Embeddings are scoped per project to prevent cross-project contamination.
    Each project gets its own table based on a hash of the project root path.
    """
    
    def __init__(self, cache_dir: Path = None, project_root: Path = None):
        self.cache_dir = cache_dir or Path.home() / ".cache" / "know-cli"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.cache_dir / "embeddings-v2.db"
        self._conn = None
        
        # Project scoping: use hash of project root to isolate embeddings
        if project_root:
            self._project_id = hashlib.sha256(
                str(project_root.resolve()).encode()
            ).hexdigest()[:16]
        else:
            self._project_id = "global"
        self._table = f"embeddings_{self._project_id}"
        
        self._init_db()
    
    def __enter__(self):
        """Enter context manager: open persistent connection."""
        self._conn = sqlite3.connect(self.db_path)
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager: close connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def _get_conn(self) -> sqlite3.Connection:
        """Get current persistent connection or create a temporary one."""
        if self._conn:
            return self._conn
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        """Initialize SQLite cache for embeddings (project-scoped table)."""
        conn = self._get_conn()
        try:
            with conn:
                conn.execute(f"""
                    CREATE TABLE IF NOT EXISTS {self._table} (
                        file_hash TEXT PRIMARY KEY,
                        file_path TEXT NOT NULL,
                        content_hash TEXT NOT NULL,
                        embedding BLOB NOT NULL,
                        model TEXT NOT NULL,
                        dim INTEGER NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                conn.execute(f"""
                    CREATE INDEX IF NOT EXISTS idx_path_{self._project_id}
                    ON {self._table}(file_path)
                """)
                conn.execute(f"""
                    CREATE INDEX IF NOT EXISTS idx_model_{self._project_id}
                    ON {self._table}(model)
                """)
                # Clean old entries (30 days)
                conn.execute(
                    f"DELETE FROM {self._table} WHERE created_at < datetime('now', '-30 days')"
                )
        finally:
            if not self._conn:
                conn.close()
    
    def get(self, file_path: str, content_hash: str, model: str) -> Optional[np.ndarray]:
        """Get cached embedding if available and model matches."""
        conn = self._get_conn()
        try:
            cursor = conn.execute(
                f"""SELECT embedding, dim FROM {self._table} 
                   WHERE file_path = ? AND content_hash = ? AND model = ?""",
                (file_path, content_hash, model)
            )
            row = cursor.fetchone()
            if row:
                # Deserialize from binary blob
                embedding_bytes = row[0]
                dim = row[1]
                return np.frombuffer(embedding_bytes, dtype=np.float32).reshape(dim)
        finally:
            if not self._conn:
                conn.close()
        return None
    
    def set(self, file_path: str, content_hash: str, embedding: np.ndarray, model: str):
        """Cache an embedding as binary blob."""
        file_hash = hashlib.sha256(f"{file_path}:{content_hash}:{model}".encode()).hexdigest()
        embedding_bytes = embedding.astype(np.float32).tobytes()
        dim = embedding.shape[0]
        
        conn = self._get_conn()
        try:
            with conn:
                conn.execute(
                    f"""INSERT OR REPLACE INTO {self._table} 
                       (file_hash, file_path, content_hash, embedding, model, dim)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (file_hash, file_path, content_hash, embedding_bytes, model, dim)
                )
        finally:
            if not self._conn:
                conn.close()

    def batch_set(self, items: List[Tuple[str, str, np.ndarray, str]]):
        """Batch insert embeddings. items = [(file_path, content_hash, embedding, model), ...]"""
        if not items:
            return
            
        data = []
        for file_path, content_hash, embedding, model in items:
            file_hash = hashlib.sha256(f"{file_path}:{content_hash}:{model}".encode()).hexdigest()
            embedding_bytes = embedding.astype(np.float32).tobytes()
            dim = embedding.shape[0]
            data.append((file_hash, file_path, content_hash, embedding_bytes, model, dim))
            
        conn = self._get_conn()
        try:
            with conn:
                conn.executemany(
                    f"""INSERT OR REPLACE INTO {self._table} 
                       (file_hash, file_path, content_hash, embedding, model, dim)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    data
                )
        finally:
            if not self._conn:
                conn.close()

    def batch_get(self, keys: List[Tuple[str, str, str]]) -> dict:
        """Batch get embeddings. keys = [(file_path, content_hash, model), ...]
        Returns dict: {(file_path, content_hash, model): embedding}
        """
        if not keys:
            return {}
            
        # Simplified batch get (could be optimized with IN clause but requires constructing query)
        # For now, just iterate with the persistent connection
        results = {}
        conn = self._get_conn()
        try:
            for fp, ch, md in keys:
                cursor = conn.execute(
                    f"""SELECT embedding, dim FROM {self._table} 
                       WHERE file_path = ? AND content_hash = ? AND model = ?""",
                    (fp, ch, md)
                )
                row = cursor.fetchone()
                if row:
                    embedding = np.frombuffer(row[0], dtype=np.float32).reshape(row[1])
                    results[(fp, ch, md)] = embedding
        finally:
            if not self._conn:
                conn.close()
        return results

    def get_all_embeddings(self, model: str) -> Tuple[List[str], np.ndarray]:
        """Get all embeddings for a model as a matrix. Returns (file_paths, embedding_matrix)."""
        conn = self._get_conn()
        try:
            cursor = conn.execute(
                f"SELECT file_path, embedding, dim FROM {self._table} WHERE model = ?",
                (model,)
            )
            rows = cursor.fetchall()
        finally:
            if not self._conn:
                conn.close()
        
        if not rows:
            return [], np.array([])
        
        file_paths = []
        embeddings = []
        
        for row in rows:
            file_paths.append(row[0])
            embedding = np.frombuffer(row[1], dtype=np.float32).reshape(row[2])
            embeddings.append(embedding)
        
        return file_paths, np.array(embeddings)
    
    def clear_model(self, model: str):
        """Clear all embeddings for a specific model."""
        conn = self._get_conn()
        try:
            with conn:
                conn.execute(f"DELETE FROM {self._table} WHERE model = ?", (model,))
        finally:
            if not self._conn:
                conn.close()


def _rrf_fuse(rankings: Dict[str, List[str]], k: int = 60) -> Dict[str, float]:
    """Reciprocal Rank Fusion.

    Args:
        rankings: mapping engine_name -> list of doc_ids in rank order.
        k: RRF constant.

    Returns mapping doc_id -> rrf score.
    """
    scores: Dict[str, float] = {}
    for _, doc_ids in rankings.items():
        for rank, doc_id in enumerate(doc_ids, start=1):
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (k + rank)
    return scores


def _format_snippet(
    file_path: Path,
    start_line: int,
    end_line: int,
    context: int = 4,
    include_line_numbers: bool = False,
    max_chars: int = 1200,
) -> Dict[str, Union[str, int]]:
    """Return a small surrounding snippet from a file."""
    try:
        content = file_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"text": "", "start_line": start_line, "end_line": end_line}

    lines = content.splitlines()
    if not lines:
        return {"text": "", "start_line": start_line, "end_line": end_line}

    # Clamp
    s = max(1, int(start_line))
    e = max(s, int(end_line))
    s2 = max(1, s - context)
    e2 = min(len(lines), e + context)

    snippet_lines = []
    for ln in range(s2, e2 + 1):
        text = lines[ln - 1]
        if include_line_numbers:
            snippet_lines.append(f"{ln:>6} | {text}")
        else:
            snippet_lines.append(text)

    snippet = "\n".join(snippet_lines)
    if len(snippet) > max_chars:
        snippet = snippet[: max_chars - 20] + "\n… [truncated]"

    return {"text": snippet, "start_line": s2, "end_line": e2}


class SemanticSearcher:
    """Semantic code search using fastembed embeddings."""
    
    # Model configuration
    DEFAULT_MODEL = "BAAI/bge-small-en-v1.5"  # 384-dim, good for code, ~100MB
    MODEL_DIM = 384
    MAX_FILE_SIZE = 1024 * 1024  # 1MB
    
    def __init__(self, model_name: Optional[str] = None, project_root: Optional[Path] = None):
        self.model_name = model_name or self.DEFAULT_MODEL
        self.project_root = project_root
        self.cache = EmbeddingCache(project_root=project_root)
        self._embedding_model = None
    
    def _get_embedding_model(self):
        """Lazy load the embedding model.

        If ``fastembed`` is unavailable, returns ``None`` and the searcher will
        fall back to a deterministic local hashing-embedding (no external deps).
        """
        if self._embedding_model is None:
            try:
                from fastembed import TextEmbedding

                self._embedding_model = TextEmbedding(model_name=self.model_name)
            except ImportError:
                self._embedding_model = False  # sentinel for "unavailable"
        return None if self._embedding_model is False else self._embedding_model

    @staticmethod
    def _hash_embedding(text: str, dim: int) -> np.ndarray:
        """Deterministic embedding fallback using a hashing trick.

        This is *not* as strong as real embeddings, but provides a reasonable
        semantic-ish baseline for tests and for environments without fastembed.
        """
        import re

        vec = np.zeros(dim, dtype=np.float32)
        tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_]+", text.lower())
        if not tokens:
            return vec

        for tok in tokens:
            h = hash(tok)
            idx = h % dim
            sign = 1.0 if (h & 1) else -1.0
            vec[idx] += sign

        # L2 normalize
        norm = float(np.linalg.norm(vec))
        if norm:
            vec /= norm
        return vec

    def _get_embedding(self, text: str) -> np.ndarray:
        """Get embedding for text.

        Uses fastembed when available, otherwise falls back to a hashing-based
        embedding with the same dimensionality.
        """
        # Truncate if too long (model has max tokens)
        max_chars = 8000
        if len(text) > max_chars:
            text = text[:max_chars]

        model = self._get_embedding_model()
        if model is None:
            return self._hash_embedding(text, self.MODEL_DIM)

        embeddings = list(model.embed([text]))
        return np.array(embeddings[0], dtype=np.float32)
    
    def _cosine_similarity(self, query_embedding: np.ndarray, embeddings_matrix: np.ndarray) -> np.ndarray:
        """Calculate cosine similarity using vectorized numpy operations."""
        # Normalize query
        query_norm = np.linalg.norm(query_embedding)
        if query_norm == 0:
            return np.zeros(embeddings_matrix.shape[0])
        query_normalized = query_embedding / query_norm
        
        # Normalize embeddings matrix (row-wise)
        norms = np.linalg.norm(embeddings_matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1  # Avoid division by zero
        embeddings_normalized = embeddings_matrix / norms
        
        # Cosine similarity = dot product of normalized vectors
        return np.dot(embeddings_normalized, query_normalized)
    
    def index_file(self, file_path: Path) -> bool:
        """Index a single file. Returns True if indexed or already cached."""
        try:
            # Check file size before reading
            size = file_path.stat().st_size
            if size > self.MAX_FILE_SIZE:
                return False

            content = file_path.read_text(encoding="utf-8", errors="ignore")
            if not content.strip():
                return False
            
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
            
            # Check cache
            cached = self.cache.get(str(file_path), content_hash, self.model_name)
            if cached is not None:
                return True
            
            # Get embedding
            embedding = self._get_embedding(content)
            
            # Cache it
            self.cache.set(str(file_path), content_hash, embedding, self.model_name)
            return True
            
        except Exception:
            return False
    
    def index_directory(self, root: Path, extensions: List[str] = None) -> int:
        """Index all files in a directory. Returns count of indexed files."""
        if extensions is None:
            extensions = [".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".cpp", ".c", ".h"]
        
        # Load .gitignore if present
        ignore_spec = None
        gitignore_path = root / ".gitignore"
        if gitignore_path.exists() and pathspec:
            try:
                with open(gitignore_path, "r") as f:
                    ignore_spec = pathspec.PathSpec.from_lines("gitwildmatch", f)
            except Exception:
                pass

        count = 0
        
        # Use persistent connection
        with self.cache:
            for ext in extensions:
                for file_path in root.rglob(f"*{ext}"):
                    # Check .gitignore
                    if ignore_spec:
                        try:
                            rel_path = file_path.relative_to(root)
                            if ignore_spec.match_file(str(rel_path)):
                                continue
                        except ValueError:
                            pass
                    
                    # Fallback skip for common dirs if pathspec failed or didn't catch them
                    if any(part.startswith(".") or part in {"node_modules", "__pycache__", "venv", ".git", "dist", "build"} 
                           for part in file_path.parts):
                        continue
                    
                    if self.index_file(file_path):
                        count += 1
        
        return count
    
    def search(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        """Search for files semantically similar to query."""
        # Get query embedding
        query_embedding = self._get_embedding(query)
        
        # Get all cached embeddings as matrix
        file_paths, embeddings_matrix = self.cache.get_all_embeddings(self.model_name)
        
        if not file_paths or embeddings_matrix.size == 0:
            return []
        
        # Vectorized cosine similarity
        similarities = self._cosine_similarity(query_embedding, embeddings_matrix)
        
        # Get top-k indices
        top_indices = np.argpartition(similarities, -min(top_k, len(similarities)))[-top_k:]
        top_indices = top_indices[np.argsort(similarities[top_indices])[::-1]]
        
        # Return results
        results = [(file_paths[i], float(similarities[i])) for i in top_indices if similarities[i] > 0]
        return results
    
    def search_code(self, query: str, root: Path, top_k: int = 10, auto_index: bool = True) -> List[dict]:
        """Search code with context and previews."""
        # Auto-index if requested
        if auto_index:
            self.index_directory(root)
        
        # Search
        results = self.search(query, top_k)
        
        # Format results with snippets
        formatted = []
        for file_path, score in results:
            try:
                path = Path(file_path)
                if path.exists():
                    content = path.read_text(encoding="utf-8", errors="ignore")
                    # Get first 10 lines as preview
                    lines = content.split("\n")[:10]
                    preview = "\n".join(lines)[:500]
                    
                    formatted.append({
                        "path": file_path,
                        "score": round(score, 3),
                        "preview": preview
                    })
            except Exception:
                pass
        
        return formatted

    def search_hybrid_code(
        self,
        query: str,
        root: Path,
        top_k: int = 10,
        auto_index: bool = True,
        engine: str = "hybrid",
        include_line_numbers: bool = False,
        path_prefix: Optional[str] = None,
        type_suffix: Optional[str] = None,
    ) -> List[dict]:
        """Hybrid retrieval: lexical BM25 (FTS5) + vector similarity (fastembed).

        - Uses Reciprocal Rank Fusion (RRF) to deterministically merge rankings.
        - Gracefully degrades: if FTS5 and/or fastembed are unavailable.

        Returns stable schema dicts suitable for JSON output.
        """

        engine = (engine or "hybrid").lower()
        if engine not in {"hybrid", "lexical", "vector"}:
            engine = "hybrid"

        # ---------------------- lexical leg (FTS5) ----------------------
        lexical_hits: list[dict] = []
        lexical_ids: list[str] = []
        lexical_available = False
        if engine in {"hybrid", "lexical"}:
            try:
                from know.lexical_index import ChunkFTSIndex

                fts = ChunkFTSIndex(root / ".know" / "cache" / "index.db")
                lexical_available = fts.available()
                if auto_index and lexical_available:
                    # Ensure chunks_fts is fresh by scanning changed files.
                    # This uses the existing incremental scanner/index pipeline.
                    from know.config import Config
                    from know.scanner import CodebaseScanner

                    cfg = Config.create_default(root)
                    CodebaseScanner(cfg).scan()

                    # Also ensure non-parser filetypes (e.g. Markdown) are indexed.
                    try:
                        fts.index_directory(root)
                    except Exception:
                        pass

                if lexical_available:
                    hits = fts.search(
                        query,
                        top_k=max(top_k * 5, 50),
                        path_prefix=path_prefix,
                        type_suffix=type_suffix,
                    )
                    for h in hits:
                        doc_id = f"{h.file_path}::{h.name}::{h.start_line}"
                        lexical_ids.append(doc_id)
                        lexical_hits.append(
                            {
                                "doc_id": doc_id,
                                "path": h.file_path,
                                "name": h.name,
                                "chunk_type": h.chunk_type,
                                "start_line": h.start_line,
                                "end_line": h.end_line,
                                "lexical_bm25": h.bm25,
                            }
                        )
            except Exception:
                lexical_available = False

        # ---------------------- vector leg (fastembed) -------------------
        vector_results: list[dict] = []
        vector_ids: list[str] = []
        vector_available = False
        if engine in {"hybrid", "vector"}:
            try:
                vector_available = True
                # search_chunks already auto-indexes embeddings for chunks.
                vec = self.search_chunks(
                    query,
                    root,
                    top_k=max(top_k * 5, 50),
                    auto_index=auto_index,
                )

                for r in vec:
                    # Use a stable doc_id compatible with lexical.
                    doc_id = f"{r['path']}::{r.get('name','')}::{int(r.get('line_start', 1))}"

                    # Apply path/type filters for vector leg too.
                    if path_prefix and not str(r["path"]).startswith(path_prefix):
                        continue
                    if type_suffix:
                        suf = type_suffix if type_suffix.startswith(".") else f".{type_suffix}"
                        if not str(r["path"]).endswith(suf):
                            continue

                    vector_ids.append(doc_id)
                    vector_results.append(
                        {
                            "doc_id": doc_id,
                            "path": r["path"],
                            "name": r.get("name", ""),
                            "chunk_type": r.get("type", r.get("chunk_type", "")) or "",
                            "start_line": int(r.get("line_start", 1)),
                            "end_line": int(r.get("line_end", r.get("line_start", 1))),
                            "vector_score": float(r.get("score", 0.0)),
                        }
                    )
            except Exception:
                vector_available = False

        # ---------------------- fuse & format ---------------------------
        if engine == "lexical" and not lexical_available:
            return []
        if engine == "vector" and not vector_available:
            return []

        if engine == "lexical":
            fused_ids = lexical_ids
            fused_scores = {doc_id: 1.0 / (i + 1) for i, doc_id in enumerate(fused_ids)}
        elif engine == "vector":
            fused_ids = vector_ids
            fused_scores = {doc_id: 1.0 / (i + 1) for i, doc_id in enumerate(fused_ids)}
        else:
            fused_scores = _rrf_fuse({"lexical": lexical_ids, "vector": vector_ids})
            fused_ids = sorted(fused_scores.keys(), key=lambda d: fused_scores[d], reverse=True)

        # Merge metadata
        by_id: Dict[str, dict] = {}
        for r in lexical_hits:
            by_id[r["doc_id"]] = {**r}
        for r in vector_results:
            by_id.setdefault(r["doc_id"], {}).update(r)

        results: list[dict] = []
        for rank, doc_id in enumerate(fused_ids[:top_k], start=1):
            meta = by_id.get(doc_id, {"doc_id": doc_id})
            path = meta.get("path", "")
            start_line = int(meta.get("start_line", 1))
            end_line = int(meta.get("end_line", start_line))

            snippet = {}
            try:
                snippet = _format_snippet(
                    root / path,
                    start_line,
                    end_line,
                    context=2,
                    include_line_numbers=include_line_numbers,
                )
            except Exception:
                snippet = {"text": "", "start_line": start_line, "end_line": end_line}

            # Scores + rationale are stable keys.
            # Penalize docs/tests slightly in final score.
            score = float(fused_scores.get(doc_id, 0.0))
            if path.startswith("docs/") or path.startswith("tests/"):
                score *= 0.7

            # Filename/path lexical boost: if query tokens appear in filename/path,
            # prioritize those hits (helps frontend queries like "composer toolbar").
            try:
                q_tokens = [t.lower() for t in query.replace("_", " ").replace("-", " ").split() if len(t) >= 3]
                path_l = str(path).lower().replace("_", " ").replace("-", " ")
                if q_tokens:
                    matches = sum(1 for t in q_tokens if t in path_l)
                    if matches > 0:
                        score *= 1.0 + min(0.35, 0.12 * matches)
            except Exception:
                pass

            out = {
                "schema": "know.search.v1",
                "engine": engine,
                "rank": rank,
                "doc_id": doc_id,
                "path": path,
                "name": meta.get("name", ""),
                "chunk_type": meta.get("chunk_type", ""),
                "start_line": start_line,
                "end_line": end_line,
                "scores": {
                    "rrf": score,
                    "lexical_bm25": meta.get("lexical_bm25"),
                    "vector": meta.get("vector_score"),
                },
                "snippet": snippet,
                "rationale": {
                    "lexical_available": lexical_available,
                    "vector_available": vector_available,
                },
            }
            results.append(out)

        return results

    def clear_cache(self):
        """Clear all cached embeddings for current model."""
        self.cache.clear_model(self.model_name)

    # ------------------------------------------------------------------
    # Function-level (chunk) embeddings
    # ------------------------------------------------------------------
    def index_chunks(self, root: Path, extensions: List[str] = None) -> int:
        """Index code at function/class level for Python files.
        
        Non-Python files fall back to file-level embedding.
        Returns number of chunks indexed.
        """
        from know.context_engine import extract_chunks_from_file

        if extensions is None:
            extensions = [".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".cpp", ".c", ".h"]

        ignore_spec = None
        gitignore_path = root / ".gitignore"
        if gitignore_path.exists() and pathspec:
            try:
                with open(gitignore_path, "r") as f:
                    ignore_spec = pathspec.PathSpec.from_lines("gitwildmatch", f)
            except Exception:
                pass

        count = 0

        with self.cache:
            for ext in extensions:
                for file_path in root.rglob(f"*{ext}"):
                    # Skip ignored directories
                    if any(part.startswith(".") or part in {"node_modules", "__pycache__", "venv", ".git", "dist", "build"}
                           for part in file_path.parts):
                        continue
                    if ignore_spec:
                        try:
                            rel_path = file_path.relative_to(root)
                            if ignore_spec.match_file(str(rel_path)):
                                continue
                        except ValueError:
                            pass

                    # Check file size
                    try:
                        if file_path.stat().st_size > self.MAX_FILE_SIZE:
                            continue
                    except OSError:
                        continue

                    chunks = extract_chunks_from_file(file_path, root)
                    for chunk in chunks:
                        chunk_key = f"{chunk.file_path}::{chunk.name}::{chunk.line_start}"
                        # Build text for embedding
                        embed_text = f"{chunk.name} {chunk.signature}\n{chunk.docstring}\n{chunk.body[:2000]}"
                        content_hash = hashlib.sha256(embed_text.encode()).hexdigest()[:16]

                        # Check cache
                        cached = self.cache.get(chunk_key, content_hash, self.model_name)
                        if cached is not None:
                            count += 1
                            continue

                        try:
                            embedding = self._get_embedding(embed_text)
                            # Store with metadata in file_path field as JSON-encoded key
                            metadata = json.dumps({
                                "file": chunk.file_path,
                                "name": chunk.name,
                                "type": chunk.chunk_type,
                                "line_start": chunk.line_start,
                                "line_end": chunk.line_end,
                            })
                            self.cache.set(chunk_key, content_hash, embedding, self.model_name)
                            count += 1
                        except Exception:
                            pass

        return count

    def search_chunks(self, query: str, root: Path, top_k: int = 20, auto_index: bool = True) -> List[dict]:
        """Search at function/class level with metadata.
        
        Returns list of dicts with: path, name, type, line_start, line_end, score, preview.
        """
        if auto_index:
            self.index_chunks(root)

        # Get query embedding
        query_embedding = self._get_embedding(query)

        # Get all embeddings
        file_paths, embeddings_matrix = self.cache.get_all_embeddings(self.model_name)
        if not file_paths or embeddings_matrix.size == 0:
            return []

        # Cosine similarity
        similarities = self._cosine_similarity(query_embedding, embeddings_matrix)
        top_indices = np.argpartition(similarities, -min(top_k, len(similarities)))[-top_k:]
        top_indices = top_indices[np.argsort(similarities[top_indices])[::-1]]

        results = []
        for i in top_indices:
            if similarities[i] <= 0:
                continue
            chunk_key = file_paths[i]
            # Parse chunk key: "file_path::name::line_start"
            parts = chunk_key.split("::")
            if len(parts) >= 3:
                results.append({
                    "path": parts[0],
                    "name": parts[1],
                    "line_start": int(parts[2]) if parts[2].isdigit() else 1,
                    "score": round(float(similarities[i]), 3),
                    "chunk_key": chunk_key,
                })
            else:
                # File-level embedding (old style)
                results.append({
                    "path": chunk_key,
                    "name": Path(chunk_key).stem,
                    "line_start": 1,
                    "score": round(float(similarities[i]), 3),
                    "chunk_key": chunk_key,
                })

        return results
