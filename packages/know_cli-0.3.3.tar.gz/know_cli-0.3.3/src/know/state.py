"""State management for know-cli tasks."""

import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Any

from know.config import Config


class StateTracker:
    """Manages persistent state for agent tasks."""
    
    def __init__(self, config: Config):
        self.config = config
        self.state_dir = config.root / ".know"
        self.state_file = self.state_dir / "state.json"
        self._ensure_state_dir()

    def _ensure_state_dir(self):
        """Ensure .know directory exists."""
        self.state_dir.mkdir(parents=True, exist_ok=True)

    def _load(self) -> Dict[str, Any]:
        """Load state from file."""
        if not self.state_file.exists():
            return {
                "current_task": None,
                "checkpoints": [],
                "history": [],
                "updated_at": None
            }
        try:
            return json.loads(self.state_file.read_text())
        except json.JSONDecodeError:
            return {
                "current_task": None,
                "checkpoints": [],
                "history": [],
                "updated_at": None
            }

    def _save(self, state: Dict[str, Any]):
        """Save state to file."""
        state["updated_at"] = time.time()
        self.state_file.write_text(json.dumps(state, indent=2))

    def set_task(self, task: str, progress: str = "started", metadata: Dict = None):
        """Set or update current task."""
        state = self._load()
        current = state.get("current_task") or {}
        state["current_task"] = {
            "description": task,
            "progress": progress,
            "started_at": current.get("started_at", time.time()),
            "updated_at": time.time(),
            "metadata": metadata or {}
        }
        self._save(state)

    def get_task(self) -> Optional[Dict]:
        """Get current task info."""
        state = self._load()
        return state.get("current_task")

    def clear_task(self):
        """Clear current task (mark complete)."""
        state = self._load()
        if state.get("current_task"):
            # Move to history
            task = state["current_task"]
            task["completed_at"] = time.time()
            state["history"].append(task)
            # Keep history manageable (last 50 items)
            state["history"] = state["history"][-50:]
        
        state["current_task"] = None
        self._save(state)

    def create_checkpoint(self, name: str = None) -> str:
        """Save current state as a checkpoint."""
        state = self._load()
        checkpoint_id = f"cp_{int(time.time())}"
        name = name or f"Checkpoint {checkpoint_id}"
        
        checkpoint = {
            "id": checkpoint_id,
            "name": name,
            "timestamp": time.time(),
            "task": state.get("current_task"),
            # In future: could include git state, file hashes, etc.
        }
        
        state.setdefault("checkpoints", []).append(checkpoint)
        # Keep checkpoints manageable (last 10)
        state["checkpoints"] = state["checkpoints"][-10:]
        
        self._save(state)
        return checkpoint_id

    def restore_checkpoint(self, checkpoint_id: str) -> bool:
        """Restore state from a checkpoint."""
        state = self._load()
        checkpoints = state.get("checkpoints", [])
        
        target = next((cp for cp in checkpoints if cp["id"] == checkpoint_id), None)
        if not target:
            return False
            
        # Restore task state
        state["current_task"] = target.get("task")
        self._save(state)
        return True

    def list_checkpoints(self) -> List[Dict]:
        """List available checkpoints."""
        state = self._load()
        return state.get("checkpoints", [])
