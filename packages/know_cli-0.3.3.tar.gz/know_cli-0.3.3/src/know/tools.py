"""Tool discovery for know-cli."""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Optional


EXCLUDED_DIR_NAMES = {
    ".git",
    ".know",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "venv",
    ".venv",
}


@dataclass
class Tool:
    name: str
    command: str
    source: str  # package.json, makefile, script, python_cli, github_actions
    path: str
    description: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


class ToolScanner:
    """Discover runnable tools and scripts from common project conventions."""

    def __init__(self, root: Path):
        self.root = Path(root)

    def scan(self) -> List[Tool]:
        tools: List[Tool] = []
        tools.extend(self.scan_scripts())
        tools.extend(self.scan_package_json())
        tools.extend(self.scan_makefile())
        tools.extend(self.scan_python_clis())
        tools.extend(self.scan_github_actions())
        tools.extend(self.scan_docker())
        return self._dedupe(tools)

    def search(self, query: str, limit: int = 25) -> List[Tool]:
        query = query.strip().lower()
        if not query:
            return self.scan()[:limit]

        scored = []
        for tool in self.scan():
            score = self._score(tool, query)
            if score > 0:
                scored.append((score, tool))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [tool for _, tool in scored[:limit]]

    def suggest(self, intent: str, limit: int = 10) -> List[Tool]:
        """Suggest likely tools for an intent phrase (simple lexical ranking)."""
        return self.search(intent, limit=limit)

    def scan_scripts(self) -> List[Tool]:
        tools: List[Tool] = []
        script_dirs = ["scripts", "bin", "tools"]
        for d in script_dirs:
            path = self.root / d
            if not path.exists():
                continue
            for f in path.glob("*"):
                if f.is_dir():
                    continue

                try:
                    rel_path = str(f.relative_to(self.root))
                    if os.access(f, os.X_OK):
                        tools.append(
                            Tool(
                                name=f.name,
                                command=f"./{rel_path}",
                                source="script",
                                path=rel_path,
                                description="Executable script",
                            )
                        )
                    elif f.suffix in [".sh", ".py", ".js", ".ts"]:
                        cmd = (
                            f"bash {rel_path}"
                            if f.suffix == ".sh"
                            else f"python3 {rel_path}"
                            if f.suffix == ".py"
                            else f"node {rel_path}"
                        )
                        tools.append(
                            Tool(
                                name=f.name,
                                command=cmd,
                                source="script",
                                path=rel_path,
                                description=f"{f.suffix[1:].upper()} script",
                            )
                        )
                except Exception:
                    pass
        return tools

    def scan_package_json(self) -> List[Tool]:
        path = self.root / "package.json"
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text())
            scripts = data.get("scripts", {})
            return [
                Tool(
                    name=name,
                    command=f"npm run {name}",
                    source="package.json",
                    path="package.json",
                    description=cmd,
                )
                for name, cmd in scripts.items()
            ]
        except Exception:
            return []

    def scan_makefile(self) -> List[Tool]:
        path = self.root / "Makefile"
        if not path.exists():
            return []
        tools: List[Tool] = []
        try:
            content = path.read_text()
            matches = re.finditer(r"^([a-zA-Z0-9_-]+)\s*:\s*(?:#\s*(.*))?$", content, re.MULTILINE)
            for m in matches:
                target = m.group(1)
                comment = m.group(2) or ""
                if target in [".PHONY", "all", "help"]:
                    continue
                tools.append(
                    Tool(
                        name=target,
                        command=f"make {target}",
                        source="Makefile",
                        path="Makefile",
                        description=comment or f"Make target: {target}",
                    )
                )
        except Exception:
            pass
        return tools

    def scan_python_clis(self) -> List[Tool]:
        """Heuristic: detect Python files with a __main__ block."""
        tools: List[Tool] = []
        for f in self.root.rglob("*.py"):
            if any(part in EXCLUDED_DIR_NAMES for part in f.parts):
                continue

            try:
                with open(f, "r", errors="ignore") as fp:
                    content = fp.read(4096)
                    if len(content) == 4096:
                        fp.seek(0, 2)
                        size = fp.tell()
                        if size > 4096:
                            fp.seek(max(0, size - 4096))
                            content += "\n" + fp.read()

                if "if __name__" in content and "__main__" in content:
                    rel_path = f.relative_to(self.root)
                    tools.append(
                        Tool(
                            name=f.stem,
                            command=f"python3 {rel_path}",
                            source="python_cli",
                            path=str(rel_path),
                            description="Python CLI script",
                        )
                    )
            except Exception:
                pass
        return tools

    def scan_github_actions(self) -> List[Tool]:
        workflows_dir = self.root / ".github" / "workflows"
        if not workflows_dir.exists():
            return []

        tools: List[Tool] = []
        for wf in workflows_dir.glob("*.y*ml"):
            tools.append(
                Tool(
                    name=wf.stem,
                    command=f"gh workflow run {wf.name}",
                    source="github_actions",
                    path=str(wf.relative_to(self.root)),
                    description="GitHub Actions workflow",
                )
            )
        return tools

    def scan_docker(self) -> List[Tool]:
        """Scan docker-compose files for services."""
        tools: List[Tool] = []
        for name in ["docker-compose.yml", "compose.yaml", "docker-compose.yaml"]:
            path = self.root / name
            if not path.exists():
                continue

            try:
                content = path.read_text()
                # Simple regex for services (avoid yaml dep if possible, though know-cli might have it)
                # Look for "  service_name:" pattern under "services:"
                # This is heuristic but usually good enough for simple files
                matches = re.finditer(r"^  ([a-zA-Z0-9_-]+):\s*$", content, re.MULTILINE)
                for m in matches:
                    svc = m.group(1)
                    if svc not in ["version", "services", "volumes", "networks"]:
                        tools.append(
                            Tool(
                                name=f"docker-{svc}",
                                command=f"docker-compose up {svc}",
                                source="docker",
                                path=name,
                                description=f"Run {svc} service",
                            )
                        )
            except Exception:
                pass
            break  # Only process the first found compose file
        return tools

    def _score(self, tool: Tool, query: str) -> float:
        haystack = " ".join(
            [tool.name.lower(), tool.command.lower(), (tool.description or "").lower(), tool.source.lower()]
        )
        terms = [t for t in re.split(r"\W+", query) if t]
        if not terms:
            return 0.0

        score = 0.0
        for term in terms:
            if term == tool.name.lower():
                score += 5
            elif term in tool.name.lower():
                score += 3
            if term in tool.command.lower():
                score += 2
            if term in (tool.description or "").lower():
                score += 2
            if term in tool.source.lower():
                score += 1
            if term in haystack:
                score += 0.5
        return score

    def _dedupe(self, tools: List[Tool]) -> List[Tool]:
        seen = set()
        deduped: List[Tool] = []
        for tool in tools:
            key = (tool.name, tool.command, tool.path)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(tool)
        deduped.sort(key=lambda t: (t.source, t.name))
        return deduped
