"""Lightweight stub of the `mcp` package used in tests.

The upstream know-cli supports an optional dependency `mcp`.
In minimal environments (including this repository's unit tests), we provide
just enough of the public surface area to construct a FastMCP server and
register tools/resources.

If the real `mcp` package is installed, it will typically take precedence in
site-packages; but tests insert `src/` early on `sys.path`, so this stub is
used when the dependency is absent.
"""
