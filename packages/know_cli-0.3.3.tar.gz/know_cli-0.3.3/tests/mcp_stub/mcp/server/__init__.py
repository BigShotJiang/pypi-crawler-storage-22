"""Server subpackage for the MCP stub."""
