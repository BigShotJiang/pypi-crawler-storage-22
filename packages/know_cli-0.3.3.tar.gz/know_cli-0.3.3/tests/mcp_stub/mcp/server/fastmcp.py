"""Minimal stub for `mcp.server.fastmcp.FastMCP`.

This is intentionally tiny: it supports the decorators used by know-cli
(`@server.tool()` and `@server.resource()`) and exposes a `name` attribute.

It is *not* a full MCP implementation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional


@dataclass
class _Registration:
    name: str
    fn: Callable[..., Any]
    description: str = ""


class FastMCP:
    def __init__(self, name: str, instructions: str = ""):
        self.name = name
        self.instructions = instructions
        self.tools: Dict[str, _Registration] = {}
        self.resources: Dict[str, _Registration] = {}

    # Decorators --------------------------------------------------------
    def tool(self, name: Optional[str] = None, description: str = ""):
        def decorator(fn: Callable[..., Any]):
            tool_name = name or fn.__name__
            self.tools[tool_name] = _Registration(tool_name, fn, description)
            return fn

        return decorator

    def resource(self, uri: Optional[str] = None, description: str = ""):
        def decorator(fn: Callable[..., Any]):
            res_name = uri or fn.__name__
            self.resources[res_name] = _Registration(res_name, fn, description)
            return fn

        return decorator
