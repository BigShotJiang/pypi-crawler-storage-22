import json

from click.testing import CliRunner

from know.cli import cli
from know.config import load_config
from know.stats import StatsTracker


def test_history_log_search_success_rate():
    runner = CliRunner()
    with runner.isolated_filesystem():
        from pathlib import Path
        from know.config import Config

        root = Path('.').resolve()
        (root / '.know' / 'cache').mkdir(parents=True, exist_ok=True)
        (root / 'src').mkdir(exist_ok=True)
        (root / 'src' / 'main.py').write_text("def hi():\n    return 'hi'\n")
        cfg = Config.create_default(root)
        cfg.root = root
        cfg.save(root / '.know' / 'config.yaml')

        r1 = runner.invoke(
            cli,
            [
                "--json",
                "history",
                "log",
                "--command",
                "npm test",
                "--result",
                "failed",
                "--reason",
                "missing env",
            ],
        )
        assert r1.exit_code == 0
        e1 = json.loads(r1.output)
        assert e1["result"] == "failed"

        r2 = runner.invoke(
            cli,
            [
                "history",
                "log",
                "--command",
                "npm test",
                "--result",
                "success",
                "--reason",
                "after env fix",
            ],
        )
        assert r2.exit_code == 0

        search = runner.invoke(
            cli,
            ["--json", "history", "search", "npm", "--result", "failed"],
        )
        assert search.exit_code == 0
        matches = json.loads(search.output)["results"]
        assert len(matches) == 1
        assert matches[0]["command"] == "npm test"
        assert matches[0]["reason"] == "missing env"

        rate = runner.invoke(cli, ["--json", "history", "success-rate", "npm"])
        assert rate.exit_code == 0
        stats = json.loads(rate.output)
        assert stats["total"] == 2
        assert stats["successes"] == 1
        assert stats["success_rate"] == 50.0


def test_cost_commands_with_fallback_and_budget():
    runner = CliRunner()
    with runner.isolated_filesystem():
        from pathlib import Path
        from know.config import Config

        root = Path('.').resolve()
        (root / '.know' / 'cache').mkdir(parents=True, exist_ok=True)
        (root / 'src').mkdir(exist_ok=True)
        (root / 'src' / 'main.py').write_text("def hi():\n    return 'hi'\n")
        cfg = Config.create_default(root)
        cfg.root = root
        cfg.save(root / '.know' / 'config.yaml')

        # No telemetry yet -> unknown fallback fields reported
        summary_empty = runner.invoke(cli, ["--json", "cost", "summary"])
        assert summary_empty.exit_code == 0
        empty_data = json.loads(summary_empty.output)
        assert empty_data["queries"] == 0
        assert "estimated_cost_usd" in empty_data["unknown_fields"]

        # Seed telemetry using existing StatsTracker DB
        config = load_config()
        tracker = StatsTracker(config)
        tracker.record_context("fix auth", budget=1000, tokens_used=600, duration_ms=120)
        tracker.record_context("fix auth", budget=1000, tokens_used=700, duration_ms=100)
        tracker.record_context("add tests", budget=800, tokens_used=500, duration_ms=140)

        by_query = runner.invoke(cli, ["--json", "cost", "by-query"])
        assert by_query.exit_code == 0
        by_query_data = json.loads(by_query.output)
        assert by_query_data["queries"][0]["tokens_used"] >= by_query_data["queries"][1]["tokens_used"]

        savings = runner.invoke(cli, ["--json", "cost", "savings"])
        assert savings.exit_code == 0
        savings_data = json.loads(savings.output)
        assert savings_data["estimated_saved_tokens"] is not None
        assert savings_data["savings_ratio"] >= 0

        budget_set = runner.invoke(cli, ["--json", "cost", "budget", "--limit", "5000"])
        assert budget_set.exit_code == 0
        budget_data = json.loads(budget_set.output)
        assert budget_data["monthly_token_budget"] == 5000
        assert budget_data["tokens_used"] == 1800
        assert budget_data["budget_remaining_tokens"] == 3200
