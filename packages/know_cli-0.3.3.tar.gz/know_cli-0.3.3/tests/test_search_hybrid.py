import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from know.cli import cli
from know.config import Config


def _init_project(root: Path) -> None:
    (root / ".know" / "cache").mkdir(parents=True, exist_ok=True)
    cfg = Config.create_default(root)
    cfg.save(root / ".know" / "config.yaml")


@pytest.mark.integration
def test_hybrid_search_returns_expected_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    root = tmp_path
    (root / "src").mkdir()

    (root / "src" / "auth.py").write_text(
        """
# Authentication helpers

def make_token(user_id: str) -> str:
    return f"token:{user_id}"

# click.option reference for lexical punctuation test
@click.option("--token")

def cli_entry():
    pass
""".lstrip()
    )

    (root / "src" / "db.py").write_text(
        """
# Database helpers

def connect_db(url: str) -> None:
    raise RuntimeError("not implemented")
""".lstrip()
    )

    _init_project(root)
    monkeypatch.chdir(root)

    runner = CliRunner()
    res = runner.invoke(cli, ["--json", "search", "make token", "--engine", "hybrid", "--top-k", "5"])
    assert res.exit_code == 0, f"Stdout: {res.output}\nStderr: {res.stderr}"

    try:
        payload = json.loads(res.output)
    except json.JSONDecodeError:
        pytest.fail(f"Invalid JSON in stdout: '{res.output}'. Stderr: '{res.stderr}'")
    assert payload["schema"] == "know.search.response.v1"
    assert payload["engine"] == "hybrid"
    assert isinstance(payload["results"], list)
    assert payload["results"], "expected at least one result"

    top = payload["results"][0]
    # Stable schema keys
    for key in [
        "schema",
        "engine",
        "rank",
        "doc_id",
        "path",
        "name",
        "chunk_type",
        "start_line",
        "end_line",
        "scores",
        "snippet",
        "rationale",
    ]:
        assert key in top

    assert top["path"].startswith("src/")
    assert "auth.py" in top["path"]


@pytest.mark.integration
def test_search_path_and_type_filters(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    root = tmp_path
    (root / "src").mkdir()
    (root / "docs").mkdir()

    (root / "src" / "utils.py").write_text("""
import click

@click.option('--flag')

def helper():
    # click.option
    return 'ok'
""".lstrip())
    (root / "docs" / "guide.md").write_text("# Guide\n\nThis doc explains helper usage.\n")

    _init_project(root)
    monkeypatch.chdir(root)

    runner = CliRunner()

    # Type filter (md)
    res = runner.invoke(
        cli,
        [
            "--json",
            "search",
            "explains helper usage",
            "--engine",
            "lexical",
            "--type",
            "md",
            "--top-k",
            "5",
        ],
    )
    assert res.exit_code == 0, f"Stdout: {res.output}\nStderr: {res.stderr}"
    payload = json.loads(res.output)
    assert payload["results"], "expected md result"
    assert payload["results"][0]["path"].endswith("guide.md")

    # JSON flag after command should work
    res3 = runner.invoke(
        cli,
        [
            "search",
            "click.option",
            "--engine",
            "lexical",
            "--json",
            "--top-k",
            "5",
        ],
    )
    assert res3.exit_code == 0, f"Stdout: {res3.output}\nStderr: {res3.stderr}"
    payload3 = json.loads(res3.output)
    assert payload3["results"], "expected click.option match"
    assert any("utils.py" in r["path"] for r in payload3["results"])

    # Path filter
    res2 = runner.invoke(
        cli,
        [
            "--json",
            "search",
            "helper",
            "--engine",
            "lexical",
            "--path",
            "src/",
            "--top-k",
            "10",
        ],
    )
    assert res2.exit_code == 0, f"Stdout: {res2.output}\nStderr: {res2.stderr}"
    payload2 = json.loads(res2.output)
    assert payload2["results"], "expected src result"
    assert payload2["results"][0]["path"].startswith("src/")
