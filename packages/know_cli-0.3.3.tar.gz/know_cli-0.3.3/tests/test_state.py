import json
from click.testing import CliRunner
from know.cli import cli


def test_state_workflow():
    runner = CliRunner()
    with runner.isolated_filesystem():
        # Init
        from pathlib import Path
        from know.config import Config

        root = Path('.').resolve()
        (root / '.know' / 'cache').mkdir(parents=True, exist_ok=True)
        (root / 'src').mkdir(exist_ok=True)
        (root / 'src' / 'main.py').write_text("def hi():\n    return 'hi'\n")
        cfg = Config.create_default(root)
        cfg.root = root
        cfg.save(root / '.know' / 'config.yaml')

        # Set state
        result = runner.invoke(cli, ["state", "set", "--task", "Fix bug", "--progress", "Started"])
        assert result.exit_code == 0

        # Get state
        result = runner.invoke(cli, ["--json", "state", "get"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["description"] == "Fix bug"
        assert data["progress"] == "Started"

        # Checkpoint
        result = runner.invoke(cli, ["--json", "state", "checkpoint", "--name", "CP1"])
        assert result.exit_code == 0
        cp_data = json.loads(result.output)
        cp_id = cp_data["checkpoint_id"]

        # Clear
        result = runner.invoke(cli, ["state", "clear"])
        assert result.exit_code == 0

        # Verify cleared
        result = runner.invoke(cli, ["state", "get"])
        assert "No active task" in result.output

        # List checkpoints
        result = runner.invoke(cli, ["--json", "state", "list"])
        assert result.exit_code == 0
        cps = json.loads(result.output)
        assert len(cps) == 1
        assert cps[0]["id"] == cp_id

        # Restore
        result = runner.invoke(cli, ["state", "restore", cp_id])
        assert result.exit_code == 0
        assert "Restored checkpoint" in result.output

        # Verify restored
        result = runner.invoke(cli, ["--json", "state", "get"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["description"] == "Fix bug"
