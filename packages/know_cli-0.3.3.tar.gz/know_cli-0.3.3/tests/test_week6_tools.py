import os
import pytest
from pathlib import Path
from know.tools import ToolScanner, Tool

@pytest.fixture
def mock_project(tmp_path):
    """Create a mock project structure with various tools."""
    # Scripts
    scripts_dir = tmp_path / "scripts"
    scripts_dir.mkdir()
    
    (scripts_dir / "deploy.sh").write_text("#!/bin/bash\necho deploy")
    (scripts_dir / "deploy.sh").chmod(0o755)
    
    (scripts_dir / "test.py").write_text("print('test')")
    
    # Python CLI
    src_dir = tmp_path / "src"
    src_dir.mkdir()
    (src_dir / "cli.py").write_text("if __name__ == '__main__':\n    print('cli')")
    
    # Package.json
    (tmp_path / "package.json").write_text('{"scripts": {"start": "node index.js", "build": "tsc"}}')
    
    # Makefile
    (tmp_path / "Makefile").write_text("all:\n\t@echo all\n\ntest:\n\t@echo test\n\ndeploy:\n\t@echo deploy")
    
    # Docker Compose
    (tmp_path / "docker-compose.yml").write_text('version: "3"\nservices:\n  db:\n    image: postgres\n  api:\n    build: .')

    # GitHub Actions
    gh_dir = tmp_path / ".github" / "workflows"
    gh_dir.mkdir(parents=True)
    (gh_dir / "ci.yml").write_text("name: CI\non: push\njobs:\n  test:\n    runs-on: ubuntu-latest")

    return tmp_path

def test_scan_scripts(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_scripts()
    
    names = [t.name for t in tools]
    assert "deploy.sh" in names
    assert "test.py" in names
    
    deploy = next(t for t in tools if t.name == "deploy.sh")
    assert deploy.command.endswith("scripts/deploy.sh")
    assert deploy.source == "script"

def test_scan_package_json(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_package_json()
    
    names = [t.name for t in tools]
    assert "start" in names
    assert "build" in names
    
    start = next(t for t in tools if t.name == "start")
    assert start.command == "npm run start"
    assert start.source == "package.json"

def test_scan_makefile(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_makefile()
    
    names = [t.name for t in tools]
    assert "test" in names
    assert "deploy" in names
    assert "all" not in names # Excluded

def test_scan_python_clis(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_python_clis()
    
    names = [t.name for t in tools]
    assert "cli" in names
    
    cli = next(t for t in tools if t.name == "cli")
    assert "python3" in cli.command
    assert cli.source == "python_cli"

def test_scan_docker(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_docker()
    
    names = [t.name for t in tools]
    assert "docker-db" in names
    assert "docker-api" in names
    
    db = next(t for t in tools if t.name == "docker-db")
    assert db.command == "docker-compose up db"

def test_scan_github_actions(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan_github_actions()
    
    names = [t.name for t in tools]
    assert "ci" in names
    
    ci = next(t for t in tools if t.name == "ci")
    assert ci.command == "gh workflow run ci.yml"

def test_scan_all(mock_project):
    scanner = ToolScanner(mock_project)
    tools = scanner.scan()
    
    assert len(tools) >= 8 # 2 scripts + 2 npm + 2 make + 1 python + 2 docker + 1 gh = 10 (approx)

def test_search(mock_project):
    scanner = ToolScanner(mock_project)
    results = scanner.search("deploy")
    
    names = [t.name for t in results]
    assert "deploy.sh" in names
    assert "deploy" in names # Makefile
    # Maybe docker-api if description matches? No description in test for docker.
    
def test_suggest(mock_project):
    scanner = ToolScanner(mock_project)
    suggestions = scanner.suggest("db")
    # Should match docker-db
    names = [t.name for t in suggestions]
    assert "docker-db" in names
