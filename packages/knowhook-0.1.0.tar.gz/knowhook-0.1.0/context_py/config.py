from enum import Enum
from typing import List

from pydantic import BaseModel


class TaskStatus(str, Enum):
    active = "active"
    skipped = "skipped"
    completed = "completed"


class CurrentTask(BaseModel):
    id: str = "1"
    description: str = "Initial setup"
    status: TaskStatus = TaskStatus.active


class ContextConfig(BaseModel):
    project_name: str = "my-project"
    goals: List[str] = ["Define project goals"]
    current_task: CurrentTask = CurrentTask()
    tech_stack: List[str] = []
    rules: List[str] = []
