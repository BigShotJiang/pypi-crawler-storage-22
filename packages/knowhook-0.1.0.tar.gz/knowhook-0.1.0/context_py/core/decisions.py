"""Architectural decisions log."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from context_py.models import Decision, DecisionStatus
from context_py.utils.paths import get_project_know_dir


def _decisions_path() -> Path:
    return get_project_know_dir() / "decisions.json"


def load_decisions() -> List[Decision]:
    """Load all decisions from .know/decisions.json."""
    path = _decisions_path()
    if not path.exists():
        return []
    data = json.loads(path.read_text())
    return [Decision(**d) for d in data]


def save_decisions(decisions: List[Decision]) -> None:
    """Save decisions list to .know/decisions.json (atomic write)."""
    path = _decisions_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps([d.model_dump() for d in decisions], indent=2))
    tmp.replace(path)


def add_decision(description: str, reasoning: str = "") -> Decision:
    """Create a new decision, append to log, and save."""
    decisions = load_decisions()
    decision = Decision(
        id=f"D{len(decisions) + 1}",
        timestamp=datetime.now(timezone.utc).isoformat(),
        description=description,
        reasoning=reasoning,
        status=DecisionStatus.active,
    )
    decisions.append(decision)
    save_decisions(decisions)
    return decision


def list_decisions(limit: int = 10) -> List[Decision]:
    """Return the most recent active decisions."""
    decisions = load_decisions()
    active = [d for d in decisions if d.status == DecisionStatus.active]
    return active[-limit:]
