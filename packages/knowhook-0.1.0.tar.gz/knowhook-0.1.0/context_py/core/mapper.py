"""Dependency mapper — scans project files to build an import/export graph."""

from __future__ import annotations

import ast
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from context_py.models import DependencyMap, FileNode
from context_py.utils.paths import get_project_know_dir, get_project_root


def scan_python_file(path: Path) -> FileNode:
    """Parse a Python file using ast to extract imports, classes, and functions."""
    imports: List[str] = []
    exports: List[str] = []
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except (SyntaxError, ValueError):
        return FileNode(path=str(path), language="python")

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            imports.append(module)
        elif isinstance(node, ast.ClassDef):
            exports.append(f"class:{node.name}")
        elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            # Only top-level functions
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                exports.append(f"def:{node.name}")

    return FileNode(path=str(path), imports=imports, exports=exports, language="python")


def scan_file_generic(path: Path) -> FileNode:
    """Scan a non-Python file using regex for common import patterns."""
    imports: List[str] = []
    exports: List[str] = []
    suffix = path.suffix.lower()

    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        lang = _detect_language(suffix)
        return FileNode(path=str(path), language=lang)

    lang = _detect_language(suffix)

    if suffix in (".js", ".jsx", ".ts", ".tsx", ".mjs"):
        # ES6: import X from 'Y' / import 'Y'
        for m in re.finditer(r"""import\s+.*?from\s+['"]([^'"]+)['"]""", source):
            imports.append(m.group(1))
        # require('Y')
        for m in re.finditer(r"""require\s*\(\s*['"]([^'"]+)['"]""", source):
            imports.append(m.group(1))
        # exports
        for m in re.finditer(r"export\s+(?:default\s+)?(?:function|class|const|let|var)\s+(\w+)", source):
            exports.append(m.group(1))
    elif suffix in (".go",):
        for m in re.finditer(r'"([^"]+)"', source):
            if "/" in m.group(1):
                imports.append(m.group(1))
    elif suffix in (".rs",):
        for m in re.finditer(r"use\s+([\w:]+)", source):
            imports.append(m.group(1))

    return FileNode(path=str(path), imports=imports, exports=exports, language=lang)


def _detect_language(suffix: str) -> str:
    mapping = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".jsx": "javascript", ".tsx": "typescript", ".go": "go",
        ".rs": "rust", ".java": "java", ".rb": "ruby",
        ".md": "markdown", ".yaml": "yaml", ".yml": "yaml",
        ".json": "json", ".toml": "toml",
    }
    return mapping.get(suffix, "unknown")


def _get_tracked_files(project_root: Path) -> List[str]:
    """Get list of tracked files using git ls-files."""
    try:
        result = subprocess.run(
            ["git", "ls-files"],
            capture_output=True, text=True, check=True,
            cwd=str(project_root),
        )
        return [f for f in result.stdout.strip().split("\n") if f]
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []


def build_dependency_map(project_root: Path | None = None) -> DependencyMap:
    """Build a full dependency map of the project."""
    if project_root is None:
        project_root = get_project_root()

    files_dict = {}
    tracked = _get_tracked_files(project_root)

    for rel_path in tracked:
        full_path = project_root / rel_path
        if not full_path.is_file():
            continue

        if full_path.suffix == ".py":
            node = scan_python_file(full_path)
        else:
            node = scan_file_generic(full_path)

        node.path = rel_path
        files_dict[rel_path] = node

    return DependencyMap(
        generated_at=datetime.now(timezone.utc).isoformat(),
        files=files_dict,
    )


def _map_path() -> Path:
    return get_project_know_dir() / "map.json"


def save_map(dep_map: DependencyMap) -> None:
    """Save dependency map to .know/map.json."""
    path = _map_path()
    data = dep_map.model_dump()
    path.write_text(json.dumps(data, indent=2))


def load_map() -> DependencyMap | None:
    """Load dependency map from .know/map.json."""
    path = _map_path()
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    return DependencyMap(**data)


def summarize_map(dep_map: DependencyMap, focus_files: List[str] | None = None) -> List[str]:
    """Produce human-readable dependency edges for the given focus files."""
    edges: List[str] = []
    targets = focus_files or list(dep_map.files.keys())

    for file_path in targets:
        node = dep_map.files.get(file_path)
        if node is None:
            continue
        for imp in node.imports:
            # Try to resolve import to a project file
            for other_path, other_node in dep_map.files.items():
                if other_path == file_path:
                    continue
                # Check if any export matches the import
                module_stem = Path(other_path).stem
                if imp.endswith(module_stem) or imp == module_stem:
                    export_names = [e.split(":")[-1] for e in other_node.exports[:3]]
                    label = ", ".join(export_names) if export_names else imp
                    edge = f"{file_path} -> {other_path} (imports {label})"
                    if edge not in edges:
                        edges.append(edge)
                    break

    return edges
