"""Session file tracker — records which files are touched during a coding session."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from context_py.models import SessionFile, SessionTracker
from context_py.utils.paths import get_project_know_dir


def _session_path() -> Path:
    return get_project_know_dir() / "session.json"


def load_session() -> SessionTracker:
    """Load current session from .know/session.json, or create a new one."""
    path = _session_path()
    if path.exists():
        data = json.loads(path.read_text())
        return SessionTracker(**data)
    return SessionTracker(
        session_id=uuid.uuid4().hex[:12],
        started_at=datetime.now(timezone.utc).isoformat(),
    )


def save_session(tracker: SessionTracker) -> None:
    """Save session tracker to .know/session.json (atomic write)."""
    path = _session_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(tracker.model_dump(), indent=2))
    tmp.replace(path)


def record_file_touch(file_path: str, action: str, session_id: str | None = None) -> None:
    """Record a file touch event in the current session."""
    tracker = load_session()
    if session_id and tracker.session_id != session_id:
        # New session started, reset
        tracker = SessionTracker(
            session_id=session_id,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
    entry = SessionFile(
        path=file_path,
        action=action,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )
    tracker.files_touched.append(entry)
    save_session(tracker)


def clear_session() -> None:
    """Reset the session tracker."""
    tracker = SessionTracker(
        session_id=uuid.uuid4().hex[:12],
        started_at=datetime.now(timezone.utc).isoformat(),
    )
    save_session(tracker)
