"""Snapshot engine — creates and restores context snapshots for compaction recovery."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from context_py.config import ContextConfig
from context_py.core.storage import find_context_file, load_config
from context_py.models import Decision, DependencyMap, SessionFile, SessionTracker, Snapshot
from context_py.utils.paths import get_snapshots_dir


def create_snapshot(
    config: ContextConfig,
    decisions: List[Decision],
    session: SessionTracker,
    dep_map: Optional[DependencyMap] = None,
    trigger: str = "manual",
) -> Snapshot:
    """Assemble a snapshot from all available context data."""
    # Build dependency edges summary
    edges: List[str] = []
    if dep_map:
        focus = [f.path for f in session.files_touched]
        if focus:
            from context_py.core.mapper import summarize_map
            edges = summarize_map(dep_map, focus)

    return Snapshot(
        version="1",
        timestamp=datetime.now(timezone.utc).isoformat(),
        trigger=trigger,
        project_name=config.project_name,
        current_task=config.current_task.model_dump(mode="json"),
        goals=list(config.goals),
        rules=list(config.rules),
        decisions=list(decisions),
        files_touched=list(session.files_touched),
        dependency_edges=edges,
    )


def save_snapshot(snapshot: Snapshot) -> Path:
    """Save a snapshot to .know/snapshots/{timestamp}.json."""
    snapshots_dir = get_snapshots_dir()
    # Use a filename-safe timestamp
    ts = snapshot.timestamp.replace(":", "").replace("-", "").replace("+", "p")[:20]
    path = snapshots_dir / f"{ts}.json"
    path.write_text(json.dumps(snapshot.model_dump(), indent=2))
    return path


def load_latest_snapshot() -> Optional[Snapshot]:
    """Load the most recent snapshot from .know/snapshots/."""
    snapshots_dir = get_snapshots_dir()
    files = sorted(snapshots_dir.glob("*.json"))
    if not files:
        return None
    data = json.loads(files[-1].read_text())
    return Snapshot(**data)


def format_snapshot_for_injection(snapshot: Snapshot) -> str:
    """Format a snapshot as structured text (~500 tokens) for post-compaction injection."""
    lines = [
        "=== KNOW: Post-Compaction Context Recovery ===",
        f"PROJECT: {snapshot.project_name}",
    ]

    # Task
    if snapshot.current_task:
        task = snapshot.current_task
        lines.append(
            f"CURRENT TASK [{task.get('id', '?')}]: "
            f"{task.get('description', 'unknown')} "
            f"(status: {task.get('status', 'unknown')})"
        )

    # Goals
    if snapshot.goals:
        lines.append(f"GOALS: {', '.join(snapshot.goals)}")

    # Decisions
    if snapshot.decisions:
        lines.append("")
        lines.append("DECISIONS:")
        for d in snapshot.decisions:
            reason = f" — {d.reasoning}" if d.reasoning else ""
            lines.append(f"- [{d.id}] {d.description}{reason}")

    # Rules
    if snapshot.rules:
        lines.append("")
        lines.append("RULES:")
        for r in snapshot.rules:
            lines.append(f"- {r}")

    # Files touched
    if snapshot.files_touched:
        lines.append("")
        lines.append("FILES TOUCHED THIS SESSION:")
        seen = set()
        for f in snapshot.files_touched:
            key = f"{f.path} ({f.action})"
            if key not in seen:
                lines.append(f"- {key}")
                seen.add(key)

    # Dependencies
    if snapshot.dependency_edges:
        lines.append("")
        lines.append("DEPENDENCIES:")
        for edge in snapshot.dependency_edges:
            lines.append(f"- {edge}")

    # Work status
    if snapshot.completed_work:
        lines.append("")
        lines.append("COMPLETED: " + ", ".join(snapshot.completed_work))
    if snapshot.pending_work:
        lines.append("PENDING: " + ", ".join(snapshot.pending_work))
    if snapshot.rejected_approaches:
        lines.append("REJECTED: " + ", ".join(snapshot.rejected_approaches))

    lines.append("=== END KNOW CONTEXT ===")
    return "\n".join(lines)


def create_and_save_snapshot(trigger: str = "manual") -> tuple[Snapshot, Path]:
    """Convenience: load all context, create snapshot, save it."""
    from context_py.core.decisions import load_decisions
    from context_py.core.mapper import load_map
    from context_py.core.session import load_session

    ctx_path = find_context_file()
    config = load_config(ctx_path) if ctx_path else ContextConfig()
    decisions = load_decisions()
    session = load_session()
    dep_map = load_map()

    snapshot = create_snapshot(config, decisions, session, dep_map, trigger=trigger)
    path = save_snapshot(snapshot)
    return snapshot, path
