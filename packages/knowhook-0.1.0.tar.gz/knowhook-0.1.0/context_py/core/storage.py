from pathlib import Path

import yaml

from context_py.config import ContextConfig

CONTEXT_FILENAME = ".context.yaml"


def find_context_file(start: Path | str = ".") -> Path | None:
    """Walk up directories to find .context.yaml."""
    current = Path(start).resolve()
    while True:
        candidate = current / CONTEXT_FILENAME
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            return None
        current = parent


def load_config(path: Path | str) -> ContextConfig:
    """Load a ContextConfig from a YAML file."""
    path = Path(path)
    with open(path) as f:
        data = yaml.safe_load(f) or {}
    return ContextConfig(**data)


def save_config(config: ContextConfig, path: Path | str) -> Path:
    """Save a ContextConfig to a YAML file."""
    path = Path(path)
    data = config.model_dump(mode="json")
    with open(path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    return path


def create_default_config(directory: Path | str = ".") -> Path:
    """Create a default .context.yaml in the given directory.

    Raises FileExistsError if one already exists.
    """
    directory = Path(directory).resolve()
    target = directory / CONTEXT_FILENAME
    if target.exists():
        raise FileExistsError(f"{CONTEXT_FILENAME} already exists in {directory}")
    config = ContextConfig()
    return save_config(config, target)
