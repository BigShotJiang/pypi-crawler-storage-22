"""Claude Code hook scripts for the compaction-resistant context layer."""
