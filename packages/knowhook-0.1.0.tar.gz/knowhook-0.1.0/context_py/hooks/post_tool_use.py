"""PostToolUse hook — tracks file edits/writes during a session.

Usage: python3 -m context_py.hooks.post_tool_use
Reads JSON from stdin, exits 0 on success.
"""

from __future__ import annotations

import json
import os
import sys


def main() -> None:
    try:
        payload = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        sys.exit(0)

    cwd = payload.get("cwd")
    if cwd:
        os.chdir(cwd)

    tool_name = payload.get("tool_name", "")
    tool_input = payload.get("tool_input", {})

    # Extract file path from Edit or Write tool input
    file_path = tool_input.get("file_path", "")
    if not file_path:
        sys.exit(0)

    action = tool_name.lower()  # "edit" or "write"

    from context_py.core.session import record_file_touch

    record_file_touch(file_path, action)
    sys.exit(0)


if __name__ == "__main__":
    main()
