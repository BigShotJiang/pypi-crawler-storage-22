"""PreCompact hook — creates a context snapshot before Claude Code compacts the conversation.

Usage: python3 -m context_py.hooks.pre_compact
Reads JSON from stdin, exits 0 on success.
"""

from __future__ import annotations

import json
import os
import sys


def main() -> None:
    try:
        payload = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        payload = {}

    # Change to project directory if provided
    cwd = payload.get("cwd")
    if cwd:
        os.chdir(cwd)

    from context_py.core.snapshot import create_and_save_snapshot

    snapshot, path = create_and_save_snapshot(trigger="pre_compact")
    # Hook must exit 0 silently — output goes nowhere useful
    sys.exit(0)


if __name__ == "__main__":
    main()
