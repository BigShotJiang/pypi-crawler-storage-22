"""SessionStart hook — restores context after compaction.

Usage: python3 -m context_py.hooks.session_start
Reads JSON from stdin, prints context briefing to stdout.
"""

from __future__ import annotations

import json
import os
import sys


def main() -> None:
    try:
        payload = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        payload = {}

    # Only activate on compact events
    source = payload.get("source", "")
    if source != "compact":
        sys.exit(0)

    cwd = payload.get("cwd")
    if cwd:
        os.chdir(cwd)

    from context_py.core.snapshot import format_snapshot_for_injection, load_latest_snapshot

    snapshot = load_latest_snapshot()
    if snapshot is None:
        sys.exit(0)

    briefing = format_snapshot_for_injection(snapshot)
    print(briefing)
    sys.exit(0)


if __name__ == "__main__":
    main()
