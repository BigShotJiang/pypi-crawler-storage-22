from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel

from context_py.config import TaskStatus
from context_py.core.storage import create_default_config, find_context_file, load_config, save_config

app = typer.Typer(name="know", help="Compaction-resistant context layer for AI coding agents.", invoke_without_command=True)

claude_app = typer.Typer(help="Manage Claude Code hooks.")
app.add_typer(claude_app, name="claude")

console = Console()


@app.callback()
def main_callback(ctx: typer.Context) -> None:
    """Compaction-resistant context layer for AI coding agents. Run without arguments to open the interactive TUI."""
    if ctx.invoked_subcommand is None:
        from context_py.tui.repl import run_repl
        run_repl()
        raise typer.Exit()


@app.command()
def init(
    directory: str = typer.Argument(".", help="Directory to initialize"),
) -> None:
    """Create a default .context.yaml in the given directory."""
    try:
        path = create_default_config(directory)
        console.print(Panel(f"Created {path}", title="init", style="green"))
    except FileExistsError as e:
        console.print(Panel(str(e), title="Already exists", style="yellow"))
        raise typer.Exit(code=1)


@app.command()
def update(
    task: Optional[str] = typer.Option(None, "--task", help="Set current task description"),
    task_id: Optional[str] = typer.Option(None, "--task-id", help="Set current task ID"),
    task_status: Optional[TaskStatus] = typer.Option(None, "--task-status", help="Set task status"),
    add_rule: Optional[str] = typer.Option(None, "--add-rule", help="Add a rule"),
    add_goal: Optional[str] = typer.Option(None, "--add-goal", help="Add a goal"),
) -> None:
    """Update the .context.yaml configuration."""
    ctx_path = find_context_file()
    if ctx_path is None:
        console.print(Panel("No .context.yaml found. Run [bold]know init[/bold] first.", title="Error", style="red"))
        raise typer.Exit(code=1)

    config = load_config(ctx_path)
    changes: list[str] = []

    if task is not None:
        config.current_task.description = task
        changes.append(f"Task description → {task}")
    if task_id is not None:
        config.current_task.id = task_id
        changes.append(f"Task ID → {task_id}")
    if task_status is not None:
        config.current_task.status = task_status
        changes.append(f"Task status → {task_status.value}")
    if add_rule is not None:
        config.rules.append(add_rule)
        changes.append(f"Added rule: {add_rule}")
    if add_goal is not None:
        config.goals.append(add_goal)
        changes.append(f"Added goal: {add_goal}")

    if not changes:
        console.print("[dim]No updates specified. Use --help to see options.[/dim]")
        return

    save_config(config, ctx_path)
    summary = "\n".join(f"  • {c}" for c in changes)
    console.print(Panel(summary, title="Updated .context.yaml", style="green"))


# ── know snapshot ────────────────────────────────────────────────────────

@app.command()
def snapshot() -> None:
    """Create a context snapshot manually."""
    from context_py.core.snapshot import create_and_save_snapshot

    snap, path = create_and_save_snapshot(trigger="manual")
    console.print(Panel(
        f"Snapshot saved to {path}\n"
        f"  Project: {snap.project_name}\n"
        f"  Files touched: {len(snap.files_touched)}\n"
        f"  Decisions: {len(snap.decisions)}\n"
        f"  Dependencies: {len(snap.dependency_edges)}",
        title="snapshot",
        style="green",
    ))


# ── know restore ─────────────────────────────────────────────────────────

@app.command()
def restore() -> None:
    """Print the latest snapshot as plain text (for post-compaction recovery)."""
    from context_py.core.snapshot import format_snapshot_for_injection, load_latest_snapshot

    snap = load_latest_snapshot()
    if snap is None:
        console.print("[dim]No snapshots found. Run [bold]know snapshot[/bold] first.[/dim]")
        raise typer.Exit(code=1)

    print(format_snapshot_for_injection(snap))


# ── know decide ──────────────────────────────────────────────────────────

@app.command()
def decide(
    description: str = typer.Argument(..., help="Description of the architectural decision"),
    reasoning: str = typer.Option("", "--reason", "-r", help="Reasoning behind the decision"),
) -> None:
    """Log an architectural decision."""
    from context_py.core.decisions import add_decision

    decision = add_decision(description, reasoning)
    reason_text = f"\n  Reasoning: {decision.reasoning}" if decision.reasoning else ""
    console.print(Panel(
        f"[{decision.id}] {decision.description}{reason_text}",
        title="Decision logged",
        style="green",
    ))


# ── know map ─────────────────────────────────────────────────────────────

@app.command(name="map")
def map_cmd() -> None:
    """Generate or update the project dependency map."""
    from context_py.core.mapper import build_dependency_map, save_map

    with console.status("[bold]Scanning project files...[/bold]"):
        dep_map = build_dependency_map()
        save_map(dep_map)

    console.print(Panel(
        f"Files scanned: {len(dep_map.files)}\n"
        f"Generated at: {dep_map.generated_at}",
        title="Dependency map",
        style="green",
    ))


# ── know sync ────────────────────────────────────────────────────────────

@app.command()
def sync() -> None:
    """Regenerate .claude/rules/know-context.md from current context."""
    from context_py.core.rules import sync_rules

    path = sync_rules()
    console.print(Panel(f"Rules file written to {path}", title="sync", style="green"))


# ── know claude install/uninstall ────────────────────────────────────────

@claude_app.command("install")
def claude_install() -> None:
    """Install Claude Code hooks for compaction-resistant context."""
    from context_py.utils.claude_hooks import install_hooks
    from context_py.utils.paths import get_project_root

    root = get_project_root()
    path = install_hooks(root)
    console.print(Panel(f"Claude Code hooks installed at {path}", title="claude install", style="green"))


@claude_app.command("uninstall")
def claude_uninstall() -> None:
    """Remove Claude Code hooks."""
    from context_py.utils.claude_hooks import uninstall_hooks
    from context_py.utils.paths import get_project_root

    root = get_project_root()
    removed = uninstall_hooks(root)
    if removed:
        console.print(Panel("Claude Code hooks removed.", title="claude uninstall", style="green"))
    else:
        console.print(Panel("No know hooks found.", title="claude uninstall", style="yellow"))


def app_entry() -> None:
    """Zero-arg entry point for console_scripts."""
    app()
