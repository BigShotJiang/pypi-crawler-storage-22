"""Data models for the compaction-resistant context layer."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class DecisionStatus(str, Enum):
    active = "active"
    superseded = "superseded"
    rejected = "rejected"


class Decision(BaseModel):
    id: str
    timestamp: str
    description: str
    reasoning: str = ""
    status: DecisionStatus = DecisionStatus.active


class FileNode(BaseModel):
    path: str
    imports: List[str] = []
    exports: List[str] = []
    language: str = "unknown"


class DependencyMap(BaseModel):
    generated_at: str
    files: Dict[str, FileNode] = {}


class SessionFile(BaseModel):
    path: str
    action: str  # "edit", "write", "read"
    timestamp: str


class SessionTracker(BaseModel):
    session_id: str
    started_at: str
    files_touched: List[SessionFile] = []


class Snapshot(BaseModel):
    version: str = "1"
    timestamp: str = ""
    trigger: str = ""  # "manual", "pre_compact", "auto"
    project_name: str = ""
    current_task: Optional[Dict] = None
    goals: List[str] = []
    rules: List[str] = []
    decisions: List[Decision] = []
    files_touched: List[SessionFile] = []
    dependency_edges: List[str] = []
    completed_work: List[str] = []
    pending_work: List[str] = []
    rejected_approaches: List[str] = []
