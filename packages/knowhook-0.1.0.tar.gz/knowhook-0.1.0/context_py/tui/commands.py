"""Slash command registry and handlers for the TUI."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from prompt_toolkit import prompt as pt_prompt
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from context_py.config import ContextConfig, TaskStatus
from context_py.core.storage import (
    create_default_config,
    find_context_file,
    load_config,
    save_config,
)


@dataclass
class SlashCommand:
    name: str
    description: str
    handler: Callable[[Console, str], None]


# Registry populated by @command decorator
COMMANDS: dict[str, SlashCommand] = {}


def command(name: str, description: str):
    """Decorator to register a slash command."""

    def decorator(fn: Callable[[Console, str], None]):
        COMMANDS[name] = SlashCommand(name=name, description=description, handler=fn)
        return fn

    return decorator


# ── /init ────────────────────────────────────────────────────────────────

@command("init", "Create a .context.yaml in current directory")
def cmd_init(console: Console, args: str) -> None:
    directory = args.strip() or "."
    try:
        path = create_default_config(directory)
        console.print(Panel(f"Created {path}", title="init", style="green"))
    except FileExistsError as e:
        console.print(Panel(str(e), title="Already exists", style="yellow"))


# ── /update ──────────────────────────────────────────────────────────────

@command("update", "Interactively update task, goals, or rules")
def cmd_update(console: Console, args: str) -> None:
    ctx_path = find_context_file()
    if ctx_path is None:
        console.print(Panel("No .context.yaml found. Run [bold]/init[/bold] first.", title="Error", style="red"))
        return

    config = load_config(ctx_path)
    changes: list[str] = []

    console.print("[bold]Leave blank to keep current value.[/bold]\n")

    # Task description
    current_task = config.current_task.description
    new_task = pt_prompt(f"Task description [{current_task}]: ").strip()
    if new_task:
        config.current_task.description = new_task
        changes.append(f"Task description -> {new_task}")

    # Task ID
    current_id = config.current_task.id
    new_id = pt_prompt(f"Task ID [{current_id}]: ").strip()
    if new_id:
        config.current_task.id = new_id
        changes.append(f"Task ID -> {new_id}")

    # Task status
    current_status = config.current_task.status.value
    new_status = pt_prompt(f"Task status (active/skipped/completed) [{current_status}]: ").strip()
    if new_status and new_status in ("active", "skipped", "completed"):
        config.current_task.status = TaskStatus(new_status)
        changes.append(f"Task status -> {new_status}")

    # Add goal
    new_goal = pt_prompt("Add a goal (blank to skip): ").strip()
    if new_goal:
        config.goals.append(new_goal)
        changes.append(f"Added goal: {new_goal}")

    # Add rule
    new_rule = pt_prompt("Add a rule (blank to skip): ").strip()
    if new_rule:
        config.rules.append(new_rule)
        changes.append(f"Added rule: {new_rule}")

    if not changes:
        console.print("[dim]No changes made.[/dim]")
        return

    save_config(config, ctx_path)
    summary = "\n".join(f"  - {c}" for c in changes)
    console.print(Panel(summary, title="Updated .context.yaml", style="green"))


# ── /snapshot ────────────────────────────────────────────────────────────

@command("snapshot", "Create a context snapshot")
def cmd_snapshot(console: Console, args: str) -> None:
    from context_py.core.snapshot import create_and_save_snapshot

    snap, path = create_and_save_snapshot(trigger="manual")
    console.print(Panel(
        f"Snapshot saved to {path}\n"
        f"  Project: {snap.project_name}\n"
        f"  Files touched: {len(snap.files_touched)}\n"
        f"  Decisions: {len(snap.decisions)}\n"
        f"  Dependencies: {len(snap.dependency_edges)}",
        title="Snapshot",
        style="green",
    ))


# ── /restore ─────────────────────────────────────────────────────────────

@command("restore", "Show latest snapshot")
def cmd_restore(console: Console, args: str) -> None:
    from context_py.core.snapshot import format_snapshot_for_injection, load_latest_snapshot

    snap = load_latest_snapshot()
    if snap is None:
        console.print(Panel("No snapshots found. Run [bold]/snapshot[/bold] first.", title="Restore", style="yellow"))
        return

    briefing = format_snapshot_for_injection(snap)
    console.print(Panel(briefing, title="Latest Snapshot", style="cyan"))


# ── /decide ──────────────────────────────────────────────────────────────

@command("decide", "Log an architectural decision")
def cmd_decide(console: Console, args: str) -> None:
    from context_py.core.decisions import add_decision

    description = args.strip()
    if not description:
        description = pt_prompt("Decision: ").strip()
    if not description:
        console.print("[dim]No decision entered.[/dim]")
        return

    reasoning = pt_prompt("Reasoning (optional): ").strip()
    decision = add_decision(description, reasoning)
    reason_text = f"\n  Reasoning: {decision.reasoning}" if decision.reasoning else ""
    console.print(Panel(
        f"[{decision.id}] {decision.description}{reason_text}",
        title="Decision logged",
        style="green",
    ))


# ── /map ─────────────────────────────────────────────────────────────────

@command("map", "Generate project dependency map")
def cmd_map(console: Console, args: str) -> None:
    from context_py.core.mapper import build_dependency_map, save_map

    with console.status("[bold]Scanning project files...[/bold]"):
        dep_map = build_dependency_map()
        save_map(dep_map)

    console.print(Panel(
        f"Files scanned: {len(dep_map.files)}\n"
        f"Generated at: {dep_map.generated_at}",
        title="Dependency Map",
        style="green",
    ))


# ── /sync ────────────────────────────────────────────────────────────────

@command("sync", "Regenerate .claude/rules/know-context.md")
def cmd_sync(console: Console, args: str) -> None:
    from context_py.core.rules import sync_rules

    path = sync_rules()
    console.print(Panel(f"Rules file written to {path}", title="Sync", style="green"))


# ── /help ────────────────────────────────────────────────────────────────

@command("help", "Show all available commands")
def cmd_help(console: Console, args: str) -> None:
    table = Table(title="Commands", show_header=True, header_style="bold")
    table.add_column("Command", style="cyan", no_wrap=True)
    table.add_column("Description")

    for name, cmd in COMMANDS.items():
        table.add_row(f"/{name}", cmd.description)

    console.print(table)


# ── /quit ────────────────────────────────────────────────────────────────

@command("quit", "Exit the TUI")
def cmd_quit(console: Console, args: str) -> None:
    raise SystemExit(0)
