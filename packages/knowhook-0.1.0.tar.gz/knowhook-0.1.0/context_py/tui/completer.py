"""prompt_toolkit autocompleter for slash commands."""

from __future__ import annotations

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


class SlashCommandCompleter(Completer):
    """Yields completions when input starts with '/'."""

    def __init__(self, commands: dict) -> None:
        self._commands = commands  # name -> SlashCommand

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor.lstrip()
        if not text.startswith("/"):
            return

        # Extract the command token being typed
        word = text.split()[0] if text.split() else text

        for name, cmd in self._commands.items():
            full = f"/{name}"
            if full.startswith(word):
                yield Completion(
                    full,
                    start_position=-len(word),
                    display=full,
                    display_meta=cmd.description,
                )
