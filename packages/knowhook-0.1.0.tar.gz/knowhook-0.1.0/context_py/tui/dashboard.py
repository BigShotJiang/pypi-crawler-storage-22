"""Rich dashboard rendering for the TUI."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel

from context_py.core.storage import find_context_file, load_config


def render_dashboard(console: Console) -> None:
    """Render the project context dashboard."""
    ctx_path = find_context_file()
    if ctx_path is None:
        console.print(Panel(
            "[dim]No .context.yaml found. Run [bold]/init[/bold] to create one.[/dim]",
            title="Context",
            style="yellow",
        ))
        return

    config = load_config(ctx_path)
    lines = [
        f"[bold]Project:[/bold] {config.project_name}",
        f"[bold]Task [{config.current_task.id}]:[/bold] {config.current_task.description}",
        f"[bold]Status:[/bold] {config.current_task.status.value}",
        "",
        "[bold]Goals:[/bold]",
    ]
    for g in config.goals:
        lines.append(f"  - {g}")

    if config.rules:
        lines.append("")
        lines.append("[bold]Rules:[/bold]")
        for r in config.rules:
            lines.append(f"  - {r}")

    if config.tech_stack:
        lines.append("")
        lines.append(f"[bold]Tech Stack:[/bold] {', '.join(config.tech_stack)}")

    console.print(Panel(
        "\n".join(lines),
        title="Context",
        subtitle=str(ctx_path),
        style="cyan",
    ))
