"""Main REPL loop for the interactive TUI."""

from __future__ import annotations

from pathlib import Path

from prompt_toolkit import PromptSession
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.history import FileHistory
from rich.console import Console

from context_py.tui.commands import COMMANDS
from context_py.tui.completer import SlashCommandCompleter
from context_py.tui.dashboard import render_dashboard

CONFIG_DIR = Path.home() / ".know"


def dispatch(console: Console, line: str) -> None:
    """Parse a '/command args' line and call the appropriate handler."""
    stripped = line.strip()
    if not stripped:
        return

    if not stripped.startswith("/"):
        console.print("[dim]Type [bold]/help[/bold] to see available commands.[/dim]")
        return

    parts = stripped.split(None, 1)
    cmd_name = parts[0][1:]  # strip leading '/'
    args = parts[1] if len(parts) > 1 else ""

    if cmd_name not in COMMANDS:
        console.print(f"[red]Unknown command:[/red] /{cmd_name}. Type [bold]/help[/bold] for a list.")
        return

    COMMANDS[cmd_name].handler(console, args)


def run_repl() -> None:
    """Launch the interactive TUI REPL."""
    console = Console()

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    console.print()
    console.print("[bold]know[/bold] — compaction-resistant context layer", style="cyan")
    console.print("[dim]Type /help for commands, Ctrl+D to exit[/dim]")
    console.print()
    render_dashboard(console)
    console.print()

    history_file = CONFIG_DIR / "history"
    session: PromptSession = PromptSession(
        history=FileHistory(str(history_file)),
        auto_suggest=AutoSuggestFromHistory(),
        completer=SlashCommandCompleter(COMMANDS),
    )

    while True:
        try:
            line = session.prompt("know> ")
            dispatch(console, line)
        except KeyboardInterrupt:
            continue
        except EOFError:
            console.print("[dim]Goodbye![/dim]")
            break
        except SystemExit:
            console.print("[dim]Goodbye![/dim]")
            break
