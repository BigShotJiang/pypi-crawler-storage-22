"""Claude Code hook installer — manages hooks and usage rules."""

from __future__ import annotations

import json
from pathlib import Path

# Marker to identify know-managed hooks
_KNOW_MARKER = "context_py.hooks."

_USAGE_RULES_FILENAME = "know-usage.md"

_USAGE_RULES = """\
# `know` — Compaction-Resistant Context Layer

You have `know` installed in this project. It preserves your context across compaction events
so you don't lose track of decisions, file relationships, or session state.

## Commands you can run via Bash

| Command | When to use it |
|---------|---------------|
| `know decide "description" -r "reasoning"` | When making an architectural choice — log it so it survives compaction |
| `know map` | After creating/renaming files — rebuilds the dependency graph in `.know/map.json` |
| `know snapshot` | Before a risky change or long pause — saves full context to `.know/snapshots/` |
| `know restore` | To see what context would be injected after compaction |
| `know sync` | After updating `.context.yaml` or logging decisions — regenerates `.claude/rules/know-context.md` |
| `know update --task "..." --add-rule "..." --add-goal "..."` | To update the project plan in `.context.yaml` |

## When to use each command

- **Starting a new task?** Run `know update --task "new task" --task-id 42` then `know sync`
- **Made an architectural decision?** Run `know decide "what you decided" -r "why"`
- **Created or restructured files?** Run `know map` to update the dependency graph
- **About to do something complex?** Run `know snapshot` to save a recovery point
- **User asks you to log a decision?** Run `know decide`

## What happens automatically (via hooks)

- **Every Edit/Write you make** is tracked in `.know/session.json` (PostToolUse hook)
- **Before compaction** a full snapshot is saved automatically (PreCompact hook)
- **After compaction** the snapshot is injected back into your context (SessionStart hook)

## Project data files

- `.context.yaml` — project plan (task, goals, rules)
- `.know/decisions.json` — architectural decision log
- `.know/session.json` — files touched this session
- `.know/map.json` — dependency graph
- `.know/snapshots/` — timestamped context snapshots
- `.claude/rules/know-context.md` — auto-generated project context (always loaded)
"""

HOOK_CONFIG = {
    "PreCompact": [
        {
            "matcher": "",
            "hooks": [
                {
                    "type": "command",
                    "command": "python3 -m context_py.hooks.pre_compact",
                    "timeout": 30,
                }
            ],
        }
    ],
    "SessionStart": [
        {
            "matcher": "compact",
            "hooks": [
                {
                    "type": "command",
                    "command": "python3 -m context_py.hooks.session_start",
                    "timeout": 10,
                }
            ],
        }
    ],
    "PostToolUse": [
        {
            "matcher": "Edit|Write",
            "hooks": [
                {
                    "type": "command",
                    "command": "python3 -m context_py.hooks.post_tool_use",
                    "timeout": 5,
                }
            ],
        }
    ],
}


def _settings_path(project_root: Path) -> Path:
    return project_root / ".claude" / "settings.local.json"


def _load_settings(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text())
    return {}


def _save_settings(settings: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2) + "\n")


def _is_know_hook(entry: dict) -> bool:
    """Check if a hook entry belongs to know."""
    for hook in entry.get("hooks", []):
        if _KNOW_MARKER in hook.get("command", ""):
            return True
    return False


def _write_usage_rules(project_root: Path) -> Path:
    """Write the know usage guide to .claude/rules/know-usage.md."""
    rules_dir = project_root / ".claude" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    path = rules_dir / _USAGE_RULES_FILENAME
    path.write_text(_USAGE_RULES)
    return path


def _remove_usage_rules(project_root: Path) -> bool:
    """Remove .claude/rules/know-usage.md if it exists."""
    path = project_root / ".claude" / "rules" / _USAGE_RULES_FILENAME
    if path.exists():
        path.unlink()
        return True
    return False


def install_hooks(project_root: Path) -> Path:
    """Install know hooks into .claude/settings.local.json and write usage rules."""
    path = _settings_path(project_root)
    settings = _load_settings(path)
    existing_hooks = settings.get("hooks", {})

    for event_name, know_entries in HOOK_CONFIG.items():
        current = existing_hooks.get(event_name, [])
        # Remove any existing know hooks for this event
        current = [e for e in current if not _is_know_hook(e)]
        # Add know hooks
        current.extend(know_entries)
        existing_hooks[event_name] = current

    settings["hooks"] = existing_hooks
    _save_settings(settings, path)

    # Write usage rules so Claude Code knows about know
    _write_usage_rules(project_root)

    return path


def uninstall_hooks(project_root: Path) -> bool:
    """Remove know hooks and usage rules. Returns True if any were removed."""
    path = _settings_path(project_root)
    removed = False

    if path.exists():
        settings = _load_settings(path)
        existing_hooks = settings.get("hooks", {})

        for event_name in list(existing_hooks.keys()):
            before = len(existing_hooks[event_name])
            existing_hooks[event_name] = [
                e for e in existing_hooks[event_name] if not _is_know_hook(e)
            ]
            if len(existing_hooks[event_name]) < before:
                removed = True
            # Clean up empty event lists
            if not existing_hooks[event_name]:
                del existing_hooks[event_name]

        if not existing_hooks and "hooks" in settings:
            del settings["hooks"]

        _save_settings(settings, path)

    # Remove usage rules file
    if _remove_usage_rules(project_root):
        removed = True

    return removed
