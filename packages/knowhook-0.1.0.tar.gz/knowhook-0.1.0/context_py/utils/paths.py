"""Project-local .know/ directory resolution."""

from __future__ import annotations

from pathlib import Path

from context_py.core.storage import find_context_file


def get_project_root() -> Path:
    """Find the project root: directory containing .context.yaml, or git root, or cwd."""
    ctx_path = find_context_file()
    if ctx_path is not None:
        return ctx_path.parent

    # Try git root
    import subprocess
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass

    return Path.cwd()


def get_project_know_dir() -> Path:
    """Get the .know/ directory for the current project, creating it if needed."""
    root = get_project_root()
    know_dir = root / ".know"
    know_dir.mkdir(exist_ok=True)
    return know_dir


def get_snapshots_dir() -> Path:
    """Get the .know/snapshots/ directory, creating it if needed."""
    snapshots = get_project_know_dir() / "snapshots"
    snapshots.mkdir(exist_ok=True)
    return snapshots
