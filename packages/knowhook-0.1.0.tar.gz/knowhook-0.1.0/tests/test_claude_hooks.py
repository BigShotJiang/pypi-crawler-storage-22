"""Tests for context_py/utils/claude_hooks.py — hook installer and usage rules."""

import json
from pathlib import Path

import pytest

from context_py.utils.claude_hooks import (
    HOOK_CONFIG,
    install_hooks,
    uninstall_hooks,
    _is_know_hook,
    _USAGE_RULES_FILENAME,
)


class TestInstallHooks:
    def test_creates_settings_file(self, tmp_path: Path):
        path = install_hooks(tmp_path)
        assert path.exists()
        assert path == tmp_path / ".claude" / "settings.local.json"

    def test_writes_all_three_hooks(self, tmp_path: Path):
        install_hooks(tmp_path)
        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        hooks = settings["hooks"]
        assert "PreCompact" in hooks
        assert "SessionStart" in hooks
        assert "PostToolUse" in hooks

    def test_pre_compact_config(self, tmp_path: Path):
        install_hooks(tmp_path)
        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        pre_compact = settings["hooks"]["PreCompact"][0]
        assert pre_compact["matcher"] == ""
        assert pre_compact["hooks"][0]["command"] == "python3 -m context_py.hooks.pre_compact"
        assert pre_compact["hooks"][0]["timeout"] == 30

    def test_session_start_matcher(self, tmp_path: Path):
        install_hooks(tmp_path)
        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        session_start = settings["hooks"]["SessionStart"][0]
        assert session_start["matcher"] == "compact"

    def test_post_tool_use_matcher(self, tmp_path: Path):
        install_hooks(tmp_path)
        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        post_tool = settings["hooks"]["PostToolUse"][0]
        assert post_tool["matcher"] == "Edit|Write"

    def test_merges_with_existing_hooks(self, tmp_path: Path):
        """Existing non-know hooks should be preserved."""
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        existing = {
            "hooks": {
                "PostToolUse": [
                    {"matcher": "Bash", "hooks": [{"type": "command", "command": "echo hi"}]}
                ]
            }
        }
        (claude_dir / "settings.local.json").write_text(json.dumps(existing))

        install_hooks(tmp_path)
        settings = json.loads((claude_dir / "settings.local.json").read_text())

        # Should have both the existing Bash hook and the new know hook
        post_tool = settings["hooks"]["PostToolUse"]
        assert len(post_tool) == 2
        commands = [h["hooks"][0]["command"] for h in post_tool]
        assert "echo hi" in commands
        assert "python3 -m context_py.hooks.post_tool_use" in commands

    def test_idempotent_install(self, tmp_path: Path):
        """Installing twice should not duplicate know hooks."""
        install_hooks(tmp_path)
        install_hooks(tmp_path)
        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        # Each event should have exactly one know hook entry
        assert len(settings["hooks"]["PreCompact"]) == 1
        assert len(settings["hooks"]["SessionStart"]) == 1
        assert len(settings["hooks"]["PostToolUse"]) == 1

    def test_creates_usage_rules_file(self, tmp_path: Path):
        install_hooks(tmp_path)
        rules_path = tmp_path / ".claude" / "rules" / _USAGE_RULES_FILENAME
        assert rules_path.exists()
        content = rules_path.read_text()
        assert "know decide" in content
        assert "know map" in content
        assert "know snapshot" in content
        assert "know sync" in content

    def test_merges_with_existing_settings(self, tmp_path: Path):
        """Existing non-hook settings should be preserved."""
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        existing = {"permissions": {"allow": ["Bash"]}}
        (claude_dir / "settings.local.json").write_text(json.dumps(existing))

        install_hooks(tmp_path)
        settings = json.loads((claude_dir / "settings.local.json").read_text())
        assert settings["permissions"] == {"allow": ["Bash"]}
        assert "hooks" in settings


class TestUninstallHooks:
    def test_removes_know_hooks(self, tmp_path: Path):
        install_hooks(tmp_path)
        removed = uninstall_hooks(tmp_path)
        assert removed is True

        settings = json.loads((tmp_path / ".claude" / "settings.local.json").read_text())
        assert "hooks" not in settings or settings.get("hooks") == {}

    def test_preserves_non_know_hooks(self, tmp_path: Path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        existing = {
            "hooks": {
                "PostToolUse": [
                    {"matcher": "Bash", "hooks": [{"type": "command", "command": "echo hi"}]},
                ]
            }
        }
        (claude_dir / "settings.local.json").write_text(json.dumps(existing))

        install_hooks(tmp_path)
        uninstall_hooks(tmp_path)

        settings = json.loads((claude_dir / "settings.local.json").read_text())
        post_tool = settings["hooks"]["PostToolUse"]
        assert len(post_tool) == 1
        assert post_tool[0]["hooks"][0]["command"] == "echo hi"

    def test_returns_false_when_nothing_to_remove(self, tmp_path: Path):
        assert uninstall_hooks(tmp_path) is False

    def test_returns_false_when_no_know_hooks(self, tmp_path: Path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        settings = {"hooks": {"PostToolUse": [
            {"matcher": "Bash", "hooks": [{"type": "command", "command": "echo hi"}]}
        ]}}
        (claude_dir / "settings.local.json").write_text(json.dumps(settings))
        assert uninstall_hooks(tmp_path) is False

    def test_removes_usage_rules_file(self, tmp_path: Path):
        install_hooks(tmp_path)
        rules_path = tmp_path / ".claude" / "rules" / _USAGE_RULES_FILENAME
        assert rules_path.exists()

        uninstall_hooks(tmp_path)
        assert not rules_path.exists()


class TestIsKnowHook:
    def test_identifies_know_hook(self):
        entry = {"hooks": [{"type": "command", "command": "python3 -m context_py.hooks.pre_compact"}]}
        assert _is_know_hook(entry) is True

    def test_rejects_non_know_hook(self):
        entry = {"hooks": [{"type": "command", "command": "echo hello"}]}
        assert _is_know_hook(entry) is False

    def test_handles_empty_hooks(self):
        entry = {"hooks": []}
        assert _is_know_hook(entry) is False

    def test_handles_missing_hooks_key(self):
        entry = {}
        assert _is_know_hook(entry) is False
