"""Tests for context_py/main.py — CLI commands via Typer CliRunner."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml
from typer.testing import CliRunner

from context_py.main import app
from context_py.config import ContextConfig, CurrentTask, TaskStatus
from context_py.models import Decision, Snapshot, SessionTracker

runner = CliRunner()


class TestInit:
    def test_creates_context_file(self, tmp_path: Path):
        result = runner.invoke(app, ["init", str(tmp_path)])
        assert result.exit_code == 0
        assert "Created" in result.output
        assert (tmp_path / ".context.yaml").exists()

    def test_fails_if_already_exists(self, tmp_project: Path):
        result = runner.invoke(app, ["init", str(tmp_project)])
        assert result.exit_code == 1
        assert "Already exists" in result.output


class TestUpdate:
    def test_updates_task(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update", "--task", "New task"])
        assert result.exit_code == 0
        assert "New task" in result.output

    def test_updates_task_id(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update", "--task-id", "99"])
        assert result.exit_code == 0
        assert "99" in result.output

    def test_updates_task_status(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update", "--task-status", "completed"])
        assert result.exit_code == 0
        assert "completed" in result.output

    def test_adds_rule(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update", "--add-rule", "No globals"])
        assert result.exit_code == 0
        assert "No globals" in result.output

    def test_adds_goal(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update", "--add-goal", "Ship v1"])
        assert result.exit_code == 0
        assert "Ship v1" in result.output

    def test_no_updates_specified(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        result = runner.invoke(app, ["update"])
        assert result.exit_code == 0
        assert "No updates" in result.output

    def test_fails_without_context_file(self, tmp_path: Path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["update", "--task", "test"])
        assert result.exit_code == 1
        assert "No .context.yaml" in result.output


class TestDecide:
    def test_logs_decision(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        know_dir = tmp_project / ".know"
        know_dir.mkdir(exist_ok=True)

        with patch("context_py.core.decisions.get_project_know_dir", return_value=know_dir):
            result = runner.invoke(app, ["decide", "Use JWT for auth"])

        assert result.exit_code == 0
        assert "Decision logged" in result.output
        assert "Use JWT for auth" in result.output

    def test_with_reasoning(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        know_dir = tmp_project / ".know"
        know_dir.mkdir(exist_ok=True)

        with patch("context_py.core.decisions.get_project_know_dir", return_value=know_dir):
            result = runner.invoke(app, ["decide", "Use Redis", "--reason", "Fast TTL"])

        assert result.exit_code == 0
        assert "Fast TTL" in result.output


class TestSnapshot:
    def test_creates_snapshot(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        mock_snap = MagicMock()
        mock_snap.project_name = "test"
        mock_snap.files_touched = []
        mock_snap.decisions = []
        mock_snap.dependency_edges = []

        with patch("context_py.core.snapshot.create_and_save_snapshot", return_value=(mock_snap, Path("snap.json"))):
            result = runner.invoke(app, ["snapshot"])

        assert result.exit_code == 0
        assert "snapshot" in result.output.lower()


class TestRestore:
    def test_prints_snapshot(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        snap = Snapshot(project_name="test", timestamp="t")

        with patch("context_py.core.snapshot.load_latest_snapshot", return_value=snap), \
             patch("context_py.core.snapshot.format_snapshot_for_injection", return_value="=== KNOW ==="):
            result = runner.invoke(app, ["restore"])

        assert result.exit_code == 0
        assert "=== KNOW ===" in result.output

    def test_fails_when_no_snapshots(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)

        with patch("context_py.core.snapshot.load_latest_snapshot", return_value=None):
            result = runner.invoke(app, ["restore"])

        assert result.exit_code == 1
        assert "No snapshots" in result.output


class TestMap:
    def test_generates_map(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)
        mock_map = MagicMock()
        mock_map.files = {"a.py": MagicMock()}
        mock_map.generated_at = "2026-01-01"

        with patch("context_py.core.mapper.build_dependency_map", return_value=mock_map), \
             patch("context_py.core.mapper.save_map"):
            result = runner.invoke(app, ["map"])

        assert result.exit_code == 0
        assert "Dependency map" in result.output


class TestSync:
    def test_generates_rules(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)

        with patch("context_py.core.rules.sync_rules", return_value=Path(".claude/rules/know-context.md")):
            result = runner.invoke(app, ["sync"])

        assert result.exit_code == 0
        assert "sync" in result.output.lower()


class TestClaudeInstall:
    def test_installs_hooks(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)

        with patch("context_py.utils.claude_hooks.install_hooks", return_value=Path(".claude/settings.local.json")), \
             patch("context_py.utils.paths.get_project_root", return_value=tmp_project):
            result = runner.invoke(app, ["claude", "install"])

        assert result.exit_code == 0
        assert "claude install" in result.output.lower()


class TestClaudeUninstall:
    def test_uninstalls_hooks(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)

        with patch("context_py.utils.claude_hooks.uninstall_hooks", return_value=True), \
             patch("context_py.utils.paths.get_project_root", return_value=tmp_project):
            result = runner.invoke(app, ["claude", "uninstall"])

        assert result.exit_code == 0
        assert "removed" in result.output.lower()

    def test_reports_nothing_to_remove(self, tmp_project: Path, monkeypatch):
        monkeypatch.chdir(tmp_project)

        with patch("context_py.utils.claude_hooks.uninstall_hooks", return_value=False), \
             patch("context_py.utils.paths.get_project_root", return_value=tmp_project):
            result = runner.invoke(app, ["claude", "uninstall"])

        assert result.exit_code == 0
        assert "No know hooks" in result.output
