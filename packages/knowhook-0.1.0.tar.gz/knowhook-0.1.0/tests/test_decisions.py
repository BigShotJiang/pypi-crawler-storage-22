"""Tests for context_py/core/decisions.py — architectural decision logging."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from context_py.core.decisions import (
    add_decision,
    list_decisions,
    load_decisions,
    save_decisions,
)
from context_py.models import Decision, DecisionStatus


@pytest.fixture
def mock_know_dir(tmp_path: Path):
    """Patch get_project_know_dir to use tmp_path."""
    know = tmp_path / ".know"
    know.mkdir()
    with patch("context_py.core.decisions.get_project_know_dir", return_value=know):
        yield know


class TestLoadDecisions:
    def test_returns_empty_when_no_file(self, mock_know_dir: Path):
        assert load_decisions() == []

    def test_loads_existing_decisions(self, mock_know_dir: Path):
        data = [
            {"id": "D1", "timestamp": "t", "description": "Use JWT", "reasoning": "", "status": "active"},
            {"id": "D2", "timestamp": "t", "description": "Use Redis", "reasoning": "fast", "status": "active"},
        ]
        (mock_know_dir / "decisions.json").write_text(json.dumps(data))
        decisions = load_decisions()
        assert len(decisions) == 2
        assert decisions[0].id == "D1"
        assert decisions[1].reasoning == "fast"


class TestSaveDecisions:
    def test_saves_to_file(self, mock_know_dir: Path):
        decisions = [
            Decision(id="D1", timestamp="t", description="test"),
        ]
        save_decisions(decisions)
        path = mock_know_dir / "decisions.json"
        assert path.exists()
        data = json.loads(path.read_text())
        assert len(data) == 1
        assert data[0]["id"] == "D1"

    def test_atomic_write_no_corruption(self, mock_know_dir: Path):
        """Verify .tmp file doesn't linger after save."""
        decisions = [Decision(id="D1", timestamp="t", description="test")]
        save_decisions(decisions)
        tmp_file = mock_know_dir / "decisions.tmp"
        assert not tmp_file.exists()


class TestAddDecision:
    def test_adds_first_decision(self, mock_know_dir: Path):
        d = add_decision("Use JWT", "Stateless auth")
        assert d.id == "D1"
        assert d.description == "Use JWT"
        assert d.reasoning == "Stateless auth"
        assert d.status == DecisionStatus.active
        # Verify persisted
        decisions = load_decisions()
        assert len(decisions) == 1

    def test_increments_id(self, mock_know_dir: Path):
        add_decision("First")
        d2 = add_decision("Second")
        assert d2.id == "D2"

    def test_default_empty_reasoning(self, mock_know_dir: Path):
        d = add_decision("No reason given")
        assert d.reasoning == ""

    def test_three_decisions_sequential(self, mock_know_dir: Path):
        add_decision("A")
        add_decision("B")
        d3 = add_decision("C")
        assert d3.id == "D3"
        assert len(load_decisions()) == 3


class TestListDecisions:
    def test_empty_list(self, mock_know_dir: Path):
        assert list_decisions() == []

    def test_filters_active_only(self, mock_know_dir: Path):
        decisions = [
            Decision(id="D1", timestamp="t", description="active one", status=DecisionStatus.active),
            Decision(id="D2", timestamp="t", description="rejected", status=DecisionStatus.rejected),
            Decision(id="D3", timestamp="t", description="superseded", status=DecisionStatus.superseded),
            Decision(id="D4", timestamp="t", description="also active", status=DecisionStatus.active),
        ]
        save_decisions(decisions)
        result = list_decisions()
        assert len(result) == 2
        assert result[0].id == "D1"
        assert result[1].id == "D4"

    def test_limit(self, mock_know_dir: Path):
        for i in range(20):
            add_decision(f"Decision {i}")
        result = list_decisions(limit=5)
        assert len(result) == 5
        # Should be the last 5
        assert result[0].description == "Decision 15"

    def test_limit_larger_than_total(self, mock_know_dir: Path):
        add_decision("Only one")
        result = list_decisions(limit=100)
        assert len(result) == 1
