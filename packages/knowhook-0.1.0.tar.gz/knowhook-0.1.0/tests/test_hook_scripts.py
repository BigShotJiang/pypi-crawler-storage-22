"""Tests for context_py/hooks/ — the three Claude Code hook scripts."""

import json
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from context_py.models import Snapshot


class TestPreCompactHook:
    def test_creates_snapshot(self, tmp_path: Path):
        payload = json.dumps({"cwd": str(tmp_path)})
        mock_snapshot = (MagicMock(), tmp_path / "snapshot.json")

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.snapshot.create_and_save_snapshot", return_value=mock_snapshot) as mock_create, \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.pre_compact import main
            main()

        assert exc_info.value.code == 0
        mock_create.assert_called_once_with(trigger="pre_compact")

    def test_handles_invalid_json(self):
        with patch("sys.stdin", StringIO("not json")), \
             patch("context_py.core.snapshot.create_and_save_snapshot", return_value=(MagicMock(), Path("x"))) as mock_create, \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.pre_compact import main
            main()

        assert exc_info.value.code == 0
        mock_create.assert_called_once()

    def test_handles_empty_stdin(self):
        with patch("sys.stdin", StringIO("")), \
             patch("context_py.core.snapshot.create_and_save_snapshot", return_value=(MagicMock(), Path("x"))), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.pre_compact import main
            main()

        assert exc_info.value.code == 0

    def test_changes_to_cwd(self, tmp_path: Path):
        payload = json.dumps({"cwd": str(tmp_path)})

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.snapshot.create_and_save_snapshot", return_value=(MagicMock(), Path("x"))), \
             patch("os.chdir") as mock_chdir, \
             pytest.raises(SystemExit):
            from context_py.hooks.pre_compact import main
            main()

        mock_chdir.assert_called_once_with(str(tmp_path))


class TestSessionStartHook:
    def test_prints_briefing_on_compact(self, capsys):
        payload = json.dumps({"source": "compact", "cwd": "/tmp"})
        snap = Snapshot(project_name="test", timestamp="t")
        briefing = "=== KNOW: Test ==="

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.snapshot.load_latest_snapshot", return_value=snap), \
             patch("context_py.core.snapshot.format_snapshot_for_injection", return_value=briefing), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.session_start import main
            main()

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert "=== KNOW: Test ===" in captured.out

    def test_exits_silently_when_not_compact(self):
        payload = json.dumps({"source": "user", "cwd": "/tmp"})

        with patch("sys.stdin", StringIO(payload)), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.session_start import main
            main()

        assert exc_info.value.code == 0

    def test_exits_silently_when_no_source(self):
        payload = json.dumps({"cwd": "/tmp"})

        with patch("sys.stdin", StringIO(payload)), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.session_start import main
            main()

        assert exc_info.value.code == 0

    def test_exits_silently_when_no_snapshot(self):
        payload = json.dumps({"source": "compact", "cwd": "/tmp"})

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.snapshot.load_latest_snapshot", return_value=None), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.session_start import main
            main()

        assert exc_info.value.code == 0

    def test_handles_invalid_json(self):
        with patch("sys.stdin", StringIO("{bad")), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.session_start import main
            main()

        # source defaults to "" which is != "compact", so exits 0
        assert exc_info.value.code == 0


class TestPostToolUseHook:
    def test_records_edit(self):
        payload = json.dumps({
            "tool_name": "Edit",
            "tool_input": {"file_path": "src/main.py"},
            "cwd": "/tmp",
        })

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.session.record_file_touch") as mock_record, \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.post_tool_use import main
            main()

        assert exc_info.value.code == 0
        mock_record.assert_called_once_with("src/main.py", "edit")

    def test_records_write(self):
        payload = json.dumps({
            "tool_name": "Write",
            "tool_input": {"file_path": "new_file.py"},
            "cwd": "/tmp",
        })

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.session.record_file_touch") as mock_record, \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.post_tool_use import main
            main()

        assert exc_info.value.code == 0
        mock_record.assert_called_once_with("new_file.py", "write")

    def test_exits_silently_when_no_file_path(self):
        payload = json.dumps({
            "tool_name": "Edit",
            "tool_input": {},
            "cwd": "/tmp",
        })

        with patch("sys.stdin", StringIO(payload)), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.post_tool_use import main
            main()

        assert exc_info.value.code == 0

    def test_exits_silently_on_invalid_json(self):
        with patch("sys.stdin", StringIO("not json")), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.post_tool_use import main
            main()

        assert exc_info.value.code == 0

    def test_exits_silently_when_no_tool_input(self):
        payload = json.dumps({"tool_name": "Edit", "cwd": "/tmp"})

        with patch("sys.stdin", StringIO(payload)), \
             pytest.raises(SystemExit) as exc_info:
            from context_py.hooks.post_tool_use import main
            main()

        assert exc_info.value.code == 0

    def test_changes_to_cwd(self):
        payload = json.dumps({
            "tool_name": "Edit",
            "tool_input": {"file_path": "x.py"},
            "cwd": "/some/project",
        })

        with patch("sys.stdin", StringIO(payload)), \
             patch("context_py.core.session.record_file_touch"), \
             patch("os.chdir") as mock_chdir, \
             pytest.raises(SystemExit):
            from context_py.hooks.post_tool_use import main
            main()

        mock_chdir.assert_called_once_with("/some/project")
