"""Tests for context_py/core/mapper.py — dependency mapping."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from context_py.core.mapper import (
    build_dependency_map,
    load_map,
    save_map,
    scan_file_generic,
    scan_python_file,
    summarize_map,
)
from context_py.models import DependencyMap, FileNode


class TestScanPythonFile:
    def test_extracts_imports(self, tmp_path: Path):
        f = tmp_path / "example.py"
        f.write_text("import os\nimport sys\nfrom pathlib import Path\n")
        node = scan_python_file(f)
        assert "os" in node.imports
        assert "sys" in node.imports
        assert "pathlib" in node.imports
        assert node.language == "python"

    def test_extracts_classes_and_functions(self, tmp_path: Path):
        f = tmp_path / "example.py"
        f.write_text(
            "class MyClass:\n    pass\n\n"
            "def my_func():\n    pass\n\n"
            "async def async_func():\n    pass\n"
        )
        node = scan_python_file(f)
        assert "class:MyClass" in node.exports
        assert "def:my_func" in node.exports
        assert "def:async_func" in node.exports

    def test_handles_syntax_error(self, tmp_path: Path):
        f = tmp_path / "bad.py"
        f.write_text("def broken(\n")
        node = scan_python_file(f)
        assert node.language == "python"
        assert node.imports == []
        assert node.exports == []

    def test_handles_empty_file(self, tmp_path: Path):
        f = tmp_path / "empty.py"
        f.write_text("")
        node = scan_python_file(f)
        assert node.imports == []
        assert node.exports == []

    def test_from_import(self, tmp_path: Path):
        f = tmp_path / "example.py"
        f.write_text("from context_py.core.storage import load_config\n")
        node = scan_python_file(f)
        assert "context_py.core.storage" in node.imports


class TestScanFileGeneric:
    def test_javascript_imports(self, tmp_path: Path):
        f = tmp_path / "app.js"
        f.write_text(
            "import React from 'react';\n"
            "const fs = require('fs');\n"
            "export function main() {}\n"
            "export default class App {}\n"
        )
        node = scan_file_generic(f)
        assert "react" in node.imports
        assert "fs" in node.imports
        assert "main" in node.exports
        assert "App" in node.exports
        assert node.language == "javascript"

    def test_typescript_file(self, tmp_path: Path):
        f = tmp_path / "util.ts"
        f.write_text("import { Config } from './config';\nexport const VERSION = '1';\n")
        node = scan_file_generic(f)
        assert "./config" in node.imports
        assert "VERSION" in node.exports
        assert node.language == "typescript"

    def test_unknown_language(self, tmp_path: Path):
        f = tmp_path / "data.xyz"
        f.write_text("some content")
        node = scan_file_generic(f)
        assert node.language == "unknown"

    def test_go_imports(self, tmp_path: Path):
        f = tmp_path / "main.go"
        f.write_text('import (\n\t"fmt"\n\t"net/http"\n)\n')
        node = scan_file_generic(f)
        assert "net/http" in node.imports
        assert node.language == "go"

    def test_rust_use(self, tmp_path: Path):
        f = tmp_path / "lib.rs"
        f.write_text("use std::io;\nuse crate::config;\n")
        node = scan_file_generic(f)
        assert "std::io" in node.imports
        assert "crate::config" in node.imports
        assert node.language == "rust"

    def test_handles_unreadable_file(self, tmp_path: Path):
        f = tmp_path / "binary.py"
        f.write_bytes(b"\x80\x81\x82\x83")
        node = scan_python_file(f)
        # Should not crash — errors="replace" handles this
        assert node.language == "python"


class TestBuildDependencyMap:
    def test_scans_tracked_files(self, tmp_path: Path):
        # Create files
        (tmp_path / "main.py").write_text("import os\ndef main(): pass\n")
        (tmp_path / "util.py").write_text("def helper(): pass\n")

        with patch(
            "context_py.core.mapper._get_tracked_files",
            return_value=["main.py", "util.py"],
        ), patch(
            "context_py.core.mapper.get_project_root",
            return_value=tmp_path,
        ):
            dep_map = build_dependency_map(tmp_path)

        assert len(dep_map.files) == 2
        assert "main.py" in dep_map.files
        assert "util.py" in dep_map.files
        assert "os" in dep_map.files["main.py"].imports

    def test_empty_when_no_tracked_files(self, tmp_path: Path):
        with patch(
            "context_py.core.mapper._get_tracked_files",
            return_value=[],
        ):
            dep_map = build_dependency_map(tmp_path)
        assert len(dep_map.files) == 0

    def test_skips_nonexistent_files(self, tmp_path: Path):
        with patch(
            "context_py.core.mapper._get_tracked_files",
            return_value=["ghost.py"],
        ):
            dep_map = build_dependency_map(tmp_path)
        assert len(dep_map.files) == 0


class TestSaveAndLoadMap:
    def test_save_and_load_roundtrip(self, tmp_path: Path):
        know = tmp_path / ".know"
        know.mkdir()
        node = FileNode(path="a.py", imports=["os"], exports=["def:main"], language="python")
        dm = DependencyMap(generated_at="2026-01-01", files={"a.py": node})

        with patch("context_py.core.mapper.get_project_know_dir", return_value=know):
            save_map(dm)
            loaded = load_map()

        assert loaded is not None
        assert len(loaded.files) == 1
        assert loaded.files["a.py"].imports == ["os"]

    def test_load_returns_none_when_missing(self, tmp_path: Path):
        know = tmp_path / ".know"
        know.mkdir()
        with patch("context_py.core.mapper.get_project_know_dir", return_value=know):
            assert load_map() is None


class TestSummarizeMap:
    def test_produces_edges(self):
        files = {
            "auth.py": FileNode(
                path="auth.py", imports=["db"], exports=["def:verify"], language="python"
            ),
            "db.py": FileNode(
                path="db.py", imports=[], exports=["class:UserModel"], language="python"
            ),
        }
        dm = DependencyMap(generated_at="t", files=files)
        edges = summarize_map(dm, focus_files=["auth.py"])
        assert len(edges) >= 1
        assert any("auth.py -> db.py" in e for e in edges)

    def test_no_edges_when_no_matches(self):
        files = {
            "a.py": FileNode(path="a.py", imports=["external_lib"], language="python"),
        }
        dm = DependencyMap(generated_at="t", files=files)
        edges = summarize_map(dm, focus_files=["a.py"])
        assert edges == []

    def test_no_self_edges(self):
        files = {
            "a.py": FileNode(path="a.py", imports=["a"], exports=["def:x"], language="python"),
        }
        dm = DependencyMap(generated_at="t", files=files)
        edges = summarize_map(dm, focus_files=["a.py"])
        assert not any("a.py -> a.py" in e for e in edges)

    def test_all_files_when_no_focus(self):
        files = {
            "a.py": FileNode(path="a.py", imports=["b"], language="python"),
            "b.py": FileNode(path="b.py", imports=[], exports=["def:helper"], language="python"),
        }
        dm = DependencyMap(generated_at="t", files=files)
        edges = summarize_map(dm)  # no focus_files
        assert len(edges) >= 1
