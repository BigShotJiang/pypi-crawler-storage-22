"""Tests for context_py/models.py — all Pydantic data models."""

from context_py.models import (
    Decision,
    DecisionStatus,
    DependencyMap,
    FileNode,
    SessionFile,
    SessionTracker,
    Snapshot,
)


class TestDecisionStatus:
    def test_enum_values(self):
        assert DecisionStatus.active == "active"
        assert DecisionStatus.superseded == "superseded"
        assert DecisionStatus.rejected == "rejected"

    def test_string_coercion(self):
        d = Decision(id="D1", timestamp="t", description="test", status="active")
        assert d.status == DecisionStatus.active


class TestDecision:
    def test_defaults(self):
        d = Decision(id="D1", timestamp="2026-01-01", description="Use JWT")
        assert d.reasoning == ""
        assert d.status == DecisionStatus.active

    def test_full_construction(self):
        d = Decision(
            id="D3",
            timestamp="2026-01-01T00:00:00",
            description="Use Redis",
            reasoning="Fast TTL",
            status=DecisionStatus.superseded,
        )
        assert d.id == "D3"
        assert d.reasoning == "Fast TTL"
        assert d.status == DecisionStatus.superseded

    def test_serialization_roundtrip(self):
        d = Decision(id="D1", timestamp="t", description="test", reasoning="why")
        data = d.model_dump()
        d2 = Decision(**data)
        assert d == d2


class TestFileNode:
    def test_defaults(self):
        node = FileNode(path="src/main.py")
        assert node.imports == []
        assert node.exports == []
        assert node.language == "unknown"

    def test_with_data(self):
        node = FileNode(
            path="auth.py",
            imports=["os", "jwt"],
            exports=["class:Auth", "def:verify"],
            language="python",
        )
        assert len(node.imports) == 2
        assert "class:Auth" in node.exports


class TestDependencyMap:
    def test_empty(self):
        dm = DependencyMap(generated_at="2026-01-01")
        assert dm.files == {}

    def test_with_files(self):
        node = FileNode(path="a.py", language="python")
        dm = DependencyMap(generated_at="t", files={"a.py": node})
        assert "a.py" in dm.files
        assert dm.files["a.py"].language == "python"


class TestSessionFile:
    def test_construction(self):
        sf = SessionFile(path="test.py", action="edit", timestamp="t")
        assert sf.path == "test.py"
        assert sf.action == "edit"


class TestSessionTracker:
    def test_defaults(self):
        st = SessionTracker(session_id="abc", started_at="t")
        assert st.files_touched == []

    def test_with_files(self):
        sf = SessionFile(path="a.py", action="write", timestamp="t")
        st = SessionTracker(session_id="abc", started_at="t", files_touched=[sf])
        assert len(st.files_touched) == 1


class TestSnapshot:
    def test_defaults(self):
        s = Snapshot()
        assert s.version == "1"
        assert s.timestamp == ""
        assert s.goals == []
        assert s.decisions == []
        assert s.files_touched == []
        assert s.dependency_edges == []
        assert s.completed_work == []
        assert s.pending_work == []
        assert s.rejected_approaches == []

    def test_full_construction(self):
        d = Decision(id="D1", timestamp="t", description="test")
        sf = SessionFile(path="a.py", action="edit", timestamp="t")
        s = Snapshot(
            version="1",
            timestamp="2026-01-01",
            trigger="manual",
            project_name="proj",
            current_task={"id": "1", "description": "task", "status": "active"},
            goals=["g1"],
            rules=["r1"],
            decisions=[d],
            files_touched=[sf],
            dependency_edges=["a.py -> b.py"],
            completed_work=["step 1"],
            pending_work=["step 2"],
            rejected_approaches=["bad idea"],
        )
        assert s.project_name == "proj"
        assert len(s.decisions) == 1
        assert s.rejected_approaches == ["bad idea"]

    def test_serialization_roundtrip(self):
        d = Decision(id="D1", timestamp="t", description="test")
        s = Snapshot(
            timestamp="t",
            trigger="manual",
            project_name="p",
            decisions=[d],
            goals=["g"],
        )
        data = s.model_dump()
        s2 = Snapshot(**data)
        assert s == s2
