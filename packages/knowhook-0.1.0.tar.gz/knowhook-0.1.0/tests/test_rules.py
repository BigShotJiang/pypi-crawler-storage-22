"""Tests for context_py/core/rules.py — Claude rules file generation."""

from pathlib import Path
from unittest.mock import patch

import pytest

from context_py.config import ContextConfig, CurrentTask, TaskStatus
from context_py.core.rules import generate_rules_file, sync_rules, write_rules_file
from context_py.models import Decision, DecisionStatus, DependencyMap, FileNode


@pytest.fixture
def sample_config() -> ContextConfig:
    return ContextConfig(
        project_name="rules-test",
        goals=["Fast API", "100% coverage"],
        current_task=CurrentTask(id="7", description="Add tests", status=TaskStatus.active),
        rules=["No print statements", "Type hints required"],
    )


@pytest.fixture
def sample_decisions() -> list[Decision]:
    return [
        Decision(id="D1", timestamp="t", description="Use pytest", reasoning="Industry standard", status=DecisionStatus.active),
        Decision(id="D2", timestamp="t", description="Old approach", status=DecisionStatus.rejected),
        Decision(id="D3", timestamp="t", description="Use fixtures", status=DecisionStatus.active),
    ]


class TestGenerateRulesFile:
    def test_includes_project_info(self, sample_config):
        content = generate_rules_file(sample_config, [])
        assert "rules-test" in content
        assert "Current Task [7]" in content
        assert "Add tests" in content
        assert "status: active" in content

    def test_includes_goals(self, sample_config):
        content = generate_rules_file(sample_config, [])
        assert "## Goals" in content
        assert "- Fast API" in content
        assert "- 100% coverage" in content

    def test_includes_rules(self, sample_config):
        content = generate_rules_file(sample_config, [])
        assert "## Rules" in content
        assert "- No print statements" in content

    def test_filters_active_decisions_only(self, sample_config, sample_decisions):
        content = generate_rules_file(sample_config, sample_decisions)
        assert "## Architectural Decisions" in content
        assert "[D1]" in content
        assert "Use pytest" in content
        assert "[D3]" in content
        assert "Use fixtures" in content
        # Rejected decision should NOT appear
        assert "Old approach" not in content

    def test_includes_reasoning(self, sample_config, sample_decisions):
        content = generate_rules_file(sample_config, sample_decisions)
        assert "Industry standard" in content

    def test_no_decisions_section_when_empty(self, sample_config):
        content = generate_rules_file(sample_config, [])
        assert "## Architectural Decisions" not in content

    def test_no_rules_section_when_empty(self):
        config = ContextConfig(rules=[])
        content = generate_rules_file(config, [])
        assert "## Rules" not in content

    def test_includes_key_files_from_dep_map(self, sample_config):
        files = {
            "auth.py": FileNode(path="auth.py", exports=["class:Auth", "def:verify"], language="python"),
            "db.py": FileNode(path="db.py", exports=["class:DB"], language="python"),
        }
        dep_map = DependencyMap(generated_at="t", files=files)
        content = generate_rules_file(sample_config, [], dep_map)
        assert "## Key Files" in content
        assert "`auth.py`" in content
        assert "Auth" in content

    def test_no_key_files_without_dep_map(self, sample_config):
        content = generate_rules_file(sample_config, [], dep_map=None)
        assert "## Key Files" not in content


class TestWriteRulesFile:
    def test_creates_file(self, tmp_path: Path):
        content = "# Test rules\n- Rule 1\n"
        path = write_rules_file(content, tmp_path)
        assert path.exists()
        assert path == tmp_path / ".claude" / "rules" / "know-context.md"
        assert path.read_text() == content

    def test_creates_directories(self, tmp_path: Path):
        # .claude/rules/ doesn't exist yet
        path = write_rules_file("content", tmp_path)
        assert path.parent.is_dir()

    def test_overwrites_existing(self, tmp_path: Path):
        write_rules_file("old content", tmp_path)
        path = write_rules_file("new content", tmp_path)
        assert path.read_text() == "new content"


class TestSyncRules:
    def test_full_pipeline(self, tmp_path: Path):
        config = ContextConfig(project_name="sync-test", rules=["rule1"])
        decisions = [Decision(id="D1", timestamp="t", description="dec1")]

        with patch("context_py.core.rules.find_context_file", return_value=tmp_path / ".context.yaml"), \
             patch("context_py.core.rules.load_config", return_value=config), \
             patch("context_py.core.decisions.load_decisions", return_value=decisions), \
             patch("context_py.core.mapper.load_map", return_value=None):
            path = sync_rules(tmp_path)

        assert path.exists()
        content = path.read_text()
        assert "sync-test" in content
        assert "rule1" in content
        assert "dec1" in content

    def test_works_without_context_file(self, tmp_path: Path):
        with patch("context_py.core.rules.find_context_file", return_value=None), \
             patch("context_py.core.decisions.load_decisions", return_value=[]), \
             patch("context_py.core.mapper.load_map", return_value=None):
            path = sync_rules(tmp_path)

        assert path.exists()
        # Should use default config
        content = path.read_text()
        assert "my-project" in content
