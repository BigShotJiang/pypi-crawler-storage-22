"""Tests for context_py/core/session.py — session file tracking."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from context_py.core.session import (
    clear_session,
    load_session,
    record_file_touch,
    save_session,
)
from context_py.models import SessionFile, SessionTracker


@pytest.fixture
def mock_know_dir(tmp_path: Path):
    """Patch get_project_know_dir to use tmp_path."""
    know = tmp_path / ".know"
    know.mkdir()
    with patch("context_py.core.session.get_project_know_dir", return_value=know):
        yield know


class TestLoadSession:
    def test_creates_new_when_no_file(self, mock_know_dir: Path):
        session = load_session()
        assert len(session.session_id) == 12
        assert session.files_touched == []

    def test_loads_existing_session(self, mock_know_dir: Path):
        data = {
            "session_id": "abc123def456",
            "started_at": "2026-01-01T00:00:00",
            "files_touched": [
                {"path": "test.py", "action": "edit", "timestamp": "t"},
            ],
        }
        (mock_know_dir / "session.json").write_text(json.dumps(data))
        session = load_session()
        assert session.session_id == "abc123def456"
        assert len(session.files_touched) == 1
        assert session.files_touched[0].path == "test.py"


class TestSaveSession:
    def test_saves_to_file(self, mock_know_dir: Path):
        tracker = SessionTracker(session_id="test123", started_at="t")
        save_session(tracker)
        path = mock_know_dir / "session.json"
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["session_id"] == "test123"

    def test_atomic_write_no_tmp_leftover(self, mock_know_dir: Path):
        tracker = SessionTracker(session_id="test123", started_at="t")
        save_session(tracker)
        assert not (mock_know_dir / "session.tmp").exists()


class TestRecordFileTouch:
    def test_appends_to_session(self, mock_know_dir: Path):
        record_file_touch("a.py", "edit")
        record_file_touch("b.py", "write")
        session = load_session()
        assert len(session.files_touched) == 2
        assert session.files_touched[0].path == "a.py"
        assert session.files_touched[0].action == "edit"
        assert session.files_touched[1].path == "b.py"
        assert session.files_touched[1].action == "write"

    def test_preserves_session_id(self, mock_know_dir: Path):
        record_file_touch("a.py", "edit")
        session_id = load_session().session_id
        record_file_touch("b.py", "write")
        assert load_session().session_id == session_id

    def test_resets_on_different_session_id(self, mock_know_dir: Path):
        record_file_touch("a.py", "edit")
        old_id = load_session().session_id
        record_file_touch("b.py", "write", session_id="new_session")
        session = load_session()
        assert session.session_id == "new_session"
        assert session.session_id != old_id
        # Only the new touch should remain
        assert len(session.files_touched) == 1
        assert session.files_touched[0].path == "b.py"

    def test_records_timestamp(self, mock_know_dir: Path):
        record_file_touch("x.py", "edit")
        session = load_session()
        assert session.files_touched[0].timestamp != ""


class TestClearSession:
    def test_resets_session(self, mock_know_dir: Path):
        record_file_touch("a.py", "edit")
        record_file_touch("b.py", "write")
        old_id = load_session().session_id

        clear_session()
        session = load_session()
        assert session.session_id != old_id
        assert session.files_touched == []
