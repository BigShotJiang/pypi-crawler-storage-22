"""Tests for context_py/core/snapshot.py — snapshot engine."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from context_py.config import ContextConfig, CurrentTask, TaskStatus
from context_py.core.snapshot import (
    create_and_save_snapshot,
    create_snapshot,
    format_snapshot_for_injection,
    load_latest_snapshot,
    save_snapshot,
)
from context_py.models import (
    Decision,
    DecisionStatus,
    DependencyMap,
    FileNode,
    SessionFile,
    SessionTracker,
    Snapshot,
)


@pytest.fixture
def sample_config() -> ContextConfig:
    return ContextConfig(
        project_name="test-project",
        goals=["Build API", "Add auth"],
        current_task=CurrentTask(id="42", description="Implement JWT", status=TaskStatus.active),
        rules=["No print statements", "Type hints required"],
    )


@pytest.fixture
def sample_decisions() -> list[Decision]:
    return [
        Decision(id="D1", timestamp="t1", description="Use JWT", reasoning="Stateless"),
        Decision(id="D2", timestamp="t2", description="Redis for tokens", reasoning="Fast TTL"),
    ]


@pytest.fixture
def sample_session() -> SessionTracker:
    return SessionTracker(
        session_id="abc123",
        started_at="2026-01-01",
        files_touched=[
            SessionFile(path="auth.py", action="edit", timestamp="t1"),
            SessionFile(path="db.py", action="edit", timestamp="t2"),
            SessionFile(path="models.py", action="write", timestamp="t3"),
        ],
    )


class TestCreateSnapshot:
    def test_assembles_all_fields(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session, trigger="manual")
        assert snap.project_name == "test-project"
        assert snap.trigger == "manual"
        assert len(snap.goals) == 2
        assert len(snap.rules) == 2
        assert len(snap.decisions) == 2
        assert len(snap.files_touched) == 3
        assert snap.current_task["id"] == "42"

    def test_without_dep_map(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session, dep_map=None)
        assert snap.dependency_edges == []

    def test_with_dep_map(self, sample_config, sample_decisions, sample_session):
        files = {
            "auth.py": FileNode(path="auth.py", imports=["db"], language="python"),
            "db.py": FileNode(path="db.py", exports=["class:UserModel"], language="python"),
        }
        dep_map = DependencyMap(generated_at="t", files=files)
        snap = create_snapshot(sample_config, sample_decisions, sample_session, dep_map=dep_map)
        assert isinstance(snap.dependency_edges, list)

    def test_empty_session(self, sample_config, sample_decisions):
        empty_session = SessionTracker(session_id="x", started_at="t")
        snap = create_snapshot(sample_config, sample_decisions, empty_session)
        assert snap.files_touched == []

    def test_empty_decisions(self, sample_config, sample_session):
        snap = create_snapshot(sample_config, [], sample_session)
        assert snap.decisions == []


class TestSaveSnapshot:
    def test_saves_to_snapshots_dir(self, tmp_path: Path):
        snapshots_dir = tmp_path / ".know" / "snapshots"
        snapshots_dir.mkdir(parents=True)
        snap = Snapshot(timestamp="2026-01-15T10:30:00+00:00", project_name="test")

        with patch("context_py.core.snapshot.get_snapshots_dir", return_value=snapshots_dir):
            path = save_snapshot(snap)

        assert path.exists()
        assert path.parent == snapshots_dir
        assert path.suffix == ".json"
        data = json.loads(path.read_text())
        assert data["project_name"] == "test"

    def test_filename_sanitization(self, tmp_path: Path):
        snapshots_dir = tmp_path / "snapshots"
        snapshots_dir.mkdir()
        snap = Snapshot(timestamp="2026-01-15T10:30:00+00:00")

        with patch("context_py.core.snapshot.get_snapshots_dir", return_value=snapshots_dir):
            path = save_snapshot(snap)

        # Filename should not contain colons or hyphens from timestamp
        assert ":" not in path.name
        assert "-" not in path.name


class TestLoadLatestSnapshot:
    def test_returns_none_when_empty(self, tmp_path: Path):
        snapshots_dir = tmp_path / "snapshots"
        snapshots_dir.mkdir()
        with patch("context_py.core.snapshot.get_snapshots_dir", return_value=snapshots_dir):
            assert load_latest_snapshot() is None

    def test_loads_most_recent(self, tmp_path: Path):
        snapshots_dir = tmp_path / "snapshots"
        snapshots_dir.mkdir()

        snap1 = Snapshot(timestamp="t1", project_name="old")
        snap2 = Snapshot(timestamp="t2", project_name="new")
        (snapshots_dir / "20260101T000000.json").write_text(
            json.dumps(snap1.model_dump())
        )
        (snapshots_dir / "20260102T000000.json").write_text(
            json.dumps(snap2.model_dump())
        )

        with patch("context_py.core.snapshot.get_snapshots_dir", return_value=snapshots_dir):
            latest = load_latest_snapshot()

        assert latest is not None
        assert latest.project_name == "new"


class TestFormatSnapshotForInjection:
    def test_includes_header_and_footer(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert text.startswith("=== KNOW: Post-Compaction Context Recovery ===")
        assert text.endswith("=== END KNOW CONTEXT ===")

    def test_includes_project_and_task(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert "PROJECT: test-project" in text
        assert "CURRENT TASK [42]" in text
        assert "Implement JWT" in text
        assert "status: active" in text

    def test_includes_goals(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert "GOALS: Build API, Add auth" in text

    def test_includes_decisions(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert "DECISIONS:" in text
        assert "[D1] Use JWT" in text
        assert "[D2] Redis for tokens" in text

    def test_includes_rules(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert "RULES:" in text
        assert "No print statements" in text

    def test_includes_files_touched(self, sample_config, sample_decisions, sample_session):
        snap = create_snapshot(sample_config, sample_decisions, sample_session)
        text = format_snapshot_for_injection(snap)
        assert "FILES TOUCHED THIS SESSION:" in text
        assert "auth.py (edit)" in text

    def test_deduplicates_files(self):
        snap = Snapshot(
            project_name="p",
            files_touched=[
                SessionFile(path="a.py", action="edit", timestamp="t1"),
                SessionFile(path="a.py", action="edit", timestamp="t2"),
                SessionFile(path="b.py", action="write", timestamp="t3"),
            ],
        )
        text = format_snapshot_for_injection(snap)
        assert text.count("a.py (edit)") == 1
        assert "b.py (write)" in text

    def test_empty_snapshot(self):
        snap = Snapshot(project_name="empty")
        text = format_snapshot_for_injection(snap)
        assert "PROJECT: empty" in text
        assert "DECISIONS:" not in text
        assert "RULES:" not in text
        assert "FILES TOUCHED" not in text

    def test_includes_work_status(self):
        snap = Snapshot(
            project_name="p",
            completed_work=["Step 1", "Step 2"],
            pending_work=["Step 3"],
            rejected_approaches=["Bad idea"],
        )
        text = format_snapshot_for_injection(snap)
        assert "COMPLETED: Step 1, Step 2" in text
        assert "PENDING: Step 3" in text
        assert "REJECTED: Bad idea" in text

    def test_includes_dependency_edges(self):
        snap = Snapshot(
            project_name="p",
            dependency_edges=["auth.py -> db.py (imports UserModel)"],
        )
        text = format_snapshot_for_injection(snap)
        assert "DEPENDENCIES:" in text
        assert "auth.py -> db.py (imports UserModel)" in text

    def test_includes_reasoning_in_decisions(self):
        snap = Snapshot(
            project_name="p",
            decisions=[
                Decision(id="D1", timestamp="t", description="Use JWT", reasoning="Stateless"),
            ],
        )
        text = format_snapshot_for_injection(snap)
        # Check for decision with reasoning (format: "description — reasoning")
        assert "Use JWT" in text
        assert "Stateless" in text


class TestCreateAndSaveSnapshot:
    def test_end_to_end(self, tmp_path: Path):
        """Test the convenience function with all mocks."""
        know = tmp_path / ".know"
        snapshots = know / "snapshots"
        snapshots.mkdir(parents=True)

        config = ContextConfig(project_name="e2e-test")
        ctx_file = tmp_path / ".context.yaml"

        with patch("context_py.core.snapshot.find_context_file", return_value=ctx_file), \
             patch("context_py.core.snapshot.load_config", return_value=config), \
             patch("context_py.core.decisions.load_decisions", return_value=[]), \
             patch("context_py.core.session.load_session", return_value=SessionTracker(session_id="x", started_at="t")), \
             patch("context_py.core.mapper.load_map", return_value=None), \
             patch("context_py.core.snapshot.get_snapshots_dir", return_value=snapshots):
            snap, path = create_and_save_snapshot(trigger="test")

        assert snap.project_name == "e2e-test"
        assert snap.trigger == "test"
        assert path.exists()
