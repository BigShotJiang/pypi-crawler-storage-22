"""Tests for context_py/core/storage.py — YAML file I/O and config management."""

from pathlib import Path

import pytest
import yaml

from context_py.config import ContextConfig, TaskStatus
from context_py.core.storage import (
    CONTEXT_FILENAME,
    create_default_config,
    find_context_file,
    load_config,
    save_config,
)


class TestFindContextFile:
    def test_finds_in_current_dir(self, tmp_project: Path):
        result = find_context_file(tmp_project)
        assert result is not None
        assert result.name == CONTEXT_FILENAME

    def test_finds_in_parent_dir(self, tmp_project: Path):
        sub = tmp_project / "src" / "deep"
        sub.mkdir(parents=True)
        result = find_context_file(sub)
        assert result is not None
        assert result.parent == tmp_project

    def test_returns_none_when_missing(self, tmp_path: Path):
        result = find_context_file(tmp_path)
        assert result is None

    def test_stops_at_filesystem_root(self):
        # Starting from / should not infinite loop
        result = find_context_file("/")
        # May or may not find one depending on system, but should not hang
        assert result is None or isinstance(result, Path)


class TestLoadConfig:
    def test_loads_valid_config(self, tmp_project: Path):
        config = load_config(tmp_project / CONTEXT_FILENAME)
        assert config.project_name == "test-project"
        assert config.current_task.id == "42"
        assert config.current_task.description == "Build auth"
        assert config.current_task.status == TaskStatus.active
        assert len(config.goals) == 2
        assert len(config.rules) == 2

    def test_loads_empty_yaml(self, tmp_path: Path):
        f = tmp_path / ".context.yaml"
        f.write_text("")
        config = load_config(f)
        # Should use all defaults
        assert config.project_name == "my-project"

    def test_loads_partial_config(self, tmp_path: Path):
        f = tmp_path / ".context.yaml"
        f.write_text(yaml.dump({"project_name": "custom"}))
        config = load_config(f)
        assert config.project_name == "custom"
        assert config.goals == ["Define project goals"]  # default


class TestSaveConfig:
    def test_saves_and_reloads(self, tmp_path: Path):
        config = ContextConfig(project_name="saved-project", goals=["g1", "g2"])
        path = tmp_path / ".context.yaml"
        save_config(config, path)
        reloaded = load_config(path)
        assert reloaded.project_name == "saved-project"
        assert reloaded.goals == ["g1", "g2"]

    def test_preserves_task_status(self, tmp_path: Path):
        config = ContextConfig()
        config.current_task.status = TaskStatus.completed
        path = tmp_path / ".context.yaml"
        save_config(config, path)
        reloaded = load_config(path)
        assert reloaded.current_task.status == TaskStatus.completed


class TestCreateDefaultConfig:
    def test_creates_file(self, tmp_path: Path):
        path = create_default_config(tmp_path)
        assert path.exists()
        config = load_config(path)
        assert config.project_name == "my-project"

    def test_raises_if_exists(self, tmp_project: Path):
        with pytest.raises(FileExistsError):
            create_default_config(tmp_project)
