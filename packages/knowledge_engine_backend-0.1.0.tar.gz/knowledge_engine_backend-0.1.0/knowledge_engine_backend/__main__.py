from __future__ import annotations

import uvicorn

from .api import create_app
from .config import load_config
from .engine import KnowledgeEngine


def main() -> None:
    config = load_config()
    engine = KnowledgeEngine.from_config(config)
    app = create_app(engine)
    uvicorn.run(app, host="0.0.0.0", port=config.port)


if __name__ == "__main__":
    main()
