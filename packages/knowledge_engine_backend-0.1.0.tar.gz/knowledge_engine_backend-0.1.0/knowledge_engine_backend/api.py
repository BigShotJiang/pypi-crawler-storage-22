from __future__ import annotations

import time

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .engine import KnowledgeEngine


class CrawlRequest(BaseModel):
    url: str


class SearchResponse(BaseModel):
    query: str
    results: list[dict]


class GenerateResponse(BaseModel):
    query: str
    answer: str


class StatusResponse(BaseModel):
    running: bool
    pages_crawled: int
    uptime: str


def create_app(engine: KnowledgeEngine) -> FastAPI:
    app = FastAPI(title="Knowledge Engine API", version="1.0")

    @app.post("/api/v1/crawl")
    def crawl(request: CrawlRequest):
        if not request.url:
            raise HTTPException(status_code=400, detail="URL is required")
        engine.start_crawl(request.url)
        return {"status": "crawl_started", "seed": request.url}

    @app.get("/api/v1/search")
    def search(q: str):
        if not q:
            raise HTTPException(status_code=400, detail="Query 'q' is required")
        hits = engine.vector_store.search(q, 5)
        results = []
        for hit in hits:
            text = hit.document.content
            if len(text) > 200:
                text = text[:200] + "..."
            results.append({"url": hit.document.id, "score": hit.score, "snippet": text})
        return SearchResponse(query=q, results=results)

    @app.get("/api/v1/status")
    def status():
        stats = engine.stats
        uptime = "0s"
        if engine.is_running():
            uptime_seconds = int(max(0, time.time() - stats.start_time))
            uptime = f"{uptime_seconds}s"
        return StatusResponse(
            running=engine.is_running(),
            pages_crawled=stats.pages_crawled,
            uptime=uptime,
        )

    @app.get("/api/v1/generate")
    def generate(q: str):
        if not q:
            raise HTTPException(status_code=400, detail="Query 'q' is required")
        answer = engine.generate_answer(q)
        return GenerateResponse(query=q, answer=answer)

    return app
