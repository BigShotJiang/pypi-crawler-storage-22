from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List

from .config import Config, load_config
from .engine import KnowledgeEngine
from .provider import OllamaProvider, OpenAIProvider


@dataclass
class Status:
    running: bool
    pages_crawled: int
    uptime: str


def _format_uptime(start_time: float, running: bool) -> str:
    if not running:
        return "0s"
    seconds = int(max(0.0, time.time() - start_time))
    return f"{seconds}s"


class KnowledgeEngineApp:
    """In-process Knowledge Engine API (no server required)."""

    def __init__(self, config: Config | None = None) -> None:
        self.config = config or load_config()
        self.engine = KnowledgeEngine.from_config(self.config)
        self._provider = self._build_provider()

    def _build_provider(self):
        provider_name = os.getenv("LLM_PROVIDER", self.config.llm.provider).lower()
        base_url = os.getenv("LLM_BASE_URL", self.config.llm.base_url)
        model = os.getenv("LLM_MODEL", self.config.llm.model)
        api_key = os.getenv("LLM_API_KEY", self.config.llm.api_key)
        if provider_name == "openai":
            return OpenAIProvider(base_url, model, api_key)
        return OllamaProvider(base_url, model)

    def start_crawl(self, url: str) -> None:
        if not url:
            raise ValueError("URL is required")
        self.engine.start_crawl(url)

    def search(self, query: str, top_k: int = 5) -> Dict[str, Any]:
        if not query:
            raise ValueError("Query is required")
        hits = self.engine.vector_store.search(query, top_k)
        results: List[Dict[str, Any]] = []
        for hit in hits:
            text = hit.document.content
            if len(text) > 200:
                text = text[:200] + "..."
            results.append({"url": hit.document.id, "score": hit.score, "snippet": text})
        return {"query": query, "results": results}

    def generate(self, query: str) -> Dict[str, str]:
        if not query:
            raise ValueError("Query is required")
        answer = self.engine.generate_answer(query)
        return {"query": query, "answer": answer}

    def status(self) -> Status:
        stats = self.engine.stats
        return Status(
            running=self.engine.is_running(),
            pages_crawled=stats.pages_crawled,
            uptime=_format_uptime(stats.start_time, self.engine.is_running()),
        )

    def auto_seed_urls(self, topic: str, limit: int = 6) -> list[str]:
        prompt = (
            "Return ONLY a JSON array of URLs for authoritative sources about the topic below. "
            "No markdown, no explanations. Provide up to "
            f"{limit} URLs.\n\nTopic: {topic}\n\nJSON:" 
        )
        raw = self._provider.generate(prompt)
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            start = raw.find("[")
            end = raw.rfind("]")
            if start != -1 and end != -1:
                data = json.loads(raw[start : end + 1])
            else:
                raise ValueError("LLM did not return valid JSON list of URLs")

        if not isinstance(data, list):
            raise ValueError("LLM did not return a JSON array")
        urls = [str(item).strip() for item in data if str(item).strip().startswith("http")]
        return urls[:limit]
