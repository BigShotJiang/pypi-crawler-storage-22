from __future__ import annotations

from dataclasses import dataclass

from .utils import get_bool_env, get_env, get_int_env, parse_duration


@dataclass
class FrontierConfig:
    max_urls_in_memory: int
    max_retries: int
    default_priority: int
    cleanup_interval: float
    politeness_delay: float
    max_concurrency: int
    enable_persistence: bool


@dataclass
class StorageConfig:
    data_dir: str


@dataclass
class PolitenessConfig:
    default_min_delay: float
    default_domain_concurrency: int
    global_max_concurrency: int
    request_queue_size: int
    default_request_timeout: float
    cleanup_interval: float
    domain_state_expiry: float
    robots_cache_duration: float
    enable_robots_check: bool
    user_agent: str


@dataclass
class LLMConfig:
    provider: str
    base_url: str
    model: str
    api_key: str


@dataclass
class Config:
    frontier: FrontierConfig
    storage: StorageConfig
    politeness: PolitenessConfig
    llm: LLMConfig
    port: int


def load_config() -> Config:
    return Config(
        frontier=FrontierConfig(
            max_urls_in_memory=get_int_env("FRONTIER_MAX_URLS", 10000),
            max_retries=get_int_env("FRONTIER_MAX_RETRIES", 3),
            default_priority=get_int_env("FRONTIER_DEFAULT_PRIORITY", 1),
            cleanup_interval=parse_duration(get_env("FRONTIER_CLEANUP_INTERVAL", "5m"), 300.0),
            politeness_delay=parse_duration(get_env("FRONTIER_POLITENESS_DELAY", "1s"), 1.0),
            max_concurrency=get_int_env("FRONTIER_MAX_CONCURRENCY", 10),
            enable_persistence=get_bool_env("FRONTIER_ENABLE_PERSISTENCE", True),
        ),
        storage=StorageConfig(
            data_dir=get_env("SEARCH_DATA_DIR", "./data"),
        ),
        politeness=PolitenessConfig(
            default_min_delay=parse_duration(get_env("POLITENESS_DEFAULT_MIN_DELAY", "1s"), 1.0),
            default_domain_concurrency=get_int_env("POLITENESS_DEFAULT_DOMAIN_CONCURRENCY", 2),
            global_max_concurrency=get_int_env("POLITENESS_GLOBAL_MAX_CONCURRENCY", 100),
            request_queue_size=get_int_env("POLITENESS_REQUEST_QUEUE_SIZE", 1000),
            default_request_timeout=parse_duration(get_env("POLITENESS_DEFAULT_REQUEST_TIMEOUT", "30s"), 30.0),
            cleanup_interval=parse_duration(get_env("POLITENESS_CLEANUP_INTERVAL", "10m"), 600.0),
            domain_state_expiry=parse_duration(get_env("POLITENESS_DOMAIN_STATE_EXPIRY", "1h"), 3600.0),
            robots_cache_duration=parse_duration(get_env("POLITENESS_ROBOTS_CACHE_DURATION", "24h"), 86400.0),
            enable_robots_check=get_bool_env("POLITENESS_ENABLE_ROBOTS_CHECK", True),
            user_agent=get_env("POLITENESS_USER_AGENT", "SearchEngine-Crawler/1.0"),
        ),
        llm=LLMConfig(
            provider=get_env("LLM_PROVIDER", "ollama"),
            base_url=get_env("LLM_BASE_URL", ""),
            model=get_env("LLM_MODEL", "qwen3:1.7b"),
            api_key=get_env("LLM_API_KEY", ""),
        ),
        port=get_int_env("PORT", 8080),
    )
