from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from .config import Config
from .fetcher import Fetcher, FetchResult
from .frontier import Priority, URLFrontier
from .politeness import PolitenessManager
from .provider import LLMProvider, OllamaProvider, OpenAIProvider, build_prompt
from .search import Document, VectorStore
from .storage import FileStorage


@dataclass
class EngineStats:
    pages_crawled: int = 0
    last_error: str = ""
    start_time: float = field(default_factory=time.time)


class KnowledgeEngine:
    def __init__(
        self,
        config: Config,
        frontier: URLFrontier,
        politeness: PolitenessManager,
        fetcher: Fetcher,
        storage: FileStorage,
        vector_store: VectorStore,
        llm: LLMProvider,
    ) -> None:
        self.config = config
        self.frontier = frontier
        self.politeness = politeness
        self.fetcher = fetcher
        self.storage = storage
        self.vector_store = vector_store
        self.llm = llm
        self.stats = EngineStats()
        self._lock = threading.RLock()
        self._running = False
        self._worker: Optional[threading.Thread] = None

    @classmethod
    def from_config(cls, config: Config) -> "KnowledgeEngine":
        frontier = URLFrontier(config.frontier)
        politeness = PolitenessManager(config.politeness)
        fetcher = Fetcher(config.politeness.default_request_timeout, config.politeness.user_agent)
        storage = FileStorage(config.storage.data_dir)
        vector_store = VectorStore()
        llm = _build_provider(config)
        engine = cls(config, frontier, politeness, fetcher, storage, vector_store, llm)
        engine._load_existing_data()
        return engine

    def start_crawl(self, seed_url: str) -> None:
        with self._lock:
            if self._running:
                self.frontier.add_url(seed_url, Priority.CRITICAL, 0)
                return
            self._running = True
            self.stats.start_time = time.time()
            self.politeness.start()
            self.frontier.start()
            self.frontier.add_url(seed_url, Priority.CRITICAL, 0)
            self._worker = threading.Thread(target=self._run_worker, daemon=True)
            self._worker.start()

    def stop_crawl(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self.politeness.stop()
            self.frontier.close()

    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def generate_answer(self, query: str) -> str:
        hits = self.vector_store.search(query, 5)
        context = "".join(f"- {hit.document.content}\n" for hit in hits)
        prompt = build_prompt(query, context)
        return self.llm.generate(prompt)

    def _run_worker(self) -> None:
        while self.is_running():
            url_info = self.frontier.get_next_url(timeout=1.0)
            if not url_info:
                time.sleep(0.2)
                continue

            if not self.politeness.can_request(url_info.url):
                time.sleep(0.1)
                self.frontier.add_url(url_info.url, url_info.priority, url_info.depth)
                continue

            def handler(target_url: str) -> None:
                result = self.fetcher.fetch(target_url)
                self.storage.save(result)
                doc = Document(id=result.url, title=result.title, content=result.text)
                self.vector_store.add_documents([doc])
                with self._lock:
                    self.stats.pages_crawled += 1
                for idx, link in enumerate(result.links[:20]):
                    self.frontier.add_url(link, Priority.MEDIUM, url_info.depth + 1)

            def callback(target_url: str, error: Optional[Exception]) -> None:
                if error:
                    self.frontier.mark_failed(target_url, error)
                    with self._lock:
                        self.stats.last_error = str(error)
                else:
                    self.frontier.mark_completed(target_url)

            try:
                self.politeness.schedule_request(url_info.url, handler, callback)
            except Exception:
                self.frontier.mark_failed(url_info.url, RuntimeError("schedule failed"))

    def _load_existing_data(self) -> None:
        if not os.path.isdir(self.config.storage.data_dir):
            return
        documents = []
        for name in os.listdir(self.config.storage.data_dir):
            if not name.endswith(".json"):
                continue
            path = os.path.join(self.config.storage.data_dir, name)
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    payload = json.load(handle)
                result = FetchResult(**payload)
                documents.append(Document(id=result.url, title=result.title, content=result.text))
            except Exception:
                continue
        if documents:
            self.vector_store.add_documents(documents)


def _build_provider(config: Config) -> LLMProvider:
    provider = config.llm.provider.lower()
    if provider == "openai":
        return OpenAIProvider(config.llm.base_url, config.llm.model, config.llm.api_key)
    return OllamaProvider(config.llm.base_url, config.llm.model)
