from __future__ import annotations

from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import List
from urllib.parse import urljoin, urlparse

import requests


@dataclass
class FetchResult:
    url: str
    title: str = ""
    text: str = ""
    links: List[str] = field(default_factory=list)
    status_code: int = 0


class _HTMLExtractor(HTMLParser):
    def __init__(self, base_url: str) -> None:
        super().__init__()
        self.base_url = base_url
        self.in_script = False
        self.in_style = False
        self.in_title = False
        self.text_chunks: List[str] = []
        self.title: str = ""
        self.links: List[str] = []

    def handle_starttag(self, tag: str, attrs: List[tuple]) -> None:
        if tag == "script":
            self.in_script = True
        elif tag == "style":
            self.in_style = True
        elif tag == "title":
            self.in_title = True
        elif tag == "a":
            for key, value in attrs:
                if key == "href" and value:
                    cleaned = clean_link(value, self.base_url)
                    if cleaned:
                        self.links.append(cleaned)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script":
            self.in_script = False
        elif tag == "style":
            self.in_style = False
        elif tag == "title":
            self.in_title = False

    def handle_data(self, data: str) -> None:
        if self.in_title:
            self.title += data
        if not self.in_script and not self.in_style:
            text = data.strip()
            if text:
                self.text_chunks.append(text)

    def get_text(self) -> str:
        return clean_text(" ".join(self.text_chunks))


class Fetcher:
    def __init__(self, timeout: float, user_agent: str) -> None:
        self.timeout = timeout
        self.user_agent = user_agent
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.user_agent})

    def fetch(self, url: str) -> FetchResult:
        response = self.session.get(url, timeout=self.timeout)
        result = FetchResult(url=url, status_code=response.status_code)
        if response.status_code != 200:
            raise RuntimeError(f"received non-200 status code: {response.status_code}")

        extractor = _HTMLExtractor(url)
        extractor.feed(response.text)
        result.title = extractor.title.strip()
        result.text = extractor.get_text()
        result.links = extractor.links
        return result


def clean_text(text: str) -> str:
    return " ".join(text.split())


def clean_link(href: str, base_url: str) -> str:
    href = href.strip()
    if not href or href.startswith("#") or href.startswith("javascript:"):
        return ""
    if href.startswith("http"):
        return href
    parsed = urlparse(base_url)
    if not parsed.scheme or not parsed.netloc:
        return ""
    return urljoin(base_url, href)
