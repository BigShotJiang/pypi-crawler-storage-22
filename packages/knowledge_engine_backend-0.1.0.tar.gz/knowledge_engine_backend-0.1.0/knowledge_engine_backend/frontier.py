from __future__ import annotations

import hashlib
import time
from collections import deque
from dataclasses import dataclass, field
from enum import IntEnum
from threading import Condition, RLock
from typing import Deque, Dict, Optional
from urllib.parse import urlparse, urlunparse

from .config import FrontierConfig


class Priority(IntEnum):
    LOW = 0
    MEDIUM = 1
    HIGH = 2
    CRITICAL = 3


@dataclass
class URLInfo:
    url: str
    priority: Priority
    depth: int
    added_at: float
    last_attempt: float = 0.0
    retry_count: int = 0
    domain: str = ""
    hash: str = ""


@dataclass
class FrontierStats:
    total_added: int = 0
    total_processed: int = 0
    total_failed: int = 0
    current_queued: int = 0
    last_updated: float = field(default_factory=time.time)


class URLFrontier:
    def __init__(self, config: FrontierConfig) -> None:
        self.config = config
        self._lock = RLock()
        self._condition = Condition(self._lock)
        self._priority_queues: Dict[Priority, Deque[URLInfo]] = {
            Priority.LOW: deque(),
            Priority.MEDIUM: deque(),
            Priority.HIGH: deque(),
            Priority.CRITICAL: deque(),
        }
        self._url_map: Dict[str, URLInfo] = {}
        self.stats = FrontierStats()
        self._stopped = False

    def start(self) -> None:
        return

    def close(self) -> None:
        with self._condition:
            self._stopped = True
            self._condition.notify_all()

    def add_url(self, raw_url: str, priority: Priority, depth: int) -> None:
        normalized = self._normalize_url(raw_url)
        if not normalized:
            return

        with self._condition:
            if normalized in self._url_map:
                existing = self._url_map[normalized]
                if priority > existing.priority:
                    existing.priority = priority
                return

            if len(self._url_map) >= self.config.max_urls_in_memory:
                return

            url_info = URLInfo(
                url=normalized,
                priority=priority,
                depth=depth,
                added_at=time.time(),
                domain=self._extract_domain(normalized),
                hash=self._hash_url(normalized),
            )
            self._url_map[normalized] = url_info
            self._priority_queues[priority].append(url_info)
            self._update_stats(total_added=1, current_queued=1)
            self._condition.notify()

    def get_next_url(self, timeout: Optional[float] = None) -> Optional[URLInfo]:
        with self._condition:
            if not self._wait_for_url(timeout):
                return None

            for priority in (Priority.CRITICAL, Priority.HIGH, Priority.MEDIUM, Priority.LOW):
                queue = self._priority_queues[priority]
                if queue:
                    info = queue.popleft()
                    self._update_stats(total_processed=1)
                    return info
            return None

    def mark_completed(self, url: str) -> None:
        with self._condition:
            if url in self._url_map:
                del self._url_map[url]
                self._update_stats(current_queued=-1)

    def mark_failed(self, url: str, error: Exception) -> None:
        with self._condition:
            if url not in self._url_map:
                return
            info = self._url_map[url]
            info.retry_count += 1
            info.last_attempt = time.time()
            if info.retry_count >= self.config.max_retries:
                del self._url_map[url]
                self._update_stats(total_failed=1, current_queued=-1)
                return
            if info.priority > Priority.LOW:
                info.priority = Priority(info.priority - 1)
            self._priority_queues[info.priority].append(info)
            self._condition.notify()

    def _wait_for_url(self, timeout: Optional[float]) -> bool:
        if self._stopped:
            return False
        if self._has_urls():
            return True
        self._condition.wait(timeout=timeout)
        return self._has_urls()

    def _has_urls(self) -> bool:
        return any(queue for queue in self._priority_queues.values())

    def _update_stats(self, total_added: int = 0, total_processed: int = 0, total_failed: int = 0, current_queued: int = 0) -> None:
        self.stats.total_added += total_added
        self.stats.total_processed += total_processed
        self.stats.total_failed += total_failed
        self.stats.current_queued += current_queued
        self.stats.last_updated = time.time()

    def _normalize_url(self, raw_url: str) -> Optional[str]:
        parsed = urlparse(raw_url)
        if not parsed.scheme or not parsed.netloc:
            return None
        cleaned = parsed._replace(fragment="")
        return urlunparse(cleaned)

    def _extract_domain(self, raw_url: str) -> str:
        parsed = urlparse(raw_url)
        return parsed.netloc

    def _hash_url(self, raw_url: str) -> str:
        return hashlib.md5(raw_url.encode("utf-8")).hexdigest()
