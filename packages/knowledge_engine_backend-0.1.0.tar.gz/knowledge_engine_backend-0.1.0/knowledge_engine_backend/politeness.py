from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, Optional
from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

from .config import PolitenessConfig


@dataclass
class RequestItem:
    url: str
    handler: Callable[[str], None]
    callback: Callable[[str, Optional[Exception]], None]
    created_at: float = field(default_factory=time.time)


@dataclass
class DomainState:
    domain: str
    last_request_time: float = 0.0
    active_requests: int = 0
    max_concurrency: int = 1
    min_delay: float = 1.0
    lock: threading.Lock = field(default_factory=threading.Lock)


class PolitenessManager:
    def __init__(self, config: PolitenessConfig) -> None:
        self.config = config
        self.domain_states: Dict[str, DomainState] = {}
        self.robots_cache: Dict[str, tuple[RobotFileParser, float]] = {}
        self.request_queue: queue.Queue[RequestItem] = queue.Queue(maxsize=config.request_queue_size)
        self.running = False
        self._worker: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def start(self) -> None:
        with self._lock:
            if self.running:
                return
            self.running = True
            self._worker = threading.Thread(target=self._process_requests, daemon=True)
            self._worker.start()

    def stop(self) -> None:
        with self._lock:
            self.running = False
        if self._worker:
            self._worker.join(timeout=2)

    def can_request(self, raw_url: str) -> bool:
        parsed = urlparse(raw_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return False
        if not self.running:
            return False
        state = self._get_domain_state(parsed.netloc)
        with state.lock:
            if state.active_requests >= state.max_concurrency:
                return False
            if time.time() - state.last_request_time < state.min_delay:
                return False
        if self.config.enable_robots_check:
            return self.is_url_allowed(raw_url)
        return True

    def schedule_request(self, raw_url: str, handler: Callable[[str], None], callback: Callable[[str, Optional[Exception]], None]) -> None:
        if not self.running:
            raise RuntimeError("politeness manager is not running")
        item = RequestItem(url=raw_url, handler=handler, callback=callback)
        try:
            self.request_queue.put(item, timeout=1)
        except queue.Full as exc:
            raise RuntimeError(f"request queue is full for URL: {raw_url}") from exc

    def is_url_allowed(self, raw_url: str) -> bool:
        parsed = urlparse(raw_url)
        if not parsed.netloc:
            return False
        parser, _ = self._get_robots_parser(parsed.netloc, parsed.scheme)
        return parser.can_fetch(self.config.user_agent, raw_url)

    def _get_domain_state(self, domain: str) -> DomainState:
        if domain not in self.domain_states:
            self.domain_states[domain] = DomainState(
                domain=domain,
                max_concurrency=self.config.default_domain_concurrency,
                min_delay=self.config.default_min_delay,
            )
        return self.domain_states[domain]

    def _get_robots_parser(self, domain: str, scheme: str) -> tuple[RobotFileParser, float]:
        now = time.time()
        cached = self.robots_cache.get(domain)
        if cached and now - cached[1] < self.config.robots_cache_duration:
            return cached
        parser = RobotFileParser()
        parser.set_url(f"{scheme}://{domain}/robots.txt")
        try:
            parser.read()
        except Exception:
            parser = RobotFileParser()
            parser.parse("User-agent: *\nAllow: /".splitlines())
        self.robots_cache[domain] = (parser, now)
        return parser, now

    def _process_requests(self) -> None:
        while self.running:
            try:
                item = self.request_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if not self.running:
                break

            parsed = urlparse(item.url)
            state = self._get_domain_state(parsed.netloc)

            while self.running:
                with state.lock:
                    now = time.time()
                    delay = state.min_delay - (now - state.last_request_time)
                    if state.active_requests < state.max_concurrency and delay <= 0:
                        state.active_requests += 1
                        state.last_request_time = now
                        break
                time.sleep(max(delay, 0.05))

            error: Optional[Exception] = None
            try:
                item.handler(item.url)
            except Exception as exc:
                error = exc
            finally:
                with state.lock:
                    state.active_requests = max(0, state.active_requests - 1)
                try:
                    item.callback(item.url, error)
                except Exception:
                    pass
                self.request_queue.task_done()
