from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Protocol

import requests


def build_prompt(query: str, context: str) -> str:
    if not context:
        context = "No specific context available."
    return (
        "You are a professional AI assistant. Use the provided context to answer the user question.\n"
        "If the context is insufficient, state that clearly but provide the best possible response.\n\n"
        f"CONTEXT:\n{context}\n\nUSER QUESTION:\n{query}\n\nRESPONSE:\n"
    )


class LLMProvider(Protocol):
    def generate(self, prompt: str) -> str: ...

    def name(self) -> str: ...


@dataclass
class OllamaProvider:
    base_url: str
    model: str

    def __post_init__(self) -> None:
        if not self.base_url:
            self.base_url = "http://localhost:11434/api/generate"

    def name(self) -> str:
        return "ollama"

    def generate(self, prompt: str) -> str:
        payload = {"model": self.model, "prompt": prompt, "stream": False}
        response = requests.post(self.base_url, json=payload, timeout=60)
        if response.status_code != 200:
            raise RuntimeError(f"ollama returned status: {response.status_code}")
        data = response.json()
        return data.get("response", "")


@dataclass
class OpenAIProvider:
    base_url: str
    model: str
    api_key: str

    def __post_init__(self) -> None:
        if not self.base_url:
            self.base_url = "https://api.openai.com/v1/chat/completions"

    def name(self) -> str:
        return "openai"

    def generate(self, prompt: str) -> str:
        payload = {"model": self.model, "messages": [{"role": "user", "content": prompt}]}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        response = requests.post(self.base_url, headers=headers, data=json.dumps(payload), timeout=60)
        if response.status_code != 200:
            raise RuntimeError(f"openai returned status: {response.status_code}")
        data = response.json()
        choices = data.get("choices", [])
        if not choices:
            raise RuntimeError("no choices returned from openai")
        return choices[0]["message"]["content"]
