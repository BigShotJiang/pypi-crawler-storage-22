from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Document:
    id: str
    content: str
    title: str = ""
    vector: List[float] = field(default_factory=list)


def tokenize(text: str) -> List[str]:
    tokens = re.split(r"[^\w]+", text.lower())
    return [token for token in tokens if len(token) > 2]


class TFIDFVectorizer:
    def __init__(self) -> None:
        self.vocabulary: Dict[str, int] = {}
        self.idf: Dict[str, float] = {}

    def fit(self, docs: List[str]) -> None:
        doc_count = float(len(docs))
        word_doc_counts: Dict[str, int] = {}

        for doc in docs:
            tokens = tokenize(doc)
            seen_in_doc = set()
            for token in tokens:
                if token not in seen_in_doc:
                    word_doc_counts[token] = word_doc_counts.get(token, 0) + 1
                    seen_in_doc.add(token)
                if token not in self.vocabulary:
                    self.vocabulary[token] = len(self.vocabulary)

        for word, count in word_doc_counts.items():
            self.idf[word] = math.log(doc_count / (count + 1)) + 1

    def transform(self, text: str) -> List[float]:
        vector = [0.0 for _ in range(len(self.vocabulary))]
        tokens = tokenize(text)
        if not tokens:
            return vector

        tf: Dict[str, float] = {}
        for token in tokens:
            tf[token] = tf.get(token, 0.0) + 1.0

        for token, count in tf.items():
            if token in self.vocabulary:
                idx = self.vocabulary[token]
                idf = self.idf.get(token, 0.0)
                vector[idx] = (count / float(len(tokens))) * idf

        return vector


@dataclass
class SearchResult:
    document: Document
    score: float


class VectorStore:
    def __init__(self) -> None:
        self.documents: List[Document] = []
        self.vectorizer = TFIDFVectorizer()

    def add_documents(self, docs: List[Document]) -> None:
        raw_texts = [doc.content for doc in docs]
        if not raw_texts:
            return
        self.vectorizer.fit(raw_texts)
        for doc in docs:
            doc.vector = self.vectorizer.transform(doc.content)
            self.documents.append(doc)

    def search(self, query: str, top_k: int) -> List[SearchResult]:
        query_vector = self.vectorizer.transform(query)
        results: List[SearchResult] = []
        for doc in self.documents:
            score = cosine_similarity(query_vector, doc.vector)
            if score > 0:
                results.append(SearchResult(document=doc, score=score))

        results.sort(key=lambda item: item.score, reverse=True)
        return results[:top_k]


def cosine_similarity(a: List[float], b: List[float]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)
