from __future__ import annotations

import json
import os
import threading
from dataclasses import asdict
from typing import Optional

from .fetcher import FetchResult


class FileStorage:
    def __init__(self, base_dir: str) -> None:
        self.base_dir = base_dir
        self._lock = threading.RLock()
        os.makedirs(self.base_dir, exist_ok=True)

    def save(self, result: FetchResult) -> None:
        filename = safe_filename(result.url)
        path = os.path.join(self.base_dir, filename)
        data = json.dumps(asdict(result), indent=2)
        with self._lock:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(data)

    def get(self, url: str) -> Optional[FetchResult]:
        filename = safe_filename(url)
        path = os.path.join(self.base_dir, filename)
        if not os.path.exists(path):
            return None
        with self._lock:
            with open(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
        return FetchResult(**payload)


def safe_filename(raw_url: str) -> str:
    safe = "".join(ch if ch.isalnum() else "_" for ch in raw_url)
    safe = safe[:100]
    return f"{safe}.json"
