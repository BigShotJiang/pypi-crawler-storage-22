from __future__ import annotations

import os
import re
from dataclasses import dataclass


def get_env(key: str, default: str) -> str:
    value = os.getenv(key)
    if value is not None and value != "":
        return value
    return default


def get_int_env(key: str, default: int) -> int:
    value = os.getenv(key)
    if value:
        try:
            return int(value)
        except ValueError:
            return default
    return default


def get_bool_env(key: str, default: bool) -> bool:
    value = os.getenv(key)
    if value:
        return value.lower() in {"1", "true", "yes", "y"}
    return default


def parse_duration(value: str, default_seconds: float) -> float:
    if not value:
        return default_seconds
    match = re.match(r"^(\d+(?:\.\d+)?)(ms|s|m|h)$", value.strip())
    if not match:
        return default_seconds
    amount = float(match.group(1))
    unit = match.group(2)
    if unit == "ms":
        return amount / 1000.0
    if unit == "s":
        return amount
    if unit == "m":
        return amount * 60.0
    if unit == "h":
        return amount * 3600.0
    return default_seconds


@dataclass
class DurationValue:
    seconds: float

    @classmethod
    def from_env(cls, key: str, default_seconds: float) -> "DurationValue":
        return cls(parse_duration(os.getenv(key, ""), default_seconds))

    def to_seconds(self) -> float:
        return self.seconds
