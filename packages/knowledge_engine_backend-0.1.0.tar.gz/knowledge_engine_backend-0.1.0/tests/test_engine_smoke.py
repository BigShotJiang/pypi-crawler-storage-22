from knowledge_engine_backend.config import load_config
from knowledge_engine_backend.engine import KnowledgeEngine


def test_engine_initializes():
    engine = KnowledgeEngine.from_config(load_config())
    assert engine.vector_store is not None
