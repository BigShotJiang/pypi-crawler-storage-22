from knowledge_engine_backend.config import FrontierConfig
from knowledge_engine_backend.frontier import Priority, URLFrontier


def test_frontier_add_and_get():
    config = FrontierConfig(
        max_urls_in_memory=100,
        max_retries=2,
        default_priority=1,
        cleanup_interval=300,
        politeness_delay=1,
        max_concurrency=10,
        enable_persistence=True,
    )
    frontier = URLFrontier(config)
    frontier.add_url("https://example.com", Priority.MEDIUM, 0)
    info = frontier.get_next_url(timeout=0.1)
    assert info is not None
    assert info.url == "https://example.com"
