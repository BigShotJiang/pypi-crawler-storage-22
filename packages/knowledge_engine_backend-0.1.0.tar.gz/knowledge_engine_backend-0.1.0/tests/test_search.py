from knowledge_engine_backend.search import Document, VectorStore, tokenize


def test_tokenize_filters_short_words():
    tokens = tokenize("Go is great for AI")
    assert "go" not in tokens
    assert "great" in tokens


def test_vector_store_search_returns_results():
    store = VectorStore()
    docs = [
        Document(id="a", content="golang concurrency patterns"),
        Document(id="b", content="python async await"),
    ]
    store.add_documents(docs)
    results = store.search("golang", 1)
    assert results
    assert results[0].document.id == "a"
