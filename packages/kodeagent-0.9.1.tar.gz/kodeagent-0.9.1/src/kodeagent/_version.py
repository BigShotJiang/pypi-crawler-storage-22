"""Single-source package version for KodeAgent.

Update the __version__ string here BEFORE making a release on GitHub.
"""

# patch: Bug fixes only, no new features
# minor: New features, backward compatible
# major: Breaking changes, API changes

__version__ = '0.9.1'
