"""Database schema enrichments."""
