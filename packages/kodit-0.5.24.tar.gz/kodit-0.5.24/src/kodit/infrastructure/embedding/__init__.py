"""Embedding infrastructure module."""
