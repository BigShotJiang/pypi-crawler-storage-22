"""Physical architecture discovery infrastructure."""
