"""Test the project."""
