"""Home for all Blueprint classes."""

from .file_storage_blueprint import FileStorageBlueprint

__all__ = ["FileStorageBlueprint"]
