"""Czech G2P module for kokorog2p."""

from kokorog2p.cs.g2p import CzechG2P

__all__ = ["CzechG2P"]
