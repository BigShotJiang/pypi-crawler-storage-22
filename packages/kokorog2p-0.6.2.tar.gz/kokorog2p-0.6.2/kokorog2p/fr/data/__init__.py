"""French G2P data package."""
