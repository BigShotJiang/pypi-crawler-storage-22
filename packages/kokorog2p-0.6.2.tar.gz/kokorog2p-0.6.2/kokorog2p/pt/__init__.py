"""Brazilian Portuguese G2P module for kokorog2p."""

from kokorog2p.pt.g2p import PortugueseG2P

__all__ = ["PortugueseG2P"]
