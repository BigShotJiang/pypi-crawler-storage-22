"""German G2P data package."""
