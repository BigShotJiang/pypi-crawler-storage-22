"""Japanese (ja) G2P module for kokorog2p.

Based on misaki's Japanese implementation.
"""

from kokorog2p.ja.g2p import JapaneseG2P

__all__ = ["JapaneseG2P"]
