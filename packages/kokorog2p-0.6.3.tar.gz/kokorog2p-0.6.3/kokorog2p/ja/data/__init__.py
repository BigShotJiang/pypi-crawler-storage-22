"""Japanese data package for kokorog2p."""
