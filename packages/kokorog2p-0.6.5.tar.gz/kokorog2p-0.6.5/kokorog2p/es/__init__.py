"""Spanish G2P module."""

from kokorog2p.es.g2p import SpanishG2P

__all__ = ["SpanishG2P"]
