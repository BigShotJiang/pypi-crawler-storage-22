"""Italian language data module."""
