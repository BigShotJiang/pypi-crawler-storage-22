"""Korean G2P data files."""
