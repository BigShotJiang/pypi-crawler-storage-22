import argparse
import json
import sys

from kolmo.router import KolmoRouter


def load_config(path: str) -> dict:
    """Load configuration from a JSON file."""
    with open(path) as f:
        return json.load(f)


def cmd_train(args: argparse.Namespace) -> None:
    """Handle the 'train' command."""
    print(f"Loading config from {args.config}...")  # noqa: T201
    config = load_config(args.config)

    router = KolmoRouter(
        default_model=config.get("default_model", "gpt-4o-mini"),
        dict_size=config.get("dict_size", KolmoRouter.DEFAULT_DICT_SIZE),
        compression_level=config.get("compression_level", KolmoRouter.DEFAULT_COMPRESSION_LEVEL),
    )

    domains = config.get("domains", [])
    for d in domains:
        name = d.get("name")
        source = d.get("source")
        target_model = d.get("target_model")
        samples = d.get("samples")
        dict_bytes = d.get("dict_bytes")
        sample_count = d.get("sample_count", 1000)
        dict_size = d.get("dict_size")

        print(f"Adding domain '{name}'...")  # noqa: T201
        router.add_domain(
            name=name,
            source=source,
            target_model=target_model,
            samples=samples,
            dict_bytes=dict_bytes,
            sample_count=sample_count,
            dict_size=dict_size,
        )

    print(f"Saving bundle to {args.output}...")  # noqa: T201
    router.save_bundle(args.output)
    print("Done!")  # noqa: T201


def cmd_route(args: argparse.Namespace) -> None:
    """Handle the 'route' command."""
    router = KolmoRouter.load_bundle(args.bundle)
    prompt = args.prompt
    if not prompt and not sys.stdin.isatty():
        prompt = sys.stdin.read()

    if not prompt:
        print("Error: No prompt provided.")  # noqa: T201
        sys.exit(1)

    result = router.route(prompt)
    print(json.dumps(result.model_dump(), indent=2))  # noqa: T201


def cmd_info(args: argparse.Namespace) -> None:
    """Handle the 'info' command."""
    router = KolmoRouter.load_bundle(args.bundle)
    info = {
        "version": router.VERSION,
        "default_model": router.default_model,
        "dict_size": router.dict_size,
        "compression_level": router.compression_level,
        "domains": {name: config.model_dump() for name, config in router.domains.items()},
        "mapping": router.mapping,
    }
    print(json.dumps(info, indent=2))  # noqa: T201


def main() -> None:
    """Kolmo CLI entry point."""
    parser = argparse.ArgumentParser(prog="kolmo", description="Kolmo CLI - LLM Routing Tool")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Train command
    train_parser = subparsers.add_parser("train", help="Train a bundle from config")
    train_parser.add_argument("config", help="Path to JSON config file")
    train_parser.add_argument("output", help="Path to save the .kolmo bundle")

    # Route command
    route_parser = subparsers.add_parser("route", help="Route a prompt using a bundle")
    route_parser.add_argument("bundle", help="Path to .kolmo bundle")
    route_parser.add_argument("prompt", nargs="?", help="Prompt string (or via stdin)")

    # Info command
    info_parser = subparsers.add_parser("info", help="Show info about a bundle")
    info_parser.add_argument("bundle", help="Path to .kolmo bundle")

    args = parser.parse_args()

    if args.command == "train":
        cmd_train(args)
    elif args.command == "route":
        cmd_route(args)
    elif args.command == "info":
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
