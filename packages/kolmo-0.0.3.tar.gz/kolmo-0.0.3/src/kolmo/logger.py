from loguru import logger

kolmo_logger = logger.bind(name="kolmo")
