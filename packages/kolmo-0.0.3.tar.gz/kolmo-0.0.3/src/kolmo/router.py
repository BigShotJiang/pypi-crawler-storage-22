import io
import json
import tarfile
import zlib
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

import zstandard as zstd
from pydantic import BaseModel

from kolmo.logger import kolmo_logger


class KolmoError(Exception):
    """Base exception for Kolmo errors."""


class BundleCorruptionError(KolmoError):
    """Raised when a bundle is corrupted or version mismatched."""


class TrainingError(KolmoError):
    """Raised when training fails."""


class DomainConfig(BaseModel):
    """Configuration for a domain."""

    name: str
    target_model: str | None = None
    description: str | None = None
    checksum: str | None = None
    dict_size: int | None = None
    compression_level: int | None = None  # Inherited from router for info


class RoutingResult(BaseModel):
    """Result of routing a prompt."""

    winner: str
    target_model: str
    scores: dict[str, float]
    latency_ms: float
    confidence: float


class ThresholdedRoutingResult(RoutingResult):
    """Result of routing with ambiguity detection."""

    candidates: list[str]
    ambiguous: bool
    reason: str | None = None


class RoutingMetrics(BaseModel):
    """Metrics emitted for each routing decision."""

    prompt_bytes: int
    latency_ms: float
    winner: str
    scores: dict[str, float]
    confidence: float
    top_score: float | None = None
    runner_up_score: float | None = None
    ncd_gap: float | None = None


class BatchRoutingResult(BaseModel):
    """Result of routing a batch of prompts."""

    results: list[RoutingResult]
    total_latency_ms: float
    avg_latency_ms: float
    throughput_rps: float
    min_latency_ms: float
    max_latency_ms: float


MetricsHook = Callable[[RoutingMetrics], None]


class KolmoRouter:
    """Router for LLM requests based on NCD compression."""

    MIN_INPUT_BYTES = 10
    DEFAULT_DICT_SIZE = 112_640
    DEFAULT_COMPRESSION_LEVEL = 3
    VERSION = "0.0.3"

    def __init__(
        self,
        default_model: str = "gpt-4o-mini",
        dict_size: int = DEFAULT_DICT_SIZE,
        compression_level: int = DEFAULT_COMPRESSION_LEVEL,
        metrics_hooks: Sequence[MetricsHook] | None = None,
    ) -> None:
        if dict_size <= 0:
            msg = "dict_size must be positive"
            raise ValueError(msg)
        if compression_level <= 0:
            msg = "compression_level must be positive"
            raise ValueError(msg)

        self.default_model = default_model
        self.dict_size = dict_size
        self.compression_level = compression_level
        self.domains: dict[str, DomainConfig] = {}
        self._dictionaries: dict[str, bytes] = {}
        self._compressors: dict[str, zstd.ZstdCompressor] = {}
        self._null_compressors: dict[int, zstd.ZstdCompressor] = {}
        self._compressed_dict_sizes: dict[str, int] = {}
        self.mapping: dict[str, str] = {}
        self._metrics_hooks: list[MetricsHook] = list(metrics_hooks) if metrics_hooks else []

    def _get_null_compressor(self, level: int) -> zstd.ZstdCompressor:
        if level not in self._null_compressors:
            self._null_compressors[level] = zstd.ZstdCompressor(level=level)
        return self._null_compressors[level]

    def add_metrics_hook(self, hook: MetricsHook) -> None:
        """Register a metrics hook called after each routing decision."""
        self._metrics_hooks.append(hook)

    def add_domain(
        self,
        name: str | DomainConfig,
        source: Any = None,
        target_model: str | None = None,
        samples: Sequence[bytes | str] | None = None,
        dict_bytes: bytes | None = None,
        sample_count: int = 1000,
        dict_size: int | None = None,
    ) -> None:
        """Add a domain.

        Source can be:
        - "huggingface:dataset_name" (optionally with /config)
        - "file:path/to/file.txt"
        - bytes (interpreted as pre-trained dictionary if dict_bytes is None)

        Alternatively, provide 'samples' to train a new dictionary
        or 'dict_bytes' to use an existing one.
        """
        # Support config object as first argument
        if isinstance(name, DomainConfig):
            config = name
            name = config.name
            if config.target_model and target_model is None:
                target_model = config.target_model

        kolmo_logger.info(f"Adding domain: {name}...")
        train_data = b""
        trained_from_samples = False

        effective_dict_size = dict_size if dict_size is not None else self.dict_size

        if dict_bytes:
            train_data = dict_bytes
        elif samples:
            train_data = self._train_from_samples(samples, dict_size=effective_dict_size)
            trained_from_samples = True
        elif isinstance(source, bytes):
            # If source is raw bytes, we treat it as a pre-trained dictionary
            train_data = source
        elif isinstance(source, str):
            if source.startswith("huggingface:"):
                train_data = self._load_hf_source(source, sample_count, dict_size=effective_dict_size)
                trained_from_samples = True
            elif source.startswith("file:"):
                train_data, trained_from_samples = self._load_file_source(source)
            else:
                msg = f"Unknown source format: {source}"
                raise TrainingError(msg)
        else:
            msg = "Either source, samples, or dict_bytes must be provided"
            raise TrainingError(msg)

        if not train_data:
            msg = f"Failed to acquire dictionary data for domain {name}"
            raise TrainingError(msg)

        checksum = format(zlib.crc32(train_data) & 0xFFFFFFFF, "08x")
        dict_size_value = effective_dict_size if trained_from_samples else len(train_data)
        config = DomainConfig(
            name=name,
            target_model=target_model,
            checksum=checksum,
            dict_size=dict_size_value,
            compression_level=self.compression_level,  # Inherited from router
        )

        self.domains[name] = config
        self._dictionaries[name] = train_data
        try:
            null_comp = self._get_null_compressor(self.compression_level)
            self._compressed_dict_sizes[name] = len(null_comp.compress(train_data))
            self._compressors[name] = zstd.ZstdCompressor(
                level=self.compression_level,
                dict_data=zstd.ZstdCompressionDict(train_data),
            )
        except zstd.ZstdError as e:
            msg = f"Failed to initialize compressor for {name}: {e}"
            raise TrainingError(msg) from e

        if target_model:
            self.mapping[name] = target_model

    def export_dictionaries(self, output_dir: str | Path) -> dict[str, str]:
        """Export trained dictionaries to an output directory."""
        base = Path(output_dir)
        base.mkdir(parents=True, exist_ok=True)
        outputs: dict[str, str] = {}
        for name, dict_bytes in self._dictionaries.items():
            dict_path = base / f"{name}.dict"
            dict_path.write_bytes(dict_bytes)
            outputs[name] = str(dict_path)
        return outputs

    def _train_from_samples(self, samples: Sequence[bytes | str], dict_size: int | None = None) -> bytes:
        processed_samples = [s.encode() if isinstance(s, str) else s for s in samples]
        total_bytes = sum(len(s) for s in processed_samples)
        dict_size = dict_size or self.dict_size

        if dict_size > total_bytes and total_bytes > 0:
            # Adjust dict_size to match total_bytes with a floor of 1024 if total_bytes allows
            new_size = max(1024, total_bytes) if total_bytes >= 1024 else total_bytes
            if new_size != dict_size:
                kolmo_logger.warning(
                    f"Adjusting dict_size from {dict_size} to {new_size} "
                    f"because total sample size ({total_bytes} bytes) is too small."
                )
                dict_size = new_size

        if dict_size <= 0:
            msg = "dict_size must be positive"
            raise ValueError(msg)
        try:
            return zstd.train_dictionary(dict_size, processed_samples).as_bytes()
        except zstd.ZstdError as e:
            msg = f"Dictionary training failed: {e}"
            raise TrainingError(msg) from e

    def _load_hf_source(self, source: str, sample_count: int, dict_size: int | None = None) -> bytes:
        path_str = source.replace("huggingface:", "")
        # Handle "dataset/config" vs "user/dataset"
        parts = path_str.split("/")
        ds_path = parts[0]
        ds_config = None

        if len(parts) == 2:
            # Ambiguous: could be user/repo or repo/config
            # We try to load it as a whole first
            ds_path = "/".join(parts)
        elif len(parts) > 2:
            # Likely user/repo/config
            ds_path = "/".join(parts[:-1])
            ds_config = parts[-1]

        kolmo_logger.debug(f"Loading HF dataset: {ds_path} (config: {ds_config})")
        try:
            try:
                from datasets import load_dataset
            except ImportError as exc:
                msg = "HuggingFace datasets is not installed. Install with `pip install kolmo[hf]`."
                raise TrainingError(msg) from exc

            ds = load_dataset(ds_path, ds_config, split="train", streaming=True)
            samples = []
            for entry in ds.take(sample_count):
                # Robust column detection
                text = (
                    entry.get("text")
                    or entry.get("content")
                    or entry.get("code")
                    or entry.get("body")
                    or next(iter(entry.values()))
                )
                if text:
                    samples.append(text.encode() if isinstance(text, str) else text)

            if not samples:
                msg = f"No text content found in HF dataset {ds_path}"
                raise TrainingError(msg)

            return self._train_from_samples(samples, dict_size=dict_size)
        except TrainingError:
            raise
        except Exception as e:
            msg = f"Failed to load HF dataset {path_str}: {e}"
            raise TrainingError(msg) from e

    def _load_file_source(self, source: str) -> tuple[bytes, bool]:
        file_path = source.replace("file:", "")
        try:
            with open(file_path, "rb") as f:
                data = f.read()
            return data, False
        except Exception as e:
            msg = f"Failed to load file source {file_path}: {e}"
            raise TrainingError(msg) from e

    def set_map(self, mapping: dict[str, str]) -> None:
        """Set the mapping from domain names to models."""
        self.mapping.update(mapping)
        for name, model in mapping.items():
            if name in self.domains:
                self.domains[name].target_model = model

    @staticmethod
    def _rank_scores(scores: dict[str, float]) -> list[tuple[str, float]]:
        return sorted(scores.items(), key=lambda item: item[1])

    @staticmethod
    def _confidence_from_ranked(ranked: Sequence[tuple[str, float]]) -> float:
        if len(ranked) > 1:
            top_score = ranked[0][1]
            runner_up = ranked[1][1]
            confidence = (runner_up - top_score) / (runner_up + 1e-9)
            return max(0.0, min(1.0, confidence))
        return 1.0

    def _score_prompt(self, p_bytes: bytes) -> dict[str, float]:
        scores: dict[str, float] = {}
        null_comp = self._get_null_compressor(self.compression_level)
        for name, comp in self._compressors.items():
            # C(x): Compression of prompt without dictionary at router's level
            c_x = len(null_comp.compress(p_bytes))
            # C(a): Cached compressed size of the dictionary at router's level
            c_a = self._compressed_dict_sizes.get(name)
            if c_a is None:
                c_a = len(null_comp.compress(self._dictionaries[name]))
                self._compressed_dict_sizes[name] = c_a
            # C(x|a): Compression of prompt with dictionary
            c_x_given_a = len(comp.compress(p_bytes))
            # C(xa) approximation
            c_xa = c_a + c_x_given_a

            # NCD(x, a) = (C(xa) - min(C(x), C(a))) / max(C(x), C(a))
            ncd = (c_xa - min(c_x, c_a)) / max(c_x, c_a)
            scores[name] = ncd
        return scores

    def _emit_metrics(
        self,
        result: RoutingResult,
        prompt_bytes: int,
        ranked: Sequence[tuple[str, float]] | None,
    ) -> None:
        if not self._metrics_hooks:
            return

        top_score = ranked[0][1] if ranked else None
        runner_up_score = ranked[1][1] if ranked and len(ranked) > 1 else None
        ncd_gap = runner_up_score - top_score if runner_up_score is not None and top_score is not None else None

        metrics = RoutingMetrics(
            prompt_bytes=prompt_bytes,
            latency_ms=result.latency_ms,
            winner=result.winner,
            scores=result.scores,
            confidence=result.confidence,
            top_score=top_score,
            runner_up_score=runner_up_score,
            ncd_gap=ncd_gap,
        )

        for hook in self._metrics_hooks:
            self._safe_call_hook(hook, metrics)

    def _safe_call_hook(self, hook: MetricsHook, metrics: RoutingMetrics) -> None:
        try:
            hook(metrics)
        except Exception as exc:  # noqa: BLE001
            kolmo_logger.error(f"Metrics hook failed: {exc}")

    def route(self, prompt: str | bytes) -> RoutingResult:
        """Route a prompt to the best domain using NCD.

        Formula: NCD(x, a) = (C(xa) - min(C(x), C(a))) / max(C(x), C(a))
        where:
          x = prompt
          a = domain dictionary
          C(a) = compressed size of the dictionary
          C(x) = compressed size of x without dictionary
          C(xa) = C(a) + C(x|a) where C(x|a) is compressed size of x with dictionary a
        """
        import time

        start_time = time.perf_counter()

        p_bytes = prompt.encode() if isinstance(prompt, str) else prompt
        if not p_bytes:
            result = RoutingResult(
                winner="default",
                target_model=self.default_model,
                scores={},
                latency_ms=0,
                confidence=0,
            )
            self._emit_metrics(result, 0, ranked=None)
            return result

        # Check minimum input size to avoid NCD noise
        if len(p_bytes) < self.MIN_INPUT_BYTES:
            result = RoutingResult(
                winner="default",
                target_model=self.default_model,
                scores={},
                latency_ms=(time.perf_counter() - start_time) * 1000,
                confidence=0,
            )
            self._emit_metrics(result, len(p_bytes), ranked=None)
            return result

        try:
            scores = self._score_prompt(p_bytes)
        except zstd.ZstdError as e:
            kolmo_logger.error(f"Compression error during routing: {e}")
            raise KolmoError(f"Routing failed due to compression error: {e}") from e

        if not scores:
            result = RoutingResult(
                winner="default",
                target_model=self.default_model,
                scores={},
                latency_ms=(time.perf_counter() - start_time) * 1000,
                confidence=0,
            )
            self._emit_metrics(result, len(p_bytes), ranked=None)
            return result

        ranked = self._rank_scores(scores)
        winner = ranked[0][0]
        confidence = self._confidence_from_ranked(ranked)

        target_model = self.mapping.get(winner, self.default_model)

        result = RoutingResult(
            winner=winner,
            target_model=target_model,
            scores=scores,
            latency_ms=(time.perf_counter() - start_time) * 1000,
            confidence=confidence,
        )
        self._emit_metrics(result, len(p_bytes), ranked=ranked)
        return result

    def route_thresholded(
        self,
        prompt: str | bytes,
        *,
        min_confidence: float = 0.0,
        ambiguity_gap: float = 0.0,
        max_candidates: int = 3,
    ) -> ThresholdedRoutingResult:
        """Route with optional confidence and ambiguity thresholds."""
        if min_confidence < 0 or min_confidence > 1:
            msg = "min_confidence must be between 0 and 1"
            raise ValueError(msg)
        if ambiguity_gap < 0:
            msg = "ambiguity_gap must be non-negative"
            raise ValueError(msg)
        if max_candidates <= 0:
            msg = "max_candidates must be positive"
            raise ValueError(msg)

        p_bytes = prompt.encode() if isinstance(prompt, str) else prompt
        result = self.route(prompt)
        ranked = self._rank_scores(result.scores) if result.scores else []
        candidates: list[str] = []

        if ranked:
            best_score = ranked[0][1]
            for name, score in ranked:
                if score - best_score <= ambiguity_gap:
                    candidates.append(name)
                if len(candidates) >= max_candidates:
                    break

        ambiguous = False
        reason = None

        if not p_bytes or len(p_bytes) < self.MIN_INPUT_BYTES:
            ambiguous = True
            reason = "insufficient_input"
        elif not result.scores:
            ambiguous = True
            reason = "no_domains"
        elif result.confidence < min_confidence:
            ambiguous = True
            reason = "low_confidence"

        if len(ranked) > 1:
            gap = ranked[1][1] - ranked[0][1]
            if gap <= ambiguity_gap:
                ambiguous = True
                reason = reason or "within_band"

        return ThresholdedRoutingResult(
            winner=result.winner,
            target_model=result.target_model,
            scores=result.scores,
            latency_ms=result.latency_ms,
            confidence=result.confidence,
            candidates=candidates,
            ambiguous=ambiguous,
            reason=reason,
        )

    def route_many(self, prompts: Sequence[str | bytes]) -> BatchRoutingResult:
        """Route a batch of prompts and return aggregate stats."""
        import time

        start_time = time.perf_counter()
        results = [self.route(prompt) for prompt in prompts]
        total_ms = (time.perf_counter() - start_time) * 1000

        if results:
            latencies = [result.latency_ms for result in results]
            avg_latency = sum(latencies) / len(latencies)
            min_latency = min(latencies)
            max_latency = max(latencies)
        else:
            avg_latency = 0.0
            min_latency = 0.0
            max_latency = 0.0

        throughput = len(results) / (total_ms / 1000) if total_ms > 0 else 0.0

        return BatchRoutingResult(
            results=results,
            total_latency_ms=total_ms,
            avg_latency_ms=avg_latency,
            throughput_rps=throughput,
            min_latency_ms=min_latency,
            max_latency_ms=max_latency,
        )

    @staticmethod
    def train_domain(
        name: str,
        target_model: str | None,
        samples: list[bytes],
        dict_size: int = DEFAULT_DICT_SIZE,
    ) -> tuple[DomainConfig, bytes]:
        """Train a domain dictionary from sample data."""
        try:
            dict_bytes = zstd.train_dictionary(dict_size, samples).as_bytes()
            checksum = format(zlib.crc32(dict_bytes) & 0xFFFFFFFF, "08x")
            config = DomainConfig(
                name=name,
                target_model=target_model,
                checksum=checksum,
                dict_size=dict_size,
            )
            return (config, dict_bytes)
        except zstd.ZstdError as e:
            msg = f"Static training failed: {e}"
            raise TrainingError(msg) from e

    def save_bundle(self, path: str) -> None:
        """Save everything into a .kolmo bundle."""
        metadata = {
            "_kolmo_version": self.VERSION,
            "default_model": self.default_model,
            "default_dict_size": self.dict_size,
            "default_compression_level": self.compression_level,
            "mapping": self.mapping,
            "domains": {n: d.model_dump() for n, d in self.domains.items()},
        }

        with tarfile.open(path, "w:gz") as tar:
            # Save metadata
            meta_json = json.dumps(metadata).encode()
            info = tarfile.TarInfo("metadata.json")
            info.size = len(meta_json)
            tar.addfile(info, io.BytesIO(meta_json))

            # Save dictionaries
            for name, dict_bytes in self._dictionaries.items():
                info = tarfile.TarInfo(f"dicts/{name}.dict")
                info.size = len(dict_bytes)
                tar.addfile(info, io.BytesIO(dict_bytes))
        kolmo_logger.info(f"Bundle saved to {path}")

    @classmethod
    def load_bundle(cls, path: str) -> "KolmoRouter":
        """Load a router from a .kolmo bundle with strict validation."""
        try:
            with tarfile.open(path, "r:gz") as tar:
                # Load metadata
                meta_member = tar.getmember("metadata.json")
                meta_file = tar.extractfile(meta_member)
                if meta_file is None:
                    msg = "metadata.json not found in bundle"
                    raise BundleCorruptionError(msg)

                metadata = json.load(meta_file)

                # Version check
                version = metadata.get("_kolmo_version")
                if version != cls.VERSION:
                    msg = f"Bundle version mismatch: expected {cls.VERSION}, got {version}"
                    raise BundleCorruptionError(msg)

                default_model = metadata["default_model"]
                dict_size = metadata.get("default_dict_size", cls.DEFAULT_DICT_SIZE)
                compression_level = metadata.get("default_compression_level", cls.DEFAULT_COMPRESSION_LEVEL)

                router = cls(
                    default_model=default_model,
                    dict_size=dict_size,
                    compression_level=compression_level,
                )
                router.mapping = metadata.get("mapping", {})

                # Load domains and dictionaries
                domain_configs = metadata["domains"]
                for name, config_dict in domain_configs.items():
                    config = DomainConfig(**config_dict)
                    dict_path = f"dicts/{name}.dict"

                    try:
                        dict_member = tar.getmember(dict_path)
                        dict_file = tar.extractfile(dict_member)
                        if dict_file is None:
                            msg = f"Dictionary file missing: {dict_path}"
                            raise BundleCorruptionError(msg)
                        dict_bytes = dict_file.read()
                    except KeyError as e:
                        msg = f"Dictionary {name} listed in metadata but missing from bundle"
                        raise BundleCorruptionError(msg) from e

                    # Checksum validation
                    actual_checksum = format(zlib.crc32(dict_bytes) & 0xFFFFFFFF, "08x")
                    if config.checksum and actual_checksum != config.checksum:
                        msg = f"Checksum mismatch for domain {name}: expected {config.checksum}, got {actual_checksum}"
                        raise BundleCorruptionError(msg)

                    router.domains[name] = config
                    router._dictionaries[name] = dict_bytes
                    null_comp = router._get_null_compressor(router.compression_level)
                    router._compressed_dict_sizes[name] = len(null_comp.compress(dict_bytes))
                    router._compressors[name] = zstd.ZstdCompressor(
                        level=router.compression_level,
                        dict_data=zstd.ZstdCompressionDict(dict_bytes),
                    )

            kolmo_logger.info(f"Bundle loaded successfully from {path}")
            return router
        except (tarfile.TarError, json.JSONDecodeError) as e:
            msg = f"Failed to parse bundle: {e}"
            raise BundleCorruptionError(msg) from e
        except Exception as e:
            if isinstance(e, BundleCorruptionError):
                raise
            msg = f"Unexpected error loading bundle: {e}"
            raise BundleCorruptionError(msg) from e
