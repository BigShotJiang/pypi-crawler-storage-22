"""Test for aether architecture integration."""

import os

from kolmo.router import KolmoRouter


def test_aether_architecture(tmp_path: str) -> None:
    """Validate that the router correctly maps domains to models and persists state."""
    # 1. Initialize
    router = KolmoRouter(default_model="openai/gpt-4o-mini")

    # 2. Add Domains using samples (robust)
    coding_samples = [f"def function_{i}(): return {i}\n# comment {i}".encode() for i in range(200)]
    router.add_domain(
        "coding",
        samples=coding_samples,
        target_model="anthropic/claude-3-opus",
    )

    reasoning_samples = [f"Equation {i}: x + {i} = {i * 2}\nProof step {i}".encode() for i in range(200)]
    router.add_domain(
        "reasoning",
        samples=reasoning_samples,
        target_model="deepseek/deepseek-r1",
    )

    # 3. Test Routing
    p1 = """def solve_logic(x):
    total = 0
    for i in range(10):
        total += x * i
    return total
"""
    res1 = router.route(p1)

    p2 = "What is the value of x if x + 5 = 10?"
    _ = router.route(p2)  # Test routing for reasoning domain

    # 4. Save Bundle
    bundle_path = os.path.join(tmp_path, "prod_router.kolmo")
    router.save_bundle(bundle_path)

    # 5. Load in a fresh router
    new_router = KolmoRouter.load_bundle(bundle_path)
    res3 = new_router.route(p1)

    assert res1.winner == res3.winner
    assert res3.target_model == "anthropic/claude-3-opus"


if __name__ == "__main__":
    # If run directly, we need a tmp path
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        test_aether_architecture(tmp)
