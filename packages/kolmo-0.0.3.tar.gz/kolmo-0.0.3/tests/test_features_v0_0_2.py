from pathlib import Path

import pytest

from kolmo.router import KolmoRouter, RoutingMetrics


def test_public_api_knobs() -> None:
    """Test dictionary size and compression level knobs (global only)."""
    # Test router-level defaults
    router = KolmoRouter(dict_size=50000, compression_level=5)
    assert router.dict_size == 50000
    assert router.compression_level == 5

    # Per-domain compression_level overrides removed for NCD consistency
    samples = [f"data {i} ".encode() * 50 for i in range(20)]
    router.add_domain("d1", samples=samples, dict_size=10000)

    assert router.domains["d1"].dict_size == 10000
    assert router.domains["d1"].compression_level == 5  # inherits from router
    # Check that the actual dictionary size matches (roughly, zstd might adjust)
    assert len(router._dictionaries["d1"]) <= 10000


def test_thresholded_routing() -> None:
    """Test confidence thresholds and ambiguity bands."""
    router = KolmoRouter()

    # Domain A: Coding
    router.add_domain("coding", samples=[b"def function(): pass\n" * 50 for _ in range(20)])
    # Domain B: Similar Coding
    router.add_domain("coding_alt", samples=[b"async def function(): await pass\n" * 50 for _ in range(20)])

    prompt = "def my_func(): return 42"

    # Test min_confidence
    res = router.route_thresholded(prompt, min_confidence=0.9)
    # With very similar domains, confidence should be low
    if res.confidence < 0.9:
        assert res.ambiguous is True
        assert res.reason == "low_confidence"

    # Test ambiguity_gap
    # Force an ambiguity gap that should catch both
    res_gap = router.route_thresholded(prompt, ambiguity_gap=0.5)
    assert len(res_gap.candidates) > 1
    assert res_gap.ambiguous is True


def test_batch_routing() -> None:
    """Test route_many for high-throughput processing."""
    router = KolmoRouter()
    router.add_domain("test", samples=[b"test data " * 100 for _ in range(20)])

    prompts = ["test prompt 1", "test prompt 2", "test prompt 3"]
    batch_res = router.route_many(prompts)

    assert len(batch_res.results) == 3
    assert batch_res.total_latency_ms > 0
    assert batch_res.avg_latency_ms > 0
    assert batch_res.throughput_rps >= 0


def test_metrics_hooks() -> None:
    """Test pluggable logging/metrics hooks."""
    received_metrics = []

    def hook(m: RoutingMetrics) -> None:
        received_metrics.append(m)

    router = KolmoRouter(metrics_hooks=[hook])
    router.add_domain("test", samples=[b"test data " * 100 for _ in range(20)])

    router.route("some test prompt")

    assert len(received_metrics) == 1
    m = received_metrics[0]
    assert m.prompt_bytes > 0
    assert m.latency_ms >= 0
    assert m.winner == "test"
    assert "test" in m.scores


def test_bundle_v0_0_2_persistence(tmp_path: Path) -> None:
    """Test saving and loading bundles with new metadata."""
    bundle_path = tmp_path / "v0_0_2.kolmo"
    router = KolmoRouter(dict_size=60000, compression_level=2)
    # Per-domain compression_level removed for NCD consistency
    router.add_domain("test", samples=[b"data " * 100 for _ in range(20)])
    router.save_bundle(str(bundle_path))

    new_router = KolmoRouter.load_bundle(str(bundle_path))
    assert new_router.dict_size == 60000
    assert new_router.compression_level == 2
    assert new_router.domains["test"].compression_level == 2  # inherited


if __name__ == "__main__":
    pytest.main([__file__])
