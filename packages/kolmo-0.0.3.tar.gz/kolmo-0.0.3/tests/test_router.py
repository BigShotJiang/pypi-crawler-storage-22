"""Test for Kolmo router."""

import io
import json
import os
import tarfile

import pytest

from kolmo.router import BundleCorruptionError, KolmoRouter, TrainingError


def test_basic_routing() -> None:
    """Test routing with synthetic data to avoid HF flakiness."""
    router = KolmoRouter()

    # Domain 1: Python Code - more samples to satisfy zstd
    python_samples = [f"def func_{i}(x): return x * {i}\n# Some comment {i}".encode() for i in range(100)]
    router.add_domain("python", samples=python_samples, target_model="gpt-python")

    # Domain 2: French Text
    french_samples = [f"Bonjour numéro {i}, j'espère que vous allez bien aujourd'hui.".encode() for i in range(100)]
    router.add_domain("french", samples=french_samples, target_model="gpt-french")

    # Test Python routing
    res_py = router.route("def process_data(data): return [x.upper() for x in data]")
    assert res_py.winner == "python"
    assert res_py.target_model == "gpt-python"

    # Test French routing
    res_fr = router.route("Bonjour, comment allez-vous aujourd'hui?")
    assert res_fr.winner == "french"
    assert res_fr.target_model == "gpt-french"


def test_bundle_persistence(tmp_path: os.PathLike) -> None:
    """Test saving and loading bundles with CRC and version checks."""
    bundle_path = os.path.join(tmp_path, "test.kolmo")
    router = KolmoRouter()
    # Provide enough data for training
    router.add_domain("test", samples=[f"sample data {i} ".encode() * 100 for i in range(20)], target_model="m1")
    router.save_bundle(bundle_path)

    # Load successfully
    new_router = KolmoRouter.load_bundle(bundle_path)
    assert "test" in new_router.domains
    assert new_router.domains["test"].target_model == "m1"
    assert new_router.domains["test"].checksum is not None

    # Corrupt checksum in metadata
    with tarfile.open(bundle_path, "r:gz") as tar:
        meta_file = tar.extractfile("metadata.json")
        assert meta_file is not None
        metadata = json.load(meta_file)
        dict_member = tar.getmember("dicts/test.dict")
        dict_file = tar.extractfile(dict_member)
        assert dict_file is not None
        dict_bytes = dict_file.read()

    corrupted_metadata = json.loads(json.dumps(metadata))
    corrupted_metadata["domains"]["test"]["checksum"] = "deadbeef"

    corrupt_path = os.path.join(tmp_path, "corrupt.kolmo")
    with tarfile.open(corrupt_path, "w:gz") as tar:
        meta_json = json.dumps(corrupted_metadata).encode()
        info = tarfile.TarInfo("metadata.json")
        info.size = len(meta_json)
        tar.addfile(info, io.BytesIO(meta_json))

        info = tarfile.TarInfo("dicts/test.dict")
        info.size = len(dict_bytes)
        tar.addfile(info, io.BytesIO(dict_bytes))

    with pytest.raises(BundleCorruptionError, match="Checksum mismatch"):
        KolmoRouter.load_bundle(corrupt_path)

    # Version mismatch
    version_metadata = json.loads(json.dumps(metadata))
    version_metadata["_kolmo_version"] = "9.9.9"

    version_path = os.path.join(tmp_path, "bad_version.kolmo")
    with tarfile.open(version_path, "w:gz") as tar:
        meta_json = json.dumps(version_metadata).encode()
        info = tarfile.TarInfo("metadata.json")
        info.size = len(meta_json)
        tar.addfile(info, io.BytesIO(meta_json))

        info = tarfile.TarInfo("dicts/test.dict")
        info.size = len(dict_bytes)
        tar.addfile(info, io.BytesIO(dict_bytes))

    with pytest.raises(BundleCorruptionError, match="Bundle version mismatch"):
        KolmoRouter.load_bundle(version_path)


def test_errors() -> None:
    """Test that explicit errors are raised."""
    router = KolmoRouter()

    # Empty samples
    with pytest.raises(TrainingError):
        router.add_domain("bad", samples=[])


def test_file_source_ambiguity(tmp_path: os.PathLike) -> None:
    """Ensure file: sources are treated as raw dictionary bytes."""
    dict_path = os.path.join(tmp_path, "dict.bin")
    dict_bytes = b"dictionary-bytes" * 20
    with open(dict_path, "wb") as f:
        f.write(dict_bytes)

    router = KolmoRouter()
    router.add_domain("file-domain", source=f"file:{dict_path}")

    assert router._dictionaries["file-domain"] == dict_bytes
    assert router.domains["file-domain"].dict_size == len(dict_bytes)


def test_ncd_score_logic() -> None:
    """Verify NCD scores reflect similarity and confidence."""
    router = KolmoRouter()

    # Train domains with distinct data
    router.add_domain("domain_a", samples=[b"alpha " * 50 + str(i).encode() for i in range(50)])
    router.add_domain("domain_b", samples=[b"beta " * 50 + str(i).encode() for i in range(50)])

    res = router.route("alpha " * 20)
    assert res.scores["domain_a"] < res.scores["domain_b"]
    assert 0 <= res.confidence <= 1.0


if __name__ == "__main__":
    pytest.main([__file__])


def test_auto_dict_scaling() -> None:
    """Test that dict_size is automatically scaled down for small datasets."""
    router = KolmoRouter()
    # Use many small samples to trigger scaling but still pass zstd requirements.
    # Total bytes = 100 * 20 = 2000 bytes.
    # Default dict_size is 112640, so this triggers scaling to 2000.
    samples = [b"short sample data " + bytes([i % 256]) for i in range(100)]
    # This should trigger auto-scaling and succeed.
    router.add_domain("small-domain", samples=samples)
    assert "small-domain" in router.domains
    assert len(router._dictionaries["small-domain"]) > 0
