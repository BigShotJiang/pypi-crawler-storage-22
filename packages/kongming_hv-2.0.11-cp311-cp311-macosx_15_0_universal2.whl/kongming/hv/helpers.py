from google.protobuf import message

from kongming.api import hv_pb2
from kongming.ext import go, hv


def from_message(msg: message.Message):
    """from_message returns the Python native obj from the supplied proto message."""
    serialized = msg.SerializeToString()
    if isinstance(msg, hv_pb2.HyperBinaryProto):
        return hv.unload_hyper_binary(
            hv.background(), hv.unmarshal_hyper_binary_proto(go.Slice_byte(serialized))
        )
    elif isinstance(msg, hv_pb2.HyperBinarySetProto):
        return hv.unload_hyper_binary_set(
            hv.background(),
            hv.unmarshal_hyper_binary_set_proto(go.Slice_byte(serialized)),
        )
    else:
        raise ValueError(f"unknown branch for {type(msg)}")


def to_message(obj) -> message.Message:
    """to_message returns the proto message for the supplied Python native obj."""
    if not hasattr(obj, "proto_load"):
        raise ValueError("no proto_load()?")

    loaded = obj.proto_load(hv.background())
    if isinstance(loaded, hv.go.Ptr_api_HyperBinaryProto):
        msg = hv_pb2.HyperBinaryProto()
        msg.ParseFromString(bytes(hv.marshal_hyper_binary_proto(loaded)))
    elif isinstance(loaded, hv.go.Ptr_api_HyperBinarySetProto):
        msg = hv_pb2.HyperBinarySetProto()
        msg.ParseFromString(bytes(hv.marshal_hyper_binary_set_proto(loaded)))
    else:
        raise ValueError(f"unknown branch for {type(obj)}")

    return msg


def weights(weights: list[float]) -> go.Slice_float64:
    """weights is used to supply a list of weight into underlying Go methods that expects weights."""
    return go.Slice_float64(weights)


def keys(keys: list[str]) -> go.Slice_string:
    """keys is used to supply a list of keys into underlying Go methods that expects keys."""
    return go.Slice_string(keys)
