"""Framework for build NLP information extraction systems using regular expressions."""
