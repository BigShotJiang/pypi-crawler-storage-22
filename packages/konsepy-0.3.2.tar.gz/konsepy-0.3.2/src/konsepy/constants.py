ID_LABEL = 'studyid'
NOTEID_LABEL = 'note_id'
NOTEDATE_LABEL = 'note_date'
NOTETEXT_LABEL = 'text'
