# Koopa

Standalone python package without any workflow routines but only workflow component functions.

### TODO
* Add functionality to align more than two channels
* Add unit tests for alignment
* Add unit tests for other segmentation
* Add example czi image
* Improve some type casting for configuration file
