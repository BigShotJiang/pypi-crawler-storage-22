def test_register_coordinates():
    pass


def test_compute_affine_transform():
    pass


def test_load_alignment_image():
    pass


def test_register_alignment_pystackreg():
    pass


def test_register_alignment_deepblink():
    pass


def test_get_stackreg():
    pass


def test_align_image():
    pass
