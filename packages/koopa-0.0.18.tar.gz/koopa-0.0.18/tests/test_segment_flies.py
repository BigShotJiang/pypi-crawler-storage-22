def test_normalize_nucleus():
    pass


def test_remove_false_objects():
    pass


def test_dilate_segmap():
    pass
