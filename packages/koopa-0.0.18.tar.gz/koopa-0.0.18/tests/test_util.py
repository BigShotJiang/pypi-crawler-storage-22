def test_get_file_list():
    pass


def test_get_final_spot_file():
    pass
