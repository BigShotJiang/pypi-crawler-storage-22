# Project Contributors

All external contributors to the project, we are grateful for all their help.

For the detailed information on who did what,
see [GitHub Contributors](https://github.com/nolar/kopf/graphs/contributors)
and [Historic GitHub Contributors](https://github.com/zalando-incubator/kopf/graphs/contributors).

## Contributors sorted alphabetically

- [Anthony Nash](https://github.com/nashant)
- [Daniel Middlecote](https://github.com/dlmiddlecote)
- [Henning Jacobs](https://github.com/hjacobs)
- [Clement Liaw](https://github.com/iexalt)
- [Ismail Kaboubi](https://github.com/smileisak)
- [Michael Narodovitch](https://github.com/michaelnarodovitch)
- [Rodrigo Tavares](https://github.com/tavaresrodrigo)
- [Sergey Vasilyev](https://github.com/nolar)
- [Soroosh Sarabadani](https://github.com/psycho-ir)
- [Trond Hindenes](https://github.com/trondhindenes)
- [Vennamaneni Sai Narasimha](https://github.com/thevennamaneni)
- [Cliff Burdick](https://github.com/cliffburdick)
- [CJ Baar](https://github.com/cjbaar)
