"""Allow running as `python -m korea_transit_mcp_server`."""

from korea_transit_mcp_server.server import main

main()
