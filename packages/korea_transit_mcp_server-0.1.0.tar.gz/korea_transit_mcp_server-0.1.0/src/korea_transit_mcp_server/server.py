"""Korea Transit MCP Server — FastMCP entry point."""

from __future__ import annotations

from fastmcp import FastMCP

from korea_transit_mcp_server.tools.bus import get_bus_arrival, get_bus_location
from korea_transit_mcp_server.tools.route import get_line_info, search_transit_route
from korea_transit_mcp_server.tools.search import find_nearby_stations, search_station
from korea_transit_mcp_server.tools.subway import (
    get_first_last_train,
    get_subway_arrival,
    get_subway_congestion,
)

mcp = FastMCP("Korea Transit")


# ---- Route Search ----

@mcp.tool()
async def transit_route(
    start: str,
    end: str,
    search_type: int = 0,
) -> str:
    """대중교통 경로를 검색합니다.

    출발지와 도착지 사이의 대중교통 경로를 찾아줍니다.
    주소, 장소명, 좌표(경도,위도) 모두 사용 가능합니다.

    Args:
        start: 출발지 (e.g. "강남역", "서울역", "127.027,37.498")
        end: 도착지 (e.g. "판교역", "여의도역")
        search_type: 검색 유형 — 0: 추천 (기본), 1: 최소시간, 2: 최소환승
    """
    return await search_transit_route(start, end, search_type)


@mcp.tool()
async def line_info(line_name: str) -> str:
    """버스/지하철 노선의 상세 정보를 조회합니다.

    노선의 경유 정류장/역, 운행 정보 등을 제공합니다.

    Args:
        line_name: 노선명 (e.g. "2호선", "333번")
    """
    return await get_line_info(line_name)


# ---- Station Search ----

@mcp.tool()
async def station_search(keyword: str, station_type: str | None = None) -> str:
    """정류장 또는 역을 검색합니다.

    키워드로 버스 정류장이나 지하철역을 검색할 수 있습니다.

    Args:
        keyword: 검색어 (e.g. "강남역", "판교역")
        station_type: "bus"=버스정류장만, "subway"=지하철역만, None=전체 (기본)
    """
    return await search_station(keyword, station_type)


@mcp.tool()
async def nearby_stations(
    longitude: float,
    latitude: float,
    radius: int = 500,
) -> str:
    """현재 위치 주변의 정류장/역을 검색합니다.

    좌표 기반으로 반경 내 버스 정류장과 지하철역을 찾아줍니다.

    Args:
        longitude: 경도 (e.g. 127.027)
        latitude: 위도 (e.g. 37.498)
        radius: 검색 반경 (미터, 기본 500m)
    """
    return await find_nearby_stations(longitude, latitude, radius)


# ---- Bus (Seoul) ----

@mcp.tool()
async def bus_arrival(ars_id: str) -> str:
    """실시간 버스 도착 정보를 조회합니다 (서울 한정).

    정류소의 실시간 버스 도착 예정 시간, 위치, 혼잡도를 제공합니다.

    Args:
        ars_id: 정류소 고유번호 5자리 (e.g. "22009")
    """
    return await get_bus_arrival(ars_id)


@mcp.tool()
async def bus_location(route_id: str, route_name: str = "") -> str:
    """실시간 버스 위치를 추적합니다 (서울 한정).

    노선의 모든 운행 중인 버스 위치와 상태를 실시간으로 제공합니다.

    Args:
        route_id: 서울시 버스 노선 ID (e.g. "100100118")
        route_name: 노선 번호 (표시용, e.g. "333")
    """
    return await get_bus_location(route_id, route_name)


# ---- Subway (Seoul) ----

@mcp.tool()
async def subway_arrival(station_name: str) -> str:
    """실시간 지하철 도착 정보를 조회합니다 (서울 한정).

    역의 실시간 열차 도착 예정 시간과 목적지를 제공합니다.

    Args:
        station_name: 역 이름 (e.g. "강남", "판교"). "역" 없이 입력하세요.
    """
    return await get_subway_arrival(station_name)


@mcp.tool()
async def subway_congestion(
    line_num: str,
    station_name: str,
    direction: str,
) -> str:
    """지하철 혼잡도 정보를 조회합니다 (서울 한정).

    특정 역의 시간대별 혼잡도 정보를 제공합니다.

    Args:
        line_num: 호선 번호 (e.g. "2", "9")
        station_name: 역 이름 (e.g. "강남", "판교")
        direction: 방향 ("상행" 또는 "하행")
    """
    return await get_subway_congestion(line_num, station_name, direction)


@mcp.tool()
async def first_last_train(
    line_name: str,
    station_name: str,
    direction: str,
) -> str:
    """지하철 첫차/막차 시간을 조회합니다.

    특정 역의 노선별 첫차/막차 시간표를 제공합니다.

    Args:
        line_name: 노선명 (e.g. "2호선", "신분당선")
        station_name: 역 이름 (e.g. "강남", "판교")
        direction: 방향 (e.g. "외선", "내선", "상행", "하행")
    """
    return await get_first_last_train(line_name, station_name, direction)


def main() -> None:
    """CLI entry point."""
    mcp.run()


if __name__ == "__main__":
    main()
