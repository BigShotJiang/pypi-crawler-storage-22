"""실시간 버스 도착 및 위치 추적 도구."""

from __future__ import annotations

from korea_transit_mcp_server.clients import public_data

CONGESTION_MAP = {"3": "여유", "4": "보통", "5": "혼잡", "6": "매우혼잡"}


def _format_arrival_item(item: dict[str, str]) -> str:
    """버스 도착 정보 한 항목을 포맷합니다."""
    bus_no = item.get("rtNm", "?")
    # 1번째 도착 버스
    msg1 = item.get("arrmsg1", "정보없음")
    # 2번째 도착 버스
    msg2 = item.get("arrmsg2", "정보없음")
    # 노선 유형
    route_type = item.get("routeType", "")
    congestion = CONGESTION_MAP.get(item.get("reride_Num1", ""), "")
    cong_str = f" ({congestion})" if congestion else ""

    next_stn = item.get("nxtStn", "")
    next_str = f" → {next_stn}" if next_stn else ""

    lines = [f"🚌 {bus_no}{next_str}{cong_str}"]
    lines.append(f"   1번째: {msg1}")
    lines.append(f"   2번째: {msg2}")
    return "\n".join(lines)


async def get_bus_arrival(ars_id: str) -> str:
    """실시간 버스 도착 정보를 조회합니다.

    Args:
        ars_id: 정류소 고유번호 5자리 (e.g. "22009"). 정류소 번호는 search_station으로 검색할 수 있습니다.
    """
    items = await public_data.get_bus_arrival(ars_id)
    if not items:
        return f"정류소 {ars_id}에 도착 예정 버스가 없습니다."

    # 첫 번째 항목에서 정류소 이름 추출
    stop_name = items[0].get("stNm", ars_id)

    lines: list[str] = [f"🚏 {stop_name} (ARS: {ars_id}) 실시간 도착 정보:\n"]
    for item in items:
        lines.append(_format_arrival_item(item))
        lines.append("")

    return "\n".join(lines)


async def get_bus_location(route_id: str, route_name: str = "") -> str:
    """실시간 버스 위치를 추적합니다.

    Args:
        route_id: 서울시 버스 노선 ID (e.g. "100100118"). search_station 결과에서 확인할 수 있습니다.
        route_name: 노선 번호 (표시용, e.g. "333")
    """
    items = await public_data.get_bus_position(route_id)
    if not items:
        return f"노선 {route_name or route_id}의 운행 중인 버스가 없습니다."

    display = route_name or route_id
    lines: list[str] = [f"🚌 {display}번 버스 위치 ({len(items)}대 운행 중):\n"]

    for item in items:
        plate = item.get("plainNo", "")
        stop_nm = item.get("stopNm", item.get("lastStnNm", ""))
        next_stop = item.get("nextStTm", "")
        congestion = CONGESTION_MAP.get(item.get("congetion", ""), "정보없음")
        is_full = item.get("islastyn", "0")
        full_str = " [막차]" if is_full == "1" else ""

        lines.append(f"  🚍 {plate}{full_str}")
        lines.append(f"     현재: {stop_nm} 부근 | 혼잡도: {congestion}")
        if next_stop:
            lines.append(f"     다음 정류장까지: {next_stop}초")
        lines.append("")

    return "\n".join(lines)
