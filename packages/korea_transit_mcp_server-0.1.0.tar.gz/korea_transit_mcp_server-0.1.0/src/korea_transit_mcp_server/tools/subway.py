"""실시간 지하철 도착, 혼잡도, 첫차/막차 조회 도구."""

from __future__ import annotations

from typing import Any

from korea_transit_mcp_server.clients import public_data


def _format_arrival_entry(item: dict[str, Any]) -> str:
    """지하철 도착 정보 한 항목을 포맷합니다."""
    line = item.get("subwayId", "")
    line_name = _subway_id_to_name(line)
    # 상행/하행 방향
    direction = item.get("updnLine", "")
    dest = item.get("trainLineNm", item.get("bstatnNm", ""))
    msg = item.get("arvlMsg2", item.get("arvlMsg3", "정보없음"))
    curr_stn = item.get("arvlMsg3", "")

    direction_str = f"({direction})" if direction else ""
    return f"🚇 {line_name} {direction_str} → {dest}: {msg}"


def _subway_id_to_name(subway_id: str) -> str:
    """지하철 노선 ID를 노선명으로 변환합니다."""
    mapping = {
        "1001": "1호선", "1002": "2호선", "1003": "3호선", "1004": "4호선",
        "1005": "5호선", "1006": "6호선", "1007": "7호선", "1008": "8호선",
        "1009": "9호선", "1063": "경의중앙선", "1065": "공항철도",
        "1067": "경춘선", "1075": "수인분당선", "1077": "신분당선",
        "1091": "GTX-A", "1092": "우이신설선", "1093": "서해선",
        "1094": "신림선",
    }
    return mapping.get(str(subway_id), f"노선({subway_id})")


async def get_subway_arrival(station_name: str) -> str:
    """실시간 지하철 도착 정보를 조회합니다.

    Args:
        station_name: 역 이름 (e.g. "강남", "판교", "서울역"). "역" 접미사 없이 입력하세요.
    """
    # "역" 접미사 제거
    clean_name = station_name.rstrip("역").strip()
    data = await public_data.get_subway_arrival(clean_name)

    arrivals = data.get("realtimeArrivalList", [])
    if not arrivals:
        return f"'{clean_name}역'의 실시간 도착 정보가 없습니다."

    # 노선별로 그룹화
    by_line: dict[str, list[str]] = {}
    for item in arrivals:
        line_name = _subway_id_to_name(item.get("subwayId", ""))
        entry = _format_arrival_entry(item)
        by_line.setdefault(line_name, []).append(entry)

    lines: list[str] = [f"🚉 {clean_name}역 실시간 도착 정보:\n"]
    for line_name, entries in by_line.items():
        for e in entries:
            lines.append(f"  {e}")
        lines.append("")

    return "\n".join(lines)


async def get_subway_congestion(
    line_num: str,
    station_name: str,
    time_slot: str | None = None,
) -> str:
    """지하철 혼잡도를 조회합니다.

    Args:
        line_num: 호선 번호 (e.g. "2")
        station_name: 역 이름 (e.g. "강남")
        time_slot: 시간대 (e.g. "08", "18"). None이면 전체 시간대.
    """
    clean_name = station_name.rstrip("역").strip()
    data = await public_data.get_subway_congestion(line_num, clean_name)

    stat_list = data.get("StatisticsTrnsport", {}).get("row", [])
    if not stat_list:
        # 대체 응답 형식 시도
        stat_list = data.get("row", [])
    if not stat_list:
        return f"{line_num}호선 {clean_name}역 혼잡도 데이터가 없습니다."

    # 대상 역에 대해 필터링
    station_data = [
        r for r in stat_list
        if clean_name in str(r.get("SUB_STA_NM", ""))
    ]
    if not station_data:
        return f"{line_num}호선 {clean_name}역 혼잡도 데이터를 찾을 수 없습니다."

    lines: list[str] = [f"🚇 {line_num}호선 {clean_name}역 혼잡도:\n"]

    # 결과는 최대 4개로 제한
    for row in station_data[:4]:
        direction = row.get("LINE_NUM", "")
        ride_sum = row.get("RIDE_PASGR_NUM", 0)
        alight_sum = row.get("ALIGHT_PASGR_NUM", 0)

        lines.append(f"  방면: {direction}")
        lines.append(f"  승차: {ride_sum:,}명 | 하차: {alight_sum:,}명")

        # 시간대별 데이터 (있는 경우)
        if time_slot:
            key_ride = f"RIDE_PASGR_NUM_{time_slot}"
            key_alight = f"ALIGHT_PASGR_NUM_{time_slot}"
            if key_ride in row:
                lines.append(
                    f"  {time_slot}시대: 승차 {row[key_ride]:,}명 / 하차 {row.get(key_alight, 0):,}명"
                )
        lines.append("")

    lines.append("※ 데이터는 통계 기반이며 실시간이 아닐 수 있습니다.")
    return "\n".join(lines)


# 첫차/막차 정보 — ODsay 지하철 시간표 데이터 사용
async def get_first_last_train(
    station_name: str,
    line_name: str | None = None,
) -> str:
    """첫차/막차 시간을 조회합니다.

    Args:
        station_name: 역 이름 (e.g. "강남")
        line_name: 호선 이름 (e.g. "2호선"). None이면 해당 역의 모든 노선.
    """
    from korea_transit_mcp_server.clients import odsay

    clean_name = station_name.rstrip("역").strip()
    data = await odsay.subway_station_info(clean_name)
    result = data.get("result", {})

    if not result:
        return f"'{clean_name}역'의 첫차/막차 정보를 찾을 수 없습니다."

    lines: list[str] = [f"🕐 {clean_name}역 첫차/막차 정보:\n"]

    # 응답 구조가 다양하므로 사용 가능한 데이터 추출
    station_list = result.get("station", result.get("stationList", []))
    if isinstance(station_list, dict):
        station_list = [station_list]

    if not station_list:
        return f"'{clean_name}역'의 시간표 정보가 없습니다."

    for stn in station_list:
        stn_line = stn.get("laneName", stn.get("lnCd", ""))
        if line_name and line_name not in str(stn_line):
            continue

        lines.append(f"  {stn_line}:")

        # 첫차/막차 시간 정보 (있는 경우)
        first_time = stn.get("firstTime", stn.get("FRN_ARVL_TM", ""))
        last_time = stn.get("lastTime", stn.get("LST_ARVL_TM", ""))

        if first_time:
            lines.append(f"    첫차: {first_time}")
        if last_time:
            lines.append(f"    막차: {last_time}")

        if not first_time and not last_time:
            lines.append("    (시간표 상세 정보 없음 — ODsay 역 정보 참고)")
        lines.append("")

    if len(lines) <= 2:
        lines.append("  해당 노선의 정보를 찾을 수 없습니다.")

    return "\n".join(lines)
