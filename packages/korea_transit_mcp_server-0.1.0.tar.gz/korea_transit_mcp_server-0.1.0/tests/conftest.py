"""Shared test fixtures."""

from __future__ import annotations

import pytest

from korea_transit_mcp_server.config import Config, SimpleCache, cache, config


@pytest.fixture(autouse=True)
def _reset_config(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensure API keys are set and cache is clear for every test."""
    monkeypatch.setattr(config, "odsay_api_key", "test-odsay-key")
    monkeypatch.setattr(config, "seoul_bus_api_key", "test-bus-key")
    monkeypatch.setattr(config, "seoul_subway_api_key", "test-subway-key")
    cache.clear()
