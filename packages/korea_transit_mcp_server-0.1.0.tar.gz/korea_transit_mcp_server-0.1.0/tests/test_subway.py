"""Tests for subway arrival and congestion tools."""

from __future__ import annotations

import re

import pytest
import respx
from httpx import Response

from korea_transit_mcp_server.tools.subway import (
    _subway_id_to_name,
    get_first_last_train,
    get_subway_arrival,
    get_subway_congestion,
)

ODSAY_BASE = "https://api.odsay.com/v1/api"


def test_subway_id_to_name():
    assert _subway_id_to_name("1002") == "2호선"
    assert _subway_id_to_name("1077") == "신분당선"
    assert "9999" in _subway_id_to_name("9999")


@respx.mock
@pytest.mark.asyncio
async def test_get_subway_arrival():
    respx.get(url__regex=r"swopenapi\.seoul\.go\.kr/api/subway/.+/json/realtimeStationArrival").mock(
        return_value=Response(200, json={
            "realtimeArrivalList": [
                {
                    "subwayId": "1002",
                    "updnLine": "상행",
                    "trainLineNm": "성수행",
                    "arvlMsg2": "전역 도착",
                    "arvlMsg3": "교대",
                },
                {
                    "subwayId": "1077",
                    "updnLine": "하행",
                    "trainLineNm": "광교행",
                    "arvlMsg2": "3분 후 도착",
                },
            ]
        })
    )

    result = await get_subway_arrival("강남역")
    assert "강남" in result
    assert "2호선" in result
    assert "신분당선" in result
    assert "성수행" in result
    assert "광교행" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_subway_arrival_empty():
    respx.get(url__regex=r"swopenapi\.seoul\.go\.kr/api/subway/.+/json/realtimeStationArrival").mock(
        return_value=Response(200, json={
            "realtimeArrivalList": []
        })
    )

    result = await get_subway_arrival("강남")
    assert "정보가 없습니다" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_subway_congestion():
    respx.get(url__regex=r"swopenapi\.seoul\.go\.kr/api/subway/.+/json/StatisticsTrnsport").mock(
        return_value=Response(200, json={
            "StatisticsTrnsport": {
                "row": [
                    {
                        "SUB_STA_NM": "강남",
                        "LINE_NUM": "내선",
                        "RIDE_PASGR_NUM": 50000,
                        "ALIGHT_PASGR_NUM": 48000,
                    }
                ]
            }
        })
    )

    result = await get_subway_congestion("2", "강남")
    assert "강남역" in result
    assert "50,000명" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_first_last_train():
    respx.get(f"{ODSAY_BASE}/subwayStationInfo").mock(
        return_value=Response(200, json={
            "result": {
                "station": [
                    {
                        "laneName": "2호선",
                        "firstTime": "05:15",
                        "lastTime": "23:50",
                    },
                    {
                        "laneName": "신분당선",
                        "firstTime": "05:30",
                        "lastTime": "00:10",
                    },
                ]
            }
        })
    )

    result = await get_first_last_train("강남")
    assert "2호선" in result
    assert "05:15" in result
    assert "23:50" in result
    assert "신분당선" in result
