# Kova

Kova is a Python security tool focused on credential exposure detection and research.

## Quickstart

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -e ".[dev]"
pytest
```

## License

This project is licensed under the GNU General Public License v3.0 or later. See [LICENSE](LICENSE).
