"""Top-level package for kova."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("kova")
except PackageNotFoundError:
    __version__ = "0.0.0"

