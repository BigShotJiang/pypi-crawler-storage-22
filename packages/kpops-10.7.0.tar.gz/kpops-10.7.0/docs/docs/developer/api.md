# Python API

<!-- dprint-ignore-start -->

::: kpops.api
    options:
      filters:
        - "!^_"

::: kpops.pipeline.Pipeline
    options:
      filters:
        - "!^_"
        - "!^model_config$"

<!-- dprint-ignore-end -->
