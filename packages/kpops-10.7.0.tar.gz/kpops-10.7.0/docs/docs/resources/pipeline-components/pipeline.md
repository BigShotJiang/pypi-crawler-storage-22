# pipeline.yaml

[:material-download:](./pipeline.yaml)

```yaml
--8<--
./docs/resources/pipeline-components/pipeline.yaml
--8<--
```
