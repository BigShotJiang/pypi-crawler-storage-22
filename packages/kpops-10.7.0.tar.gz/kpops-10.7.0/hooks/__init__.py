"""KPOps Git hooks."""

from pathlib import Path

ROOT = Path(__file__).parents[1].resolve()
