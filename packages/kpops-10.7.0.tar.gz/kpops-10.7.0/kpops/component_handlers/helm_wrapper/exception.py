class ReleaseNotFoundException(Exception):
    pass


class ParseError(Exception):
    pass
