__version__ = "10.7.0"
KPOPS = "KPOps"
KPOPS_MODULE = "kpops."
