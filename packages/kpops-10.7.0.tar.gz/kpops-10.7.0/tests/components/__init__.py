from pathlib import Path

PIPELINE_BASE_DIR = Path(__file__).parent
RESOURCES_PATH = PIPELINE_BASE_DIR / "resources"
