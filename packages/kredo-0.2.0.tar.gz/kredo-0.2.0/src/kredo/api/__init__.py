"""Kredo Discovery API package."""
