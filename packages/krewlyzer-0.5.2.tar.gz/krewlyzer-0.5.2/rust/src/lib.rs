//! krewlyzer-core: High-performance Rust backend for cfDNA analysis
//!
//! This crate provides fast implementations of fragment size analysis functions
//! for cell-free DNA analysis, exposed to Python via PyO3.
//!
//! ## Feature Modules
//! - **extract_motif**: Fragment extraction, End/Breakpoint motifs, GC correction
//! - **fsc**: Fragment Size Coverage (windowed depth per size bin)
//! - **fsd**: Fragment Size Distribution (histograms per chromosome arm)
//! - **wps**: Windowed Protection Score (nucleosome/TF profiling, FFT periodicity, NRL)
//! - **ocf**: Orientation-aware cfDNA Fragmentation (strand asymmetry at OCRs)
//! - **mfsd**: Mutant Fragment Size Distribution (variant-level size profiles)
//! - **uxm**: Fragment-level Methylation (bisulfite BAM analysis)
//!
//! ## Support Modules
//! - **engine**: Generic fragment analysis engine with parallel processing
//! - **pipeline**: Unified pipeline orchestration for run-all
//! - **gc_correction**: LOESS-based GC bias correction
//! - **filters**: Read filtering (MAPQ, length, proper pair, duplicates)
//! - **bed**: BED file parsing (gzip-compressed)

use pyo3::prelude::*;

// fsc, wps, fsd, ocf, mfsd, uxm maintained for individual tool access via legacy-compatible APIs (using new engines internally)
pub mod filters;
pub mod bed;
pub mod fsc;
pub mod fsd;
pub mod ocf;
pub mod wps;
pub mod mfsd;
pub mod uxm;
pub mod extract_motif;
pub mod engine;
pub mod pipeline;
pub mod gc_correction;
pub mod pon_model;
pub mod pon_builder;  // PON aggregation functions
pub mod gc_reference;
pub mod region_entropy;  // TFBS/ATAC size entropy
pub mod motif_utils;     // Shared motif/sequence utilities
pub mod region_mds;      // Per-region MDS (Helzer et al.)

/// Read filtering configuration
#[pyclass]
#[derive(Clone, Debug)]
pub struct ReadFilters {
    #[pyo3(get, set)]
    pub mapq: u8,
    #[pyo3(get, set)]
    pub min_length: u32,
    #[pyo3(get, set)]
    pub max_length: u32,
    #[pyo3(get, set)]
    pub skip_duplicates: bool,
    #[pyo3(get, set)]
    pub require_proper_pair: bool,
}

#[pymethods]
impl ReadFilters {
    #[new]
    #[pyo3(signature = (mapq=20, min_length=65, max_length=400, skip_duplicates=true, require_proper_pair=true))]
    fn new(
        mapq: u8,
        min_length: u32,
        max_length: u32,
        skip_duplicates: bool,
        require_proper_pair: bool,
    ) -> Self {
        Self {
            mapq,
            min_length,
            max_length,
            skip_duplicates,
            require_proper_pair,
        }
    }
}

#[pymodule]
#[pyo3(name = "_core")]
fn krewlyzer_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Initialize logging (bridges Rust log -> Python logging)
    let _ = pyo3_log::init();

    m.add_class::<ReadFilters>()?;
    
    // Thread configuration
    m.add_function(wrap_pyfunction!(configure_threads, m)?)?;
    
    // FSC functions
    m.add_function(wrap_pyfunction!(fsc::count_fragments_by_bins, m)?)?;
    m.add_function(wrap_pyfunction!(fsc::aggregate_by_gene, m)?)?;

    // FSD submodule
    let fsd_mod = PyModule::new(m.py(), "fsd")?;
    fsd_mod.add_function(wrap_pyfunction!(fsd::calculate_fsd, &fsd_mod)?)?;
    fsd_mod.add_function(wrap_pyfunction!(fsd::apply_pon_logratio, &fsd_mod)?)?;
    m.add_submodule(&fsd_mod)?;

    // WPS submodule
    let wps_mod = PyModule::new(m.py(), "wps")?;
    wps_mod.add_function(wrap_pyfunction!(wps::calculate_wps, &wps_mod)?)?;
    wps_mod.add_function(wrap_pyfunction!(wps::apply_pon_zscore, &wps_mod)?)?;
    m.add_submodule(&wps_mod)?;

    // OCF submodule
    let ocf_mod = PyModule::new(m.py(), "ocf")?;
    ocf_mod.add_function(wrap_pyfunction!(ocf::calculate_ocf, &ocf_mod)?)?;
    ocf_mod.add_function(wrap_pyfunction!(ocf::apply_pon_zscore, &ocf_mod)?)?;
    m.add_submodule(&ocf_mod)?;
    
    // mFSD submodule
    let mfsd_mod = PyModule::new(m.py(), "mfsd")?;
    mfsd_mod.add_function(wrap_pyfunction!(mfsd::calculate_mfsd, &mfsd_mod)?)?;
    m.add_submodule(&mfsd_mod)?;
    
    // UXM submodule
    let uxm_mod = PyModule::new(m.py(), "uxm")?;
    uxm_mod.add_function(wrap_pyfunction!(uxm::calculate_uxm, &uxm_mod)?)?;
    m.add_submodule(&uxm_mod)?;
    
    // Unified Engine (Extract+Motif)
    let extract_motif_mod = PyModule::new(m.py(), "extract_motif")?;
    extract_motif_mod.add_function(wrap_pyfunction!(extract_motif::process_bam_parallel, &extract_motif_mod)?)?;
    m.add_submodule(&extract_motif_mod)?;
    
    // Unified Pipeline (FSC/FSD/WPS/OCF)
    m.add_function(wrap_pyfunction!(pipeline::run_unified_pipeline, m)?)?;
    
    // GC Reference submodule (pre-computed assets)
    let gc_mod = PyModule::new(m.py(), "gc")?;
    gc_mod.add_function(wrap_pyfunction!(gc_reference::generate_valid_regions, &gc_mod)?)?;
    gc_mod.add_function(wrap_pyfunction!(gc_reference::generate_valid_regions_ontarget, &gc_mod)?)?;
    gc_mod.add_function(wrap_pyfunction!(gc_reference::generate_ref_genome_gc, &gc_mod)?)?;
    gc_mod.add_function(wrap_pyfunction!(gc_correction::compute_and_write_gc_factors, &gc_mod)?)?;
    m.add_submodule(&gc_mod)?;
    
    // PON Builder submodule (aggregation functions)
    let pon_builder_mod = PyModule::new(m.py(), "pon_builder")?;
    pon_builder_mod.add_function(wrap_pyfunction!(pon_builder::compute_gc_bias_model, &pon_builder_mod)?)?;
    pon_builder_mod.add_function(wrap_pyfunction!(pon_builder::compute_fsd_baseline, &pon_builder_mod)?)?;
    pon_builder_mod.add_function(wrap_pyfunction!(pon_builder::compute_wps_baseline, &pon_builder_mod)?)?;
    pon_builder_mod.add_function(wrap_pyfunction!(pon_builder::compute_region_mds_baseline, &pon_builder_mod)?)?;
    m.add_submodule(&pon_builder_mod)?;
    
    // Region Entropy submodule (TFBS/ATAC size entropy)
    let region_entropy_mod = PyModule::new(m.py(), "region_entropy")?;
    region_entropy_mod.add_function(wrap_pyfunction!(region_entropy::run_region_entropy, &region_entropy_mod)?)?;
    region_entropy_mod.add_function(wrap_pyfunction!(region_entropy::apply_pon_zscore, &region_entropy_mod)?)?;
    m.add_submodule(&region_entropy_mod)?;
    
    // Region MDS submodule (per-region motif diversity, Helzer et al.)
    let region_mds_mod = PyModule::new(m.py(), "region_mds")?;
    region_mds_mod.add_function(wrap_pyfunction!(region_mds::run_region_mds, &region_mds_mod)?)?;
    m.add_submodule(&region_mds_mod)?;
    
    // Version
    #[pyfn(m)]
    fn version() -> &'static str {
        env!("CARGO_PKG_VERSION")
    }
    
    Ok(())
}

/// Configure the number of threads for Rayon parallel processing.
/// Must be called before any parallel operations.
/// 
/// # Arguments
/// * `num_threads` - Number of threads to use (0 = use all available cores)
#[pyfunction]
#[pyo3(signature = (num_threads=0))]
fn configure_threads(num_threads: usize) -> PyResult<()> {
    let threads = if num_threads == 0 {
        num_cpus::get()
    } else {
        num_threads
    };
    
    rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .build_global()
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(
            format!("Failed to configure thread pool: {}. Note: can only be called once.", e)
        ))?;
    
    Ok(())
}
