"""Tool registry - re-exports from SDK with CLI convenience functions."""

from __future__ import annotations

# Re-export from SDK
from krim_sdk.tools.base import Tool
from krim_sdk.tools.read import ReadTool
from krim_sdk.tools.write import WriteTool
from krim_sdk.tools.edit import EditTool
from krim_sdk.tools.bash import BashTool
from krim_sdk.tools.grep import GrepTool
from krim_sdk.tools.glob import GlobTool
from krim_sdk.tools.submit import SubmitTool
from krim_sdk.tools.skill import SkillTool


def create_tools() -> list[Tool]:
    """Create fresh tool instances."""
    return [ReadTool(), WriteTool(), EditTool(), BashTool(), GrepTool(), GlobTool(), SkillTool(), SubmitTool()]


def get_tool(tools: list[Tool], name: str) -> Tool | None:
    for t in tools:
        if t.name == name:
            return t
    return None


def tool_schemas(tools: list[Tool]) -> list[dict]:
    return [t.schema() for t in tools]
