"""SDK exceptions."""

from __future__ import annotations


class KrimSDKError(Exception):
    """Base exception for KRIM SDK."""
    pass


class RetryableError(KrimSDKError):
    """Error that can be retried (e.g., rate limits, network issues)."""
    pass


class ToolError(KrimSDKError):
    """Error during tool execution."""
    def __init__(self, tool_name: str, message: str):
        self.tool_name = tool_name
        super().__init__(f"Tool '{tool_name}' error: {message}")


class ModelError(KrimSDKError):
    """Error from model/API."""
    pass


class ConfigError(KrimSDKError):
    """Configuration error."""
    pass


class HookBlockedError(KrimSDKError):
    """Tool execution blocked by hook."""
    def __init__(self, tool_name: str, message: str | None = None):
        self.tool_name = tool_name
        msg = f"Tool '{tool_name}' blocked by hook"
        if message:
            msg += f": {message}"
        super().__init__(msg)
