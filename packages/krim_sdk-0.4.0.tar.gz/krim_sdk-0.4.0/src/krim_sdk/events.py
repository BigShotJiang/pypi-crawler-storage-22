"""Event system for SDK - enables UI-agnostic agent execution."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class EventType(Enum):
    """Types of events emitted by the agent."""
    # Agent lifecycle
    AGENT_START = "agent_start"
    AGENT_END = "agent_end"

    # Turn events
    TURN_START = "turn_start"
    TURN_END = "turn_end"

    # Model events
    MODEL_REQUEST = "model_request"
    MODEL_RESPONSE = "model_response"
    MODEL_STREAM = "model_stream"
    MODEL_ERROR = "model_error"
    MODEL_RETRY = "model_retry"

    # Tool events
    TOOL_START = "tool_start"
    TOOL_END = "tool_end"
    TOOL_ASK = "tool_ask"

    # Compaction
    COMPACTION_START = "compaction_start"
    COMPACTION_END = "compaction_end"

    # Special states
    DOOM_LOOP = "doom_loop"
    MAX_TURNS = "max_turns"
    SUBMIT = "submit"


@dataclass
class Event:
    """Event emitted by the agent."""
    type: EventType
    data: dict[str, Any]


@runtime_checkable
class EventHandler(Protocol):
    """Protocol for handling agent events.

    Implement this to receive callbacks during agent execution.
    All methods are optional - implement only what you need.

    Example:
        class MyHandler:
            def on_stream(self, text: str) -> None:
                print(text, end="", flush=True)

            def on_tool_start(self, name: str, args: dict) -> None:
                print(f"Running {name}...")
    """

    def on_event(self, event: Event) -> None:
        """Called for every event. Override for generic handling."""
        ...

    def on_stream(self, text: str) -> None:
        """Called for each streaming text chunk from the model."""
        ...

    def on_tool_start(self, name: str, args: dict) -> None:
        """Called before tool execution."""
        ...

    def on_tool_end(self, name: str, result: str) -> None:
        """Called after tool execution."""
        ...

    def on_tool_ask(self, tool_name: str, command: str) -> bool:
        """Called when a tool needs user approval (e.g., bash).

        Return True to allow, False to deny.
        Default implementation returns True (allow all).
        """
        ...

    def on_retry(self, attempt: int, max_retries: int, error: Exception, delay: float) -> None:
        """Called before retry with backoff."""
        ...

    def on_compaction(self, before_tokens: int, after_tokens: int) -> None:
        """Called after context compaction."""
        ...

    def on_submit(self, summary: str) -> None:
        """Called when agent submits final answer."""
        ...


class NullEventHandler:
    """Default no-op event handler. All operations are silent."""

    def on_event(self, event: Event) -> None:
        pass

    def on_stream(self, text: str) -> None:
        pass

    def on_tool_start(self, name: str, args: dict) -> None:
        pass

    def on_tool_end(self, name: str, result: str) -> None:
        pass

    def on_tool_ask(self, tool_name: str, command: str) -> bool:
        return True  # Default: allow all

    def on_retry(self, attempt: int, max_retries: int, error: Exception, delay: float) -> None:
        pass

    def on_compaction(self, before_tokens: int, after_tokens: int) -> None:
        pass

    def on_submit(self, summary: str) -> None:
        pass


class PrintEventHandler:
    """Simple event handler that prints to stdout. Useful for debugging."""

    def on_event(self, event: Event) -> None:
        pass

    def on_stream(self, text: str) -> None:
        print(text, end="", flush=True)

    def on_tool_start(self, name: str, args: dict) -> None:
        print(f"\n[tool] {name}")

    def on_tool_end(self, name: str, result: str) -> None:
        preview = result[:200] + "..." if len(result) > 200 else result
        print(f"[result] {preview}")

    def on_tool_ask(self, tool_name: str, command: str) -> bool:
        response = input(f"\n[{tool_name}] {command}\nAllow? [Y/n] ").strip().lower()
        return response in ("", "y", "yes")

    def on_retry(self, attempt: int, max_retries: int, error: Exception, delay: float) -> None:
        print(f"[retry] {attempt}/{max_retries} in {delay:.0f}s: {error}")

    def on_compaction(self, before_tokens: int, after_tokens: int) -> None:
        print(f"[compact] {before_tokens:,} -> {after_tokens:,} tokens")

    def on_submit(self, summary: str) -> None:
        print(f"\n[done] {summary}")
