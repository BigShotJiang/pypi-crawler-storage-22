"""Hook system for intercepting and modifying agent behavior."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable


@dataclass
class HookContext:
    """Context passed to hook callbacks."""
    messages: list[dict]
    turn: int
    tool_name: str | None = None
    tool_args: dict | None = None
    tool_result: str | None = None


@dataclass
class HookResult:
    """Result from a hook callback."""
    # For PRE_TOOL_USE: can block or modify tool call
    block: bool = False
    block_message: str | None = None
    modified_args: dict | None = None

    # For POST_TOOL_USE: can modify result
    modified_result: str | None = None

    # General: inject message into conversation
    inject_message: str | None = None


# Type alias for hook callbacks
HookCallback = Callable[[HookContext], HookResult | None]
AsyncHookCallback = Callable[[HookContext], Awaitable[HookResult | None]]


@dataclass
class HookMatcher:
    """Associates a tool pattern with hook callbacks.

    Example:
        # Match specific tool
        HookMatcher("bash", hooks=[my_bash_hook])

        # Match multiple tools with regex
        HookMatcher("Write|Edit", hooks=[my_file_hook])

        # Match all tools
        HookMatcher(".*", hooks=[my_logging_hook])
    """
    pattern: str
    hooks: list[HookCallback] = field(default_factory=list)
    _compiled: re.Pattern | None = field(default=None, repr=False)

    def __post_init__(self):
        self._compiled = re.compile(self.pattern, re.IGNORECASE)

    def matches(self, tool_name: str) -> bool:
        """Check if this matcher applies to the given tool."""
        return bool(self._compiled and self._compiled.match(tool_name))


@dataclass
class Hooks:
    """Collection of hooks for different lifecycle points.

    Example:
        def log_tool_use(ctx: HookContext) -> HookResult | None:
            print(f"Tool: {ctx.tool_name}")
            return None

        def block_dangerous(ctx: HookContext) -> HookResult | None:
            if "rm -rf" in str(ctx.tool_args):
                return HookResult(block=True, block_message="Blocked dangerous command")
            return None

        hooks = Hooks(
            pre_tool_use=[
                HookMatcher(".*", hooks=[log_tool_use]),
                HookMatcher("bash", hooks=[block_dangerous]),
            ]
        )
    """
    pre_tool_use: list[HookMatcher] = field(default_factory=list)
    post_tool_use: list[HookMatcher] = field(default_factory=list)
    pre_compact: list[HookCallback] = field(default_factory=list)
    stop: list[HookCallback] = field(default_factory=list)

    def run_pre_tool_hooks(self, tool_name: str, tool_args: dict, messages: list[dict], turn: int) -> HookResult | None:
        """Run pre-tool hooks and return combined result."""
        ctx = HookContext(
            messages=messages,
            turn=turn,
            tool_name=tool_name,
            tool_args=tool_args,
        )

        for matcher in self.pre_tool_use:
            if matcher.matches(tool_name):
                for hook in matcher.hooks:
                    result = hook(ctx)
                    if result and result.block:
                        return result
                    if result and result.modified_args:
                        ctx.tool_args = result.modified_args

        # Return modified args if any
        if ctx.tool_args != tool_args:
            return HookResult(modified_args=ctx.tool_args)
        return None

    def run_post_tool_hooks(self, tool_name: str, tool_result: str, messages: list[dict], turn: int) -> str:
        """Run post-tool hooks and return potentially modified result."""
        ctx = HookContext(
            messages=messages,
            turn=turn,
            tool_name=tool_name,
            tool_result=tool_result,
        )

        result = tool_result
        for matcher in self.post_tool_use:
            if matcher.matches(tool_name):
                for hook in matcher.hooks:
                    hook_result = hook(ctx)
                    if hook_result and hook_result.modified_result:
                        result = hook_result.modified_result
                        ctx.tool_result = result

        return result
