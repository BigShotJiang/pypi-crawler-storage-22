"""
Krista Common Proto Schema Package

This package contains compiled Protocol Buffer definitions
that can be imported directly in Python projects.

Usage:
    from krista_common_proto_schema import user_pb2, message_pb2

    user = user_pb2.User(id=1, name="John")
    message = message_pb2.Message(id=1, sender=user, content="Hello")
"""

__version__ = "1.0.5"

# Import compiled proto modules for easy access
from . import user_pb2
from . import message_pb2

__all__ = ["user_pb2", "message_pb2"]
