"""Auto-generated package file."""
