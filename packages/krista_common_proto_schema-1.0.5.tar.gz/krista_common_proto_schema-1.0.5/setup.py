#!/usr/bin/env python3
"""
Setup script for common-proto-schema Python package.

This makes the proto schema installable as a Python package,
similar to how Maven packages it as a JAR for Java.

Usage:
    # Install locally (development)
    pip install -e .
    
    # Build distribution
    python setup.py sdist bdist_wheel
    
    # Install from built package
    pip install dist/common_proto_schema-1.0.0-py3-none-any.whl
"""

from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
from setuptools.command.sdist import sdist
from distutils.command.build import build
import subprocess
import os
import shutil
from pathlib import Path


class BuildProtoCommand(build_py):
    """Custom build command that compiles proto files before building package."""
    
    def run(self):
        """Compile proto files to Python before building."""
        print("=" * 60)
        print("Compiling proto files to Python...")
        print("=" * 60)

        # Verify proto checksums first
        print("\n🔍 Verifying proto file checksums...")
        verify_script = Path("../proto/verify_checksums.sh")
        if verify_script.exists():
            try:
                subprocess.run(
                    ["bash", str(verify_script)],
                    cwd=str(verify_script.parent),
                    check=True,
                    capture_output=True,
                    text=True
                )
                print("✅ Proto checksums verified\n")
            except subprocess.CalledProcessError as e:
                print(f"❌ Proto checksum verification failed!")
                print(e.stdout)
                print(e.stderr)
                raise RuntimeError("Proto files have been modified. Update VERSION and regenerate checksums.")
        else:
            print("⚠️  Checksum verification skipped (verify_checksums.sh not found)\n")

        # Paths
        proto_dir = Path("../proto")
        output_dir = Path("krista_common_proto_schema")

        # Read version from VERSION file
        version_file = Path("../VERSION")
        version = version_file.read_text().strip()

        # Create output directory
        output_dir.mkdir(exist_ok=True)

        # Create __init__.py with dynamic version
        init_file = output_dir / "__init__.py"
        init_file.write_text(f'''"""
Krista Common Proto Schema Package

This package contains compiled Protocol Buffer definitions
that can be imported directly in Python projects.

Usage:
    from krista_common_proto_schema import user_pb2, message_pb2

    user = user_pb2.User(id=1, name="John")
    message = message_pb2.Message(id=1, sender=user, content="Hello")
"""

__version__ = "{version}"

# Import compiled proto modules for easy access
from . import user_pb2
from . import message_pb2

__all__ = ["user_pb2", "message_pb2"]
''')
        
        # Find all .proto files
        proto_files = list(proto_dir.glob("**/*.proto"))
        
        if not proto_files:
            print("⚠️  No proto files found!")
            return
        
        print(f"Found {len(proto_files)} proto files:")
        for pf in proto_files:
            print(f"  - {pf}")
        
        # Compile each proto file
        for proto_file in proto_files:
            print(f"\n🔨 Compiling {proto_file}...")
            
            try:
                subprocess.run(
                    [
                        "python3", "-m", "grpc_tools.protoc",
                        f"-I={proto_dir}",
                        f"--python_out={output_dir}",
                        str(proto_file)
                    ],
                    check=True,
                    capture_output=True,
                    text=True
                )
                print(f"   ✅ Compiled successfully")
            except subprocess.CalledProcessError as e:
                print(f"   ❌ Error: {e.stderr}")
                raise
        
        # Create __init__.py files in all subdirectories to make them packages
        print("\n📦 Creating __init__.py files in subdirectories...")
        for subdir in output_dir.rglob("*"):
            if subdir.is_dir() and subdir != output_dir:
                init_file = subdir / "__init__.py"
                if not init_file.exists():
                    init_file.write_text('"""Auto-generated package file."""\n')
                    print(f"   ✅ Created {init_file.relative_to(output_dir.parent)}")

        print("\n" + "=" * 60)
        print("✅ All proto files compiled successfully!")
        print("=" * 60)

        # Continue with normal build
        super().run()


class CustomBuild(build):
    """Custom build command that ensures proto files are compiled."""

    def run(self):
        """Run build_py first to compile protos, then continue with normal build."""
        # This ensures BuildProtoCommand runs before the build
        self.run_command('build_py')
        super().run()


class CustomSDist(sdist):
    """Custom sdist command that ensures proto files are compiled before creating source distribution."""

    def run(self):
        """Compile proto files first, then create source distribution."""
        # Ensure proto files are compiled
        self.run_command('build_py')
        super().run()


# Read version from VERSION file at repository root
version_file = Path(__file__).parent.parent / "VERSION"
version = version_file.read_text().strip()

setup(
    name="krista_common_proto_schema",
    version=version,
    author="Krista",
    author_email="vijay.bhatt@kristasoft.com",
    description="Shared Protocol Buffer definitions.",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/krista-common-proto-schema",

    # Package configuration - explicitly list all packages
    packages=[
        "krista_common_proto_schema",
        "krista_common_proto_schema.common",
    ],

    # Include proto files in the package
    package_data={
        "krista_common_proto_schema": ["*.proto"],
        "krista_common_proto_schema.common": ["*.proto", "*.py"],
    },
    
    # Dependencies
    install_requires=[
        "protobuf>=4.25.0,<7.0.0",
    ],

    # Build dependencies
    setup_requires=[
        "grpcio-tools>=1.60.0",
    ],
    
    # Custom build commands
    cmdclass={
        "build": CustomBuild,
        "build_py": BuildProtoCommand,
        "sdist": CustomSDist,
    },
    
    # Metadata
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
)

