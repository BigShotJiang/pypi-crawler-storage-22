import logging
import re
import time
import traceback
from concurrent.futures import Future
from concurrent.futures.thread import ThreadPoolExecutor
from functools import partial

from kubernetes import watch
from kubernetes.client import CoreV1Api, V1Pod
from urllib3.exceptions import ProtocolError

from krkn_lib.models.pod_monitor.models import (
    MonitoredPod,
    PodEvent,
    PodsSnapshot,
    PodStatus,
)


def _select_pods(
    select_partial: partial,
    namespace_pattern: str = None,
    name_pattern: str = None,
):
    initial_pods = select_partial()
    snapshot = PodsSnapshot()
    snapshot.resource_version = initial_pods.metadata.resource_version

    for pod in initial_pods.items:
        match_name = True
        match_namespace = True
        if namespace_pattern:
            match = re.match(namespace_pattern, pod.metadata.namespace)
            match_namespace = match is not None
        if name_pattern:
            match = re.match(name_pattern, pod.metadata.name)
            match_name = match is not None
        if match_name and match_namespace:
            mon_pod = MonitoredPod()
            snapshot.initial_pods.append(pod.metadata.name)
            mon_pod.name = pod.metadata.name
            mon_pod.namespace = pod.metadata.namespace
            snapshot.pods[mon_pod.name] = mon_pod
    return snapshot


def _monitor_pods(
    monitor_partial: partial,
    snapshot: PodsSnapshot,
    max_timeout: int,
    name_pattern: str = None,
    namespace_pattern: str = None,
    max_retries: int = 3,
) -> PodsSnapshot:
    """
    Monitor pods with automatic retry on watch stream disconnection.

    :param monitor_partial: Partial function for monitoring pods
    :param snapshot: Snapshot to populate with pod events
    :param max_timeout: Maximum time to monitor (seconds)
    :param name_pattern: Regex pattern for pod names
    :param namespace_pattern: Regex pattern for namespaces
    :param max_retries: Maximum number of retries on connection error
        (default: 3)
    :return: PodsSnapshot with collected pod events
    """

    start_time = time.time()
    retry_count = 0
    deleted_parent_pods = []
    restored_pods = []
    pods_became_not_ready = set()
    cluster_restored = False

    logging.info(
        f"Monitoring pods - tracking {len(snapshot.initial_pods)} initial pods"
    )
    inital_pod_len = len(snapshot.initial_pods)

    while retry_count <= max_retries:
        try:
            # Calculate remaining timeout if retrying
            if retry_count > 0:
                elapsed = time.time() - start_time
                remain_timeout = max(1, int(max_timeout - elapsed))
                logging.info("remain timeout " + str(remain_timeout))
                if remain_timeout <= 0:
                    logging.info(
                        "Maximum timeout reached, stopping monitoring"
                    )
                    break
                logging.info(
                    "Reconnecting watch stream"
                    f"(attempt {retry_count}/{max_retries}),"
                    f"remaining timeout: {remain_timeout}s"
                )
            else:
                remain_timeout = max_timeout

            w = watch.Watch(return_type=V1Pod)

            for e in w.stream(monitor_partial, timeout_seconds=remain_timeout):

                match_name = True
                match_namespace = True
                event_type = e["type"]
                pod = e["object"]

                if namespace_pattern:
                    match = re.match(namespace_pattern, pod.metadata.namespace)
                    match_namespace = match is not None
                if name_pattern:
                    match = re.match(name_pattern, pod.metadata.name)
                    match_name = match is not None

                if not (match_name and match_namespace):
                    continue

                if match_name and match_namespace:
                    # Capture timestamp when event is received
                    event_timestamp = time.time()
                    pod_name = pod.metadata.name

                    # Determine status based on event type
                    status = PodStatus.UNDEFINED

                    if event_type == "MODIFIED":
                        if pod.metadata.deletion_timestamp is not None:
                            status = PodStatus.DELETION_SCHEDULED
                            if pod_name not in deleted_parent_pods:
                                deleted_parent_pods.append(pod_name)
                        elif _is_pod_ready(pod):
                            status = PodStatus.READY
                            if pod_name not in restored_pods:
                                restored_pods.append(pod_name)
                            if len(restored_pods) >= inital_pod_len:
                                cluster_restored = True
                        else:
                            status = PodStatus.NOT_READY

                    elif event_type == "DELETED":
                        status = PodStatus.DELETED
                    elif event_type == "ADDED":
                        status = PodStatus.ADDED

                    # Create PodEvent
                    pod_event = PodEvent(timestamp=event_timestamp)
                    pod_event.status = status

                    if pod_event.status == PodStatus.ADDED:

                        if pod_name not in snapshot.added_pods:
                            snapshot.added_pods.append(pod_name)
                        # in case a pod is respawn with the same name
                        # the dictionary must not be reinitialized
                        if pod_name not in snapshot.pods:
                            snapshot.pods[pod_name] = MonitoredPod()
                            snapshot.pods[pod_name].name = pod_name
                            snapshot.pods[pod_name].namespace = (
                                pod.metadata.namespace
                            )

                    # skips events out of the snapshot
                    if pod_name in snapshot.pods:

                        snapshot.pods[pod_name].status_changes.append(
                            pod_event
                        )

                        # Early exit condition 1: All deleted pods
                        # replaced
                        if cluster_restored:
                            logging.debug(
                                "Cluster restored: all initial pods "
                                "have recovered, stopping monitoring"
                            )
                            w.stop()
                            return snapshot

                        if (
                            len(deleted_parent_pods) > 0
                            and len(deleted_parent_pods) == len(restored_pods)
                        ):
                            # Check that restored pods are actually new pods
                            # (not just initial pods that stayed ready)
                            # by verifying they have ADDED events
                            new_pods_count = sum(
                                1 for pod_name in restored_pods
                                if pod_name in snapshot.added_pods
                            )
                            if new_pods_count == len(deleted_parent_pods):
                                logging.info(
                                    f"Deletion events "
                                    f"({len(deleted_parent_pods)}) "
                                    f"match new READY pods "
                                    f"({new_pods_count}), "
                                    "all disrupted pods restored, "
                                    "stopping monitoring"
                                )
                                w.stop()
                                return snapshot

                        # Early exit condition 2: All initially monitored
                        # pods that became not ready are now ready again
                        if (
                            len(pods_became_not_ready) == 0
                            and len(restored_pods) > 0
                            and len(deleted_parent_pods) == 0
                        ):
                            # Check if any initial pod had NOT_READY
                            had_disruption = any(
                                any(
                                    ev.status == PodStatus.NOT_READY
                                    for ev in snapshot.pods[
                                        p
                                    ].status_changes
                                )
                                for p in snapshot.initial_pods
                                if p in snapshot.pods
                            )
                            if had_disruption:
                                logging.info(
                                    "All initially monitored pods "
                                    "that became not ready have "
                                    "recovered, stopping monitoring"
                                )
                                w.stop()
                                return snapshot

            # If we exit the loop normally (timeout reached), we're done
            logging.info(
                "Watch stream completed normally (timeout reached)"
            )
            w.stop()
            return snapshot

        except ProtocolError as e:
            logging.warning(f"ProtocolError encountered: {e}")

            if retry_count > max_retries:
                logging.warning(
                    f"Watch stream connection broken after "
                    f"{max_retries} retries. ProtocolError: {e}. "
                    "Returning snapshot with data collected so far."
                )
                break

            # Log retry attempt
            logging.info(
                f"Watch stream connection broken (ProtocolError): "
                f"{e}. Retry {retry_count}/{max_retries} in progress..."
            )
            backoff_time = 1

            # Check if we have time for backoff
            elapsed = time.time() - start_time
            if elapsed + backoff_time >= max_timeout:
                logging.info(
                    "Not enough time remaining for backoff, "
                    "returning snapshot with data collected."
                )
                break

            logging.info(f"Waiting {backoff_time}s before retry...")
            time.sleep(backoff_time)

        except Exception as e:
            logging.error(f"Unexpected error in monitor pods: {e}")
            logging.error("Stack trace:\n%s", traceback.format_exc())
            raise Exception(e)

        retry_count += 1

    logging.info(
        f"Exiting monitoring loop, returning snapshot with "
        f"{len(snapshot.pods)} pods"
    )
    return snapshot


def _is_pod_ready(pod: V1Pod) -> bool:
    if not pod.status.container_statuses:
        return False
    for status in pod.status.container_statuses:
        if not status.ready:
            return False
    return True


def select_and_monitor_by_label(
    label_selector: str,
    max_timeout: int,
    v1_client: CoreV1Api,
) -> Future:
    """
    Monitors all the pods identified
    by a label selector and collects infos about the
    pods recovery after a kill scenario while the scenario is running.

    :param label_selector: the label selector used
        to filter the pods to monitor (must be the
        same used in `select_pods_by_label`)
    :param max_timeout: the expected time the pods should take
        to recover. If the killed pods are replaced in this time frame,
        but they didn't reach the Ready State, they will be marked as
        unrecovered. If during the time frame the pods are not replaced
        at all the error field of the PodsStatus structure will be
        valorized with an exception.
    :param v1_client: kubernetes V1Api client
    :return:
        a Future which result (PodsSnapshot) must be
        gathered to obtain the pod infos.

    """
    select_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        label_selector=label_selector,
        field_selector="status.phase=Running",
    )
    snapshot = _select_pods(select_partial)

    monitor_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        resource_version=snapshot.resource_version,
        label_selector=label_selector,
    )
    pool = ThreadPoolExecutor(max_workers=1)
    future = pool.submit(
        _monitor_pods,
        monitor_partial,
        snapshot,
        max_timeout,
        name_pattern=None,
        namespace_pattern=None,
    )
    return future


def select_and_monitor_by_name_pattern_and_namespace_pattern(
    pod_name_pattern: str,
    namespace_pattern: str,
    max_timeout: int,
    v1_client: CoreV1Api,
):
    """
    Monitors all the pods identified by a pod name regex pattern
    and a namespace regex pattern, that collects infos about the
    pods recovery after a kill scenario while the scenario is running.
    Raises an exception if the regex format is not correct.

    :param pod_name_pattern: a regex representing the
        pod name pattern used to filter the pods to be monitored
        (must be the same used in
        `select_pods_by_name_pattern_and_namespace_pattern`)
    :param namespace_pattern: a regex representing the namespace
        pattern used to filter the pods to be monitored
        (must be the same used in
        `select_pods_by_name_pattern_and_namespace_pattern`)
    :param max_timeout: the expected time the pods should take to
        recover. If the killed pods are replaced in this time frame,
        but they didn't reach the Ready State, they will be marked as
        unrecovered. If during the time frame the pods are not replaced
        at all the error field of the PodsStatus structure will be
        valorized with an exception.
    :param v1_client: kubernetes V1Api client
    :return:
        a Future which result (PodsSnapshot) must be
        gathered to obtain the pod infos.

    """
    try:
        re.compile(pod_name_pattern)
    except re.error as e:
        raise Exception(f"invalid pod name pattern regex: {e}")

    try:
        re.compile(namespace_pattern)
    except re.error as e:
        raise Exception(f"invalid pod namespace regex: {e}")

    select_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        field_selector="status.phase=Running",
    )
    snapshot = _select_pods(
        select_partial,
        name_pattern=pod_name_pattern,
        namespace_pattern=namespace_pattern,
    )

    monitor_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        resource_version=snapshot.resource_version,
    )
    pool = ThreadPoolExecutor(max_workers=1)
    future = pool.submit(
        _monitor_pods,
        monitor_partial,
        snapshot,
        max_timeout,
        name_pattern=pod_name_pattern,
        namespace_pattern=namespace_pattern,
    )
    return future


def select_and_monitor_by_namespace_pattern_and_label(
    namespace_pattern: str,
    label_selector: str,
    v1_client: CoreV1Api,
    max_timeout=30,
):
    """
    Monitors all the pods identified
    by a namespace regex pattern
    and a pod label selector, that collects infos about the
    pods recovery after a kill scenario while the scenario is running.
    Raises an exception if the regex format is not correct.

    :param label_selector: the label selector used to filter
        the pods to monitor (must be the same used in
        `select_pods_by_label`)
    :param v1_client: kubernetes V1Api client
    :param namespace_pattern: a regex representing the namespace
        pattern used to filter the pods to be monitored (must be
        the same used
        in `select_pods_by_name_pattern_and_namespace_pattern`)
    :param max_timeout: the expected time the pods should take to recover.
        If the killed pods are replaced in this time frame, but they
        didn't reach the Ready State, they will be marked as unrecovered.
        If during the time frame the pods are not replaced
        at all the error field of the PodsStatus structure will be
        valorized with an exception.
    :return:
        a Future which result (PodsSnapshot) must be
        gathered to obtain the pod infos.

    """
    try:
        re.compile(namespace_pattern)
    except re.error as e:
        raise Exception(f"invalid pod namespace regex: {e}")

    select_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        label_selector=label_selector,
        field_selector="status.phase=Running",
    )
    snapshot = _select_pods(
        select_partial,
        namespace_pattern=namespace_pattern,
    )

    monitor_partial = partial(
        v1_client.list_pod_for_all_namespaces,
        resource_version=snapshot.resource_version,
        label_selector=label_selector,
    )
    pool = ThreadPoolExecutor(max_workers=1)
    future = pool.submit(
        _monitor_pods,
        monitor_partial,
        snapshot,
        max_timeout,
        name_pattern=None,
        namespace_pattern=namespace_pattern,
    )
    return future
