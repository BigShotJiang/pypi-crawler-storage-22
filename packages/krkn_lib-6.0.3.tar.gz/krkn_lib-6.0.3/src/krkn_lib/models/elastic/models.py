import datetime

from elasticsearch_dsl import (
    Boolean,
    Date,
    Document,
    Float,
    InnerDoc,
    Integer,
    Keyword,
    Nested,
    Text,
)

from krkn_lib.models.telemetry import ChaosRunTelemetry


class ElasticAlert(Document):
    run_uuid = Keyword()
    severity = Text()
    alert = Text()
    created_at = Date()

    def __init__(
        self,
        run_uuid: str = None,
        severity: str = None,
        alert: str = None,
        created_at: datetime = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.run_uuid = run_uuid
        self.severity = severity
        self.alert = alert
        self.created_at = created_at

    def to_dict(self, **kwargs):
        """Override to_dict to ensure ISO 8601 datetime format"""
        d = super().to_dict(**kwargs)
        # Convert datetime objects or string dates to ISO 8601 format
        if 'created_at' in d and d['created_at'] is not None:
            if isinstance(d['created_at'], datetime.datetime):
                d['created_at'] = d['created_at'].isoformat()
            elif isinstance(d['created_at'], str) and ' ' in d['created_at']:
                # Fix space-separated datetime strings to ISO format
                d['created_at'] = d['created_at'].replace(' ', 'T')
        return d


class ElasticMetric(Document):
    run_uuid = Keyword()
    timestamp = Date()

    def __init__(
        self,
        run_uuid: str,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.run_uuid = run_uuid

    def to_dict(self, **kwargs):
        """Override to_dict to ensure ISO 8601 datetime format"""
        d = super().to_dict(**kwargs)
        # Convert datetime objects or string dates to ISO 8601 format
        if 'timestamp' in d and d['timestamp'] is not None:
            if isinstance(d['timestamp'], datetime.datetime):
                d['timestamp'] = d['timestamp'].isoformat()
            elif isinstance(d['timestamp'], str) and ' ' in d['timestamp']:
                # Fix space-separated datetime strings to ISO format
                d['timestamp'] = d['timestamp'].replace(' ', 'T')
        return d


# Telemetry models
class ElasticAffectedPod(InnerDoc):
    pod_name = Text(fields={"keyword": Keyword()})
    namespace = Text()
    total_recovery_time = Float()
    pod_readiness_time = Float()
    pod_rescheduling_time = Float()


class ElasticPodsStatus(InnerDoc):
    recovered = Nested(ElasticAffectedPod, multi=True)
    unrecovered = Nested(ElasticAffectedPod, multi=True)
    error = Text()


class ElasticAffectedNodes(InnerDoc):
    node_name = Text(fields={"keyword": Keyword()})
    node_id = Text()
    not_ready_time = Float()
    ready_time = Float()
    stopped_time = Float()
    running_time = Float()
    terminating_time = Float()


class ElasticScenarioParameters(InnerDoc):
    pass


class ElasticResiliencyReport(InnerDoc):
    scenarios = Nested(InnerDoc)
    resiliency_score = Integer()
    passed_slos = Integer()
    total_slos = Integer()


class ElasticScenarioTelemetry(InnerDoc):
    start_timestamp = Float()
    end_timestamp = Float()
    scenario = Text(fields={"keyword": Keyword()})
    scenario_type = Text(fields={"keyword": Keyword()})
    exit_status = Integer()
    parameters_base64 = Text()
    parameters = Nested(ElasticScenarioParameters)
    affected_pods = Nested(ElasticPodsStatus)
    affected_nodes = Nested(ElasticAffectedNodes, multi=True)
    overall_resiliency_report = Nested(ElasticResiliencyReport)


class ElasticNodeInfo(InnerDoc):
    count = Integer()
    architecture = Text()
    instance_type = Text()
    nodes_type = Text()
    kernel_version = Text()
    kubelet_version = Text()
    os_version = Text()


class ElasticTaint(InnerDoc):
    key = Text()
    value = Text()
    effect = Text()


class ElasticHealthChecks(InnerDoc):
    url = Text()
    status = Boolean()
    status_code = Text()
    start_timestamp = Date()
    end_timestamp = Date()
    duration = Float()


class ElasticVirtChecks(InnerDoc):
    vm_name = Text()
    ip_address = Text()
    new_ip_address = Text()
    namespace = Text()
    node_name = Text()
    status = Boolean()
    start_timestamp = Date()
    end_timestamp = Date()
    duration = Float()


class ElasticErrorLog(InnerDoc):
    timestamp = Text()
    message = Text()


class ElasticChaosRunTelemetry(Document):
    scenarios = Nested(ElasticScenarioTelemetry, multi=True)
    node_summary_infos = Nested(ElasticNodeInfo, multi=True)
    node_taints = Nested(ElasticTaint, multi=True)
    kubernetes_objects_count = Nested(InnerDoc)
    network_plugins = Text(multi=True)
    timestamp = Text()
    total_node_count = Integer()
    cloud_infrastructure = Text()
    cloud_type = Text()
    cluster_version = Text()
    major_version = Text()
    build_url = Text()
    job_status = Boolean()
    run_uuid = Text(fields={"keyword": Keyword()})
    health_checks = Nested(ElasticHealthChecks, multi=True)
    virt_checks = Nested(ElasticVirtChecks, multi=True)
    post_virt_checks = Nested(ElasticVirtChecks, multi=True)
    error_logs = Nested(ElasticErrorLog, multi=True)

    class Index:
        name = "chaos_run_telemetry"

    def __init__(
        self, chaos_run_telemetry: ChaosRunTelemetry = None, **kwargs
    ):
        super().__init__(**kwargs)
        # cheap trick to avoid reinventing the wheel :-)
        if chaos_run_telemetry is None and kwargs:
            chaos_run_telemetry = ChaosRunTelemetry(json_dict=kwargs)
        self.scenarios = [
            ElasticScenarioTelemetry(
                start_timestamp=sc.start_timestamp,
                end_timestamp=sc.end_timestamp,
                scenario=sc.scenario,
                scenario_type=sc.scenario_type,
                exit_status=sc.exit_status,
                parameters_base64=sc.parameters_base64,
                parameters=sc.parameters,
                affected_pods=ElasticPodsStatus(
                    recovered=[
                        ElasticAffectedPod(
                            pod_name=pod.pod_name,
                            namespace=pod.namespace,
                            total_recovery_time=(
                                pod.total_recovery_time
                            ),
                            pod_readiness_time=pod.pod_readiness_time,
                            pod_rescheduling_time=(
                                pod.pod_rescheduling_time
                            ),
                        )
                        for pod in sc.affected_pods.recovered
                    ],
                    unrecovered=[
                        ElasticAffectedPod(
                            pod_name=pod.pod_name, namespace=pod.namespace
                        )
                        for pod in sc.affected_pods.unrecovered
                    ],
                    error=sc.affected_pods.error,
                ),
                affected_nodes=[
                    ElasticAffectedNodes(
                        node_name=node.node_name,
                        node_id=node.node_id,
                        not_ready_time=node.not_ready_time,
                        ready_time=node.ready_time,
                        stopped_time=node.stopped_time,
                        running_time=node.running_time,
                        terminating_time=node.terminating_time,
                    )
                    for node in sc.affected_nodes
                ],
                overall_resiliency_report=(
                    ElasticResiliencyReport(
                        scenarios=(
                            sc.overall_resiliency_report.scenarios
                        ),
                        resiliency_score=(
                            sc.overall_resiliency_report.resiliency_score
                        ),
                        passed_slos=sc.overall_resiliency_report.passed_slos,
                        total_slos=sc.overall_resiliency_report.total_slos,
                    )
                    if sc.overall_resiliency_report
                    else None
                ),
            )
            for sc in chaos_run_telemetry.scenarios
        ]

        self.node_summary_infos = [
            ElasticNodeInfo(
                count=info.count,
                nodes_type=info.nodes_type,
                architecture=info.architecture,
                instance_type=info.instance_type,
                kernel_version=info.kernel_version,
                kubelet_version=info.kubelet_version,
                os_version=info.os_version,
            )
            for info in chaos_run_telemetry.node_summary_infos
        ]
        self.node_taints = [
            ElasticTaint(
                key=taint.key, value=taint.value, effect=taint.effect
            )
            for taint in chaos_run_telemetry.node_taints
        ]
        self.kubernetes_objects_count = (
            chaos_run_telemetry.kubernetes_objects_count
        )
        self.network_plugins = chaos_run_telemetry.network_plugins

        if chaos_run_telemetry.health_checks:
            self.health_checks = [
                ElasticHealthChecks(
                    url=info.url,
                    status=info.status,
                    status_code=info.status_code,
                    start_timestamp=datetime.datetime.fromisoformat(
                        str(info.start_timestamp)
                    ),
                    end_timestamp=datetime.datetime.fromisoformat(
                        str(info.end_timestamp)
                    ),
                    duration=info.duration,
                )
                for info in chaos_run_telemetry.health_checks
            ]
        else:
            self.health_checks = None

        if chaos_run_telemetry.virt_checks:
            self.virt_checks = [
                ElasticVirtChecks(
                    vm_name=info.vm_name,
                    ip_address=info.ip_address,
                    new_ip_address=info.new_ip_address,
                    namespace=info.namespace,
                    node_name=info.node_name,
                    status=info.status,
                    start_timestamp=datetime.datetime.fromisoformat(
                        str(info.start_timestamp)
                    ),
                    end_timestamp=datetime.datetime.fromisoformat(
                        str(info.end_timestamp)
                    ),
                    duration=info.duration,
                )
                for info in chaos_run_telemetry.virt_checks
            ]
        else:
            self.virt_checks = None

        if chaos_run_telemetry.post_virt_checks:
            self.post_virt_checks = [
                ElasticVirtChecks(
                    vm_name=post_info.vm_name,
                    ip_address=post_info.ip_address,
                    new_ip_address=post_info.new_ip_address,
                    namespace=post_info.namespace,
                    node_name=post_info.node_name,
                    status=post_info.status,
                    start_timestamp=datetime.datetime.fromisoformat(
                        str(post_info.start_timestamp)
                    ),
                    end_timestamp=datetime.datetime.fromisoformat(
                        str(post_info.end_timestamp)
                    ),
                    duration=post_info.duration,
                )
                for post_info in chaos_run_telemetry.post_virt_checks
            ]
        else:
            self.post_virt_checks = None

        self.timestamp = chaos_run_telemetry.timestamp
        self.total_node_count = chaos_run_telemetry.total_node_count
        self.cloud_infrastructure = (
            chaos_run_telemetry.cloud_infrastructure
        )
        self.cloud_type = chaos_run_telemetry.cloud_type
        self.cluster_version = chaos_run_telemetry.cluster_version
        self.run_uuid = chaos_run_telemetry.run_uuid
        self.job_status = chaos_run_telemetry.job_status
        self.major_version = chaos_run_telemetry.major_version
        self.build_url = chaos_run_telemetry.build_url

        if chaos_run_telemetry.error_logs:
            self.error_logs = [
                ElasticErrorLog(
                    timestamp=error.get('timestamp'),
                    message=error.get('message')
                )
                for error in chaos_run_telemetry.error_logs
            ]
        else:
            self.error_logs = None

    def to_dict(self, **kwargs):
        """Override to_dict to ensure ISO 8601 datetime format"""
        d = super().to_dict(**kwargs)
        # Recursively convert datetime objects to ISO 8601 format
        d = self._convert_datetimes_to_iso(d)
        return d

    @staticmethod
    def _convert_datetimes_to_iso(obj):
        """Recursively convert datetime objects to ISO 8601 strings"""
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        elif isinstance(obj, str) and ' ' in obj and len(obj) >= 19:
            # Fix space-separated datetime strings to ISO format
            # Check if it looks like a datetime (has space, length >= 19)
            try:
                # Try to parse and reformat
                datetime.datetime.strptime(obj[:19], '%Y-%m-%d %H:%M:%S')
                return obj.replace(' ', 'T')
            except ValueError:
                # Not a datetime string, return as-is
                return obj
        elif isinstance(obj, dict):
            return {k: ElasticChaosRunTelemetry._convert_datetimes_to_iso(v)
                    for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [ElasticChaosRunTelemetry._convert_datetimes_to_iso(item)
                    for item in obj]
        else:
            return obj
