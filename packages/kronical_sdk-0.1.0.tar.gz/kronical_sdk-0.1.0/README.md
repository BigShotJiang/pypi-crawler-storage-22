# kronical-sdk

This package has been renamed to **kronical**.

```bash
pip install kronical
```

This placeholder package depends on `kronical` so existing installs will continue to work.
