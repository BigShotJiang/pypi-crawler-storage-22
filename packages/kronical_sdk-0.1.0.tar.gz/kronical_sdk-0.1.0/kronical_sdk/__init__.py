"""This package has moved to 'kronical'. Install with: pip install kronical"""
from kronical import *  # noqa: F401,F403
