# krx300_hj3415/domain/universe.py
from __future__ import annotations

from enum import StrEnum

class UniverseKind(StrEnum):
    KRX300 = "krx300"

