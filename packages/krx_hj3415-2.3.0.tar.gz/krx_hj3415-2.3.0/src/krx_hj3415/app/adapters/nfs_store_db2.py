from __future__ import annotations

from typing import Sequence

from pymongo.asynchronous.database import AsyncDatabase

from db2_hj3415.nfs.repo import delete_codes_from_nfs
from krx_hj3415.app.ports.nfs_cleaner import NfsCleanerPort


class NfsCleanerDb2(NfsCleanerPort):
    def __init__(self, db: AsyncDatabase):
        self._db = db

    async def delete_codes(self, *, codes: Sequence[str]) -> dict[str, int]:
        return await delete_codes_from_nfs(self._db, codes=codes, endpoint=None)