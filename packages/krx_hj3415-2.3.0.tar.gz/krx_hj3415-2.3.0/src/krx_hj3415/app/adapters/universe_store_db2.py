from __future__ import annotations

from pymongo.asynchronous.database import AsyncDatabase

from contracts_hj3415.universe.dto import UniverseDTO
from contracts_hj3415.universe.types import Universe

from db2_hj3415.universe import repo as urepo
from db2_hj3415.universe import mappers as umap

from krx_hj3415.app.ports.universe_store import UniverseStorePort


class UniverseStoreDb2(UniverseStorePort):
    def __init__(self, db: AsyncDatabase):
        self._db = db

    async def get_latest(self, *, universe: Universe) -> UniverseDTO | None:
        doc = await urepo.get_latest(self._db, universe=universe)
        if not doc:
            return None
        return umap.latest_doc_to_dto(doc)

    async def upsert_latest(self, *, dto: UniverseDTO) -> None:
        doc = umap.dto_to_latest_doc(dto)
        await urepo.upsert_latest_doc(self._db, doc=doc)

    async def insert_snapshot(self, *, dto: UniverseDTO) -> None:
        doc = umap.dto_to_snapshot_doc(dto)
        await urepo.insert_snapshot_doc(self._db, doc=doc)