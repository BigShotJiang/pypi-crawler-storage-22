from __future__ import annotations

from typing import Protocol, Sequence


class NfsCleanerPort(Protocol):
    async def delete_codes(self, *, codes: Sequence[str]) -> dict[str, int]:
        ...