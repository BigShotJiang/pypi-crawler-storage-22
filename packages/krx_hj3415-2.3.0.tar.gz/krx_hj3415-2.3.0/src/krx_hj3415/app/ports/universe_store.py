from __future__ import annotations

from typing import Protocol

from contracts_hj3415.universe.dto import UniverseDTO
from contracts_hj3415.universe.types import Universe


class UniverseStorePort(Protocol):
    async def get_latest(self, *, universe: Universe) -> UniverseDTO | None:
        ...

    async def upsert_latest(self, *, dto: UniverseDTO) -> None:
        ...

    async def insert_snapshot(self, *, dto: UniverseDTO) -> None:
        ...