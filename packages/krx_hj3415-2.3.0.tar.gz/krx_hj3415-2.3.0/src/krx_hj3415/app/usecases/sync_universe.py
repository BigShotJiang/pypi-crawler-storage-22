# krx_hj3415/app/usecases/sync_universe.py
from __future__ import annotations

from datetime import datetime
from typing import Iterable, cast

from common_hj3415.utils.time import utcnow

from contracts_hj3415.universe.dto import UniverseItemDTO, UniverseDTO
from contracts_hj3415.universe.types import Universe

from krx_hj3415.app.domain.types import CodeItem, UniverseDiff, UniverseEnum, MarketEnum
from krx_hj3415.app.domain.diff import diff_universe
from krx_hj3415.app.provider.krx300_samsungfund_excel import fetch_krx300_items

from krx_hj3415.app.ports.universe_store import UniverseStorePort
from krx_hj3415.app.ports.nfs_cleaner import NfsCleanerPort


async def refresh_krx300(*, max_days: int = 15) -> tuple[datetime, list[CodeItem]]:
    return fetch_krx300_items(max_days=max_days)


def _dto_to_code_items(dto: UniverseDTO | None) -> list[CodeItem]:
    if not dto:
        return []

    out: list[CodeItem] = []
    for row in dto.get("items", []):
        if not isinstance(row, dict):
            continue
        code = str(row.get("code") or "").strip()
        if not code:
            continue
        name = str(row.get("name") or "").strip()
        market = MarketEnum(row.get("market"))
        # old_item의 asof는 diff 용도라면 dto["asof"]를 쓰는 게 더 자연스럽긴 함(선택)
        out.append(CodeItem(code=code, name=name, asof=utcnow(), market=market))
    return out


def _code_items_to_dtos(
    items: Iterable[CodeItem],
    *,
    market: MarketEnum = MarketEnum.KRX,
) -> list[UniverseItemDTO]:
    """
    krx 도메인 CodeItem 목록을 contracts UniverseItemDTO 목록으로 변환한다.

    - CodeItem.code 는 필수
    - CodeItem.name 은 비어있지 않을 때만 포함
    - market 은 krx 정책(default: "KRX")에 따라 주입
    """
    out: list[UniverseItemDTO] = []

    for it in items:
        if it is None:
            continue

        code = (it.code or "").strip()
        if not code:
            continue

        dto: UniverseItemDTO = {
            "code": code,
            "market": market.value,
        }

        if isinstance(it.name, str) and it.name.strip():
            dto["name"] = it.name.strip()

        out.append(dto)

    return out


async def apply_removed(
    cleaner: NfsCleanerPort,
    *,
    removed_codes: Iterable[str],
) -> dict[str, int]:
    codes = [str(c).strip() for c in removed_codes if c and str(c).strip()]
    if not codes:
        return {"latest_deleted": 0, "snapshots_deleted": 0}
    return await cleaner.delete_codes(codes=codes)


async def run_sync(
    universe_store: UniverseStorePort,
    *,
    universe: UniverseEnum = UniverseEnum.KRX300,
    max_days: int = 15,
    snapshot: bool = True,
) -> UniverseDiff:
    # 1) fetch
    asof, new_items = await refresh_krx300(max_days=max_days)

    # 2) load old (DTO)
    old_dto = await universe_store.get_latest(universe=cast(Universe, universe.value))
    old_items = _dto_to_code_items(old_dto)

    # 3) diff
    d = diff_universe(
        universe=universe, asof=asof, new_items=new_items, old_items=old_items
    )

    # 4) save (DTO로 저장 요청)
    dto: UniverseDTO = {
        "universe": universe.value,
        "asof": asof,
        "source": "samsungfund",
        "items": _code_items_to_dtos(new_items, market=MarketEnum.KRX),
    }
    await universe_store.upsert_latest(dto=dto)
    if snapshot:
        await universe_store.insert_snapshot(dto=dto)

    return d
