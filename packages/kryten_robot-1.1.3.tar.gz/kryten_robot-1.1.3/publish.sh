#!/bin/bash
# Kryten-Robot PyPI Publishing Script
# Version: 0.5.1
# 
# This script automates building and publishing kryten-robot to PyPI.
# It handles cleaning, building, and optionally publishing the package.

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Flags
BUILD=false
PUBLISH=false
TESTPYPI=false
CLEAN=false
HELP=false

function print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

function print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

function print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

function show_help() {
    cat <<EOF
Kryten-Robot PyPI Publishing Script
====================================

Usage: ./publish.sh [OPTIONS]

Options:
    --clean      Clean build artifacts (dist/, build/, *.egg-info/)
    --build      Build the package (creates wheel and source distribution)
    --testpypi   Publish to TestPyPI (for testing before production)
    --publish    Publish to production PyPI
    --help       Show this help message

Examples:
    # Clean and build
    ./publish.sh --clean --build

    # Build and publish to TestPyPI
    ./publish.sh --build --testpypi

    # Build and publish to production PyPI
    ./publish.sh --build --publish

    # Just clean
    ./publish.sh --clean

Prerequisites:
    1. Poetry installed: pip install poetry
    2. PyPI API token configured: poetry config pypi-token.pypi YOUR-TOKEN
    3. (Optional) TestPyPI token: poetry config pypi-token.testpypi YOUR-TOKEN

EOF
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --build)
            BUILD=true
            shift
            ;;
        --publish)
            PUBLISH=true
            shift
            ;;
        --testpypi)
            TESTPYPI=true
            shift
            ;;
        --clean)
            CLEAN=true
            shift
            ;;
        --help)
            HELP=true
            shift
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Show help if requested or no parameters
if [ "$HELP" = true ] || [ "$BUILD" = false ] && [ "$PUBLISH" = false ] && [ "$TESTPYPI" = false ] && [ "$CLEAN" = false ]; then
    show_help
    exit 0
fi

print_info "Kryten-Robot PyPI Publishing Script"
echo -e "${CYAN}====================================${NC}"
echo ""

# Check Poetry is installed
if ! command -v poetry &> /dev/null; then
    print_error "Poetry is not installed or not in PATH"
    echo "Install with: pip install poetry"
    exit 1
fi

POETRY_VERSION=$(poetry --version)
print_info "Poetry version: $POETRY_VERSION"

# Read version from pyproject.toml
if [ -f "pyproject.toml" ]; then
    VERSION=$(grep -m1 'version = "' pyproject.toml | cut -d '"' -f 2)
    print_info "Package version: $VERSION"
else
    print_error "pyproject.toml not found"
    exit 1
fi

# Clean build artifacts
if [ "$CLEAN" = true ]; then
    print_info "Cleaning build artifacts..."
    rm -rf dist build *.egg-info kryten.egg-info 2>/dev/null || true
    print_info "Clean complete"
fi

# Build package
if [ "$BUILD" = true ]; then
    print_info "Building package..."
    echo ""
    
    if poetry build; then
        echo ""
        print_info "Build complete!"
        
        # Show what was built
        if [ -d "dist" ]; then
            print_info "Built packages:"
            ls -1 dist/ | while read -r file; do
                echo -e "  ${CYAN}- $file${NC}"
            done
        fi
    else
        print_error "Build failed"
        exit 1
    fi
fi

# Publish to TestPyPI
if [ "$TESTPYPI" = true ]; then
    echo ""
    print_info "Publishing to TestPyPI..."
    print_warn "This will upload to https://test.pypi.org/"
    
    read -p "Continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_info "Cancelled"
        exit 0
    fi
    
    # Configure TestPyPI repository if not already done
    poetry config repositories.testpypi https://test.pypi.org/legacy/ 2>/dev/null || true
    
    if poetry publish -r testpypi; then
        echo ""
        print_info "Published to TestPyPI!"
        print_info "View at: https://test.pypi.org/project/kryten-robot/$VERSION/"
        print_info "Install with: pip install --index-url https://test.pypi.org/simple/ kryten-robot"
    else
        print_error "TestPyPI publish failed"
        print_warn "Make sure you have configured TestPyPI token:"
        echo "  poetry config pypi-token.testpypi YOUR-TOKEN"
        exit 1
    fi
fi

# Publish to production PyPI
if [ "$PUBLISH" = true ]; then
    echo ""
    print_warn "Publishing to PRODUCTION PyPI..."
    print_warn "This will make version $VERSION publicly available!"
    echo ""
    
    read -p "Are you sure? (yes/N): " -r
    if [ "$REPLY" != "yes" ]; then
        print_info "Cancelled (you must type 'yes' to confirm)"
        exit 0
    fi
    
    if poetry publish; then
        echo ""
        print_info "Published to PyPI!"
        print_info "View at: https://pypi.org/project/kryten-robot/$VERSION/"
        print_info "Install with: pip install kryten-robot"
        print_info "Upgrade with: pip install --upgrade kryten-robot"
    else
        print_error "PyPI publish failed"
        print_warn "Make sure you have configured PyPI token:"
        echo "  poetry config pypi-token.pypi YOUR-TOKEN"
        exit 1
    fi
fi

echo ""
print_info "Done!"
