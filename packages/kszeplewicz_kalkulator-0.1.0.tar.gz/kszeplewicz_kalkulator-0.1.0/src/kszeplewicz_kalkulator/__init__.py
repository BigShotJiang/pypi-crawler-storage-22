def hello() -> str:
    return "Hello from sages-kalkulator!"
