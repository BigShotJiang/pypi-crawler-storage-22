# Security Policy

## Reporting a vulnerability

If you find a security vulnerability in Kuberoku, please report it responsibly.

**Do not open a public issue.**

Instead, use [GitHub's private security advisory](https://github.com/amanjain/kuberoku/security/advisories/new).

Include:
- Description of the vulnerability
- Steps to reproduce
- Impact assessment
- Suggested fix (if you have one)

You'll receive a response within 72 hours.

## Scope

Kuberoku is a CLI/SDK that talks to the Kubernetes API. It does not run server-side components. Security concerns include:

- Secret value leakage in CLI output, logs, or crash reports
- Command injection via user-supplied app names, config values, or arguments
- Unsafe handling of kubeconfig credentials
- Dependency vulnerabilities

## What Kuberoku does NOT protect

- Secrets at rest in K8s (cluster admin responsibility: EncryptionConfiguration)
- RBAC enforcement within a namespace (K8s limitation)
- Network-level encryption (cluster responsibility: mTLS, network policies)

See `docs/NORTHSTAR.txt` Section 1 for the full security model.
