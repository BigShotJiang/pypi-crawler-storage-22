# Changelog

## 0.1.0 (unreleased)

Initial alpha release.

### Added

- **Apps**: create, destroy, info, rename, status, link, maintenance
- **Config**: set, get, unset with secret masking and optimistic concurrency
- **Deploy**: image deploy, build-from-git, multi-process types
- **PS**: scale, restart, stop, type, set commands
- **Releases**: info, rollback, prune with full audit trail
- **Services**: expose, ports, logs, exec, connect, maintenance
- **Addons**: PostgreSQL and Redis with credentials, backup, exec, connect
- **Addon versioning**: create with `--version`, `addons:migrate` (backup → PVC wipe → restore for Postgres), `addons:migrate-rollback`
- **Plugins**: install, uninstall, search via PyPI entry points
- **Domains**: add, remove, clear with Ingress management
- **Clusters**: add, remove, switch, current, info, doctor, setup
- **Networking**: default-deny NetworkPolicies, per-process allow rules
- **SDK**: full Python API matching CLI 1:1, frozen dataclasses, typed exceptions
- **Distribution**: PyPI package, pre-built binaries (Linux, macOS, Windows), curl installer
