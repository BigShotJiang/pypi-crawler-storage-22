# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for kuberoku single-file binary."""

import certifi
import os

block_cipher = None

a = Analysis(
    ["src/kuberoku/__main__.py"],
    pathex=["src"],
    binaries=[],
    datas=[
        # certifi CA bundle — required for kubernetes HTTPS connections
        (certifi.where(), os.path.join("certifi", "")),
    ],
    hiddenimports=[
        # kubernetes (code-generated models + dynamic imports)
        "kubernetes",
        "kubernetes.client",
        "kubernetes.client.api",
        "kubernetes.client.models",
        "kubernetes.client.rest",
        "kubernetes.config",
        "kubernetes.stream",
        "kubernetes.watch",
        # kubernetes transitive deps
        "certifi",
        "urllib3",
        # yaml (C extension)
        "yaml",
        "_yaml",
        # rich + click (full packages)
        "rich",
        "click",
        # kuberoku lazy imports PyInstaller misses
        "kuberoku.k8s.client",
        "kuberoku.config.user",
        "kuberoku.config.project",
        "kuberoku.addons.postgres",
        "kuberoku.addons.redis",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter",
        "unittest",
        "test",
        "xmlrpc",
    ],
    noarchive=False,
    optimize=0,
    cipher=block_cipher,
)

pyz = PYZ(a.pure, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="kuberoku",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
