#!/usr/bin/env bash
#
# Shared utilities for kuberoku scripts.
# Source this file: source "$(dirname "$0")/_common.sh"
#

set -uo pipefail

# ── Paths ───────────────────────────────────────────────────────
SCRIPTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPTS_DIR/.." && pwd)"
cd "$REPO_ROOT"

# ── Python ──────────────────────────────────────────────────────
if [ -f "$REPO_ROOT/.venv/bin/python" ]; then
    PY="$REPO_ROOT/.venv/bin/python"
elif command -v python3 &> /dev/null; then
    PY="python3"
else
    PY="python"
fi

# ── Counters ────────────────────────────────────────────────────
_PASS=0
_FAIL=0
_WARN=0

# ── Output helpers ──────────────────────────────────────────────
section() { printf "\n--- %s ---\n" "$1"; }
pass()    { _PASS=$((_PASS + 1)); printf "  PASS  %s\n" "$1"; }
fail()    { _FAIL=$((_FAIL + 1)); printf "  FAIL  %s\n" "$1"; }
warn()    { _WARN=$((_WARN + 1)); printf "  WARN  %s\n" "$1"; }
skip()    { printf "  SKIP  %s (%s)\n" "$1" "$2"; }

summary() {
    printf "\n"
    if [ "$_FAIL" -gt 0 ]; then
        printf "Result: %d passed, %d failed" "$_PASS" "$_FAIL"
        [ "$_WARN" -gt 0 ] && printf ", %d warnings" "$_WARN"
        printf "\n"
        exit 1
    else
        printf "Result: %d passed" "$_PASS"
        [ "$_WARN" -gt 0 ] && printf ", %d warnings" "$_WARN"
        printf "\n"
    fi
}

# ── Tool checks ─────────────────────────────────────────────────
has_py_tool() {
    "$PY" -m "$1" --version &> /dev/null 2>&1
}

has_command() {
    command -v "$1" &> /dev/null
}

# ── Args ─────────────────────────────────────────────────────────
FIX=false
for arg in "$@"; do
    [ "$arg" = "--fix" ] && FIX=true
done
