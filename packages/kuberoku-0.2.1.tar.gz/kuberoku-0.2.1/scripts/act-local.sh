#!/usr/bin/env bash
# Run GitHub Actions workflow locally via act + colima.
#
# Usage:
#   ./scripts/act-local.sh                     # full matrix (all combos)
#   ./scripts/act-local.sh 3.12 latest         # single combo
#
# Prerequisites:
#   brew install act colima
#   colima start --kubernetes --cpu 2 --memory 4

set -euo pipefail

DOCKER_HOST="unix://${HOME}/.colima/docker.sock"
export DOCKER_HOST

if ! colima status &>/dev/null; then
    echo "Starting colima (with Kubernetes)..."
    colima start --kubernetes --cpu 2 --memory 4
fi

ARGS=(
    -j test
    --container-architecture linux/amd64
    --container-daemon-socket -
)

if [[ $# -ge 1 ]]; then
    ARGS+=(--matrix "python-version:$1")
fi
if [[ $# -ge 2 ]]; then
    ARGS+=(--matrix "kubernetes:$2")
fi

echo "Running: act ${ARGS[*]}"
act "${ARGS[@]}"
