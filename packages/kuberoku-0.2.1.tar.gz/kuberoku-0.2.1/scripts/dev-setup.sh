#!/usr/bin/env bash
#
# One-time dev environment setup for kuberoku contributors.
#
# What this does:
#   1. Creates Python venv + installs dev dependencies
#   2. Installs colima + act (macOS only, via Homebrew)
#   3. Starts colima with Docker + Kubernetes
#   4. Verifies everything works
#
# Usage:
#   ./scripts/dev-setup.sh
#
# After setup, you can:
#   ./scripts/test.sh              # run tests locally
#   ./scripts/lint.sh              # lint + type check
#   ./scripts/act-local.sh 3.12    # run CI locally
#   colima stop                    # stop when done
#

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# ── Helpers ────────────────────────────────────────────────────
step()  { printf "\n==> %s\n" "$1"; }
ok()    { printf "    ✓ %s\n" "$1"; }
skip()  { printf "    - %s (skipped: %s)\n" "$1" "$2"; }
die()   { printf "    ✗ %s\n" "$1" >&2; exit 1; }

# ── 1. Python venv ────────────────────────────────────────────
step "Python virtual environment"

if [ -f "$REPO_ROOT/.venv/bin/python" ]; then
    skip ".venv" "already exists"
else
    python3 -m venv .venv
    ok "Created .venv"
fi

source "$REPO_ROOT/.venv/bin/activate"
pip install --upgrade pip --quiet
pip install -e ".[dev]" --quiet
ok "Installed dev dependencies"

# ── 2. Verify Python tools ────────────────────────────────────
step "Python tools"

python -m pytest --version > /dev/null 2>&1 && ok "pytest" || die "pytest not found"
python -m mypy --version > /dev/null 2>&1 && ok "mypy" || die "mypy not found"
python -m ruff --version > /dev/null 2>&1 && ok "ruff" || die "ruff not found"

# ── 3. Colima + act (macOS only) ──────────────────────────────
step "Docker + Kubernetes runtime (colima)"

if [[ "$(uname)" != "Darwin" ]]; then
    skip "colima" "macOS only — use Docker directly on Linux"
else
    if ! command -v brew &> /dev/null; then
        die "Homebrew not found. Install from https://brew.sh"
    fi

    if ! command -v colima &> /dev/null; then
        brew install colima
        ok "Installed colima"
    else
        ok "colima already installed"
    fi

    if ! command -v act &> /dev/null; then
        brew install act
        ok "Installed act"
    else
        ok "act already installed"
    fi

    # Start colima if not running
    if colima status &>/dev/null; then
        ok "colima already running"
    else
        printf "    Starting colima (first time takes a few minutes)...\n"
        colima start --kubernetes --cpu 2 --memory 4
        ok "colima started with Docker + Kubernetes"
    fi
fi

# ── 4. Verify everything ──────────────────────────────────────
step "Verification"

# Docker
if docker ps &> /dev/null; then
    ok "Docker is working"
else
    if [[ "$(uname)" == "Darwin" ]]; then
        export DOCKER_HOST="unix://${HOME}/.colima/docker.sock"
        if docker ps &> /dev/null; then
            ok "Docker is working (via colima socket)"
            printf "    Note: Add this to your shell profile:\n"
            printf "    export DOCKER_HOST=\"unix://\${HOME}/.colima/docker.sock\"\n"
        else
            die "Docker is not reachable"
        fi
    else
        die "Docker is not reachable"
    fi
fi

# Kubernetes
if command -v kubectl &> /dev/null && kubectl get nodes &> /dev/null; then
    ok "Kubernetes is working ($(kubectl get nodes -o name 2>/dev/null | head -1))"
else
    skip "kubectl" "not available or cluster not ready"
fi

# Tests
python -m pytest tests/ -q --tb=line 2>&1 | tail -1
ok "Tests verified"

# ── Done ───────────────────────────────────────────────────────
step "Setup complete"
printf "\n"
printf "    Quick reference:\n"
printf "    source .venv/bin/activate         # activate venv\n"
printf "    ./scripts/test.sh                 # run tests\n"
printf "    ./scripts/lint.sh                 # lint + type check\n"
printf "    ./scripts/act-local.sh 3.12       # run CI locally\n"
printf "    colima stop                       # stop when done\n"
printf "\n"
