#!/usr/bin/env bash
#
# Code quality checks — "Is the code well-written?"
#
# Usage:
#   ./scripts/lint.sh          # Check formatting, lint, types, dead code
#   ./scripts/lint.sh --fix    # Auto-fix formatting and lint issues
#

source "$(dirname "$0")/_common.sh"

printf "Python: %s\n" "$PY"
printf "Fix mode: %s\n" "$FIX"

# ── Format (ruff format) ────────────────────────────────────────
section "Format (ruff format)"
if [ "$FIX" = true ]; then
    "$PY" -m ruff format src/ tests/ && pass "ruff format" || fail "ruff format"
else
    "$PY" -m ruff format --check src/ tests/ && pass "ruff format" || fail "ruff format"
fi

# ── Lint (ruff check) ───────────────────────────────────────────
section "Lint (ruff check)"
if [ "$FIX" = true ]; then
    "$PY" -m ruff check src/ tests/ --fix && pass "ruff check" || fail "ruff check"
else
    "$PY" -m ruff check src/ tests/ && pass "ruff check" || fail "ruff check"
fi

# ── Types (mypy) ────────────────────────────────────────────────
section "Types (mypy --strict)"
"$PY" -m mypy --strict src/kuberoku/ && pass "mypy --strict" || fail "mypy --strict"

# ── Dead code (vulture) ─────────────────────────────────────────
section "Dead code (vulture)"
if has_py_tool vulture; then
    output=$("$PY" -m vulture src/kuberoku/ --min-confidence 80 2>&1) || true
    if [ -z "$output" ]; then
        pass "vulture"
    else
        warn "vulture — potential unused code found"
        printf "%s\n" "$output"
    fi
else
    skip "vulture" "not installed"
fi

summary
