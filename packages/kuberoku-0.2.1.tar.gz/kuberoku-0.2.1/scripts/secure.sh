#!/usr/bin/env bash
#
# Security checks — "Is the code safe?"
#
# Usage:
#   ./scripts/secure.sh    # Run all security checks
#

source "$(dirname "$0")/_common.sh"

printf "Python: %s\n" "$PY"

# ── Security lint (ruff/bandit rules) ───────────────────────────
section "Security lint (bandit rules)"
"$PY" -m ruff check src/ --select S && pass "bandit rules" || fail "bandit rules"

# ── Secret scanning (gitleaks) ──────────────────────────────────
section "Secret scanning (gitleaks)"
if has_command gitleaks; then
    if gitleaks detect --no-git --source . --redact 2>&1; then
        pass "gitleaks"
    else
        fail "gitleaks — potential secrets detected"
    fi
else
    skip "gitleaks" "not installed — brew install gitleaks"
fi

# ── Dependency audit (pip-audit) ────────────────────────────────
section "Dependency audit (pip-audit)"
if has_py_tool pip_audit; then
    if "$PY" -m pip_audit --skip-editable --progress-spinner=off 2>/dev/null; then
        pass "pip-audit"
    else
        fail "pip-audit — vulnerabilities found"
    fi
else
    skip "pip-audit" "not installed"
fi

summary
