"""Kuberoku — Heroku-like DX on vanilla Kubernetes."""

from kuberoku._version import __version__
from kuberoku.client import Kuberoku

__all__ = ["Kuberoku", "__version__"]
