"""Support for `python -m kuberoku`."""

from kuberoku.cli.main import run

run()
