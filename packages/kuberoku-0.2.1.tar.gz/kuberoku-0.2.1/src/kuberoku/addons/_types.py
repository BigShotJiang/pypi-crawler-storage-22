"""AddonDef — frozen definition of a built-in addon type.

Each built-in addon (postgres, redis) registers an AddonDef that
describes how to create, configure, and manage instances of that type.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AddonDef:
    """Immutable definition of an addon type."""

    type_name: str  # "postgres", "redis"
    image: str  # "postgres:16"
    port: int  # 5432
    protocol: str  # "TCP"
    default_cpu: str  # "250m"
    default_memory: str  # "256Mi"
    default_storage: str | None  # "1Gi" or None
    needs_storage: bool  # True for postgres
    storage_optional: bool  # True for redis (--ephemeral OK)
    needs_auth: bool  # True for postgres
    env_key: str  # "DATABASE_URL"
    url_template: str  # "postgres://{user}:{password}@{host}:{port}/{db}"
    data_dir: str | None  # "/var/lib/postgresql/data"
    volume_name: str  # "pgdata"
    readiness_probe: dict[str, Any]
    exec_command: list[str] | None
    backup_command: list[str] | None
    restore_command: list[str] | None
    container_env_builder: (
        Callable[[str, str, str, str], list[dict[str, Any]]] | None
    )  # (secret_name, user, password, db) -> env list
    # Versioning (optional — backward compatible with existing AddonDefs)
    versions: dict[str, str] | None = None  # {"15": "postgres:15", "16": "postgres:16"}
    default_version: str | None = None  # "16"
    migration_paths: dict[str, tuple[str, ...]] | None = None  # allowed transitions
    # File-based migration commands (binary format, no stdin/stdout piping)
    migrate_dump_command: list[str] | None = None  # writes to migrate_dump_file
    migrate_restore_command: list[str] | None = None  # reads from migrate_dump_file
    migrate_dump_file: str | None = None  # "/tmp/backup.dump"
