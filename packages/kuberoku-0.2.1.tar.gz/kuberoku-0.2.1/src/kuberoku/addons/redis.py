"""Redis addon definition."""

from __future__ import annotations

from typing import Any

from kuberoku.addons._types import AddonDef


def _redis_env(secret_name: str, user: str, password: str, db: str) -> list[dict[str, Any]]:
    """Build container env list for Redis using Secret refs."""
    return [
        {
            "name": "REDIS_PASSWORD",
            "valueFrom": {
                "secretKeyRef": {"name": secret_name, "key": "password"},
            },
        },
    ]


REDIS = AddonDef(
    type_name="redis",
    image="redis:7",
    port=6379,
    protocol="TCP",
    default_cpu="100m",
    default_memory="128Mi",
    default_storage="1Gi",
    needs_storage=True,
    storage_optional=True,  # --ephemeral OK for redis
    needs_auth=True,
    env_key="REDIS_URL",
    url_template="redis://:{password}@{host}:{port}/0",
    data_dir="/data",
    volume_name="redis-data",
    readiness_probe={
        "exec": {
            "command": ["redis-cli", "ping"],
        },
        "initialDelaySeconds": 3,
        "periodSeconds": 5,
        "timeoutSeconds": 3,
    },
    exec_command=["redis-cli", "-a", "{password}"],
    backup_command=None,
    restore_command=None,
    container_env_builder=_redis_env,
    versions={"7": "redis:7", "8": "redis:8"},
    default_version="7",
    migration_paths=None,  # Any transition allowed (stable data format)
)
