"""Single source of truth for all Kuberoku identity constants.

Every other module imports from here. Change TOOL_NAME to rebrand the
entire tool (Layer 1 rebrand — runtime only, one file, 2 minutes).
"""

# The canonical tool name — everything else derives from this.
TOOL_NAME: str = "kuberoku"

# Default resource prefix for K8s resource names ({PREFIX}-app-myapi, etc.)
DEFAULT_RESOURCE_PREFIX: str = TOOL_NAME

# Default label domain for K8s labels/annotations (app.kuberoku.com/*)
# NOT derived from TOOL_NAME — this is a real domain you must own.
# Rebranders: change this to your own domain.
DEFAULT_LABEL_DOMAIN: str = "app.kuberoku.com"

# Plugin PyPI package prefix (kuberoku-postgres, kuberoku-redis, etc.)
PLUGIN_PREFIX: str = f"{TOOL_NAME}-"

# Plugin entry_points group name
PLUGIN_GROUP: str = f"{TOOL_NAME}.plugins"

# Global config directory name (~/.kuberoku/)
CONFIG_DIR_NAME: str = f".{TOOL_NAME}"

# Project marker file name (.kuberoku)
PROJECT_FILE_NAME: str = f".{TOOL_NAME}"

# Environment variable prefix (KUBEROKU_APP, KUBEROKU_CLUSTER, etc.)
ENV_PREFIX: str = f"{TOOL_NAME.upper()}_"

# Default K8s namespace
DEFAULT_NAMESPACE: str = TOOL_NAME

# User config file name (~/.kuberoku/config.yaml)
USER_CONFIG_FILE: str = "config.yaml"

# ── Config limits ────────────────────────────────────────────────
CONFIG_MAX_VARS: int = 256
CONFIG_MAX_KEY_LENGTH: int = 256
CONFIG_MAX_VALUE_SIZE: int = 128 * 1024  # 128 KiB
CONFIG_MAX_TOTAL_SIZE: int = 512 * 1024  # 512 KiB
