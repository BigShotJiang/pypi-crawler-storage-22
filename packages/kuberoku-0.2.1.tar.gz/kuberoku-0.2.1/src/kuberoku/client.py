"""Kuberoku — public SDK facade.

This is the top-level class users import:
    from kuberoku import Kuberoku
    k = Kuberoku()
    k.apps.create("myapp")

Wraps KuberokuFactory. Provides the ergonomic API described in Section 7.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from kuberoku.factory import KuberokuFactory

if TYPE_CHECKING:
    from kuberoku.k8s.protocols import K8sClientProtocol
    from kuberoku.sdk.addons import AddonsService
    from kuberoku.sdk.apps import AppsService
    from kuberoku.sdk.build import BuildService
    from kuberoku.sdk.clusters import ClustersService
    from kuberoku.sdk.config import ConfigService
    from kuberoku.sdk.deploy import DeployService
    from kuberoku.sdk.doctor import DoctorService
    from kuberoku.sdk.domains import DomainsService
    from kuberoku.sdk.plugins import PluginService
    from kuberoku.sdk.ps import PsService
    from kuberoku.sdk.releases import ReleasesService
    from kuberoku.sdk.services import ServicesService


class Kuberoku:
    """Public SDK entry point. Wraps KuberokuFactory."""

    def __init__(
        self,
        context: str | None = None,
        namespace: str | None = None,
        k8s_client: K8sClientProtocol | None = None,
    ) -> None:
        # Context is stored but not used until lazy K8s client creation.
        # For now, the factory creates a K8sClient from the default kubeconfig.
        # The `context` param will be wired when KuberokuFactory gains context support.
        _ = context  # reserved for future use
        self._factory = KuberokuFactory(
            k8s_client=k8s_client,
            namespace=namespace,
        )

    @property
    def apps(self) -> AppsService:
        return self._factory.apps

    @property
    def config(self) -> ConfigService:
        return self._factory.config

    @property
    def deploy(self) -> DeployService:
        return self._factory.deploy

    @property
    def releases(self) -> ReleasesService:
        return self._factory.releases

    @property
    def ps(self) -> PsService:
        return self._factory.ps

    @property
    def services(self) -> ServicesService:
        return self._factory.services

    @property
    def addons(self) -> AddonsService:
        return self._factory.addons

    @property
    def domains(self) -> DomainsService:
        return self._factory.domains

    @property
    def clusters(self) -> ClustersService:
        return self._factory.clusters

    @property
    def doctor(self) -> DoctorService:
        return self._factory.doctor

    @property
    def plugins(self) -> PluginService:
        return self._factory.plugins

    @property
    def build(self) -> BuildService:
        return self._factory.build
