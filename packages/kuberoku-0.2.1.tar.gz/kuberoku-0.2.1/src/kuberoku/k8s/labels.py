"""Label and annotation builders for K8s resources.

Centralizes all label dict construction. One change here updates all
resource builders. Prevents typos in label keys (a silent, nasty bug).
"""

from __future__ import annotations


def for_app(domain: str, prefix: str, app: str, resource_type: str) -> dict[str, str]:
    """Labels for any resource belonging to an app."""
    return {
        f"{domain}/managed-by": prefix,
        f"{domain}/app": app,
        f"{domain}/resource-type": resource_type,
    }


def for_process(domain: str, prefix: str, app: str, process: str) -> dict[str, str]:
    """Labels for a process-type resource (Deployment, Service)."""
    return {
        **for_app(domain, prefix, app, "process"),
        f"{domain}/process-type": process,
    }


def for_addon(
    domain: str,
    prefix: str,
    app: str,
    instance: str,
    addon_type: str,
) -> dict[str, str]:
    """Labels for an addon resource."""
    return {
        **for_app(domain, prefix, app, "addon"),
        f"{domain}/addon-instance": instance,
        f"{domain}/addon-type": addon_type,
    }


def selector(domain: str, app: str, process: str) -> dict[str, str]:
    """Minimal labels for Deployment selector (immutable after creation)."""
    return {
        f"{domain}/app": app,
        f"{domain}/process-type": process,
    }


def managed_by(domain: str, prefix: str) -> dict[str, str]:
    """Labels to find ALL Kuberoku-managed resources."""
    return {f"{domain}/managed-by": prefix}
