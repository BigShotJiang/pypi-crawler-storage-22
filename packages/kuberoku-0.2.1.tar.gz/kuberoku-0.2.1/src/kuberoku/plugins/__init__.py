"""Plugin system for kuberoku.

Plugins extend kuberoku by adding new CLI command groups and addon types.
Discovery is via importlib.metadata entry_points.
"""
