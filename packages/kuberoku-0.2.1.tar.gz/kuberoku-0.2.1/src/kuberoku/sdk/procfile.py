"""Procfile parser.

Reads a Heroku-style Procfile and returns a dict of process type → command.
Format: one `TYPE: COMMAND` per line. Blank lines and # comments are ignored.
"""

from __future__ import annotations

from pathlib import Path


def parse_procfile(path: Path) -> dict[str, str]:
    """Parse a Procfile, returning {process_type: command}.

    Returns an empty dict if the file doesn't exist.
    Ignores blank lines and lines starting with #.
    Splits on the first colon only (commands may contain colons).
    """
    if not path.is_file():
        return {}

    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if ":" not in stripped:
            continue
        key, value = stripped.split(":", 1)
        key = key.strip()
        value = value.strip()
        if key and value:
            result[key] = value
    return result
