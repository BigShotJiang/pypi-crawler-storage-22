"""CLI tests for addons commands via CliRunner."""

from __future__ import annotations

from click.testing import CliRunner

from kuberoku.cli.main import cli
from kuberoku.factory import KuberokuFactory
from tests.backends.fake import FakeK8sClient


def _make_ctx(ns: str) -> dict[str, KuberokuFactory]:
    factory = KuberokuFactory(k8s_client=FakeK8sClient(), namespace=ns)
    factory.apps.create("myapp")
    return {"factory": factory}


def test_cli_addons_create(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    result = cli_runner.invoke(cli, ["addons", "create", "postgres", "-a", "myapp"], obj=obj)
    assert result.exit_code == 0
    assert "postgres" in result.output


def test_cli_addons_list_empty(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    result = cli_runner.invoke(cli, ["addons", "-a", "myapp"], obj=obj)
    assert result.exit_code == 0
    assert "No addons" in result.output


def test_cli_addons_list_with_addon(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(cli, ["addons", "-a", "myapp"], obj=obj)
    assert result.exit_code == 0
    assert "postgres" in result.output


def test_cli_addons_info(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(cli, ["addons", "info", "postgres", "-a", "myapp"], obj=obj)
    assert result.exit_code == 0
    assert "postgres" in result.output
    assert "running" in result.output.lower()


def test_cli_addons_destroy(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons", "destroy", "postgres", "-a", "myapp", "--confirm"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "Destroyed" in result.output


def test_cli_addons_scale(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons", "scale", "postgres", "-a", "myapp", "--memory", "512Mi"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "Scaled" in result.output


def test_cli_addons_credentials(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons", "credentials", "postgres", "-a", "myapp"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "password" in result.output


def test_cli_addons_credentials_rotate(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons", "credentials-rotate", "postgres", "-a", "myapp"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "Rotated" in result.output


def test_cli_colon_credentials_rotate(cli_runner: CliRunner, tmp_namespace: str) -> None:
    """addons:credentials:rotate should work via colon-to-dash resolution."""
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons:credentials:rotate", "postgres", "-a", "myapp"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "Rotated" in result.output


def test_cli_addons_exec(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    obj["factory"].addons.create("myapp", "postgres")
    result = cli_runner.invoke(
        cli,
        ["addons", "exec", "postgres", "-a", "myapp"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "kubectl exec" in result.output


def test_cli_colon_syntax(cli_runner: CliRunner, tmp_namespace: str) -> None:
    """addons:create should work like addons create."""
    obj = _make_ctx(tmp_namespace)
    result = cli_runner.invoke(cli, ["addons:create", "postgres", "-a", "myapp"], obj=obj)
    assert result.exit_code == 0
    assert "postgres" in result.output


def test_cli_addons_create_with_as(cli_runner: CliRunner, tmp_namespace: str) -> None:
    obj = _make_ctx(tmp_namespace)
    result = cli_runner.invoke(
        cli,
        ["addons", "create", "postgres", "-a", "myapp", "--as", "analytics-db"],
        obj=obj,
    )
    assert result.exit_code == 0
    assert "analytics-db" in result.output
