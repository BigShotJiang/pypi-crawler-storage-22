"""Tests for AddonsService.credentials and credentials_rotate."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory


def test_credentials_show(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    creds = app_factory.addons.credentials("myapp", "postgres")
    assert creds["username"] == "kuberoku"
    assert len(creds["password"]) > 0
    assert "database" in creds
    assert "url" in creds
    assert "postgres://" in creds["url"]


def test_credentials_rotate(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    old_creds = app_factory.addons.credentials("myapp", "postgres")
    new_creds = app_factory.addons.credentials_rotate("myapp", "postgres")
    assert new_creds["password"] != old_creds["password"]
    assert new_creds["username"] == old_creds["username"]
    assert "postgres://" in new_creds["url"]


def test_credentials_rotate_updates_config(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    new_creds = app_factory.addons.credentials_rotate("myapp", "postgres")
    config = app_factory.config.list("myapp")
    assert new_creds["password"] in config["DATABASE_URL"]


def test_credentials_redis(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "redis")
    creds = app_factory.addons.credentials("myapp", "redis")
    assert len(creds["password"]) > 0
    assert "redis://" in creds["url"]
