"""Tests for AddonsService.destroy — cleanup of all addon resources."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AddonNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import addon_pvc_name, safe_name
from tests.backends.fake import FakeNotFoundError


def test_destroy_removes_statefulset(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.destroy("myapp", "postgres")
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)


def test_destroy_removes_service(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.destroy("myapp", "postgres")
    svc_name = safe_name(app_factory.prefix, "addon", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_service(app_factory.namespace, svc_name)


def test_destroy_removes_network_policy(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.destroy("myapp", "postgres")
    np_name = safe_name(app_factory.prefix, "netpol-allow", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_network_policy(app_factory.namespace, np_name)


def test_destroy_removes_credential_secret(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.destroy("myapp", "postgres")
    secret_name = safe_name(app_factory.prefix, "addon-secret", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_secret(app_factory.namespace, secret_name)


def test_destroy_removes_metadata(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.destroy("myapp", "postgres")
    cm_name = safe_name(app_factory.prefix, "addon-meta", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_configmap(app_factory.namespace, cm_name)


def test_destroy_retains_pvc_by_default(app_factory: KuberokuFactory) -> None:
    """PVC is NOT deleted unless --delete-data is used."""
    app_factory.addons.create("myapp", "postgres")
    # Simulate PVC creation (real K8s creates this from volumeClaimTemplate)
    pvc_name = addon_pvc_name(app_factory.prefix, "myapp", "postgres", "pgdata")
    app_factory.k8s.create_pvc(
        app_factory.namespace,
        {"apiVersion": "v1", "kind": "PersistentVolumeClaim", "metadata": {"name": pvc_name}},
    )
    app_factory.addons.destroy("myapp", "postgres")
    # PVC should still exist
    pvc = app_factory.k8s.get_pvc(app_factory.namespace, pvc_name)
    assert pvc["metadata"]["name"] == pvc_name


def test_destroy_delete_data(app_factory: KuberokuFactory) -> None:
    """--delete-data deletes the PVC."""
    app_factory.addons.create("myapp", "postgres")
    pvc_name = addon_pvc_name(app_factory.prefix, "myapp", "postgres", "pgdata")
    app_factory.k8s.create_pvc(
        app_factory.namespace,
        {"apiVersion": "v1", "kind": "PersistentVolumeClaim", "metadata": {"name": pvc_name}},
    )
    app_factory.addons.destroy("myapp", "postgres", delete_data=True)
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_pvc(app_factory.namespace, pvc_name)


def test_destroy_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(AddonNotFoundError):
        app_factory.addons.destroy("myapp", "nonexistent")


def test_destroy_on_step(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    steps: list[str] = []
    app_factory.addons.destroy("myapp", "postgres", on_step=steps.append)
    assert len(steps) > 0


def test_destroy_from_app_destroy(app_factory: KuberokuFactory) -> None:
    """apps:destroy should clean up addon StatefulSets."""
    app_factory.addons.create("myapp", "postgres")
    app_factory.apps.destroy("myapp")
    # StatefulSet should be gone
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)
