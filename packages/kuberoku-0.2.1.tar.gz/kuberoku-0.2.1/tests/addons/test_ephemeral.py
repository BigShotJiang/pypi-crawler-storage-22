"""Tests for ephemeral addons (no PVC)."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import KuberokuError
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name


def test_redis_ephemeral(app_factory: KuberokuFactory) -> None:
    """Redis supports ephemeral mode (no PVC)."""
    addon = app_factory.addons.create("myapp", "redis", ephemeral=True)
    assert addon.ephemeral is True
    assert addon.storage is None
    # StatefulSet should have no volumeClaimTemplates
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-redis")
    sts = app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)
    assert "volumeClaimTemplates" not in sts.get("spec", {})


def test_postgres_ephemeral_fails(app_factory: KuberokuFactory) -> None:
    """Postgres requires persistent storage — ephemeral mode is an error."""
    with pytest.raises(KuberokuError, match="requires persistent storage"):
        app_factory.addons.create("myapp", "postgres", ephemeral=True)


def test_redis_non_ephemeral_has_pvc(app_factory: KuberokuFactory) -> None:
    """Non-ephemeral redis should have volumeClaimTemplates."""
    app_factory.addons.create("myapp", "redis")
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-redis")
    sts = app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)
    assert "volumeClaimTemplates" in sts["spec"]
