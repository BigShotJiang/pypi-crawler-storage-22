"""Tests for external addons (no StatefulSet, just URL injection)."""

from __future__ import annotations

import pytest

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name
from tests.backends.fake import FakeNotFoundError


def test_external_no_statefulset(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres", external_url="postgres://external:5432/db")
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-postgres")
    with pytest.raises(FakeNotFoundError):
        app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)


def test_external_injects_url(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres", external_url="postgres://external:5432/db")
    config = app_factory.config.list("myapp")
    assert config["DATABASE_URL"] == "postgres://external:5432/db"


def test_external_shows_in_list(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres", external_url="postgres://external:5432/db")
    addons = app_factory.addons.list("myapp")
    assert len(addons) == 1
    assert addons[0].external is True
