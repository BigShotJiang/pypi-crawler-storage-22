"""Tests for AddonsService.info."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AddonNotFoundError
from kuberoku.factory import KuberokuFactory


def test_info_running(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    addon = app_factory.addons.info("myapp", "postgres")
    assert addon.addon_type == "postgres"
    assert addon.status == "running"
    assert addon.image == "postgres:16"
    assert addon.cpu == "250m"
    assert addon.memory == "256Mi"


def test_info_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(AddonNotFoundError):
        app_factory.addons.info("myapp", "nonexistent")


def test_info_redis(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "redis")
    addon = app_factory.addons.info("myapp", "redis")
    assert addon.addon_type == "redis"
    assert addon.image == "redis:7"
