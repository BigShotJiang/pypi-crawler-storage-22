"""Tests for AddonsService.list."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AppNotFoundError
from kuberoku.factory import KuberokuFactory


def test_list_empty(app_factory: KuberokuFactory) -> None:
    addons = app_factory.addons.list("myapp")
    assert addons == []


def test_list_single(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    addons = app_factory.addons.list("myapp")
    assert len(addons) == 1
    assert addons[0].addon_type == "postgres"


def test_list_multiple(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.create("myapp", "redis")
    addons = app_factory.addons.list("myapp")
    assert len(addons) == 2
    types = {a.addon_type for a in addons}
    assert types == {"postgres", "redis"}


def test_list_sorted_by_name(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "redis")
    app_factory.addons.create("myapp", "postgres")
    addons = app_factory.addons.list("myapp")
    assert addons[0].instance_name == "postgres"
    assert addons[1].instance_name == "redis"


def test_list_app_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(AppNotFoundError):
        app_factory.addons.list("nonexistent")
