"""Tests for multi-instance addons (same type, different names)."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory


def test_two_postgres_instances(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.create("myapp", "postgres", instance_name="analytics-db")
    addons = app_factory.addons.list("myapp")
    assert len(addons) == 2
    names = {a.instance_name for a in addons}
    assert names == {"postgres", "analytics-db"}


def test_named_instance_env_key(app_factory: KuberokuFactory) -> None:
    """Named instances get {NAME_UPPER}_URL instead of default."""
    app_factory.addons.create("myapp", "postgres")
    addon2 = app_factory.addons.create("myapp", "postgres", instance_name="analytics-db")
    assert addon2.env_key == "ANALYTICS_DB_URL"


def test_default_instance_gets_default_key(app_factory: KuberokuFactory) -> None:
    addon = app_factory.addons.create("myapp", "postgres")
    assert addon.env_key == "DATABASE_URL"


def test_multi_instance_separate_credentials(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    app_factory.addons.create("myapp", "postgres", instance_name="analytics-db")
    creds1 = app_factory.addons.credentials("myapp", "postgres")
    creds2 = app_factory.addons.credentials("myapp", "analytics-db")
    assert creds1["password"] != creds2["password"]


def test_three_postgres_two_redis_same_app(app_factory: KuberokuFactory) -> None:
    """3 postgres + 2 redis in the same app — verifies env keys, isolation, list."""
    pg1 = app_factory.addons.create("myapp", "postgres")
    pg2 = app_factory.addons.create("myapp", "postgres", instance_name="analytics-db")
    pg3 = app_factory.addons.create("myapp", "postgres", instance_name="audit-db")
    r1 = app_factory.addons.create("myapp", "redis")
    r2 = app_factory.addons.create("myapp", "redis", instance_name="cache")

    # All 5 addons visible
    addons = app_factory.addons.list("myapp")
    assert len(addons) == 5
    names = {a.instance_name for a in addons}
    assert names == {"postgres", "analytics-db", "audit-db", "redis", "cache"}

    # Env keys are unique
    env_keys = {a.env_key for a in addons}
    assert len(env_keys) == 5
    assert pg1.env_key == "DATABASE_URL"
    assert pg2.env_key == "ANALYTICS_DB_URL"
    assert pg3.env_key == "AUDIT_DB_URL"
    assert r1.env_key == "REDIS_URL"
    assert r2.env_key == "CACHE_URL"

    # Each addon has separate credentials
    all_passwords = set()
    for name in names:
        creds = app_factory.addons.credentials("myapp", name)
        all_passwords.add(creds["password"])
    assert len(all_passwords) == 5

    # Info works for each
    for name in names:
        addon_info = app_factory.addons.info("myapp", name)
        assert addon_info.status == "running"

    # Destroy one postgres, others unaffected
    app_factory.addons.destroy("myapp", "audit-db")
    remaining = app_factory.addons.list("myapp")
    assert len(remaining) == 4
    remaining_names = {a.instance_name for a in remaining}
    assert "audit-db" not in remaining_names

    # Config still has the other 4 env vars
    config = app_factory.config.list("myapp")
    assert "DATABASE_URL" in config
    assert "ANALYTICS_DB_URL" in config
    assert "REDIS_URL" in config
    assert "CACHE_URL" in config
    assert "AUDIT_DB_URL" not in config
