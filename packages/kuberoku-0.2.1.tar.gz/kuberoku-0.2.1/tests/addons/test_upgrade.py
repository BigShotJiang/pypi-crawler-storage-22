"""Tests for AddonsService.scale (formerly upgrade)."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name


def test_scale_memory(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    addon = app_factory.addons.scale("myapp", "postgres", memory="512Mi")
    assert addon.memory == "512Mi"
    sts_name = safe_name(app_factory.prefix, "addon", "myapp-postgres")
    sts = app_factory.k8s.get_statefulset(app_factory.namespace, sts_name)
    res = sts["spec"]["template"]["spec"]["containers"][0]["resources"]
    assert res["requests"]["memory"] == "512Mi"


def test_scale_cpu(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    addon = app_factory.addons.scale("myapp", "postgres", cpu="500m")
    assert addon.cpu == "500m"


def test_scale_cpu_and_memory(app_factory: KuberokuFactory) -> None:
    app_factory.addons.create("myapp", "postgres")
    addon = app_factory.addons.scale("myapp", "postgres", cpu="500m", memory="1Gi")
    assert addon.cpu == "500m"
    assert addon.memory == "1Gi"
