"""Shared fixtures for apps tests."""

from __future__ import annotations

import pytest

from kuberoku.factory import KuberokuFactory
from kuberoku.sdk.apps import AppsService


@pytest.fixture()
def apps_service(factory: KuberokuFactory) -> AppsService:
    """AppsService instance — backend determined by --backend flag."""
    return factory.apps
