"""Shared fixtures for config tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from kuberoku.factory import KuberokuFactory
    from kuberoku.sdk.config import ConfigService


@pytest.fixture()
def config_service(factory: KuberokuFactory) -> ConfigService:
    """ConfigService instance — backend determined by --backend flag."""
    return factory.config


@pytest.fixture()
def app_name(factory: KuberokuFactory) -> str:
    """Create an app and return its name (config commands need an existing app)."""
    factory.apps.create("testapp")
    return "testapp"
