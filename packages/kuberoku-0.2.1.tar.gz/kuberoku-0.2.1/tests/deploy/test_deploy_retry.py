"""Tests for deploy retry on 409 Conflict and command removal paths."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name
from tests.backends.fake import FakeK8sClient


def test_update_deployment_retries_on_409() -> None:
    """Deploy update retries on 409 Conflict."""
    k8s = FakeK8sClient()
    factory = KuberokuFactory(k8s_client=k8s, namespace="test-ns")
    factory.apps.create("myapp")
    factory.deploy.deploy("myapp", image="myapp:v1", wait=False)

    dep_name = safe_name(factory.prefix, "myapp", "web")
    k8s.inject_conflict("Deployment", factory.namespace, dep_name, count=2)

    factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    dep = k8s.get_deployment(factory.namespace, dep_name)
    assert dep["spec"]["template"]["spec"]["containers"][0]["image"] == "myapp:v2"


def test_update_deployment_exhausts_retries() -> None:
    """Deploy update exhausts retry loop, succeeds on final attempt."""
    k8s = FakeK8sClient()
    factory = KuberokuFactory(k8s_client=k8s, namespace="test-ns")
    factory.apps.create("myapp")
    factory.deploy.deploy("myapp", image="myapp:v1", wait=False)

    dep_name = safe_name(factory.prefix, "myapp", "web")
    # 5 conflicts = exhausts retry loop (5 attempts), succeeds on final attempt
    k8s.inject_conflict("Deployment", factory.namespace, dep_name, count=5)

    factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    dep = k8s.get_deployment(factory.namespace, dep_name)
    assert dep["spec"]["template"]["spec"]["containers"][0]["image"] == "myapp:v2"


def test_deploy_removes_command_when_none() -> None:
    """Redeploying without a command removes the previously-set command."""
    k8s = FakeK8sClient()
    factory = KuberokuFactory(k8s_client=k8s, namespace="test-ns")
    factory.apps.create("myapp")
    factory.deploy.deploy("myapp", image="myapp:v1", wait=False)

    # Manually set a command on the deployment
    dep_name = safe_name(factory.prefix, "myapp", "web")
    dep = k8s.get_deployment(factory.namespace, dep_name)
    dep["spec"]["template"]["spec"]["containers"][0]["command"] = ["/bin/sh", "-c", "old-cmd"]
    k8s.update_deployment(factory.namespace, dep_name, dep)

    # Redeploy with no command — should remove the command
    factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    dep = k8s.get_deployment(factory.namespace, dep_name)
    assert "command" not in dep["spec"]["template"]["spec"]["containers"][0]


def test_restart_deployment_retries_on_409() -> None:
    """Restart deployment retries on 409 Conflict."""
    k8s = FakeK8sClient()
    factory = KuberokuFactory(k8s_client=k8s, namespace="test-ns")
    factory.apps.create("myapp")
    factory.deploy.deploy("myapp", image="myapp:v1", wait=False)

    dep_name = safe_name(factory.prefix, "myapp", "web")
    k8s.inject_conflict("Deployment", factory.namespace, dep_name, count=2)

    count = factory.deploy._restart_deployments("myapp")
    assert count == 1


def test_restart_deployment_exhausts_retries() -> None:
    """Restart deployment exhausts retry loop, succeeds on final attempt."""
    k8s = FakeK8sClient()
    factory = KuberokuFactory(k8s_client=k8s, namespace="test-ns")
    factory.apps.create("myapp")
    factory.deploy.deploy("myapp", image="myapp:v1", wait=False)

    dep_name = safe_name(factory.prefix, "myapp", "web")
    k8s.inject_conflict("Deployment", factory.namespace, dep_name, count=5)

    count = factory.deploy._restart_deployments("myapp")
    assert count == 1
