"""Tests for ReleasesService.list and .info."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AppNotFoundError, ReleaseNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.models import ProcessFormation


def _create_releases(factory: KuberokuFactory, count: int) -> None:
    formation = {"web": ProcessFormation(1, None, "default")}
    for i in range(1, count + 1):
        factory.releases.create_release(
            "myapp", images={"web": f"v{i}"}, formation=formation, description=f"Release v{i}"
        )


def test_list_empty(app_factory: KuberokuFactory) -> None:
    releases = app_factory.releases.list("myapp")
    assert releases == []


def test_list_returns_newest_first(app_factory: KuberokuFactory) -> None:
    _create_releases(app_factory, 3)
    releases = app_factory.releases.list("myapp")
    assert [r.version for r in releases] == [3, 2, 1]


def test_list_num_limit(app_factory: KuberokuFactory) -> None:
    _create_releases(app_factory, 5)
    releases = app_factory.releases.list("myapp", num=2)
    assert len(releases) == 2
    assert releases[0].version == 5


def test_list_app_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(AppNotFoundError):
        app_factory.releases.list("nonexistent")


def test_info_happy_path(app_factory: KuberokuFactory) -> None:
    _create_releases(app_factory, 3)
    release = app_factory.releases.info("myapp", 2)
    assert release.version == 2
    assert release.description == "Release v2"


def test_info_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(ReleaseNotFoundError):
        app_factory.releases.info("myapp", 99)


def test_info_app_not_found(app_factory: KuberokuFactory) -> None:
    with pytest.raises(AppNotFoundError):
        app_factory.releases.info("nonexistent", 1)
