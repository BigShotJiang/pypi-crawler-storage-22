"""Tests for ReleasesService.rollback."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import ReleaseNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name


def test_rollback_to_previous(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    release = app_factory.releases.rollback("myapp")
    assert release.images["web"] == "myapp:v1"
    assert "Rollback" in release.description


def test_rollback_to_specific_version(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v3", wait=False)
    release = app_factory.releases.rollback("myapp", version=1)
    assert release.images["web"] == "myapp:v1"


def test_rollback_creates_new_release(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    release = app_factory.releases.rollback("myapp")
    # v1=deploy, v2=deploy, v3=rollback
    assert release.version == 3


def test_rollback_updates_deployment(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    app_factory.releases.rollback("myapp")
    dep = app_factory.k8s.get_deployment(
        app_factory.namespace, safe_name(app_factory.prefix, "myapp", "web")
    )
    assert dep["spec"]["template"]["spec"]["containers"][0]["image"] == "myapp:v1"


def test_rollback_restores_formation(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", replicas=2, wait=False)
    app_factory.ps.scale("myapp", {"web": 5})
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    # Rollback to v1 (which had 2 replicas formation)
    release = app_factory.releases.rollback("myapp", version=1)
    assert release.formation["web"].replicas == 2


def test_rollback_version_not_found(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    with pytest.raises(ReleaseNotFoundError):
        app_factory.releases.rollback("myapp", version=99)


def test_rollback_no_previous(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    with pytest.raises(ReleaseNotFoundError):
        app_factory.releases.rollback("myapp")


def test_rollback_on_step(app_factory: KuberokuFactory) -> None:
    app_factory.deploy.deploy("myapp", image="myapp:v1", wait=False)
    app_factory.deploy.deploy("myapp", image="myapp:v2", wait=False)
    steps: list[str] = []
    app_factory.releases.rollback("myapp", on_step=steps.append)
    assert any("Rolling back" in s or "Rollback" in s.lower() for s in steps)
