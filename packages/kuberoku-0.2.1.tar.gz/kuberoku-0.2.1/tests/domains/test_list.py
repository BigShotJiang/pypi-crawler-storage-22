"""Tests for domains list."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AppNotFoundError
from kuberoku.factory import KuberokuFactory


class TestDomainsList:
    def test_list_empty(self, factory: KuberokuFactory, app_with_web: str) -> None:
        domains = factory.domains.list(app_with_web)
        assert domains == []

    def test_list_single(self, factory: KuberokuFactory, app_with_web: str) -> None:
        factory.domains.add(app_with_web, "api.example.com")
        domains = factory.domains.list(app_with_web)
        assert len(domains) == 1
        assert domains[0].hostname == "api.example.com"
        assert domains[0].tls is True

    def test_list_multiple_sorted(self, factory: KuberokuFactory, app_with_web: str) -> None:
        factory.domains.add(app_with_web, "beta.example.com")
        factory.domains.add(app_with_web, "alpha.example.com")
        domains = factory.domains.list(app_with_web)
        assert len(domains) == 2
        assert domains[0].hostname == "alpha.example.com"
        assert domains[1].hostname == "beta.example.com"

    def test_list_shows_auto_generated(self, factory: KuberokuFactory, app_with_web: str) -> None:
        factory.domains.add(app_with_web, "myapp.apps.example.com", auto_generated=True)
        factory.domains.add(app_with_web, "api.example.com")
        domains = factory.domains.list(app_with_web)
        auto = [d for d in domains if d.auto_generated]
        custom = [d for d in domains if not d.auto_generated]
        assert len(auto) == 1
        assert len(custom) == 1

    def test_list_nonexistent_app_raises(self, factory: KuberokuFactory) -> None:
        with pytest.raises(AppNotFoundError):
            factory.domains.list("nonexistent")
