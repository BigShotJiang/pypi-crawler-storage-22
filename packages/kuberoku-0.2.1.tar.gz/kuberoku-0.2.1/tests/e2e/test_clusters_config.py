"""E2E test: cluster config CRUD — pure filesystem, no K8s needed.

Tests add/remove/list/switch/info against a temp config file.
Run with: pytest tests/e2e/test_clusters_config.py -v -s
"""

from __future__ import annotations

import pathlib

from kuberoku.config.user import (
    add_cluster,
    get_cluster,
    get_current_cluster_name,
    list_clusters,
    remove_cluster,
    set_current_cluster,
)


def _config_path(tmp_path: pathlib.Path) -> pathlib.Path:
    """Return a temp config.yaml path."""
    d = tmp_path / ".kuberoku"
    d.mkdir(exist_ok=True)
    return d / "config.yaml"


def test_00_add_cluster(tmp_path: pathlib.Path) -> None:
    """Add first cluster."""
    p = _config_path(tmp_path)
    cfg = add_cluster("dev", "dev-context", namespace="dev-ns", path=p)
    assert cfg.name == "dev"
    assert cfg.context == "dev-context"
    assert cfg.namespace == "dev-ns"
    result = get_cluster("dev", path=p)
    assert result is not None
    assert result.name == "dev"
    print(f"\n  Added cluster: {result.name}")


def test_01_add_second_cluster(tmp_path: pathlib.Path) -> None:
    """Add a second cluster."""
    p = _config_path(tmp_path)
    add_cluster("dev", "dev-context", path=p)
    add_cluster("prod", "prod-context", namespace="production", path=p)
    result = get_cluster("prod", path=p)
    assert result is not None
    assert result.name == "prod"
    assert result.namespace == "production"
    print(f"\n  Added cluster: {result.name}")


def test_02_list_clusters(tmp_path: pathlib.Path) -> None:
    """List should show both clusters."""
    p = _config_path(tmp_path)
    add_cluster("dev", "dev-context", path=p)
    add_cluster("prod", "prod-context", path=p)
    clusters = list_clusters(path=p)
    names = [c.name for c in clusters]
    assert "dev" in names
    assert "prod" in names
    print(f"\n  Clusters: {names}")


def test_03_current_is_first(tmp_path: pathlib.Path) -> None:
    """Current cluster should be the first one added."""
    p = _config_path(tmp_path)
    add_cluster("dev", "dev-context", path=p)
    add_cluster("prod", "prod-context", path=p)
    current = get_current_cluster_name(path=p)
    assert current == "dev"
    print(f"\n  Current cluster: {current}")


def test_04_switch_cluster(tmp_path: pathlib.Path) -> None:
    """Switch to prod."""
    p = _config_path(tmp_path)
    add_cluster("dev", "dev-context", path=p)
    add_cluster("prod", "prod-context", path=p)
    set_current_cluster("prod", path=p)
    current = get_current_cluster_name(path=p)
    assert current == "prod"
    print(f"\n  Switched to: {current}")


def test_05_remove_cluster(tmp_path: pathlib.Path) -> None:
    """Remove dev cluster."""
    p = _config_path(tmp_path)
    add_cluster("dev", "dev-context", path=p)
    add_cluster("prod", "prod-context", path=p)
    removed = remove_cluster("dev", path=p)
    assert removed is True
    clusters = list_clusters(path=p)
    names = [c.name for c in clusters]
    assert "dev" not in names
    assert "prod" in names
    print(f"\n  After remove: {names}")


def test_06_info_cluster(tmp_path: pathlib.Path) -> None:
    """Get cluster info with all fields."""
    p = _config_path(tmp_path)
    add_cluster(
        "staging",
        "staging-ctx",
        namespace="stg",
        base_domain="apps.staging.com",
        path=p,
    )
    result = get_cluster("staging", path=p)
    assert result is not None
    assert result.context == "staging-ctx"
    assert result.namespace == "stg"
    assert result.base_domain == "apps.staging.com"
    print(f"\n  Cluster info: {result}")
