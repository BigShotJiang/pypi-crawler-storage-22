"""E2E test: releases:prune — deploy multiple versions and prune.

Run with: pytest tests/e2e/test_releases_prune.py --backend real -v -s
"""

from __future__ import annotations

from typing import Any

import pytest

from kuberoku.factory import KuberokuFactory
from tests.e2e.helpers import (
    cleanup_namespace_fixture,
    make_real_factory,
    skip_if_no_cluster,
    wait_for_pods_ready,
)


@pytest.fixture(scope="module")
def real_factory() -> KuberokuFactory:
    return make_real_factory("e2e-prune")


@pytest.fixture(scope="module", autouse=True)
def cleanup_namespace(real_factory: KuberokuFactory) -> Any:
    yield
    cleanup_namespace_fixture(real_factory)


def test_00_skip_if_no_cluster() -> None:
    """Skip the entire module if no cluster is available."""
    skip_if_no_cluster()


def test_01_create_and_deploy_v1(real_factory: KuberokuFactory) -> None:
    """Create app and deploy v1."""
    real_factory.apps.create("prunetest")
    release = real_factory.deploy.deploy(
        "prunetest",
        image="nginx:1.27-alpine",
        ports=[{"containerPort": 80, "protocol": "TCP"}],
        wait=False,
    )
    assert release.version == 1
    wait_for_pods_ready(real_factory, "prunetest", expected=1)
    print(f"\n  Deployed v{release.version}")


def test_02_deploy_v2_v3(real_factory: KuberokuFactory) -> None:
    """Deploy v2 and v3 — 3 releases total."""
    r2 = real_factory.deploy.deploy(
        "prunetest",
        image="nginx:1.27",
        ports=[{"containerPort": 80, "protocol": "TCP"}],
        wait=False,
        no_procfile=True,
    )
    assert r2.version == 2

    r3 = real_factory.deploy.deploy(
        "prunetest",
        image="nginx:1.27-alpine",
        ports=[{"containerPort": 80, "protocol": "TCP"}],
        wait=False,
        no_procfile=True,
    )
    assert r3.version == 3
    wait_for_pods_ready(real_factory, "prunetest", expected=1, image="nginx:1.27-alpine")
    print(f"\n  Deployed v2 and v3")


def test_03_verify_three_releases(real_factory: KuberokuFactory) -> None:
    """Verify 3 releases exist."""
    releases = real_factory.releases.list("prunetest")
    assert len(releases) >= 3
    for r in releases:
        print(f"  v{r.version}: {r.description}")


def test_04_prune_keep_1(real_factory: KuberokuFactory) -> None:
    """Prune releases, keeping only 1."""
    pruned = real_factory.releases.prune("prunetest", keep=1)
    print(f"\n  Pruned {pruned} release(s)")
    assert pruned >= 2


def test_05_verify_one_release(real_factory: KuberokuFactory) -> None:
    """Only the latest release should remain."""
    releases = real_factory.releases.list("prunetest")
    assert len(releases) == 1
    assert releases[0].version == 3
    print(f"\n  Remaining: v{releases[0].version}")


def test_06_cleanup(real_factory: KuberokuFactory) -> None:
    """Destroy the app."""
    real_factory.apps.destroy("prunetest")
    apps = real_factory.apps.list()
    assert not any(a.name == "prunetest" for a in apps)
    print("\n  Cleaned up")
