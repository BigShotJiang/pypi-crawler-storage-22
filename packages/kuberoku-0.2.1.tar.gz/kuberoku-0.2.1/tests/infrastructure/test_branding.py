"""Tests for branding.py — all identity constants derive from TOOL_NAME."""

from kuberoku.branding import (
    CONFIG_DIR_NAME,
    DEFAULT_LABEL_DOMAIN,
    DEFAULT_NAMESPACE,
    DEFAULT_RESOURCE_PREFIX,
    ENV_PREFIX,
    PLUGIN_GROUP,
    PLUGIN_PREFIX,
    PROJECT_FILE_NAME,
    TOOL_NAME,
)


class TestBrandingDerivation:
    """Verify every constant derives from TOOL_NAME — the 2-minute rebrand promise."""

    def test_tool_name_is_kuberoku(self) -> None:
        assert TOOL_NAME == "kuberoku"

    def test_resource_prefix_matches_tool_name(self) -> None:
        assert DEFAULT_RESOURCE_PREFIX == TOOL_NAME

    def test_label_domain_contains_tool_name(self) -> None:
        assert TOOL_NAME in DEFAULT_LABEL_DOMAIN
        assert DEFAULT_LABEL_DOMAIN == "app.kuberoku.com"

    def test_plugin_prefix_is_tool_name_dash(self) -> None:
        assert f"{TOOL_NAME}-" == PLUGIN_PREFIX

    def test_plugin_group_is_tool_name_dot_plugins(self) -> None:
        assert f"{TOOL_NAME}.plugins" == PLUGIN_GROUP

    def test_config_dir_is_dot_tool_name(self) -> None:
        assert f".{TOOL_NAME}" == CONFIG_DIR_NAME

    def test_project_file_is_dot_tool_name(self) -> None:
        assert f".{TOOL_NAME}" == PROJECT_FILE_NAME

    def test_env_prefix_is_upper_tool_name(self) -> None:
        assert f"{TOOL_NAME.upper()}_" == ENV_PREFIX
        assert ENV_PREFIX == "KUBEROKU_"

    def test_default_namespace_is_tool_name(self) -> None:
        assert DEFAULT_NAMESPACE == TOOL_NAME
