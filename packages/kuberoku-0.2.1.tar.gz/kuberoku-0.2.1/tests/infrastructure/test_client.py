"""Tests for client.py — Kuberoku public facade."""

from __future__ import annotations

from kuberoku import Kuberoku
from kuberoku.sdk.addons import AddonsService
from kuberoku.sdk.apps import AppsService
from kuberoku.sdk.build import BuildService
from kuberoku.sdk.clusters import ClustersService
from kuberoku.sdk.config import ConfigService
from kuberoku.sdk.deploy import DeployService
from kuberoku.sdk.doctor import DoctorService
from kuberoku.sdk.domains import DomainsService
from kuberoku.sdk.plugins import PluginService
from kuberoku.sdk.ps import PsService
from kuberoku.sdk.releases import ReleasesService
from kuberoku.sdk.services import ServicesService
from tests.backends.fake import FakeK8sClient


class TestKuberokuFacade:
    def test_create_with_k8s_client(self) -> None:
        k = Kuberoku(k8s_client=FakeK8sClient(), namespace="test")
        assert isinstance(k.apps, AppsService)

    def test_create_default(self) -> None:
        """Creating without k8s_client — factory stays lazy."""
        k = Kuberoku(k8s_client=FakeK8sClient())
        assert isinstance(k.apps, AppsService)

    def test_apps_create_via_facade(self) -> None:
        k = Kuberoku(k8s_client=FakeK8sClient(), namespace="test")
        app = k.apps.create("myapi")
        assert app.name == "myapi"

    def test_context_param_accepted(self) -> None:
        """context param is accepted (reserved for future use)."""
        k = Kuberoku(context="my-context", k8s_client=FakeK8sClient())
        assert isinstance(k.apps, AppsService)

    def test_all_service_properties(self) -> None:
        """All service properties return the correct service types."""
        k = Kuberoku(k8s_client=FakeK8sClient(), namespace="test")
        assert isinstance(k.config, ConfigService)
        assert isinstance(k.deploy, DeployService)
        assert isinstance(k.releases, ReleasesService)
        assert isinstance(k.ps, PsService)
        assert isinstance(k.services, ServicesService)
        assert isinstance(k.addons, AddonsService)
        assert isinstance(k.domains, DomainsService)
        assert isinstance(k.clusters, ClustersService)
        assert isinstance(k.doctor, DoctorService)
        assert isinstance(k.plugins, PluginService)
        assert isinstance(k.build, BuildService)
