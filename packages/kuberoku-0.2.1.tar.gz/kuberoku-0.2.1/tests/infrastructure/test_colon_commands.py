"""Tests for cli/main.py — ColonCommandGroup and CLI entry point."""

from click.testing import CliRunner

from kuberoku._version import __version__
from kuberoku.branding import TOOL_NAME
from kuberoku.cli.main import cli


class TestColonCommandGroup:
    """Verify colon command resolution — the core UX feature."""

    def test_version_flag(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.output
        assert TOOL_NAME in result.output

    def test_help_flag(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Heroku-like DX" in result.output

    def test_colon_syntax_resolves_to_subcommand(self) -> None:
        """apps:create resolves identically to apps create."""
        runner = CliRunner()
        result = runner.invoke(cli, ["apps:create", "--help"])
        assert result.exit_code == 0
        assert "Create a new app" in result.output

    def test_unknown_command_exits_with_usage(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["nonexistent"])
        assert result.exit_code != 0
