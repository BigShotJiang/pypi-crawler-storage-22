"""Tests for _parse_duration helper in sdk/services.py."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import InvalidDurationError
from kuberoku.sdk.services import _parse_duration


class TestParseDuration:
    def test_seconds_only(self) -> None:
        assert _parse_duration("30s") == 30

    def test_minutes_only(self) -> None:
        assert _parse_duration("5m") == 300

    def test_hours_only(self) -> None:
        assert _parse_duration("1h") == 3600

    def test_hours_and_minutes(self) -> None:
        assert _parse_duration("2h30m") == 9000

    def test_hours_minutes_seconds(self) -> None:
        assert _parse_duration("1h30m15s") == 5415

    def test_minutes_and_seconds(self) -> None:
        assert _parse_duration("5m30s") == 330

    def test_whitespace_stripped(self) -> None:
        assert _parse_duration("  10m  ") == 600

    def test_empty_string_raises(self) -> None:
        with pytest.raises(InvalidDurationError):
            _parse_duration("")

    def test_invalid_format_raises(self) -> None:
        with pytest.raises(InvalidDurationError):
            _parse_duration("abc")

    def test_bare_number_raises(self) -> None:
        with pytest.raises(InvalidDurationError):
            _parse_duration("100")

    def test_zero_duration_raises(self) -> None:
        with pytest.raises(InvalidDurationError):
            _parse_duration("0s")

    def test_negative_not_matched(self) -> None:
        with pytest.raises(InvalidDurationError):
            _parse_duration("-5m")
