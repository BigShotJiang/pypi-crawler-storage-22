"""Tests for k8s/labels.py — label builders."""

from kuberoku.k8s import labels

DOMAIN = "app.kuberoku.com"
PREFIX = "kuberoku"


class TestForApp:
    def test_returns_managed_by_app_and_type(self) -> None:
        result = labels.for_app(DOMAIN, PREFIX, "myapi", "app-manifest")
        assert result == {
            "app.kuberoku.com/managed-by": "kuberoku",
            "app.kuberoku.com/app": "myapi",
            "app.kuberoku.com/resource-type": "app-manifest",
        }

    def test_custom_domain_and_prefix(self) -> None:
        result = labels.for_app("app.k8u.dev", "k8u", "myapi", "env")
        assert result["app.k8u.dev/managed-by"] == "k8u"
        assert result["app.k8u.dev/app"] == "myapi"


class TestForProcess:
    def test_includes_app_labels_plus_process_type(self) -> None:
        result = labels.for_process(DOMAIN, PREFIX, "myapi", "web")
        assert result["app.kuberoku.com/process-type"] == "web"
        assert result["app.kuberoku.com/app"] == "myapi"
        assert result["app.kuberoku.com/managed-by"] == "kuberoku"
        assert result["app.kuberoku.com/resource-type"] == "process"

    def test_different_process_types(self) -> None:
        web = labels.for_process(DOMAIN, PREFIX, "myapi", "web")
        worker = labels.for_process(DOMAIN, PREFIX, "myapi", "worker")
        assert web["app.kuberoku.com/process-type"] == "web"
        assert worker["app.kuberoku.com/process-type"] == "worker"


class TestForAddon:
    def test_includes_addon_instance_and_type(self) -> None:
        result = labels.for_addon(DOMAIN, PREFIX, "myapi", "analytics-db", "postgres")
        assert result["app.kuberoku.com/addon-instance"] == "analytics-db"
        assert result["app.kuberoku.com/addon-type"] == "postgres"
        assert result["app.kuberoku.com/resource-type"] == "addon"
        assert result["app.kuberoku.com/app"] == "myapi"


class TestSelector:
    def test_minimal_labels_for_deployment_selector(self) -> None:
        result = labels.selector(DOMAIN, "myapi", "web")
        assert result == {
            "app.kuberoku.com/app": "myapi",
            "app.kuberoku.com/process-type": "web",
        }
        # Selector must NOT include managed-by (it's not immutable)
        assert "app.kuberoku.com/managed-by" not in result


class TestManagedBy:
    def test_single_label_for_discovery(self) -> None:
        result = labels.managed_by(DOMAIN, PREFIX)
        assert result == {"app.kuberoku.com/managed-by": "kuberoku"}
