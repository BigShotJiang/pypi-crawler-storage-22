"""Tests for build_addon_external_allow_policy and updated build_external_allow_policy."""

from __future__ import annotations

from kuberoku.k8s.resources import (
    build_addon_external_allow_policy,
    build_external_allow_policy,
)


class TestBuildExternalAllowPolicy:
    def test_has_exposed_by_annotation(self) -> None:
        policy = build_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "web",
            [{"port": 8080, "protocol": "TCP"}],
        )
        annotations = policy["metadata"]["annotations"]
        assert annotations["app.test.com/exposed-by"] == "expose"

    def test_custom_exposed_by(self) -> None:
        policy = build_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "web",
            [{"port": 8080, "protocol": "TCP"}],
            exposed_by="domains",
        )
        assert policy["metadata"]["annotations"]["app.test.com/exposed-by"] == "domains"

    def test_has_process_type_label(self) -> None:
        policy = build_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "web",
            [{"port": 8080, "protocol": "TCP"}],
        )
        labels = policy["metadata"]["labels"]
        assert labels["app.test.com/process-type"] == "web"

    def test_no_from_in_ingress(self) -> None:
        policy = build_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "web",
            [{"port": 8080, "protocol": "TCP"}],
        )
        ingress = policy["spec"]["ingress"]
        assert len(ingress) == 1
        assert "from" not in ingress[0]


class TestBuildAddonExternalAllowPolicy:
    def test_structure(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "postgres",
            "postgres",
            [{"port": 5432, "protocol": "TCP"}],
        )
        assert policy["apiVersion"] == "networking.k8s.io/v1"
        assert policy["kind"] == "NetworkPolicy"

    def test_has_addon_labels(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "postgres",
            "postgres",
            [{"port": 5432, "protocol": "TCP"}],
        )
        labels = policy["metadata"]["labels"]
        assert labels["app.test.com/addon-instance"] == "postgres"
        assert labels["app.test.com/addon-type"] == "postgres"

    def test_has_exposed_by_annotation(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "postgres",
            "postgres",
            [{"port": 5432, "protocol": "TCP"}],
        )
        annotations = policy["metadata"]["annotations"]
        assert annotations["app.test.com/exposed-by"] == "expose"

    def test_uses_addon_selector(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "postgres",
            "postgres",
            [{"port": 5432, "protocol": "TCP"}],
        )
        selector = policy["spec"]["podSelector"]["matchLabels"]
        assert "app.test.com/addon-instance" in selector
        assert selector["app.test.com/addon-instance"] == "postgres"

    def test_no_from_in_ingress(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "postgres",
            "postgres",
            [{"port": 5432, "protocol": "TCP"}],
        )
        ingress = policy["spec"]["ingress"]
        assert len(ingress) == 1
        assert "from" not in ingress[0]

    def test_custom_exposed_by(self) -> None:
        policy = build_addon_external_allow_policy(
            "kube",
            "app.test.com",
            "myapp",
            "redis",
            "redis",
            [{"port": 6379, "protocol": "TCP"}],
            exposed_by="domains",
        )
        assert policy["metadata"]["annotations"]["app.test.com/exposed-by"] == "domains"
