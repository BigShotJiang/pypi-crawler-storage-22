"""Tests for cli/output.py — rendering helpers."""

from __future__ import annotations

from io import StringIO
from unittest.mock import patch

from kuberoku.cli.output import error, is_tty


class TestOutputHelpers:
    def test_is_tty_returns_bool(self) -> None:
        result = is_tty()
        assert isinstance(result, bool)

    def test_error_prints_message_with_prefix(self) -> None:
        buf = StringIO()
        with patch("click.echo", side_effect=lambda msg, **kw: buf.write(msg)):
            error("something went wrong")
        assert "Error: something went wrong" in buf.getvalue()

    def test_error_formats_exception(self) -> None:
        buf = StringIO()
        with patch("click.echo", side_effect=lambda msg, **kw: buf.write(msg)):
            error(ValueError("oops"))
        assert "Error: oops" in buf.getvalue()

    def test_error_sends_to_stderr(self) -> None:
        """error() passes err=True to click.echo."""
        calls: list[dict[str, object]] = []
        with patch("click.echo", side_effect=lambda msg, **kw: calls.append(kw)):
            error("fail")
        assert calls[0].get("err") is True
