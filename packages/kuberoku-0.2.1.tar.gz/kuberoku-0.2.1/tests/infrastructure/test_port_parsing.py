"""Tests for port parsing utilities."""

from __future__ import annotations

import pytest

from kuberoku.sdk.deploy import default_web_ports, parse_port


def test_parse_tcp_port() -> None:
    assert parse_port("8080/tcp") == {"containerPort": 8080, "protocol": "TCP"}


def test_parse_udp_port() -> None:
    assert parse_port("53/udp") == {"containerPort": 53, "protocol": "UDP"}


def test_parse_port_no_protocol() -> None:
    assert parse_port("8080") == {"containerPort": 8080, "protocol": "TCP"}


def test_parse_port_case_insensitive() -> None:
    assert parse_port("8080/TCP") == {"containerPort": 8080, "protocol": "TCP"}
    assert parse_port("53/UDP") == {"containerPort": 53, "protocol": "UDP"}


def test_parse_port_invalid_number() -> None:
    with pytest.raises(ValueError, match="Invalid port"):
        parse_port("abc/tcp")


def test_parse_port_out_of_range() -> None:
    with pytest.raises(ValueError, match="out of range"):
        parse_port("99999/tcp")


def test_parse_port_zero() -> None:
    with pytest.raises(ValueError, match="out of range"):
        parse_port("0/tcp")


def test_parse_port_invalid_protocol() -> None:
    with pytest.raises(ValueError, match="Invalid protocol"):
        parse_port("8080/sctp")


def test_default_web_ports() -> None:
    ports = default_web_ports()
    assert ports == [{"containerPort": 8080, "protocol": "TCP"}]
