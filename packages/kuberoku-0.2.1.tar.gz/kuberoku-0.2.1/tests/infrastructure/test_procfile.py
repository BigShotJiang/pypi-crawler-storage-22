"""Tests for Procfile parser."""

from __future__ import annotations

from pathlib import Path

from kuberoku.sdk.procfile import parse_procfile


def test_empty_file(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("")
    assert parse_procfile(f) == {}


def test_file_not_found(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    assert parse_procfile(f) == {}


def test_single_entry(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("web: python app.py\n")
    assert parse_procfile(f) == {"web": "python app.py"}


def test_multiple_entries(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("web: python app.py\nworker: celery -A tasks\n")
    result = parse_procfile(f)
    assert result == {"web": "python app.py", "worker": "celery -A tasks"}


def test_comments_ignored(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("# This is a comment\nweb: python app.py\n# Another\n")
    assert parse_procfile(f) == {"web": "python app.py"}


def test_blank_lines_ignored(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("\nweb: python app.py\n\nworker: celery\n\n")
    assert parse_procfile(f) == {"web": "python app.py", "worker": "celery"}


def test_command_with_colons(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("web: gunicorn app:app --bind 0.0.0.0:8080\n")
    assert parse_procfile(f) == {"web": "gunicorn app:app --bind 0.0.0.0:8080"}


def test_whitespace_around_colon(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("  web  :  python app.py  \n")
    assert parse_procfile(f) == {"web": "python app.py"}


def test_line_without_colon_ignored(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("not a valid line\nweb: python app.py\n")
    assert parse_procfile(f) == {"web": "python app.py"}


def test_empty_key_ignored(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text(": empty key\nweb: python app.py\n")
    assert parse_procfile(f) == {"web": "python app.py"}


def test_empty_value_ignored(tmp_path: Path) -> None:
    f = tmp_path / "Procfile"
    f.write_text("web:\nworker: celery\n")
    assert parse_procfile(f) == {"worker": "celery"}
