"""Shared helpers for ps tests."""

from __future__ import annotations

from typing import Any

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s import labels
from tests.backends.fake import FakeK8sClient


def create_test_pod(
    factory: KuberokuFactory,
    app: str,
    process: str,
    name: str,
    phase: str = "Running",
    start_time: str = "2024-01-01T00:00:00Z",
) -> dict[str, Any]:
    """Create a fake pod for ps tests."""
    k8s = factory.k8s
    assert isinstance(k8s, FakeK8sClient)
    pod: dict[str, Any] = {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": name,
            "labels": labels.for_process(factory.domain, factory.prefix, app, process),
        },
        "spec": {
            "containers": [{"name": process, "image": "myapp:v1"}],
            "nodeName": "test-node",
        },
        "status": {
            "phase": phase,
            "startTime": start_time,
        },
    }
    return k8s.create_pod(factory.namespace, pod)
