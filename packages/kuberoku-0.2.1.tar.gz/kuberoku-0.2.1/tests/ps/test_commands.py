"""Tests for PsService.get_commands."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory


def test_get_commands_empty(app_factory: KuberokuFactory) -> None:
    result = app_factory.ps.get_commands("myapp")
    assert result == {}


def test_get_commands_after_set(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_commands("myapp", {"web": "gunicorn"}, no_restart=True)
    result = deployed_factory.ps.get_commands("myapp")
    assert result["web"].command == "gunicorn"
    assert result["web"].command_source == "manual"


def test_get_commands_after_deploy(deployed_factory: KuberokuFactory) -> None:
    result = deployed_factory.ps.get_commands("myapp")
    assert "web" in result
    assert result["web"].command is None
