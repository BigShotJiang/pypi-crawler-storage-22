"""Tests for PsService.restart."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import ProcessTypeNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s import labels
from tests.ps.conftest import create_test_pod as _create_pod


def test_restart_all(deployed_factory: KuberokuFactory) -> None:
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    _create_pod(deployed_factory, "myapp", "web", "web-pod-2")
    count = deployed_factory.ps.restart("myapp")
    assert count == 2


def test_restart_by_type(deployed_factory: KuberokuFactory) -> None:
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    deployed_factory.deploy.deploy("myapp", image="myapp:v1", process_type="worker", wait=False)
    _create_pod(deployed_factory, "myapp", "worker", "worker-pod-1")
    count = deployed_factory.ps.restart("myapp", process_type="web")
    assert count == 1
    # Worker should still exist
    pods = deployed_factory.k8s.list_pods(
        deployed_factory.namespace,
        labels=labels.selector(deployed_factory.domain, "myapp", "worker"),
    )
    assert len(pods) == 1


def test_restart_by_dyno(deployed_factory: KuberokuFactory) -> None:
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    _create_pod(deployed_factory, "myapp", "web", "web-pod-2")
    count = deployed_factory.ps.restart("myapp", dyno="web.1")
    assert count == 1
    # One pod should remain
    pods = deployed_factory.k8s.list_pods(
        deployed_factory.namespace,
        labels=labels.selector(deployed_factory.domain, "myapp", "web"),
    )
    assert len(pods) == 1


def test_restart_empty(deployed_factory: KuberokuFactory) -> None:
    count = deployed_factory.ps.restart("myapp")
    assert count == 0


def test_restart_on_step(deployed_factory: KuberokuFactory) -> None:
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    steps: list[str] = []
    deployed_factory.ps.restart("myapp", on_step=steps.append)
    assert len(steps) > 0


def test_restart_dyno_not_found(deployed_factory: KuberokuFactory) -> None:
    """Restarting a nonexistent dyno raises ProcessTypeNotFoundError."""
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    with pytest.raises(ProcessTypeNotFoundError):
        deployed_factory.ps.restart("myapp", dyno="worker.99")


def test_restart_dyno_with_on_step(deployed_factory: KuberokuFactory) -> None:
    """Restart specific dyno invokes on_step callback."""
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    steps: list[str] = []
    count = deployed_factory.ps.restart("myapp", dyno="web.1", on_step=steps.append)
    assert count == 1
    assert any("web.1" in s for s in steps)


def test_restart_by_type_with_on_step(deployed_factory: KuberokuFactory) -> None:
    """Restart by process type invokes on_step with count."""
    _create_pod(deployed_factory, "myapp", "web", "web-pod-1")
    _create_pod(deployed_factory, "myapp", "web", "web-pod-2")
    steps: list[str] = []
    count = deployed_factory.ps.restart("myapp", process_type="web", on_step=steps.append)
    assert count == 2
    assert any("2" in s and "web" in s for s in steps)
