"""Tests for PsService.stop."""

from __future__ import annotations

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name


def test_stop_scales_to_zero(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.stop("myapp", "web")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    assert dep["spec"]["replicas"] == 0


def test_stop_updates_formation(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.stop("myapp", "web")
    formation = deployed_factory.ps.get_commands("myapp")
    assert formation["web"].replicas == 0
