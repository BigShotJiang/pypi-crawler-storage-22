"""Tests for PsService.set_type and get_type."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import ProcessTypeNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s.resources import safe_name


def test_set_type_cpu_only(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", cpu="250m")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    res = dep["spec"]["template"]["spec"]["containers"][0]["resources"]
    assert res["requests"]["cpu"] == "250m"


def test_set_type_memory_only(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", memory="256Mi")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    res = dep["spec"]["template"]["spec"]["containers"][0]["resources"]
    assert res["requests"]["memory"] == "256Mi"


def test_set_type_both(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", cpu="250m", memory="256Mi")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    res = dep["spec"]["template"]["spec"]["containers"][0]["resources"]
    assert res["requests"]["cpu"] == "250m"
    assert res["requests"]["memory"] == "256Mi"


def test_set_type_request_limit_format(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", cpu="250m/500m", memory="256Mi/512Mi")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    res = dep["spec"]["template"]["spec"]["containers"][0]["resources"]
    assert res["requests"]["cpu"] == "250m"
    assert res["limits"]["cpu"] == "500m"
    assert res["requests"]["memory"] == "256Mi"
    assert res["limits"]["memory"] == "512Mi"


def test_set_type_triggers_restart(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", cpu="250m")
    dep = deployed_factory.k8s.get_deployment(
        deployed_factory.namespace, safe_name(deployed_factory.prefix, "myapp", "web")
    )
    annotations = dep["spec"]["template"]["metadata"]["annotations"]
    assert "kubectl.kubernetes.io/restartedAt" in annotations


def test_set_type_not_found(deployed_factory: KuberokuFactory) -> None:
    with pytest.raises(ProcessTypeNotFoundError):
        deployed_factory.ps.set_type("myapp", "nonexistent", cpu="250m")


def test_get_type_shows_current(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.ps.set_type("myapp", "web", cpu="250m", memory="256Mi")
    result = deployed_factory.ps.get_type("myapp", "web")
    assert "web" in result
    assert result["web"]["requests"]["cpu"] == "250m"


def test_get_type_empty(deployed_factory: KuberokuFactory) -> None:
    result = deployed_factory.ps.get_type("myapp", "web")
    assert result == {"web": {}}


def test_get_type_all(deployed_factory: KuberokuFactory) -> None:
    deployed_factory.deploy.deploy("myapp", image="myapp:v1", process_type="worker", wait=False)
    deployed_factory.ps.set_type("myapp", "web", cpu="250m")
    result = deployed_factory.ps.get_type("myapp")
    assert "web" in result
    assert "worker" in result
