"""Shared fixtures for services tests."""

from __future__ import annotations

from typing import Any

import pytest

from kuberoku.factory import KuberokuFactory
from kuberoku.k8s import labels
from tests.backends.fake import FakeK8sClient


def _create_fake_pod(
    factory: KuberokuFactory,
    app: str,
    process: str,
    pod_suffix: str,
    image: str = "myapp:v1",
    log_lines: list[str] | None = None,
) -> str:
    """Create a fake pod matching a deployment's labels and optionally inject logs."""
    pod_name = f"{factory.prefix}-{app}-{process}-{pod_suffix}"
    pod_labels = labels.for_process(factory.domain, factory.prefix, app, process)
    body: dict[str, Any] = {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": pod_name,
            "labels": pod_labels,
        },
        "spec": {
            "containers": [{"name": process, "image": image}],
            "nodeName": "fake-node-1",
        },
        "status": {
            "phase": "Running",
            "containerStatuses": [
                {
                    "name": process,
                    "ready": True,
                    "state": {"running": {"startedAt": "2025-01-01T00:00:00Z"}},
                },
            ],
        },
    }
    factory.k8s.create_pod(factory.namespace, body)
    if log_lines is not None:
        k8s = factory.k8s
        assert isinstance(k8s, FakeK8sClient)
        k8s.inject_pod_logs(pod_name, log_lines)
    return pod_name


@pytest.fixture()
def deployed_factory_with_pods(deployed_factory: KuberokuFactory) -> KuberokuFactory:
    """Factory with a deployed app and 2 fake web pods with injected logs."""
    _create_fake_pod(
        deployed_factory,
        "myapp",
        "web",
        "pod-a",
        log_lines=["Starting server...", "Listening on :8080"],
    )
    _create_fake_pod(
        deployed_factory,
        "myapp",
        "web",
        "pod-b",
        log_lines=["Starting server...", "Listening on :8080", "Request handled"],
    )
    return deployed_factory


@pytest.fixture()
def addon_factory(app_factory: KuberokuFactory) -> KuberokuFactory:
    """Factory with a postgres addon attached."""
    app_factory.addons.create("myapp", "postgres")
    return app_factory


@pytest.fixture()
def full_factory(deployed_factory: KuberokuFactory) -> KuberokuFactory:
    """Factory with both deployed web process and postgres addon."""
    deployed_factory.addons.create("myapp", "postgres")
    return deployed_factory


@pytest.fixture()
def multi_process_factory(deployed_factory: KuberokuFactory) -> KuberokuFactory:
    """Factory with web + worker process types deployed."""
    deployed_factory.deploy.deploy(
        "myapp",
        image="myapp:v2",
        process_type="worker",
        ports=None,
        wait=False,
    )
    return deployed_factory


@pytest.fixture()
def multi_process_factory_with_pods(
    multi_process_factory: KuberokuFactory,
) -> KuberokuFactory:
    """Factory with web + worker pods and injected logs."""
    _create_fake_pod(
        multi_process_factory,
        "myapp",
        "web",
        "pod-a",
        log_lines=["Web starting", "Web ready"],
    )
    _create_fake_pod(
        multi_process_factory,
        "myapp",
        "worker",
        "pod-c",
        log_lines=["Worker starting", "Processing job"],
    )
    return multi_process_factory
