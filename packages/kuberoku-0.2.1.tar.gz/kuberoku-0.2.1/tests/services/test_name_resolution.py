"""Tests for name resolution in ServicesService and AddonsService."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import NameNotFoundError
from kuberoku.factory import KuberokuFactory


class TestProcessNameResolution:
    """Test process type name resolution via expose_on()."""

    def test_process_found(self, deployed_factory: KuberokuFactory) -> None:
        ep = deployed_factory.services.expose_on("myapp", "web")
        assert ep.kind == "process"

    def test_process_not_found(self, app_factory: KuberokuFactory) -> None:
        with pytest.raises(NameNotFoundError):
            app_factory.services.expose_on("myapp", "nonexistent")

    def test_process_expose_works(
        self,
        full_factory: KuberokuFactory,
    ) -> None:
        """Process expose in app with both process and addon works."""
        ep = full_factory.services.expose_on("myapp", "web")
        assert ep.kind == "process"


class TestAddonNameResolution:
    """Test addon name resolution via addons.expose_on()."""

    def test_addon_found(self, addon_factory: KuberokuFactory) -> None:
        ep = addon_factory.addons.expose_on("myapp", "postgres")
        assert ep.kind == "addon"

    def test_addon_expose_works(
        self,
        full_factory: KuberokuFactory,
    ) -> None:
        """Addon expose in app with both process and addon works."""
        ep = full_factory.addons.expose_on("myapp", "postgres")
        assert ep.kind == "addon"
