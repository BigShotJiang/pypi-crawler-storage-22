"""Tests for ServicesService.list_ports()."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import AppNotFoundError
from kuberoku.factory import KuberokuFactory
from kuberoku.models import PortMapping


class TestListPorts:
    def test_single_web_type(self, deployed_factory: KuberokuFactory) -> None:
        result = deployed_factory.services.list_ports("myapp")
        assert "web" in result
        assert result["web"] == (PortMapping(port=8080, protocol="TCP"),)

    def test_multi_type(self, multi_process_factory: KuberokuFactory) -> None:
        result = multi_process_factory.services.list_ports("myapp")
        assert "web" in result
        assert "worker" not in result  # worker has no ports/service

    def test_no_services(self, app_factory: KuberokuFactory) -> None:
        """App with no deployments has no ports."""
        result = app_factory.services.list_ports("myapp")
        assert result == {}

    def test_app_not_found(self, app_factory: KuberokuFactory) -> None:
        with pytest.raises(AppNotFoundError):
            app_factory.services.list_ports("nonexistent")

    def test_multiple_ports(self, deployed_factory: KuberokuFactory) -> None:
        """After adding a second port, list_ports shows both."""
        deployed_factory.services.add_port("myapp", "9090/tcp")
        result = deployed_factory.services.list_ports("myapp")
        assert len(result["web"]) == 2
        ports = {(pm.port, pm.protocol) for pm in result["web"]}
        assert (8080, "TCP") in ports
        assert (9090, "TCP") in ports

    def test_udp_port(self, deployed_factory: KuberokuFactory) -> None:
        """UDP port shows up with correct protocol."""
        deployed_factory.services.add_port("myapp", "5353/udp")
        result = deployed_factory.services.list_ports("myapp")
        ports = {(pm.port, pm.protocol) for pm in result["web"]}
        assert (5353, "UDP") in ports

    def test_addon_ports_not_included(self, full_factory: KuberokuFactory) -> None:
        """Addon Services should NOT appear in list_ports (process only)."""
        result = full_factory.services.list_ports("myapp")
        # Only web process type, not addon
        assert set(result.keys()) == {"web"}
