"""Tests for ServicesService.remove_port()."""

from __future__ import annotations

import pytest

from kuberoku.exceptions import (
    AmbiguousProcessTypeError,
    AppNotFoundError,
    PortNotFoundError,
    ProcessTypeNotFoundError,
)
from kuberoku.factory import KuberokuFactory
from kuberoku.k8s import resources
from kuberoku.models import PortMapping
from tests.backends.fake import FakeNotFoundError


class TestRemovePort:
    def test_remove_port_basic(self, deployed_factory: KuberokuFactory) -> None:
        """Add a second port, then remove the original."""

        deployed_factory.services.add_port("myapp", "9090/tcp")
        deployed_factory.services.remove_port("myapp", "8080/tcp")
        result = deployed_factory.services.list_ports("myapp")
        assert result["web"] == (PortMapping(port=9090, protocol="TCP"),)

    def test_remove_port_not_found(self, deployed_factory: KuberokuFactory) -> None:
        with pytest.raises(PortNotFoundError) as exc_info:
            deployed_factory.services.remove_port("myapp", "9999/tcp")
        assert exc_info.value.port == 9999
        assert exc_info.value.process_type == "web"

    def test_remove_port_app_not_found(self, app_factory: KuberokuFactory) -> None:
        with pytest.raises(AppNotFoundError):
            app_factory.services.remove_port("nonexistent", "8080/tcp")

    def test_remove_port_process_type_not_found(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        with pytest.raises(ProcessTypeNotFoundError):
            deployed_factory.services.remove_port(
                "myapp",
                "8080/tcp",
                process_type="nonexistent",
            )

    def test_remove_last_port_deletes_service(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        """Removing the last port should delete the Service."""
        deployed_factory.services.remove_port("myapp", "8080/tcp")
        svc_name = resources.safe_name(
            deployed_factory.prefix,
            "myapp",
            "web",
        )
        with pytest.raises(FakeNotFoundError):
            deployed_factory.k8s.get_service(
                deployed_factory.namespace,
                svc_name,
            )

    def test_remove_last_port_deletes_network_policy(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        """Removing the last port should delete the process-allow NetworkPolicy."""
        deployed_factory.services.remove_port("myapp", "8080/tcp")
        np_name = resources.safe_name(
            deployed_factory.prefix,
            "netpol-allow",
            "myapp-web",
        )
        with pytest.raises(FakeNotFoundError):
            deployed_factory.k8s.get_network_policy(
                deployed_factory.namespace,
                np_name,
            )

    def test_remove_port_keeps_remaining(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        """Removing one of two ports keeps the other."""
        deployed_factory.services.add_port("myapp", "9090/tcp")
        deployed_factory.services.remove_port("myapp", "9090/tcp")
        result = deployed_factory.services.list_ports("myapp")

        assert result["web"] == (PortMapping(port=8080, protocol="TCP"),)

    def test_remove_port_updates_deployment(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        """Verify Deployment container ports are updated."""
        deployed_factory.services.add_port("myapp", "9090/tcp")
        deployed_factory.services.remove_port("myapp", "8080/tcp")
        dep_name = resources.safe_name(
            deployed_factory.prefix,
            "myapp",
            "web",
        )
        dep = deployed_factory.k8s.get_deployment(
            deployed_factory.namespace,
            dep_name,
        )
        container_ports = dep["spec"]["template"]["spec"]["containers"][0]["ports"]
        port_nums = [p["containerPort"] for p in container_ports]
        assert 8080 not in port_nums
        assert 9090 in port_nums

    def test_remove_port_updates_network_policy(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        """Verify the process-allow NetworkPolicy is updated."""
        deployed_factory.services.add_port("myapp", "9090/tcp")
        deployed_factory.services.remove_port("myapp", "8080/tcp")
        np_name = resources.safe_name(
            deployed_factory.prefix,
            "netpol-allow",
            "myapp-web",
        )
        np = deployed_factory.k8s.get_network_policy(
            deployed_factory.namespace,
            np_name,
        )
        np_ports = np["spec"]["ingress"][0]["ports"]
        port_nums = [p["port"] for p in np_ports]
        assert 8080 not in port_nums
        assert 9090 in port_nums

    def test_remove_port_ambiguous_multi_type(
        self,
        multi_process_factory: KuberokuFactory,
    ) -> None:
        with pytest.raises(AmbiguousProcessTypeError):
            multi_process_factory.services.remove_port("myapp", "8080/tcp")

    def test_remove_port_with_explicit_type(
        self,
        multi_process_factory: KuberokuFactory,
    ) -> None:
        """With --type specified, remove works for multi-type apps."""
        multi_process_factory.services.add_port(
            "myapp",
            "9090/tcp",
            process_type="web",
        )
        multi_process_factory.services.remove_port(
            "myapp",
            "9090/tcp",
            process_type="web",
        )
        result = multi_process_factory.services.list_ports("myapp")

        assert result["web"] == (PortMapping(port=8080, protocol="TCP"),)

    def test_remove_port_on_step_callback(
        self,
        deployed_factory: KuberokuFactory,
    ) -> None:
        deployed_factory.services.add_port("myapp", "9090/tcp")
        steps: list[str] = []
        deployed_factory.services.remove_port(
            "myapp",
            "9090/tcp",
            on_step=steps.append,
        )
        assert len(steps) >= 1
