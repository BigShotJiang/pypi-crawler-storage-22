# Changelog

## 0.2.2 (unreleased)

### Improved

- **clusters:setup**: auto-installs nginx-ingress controller when none is detected (no more "Manual steps needed" dead end)
- **Ingress detection**: provider-agnostic — uses standard IngressClass API instead of namespace scanning for specific controllers
- **Ingress manifest version**: dynamically resolves latest release from GitHub API with fallback, instead of hardcoded version

### Changed

- Simplified `detect_ingress_controller()` to IngressClass-only discovery
- Added `setup-test` CI job (kind + k3d-no-traefik matrix) for auto-install path

## 0.2.1

### Fixed

- **services:connect**: auto-remaps privileged ports (80→8080, 443→8443) so `kubectl port-forward` works without sudo
- **services:connect**: shows browser URL after port-forward starts

## 0.2.0

### Improved

- **First-time user DX**: friendly `NoKubeConfigError` with setup hints instead of raw Python traceback
- **"Did you mean?" suggestions**: typo correction for commands and app names
- **Guided hints**: contextual help messages for common errors

## 0.1.0

Initial alpha release.

### Added

- **Apps**: create, destroy, info, rename, status, link, maintenance
- **Config**: set, get, unset with secret masking and optimistic concurrency
- **Deploy**: image deploy, build-from-git, multi-process types
- **PS**: scale, restart, stop, type, set commands
- **Releases**: info, rollback, prune with full audit trail
- **Services**: expose, ports, logs, exec, connect, maintenance
- **Addons**: PostgreSQL and Redis with credentials, backup, exec, connect
- **Addon versioning**: create with `--version`, `addons:migrate` (backup → PVC wipe → restore for Postgres), `addons:migrate-rollback`
- **Plugins**: install, uninstall, search via PyPI entry points
- **Domains**: add, remove, clear with Ingress management
- **Clusters**: add, remove, switch, current, info, doctor, setup
- **Networking**: default-deny NetworkPolicies, per-process allow rules
- **SDK**: full Python API matching CLI 1:1, frozen dataclasses, typed exceptions
- **Distribution**: PyPI package, pre-built binaries (Linux, macOS, Windows), curl installer
