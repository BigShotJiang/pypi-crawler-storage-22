"""Middleware modules"""

# Note: Lazy imports to avoid circular dependency.
# auth.py imports user_id_validation.py which imports request_id.py from this package.
# If we eagerly import auth here, we create a cycle when user_id_validation is loaded.

from control_plane_api.app.middleware.prometheus_middleware import PrometheusMiddleware


def __getattr__(name):
    """Lazy import to avoid circular dependencies."""
    if name == "get_current_organization":
        from control_plane_api.app.middleware.auth import get_current_organization
        return get_current_organization
    if name == "extract_token_from_headers":
        from control_plane_api.app.middleware.auth import extract_token_from_headers
        return extract_token_from_headers
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "get_current_organization",
    "extract_token_from_headers",
    "PrometheusMiddleware",
]
