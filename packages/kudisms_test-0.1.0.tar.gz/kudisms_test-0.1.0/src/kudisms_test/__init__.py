def main() -> None:
    print("Hello from kudisms-test!")
