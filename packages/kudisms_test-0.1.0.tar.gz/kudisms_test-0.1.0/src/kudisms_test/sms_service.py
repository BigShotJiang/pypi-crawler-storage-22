def send_sms():
    print("sending sms to ...")