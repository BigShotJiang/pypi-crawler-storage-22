# KUDO

KUDO is an experimental Python visualization toolkit aimed at rendering
animated and interactive graphical components in a web browser via localhost.

This package is currently in early development.

