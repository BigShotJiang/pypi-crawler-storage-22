BUY = 0

SELL = 1
