from dataclasses import field, fields
from typing import Dict, Union

from pydantic import ConfigDict
from pydantic import Field as PydanticField
from pydantic.dataclasses import dataclass

from kumoapi.model_plan import (
    ColumnProcessingPlan,
    Metadata,
    MissingType,
    OptimizationPlan,
    TrainingJobPlan,
    _add_indent,
    compat_field,
)
from kumoapi.typing import WITH_PYDANTIC_V2, TimeUnit


@dataclass(config=dict(validate_assignment=True))
class TimeOffset:
    r"""Represents a time offset with a value and unit.

    :ivar value: (``int``) The numerical value of the time offset.
    :ivar unit: (``TimeUnit``) The unit of time for the offset
        (*default:* ``TimeUnit.DAYS``).
    """
    value: int = PydanticField(gt=0)
    unit: TimeUnit = compat_field(default=TimeUnit.DAYS, metadata=Metadata())


@dataclass(config=dict(validate_assignment=True))
class DistillationPlan:
    r"""Defines attributes that affect the features/interactions used to
    train the online serving model.

    :ivar max_embedding_offset: (``TimeOffset``) Maximum gap between generation
        of entity/target embedding and online prediction.

    :ivar real_time_interactions: (``dict[str, int]``) Names of tables one hop
        away from entity and the maximum number of interactions after
        max_embedding_offset to use during distillation (*default:* ``{}``).
    """
    max_embedding_offset: Union[TimeOffset, MissingType] = compat_field(
        default=MissingType.VALUE,
        metadata=Metadata(),
    )

    real_time_interactions: Dict[str, int] = compat_field(
        default_factory=dict,
        metadata=Metadata(),
    )


if WITH_PYDANTIC_V2:
    from pydantic import SerializeAsAny

    _SerializableDistillationPlan = SerializeAsAny[DistillationPlan]
    _SerializableOptimizationPlan = SerializeAsAny[OptimizationPlan]
    _SerializableTrainingJobPlan = SerializeAsAny[TrainingJobPlan]
    _SerializableColumnProcessingPlan = SerializeAsAny[ColumnProcessingPlan]
else:
    _SerializableDistillationPlan = DistillationPlan
    _SerializableOptimizationPlan = OptimizationPlan
    _SerializableTrainingJobPlan = TrainingJobPlan
    _SerializableColumnProcessingPlan = ColumnProcessingPlan


@dataclass(config=ConfigDict(validate_assignment=True), repr=False)
class DistilledModelPlan:
    r"""A complete definition of a Kumo distilled model plan, encompassing a
    :class:`~kumoapi.model_plan.TrainingJobPlan`,
    :class:`~kumoapi.model_plan.ColumnProcessingPlan`,
    :class:`~kumoapi.model_plan.OptimizationPlan`, and a
    :class:`~kumoapi.distilled_model_plan.DistillationPlan`."""
    training_job: _SerializableTrainingJobPlan = field(
        default_factory=TrainingJobPlan)
    # In the column_processing plan the training table
    # features can be keyed as `TRAIN_TABLE.{column_name}`.
    column_processing: _SerializableColumnProcessingPlan = field(
        default_factory=ColumnProcessingPlan)
    optimization: _SerializableOptimizationPlan = field(
        default_factory=OptimizationPlan)
    distillation: _SerializableDistillationPlan = field(
        default_factory=DistillationPlan)

    def __repr__(self) -> str:
        field_repr = '\n'.join(
            [f'{f.name}={getattr(self, f.name)},' for f in fields(self)])
        reprs = _add_indent(field_repr, num_spaces=2)
        return f'{self.__class__.__name__}(\n{reprs}\n)'
