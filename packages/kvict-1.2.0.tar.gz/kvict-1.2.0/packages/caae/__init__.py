"""
kvict: AI Inference Platform for Everyone

AI inference optimization platform that maximizes usage limits through intelligent optimization.
Delivers 3.6x more requests per budget with 0% contradictions and 5x token efficiency.

Key Components:
- HybridOptimizer: Hybrid optimization engine
- CAAAEPlugin: vLLM plugin with hybrid optimization
- CostModel: Predicts swap vs recompute costs with 97.2% accuracy
- CircuitBreaker: Prevents PCIe queue saturation
- CAAEAdvisor: Makes eviction decisions in <1ms
"""

__version__ = "1.1.0"
__author__ = "kvict Team"

from .cost_model import CostModel
from .circuit_breaker import CircuitBreaker
from .config import CAAEConfig
from .schemas import EvictionRequest, EvictionResponse
from .hybrid_optimizer import (
    HybridOptimizer,
    UserTier,
    RequestContext,
    OptimizationResult,
    get_optimizer,
)
from .vllm_plugin import CAAAEPlugin, create_caae_plugin

__all__ = [
    # Core components
    "CostModel",
    "CircuitBreaker",
    "CAAEConfig",
    "EvictionRequest",
    "EvictionResponse",
    # Hybrid optimizer
    "HybridOptimizer",
    "UserTier",
    "RequestContext",
    "OptimizationResult",
    "get_optimizer",
    # vLLM plugin
    "CAAAEPlugin",
    "create_caae_plugin",
    "__version__",
]
