#!/usr/bin/env python3
"""
CAAE Dashboard API Backend

FastAPI-based REST API for the CAAE SaaS dashboard.
Provides real-time metrics, A/B testing, ROI calculation, and admin controls.

Usage:
    uvicorn caae.dashboard_api:app --host 0.0.0.0 --port 8000

Author: CAAE Research
Date: January 23, 2026
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from typing import List, Dict
from datetime import datetime, timedelta
import logging

from .metrics import get_collector
from .quantization_api import router as quantization_router

logger = logging.getLogger(__name__)

# ============================================================================
# API MODELS
# ============================================================================


class MetricsResponse(BaseModel):
    """Metrics response for dashboard."""

    timestamp: str
    total_requests: int
    qps: float
    p50_latency_ms: float
    p99_latency_ms: float
    p999_latency_ms: float
    mean_latency_ms: float
    avg_improvement_percent: float
    total_cost_saved_usd: float
    sla_compliance_rate: float


class ConfigResponse(BaseModel):
    """Plugin configuration."""

    enable_exp8_speculative_decoding: bool = True
    enable_exp9_multi_gpu: bool = True
    enable_exp10_adaptive_sla: bool = True
    enable_exp7_shared_pooling: bool = True
    enable_telemetry: bool = True


class ABTestRequest(BaseModel):
    """A/B test configuration."""

    name: str
    baseline_enabled: bool = True
    caae_enabled: bool = True
    split_percent: float = 50.0  # % of traffic to CAAE
    duration_hours: int = 24


class ABTestResult(BaseModel):
    """A/B test results."""

    test_name: str
    status: str  # "running", "completed"
    baseline_qps: float
    baseline_p99_ms: float
    caae_qps: float
    caae_p99_ms: float
    throughput_improvement_percent: float
    latency_improvement_percent: float
    cost_saved_usd: float


class ROICalculation(BaseModel):
    """ROI calculation."""

    monthly_gpu_spend_usd: float
    estimated_improvement_percent: float
    estimated_monthly_savings_usd: float
    caae_subscription_cost_usd: float
    net_monthly_benefit_usd: float
    payback_period_months: float
    annual_savings_usd: float


# ============================================================================
# FASTAPI APP
# ============================================================================

app = FastAPI(
    title="CAAE Dashboard API",
    description="Real-time metrics, A/B testing, and ROI tracking for LLM inference optimization",
    version="1.1.0",
)

# Enable CORS for dashboard frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include quantization router
app.include_router(quantization_router)

# In-memory storage (would use database in production)
ab_tests: Dict[str, ABTestResult] = {}
metrics_history: List[MetricsResponse] = []


# ============================================================================
# HEALTH & INFO ENDPOINTS
# ============================================================================


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "version": "1.0.0",
    }


@app.get("/metrics", response_class=PlainTextResponse)
async def get_prometheus_metrics():
    """
    Get metrics in Prometheus OpenMetrics format.

    This endpoint exports:
    - caae_total_decisions: Total decisions made
    - caae_swaps_executed_total: Number of swap decisions
    - caae_recomputes_triggered_total: Number of recompute decisions
    - caae_holds_issued_total: Number of hold decisions
    - caae_fallbacks_triggered_total: Number of fallbacks to baseline
    - caae_service_errors_total: Number of CAAE service errors
    - caae_circuit_breaker_state: Circuit breaker state (0=closed, 1=half_open, 2=open)
    - caae_circuit_breaker_active: Is circuit breaker active (0 or 1)
    - caae_queue_depth_*_ms: Queue depth measurements
    - caae_decision_latency_ms: Decision latency histogram

    Usage:
        # Scrape with Prometheus
        curl http://localhost:8000/metrics
    """
    collector = get_collector()
    return collector.generate_prometheus_metrics()


# ============================================================================
# ADMIN ENDPOINTS - Circuit Breaker Control
# ============================================================================


class CircuitBreakerCommand(BaseModel):
    """Circuit breaker control command."""

    reason: str
    operator: str


class CircuitBreakerStatus(BaseModel):
    """Circuit breaker status."""

    state: str  # "closed", "half_open", "open"
    is_active: bool
    timestamp: str


@app.post("/v1/admin/circuit-breaker/force-close")
async def force_close_circuit_breaker(cmd: CircuitBreakerCommand):
    """
    Force-close the circuit breaker immediately.

    This is a manual recovery operation that resets the circuit breaker
    to CLOSED state regardless of current queue depth conditions.

    **Use Case:** After identifying and fixing the root cause of queue
    depth issues, use this to resume normal LWKCP-based decisions.

    **Args:**
        reason: Human-readable reason for force-close (e.g., "Queue depth
                normalized after reducing batch size to 16")
        operator: Name or email of operator performing this action

    **Response:**
        success: Boolean indicating operation succeeded
        previous_state: State before force-close (0=closed, 1=half_open, 2=open)
        current_state: State after force-close (should be 0)
        timestamp: When force-close was executed
        recovery_stats: Metrics about the previous open state

    **Example:**
        ```bash
        curl -X POST http://caae-advisor:8000/v1/admin/circuit-breaker/force-close \\
          -H "Content-Type: application/json" \\
          -d '{
            "reason": "Resolved PCIe contention, batch size reduced",
            "operator": "alice@company.com"
          }'
        ```

    **Important:**
    - Only force-close after verifying queue depth is actually low
    - Monitor metrics for 5+ minutes after force-close
    - If circuit breaker immediately re-trips, underlying issue not fixed
    - Document the reason in your incident tracking system
    """
    # Log the force-close action
    logger.warning(f"Circuit breaker force-closed by {cmd.operator}: {cmd.reason}")

    # In production, this would interact with the actual circuit breaker
    # For now, return a simulated response
    return {
        "status": "success",
        "previous_state": "open",
        "current_state": "closed",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "recovery_stats": {
            "time_in_open_state_ms": 45000,
            "threshold_exceeded_count": 127,
            "recovery_attempted": False,
        },
        "operator": cmd.operator,
        "reason": cmd.reason,
    }


@app.post("/v1/admin/circuit-breaker/force-open")
async def force_open_circuit_breaker(cmd: CircuitBreakerCommand):
    """
    Force-open the circuit breaker immediately.

    Forces conservative (LRU/recompute) behavior regardless of queue depth.

    **Use Case:** Emergency response if you detect PCIe saturation starting
    and want to immediately prevent further transfers before automatic
    detection triggers the breaker.

    **Args:**
        reason: Reason for force-open
        operator: Operator performing this action
    """
    logger.warning(f"Circuit breaker force-opened by {cmd.operator}: {cmd.reason}")

    return {
        "status": "success",
        "previous_state": "closed",
        "current_state": "open",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "operator": cmd.operator,
        "reason": cmd.reason,
    }


@app.get("/v1/admin/circuit-breaker/status", response_model=CircuitBreakerStatus)
async def get_circuit_breaker_status():
    """
    Get current circuit breaker state.

    **Response:**
        state: "closed", "half_open", or "open"
        is_active: Boolean, true if circuit is currently tripped
        timestamp: Current server time

    **Example:**
        ```bash
        curl http://caae-advisor:8000/v1/admin/circuit-breaker/status
        ```
    """
    # In production, query the actual circuit breaker state
    # For now, get from metrics
    return CircuitBreakerStatus(
        state="closed",
        is_active=False,
        timestamp=datetime.utcnow().isoformat() + "Z",
    )


@app.get("/v1/admin/recent-decisions")
async def get_recent_decisions(
    limit: int = Query(100, ge=1, le=1000),
    action_filter: str = Query(
        None, description="Filter by action: swap, recompute, hold"
    ),
):
    """
    Get recent CAAE decisions for debugging.

    **Args:**
        limit: Number of recent decisions to return (1-1000)
        action_filter: Optional filter by action type

    **Response:**
        List of recent decisions with:
        - timestamp
        - action: "swap", "recompute", or "hold"
        - context_tokens
        - queue_depth_ms
        - fallback: whether this was a fallback to baseline
        - latency_ms: decision latency
        - confidence: confidence score (0-1)
    """
    # In production, query from decision log database
    # For now, return simulated data
    return {
        "decisions": [
            {
                "timestamp": (datetime.utcnow() - timedelta(seconds=i)).isoformat()
                + "Z",
                "action": ["swap", "recompute", "hold"][i % 3],
                "context_tokens": 25000 + (i * 1000),
                "queue_depth_ms": 1.5 + (i * 0.1),
                "fallback": False,
                "latency_ms": 0.8,
                "confidence": 0.95,
            }
            for i in range(min(limit, 100))
        ],
        "count": min(limit, 100),
    }


@app.get("/config")
async def get_config() -> ConfigResponse:
    """Get current CAAE plugin configuration."""
    return ConfigResponse(
        enable_exp8_speculative_decoding=True,
        enable_exp9_multi_gpu=True,
        enable_exp10_adaptive_sla=True,
        enable_exp7_shared_pooling=True,
        enable_telemetry=True,
    )


# ============================================================================
# METRICS ENDPOINTS
# ============================================================================


@app.get("/metrics/current", response_model=MetricsResponse)
async def get_current_metrics() -> MetricsResponse:
    """
    Get current real-time metrics.

    Returns latest aggregated metrics from vLLM plugin.
    """
    # In production, fetch from plugin/prometheus
    return MetricsResponse(
        timestamp=datetime.utcnow().isoformat() + "Z",
        total_requests=1000,
        qps=42.5,
        p50_latency_ms=285.3,
        p99_latency_ms=412.8,
        p999_latency_ms=598.2,
        mean_latency_ms=312.4,
        avg_improvement_percent=42.8,
        total_cost_saved_usd=1250.50,
        sla_compliance_rate=0.982,
    )


@app.get("/metrics/history")
async def get_metrics_history(
    hours: int = Query(24, ge=1, le=720)
) -> List[MetricsResponse]:
    """
    Get historical metrics over time period.

    Args:
        hours: Number of hours to look back (1-720)

    Returns:
        List of metrics snapshots
    """
    # In production, fetch from time-series database
    # Return hourly aggregates for the requested period

    history = []
    for i in range(hours):
        timestamp = datetime.utcnow() - timedelta(hours=hours - i)
        history.append(
            MetricsResponse(
                timestamp=timestamp.isoformat() + "Z",
                total_requests=1000 + (i * 50),
                qps=40.0 + (i * 0.1),
                p50_latency_ms=300.0 - (i * 1.0),
                p99_latency_ms=450.0 - (i * 1.5),
                p999_latency_ms=650.0 - (i * 2.0),
                mean_latency_ms=330.0 - (i * 1.1),
                avg_improvement_percent=40.0 + (i * 0.1),
                total_cost_saved_usd=1000.0 + (i * 50.0),
                sla_compliance_rate=0.95 + (i * 0.0003),
            )
        )

    return history


@app.get("/metrics/by-model")
async def get_metrics_by_model() -> Dict[str, MetricsResponse]:
    """Get metrics breakdown by model."""
    return {
        "meta-llama/Llama-2-70b": MetricsResponse(
            timestamp=datetime.utcnow().isoformat() + "Z",
            total_requests=500,
            qps=20.0,
            p50_latency_ms=300.0,
            p99_latency_ms=420.0,
            p999_latency_ms=600.0,
            mean_latency_ms=330.0,
            avg_improvement_percent=43.0,
            total_cost_saved_usd=800.0,
            sla_compliance_rate=0.985,
        ),
        "mistral/Mistral-7B": MetricsResponse(
            timestamp=datetime.utcnow().isoformat() + "Z",
            total_requests=300,
            qps=15.0,
            p50_latency_ms=180.0,
            p99_latency_ms=280.0,
            p999_latency_ms=400.0,
            mean_latency_ms=210.0,
            avg_improvement_percent=42.5,
            total_cost_saved_usd=450.0,
            sla_compliance_rate=0.980,
        ),
        "meta-llama/Llama-2-13b": MetricsResponse(
            timestamp=datetime.utcnow().isoformat() + "Z",
            total_requests=200,
            qps=7.5,
            p50_latency_ms=240.0,
            p99_latency_ms=350.0,
            p999_latency_ms=500.0,
            mean_latency_ms=280.0,
            avg_improvement_percent=42.0,
            total_cost_saved_usd=0.0,
            sla_compliance_rate=0.975,
        ),
    }


# ============================================================================
# A/B TESTING ENDPOINTS
# ============================================================================


@app.post("/abtest/create")
async def create_ab_test(test: ABTestRequest, background_tasks: BackgroundTasks):
    """
    Create a new A/B test comparing baseline vs CAAE.

    Splits traffic percentage-wise between baseline and CAAE optimizations.
    """
    if test.name in ab_tests:
        raise HTTPException(
            status_code=400, detail="Test with this name already exists"
        )

    if not 1 <= test.split_percent <= 99:
        raise HTTPException(
            status_code=400, detail="split_percent must be between 1 and 99"
        )

    result = ABTestResult(
        test_name=test.name,
        status="running",
        baseline_qps=40.0,
        baseline_p99_ms=450.0,
        caae_qps=0.0,
        caae_p99_ms=0.0,
        throughput_improvement_percent=0.0,
        latency_improvement_percent=0.0,
        cost_saved_usd=0.0,
    )

    ab_tests[test.name] = result
    logger.info(f"Created A/B test: {test.name}")

    # In production, would trigger test runner in background
    # background_tasks.add_task(run_ab_test, test)

    return {"test_name": test.name, "status": "created"}


@app.get("/abtest/{test_name}", response_model=ABTestResult)
async def get_ab_test_results(test_name: str) -> ABTestResult:
    """Get results for an A/B test."""
    if test_name not in ab_tests:
        raise HTTPException(status_code=404, detail="Test not found")

    return ab_tests[test_name]


@app.get("/abtest/list")
async def list_ab_tests():
    """List all A/B tests."""
    return {
        "tests": list(ab_tests.keys()),
        "count": len(ab_tests),
    }


@app.post("/abtest/{test_name}/complete")
async def complete_ab_test(test_name: str):
    """Mark A/B test as completed."""
    if test_name not in ab_tests:
        raise HTTPException(status_code=404, detail="Test not found")

    test = ab_tests[test_name]
    test.status = "completed"
    test.caae_qps = 112.0  # Example: 2.9x improvement
    test.caae_p99_ms = 280.0
    test.throughput_improvement_percent = 180.0
    test.latency_improvement_percent = 37.8
    test.cost_saved_usd = 5000.0

    return {"status": "completed", "result": test}


# ============================================================================
# ROI CALCULATION ENDPOINTS
# ============================================================================


@app.post("/roi/calculate", response_model=ROICalculation)
async def calculate_roi(
    gpu_spend: float = Query(..., gt=0), improvement: float = Query(42.8, ge=0, le=100)
):
    """
    Calculate ROI for CAAE subscription.

    Args:
        gpu_spend: Monthly GPU infrastructure spend (USD)
        improvement: Expected performance improvement (%)

    Returns:
        ROI calculation with payback period
    """
    monthly_savings = gpu_spend * (improvement / 100)

    # Pricing tiers
    if gpu_spend < 5000:
        subscription_cost = 5000
    elif gpu_spend < 25000:
        subscription_cost = 25000
    else:
        subscription_cost = gpu_spend * 0.15  # 15% of GPU spend

    net_monthly_benefit = monthly_savings - subscription_cost
    payback_months = (
        subscription_cost / monthly_savings if monthly_savings > 0 else float("inf")
    )

    return ROICalculation(
        monthly_gpu_spend_usd=gpu_spend,
        estimated_improvement_percent=improvement,
        estimated_monthly_savings_usd=monthly_savings,
        caae_subscription_cost_usd=subscription_cost,
        net_monthly_benefit_usd=max(0, net_monthly_benefit),
        payback_period_months=payback_months,
        annual_savings_usd=max(0, (monthly_savings - subscription_cost) * 12),
    )


@app.get("/roi/pricing-tiers")
async def get_pricing_tiers():
    """Get pricing tier information."""
    return {
        "tiers": [
            {
                "name": "Basic",
                "monthly_cost": 5000,
                "features": [
                    "Single GPU node (1-4 GPUs)",
                    "Exp 9 (multi-GPU) only",
                    "Basic dashboard",
                    "Email support",
                ],
                "target": "Startups, researchers",
            },
            {
                "name": "Professional",
                "monthly_cost": 25000,
                "features": [
                    "Multi-node clusters (up to 100 GPUs)",
                    "All experiments (8, 9, 7, 10, 13)",
                    "Full dashboard + API",
                    "Slack/email support",
                    "A/B testing tools",
                ],
                "target": "Mid-size platforms",
            },
            {
                "name": "Enterprise",
                "monthly_cost": "Custom",
                "features": [
                    "Unlimited scale",
                    "Custom optimizations",
                    "Dedicated support",
                    "On-prem deployment",
                    "SLA guarantees",
                ],
                "target": "Enterprise customers",
            },
        ]
    }


# ============================================================================
# CONFIGURATION ENDPOINTS
# ============================================================================


@app.put("/config/experiments")
async def update_experiment_config(config: ConfigResponse):
    """
    Update which experiments are enabled.

    Allows customers to enable/disable optimizations per their needs.
    """
    # In production, would persist to database and sync to plugins
    logger.info(f"Updated experiment config: {config}")
    return {
        "status": "updated",
        "config": config,
    }


@app.post("/config/reset")
async def reset_config():
    """Reset configuration to defaults."""
    return {
        "status": "reset",
        "config": ConfigResponse(),
    }


# ============================================================================
# COST TRACKING ENDPOINTS
# ============================================================================


@app.get("/costs/daily-savings")
async def get_daily_savings(days: int = Query(30, ge=1, le=365)):
    """Get daily cost savings over time period."""
    daily_savings = []
    for i in range(days):
        date = datetime.utcnow() - timedelta(days=days - i)
        daily_savings.append(
            {
                "date": date.date().isoformat(),
                "gpu_cost_baseline_usd": 1500.0 + (i * 10),
                "gpu_cost_with_caae_usd": 900.0 + (i * 6),
                "caae_subscription_daily_usd": 833.33,  # $25k/month
                "net_savings_usd": max(0, (1500.0 - 900.0) - 833.33),
            }
        )

    return {"daily_savings": daily_savings}


@app.get("/costs/summary")
async def get_cost_summary():
    """Get cost savings summary."""
    return {
        "period": "last_30_days",
        "baseline_gpu_cost": 45000.0,
        "with_caae_cost": 27000.0,
        "caae_subscription": 25000.0,
        "gross_savings": 18000.0,
        "net_savings": -7000.0,  # Negative in month 1, positive after
        "payback_month": 2,
        "roi_percent": 28.0,
    }


# ============================================================================
# DOCUMENTATION ENDPOINTS
# ============================================================================


@app.get("/docs/getting-started")
async def get_getting_started():
    """Get getting started guide."""
    return {
        "title": "Getting Started with CAAE",
        "steps": [
            {
                "number": 1,
                "title": "Install Plugin",
                "command": "pip install caae",
            },
            {
                "number": 2,
                "title": "Add to vLLM",
                "code": """
from caae.vllm_plugin import create_caae_plugin
plugin = create_caae_plugin()
llm = LLM(model="...", plugins=[plugin])
                """,
            },
            {
                "number": 3,
                "title": "View Dashboard",
                "url": "https://dashboard.caae.io",
            },
            {
                "number": 4,
                "title": "Run A/B Test",
                "description": "Compare baseline vs CAAE performance",
            },
        ],
    }


@app.get("/docs/experiments")
async def get_experiments_docs():
    """Get documentation on all experiments."""
    return {
        "experiments": [
            {
                "id": 8,
                "name": "Speculative Decoding Optimization",
                "improvement": "2.0x batch size",
                "description": "Selective caching of draft tokens with 71.4% prediction accuracy",
            },
            {
                "id": 9,
                "name": "Multi-GPU NVLink Coordination",
                "improvement": "2.9x throughput",
                "description": "Cluster-aware KV cache eviction coordination",
            },
            {
                "id": 7,
                "name": "Shared KV Cache Pooling",
                "improvement": "4x batch size",
                "description": "Content-based KV block sharing for RAG workloads",
            },
            {
                "id": 10,
                "name": "Adaptive SLA Prioritization",
                "improvement": "35% throughput, 98%+ SLA compliance",
                "description": "Dynamic eviction thresholds based on request deadlines",
            },
            {
                "id": 13,
                "name": "Production Trace Validation",
                "improvement": "54.3% P99 latency",
                "description": "Real Azure/AWS trace validation",
            },
        ]
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
