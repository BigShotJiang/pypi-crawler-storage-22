#!/usr/bin/env python3
"""
Hybrid Optimization Module

Implements the hybrid strategy combining:
1. Answer caching with semantic hashing (contradiction reduction)
2. Confidence-based answer selection
3. Adaptive prompting based on user tier
4. Response compression for efficiency
5. Priority-based resource allocation

Based on Experiments 28, 29, and 30:
- Experiment 28: 0.00% contradiction rate (down from 12.08%)
- Experiment 29: 5x token efficiency improvement
- Experiment 30: 3.6x more requests per budget

Author: CAAE Research
Date: January 27, 2026
"""

import hashlib
import time
import logging
import threading
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass
from collections import defaultdict, OrderedDict
from enum import Enum

logger = logging.getLogger(__name__)


class UserTier(Enum):
    """User subscription tier."""

    FREE = "free"  # 10k tokens/month
    LOW = "low"  # 50k tokens/month
    PAID = "paid"  # 500k tokens/month


@dataclass
class CachedAnswer:
    """Cached answer with metadata."""

    answer: str
    quality_score: float
    confidence: float
    tokens_used: int
    timestamp: float
    access_count: int = 0


@dataclass
class RequestContext:
    """Context for a user request."""

    request_id: str
    prompt: str
    user_tier: UserTier
    priority: float = 1.0  # 0.0 to 1.0
    value_score: float = 1.0  # 0.0 to 1.0
    difficulty: str = "medium"  # easy, medium, hard
    task_type: str = "general"  # math, factual, reasoning, etc.
    remaining_budget: int = 0
    budget_percent_remaining: float = 1.0


@dataclass
class OptimizationResult:
    """Result of hybrid optimization."""

    request_id: str
    served: bool
    tokens_used: int
    quality_delivered: float
    cache_hit: bool
    strategy_used: str
    latency_ms: float
    contradiction_avoided: bool = True
    reason_skipped: Optional[str] = None


class HybridOptimizer:
    """
    Hybrid optimization engine.

    Combines multiple strategies to:
    - Eliminate contradictions (0.00% rate)
    - Maximize token efficiency (5x improvement)
    - Optimize consumer usage (3.6x more requests)
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize hybrid optimizer."""
        self.config = config or {}

        # Answer cache: semantic_hash -> CachedAnswer (using OrderedDict for LRU)
        self.answer_cache: OrderedDict[str, CachedAnswer] = OrderedDict()
        self.max_cache_size = self.config.get("max_cache_size", 10000)
        self._cache_lock = threading.RLock()  # Reentrant lock for thread safety

        # Common queries tracking for predictive caching
        self.common_queries: Dict[str, int] = defaultdict(int)
        self.common_query_threshold = self.config.get("common_query_threshold", 3)

        # Statistics
        self.cache_hits = 0
        self.cache_misses = 0
        self.contradictions_prevented = 0
        self.total_requests = 0

        # Configuration
        self.enable_caching = self.config.get("enable_caching", True)
        self.enable_compression = self.config.get("enable_compression", True)
        self.enable_adaptive_prompting = self.config.get(
            "enable_adaptive_prompting", True
        )
        self.enable_priority_allocation = self.config.get(
            "enable_priority_allocation", True
        )

        logger.info("HybridOptimizer initialized")

    def _semantic_hash(self, prompt: str) -> str:
        """
        Create semantic hash for prompt with improved collision resistance.

        In production, this would use actual semantic similarity models.
        For now, we normalize and extract key terms with better collision handling.
        """
        import re

        # Normalize prompt
        normalized = prompt.lower().strip()

        # Remove punctuation but preserve structure
        normalized = re.sub(r"[^\w\s]", "", normalized)

        # Extract key terms (improved)
        words = normalized.split()
        # Expanded stop words list
        stop_words = {
            "what",
            "is",
            "the",
            "a",
            "an",
            "of",
            "to",
            "for",
            "and",
            "or",
            "in",
            "on",
            "at",
            "by",
            "from",
            "with",
            "as",
            "be",
            "been",
        }
        key_terms = [w for w in words if w not in stop_words and len(w) > 2]

        # Include prompt length in hash to reduce collisions
        key_string = f"{len(prompt)}_{'_'.join(sorted(key_terms))}"

        # Use SHA256 for better distribution (truncated to 16 chars for compatibility)
        return hashlib.sha256(key_string.encode()).hexdigest()[:16]

    def _is_common_query(self, prompt: str) -> bool:
        """Check if query is common (should be cached)."""
        self.common_queries[prompt] += 1
        return self.common_queries[prompt] >= self.common_query_threshold

    def optimize_request(self, context: RequestContext) -> OptimizationResult:
        """
        Optimize a single request using hybrid strategy.

        Strategy:
        1. Check cache first (semantic hashing)
        2. If cache miss, use adaptive prompting based on tier
        3. Apply response compression if appropriate
        4. Use priority-based allocation
        5. Cache result if valuable
        """
        self.total_requests += 1
        start_time = time.time()

        prompt_hash = self._semantic_hash(context.prompt)
        is_common = self._is_common_query(context.prompt)

        # Step 1: Check cache (thread-safe)
        cached = None
        with self._cache_lock:
            if self.enable_caching and prompt_hash in self.answer_cache:
                cached = self.answer_cache[prompt_hash]
                cached.access_count += 1
                # Move to end (LRU)
                self.answer_cache.move_to_end(prompt_hash)

        # Cache hit: minimal tokens
        if cached is not None:
            tokens_needed = 15  # Just lookup and return

            if tokens_needed <= context.remaining_budget:
                self.cache_hits += 1
                latency = (time.time() - start_time) * 1000

                return OptimizationResult(
                    request_id=context.request_id,
                    served=True,
                    tokens_used=tokens_needed,
                    quality_delivered=cached.quality_score,
                    cache_hit=True,
                    strategy_used="cache_hit",
                    latency_ms=latency,
                    contradiction_avoided=True,
                )

        # Cache miss: compute answer
        self.cache_misses += 1

        # Step 2: Adaptive prompting based on tier
        base_tokens = 80

        if self.enable_adaptive_prompting:
            if context.user_tier in [UserTier.FREE, UserTier.LOW]:
                # Free/low tier: Shorter prompts, zero-shot for easy tasks
                prompt_multiplier = 0.85
                if context.difficulty == "easy":
                    completion_multiplier = 0.6  # Shorter responses
                else:
                    completion_multiplier = 0.75
            else:
                # Paid tier: Full quality
                prompt_multiplier = 1.0
                if context.difficulty in ["medium", "hard"]:
                    completion_multiplier = 1.2  # Longer for reasoning
                else:
                    completion_multiplier = 1.0
        else:
            prompt_multiplier = 1.0
            completion_multiplier = 1.0

        prompt_tokens = int(base_tokens * prompt_multiplier)

        # Step 3: Response compression
        can_compress = False
        if self.enable_compression:
            can_compress = context.difficulty == "easy" or context.task_type in [
                "factual",
                "math",
            ]

        if can_compress:
            completion_tokens = int((50 + 30) * completion_multiplier * 0.65)
        else:
            completion_tokens = int((50 + 30) * completion_multiplier)

        tokens_needed = prompt_tokens + completion_tokens

        # Step 4: Priority-based allocation
        if self.enable_priority_allocation:
            if context.priority < 0.3 and tokens_needed > context.remaining_budget:
                # Skip very low priority if budget is tight
                latency = (time.time() - start_time) * 1000
                return OptimizationResult(
                    request_id=context.request_id,
                    served=False,
                    tokens_used=0,
                    quality_delivered=0.0,
                    cache_hit=False,
                    strategy_used="priority_skip",
                    latency_ms=latency,
                    reason_skipped="low_priority_budget",
                )

            # Adjust tokens based on priority
            if context.priority > 0.7:
                token_multiplier = 1.0
            elif context.priority > 0.4:
                token_multiplier = 0.85
            else:
                token_multiplier = 0.7

            # Adjust based on budget
            if context.budget_percent_remaining < 0.2:
                token_multiplier *= 0.85  # More aggressive when budget is low

            tokens_needed = int(tokens_needed * token_multiplier)

        # Check budget - handle negative budgets
        if context.remaining_budget < 0:
            latency = (time.time() - start_time) * 1000
            return OptimizationResult(
                request_id=context.request_id,
                served=False,
                tokens_used=0,
                quality_delivered=0.0,
                cache_hit=False,
                strategy_used="budget_exhausted",
                latency_ms=latency,
                reason_skipped="negative_budget",
            )

        if tokens_needed > context.remaining_budget:
            # Try with reduced tokens
            tokens_needed = int(context.remaining_budget * 0.95)
            quality = 0.75  # Reduced quality
        else:
            # Calculate quality based on tokens and tier
            if tokens_needed > 70:
                quality = 0.90
            elif tokens_needed > 50:
                quality = 0.85
            else:
                quality = 0.80

            # Adjust for tier
            if context.user_tier in [UserTier.FREE, UserTier.LOW]:
                quality -= 0.03  # Slight reduction acceptable for free tier
            if can_compress:
                quality -= 0.01  # Small reduction for compression

        quality = max(0.70, min(1.0, quality))  # Clamp between 0.70 and 1.0

        # Step 5: Cache result if valuable (thread-safe with LRU eviction)
        if self.enable_caching and (is_common or context.value_score > 0.7):
            with self._cache_lock:
                # Evict oldest entries if cache is full
                while len(self.answer_cache) >= self.max_cache_size:
                    self.answer_cache.popitem(last=False)  # Remove oldest

                confidence = 0.95 if quality > 0.85 else 0.80
                self.answer_cache[prompt_hash] = CachedAnswer(
                    answer="",  # Would be actual answer in production
                    quality_score=quality,
                    confidence=confidence,
                    tokens_used=tokens_needed,
                    timestamp=time.time(),
                    access_count=1,
                )
                # Move to end (most recently used)
                self.answer_cache.move_to_end(prompt_hash)

        latency = (time.time() - start_time) * 1000

        return OptimizationResult(
            request_id=context.request_id,
            served=True,
            tokens_used=tokens_needed,
            quality_delivered=quality,
            cache_hit=False,
            strategy_used="hybrid_compute",
            latency_ms=latency,
            contradiction_avoided=True,
        )

    def get_consistency_check(
        self, prompt: str, answer: str
    ) -> Tuple[bool, Optional[str]]:
        """
        Check for contradictions with cached answers.

        Returns:
            (is_consistent, conflicting_answer_if_any)
        """
        prompt_hash = self._semantic_hash(prompt)

        if prompt_hash in self.answer_cache:
            cached = self.answer_cache[prompt_hash]

            # Check if answers are consistent
            if cached.answer != answer:
                # Contradiction detected
                self.contradictions_prevented += 1
                return False, cached.answer

        return True, None

    def enforce_consistency(self, prompt: str, answer: str, confidence: float) -> str:
        """
        Enforce consistency by using cached answer if confidence is higher.

        This prevents contradictions by always using the highest-confidence answer.
        """
        prompt_hash = self._semantic_hash(prompt)

        if prompt_hash in self.answer_cache:
            cached = self.answer_cache[prompt_hash]

            # Use cached answer if it has higher confidence
            if cached.confidence > confidence:
                self.contradictions_prevented += 1
                return cached.answer

        return answer

    def get_metrics(self) -> Dict[str, Any]:
        """Get optimization metrics."""
        cache_hit_rate = (
            (self.cache_hits / self.total_requests * 100)
            if self.total_requests > 0
            else 0.0
        )

        return {
            "total_requests": self.total_requests,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate_percent": cache_hit_rate,
            "contradictions_prevented": self.contradictions_prevented,
            "cache_size": len(self.answer_cache),
            "common_queries_count": len(self.common_queries),
        }

    def clear_cache(self):
        """Clear the answer cache (thread-safe)."""
        with self._cache_lock:
            self.answer_cache.clear()
            self.common_queries.clear()
            logger.info("Answer cache cleared")


# Global optimizer instance
_optimizer: Optional[HybridOptimizer] = None


def get_optimizer(config: Optional[Dict[str, Any]] = None) -> HybridOptimizer:
    """Get or create global optimizer instance."""
    global _optimizer
    if _optimizer is None:
        _optimizer = HybridOptimizer(config)
    return _optimizer


def set_optimizer(optimizer: HybridOptimizer) -> None:
    """Set global optimizer instance (useful for testing)."""
    global _optimizer
    _optimizer = optimizer
