"""Test suite for CAAE package."""
