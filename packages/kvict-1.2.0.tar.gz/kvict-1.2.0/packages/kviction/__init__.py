"""
kvict: CLI and packaging glue for the CAAE advisor and kv_evict library.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("kvict")
except PackageNotFoundError:  # pragma: no cover - fallback for editable installs
    __version__ = "0.0.0"


__all__ = ["__version__"]
