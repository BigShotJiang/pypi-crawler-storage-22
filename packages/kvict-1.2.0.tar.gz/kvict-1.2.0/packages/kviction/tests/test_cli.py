from kvict.cli import main


def test_help_shows_usage(capsys):
    code = main([])
    captured = capsys.readouterr()

    assert code == 1
    assert "kvict" in captured.out


def test_kube_manifest_renders_yaml(capsys):
    code = main(
        [
            "kube",
            "--name",
            "test-app",
            "--namespace",
            "default",
            "--image",
            "example.com/test:1",
        ]
    )
    captured = capsys.readouterr()

    assert code == 0
    assert "test-app" in captured.out
    assert "example.com/test:1" in captured.out
