"""
kvict Proxy - Subscription Stretching Proxy for LLM APIs.

Routes requests through an intelligent caching proxy that uses CAAE-inspired
cost modeling to maximize token savings. Provider-agnostic: OpenAI, Anthropic,
vLLM, and self-hosted backends.

Value prop: "Make your Pro plan feel 2-3x larger without changing providers."
"""

__version__ = "1.0.0"
