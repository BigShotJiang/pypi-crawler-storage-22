"""
Provider adapters for the kvict Proxy.

Each adapter translates between the unified OpenAI-compatible format
and a specific provider's native API format.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base import ProviderAdapter


def get_adapter(provider: str, base_url: str = "") -> ProviderAdapter:
    """
    Factory function to get a provider adapter by name.

    Args:
        provider: One of "openai", "anthropic", "gemini", "vllm", "generic"
        base_url: Optional custom base URL for the provider

    Returns:
        A ProviderAdapter instance

    Raises:
        ValueError: If provider is not recognized
    """
    if provider == "openai":
        from .openai import OpenAIAdapter

        return OpenAIAdapter(base_url=base_url or "https://api.openai.com")

    elif provider == "anthropic":
        from .anthropic import AnthropicAdapter

        return AnthropicAdapter(base_url=base_url or "https://api.anthropic.com")

    elif provider == "gemini":
        from .gemini import GeminiAdapter

        return GeminiAdapter(
            base_url=base_url or "https://generativelanguage.googleapis.com/v1beta"
        )

    elif provider == "vllm":
        from .vllm_compat import VLLMCompatAdapter

        if not base_url:
            raise ValueError("vllm provider requires a base_url")
        return VLLMCompatAdapter(base_url=base_url)

    elif provider == "generic":
        from .generic import GenericAdapter

        if not base_url:
            raise ValueError("generic provider requires a base_url")
        return GenericAdapter(base_url=base_url)

    else:
        raise ValueError(
            f"Unknown provider: {provider!r}. "
            f"Supported: openai, anthropic, gemini, vllm, generic"
        )
