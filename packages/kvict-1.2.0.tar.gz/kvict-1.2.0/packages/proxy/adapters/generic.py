"""
Generic self-hosted provider adapter.

Minimal-transform passthrough for arbitrary OpenAI-compatible endpoints.
Same as vLLM adapter but with name="generic" for clarity.

Users with custom LLM servers (llama.cpp, text-generation-inference,
Ollama, etc.) use this adapter.
"""

from __future__ import annotations

from proxy.adapters.vllm_compat import VLLMCompatAdapter


class GenericAdapter(VLLMCompatAdapter):
    """Generic adapter for self-hosted OpenAI-compatible servers."""

    @property
    def name(self) -> str:
        return "generic"
