"""
vLLM / OpenAI-compatible provider adapter.

vLLM serves an OpenAI-compatible API by default, so this adapter
is a near-passthrough. The key difference: configurable base_url
pointing to the user's self-hosted endpoint, and zero pricing
(self-hosted cost tracked separately).
"""

from __future__ import annotations

import json
from typing import Any, Dict, Tuple

from proxy.adapters.openai import OpenAIAdapter
from proxy.pricing import ZERO_PRICING
from proxy.schemas import TokenPricing


class VLLMCompatAdapter(OpenAIAdapter):
    """Adapter for vLLM and other OpenAI-compatible servers.

    Inherits from OpenAIAdapter since the API format is identical.
    Only overrides: name, pricing (zero for self-hosted).
    """

    @property
    def name(self) -> str:
        return "vllm"

    def get_pricing(self, model: str) -> TokenPricing:
        # Self-hosted: no per-token API cost
        # Users can configure custom pricing via the dashboard
        return ZERO_PRICING
