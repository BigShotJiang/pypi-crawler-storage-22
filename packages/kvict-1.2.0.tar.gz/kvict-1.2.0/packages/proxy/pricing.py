"""
Provider pricing tables.

Single source of truth for per-model token costs across all providers.
Prices are in USD per 1,000 tokens. Updated manually.

Sources:
  - OpenAI: https://openai.com/api/pricing/
  - Anthropic: https://docs.anthropic.com/en/docs/about-claude/models
"""

from proxy.schemas import TokenPricing

# ---------------------------------------------------------------------------
# OpenAI pricing (USD per 1K tokens, as of Jan 2026)
# ---------------------------------------------------------------------------
OPENAI_PRICING: dict[str, TokenPricing] = {
    # GPT-4o family
    "gpt-4o": TokenPricing(
        input_cost_per_1k=0.0025,
        output_cost_per_1k=0.01,
        cached_input_cost_per_1k=0.00125,
    ),
    "gpt-4o-2024-11-20": TokenPricing(
        input_cost_per_1k=0.0025,
        output_cost_per_1k=0.01,
        cached_input_cost_per_1k=0.00125,
    ),
    "gpt-4o-mini": TokenPricing(
        input_cost_per_1k=0.00015,
        output_cost_per_1k=0.0006,
        cached_input_cost_per_1k=0.000075,
    ),
    "gpt-4o-mini-2024-07-18": TokenPricing(
        input_cost_per_1k=0.00015,
        output_cost_per_1k=0.0006,
        cached_input_cost_per_1k=0.000075,
    ),
    # GPT-4 Turbo
    "gpt-4-turbo": TokenPricing(
        input_cost_per_1k=0.01,
        output_cost_per_1k=0.03,
        cached_input_cost_per_1k=0.005,
    ),
    "gpt-4-turbo-2024-04-09": TokenPricing(
        input_cost_per_1k=0.01,
        output_cost_per_1k=0.03,
        cached_input_cost_per_1k=0.005,
    ),
    # Legacy / chat
    "gpt-3.5-turbo": TokenPricing(
        input_cost_per_1k=0.0005,
        output_cost_per_1k=0.0015,
        cached_input_cost_per_1k=0.00025,
    ),
    # o-series reasoning models
    "o1": TokenPricing(
        input_cost_per_1k=0.015,
        output_cost_per_1k=0.06,
        cached_input_cost_per_1k=0.0075,
    ),
    "o1-mini": TokenPricing(
        input_cost_per_1k=0.003,
        output_cost_per_1k=0.012,
        cached_input_cost_per_1k=0.0015,
    ),
    "o3-mini": TokenPricing(
        input_cost_per_1k=0.0011,
        output_cost_per_1k=0.0044,
        cached_input_cost_per_1k=0.00055,
    ),
}

# ---------------------------------------------------------------------------
# Anthropic pricing (USD per 1K tokens, as of Jan 2026)
# ---------------------------------------------------------------------------
ANTHROPIC_PRICING: dict[str, TokenPricing] = {
    "claude-opus-4-20250514": TokenPricing(
        input_cost_per_1k=0.015,
        output_cost_per_1k=0.075,
        cached_input_cost_per_1k=0.0075,
    ),
    "claude-sonnet-4-20250514": TokenPricing(
        input_cost_per_1k=0.003,
        output_cost_per_1k=0.015,
        cached_input_cost_per_1k=0.0015,
    ),
    "claude-3-5-haiku-20241022": TokenPricing(
        input_cost_per_1k=0.0008,
        output_cost_per_1k=0.004,
        cached_input_cost_per_1k=0.0004,
    ),
}

# Convenience aliases
ANTHROPIC_PRICING["claude-opus-4-20250514"] = ANTHROPIC_PRICING["claude-opus-4-20250514"]
ANTHROPIC_PRICING["claude-sonnet-4-20250514"] = ANTHROPIC_PRICING["claude-sonnet-4-20250514"]

# ---------------------------------------------------------------------------
# Fallback / self-hosted (zero cost)
# ---------------------------------------------------------------------------
ZERO_PRICING = TokenPricing(
    input_cost_per_1k=0.0,
    output_cost_per_1k=0.0,
    cached_input_cost_per_1k=0.0,
)


def get_pricing(provider: str, model: str) -> TokenPricing:
    """Look up pricing for a provider + model combination.

    Falls back to zero pricing for unknown models.
    """
    tables: dict[str, dict[str, TokenPricing]] = {
        "openai": OPENAI_PRICING,
        "anthropic": ANTHROPIC_PRICING,
        "gemini": GEMINI_PRICING,
    }
    table = tables.get(provider, {})
    return table.get(model, ZERO_PRICING)
