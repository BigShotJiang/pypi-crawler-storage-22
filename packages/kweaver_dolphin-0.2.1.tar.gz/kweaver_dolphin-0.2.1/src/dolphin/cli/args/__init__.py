# -*- coding: utf-8 -*-
"""Args 模块 - 参数解析"""

from dolphin.cli.args.parser import Args, parseArgs

__all__ = [
    "Args",
    "parseArgs",
]
