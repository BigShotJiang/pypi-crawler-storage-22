# -*- coding: utf-8 -*-
"""Interrupt 模块 - 中断处理"""

from dolphin.cli.interrupt.handler import InterruptToken

__all__ = [
    "InterruptToken",
]
