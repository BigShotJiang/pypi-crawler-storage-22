# -*- coding: utf-8 -*-
"""Runner 模块 - CLI 运行器"""

from dolphin.cli.runner.runner import runDolphinAgent

__all__ = [
    "runDolphinAgent",
]
