# -*- coding: utf-8 -*-
"""Utils 模块 - CLI 工具"""

from dolphin.cli.utils.version import getVersion

__all__ = [
    "getVersion",
]
