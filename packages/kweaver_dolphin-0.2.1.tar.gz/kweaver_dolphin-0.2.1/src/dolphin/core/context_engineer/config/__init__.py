"""Configuration management for context engineering."""

from .settings import ContextConfig

__all__ = ["ContextConfig"]
