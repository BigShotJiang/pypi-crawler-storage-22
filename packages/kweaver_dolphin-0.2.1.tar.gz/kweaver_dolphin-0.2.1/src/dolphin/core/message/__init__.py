# -*- coding: utf-8 -*-
"""Message 模块 - 消息压缩"""

from dolphin.core.message.compressor import MessageCompressor

__all__ = [
    "MessageCompressor",
]
