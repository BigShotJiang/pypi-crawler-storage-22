# -*- coding: utf-8 -*-
"""Parser 模块 - 语法解析器"""

from dolphin.core.parser.parser import Parser

__all__ = [
    "Parser",
]
