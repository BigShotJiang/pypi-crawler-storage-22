"""
kyber - A lightweight AI agent framework
"""

__version__ = "2026.2.6.7"
__logo__ = "💎"
