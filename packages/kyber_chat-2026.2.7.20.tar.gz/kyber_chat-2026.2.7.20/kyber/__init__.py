"""
kyber - A lightweight AI agent framework
"""

__version__ = "2026.2.7.20"
__logo__ = "💎"
