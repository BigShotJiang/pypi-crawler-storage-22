"""
kyber - A lightweight AI agent framework
"""

__version__ = "2026.2.7.8"
__logo__ = "💎"
