"""
kyber - A lightweight AI agent framework
"""

__version__ = "2026.2.8.25"
__logo__ = "💎"
