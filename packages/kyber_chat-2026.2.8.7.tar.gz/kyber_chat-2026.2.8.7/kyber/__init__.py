"""
kyber - A lightweight AI agent framework
"""

__version__ = "2026.2.8.7"
__logo__ = "💎"
