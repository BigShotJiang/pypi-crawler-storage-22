LLM_pricing = {
      "gpt-4o":{"input":5.00,"output":15.00},
      "gpt-4o-mini":{"input":0.15,"output":0.6}
}