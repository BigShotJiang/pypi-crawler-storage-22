import time 
import uuid 
import json
import logging
from typing import Any, Dict, Optional
from openai import OpenAI
from pydantic import BaseModel,Field

from .config import LLM_pricing

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("kyber.telemetry")

class LLMCallContext(BaseModel):
      execution_id: str
      agent_id: str
      tenent_id: str
      circuit_id: Optional[str] = None
      
def _calculate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
      if model not in LLM_pricing:
            return 0.0
      princing = LLM_pricing[model]
      input_cost = (prompt_tokens / 1000) * princing["input"]
      output_cost = (completion_tokens / 1000) * princing["output"]
      return round(input_cost + output_cost, 6)

def llm_call(
      *,
      model: str,
      messages: list[Dict[str, str]],
      purpose: str,
      context: LLMCallContext,
      temperature: float = 0.7,
      max_retries: int = 3,
      client: Optional[OpenAI] = None
) -> Dict[str, Any]:
      
      if not purpose:
            raise ValueError("Purpose must be provided for LLM call telemetry.")
      
      call_id = str(uuid.uuid4())
      start_time = time.time()
      retry_count = 0
      client = client or OpenAI()
      
      while retry_count <= max_retries:
            try:
                  response = client.chat.completions.create(
                        model=model,
                        messages=messages,
                        temperature=temperature,
                        timeout=30.0
                  )
                  
                  
                  usage = response.usage
                  latency_ms = int((time.time() - start_time) * 1000)
                  cost_usd = _calculate_cost(model,usage.prompt_tokens, usage.completion_tokens)
                  
                  telemetry = {
                        "call_id": call_id,
                        "execution_id": context.execution_id,
                        "agent_id": context.agent_id,
                        "tenent_id": context.tenent_id,
                        "circuit_id": context.circuit_id,
                        "model": model,
                        "purpose": purpose,
                        "latency_ms": latency_ms,
                        "prompt_tokens": usage.prompt_tokens,
                        "completion_tokens": usage.completion_tokens,
                        "total_tokens": usage.total_tokens,
                        "llm_cost_usd": cost_usd,
                        "success": True,
                        "error_message": None,
                        "temperature": temperature,
                        "retry_count": retry_count,
                        "timestamp": time.time()
                  }
                  
                  logger.info("LLM Call Telemetry:", extra={"telemetry": telemetry})
                  
                  return json.loads(response.model_dump_json())
            except Exception as e:
                  retry_count += 1
                  if retry_count > max_retries:
                        latency_ms = int((time.time() - start_time) * 1000)
                        telemetry = {
                              "call_id": call_id,
                              "execution_id": context.execution_id,
                              "agent_id": context.agent_id,
                              "tenent_id": context.tenent_id,
                              "circuit_id": context.circuit_id,
                              "model": model,
                              "purpose": purpose,
                              "latency_ms": latency_ms,
                              "prompt_tokens": 0,
                              "completion_tokens": 0,
                              "total_tokens": 0,
                              "llm_cost_usd": 0.0,
                              "success": False,
                              "error_message": str(e),
                              "temperature": temperature,
                              "retry_count": retry_count,
                              "timestamp": time.time()
                        }
                        
                        logger.error("LLM Call Telemetry:", extra={"telemetry": telemetry})
                        raise e
                  time.sleep(0.5 *(2 ** (retry_count - 1)))  # Exponential backoff