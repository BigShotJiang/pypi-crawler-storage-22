from setuptools import setup, find_packages

setup(
      name="kyber_runtime",
      version="0.1.4",
      author="Your Team",
      description="Kyber Agent Runtime SDK for instrumented LLM calls",
      long_description_content_type="text/markdown",
      packages=find_packages(),
      install_requires=[
            "openai>=1.0.0",
            "pydantic>=2.0.0"
        ],
        python_requires=">=3.9"
 )