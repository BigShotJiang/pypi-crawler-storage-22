# Kybernis Python SDK (beta)

This SDK lets multi-agent builders (LangGraph, CrewAI, LangChain) route tool calls through the Kybernis execution gate, emit execution spans, and report tool health/cost.

## Install (local dev)
- Add sdk/python to your PYTHONPATH or vendor the package into your app.
- Or set `KYB_SDK_PATH` to the absolute path of sdk/python.

## Minimal usage
- Set env: `KYB_API_BASE`, `KYB_API_TOKEN`, `KYB_TENANT_ID`, `KYB_RUN_ID`
- Enable SDK: `KYB_SDK_ON=1`

The SDK provides:
- `KybernisClient` for tool registry, health, events, cost, and gate requests.
- `kyb_tool` decorator to gate tool calls before framework-level HITL.
- `install()` auto-patches requests/httpx to inject Kybernis headers.
- `derive_idempotency_key()` to match proxy idempotency hashing.
- `span()` helpers for non-HTTP execution spans.
- Side-effect helpers: `webhook()`, `email()`, `charge()`.

## Env flags
- `KYB_SDK_ON=1` enable SDK
- `KYB_API_BASE` control plane base URL
- `KYB_API_TOKEN` auth token
- `KYB_TENANT_ID` tenant scope
- `KYB_RUN_ID` run scope (set per run)
- `KYB_TOOL_REGISTER=1` auto-register tools
- `KYB_GATE_AUTO_APPROVE=1` auto-approve gate unless overridden
- `KYB_TOOL_CALL_LIMIT=0` per-tool call limit (0 = unlimited)
- `KYB_ENFORCE_EGRESS=1` fail-closed if HTTP(S)_PROXY is not set
