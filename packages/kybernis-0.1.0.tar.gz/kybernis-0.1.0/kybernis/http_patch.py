import os
import uuid
from typing import Dict, Optional


_INSTALLED_REQUESTS = False
_INSTALLED_HTTPX = False


def _env(name: str, default: str = "") -> str:
    v = os.getenv(name)
    return v if v is not None else default


def _truthy(val: str, default: bool = True) -> bool:
    if val is None or str(val).strip() == "":
        return default
    return str(val).strip().lower() in {"1", "true", "yes", "on"}


def _build_headers(existing: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    headers: Dict[str, str] = dict(existing or {})

    tenant_id = _env("KYB_TENANT_ID", "")
    run_id = _env("KYB_RUN_ID", "")
    session_id = _env("KYB_SESSION_ID", "")

    span_id = headers.get("X-Kyb-Span-Id") or headers.get("X-Kyb-Step-Id")
    if not span_id:
        span_id = uuid.uuid4().hex

    if tenant_id and "X-Kyb-Tenant-Id" not in headers:
        headers["X-Kyb-Tenant-Id"] = tenant_id
    if run_id and "X-Kyb-Run-Id" not in headers:
        headers["X-Kyb-Run-Id"] = run_id
    if session_id and "X-Kyb-Session-Id" not in headers:
        headers["X-Kyb-Session-Id"] = session_id
    if "X-Kyb-Span-Id" not in headers:
        headers["X-Kyb-Span-Id"] = span_id

    headers.setdefault("X-Kyb-On", "1" if _truthy(_env("KYB_ON", "1")) else "0")
    headers.setdefault("X-Kyb-Idempotency", "1" if _truthy(_env("KYB_IDEM", "1")) else "0")
    headers.setdefault("X-Kyb-Retry", "1" if _truthy(_env("KYB_RETRY", "1")) else "0")
    headers.setdefault("X-Kyb-Budget", "1" if _truthy(_env("KYB_BUDGET", "0"), default=False) else "0")

    return headers


def _enforce_egress() -> None:
    if not _truthy(_env("KYB_ENFORCE_EGRESS", "0"), default=False):
        return
    if _env("HTTP_PROXY") or _env("HTTPS_PROXY"):
        return
    raise RuntimeError("KYB_ENFORCE_EGRESS=1 requires HTTP_PROXY/HTTPS_PROXY")


def install_requests_patch() -> None:
    global _INSTALLED_REQUESTS
    if _INSTALLED_REQUESTS:
        return
    _INSTALLED_REQUESTS = True

    try:
        import requests  # type: ignore
    except Exception:
        return

    original = requests.sessions.Session.request

    def patched(self, method, url, **kwargs):
        _enforce_egress()
        headers = kwargs.get("headers") or {}
        kwargs["headers"] = _build_headers(headers)
        return original(self, method, url, **kwargs)

    requests.sessions.Session.request = patched  # type: ignore[attr-defined]


def install_httpx_patch() -> None:
    global _INSTALLED_HTTPX
    if _INSTALLED_HTTPX:
        return
    _INSTALLED_HTTPX = True

    try:
        import httpx  # type: ignore
    except Exception:
        return

    original = httpx.Client.request

    def patched(self, method, url, **kwargs):
        _enforce_egress()
        headers = kwargs.get("headers") or {}
        kwargs["headers"] = _build_headers(headers)
        return original(self, method, url, **kwargs)

    httpx.Client.request = patched  # type: ignore[attr-defined]
