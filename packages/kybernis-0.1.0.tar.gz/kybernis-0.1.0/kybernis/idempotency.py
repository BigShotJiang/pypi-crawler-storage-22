import hashlib
from typing import Optional


def derive_idempotency_key(method: str, url: str, body: Optional[bytes] = None) -> str:
    """
    Deterministic key aligned with proxy hashRequest: sha256(method|url|body).
    """
    h = hashlib.sha256()
    h.update(method.encode("utf-8"))
    h.update(b"|")
    h.update(url.encode("utf-8"))
    h.update(b"|")
    h.update(body or b"")
    return h.hexdigest()
