import json
from typing import Any, Dict, Optional

import requests


class SideEffectClient:
    def __init__(self, timeout_s: int = 10) -> None:
        self.timeout_s = timeout_s

    def post(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
        idempotency_key: Optional[str] = None,
    ) -> requests.Response:
        h = dict(headers or {})
        if idempotency_key:
            h.setdefault("Idempotency-Key", idempotency_key)
        h.setdefault("Content-Type", "application/json")
        return requests.post(url, headers=h, data=json.dumps(payload), timeout=self.timeout_s)


def webhook(url: str, payload: Dict[str, Any], idempotency_key: Optional[str] = None) -> requests.Response:
    return SideEffectClient().post(url, payload, idempotency_key=idempotency_key)


def email(url: str, payload: Dict[str, Any], idempotency_key: Optional[str] = None) -> requests.Response:
    return SideEffectClient().post(url, payload, idempotency_key=idempotency_key)


def charge(url: str, payload: Dict[str, Any], idempotency_key: Optional[str] = None) -> requests.Response:
    return SideEffectClient().post(url, payload, idempotency_key=idempotency_key)
