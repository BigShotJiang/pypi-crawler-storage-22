import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Optional

from .client import KybernisClient


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def span_start(
    client: KybernisClient,
    run_id: str,
    span_type: str,
    name: str,
    span_id: Optional[str] = None,
    parent_id: str = "",
    attributes: Optional[Dict[str, Any]] = None,
) -> str:
    sid = span_id or uuid.uuid4().hex
    payload = {
        "span_id": sid,
        "parent_span_id": parent_id or None,
        "span_type": span_type,
        "name": name,
        "ts": _now_iso(),
        "attributes": attributes or {},
    }
    client.emit_event(run_id, "SPAN_START", payload, parent_id=parent_id)
    return sid


def span_end(
    client: KybernisClient,
    run_id: str,
    span_id: str,
    status: str = "ok",
    latency_ms: Optional[int] = None,
    attributes: Optional[Dict[str, Any]] = None,
    parent_id: str = "",
) -> None:
    payload = {
        "span_id": span_id,
        "status": status,
        "latency_ms": latency_ms if latency_ms is not None else 0,
        "ts": _now_iso(),
        "attributes": attributes or {},
    }
    client.emit_event(run_id, "SPAN_END", payload, parent_id=parent_id)


@contextmanager
def span(
    client: KybernisClient,
    run_id: str,
    span_type: str,
    name: str,
    parent_id: str = "",
    attributes: Optional[Dict[str, Any]] = None,
):
    start = time.time()
    sid = span_start(client, run_id, span_type, name, parent_id=parent_id, attributes=attributes)
    try:
        yield sid
        latency_ms = int((time.time() - start) * 1000)
        span_end(client, run_id, sid, status="ok", latency_ms=latency_ms, parent_id=parent_id)
    except Exception as exc:
        latency_ms = int((time.time() - start) * 1000)
        span_end(
            client,
            run_id,
            sid,
            status="error",
            latency_ms=latency_ms,
            attributes={"error": str(exc)},
            parent_id=parent_id,
        )
        raise
