# Kylas CRM MCP Server - Lead Only
__version__ = "1.0.1"
