"""
Run the Kylas CRM MCP server via: python3 -m kylas_crm_mcp
Uses the same entry point as the kylas-crm-mcp script, so it works
regardless of current working directory (avoids loading a local main.py).
"""
import sys
from importlib.metadata import entry_points

def main() -> None:
    eps = entry_points(group="console_scripts")
    for ep in eps:
        if ep.name == "kylas-crm-mcp":
            ep.load()()
            return
    print("kylas-crm-mcp: could not find console_scripts entry point. Run: pip install kylas-crm-mcp", file=sys.stderr)
    sys.exit(1)

if __name__ == "__main__":
    main()
