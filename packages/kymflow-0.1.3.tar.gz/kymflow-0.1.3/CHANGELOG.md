# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-11-01
### Added
- Initial public release of KymFlow.
- macOS standalone app bundle for running the KymFlow GUI without Python.

### Fixed
- N/A

### Known Issues
- Lots we will address in next releases.
