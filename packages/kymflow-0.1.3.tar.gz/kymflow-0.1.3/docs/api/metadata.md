# core.metadata

::: core.metadata

