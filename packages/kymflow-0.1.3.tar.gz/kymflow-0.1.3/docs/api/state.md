# core.state

::: core.state
