# src/kymflow/gui_v2/pages/__init__.py
"""v2 pages."""
