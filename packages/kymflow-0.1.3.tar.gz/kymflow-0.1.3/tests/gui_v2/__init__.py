"""Tests for GUI v2 components."""

