from __future__ import annotations
import sys
import pathlib
sys.path.append(str(pathlib.Path(__file__).parent.parent))

from l0n0lc import jit
import pytest

@jit(总是重编=True)
class NoInit:
    name: str = 'NoInit'
    name2: int = 123


@jit(总是重编=True)
class Home:
    name: str
    def __init__(self, name: str):
        self.name = name

    def getName(self)->str:
        return self.name

# 测试1: 字符串类型支持
@jit(总是重编=True)
class Person:
    name: str
    age: int
    home: Home = Home('大房子')
    _legs: int = 2

    def __init__(self, name: str, age: int):
        self.name = name
        self.age = age

# 测试2: 运算符重载
class Point:
    x: float = float(0)
    y: float = float(0)

    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y

    def __add__(self, other: Point) -> Point:
        return Point(self.x + other.x, self.y + other.y)

# 测试3: 静态方法
class Calculator:
    @staticmethod
    def add(a: int, b: int) -> int:
        return a + b


def test_operator_overloading():
    """测试运算符重载"""
    @jit(总是重编=True)
    def test_impl() -> float:
        p1 = Point(1.0, 2.0)
        p2 = Point(3.0, 4.0)
        result = p1 + p2
        return result.x  # Should be 4.0
    
    result = test_impl()
    assert result == 4.0, f"Expected 4.0, got {result}"
    print(f"✓ 运算符重载: {result}")


def test_static_method():
    """测试静态方法"""
    @jit(总是重编=True)
    def test_impl() -> int:
        return Calculator.add(10, 20)  # Should be 30
    
    result = test_impl()
    assert result == 30, f"Expected 30, got {result}"
    print(f"✓ 静态方法: {result}")

def test_复杂类型():
    @jit(总是重编=True)
    def test_impl()->int:
        p = Person('小明', 10000)
        print(p.home.name)
        print(p.home.getName())
        noInit = NoInit()
        print(noInit.name)
        return p.age
    result = test_impl()
    print(f"✓ 复杂类型: {result}")


if __name__ == '__main__':
    print("=== 测试C++类支持改进 ===")

    # 测试运算符重载
    try:
        test_operator_overloading()
    except Exception as e:
        print(f"✗ 运算符重载: {e}")

    # 测试静态方法
    try:
        test_static_method()
    except Exception as e:
        print(f"✗ 静态方法: {e}")  

    # 测试复杂类型
    try:
        test_复杂类型()
    except Exception as e:
        print(f"✗ 复杂类型: {e}")  