"""
compile_commands.json 功能的单元测试
"""

import unittest
import json
import os
import shutil
from l0n0lc import jit, set输出compile_commands
from l0n0lc.工具 import 全局上下文
from l0n0lc.cpp编译器 import Cpp编译器
from l0n0lc.编译管理器 import 编译管理器


class TestCompileCommands开关(unittest.TestCase):
    """测试 compile_commands.json 开关功能"""

    def setUp(self):
        """每个测试前的设置"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def tearDown(self):
        """每个测试后的清理"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def test_默认状态为False(self):
        """测试默认状态下开关为 False"""
        self.assertFalse(全局上下文.输出compile_commands)

    def test_set输出compile_commands启用(self):
        """测试启用开关"""
        set输出compile_commands(True)
        self.assertTrue(全局上下文.输出compile_commands)

    def test_set输出compile_commands禁用(self):
        """测试禁用开关"""
        set输出compile_commands(True)
        self.assertTrue(全局上下文.输出compile_commands)

        set输出compile_commands(False)
        self.assertFalse(全局上下文.输出compile_commands)


class TestCompileCommands生成(unittest.TestCase):
    """测试 compile_commands.json 生成功能"""

    def setUp(self):
        """每个测试前的设置"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def tearDown(self):
        """每个测试后的清理"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def test_默认不生成compile_commands_json(self):
        """测试默认情况下不生成 compile_commands.json"""
        # 清理可能存在的文件
        if os.path.exists("./l0n0lcoutput/compile_commands.json"):
            os.remove("./l0n0lcoutput/compile_commands.json")

        @jit(总是重编=True)
        def test_func():
            return 42

        # 调用函数触发编译
        test_func()

        # 验证文件不存在
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        self.assertFalse(os.path.exists(compile_commands_path))

    def test_启用后生成compile_commands_json(self):
        """测试启用后生成 compile_commands.json"""
        # 启用开关
        set输出compile_commands(True)

        @jit(总是重编=True)
        def test_func():
            return 42

        # 调用函数触发编译
        test_func()

        # 验证文件存在
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        self.assertTrue(os.path.exists(compile_commands_path))

    def test_禁用后不生成compile_commands_json(self):
        """测试禁用后不生成 compile_commands.json"""
        # 先启用再禁用
        set输出compile_commands(True)
        set输出compile_commands(False)

        # 清理可能存在的文件
        if os.path.exists("./l0n0lcoutput/compile_commands.json"):
            os.remove("./l0n0lcoutput/compile_commands.json")

        @jit(总是重编=True)
        def test_func():
            return 42

        # 调用函数触发编译
        test_func()

        # 验证文件不存在
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        self.assertFalse(os.path.exists(compile_commands_path))


class TestCompileCommands格式(unittest.TestCase):
    """测试 compile_commands.json 格式正确性"""

    def setUp(self):
        """每个测试前的设置"""
        # 重置全局状态并启用
        全局上下文.输出compile_commands = False
        set输出compile_commands(True)

    def tearDown(self):
        """每个测试后的清理"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def test_compile_commands_json格式正确(self):
        """测试生成的 compile_commands.json 格式正确"""

        @jit(总是重编=True)
        def test_func():
            return 42

        # 调用函数触发编译
        test_func()

        # 读取并解析文件
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        with open(compile_commands_path, 'r', encoding='utf-8') as f:
            entries = json.load(f)

        # 验证是列表
        self.assertIsInstance(entries, list)

        # 验证至少有一个条目
        self.assertGreater(len(entries), 0)

        # 验证每个条目包含必需的字段
        for entry in entries:
            self.assertIn("directory", entry)
            self.assertIn("command", entry)
            self.assertIn("file", entry)

            # 验证字段类型
            self.assertIsInstance(entry["directory"], str)
            self.assertIsInstance(entry["command"], str)
            self.assertIsInstance(entry["file"], str)

            # 验证 file 字段指向 .cpp 文件
            self.assertTrue(entry["file"].endswith('.cpp'),
                         f"file 字段应该指向 .cpp 文件，实际: {entry['file']}")

            # 验证 directory 是绝对路径
            self.assertTrue(os.path.isabs(entry["directory"]),
                         f"directory 应该是绝对路径，实际: {entry['directory']}")

            # 验证 file 是绝对路径
            self.assertTrue(os.path.isabs(entry["file"]),
                         f"file 应该是绝对路径，实际: {entry['file']}")

    def test_compile_commands_json包含编译命令(self):
        """测试 compile_commands.json 包含正确的编译命令"""

        @jit(总是重编=True)
        def test_func():
            return 42

        # 调用函数触发编译
        test_func()

        # 读取并解析文件
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        with open(compile_commands_path, 'r', encoding='utf-8') as f:
            entries = json.load(f)

        # 验证编译命令包含关键部分
        self.assertGreater(len(entries), 0)
        command = entries[0]["command"]

        # 验证命令包含编译器
        self.assertIn("c++", command.lower())

        # 验证命令包含输出选项
        self.assertIn("-o", command)

        # 验证命令包含共享库选项
        self.assertIn("--shared", command)
        self.assertIn("-fPIC", command)


class TestCompileCommands更新(unittest.TestCase):
    """测试 compile_commands.json 更新逻辑"""

    def setUp(self):
        """每个测试前的设置"""
        # 重置全局状态并启用
        全局上下文.输出compile_commands = False
        set输出compile_commands(True)

    def tearDown(self):
        """每个测试后的清理"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def test_重复编译更新而非重复添加(self):
        """测试重复编译时更新条目而非重复添加"""

        @jit(总是重编=True)
        def test_func():
            return 42

        # 第一次编译
        test_func()

        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        with open(compile_commands_path, 'r', encoding='utf-8') as f:
            entries_first = json.load(f)

        # 第二次编译（相同函数）
        test_func()

        with open(compile_commands_path, 'r', encoding='utf-8') as f:
            entries_second = json.load(f)

        # 条目数量应该相等（不会重复添加）
        self.assertEqual(len(entries_first), len(entries_second))

    def test_多个函数生成多条目(self):
        """测试多个函数生成多个条目"""

        @jit(总是重编=True)
        def func1():
            return 1

        @jit(总是重编=True)
        def func2():
            return 2

        # 编译两个函数
        func1()
        func2()

        # 读取编译数据库
        compile_commands_path = "./l0n0lcoutput/compile_commands.json"
        with open(compile_commands_path, 'r', encoding='utf-8') as f:
            entries = json.load(f)

        # 验证有多个条目（每个函数一个 .cpp 文件）
        self.assertGreater(len(entries), 1)

        # 验证每个条目指向不同的 .cpp 文件
        cpp_files = [entry["file"] for entry in entries]
        self.assertEqual(len(cpp_files), len(set(cpp_files)),
                        "每个条目应该指向唯一的 .cpp 文件")


class TestCompileCommands管理器(unittest.TestCase):
    """测试编译管理器的编译数据库更新功能"""

    def setUp(self):
        """每个测试前的设置"""
        # 重置全局状态并启用
        全局上下文.输出compile_commands = False
        set输出compile_commands(True)

    def tearDown(self):
        """每个测试后的清理"""
        # 重置全局状态
        全局上下文.输出compile_commands = False

    def test_管理器禁用时不生成(self):
        """测试编译管理器在禁用时不生成 compile_commands.json"""
        # 禁用开关
        set输出compile_commands(False)

        # 清理可能存在的文件
        if os.path.exists("./l0n0lcoutput/compile_commands.json"):
            os.remove("./l0n0lcoutput/compile_commands.json")

        编译器 = Cpp编译器(优化级别='O2')
        管理器 = 编译管理器("./l0n0lcoutput", 编译器)

        # 确保目录存在
        os.makedirs("./l0n0lcoutput", exist_ok=True)

        # 创建一个简单的测试源文件
        test_cpp = "./l0n0lcoutput/test.cpp"
        with open(test_cpp, 'w') as f:
            f.write('int main() { return 0; }')

        # 执行编译
        try:
            管理器.执行编译(
                [test_cpp],
                "./l0n0lcoutput/test.so",
                是否为可执行文件=False
            )
        except Exception:
            pass  # 编译可能失败，我们只关心是否生成了 compile_commands.json

        # 验证文件不存在
        self.assertFalse(os.path.exists("./l0n0lcoutput/compile_commands.json"))

    def test_管理器启用时生成(self):
        """测试编译管理器在启用时生成 compile_commands.json"""
        # 启用开关
        set输出compile_commands(True)

        编译器 = Cpp编译器(优化级别='O2')
        管理器 = 编译管理器("./l0n0lcoutput", 编译器)

        # 确保目录存在
        os.makedirs("./l0n0lcoutput", exist_ok=True)

        # 创建一个简单的测试源文件
        test_cpp = "./l0n0lcoutput/test.cpp"
        with open(test_cpp, 'w') as f:
            f.write('''
extern "C" int test_func() {
    return 42;
}
''')

        # 执行编译
        管理器.执行编译(
            [test_cpp],
            "./l0n0lcoutput/test.so",
            是否为可执行文件=False
        )

        # 验证文件存在
        self.assertTrue(os.path.exists("./l0n0lcoutput/compile_commands.json"))

    def test_编译失败时也生成compile_commands_json(self):
        """测试编译失败时也生成 compile_commands.json（用于错误诊断）"""
        # 启用开关
        set输出compile_commands(True)

        编译器 = Cpp编译器(优化级别='O2')
        管理器 = 编译管理器("./l0n0lcoutput", 编译器)

        # 确保目录存在
        os.makedirs("./l0n0lcoutput", exist_ok=True)

        # 创建一个有语法错误的测试源文件
        test_cpp = "./l0n0lcoutput/test_error.cpp"
        with open(test_cpp, 'w') as f:
            f.write('this is invalid c++ syntax {')

        # 尝试编译（应该失败）
        with self.assertRaises(RuntimeError):
            管理器.执行编译(
                [test_cpp],
                "./l0n0lcoutput/test_error.so",
                是否为可执行文件=False
            )

        # 即使编译失败，也应该生成 compile_commands.json
        self.assertTrue(os.path.exists("./l0n0lcoutput/compile_commands.json"))

        # 验证文件内容包含失败的编译命令
        with open("./l0n0lcoutput/compile_commands.json", 'r', encoding='utf-8') as f:
            entries = json.load(f)

        self.assertGreater(len(entries), 0)
        # 验证包含错误文件的条目
        error_file_entry = None
        for entry in entries:
            if "test_error.cpp" in entry["file"]:
                error_file_entry = entry
                break

        self.assertIsNotNone(error_file_entry, "应该包含错误文件的编译条目")
        self.assertIn("c++", error_file_entry["command"])


if __name__ == '__main__':
    unittest.main()
