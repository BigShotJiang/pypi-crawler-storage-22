# L3MON Installer
Auto-installer for L3mon on Termux and Debian-based systems.
