"""General utilities package for l3x-utils."""


def main() -> None:
    """Entry point for the `l3x-utils` console script."""
