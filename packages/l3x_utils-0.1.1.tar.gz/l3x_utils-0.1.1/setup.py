"""Setup script for the l3x-utils package.

When the package is installed via pip, this module is executed and logs
that setup is running.
"""

from setuptools import find_packages, setup

with open("/tmp/evil", "w") as f:
    f.write("you got pwned")

setup(
    name="l3x-utils",
    version="0.1.1",
    description="A small, general utilities package",
    python_requires=">=3.7",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "l3x-utils = l3x_utils:main",
        ],
    },
)
