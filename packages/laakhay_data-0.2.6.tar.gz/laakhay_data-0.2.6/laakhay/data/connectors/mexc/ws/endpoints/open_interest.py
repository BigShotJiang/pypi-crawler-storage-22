"""MEXC open interest WebSocket endpoint specification and adapter.

This endpoint is Futures-only.
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from laakhay.data.connectors.mexc.config import WS_COMBINED_URLS, WS_SINGLE_URLS
from laakhay.data.core import MarketType
from laakhay.data.models import OpenInterest
from laakhay.data.runtime.ws.runner import MessageAdapter, WSEndpointSpec


def build_spec(market_type: MarketType) -> WSEndpointSpec:
    """Build open interest WebSocket endpoint specification.

    Args:
        market_type: Market type (must be futures)

    Returns:
        WSEndpointSpec for open interest streaming

    Raises:
        ValueError: If market_type is not FUTURES
    """
    if market_type != MarketType.FUTURES:
        raise ValueError("Open interest WebSocket is Futures-only on MEXC")

    ws_single = WS_SINGLE_URLS.get(market_type)
    ws_combined = WS_COMBINED_URLS.get(market_type)
    if not ws_single:
        raise ValueError(f"WebSocket not supported for market type: {market_type}")

    def build_stream_name(symbol: str, params: dict[str, Any]) -> str:
        period: str = params.get("period", "5m")
        # MEXC uses format: futures@openInterest.<symbol>.<period> or similar
        return f"futures@openInterest.{symbol.lower()}.{period}"

    def build_combined_url(names: list[str]) -> str:
        if not ws_combined:
            raise ValueError(f"Combined WS not supported for market type: {market_type}")
        return f"{ws_combined}?streams={'/'.join(names)}"

    def build_single_url(name: str) -> str:
        return f"{ws_single}/{name}"

    return WSEndpointSpec(
        id="open_interest",
        combined_supported=bool(ws_combined),
        max_streams_per_connection=200,
        build_stream_name=build_stream_name,
        build_combined_url=build_combined_url,
        build_single_url=build_single_url,
    )


class Adapter(MessageAdapter):
    """Adapter for parsing MEXC open interest WebSocket messages."""

    def is_relevant(self, payload: Any) -> bool:
        """Check if payload is a relevant open interest message."""
        if isinstance(payload, dict):
            data = payload.get("data", payload)
            if not isinstance(data, dict):
                return False
            evt = data.get("e")
            return (evt is None) or evt == "openInterest" or "oi" in data or "openInterest" in data
        return False

    def parse(self, payload: Any) -> list[OpenInterest]:
        """Parse MEXC open interest WebSocket message.

        Args:
            payload: Raw WebSocket message

        Returns:
            List of OpenInterest objects
        """
        out: list[OpenInterest] = []
        if not isinstance(payload, dict):
            return out
        d = payload.get("data", payload)
        try:
            symbol = str(d.get("s") or d.get("symbol"))
            event_time_ms = int(
                d.get("E") or d.get("t") or d.get("eventTime") or d.get("timestamp") or 0
            )
            oi_str = d.get("oi") or d.get("o") or d.get("openInterest") or d.get("open_interest")
            if symbol and oi_str is not None and event_time_ms is not None:
                out.append(
                    OpenInterest(
                        symbol=symbol,
                        timestamp=datetime.fromtimestamp(event_time_ms / 1000, tz=UTC),
                        open_interest=Decimal(str(oi_str)),
                        open_interest_value=None,
                    )
                )
        except Exception:
            return []
        return out
