[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![Checked with pyright](https://microsoft.github.io/pyright/img/pyright_badge.svg)](https://microsoft.github.io/pyright/)
[![Actions status](https://github.com/lab-sync/lab-device-sdk/actions/workflows/ci.yaml/badge.svg?branch=main)](https://github.com/lab-sync/lab-device-sdk/actions)
[![Open in Dev Containers](https://img.shields.io/static/v1?label=Dev%20Containers&message=Open&color=blue)](https://vscode.dev/redirect?url=vscode://ms-vscode-remote.remote-containers/cloneInVolume?url=https://github.com/lab-sync/lab-device-sdk)
[![PyPI Version](https://img.shields.io/pypi/v/lab-device-sdk.svg)](https://pypi.org/project/lab-device-sdk/)
[![Downloads](https://pepy.tech/badge/lab-device-sdk)](https://pepy.tech/project/lab-device-sdk)
[![Python Versions](https://img.shields.io/pypi/pyversions/lab-device-sdk.svg)](https://pypi.org/project/lab-device-sdk/)
[![Codecov](https://codecov.io/gh/lab-sync/lab-device-sdk/branch/main/graph/badge.svg)](https://codecov.io/gh/lab-sync/lab-device-sdk)

## Usage

Create a device driver by inheriting from the `Device` class and using decorators:

```python
from lab_device_sdk import Device, command, settings, float_in, int_in, string_in, string_out, StringType

class MyDevice(Device):
    device_type_id = "f423f4b7-d389-42c5-bc44-eb3acee3154d"  # Use a UUID for your device type
    manufacturer = "My Company"
    model = "Model X"

    def __init__(self, device_id: str, configuration: str | None = None):
        super().__init__(device_id, configuration)

    @settings()
    @string_in("Host", "localhost", "Device host address")
    @string_in("Port", "8080", "Device port")
    @int_in("Timeout (sec)", 30, "Connection timeout")
    async def connect(self, host: str, port: str):
        # Connection logic here
        pass

    @command("Get Status", "Get device status")
    @string_out("Status")
    async def get_status(self) -> str:
        return "OK"

    @command("Set Temperature", "Set device temperature")
    @float_in("Temperature (C)", 25.0, "Device temperature")
    async def set_temperature(self, temperature: float):
        pass

    @command("Reset", "Reset the device")
    async def reset(self):
        pass

    @command("Set Mode", "Set device mode")
    @string_in("Mode", "Normal", "Device mode", options=["Normal", "Safe", "Test"], string_type=StringType.CONSTRAINED_TO_OPTIONS)
    async def set_mode(self, mode: str):
        pass
```

# Development
This project has a dev container. If you already have VS Code and Docker installed, you can click the badge above or [here](https://vscode.dev/redirect?url=vscode://ms-vscode-remote.remote-containers/cloneInVolume?url=https://github.com/lab-sync/lab-device-sdk) to get started. Clicking these links will cause VS Code to automatically install the Dev Containers extension if needed, clone the source code into a container volume, and spin up a dev container for use.

To publish a new version of the repository, you can run the `Publish` workflow manually and publish to the staging registry from any branch, and you can check the 'Publish to Primary' option when on `main` to publish to the primary registry and create a git tag.





## Updating from the template
This repository uses a copier template. To pull in the latest updates from the template, use the command:
`copier update --trust --conflict rej --defaults`
