"""Lab Device SDK for creating device drivers.

This minimal SDK provides the base classes and decorators needed to create
device drivers compatible with Device Hub. The SDK is designed to have
minimal dependencies while providing a clean API for driver developers.

Example usage:
    from lab_device_sdk import Device, command, settings, string_in, string_out

    class MyDevice(Device):
        device_type_id = "my-device-001"
        manufacturer = "ACME Corp"
        model = "Model X"

        @settings()
        @string_in("host", "localhost", "Device host address")
        async def connect(self, host: str):
            # Connection logic here
            pass

        @command("GetStatus", "Get device status")
        @string_out("status", "Current device status")
        async def get_status(self) -> str:
            return "OK"
"""
# pylint: disable=duplicate-code  # Docstring examples intentionally similar to device.py

from importlib.metadata import version

__version__ = version("lab-device-sdk")

from .decorators import bool_in
from .decorators import bool_out
from .decorators import command
from .decorators import float_in
from .decorators import float_out
from .decorators import int_in
from .decorators import int_out
from .decorators import settings
from .decorators import string_in
from .decorators import string_out
from .device import Device
from .device_category import DeviceCategory
from .types import BOOLEAN
from .types import FLOATING_POINT
from .types import INTEGER
from .types import PARAMETER_TYPES
from .types import STRING
from .types import StringType

__all__ = [
    "BOOLEAN",
    "FLOATING_POINT",
    "INTEGER",
    "PARAMETER_TYPES",
    "STRING",
    "Device",
    "DeviceCategory",
    "StringType",
    "bool_in",
    "bool_out",
    "command",
    "float_in",
    "float_out",
    "int_in",
    "int_out",
    "settings",
    "string_in",
    "string_out",
]
