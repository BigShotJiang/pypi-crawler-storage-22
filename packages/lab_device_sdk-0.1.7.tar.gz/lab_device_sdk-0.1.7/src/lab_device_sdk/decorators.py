"""Simple metadata decorators for device commands and parameters.

These decorators only add metadata attributes to methods. The main project handles the complex parameter object creation and validation.
"""
# ruff: noqa: UP047, PLR0913

from collections.abc import Callable
from typing import Any
from typing import TypeVar

from .types import StringType

# Type variable for decorated functions
F = TypeVar("F", bound=Callable[..., Any])


def command(name: str, description: str, category: str = "Main") -> Callable[[F], F]:
    """Mark a method as a device command with category.

    Args:
        name: Command name (user-friendly)
        description: Command description
        category: Command category for grouping (default: "Main")

    Example:
        @command("Reset", "Reset the device", category="Configuration")
        async def reset_device(self):
            pass
    """

    def decorator(func: F) -> F:
        func._is_command = True  # type: ignore[attr-defined] # noqa: SLF001
        func._cmd_name = name  # type: ignore[attr-defined] # noqa: SLF001
        func._cmd_desc = description  # type: ignore[attr-defined] # noqa: SLF001
        func._cmd_category = category  # type: ignore[attr-defined] # noqa: SLF001
        return func

    return decorator


def settings() -> Callable[[F], F]:
    """Mark a method as a settings method (typically connect).

    Settings methods are used for device connection/configuration.
    They should not have output parameters.

    Example:
        @settings()
        @string_in("host", "localhost", "Device host")
        async def connect(self, host: str):
            pass
    """

    def decorator(func: F) -> F:
        func._is_settings = True  # type: ignore[attr-defined] # noqa: SLF001
        return func

    return decorator


def _add_parameter(func: F, param_info: dict[str, Any], direction: str) -> F:
    """Add parameter metadata to a function."""
    attr_name = f"_params_{direction}"
    if not hasattr(func, attr_name):
        setattr(func, attr_name, [])
    getattr(func, attr_name).insert(0, param_info)  # Insert at beginning to maintain order
    return func


# Input parameter decorators
def string_in(
    name: str,
    default_value: str = "",
    description: str = "",
    maps_to: str | None = None,
    options: list[str] | None = None,
    *,
    dynamic_options: bool = False,
    string_type: StringType = StringType.UNCONSTRAINED,
    type_details: str = "",
) -> Callable[[F], F]:
    """Add a string input parameter to a command or settings method.

    Args:
        name: The parameter name
        default_value: Default value for the parameter
        description: Description of the parameter
        maps_to: Name of the method parameter this maps to
        options: List of valid options (for ConstrainedToOptions type)
        dynamic_options: Whether options are dynamically generated
        string_type: The type of string parameter (using StringType enum)
        type_details: Additional type details (e.g., file filter like "*.txt")
    """

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "string",
            "default": default_value,
            "description": description,
            "maps_to": maps_to,
            "options": options,
            "dynamic_options": dynamic_options,
            "string_type": string_type.value if hasattr(string_type, "value") else string_type,
            "type_details": type_details,
        }
        return _add_parameter(func, param_info, "in")

    return decorator


def int_in(
    name: str,
    default_value: int = 0,
    description: str = "",
    maps_to: str | None = None,
    min_value: int | None = None,
    max_value: int | None = None,
) -> Callable[[F], F]:
    """Add an integer input parameter to a command or settings method."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "integer",
            "default": default_value,
            "description": description,
            "maps_to": maps_to,
            "min_value": min_value,
            "max_value": max_value,
        }
        return _add_parameter(func, param_info, "in")

    return decorator


def float_in(
    name: str,
    default_value: float = 0.0,
    description: str = "",
    maps_to: str | None = None,
    min_value: float | None = None,
    max_value: float | None = None,
) -> Callable[[F], F]:
    """Add a floating point input parameter to a command or settings method."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "floating_point",
            "default": default_value,
            "description": description,
            "maps_to": maps_to,
            "min_value": min_value,
            "max_value": max_value,
        }
        return _add_parameter(func, param_info, "in")

    return decorator


def bool_in(
    name: str,
    *,
    default_value: bool = False,
    description: str = "",
    maps_to: str | None = None,
) -> Callable[[F], F]:
    """Add a boolean input parameter to a command or settings method."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "boolean",
            "default": default_value,
            "description": description,
            "maps_to": maps_to,
        }
        return _add_parameter(func, param_info, "in")

    return decorator


# Output parameter decorators
def string_out(name: str, description: str = "") -> Callable[[F], F]:
    """Add a string output parameter to a command."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "string",
            "description": description,
        }
        return _add_parameter(func, param_info, "out")

    return decorator


def int_out(name: str, description: str = "") -> Callable[[F], F]:
    """Add an integer output parameter to a command."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "integer",
            "description": description,
        }
        return _add_parameter(func, param_info, "out")

    return decorator


def float_out(name: str, description: str = "") -> Callable[[F], F]:
    """Add a floating point output parameter to a command."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "floating_point",
            "description": description,
        }
        return _add_parameter(func, param_info, "out")

    return decorator


def bool_out(name: str, description: str = "") -> Callable[[F], F]:
    """Add a boolean output parameter to a command."""

    def decorator(func: F) -> F:
        param_info = {
            "name": name,
            "type": "boolean",
            "description": description,
        }
        return _add_parameter(func, param_info, "out")

    return decorator
