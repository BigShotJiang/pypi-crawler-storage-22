"""Minimal Device base class for SDK."""
# pylint: disable=duplicate-code  # Docstring examples intentionally similar to __init__.py


class Device:
    """Base class for device drivers.

    This minimal base class provides just enough structure for driver developers
    to create compatible device drivers without heavy dependencies.

    Subclasses must define:
        - device_type_id: Unique identifier for the device type, usually a UUID string
        - manufacturer: Device manufacturer name
        - model: Device model name

    Example:
        class MyDevice(Device):
            device_type_id = "f423f4b7-d389-42c5-bc44-eb3acee3154d"
            manufacturer = "ACME Corp"
            model = "Model X"

            @settings()
            @string_in("host", "localhost", "Device host")
            async def connect(self, host: str):
                # Connection logic
                pass

            @command("GetStatus", "Get device status")
            @string_out("status", "Current device status")
            async def get_status(self) -> str:
                return "OK"
    """

    # These must be defined by subclasses
    device_type_id: str | None = None
    manufacturer: str | None = None
    model: str | None = None

    def __init__(self, device_id: str, configuration: str | None = None):
        """Initialize device with ID and optional configuration.

        Args:
            device_id: Unique identifier for this device instance
            configuration: Optional configuration string (implementation-specific)
        """
        super().__init__()
        self.device_id = device_id
        self.configuration = configuration

        # Validate required class attributes
        if not all([self.device_type_id, self.manufacturer, self.model]):
            missing_attrs = "device_type_id, manufacturer, and model"
            raise ValueError(f"{self.__class__.__name__} must define {missing_attrs}")  # noqa: TRY003

    async def disconnect(self) -> None:
        """Disconnect from the device and cleanup resources.

        Override this method to implement device-specific disconnection
        logic.
        This method is called when the device is being disconnected or
        cleaned up.

        Example:
            async def disconnect(self) -> None:
                await self.client.close()
                logger.info("Device disconnected")
        """
        return  # Default implementation does nothing

    @staticmethod
    def get_configurations() -> list[str]:
        """Return device configuration options.

        This method can be overridden to provide custom configuration options. By default, returns an empty list.
        """
        return []
