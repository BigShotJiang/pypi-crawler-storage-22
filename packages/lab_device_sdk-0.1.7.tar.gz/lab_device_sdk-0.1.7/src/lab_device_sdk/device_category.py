"""Device category enumeration for SDK drivers."""

from enum import Enum


class DeviceCategory(str, Enum):
    """Categories of laboratory devices supported by the system.

    Use these categories when defining your device driver to help organize
    and filter devices in the UI.

    Example:
        class MyShaker(Device):
            device_type_id = "my-shaker-001"
            manufacturer = "ACME"
            model = "Shaker Pro"
            category = DeviceCategory.SHAKING
    """

    SEALING_PEELING = "sealing_peeling"
    CAPPING_DECAPPING = "capping_decapping"
    LABELING = "labeling"
    PCR = "pcr"
    LIQUID_HANDLING = "liquid_handling"
    BARCODE_READING = "barcode_reading"
    LABEL_PRINTING = "label_printing"
    PLATE_HANDLING = "plate_handling"
    MOBILE_ROBOT = "mobile_robot"
    TRANSPORT = "transport"
    STORAGE = "storage"
    SHAKING = "shaking"
    DETECTION = "detection"
    SENSOR = "sensor"
    ACTUATOR = "actuator"
    MISC = "misc"
