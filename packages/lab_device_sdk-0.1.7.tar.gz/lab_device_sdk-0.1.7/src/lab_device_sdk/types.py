"""Basic type definitions for the SDK.

These are kept minimal to avoid dependencies.
"""

from enum import StrEnum

# Parameter type constants
STRING = "string"
INTEGER = "integer"
FLOATING_POINT = "floating_point"
BOOLEAN = "boolean"

# Parameter types list for validation
PARAMETER_TYPES = [STRING, INTEGER, FLOATING_POINT, BOOLEAN]


class StringType(StrEnum):
    """Enumeration of string parameter types.

    This matches the C# StringType enum in Parameter.cs for serialization compatibility.
    """

    UNCONSTRAINED = "Unconstrained"
    CONSTRAINED_TO_OPTIONS = "ConstrainedToOptions"
    FILE_PATH = "FilePath"
    FOLDER_PATH = "FolderPath"
    JSON = "Json"
    XML = "XML"
    CSV = "CSV"
    CODE = "Code"
