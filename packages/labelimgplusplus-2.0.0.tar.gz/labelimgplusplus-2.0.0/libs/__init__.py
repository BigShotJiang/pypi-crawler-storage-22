__version_info__ = ('2', '0', '0a')
__version__ = '.'.join(__version_info__)  # 2.0.0a
