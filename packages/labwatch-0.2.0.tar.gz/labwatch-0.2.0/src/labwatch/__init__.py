"""labwatch - General-purpose homelab monitoring CLI."""

__version__ = "0.2.0"
