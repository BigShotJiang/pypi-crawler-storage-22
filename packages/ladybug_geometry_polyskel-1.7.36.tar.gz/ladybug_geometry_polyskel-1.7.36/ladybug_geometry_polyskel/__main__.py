from ladybug_geometry_polyskel.cli import geometry

if __name__ == '__main__':
    geometry()
