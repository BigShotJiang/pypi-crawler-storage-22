# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRC16Kermit.py."""

from ..vendor.PyCRC.CRC16Kermit import CRC16Kermit

__all__ = ["CRC16Kermit"]
