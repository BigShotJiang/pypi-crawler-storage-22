# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRCCCITT.py."""

from ..vendor.PyCRC.CRCCCITT import CRCCCITT

__all__ = ["CRCCCITT"]
