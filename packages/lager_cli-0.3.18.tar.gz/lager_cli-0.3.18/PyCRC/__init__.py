# -*- coding: utf-8 -*-
"""Backward compatibility stub - PyCRC has moved to cli/vendor/PyCRC/."""

# Re-export from new location
from ..vendor.PyCRC import __author__, __email__, __version__

__all__ = ["__author__", "__email__", "__version__"]
