"""
Battery CLI utilities package.

Contains TUI and WebSocket client implementations for battery monitoring.
The main CLI command is located at cli/commands/power/battery.py.
"""
