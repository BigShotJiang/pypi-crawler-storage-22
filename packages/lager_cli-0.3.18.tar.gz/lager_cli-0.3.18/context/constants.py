"""
    cli.context.constants

    Constants used across the context module.
"""

# Default region for box location (used for display purposes only)
DEFAULT_REGION = 'us-west-1'
