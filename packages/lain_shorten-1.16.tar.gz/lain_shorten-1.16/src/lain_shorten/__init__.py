from .shorten import shorten_url

__all__ = ["shorten_url"]
