"""
command-line tool to deobfuscate & download manga chapters from multiple official Japanese providers.
"""

__version__ = "0.1.10"
__description__ = "command-line tool to deobfuscate & download manga chapters from multiple official Japanese providers."
__author__ = "syvixor"
__author_email__ = "syvixor@proton.me"
__license__ = "MIT"