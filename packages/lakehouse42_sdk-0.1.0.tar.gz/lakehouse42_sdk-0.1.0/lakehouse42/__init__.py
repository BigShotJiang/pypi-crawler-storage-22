"""
Lakehouse42 Python SDK.

A Python client library for interacting with the Lakehouse42 API.

Usage:
    from lakehouse42 import LakehouseClient

    # Async usage
    async with LakehouseClient(api_key="lh_xxx") as client:
        doc = await client.documents.create(
            title="My Document",
            content="Document content..."
        )

    # Sync usage
    from lakehouse42 import LakehouseClientSync

    client = LakehouseClientSync(api_key="lh_xxx")
    doc = client.documents.create(
        title="My Document",
        content="Document content..."
    )
"""

from lakehouse42.client import LakehouseClient, LakehouseClientSync
from lakehouse42.exceptions import (
    LakehouseError,
    AuthenticationError,
    RateLimitError,
    NotFoundError,
    ValidationError,
    APIError,
    APIConnectionError,
    APITimeoutError,
    ConflictError,
    QuotaExceededError,
    PermissionError,
    InternalServerError,
)
from lakehouse42.types import (
    # Documents
    Document,
    DocumentDetail,
    DocumentList,
    DocumentMetadata,
    DocumentStatus,
    Chunk,
    # Search
    SearchResult,
    SearchResults,
    SearchMode,
    SearchFilter,
    StreamSearchEvent,
    StreamSearchSource,
    # Chat
    ChatCompletion,
    ChatCompletionChunk,
    ChatChoice,
    ChatChoiceChunk,
    ChatMessage,
    ChatDelta,
    MessageRole,
    Usage,
    Source,
    # Collections
    Collection,
    CollectionList,
    RetrievalConfig,
    RetrievalWeights,
    # Entities
    Entity,
    EntityRelationship,
    EntityType,
    KnowledgeGraph,
    KnowledgeGraphStats,
    # Time Travel
    SnapshotInfo,
    SnapshotList,
    TimeTravelQueryResult,
    SchemaChange,
    DiffResult,
    # Batch Upload
    BatchUploadedDocument,
    BatchUploadResult,
    # Discovery
    EndpointInfo,
    RateLimitTier,
    AuthenticationInfo,
    DocumentationInfo,
    DiscoveryResponse,
)
from lakehouse42.resources.time_travel import TimeTravelResource, TimeTravelResourceSync

__version__ = "0.1.0"
__all__ = [
    # Client
    "LakehouseClient",
    "LakehouseClientSync",
    # Exceptions
    "LakehouseError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    "ValidationError",
    "APIError",
    "APIConnectionError",
    "APITimeoutError",
    "ConflictError",
    "QuotaExceededError",
    "PermissionError",
    "InternalServerError",
    # Document Types
    "Document",
    "DocumentDetail",
    "DocumentList",
    "DocumentMetadata",
    "DocumentStatus",
    "Chunk",
    # Search Types
    "SearchResult",
    "SearchResults",
    "SearchMode",
    "SearchFilter",
    "StreamSearchEvent",
    "StreamSearchSource",
    # Chat Types
    "ChatCompletion",
    "ChatCompletionChunk",
    "ChatChoice",
    "ChatChoiceChunk",
    "ChatMessage",
    "ChatDelta",
    "MessageRole",
    "Usage",
    "Source",
    # Collection Types
    "Collection",
    "CollectionList",
    "RetrievalConfig",
    "RetrievalWeights",
    # Entity Types
    "Entity",
    "EntityRelationship",
    "EntityType",
    "KnowledgeGraph",
    "KnowledgeGraphStats",
    # Time Travel Types
    "TimeTravelResource",
    "TimeTravelResourceSync",
    "SnapshotInfo",
    "SnapshotList",
    "TimeTravelQueryResult",
    "SchemaChange",
    "DiffResult",
    # Batch Upload Types
    "BatchUploadedDocument",
    "BatchUploadResult",
    # Discovery Types
    "EndpointInfo",
    "RateLimitTier",
    "AuthenticationInfo",
    "DocumentationInfo",
    "DiscoveryResponse",
]
