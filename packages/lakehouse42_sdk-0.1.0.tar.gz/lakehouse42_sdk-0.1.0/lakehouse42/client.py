"""
Lakehouse42 client implementation.

Provides both async (LakehouseClient) and sync (LakehouseClientSync) clients.
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from typing import Any, Dict, Optional, TYPE_CHECKING

import httpx

from lakehouse42.exceptions import (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    InternalServerError,
    raise_for_status,
)

if TYPE_CHECKING:
    from lakehouse42.resources.documents import DocumentsResource, DocumentsResourceSync
    from lakehouse42.resources.search import SearchResource, SearchResourceSync
    from lakehouse42.resources.chat import ChatResource, ChatResourceSync
    from lakehouse42.resources.collections import CollectionsResource, CollectionsResourceSync
    from lakehouse42.resources.entities import EntitiesResource, EntitiesResourceSync
    from lakehouse42.resources.time_travel import TimeTravelResource, TimeTravelResourceSync
    from lakehouse42.types import DiscoveryResponse


DEFAULT_BASE_URL = "https://api.lakehouse42.com/v1"
DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_MIN_WAIT = 0.5
DEFAULT_RETRY_MAX_WAIT = 30.0


def _calculate_retry_delay(
    attempt: int,
    min_wait: float = DEFAULT_RETRY_MIN_WAIT,
    max_wait: float = DEFAULT_RETRY_MAX_WAIT,
) -> float:
    """Calculate retry delay with exponential backoff and jitter."""
    delay = min(min_wait * (2 ** attempt), max_wait)
    # Add jitter (0-25% of delay)
    jitter = delay * random.uniform(0, 0.25)
    return delay + jitter


def _should_retry(status_code: int, attempt: int, max_retries: int) -> bool:
    """Determine if a request should be retried."""
    if attempt >= max_retries:
        return False
    # Retry on rate limits and server errors
    return status_code in (429, 500, 502, 503, 504)


class LakehouseClient:
    """
    Async Python SDK for the Lakehouse42 API.

    Usage:
        async with LakehouseClient(api_key="lh_xxx") as client:
            # Create a document
            doc = await client.documents.create(
                title="My Document",
                content="Document content..."
            )

            # Search
            results = await client.search.query("What is machine learning?")

            # Chat with RAG
            response = await client.chat.completions.create(
                messages=[{"role": "user", "content": "Summarize Q1 report"}]
            )

    Args:
        api_key: Your Lakehouse42 API key (starts with 'lh_')
        base_url: Base URL for the API (default: https://api.lakehouse42.com/v1)
        timeout: Request timeout in seconds (default: 60)
        max_retries: Maximum number of retries for failed requests (default: 2)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._default_headers(),
            timeout=httpx.Timeout(timeout),
        )

        # Initialize resources lazily to avoid circular imports
        self._documents: Optional[DocumentsResource] = None
        self._search: Optional[SearchResource] = None
        self._chat: Optional[ChatResource] = None
        self._collections: Optional[CollectionsResource] = None
        self._entities: Optional[EntitiesResource] = None
        self._time_travel: Optional[TimeTravelResource] = None

    def _default_headers(self) -> Dict[str, str]:
        """Get default headers for requests."""
        from lakehouse42 import __version__

        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"lakehouse42-python/{__version__}",
        }

    @property
    def documents(self) -> "DocumentsResource":
        """Documents API resource."""
        if self._documents is None:
            from lakehouse42.resources.documents import DocumentsResource

            self._documents = DocumentsResource(self)
        return self._documents

    @property
    def search(self) -> "SearchResource":
        """Search API resource."""
        if self._search is None:
            from lakehouse42.resources.search import SearchResource

            self._search = SearchResource(self)
        return self._search

    @property
    def chat(self) -> "ChatResource":
        """Chat API resource."""
        if self._chat is None:
            from lakehouse42.resources.chat import ChatResource

            self._chat = ChatResource(self)
        return self._chat

    @property
    def collections(self) -> "CollectionsResource":
        """Collections API resource."""
        if self._collections is None:
            from lakehouse42.resources.collections import CollectionsResource

            self._collections = CollectionsResource(self)
        return self._collections

    @property
    def entities(self) -> "EntitiesResource":
        """Entities/Knowledge Graph API resource."""
        if self._entities is None:
            from lakehouse42.resources.entities import EntitiesResource

            self._entities = EntitiesResource(self)
        return self._entities

    @property
    def time_travel(self) -> "TimeTravelResource":
        """Time Travel API resource for querying historical data."""
        if self._time_travel is None:
            from lakehouse42.resources.time_travel import TimeTravelResource

            self._time_travel = TimeTravelResource(self)
        return self._time_travel

    async def discover(self) -> "DiscoveryResponse":
        """
        Discover API capabilities and endpoints.

        This endpoint is public and does not require authentication.
        It returns information about available endpoints, authentication
        requirements, rate limits, and documentation links.

        Returns:
            DiscoveryResponse with API information

        Example:
            async with LakehouseClient(api_key="lh_xxx") as client:
                info = await client.discover()
                print(f"API: {info.name} v{info.version}")
                print(f"Endpoints: {len(info.endpoints)}")
                for endpoint in info.endpoints:
                    print(f"  {endpoint.method} {endpoint.path}")
        """
        from lakehouse42.types import DiscoveryResponse

        # Discovery endpoint doesn't require auth, but we use _request for consistency
        # The base URL is /v1, so we need to call the root
        data = await self._client.get(
            self.base_url.replace("/v1", "") + "/api/v1",
            headers={"User-Agent": self._default_headers()["User-Agent"]},
        )

        if data.status_code >= 400:
            # Handle error case
            from lakehouse42.exceptions import raise_for_status

            try:
                error_data = data.json()
            except json.JSONDecodeError:
                error_data = {"error": {"message": data.text}}
            raise_for_status(data.status_code, error_data)

        return DiscoveryResponse(**data.json())

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Make an API request.

        Args:
            method: HTTP method
            path: API path (relative to base_url)
            json_data: JSON body data
            params: Query parameters
            files: Files for multipart upload
            data: Form data
            headers: Additional headers
            timeout: Request timeout override

        Returns:
            Parsed JSON response

        Raises:
            LakehouseError: On API errors
            APIConnectionError: On network errors
            APITimeoutError: On timeout
        """
        url = path if path.startswith("http") else f"{self.base_url}{path}"

        request_headers = self._default_headers()
        if headers:
            request_headers.update(headers)

        # Remove Content-Type for file uploads
        if files:
            del request_headers["Content-Type"]

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": request_headers,
        }

        if json_data is not None:
            kwargs["json"] = json_data
        if params is not None:
            # Filter out None values
            kwargs["params"] = {k: v for k, v in params.items() if v is not None}
        if files is not None:
            kwargs["files"] = files
        if data is not None:
            kwargs["data"] = data
        if timeout is not None:
            kwargs["timeout"] = timeout

        last_error: Optional[Exception] = None
        last_status_code: Optional[int] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.request(**kwargs)

                if response.status_code >= 400:
                    last_status_code = response.status_code

                    # Check if we should retry
                    if _should_retry(response.status_code, attempt, self.max_retries):
                        retry_after = response.headers.get("retry-after")
                        if retry_after:
                            delay = float(retry_after)
                        else:
                            delay = _calculate_retry_delay(attempt)
                        await asyncio.sleep(delay)
                        continue

                    try:
                        error_data = response.json()
                    except json.JSONDecodeError:
                        error_data = {"error": {"message": response.text}}
                    raise_for_status(response.status_code, error_data)

                if response.status_code == 204:
                    return {}

                # Handle wrapped response format
                data = response.json()
                if isinstance(data, dict) and "data" in data:
                    return data["data"]
                return data

            except httpx.TimeoutException as e:
                last_error = APITimeoutError(
                    message=f"Request timed out after {timeout or self.timeout}s",
                    original_error=e,
                )
                # Don't retry timeouts by default
                break

            except httpx.ConnectError as e:
                last_error = APIConnectionError(
                    message=f"Failed to connect to {url}",
                    original_error=e,
                )
                if attempt < self.max_retries:
                    delay = _calculate_retry_delay(attempt)
                    await asyncio.sleep(delay)
                    continue
                break

            except (RateLimitError, InternalServerError) as e:
                last_error = e
                if attempt < self.max_retries:
                    retry_after = getattr(e, "retry_after", None)
                    if retry_after:
                        delay = float(retry_after)
                    else:
                        delay = _calculate_retry_delay(attempt)
                    await asyncio.sleep(delay)
                    continue
                raise

            except httpx.HTTPStatusError:
                # Already handled above
                raise

        if last_error:
            raise last_error

        raise APIConnectionError(message="Request failed with unknown error")

    async def _stream(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ):
        """
        Make a streaming API request.

        Yields:
            Lines from the SSE response
        """
        url = path if path.startswith("http") else f"{self.base_url}{path}"

        request_headers = self._default_headers()

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": request_headers,
        }

        if json_data is not None:
            kwargs["json"] = json_data
        if params is not None:
            kwargs["params"] = {k: v for k, v in params.items() if v is not None}
        if timeout is not None:
            kwargs["timeout"] = timeout

        try:
            async with self._client.stream(**kwargs) as response:
                if response.status_code >= 400:
                    content = await response.aread()
                    try:
                        error_data = json.loads(content)
                    except json.JSONDecodeError:
                        error_data = {"error": {"message": content.decode()}}
                    raise_for_status(response.status_code, error_data)

                async for line in response.aiter_lines():
                    if line:
                        yield line

        except httpx.TimeoutException as e:
            raise APITimeoutError(
                message=f"Stream timed out after {timeout or self.timeout}s",
                original_error=e,
            )
        except httpx.ConnectError as e:
            raise APIConnectionError(
                message=f"Failed to connect to {url}",
                original_error=e,
            )

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._client.aclose()

    async def __aenter__(self) -> "LakehouseClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()


class LakehouseClientSync:
    """
    Sync Python SDK for the Lakehouse42 API.

    This is a synchronous wrapper around the async client for convenience.

    Usage:
        client = LakehouseClientSync(api_key="lh_xxx")

        # Create a document
        doc = client.documents.create(
            title="My Document",
            content="Document content..."
        )

        # Search
        results = client.search.query("What is machine learning?")

        # Chat with RAG
        response = client.chat.completions.create(
            messages=[{"role": "user", "content": "Summarize Q1 report"}]
        )

        client.close()

    Args:
        api_key: Your Lakehouse42 API key (starts with 'lh_')
        base_url: Base URL for the API (default: https://api.lakehouse42.com/v1)
        timeout: Request timeout in seconds (default: 60)
        max_retries: Maximum number of retries for failed requests (default: 2)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._default_headers(),
            timeout=httpx.Timeout(timeout),
        )

        # Initialize resources lazily
        self._documents: Optional[DocumentsResourceSync] = None
        self._search: Optional[SearchResourceSync] = None
        self._chat: Optional[ChatResourceSync] = None
        self._collections: Optional[CollectionsResourceSync] = None
        self._entities: Optional[EntitiesResourceSync] = None
        self._time_travel: Optional[TimeTravelResourceSync] = None

    def _default_headers(self) -> Dict[str, str]:
        """Get default headers for requests."""
        from lakehouse42 import __version__

        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"lakehouse42-python/{__version__}",
        }

    @property
    def documents(self) -> "DocumentsResourceSync":
        """Documents API resource."""
        if self._documents is None:
            from lakehouse42.resources.documents import DocumentsResourceSync

            self._documents = DocumentsResourceSync(self)
        return self._documents

    @property
    def search(self) -> "SearchResourceSync":
        """Search API resource."""
        if self._search is None:
            from lakehouse42.resources.search import SearchResourceSync

            self._search = SearchResourceSync(self)
        return self._search

    @property
    def chat(self) -> "ChatResourceSync":
        """Chat API resource."""
        if self._chat is None:
            from lakehouse42.resources.chat import ChatResourceSync

            self._chat = ChatResourceSync(self)
        return self._chat

    @property
    def collections(self) -> "CollectionsResourceSync":
        """Collections API resource."""
        if self._collections is None:
            from lakehouse42.resources.collections import CollectionsResourceSync

            self._collections = CollectionsResourceSync(self)
        return self._collections

    @property
    def entities(self) -> "EntitiesResourceSync":
        """Entities/Knowledge Graph API resource."""
        if self._entities is None:
            from lakehouse42.resources.entities import EntitiesResourceSync

            self._entities = EntitiesResourceSync(self)
        return self._entities

    @property
    def time_travel(self) -> "TimeTravelResourceSync":
        """Time Travel API resource for querying historical data."""
        if self._time_travel is None:
            from lakehouse42.resources.time_travel import TimeTravelResourceSync

            self._time_travel = TimeTravelResourceSync(self)
        return self._time_travel

    def discover(self) -> "DiscoveryResponse":
        """
        Discover API capabilities and endpoints.

        This endpoint is public and does not require authentication.
        It returns information about available endpoints, authentication
        requirements, rate limits, and documentation links.

        Returns:
            DiscoveryResponse with API information

        Example:
            client = LakehouseClientSync(api_key="lh_xxx")
            info = client.discover()
            print(f"API: {info.name} v{info.version}")
            print(f"Endpoints: {len(info.endpoints)}")
        """
        from lakehouse42.types import DiscoveryResponse

        # Discovery endpoint doesn't require auth
        data = self._client.get(
            self.base_url.replace("/v1", "") + "/api/v1",
            headers={"User-Agent": self._default_headers()["User-Agent"]},
        )

        if data.status_code >= 400:
            from lakehouse42.exceptions import raise_for_status

            try:
                error_data = data.json()
            except json.JSONDecodeError:
                error_data = {"error": {"message": data.text}}
            raise_for_status(data.status_code, error_data)

        return DiscoveryResponse(**data.json())

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Make an API request."""
        url = path if path.startswith("http") else f"{self.base_url}{path}"

        request_headers = self._default_headers()
        if headers:
            request_headers.update(headers)

        if files:
            del request_headers["Content-Type"]

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": request_headers,
        }

        if json_data is not None:
            kwargs["json"] = json_data
        if params is not None:
            kwargs["params"] = {k: v for k, v in params.items() if v is not None}
        if files is not None:
            kwargs["files"] = files
        if data is not None:
            kwargs["data"] = data
        if timeout is not None:
            kwargs["timeout"] = timeout

        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(**kwargs)

                if response.status_code >= 400:
                    # Check if we should retry
                    if _should_retry(response.status_code, attempt, self.max_retries):
                        retry_after = response.headers.get("retry-after")
                        if retry_after:
                            delay = float(retry_after)
                        else:
                            delay = _calculate_retry_delay(attempt)
                        time.sleep(delay)
                        continue

                    try:
                        error_data = response.json()
                    except json.JSONDecodeError:
                        error_data = {"error": {"message": response.text}}
                    raise_for_status(response.status_code, error_data)

                if response.status_code == 204:
                    return {}

                # Handle wrapped response format
                data_resp = response.json()
                if isinstance(data_resp, dict) and "data" in data_resp:
                    return data_resp["data"]
                return data_resp

            except httpx.TimeoutException as e:
                last_error = APITimeoutError(
                    message=f"Request timed out after {timeout or self.timeout}s",
                    original_error=e,
                )
                break

            except httpx.ConnectError as e:
                last_error = APIConnectionError(
                    message=f"Failed to connect to {url}",
                    original_error=e,
                )
                if attempt < self.max_retries:
                    delay = _calculate_retry_delay(attempt)
                    time.sleep(delay)
                    continue
                break

            except (RateLimitError, InternalServerError) as e:
                last_error = e
                if attempt < self.max_retries:
                    retry_after = getattr(e, "retry_after", None)
                    if retry_after:
                        delay = float(retry_after)
                    else:
                        delay = _calculate_retry_delay(attempt)
                    time.sleep(delay)
                    continue
                raise

        if last_error:
            raise last_error

        raise APIConnectionError(message="Request failed with unknown error")

    def _stream(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ):
        """Make a streaming API request."""
        url = path if path.startswith("http") else f"{self.base_url}{path}"

        request_headers = self._default_headers()

        kwargs: Dict[str, Any] = {
            "method": method,
            "url": url,
            "headers": request_headers,
        }

        if json_data is not None:
            kwargs["json"] = json_data
        if params is not None:
            kwargs["params"] = {k: v for k, v in params.items() if v is not None}
        if timeout is not None:
            kwargs["timeout"] = timeout

        try:
            with self._client.stream(**kwargs) as response:
                if response.status_code >= 400:
                    content = response.read()
                    try:
                        error_data = json.loads(content)
                    except json.JSONDecodeError:
                        error_data = {"error": {"message": content.decode()}}
                    raise_for_status(response.status_code, error_data)

                for line in response.iter_lines():
                    if line:
                        yield line

        except httpx.TimeoutException as e:
            raise APITimeoutError(
                message=f"Stream timed out after {timeout or self.timeout}s",
                original_error=e,
            )
        except httpx.ConnectError as e:
            raise APIConnectionError(
                message=f"Failed to connect to {url}",
                original_error=e,
            )

    def close(self) -> None:
        """Close the client and release resources."""
        self._client.close()

    def __enter__(self) -> "LakehouseClientSync":
        return self

    def __exit__(self, *args) -> None:
        self.close()
