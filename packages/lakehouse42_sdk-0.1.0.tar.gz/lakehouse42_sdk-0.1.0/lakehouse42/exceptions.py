"""
Lakehouse42 SDK exceptions.

All exceptions raised by the SDK inherit from LakehouseError.
"""

from typing import Optional, Dict, Any


class LakehouseError(Exception):
    """Base exception for all Lakehouse42 SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        error_type: Optional[str] = None,
        error_code: Optional[str] = None,
        param: Optional[str] = None,
        response: Optional[Dict[str, Any]] = None,
    ):
        self.message = message
        self.status_code = status_code
        self.error_type = error_type
        self.error_code = error_code
        self.param = param
        self.response = response
        super().__init__(message)

    def __str__(self) -> str:
        parts = [self.message]
        if self.status_code:
            parts.insert(0, f"[{self.status_code}]")
        if self.error_type:
            parts.insert(0, f"{self.error_type}:")
        return " ".join(parts)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"status_code={self.status_code!r}, "
            f"error_type={self.error_type!r}"
            f")"
        )


class APIError(LakehouseError):
    """
    Raised when the API returns an error response.

    This is the base class for all API-related errors and includes
    details from the API response.
    """

    pass


class AuthenticationError(APIError):
    """
    Raised when authentication fails.

    This occurs when:
    - API key is missing
    - API key is invalid
    - API key has expired
    - API key lacks required scopes
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        **kwargs,
    ):
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 401),
            error_type=kwargs.pop("error_type", "authentication_error"),
            **kwargs,
        )


class RateLimitError(APIError):
    """
    Raised when rate limits are exceeded.

    Check the `retry_after` attribute for the number of seconds
    to wait before retrying.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[float] = None,
        **kwargs,
    ):
        self.retry_after = retry_after
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 429),
            error_type=kwargs.pop("error_type", "rate_limit_error"),
            **kwargs,
        )

    def __str__(self) -> str:
        base = super().__str__()
        if self.retry_after:
            return f"{base} (retry after {self.retry_after}s)"
        return base


class NotFoundError(APIError):
    """
    Raised when a requested resource is not found.

    This occurs when:
    - Document ID doesn't exist
    - Collection ID doesn't exist
    - Resource was deleted
    """

    def __init__(
        self,
        message: str = "Resource not found",
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        **kwargs,
    ):
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 404),
            error_type=kwargs.pop("error_type", "not_found"),
            **kwargs,
        )


class ValidationError(APIError):
    """
    Raised when request validation fails.

    Check the `param` attribute to see which parameter caused the error.
    """

    def __init__(
        self,
        message: str = "Validation error",
        **kwargs,
    ):
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 400),
            error_type=kwargs.pop("error_type", "invalid_request_error"),
            **kwargs,
        )


class PermissionError(APIError):
    """
    Raised when the API key lacks permission for the requested action.
    """

    def __init__(
        self,
        message: str = "Permission denied",
        **kwargs,
    ):
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 403),
            error_type=kwargs.pop("error_type", "permission_error"),
            **kwargs,
        )


class ConflictError(APIError):
    """
    Raised when there's a conflict with the current state.

    This occurs when:
    - Resource already exists
    - Concurrent modification conflict
    """

    def __init__(
        self,
        message: str = "Resource conflict",
        **kwargs,
    ):
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 409),
            error_type=kwargs.pop("error_type", "conflict_error"),
            **kwargs,
        )


class QuotaExceededError(APIError):
    """
    Raised when organization quota is exceeded.

    This is different from rate limiting - quotas are typically
    monthly limits on usage.
    """

    def __init__(
        self,
        message: str = "Quota exceeded",
        quota_type: Optional[str] = None,
        **kwargs,
    ):
        self.quota_type = quota_type
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 402),
            error_type=kwargs.pop("error_type", "quota_exceeded"),
            **kwargs,
        )


class InternalServerError(APIError):
    """
    Raised when the API experiences an internal error.

    These errors are typically transient. Retry with exponential backoff.
    """

    def __init__(
        self,
        message: str = "Internal server error",
        **kwargs,
    ):
        super().__init__(
            message=message,
            status_code=kwargs.pop("status_code", 500),
            error_type=kwargs.pop("error_type", "internal_error"),
            **kwargs,
        )


class APIConnectionError(LakehouseError):
    """
    Raised when unable to connect to the API.

    This occurs when:
    - Network is unavailable
    - DNS resolution fails
    - Connection is refused
    """

    def __init__(
        self,
        message: str = "Failed to connect to Lakehouse42 API",
        original_error: Optional[Exception] = None,
        **kwargs,
    ):
        self.original_error = original_error
        super().__init__(message=message, **kwargs)


class APITimeoutError(APIConnectionError):
    """
    Raised when a request times out.

    Consider increasing the timeout or checking if the request
    is too large.
    """

    def __init__(
        self,
        message: str = "Request timed out",
        **kwargs,
    ):
        super().__init__(message=message, **kwargs)


def raise_for_status(status_code: int, response_data: Dict[str, Any]) -> None:
    """
    Raise an appropriate exception based on the status code and response.

    Args:
        status_code: HTTP status code
        response_data: Parsed JSON response body
    """
    error_info = response_data.get("error", {})
    message = error_info.get("message", "Unknown error")
    error_type = error_info.get("type")
    error_code = error_info.get("code")
    param = error_info.get("param")

    kwargs = {
        "message": message,
        "status_code": status_code,
        "error_type": error_type,
        "error_code": error_code,
        "param": param,
        "response": response_data,
    }

    if status_code == 401:
        raise AuthenticationError(**kwargs)
    elif status_code == 403:
        raise PermissionError(**kwargs)
    elif status_code == 404:
        raise NotFoundError(**kwargs)
    elif status_code == 409:
        raise ConflictError(**kwargs)
    elif status_code == 429:
        retry_after = error_info.get("retry_after")
        raise RateLimitError(retry_after=retry_after, **kwargs)
    elif status_code == 400:
        raise ValidationError(**kwargs)
    elif status_code == 402:
        raise QuotaExceededError(**kwargs)
    elif status_code >= 500:
        raise InternalServerError(**kwargs)
    else:
        raise APIError(**kwargs)
