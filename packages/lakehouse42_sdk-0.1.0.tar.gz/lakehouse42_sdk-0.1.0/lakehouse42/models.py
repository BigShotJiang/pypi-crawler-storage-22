"""
Lakehouse42 SDK models (Pydantic models for API responses).

This module re-exports all types from lakehouse42.types for convenience.
Import from here or directly from lakehouse42.types.
"""

# Re-export all types
from lakehouse42.types import (
    # Enums
    DocumentStatus,
    SearchMode,
    MessageRole,
    EntityType,
    # Document Types
    DocumentMetadata,
    Document,
    DocumentDetail,
    DocumentList,
    Chunk,
    # Search Types
    SearchFilter,
    SearchResult,
    SearchResults,
    StreamSearchSource,
    StreamSearchEvent,
    # Chat Types
    ChatMessage,
    Source,
    Usage,
    ChatChoice,
    ChatCompletion,
    ChatDelta,
    ChatChoiceChunk,
    ChatCompletionChunk,
    # Collection Types
    RetrievalWeights,
    TopKConfig,
    RetrievalConfig,
    Collection,
    CollectionList,
    # Entity Types
    Entity,
    EntityRelationship,
    KnowledgeGraphStats,
    KnowledgeGraph,
    # Request Types
    DocumentCreateRequest,
    DocumentUpdateRequest,
    SearchRequest,
    ChatRequest,
    CollectionCreateRequest,
    CollectionUpdateRequest,
    # Response Types
    APIResponse,
)

__all__ = [
    # Enums
    "DocumentStatus",
    "SearchMode",
    "MessageRole",
    "EntityType",
    # Document Types
    "DocumentMetadata",
    "Document",
    "DocumentDetail",
    "DocumentList",
    "Chunk",
    # Search Types
    "SearchFilter",
    "SearchResult",
    "SearchResults",
    "StreamSearchSource",
    "StreamSearchEvent",
    # Chat Types
    "ChatMessage",
    "Source",
    "Usage",
    "ChatChoice",
    "ChatCompletion",
    "ChatDelta",
    "ChatChoiceChunk",
    "ChatCompletionChunk",
    # Collection Types
    "RetrievalWeights",
    "TopKConfig",
    "RetrievalConfig",
    "Collection",
    "CollectionList",
    # Entity Types
    "Entity",
    "EntityRelationship",
    "KnowledgeGraphStats",
    "KnowledgeGraph",
    # Request Types
    "DocumentCreateRequest",
    "DocumentUpdateRequest",
    "SearchRequest",
    "ChatRequest",
    "CollectionCreateRequest",
    "CollectionUpdateRequest",
    # Response Types
    "APIResponse",
]
