"""
Lakehouse42 API resources.
"""

from lakehouse42.resources.documents import DocumentsResource, DocumentsResourceSync
from lakehouse42.resources.search import SearchResource, SearchResourceSync
from lakehouse42.resources.chat import ChatResource, ChatResourceSync
from lakehouse42.resources.collections import CollectionsResource, CollectionsResourceSync
from lakehouse42.resources.entities import EntitiesResource, EntitiesResourceSync

__all__ = [
    "DocumentsResource",
    "DocumentsResourceSync",
    "SearchResource",
    "SearchResourceSync",
    "ChatResource",
    "ChatResourceSync",
    "CollectionsResource",
    "CollectionsResourceSync",
    "EntitiesResource",
    "EntitiesResourceSync",
]
