"""
Collections API resource.

Provides methods for organizing documents into collections.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

from lakehouse42.types import Collection, CollectionList, Document, DocumentList

if TYPE_CHECKING:
    from lakehouse42.client import LakehouseClient, LakehouseClientSync


class CollectionsResource:
    """
    Async collections API resource.

    Collections help organize documents into logical groups.

    Usage:
        # Create a collection
        collection = await client.collections.create(
            name="HR Documents",
            description="Human resources policies and guides"
        )

        # Add documents to collection
        doc = await client.documents.create(
            title="PTO Policy",
            content="...",
            collection_id=collection.id
        )

        # List documents in collection
        docs = await client.collections.list_documents(collection.id)
    """

    def __init__(self, client: "LakehouseClient"):
        self._client = client

    async def create(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Collection:
        """
        Create a new collection.

        Args:
            name: Collection name (must be unique within organization)
            description: Optional description
            metadata: Custom metadata to attach to the collection

        Returns:
            Created collection

        Example:
            collection = await client.collections.create(
                name="Engineering Docs",
                description="Technical documentation and runbooks",
                metadata={"team": "platform"}
            )
        """
        data = await self._client._request(
            "POST",
            "/collections",
            json_data={
                "name": name,
                "description": description,
                "metadata": metadata or {},
            },
        )
        return Collection(**data)

    async def get(self, collection_id: str) -> Collection:
        """
        Get a collection by ID.

        Args:
            collection_id: Collection ID

        Returns:
            Collection

        Raises:
            NotFoundError: If collection doesn't exist
        """
        data = await self._client._request("GET", f"/collections/{collection_id}")
        return Collection(**data)

    async def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        search: Optional[str] = None,
    ) -> CollectionList:
        """
        List collections with pagination.

        Args:
            limit: Maximum number of collections to return (1-100)
            cursor: Pagination cursor from previous response
            search: Search by name

        Returns:
            Paginated list of collections

        Example:
            result = await client.collections.list(limit=10)
            for col in result.data:
                print(f"{col.name}: {col.document_count} documents")
        """
        params = {
            "limit": limit,
            "cursor": cursor,
            "search": search,
        }
        data = await self._client._request("GET", "/collections", params=params)
        return CollectionList(**data)

    async def update(
        self,
        collection_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Collection:
        """
        Update a collection.

        Args:
            collection_id: Collection ID
            name: New name
            description: New description
            metadata: New metadata (replaces existing)

        Returns:
            Updated collection
        """
        json_data = {}
        if name is not None:
            json_data["name"] = name
        if description is not None:
            json_data["description"] = description
        if metadata is not None:
            json_data["metadata"] = metadata

        data = await self._client._request(
            "PATCH",
            f"/collections/{collection_id}",
            json_data=json_data,
        )
        return Collection(**data)

    async def delete(self, collection_id: str) -> None:
        """
        Delete a collection.

        Note: This does not delete documents in the collection.
        Documents will have their collection_id set to null.

        Args:
            collection_id: Collection ID

        Raises:
            NotFoundError: If collection doesn't exist
        """
        await self._client._request("DELETE", f"/collections/{collection_id}")

    async def list_documents(
        self,
        collection_id: str,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
    ) -> DocumentList:
        """
        List documents in a collection.

        Args:
            collection_id: Collection ID
            limit: Maximum number of documents to return (1-100)
            cursor: Pagination cursor from previous response

        Returns:
            Paginated list of documents

        Example:
            docs = await client.collections.list_documents("col_123")
            for doc in docs.data:
                print(f"- {doc.title}")
        """
        params = {
            "limit": limit,
            "cursor": cursor,
            "collection_id": collection_id,
        }
        data = await self._client._request("GET", "/documents", params=params)
        return DocumentList(**data)

    async def add_document(
        self,
        collection_id: str,
        document_id: str,
    ) -> Document:
        """
        Add a document to a collection.

        Args:
            collection_id: Collection ID
            document_id: Document ID

        Returns:
            Updated document
        """
        data = await self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data={"collection_id": collection_id},
        )
        return Document(**data)

    async def remove_document(
        self,
        collection_id: str,
        document_id: str,
    ) -> Document:
        """
        Remove a document from a collection.

        Args:
            collection_id: Collection ID
            document_id: Document ID

        Returns:
            Updated document
        """
        data = await self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data={"collection_id": None},
        )
        return Document(**data)


class CollectionsResourceSync:
    """
    Sync collections API resource.

    Usage:
        collection = client.collections.create(
            name="HR Documents",
            description="Human resources policies"
        )
    """

    def __init__(self, client: "LakehouseClientSync"):
        self._client = client

    def create(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Collection:
        """Create a new collection."""
        data = self._client._request(
            "POST",
            "/collections",
            json_data={
                "name": name,
                "description": description,
                "metadata": metadata or {},
            },
        )
        return Collection(**data)

    def get(self, collection_id: str) -> Collection:
        """Get a collection by ID."""
        data = self._client._request("GET", f"/collections/{collection_id}")
        return Collection(**data)

    def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        search: Optional[str] = None,
    ) -> CollectionList:
        """List collections with pagination."""
        params = {
            "limit": limit,
            "cursor": cursor,
            "search": search,
        }
        data = self._client._request("GET", "/collections", params=params)
        return CollectionList(**data)

    def update(
        self,
        collection_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Collection:
        """Update a collection."""
        json_data = {}
        if name is not None:
            json_data["name"] = name
        if description is not None:
            json_data["description"] = description
        if metadata is not None:
            json_data["metadata"] = metadata

        data = self._client._request(
            "PATCH",
            f"/collections/{collection_id}",
            json_data=json_data,
        )
        return Collection(**data)

    def delete(self, collection_id: str) -> None:
        """Delete a collection."""
        self._client._request("DELETE", f"/collections/{collection_id}")

    def list_documents(
        self,
        collection_id: str,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
    ) -> DocumentList:
        """List documents in a collection."""
        params = {
            "limit": limit,
            "cursor": cursor,
            "collection_id": collection_id,
        }
        data = self._client._request("GET", "/documents", params=params)
        return DocumentList(**data)

    def add_document(
        self,
        collection_id: str,
        document_id: str,
    ) -> Document:
        """Add a document to a collection."""
        data = self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data={"collection_id": collection_id},
        )
        return Document(**data)

    def remove_document(
        self,
        collection_id: str,
        document_id: str,
    ) -> Document:
        """Remove a document from a collection."""
        data = self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data={"collection_id": None},
        )
        return Document(**data)
