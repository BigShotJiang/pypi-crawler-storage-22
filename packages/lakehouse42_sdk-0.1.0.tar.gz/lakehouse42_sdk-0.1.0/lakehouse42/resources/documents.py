"""
Documents API resource.

Provides methods for creating, retrieving, listing, updating, and deleting documents.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, TYPE_CHECKING, Union

from lakehouse42.types import Document, DocumentList, DocumentMetadata, Chunk, BatchUploadResult, BatchUploadedDocument

if TYPE_CHECKING:
    from lakehouse42.client import LakehouseClient, LakehouseClientSync


class DocumentsResource:
    """
    Async documents API resource.

    Usage:
        # Create a document from text
        doc = await client.documents.create(
            title="My Document",
            content="Document content..."
        )

        # Upload a file
        doc = await client.documents.upload("/path/to/file.pdf")

        # Get a document
        doc = await client.documents.get("doc_123")

        # List documents
        docs = await client.documents.list(limit=20)

        # Delete a document
        await client.documents.delete("doc_123")
    """

    def __init__(self, client: "LakehouseClient"):
        self._client = client

    async def create(
        self,
        content: str,
        title: str,
        *,
        content_type: str = "text/plain",
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
        chunking_strategy: Optional[str] = None,
    ) -> Document:
        """
        Create a new document from text content.

        The document will be processed asynchronously:
        1. Content is chunked based on the chunking strategy
        2. Embeddings are generated for each chunk
        3. Entities are extracted (if enabled)

        Args:
            content: Document content (text, markdown, or HTML)
            title: Document title
            content_type: Content MIME type (default: text/plain)
            metadata: Custom metadata to attach to the document
            collection_id: Collection to add document to
            chunking_strategy: Chunking strategy (semantic, fixed, or paragraph)

        Returns:
            Created document

        Example:
            doc = await client.documents.create(
                title="Company Policies",
                content="# Remote Work Policy\\n\\nEmployees may...",
                content_type="text/markdown",
                metadata={"category": "HR", "department": "all"}
            )
        """
        data = await self._client._request(
            "POST",
            "/documents",
            json_data={
                "content": content,
                "title": title,
                "content_type": content_type,
                "metadata": metadata or {},
                "collection_id": collection_id,
                "chunking_strategy": chunking_strategy,
            },
        )
        return Document(**data)

    async def upload(
        self,
        file: Union[str, Path, BinaryIO],
        *,
        title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
    ) -> Document:
        """
        Upload a document file.

        Supported formats:
        - PDF (.pdf)
        - Word (.docx)
        - Text (.txt)
        - Markdown (.md)
        - HTML (.html)

        Maximum file size: 50MB

        Args:
            file: File path or file-like object
            title: Document title (defaults to filename)
            metadata: Custom metadata to attach to the document
            collection_id: Collection to add document to

        Returns:
            Created document

        Example:
            # From path
            doc = await client.documents.upload("/path/to/report.pdf")

            # From file object
            with open("report.pdf", "rb") as f:
                doc = await client.documents.upload(f, title="Q1 Report")
        """
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            filename = file_path.name
            file_obj = open(file_path, "rb")
            close_file = True
        else:
            filename = getattr(file, "name", "upload")
            file_obj = file
            close_file = False

        try:
            files = {"file": (filename, file_obj)}
            form_data = {}
            if title:
                form_data["title"] = title
            if metadata:
                form_data["metadata"] = json.dumps(metadata)
            if collection_id:
                form_data["collection_id"] = collection_id

            data = await self._client._request(
                "POST",
                "/documents/upload",
                files=files,
                data=form_data if form_data else None,
            )
            return Document(**data)
        finally:
            if close_file:
                file_obj.close()

    async def get(self, document_id: str) -> Document:
        """
        Get a document by ID.

        Args:
            document_id: Document ID

        Returns:
            Document

        Raises:
            NotFoundError: If document doesn't exist

        Example:
            doc = await client.documents.get("doc_123")
            print(f"Title: {doc.title}, Status: {doc.status}")
        """
        data = await self._client._request("GET", f"/documents/{document_id}")
        return Document(**data)

    async def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        collection_id: Optional[str] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
    ) -> DocumentList:
        """
        List documents with pagination and filtering.

        Uses cursor-based pagination for consistent results.

        Args:
            limit: Maximum number of documents to return (1-100)
            cursor: Pagination cursor from previous response
            collection_id: Filter by collection
            status: Filter by status (processing, ready, failed)
            search: Search by title

        Returns:
            Paginated list of documents

        Example:
            # Get first page
            result = await client.documents.list(limit=20)
            for doc in result.data:
                print(doc.title)

            # Get next page
            if result.has_more:
                next_page = await client.documents.list(cursor=result.next_cursor)
        """
        params = {
            "limit": limit,
            "cursor": cursor,
            "collection_id": collection_id,
            "status": status,
            "search": search,
        }
        data = await self._client._request("GET", "/documents", params=params)
        return DocumentList(**data)

    async def update(
        self,
        document_id: str,
        *,
        title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
    ) -> Document:
        """
        Update a document's metadata.

        Args:
            document_id: Document ID
            title: New title
            metadata: New metadata (replaces existing)
            collection_id: New collection ID (or empty string to remove)

        Returns:
            Updated document

        Example:
            doc = await client.documents.update(
                "doc_123",
                title="Updated Title",
                metadata={"reviewed": True}
            )
        """
        json_data = {}
        if title is not None:
            json_data["title"] = title
        if metadata is not None:
            json_data["metadata"] = metadata
        if collection_id is not None:
            json_data["collection_id"] = collection_id if collection_id else None

        data = await self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data=json_data,
        )
        return Document(**data)

    async def delete(self, document_id: str) -> None:
        """
        Delete a document and all its chunks.

        Args:
            document_id: Document ID

        Raises:
            NotFoundError: If document doesn't exist

        Example:
            await client.documents.delete("doc_123")
        """
        await self._client._request("DELETE", f"/documents/{document_id}")

    async def get_chunks(self, document_id: str) -> List[Chunk]:
        """
        Get all chunks for a document.

        Args:
            document_id: Document ID

        Returns:
            List of chunks ordered by chunk_index

        Example:
            chunks = await client.documents.get_chunks("doc_123")
            for chunk in chunks:
                print(f"Chunk {chunk.chunk_index}: {chunk.content[:100]}...")
        """
        data = await self._client._request("GET", f"/documents/{document_id}/chunks")
        return [Chunk(**c) for c in data]

    async def upload_batch(
        self,
        files: List[Union[str, Path, BinaryIO]],
        *,
        collection_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> BatchUploadResult:
        """
        Upload multiple documents in a single batch request.

        Batch upload is more efficient than individual uploads when
        you need to upload multiple files. The server validates
        all files before processing any of them.

        Supported formats:
        - PDF (.pdf)
        - Word (.doc, .docx)
        - Excel (.xls, .xlsx)
        - PowerPoint (.ppt, .pptx)
        - Text (.txt)
        - Markdown (.md)
        - CSV (.csv)
        - HTML (.html)
        - JSON (.json)
        - XML (.xml)

        Limits:
        - Maximum 10 files per batch
        - Maximum 50MB per file

        Args:
            files: List of file paths or file-like objects (max 10)
            collection_id: Collection to add all documents to
            metadata: Custom metadata to attach to all documents

        Returns:
            BatchUploadResult with list of uploaded documents

        Example:
            # From paths
            result = await client.documents.upload_batch([
                "/path/to/report1.pdf",
                "/path/to/report2.pdf",
                "/path/to/data.xlsx"
            ])

            # From file objects
            with open("doc1.pdf", "rb") as f1, open("doc2.pdf", "rb") as f2:
                result = await client.documents.upload_batch(
                    [f1, f2],
                    collection_id="col_123",
                    metadata={"department": "Engineering"}
                )

            print(f"Uploaded {result.total_uploaded} documents")
            for doc in result.documents:
                print(f"  - {doc.title} ({doc.id})")
        """
        if len(files) > 10:
            raise ValueError("Maximum 10 files per batch upload")

        if len(files) == 0:
            raise ValueError("At least one file is required")

        # Prepare files for upload
        file_tuples = []
        files_to_close = []

        try:
            for file in files:
                if isinstance(file, (str, Path)):
                    file_path = Path(file)
                    filename = file_path.name
                    file_obj = open(file_path, "rb")
                    files_to_close.append(file_obj)
                else:
                    filename = getattr(file, "name", "upload")
                    file_obj = file

                file_tuples.append(("files", (filename, file_obj)))

            # Build form data
            form_data = {}
            if collection_id:
                form_data["collection_id"] = collection_id
            if metadata:
                form_data["metadata"] = json.dumps(metadata)

            data = await self._client._request(
                "POST",
                "/documents/upload/batch",
                files=file_tuples,
                data=form_data if form_data else None,
            )
            return BatchUploadResult(**data)
        finally:
            for f in files_to_close:
                f.close()


class DocumentsResourceSync:
    """
    Sync documents API resource.

    Usage:
        # Create a document from text
        doc = client.documents.create(
            title="My Document",
            content="Document content..."
        )

        # Upload a file
        doc = client.documents.upload("/path/to/file.pdf")
    """

    def __init__(self, client: "LakehouseClientSync"):
        self._client = client

    def create(
        self,
        content: str,
        title: str,
        *,
        content_type: str = "text/plain",
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
        chunking_strategy: Optional[str] = None,
    ) -> Document:
        """Create a new document from text content."""
        data = self._client._request(
            "POST",
            "/documents",
            json_data={
                "content": content,
                "title": title,
                "content_type": content_type,
                "metadata": metadata or {},
                "collection_id": collection_id,
                "chunking_strategy": chunking_strategy,
            },
        )
        return Document(**data)

    def upload(
        self,
        file: Union[str, Path, BinaryIO],
        *,
        title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
    ) -> Document:
        """Upload a document file."""
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            filename = file_path.name
            file_obj = open(file_path, "rb")
            close_file = True
        else:
            filename = getattr(file, "name", "upload")
            file_obj = file
            close_file = False

        try:
            files = {"file": (filename, file_obj)}
            form_data = {}
            if title:
                form_data["title"] = title
            if metadata:
                form_data["metadata"] = json.dumps(metadata)
            if collection_id:
                form_data["collection_id"] = collection_id

            data = self._client._request(
                "POST",
                "/documents/upload",
                files=files,
                data=form_data if form_data else None,
            )
            return Document(**data)
        finally:
            if close_file:
                file_obj.close()

    def get(self, document_id: str) -> Document:
        """Get a document by ID."""
        data = self._client._request("GET", f"/documents/{document_id}")
        return Document(**data)

    def list(
        self,
        *,
        limit: int = 20,
        cursor: Optional[str] = None,
        collection_id: Optional[str] = None,
        status: Optional[str] = None,
        search: Optional[str] = None,
    ) -> DocumentList:
        """List documents with pagination and filtering."""
        params = {
            "limit": limit,
            "cursor": cursor,
            "collection_id": collection_id,
            "status": status,
            "search": search,
        }
        data = self._client._request("GET", "/documents", params=params)
        return DocumentList(**data)

    def update(
        self,
        document_id: str,
        *,
        title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        collection_id: Optional[str] = None,
    ) -> Document:
        """Update a document's metadata."""
        json_data = {}
        if title is not None:
            json_data["title"] = title
        if metadata is not None:
            json_data["metadata"] = metadata
        if collection_id is not None:
            json_data["collection_id"] = collection_id if collection_id else None

        data = self._client._request(
            "PATCH",
            f"/documents/{document_id}",
            json_data=json_data,
        )
        return Document(**data)

    def delete(self, document_id: str) -> None:
        """Delete a document and all its chunks."""
        self._client._request("DELETE", f"/documents/{document_id}")

    def get_chunks(self, document_id: str) -> List[Chunk]:
        """Get all chunks for a document."""
        data = self._client._request("GET", f"/documents/{document_id}/chunks")
        return [Chunk(**c) for c in data]

    def upload_batch(
        self,
        files: List[Union[str, Path, BinaryIO]],
        *,
        collection_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> BatchUploadResult:
        """
        Upload multiple documents in a single batch request.

        See async version for full documentation.
        """
        if len(files) > 10:
            raise ValueError("Maximum 10 files per batch upload")

        if len(files) == 0:
            raise ValueError("At least one file is required")

        # Prepare files for upload
        file_tuples = []
        files_to_close = []

        try:
            for file in files:
                if isinstance(file, (str, Path)):
                    file_path = Path(file)
                    filename = file_path.name
                    file_obj = open(file_path, "rb")
                    files_to_close.append(file_obj)
                else:
                    filename = getattr(file, "name", "upload")
                    file_obj = file

                file_tuples.append(("files", (filename, file_obj)))

            # Build form data
            form_data = {}
            if collection_id:
                form_data["collection_id"] = collection_id
            if metadata:
                form_data["metadata"] = json.dumps(metadata)

            data = self._client._request(
                "POST",
                "/documents/upload/batch",
                files=file_tuples,
                data=form_data if form_data else None,
            )
            return BatchUploadResult(**data)
        finally:
            for f in files_to_close:
                f.close()
