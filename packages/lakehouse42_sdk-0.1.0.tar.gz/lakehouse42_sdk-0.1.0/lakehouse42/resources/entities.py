"""
Entities/Knowledge Graph API resource.

Provides methods for querying the knowledge graph and entities extracted from documents.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

from lakehouse42.types import (
    Entity,
    EntityRelationship,
    KnowledgeGraph,
    KnowledgeGraphStats,
)

if TYPE_CHECKING:
    from lakehouse42.client import LakehouseClient, LakehouseClientSync


class EntitiesResource:
    """
    Async entities/knowledge graph API resource.

    The knowledge graph contains entities (people, organizations, concepts, etc.)
    and their relationships extracted from your documents.

    Usage:
        # Get the knowledge graph
        graph = await client.entities.get_graph(limit=100)

        # Get entities for a specific document
        graph = await client.entities.get_graph(document_id="doc_123")

        # Get a specific entity
        entity = await client.entities.get("entity_123")

        # Find related entities
        related = await client.entities.get_related("entity_123")
    """

    def __init__(self, client: "LakehouseClient"):
        self._client = client

    async def get_graph(
        self,
        *,
        limit: int = 100,
        document_id: Optional[str] = None,
    ) -> KnowledgeGraph:
        """
        Get the knowledge graph for the organization.

        Returns nodes (entities) and edges (relationships) that can be used
        to visualize or analyze the knowledge graph.

        Args:
            limit: Maximum number of entities to return (1-500)
            document_id: Filter to entities from a specific document

        Returns:
            Knowledge graph with nodes, edges, and statistics

        Example:
            graph = await client.entities.get_graph(limit=200)

            print(f"Nodes: {graph.stats.total_nodes}")
            print(f"Edges: {graph.stats.total_edges}")
            print(f"Avg connections: {graph.stats.avg_connections:.2f}")

            for node in graph.nodes:
                print(f"- {node.label} ({node.type})")
        """
        params: Dict[str, Any] = {"limit": limit}
        if document_id:
            params["documentId"] = document_id

        # Use the non-v1 endpoint for knowledge graph
        data = await self._client._request(
            "GET",
            "/knowledge-graph",
            params=params,
        )

        return KnowledgeGraph(
            nodes=[
                Entity(
                    id=node["id"],
                    name=node["label"],
                    type=node["type"],
                    metadata=node.get("metadata", {}),
                )
                for node in data.get("nodes", [])
            ],
            edges=[
                EntityRelationship(
                    source=edge["source"],
                    target=edge["target"],
                    relationship_type=edge["label"],
                    weight=edge.get("weight", 1.0),
                )
                for edge in data.get("edges", [])
            ],
            stats=KnowledgeGraphStats(
                total_nodes=data.get("stats", {}).get("totalNodes", 0),
                total_edges=data.get("stats", {}).get("totalEdges", 0),
                avg_connections=data.get("stats", {}).get("avgConnections", 0.0),
            ),
        )

    async def list(
        self,
        *,
        limit: int = 100,
        cursor: Optional[str] = None,
        entity_type: Optional[str] = None,
        document_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List entities with pagination.

        Args:
            limit: Maximum number of entities to return (1-100)
            cursor: Pagination cursor from previous response
            entity_type: Filter by entity type (person, organization, concept, etc.)
            document_id: Filter to entities from a specific document

        Returns:
            Paginated list of entities

        Example:
            result = await client.entities.list(entity_type="person")
            for entity in result.get("entities", []):
                print(f"- {entity['name']} ({entity['type']})")
        """
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if entity_type:
            params["entity_type"] = entity_type
        if document_id:
            params["document_id"] = document_id

        return await self._client._request("GET", "/entities", params=params)

    async def get(self, entity_id: str) -> Entity:
        """
        Get an entity by ID.

        Args:
            entity_id: Entity ID

        Returns:
            Entity details

        Raises:
            NotFoundError: If entity doesn't exist

        Example:
            entity = await client.entities.get("entity_123")
            print(f"Name: {entity.name}")
            print(f"Type: {entity.type}")
        """
        data = await self._client._request("GET", f"/entities/{entity_id}")
        return Entity(**data)

    async def get_related(
        self,
        entity_id: str,
        *,
        limit: int = 20,
        relationship_types: Optional[List[str]] = None,
    ) -> List[EntityRelationship]:
        """
        Get entities related to a given entity.

        Args:
            entity_id: Entity ID to find relationships for
            limit: Maximum number of relationships to return
            relationship_types: Filter by relationship types

        Returns:
            List of entity relationships

        Example:
            related = await client.entities.get_related(
                "entity_123",
                relationship_types=["works_for", "reports_to"]
            )
            for rel in related:
                print(f"{rel.source} --{rel.relationship_type}--> {rel.target}")
        """
        params: Dict[str, Any] = {"limit": limit}
        if relationship_types:
            params["relationship_types"] = ",".join(relationship_types)

        data = await self._client._request(
            "GET",
            f"/entities/{entity_id}/relationships",
            params=params,
        )
        return [EntityRelationship(**r) for r in data.get("relationships", [])]

    async def search(
        self,
        query: str,
        *,
        limit: int = 20,
        entity_types: Optional[List[str]] = None,
    ) -> List[Entity]:
        """
        Search for entities by name.

        Args:
            query: Search query
            limit: Maximum number of results
            entity_types: Filter by entity types

        Returns:
            List of matching entities

        Example:
            entities = await client.entities.search(
                "John",
                entity_types=["person"]
            )
            for entity in entities:
                print(f"- {entity.name}")
        """
        params: Dict[str, Any] = {"query": query, "limit": limit}
        if entity_types:
            params["entity_types"] = ",".join(entity_types)

        data = await self._client._request("GET", "/entities/search", params=params)
        return [Entity(**e) for e in data.get("entities", [])]


class EntitiesResourceSync:
    """
    Sync entities/knowledge graph API resource.

    Usage:
        graph = client.entities.get_graph(limit=100)
        entity = client.entities.get("entity_123")
    """

    def __init__(self, client: "LakehouseClientSync"):
        self._client = client

    def get_graph(
        self,
        *,
        limit: int = 100,
        document_id: Optional[str] = None,
    ) -> KnowledgeGraph:
        """Get the knowledge graph for the organization."""
        params: Dict[str, Any] = {"limit": limit}
        if document_id:
            params["documentId"] = document_id

        data = self._client._request(
            "GET",
            "/knowledge-graph",
            params=params,
        )

        return KnowledgeGraph(
            nodes=[
                Entity(
                    id=node["id"],
                    name=node["label"],
                    type=node["type"],
                    metadata=node.get("metadata", {}),
                )
                for node in data.get("nodes", [])
            ],
            edges=[
                EntityRelationship(
                    source=edge["source"],
                    target=edge["target"],
                    relationship_type=edge["label"],
                    weight=edge.get("weight", 1.0),
                )
                for edge in data.get("edges", [])
            ],
            stats=KnowledgeGraphStats(
                total_nodes=data.get("stats", {}).get("totalNodes", 0),
                total_edges=data.get("stats", {}).get("totalEdges", 0),
                avg_connections=data.get("stats", {}).get("avgConnections", 0.0),
            ),
        )

    def list(
        self,
        *,
        limit: int = 100,
        cursor: Optional[str] = None,
        entity_type: Optional[str] = None,
        document_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List entities with pagination."""
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if entity_type:
            params["entity_type"] = entity_type
        if document_id:
            params["document_id"] = document_id

        return self._client._request("GET", "/entities", params=params)

    def get(self, entity_id: str) -> Entity:
        """Get an entity by ID."""
        data = self._client._request("GET", f"/entities/{entity_id}")
        return Entity(**data)

    def get_related(
        self,
        entity_id: str,
        *,
        limit: int = 20,
        relationship_types: Optional[List[str]] = None,
    ) -> List[EntityRelationship]:
        """Get entities related to a given entity."""
        params: Dict[str, Any] = {"limit": limit}
        if relationship_types:
            params["relationship_types"] = ",".join(relationship_types)

        data = self._client._request(
            "GET",
            f"/entities/{entity_id}/relationships",
            params=params,
        )
        return [EntityRelationship(**r) for r in data.get("relationships", [])]

    def search(
        self,
        query: str,
        *,
        limit: int = 20,
        entity_types: Optional[List[str]] = None,
    ) -> List[Entity]:
        """Search for entities by name."""
        params: Dict[str, Any] = {"query": query, "limit": limit}
        if entity_types:
            params["entity_types"] = ",".join(entity_types)

        data = self._client._request("GET", "/entities/search", params=params)
        return [Entity(**e) for e in data.get("entities", [])]
