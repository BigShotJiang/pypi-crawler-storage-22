"""
Search API resource.

Provides methods for searching the knowledge base and finding similar content.
"""

from __future__ import annotations

import json
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, TYPE_CHECKING

from lakehouse42.types import (
    SearchFilter,
    SearchMode,
    SearchResult,
    SearchResults,
    StreamSearchEvent,
    StreamSearchSource,
)

if TYPE_CHECKING:
    from lakehouse42.client import LakehouseClient, LakehouseClientSync


class SearchResource:
    """
    Async search API resource.

    Usage:
        # Basic search
        results = await client.search.query("What is machine learning?")

        # Hybrid search with filters
        results = await client.search.query(
            "revenue growth",
            mode="hybrid",
            filters=[{"field": "metadata.year", "operator": "gte", "value": 2023}],
            collection_ids=["col_123"]
        )

        # Find similar chunks
        similar = await client.search.find_similar("chunk_456")
    """

    def __init__(self, client: "LakehouseClient"):
        self._client = client

    async def query(
        self,
        query: str,
        *,
        mode: str = "hybrid",
        top_k: int = 10,
        min_score: float = 0.0,
        filters: Optional[List[Dict[str, Any]]] = None,
        collection_ids: Optional[List[str]] = None,
        include_content: bool = True,
        include_metadata: bool = True,
        rerank: bool = False,
    ) -> SearchResults:
        """
        Search the knowledge base.

        Search Modes:
        - vector: Pure semantic search using embeddings. Best for conceptual queries.
        - keyword: BM25 keyword search. Best for exact term matching.
        - hybrid: Combines both approaches with reciprocal rank fusion. Recommended.

        Args:
            query: Search query text
            mode: Search mode (vector, keyword, or hybrid)
            top_k: Number of results to return (1-100)
            min_score: Minimum relevance score (0-1)
            filters: Metadata filters (e.g., [{"field": "author", "operator": "eq", "value": "John"}])
            collection_ids: Limit search to specific collections
            include_content: Include chunk content in results
            include_metadata: Include metadata in results
            rerank: Apply cross-encoder reranking for improved relevance

        Returns:
            Search results with relevance scores

        Example:
            # Search with filters
            results = await client.search.query(
                "quarterly earnings",
                filters=[
                    {"field": "metadata.year", "operator": "eq", "value": 2024},
                    {"field": "metadata.type", "operator": "eq", "value": "report"}
                ],
                top_k=5,
                rerank=True
            )

            for result in results.results:
                print(f"{result.document_title}: {result.score:.2f}")
                print(f"  {result.content[:200]}...")
        """
        # Convert filter dicts to SearchFilter format
        filter_list = []
        if filters:
            for f in filters:
                if isinstance(f, dict):
                    filter_list.append(f)
                elif isinstance(f, SearchFilter):
                    filter_list.append(f.model_dump())

        data = await self._client._request(
            "POST",
            "/search",
            json_data={
                "query": query,
                "mode": mode,
                "top_k": top_k,
                "min_score": min_score,
                "filters": filter_list,
                "collection_ids": collection_ids or [],
                "include_content": include_content,
                "include_metadata": include_metadata,
                "rerank": rerank,
            },
        )
        return SearchResults(**data)

    async def find_similar(
        self,
        chunk_id: str,
        *,
        top_k: int = 10,
        collection_ids: Optional[List[str]] = None,
    ) -> SearchResults:
        """
        Find chunks similar to a given chunk.

        This uses vector similarity to find content that is semantically
        similar to the specified chunk.

        Args:
            chunk_id: ID of the chunk to find similar content for
            top_k: Number of results to return (1-100)
            collection_ids: Limit search to specific collections

        Returns:
            Search results with similarity scores

        Example:
            # Find similar content to a specific chunk
            similar = await client.search.find_similar("chunk_123", top_k=5)
            for result in similar.results:
                print(f"Similar: {result.document_title} ({result.score:.2f})")
        """
        params: Dict[str, Any] = {
            "top_k": top_k,
        }
        if collection_ids:
            params["collection_ids"] = ",".join(collection_ids)

        data = await self._client._request(
            "GET",
            f"/search/similar/{chunk_id}",
            params=params,
        )
        return SearchResults(**data)

    async def stream(
        self,
        query: str,
        *,
        collection_ids: Optional[List[str]] = None,
        document_ids: Optional[List[str]] = None,
        top_k: int = 10,
        model: Optional[str] = None,
    ) -> AsyncIterator[StreamSearchEvent]:
        """
        Execute a streaming RAG search.

        This performs a search and streams the response generation,
        yielding events as they arrive.

        Event Types:
        - sources: Initial search results/sources
        - content: Streamed answer content chunks
        - metadata: Final metadata (tokens, latency)
        - complete: Stream complete with query_id
        - error: Error message

        Args:
            query: Search query text
            collection_ids: Limit search to specific collections
            document_ids: Limit search to specific documents
            top_k: Number of results to retrieve
            model: LLM model to use for generation

        Yields:
            StreamSearchEvent with type-specific data

        Example:
            sources = []
            full_response = ""

            async for event in client.search.stream("What is our PTO policy?"):
                if event.type == "sources":
                    sources = event.sources
                    print(f"Found {len(sources)} sources")
                elif event.type == "content":
                    print(event.content, end="", flush=True)
                    full_response += event.content or ""
                elif event.type == "metadata":
                    print(f"\\nTokens: {event.tokens_used}")
                elif event.type == "complete":
                    print(f"Query ID: {event.query_id}")
                elif event.type == "error":
                    print(f"Error: {event.error}")
        """
        async for line in self._client._stream(
            "POST",
            "/search/stream",
            json_data={
                "query": query,
                "collectionIds": collection_ids,
                "documentIds": document_ids,
                "topK": top_k,
                "model": model,
            },
        ):
            if line.startswith("data: "):
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    parsed = json.loads(data)
                    event_type = parsed.get("type", "")

                    # Parse sources if present
                    sources = None
                    if "sources" in parsed:
                        sources = [
                            StreamSearchSource(**s) for s in parsed["sources"]
                        ]

                    yield StreamSearchEvent(
                        type=event_type,
                        sources=sources,
                        content=parsed.get("content"),
                        query_type=parsed.get("queryType"),
                        weights_used=parsed.get("weightsUsed"),
                        tokens_used=parsed.get("tokensUsed"),
                        model_used=parsed.get("modelUsed"),
                        latency_ms=parsed.get("latencyMs"),
                        retrieval_latency_ms=parsed.get("retrievalLatencyMs"),
                        query_id=parsed.get("queryId"),
                        error=parsed.get("error"),
                    )
                except json.JSONDecodeError:
                    continue


class SearchResourceSync:
    """
    Sync search API resource.

    Usage:
        # Basic search
        results = client.search.query("What is machine learning?")

        # Find similar chunks
        similar = client.search.find_similar("chunk_456")
    """

    def __init__(self, client: "LakehouseClientSync"):
        self._client = client

    def query(
        self,
        query: str,
        *,
        mode: str = "hybrid",
        top_k: int = 10,
        min_score: float = 0.0,
        filters: Optional[List[Dict[str, Any]]] = None,
        collection_ids: Optional[List[str]] = None,
        include_content: bool = True,
        include_metadata: bool = True,
        rerank: bool = False,
    ) -> SearchResults:
        """
        Search the knowledge base.

        See async version for full documentation.
        """
        filter_list = []
        if filters:
            for f in filters:
                if isinstance(f, dict):
                    filter_list.append(f)
                elif isinstance(f, SearchFilter):
                    filter_list.append(f.model_dump())

        data = self._client._request(
            "POST",
            "/search",
            json_data={
                "query": query,
                "mode": mode,
                "top_k": top_k,
                "min_score": min_score,
                "filters": filter_list,
                "collection_ids": collection_ids or [],
                "include_content": include_content,
                "include_metadata": include_metadata,
                "rerank": rerank,
            },
        )
        return SearchResults(**data)

    def find_similar(
        self,
        chunk_id: str,
        *,
        top_k: int = 10,
        collection_ids: Optional[List[str]] = None,
    ) -> SearchResults:
        """
        Find chunks similar to a given chunk.

        See async version for full documentation.
        """
        params: Dict[str, Any] = {
            "top_k": top_k,
        }
        if collection_ids:
            params["collection_ids"] = ",".join(collection_ids)

        data = self._client._request(
            "GET",
            f"/search/similar/{chunk_id}",
            params=params,
        )
        return SearchResults(**data)

    def stream(
        self,
        query: str,
        *,
        collection_ids: Optional[List[str]] = None,
        document_ids: Optional[List[str]] = None,
        top_k: int = 10,
        model: Optional[str] = None,
    ) -> Iterator[StreamSearchEvent]:
        """
        Execute a streaming RAG search.

        See async version for full documentation.
        """
        for line in self._client._stream(
            "POST",
            "/search/stream",
            json_data={
                "query": query,
                "collectionIds": collection_ids,
                "documentIds": document_ids,
                "topK": top_k,
                "model": model,
            },
        ):
            if line.startswith("data: "):
                data = line[6:]
                if data == "[DONE]":
                    break
                try:
                    parsed = json.loads(data)
                    event_type = parsed.get("type", "")

                    sources = None
                    if "sources" in parsed:
                        sources = [
                            StreamSearchSource(**s) for s in parsed["sources"]
                        ]

                    yield StreamSearchEvent(
                        type=event_type,
                        sources=sources,
                        content=parsed.get("content"),
                        query_type=parsed.get("queryType"),
                        weights_used=parsed.get("weightsUsed"),
                        tokens_used=parsed.get("tokensUsed"),
                        model_used=parsed.get("modelUsed"),
                        latency_ms=parsed.get("latencyMs"),
                        retrieval_latency_ms=parsed.get("retrievalLatencyMs"),
                        query_id=parsed.get("queryId"),
                        error=parsed.get("error"),
                    )
                except json.JSONDecodeError:
                    continue
