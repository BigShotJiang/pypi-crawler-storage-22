"""
Time Travel API resource.

Provides methods for querying historical data via Iceberg snapshots.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

from lakehouse42.types import (
    SnapshotInfo,
    SnapshotList,
    TimeTravelQueryResult,
    DiffResult,
)

if TYPE_CHECKING:
    from lakehouse42.client import LakehouseClient, LakehouseClientSync


class TimeTravelResource:
    """
    Async time travel API resource.

    Time travel enables querying historical data via Iceberg snapshots,
    comparing changes between snapshots, and listing available snapshots.

    Usage:
        # Query data at a specific snapshot
        result = await client.time_travel.query(
            table_name="documents",
            namespace="org_abc123",
            snapshot_id="1234567890123456789"
        )

        # Query data at a specific timestamp
        result = await client.time_travel.query(
            table_name="chunks",
            namespace="org_abc123",
            as_of_timestamp="2024-01-15T10:30:00Z"
        )

        # Compare two snapshots
        diff = await client.time_travel.diff(
            table_name="documents",
            namespace="org_abc123",
            from_snapshot_id="1234567890",
            to_snapshot_id="1234567891"
        )

        # List snapshots
        snapshots = await client.time_travel.list_snapshots(
            table_name="documents",
            namespace="org_abc123"
        )
    """

    def __init__(self, client: "LakehouseClient"):
        self._client = client

    async def query(
        self,
        table_name: str,
        namespace: str,
        *,
        snapshot_id: Optional[str] = None,
        as_of_timestamp: Optional[str] = None,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        limit: int = 100,
    ) -> TimeTravelQueryResult:
        """
        Query an Iceberg table at a specific point in time.

        You must specify either `snapshot_id` or `as_of_timestamp` to
        query historical data. If neither is provided, the current
        snapshot will be used.

        Args:
            table_name: Name of the Iceberg table to query
            namespace: Iceberg namespace (typically org_{id})
            snapshot_id: Specific snapshot ID to query
            as_of_timestamp: ISO timestamp to query data as of
            columns: Specific columns to return (default: all)
            where: SQL WHERE clause filter
            limit: Maximum number of rows to return (1-10000, default: 100)

        Returns:
            TimeTravelQueryResult with rows, columns, and metadata

        Example:
            # Query by snapshot ID
            result = await client.time_travel.query(
                table_name="documents",
                namespace="org_abc123",
                snapshot_id="1234567890123456789",
                columns=["id", "title", "created_at"],
                limit=50
            )

            for row in result.rows:
                print(f"{row['id']}: {row['title']}")

            # Query by timestamp
            result = await client.time_travel.query(
                table_name="chunks",
                namespace="org_abc123",
                as_of_timestamp="2024-01-15T10:30:00Z",
                where="document_id = 'doc-123'"
            )
        """
        json_data: Dict[str, Any] = {
            "table_name": table_name,
            "namespace": namespace,
            "limit": limit,
        }

        if snapshot_id:
            json_data["snapshot_id"] = snapshot_id
        if as_of_timestamp:
            json_data["as_of_timestamp"] = as_of_timestamp
        if columns:
            json_data["columns"] = columns
        if where:
            json_data["where"] = where

        data = await self._client._request(
            "POST",
            "/time-travel/query",
            json_data=json_data,
        )
        return TimeTravelQueryResult(**data)

    async def diff(
        self,
        table_name: str,
        namespace: str,
        from_snapshot_id: str,
        to_snapshot_id: str,
    ) -> DiffResult:
        """
        Compare two Iceberg snapshots and return the differences.

        This performs a file-level diff between two snapshots, returning
        counts of added/deleted rows and schema changes if any.

        Args:
            table_name: Name of the Iceberg table
            namespace: Iceberg namespace (typically org_{id})
            from_snapshot_id: Starting snapshot ID for comparison
            to_snapshot_id: Ending snapshot ID for comparison

        Returns:
            DiffResult with added_rows, deleted_rows, schema_changes, etc.

        Example:
            diff = await client.time_travel.diff(
                table_name="documents",
                namespace="org_abc123",
                from_snapshot_id="1234567890",
                to_snapshot_id="1234567891"
            )

            print(f"Added rows: {diff.added_rows}")
            print(f"Deleted rows: {diff.deleted_rows}")
            print(f"Changed files: {diff.changed_files}")

            for change in diff.schema_changes:
                print(f"Schema: {change.field} - {change.change}")
        """
        data = await self._client._request(
            "POST",
            "/time-travel/diff",
            json_data={
                "table_name": table_name,
                "namespace": namespace,
                "from_snapshot_id": from_snapshot_id,
                "to_snapshot_id": to_snapshot_id,
            },
        )
        return DiffResult(**data)

    async def list_snapshots(
        self,
        table_name: str,
        namespace: str,
        *,
        limit: int = 50,
        document_id: Optional[str] = None,
    ) -> SnapshotList:
        """
        List snapshots for an Iceberg table.

        Returns historical snapshots ordered by commit time (most recent first).

        Args:
            table_name: Name of the Iceberg table
            namespace: Iceberg namespace (typically org_{id})
            limit: Maximum number of snapshots to return (1-1000, default: 50)
            document_id: Filter to snapshots containing a specific document

        Returns:
            SnapshotList with snapshots and total count

        Example:
            snapshots = await client.time_travel.list_snapshots(
                table_name="documents",
                namespace="org_abc123",
                limit=10
            )

            print(f"Total snapshots: {snapshots.total}")
            for snap in snapshots.snapshots:
                print(f"{snap.snapshot_id}: {snap.operation} at {snap.committed_at}")
                if snap.summary:
                    print(f"  Added records: {snap.summary.get('added-records', 'N/A')}")
        """
        params: Dict[str, Any] = {
            "table_name": table_name,
            "namespace": namespace,
            "limit": limit,
        }
        if document_id:
            params["document_id"] = document_id

        data = await self._client._request(
            "GET",
            "/time-travel/snapshots",
            params=params,
        )
        return SnapshotList(**data)


class TimeTravelResourceSync:
    """
    Sync time travel API resource.

    Usage:
        result = client.time_travel.query(
            table_name="documents",
            namespace="org_abc123",
            snapshot_id="1234567890123456789"
        )
    """

    def __init__(self, client: "LakehouseClientSync"):
        self._client = client

    def query(
        self,
        table_name: str,
        namespace: str,
        *,
        snapshot_id: Optional[str] = None,
        as_of_timestamp: Optional[str] = None,
        columns: Optional[List[str]] = None,
        where: Optional[str] = None,
        limit: int = 100,
    ) -> TimeTravelQueryResult:
        """
        Query an Iceberg table at a specific point in time.

        See async version for full documentation.
        """
        json_data: Dict[str, Any] = {
            "table_name": table_name,
            "namespace": namespace,
            "limit": limit,
        }

        if snapshot_id:
            json_data["snapshot_id"] = snapshot_id
        if as_of_timestamp:
            json_data["as_of_timestamp"] = as_of_timestamp
        if columns:
            json_data["columns"] = columns
        if where:
            json_data["where"] = where

        data = self._client._request(
            "POST",
            "/time-travel/query",
            json_data=json_data,
        )
        return TimeTravelQueryResult(**data)

    def diff(
        self,
        table_name: str,
        namespace: str,
        from_snapshot_id: str,
        to_snapshot_id: str,
    ) -> DiffResult:
        """
        Compare two Iceberg snapshots and return the differences.

        See async version for full documentation.
        """
        data = self._client._request(
            "POST",
            "/time-travel/diff",
            json_data={
                "table_name": table_name,
                "namespace": namespace,
                "from_snapshot_id": from_snapshot_id,
                "to_snapshot_id": to_snapshot_id,
            },
        )
        return DiffResult(**data)

    def list_snapshots(
        self,
        table_name: str,
        namespace: str,
        *,
        limit: int = 50,
        document_id: Optional[str] = None,
    ) -> SnapshotList:
        """
        List snapshots for an Iceberg table.

        See async version for full documentation.
        """
        params: Dict[str, Any] = {
            "table_name": table_name,
            "namespace": namespace,
            "limit": limit,
        }
        if document_id:
            params["document_id"] = document_id

        data = self._client._request(
            "GET",
            "/time-travel/snapshots",
            params=params,
        )
        return SnapshotList(**data)
