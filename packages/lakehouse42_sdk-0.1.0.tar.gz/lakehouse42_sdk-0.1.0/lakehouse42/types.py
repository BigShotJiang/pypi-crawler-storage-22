"""
Lakehouse42 SDK type definitions.

All request and response types are defined using Pydantic models
for validation and serialization.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


# Enums


class DocumentStatus(str, Enum):
    """Document processing status."""

    PENDING = "pending"
    PROCESSING = "processing"
    READY = "ready"
    FAILED = "failed"


class SearchMode(str, Enum):
    """Search mode for queries."""

    VECTOR = "vector"  # Semantic similarity only
    KEYWORD = "keyword"  # BM25 keyword search
    HYBRID = "hybrid"  # Combined vector + keyword


class MessageRole(str, Enum):
    """Role of a chat message."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class EntityType(str, Enum):
    """Types of entities in the knowledge graph."""

    PERSON = "person"
    ORGANIZATION = "organization"
    PRODUCT = "product"
    LOCATION = "location"
    DATE = "date"
    CONCEPT = "concept"
    PROCESS = "process"
    DOCUMENT = "document"
    CUSTOM = "custom"


# Document Types


class DocumentMetadata(BaseModel):
    """Metadata attached to a document."""

    source: Optional[str] = None
    author: Optional[str] = None
    created_date: Optional[datetime] = None
    tags: List[str] = Field(default_factory=list)
    custom: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        extra = "allow"


class Document(BaseModel):
    """A document in the knowledge base."""

    id: str
    title: str
    content_type: str
    status: Union[DocumentStatus, str] = DocumentStatus.PENDING
    chunk_count: int = 0
    word_count: Optional[int] = None
    size_bytes: Optional[int] = None
    collection_id: Optional[str] = None
    collection_name: Optional[str] = None
    metadata: Union[DocumentMetadata, Dict[str, Any]] = Field(default_factory=dict)
    processing_error: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        extra = "allow"


class DocumentDetail(Document):
    """Document with chunks included."""

    chunks: List["Chunk"] = Field(default_factory=list)


class DocumentList(BaseModel):
    """Paginated list of documents."""

    documents: List[Document] = Field(default_factory=list, alias="data")
    has_more: bool = False
    next_cursor: Optional[str] = None
    total_count: int = 0

    class Config:
        populate_by_name = True

    @property
    def data(self) -> List[Document]:
        """Alias for documents for backwards compatibility."""
        return self.documents


class Chunk(BaseModel):
    """A chunk of a document."""

    id: str
    chunk_index: int = 0
    content: str
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    document_id: Optional[str] = None
    token_count: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


# Search Types


class SearchFilter(BaseModel):
    """A filter for search queries."""

    field: str
    operator: str = "eq"  # eq, ne, gt, gte, lt, lte, in, contains
    value: Any


class SearchResult(BaseModel):
    """A single search result."""

    chunk_id: str
    document_id: str
    document_title: Optional[str] = None
    content: Optional[str] = None
    score: float
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    highlights: List[str] = Field(default_factory=list)
    retriever_contributions: Dict[str, float] = Field(default_factory=dict)


class SearchResults(BaseModel):
    """Search query results."""

    results: List[SearchResult]
    query: str
    mode: Union[SearchMode, str] = SearchMode.HYBRID
    total_results: int = 0
    processing_time_ms: float = 0.0
    weights_used: Dict[str, float] = Field(default_factory=dict)
    query_id: Optional[str] = None

    class Config:
        extra = "allow"


class StreamSearchSource(BaseModel):
    """Source from streaming search."""

    chunk_id: str
    document_id: str
    document_name: Optional[str] = None
    content: str
    score: float
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    retriever_contributions: Dict[str, float] = Field(default_factory=dict)


class StreamSearchEvent(BaseModel):
    """Event from streaming search."""

    type: str  # sources, content, metadata, complete, error
    sources: Optional[List[StreamSearchSource]] = None
    content: Optional[str] = None
    query_type: Optional[str] = None
    weights_used: Optional[Dict[str, float]] = None
    tokens_used: Optional[int] = None
    model_used: Optional[str] = None
    latency_ms: Optional[int] = None
    retrieval_latency_ms: Optional[int] = None
    query_id: Optional[str] = None
    error: Optional[str] = None


# Chat Types


class ChatMessage(BaseModel):
    """A message in a chat conversation."""

    role: MessageRole
    content: str


class Source(BaseModel):
    """A source citation from the knowledge base."""

    document_id: str
    document_title: str
    chunk_id: str
    content_preview: str
    relevance_score: float


class Usage(BaseModel):
    """Token usage information."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatChoice(BaseModel):
    """A choice in a chat completion."""

    index: int
    message: ChatMessage
    finish_reason: Optional[str] = None


class ChatCompletion(BaseModel):
    """A chat completion response."""

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[ChatChoice]
    usage: Usage
    sources: List[Source] = Field(default_factory=list)


class ChatDelta(BaseModel):
    """Delta content in a streaming chunk."""

    role: Optional[MessageRole] = None
    content: Optional[str] = None


class ChatChoiceChunk(BaseModel):
    """A choice in a streaming chat chunk."""

    index: int
    delta: ChatDelta
    finish_reason: Optional[str] = None


class ChatCompletionChunk(BaseModel):
    """A streaming chat completion chunk."""

    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: List[ChatChoiceChunk]


# Collection Types


class RetrievalWeights(BaseModel):
    """Weights for retrieval methods."""

    dense: float = 0.4
    sparse: float = 0.3
    bm25: float = 0.3


class TopKConfig(BaseModel):
    """Top-k configuration for retrieval."""

    initial: int = 100
    after_fusion: int = 50
    final: int = 10


class RetrievalConfig(BaseModel):
    """Retrieval configuration for a collection."""

    default_weights: Optional[RetrievalWeights] = None
    reranking_enabled: Optional[bool] = None
    top_k: Optional[TopKConfig] = None


class Collection(BaseModel):
    """A collection of documents."""

    id: str
    name: str
    description: Optional[str] = None
    color: str = "#6366f1"
    icon: str = "folder"
    is_default: bool = False
    document_count: int = 0
    retrieval_config: Optional[RetrievalConfig] = None
    metadata_schema: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        extra = "allow"


class CollectionList(BaseModel):
    """Paginated list of collections."""

    collections: List[Collection] = Field(default_factory=list, alias="data")
    has_more: bool = False
    next_cursor: Optional[str] = None

    class Config:
        populate_by_name = True

    @property
    def data(self) -> List[Collection]:
        """Alias for collections for backwards compatibility."""
        return self.collections


# Entity/Knowledge Graph Types


class Entity(BaseModel):
    """An entity in the knowledge graph."""

    id: str
    name: str
    type: str  # person, organization, concept, etc.
    normalized_name: Optional[str] = None
    confidence: Optional[float] = None
    attributes: Optional[Dict[str, Any]] = None
    source_document_ids: Optional[List[str]] = None
    external_ids: Optional[Dict[str, str]] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    class Config:
        extra = "allow"


class EntityRelationship(BaseModel):
    """A relationship between entities."""

    source: str  # Source entity ID
    target: str  # Target entity ID
    relationship_type: str  # e.g., "works_for", "reports_to"
    weight: float = 1.0
    confidence: Optional[float] = None
    source_document_id: Optional[str] = None

    class Config:
        extra = "allow"


class KnowledgeGraphStats(BaseModel):
    """Statistics about the knowledge graph."""

    total_nodes: int = 0
    total_edges: int = 0
    avg_connections: float = 0.0


class KnowledgeGraph(BaseModel):
    """Knowledge graph with nodes and edges."""

    nodes: List[Entity] = Field(default_factory=list)
    edges: List[EntityRelationship] = Field(default_factory=list)
    stats: KnowledgeGraphStats = Field(default_factory=KnowledgeGraphStats)


# Request Types (for internal use)


class DocumentCreateRequest(BaseModel):
    """Request to create a document."""

    content: str
    title: str
    content_type: str = "text/plain"
    collection_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    chunking_strategy: Optional[str] = None


class DocumentUpdateRequest(BaseModel):
    """Request to update a document."""

    title: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    collection_id: Optional[str] = None


class SearchRequest(BaseModel):
    """Request for a search query."""

    query: str
    mode: SearchMode = SearchMode.HYBRID
    top_k: int = Field(default=10, ge=1, le=100)
    min_score: float = Field(default=0.0, ge=0, le=1)
    filters: List[SearchFilter] = Field(default_factory=list)
    collection_ids: List[str] = Field(default_factory=list)
    include_content: bool = True
    include_metadata: bool = True
    rerank: bool = False


class ChatRequest(BaseModel):
    """Request for a chat completion."""

    messages: List[ChatMessage]
    model: str = "gpt-4-turbo"
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=1024, ge=1, le=4096)
    stream: bool = False
    use_knowledge_base: bool = True
    search_top_k: int = Field(default=5, ge=1, le=20)
    collection_ids: List[str] = Field(default_factory=list)
    include_sources: bool = True
    session_id: Optional[str] = None


class CollectionCreateRequest(BaseModel):
    """Request to create a collection."""

    name: str
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CollectionUpdateRequest(BaseModel):
    """Request to update a collection."""

    name: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


# Time Travel Types


class SnapshotInfo(BaseModel):
    """Information about an Iceberg table snapshot."""

    snapshot_id: str
    parent_id: Optional[str] = None
    operation: str  # e.g., "append", "overwrite", "delete"
    committed_at: str  # ISO timestamp
    summary: Dict[str, str] = Field(default_factory=dict)
    manifest_list: str = ""


class SnapshotList(BaseModel):
    """List of snapshots for an Iceberg table."""

    snapshots: List[SnapshotInfo] = Field(default_factory=list)
    table_name: str
    namespace: str
    total: int = 0


class TimeTravelQueryResult(BaseModel):
    """Result of a time-travel query."""

    rows: List[Dict[str, Any]] = Field(default_factory=list)
    columns: List[str] = Field(default_factory=list)
    row_count: int = 0
    table_name: str
    snapshot_id: Optional[str] = None
    as_of_timestamp: Optional[str] = None
    latency_ms: int = 0


class SchemaChange(BaseModel):
    """A schema change between snapshots."""

    field: str
    change: str  # e.g., "added", "removed", "modified"


class DiffResult(BaseModel):
    """Result of comparing two Iceberg snapshots."""

    added_rows: int = 0
    deleted_rows: int = 0
    changed_rows: int = 0
    schema_changes: List[SchemaChange] = Field(default_factory=list)
    changed_files: int = 0
    table_name: str
    from_snapshot_id: str
    to_snapshot_id: str
    details: List[Dict[str, Any]] = Field(default_factory=list)


# Batch Upload Types


class BatchUploadedDocument(BaseModel):
    """Information about a document uploaded in a batch."""

    id: str
    title: str
    content_type: str
    status: str
    size_bytes: int


class BatchUploadResult(BaseModel):
    """Result of a batch document upload."""

    documents: List[BatchUploadedDocument] = Field(default_factory=list)
    total_uploaded: int = 0


# API Discovery Types


class EndpointInfo(BaseModel):
    """Information about an API endpoint."""

    method: str
    path: str
    description: str
    scopes: List[str] = Field(default_factory=list)


class RateLimitTier(BaseModel):
    """Rate limit information for a tier."""

    requests_per_minute: int
    search_per_minute: int


class AuthenticationInfo(BaseModel):
    """Authentication information for the API."""

    type: str
    header: str
    bearer_prefix: str
    description: str
    registration_url: str


class DocumentationInfo(BaseModel):
    """Documentation links for the API."""

    openapi_spec: str
    interactive_docs: str


class DiscoveryResponse(BaseModel):
    """API discovery response."""

    name: str
    version: str
    description: str
    base_url: str
    authentication: AuthenticationInfo
    documentation: DocumentationInfo
    endpoints: List[EndpointInfo] = Field(default_factory=list)
    rate_limits: Dict[str, RateLimitTier] = Field(default_factory=dict)
    scopes: Dict[str, str] = Field(default_factory=dict)


# API Response wrapper


class APIResponse(BaseModel):
    """Generic API response wrapper."""

    data: Any
    meta: Optional[Dict[str, Any]] = None
