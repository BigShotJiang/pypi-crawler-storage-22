# Lambda Playwright SDK

A Python SDK for interacting with the Lambda Playwright service.

## Installation

```bash
pip install lambda-playwright
```

## Usage

### Initialization

```python
from lambda_playwright import LambdaPlaywright

# Initialize with environment variables (AWS_PLAYWRIGHT_FUNCTION_URL, AWS_PLAYWRIGHT_ACCESS_KEY, AWS_PLAYWRIGHT_SECRET_ACCESS)
client = LambdaPlaywright()

# Or explicitly
client = LambdaPlaywright(
    function_url="https://your-function-url.lambda-url.ap-southeast-1.on.aws",
    access_key_id="YOUR_ACCESS_KEY",
    secret_access_key="YOUR_SECRET_KEY",
    region="ap-southeast-1"
)
```

### Visit a Page

```python
response = client.visit({
    "url": "https://example.com",
    "actions": [
        {"type": "click", "selector": "button#submit"},
        {"type": "wait_for_selector", "selector": ".results"}
    ],
    "wait_for_network_idle": True
})

print(response["html"])
```

### Render HTML

```python
response = client.render_html({
    "html_content": "<h1>Hello World</h1><script>document.write('Loaded');</script>",
    "actions": [],
    "scroll_to_bottom": True
})

print(response["html"])
```

## Development

To run locally against a local Lambda container:

```python
client = LambdaPlaywright(debug=True)
```
