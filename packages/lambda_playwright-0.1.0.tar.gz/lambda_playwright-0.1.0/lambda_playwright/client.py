import os
import json
import logging
import requests
from typing import Optional, Dict, Union, Any
from requests_aws4auth import AWS4Auth
from .types import Endpoint, VisitPagePayload, RenderHtmlPayload

logger = logging.getLogger(__name__)


class LambdaPlaywright:
    """
    Client for the Lambda Playwright service.
    """

    def __init__(
        self,
        function_url: Optional[str] = None,
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
        region: str = "ap-southeast-1",
        debug: bool = False,
        local_url: str = "http://localhost:9000/2015-03-31/functions/function/invocations",
    ):
        """
        Initialize the LambdaPlaywright client.

        Args:
            function_url: The AWS Lambda Function URL. Defaults to AWS_PLAYWRIGHT_FUNCTION_URL env var.
            access_key_id: AWS Access Key ID. Defaults to AWS_PLAYWRIGHT_ACCESS_KEY env var.
            secret_access_key: AWS Secret Access Key. Defaults to AWS_PLAYWRIGHT_SECRET_ACCESS env var.
            region: AWS Region. Defaults to "ap-southeast-1".
            debug: If True, invoke local Lambda container. Defaults to False.
            local_url: URL for local Lambda container. Defaults to standard RIE URL.
        """
        self.debug = debug
        self.local_url = local_url
        self.region = region

        # Load from env if not provided
        self.function_url = function_url or os.getenv("AWS_PLAYWRIGHT_FUNCTION_URL")
        self.access_key_id = access_key_id or os.getenv("AWS_PLAYWRIGHT_ACCESS_KEY")
        self.secret_access_key = secret_access_key or os.getenv(
            "AWS_PLAYWRIGHT_SECRET_ACCESS"
        )

        if not self.debug:
            if not self.function_url:
                # We don't raise here strictly to allow instantiation if user plans to set it later or only use debug?
                # But it's better to fail early if invalid config.
                # However, if user only wants to use debug mode, they shouldn't need function_url.
                pass

            if (
                not self.access_key_id or not self.secret_access_key
            ) and not self.function_url:
                # If function URL is missing, cannot do anything.
                # If creds are missing, maybe auth is handled elsewhere (e.g. EC2 role)?
                # But requests_aws4auth needs explicit creds usually unless using boto3 session to fetch them.
                # We'll stick to requiring them for now as per original main.py logic.
                pass

    def _get_auth(self) -> Optional[AWS4Auth]:
        if self.debug:
            return None

        if not self.access_key_id or not self.secret_access_key:
            raise ValueError(
                "AWS credentials must be provided or set in env vars for non-debug mode"
            )

        return AWS4Auth(
            self.access_key_id,
            self.secret_access_key,
            self.region,
            "lambda",
        )

    def _invoke(self, endpoint: Endpoint, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Internal invoke method.
        """
        if self.debug:
            url = self.local_url
            # For local RIE, we emulate the rawPath behavior if needed,
            # or rely on the handler finding rawPath in the body as per `main.py` convention.
            full_payload = {"rawPath": endpoint.value, **payload}
        else:
            if not self.function_url:
                raise ValueError("function_url is not configured")
            url = f"{self.function_url.rstrip('/')}{endpoint.value}"
            full_payload = payload

        auth = self._get_auth()
        headers = {"Content-Type": "application/json"}

        logger.debug(f"Invoking {url} with payload {full_payload}")

        response = requests.post(url, json=full_payload, headers=headers, auth=auth)

        if response.status_code != 200:
            # Try to parse error message if possible
            try:
                err_body = response.json()
                if isinstance(err_body, dict) and "message" in err_body:
                    raise Exception(f"Lambda invocation failed: {err_body['message']}")
            except Exception:
                pass
            raise Exception(
                f"Lambda invocation failed with status {response.status_code}: {response.text}"
            )

        # Parse response
        try:
            data = response.json()
        except json.JSONDecodeError:
            raise Exception("Response was not valid JSON")

        if "body" in data:
            body_content = data["body"]
            if isinstance(body_content, str):
                try:
                    return json.loads(body_content)
                except json.JSONDecodeError:
                    return body_content  # Should probably be JSON, but if not return raw string?
            return body_content

        return data

    def visit(self, payload: VisitPagePayload) -> Dict[str, Any]:
        """
        Visit a web page.
        """
        return self._invoke(Endpoint.VISIT, payload)

    def render_html(self, payload: RenderHtmlPayload) -> Dict[str, Any]:
        """
        Render HTML content.
        """
        return self._invoke(Endpoint.RENDER_HTML, payload)
