from setuptools import setup, find_packages

setup(
    name="lambda_playwright",
    version="0.1.0",
    description="SDK for invoking Lambda Playwright service",
    author="Hubexo",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "requests-aws4auth>=1.1.0",
    ],
    python_requires=">=3.8",
)
