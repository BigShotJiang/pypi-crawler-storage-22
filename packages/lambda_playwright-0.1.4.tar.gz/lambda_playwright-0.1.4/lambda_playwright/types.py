from enum import Enum
from typing import TypedDict, List, Optional, Any, Union


class Endpoint(Enum):
    VISIT = "/visit"
    RENDER_HTML = "/render-html"


class ActionType(str, Enum):
    CLICK = "click"
    WAIT_FOR_SELECTOR = "wait_for_selector"
    SLEEP = "sleep"
    SCROLL_TO_BOTTOM = "scroll_to_bottom"
    FILL = "fill"
    TYPE = "type"
    EVALUATE = "evaluate"


class Action(TypedDict, total=False):
    type: ActionType
    selector: Optional[str]
    timeout: Optional[int]
    duration: Optional[float]
    value: Optional[str]
    text: Optional[str]
    delay: Optional[float]
    script: Optional[str]


class VisitPagePayload(TypedDict, total=False):
    url: str
    headers: Optional[dict]
    cookies: Optional[dict]
    user_agent: Optional[str]
    actions: Optional[List[Action]]
    max_retries: Optional[int]
    timeout_ms: Optional[int]
    wait_for_network_idle: Optional[bool]
    scroll_to_bottom: Optional[bool]


class RenderHtmlPayload(TypedDict, total=False):
    html_content: str
    actions: Optional[List[Action]]
    max_retries: Optional[int]
    timeout_ms: Optional[int]
    wait_for_network_idle: Optional[bool]
    scroll_to_bottom: Optional[bool]
