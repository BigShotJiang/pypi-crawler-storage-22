from pathlib import Path
from setuptools import setup, find_packages

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="lambda_playwright",
    version="0.1.4",
    description="SDK for invoking Lambda Playwright service",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Hubexo",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "requests-aws4auth>=1.1.0",
    ],
    python_requires=">=3.8",
)
