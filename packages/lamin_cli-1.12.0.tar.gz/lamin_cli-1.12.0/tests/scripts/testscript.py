print("hello")
print("world")
