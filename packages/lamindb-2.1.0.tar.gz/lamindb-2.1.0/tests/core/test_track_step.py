import concurrent.futures
from pathlib import Path
from typing import Iterable

import lamindb as ln
import pandas as pd
import pytest


@ln.step()
def process_chunk(
    chunk_id: int, artifact_param: ln.Artifact, records_params: Iterable[ln.Record]
) -> str:
    # Create a simple DataFrame
    df = pd.DataFrame(
        {"id": range(chunk_id * 10, (chunk_id + 1) * 10), "value": range(10)}
    )
    env_file = Path("file_with_same_hash.txt")
    env_file.write_text("1")
    ln.Artifact(env_file, description="file_with_same_hash").save()
    # Save it as an artifact
    key = f"chunk_{chunk_id}.parquet"
    artifact = ln.Artifact.from_dataframe(df, key=key).save()
    return artifact.key


def test_step_parallel():
    # Ensure no global run from a previous test (e.g. test_flow)
    ln.context._run = None
    with pytest.raises(RuntimeError) as err:
        process_chunk(4)
    assert (
        err.exconly()
        == "RuntimeError: Please track the global run context before using @ln.step(): ln.track() or @ln.flow()"
    )

    # Ensure tracking is on
    ln.track()

    # Number of parallel executions
    n_parallel = 3

    param_artifact = ln.Artifact(".gitignore", key="param_artifact").save()
    ln.Record(name="record1").save(), ln.Record(name="record2").save()
    records_params = ln.Record.filter(name__startswith="record")

    # Use ThreadPoolExecutor for parallel execution
    with concurrent.futures.ThreadPoolExecutor(max_workers=n_parallel) as executor:
        # Submit all tasks
        futures = [
            executor.submit(process_chunk, i, param_artifact, records_params)
            for i in range(n_parallel)
        ]
        # Get results as they complete
        chunk_keys = [
            future.result() for future in concurrent.futures.as_completed(futures)
        ]

    # Verify results
    # Each execution should have created its own artifact with unique run
    print(f"Created artifacts with keys: {chunk_keys}")
    artifacts = [ln.Artifact.get(key=key) for key in chunk_keys]
    same_hash_artifacts = ln.Artifact.filter(description="file_with_same_hash")

    # Check that we got the expected number of artifacts
    assert len(artifacts) == n_parallel
    assert (
        len(same_hash_artifacts) == 1
    )  # only one artifact with the same hash should exist

    # Verify each artifact has its own unique run
    runs = [artifact.run for artifact in artifacts]
    run_ids = [run.id for run in runs]
    print(f"Run IDs: {run_ids}")
    assert len(set(run_ids)) == n_parallel  # all runs should be unique

    # Verify each run has the correct start and finish times
    for run in runs:
        print(f"Run details: {run}")
        assert run.started_at is not None
        assert run.finished_at is not None
        assert run.started_at < run.finished_at
        assert run.status == "completed"
        assert isinstance(run.params["chunk_id"], int)
        assert run.params["artifact_param"].startswith(
            f"Artifact[{param_artifact.uid}]"
        )
        assert run.params["records_params"] == [
            f"Record[{record.uid}]" for record in records_params
        ]

    # Clean up test artifacts
    runs = []
    for artifact in artifacts:
        runs.append(artifact.run)
        artifact.delete(permanent=True)
    param_artifact.delete(permanent=True)
    same_hash_artifacts[0].delete(permanent=True)
    Path("file_with_same_hash.txt").unlink()
    for run in runs:
        run.delete(permanent=True)

    ln.context._uid = None
    ln.context._run = None
    ln.context._transform = None
    ln.context._path = None
