import lamindb_setup
