"""Tests for lance_namespace package."""
