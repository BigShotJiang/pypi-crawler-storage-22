"""Tests for langasync."""
