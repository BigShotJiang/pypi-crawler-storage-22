"""LangBot - Production-grade platform for building agentic IM bots"""

__version__ = '4.8.2'
