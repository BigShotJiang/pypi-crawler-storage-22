from .client import WeChatPadClient as WeChatPadClient
