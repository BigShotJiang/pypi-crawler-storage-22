"""langchain-deepsigma — LangChain integration for Σ OVERWATCH.

Provides three integration surfaces:

Callbacks
---------
:class:`DeepSigmaCallbackHandler`
    Drop into any LangChain chain or agent. Every run is automatically
    wrapped in a sealed Decision Episode and run through the full
    DLR / RS / DS / MG governance pipeline.

Tools
-----
:func:`deepsigma_tools`
    Returns all four governance tools pre-wired to a set of artifacts.

:class:`IRISQueryTool`
    Ask WHY, WHAT_DRIFTED, STATUS, RECALL, or WHAT_CHANGED against
    the Memory Graph.

:class:`CoherenceScorerTool`
    Score a set of episodes (0–100, A–F) across four dimensions.

:class:`AuditTool`
    Run cross-artifact consistency checks and surface findings.

:class:`ReconcilerTool`
    Detect inconsistencies and propose repairs.

Memory
------
:class:`DeepSigmaMemory`
    LangChain ``BaseMemory`` backed by the Σ OVERWATCH Memory Graph.
    Each conversation turn is stored as a mini Decision Episode;
    ``load_memory_variables`` returns a formatted decision history string.
"""
from langchain_deepsigma.callbacks import DeepSigmaCallbackHandler
from langchain_deepsigma.memory import DeepSigmaMemory
from langchain_deepsigma.tools import (
    AuditTool,
    CoherenceScorerTool,
    IRISQueryTool,
    ReconcilerTool,
    deepsigma_tools,
)

__version__ = "0.1.0"

__all__ = [
    "DeepSigmaCallbackHandler",
    "DeepSigmaMemory",
    "IRISQueryTool",
    "CoherenceScorerTool",
    "AuditTool",
    "ReconcilerTool",
    "deepsigma_tools",
]
