from langgraph.graph.state import CompiledStateGraph, StateGraph

SubGraph = StateGraph | CompiledStateGraph
