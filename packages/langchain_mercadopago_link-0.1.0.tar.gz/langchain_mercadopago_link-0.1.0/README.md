# langchain-mercadopago-link

A LangChain tool for generating MercadoPago payment links. This package provides a reusable LangChain Tool that can be integrated into LangChain agents and chains to generate payment links dynamically.

## Installation

```bash
pip install langchain-mercadopago-link
```

## Quick Start

```python
from langchain_mercadopago_link import MercadoPagoPaymentTool

# Initialize the tool with your MercadoPago credentials
tool = MercadoPagoPaymentTool(
    access_token="YOUR_MERCADOPAGO_ACCESS_TOKEN",
    local_id="YOUR_LOCAL_ID"  # Optional
)

# Use the tool directly
result = tool.run({
    "title": "Development Consulting",
    "description": "Web development consulting services",
    "amount": 5000.0,
    "currency": "ARS"
})

print(result)
```

## Usage with LangChain Agents

```python
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_mercadopago_link import MercadoPagoPaymentTool

# Initialize LLM
llm = ChatOpenAI(temperature=0)

# Initialize the MercadoPago tool
payment_tool = MercadoPagoPaymentTool(
    access_token="YOUR_ACCESS_TOKEN",
    local_id="YOUR_LOCAL_ID"
)

# Create an agent with the payment tool
agent = initialize_agent(
    tools=[payment_tool],
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Use the agent to generate a payment link
response = agent.run(
    "I need to generate a payment link for $10000 Argentine pesos "
    "for graphic design services"
)
```

## Usage in LangChain Chains

```python
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain_mercadopago_link import MercadoPagoPaymentTool

# Create a chain that uses the payment tool
llm = ChatOpenAI(temperature=0)
payment_tool = MercadoPagoPaymentTool(
    access_token="YOUR_ACCESS_TOKEN"
)

# Define a prompt that extracts payment information
prompt = PromptTemplate(
    input_variables=["user_request"],
    template="""
    Analyze the following request and extract payment information:
    {user_request}
    
    Then use the MercadoPago tool to generate the link.
    """
)

chain = LLMChain(llm=llm, prompt=prompt)
# ... integrate with tool execution
```

## Tool Parameters

The `MercadoPagoPaymentTool` accepts the following parameters:

- **access_token** (required): Your MercadoPago Access Token
- **local_id** (optional): Your MercadoPago Local ID

### Tool Input Schema

When calling the tool, you can provide:

- **title** (required): Title of the product or service
- **description** (required): Detailed description
- **amount** (required): Payment amount
- **currency** (optional, default: "ARS"): Currency code (ARS, USD, EUR, BRL, MXN, etc.). Can be changed to any supported MercadoPago currency.
- **quantity** (optional, default: 1): Quantity of items
- **success_url** (optional): Redirect URL after successful payment. If not provided, no redirect URL will be set.
- **failure_url** (optional): Redirect URL after failed payment. If not provided, no redirect URL will be set.
- **pending_url** (optional): Redirect URL for pending payment. If not provided, no redirect URL will be set.
- **external_reference** (optional): External reference for the payment

**Note**: All URL parameters are completely optional. If you don't provide any URLs, MercadoPago will handle the payment flow without custom redirect URLs. You can provide one, two, or all three URLs as needed.

## Example: Complete Integration

```python
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from langchain_mercadopago_link import MercadoPagoPaymentTool
import os

# Get credentials from environment variables
access_token = os.getenv("MERCADOPAGO_ACCESS_TOKEN")
local_id = os.getenv("MERCADOPAGO_LOCAL_ID")

# Initialize tool
payment_tool = MercadoPagoPaymentTool(
    access_token=access_token,
    local_id=local_id
)

# Initialize agent
llm = ChatOpenAI(temperature=0)
agent = initialize_agent(
    tools=[payment_tool],
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    verbose=True
)

# Generate payment link from natural language
result = agent.run(
    "The client needs to pay $15000 pesos for a Python course. "
    "Generate the payment link."
)
```

## Requirements

- Python >= 3.9
- langchain >= 0.2.0
- mercadopago >= 2.2.0
- pydantic >= 2.0.0

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Author

Sebastian Martin Artaza

## Links

- [GitHub Repository](https://github.com/martinartaza/langchain-mercadopago-link)
- [PyPI Package](https://pypi.org/project/langchain-mercadopago-link/)
