"""
LangChain MercadoPago Link Generator

A LangChain tool for generating MercadoPago payment links.
"""

from langchain_mercadopago_link.tools import MercadoPagoPaymentTool

__version__ = "0.1.0"
__all__ = ["MercadoPagoPaymentTool"]
