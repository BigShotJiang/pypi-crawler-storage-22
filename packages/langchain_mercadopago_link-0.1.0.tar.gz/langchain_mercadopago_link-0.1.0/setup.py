"""
Setup configuration for langchain-mercadopago-link package.
"""
from setuptools import setup, find_packages
from pathlib import Path

# Leer el README para la descripción larga
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""

setup(
    name="langchain-mercadopago-link",
    version="0.1.0",
    author="Sebastian Martin Artaza",
    author_email="martin.artaza@gmail.com",
    description="A LangChain tool for generating MercadoPago payment links",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/martinartaza/langchain-mercadopago-link",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business :: Financial",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=[
        "langchain>=0.2.0",
        "mercadopago>=2.2.0",
        "pydantic>=2.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-asyncio>=0.21.0",
        ],
    },
    keywords="langchain mercadopago payment link tool",
    project_urls={
        "Bug Reports": "https://github.com/martinartaza/langchain-mercadopago-link/issues",
        "Source": "https://github.com/martinartaza/langchain-mercadopago-link",
        "Documentation": "https://github.com/martinartaza/langchain-mercadopago-link#readme",
    },
)
