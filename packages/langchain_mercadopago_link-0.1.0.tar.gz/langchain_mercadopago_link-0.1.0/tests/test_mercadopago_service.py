"""
Tests for the MercadoPago service.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
from langchain_mercadopago_link.mercadopago_service import MercadoPagoService


class TestMercadoPagoService:
    """Tests for MercadoPagoService."""
    
    @patch('langchain_mercadopago_link.mercadopago_service.mercadopago')
    def test_init(self, mock_mercadopago):
        """Test service initialization."""
        access_token = "test_token"
        local_id = "test_local_id"
        
        service = MercadoPagoService(access_token, local_id)
        
        assert service.local_id == local_id
        mock_mercadopago.SDK.assert_called_once_with(access_token)
    
    @patch('langchain_mercadopago_link.mercadopago_service.mercadopago')
    def test_create_payment_link_success(self, mock_mercadopago):
        """Test successful payment link creation."""
        # Mock SDK
        mock_sdk_instance = MagicMock()
        mock_preference = MagicMock()
        mock_sdk_instance.preference.return_value = mock_preference
        
        # Mock successful response
        mock_response = {
            "response": {
                "id": "1234567890-abc123",
                "init_point": "https://www.mercadopago.com.ar/checkout/v1/redirect?pref_id=123",
                "sandbox_init_point": "https://sandbox.mercadopago.com.ar/checkout/v1/redirect?pref_id=123"
            }
        }
        mock_preference.create.return_value = mock_response
        mock_mercadopago.SDK.return_value = mock_sdk_instance
        
        service = MercadoPagoService("test_token", "test_local_id")
        result = service.create_payment_link(
            title="Test Product",
            description="Test Description",
            amount=1000.0,
            currency="ARS"
        )
        
        assert result["success"] is True
        assert result["preference_id"] == "1234567890-abc123"
        assert "payment_link" in result
    
    @patch('langchain_mercadopago_link.mercadopago_service.mercadopago')
    def test_create_payment_link_error(self, mock_mercadopago):
        """Test payment link creation with error."""
        # Mock SDK
        mock_sdk_instance = MagicMock()
        mock_preference = MagicMock()
        mock_sdk_instance.preference.return_value = mock_preference
        
        # Mock error response
        mock_response = {
            "status": 400,
            "message": "Error de validación"
        }
        mock_preference.create.return_value = mock_response
        mock_mercadopago.SDK.return_value = mock_sdk_instance
        
        service = MercadoPagoService("test_token")
        result = service.create_payment_link(
            title="Test Product",
            description="Test Description",
            amount=1000.0
        )
        
        assert result["success"] is False
        assert "error" in result
    
    @patch('langchain_mercadopago_link.mercadopago_service.mercadopago')
    def test_create_payment_link_exception(self, mock_mercadopago):
        """Test exception handling."""
        # Mock SDK that raises exception
        mock_sdk_instance = MagicMock()
        mock_preference = MagicMock()
        mock_sdk_instance.preference.return_value = mock_preference
        mock_preference.create.side_effect = Exception("Network error")
        mock_mercadopago.SDK.return_value = mock_sdk_instance
        
        service = MercadoPagoService("test_token")
        result = service.create_payment_link(
            title="Test Product",
            description="Test Description",
            amount=1000.0
        )
        
        assert result["success"] is False
        assert "error" in result
        assert "Network error" in result["error"]
