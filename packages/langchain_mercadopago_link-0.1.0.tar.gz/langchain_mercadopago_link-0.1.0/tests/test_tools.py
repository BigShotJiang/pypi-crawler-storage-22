"""
Tests for the LangChain Tool.
"""
import pytest
from unittest.mock import Mock, patch, MagicMock
from langchain_mercadopago_link.tools import MercadoPagoPaymentTool, MercadoPagoPaymentToolInput


class TestMercadoPagoPaymentTool:
    """Tests for MercadoPagoPaymentTool."""
    
    @patch('langchain_mercadopago_link.tools.MercadoPagoService')
    def test_init(self, mock_service_class):
        """Test tool initialization."""
        access_token = "test_token"
        local_id = "test_local_id"
        
        tool = MercadoPagoPaymentTool(access_token=access_token, local_id=local_id)
        
        assert tool.access_token == access_token
        assert tool.local_id == local_id
        assert tool.name == "mercadopago_payment_link_generator"
        mock_service_class.assert_called_once_with(access_token, local_id)
    
    @patch('langchain_mercadopago_link.tools.MercadoPagoService')
    def test_service_property(self, mock_service_class):
        """Test the service property."""
        mock_service = MagicMock()
        mock_service_class.return_value = mock_service
        
        tool = MercadoPagoPaymentTool(access_token="test_token")
        service = tool.service
        
        assert service == mock_service
    
    @patch('langchain_mercadopago_link.tools.MercadoPagoService')
    def test_run_success(self, mock_service_class):
        """Test successful tool execution."""
        # Mock service
        mock_service = MagicMock()
        mock_service.create_payment_link.return_value = {
            "success": True,
            "payment_link": "https://www.mercadopago.com.ar/checkout/v1/redirect?pref_id=123",
            "preference_id": "1234567890-abc123"
        }
        mock_service_class.return_value = mock_service
        
        tool = MercadoPagoPaymentTool(access_token="test_token")
        result = tool._run(
            title="Test Product",
            description="Test Description",
            amount=1000.0,
            currency="ARS"
        )
        
        assert "Payment link generated successfully" in result
        assert "1234567890-abc123" in result
        mock_service.create_payment_link.assert_called_once()
    
    @patch('langchain_mercadopago_link.tools.MercadoPagoService')
    def test_run_error(self, mock_service_class):
        """Test tool execution with error."""
        # Mock service with error
        mock_service = MagicMock()
        mock_service.create_payment_link.return_value = {
            "success": False,
            "error": "Error de validación"
        }
        mock_service_class.return_value = mock_service
        
        tool = MercadoPagoPaymentTool(access_token="test_token")
        result = tool._run(
            title="Test Product",
            description="Test Description",
            amount=1000.0
        )
        
        assert "Error generating payment link" in result
        assert "Error de validación" in result
    
    def test_args_schema(self):
        """Test the arguments schema."""
        tool = MercadoPagoPaymentTool(access_token="test_token")
        
        assert tool.args_schema == MercadoPagoPaymentToolInput
        
        # Verify that the schema has the correct fields
        schema_fields = MercadoPagoPaymentToolInput.__fields__
        assert "title" in schema_fields
        assert "description" in schema_fields
        assert "amount" in schema_fields
        assert "currency" in schema_fields
