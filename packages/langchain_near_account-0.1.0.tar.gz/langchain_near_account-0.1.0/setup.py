"""Setup configuration for langchain-near-account package."""
from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Inline requirements to avoid MANIFEST issues
requirements = [
    "langchain>=0.1.0",
    "langchain-core>=0.1.0",
    "pydantic>=2.0.0",
    "py-near>=0.2.0",
    "aiohttp>=3.8.0",
    "typing-extensions>=4.0.0",
]

setup(
    name="langchain-near-account",
    version="0.1.0",
    author="NEAR AI Marketplace",
    author_email="dev@near.ai",
    description="LangChain tools for NEAR Protocol account management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/near/langchain-near-account",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Framework :: AsyncIO",
    ],
    python_requires=">=3.9",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "isort>=5.12.0",
            "mypy>=1.0.0",
        ],
    },
    keywords="langchain near blockchain account management web3 cryptocurrency",
)
