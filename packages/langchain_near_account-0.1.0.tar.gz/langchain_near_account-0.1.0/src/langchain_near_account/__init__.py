"""
LangChain NEAR Account Manager

A comprehensive LangChain toolkit for NEAR Protocol account management operations.
Provides tools for creating accounts, managing access keys, transferring NEAR,
and querying account information.

Example usage:
    from langchain_near_account import NearAccountToolkit
    
    toolkit = NearAccountToolkit(
        account_id="my-account.near",
        private_key="ed25519:...",
        network="mainnet"
    )
    
    tools = toolkit.get_tools()
"""

from langchain_near_account.toolkit import NearAccountToolkit
from langchain_near_account.tools import (
    CreateAccountTool,
    FundAccountTool,
    AddAccessKeyTool,
    DeleteAccessKeyTool,
    ViewAccountTool,
    ListKeysTool,
)
from langchain_near_account.client import NearAccountClient

__version__ = "0.1.0"

__all__ = [
    "NearAccountToolkit",
    "NearAccountClient",
    "CreateAccountTool",
    "FundAccountTool",
    "AddAccessKeyTool",
    "DeleteAccessKeyTool",
    "ViewAccountTool",
    "ListKeysTool",
]
