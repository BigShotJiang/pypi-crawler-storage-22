"""
NEAR Account Client

Async client wrapper for NEAR Protocol operations using py-near.
Provides a clean interface for account management operations.
"""

from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass
import asyncio
import json

from py_near.account import Account
from py_near.dapps.core import NEAR
from py_near.exceptions import RpcError


@dataclass
class AccountInfo:
    """NEAR account information."""
    account_id: str
    amount: str  # Balance in yoctoNEAR
    locked: str  # Locked balance in yoctoNEAR
    code_hash: str
    storage_usage: int
    storage_paid_at: int
    block_height: int
    block_hash: str
    
    @property
    def balance_near(self) -> float:
        """Get balance in NEAR (human-readable)."""
        return int(self.amount) / 10**24
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "account_id": self.account_id,
            "amount": self.amount,
            "balance_near": self.balance_near,
            "locked": self.locked,
            "code_hash": self.code_hash,
            "storage_usage": self.storage_usage,
            "storage_paid_at": self.storage_paid_at,
            "block_height": self.block_height,
            "block_hash": self.block_hash,
        }


@dataclass
class AccessKeyInfo:
    """NEAR access key information."""
    public_key: str
    access_key: Dict[str, Any]
    
    @property
    def is_full_access(self) -> bool:
        """Check if this is a full access key."""
        return self.access_key.get("permission") == "FullAccess"
    
    @property
    def nonce(self) -> int:
        """Get the key nonce."""
        return self.access_key.get("nonce", 0)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "public_key": self.public_key,
            "access_key": self.access_key,
            "is_full_access": self.is_full_access,
            "nonce": self.nonce,
        }


@dataclass
class TransactionResult:
    """Result of a NEAR transaction."""
    transaction_hash: str
    status: str
    receipts_outcome: List[Dict[str, Any]]
    final_execution_status: Optional[str] = None
    
    @property
    def is_successful(self) -> bool:
        """Check if the transaction was successful."""
        return self.status == "success" or "SuccessValue" in str(self.status)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "transaction_hash": self.transaction_hash,
            "status": self.status,
            "is_successful": self.is_successful,
            "receipts_outcome": self.receipts_outcome,
        }


class NearAccountClient:
    """
    Async client for NEAR Protocol account management operations.
    
    This client wraps the py-near library to provide a clean, async interface
    for common account management operations including:
    - Creating new accounts
    - Transferring NEAR tokens
    - Managing access keys (add/remove)
    - Viewing account information
    
    Args:
        account_id: The NEAR account ID to use for signing transactions
        private_key: The private key in ed25519 format (ed25519:...)
        network: Network to connect to ("mainnet", "testnet", or RPC URL)
        
    Example:
        ```python
        client = NearAccountClient(
            account_id="my-account.testnet",
            private_key="ed25519:...",
            network="testnet"
        )
        await client.connect()
        
        # View account info
        info = await client.view_account("target.testnet")
        print(f"Balance: {info.balance_near} NEAR")
        
        await client.disconnect()
        ```
    """
    
    # Network RPC endpoints
    NETWORK_URLS = {
        "mainnet": "https://rpc.mainnet.near.org",
        "testnet": "https://rpc.testnet.near.org",
    }
    
    def __init__(
        self,
        account_id: str,
        private_key: str,
        network: str = "testnet",
    ):
        """Initialize the NEAR account client."""
        self.account_id = account_id
        self.private_key = private_key
        self.network = network
        self.rpc_url = self.NETWORK_URLS.get(network, network)
        self._account: Optional[Account] = None
        self._connected = False
    
    async def connect(self) -> None:
        """
        Establish connection to the NEAR network.
        
        This must be called before any other operations.
        
        Raises:
            ConnectionError: If unable to connect to the RPC endpoint
        """
        try:
            self._account = Account(
                account_id=self.account_id,
                private_key=self.private_key,
                rpc_addr=self.rpc_url,
            )
            await self._account.startup()
            self._connected = True
        except Exception as e:
            raise ConnectionError(f"Failed to connect to NEAR network: {e}")
    
    async def disconnect(self) -> None:
        """Close the connection to the NEAR network."""
        self._connected = False
        self._account = None
    
    def _ensure_connected(self) -> None:
        """Ensure the client is connected."""
        if not self._connected or self._account is None:
            raise RuntimeError("Client not connected. Call connect() first.")
    
    async def create_account(
        self,
        new_account_id: str,
        public_key: str,
        initial_balance: float = 0.1,
    ) -> TransactionResult:
        """
        Create a new NEAR account.
        
        The new account will be created as a sub-account if creating from
        a named account, or via the appropriate registrar for top-level
        accounts.
        
        Args:
            new_account_id: The account ID for the new account
            public_key: The public key for the new account (ed25519:...)
            initial_balance: Initial NEAR balance to fund the account (default: 0.1)
            
        Returns:
            TransactionResult with the transaction details
            
        Raises:
            RuntimeError: If not connected
            ValueError: If account creation fails
            
        Example:
            ```python
            result = await client.create_account(
                new_account_id="sub.my-account.testnet",
                public_key="ed25519:...",
                initial_balance=1.0
            )
            print(f"Account created: {result.transaction_hash}")
            ```
        """
        self._ensure_connected()
        
        try:
            # Convert NEAR to yoctoNEAR
            amount_yocto = int(initial_balance * 10**24)
            
            result = await self._account.create_account(
                account_id=new_account_id,
                public_key=public_key,
                initial_balance=amount_yocto,
            )
            
            return TransactionResult(
                transaction_hash=result.transaction.hash,
                status=str(result.status),
                receipts_outcome=[r.to_dict() if hasattr(r, 'to_dict') else str(r) 
                                  for r in result.receipts_outcome] if hasattr(result, 'receipts_outcome') else [],
            )
        except RpcError as e:
            raise ValueError(f"Failed to create account: {e}")
    
    async def fund_account(
        self,
        receiver_id: str,
        amount: float,
    ) -> TransactionResult:
        """
        Transfer NEAR tokens to another account.
        
        Args:
            receiver_id: The account ID to receive the NEAR
            amount: Amount of NEAR to transfer
            
        Returns:
            TransactionResult with the transaction details
            
        Raises:
            RuntimeError: If not connected
            ValueError: If transfer fails
            
        Example:
            ```python
            result = await client.fund_account(
                receiver_id="recipient.testnet",
                amount=5.0
            )
            print(f"Transferred 5 NEAR: {result.transaction_hash}")
            ```
        """
        self._ensure_connected()
        
        try:
            # Convert NEAR to yoctoNEAR
            amount_yocto = int(amount * 10**24)
            
            result = await self._account.send_money(
                account_id=receiver_id,
                amount=amount_yocto,
            )
            
            return TransactionResult(
                transaction_hash=result.transaction.hash,
                status=str(result.status),
                receipts_outcome=[r.to_dict() if hasattr(r, 'to_dict') else str(r) 
                                  for r in result.receipts_outcome] if hasattr(result, 'receipts_outcome') else [],
            )
        except RpcError as e:
            raise ValueError(f"Failed to transfer NEAR: {e}")
    
    async def add_access_key(
        self,
        public_key: str,
        permission: str = "full_access",
        contract_id: Optional[str] = None,
        method_names: Optional[List[str]] = None,
        allowance: Optional[float] = None,
    ) -> TransactionResult:
        """
        Add an access key to the account.
        
        Can add either a full access key or a function call access key
        with restricted permissions.
        
        Args:
            public_key: The public key to add (ed25519:...)
            permission: "full_access" or "function_call"
            contract_id: For function_call keys, the contract to allow calls to
            method_names: For function_call keys, list of allowed method names
                         (empty list means all methods)
            allowance: For function_call keys, NEAR allowance for gas
            
        Returns:
            TransactionResult with the transaction details
            
        Raises:
            RuntimeError: If not connected
            ValueError: If parameters are invalid or operation fails
            
        Example:
            ```python
            # Add full access key
            result = await client.add_access_key(
                public_key="ed25519:...",
                permission="full_access"
            )
            
            # Add function call key
            result = await client.add_access_key(
                public_key="ed25519:...",
                permission="function_call",
                contract_id="contract.testnet",
                method_names=["deposit", "withdraw"],
                allowance=0.25
            )
            ```
        """
        self._ensure_connected()
        
        try:
            if permission == "full_access":
                result = await self._account.add_full_access_key(
                    public_key=public_key,
                )
            elif permission == "function_call":
                if contract_id is None:
                    raise ValueError("contract_id is required for function_call keys")
                
                # Convert allowance to yoctoNEAR if provided
                allowance_yocto = int(allowance * 10**24) if allowance else None
                
                result = await self._account.add_function_call_access_key(
                    public_key=public_key,
                    receiver_id=contract_id,
                    method_names=method_names or [],
                    allowance=allowance_yocto,
                )
            else:
                raise ValueError(f"Invalid permission type: {permission}")
            
            return TransactionResult(
                transaction_hash=result.transaction.hash,
                status=str(result.status),
                receipts_outcome=[r.to_dict() if hasattr(r, 'to_dict') else str(r) 
                                  for r in result.receipts_outcome] if hasattr(result, 'receipts_outcome') else [],
            )
        except RpcError as e:
            raise ValueError(f"Failed to add access key: {e}")
    
    async def delete_access_key(
        self,
        public_key: str,
    ) -> TransactionResult:
        """
        Remove an access key from the account.
        
        Args:
            public_key: The public key to remove (ed25519:...)
            
        Returns:
            TransactionResult with the transaction details
            
        Raises:
            RuntimeError: If not connected
            ValueError: If key doesn't exist or operation fails
            
        Example:
            ```python
            result = await client.delete_access_key(
                public_key="ed25519:..."
            )
            print(f"Key removed: {result.transaction_hash}")
            ```
        """
        self._ensure_connected()
        
        try:
            result = await self._account.delete_access_key(
                public_key=public_key,
            )
            
            return TransactionResult(
                transaction_hash=result.transaction.hash,
                status=str(result.status),
                receipts_outcome=[r.to_dict() if hasattr(r, 'to_dict') else str(r) 
                                  for r in result.receipts_outcome] if hasattr(result, 'receipts_outcome') else [],
            )
        except RpcError as e:
            raise ValueError(f"Failed to delete access key: {e}")
    
    async def view_account(
        self,
        account_id: Optional[str] = None,
    ) -> AccountInfo:
        """
        Get information about a NEAR account.
        
        Args:
            account_id: The account ID to query (defaults to connected account)
            
        Returns:
            AccountInfo with the account details
            
        Raises:
            RuntimeError: If not connected
            ValueError: If account doesn't exist
            
        Example:
            ```python
            info = await client.view_account("alice.testnet")
            print(f"Balance: {info.balance_near} NEAR")
            print(f"Storage: {info.storage_usage} bytes")
            ```
        """
        self._ensure_connected()
        
        target_account = account_id or self.account_id
        
        try:
            result = await self._account.get_account_details(target_account)
            
            return AccountInfo(
                account_id=target_account,
                amount=str(result.get("amount", "0")),
                locked=str(result.get("locked", "0")),
                code_hash=result.get("code_hash", ""),
                storage_usage=result.get("storage_usage", 0),
                storage_paid_at=result.get("storage_paid_at", 0),
                block_height=result.get("block_height", 0),
                block_hash=result.get("block_hash", ""),
            )
        except RpcError as e:
            raise ValueError(f"Failed to view account: {e}")
    
    async def list_keys(
        self,
        account_id: Optional[str] = None,
    ) -> List[AccessKeyInfo]:
        """
        List all access keys for an account.
        
        Args:
            account_id: The account ID to query (defaults to connected account)
            
        Returns:
            List of AccessKeyInfo objects
            
        Raises:
            RuntimeError: If not connected
            ValueError: If account doesn't exist
            
        Example:
            ```python
            keys = await client.list_keys()
            for key in keys:
                print(f"{key.public_key}: {'Full Access' if key.is_full_access else 'Function Call'}")
            ```
        """
        self._ensure_connected()
        
        target_account = account_id or self.account_id
        
        try:
            result = await self._account.get_access_key_list(target_account)
            
            return [
                AccessKeyInfo(
                    public_key=key.get("public_key", ""),
                    access_key=key.get("access_key", {}),
                )
                for key in result.get("keys", [])
            ]
        except RpcError as e:
            raise ValueError(f"Failed to list access keys: {e}")
    
    async def __aenter__(self) -> "NearAccountClient":
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
