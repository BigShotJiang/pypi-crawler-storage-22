"""
NEAR Account Toolkit for LangChain

This module provides a convenient toolkit class that bundles all NEAR
account management tools together for easy integration with LangChain
agents and chains.
"""

from typing import List, Optional

from langchain_core.tools import BaseTool

from langchain_near_account.client import NearAccountClient
from langchain_near_account.tools import (
    CreateAccountTool,
    FundAccountTool,
    AddAccessKeyTool,
    DeleteAccessKeyTool,
    ViewAccountTool,
    ListKeysTool,
)


class NearAccountToolkit:
    """
    Toolkit for NEAR Protocol account management operations.
    
    This toolkit provides a collection of LangChain tools for managing
    NEAR accounts, including:
    
    - **create_near_account**: Create new NEAR accounts
    - **fund_near_account**: Transfer NEAR tokens
    - **add_near_access_key**: Add full access or function call keys
    - **delete_near_access_key**: Remove access keys
    - **view_near_account**: Get account information
    - **list_near_access_keys**: List all access keys
    
    Args:
        account_id: The NEAR account ID for signing transactions
        private_key: The private key in ed25519 format
        network: Network to use ("mainnet", "testnet", or RPC URL)
        
    Example:
        ```python
        from langchain_near_account import NearAccountToolkit
        from langchain.agents import create_openai_tools_agent
        from langchain_openai import ChatOpenAI
        
        # Initialize toolkit
        toolkit = NearAccountToolkit(
            account_id="my-account.testnet",
            private_key="ed25519:...",
            network="testnet"
        )
        
        # Connect to NEAR
        await toolkit.connect()
        
        # Get tools for agent
        tools = toolkit.get_tools()
        
        # Create agent with tools
        llm = ChatOpenAI(model="gpt-4")
        agent = create_openai_tools_agent(llm, tools, prompt)
        
        # Clean up when done
        await toolkit.disconnect()
        ```
        
    Using as context manager:
        ```python
        async with NearAccountToolkit(
            account_id="my-account.testnet",
            private_key="ed25519:...",
        ) as toolkit:
            tools = toolkit.get_tools()
            # Use tools...
        ```
    """
    
    def __init__(
        self,
        account_id: str,
        private_key: str,
        network: str = "testnet",
    ):
        """
        Initialize the NEAR Account Toolkit.
        
        Args:
            account_id: The NEAR account ID to use for signing
            private_key: The private key (ed25519:...)
            network: Network to connect to
        """
        self.client = NearAccountClient(
            account_id=account_id,
            private_key=private_key,
            network=network,
        )
        self._tools: Optional[List[BaseTool]] = None
    
    async def connect(self) -> None:
        """
        Connect to the NEAR network.
        
        Must be called before using any tools.
        """
        await self.client.connect()
    
    async def disconnect(self) -> None:
        """
        Disconnect from the NEAR network.
        
        Should be called when done using the toolkit.
        """
        await self.client.disconnect()
    
    def get_tools(self) -> List[BaseTool]:
        """
        Get all available NEAR account management tools.
        
        Returns:
            List of LangChain BaseTool instances
            
        Example:
            ```python
            tools = toolkit.get_tools()
            for tool in tools:
                print(f"- {tool.name}: {tool.description}")
            ```
        """
        if self._tools is None:
            self._tools = [
                CreateAccountTool(client=self.client),
                FundAccountTool(client=self.client),
                AddAccessKeyTool(client=self.client),
                DeleteAccessKeyTool(client=self.client),
                ViewAccountTool(client=self.client),
                ListKeysTool(client=self.client),
            ]
        return self._tools
    
    def get_tool(self, name: str) -> Optional[BaseTool]:
        """
        Get a specific tool by name.
        
        Args:
            name: The tool name to retrieve
            
        Returns:
            The tool instance or None if not found
            
        Example:
            ```python
            view_tool = toolkit.get_tool("view_near_account")
            if view_tool:
                result = await view_tool.ainvoke({"account_id": "alice.testnet"})
            ```
        """
        for tool in self.get_tools():
            if tool.name == name:
                return tool
        return None
    
    @property
    def tool_names(self) -> List[str]:
        """Get list of available tool names."""
        return [tool.name for tool in self.get_tools()]
    
    async def __aenter__(self) -> "NearAccountToolkit":
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
