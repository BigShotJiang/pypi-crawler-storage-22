"""
LangChain Tools for NEAR Account Management

This module provides LangChain-compatible tools for managing NEAR Protocol
accounts, including creating accounts, transferring NEAR, and managing
access keys.
"""

from typing import Optional, List, Type, Any
import asyncio
import json

from langchain_core.tools import BaseTool
from langchain_core.callbacks import CallbackManagerForToolRun, AsyncCallbackManagerForToolRun
from pydantic import BaseModel, Field

from langchain_near_account.client import NearAccountClient


class CreateAccountInput(BaseModel):
    """Input schema for CreateAccountTool."""
    
    new_account_id: str = Field(
        description="The NEAR account ID to create (e.g., 'myaccount.testnet' or 'sub.parent.near')"
    )
    public_key: str = Field(
        description="The ed25519 public key for the new account (format: 'ed25519:...')"
    )
    initial_balance: float = Field(
        default=0.1,
        description="Initial NEAR balance to fund the account with (default: 0.1 NEAR)"
    )


class CreateAccountTool(BaseTool):
    """
    Tool for creating new NEAR Protocol accounts.
    
    This tool creates a new NEAR account with the specified account ID,
    public key, and initial balance. The account will be created as a
    sub-account of the signing account.
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = CreateAccountTool(client=near_client)
        result = await tool.ainvoke({
            "new_account_id": "myapp.myaccount.testnet",
            "public_key": "ed25519:...",
            "initial_balance": 1.0
        })
        ```
    """
    
    name: str = "create_near_account"
    description: str = (
        "Create a new NEAR Protocol account. "
        "Requires a unique account ID, public key, and optional initial balance. "
        "Returns transaction hash on success."
    )
    args_schema: Type[BaseModel] = CreateAccountInput
    client: NearAccountClient
    
    def _run(
        self,
        new_account_id: str,
        public_key: str,
        initial_balance: float = 0.1,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(new_account_id, public_key, initial_balance, run_manager=None)
        )
    
    async def _arun(
        self,
        new_account_id: str,
        public_key: str,
        initial_balance: float = 0.1,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously create a new NEAR account.
        
        Args:
            new_account_id: The account ID to create
            public_key: The public key for the account
            initial_balance: Initial NEAR balance
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with transaction result
        """
        try:
            result = await self.client.create_account(
                new_account_id=new_account_id,
                public_key=public_key,
                initial_balance=initial_balance,
            )
            return json.dumps({
                "success": True,
                "account_id": new_account_id,
                "transaction_hash": result.transaction_hash,
                "initial_balance": initial_balance,
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })


class FundAccountInput(BaseModel):
    """Input schema for FundAccountTool."""
    
    receiver_id: str = Field(
        description="The NEAR account ID to receive the funds"
    )
    amount: float = Field(
        description="Amount of NEAR to transfer"
    )


class FundAccountTool(BaseTool):
    """
    Tool for transferring NEAR tokens to another account.
    
    This tool sends NEAR tokens from the connected account to a
    specified receiver account.
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = FundAccountTool(client=near_client)
        result = await tool.ainvoke({
            "receiver_id": "recipient.testnet",
            "amount": 5.0
        })
        ```
    """
    
    name: str = "fund_near_account"
    description: str = (
        "Transfer NEAR tokens to another account. "
        "Specify the receiver account ID and amount in NEAR. "
        "Returns transaction hash on success."
    )
    args_schema: Type[BaseModel] = FundAccountInput
    client: NearAccountClient
    
    def _run(
        self,
        receiver_id: str,
        amount: float,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(receiver_id, amount, run_manager=None)
        )
    
    async def _arun(
        self,
        receiver_id: str,
        amount: float,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously transfer NEAR to another account.
        
        Args:
            receiver_id: The account to receive NEAR
            amount: Amount of NEAR to transfer
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with transaction result
        """
        try:
            result = await self.client.fund_account(
                receiver_id=receiver_id,
                amount=amount,
            )
            return json.dumps({
                "success": True,
                "receiver_id": receiver_id,
                "amount": amount,
                "transaction_hash": result.transaction_hash,
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })


class AddAccessKeyInput(BaseModel):
    """Input schema for AddAccessKeyTool."""
    
    public_key: str = Field(
        description="The ed25519 public key to add (format: 'ed25519:...')"
    )
    permission: str = Field(
        default="full_access",
        description="Permission type: 'full_access' or 'function_call'"
    )
    contract_id: Optional[str] = Field(
        default=None,
        description="For function_call keys: the contract ID to allow calls to"
    )
    method_names: Optional[List[str]] = Field(
        default=None,
        description="For function_call keys: list of allowed method names (empty for all methods)"
    )
    allowance: Optional[float] = Field(
        default=None,
        description="For function_call keys: NEAR allowance for gas fees"
    )


class AddAccessKeyTool(BaseTool):
    """
    Tool for adding access keys to a NEAR account.
    
    This tool can add either full access keys (complete account control)
    or function call keys (restricted to specific contract calls).
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = AddAccessKeyTool(client=near_client)
        
        # Add full access key
        result = await tool.ainvoke({
            "public_key": "ed25519:...",
            "permission": "full_access"
        })
        
        # Add function call key
        result = await tool.ainvoke({
            "public_key": "ed25519:...",
            "permission": "function_call",
            "contract_id": "contract.testnet",
            "method_names": ["deposit", "withdraw"],
            "allowance": 0.25
        })
        ```
    """
    
    name: str = "add_near_access_key"
    description: str = (
        "Add an access key to the NEAR account. "
        "Can add full access keys (complete control) or function call keys "
        "(restricted to specific contract methods). "
        "Returns transaction hash on success."
    )
    args_schema: Type[BaseModel] = AddAccessKeyInput
    client: NearAccountClient
    
    def _run(
        self,
        public_key: str,
        permission: str = "full_access",
        contract_id: Optional[str] = None,
        method_names: Optional[List[str]] = None,
        allowance: Optional[float] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(public_key, permission, contract_id, method_names, allowance, run_manager=None)
        )
    
    async def _arun(
        self,
        public_key: str,
        permission: str = "full_access",
        contract_id: Optional[str] = None,
        method_names: Optional[List[str]] = None,
        allowance: Optional[float] = None,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously add an access key to the account.
        
        Args:
            public_key: The public key to add
            permission: Permission type
            contract_id: Contract ID for function call keys
            method_names: Allowed method names for function call keys
            allowance: NEAR allowance for function call keys
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with transaction result
        """
        try:
            result = await self.client.add_access_key(
                public_key=public_key,
                permission=permission,
                contract_id=contract_id,
                method_names=method_names,
                allowance=allowance,
            )
            return json.dumps({
                "success": True,
                "public_key": public_key,
                "permission": permission,
                "contract_id": contract_id,
                "transaction_hash": result.transaction_hash,
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })


class DeleteAccessKeyInput(BaseModel):
    """Input schema for DeleteAccessKeyTool."""
    
    public_key: str = Field(
        description="The ed25519 public key to remove (format: 'ed25519:...')"
    )


class DeleteAccessKeyTool(BaseTool):
    """
    Tool for removing access keys from a NEAR account.
    
    This tool removes an existing access key from the connected account.
    Use with caution - removing all full access keys will lock the account.
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = DeleteAccessKeyTool(client=near_client)
        result = await tool.ainvoke({
            "public_key": "ed25519:..."
        })
        ```
    """
    
    name: str = "delete_near_access_key"
    description: str = (
        "Remove an access key from the NEAR account. "
        "WARNING: Removing all full access keys will lock the account permanently. "
        "Returns transaction hash on success."
    )
    args_schema: Type[BaseModel] = DeleteAccessKeyInput
    client: NearAccountClient
    
    def _run(
        self,
        public_key: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(public_key, run_manager=None)
        )
    
    async def _arun(
        self,
        public_key: str,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously remove an access key from the account.
        
        Args:
            public_key: The public key to remove
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with transaction result
        """
        try:
            result = await self.client.delete_access_key(
                public_key=public_key,
            )
            return json.dumps({
                "success": True,
                "public_key": public_key,
                "transaction_hash": result.transaction_hash,
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })


class ViewAccountInput(BaseModel):
    """Input schema for ViewAccountTool."""
    
    account_id: Optional[str] = Field(
        default=None,
        description="The NEAR account ID to view (defaults to connected account)"
    )


class ViewAccountTool(BaseTool):
    """
    Tool for viewing NEAR account information.
    
    This tool retrieves detailed information about a NEAR account including
    balance, storage usage, and other metadata.
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = ViewAccountTool(client=near_client)
        result = await tool.ainvoke({
            "account_id": "alice.testnet"
        })
        ```
    """
    
    name: str = "view_near_account"
    description: str = (
        "Get information about a NEAR account including balance, "
        "storage usage, and code hash. "
        "Returns account details in JSON format."
    )
    args_schema: Type[BaseModel] = ViewAccountInput
    client: NearAccountClient
    
    def _run(
        self,
        account_id: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(account_id, run_manager=None)
        )
    
    async def _arun(
        self,
        account_id: Optional[str] = None,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously retrieve account information.
        
        Args:
            account_id: The account ID to query
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with account information
        """
        try:
            info = await self.client.view_account(account_id=account_id)
            return json.dumps({
                "success": True,
                **info.to_dict(),
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })


class ListKeysInput(BaseModel):
    """Input schema for ListKeysTool."""
    
    account_id: Optional[str] = Field(
        default=None,
        description="The NEAR account ID to list keys for (defaults to connected account)"
    )


class ListKeysTool(BaseTool):
    """
    Tool for listing all access keys on a NEAR account.
    
    This tool retrieves all access keys (both full access and function call)
    associated with a NEAR account.
    
    Attributes:
        name: The tool name for LangChain
        description: Description of what the tool does
        client: The NearAccountClient instance to use
        
    Example:
        ```python
        tool = ListKeysTool(client=near_client)
        result = await tool.ainvoke({
            "account_id": "alice.testnet"
        })
        ```
    """
    
    name: str = "list_near_access_keys"
    description: str = (
        "List all access keys for a NEAR account. "
        "Returns public keys with their permission types "
        "(full access or function call with details)."
    )
    args_schema: Type[BaseModel] = ListKeysInput
    client: NearAccountClient
    
    def _run(
        self,
        account_id: Optional[str] = None,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        """Synchronous execution - wraps async method."""
        return asyncio.get_event_loop().run_until_complete(
            self._arun(account_id, run_manager=None)
        )
    
    async def _arun(
        self,
        account_id: Optional[str] = None,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        """
        Asynchronously list all access keys for an account.
        
        Args:
            account_id: The account ID to query
            run_manager: Callback manager for the tool run
            
        Returns:
            JSON string with list of access keys
        """
        try:
            keys = await self.client.list_keys(account_id=account_id)
            return json.dumps({
                "success": True,
                "account_id": account_id or self.client.account_id,
                "keys": [key.to_dict() for key in keys],
                "total_keys": len(keys),
            })
        except Exception as e:
            return json.dumps({
                "success": False,
                "error": str(e),
            })
