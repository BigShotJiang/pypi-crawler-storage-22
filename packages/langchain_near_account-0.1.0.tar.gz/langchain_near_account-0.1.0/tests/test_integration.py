"""
Integration tests for NEAR Account LangChain Tools.

These tests require:
1. A valid NEAR testnet account
2. Network connectivity
3. Environment variables:
   - NEAR_ACCOUNT_ID: Your testnet account ID
   - NEAR_PRIVATE_KEY: Your account's private key

Run with: pytest tests/test_integration.py -m integration
"""

import os
import pytest
import json

from langchain_near_account import NearAccountToolkit


# Skip all tests if credentials not available
pytestmark = pytest.mark.integration

# Check for required environment variables
NEAR_ACCOUNT_ID = os.environ.get("NEAR_ACCOUNT_ID")
NEAR_PRIVATE_KEY = os.environ.get("NEAR_PRIVATE_KEY")

skip_reason = "NEAR credentials not configured"
requires_credentials = pytest.mark.skipif(
    not (NEAR_ACCOUNT_ID and NEAR_PRIVATE_KEY),
    reason=skip_reason
)


@pytest.fixture
async def toolkit():
    """Create and connect a toolkit for testing."""
    if not (NEAR_ACCOUNT_ID and NEAR_PRIVATE_KEY):
        pytest.skip(skip_reason)
    
    tk = NearAccountToolkit(
        account_id=NEAR_ACCOUNT_ID,
        private_key=NEAR_PRIVATE_KEY,
        network="testnet",
    )
    await tk.connect()
    yield tk
    await tk.disconnect()


@requires_credentials
class TestIntegrationViewAccount:
    """Integration tests for viewing accounts."""
    
    @pytest.mark.asyncio
    async def test_view_own_account(self, toolkit):
        """Test viewing own account information."""
        tool = toolkit.get_tool("view_near_account")
        result = await tool.ainvoke({})
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["account_id"] == NEAR_ACCOUNT_ID
        assert float(data["balance_near"]) >= 0
    
    @pytest.mark.asyncio
    async def test_view_known_account(self, toolkit):
        """Test viewing a known public account."""
        tool = toolkit.get_tool("view_near_account")
        result = await tool.ainvoke({"account_id": "near.testnet"})
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["account_id"] == "near.testnet"
    
    @pytest.mark.asyncio
    async def test_view_nonexistent_account(self, toolkit):
        """Test viewing a nonexistent account returns error."""
        tool = toolkit.get_tool("view_near_account")
        result = await tool.ainvoke({
            "account_id": "this-account-definitely-does-not-exist-12345.testnet"
        })
        
        data = json.loads(result)
        assert data["success"] is False
        assert "error" in data


@requires_credentials
class TestIntegrationListKeys:
    """Integration tests for listing access keys."""
    
    @pytest.mark.asyncio
    async def test_list_own_keys(self, toolkit):
        """Test listing own account keys."""
        tool = toolkit.get_tool("list_near_access_keys")
        result = await tool.ainvoke({})
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["total_keys"] >= 1  # Should have at least the signing key
        assert len(data["keys"]) >= 1
    
    @pytest.mark.asyncio
    async def test_list_keys_has_full_access(self, toolkit):
        """Test that own account has at least one full access key."""
        tool = toolkit.get_tool("list_near_access_keys")
        result = await tool.ainvoke({})
        
        data = json.loads(result)
        
        full_access_keys = [k for k in data["keys"] if k["is_full_access"]]
        assert len(full_access_keys) >= 1, "Account should have at least one full access key"


@requires_credentials
class TestIntegrationReadOnly:
    """Integration tests that only read data (safe to run)."""
    
    @pytest.mark.asyncio
    async def test_toolkit_connects(self, toolkit):
        """Test that toolkit connects successfully."""
        assert toolkit.client._connected is True
    
    @pytest.mark.asyncio
    async def test_all_tools_available(self, toolkit):
        """Test all expected tools are available."""
        tools = toolkit.get_tools()
        assert len(tools) == 6
        
        expected_names = [
            "create_near_account",
            "fund_near_account",
            "add_near_access_key",
            "delete_near_access_key",
            "view_near_account",
            "list_near_access_keys",
        ]
        
        actual_names = [t.name for t in tools]
        for name in expected_names:
            assert name in actual_names, f"Missing tool: {name}"


# Note: Tests for create_account, fund_account, add/delete_access_key
# are not included as integration tests because they would:
# 1. Cost NEAR tokens
# 2. Create state on testnet
# 3. Potentially lock accounts if not careful
#
# These operations are thoroughly tested via unit tests with mocks.
