"""
Unit tests for NEAR Account LangChain Tools.

Uses pytest and pytest-asyncio for async test support.
Tests use mocking to avoid actual NEAR network calls.
"""

import pytest
import json
from unittest.mock import AsyncMock, MagicMock, patch

from langchain_near_account import (
    NearAccountToolkit,
    NearAccountClient,
    CreateAccountTool,
    FundAccountTool,
    AddAccessKeyTool,
    DeleteAccessKeyTool,
    ViewAccountTool,
    ListKeysTool,
)
from langchain_near_account.client import (
    AccountInfo,
    AccessKeyInfo,
    TransactionResult,
)


# Test fixtures
@pytest.fixture
def mock_client():
    """Create a mock NearAccountClient."""
    client = MagicMock(spec=NearAccountClient)
    client.account_id = "test.testnet"
    client._connected = True
    return client


@pytest.fixture
def sample_transaction_result():
    """Create a sample transaction result."""
    return TransactionResult(
        transaction_hash="9Xyz123ABC...",
        status="success",
        receipts_outcome=[],
    )


@pytest.fixture
def sample_account_info():
    """Create sample account info."""
    return AccountInfo(
        account_id="test.testnet",
        amount="1000000000000000000000000",  # 1 NEAR
        locked="0",
        code_hash="11111111111111111111111111111111",
        storage_usage=100,
        storage_paid_at=0,
        block_height=12345678,
        block_hash="ABCD1234...",
    )


@pytest.fixture
def sample_access_keys():
    """Create sample access key list."""
    return [
        AccessKeyInfo(
            public_key="ed25519:ABC123...",
            access_key={"nonce": 1, "permission": "FullAccess"},
        ),
        AccessKeyInfo(
            public_key="ed25519:DEF456...",
            access_key={
                "nonce": 5,
                "permission": {
                    "FunctionCall": {
                        "allowance": "250000000000000000000000",
                        "receiver_id": "contract.testnet",
                        "method_names": ["deposit", "withdraw"],
                    }
                }
            },
        ),
    ]


class TestCreateAccountTool:
    """Tests for CreateAccountTool."""
    
    @pytest.mark.asyncio
    async def test_create_account_success(self, mock_client, sample_transaction_result):
        """Test successful account creation."""
        mock_client.create_account = AsyncMock(return_value=sample_transaction_result)
        
        tool = CreateAccountTool(client=mock_client)
        result = await tool._arun(
            new_account_id="new.testnet",
            public_key="ed25519:ABC123...",
            initial_balance=0.5,
        )
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["account_id"] == "new.testnet"
        assert data["transaction_hash"] == "9Xyz123ABC..."
        assert data["initial_balance"] == 0.5
        
        mock_client.create_account.assert_called_once_with(
            new_account_id="new.testnet",
            public_key="ed25519:ABC123...",
            initial_balance=0.5,
        )
    
    @pytest.mark.asyncio
    async def test_create_account_failure(self, mock_client):
        """Test account creation failure."""
        mock_client.create_account = AsyncMock(
            side_effect=ValueError("Account already exists")
        )
        
        tool = CreateAccountTool(client=mock_client)
        result = await tool._arun(
            new_account_id="existing.testnet",
            public_key="ed25519:ABC123...",
        )
        
        data = json.loads(result)
        assert data["success"] is False
        assert "Account already exists" in data["error"]
    
    def test_tool_metadata(self, mock_client):
        """Test tool has correct metadata."""
        tool = CreateAccountTool(client=mock_client)
        
        assert tool.name == "create_near_account"
        assert "Create" in tool.description
        assert "NEAR" in tool.description


class TestFundAccountTool:
    """Tests for FundAccountTool."""
    
    @pytest.mark.asyncio
    async def test_fund_account_success(self, mock_client, sample_transaction_result):
        """Test successful NEAR transfer."""
        mock_client.fund_account = AsyncMock(return_value=sample_transaction_result)
        
        tool = FundAccountTool(client=mock_client)
        result = await tool._arun(
            receiver_id="recipient.testnet",
            amount=10.0,
        )
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["receiver_id"] == "recipient.testnet"
        assert data["amount"] == 10.0
        assert data["transaction_hash"] == "9Xyz123ABC..."
    
    @pytest.mark.asyncio
    async def test_fund_account_insufficient_balance(self, mock_client):
        """Test transfer with insufficient balance."""
        mock_client.fund_account = AsyncMock(
            side_effect=ValueError("Insufficient balance")
        )
        
        tool = FundAccountTool(client=mock_client)
        result = await tool._arun(
            receiver_id="recipient.testnet",
            amount=1000000.0,
        )
        
        data = json.loads(result)
        assert data["success"] is False
        assert "Insufficient balance" in data["error"]


class TestAddAccessKeyTool:
    """Tests for AddAccessKeyTool."""
    
    @pytest.mark.asyncio
    async def test_add_full_access_key(self, mock_client, sample_transaction_result):
        """Test adding full access key."""
        mock_client.add_access_key = AsyncMock(return_value=sample_transaction_result)
        
        tool = AddAccessKeyTool(client=mock_client)
        result = await tool._arun(
            public_key="ed25519:NewKey123...",
            permission="full_access",
        )
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["public_key"] == "ed25519:NewKey123..."
        assert data["permission"] == "full_access"
        
        mock_client.add_access_key.assert_called_once_with(
            public_key="ed25519:NewKey123...",
            permission="full_access",
            contract_id=None,
            method_names=None,
            allowance=None,
        )
    
    @pytest.mark.asyncio
    async def test_add_function_call_key(self, mock_client, sample_transaction_result):
        """Test adding function call access key."""
        mock_client.add_access_key = AsyncMock(return_value=sample_transaction_result)
        
        tool = AddAccessKeyTool(client=mock_client)
        result = await tool._arun(
            public_key="ed25519:FunctionKey123...",
            permission="function_call",
            contract_id="contract.testnet",
            method_names=["deposit", "withdraw"],
            allowance=0.25,
        )
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["permission"] == "function_call"
        assert data["contract_id"] == "contract.testnet"
        
        mock_client.add_access_key.assert_called_once_with(
            public_key="ed25519:FunctionKey123...",
            permission="function_call",
            contract_id="contract.testnet",
            method_names=["deposit", "withdraw"],
            allowance=0.25,
        )


class TestDeleteAccessKeyTool:
    """Tests for DeleteAccessKeyTool."""
    
    @pytest.mark.asyncio
    async def test_delete_access_key_success(self, mock_client, sample_transaction_result):
        """Test successful key deletion."""
        mock_client.delete_access_key = AsyncMock(return_value=sample_transaction_result)
        
        tool = DeleteAccessKeyTool(client=mock_client)
        result = await tool._arun(
            public_key="ed25519:OldKey123...",
        )
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["public_key"] == "ed25519:OldKey123..."
        assert data["transaction_hash"] == "9Xyz123ABC..."
    
    @pytest.mark.asyncio
    async def test_delete_nonexistent_key(self, mock_client):
        """Test deleting a key that doesn't exist."""
        mock_client.delete_access_key = AsyncMock(
            side_effect=ValueError("Access key not found")
        )
        
        tool = DeleteAccessKeyTool(client=mock_client)
        result = await tool._arun(
            public_key="ed25519:NonexistentKey...",
        )
        
        data = json.loads(result)
        assert data["success"] is False
        assert "Access key not found" in data["error"]


class TestViewAccountTool:
    """Tests for ViewAccountTool."""
    
    @pytest.mark.asyncio
    async def test_view_account_success(self, mock_client, sample_account_info):
        """Test successful account view."""
        mock_client.view_account = AsyncMock(return_value=sample_account_info)
        
        tool = ViewAccountTool(client=mock_client)
        result = await tool._arun(account_id="test.testnet")
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["account_id"] == "test.testnet"
        assert data["balance_near"] == 1.0
        assert data["storage_usage"] == 100
    
    @pytest.mark.asyncio
    async def test_view_nonexistent_account(self, mock_client):
        """Test viewing a nonexistent account."""
        mock_client.view_account = AsyncMock(
            side_effect=ValueError("Account does not exist")
        )
        
        tool = ViewAccountTool(client=mock_client)
        result = await tool._arun(account_id="nonexistent.testnet")
        
        data = json.loads(result)
        assert data["success"] is False
        assert "Account does not exist" in data["error"]
    
    @pytest.mark.asyncio
    async def test_view_own_account(self, mock_client, sample_account_info):
        """Test viewing own account when no account_id specified."""
        mock_client.view_account = AsyncMock(return_value=sample_account_info)
        
        tool = ViewAccountTool(client=mock_client)
        result = await tool._arun()
        
        data = json.loads(result)
        assert data["success"] is True
        
        # Should call with None to use default account
        mock_client.view_account.assert_called_once_with(account_id=None)


class TestListKeysTool:
    """Tests for ListKeysTool."""
    
    @pytest.mark.asyncio
    async def test_list_keys_success(self, mock_client, sample_access_keys):
        """Test successful key listing."""
        mock_client.list_keys = AsyncMock(return_value=sample_access_keys)
        
        tool = ListKeysTool(client=mock_client)
        result = await tool._arun(account_id="test.testnet")
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["total_keys"] == 2
        assert len(data["keys"]) == 2
        
        # Check first key (full access)
        assert data["keys"][0]["is_full_access"] is True
        
        # Check second key (function call)
        assert data["keys"][1]["is_full_access"] is False
    
    @pytest.mark.asyncio
    async def test_list_keys_empty(self, mock_client):
        """Test listing keys for account with no keys."""
        mock_client.list_keys = AsyncMock(return_value=[])
        
        tool = ListKeysTool(client=mock_client)
        result = await tool._arun(account_id="empty.testnet")
        
        data = json.loads(result)
        assert data["success"] is True
        assert data["total_keys"] == 0
        assert data["keys"] == []


class TestNearAccountToolkit:
    """Tests for NearAccountToolkit."""
    
    def test_toolkit_initialization(self):
        """Test toolkit initializes correctly."""
        toolkit = NearAccountToolkit(
            account_id="test.testnet",
            private_key="ed25519:ABC123...",
            network="testnet",
        )
        
        assert toolkit.client.account_id == "test.testnet"
        assert toolkit.client.network == "testnet"
    
    def test_get_tools_returns_all_tools(self):
        """Test get_tools returns all expected tools."""
        toolkit = NearAccountToolkit(
            account_id="test.testnet",
            private_key="ed25519:ABC123...",
        )
        
        tools = toolkit.get_tools()
        
        assert len(tools) == 6
        
        tool_names = [tool.name for tool in tools]
        assert "create_near_account" in tool_names
        assert "fund_near_account" in tool_names
        assert "add_near_access_key" in tool_names
        assert "delete_near_access_key" in tool_names
        assert "view_near_account" in tool_names
        assert "list_near_access_keys" in tool_names
    
    def test_get_tool_by_name(self):
        """Test retrieving specific tool by name."""
        toolkit = NearAccountToolkit(
            account_id="test.testnet",
            private_key="ed25519:ABC123...",
        )
        
        view_tool = toolkit.get_tool("view_near_account")
        assert view_tool is not None
        assert view_tool.name == "view_near_account"
        
        # Test non-existent tool
        missing = toolkit.get_tool("nonexistent_tool")
        assert missing is None
    
    def test_tool_names_property(self):
        """Test tool_names property."""
        toolkit = NearAccountToolkit(
            account_id="test.testnet",
            private_key="ed25519:ABC123...",
        )
        
        names = toolkit.tool_names
        assert len(names) == 6
        assert all(isinstance(name, str) for name in names)
    
    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test toolkit works as async context manager."""
        with patch.object(NearAccountClient, 'connect', new_callable=AsyncMock) as mock_connect:
            with patch.object(NearAccountClient, 'disconnect', new_callable=AsyncMock) as mock_disconnect:
                async with NearAccountToolkit(
                    account_id="test.testnet",
                    private_key="ed25519:ABC123...",
                ) as toolkit:
                    mock_connect.assert_called_once()
                    assert toolkit is not None
                
                mock_disconnect.assert_called_once()


class TestAccountInfo:
    """Tests for AccountInfo dataclass."""
    
    def test_balance_near_conversion(self):
        """Test yoctoNEAR to NEAR conversion."""
        info = AccountInfo(
            account_id="test.testnet",
            amount="5000000000000000000000000",  # 5 NEAR
            locked="0",
            code_hash="11111111111111111111111111111111",
            storage_usage=100,
            storage_paid_at=0,
            block_height=12345678,
            block_hash="ABCD1234...",
        )
        
        assert info.balance_near == 5.0
    
    def test_to_dict(self):
        """Test AccountInfo to_dict method."""
        info = AccountInfo(
            account_id="test.testnet",
            amount="1000000000000000000000000",
            locked="0",
            code_hash="11111111111111111111111111111111",
            storage_usage=100,
            storage_paid_at=0,
            block_height=12345678,
            block_hash="ABCD1234...",
        )
        
        d = info.to_dict()
        assert d["account_id"] == "test.testnet"
        assert d["balance_near"] == 1.0
        assert "amount" in d
        assert "storage_usage" in d


class TestAccessKeyInfo:
    """Tests for AccessKeyInfo dataclass."""
    
    def test_full_access_key(self):
        """Test full access key detection."""
        key = AccessKeyInfo(
            public_key="ed25519:ABC123...",
            access_key={"nonce": 1, "permission": "FullAccess"},
        )
        
        assert key.is_full_access is True
        assert key.nonce == 1
    
    def test_function_call_key(self):
        """Test function call key detection."""
        key = AccessKeyInfo(
            public_key="ed25519:DEF456...",
            access_key={
                "nonce": 5,
                "permission": {
                    "FunctionCall": {
                        "allowance": "250000000000000000000000",
                        "receiver_id": "contract.testnet",
                        "method_names": [],
                    }
                }
            },
        )
        
        assert key.is_full_access is False
        assert key.nonce == 5


class TestTransactionResult:
    """Tests for TransactionResult dataclass."""
    
    def test_successful_transaction(self):
        """Test successful transaction detection."""
        result = TransactionResult(
            transaction_hash="9Xyz123ABC...",
            status="success",
            receipts_outcome=[],
        )
        
        assert result.is_successful is True
    
    def test_failed_transaction(self):
        """Test failed transaction detection."""
        result = TransactionResult(
            transaction_hash="9Xyz123ABC...",
            status="Failure",
            receipts_outcome=[],
        )
        
        assert result.is_successful is False
    
    def test_to_dict(self):
        """Test TransactionResult to_dict method."""
        result = TransactionResult(
            transaction_hash="9Xyz123ABC...",
            status="success",
            receipts_outcome=[{"id": "1"}],
        )
        
        d = result.to_dict()
        assert d["transaction_hash"] == "9Xyz123ABC..."
        assert d["is_successful"] is True
        assert d["receipts_outcome"] == [{"id": "1"}]
