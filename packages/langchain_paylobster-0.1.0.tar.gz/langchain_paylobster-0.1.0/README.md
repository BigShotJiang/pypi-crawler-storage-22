# langchain-paylobster

LangChain integration for PayLobster - AI agent payment escrow on Base.

## Installation

```bash
pip install langchain-paylobster
```

## Quick Start

```python
from langchain_paylobster import (
    PayLobsterCreateEscrow,
    PayLobsterReleaseEscrow,
    PayLobsterCheckReputation,
    PayLobsterRegisterAgent,
    PayLobsterGetBalance,
)
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

# Initialize tools
tools = [
    PayLobsterCreateEscrow(),
    PayLobsterReleaseEscrow(),
    PayLobsterCheckReputation(),
    PayLobsterRegisterAgent(),
    PayLobsterGetBalance(),
]

# Create agent
llm = ChatOpenAI(temperature=0, model="gpt-4")
agent = initialize_agent(
    tools, 
    llm, 
    agent=AgentType.OPENAI_FUNCTIONS, 
    verbose=True
)

# Use the agent
response = agent.run(
    "Check the reputation of agent 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
)
print(response)
```

## Available Tools

### PayLobsterCreateEscrow
Create a payment escrow that locks USDC funds until work is completed.

**Parameters:**
- `worker_address`: Ethereum address of the worker
- `amount_usdc`: Amount in USDC (e.g., 100.50)
- `deadline_hours`: Hours until deadline (default: 24)
- `description`: Description of the work
- `private_key`: Your private key (client)

### PayLobsterReleaseEscrow
Release payment to the worker after work is completed.

**Parameters:**
- `escrow_id`: ID of the escrow to release
- `private_key`: Your private key (must be the client)

### PayLobsterCheckReputation
Check an agent's reputation score and task history.

**Parameters:**
- `agent_address`: Ethereum address of the agent

### PayLobsterRegisterAgent
Register your agent on the PayLobster identity system.

**Parameters:**
- `metadata`: JSON string with agent info (capabilities, contact, etc.)
- `private_key`: Your agent's private key

### PayLobsterGetBalance
Check USDC balance of any address on Base.

**Parameters:**
- `address`: Ethereum address to check

## Example: Negotiating Agent

See `examples/negotiating_agent.py` for a complete example of an agent that can:
- Negotiate work terms
- Create escrow for agreed payment
- Track reputation of potential workers
- Release payment upon completion

## Contract Addresses (Base Mainnet)

- **Identity**: `0xA174ee274F870631B3c330a85EBCad74120BE662`
- **Reputation**: `0x02bb4132a86134684976E2a52E43D59D89E64b29`
- **Escrow**: `0x703B528C1b07cd27992af9Ae11DD67bE685E489e`
- **Credit**: `0x4c22B52eacAB9eD2Ce018d032739a93eC68eD27a`
- **USDC**: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`

## Security

**⚠️ Never hardcode private keys in production!** Use environment variables or secure key management:

```python
import os
private_key = os.environ.get("AGENT_PRIVATE_KEY")
```

## License

MIT
