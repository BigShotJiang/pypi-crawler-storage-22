"""
Example: LangChain agent that can negotiate work and handle PayLobster payments.

This agent can:
- Check worker reputation before hiring
- Create escrow for agreed work
- Release payment after completion
"""

import os
from langchain_paylobster import (
    PayLobsterCreateEscrow,
    PayLobsterReleaseEscrow,
    PayLobsterCheckReputation,
    PayLobsterGetBalance,
)
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

# Initialize PayLobster tools
tools = [
    PayLobsterCreateEscrow(),
    PayLobsterReleaseEscrow(),
    PayLobsterCheckReputation(),
    PayLobsterGetBalance(),
]

# Create agent with GPT-4
llm = ChatOpenAI(temperature=0, model="gpt-4")
agent = initialize_agent(
    tools,
    llm,
    agent=AgentType.OPENAI_FUNCTIONS,
    verbose=True,
    agent_kwargs={
        "system_message": """You are a PayLobster payment agent. You help negotiate work 
        agreements and handle secure escrow payments. Always check worker reputation before 
        creating escrow. Be professional and clear about payment terms."""
    },
)


def main():
    # Scenario: Hiring a worker to analyze a dataset
    worker_address = "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
    client_key = os.environ.get("CLIENT_PRIVATE_KEY")

    if not client_key:
        print("Error: Set CLIENT_PRIVATE_KEY environment variable")
        return

    # Step 1: Check worker reputation
    print("\n=== Step 1: Checking Worker Reputation ===")
    reputation_response = agent.run(
        f"Check the reputation of the worker at address {worker_address}. "
        "Tell me if they are trustworthy based on their completed tasks and success rate."
    )
    print(reputation_response)

    # Step 2: Negotiate and create escrow
    print("\n=== Step 2: Creating Escrow ===")
    escrow_response = agent.run(
        f"""The worker has agreed to analyze our dataset for $150 USDC, 
        due in 48 hours. Create an escrow with:
        - Worker: {worker_address}
        - Amount: 150 USDC
        - Deadline: 48 hours
        - Description: "Data analysis of Q4 sales dataset"
        - My private key: {client_key}
        
        Confirm the escrow was created and give me the escrow ID."""
    )
    print(escrow_response)

    # Step 3: Later, after work is done, release payment
    # (In practice, you'd wait for the work to be completed)
    print("\n=== Step 3: Release Payment (after work is done) ===")
    print("Simulated: Work has been completed and verified.")

    # Extract escrow ID from previous response (in practice, store this properly)
    # For demo purposes, let's assume escrow ID is 1
    escrow_id = 1

    release_response = agent.run(
        f"""The worker has completed the data analysis and delivered the results. 
        Release the payment from escrow ID {escrow_id} using my private key: {client_key}"""
    )
    print(release_response)


if __name__ == "__main__":
    main()
