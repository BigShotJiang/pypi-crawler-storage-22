"""PayLobster contract addresses and minimal ABIs for Base mainnet."""

from typing import Dict, Any

# Base mainnet contract addresses
CONTRACTS = {
    "IDENTITY": "0xA174ee274F870631B3c330a85EBCad74120BE662",
    "REPUTATION": "0x02bb4132a86134684976E2a52E43D59D89E64b29",
    "ESCROW": "0x703B528C1b07cd27992af9Ae11DD67bE685E489e",
    "CREDIT": "0x4c22B52eacAB9eD2Ce018d032739a93eC68eD27a",
    "USDC": "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
}

# Base mainnet RPC
BASE_RPC_URL = "https://mainnet.base.org"

# Minimal ABIs - only the functions we need
IDENTITY_ABI: list[Dict[str, Any]] = [
    {
        "inputs": [{"name": "metadata", "type": "string"}],
        "name": "register",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function",
    },
    {
        "inputs": [{"name": "agent", "type": "address"}],
        "name": "isRegistered",
        "outputs": [{"name": "", "type": "bool"}],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [{"name": "agent", "type": "address"}],
        "name": "getMetadata",
        "outputs": [{"name": "", "type": "string"}],
        "stateMutability": "view",
        "type": "function",
    },
]

REPUTATION_ABI: list[Dict[str, Any]] = [
    {
        "inputs": [{"name": "agent", "type": "address"}],
        "name": "getReputation",
        "outputs": [
            {"name": "score", "type": "uint256"},
            {"name": "completedTasks", "type": "uint256"},
            {"name": "failedTasks", "type": "uint256"},
        ],
        "stateMutability": "view",
        "type": "function",
    },
]

ESCROW_ABI: list[Dict[str, Any]] = [
    {
        "inputs": [
            {"name": "worker", "type": "address"},
            {"name": "amount", "type": "uint256"},
            {"name": "token", "type": "address"},
            {"name": "deadline", "type": "uint256"},
            {"name": "description", "type": "string"},
        ],
        "name": "createEscrow",
        "outputs": [{"name": "escrowId", "type": "uint256"}],
        "stateMutability": "nonpayable",
        "type": "function",
    },
    {
        "inputs": [{"name": "escrowId", "type": "uint256"}],
        "name": "releaseEscrow",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function",
    },
    {
        "inputs": [{"name": "escrowId", "type": "uint256"}],
        "name": "getEscrow",
        "outputs": [
            {"name": "client", "type": "address"},
            {"name": "worker", "type": "address"},
            {"name": "amount", "type": "uint256"},
            {"name": "token", "type": "address"},
            {"name": "status", "type": "uint8"},
            {"name": "deadline", "type": "uint256"},
        ],
        "stateMutability": "view",
        "type": "function",
    },
]

ERC20_ABI: list[Dict[str, Any]] = [
    {
        "inputs": [{"name": "account", "type": "address"}],
        "name": "balanceOf",
        "outputs": [{"name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [
            {"name": "spender", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "name": "approve",
        "outputs": [{"name": "", "type": "bool"}],
        "stateMutability": "nonpayable",
        "type": "function",
    },
    {
        "inputs": [],
        "name": "decimals",
        "outputs": [{"name": "", "type": "uint8"}],
        "stateMutability": "view",
        "type": "function",
    },
]
