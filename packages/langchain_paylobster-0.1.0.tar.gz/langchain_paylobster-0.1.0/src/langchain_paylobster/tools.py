"""LangChain tools for PayLobster escrow operations."""

from typing import Optional, Type
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from web3 import Web3
from web3.exceptions import ContractLogicError

from langchain_paylobster.constants import (
    CONTRACTS,
    BASE_RPC_URL,
    IDENTITY_ABI,
    REPUTATION_ABI,
    ESCROW_ABI,
    ERC20_ABI,
)


class CreateEscrowInput(BaseModel):
    """Input for creating an escrow."""

    worker_address: str = Field(description="Ethereum address of the worker agent")
    amount_usdc: float = Field(description="Amount in USDC (e.g., 100.50)")
    deadline_hours: int = Field(
        description="Hours from now until deadline", default=24
    )
    description: str = Field(description="Description of the work to be done")
    private_key: str = Field(description="Private key of the client (caller)")


class ReleaseEscrowInput(BaseModel):
    """Input for releasing an escrow."""

    escrow_id: int = Field(description="ID of the escrow to release")
    private_key: str = Field(description="Private key of the client")


class CheckReputationInput(BaseModel):
    """Input for checking reputation."""

    agent_address: str = Field(description="Ethereum address of the agent")


class RegisterAgentInput(BaseModel):
    """Input for registering an agent."""

    metadata: str = Field(
        description="JSON metadata describing the agent (capabilities, contact, etc.)"
    )
    private_key: str = Field(description="Private key of the agent to register")


class GetBalanceInput(BaseModel):
    """Input for getting USDC balance."""

    address: str = Field(description="Ethereum address to check balance for")


class PayLobsterCreateEscrow(BaseTool):
    """Tool for creating a payment escrow on PayLobster."""

    name: str = "paylobster_create_escrow"
    description: str = (
        "Create a payment escrow on PayLobster. Locks USDC funds that will be released "
        "to a worker upon completion of work. Returns the escrow ID."
    )
    args_schema: Type[BaseModel] = CreateEscrowInput

    def _run(
        self,
        worker_address: str,
        amount_usdc: float,
        deadline_hours: int,
        description: str,
        private_key: str,
    ) -> str:
        """Create an escrow."""
        try:
            w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
            account = w3.eth.account.from_key(private_key)

            # Convert USDC amount (6 decimals)
            amount_wei = int(amount_usdc * 1_000_000)

            # Calculate deadline timestamp
            deadline = w3.eth.get_block("latest")["timestamp"] + (
                deadline_hours * 3600
            )

            # Approve USDC spending first
            usdc = w3.eth.contract(address=CONTRACTS["USDC"], abi=ERC20_ABI)
            approve_tx = usdc.functions.approve(
                CONTRACTS["ESCROW"], amount_wei
            ).build_transaction(
                {
                    "from": account.address,
                    "nonce": w3.eth.get_transaction_count(account.address),
                }
            )
            signed_approve = account.sign_transaction(approve_tx)
            approve_hash = w3.eth.send_raw_transaction(signed_approve.raw_transaction)
            w3.eth.wait_for_transaction_receipt(approve_hash)

            # Create escrow
            escrow = w3.eth.contract(address=CONTRACTS["ESCROW"], abi=ESCROW_ABI)
            tx = escrow.functions.createEscrow(
                Web3.to_checksum_address(worker_address),
                amount_wei,
                CONTRACTS["USDC"],
                deadline,
                description,
            ).build_transaction(
                {
                    "from": account.address,
                    "nonce": w3.eth.get_transaction_count(account.address),
                }
            )

            signed_tx = account.sign_transaction(tx)
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

            # Extract escrow ID from logs
            escrow_id = receipt["logs"][0]["topics"][1].hex() if receipt["logs"] else "unknown"

            return f"Escrow created successfully! Escrow ID: {escrow_id}, Transaction: {tx_hash.hex()}"

        except Exception as e:
            return f"Error creating escrow: {str(e)}"

    async def _arun(
        self,
        worker_address: str,
        amount_usdc: float,
        deadline_hours: int,
        description: str,
        private_key: str,
    ) -> str:
        """Async version - calls sync version."""
        return self._run(
            worker_address, amount_usdc, deadline_hours, description, private_key
        )


class PayLobsterReleaseEscrow(BaseTool):
    """Tool for releasing payment from an escrow."""

    name: str = "paylobster_release_escrow"
    description: str = (
        "Release payment from a PayLobster escrow to the worker. "
        "Only the client who created the escrow can release it."
    )
    args_schema: Type[BaseModel] = ReleaseEscrowInput

    def _run(self, escrow_id: int, private_key: str) -> str:
        """Release an escrow."""
        try:
            w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
            account = w3.eth.account.from_key(private_key)

            escrow = w3.eth.contract(address=CONTRACTS["ESCROW"], abi=ESCROW_ABI)
            tx = escrow.functions.releaseEscrow(escrow_id).build_transaction(
                {
                    "from": account.address,
                    "nonce": w3.eth.get_transaction_count(account.address),
                }
            )

            signed_tx = account.sign_transaction(tx)
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

            return f"Escrow {escrow_id} released successfully! Transaction: {tx_hash.hex()}"

        except Exception as e:
            return f"Error releasing escrow: {str(e)}"

    async def _arun(self, escrow_id: int, private_key: str) -> str:
        """Async version - calls sync version."""
        return self._run(escrow_id, private_key)


class PayLobsterCheckReputation(BaseTool):
    """Tool for checking an agent's reputation on PayLobster."""

    name: str = "paylobster_check_reputation"
    description: str = (
        "Check the reputation score and task history of an agent on PayLobster. "
        "Returns score, completed tasks, and failed tasks."
    )
    args_schema: Type[BaseModel] = CheckReputationInput

    def _run(self, agent_address: str) -> str:
        """Check reputation."""
        try:
            w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
            reputation = w3.eth.contract(
                address=CONTRACTS["REPUTATION"], abi=REPUTATION_ABI
            )

            score, completed, failed = reputation.functions.getReputation(
                Web3.to_checksum_address(agent_address)
            ).call()

            total = completed + failed
            success_rate = (completed / total * 100) if total > 0 else 0

            return (
                f"Agent {agent_address[:10]}...{agent_address[-8:]}:\n"
                f"  Reputation Score: {score}\n"
                f"  Completed Tasks: {completed}\n"
                f"  Failed Tasks: {failed}\n"
                f"  Success Rate: {success_rate:.1f}%"
            )

        except Exception as e:
            return f"Error checking reputation: {str(e)}"

    async def _arun(self, agent_address: str) -> str:
        """Async version - calls sync version."""
        return self._run(agent_address)


class PayLobsterRegisterAgent(BaseTool):
    """Tool for registering an agent on PayLobster."""

    name: str = "paylobster_register_agent"
    description: str = (
        "Register an agent on the PayLobster identity system. "
        "Metadata should be a JSON string with agent capabilities, contact info, etc."
    )
    args_schema: Type[BaseModel] = RegisterAgentInput

    def _run(self, metadata: str, private_key: str) -> str:
        """Register an agent."""
        try:
            w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
            account = w3.eth.account.from_key(private_key)

            identity = w3.eth.contract(address=CONTRACTS["IDENTITY"], abi=IDENTITY_ABI)

            # Check if already registered
            is_registered = identity.functions.isRegistered(account.address).call()
            if is_registered:
                return f"Agent {account.address} is already registered."

            tx = identity.functions.register(metadata).build_transaction(
                {
                    "from": account.address,
                    "nonce": w3.eth.get_transaction_count(account.address),
                }
            )

            signed_tx = account.sign_transaction(tx)
            tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
            receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

            return f"Agent registered successfully! Address: {account.address}, Transaction: {tx_hash.hex()}"

        except Exception as e:
            return f"Error registering agent: {str(e)}"

    async def _arun(self, metadata: str, private_key: str) -> str:
        """Async version - calls sync version."""
        return self._run(metadata, private_key)


class PayLobsterGetBalance(BaseTool):
    """Tool for getting USDC balance."""

    name: str = "paylobster_get_balance"
    description: str = "Get the USDC balance of an Ethereum address on Base."
    args_schema: Type[BaseModel] = GetBalanceInput

    def _run(self, address: str) -> str:
        """Get USDC balance."""
        try:
            w3 = Web3(Web3.HTTPProvider(BASE_RPC_URL))
            usdc = w3.eth.contract(address=CONTRACTS["USDC"], abi=ERC20_ABI)

            balance_wei = usdc.functions.balanceOf(
                Web3.to_checksum_address(address)
            ).call()
            balance_usdc = balance_wei / 1_000_000  # USDC has 6 decimals

            return f"USDC Balance for {address[:10]}...{address[-8:]}: ${balance_usdc:,.2f}"

        except Exception as e:
            return f"Error getting balance: {str(e)}"

    async def _arun(self, address: str) -> str:
        """Async version - calls sync version."""
        return self._run(address)
