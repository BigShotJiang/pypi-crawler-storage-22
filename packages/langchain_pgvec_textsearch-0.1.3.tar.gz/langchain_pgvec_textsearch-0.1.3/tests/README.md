tests example

```
python tests/run_quick_test.py "postgresql+asyncpg://id4thomas:password@localhost:9010/psi_king"
```