# langchain-synapse

An integration package connecting [Synapse](https://github.com/raghuram369/synapse) memory and [LangChain](https://github.com/langchain-ai/langchain).

**Privacy-first AI memory** — all data stays local. Zero API calls for storage. Zero external dependencies beyond LangChain and Synapse.

## Installation

```bash
pip install langchain-synapse
```

## Components

### SynapseMemory

Drop-in `BaseMemory` implementation for any LangChain chain:

```python
from langchain_synapse import SynapseMemory
from synapse import Synapse

syn = Synapse("./agent_memory")
memory = SynapseMemory(synapse=syn)

# Use with any chain
chain = prompt | llm
chain.invoke({"input": "hello"}, config={"memory": memory})
```

### SynapseChatMessageHistory

Persistent chat history with semantic recall:

```python
from langchain_synapse import SynapseChatMessageHistory
from synapse import Synapse

syn = Synapse("./chat_memory")
history = SynapseChatMessageHistory(synapse=syn, session_id="user-123")

history.add_user_message("I love Italian food")
history.add_ai_message("Great! Any favorite dish?")

# Semantic search — find relevant messages, not just recent ones
relevant = history.search("What cuisine do they prefer?")
```

### SynapseRetriever

Use Synapse as a retriever in RAG pipelines:

```python
from langchain_synapse import SynapseRetriever
from synapse import Synapse

syn = Synapse("./knowledge_base")
syn.remember("Python was created by Guido van Rossum")
syn.remember("Rust was created by Graydon Hoare at Mozilla")

retriever = SynapseRetriever(synapse=syn, k=5)

# Use in a RAG chain
from langchain_core.runnables import RunnablePassthrough
chain = (
    {"context": retriever, "question": RunnablePassthrough()}
    | prompt
    | llm
)
```

## Why Synapse?

- **🔒 Privacy-first**: All memory stays on your machine. No cloud. No API calls for storage.
- **🧠 Neuroscience-inspired**: Memory strengthening, decay, and semantic recall — not just vector similarity.
- **⚡ Zero dependencies**: Synapse itself is pure Python with no external dependencies.
- **📦 Portable**: `.synapse` files can be shared, versioned, and federated across agents.

## License

MIT
