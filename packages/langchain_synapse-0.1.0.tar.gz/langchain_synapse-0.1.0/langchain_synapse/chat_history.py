"""SynapseChatMessageHistory — LangChain chat history backed by Synapse.

Privacy-first: all messages stay local. No cloud storage.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Sequence

from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from synapse import Synapse


class SynapseChatMessageHistory(BaseChatMessageHistory):
    """Persistent chat message history using Synapse as the backend.

    Unlike simple list-based histories, Synapse provides semantic recall —
    relevant past messages surface automatically based on context.

    Example::

        from synapse import Synapse
        from langchain_synapse import SynapseChatMessageHistory

        syn = Synapse("./chat_memory")
        history = SynapseChatMessageHistory(synapse=syn, session_id="user-123")

        history.add_user_message("I love Italian food")
        history.add_ai_message("Great! Do you have a favorite dish?")
    """

    def __init__(
        self,
        synapse: Optional[Synapse] = None,
        path: str = ":memory:",
        session_id: str = "default",
    ):
        self.synapse = synapse or Synapse(path)
        self.session_id = session_id

    def _make_metadata(self, role: str) -> Dict[str, Any]:
        return {
            "role": role,
            "session_id": self.session_id,
            "source": "langchain_chat_history",
            "timestamp": time.time(),
        }

    def add_message(self, message: BaseMessage) -> None:
        """Add a LangChain BaseMessage to history."""
        if isinstance(message, HumanMessage):
            role = "human"
        elif isinstance(message, AIMessage):
            role = "ai"
        elif isinstance(message, SystemMessage):
            role = "system"
        else:
            role = "unknown"

        self.synapse.remember(
            str(message.content),
            memory_type="observation",
            metadata=self._make_metadata(role),
            episode=f"chat-{self.session_id}",
        )

    @property
    def messages(self) -> List[BaseMessage]:
        """Return all messages in this session, ordered by time."""
        all_memories = self.synapse.recall("", limit=10000)
        session_memories = [
            m for m in all_memories
            if (m.metadata or {}).get("session_id") == self.session_id
        ]
        session_memories.sort(key=lambda m: m.created_at)

        messages: List[BaseMessage] = []
        for mem in session_memories:
            role = (mem.metadata or {}).get("role", "human")
            if role == "ai":
                messages.append(AIMessage(content=mem.content))
            elif role == "system":
                messages.append(SystemMessage(content=mem.content))
            else:
                messages.append(HumanMessage(content=mem.content))
        return messages

    def search(self, query: str, limit: int = 5) -> List[Any]:
        """Semantic search across chat history — Synapse's superpower."""
        results = self.synapse.recall(query, limit=limit)
        return [m for m in results
                if (m.metadata or {}).get("session_id") == self.session_id]

    def clear(self) -> None:
        """Clear all messages in this session."""
        all_memories = self.synapse.recall("", limit=10000)
        for mem in all_memories:
            if (mem.metadata or {}).get("session_id") == self.session_id:
                self.synapse.forget(mem.id)
