"""SynapseMemory — LangChain BaseMemory backed by Synapse.

Privacy-first: all memory stays local. No API calls for storage.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from langchain_core.memory import BaseMemory
from synapse import Synapse


class SynapseMemory(BaseMemory):
    """LangChain-compatible memory backed by Synapse.

    Stores conversation history and relevant facts in a local Synapse
    database. Recall is semantic — not just last-N messages.

    Example::

        from synapse import Synapse
        from langchain_synapse import SynapseMemory

        syn = Synapse("./agent_memory")
        memory = SynapseMemory(synapse=syn)
    """

    synapse: Any  # Synapse instance
    memory_key: str = "history"
    input_key: Optional[str] = None
    output_key: Optional[str] = None
    recall_limit: int = 10
    store_inputs: bool = True
    store_outputs: bool = True
    return_messages: bool = False

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, synapse: Optional[Synapse] = None, path: str = ":memory:", **kwargs: Any):
        super().__init__(synapse=synapse or Synapse(path), **kwargs)

    @property
    def memory_variables(self) -> List[str]:
        return [self.memory_key]

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Recall relevant memories based on the current input."""
        context_parts = [v for v in inputs.values() if isinstance(v, str)]
        context = " ".join(context_parts) if context_parts else ""

        memories = self.synapse.recall(context, limit=self.recall_limit)

        if self.return_messages:
            from langchain_core.messages import AIMessage, HumanMessage

            messages = []
            for mem in memories:
                role = (mem.metadata or {}).get("role", "human")
                if role == "ai":
                    messages.append(AIMessage(content=mem.content))
                else:
                    messages.append(HumanMessage(content=mem.content))
            return {self.memory_key: messages}

        formatted = "\n".join(f"- {m.content}" for m in memories)
        return {self.memory_key: formatted}

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, str]) -> None:
        """Store the conversation turn in Synapse."""
        if self.store_inputs:
            input_key = self.input_key or next(iter(inputs), None)
            if input_key and input_key in inputs:
                value = inputs[input_key]
                if isinstance(value, str) and value.strip():
                    self.synapse.remember(
                        value,
                        memory_type="observation",
                        metadata={"role": "human", "source": "langchain"},
                    )

        if self.store_outputs:
            output_key = self.output_key or next(iter(outputs), None)
            if output_key and output_key in outputs:
                value = outputs[output_key]
                if isinstance(value, str) and value.strip():
                    self.synapse.remember(
                        value,
                        memory_type="observation",
                        metadata={"role": "ai", "source": "langchain"},
                    )

    def clear(self) -> None:
        """Clear all memories."""
        all_memories = self.synapse.recall("", limit=10000)
        for mem in all_memories:
            self.synapse.forget(mem.id)
