"""SynapseRetriever — LangChain BaseRetriever backed by Synapse.

Privacy-first: all retrieval is local. No vector DB API calls.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from synapse import Synapse


class SynapseRetriever(BaseRetriever):
    """LangChain-compatible retriever using Synapse's semantic recall.

    Synapse combines BM25, concept graphs, and optional local embeddings
    for retrieval — all running locally with zero external API calls.

    Example::

        from synapse import Synapse
        from langchain_synapse import SynapseRetriever

        syn = Synapse("./knowledge_base")
        syn.remember("Python was created by Guido van Rossum")

        retriever = SynapseRetriever(synapse=syn, k=5)
        docs = retriever.invoke("Who created Python?")
    """

    synapse: Any  # Synapse instance
    k: int = 5
    memory_type: Optional[str] = None
    min_strength: float = 0.01
    metadata_filter: Dict[str, Any] = {}

    class Config:
        arbitrary_types_allowed = True

    def __init__(self, synapse: Optional[Synapse] = None, path: str = ":memory:", **kwargs: Any):
        super().__init__(synapse=synapse or Synapse(path), **kwargs)

    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        """Retrieve relevant documents from Synapse."""
        memories = self.synapse.recall(
            query,
            limit=self.k,
            memory_type=self.memory_type,
            min_strength=self.min_strength,
        )

        if self.metadata_filter:
            memories = [
                m for m in memories
                if all(
                    (m.metadata or {}).get(k) == v
                    for k, v in self.metadata_filter.items()
                )
            ]

        return [
            Document(
                page_content=mem.content,
                metadata={
                    "memory_id": mem.id,
                    "memory_type": mem.memory_type,
                    "strength": mem.effective_strength,
                    "created_at": mem.created_at,
                    **(mem.metadata or {}),
                },
            )
            for mem in memories
        ]
