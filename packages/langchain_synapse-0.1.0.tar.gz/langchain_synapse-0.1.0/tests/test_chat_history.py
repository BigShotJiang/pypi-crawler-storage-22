"""Tests for SynapseChatMessageHistory."""

from langchain_core.messages import AIMessage, HumanMessage
from synapse import Synapse
from langchain_synapse import SynapseChatMessageHistory


def test_add_and_retrieve_messages():
    syn = Synapse(":memory:")
    history = SynapseChatMessageHistory(synapse=syn, session_id="test")
    history.add_user_message("Hello")
    history.add_ai_message("Hi there!")
    messages = history.messages
    assert len(messages) == 2
    assert isinstance(messages[0], HumanMessage)
    assert isinstance(messages[1], AIMessage)


def test_search():
    syn = Synapse(":memory:")
    history = SynapseChatMessageHistory(synapse=syn, session_id="test")
    history.add_user_message("I love Italian food")
    history.add_user_message("The weather is nice today")
    results = history.search("cuisine preferences")
    assert len(results) > 0


def test_clear():
    syn = Synapse(":memory:")
    history = SynapseChatMessageHistory(synapse=syn, session_id="test")
    history.add_user_message("Hello")
    history.clear()
    assert len(history.messages) == 0


def test_session_isolation():
    syn = Synapse(":memory:")
    h1 = SynapseChatMessageHistory(synapse=syn, session_id="s1")
    h2 = SynapseChatMessageHistory(synapse=syn, session_id="s2")
    h1.add_user_message("Session 1 message")
    h2.add_user_message("Session 2 message")
    assert len(h1.messages) == 1
    assert len(h2.messages) == 1
