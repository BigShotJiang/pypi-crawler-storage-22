"""Tests for SynapseMemory."""

from synapse import Synapse
from langchain_synapse import SynapseMemory


def test_memory_variables():
    mem = SynapseMemory(synapse=Synapse(":memory:"))
    assert mem.memory_variables == ["history"]


def test_save_and_load():
    syn = Synapse(":memory:")
    mem = SynapseMemory(synapse=syn)
    mem.save_context({"input": "I like pizza"}, {"output": "Great choice!"})
    result = mem.load_memory_variables({"input": "food preferences"})
    assert "history" in result
    assert len(result["history"]) > 0


def test_clear():
    syn = Synapse(":memory:")
    mem = SynapseMemory(synapse=syn)
    mem.save_context({"input": "test"}, {"output": "response"})
    mem.clear()
    result = mem.load_memory_variables({"input": "test"})
    assert result["history"] == ""


def test_return_messages():
    syn = Synapse(":memory:")
    mem = SynapseMemory(synapse=syn, return_messages=True)
    mem.save_context({"input": "hello"}, {"output": "hi there"})
    result = mem.load_memory_variables({"input": "greeting"})
    messages = result["history"]
    assert len(messages) > 0
