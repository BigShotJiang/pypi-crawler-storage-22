"""Tests for SynapseRetriever."""

from langchain_core.documents import Document
from synapse import Synapse
from langchain_synapse import SynapseRetriever


def test_retrieve_documents():
    syn = Synapse(":memory:")
    syn.remember("Python was created by Guido van Rossum")
    syn.remember("JavaScript was created by Brendan Eich")

    retriever = SynapseRetriever(synapse=syn, k=5)
    docs = retriever.invoke("Who created Python?")
    assert len(docs) > 0
    assert all(isinstance(d, Document) for d in docs)


def test_empty_retrieval():
    syn = Synapse(":memory:")
    retriever = SynapseRetriever(synapse=syn, k=5)
    docs = retriever.invoke("anything")
    assert docs == []
