# langchain-tradekix 📊

Financial market data tools for [LangChain](https://langchain.com) agents, powered by [TradeKix](https://www.tradekix.ai).

## Installation

```bash
pip install langchain-tradekix
```

## Quick Start

```bash
export TRADEKIX_API_KEY=tk_live_your_key_here
```

```python
from langchain_tradekix import TradekixMarketOverviewTool, TradekixPricesTool, TradekixCongressionalTradesTool
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI

tools = [
    TradekixMarketOverviewTool(),
    TradekixPricesTool(),
    TradekixCongressionalTradesTool(),
]

llm = ChatOpenAI(model="gpt-4")
agent = initialize_agent(tools, llm, agent=AgentType.OPENAI_FUNCTIONS, verbose=True)
agent.run("What's the market doing today? Any congress members trading NVDA?")
```

## Get a Free API Key

```bash
curl -X POST https://tradekix-alpha.vercel.app/api/v1/connect \
  -H "Content-Type: application/json" \
  -d '{"agent_name": "MyAgent", "email": "you@example.com", "source": "langchain"}'
```

LangChain signups get **Developer tier** — 100 calls/day free.

## Available Tools

| Tool | Description |
|------|-------------|
| `TradekixMarketOverviewTool` | Full market snapshot — indices, forex, events, alerts, news |
| `TradekixPricesTool` | Stock & crypto prices (historical + current) |
| `TradekixIndicesTool` | Major market indices by region/country |
| `TradekixForexTool` | Forex exchange rates |
| `TradekixEarningsTool` | Earnings calendar |
| `TradekixEconomicEventsTool` | Economic events (FOMC, CPI, jobs) |
| `TradekixCongressionalTradesTool` | Congressional stock trades with conflict detection |
| `TradekixSentimentTool` | Social media sentiment |
| `TradekixTweetsTool` | Curated financial tweets |
| `TradekixNewsTool` | AI-curated financial news |

## Pricing

| Tier | Calls/Day | Price |
|------|-----------|-------|
| Developer | 100 | Free |
| Agent Pro | 2,000 | $9/mo |
| Enterprise | 50,000 | Contact us |

## Links

- [tradekix.ai](https://www.tradekix.ai) — Website
- [AI Agent Access](https://www.tradekix.ai/ai-agent-access) — Docs
- [GitHub](https://github.com/TradekixAI/langchain-tradekix)
- [MCP Server](https://www.npmjs.com/package/tradekix-mcp-server) — For Claude/Cursor

## License

MIT
