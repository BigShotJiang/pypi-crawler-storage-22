"""TradeKix tools for LangChain agents.

Each tool wraps a TradeKix API endpoint, providing financial market data
to LangChain agents. All tools require a TradeKix API key.

Get a free API key: POST https://tradekix-alpha.vercel.app/api/v1/connect
Docs: https://www.tradekix.ai/ai-agent-access
"""

import os
import json
from typing import Optional, Type

import requests
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field


BASE_URL = "https://tradekix-alpha.vercel.app/api/v1"


def _get_api_key() -> str:
    key = os.environ.get("TRADEKIX_API_KEY")
    if not key:
        raise ValueError(
            "TRADEKIX_API_KEY environment variable is required. "
            "Get a free key at https://www.tradekix.ai/ai-agent-access"
        )
    return key


def _make_request(endpoint: str, params: Optional[dict] = None) -> str:
    api_key = _get_api_key()
    headers = {"X-API-Key": api_key}
    url = f"{BASE_URL}/{endpoint}"

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        data = resp.json()

        if not data.get("success"):
            error = data.get("error", "Unknown error")
            upgrade = data.get("upgrade", {})
            if upgrade:
                return json.dumps({"error": error, "upgrade": upgrade})
            return json.dumps({"error": error})

        return json.dumps(data.get("data", {}), default=str)
    except requests.RequestException as e:
        return json.dumps({"error": f"Request failed: {str(e)}"})


# --- Market Overview ---

class TradekixMarketOverviewTool(BaseTool):
    name: str = "tradekix_market_overview"
    description: str = (
        "Get a comprehensive market overview including major indices, forex rates, "
        "upcoming economic events, latest alerts, and news summaries. No input needed."
    )

    def _run(self, query: str = "") -> str:
        return _make_request("market/overview")


# --- Stock/Crypto Prices ---

class PricesInput(BaseModel):
    symbol: str = Field(description="Ticker symbol, e.g. AAPL, BTC-USD, TSLA")
    from_date: Optional[str] = Field(None, description="Start date (YYYY-MM-DD)")
    to_date: Optional[str] = Field(None, description="End date (YYYY-MM-DD)")
    limit: Optional[int] = Field(None, description="Number of results (default 30)")


class TradekixPricesTool(BaseTool):
    name: str = "tradekix_prices"
    description: str = (
        "Get historical and current price data for stocks and crypto. "
        "Requires a ticker symbol (e.g. AAPL, BTC-USD)."
    )
    args_schema: Type[BaseModel] = PricesInput

    def _run(self, symbol: str, from_date: str = None, to_date: str = None, limit: int = None) -> str:
        params = {"symbol": symbol}
        if from_date: params["from"] = from_date
        if to_date: params["to"] = to_date
        if limit: params["limit"] = str(limit)
        return _make_request("market/prices", params)


# --- Market Indices ---

class IndicesInput(BaseModel):
    region: Optional[str] = Field(None, description="Region filter: US, EU, APAC")
    country: Optional[str] = Field(None, description="Country code filter")


class TradekixIndicesTool(BaseTool):
    name: str = "tradekix_indices"
    description: str = "Get major market indices. Optionally filter by region (US, EU, APAC) or country."
    args_schema: Type[BaseModel] = IndicesInput

    def _run(self, region: str = None, country: str = None) -> str:
        params = {}
        if region: params["region"] = region
        if country: params["country"] = country
        return _make_request("market/indices", params)


# --- Forex ---

class ForexInput(BaseModel):
    symbol: Optional[str] = Field(None, description="Currency pair, e.g. EUR/USD")


class TradekixForexTool(BaseTool):
    name: str = "tradekix_forex"
    description: str = "Get forex exchange rates. Optionally filter by currency pair."
    args_schema: Type[BaseModel] = ForexInput

    def _run(self, symbol: str = None) -> str:
        params = {}
        if symbol: params["symbol"] = symbol
        return _make_request("market/forex", params)


# --- Earnings ---

class TradekixEarningsTool(BaseTool):
    name: str = "tradekix_earnings"
    description: str = "Get upcoming and recent earnings reports. No input needed."

    def _run(self, query: str = "") -> str:
        return _make_request("events/earnings")


# --- Economic Events ---

class EconomicEventsInput(BaseModel):
    country: Optional[str] = Field(None, description="Country code, e.g. US")
    impact: Optional[str] = Field(None, description="Impact level: low, medium, or high")
    from_date: Optional[str] = Field(None, description="Start date (YYYY-MM-DD)")
    to_date: Optional[str] = Field(None, description="End date (YYYY-MM-DD)")


class TradekixEconomicEventsTool(BaseTool):
    name: str = "tradekix_economic_events"
    description: str = (
        "Get economic events calendar: FOMC meetings, CPI releases, jobs data. "
        "Filter by country, impact (low/medium/high), and date range."
    )
    args_schema: Type[BaseModel] = EconomicEventsInput

    def _run(self, country: str = None, impact: str = None, from_date: str = None, to_date: str = None) -> str:
        params = {}
        if country: params["country"] = country
        if impact: params["impact"] = impact
        if from_date: params["from"] = from_date
        if to_date: params["to"] = to_date
        return _make_request("events/economic", params)


# --- Congressional Trades ---

class CongressionalTradesInput(BaseModel):
    symbol: Optional[str] = Field(None, description="Filter by ticker symbol")
    politician: Optional[str] = Field(None, description="Filter by politician name")
    party: Optional[str] = Field(None, description="Filter by party: Democrat or Republican")
    type: Optional[str] = Field(None, description="Transaction type: buy or sell")
    from_date: Optional[str] = Field(None, description="Start date (YYYY-MM-DD)")
    to_date: Optional[str] = Field(None, description="End date (YYYY-MM-DD)")


class TradekixCongressionalTradesTool(BaseTool):
    name: str = "tradekix_congressional_trades"
    description: str = (
        "Track stock trades made by US congress members with conflict-of-interest detection. "
        "Filter by ticker, politician, party, type, and date range."
    )
    args_schema: Type[BaseModel] = CongressionalTradesInput

    def _run(self, symbol: str = None, politician: str = None, party: str = None,
             type: str = None, from_date: str = None, to_date: str = None) -> str:
        params = {}
        if symbol: params["symbol"] = symbol
        if politician: params["politician"] = politician
        if party: params["party"] = party
        if type: params["type"] = type
        if from_date: params["from"] = from_date
        if to_date: params["to"] = to_date
        return _make_request("trades/congressional", params)


# --- Sentiment ---

class SentimentInput(BaseModel):
    sentiment: Optional[str] = Field(None, description="Filter: bullish, bearish, or neutral")
    financial_only: Optional[bool] = Field(None, description="Only financial content")


class TradekixSentimentTool(BaseTool):
    name: str = "tradekix_sentiment"
    description: str = "Get aggregated social media sentiment from financial discussions."
    args_schema: Type[BaseModel] = SentimentInput

    def _run(self, sentiment: str = None, financial_only: bool = None) -> str:
        params = {}
        if sentiment: params["sentiment"] = sentiment
        if financial_only is not None: params["financial_only"] = str(financial_only).lower()
        return _make_request("social/sentiment", params)


# --- Tweets ---

class TweetsInput(BaseModel):
    author: Optional[str] = Field(None, description="Filter by author")
    symbol: Optional[str] = Field(None, description="Filter by ticker symbol")
    sentiment: Optional[str] = Field(None, description="Filter: bullish, bearish, or neutral")
    financial_only: Optional[bool] = Field(None, description="Only financial content")


class TradekixTweetsTool(BaseTool):
    name: str = "tradekix_tweets"
    description: str = "Get curated financial tweets and social posts."
    args_schema: Type[BaseModel] = TweetsInput

    def _run(self, author: str = None, symbol: str = None, sentiment: str = None,
             financial_only: bool = None) -> str:
        params = {}
        if author: params["author"] = author
        if symbol: params["symbol"] = symbol
        if sentiment: params["sentiment"] = sentiment
        if financial_only is not None: params["financial_only"] = str(financial_only).lower()
        return _make_request("social/tweets", params)


# --- News ---

class TradekixNewsTool(BaseTool):
    name: str = "tradekix_news"
    description: str = "Get AI-curated summary of latest financial news and market-moving events. No input needed."

    def _run(self, query: str = "") -> str:
        return _make_request("news/summary")
