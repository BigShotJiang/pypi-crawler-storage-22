"""
Langfuse Library - A production-ready wrapper for Langfuse prompts and tracing.

This library provides a robust, enterprise-grade interface for:
- Fetching and managing prompts from Langfuse with caching
- Calling LLMs with automatic tracing and retry logic
- Token tracking and observability
- Error handling and validation
- Performance metrics

Example:
    >>> from langfuse_prompt_library import LangfuseManager
    >>>
    >>> lf = LangfuseManager()
    >>> response = lf.call_llm(
    ...     prompt_name="customer_support_agent",
    ...     user_input="How do I reset my password?",
    ...     prompt_label="production"
    ... )
    >>> print(response.content)
"""

from .manager import LangfuseManager
from .models import LLMResponse
from .config import LangfuseConfig
from utils.logger import get_logger
from .exceptions import (
    LangfuseLibraryError,
    ConfigurationError,
    PromptNotFoundError,
    ProviderError,
    APITimeoutError,
    RateLimitError,
    CacheError,
    ValidationError,
    TracingError
)

__version__ = "0.1.0"
__all__ = [
    "LangfuseManager",
    "LLMResponse",
    "LangfuseConfig",
    "get_logger",
    "LangfuseLibraryError",
    "ConfigurationError",
    "PromptNotFoundError",
    "ProviderError",
    "APITimeoutError",
    "RateLimitError",
    "CacheError",
    "ValidationError",
    "TracingError"
]
