"""
Custom exceptions for Langfuse library.

Provides specific exception types for better error handling and debugging.
"""


class LangfuseLibraryError(Exception):
    """Base exception for all Langfuse library errors."""
    pass


class ConfigurationError(LangfuseLibraryError):
    """Raised when configuration is invalid or missing."""
    pass


class PromptNotFoundError(LangfuseLibraryError):
    """Raised when a requested prompt is not found."""

    def __init__(self, prompt_name: str, version: str = None, label: str = None):
        self.prompt_name = prompt_name
        self.version = version
        self.label = label

        msg = f"Prompt '{prompt_name}' not found"
        if version:
            msg += f" (version: {version})"
        if label:
            msg += f" (label: {label})"

        super().__init__(msg)


class ProviderError(LangfuseLibraryError):
    """Raised when LLM provider encounters an error."""

    def __init__(self, provider: str, message: str, original_error: Exception = None):
        self.provider = provider
        self.original_error = original_error

        msg = f"{provider} provider error: {message}"
        if original_error:
            msg += f" | Original error: {str(original_error)}"

        super().__init__(msg)


class APITimeoutError(LangfuseLibraryError):
    """Raised when an API call times out."""

    def __init__(self, operation: str, timeout: float):
        self.operation = operation
        self.timeout = timeout
        super().__init__(f"{operation} timed out after {timeout} seconds")


class RateLimitError(LangfuseLibraryError):
    """Raised when rate limit is exceeded."""

    def __init__(self, provider: str, retry_after: int = None):
        self.provider = provider
        self.retry_after = retry_after

        msg = f"Rate limit exceeded for {provider}"
        if retry_after:
            msg += f" | Retry after {retry_after} seconds"

        super().__init__(msg)


class CacheError(LangfuseLibraryError):
    """Raised when cache operations fail."""
    pass


class ValidationError(LangfuseLibraryError):
    """Raised when input validation fails."""

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(f"Validation error for '{field}': {message}")


class TracingError(LangfuseLibraryError):
    """Raised when tracing operations fail."""

    def __init__(self, message: str, original_error: Exception = None):
        self.original_error = original_error

        msg = f"Tracing error: {message}"
        if original_error:
            msg += f" | Original error: {str(original_error)}"

        super().__init__(msg)
