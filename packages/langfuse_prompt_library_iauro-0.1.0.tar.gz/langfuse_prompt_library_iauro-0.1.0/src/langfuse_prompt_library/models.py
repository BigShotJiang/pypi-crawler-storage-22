"""
Data models for Langfuse library responses.
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional


@dataclass
class LLMResponse:
    """Normalized response from LLM providers.

    Attributes:
        content: The text content of the LLM response
        model: The model name used for the generation
        usage: Token usage information (input, output, total)
        metadata: Additional metadata about the generation
        raw_response: The raw response object from the provider (optional)
    """

    content: str
    model: str
    usage: Dict[str, int]
    metadata: Optional[Dict[str, Any]] = None
    raw_response: Optional[Any] = None

    def __str__(self) -> str:
        """String representation showing the content."""
        return self.content

    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary.

        Returns:
            Dictionary representation of the response
        """
        return {
            "content": self.content,
            "model": self.model,
            "usage": self.usage,
            "metadata": self.metadata
        }
