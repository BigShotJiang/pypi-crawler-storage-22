"""
Logging utilities for Langfuse library.

Provides structured logging with appropriate log levels and formatting.
"""

import logging
import sys
from typing import Optional


class LangfuseLogger:
    """Structured logger for Langfuse library operations."""

    def __init__(self, name: str = "langfuse_prompt_library", level: int = logging.INFO):
        """Initialize logger.

        Args:
            name: Logger name
            level: Logging level (default: INFO)
        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)

        # Remove existing handlers to avoid duplicates
        self.logger.handlers.clear()

        # Create console handler with formatting
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(level)

        # Create formatter
        formatter = logging.Formatter(
            fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)

        self.logger.addHandler(handler)
        self.logger.propagate = False

    def debug(self, message: str, **kwargs) -> None:
        """Log debug message.

        Args:
            message: Log message
            **kwargs: Additional context as key-value pairs
        """
        extra_info = " | ".join(f"{k}={v}" for k, v in kwargs.items()) if kwargs else ""
        full_message = f"{message} | {extra_info}" if extra_info else message
        self.logger.debug(full_message)

    def info(self, message: str, **kwargs) -> None:
        """Log info message.

        Args:
            message: Log message
            **kwargs: Additional context as key-value pairs
        """
        extra_info = " | ".join(f"{k}={v}" for k, v in kwargs.items()) if kwargs else ""
        full_message = f"{message} | {extra_info}" if extra_info else message
        self.logger.info(full_message)

    def warning(self, message: str, **kwargs) -> None:
        """Log warning message.

        Args:
            message: Log message
            **kwargs: Additional context as key-value pairs
        """
        extra_info = " | ".join(f"{k}={v}" for k, v in kwargs.items()) if kwargs else ""
        full_message = f"{message} | {extra_info}" if extra_info else message
        self.logger.warning(full_message)

    def error(self, message: str, exc_info: bool = False, **kwargs) -> None:
        """Log error message.

        Args:
            message: Log message
            exc_info: Include exception information
            **kwargs: Additional context as key-value pairs
        """
        extra_info = " | ".join(f"{k}={v}" for k, v in kwargs.items()) if kwargs else ""
        full_message = f"{message} | {extra_info}" if extra_info else message
        self.logger.error(full_message, exc_info=exc_info)

    def critical(self, message: str, exc_info: bool = False, **kwargs) -> None:
        """Log critical message.

        Args:
            message: Log message
            exc_info: Include exception information
            **kwargs: Additional context as key-value pairs
        """
        extra_info = " | ".join(f"{k}={v}" for k, v in kwargs.items()) if kwargs else ""
        full_message = f"{message} | {extra_info}" if extra_info else message
        self.logger.critical(full_message, exc_info=exc_info)

    def set_level(self, level: int) -> None:
        """Change logging level.

        Args:
            level: New logging level (e.g., logging.DEBUG, logging.INFO)
        """
        self.logger.setLevel(level)
        for handler in self.logger.handlers:
            handler.setLevel(level)


def get_logger(name: str = "langfuse_prompt_library", level: Optional[int] = None) -> LangfuseLogger:
    """Get or create a logger instance.

    Args:
        name: Logger name
        level: Optional logging level

    Returns:
        LangfuseLogger instance
    """
    if level is None:
        level = logging.INFO
    return LangfuseLogger(name, level)
