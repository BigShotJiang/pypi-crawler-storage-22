"""Tests for langfuse_prompt_library."""

import pytest
from unittest.mock import Mock, patch, MagicMock
from langfuse_prompt_library import (
    LangfuseManager,
    LangfuseConfig,
    LLMResponse,
    ConfigurationError,
    PromptNotFoundError,
    ProviderError
)


class TestLangfuseConfig:
    """Tests for LangfuseConfig class."""

    def test_config_from_env(self, mock_env_vars):
        """Test loading configuration from environment variables."""
        config = LangfuseConfig.from_env()
        assert config.secret_key == "test-secret-key"
        assert config.public_key == "test-public-key"
        assert config.host == "https://test.langfuse.com"
        assert config.openai_api_key == "test-openai-key"

    def test_config_validation_missing_keys(self):
        """Test configuration validation fails with missing keys."""
        config = LangfuseConfig(
            secret_key="",
            public_key="test-key"
        )
        with pytest.raises(ConfigurationError):
            config.validate()

    def test_config_custom_values(self):
        """Test creating config with custom values."""
        config = LangfuseConfig(
            secret_key="secret",
            public_key="public",
            host="https://custom.langfuse.com",
            enable_caching=False,
            cache_ttl=7200
        )
        assert config.host == "https://custom.langfuse.com"
        assert config.enable_caching is False
        assert config.cache_ttl == 7200


class TestLangfuseManager:
    """Tests for LangfuseManager class."""

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_manager_initialization(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test LangfuseManager initialization."""
        manager = LangfuseManager()
        assert manager is not None
        assert manager.config is not None
        mock_langfuse.assert_called_once()

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_get_prompt_with_cache(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test getting a prompt with caching enabled."""
        # Setup mock
        mock_prompt = Mock()
        mock_prompt.version = 1
        mock_langfuse_instance = mock_langfuse.return_value
        mock_langfuse_instance.get_prompt.return_value = mock_prompt

        manager = LangfuseManager()

        # First call - should hit API
        result = manager.get_prompt("test_prompt", label="production")
        assert result == mock_prompt

        # Second call - should hit cache
        result2 = manager.get_prompt("test_prompt", label="production")
        assert result2 == mock_prompt

        # Should only call API once due to caching
        assert mock_langfuse_instance.get_prompt.call_count == 1

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_get_prompt_not_found(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test getting a non-existent prompt raises error."""
        mock_langfuse_instance = mock_langfuse.return_value
        mock_langfuse_instance.get_prompt.side_effect = Exception("Not found")

        manager = LangfuseManager()

        with pytest.raises(PromptNotFoundError):
            manager.get_prompt("nonexistent_prompt")

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_clear_cache(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test clearing the prompt cache."""
        manager = LangfuseManager()
        manager.clear_cache()
        # Should not raise any errors

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_get_cache_stats(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test getting cache statistics."""
        manager = LangfuseManager()
        stats = manager.get_cache_stats()
        assert stats is not None
        assert "hits" in stats
        assert "misses" in stats

    @patch('langfuse_prompt_library.manager.Langfuse')
    @patch('langfuse_prompt_library.manager.OpenAI')
    def test_flush(self, mock_openai, mock_langfuse, mock_env_vars):
        """Test flushing traces."""
        mock_langfuse_instance = mock_langfuse.return_value
        manager = LangfuseManager()
        manager.flush()
        mock_langfuse_instance.flush.assert_called_once()


class TestLLMResponse:
    """Tests for LLMResponse model."""

    def test_llm_response_creation(self):
        """Test creating an LLMResponse object."""
        response = LLMResponse(
            content="Test response",
            model="gpt-3.5-turbo",
            usage={"input": 10, "output": 20, "total": 30},
            metadata={"prompt_name": "test"}
        )
        assert response.content == "Test response"
        assert response.model == "gpt-3.5-turbo"
        assert response.usage["total"] == 30
        assert response.metadata["prompt_name"] == "test"


class TestValidation:
    """Tests for validation utilities."""

    def test_validate_prompt_name(self):
        """Test prompt name validation."""
        from langfuse_prompt_library.utils import validate_prompt_name
        from langfuse_prompt_library.exceptions import ValidationError

        # Valid names
        validate_prompt_name("valid_prompt")
        validate_prompt_name("valid-prompt-123")

        # Invalid names
        with pytest.raises(ValidationError):
            validate_prompt_name("")

        with pytest.raises(ValidationError):
            validate_prompt_name("   ")

    def test_validate_model_name(self):
        """Test model name validation."""
        from langfuse_prompt_library.utils import validate_model_name
        from langfuse_prompt_library.exceptions import ValidationError

        # Valid models
        validate_model_name("gpt-3.5-turbo")
        validate_model_name("claude-sonnet-4")

        # Invalid models
        with pytest.raises(ValidationError):
            validate_model_name("")

    def test_validate_temperature(self):
        """Test temperature validation."""
        from langfuse_prompt_library.utils import validate_temperature
        from langfuse_prompt_library.exceptions import ValidationError

        # Valid temperatures
        validate_temperature(0.0)
        validate_temperature(0.7)
        validate_temperature(2.0)

        # Invalid temperatures
        with pytest.raises(ValidationError):
            validate_temperature(-0.1)

        with pytest.raises(ValidationError):
            validate_temperature(2.1)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
