# langgraph-synapse

An integration package connecting [Synapse](https://github.com/raghuram369/synapse) memory and [LangGraph](https://github.com/langchain-ai/langgraph).

**Privacy-first checkpointing and cross-thread memory** — all data stays local.

## Installation

```bash
pip install langgraph-synapse
```

## Components

### SynapseCheckpointer

Persist LangGraph state across invocations:

```python
from synapse import Synapse
from langgraph_synapse import SynapseCheckpointer

syn = Synapse("./agent_state")
checkpointer = SynapseCheckpointer(synapse=syn)

# Use with LangGraph
graph = builder.compile(checkpointer=checkpointer)
graph.invoke(
    {"messages": [{"role": "user", "content": "hello"}]},
    config={"configurable": {"thread_id": "thread-1"}},
)
```

### SynapseStore

Cross-thread memory store with semantic search:

```python
from synapse import Synapse
from langgraph_synapse import SynapseStore

syn = Synapse("./shared_memory")
store = SynapseStore(synapse=syn)

# Store shared context
store.put(("user", "preferences"), "diet", {"value": "vegetarian"})

# Retrieve across any thread
item = store.get(("user", "preferences"), "diet")

# Semantic search
results = store.search(("user",), query="food preferences")
```

## Why Synapse?

- **🔒 Privacy-first**: All state stays on your machine
- **🧠 Semantic recall**: Not just key-value — find relevant state by meaning
- **⚡ Zero dependencies**: Synapse is pure Python
- **📦 Portable**: `.synapse` files can be shared and federated

## License

MIT
