"""SynapseCheckpointer — LangGraph checkpoint persistence backed by Synapse."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, Iterator, Optional, Sequence, Tuple

from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple
from synapse import Synapse


class SynapseCheckpointer(BaseCheckpointSaver):
    """LangGraph-compatible checkpointer using Synapse for persistence.

    All data stays local. No cloud. No API calls.

    Example::

        from synapse import Synapse
        from langgraph_synapse import SynapseCheckpointer

        syn = Synapse("./agent_state")
        checkpointer = SynapseCheckpointer(synapse=syn)
        graph = builder.compile(checkpointer=checkpointer)
    """

    def __init__(self, synapse: Optional[Synapse] = None, path: str = ":memory:"):
        super().__init__()
        self.synapse = synapse or Synapse(path)
        self._index: Dict[str, list] = {}
        self._rebuild_index()

    def _rebuild_index(self) -> None:
        all_memories = self.synapse.recall("", limit=10000)
        for mem in all_memories:
            meta = mem.metadata or {}
            if meta.get("source") == "langgraph_checkpoint":
                thread_id = meta.get("thread_id", "default")
                checkpoint_id = meta.get("checkpoint_id", "")
                self._index.setdefault(thread_id, []).append(
                    (checkpoint_id, mem.id, mem.created_at)
                )
        for thread_id in self._index:
            self._index[thread_id].sort(key=lambda x: x[2])

    def _make_checkpoint_id(self, thread_id: str) -> str:
        count = len(self._index.get(thread_id, []))
        return f"{thread_id}:{count}:{time.time()}"

    def put(
        self,
        config: Dict[str, Any],
        checkpoint: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        new_versions: Optional[Any] = None,
    ) -> Dict[str, Any]:
        configurable = config.get("configurable", {})
        thread_id = configurable.get("thread_id", "default")
        checkpoint_ns = configurable.get("checkpoint_ns", "")
        checkpoint_id = self._make_checkpoint_id(thread_id)

        content = json.dumps(checkpoint, default=str)
        mem = self.synapse.remember(
            content,
            memory_type="fact",
            metadata={
                "source": "langgraph_checkpoint",
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint_id,
                "checkpoint_metadata": json.dumps(metadata or {}, default=str),
            },
            deduplicate=False,
        )
        self._index.setdefault(thread_id, []).append(
            (checkpoint_id, mem.id, mem.created_at)
        )
        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint_id,
            }
        }

    def put_writes(
        self,
        config: Dict[str, Any],
        writes: Sequence[Tuple[str, Any]],
        task_id: str,
    ) -> None:
        configurable = config.get("configurable", {})
        thread_id = configurable.get("thread_id", "default")
        checkpoint_id = configurable.get("checkpoint_id", "")
        content = json.dumps({"writes": writes, "task_id": task_id}, default=str)
        self.synapse.remember(
            content,
            memory_type="fact",
            metadata={
                "source": "langgraph_writes",
                "thread_id": thread_id,
                "checkpoint_id": checkpoint_id,
                "task_id": task_id,
            },
            deduplicate=False,
        )

    def get_tuple(self, config: Dict[str, Any]) -> Optional[CheckpointTuple]:
        configurable = config.get("configurable", {})
        thread_id = configurable.get("thread_id", "default")
        checkpoint_id = configurable.get("checkpoint_id")
        entries = self._index.get(thread_id, [])
        if not entries:
            return None

        target = (
            next((e for e in entries if e[0] == checkpoint_id), None)
            if checkpoint_id
            else entries[-1]
        )
        if not target:
            return None

        cp_id, mem_id, _ = target
        memories = self.synapse.recall("", limit=10000)
        mem = next((m for m in memories if m.id == mem_id), None)
        if not mem:
            return None

        checkpoint = json.loads(mem.content)
        meta = mem.metadata or {}
        checkpoint_metadata = json.loads(meta.get("checkpoint_metadata", "{}"))

        return CheckpointTuple(
            config={
                "configurable": {
                    "thread_id": thread_id,
                    "checkpoint_ns": meta.get("checkpoint_ns", ""),
                    "checkpoint_id": cp_id,
                }
            },
            checkpoint=checkpoint,
            metadata=checkpoint_metadata,
            parent_config=None,
            pending_writes=[],
        )

    def list(
        self,
        config: Optional[Dict[str, Any]] = None,
        *,
        filter: Optional[Dict[str, Any]] = None,
        before: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
    ) -> Iterator[CheckpointTuple]:
        if config:
            thread_id = config.get("configurable", {}).get("thread_id", "default")
            entries = self._index.get(thread_id, [])
        else:
            entries = [e for thread_entries in self._index.values() for e in thread_entries]
            thread_id = "default"

        entries.sort(key=lambda x: x[2], reverse=True)
        if limit:
            entries = entries[:limit]
        for cp_id, mem_id, created_at in entries:
            result = self.get_tuple(
                {"configurable": {"thread_id": thread_id, "checkpoint_id": cp_id}}
            )
            if result:
                yield result
