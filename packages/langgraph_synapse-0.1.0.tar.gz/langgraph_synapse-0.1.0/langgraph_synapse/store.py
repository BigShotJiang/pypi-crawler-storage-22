"""SynapseStore — LangGraph cross-thread memory store backed by Synapse."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from synapse import Synapse

try:
    from langgraph.store.base import BaseStore, Item

    _HAS_STORE = True
except ImportError:
    _HAS_STORE = False
    BaseStore = object  # type: ignore
    Item = dict  # type: ignore


class SynapseStore(BaseStore):  # type: ignore[misc]
    """Cross-thread memory store for LangGraph using Synapse.

    Implements LangGraph's BaseStore interface for shared memory across
    threads. Memories are namespaced and semantically searchable.

    Example::

        from synapse import Synapse
        from langgraph_synapse import SynapseStore

        syn = Synapse("./shared_memory")
        store = SynapseStore(synapse=syn)
        store.put(("user", "preferences"), "diet", {"value": "vegetarian"})
        item = store.get(("user", "preferences"), "diet")
    """

    def __init__(self, synapse: Optional[Synapse] = None, path: str = ":memory:"):
        if _HAS_STORE:
            super().__init__()
        self.synapse = synapse or Synapse(path)

    def _namespace_key(self, namespace: Tuple[str, ...]) -> str:
        return "/".join(namespace)

    def _full_key(self, namespace: Tuple[str, ...], key: str) -> str:
        return f"{self._namespace_key(namespace)}/{key}"

    def _find_by_key(self, namespace: Tuple[str, ...], key: str):
        full_key = self._full_key(namespace, key)
        all_memories = self.synapse.recall("", limit=10000)
        for mem in all_memories:
            meta = mem.metadata or {}
            if meta.get("source") == "langgraph_store" and meta.get("full_key") == full_key:
                return mem
        return None

    def put(
        self,
        namespace: Tuple[str, ...],
        key: str,
        value: Dict[str, Any],
        index: Optional[List[str]] = None,
    ) -> None:
        existing = self._find_by_key(namespace, key)
        if existing:
            self.synapse.forget(existing.id)

        ns_str = self._namespace_key(namespace)
        content = json.dumps({"key": key, "value": value, "namespace": ns_str}, default=str)
        metadata = {
            "source": "langgraph_store",
            "namespace": ns_str,
            "item_key": key,
            "full_key": self._full_key(namespace, key),
            "updated_at": time.time(),
        }
        if index:
            metadata["index_fields"] = json.dumps(index)
        self.synapse.remember(content, memory_type="fact", metadata=metadata, deduplicate=False)

    def get(self, namespace: Tuple[str, ...], key: str) -> Optional[Any]:
        mem = self._find_by_key(namespace, key)
        if not mem:
            return None
        data = json.loads(mem.content)
        if _HAS_STORE:
            return Item(
                value=data.get("value", {}),
                key=key,
                namespace=namespace,
                created_at=mem.created_at,
                updated_at=(mem.metadata or {}).get("updated_at", mem.created_at),
            )
        return data.get("value")

    def delete(self, namespace: Tuple[str, ...], key: str) -> None:
        mem = self._find_by_key(namespace, key)
        if mem:
            self.synapse.forget(mem.id)

    def list_namespaces(
        self,
        *,
        prefix: Optional[Tuple[str, ...]] = None,
        suffix: Optional[Tuple[str, ...]] = None,
        max_depth: Optional[int] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Tuple[str, ...]]:
        all_memories = self.synapse.recall("", limit=10000)
        namespaces = set()
        for mem in all_memories:
            meta = mem.metadata or {}
            if meta.get("source") == "langgraph_store":
                ns = meta.get("namespace", "")
                ns_tuple = tuple(ns.split("/")) if ns else ()
                if prefix and ns_tuple[: len(prefix)] != prefix:
                    continue
                if suffix and ns_tuple[-len(suffix) :] != suffix:
                    continue
                if max_depth and len(ns_tuple) > max_depth:
                    ns_tuple = ns_tuple[:max_depth]
                namespaces.add(ns_tuple)
        result = sorted(namespaces)
        return result[offset : offset + limit]

    def search(
        self,
        namespace_prefix: Tuple[str, ...],
        *,
        query: Optional[str] = None,
        filter: Optional[Dict[str, Any]] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> List[Any]:
        ns_prefix = self._namespace_key(namespace_prefix)
        memories = self.synapse.recall(query or "", limit=limit * 3)

        results = []
        for mem in memories:
            meta = mem.metadata or {}
            if meta.get("source") != "langgraph_store":
                continue
            ns = meta.get("namespace", "")
            if not ns.startswith(ns_prefix):
                continue
            data = json.loads(mem.content)
            if filter:
                value = data.get("value", {})
                if not all(value.get(k) == v for k, v in filter.items()):
                    continue
            if _HAS_STORE:
                results.append(
                    Item(
                        value=data.get("value", {}),
                        key=meta.get("item_key", ""),
                        namespace=tuple(ns.split("/")),
                        created_at=mem.created_at,
                        updated_at=meta.get("updated_at", mem.created_at),
                    )
                )
            else:
                results.append(data.get("value", {}))
        return results[offset : offset + limit]

    def batch(self, ops: Sequence[Any]) -> List[Any]:
        results = []
        for op in ops:
            if hasattr(op, "namespace") and hasattr(op, "key"):
                results.append(self.get(op.namespace, op.key))
            else:
                results.append(None)
        return results
