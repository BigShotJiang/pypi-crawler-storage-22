"""Tests for SynapseCheckpointer."""

from synapse import Synapse
from langgraph_synapse import SynapseCheckpointer


def test_put_and_get():
    syn = Synapse(":memory:")
    cp = SynapseCheckpointer(synapse=syn)
    config = {"configurable": {"thread_id": "t1"}}
    checkpoint = {"v": 1, "ts": "2024-01-01", "channel_values": {"messages": []}}

    result_config = cp.put(config, checkpoint, metadata={"step": 0})
    assert result_config["configurable"]["thread_id"] == "t1"

    tup = cp.get_tuple(config)
    assert tup is not None


def test_list_checkpoints():
    syn = Synapse(":memory:")
    cp = SynapseCheckpointer(synapse=syn)
    config = {"configurable": {"thread_id": "t1"}}
    cp.put(config, {"v": 1, "ts": "1"}, metadata={"step": 0})
    cp.put(config, {"v": 1, "ts": "2"}, metadata={"step": 1})
    items = list(cp.list(config))
    assert len(items) == 2
