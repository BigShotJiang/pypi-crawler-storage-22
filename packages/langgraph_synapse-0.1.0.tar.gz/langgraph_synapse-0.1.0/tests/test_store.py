"""Tests for SynapseStore."""

from synapse import Synapse
from langgraph_synapse import SynapseStore


def test_put_and_get():
    syn = Synapse(":memory:")
    store = SynapseStore(synapse=syn)
    store.put(("user", "prefs"), "diet", {"value": "vegetarian"})
    item = store.get(("user", "prefs"), "diet")
    assert item is not None


def test_delete():
    syn = Synapse(":memory:")
    store = SynapseStore(synapse=syn)
    store.put(("user", "prefs"), "diet", {"value": "vegetarian"})
    store.delete(("user", "prefs"), "diet")
    item = store.get(("user", "prefs"), "diet")
    assert item is None


def test_search():
    syn = Synapse(":memory:")
    store = SynapseStore(synapse=syn)
    store.put(("user", "prefs"), "diet", {"value": "vegetarian"})
    store.put(("user", "prefs"), "color", {"value": "blue"})
    results = store.search(("user",), query="food")
    assert len(results) >= 0  # results depend on recall scoring
