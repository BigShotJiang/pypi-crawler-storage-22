# LangProtect MCP Gateway

🛡️ **Security gateway for Model Context Protocol (MCP)** - Protect your AI tool interactions from security threats.

## Features

✅ **Automatic Threat Detection** - Scans all MCP requests for security risks  
✅ **Access Control** - Whitelist/blacklist MCP servers and tools  
✅ **Full Audit Trail** - Logs all AI interactions for compliance  
✅ **IDE Support** - Works with VS Code, Cursor, and all MCP-compatible IDEs  
✅ **Easy Setup** - 30-second installation

## Quick Start

### Installation

```bash
pip install langprotect-mcp-gateway
```

### Configuration

Create your MCP config file:

**VS Code:** `~/.config/Code/User/mcp.json`  
**Cursor:** `~/.cursor/mcp.json`

```json
{
  "mcpServers": {
    "langprotect-gateway": {
      "command": "langprotect-gateway",
      "env": {
        "LANGPROTECT_URL": "https://your-langprotect-server.com",
        "LANGPROTECT_EMAIL": "your.email@company.com",
        "LANGPROTECT_PASSWORD": "your-password"
      },
      "servers": {
        "filesystem": {
          "command": "npx",
          "args": ["-y", "@modelcontextprotocol/server-filesystem", "."]
        }
      }
    }
  }
}
```

📝 **Note:** Replace `LANGPROTECT_URL` with your actual server URL (e.g., `https://langprotect.yourcompany.com` or `http://localhost:8000` for local testing).

### Restart Your IDE

**VS Code:** `Ctrl+Shift+P` → "Reload Window"  
**Cursor:** Close and reopen

Done! 🎉 All your AI tool interactions are now protected.

## What It Does

The LangProtect MCP Gateway intercepts all AI tool interactions and:

1. **Scans for threats** - Detects malicious commands, data exfiltration attempts
2. **Enforces policies** - Blocks access to sensitive files and dangerous operations
3. **Logs everything** - Complete audit trail for compliance
4. **Auto-detects IDE** - Tracks which IDE/tool made each request

## Supported IDEs

- ✅ VS Code (with GitHub Copilot, Codeium, etc.)
- ✅ Cursor IDE
- ✅ Windsurf
- ✅ Zed Editor
- ✅ Any MCP-compatible IDE

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `LANGPROTECT_URL` | No | `http://localhost:8000` | Your LangProtect server URL |
| `LANGPROTECT_EMAIL` | **Yes** | - | Your email address |
| `LANGPROTECT_PASSWORD` | **Yes** | - | Your password |
| `DEBUG` | No | `false` | Enable debug logging (true/false) |
| `MCP_CONFIG_PATH` | No | Auto-detected | Path to servers config (Cursor only) |

⚠️ **Production Setup:** For production deployments, always set `LANGPROTECT_URL` to your actual server:

```json
"env": {
  "LANGPROTECT_URL": "https://langprotect.yourcompany.com",
  "LANGPROTECT_EMAIL": "your.email@company.com",
  "LANGPROTECT_PASSWORD": "your-password"
}
```

The default `http://localhost:8000` is only for local development/testing.

## Architecture

```
AI Assistant (Copilot, etc.)
         ↓
LangProtect Gateway (this package)
         ↓
    [Security Scan]
         ↓
MCP Servers (filesystem, github, etc.)
```

Every request is:
1. Intercepted by the gateway
2. Scanned for security threats
3. Logged to LangProtect backend
4. Forwarded to actual MCP server (if safe)
5. Response returned to AI

## Dashboard

Monitor all activity at your LangProtect dashboard:
- View all AI interactions
- See security threats blocked
- Track IDE usage
- Generate compliance reports

## Security

The gateway protects against:
- 🚫 Sensitive file access (`.env`, SSH keys, etc.)
- 🚫 Dangerous commands (`rm -rf`, data exfiltration)
- 🚫 SQL injection patterns
- 🚫 Hardcoded credentials in suggestions
- 🚫 Prompt injection attacks

## Troubleshooting

**Authentication failed:**
- Check `LANGPROTECT_URL`, `LANGPROTECT_EMAIL`, `LANGPROTECT_PASSWORD` are correct
- Ensure LangProtect backend is accessible

**Gateway not starting:**
- Check Python version: `python3 --version` (need 3.11+)
- Check package installed: `pip show langprotect-mcp-gateway`

**Tools not working:**
- Check MCP servers are configured under `"servers"` section
- Restart IDE completely

## For Team Leads

### Quick Team Rollout:

1. **Share credentials** with each team member:
   ```
   Email: user@company.com
   Password: secure-password
   Server: http://langprotect.company.com:8000
   ```

2. **Team members install:**
   ```bash
   pip install langprotect-mcp-gateway
   # Configure mcp.json with credentials
   # Restart IDE
   ```

3. **Monitor dashboard:** See all team activity in real-time

## Updates

```bash
pip install --upgrade langprotect-mcp-gateway
```

## Support

- **Documentation:** https://docs.langprotect.com
- **Issues:** https://github.com/langprotect/mcp-gateway/issues
- **Security:** security@langprotect.com

## License

MIT License - see LICENSE file for details

## Links

- **Homepage:** https://langprotect.com
- **GitHub:** https://github.com/langprotect/mcp-gateway
- **Documentation:** https://docs.langprotect.com
