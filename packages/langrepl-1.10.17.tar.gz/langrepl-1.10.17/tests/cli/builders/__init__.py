"""Tests for message builders."""
