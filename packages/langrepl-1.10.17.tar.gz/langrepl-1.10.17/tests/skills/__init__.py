"""Tests for skills module."""
