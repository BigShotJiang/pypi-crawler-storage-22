# Fixture generation

example:

    lara-django-dev dumpdata lara_django_material.partdeviceclass --indent 2 --natural-primary > 1_partdeviceclasses_fix.json