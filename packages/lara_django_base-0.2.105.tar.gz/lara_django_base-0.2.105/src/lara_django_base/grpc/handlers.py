"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_base  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_base.grpc.services import (
    DataTypeService,
    MediaTypeService,
    NamespaceService,
    NamespaceByURIService,
    TagService,
    ItemStatusService,
    ExtraDataService,
    PhysicalUnitService,
    ExternalResourceService,
    PhysicalStateMatterService,
    ScientificConstantService,
    CurrencyService,
    GeoLocationService,
    CountryService,
    SubdivisionTypeService,
    CountrySubdivisionService,
    CityService,
    AddressService,
    RoomCategoryService,
    RoomService,
    LocationService,
    LARASyncServerService,
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_base", server)
    # monkey patching to import the grpc module from the API
    app_registry.get_grpc_module = lambda: "lara_django_base_grpc.v1"

    app_registry.register(DataTypeService)

    app_registry.register(MediaTypeService)

    app_registry.register(NamespaceService)

    app_registry.register(NamespaceByURIService)

    app_registry.register(TagService)

    app_registry.register(ItemStatusService)

    app_registry.register(ExtraDataService)

    app_registry.register(PhysicalUnitService)

    app_registry.register(ExternalResourceService)

    app_registry.register(PhysicalStateMatterService)

    app_registry.register(ScientificConstantService)

    app_registry.register(CurrencyService)

    app_registry.register(GeoLocationService)

    app_registry.register(CountryService)

    app_registry.register(SubdivisionTypeService)

    app_registry.register(CountrySubdivisionService)

    app_registry.register(CityService)

    app_registry.register(AddressService)

    app_registry.register(RoomCategoryService)

    app_registry.register(RoomService)

    app_registry.register(LocationService)

    app_registry.register(LARASyncServerService)
