"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_base  (LARA-version)

from django_socio_grpc import proto_serializers
from lara_django_base_grpc.v1 import lara_django_base_pb2
from rest_framework.serializers import PrimaryKeyRelatedField, UUIDField

from lara_django_base.models import (
    Address,
    City,
    Country,
    CountrySubdivision,
    Currency,
    DataType,
    ExternalResource,
    ExtraData,
    GeoLocation,
    ItemStatus,
    LARASyncServer,
    Location,
    MediaType,
    Namespace,
    PhysicalStateMatter,
    PhysicalUnit,
    Room,
    RoomCategory,
    ScientificConstant,
    SubdivisionType,
    Tag,
)


class DataTypeProtoSerializer(proto_serializers.ModelProtoSerializer):
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = DataType
        proto_class = lara_django_base_pb2.DataTypeResponse

        proto_class_list = lara_django_base_pb2.DataTypeListResponse

        fields = "__all__"  # [name', description']


class MediaTypeProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = MediaType
        proto_class = lara_django_base_pb2.MediaTypeResponse

        proto_class_list = lara_django_base_pb2.MediaTypeListResponse

        fields = "__all__"  # [name', media_type', def_filename_extension_regex', description']


class NamespaceProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = Namespace
        proto_class = lara_django_base_pb2.NamespaceResponse

        proto_class_list = lara_django_base_pb2.NamespaceListResponse

        fields = "__all__"


class NamespaceByURIProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = Namespace
        proto_class = lara_django_base_pb2.NamespaceResponse

        proto_class_list = lara_django_base_pb2.NamespaceListResponse

        fields = "__all__"


class TagProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = Tag
        proto_class = lara_django_base_pb2.TagResponse

        proto_class_list = lara_django_base_pb2.TagListResponse

        fields = "__all__"  # [tag']


class ItemStatusProtoSerializer(proto_serializers.ModelProtoSerializer):
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True, many=True
    )
    class Meta:
        model = ItemStatus
        proto_class = lara_django_base_pb2.ItemStatusResponse

        proto_class_list = lara_django_base_pb2.ItemStatusListResponse

        fields = "__all__"  # [status', description']


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_base_pb2.ExtraDataResponse

        proto_class_list = lara_django_base_pb2.ExtraDataListResponse

        fields = "__all__"  # [name', namespace', URI', text', XML', JSON', bin', media_type',
        # IRI', URL', description', file', image']


class PhysicalUnitProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = PhysicalUnit
        proto_class = lara_django_base_pb2.PhysicalUnitResponse

        proto_class_list = lara_django_base_pb2.PhysicalUnitListResponse

        fields = "__all__"  # [name', dimension', description']


class ExternalResourceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    resource_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True, many=True
    )

    class Meta:
        model = ExternalResource
        proto_class = lara_django_base_pb2.ExternalResourceResponse

        proto_class_list = lara_django_base_pb2.ExternalResourceListResponse

        fields = (
            "__all__"  # [name', media_type', URI', text', XML', JSON', bin', IRI', URL', description', file', image']
        )


class PhysicalStateMatterProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = PhysicalStateMatter
        proto_class = lara_django_base_pb2.PhysicalStateMatterResponse

        proto_class_list = lara_django_base_pb2.PhysicalStateMatterListResponse

        fields = "__all__"  # [name', description']


class ScientificConstantProtoSerializer(proto_serializers.ModelProtoSerializer):
    unit = PrimaryKeyRelatedField(queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"))

    class Meta:
        model = ScientificConstant
        proto_class = lara_django_base_pb2.ScientificConstantResponse

        proto_class_list = lara_django_base_pb2.ScientificConstantListResponse

        fields = "__all__"  # [name', value', unit', JSON', IRI', url_source', url_definition', description']


class CurrencyProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = Currency
        proto_class = lara_django_base_pb2.CurrencyResponse

        proto_class_list = lara_django_base_pb2.CurrencyListResponse

        fields = "__all__"  # [name', IRI', alpha3code', numeric_code', symbol', exchange_rate_eur']


class GeoLocationProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = GeoLocation
        proto_class = lara_django_base_pb2.GeoLocationResponse

        proto_class_list = lara_django_base_pb2.GeoLocationListResponse

        fields = "__all__"  # [name', coordinates_dd_lat', coordinates_dd_long', elevation', openstreetmap', googlemap']


class CountryProtoSerializer(proto_serializers.ModelProtoSerializer):
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = Country
        proto_class = lara_django_base_pb2.CountryResponse

        proto_class_list = lara_django_base_pb2.CountryListResponse

        fields = (
            "__all__"  # [name', name_local', alpha2code', alpha3code', numeric_code', phone_code', icon', currency']
        )


class SubdivisionTypeProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = SubdivisionType
        proto_class = lara_django_base_pb2.SubdivisionTypeResponse

        proto_class_list = lara_django_base_pb2.SubdivisionTypeListResponse

        fields = "__all__"  # [name', description']


class CountrySubdivisionProtoSerializer(proto_serializers.ModelProtoSerializer):
    country = PrimaryKeyRelatedField(queryset=Country.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    subdivision_type = PrimaryKeyRelatedField(
        queryset=SubdivisionType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = CountrySubdivision
        proto_class = lara_django_base_pb2.CountrySubdivisionResponse

        proto_class_list = lara_django_base_pb2.CountrySubdivisionListResponse

        fields = "__all__"  # [name', name_local', code', alpha2code', subdivision_type', country', timezone']


class CityProtoSerializer(proto_serializers.ModelProtoSerializer):
    country = PrimaryKeyRelatedField(queryset=Country.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    subdivision = PrimaryKeyRelatedField(
        queryset=CountrySubdivision.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = City
        proto_class = lara_django_base_pb2.CityResponse

        proto_class_list = lara_django_base_pb2.CityListResponse

        fields = "__all__"  # [name', name_local', country', subdivision', timezone']


class AddressProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    city = PrimaryKeyRelatedField(queryset=City.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    subdivision = PrimaryKeyRelatedField(
        queryset=CountrySubdivision.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    country = PrimaryKeyRelatedField(
        queryset=Country.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    geolocation = PrimaryKeyRelatedField(
        queryset=GeoLocation.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )

    class Meta:
        model = Address
        proto_class = lara_django_base_pb2.AddressResponse

        proto_class_list = lara_django_base_pb2.AddressListResponse

        fields = "__all__"  # [building', street', house_number', supplement', city', subdivision',
        # country', postal_code', geolocation']


class RoomCategoryProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = RoomCategory
        proto_class = lara_django_base_pb2.RoomCategoryResponse

        proto_class_list = lara_django_base_pb2.RoomCategoryListResponse

        fields = "__all__"  # [category', description']


class RoomProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    category = PrimaryKeyRelatedField(
        queryset=RoomCategory.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    # data_extra = PrimaryKeyRelatedField(
    #     queryset=ExtraData.objects.all(),
    #     pk_field=UUIDField(format="hex_verbose"),
    #     required=False,
    #     allow_null=True,
    #     many=True,
    # )

    class Meta:
        model = Room
        proto_class = lara_django_base_pb2.RoomResponse

        proto_class_list = lara_django_base_pb2.RoomListResponse

        fields = "__all__"  # [name', category', number', floor', phone_number', address',
        # room_map', max_people', area', volume']


class LocationProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    geolocation = PrimaryKeyRelatedField(
        queryset=GeoLocation.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    address = PrimaryKeyRelatedField(
        queryset=Address.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
        many=True,
    )
    # barcode_json = JSONField(required=False, allow_null=True)

    class Meta:
        model = Location
        proto_class = lara_django_base_pb2.LocationResponse

        proto_class_list = lara_django_base_pb2.LocationListResponse

        fields = "__all__"  # [name', barcode1D', barcode2D', geolocation', address', building',
        # floor', room', cabinet', shelf', drawer', box', position', URI', JSON', IRI', URL', description']


class LARASyncServerProtoSerializer(proto_serializers.ModelProtoSerializer):
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True, many=True
    )

    class Meta:
        model = LARASyncServer
        proto_class = lara_django_base_pb2.LARASyncServerResponse

        proto_class_list = lara_django_base_pb2.LARASyncServerListResponse

        fields = "__all__"  # [name', description', host', port', path', version', protocol']
