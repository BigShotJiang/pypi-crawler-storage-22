"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_base Model Context Protocol (MCP) handler *

:details: lara_django_base Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import MediaType, DataType, Namespace, Tag, ItemRole, ItemStatus, ExtraData, ExternalResource, PhysicalUnit, PhysicalStateMatter, ScientificConstant, Currency

class MediaTypeQueryTool(ModelQueryToolset):
    model = MediaType

class DataTypeQueryTool(ModelQueryToolset):
    model = DataType

class NamespaceQueryTool(ModelQueryToolset):
    model = Namespace



