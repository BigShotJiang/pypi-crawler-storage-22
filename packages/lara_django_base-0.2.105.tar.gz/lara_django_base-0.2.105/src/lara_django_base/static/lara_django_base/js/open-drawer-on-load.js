(() => {
  function openDrawerOnLoad() {
    const el = document.getElementById('drawer-toggle');
    if (!el) return;
    // Always open the drawer
    if (!el.checked) {
      el.checked = true;
      // Notify any listeners
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', openDrawerOnLoad, { once: true });
  } else {
    openDrawerOnLoad();
  }
})();