from django import template
from django.utils.safestring import mark_safe
from django.templatetags.static import static

register = template.Library()


@register.simple_tag
def icon(name, class_name="w-4 h-4", title=None, **kwargs):
    """
    Render an SVG icon from the symbols.svg sprite file.
    
    Usage:
        {% icon 'home' %}
        {% icon 'dashboard' class_name='w-6 h-6 text-blue-500' %}
        {% icon 'bell' title='Notifications' %}
    
    Args:
        name (str): The icon name (without prefix)
        class_name (str): CSS classes for styling
        title (str): Optional title for accessibility
        **kwargs: Additional HTML attributes
    
    Returns:
        SafeString: HTML for the SVG icon
    """
    # Build additional attributes
    attrs = []
    for key, value in kwargs.items():
        # Convert Python attribute names to HTML (e.g., data_value -> data-value)
        html_key = key.replace('_', '-')
        attrs.append(f'{html_key}="{value}"')
    
    attrs_str = ' ' + ' '.join(attrs) if attrs else ''
    
    # Add accessibility attributes
    aria_attr = f'aria-label="{title}"' if title else 'aria-hidden="true"'
    
    # Generate the icon HTML
    icon_html = f'''<svg class="{class_name}" {aria_attr}{attrs_str}>
    <use href="{static('lara_django_base/icons/symbols.svg')}#{name}"></use>
</svg>'''
    
    return mark_safe(icon_html)


@register.inclusion_tag('lara_django_base/includes/icon.html')
def icon_include(name, class_name="w-4 h-4", title=None):
    """
    Alternative inclusion tag approach for icons.
    
    Usage:
        {% icon_include 'home' %}
        {% icon_include 'dashboard' class_name='w-6 h-6' %}
    """
    return {
        'name': name,
        'class': class_name,
        'title': title,
    }
