"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_base high_level_interface *

:details: lara_django_base high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_base
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_base_grpc.lara_django_base_data_model as base_dm
import lara_django_base_grpc.lara_django_base_interface as base_if
from lara_django_base_grpc.abstract_interface import (
    LARAInterface,
    GRPCChannelSingleton,
    import_model_instance_from_file,
    export_model_instance_to_file,
    upload_file,
    download_file,
    update_file,
    upload_image,
    update_image,
    download_image,
    id_cache,
)

import lara_django_base_grpc.lara_django_base_data_model as base_dm

logger = logging.getLogger(__name__)


# _________________  MediaType  ______________________


class MediaTypeInterface:
    """Initialize the MediaTypeInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mediatype_client = lara_django_base_pb2_grpc.MediaTypeControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, mediatypes: list[base_dm.MediaType] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.MediaType]:
        """
        Create a list of mediatype instances.

            Returns a list of mediatype data model objects or ids_only.
        :param mediatypes: list of mediatype data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mediatype data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.mediatype_client.Create(lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump()))
                for mediatype in mediatypes
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mediatype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mediatype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        mediatype_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.MediaType]:
        """
        Retrieve a list of mediatype instances by mediatype_id, name or filter_dict.

            Returns a list of mediatype data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if mediatype_id is not None:
            try:
                res = await self.mediatype_client.Retrieve(
                    lara_django_base_pb2.MediaTypeRetrieveRequest(mediatype_id=mediatype_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving mediatype_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mediatype_client.List(lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving mediatype name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the mediatype_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].mediatype_id
        else:
            raise ValueError(f"Error retrieving mediatype_id - no or too many results found.")

    async def get_by_id(self, mediatype_id: str = None) -> base_dm.MediaType:
        """Retrieve a mediatype data model by mediatype_id."""
        try:
            res = await self.mediatype_client.Retrieve(
                lara_django_base_pb2.MediaTypeRetrieveRequest(mediatype_id=mediatype_id)
            )
            return base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mediatype_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.MediaType | str:
        """Retrieve a mediatype data model by name."""
        try:
            res = await self.mediatype_client.RetrieveByNameNamespace(
                lara_django_base_pb2.MediaTypeRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["mediatype_id"]
            else:
                return base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mediatype name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all mediatypes."""
        if filter_dict is None:
            res = await self.mediatype_client.List(lara_django_base_pb2.MediaTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mediatype_client.List(lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.mediatype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all mediatypes."""
        if self.mediatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mediatype_full_client.List(lara_django_base_pb2.MediaTypeFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mediatype_full_client.List(
                lara_django_base_pb2.MediaTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, mediatype: base_dm.MediaType = None) -> None:
        """Update a mediatype model instance."""
        try:
            res = await self.mediatype_client.Update(lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump()))
        except Exception as e:
            logger.error(f"Error updating mediatype_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a mediatype by mediatype_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.mediatype_client.Destroy(lara_django_base_pb2.MediaTypeDestroyRequest(mediatype_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mediatype_id: {e}")


# _________________  DataType  ______________________


class DataTypeInterface:
    """Initialize the DataTypeInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.datatype_client = lara_django_base_pb2_grpc.DataTypeControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, datatypes: list[base_dm.DataType] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.DataType]:
        """
        Create a list of datatype instances.

            Returns a list of datatype data model objects or ids_only.
        :param datatypes: list of datatype data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of datatype data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.datatype_client.Create(lara_django_base_pb2.DataTypeRequest(**datatype.model_dump()))
                for datatype in datatypes
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.datatype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating datatype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        datatype_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.DataType]:
        """
        Retrieve a list of datatype instances by datatype_id, name or filter_dict.

            Returns a list of datatype data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if datatype_id is not None:
            try:
                res = await self.datatype_client.Retrieve(
                    lara_django_base_pb2.DataTypeRetrieveRequest(datatype_id=datatype_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving datatype_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.datatype_client.List(lara_django_base_pb2.DataTypeListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving datatype name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the datatype_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].datatype_id
        else:
            raise ValueError(f"Error retrieving datatype_id - no or too many results found.")

    async def get_by_id(self, datatype_id: str = None) -> base_dm.DataType:
        """Retrieve a datatype data model by datatype_id."""
        try:
            res = await self.datatype_client.Retrieve(
                lara_django_base_pb2.DataTypeRetrieveRequest(datatype_id=datatype_id)
            )
            return base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving datatype_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.DataType | str:
        """Retrieve a datatype data model by name."""
        try:
            res = await self.datatype_client.RetrieveByNameNamespace(
                lara_django_base_pb2.DataTypeRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["datatype_id"]
            else:
                return base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving datatype name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all datatypes."""
        if filter_dict is None:
            res = await self.datatype_client.List(lara_django_base_pb2.DataTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.datatype_client.List(lara_django_base_pb2.DataTypeListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.datatype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all datatypes."""
        if self.datatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.datatype_full_client.List(lara_django_base_pb2.DataTypeFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.datatype_full_client.List(
                lara_django_base_pb2.DataTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, datatype: base_dm.DataType = None) -> None:
        """Update a datatype model instance."""
        try:
            res = await self.datatype_client.Update(lara_django_base_pb2.DataTypeRequest(**datatype.model_dump()))
        except Exception as e:
            logger.error(f"Error updating datatype_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a datatype by datatype_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.datatype_client.Destroy(lara_django_base_pb2.DataTypeDestroyRequest(datatype_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting datatype_id: {e}")


# _________________  Namespace  ______________________


class NamespaceInterface:
    """Initialize the NamespaceInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespaceURI_client=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id
        self.namespaceURI_client = namespaceURI_client
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.id_cache = {}

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if namespaceURI_client is None:
            self.namespaceURI_client = lara_django_base_pb2_grpc.NamespaceByURIControllerStub(channel)
        self.namespace_client = lara_django_base_pb2_grpc.NamespaceControllerStub(channel)

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
        default_namespace_id = None

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespaceURI_client = lara_django_base_pb2_grpc.NamespaceByURIControllerStub(channel)

        try:
            res = await namespaceURI_client.Retrieve(
                lara_django_base_pb2.NamespaceByURIRetrieveRequest(uri=default_namespace_uri)
            )
            default_namespace_id = res.namespace_id
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespaceURI_client=namespaceURI_client,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=None)
    async def create(
        self, namespaces: list[base_dm.Namespace] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.Namespace]:
        """
        Create a list of namespace instances.

            Returns a list of namespace data model objects or ids_only.
        :param namespaces: list of namespace data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of namespace data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.namespace_client.Create(lara_django_base_pb2.NamespaceRequest(**namespace.model_dump()))
                for namespace in namespaces
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.namespace_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating namespace: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_id: str | None = None,
        uri: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Namespace]:
        """
        Retrieve a list of namespace instances by namespace_id, name or filter_dict.

            Returns a list of namespace data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if namespace_id is not None:
            try:
                res = await self.namespace_client.Retrieve(
                    lara_django_base_pb2.NamespaceRetrieveRequest(namespace_id=namespace_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if uri is not None:
            filter_dict["uri"] = uri

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.namespace_client.List(lara_django_base_pb2.NamespaceListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving namespace uri: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(self, namespace_uri: str | None = None) -> str:
        """Retrieve the namespace_id for a given namespace_uri."""
        try:
            res = await self.namespaceURI_client.Retrieve(
                lara_django_base_pb2.NamespaceByURIRetrieveRequest(uri=namespace_uri)
            )
            namespace_id = res.namespace_id
            self.id_cache[namespace_uri] = namespace_id
            return namespace_id
        # """ retrieve the namespace_id for a given namespace_name,
        #        namespace_name_display or iri
        # """

        # results_list = await self.retrieve(uri=uri, filter_dict={}, raw=True)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
            # if len(results_list) == 1 :
            #     return results_list[0].namespace_id
            # else:
            raise ValueError(f"Error retrieving namespace_id - no or too many results found.")

    async def get_by_id(self, namespace_id: str | None = None) -> base_dm.Namespace:
        """Retrieve a namespace data model by namespace_id."""
        try:
            res = await self.namespace_client.Retrieve(
                lara_django_base_pb2.NamespaceRetrieveRequest(namespace_id=namespace_id)
            )
            return base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    async def get_by_name(self, uri: str | None = None, id_only: bool = False) -> base_dm.Namespace | str:
        """Retrieve a namespace data model by name."""
        try:
            res = await self.namespaceURI_client.Retrieve(lara_django_base_pb2.NamespaceByURIRetrieveRequest(uri=uri))
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["namespace_id"]
            else:
                return base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving namespace uri: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all namespaces."""
        if filter_dict is None:
            res = await self.namespace_client.List(lara_django_base_pb2.NamespaceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.namespace_client.List(lara_django_base_pb2.NamespaceListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.namespace_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all namespaces."""
        if self.namespace_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.namespace_full_client.List(lara_django_base_pb2.NamespaceFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.namespace_full_client.List(
                lara_django_base_pb2.NamespaceFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, namespace: base_dm.Namespace = None) -> None:
        """Update a namespace model instance."""
        try:
            res = await self.namespace_client.Update(lara_django_base_pb2.NamespaceRequest(**namespace.model_dump()))
        except Exception as e:
            logger.error(f"Error updating namespace_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a namespace by namespace_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.namespace_client.Destroy(lara_django_base_pb2.NamespaceDestroyRequest(namespace_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting namespace_id: {e}")


# _________________  Tag  ______________________


class TagInterface:
    """Initialize the TagInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.tag_client = lara_django_base_pb2_grpc.TagControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, tags: list[base_dm.Tag] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.Tag]:
        """
        Create a list of tag instances.

            Returns a list of tag data model objects or ids_only.
        :param tags: list of tag data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of tag data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.tag_client.Create(lara_django_base_pb2.TagRequest(**tag.model_dump())) for tag in tags
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.tag_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating tag: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        tag_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Tag]:
        """
        Retrieve a list of tag instances by tag_id, name or filter_dict.

            Returns a list of tag data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if tag_id is not None:
            try:
                res = await self.tag_client.Retrieve(lara_django_base_pb2.TagRetrieveRequest(tag_id=tag_id))
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving tag_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.tag_client.List(lara_django_base_pb2.TagListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)) for res in results]
        except Exception as e:
            logger.error(f"Error retrieving tag name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the tag_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].tag_id
        else:
            raise ValueError(f"Error retrieving tag_id - no or too many results found.")

    async def get_by_id(self, tag_id: str = None) -> base_dm.Tag:
        """Retrieve a tag data model by tag_id."""
        try:
            res = await self.tag_client.Retrieve(lara_django_base_pb2.TagRetrieveRequest(tag_id=tag_id))
            return base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving tag_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.Tag | str:
        """Retrieve a tag data model by name."""
        try:
            res = await self.tag_client.RetrieveByNameNamespace(
                lara_django_base_pb2.TagRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["tag_id"]
            else:
                return base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving tag name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all tags."""
        if filter_dict is None:
            res = await self.tag_client.List(lara_django_base_pb2.TagListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.tag_client.List(lara_django_base_pb2.TagListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.tag_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all tags."""
        if self.tag_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.tag_full_client.List(lara_django_base_pb2.TagFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.tag_full_client.List(lara_django_base_pb2.TagFullListRequest(), metadata=metadata)

    @import_model_instance_from_file()
    async def update(self, tag: base_dm.Tag = None) -> None:
        """Update a tag model instance."""
        try:
            res = await self.tag_client.Update(lara_django_base_pb2.TagRequest(**tag.model_dump()))
        except Exception as e:
            logger.error(f"Error updating tag_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a tag by tag_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.tag_client.Destroy(lara_django_base_pb2.TagDestroyRequest(tag_id=id)) for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting tag_id: {e}")


# _________________  ItemRole  ______________________


class ItemRoleInterface:
    """Initialize the ItemRoleInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.itemrole_client = lara_django_base_pb2_grpc.ItemRoleControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, itemroles: list[base_dm.ItemRole] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.ItemRole]:
        """
        Create a list of itemrole instances.

            Returns a list of itemrole data model objects or ids_only.
        :param itemroles: list of itemrole data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of itemrole data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.itemrole_client.Create(lara_django_base_pb2.ItemRoleRequest(**itemrole.model_dump()))
                for itemrole in itemroles
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.itemrole_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating itemrole: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        itemrole_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.ItemRole]:
        """
        Retrieve a list of itemrole instances by itemrole_id, name or filter_dict.

            Returns a list of itemrole data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if itemrole_id is not None:
            try:
                res = await self.itemrole_client.Retrieve(
                    lara_django_base_pb2.ItemRoleRetrieveRequest(itemrole_id=itemrole_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.ItemRole(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving itemrole_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.itemrole_client.List(lara_django_base_pb2.ItemRoleListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.ItemRole(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving itemrole name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the itemrole_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].itemrole_id
        else:
            raise ValueError(f"Error retrieving itemrole_id - no or too many results found.")

    async def get_by_id(self, itemrole_id: str = None) -> base_dm.ItemRole:
        """Retrieve a itemrole data model by itemrole_id."""
        try:
            res = await self.itemrole_client.Retrieve(
                lara_django_base_pb2.ItemRoleRetrieveRequest(itemrole_id=itemrole_id)
            )
            return base_dm.ItemRole(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemrole_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.ItemRole | str:
        """Retrieve a itemrole data model by name."""
        try:
            res = await self.itemrole_client.RetrieveByNameNamespace(
                lara_django_base_pb2.ItemRoleRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["itemrole_id"]
            else:
                return base_dm.ItemRole(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemrole name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all itemroles."""
        if filter_dict is None:
            res = await self.itemrole_client.List(lara_django_base_pb2.ItemRoleListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.itemrole_client.List(lara_django_base_pb2.ItemRoleListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.itemrole_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all itemroles."""
        if self.itemrole_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.itemrole_full_client.List(lara_django_base_pb2.ItemRoleFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.itemrole_full_client.List(
                lara_django_base_pb2.ItemRoleFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, itemrole: base_dm.ItemRole = None) -> None:
        """Update a itemrole model instance."""
        try:
            res = await self.itemrole_client.Update(lara_django_base_pb2.ItemRoleRequest(**itemrole.model_dump()))
        except Exception as e:
            logger.error(f"Error updating itemrole_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a itemrole by itemrole_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.itemrole_client.Destroy(lara_django_base_pb2.ItemRoleDestroyRequest(itemrole_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting itemrole_id: {e}")


# _________________  ItemStatus  ______________________


class ItemStatusInterface:
    """Initialize the ItemStatusInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.itemstatus_client = lara_django_base_pb2_grpc.ItemStatusControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, itemstatus: list[base_dm.ItemStatus] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.ItemStatus]:
        """
        Create a list of itemstatus instances.

            Returns a list of itemstatus data model objects or ids_only.
        :param itemstatus: list of itemstatus data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of itemstatus data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.itemstatus_client.Create(lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump()))
                for itemstatus in itemstatus
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.itemstatus_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating itemstatus: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        itemstatus_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.ItemStatus]:
        """
        Retrieve a list of itemstatus instances by itemstatus_id, name or filter_dict.

            Returns a list of itemstatus data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if itemstatus_id is not None:
            try:
                res = await self.itemstatus_client.Retrieve(
                    lara_django_base_pb2.ItemStatusRetrieveRequest(itemstatus_id=itemstatus_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving itemstatus_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.itemstatus_client.List(lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving itemstatus name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the itemstatus_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].itemstatus_id
        else:
            raise ValueError(f"Error retrieving itemstatus_id - no or too many results found.")

    async def get_by_id(self, itemstatus_id: str = None) -> base_dm.ItemStatus:
        """Retrieve a itemstatus data model by itemstatus_id."""
        try:
            res = await self.itemstatus_client.Retrieve(
                lara_django_base_pb2.ItemStatusRetrieveRequest(itemstatus_id=itemstatus_id)
            )
            return base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemstatus_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.ItemStatus | str:
        """Retrieve a itemstatus data model by name."""
        try:
            res = await self.itemstatus_client.RetrieveByNameNamespace(
                lara_django_base_pb2.ItemStatusRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["itemstatus_id"]
            else:
                return base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemstatus name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all itemstatuss."""
        if filter_dict is None:
            res = await self.itemstatus_client.List(lara_django_base_pb2.ItemStatusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.itemstatus_client.List(lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.itemstatus_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all itemstatuss."""
        if self.itemstatus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.itemstatus_full_client.List(lara_django_base_pb2.ItemStatusFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.itemstatus_full_client.List(
                lara_django_base_pb2.ItemStatusFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, itemstatus: base_dm.ItemStatus = None) -> None:
        """Update a itemstatus model instance."""
        try:
            res = await self.itemstatus_client.Update(lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump()))
        except Exception as e:
            logger.error(f"Error updating itemstatus_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a itemstatus by itemstatus_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.itemstatus_client.Destroy(lara_django_base_pb2.ItemStatusDestroyRequest(itemstatus_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting itemstatus_id: {e}")


# _________________  ExtraData  ______________________


class ExtraDataInterface:
    """Initialize the ExtraDataInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespace_if=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_base_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_base_pb2_grpc.ExtraDataControllerStub(channel)

        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_base_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_base_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_base_pb2.ImageUploadChunk

        # self.extradata_full_client = lara_django_base_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str | None = None):
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespace_if=namespace_if,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(
        self, extradata: list[base_dm.ExtraData] | None = None, ids_only: bool = False, namespace_uri: str = None
    ) -> list[str] | list[base_dm.ExtraData]:
        """
        Create a list of extradata instances.

            Returns a list of extradata data model objects or ids_only.

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None
        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_base_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if extradata.namespace == "" or extradata.namespace == "default":
                extradata.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = (
                self.extradata_client.Create(lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump()))
                for extradata in extradata
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str | None = None,
        extradata_id: str | None = None,
        name: str | None = None,
        # name_display: str | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.ExtraData]:
        """
        Retrieve a list of extradata instances by extradata_id, name or filter_dict.

            Returns a list of extradata data model objects.
                If raw is True, the raw protobuf objects are returned.
                If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")

        results_list = []
        if extradata_id is not None:
            try:
                res = await self.extradata_client.Retrieve(
                    lara_django_base_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        namespace_uri: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the extradata_id for a given name, name_display or iri."""

        results_list = await self.retrieve(name=name, namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1:
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> base_dm.ExtraData:
        """Retrieve a extradata data model by extradata_id."""
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_base_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(
        self, name: str = None, namespace_uri: str = None, id_only: bool = False
    ) -> base_dm.ExtraData | str:
        """Retrieve a extradata data model by name."""
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_base_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return base_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

    @download_file  # needed for file download
    async def get_file(self, extradata_id: str | None = None, id_only: bool = True) -> bytes | None:
        """Retrieve a file by data_id."""
        self.item_id = extradata_id

    async def get_file_by_name(
        self,
        name: str | None = None,
        namespace_uri: str | None = None,
        filename_target: str | None = None,
        as_byte_str: bool | None = None,
    ) -> bytes | None:
        """Retrieve a file by name."""
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(
                extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True
            )
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

    @download_image  # needed for image download
    async def get_image(self, extradata_id: str = None, id_only: bool = True) -> bytes | None:
        """Retrieve an image by data_id."""
        self.item_id = extradata_id

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all extradatas."""
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_base_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all extradatas."""
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(lara_django_base_pb2.ExtraDataFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_base_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata: base_dm.ExtraData = None) -> None:
        """Update a extradata model instance."""
        try:
            res = await self.extradata_client.Update(lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump()))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a extradata by extradata_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.extradata_client.Destroy(lara_django_base_pb2.ExtraDataDestroyRequest(extradata_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")


# _________________  ExternalResource  ______________________


class ExternalResourceInterface:
    """Initialize the ExternalResourceInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespace_if=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.externalresource_class_client = (
        #     lara_django_base_pb2_grpc.ExternalResourceclassByIRIControllerStub(channel)
        # )

        self.externalresource_client = lara_django_base_pb2_grpc.ExternalResourceControllerStub(channel)

        # self.externalresource_full_client = lara_django_base_pb2_grpc.ExternalResourceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespace_if=namespace_if,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file()
    async def create(
        self,
        externalresources: list[base_dm.ExternalResource] | None = None,
        ids_only: bool = False,
        namespace_uri: str = None,
    ) -> list[str] | list[base_dm.ExternalResource]:
        """
        Create a list of externalresource instances.

            Returns a list of externalresource data model objects or ids_only.

        :param externalresources: list of externalresource data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of externalresource data model objects or ids_only
        """
        externalresourceclass_id = None
        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if externalresource_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.externalresource_class_client.Retrieve(
        #         lara_django_base_pb2.ExternalResourceclassRetrieveRequest(iri=externalresource_class_iri)
        #     )
        #     externalresourceclass_id = res.externalresourceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving externalresourceclass_id: {e}")
        for externalresource in externalresources:
            if externalresource.namespace == "" or externalresource.namespace == "default":
                externalresource.namespace = namespace_id
            # externalresource.externalresource_class = externalresourceclass_id # uncomment if a model class is used

        try:
            create_coroutines = (
                self.externalresource_client.Create(
                    lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump())
                )
                for externalresource in externalresources
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [
                    MessageToDict(item, preserving_proto_field_name=True).get("externalresource_id") for item in res
                ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating externalresource: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str | None = None,
        externalresource_id: str | None = None,
        name: str | None = None,
        # name_display: str | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.ExternalResource]:
        """
        Retrieve a list of externalresource instances by externalresource_id, name or filter_dict.

            Returns a list of externalresource data model objects.
                If raw is True, the raw protobuf objects are returned.
                If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")

        results_list = []
        if externalresource_id is not None:
            try:
                res = await self.externalresource_client.Retrieve(
                    lara_django_base_pb2.ExternalResourceRetrieveRequest(externalresource_id=externalresource_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(
                        base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True))
                    )
            except Exception as e:
                logger.error(f"Error retrieving externalresource_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.externalresource_client.List(
                lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving externalresource name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        namespace_uri: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the externalresource_id for a given name, name_display or iri."""

        results_list = await self.retrieve(name=name, namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1:
            return results_list[0].externalresource_id
        else:
            raise ValueError(f"Error retrieving externalresource_id - no or too many results found.")

    async def get_by_id(self, externalresource_id: str = None, id_only: bool = False) -> base_dm.ExternalResource:
        """Retrieve a externalresource data model by externalresource_id."""
        try:
            res = await self.externalresource_client.Retrieve(
                lara_django_base_pb2.ExternalResourceRetrieveRequest(externalresource_id=externalresource_id)
            )
            item = base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.externalresource_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving externalresource_id: {e}")

    async def get_by_name(
        self, name: str = None, namespace_uri: str = None, id_only: bool = False
    ) -> base_dm.ExternalResource | str:
        """Retrieve a externalresource data model by name."""
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.externalresource_client.RetrieveByNameNamespace(
                lara_django_base_pb2.ExternalResourceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["externalresource_id"]
            if id_only:
                return self.item_id
            else:
                return base_dm.ExternalResource(**item)
        except Exception as e:
            logger.error(f"Error retrieving externalresource name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all externalresources."""
        if filter_dict is None:
            res = await self.externalresource_client.List(lara_django_base_pb2.ExternalResourceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.externalresource_client.List(
                lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.externalresource_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all externalresources."""
        if self.externalresource_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.externalresource_full_client.List(lara_django_base_pb2.ExternalResourceFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.externalresource_full_client.List(
                lara_django_base_pb2.ExternalResourceFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, externalresource: base_dm.ExternalResource = None) -> None:
        """Update a externalresource model instance."""
        try:
            res = await self.externalresource_client.Update(
                lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating externalresource_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a externalresource by externalresource_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.externalresource_client.Destroy(
                    lara_django_base_pb2.ExternalResourceDestroyRequest(externalresource_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting externalresource_id: {e}")


# _________________  PhysicalUnit  ______________________


class PhysicalUnitInterface:
    """Initialize the PhysicalUnitInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.physicalunit_client = lara_django_base_pb2_grpc.PhysicalUnitControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, physicalunits: list[base_dm.PhysicalUnit] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.PhysicalUnit]:
        """
        Create a list of physicalunit instances.

            Returns a list of physicalunit data model objects or ids_only.
        :param physicalunits: list of physicalunit data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of physicalunit data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.physicalunit_client.Create(lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump()))
                for physicalunit in physicalunits
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalunit_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating physicalunit: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        physicalunit_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.PhysicalUnit]:
        """
        Retrieve a list of physicalunit instances by physicalunit_id, name or filter_dict.

            Returns a list of physicalunit data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if physicalunit_id is not None:
            try:
                res = await self.physicalunit_client.Retrieve(
                    lara_django_base_pb2.PhysicalUnitRetrieveRequest(physicalunit_id=physicalunit_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving physicalunit_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.physicalunit_client.List(lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving physicalunit name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the physicalunit_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].physicalunit_id
        else:
            raise ValueError(f"Error retrieving physicalunit_id - no or too many results found.")

    async def get_by_id(self, physicalunit_id: str = None) -> base_dm.PhysicalUnit:
        """Retrieve a physicalunit data model by physicalunit_id."""
        try:
            res = await self.physicalunit_client.Retrieve(
                lara_django_base_pb2.PhysicalUnitRetrieveRequest(physicalunit_id=physicalunit_id)
            )
            return base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalunit_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.PhysicalUnit | str:
        """Retrieve a physicalunit data model by name."""
        try:
            res = await self.physicalunit_client.RetrieveByNameNamespace(
                lara_django_base_pb2.PhysicalUnitRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["physicalunit_id"]
            else:
                return base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalunit name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all physicalunits."""
        if filter_dict is None:
            res = await self.physicalunit_client.List(lara_django_base_pb2.PhysicalUnitListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalunit_client.List(lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.physicalunit_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all physicalunits."""
        if self.physicalunit_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalunit_full_client.List(lara_django_base_pb2.PhysicalUnitFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalunit_full_client.List(
                lara_django_base_pb2.PhysicalUnitFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, physicalunit: base_dm.PhysicalUnit = None) -> None:
        """Update a physicalunit model instance."""
        try:
            res = await self.physicalunit_client.Update(
                lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating physicalunit_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a physicalunit by physicalunit_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.physicalunit_client.Destroy(lara_django_base_pb2.PhysicalUnitDestroyRequest(physicalunit_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting physicalunit_id: {e}")


# _________________  PhysicalStateMatter  ______________________


class PhysicalStateMatterInterface:
    """Initialize the PhysicalStateMatterInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.physicalstatematter_client = lara_django_base_pb2_grpc.PhysicalStateMatterControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, physicalstatesmatter: list[base_dm.PhysicalStateMatter] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.PhysicalStateMatter]:
        """
        Create a list of physicalstatematter instances.

            Returns a list of physicalstatematter data model objects or ids_only.
        :param physicalstatesmatter: list of physicalstatematter data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of physicalstatematter data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.physicalstatematter_client.Create(
                    lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump())
                )
                for physicalstatematter in physicalstatesmatter
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalstatematter_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating physicalstatematter: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        physicalstatematter_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.PhysicalStateMatter]:
        """
        Retrieve a list of physicalstatematter instances by physicalstatematter_id, name or filter_dict.

            Returns a list of physicalstatematter data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if physicalstatematter_id is not None:
            try:
                res = await self.physicalstatematter_client.Retrieve(
                    lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(
                        physicalstatematter_id=physicalstatematter_id
                    )
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(
                        base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
                    )
            except Exception as e:
                logger.error(f"Error retrieving physicalstatematter_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.physicalstatematter_client.List(
                lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
                    for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the physicalstatematter_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].physicalstatematter_id
        else:
            raise ValueError(f"Error retrieving physicalstatematter_id - no or too many results found.")

    async def get_by_id(self, physicalstatematter_id: str = None) -> base_dm.PhysicalStateMatter:
        """Retrieve a physicalstatematter data model by physicalstatematter_id."""
        try:
            res = await self.physicalstatematter_client.Retrieve(
                lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(physicalstatematter_id=physicalstatematter_id)
            )
            return base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.PhysicalStateMatter | str:
        """Retrieve a physicalstatematter data model by name."""
        try:
            res = await self.physicalstatematter_client.RetrieveByNameNamespace(
                lara_django_base_pb2.PhysicalStateMatterRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["physicalstatematter_id"]
            else:
                return base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all physicalstatematters."""
        if filter_dict is None:
            res = await self.physicalstatematter_client.List(lara_django_base_pb2.PhysicalStateMatterListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalstatematter_client.List(
                lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.physicalstatematter_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all physicalstatematters."""
        if self.physicalstatematter_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, physicalstatematter: base_dm.PhysicalStateMatter = None) -> None:
        """Update a physicalstatematter model instance."""
        try:
            res = await self.physicalstatematter_client.Update(
                lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating physicalstatematter_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a physicalstatematter by physicalstatematter_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.physicalstatematter_client.Destroy(
                    lara_django_base_pb2.PhysicalStateMatterDestroyRequest(physicalstatematter_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting physicalstatematter_id: {e}")


# _________________  ScientificConstant  ______________________


class ScientificConstantInterface:
    """Initialize the ScientificConstantInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.scientificconstant_client = lara_django_base_pb2_grpc.ScientificConstantControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, scientificconstants: list[base_dm.ScientificConstant] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.ScientificConstant]:
        """
        Create a list of scientificconstant instances.

            Returns a list of scientificconstant data model objects or ids_only.
        :param scientificconstants: list of scientificconstant data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of scientificconstant data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.scientificconstant_client.Create(
                    lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump())
                )
                for scientificconstant in scientificconstants
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.scientificconstant_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating scientificconstant: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        scientificconstant_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.ScientificConstant]:
        """
        Retrieve a list of scientificconstant instances by scientificconstant_id, name or filter_dict.

            Returns a list of scientificconstant data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if scientificconstant_id is not None:
            try:
                res = await self.scientificconstant_client.Retrieve(
                    lara_django_base_pb2.ScientificConstantRetrieveRequest(scientificconstant_id=scientificconstant_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(
                        base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
                    )
            except Exception as e:
                logger.error(f"Error retrieving scientificconstant_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.scientificconstant_client.List(
                lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
                    for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the scientificconstant_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].scientificconstant_id
        else:
            raise ValueError(f"Error retrieving scientificconstant_id - no or too many results found.")

    async def get_by_id(self, scientificconstant_id: str = None) -> base_dm.ScientificConstant:
        """Retrieve a scientificconstant data model by scientificconstant_id."""
        try:
            res = await self.scientificconstant_client.Retrieve(
                lara_django_base_pb2.ScientificConstantRetrieveRequest(scientificconstant_id=scientificconstant_id)
            )
            return base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.ScientificConstant | str:
        """Retrieve a scientificconstant data model by name."""
        try:
            res = await self.scientificconstant_client.RetrieveByNameNamespace(
                lara_django_base_pb2.ScientificConstantRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["scientificconstant_id"]
            else:
                return base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all scientificconstants."""
        if filter_dict is None:
            res = await self.scientificconstant_client.List(lara_django_base_pb2.ScientificConstantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.scientificconstant_client.List(
                lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.scientificconstant_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all scientificconstants."""
        if self.scientificconstant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, scientificconstant: base_dm.ScientificConstant = None) -> None:
        """Update a scientificconstant model instance."""
        try:
            res = await self.scientificconstant_client.Update(
                lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating scientificconstant_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a scientificconstant by scientificconstant_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.scientificconstant_client.Destroy(
                    lara_django_base_pb2.ScientificConstantDestroyRequest(scientificconstant_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting scientificconstant_id: {e}")


# _________________  Currency  ______________________


class CurrencyInterface:
    """Initialize the CurrencyInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.currency_client = lara_django_base_pb2_grpc.CurrencyControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, currencies: list[base_dm.Currency] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.Currency]:
        """
        Create a list of currency instances.

            Returns a list of currency data model objects or ids_only.
        :param currencies: list of currency data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of currency data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.currency_client.Create(lara_django_base_pb2.CurrencyRequest(**currency.model_dump()))
                for currency in currencies
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.currency_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating currency: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        currency_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Currency]:
        """
        Retrieve a list of currency instances by currency_id, name or filter_dict.

            Returns a list of currency data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if currency_id is not None:
            try:
                res = await self.currency_client.Retrieve(
                    lara_django_base_pb2.CurrencyRetrieveRequest(currency_id=currency_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving currency_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.currency_client.List(lara_django_base_pb2.CurrencyListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving currency name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the currency_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].currency_id
        else:
            raise ValueError(f"Error retrieving currency_id - no or too many results found.")

    async def get_by_id(self, currency_id: str = None) -> base_dm.Currency:
        """Retrieve a currency data model by currency_id."""
        try:
            res = await self.currency_client.Retrieve(
                lara_django_base_pb2.CurrencyRetrieveRequest(currency_id=currency_id)
            )
            return base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving currency_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.Currency | str:
        """Retrieve a currency data model by name."""
        try:
            res = await self.currency_client.RetrieveByNameNamespace(
                lara_django_base_pb2.CurrencyRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["currency_id"]
            else:
                return base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving currency name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all currencys."""
        if filter_dict is None:
            res = await self.currency_client.List(lara_django_base_pb2.CurrencyListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.currency_client.List(lara_django_base_pb2.CurrencyListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.currency_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all currencys."""
        if self.currency_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.currency_full_client.List(lara_django_base_pb2.CurrencyFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.currency_full_client.List(
                lara_django_base_pb2.CurrencyFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, currency: base_dm.Currency = None) -> None:
        """Update a currency model instance."""
        try:
            res = await self.currency_client.Update(lara_django_base_pb2.CurrencyRequest(**currency.model_dump()))
        except Exception as e:
            logger.error(f"Error updating currency_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a currency by currency_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.currency_client.Destroy(lara_django_base_pb2.CurrencyDestroyRequest(currency_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting currency_id: {e}")


# _________________  LARAExtension  ______________________


class LARAExtensionInterface:
    """Initialize the LARAExtensionInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.laraextension_client = lara_django_base_pb2_grpc.LARAExtensionControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, laraextensions: list[base_dm.LARAExtension] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.LARAExtension]:
        """
        Create a list of laraextension instances.

            Returns a list of laraextension data model objects or ids_only.
        :param laraextensions: list of laraextension data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of laraextension data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.laraextension_client.Create(
                    lara_django_base_pb2.LARAExtensionRequest(**laraextension.model_dump())
                )
                for laraextension in laraextensions
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.laraextension_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating laraextension: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        laraextension_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.LARAExtension]:
        """
        Retrieve a list of laraextension instances by laraextension_id, name or filter_dict.

            Returns a list of laraextension data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if laraextension_id is not None:
            try:
                res = await self.laraextension_client.Retrieve(
                    lara_django_base_pb2.LARAExtensionRetrieveRequest(laraextension_id=laraextension_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving laraextension_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.laraextension_client.List(
                lara_django_base_pb2.LARAExtensionListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving laraextension name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the laraextension_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].laraextension_id
        else:
            raise ValueError(f"Error retrieving laraextension_id - no or too many results found.")

    async def get_by_id(self, laraextension_id: str = None) -> base_dm.LARAExtension:
        """Retrieve a laraextension data model by laraextension_id."""
        try:
            res = await self.laraextension_client.Retrieve(
                lara_django_base_pb2.LARAExtensionRetrieveRequest(laraextension_id=laraextension_id)
            )
            return base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving laraextension_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.LARAExtension | str:
        """Retrieve a laraextension data model by name."""
        try:
            res = await self.laraextension_client.RetrieveByNameNamespace(
                lara_django_base_pb2.LARAExtensionRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["laraextension_id"]
            else:
                return base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving laraextension name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all laraextensions."""
        if filter_dict is None:
            res = await self.laraextension_client.List(lara_django_base_pb2.LARAExtensionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.laraextension_client.List(
                lara_django_base_pb2.LARAExtensionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.laraextension_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all laraextensions."""
        if self.laraextension_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.laraextension_full_client.List(lara_django_base_pb2.LARAExtensionFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.laraextension_full_client.List(
                lara_django_base_pb2.LARAExtensionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, laraextension: base_dm.LARAExtension = None) -> None:
        """Update a laraextension model instance."""
        try:
            res = await self.laraextension_client.Update(
                lara_django_base_pb2.LARAExtensionRequest(**laraextension.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating laraextension_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a laraextension by laraextension_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.laraextension_client.Destroy(lara_django_base_pb2.LARAExtensionDestroyRequest(laraextension_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting laraextension_id: {e}")


# _________________  GeoLocation  ______________________


class GeoLocationInterface:
    """Initialize the GeoLocationInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.geolocation_client = lara_django_base_pb2_grpc.GeoLocationControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, geolocations: list[base_dm.GeoLocation] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.GeoLocation]:
        """
        Create a list of geolocation instances.

            Returns a list of geolocation data model objects or ids_only.
        :param geolocations: list of geolocation data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of geolocation data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.geolocation_client.Create(lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump()))
                for geolocation in geolocations
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.geolocation_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating geolocation: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        geolocation_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.GeoLocation]:
        """
        Retrieve a list of geolocation instances by geolocation_id, name or filter_dict.

            Returns a list of geolocation data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if geolocation_id is not None:
            try:
                res = await self.geolocation_client.Retrieve(
                    lara_django_base_pb2.GeoLocationRetrieveRequest(geolocation_id=geolocation_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving geolocation_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.geolocation_client.List(lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving geolocation name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the geolocation_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].geolocation_id
        else:
            raise ValueError(f"Error retrieving geolocation_id - no or too many results found.")

    async def get_by_id(self, geolocation_id: str = None) -> base_dm.GeoLocation:
        """Retrieve a geolocation data model by geolocation_id."""
        try:
            res = await self.geolocation_client.Retrieve(
                lara_django_base_pb2.GeoLocationRetrieveRequest(geolocation_id=geolocation_id)
            )
            return base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving geolocation_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.GeoLocation | str:
        """Retrieve a geolocation data model by name."""
        try:
            res = await self.geolocation_client.RetrieveByNameNamespace(
                lara_django_base_pb2.GeoLocationRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["geolocation_id"]
            else:
                return base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving geolocation name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all geolocations."""
        if filter_dict is None:
            res = await self.geolocation_client.List(lara_django_base_pb2.GeoLocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.geolocation_client.List(lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.geolocation_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all geolocations."""
        if self.geolocation_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.geolocation_full_client.List(lara_django_base_pb2.GeoLocationFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.geolocation_full_client.List(
                lara_django_base_pb2.GeoLocationFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, geolocation: base_dm.GeoLocation = None) -> None:
        """Update a geolocation model instance."""
        try:
            res = await self.geolocation_client.Update(
                lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating geolocation_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a geolocation by geolocation_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.geolocation_client.Destroy(lara_django_base_pb2.GeoLocationDestroyRequest(geolocation_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting geolocation_id: {e}")


# _________________  Country  ______________________


class CountryInterface:
    """Initialize the CountryInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.country_client = lara_django_base_pb2_grpc.CountryControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, countries: list[base_dm.Country] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.Country]:
        """
        Create a list of country instances.

            Returns a list of country data model objects or ids_only.
        :param countries: list of country data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of country data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.country_client.Create(lara_django_base_pb2.CountryRequest(**country.model_dump()))
                for country in countries
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.country_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating country: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        country_id: str | None = None,
        name: str | None = None,
        name_local: str | None = None,
        alpha2code: str | None = None,
        alpha3code: str | None = None,
        numeric_code: int | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Country]:
        """
        Retrieve a list of country instances by country_id, name or filter_dict.

            Returns a list of country data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if country_id is not None:
            try:
                res = await self.country_client.Retrieve(
                    lara_django_base_pb2.CountryRetrieveRequest(country_id=country_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving country_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if name_local is not None:
            filter_dict["name_local"] = name_local
        if alpha2code is not None:
            filter_dict["alpha2code"] = alpha2code.upper()
        if alpha3code is not None:
            filter_dict["alpha3code"] = alpha3code.upper()
        if numeric_code is not None:
            filter_dict["numeric_code"] = numeric_code

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.country_client.List(lara_django_base_pb2.CountryListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving country name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        name_local: str | None = None,
        alpha2code: str | None = None,
        alpha3code: str | None = None,
        numeric_code: int | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the country_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(
            name=name,
            name_local=name_local,
            alpha2code=alpha2code,
            alpha3code=alpha3code,
            numeric_code=numeric_code,
            filter_dict=filter_dict,  # if one does not reset the filter_dict, the previous filter_dict will be used, why ??
            raw=True,
        )

        if len(results_list) == 1:
            return results_list[0].country_id
        else:
            raise ValueError(f"Error retrieving country_id - no or too many results found.")

    async def get_by_id(self, country_id: str = None) -> base_dm.Country:
        """Retrieve a country data model by country_id."""
        try:
            res = await self.country_client.Retrieve(lara_django_base_pb2.CountryRetrieveRequest(country_id=country_id))
            return base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving country_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.Country | str:
        """Retrieve a country data model by name."""
        try:
            res = await self.country_client.RetrieveByNameNamespace(
                lara_django_base_pb2.CountryRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["country_id"]
            else:
                return base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving country name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all countrys."""
        if filter_dict is None:
            res = await self.country_client.List(lara_django_base_pb2.CountryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.country_client.List(lara_django_base_pb2.CountryListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.country_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all countrys."""
        if self.country_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.country_full_client.List(lara_django_base_pb2.CountryFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.country_full_client.List(lara_django_base_pb2.CountryFullListRequest(), metadata=metadata)

    @import_model_instance_from_file()
    async def update(self, country: base_dm.Country = None) -> None:
        """Update a country model instance."""
        try:
            res = await self.country_client.Update(lara_django_base_pb2.CountryRequest(**country.model_dump()))
        except Exception as e:
            logger.error(f"Error updating country_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a country by country_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.country_client.Destroy(lara_django_base_pb2.CountryDestroyRequest(country_id=id)) for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting country_id: {e}")


# _________________  SubdivisionType  ______________________


class SubdivisionTypeInterface:
    """Initialize the SubdivisionTypeInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.subdivisiontype_client = lara_django_base_pb2_grpc.SubdivisionTypeControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, subdivisiontypes: list[base_dm.SubdivisionType] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.SubdivisionType]:
        """
        Create a list of subdivisiontype instances.

            Returns a list of subdivisiontype data model objects or ids_only.
        :param subdivisiontypes: list of subdivisiontype data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of subdivisiontype data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.subdivisiontype_client.Create(
                    lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump())
                )
                for subdivisiontype in subdivisiontypes
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.subdivisiontype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating subdivisiontype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        subdivisiontype_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.SubdivisionType]:
        """
        Retrieve a list of subdivisiontype instances by subdivisiontype_id, name or filter_dict.

            Returns a list of subdivisiontype data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if subdivisiontype_id is not None:
            try:
                res = await self.subdivisiontype_client.Retrieve(
                    lara_django_base_pb2.SubdivisionTypeRetrieveRequest(subdivisiontype_id=subdivisiontype_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving subdivisiontype_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.subdivisiontype_client.List(
                lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the subdivisiontype_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].subdivisiontype_id
        else:
            raise ValueError(f"Error retrieving subdivisiontype_id - no or too many results found.")

    async def get_by_id(self, subdivisiontype_id: str = None) -> base_dm.SubdivisionType:
        """Retrieve a subdivisiontype data model by subdivisiontype_id."""
        try:
            res = await self.subdivisiontype_client.Retrieve(
                lara_django_base_pb2.SubdivisionTypeRetrieveRequest(subdivisiontype_id=subdivisiontype_id)
            )
            return base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.SubdivisionType | str:
        """Retrieve a subdivisiontype data model by name."""
        try:
            res = await self.subdivisiontype_client.RetrieveByNameNamespace(
                lara_django_base_pb2.SubdivisionTypeRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["subdivisiontype_id"]
            else:
                return base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all subdivisiontypes."""
        if filter_dict is None:
            res = await self.subdivisiontype_client.List(lara_django_base_pb2.SubdivisionTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.subdivisiontype_client.List(
                lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subdivisiontype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all subdivisiontypes."""
        if self.subdivisiontype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.subdivisiontype_full_client.List(lara_django_base_pb2.SubdivisionTypeFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.subdivisiontype_full_client.List(
                lara_django_base_pb2.SubdivisionTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, subdivisiontype: base_dm.SubdivisionType = None) -> None:
        """Update a subdivisiontype model instance."""
        try:
            res = await self.subdivisiontype_client.Update(
                lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating subdivisiontype_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a subdivisiontype by subdivisiontype_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.subdivisiontype_client.Destroy(
                    lara_django_base_pb2.SubdivisionTypeDestroyRequest(subdivisiontype_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting subdivisiontype_id: {e}")


# _________________  CountrySubdivision  ______________________


class CountrySubdivisionInterface:
    """Initialize the CountrySubdivisionInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.countrysubdivision_client = lara_django_base_pb2_grpc.CountrySubdivisionControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, countrysubdivisions: list[base_dm.CountrySubdivision] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.CountrySubdivision]:
        """
        Create a list of countrysubdivision instances.

            Returns a list of countrysubdivision data model objects or ids_only.
        :param countrysubdivisions: list of countrysubdivision data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of countrysubdivision data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.countrysubdivision_client.Create(
                    lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump())
                )
                for countrysubdivision in countrysubdivisions
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.countrysubdivision_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating countrysubdivision: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        countrysubdivision_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.CountrySubdivision]:
        """
        Retrieve a list of countrysubdivision instances by countrysubdivision_id, name or filter_dict.

            Returns a list of countrysubdivision data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if countrysubdivision_id is not None:
            try:
                res = await self.countrysubdivision_client.Retrieve(
                    lara_django_base_pb2.CountrySubdivisionRetrieveRequest(countrysubdivision_id=countrysubdivision_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(
                        base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
                    )
            except Exception as e:
                logger.error(f"Error retrieving countrysubdivision_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.countrysubdivision_client.List(
                lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
                    for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the countrysubdivision_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].countrysubdivision_id
        else:
            raise ValueError(f"Error retrieving countrysubdivision_id - no or too many results found.")

    async def get_by_id(self, countrysubdivision_id: str = None) -> base_dm.CountrySubdivision:
        """Retrieve a countrysubdivision data model by countrysubdivision_id."""
        try:
            res = await self.countrysubdivision_client.Retrieve(
                lara_django_base_pb2.CountrySubdivisionRetrieveRequest(countrysubdivision_id=countrysubdivision_id)
            )
            return base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.CountrySubdivision | str:
        """Retrieve a countrysubdivision data model by name."""
        try:
            res = await self.countrysubdivision_client.RetrieveByNameNamespace(
                lara_django_base_pb2.CountrySubdivisionRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["countrysubdivision_id"]
            else:
                return base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all countrysubdivisions."""
        if filter_dict is None:
            res = await self.countrysubdivision_client.List(lara_django_base_pb2.CountrySubdivisionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.countrysubdivision_client.List(
                lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.countrysubdivision_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all countrysubdivisions."""
        if self.countrysubdivision_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, countrysubdivision: base_dm.CountrySubdivision = None) -> None:
        """Update a countrysubdivision model instance."""
        try:
            res = await self.countrysubdivision_client.Update(
                lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating countrysubdivision_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a countrysubdivision by countrysubdivision_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.countrysubdivision_client.Destroy(
                    lara_django_base_pb2.CountrySubdivisionDestroyRequest(countrysubdivision_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting countrysubdivision_id: {e}")


# _________________  City  ______________________


class CityInterface:
    """Initialize the CityInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.city_client = lara_django_base_pb2_grpc.CityControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, cities: list[base_dm.City] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.City]:
        """
        Create a list of city instances.

            Returns a list of city data model objects or ids_only.
        :param cities: list of city data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of city data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.city_client.Create(lara_django_base_pb2.CityRequest(**city.model_dump())) for city in cities
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.city_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating city: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        city_id: str | None = None,
        name: str | None = None,
        name_local: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.City]:
        """
        Retrieve a list of city instances by city_id, name or filter_dict.

            Returns a list of city data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if city_id is not None:
            try:
                res = await self.city_client.Retrieve(lara_django_base_pb2.CityRetrieveRequest(city_id=city_id))
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving city_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if name_local is not None:
            filter_dict["name_local"] = name_local

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.city_client.List(lara_django_base_pb2.CityListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving city name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        name_local: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the city_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, name_local=name_local, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].city_id
        else:
            raise ValueError(f"Error retrieving city_id - no or too many results found.")

    async def get_by_id(self, city_id: str = None) -> base_dm.City:
        """Retrieve a city data model by city_id."""
        try:
            res = await self.city_client.Retrieve(lara_django_base_pb2.CityRetrieveRequest(city_id=city_id))
            return base_dm.City(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving city_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.City | str:
        """Retrieve a city data model by name."""
        try:
            res = await self.city_client.RetrieveByNameNamespace(
                lara_django_base_pb2.CityRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["city_id"]
            else:
                return base_dm.City(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving city name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all citys."""
        if filter_dict is None:
            res = await self.city_client.List(lara_django_base_pb2.CityListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.city_client.List(lara_django_base_pb2.CityListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.city_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all citys."""
        if self.city_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.city_full_client.List(lara_django_base_pb2.CityFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.city_full_client.List(lara_django_base_pb2.CityFullListRequest(), metadata=metadata)

    @import_model_instance_from_file()
    async def update(self, city: base_dm.City = None) -> None:
        """Update a city model instance."""
        try:
            res = await self.city_client.Update(lara_django_base_pb2.CityRequest(**city.model_dump()))
        except Exception as e:
            logger.error(f"Error updating city_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a city by city_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.city_client.Destroy(lara_django_base_pb2.CityDestroyRequest(city_id=id)) for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting city_id: {e}")


# _________________  Address  ______________________


class AddressInterface:
    """Initialize the AddressInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespace_if=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.address_class_client = (
        #     lara_django_base_pb2_grpc.AddressclassByIRIControllerStub(channel)
        # )

        self.address_client = lara_django_base_pb2_grpc.AddressControllerStub(channel)

        # self.address_full_client = lara_django_base_pb2_grpc.AddressFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespace_if=namespace_if,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file()
    async def create(
        self, addresses: list[base_dm.Address] | None = None, ids_only: bool = False, namespace_uri: str = None
    ) -> list[str] | list[base_dm.Address]:
        """
        Create a list of address instances.

            Returns a list of address data model objects or ids_only.

        :param addresses: list of address data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of address data model objects or ids_only
        """
        addressclass_id = None
        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if address_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.address_class_client.Retrieve(
        #         lara_django_base_pb2.AddressclassRetrieveRequest(iri=address_class_iri)
        #     )
        #     addressclass_id = res.addressclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving addressclass_id: {e}")
        for address in addresses:
            if address.namespace == "" or address.namespace == "default":
                address.namespace = namespace_id
            # address.address_class = addressclass_id # uncomment if a model class is used

        try:
            create_coroutines = (
                self.address_client.Create(lara_django_base_pb2.AddressRequest(**address.model_dump()))
                for address in addresses
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [MessageToDict(item, preserving_proto_field_name=True).get("address_id") for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating address: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str | None = None,
        name: str | None = None,
        address_id: str | None = None,
        street: str | None = None,
        house_number: str | None = None,
        postal_code: str | None = None,
        city_name: str | None = None,
        country_name: str | None = None,
        country_alpha2code: str | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Address]:
        """
        Retrieve a list of address instances by address_id, name or filter_dict.

            Returns a list of address data model objects.
                If raw is True, the raw protobuf objects are returned.
                If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")

        results_list = []
        if address_id is not None:
            try:
                res = await self.address_client.Retrieve(
                    lara_django_base_pb2.AddressRetrieveRequest(address_id=address_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving address_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if street is not None:
            filter_dict["street"] = street
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        if house_number is not None:
            filter_dict["house_number"] = house_number
        if postal_code is not None:
            filter_dict["postal_code"] = postal_code
        if city_name is not None:
            filter_dict["city__name"] = city_name
        if country_name is not None:
            filter_dict["country__name"] = country_name
        if country_alpha2code is not None:
            filter_dict["country__alpha2code"] = country_alpha2code

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.address_client.List(lara_django_base_pb2.AddressListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving address name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        street: str | None = None,
        house_number: str | None = None,
        postal_code: str | None = None,
        city_name: str | None = None,
        country_name: str | None = None,
        country_alpha2code: str | None = None,
        namespace_uri: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the address_id for a given name, name_display or iri."""
        results_list = await self.retrieve(
            name=name,
            street=street,
            house_number=house_number,
            postal_code=postal_code,
            city_name=city_name,
            country_name=country_name,
            country_alpha2code=country_alpha2code,
            namespace_uri=namespace_uri,
            filter_dict=filter_dict,
            raw=True,
        )

        if len(results_list) == 1:
            return results_list[0].address_id
        else:
            raise ValueError(f"Error retrieving address_id - no or too many results found.")

    async def get_by_id(self, address_id: str = None, id_only: bool = False) -> base_dm.Address:
        """Retrieve a address data model by address_id."""
        try:
            res = await self.address_client.Retrieve(lara_django_base_pb2.AddressRetrieveRequest(address_id=address_id))
            item = base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.address_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving address_id: {e}")

    # async def get_by_name(self, name: str = None,
    #                             namespace_uri : str = None,
    #                             id_only: bool = False) -> base_dm.Address | str:
    #     """Retrieve a address data model by name."""
    #     if namespace_uri is None and self._default_namespace_uri is not None:
    #         namespace_uri = self._default_namespace_uri
    #     if namespace_uri is None:
    #         raise ValueError("No namespace URI is given.")
    #     try:
    #         res = await self.address_client.RetrieveByNameNamespace(
    #             lara_django_base_pb2.AddressRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
    #         )
    #         item = MessageToDict(res, preserving_proto_field_name=True)
    #         self.item_id = item["address_id"]
    #         if id_only:
    #             return self.item_id
    #         else:
    #             return base_dm.Address(**item)
    #     except Exception as e:
    #         logger.error(f"Error retrieving address name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all addresss."""
        if filter_dict is None:
            res = await self.address_client.List(lara_django_base_pb2.AddressListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.address_client.List(lara_django_base_pb2.AddressListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.address_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all addresss."""
        if self.address_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.address_full_client.List(lara_django_base_pb2.AddressFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.address_full_client.List(lara_django_base_pb2.AddressFullListRequest(), metadata=metadata)

    @import_model_instance_from_file()
    async def update(self, address: base_dm.Address = None) -> None:
        """Update a address model instance."""
        try:
            res = await self.address_client.Update(lara_django_base_pb2.AddressRequest(**address.model_dump()))
        except Exception as e:
            logger.error(f"Error updating address_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a address by address_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.address_client.Destroy(lara_django_base_pb2.AddressDestroyRequest(address_id=id)) for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting address_id: {e}")


# _________________  RoomCategory  ______________________


class RoomCategoryInterface:
    """Initialize the RoomCategoryInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.roomcategory_client = lara_django_base_pb2_grpc.RoomCategoryControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, roomcategories: list[base_dm.RoomCategory] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.RoomCategory]:
        """
        Create a list of roomcategory instances.

            Returns a list of roomcategory data model objects or ids_only.
        :param roomcategories: list of roomcategory data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of roomcategory data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.roomcategory_client.Create(lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump()))
                for roomcategory in roomcategories
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.roomcategory_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating roomcategory: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        roomcategory_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.RoomCategory]:
        """
        Retrieve a list of roomcategory instances by roomcategory_id, name or filter_dict.

            Returns a list of roomcategory data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if roomcategory_id is not None:
            try:
                res = await self.roomcategory_client.Retrieve(
                    lara_django_base_pb2.RoomCategoryRetrieveRequest(roomcategory_id=roomcategory_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving roomcategory_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.roomcategory_client.List(lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving roomcategory name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the roomcategory_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].roomcategory_id
        else:
            raise ValueError(f"Error retrieving roomcategory_id - no or too many results found.")

    async def get_by_id(self, roomcategory_id: str = None) -> base_dm.RoomCategory:
        """Retrieve a roomcategory data model by roomcategory_id."""
        try:
            res = await self.roomcategory_client.Retrieve(
                lara_django_base_pb2.RoomCategoryRetrieveRequest(roomcategory_id=roomcategory_id)
            )
            return base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roomcategory_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.RoomCategory | str:
        """Retrieve a roomcategory data model by name."""
        try:
            res = await self.roomcategory_client.RetrieveByNameNamespace(
                lara_django_base_pb2.RoomCategoryRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["roomcategory_id"]
            else:
                return base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roomcategory name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all roomcategorys."""
        if filter_dict is None:
            res = await self.roomcategory_client.List(lara_django_base_pb2.RoomCategoryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.roomcategory_client.List(lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.roomcategory_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all roomcategorys."""
        if self.roomcategory_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.roomcategory_full_client.List(lara_django_base_pb2.RoomCategoryFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.roomcategory_full_client.List(
                lara_django_base_pb2.RoomCategoryFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, roomcategory: base_dm.RoomCategory = None) -> None:
        """Update a roomcategory model instance."""
        try:
            res = await self.roomcategory_client.Update(
                lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating roomcategory_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a roomcategory by roomcategory_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.roomcategory_client.Destroy(lara_django_base_pb2.RoomCategoryDestroyRequest(roomcategory_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting roomcategory_id: {e}")


# _________________  Room  ______________________


class RoomInterface:
    """Initialize the RoomInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespace_if=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.room_class_client = (
        #     lara_django_base_pb2_grpc.RoomclassByIRIControllerStub(channel)
        # )

        self.room_client = lara_django_base_pb2_grpc.RoomControllerStub(channel)

        self.item_id = None
        self.update_item_id = "room_id"
        self.stub = self.room_client

        self.image_upload_chunk = lara_django_base_pb2.ImageUploadChunk

        # self.room_full_client = lara_django_base_pb2_grpc.RoomFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespace_if=namespace_if,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file()
    @upload_image  # needed for image upload
    async def create(
        self, rooms: list[base_dm.Room] | None = None, ids_only: bool = False, namespace_uri: str = None
    ) -> list[str] | list[base_dm.Room]:
        """
        Create a list of room instances.

            Returns a list of room data model objects or ids_only.

        :param rooms: list of room data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of room data model objects or ids_only
        """
        roomclass_id = None
        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if room_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.room_class_client.Retrieve(
        #         lara_django_base_pb2.RoomclassRetrieveRequest(iri=room_class_iri)
        #     )
        #     roomclass_id = res.roomclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving roomclass_id: {e}")
        for room in rooms:
            if room.namespace == "" or room.namespace == "default":
                room.namespace = namespace_id
            # room.room_class = roomclass_id # uncomment if a model class is used

        try:
            create_coroutines = (
                self.room_client.Create(lara_django_base_pb2.RoomRequest(**room.model_dump())) for room in rooms
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [MessageToDict(item, preserving_proto_field_name=True).get("room_id") for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating room: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str | None = None,
        room_id: str | None = None,
        name: str | None = None,
        # name_display: str | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Room]:
        """
        Retrieve a list of room instances by room_id, name or filter_dict.

            Returns a list of room data model objects.
                If raw is True, the raw protobuf objects are returned.
                If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")

        results_list = []
        if room_id is not None:
            try:
                res = await self.room_client.Retrieve(lara_django_base_pb2.RoomRetrieveRequest(room_id=room_id))
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving room_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.room_client.List(lara_django_base_pb2.RoomListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving room name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        namespace_uri: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the room_id for a given name, name_display or iri."""

        results_list = await self.retrieve(name=name, namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1:
            return results_list[0].room_id
        else:
            raise ValueError(f"Error retrieving room_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, room_id: str = None, id_only: bool = False) -> base_dm.Room:
        """Retrieve a room data model by room_id."""
        try:
            res = await self.room_client.Retrieve(lara_django_base_pb2.RoomRetrieveRequest(room_id=room_id))
            item = base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.room_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving room_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(
        self, name: str = None, namespace_uri: str = None, id_only: bool = False
    ) -> base_dm.Room | str:
        """Retrieve a room data model by name."""
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.room_client.RetrieveByNameNamespace(
                lara_django_base_pb2.RoomRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["room_id"]
            if id_only:
                return self.item_id
            else:
                return base_dm.Room(**item)
        except Exception as e:
            logger.error(f"Error retrieving room name: {e}")

    @download_image  # needed for image download
    async def get_image(self, room_id: str = None, id_only: bool = True) -> bytes | None:
        """Retrieve an image by data_id."""
        self.item_id = room_id

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all rooms."""
        if filter_dict is None:
            res = await self.room_client.List(lara_django_base_pb2.RoomListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.room_client.List(lara_django_base_pb2.RoomListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.room_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all rooms."""
        if self.room_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.room_full_client.List(lara_django_base_pb2.RoomFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.room_full_client.List(lara_django_base_pb2.RoomFullListRequest(), metadata=metadata)

    @import_model_instance_from_file()
    @update_image  # needed for image update
    async def update(self, room: base_dm.Room = None) -> None:
        """Update a room model instance."""
        try:
            res = await self.room_client.Update(lara_django_base_pb2.RoomRequest(**room.model_dump()))
        except Exception as e:
            logger.error(f"Error updating room_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a room by room_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.room_client.Destroy(lara_django_base_pb2.RoomDestroyRequest(room_id=id)) for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting room_id: {e}")


# _________________  LocationType  ______________________


class LocationTypeInterface:
    """Initialize the LocationTypeInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.locationtype_client = lara_django_base_pb2_grpc.LocationTypeControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, locationtypes: list[base_dm.LocationType] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.LocationType]:
        """
        Create a list of locationtype instances.

            Returns a list of locationtype data model objects or ids_only.
        :param locationtypes: list of locationtype data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of locationtype data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.locationtype_client.Create(lara_django_base_pb2.LocationTypeRequest(**locationtype.model_dump()))
                for locationtype in locationtypes
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.locationtype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating locationtype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        locationtype_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.LocationType]:
        """
        Retrieve a list of locationtype instances by locationtype_id, name or filter_dict.

            Returns a list of locationtype data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if locationtype_id is not None:
            try:
                res = await self.locationtype_client.Retrieve(
                    lara_django_base_pb2.LocationTypeRetrieveRequest(locationtype_id=locationtype_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.LocationType(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving locationtype_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.locationtype_client.List(lara_django_base_pb2.LocationTypeListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.LocationType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving locationtype name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the locationtype_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].locationtype_id
        else:
            raise ValueError(f"Error retrieving locationtype_id - no or too many results found.")

    async def get_by_id(self, locationtype_id: str = None) -> base_dm.LocationType:
        """Retrieve a locationtype data model by locationtype_id."""
        try:
            res = await self.locationtype_client.Retrieve(
                lara_django_base_pb2.LocationTypeRetrieveRequest(locationtype_id=locationtype_id)
            )
            return base_dm.LocationType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving locationtype_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.LocationType | str:
        """Retrieve a locationtype data model by name."""
        try:
            res = await self.locationtype_client.RetrieveByNameNamespace(
                lara_django_base_pb2.LocationTypeRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["locationtype_id"]
            else:
                return base_dm.LocationType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving locationtype name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all locationtypes."""
        if filter_dict is None:
            res = await self.locationtype_client.List(lara_django_base_pb2.LocationTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.locationtype_client.List(lara_django_base_pb2.LocationTypeListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.locationtype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all locationtypes."""
        if self.locationtype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.locationtype_full_client.List(lara_django_base_pb2.LocationTypeFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.locationtype_full_client.List(
                lara_django_base_pb2.LocationTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, locationtype: base_dm.LocationType = None) -> None:
        """Update a locationtype model instance."""
        try:
            res = await self.locationtype_client.Update(
                lara_django_base_pb2.LocationTypeRequest(**locationtype.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating locationtype_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a locationtype by locationtype_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.locationtype_client.Destroy(lara_django_base_pb2.LocationTypeDestroyRequest(locationtype_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting locationtype_id: {e}")


# _________________  Location  ______________________


class LocationInterface:
    """Initialize the LocationInterface."""

    def __init__(
        self,
        channel: grpc.Channel = None,
        default_namespace_uri: str = None,
        default_namespace_id: str = None,
        namespace_if=None,
    ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.location_class_client = (
        #     lara_django_base_pb2_grpc.LocationclassByIRIControllerStub(channel)
        # )

        self.location_client = lara_django_base_pb2_grpc.LocationControllerStub(channel)

        # self.location_full_client = lara_django_base_pb2_grpc.LocationFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        return cls(
            channel=channel,
            default_namespace_uri=default_namespace_uri,
            default_namespace_id=default_namespace_id,
            namespace_if=namespace_if,
        )

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file()
    async def create(
        self, locations: list[base_dm.Location] | None = None, ids_only: bool = False, namespace_uri: str = None
    ) -> list[str] | list[base_dm.Location]:
        """
        Create a list of location instances.

            Returns a list of location data model objects or ids_only.

        :param locations: list of location data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of location data model objects or ids_only
        """
        locationclass_id = None
        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if location_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.location_class_client.Retrieve(
        #         lara_django_base_pb2.LocationclassRetrieveRequest(iri=location_class_iri)
        #     )
        #     locationclass_id = res.locationclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving locationclass_id: {e}")
        for location in locations:
            if location.namespace == "" or location.namespace == "default":
                location.namespace = namespace_id
            # location.location_class = locationclass_id # uncomment if a model class is used

        try:
            create_coroutines = (
                self.location_client.Create(lara_django_base_pb2.LocationRequest(**location.model_dump()))
                for location in locations
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [MessageToDict(item, preserving_proto_field_name=True).get("location_id") for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating location: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str | None = None,
        location_id: str | None = None,
        name: str | None = None,
        # name_display: str | None = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.Location]:
        """
        Retrieve a list of location instances by location_id, name or filter_dict.

            Returns a list of location data model objects.
                If raw is True, the raw protobuf objects are returned.
                If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")

        results_list = []
        if location_id is not None:
            try:
                res = await self.location_client.Retrieve(
                    lara_django_base_pb2.LocationRetrieveRequest(location_id=location_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving location_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.location_client.List(lara_django_base_pb2.LocationListRequest(), metadata=metadata)
            if raw:
                results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving location name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        namespace_uri: str | None = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the location_id for a given name, name_display or iri."""

        results_list = await self.retrieve(name=name, namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1:
            return results_list[0].location_id
        else:
            raise ValueError(f"Error retrieving location_id - no or too many results found.")

    async def get_by_id(self, location_id: str = None, id_only: bool = False) -> base_dm.Location:
        """Retrieve a location data model by location_id."""
        try:
            res = await self.location_client.Retrieve(
                lara_django_base_pb2.LocationRetrieveRequest(location_id=location_id)
            )
            item = base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.location_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving location_id: {e}")

    async def get_by_name(
        self, name: str = None, namespace_uri: str = None, id_only: bool = False
    ) -> base_dm.Location | str:
        """Retrieve a location data model by name."""
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.location_client.RetrieveByNameNamespace(
                lara_django_base_pb2.LocationRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["location_id"]
            if id_only:
                return self.item_id
            else:
                return base_dm.Location(**item)
        except Exception as e:
            logger.error(f"Error retrieving location name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all locations."""
        if filter_dict is None:
            res = await self.location_client.List(lara_django_base_pb2.LocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.location_client.List(lara_django_base_pb2.LocationListRequest(), metadata=metadata)
        if res is not None and ids_only:
            return [item.location_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all locations."""
        if self.location_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.location_full_client.List(lara_django_base_pb2.LocationFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.location_full_client.List(
                lara_django_base_pb2.LocationFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, location: base_dm.Location = None) -> None:
        """Update a location model instance."""
        try:
            res = await self.location_client.Update(lara_django_base_pb2.LocationRequest(**location.model_dump()))
        except Exception as e:
            logger.error(f"Error updating location_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a location by location_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.location_client.Destroy(lara_django_base_pb2.LocationDestroyRequest(location_id=id))
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting location_id: {e}")


# _________________  LARASyncServer  ______________________


class LARASyncServerInterface:
    """Initialize the LARASyncServerInterface."""

    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.larasyncserver_client = lara_django_base_pb2_grpc.LARASyncServerControllerStub(channel)

    @import_model_instance_from_file()
    async def create(
        self, larasyncservers: list[base_dm.LARASyncServer] | None = None, ids_only: bool = False
    ) -> list[str] | list[base_dm.LARASyncServer]:
        """
        Create a list of larasyncserver instances.

            Returns a list of larasyncserver data model objects or ids_only.
        :param larasyncservers: list of larasyncserver data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of larasyncserver data model objects or ids_only
        """
        try:
            create_coroutines = (
                self.larasyncserver_client.Create(
                    lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump())
                )
                for larasyncserver in larasyncservers
            )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.larasyncserver_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating larasyncserver: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        larasyncserver_id: str | None = None,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        raw: bool = False,
    ) -> list[base_dm.LARASyncServer]:
        """
        Retrieve a list of larasyncserver instances by larasyncserver_id, name or filter_dict.

            Returns a list of larasyncserver data model objects.
            If raw is True, the raw protobuf objects are returned.
        """
        results_list = []
        if larasyncserver_id is not None:
            try:
                res = await self.larasyncserver_client.Retrieve(
                    lara_django_base_pb2.LARASyncServerRetrieveRequest(larasyncserver_id=larasyncserver_id)
                )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append(base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)))
            except Exception as e:
                logger.error(f"Error retrieving larasyncserver_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.larasyncserver_client.List(
                lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
            )
            if raw:
                results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [
                    base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)) for res in results
                ]
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver name: {e}")

        return results_list

    # @id_cache
    async def retrieve_id(
        self,
        name: str | None = None,
        # name_display: str = None,
        filter_dict: dict | None = None,
        iri: str | None = None,
    ) -> str | None:
        """Retrieve the larasyncserver_id for a given name, (name_display) or iri."""
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1:
            return results_list[0].larasyncserver_id
        else:
            raise ValueError(f"Error retrieving larasyncserver_id - no or too many results found.")

    async def get_by_id(self, larasyncserver_id: str = None) -> base_dm.LARASyncServer:
        """Retrieve a larasyncserver data model by larasyncserver_id."""
        try:
            res = await self.larasyncserver_client.Retrieve(
                lara_django_base_pb2.LARASyncServerRetrieveRequest(larasyncserver_id=larasyncserver_id)
            )
            return base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver_id: {e}")

    async def get_by_name(self, name: str = None, id_only: bool = False) -> base_dm.LARASyncServer | str:
        """Retrieve a larasyncserver data model by name."""
        try:
            res = await self.larasyncserver_client.RetrieveByNameNamespace(
                lara_django_base_pb2.LARASyncServerRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["larasyncserver_id"]
            else:
                return base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver name: {e}")

    async def list_items(self, filter_dict: dict | None = None, ids_only: bool = False) -> list[str]:
        """List all larasyncservers."""
        if filter_dict is None:
            res = await self.larasyncserver_client.List(lara_django_base_pb2.LARASyncServerListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.larasyncserver_client.List(
                lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.larasyncserver_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict | None = None) -> list:
        """List all larasyncservers."""
        if self.larasyncserver_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.larasyncserver_full_client.List(lara_django_base_pb2.LARASyncServerFullListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.larasyncserver_full_client.List(
                lara_django_base_pb2.LARASyncServerFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file()
    async def update(self, larasyncserver: base_dm.LARASyncServer = None) -> None:
        """Update a larasyncserver model instance."""
        try:
            res = await self.larasyncserver_client.Update(
                lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump())
            )
        except Exception as e:
            logger.error(f"Error updating larasyncserver_id: {e}")
        else:
            return res

    async def delete(self, id_list: list[str] | None = None, filter_dict: dict | None = None) -> None:
        """Delete a larasyncserver by larasyncserver_id or filter_dict."""
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = (
                self.larasyncserver_client.Destroy(
                    lara_django_base_pb2.LARASyncServerDestroyRequest(larasyncserver_id=id)
                )
                for id in id_list
            )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting larasyncserver_id: {e}")
