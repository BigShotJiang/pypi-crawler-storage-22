"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_base high_level_interface *

:details: lara_django_base high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_base
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, export_file, import_file, id_cache, update_image

import  lara_django_base_grpc.lara_django_base_data_model as base_dm 



#_________________  MediaType  ______________________


class MediaTypeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mediatype_client = lara_django_base_pb2_grpc.MediaTypeControllerStub(channel)

        # self.mediatype_full_client = lara_django_base_pb2_grpc.MediaTypeFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mediatypes:  list[base_dm.MediaType] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.MediaType]]:
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mediatype_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mediatype_class_client.Retrieve(
        #         lara_django_base_pb2.MediaTypeclassRetrieveRequest(iri=mediatype_class_iri)
        #     )
        #     mediatypeclass_id = res.mediatypeclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mediatypeclass_id: {e}")
        # for mediatype in mediatypes:
        #     mediatype.namespace = self.namespace_id
        #     mediatype.mediatype_class = mediatypeclass_id

        try:
            create_coroutines = ( self.mediatype_client.Create(lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump())) for mediatype in mediatypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mediatype_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mediatype: {e}")

    @export_file
    async def retrieve(
        self, 
        mediatype_id: str = None,
        mediatype_name: str = None,
        #mediatype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.MediaType]:
        filter_list = []
        results_list = []
        if  mediatype_id is not None:
            try:
                res =  await self.mediatype_client.Retrieve(
                    lara_django_base_pb2.MediaTypeRetrieveRequest(mediatype_id=mediatype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mediatype_id: {e}")

        if mediatype_name is not None:
            filter_list.append({"name": mediatype_name})
        # if mediatype_name_full is not None:
        #     filter_list.append({"name_full": mediatype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mediatype_client.List(
                        lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mediatype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mediatype_name: str = None,
                          mediatype_name_full: str = None,
                          iri: str = None,) -> str:
        if mediatype_name is not None:
            filter_dict = {"name": mediatype_name}
        elif mediatype_name_full is not None:
            filter_dict = {"name_full": mediatype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mediatype_client.List(
                    lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mediatype_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mediatype_id
            else:
                raise ValueError(f"Error retrieving mediatype_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mediatype_client.List(lara_django_base_pb2.MediaTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mediatype_client.List(
                lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mediatype_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mediatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mediatype_full_client.List(
                lara_django_base_pb2.MediaTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mediatype_full_client.List(
                lara_django_base_pb2.MediaTypeFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, mediatype : base_dm.MediaType = None) -> None:
        try:
            await self.mediatype_client.Update(
                lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mediatype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mediatype_client.Destroy(lara_django_base_pb2.MediaTypeDestroyRequest(mediatype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mediatype_id: {e}")

#_________________  DataType  ______________________


class DataTypeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.datatype_client = lara_django_base_pb2_grpc.DataTypeControllerStub(channel)

        # self.datatype_full_client = lara_django_base_pb2_grpc.DataTypeFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  datatypes:  list[base_dm.DataType] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.DataType]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if datatype_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.datatype_class_client.Retrieve(
        #         lara_django_base_pb2.DataTypeclassRetrieveRequest(iri=datatype_class_iri)
        #     )
        #     datatypeclass_id = res.datatypeclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving datatypeclass_id: {e}")
        # for datatype in datatypes:
        #     datatype.namespace = self.namespace_id
        #     datatype.datatype_class = datatypeclass_id

        try:
            create_coroutines = ( self.datatype_client.Create(lara_django_base_pb2.DataTypeRequest(**datatype.model_dump())) for datatype in datatypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.datatype_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating datatype: {e}")

    @export_file
    async def retrieve(
        self, 
        datatype_id: str = None,
        datatype_name: str = None,
        #datatype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.DataType]:
        filter_list = []
        results_list = []
        if  datatype_id is not None:
            try:
                res =  await self.datatype_client.Retrieve(
                    lara_django_base_pb2.DataTypeRetrieveRequest(datatype_id=datatype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving datatype_id: {e}")

        if datatype_name is not None:
            filter_list.append({"name": datatype_name})
        # if datatype_name_full is not None:
        #     filter_list.append({"name_full": datatype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.datatype_client.List(
                        lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving datatype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          datatype_name: str = None,
                          datatype_name_full: str = None,
                          iri: str = None,) -> str:
        if datatype_name is not None:
            filter_dict = {"name": datatype_name}
        elif datatype_name_full is not None:
            filter_dict = {"name_full": datatype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.datatype_client.List(
                    lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving datatype_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].datatype_id
            else:
                raise ValueError(f"Error retrieving datatype_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.datatype_client.List(lara_django_base_pb2.DataTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.datatype_client.List(
                lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.datatype_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.datatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.datatype_full_client.List(
                lara_django_base_pb2.DataTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.datatype_full_client.List(
                lara_django_base_pb2.DataTypeFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, datatype : base_dm.DataType = None) -> None:
        try:
            await self.datatype_client.Update(
                lara_django_base_pb2.DataTypeRequest(**datatype.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating datatype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.datatype_client.Destroy(lara_django_base_pb2.DataTypeDestroyRequest(datatype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting datatype_id: {e}")

#_________________  Namespace  ______________________


class NamespaceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.id_cache = {}

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
     
        self.namespaceURI_client = (
            lara_django_base_pb2_grpc.NamespaceByURIControllerStub(channel)
        )
        self.namespace_client = lara_django_base_pb2_grpc.NamespaceControllerStub(channel)


    @import_file(relation_resolver=lambda x: x)
    async def create(self,  namespaces:  list[base_dm.Namespace] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Namespace]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # namespaceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if namespace_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.namespace_class_client.Retrieve(
        #         lara_django_base_pb2.NamespaceclassRetrieveRequest(iri=namespace_class_iri)
        #     )
        #     namespaceclass_id = res.namespaceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving namespaceclass_id: {e}")
        # for namespace in namespaces:
        #     namespace.namespace = self.namespace_id
        #     namespace.namespace_class = namespaceclass_id

        try:
            create_coroutines = ( self.namespace_client.Create(lara_django_base_pb2.NamespaceRequest(**namespace.model_dump())) for namespace in namespaces )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.namespace_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating namespace: {e}")

    @export_file
    async def retrieve(
        self, 
        namespace_id: str = None,
        namespace_uri: str = None,
        #namespace_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Namespace]:
        filter_list = []
        results_list = []
        if  namespace_id is not None:
            try:
                res =  await self.namespace_client.Retrieve(
                    lara_django_base_pb2.NamespaceRetrieveRequest(namespace_id=namespace_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving namespace_id: {e}")

        if namespace_uri is not None:
            filter_list.append({"uri": namespace_uri})
        # if namespace_name_full is not None:
        #     filter_list.append({"name_full": namespace_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.namespace_client.List(
                        lara_django_base_pb2.NamespaceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving namespace_uri: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, namespace_uri: str = None):
        # try:
        #     return self.id_cache[namespace_uri]
        # except KeyError:
        try:
            res = await self.namespaceURI_client.Retrieve(
                    lara_django_base_pb2.NamespaceByURIRetrieveRequest(uri=namespace_uri)
                )
            namespace_id = res.namespace_id
            self.id_cache[namespace_uri] = namespace_id
            return namespace_id
        except Exception as e:
                logging.error(f"Error retrieving namespace_id: {e}")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.namespace_client.List(lara_django_base_pb2.NamespaceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.namespace_client.List(
                lara_django_base_pb2.NamespaceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.namespace_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.namespace_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.namespace_full_client.List(
                lara_django_base_pb2.NamespaceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.namespace_full_client.List(
                lara_django_base_pb2.NamespaceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, namespace : base_dm.Namespace = None) -> None:
        try:
            await self.namespace_client.Update(
                lara_django_base_pb2.NamespaceRequest(**namespace.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating namespace_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.namespace_client.Destroy(lara_django_base_pb2.NamespaceDestroyRequest(namespace_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting namespace_id: {e}")

#_________________  Tag  ______________________


class TagInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.tag_class_client = (
        #     lara_django_base_pb2_grpc.TagclassByIRIControllerStub(channel)
        # )
        
        self.tag_client = lara_django_base_pb2_grpc.TagControllerStub(channel)

        # self.tag_full_client = lara_django_base_pb2_grpc.TagFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  tags:  list[base_dm.Tag] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Tag]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # tagclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if tag_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.tag_class_client.Retrieve(
        #         lara_django_base_pb2.TagclassRetrieveRequest(iri=tag_class_iri)
        #     )
        #     tagclass_id = res.tagclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving tagclass_id: {e}")
        # for tag in tags:
        #     tag.namespace = self.namespace_id
        #     tag.tag_class = tagclass_id

        try:
            create_coroutines = ( self.tag_client.Create(lara_django_base_pb2.TagRequest(**tag.model_dump())) for tag in tags )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.tag_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating tag: {e}")

    @export_file
    async def retrieve(
        self, 
        tag_id: str = None,
        tag_name: str = None,
        #tag_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Tag]:
        filter_list = []
        results_list = []
        if  tag_id is not None:
            try:
                res =  await self.tag_client.Retrieve(
                    lara_django_base_pb2.TagRetrieveRequest(tag_id=tag_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving tag_id: {e}")

        if tag_name is not None:
            filter_list.append({"name": tag_name})
        # if tag_name_full is not None:
        #     filter_list.append({"name_full": tag_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.tag_client.List(
                        lara_django_base_pb2.TagListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving tag_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          tag_name: str = None,
                          tag_name_full: str = None,
                          iri: str = None,) -> str:
        if tag_name is not None:
            filter_dict = {"name": tag_name}
        elif tag_name_full is not None:
            filter_dict = {"name_full": tag_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.tag_client.List(
                    lara_django_base_pb2.TagListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving tag_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].tag_id
            else:
                raise ValueError(f"Error retrieving tag_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.tag_client.List(lara_django_base_pb2.TagListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.tag_client.List(
                lara_django_base_pb2.TagListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.tag_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.tag_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.tag_full_client.List(
                lara_django_base_pb2.TagFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.tag_full_client.List(
                lara_django_base_pb2.TagFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, tag : base_dm.Tag = None) -> None:
        try:
            await self.tag_client.Update(
                lara_django_base_pb2.TagRequest(**tag.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating tag_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.tag_client.Destroy(lara_django_base_pb2.TagDestroyRequest(tag_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting tag_id: {e}")

#_________________  ItemStatus  ______________________


class ItemStatusInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.itemstatus_class_client = (
        #     lara_django_base_pb2_grpc.ItemStatusclassByIRIControllerStub(channel)
        # )
        
        self.itemstatus_client = lara_django_base_pb2_grpc.ItemStatusControllerStub(channel)

        # self.itemstatus_full_client = lara_django_base_pb2_grpc.ItemStatusFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  itemstatus:  list[base_dm.ItemStatus] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ItemStatus]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # itemstatusclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if itemstatus_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.itemstatus_class_client.Retrieve(
        #         lara_django_base_pb2.ItemStatusclassRetrieveRequest(iri=itemstatus_class_iri)
        #     )
        #     itemstatusclass_id = res.itemstatusclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving itemstatusclass_id: {e}")
        # for itemstatus in itemstatuss:
        #     itemstatus.namespace = self.namespace_id
        #     itemstatus.itemstatus_class = itemstatusclass_id

        try:
            create_coroutines = ( self.itemstatus_client.Create(lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump())) for itemstatus in itemstatus )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.itemstatus_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating itemstatus: {e}")

    @export_file
    async def retrieve(
        self, 
        itemstatus_id: str = None,
        itemstatus_name: str = None,
        #itemstatus_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ItemStatus]:
        filter_list = []
        results_list = []
        if  itemstatus_id is not None:
            try:
                res =  await self.itemstatus_client.Retrieve(
                    lara_django_base_pb2.ItemStatusRetrieveRequest(itemstatus_id=itemstatus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving itemstatus_id: {e}")

        if itemstatus_name is not None:
            filter_list.append({"name": itemstatus_name})
        # if itemstatus_name_full is not None:
        #     filter_list.append({"name_full": itemstatus_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.itemstatus_client.List(
                        lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving itemstatus_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          itemstatus_name: str = None,
                          itemstatus_name_full: str = None,
                          iri: str = None,) -> str:
        if itemstatus_name is not None:
            filter_dict = {"name": itemstatus_name}
        elif itemstatus_name_full is not None:
            filter_dict = {"name_full": itemstatus_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.itemstatus_client.List(
                    lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving itemstatus_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].itemstatus_id
            else:
                raise ValueError(f"Error retrieving itemstatus_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.itemstatus_client.List(lara_django_base_pb2.ItemStatusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.itemstatus_client.List(
                lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.itemstatus_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.itemstatus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.itemstatus_full_client.List(
                lara_django_base_pb2.ItemStatusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.itemstatus_full_client.List(
                lara_django_base_pb2.ItemStatusFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, itemstatus : base_dm.ItemStatus = None) -> None:
        try:
            await self.itemstatus_client.Update(
                lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating itemstatus_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.itemstatus_client.Destroy(lara_django_base_pb2.ItemStatusDestroyRequest(itemstatus_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting itemstatus_id: {e}")

#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_base_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_base_pb2_grpc.ExtraDataControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        self.stub = self.extradata_client
        self.file_chunk = lara_django_base_pb2.FileChunk
        self.update_item_id = "extradata_id"

        # self.extradata_full_client = lara_django_base_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  extradata:  list[base_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_base_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_base_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_base_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_base_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_base_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, extradata : base_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_base_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  ExternalResource  ______________________


class ExternalResourceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.externalresource_class_client = (
        #     lara_django_base_pb2_grpc.ExternalResourceclassByIRIControllerStub(channel)
        # )
        
        self.externalresource_client = lara_django_base_pb2_grpc.ExternalResourceControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.externalresource_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "externalresource_id"

        # self.externalresource_full_client = lara_django_base_pb2_grpc.ExternalResourceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  externalresources:  list[base_dm.ExternalResource] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ExternalResource]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # externalresourceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if externalresource_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.externalresource_class_client.Retrieve(
        #         lara_django_base_pb2.ExternalResourceclassRetrieveRequest(iri=externalresource_class_iri)
        #     )
        #     externalresourceclass_id = res.externalresourceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving externalresourceclass_id: {e}")
        # for externalresource in externalresources:
        #     externalresource.namespace = self.namespace_id
        #     externalresource.externalresource_class = externalresourceclass_id

        try:
            create_coroutines = ( self.externalresource_client.Create(lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump())) for externalresource in externalresources )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.externalresource_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating externalresource: {e}")

    @export_file
    async def retrieve(
        self, 
        externalresource_id: str = None,
        externalresource_name: str = None,
        #externalresource_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ExternalResource]:
        filter_list = []
        results_list = []
        if  externalresource_id is not None:
            try:
                res =  await self.externalresource_client.Retrieve(
                    lara_django_base_pb2.ExternalResourceRetrieveRequest(externalresource_id=externalresource_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving externalresource_id: {e}")

        if externalresource_name is not None:
            filter_list.append({"name": externalresource_name})
        # if externalresource_name_full is not None:
        #     filter_list.append({"name_full": externalresource_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.externalresource_client.List(
                        lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving externalresource_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          externalresource_name: str = None,
                          externalresource_name_full: str = None,
                          iri: str = None,) -> str:
        if externalresource_name is not None:
            filter_dict = {"name": externalresource_name}
        elif externalresource_name_full is not None:
            filter_dict = {"name_full": externalresource_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.externalresource_client.List(
                    lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving externalresource_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].externalresource_id
            else:
                raise ValueError(f"Error retrieving externalresource_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.externalresource_client.List(lara_django_base_pb2.ExternalResourceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.externalresource_client.List(
                lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.externalresource_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.externalresource_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.externalresource_full_client.List(
                lara_django_base_pb2.ExternalResourceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.externalresource_full_client.List(
                lara_django_base_pb2.ExternalResourceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, externalresource : base_dm.ExternalResource = None) -> None:
        try:
            await self.externalresource_client.Update(
                lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating externalresource_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.externalresource_client.Destroy(lara_django_base_pb2.ExternalResourceDestroyRequest(externalresource_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting externalresource_id: {e}")

#_________________  PhysicalUnit  ______________________


class PhysicalUnitInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.physicalunit_class_client = (
        #     lara_django_base_pb2_grpc.PhysicalUnitclassByIRIControllerStub(channel)
        # )
        
        self.physicalunit_client = lara_django_base_pb2_grpc.PhysicalUnitControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.physicalunit_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "physicalunit_id"

        # self.physicalunit_full_client = lara_django_base_pb2_grpc.PhysicalUnitFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  physicalunits:  list[base_dm.PhysicalUnit] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.PhysicalUnit]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # physicalunitclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if physicalunit_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.physicalunit_class_client.Retrieve(
        #         lara_django_base_pb2.PhysicalUnitclassRetrieveRequest(iri=physicalunit_class_iri)
        #     )
        #     physicalunitclass_id = res.physicalunitclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving physicalunitclass_id: {e}")
        # for physicalunit in physicalunits:
        #     physicalunit.namespace = self.namespace_id
        #     physicalunit.physicalunit_class = physicalunitclass_id

        try:
            create_coroutines = ( self.physicalunit_client.Create(lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump())) for physicalunit in physicalunits )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalunit_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating physicalunit: {e}")

    @export_file
    async def retrieve(
        self, 
        physicalunit_id: str = None,
        physicalunit_name: str = None,
        #physicalunit_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.PhysicalUnit]:
        filter_list = []
        results_list = []
        if  physicalunit_id is not None:
            try:
                res =  await self.physicalunit_client.Retrieve(
                    lara_django_base_pb2.PhysicalUnitRetrieveRequest(physicalunit_id=physicalunit_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving physicalunit_id: {e}")

        if physicalunit_name is not None:
            filter_list.append({"name": physicalunit_name})
        # if physicalunit_name_full is not None:
        #     filter_list.append({"name_full": physicalunit_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalunit_client.List(
                        lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving physicalunit_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          physicalunit_name: str = None,
                          physicalunit_name_full: str = None,
                          iri: str = None,) -> str:
        if physicalunit_name is not None:
            filter_dict = {"name": physicalunit_name}
        elif physicalunit_name_full is not None:
            filter_dict = {"name_full": physicalunit_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalunit_client.List(
                    lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving physicalunit_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].physicalunit_id
            else:
                raise ValueError(f"Error retrieving physicalunit_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.physicalunit_client.List(lara_django_base_pb2.PhysicalUnitListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalunit_client.List(
                lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.physicalunit_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.physicalunit_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalunit_full_client.List(
                lara_django_base_pb2.PhysicalUnitFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalunit_full_client.List(
                lara_django_base_pb2.PhysicalUnitFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, physicalunit : base_dm.PhysicalUnit = None) -> None:
        try:
            await self.physicalunit_client.Update(
                lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating physicalunit_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.physicalunit_client.Destroy(lara_django_base_pb2.PhysicalUnitDestroyRequest(physicalunit_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting physicalunit_id: {e}")

#_________________  PhysicalStateMatter  ______________________


class PhysicalStateMatterInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.physicalstatematter_class_client = (
        #     lara_django_base_pb2_grpc.PhysicalStateMatterclassByIRIControllerStub(channel)
        # )
        
        self.physicalstatematter_client = lara_django_base_pb2_grpc.PhysicalStateMatterControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.physicalstatematter_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "physicalstatematter_id"

        # self.physicalstatematter_full_client = lara_django_base_pb2_grpc.PhysicalStateMatterFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  physicalstatesmatter:  list[base_dm.PhysicalStateMatter] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.PhysicalStateMatter]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # physicalstatematterclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if physicalstatematter_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.physicalstatematter_class_client.Retrieve(
        #         lara_django_base_pb2.PhysicalStateMatterclassRetrieveRequest(iri=physicalstatematter_class_iri)
        #     )
        #     physicalstatematterclass_id = res.physicalstatematterclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving physicalstatematterclass_id: {e}")
        # for physicalstatematter in physicalstatematters:
        #     physicalstatematter.namespace = self.namespace_id
        #     physicalstatematter.physicalstatematter_class = physicalstatematterclass_id

        try:
            create_coroutines = ( self.physicalstatematter_client.Create(lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump())) for physicalstatematter in physicalstatesmatter )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalstatematter_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating physicalstatematter: {e}")

    @export_file
    async def retrieve(
        self, 
        physicalstatematter_id: str = None,
        physicalstatematter_name: str = None,
        #physicalstatematter_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.PhysicalStateMatter]:
        filter_list = []
        results_list = []
        if  physicalstatematter_id is not None:
            try:
                res =  await self.physicalstatematter_client.Retrieve(
                    lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(physicalstatematter_id=physicalstatematter_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving physicalstatematter_id: {e}")

        if physicalstatematter_name is not None:
            filter_list.append({"name": physicalstatematter_name})
        # if physicalstatematter_name_full is not None:
        #     filter_list.append({"name_full": physicalstatematter_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalstatematter_client.List(
                        lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving physicalstatematter_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          physicalstatematter_name: str = None,
                          physicalstatematter_name_full: str = None,
                          iri: str = None,) -> str:
        if physicalstatematter_name is not None:
            filter_dict = {"name": physicalstatematter_name}
        elif physicalstatematter_name_full is not None:
            filter_dict = {"name_full": physicalstatematter_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalstatematter_client.List(
                    lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving physicalstatematter_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].physicalstatematter_id
            else:
                raise ValueError(f"Error retrieving physicalstatematter_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.physicalstatematter_client.List(lara_django_base_pb2.PhysicalStateMatterListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalstatematter_client.List(
                lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.physicalstatematter_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.physicalstatematter_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, physicalstatematter : base_dm.PhysicalStateMatter = None) -> None:
        try:
            await self.physicalstatematter_client.Update(
                lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating physicalstatematter_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.physicalstatematter_client.Destroy(lara_django_base_pb2.PhysicalStateMatterDestroyRequest(physicalstatematter_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting physicalstatematter_id: {e}")

#_________________  ScientificConstant  ______________________


class ScientificConstantInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.scientificconstant_class_client = (
        #     lara_django_base_pb2_grpc.ScientificConstantclassByIRIControllerStub(channel)
        # )
        
        self.scientificconstant_client = lara_django_base_pb2_grpc.ScientificConstantControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.scientificconstant_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "scientificconstant_id"

        # self.scientificconstant_full_client = lara_django_base_pb2_grpc.ScientificConstantFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  scientificconstants:  list[base_dm.ScientificConstant] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ScientificConstant]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # scientificconstantclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if scientificconstant_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.scientificconstant_class_client.Retrieve(
        #         lara_django_base_pb2.ScientificConstantclassRetrieveRequest(iri=scientificconstant_class_iri)
        #     )
        #     scientificconstantclass_id = res.scientificconstantclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving scientificconstantclass_id: {e}")
        # for scientificconstant in scientificconstants:
        #     scientificconstant.namespace = self.namespace_id
        #     scientificconstant.scientificconstant_class = scientificconstantclass_id

        try:
            create_coroutines = ( self.scientificconstant_client.Create(lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump())) for scientificconstant in scientificconstants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.scientificconstant_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating scientificconstant: {e}")

    @export_file
    async def retrieve(
        self, 
        scientificconstant_id: str = None,
        scientificconstant_name: str = None,
        #scientificconstant_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ScientificConstant]:
        filter_list = []
        results_list = []
        if  scientificconstant_id is not None:
            try:
                res =  await self.scientificconstant_client.Retrieve(
                    lara_django_base_pb2.ScientificConstantRetrieveRequest(scientificconstant_id=scientificconstant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving scientificconstant_id: {e}")

        if scientificconstant_name is not None:
            filter_list.append({"name": scientificconstant_name})
        # if scientificconstant_name_full is not None:
        #     filter_list.append({"name_full": scientificconstant_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.scientificconstant_client.List(
                        lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving scientificconstant_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          scientificconstant_name: str = None,
                          scientificconstant_name_full: str = None,
                          iri: str = None,) -> str:
        if scientificconstant_name is not None:
            filter_dict = {"name": scientificconstant_name}
        elif scientificconstant_name_full is not None:
            filter_dict = {"name_full": scientificconstant_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.scientificconstant_client.List(
                    lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving scientificconstant_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].scientificconstant_id
            else:
                raise ValueError(f"Error retrieving scientificconstant_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.scientificconstant_client.List(lara_django_base_pb2.ScientificConstantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.scientificconstant_client.List(
                lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.scientificconstant_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.scientificconstant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, scientificconstant : base_dm.ScientificConstant = None) -> None:
        try:
            await self.scientificconstant_client.Update(
                lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating scientificconstant_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.scientificconstant_client.Destroy(lara_django_base_pb2.ScientificConstantDestroyRequest(scientificconstant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting scientificconstant_id: {e}")

#_________________  Currency  ______________________


class CurrencyInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.currency_class_client = (
        #     lara_django_base_pb2_grpc.CurrencyclassByIRIControllerStub(channel)
        # )
        
        self.currency_client = lara_django_base_pb2_grpc.CurrencyControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.currency_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "currency_id"

        # self.currency_full_client = lara_django_base_pb2_grpc.CurrencyFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  currencies:  list[base_dm.Currency] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Currency]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # currencyclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if currency_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.currency_class_client.Retrieve(
        #         lara_django_base_pb2.CurrencyclassRetrieveRequest(iri=currency_class_iri)
        #     )
        #     currencyclass_id = res.currencyclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving currencyclass_id: {e}")
        # for currency in currencys:
        #     currency.namespace = self.namespace_id
        #     currency.currency_class = currencyclass_id

        try:
            create_coroutines = ( self.currency_client.Create(lara_django_base_pb2.CurrencyRequest(**currency.model_dump())) for currency in currencies )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.currency_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating currency: {e}")

    @export_file
    async def retrieve(
        self, 
        currency_id: str = None,
        currency_name: str = None,
        #currency_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Currency]:
        filter_list = []
        results_list = []
        if  currency_id is not None:
            try:
                res =  await self.currency_client.Retrieve(
                    lara_django_base_pb2.CurrencyRetrieveRequest(currency_id=currency_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving currency_id: {e}")

        if currency_name is not None:
            filter_list.append({"name": currency_name})
        # if currency_name_full is not None:
        #     filter_list.append({"name_full": currency_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.currency_client.List(
                        lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving currency_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          currency_name: str = None,
                          currency_name_full: str = None,
                          iri: str = None,) -> str:
        if currency_name is not None:
            filter_dict = {"name": currency_name}
        elif currency_name_full is not None:
            filter_dict = {"name_full": currency_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.currency_client.List(
                    lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving currency_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].currency_id
            else:
                raise ValueError(f"Error retrieving currency_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.currency_client.List(lara_django_base_pb2.CurrencyListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.currency_client.List(
                lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.currency_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.currency_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.currency_full_client.List(
                lara_django_base_pb2.CurrencyFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.currency_full_client.List(
                lara_django_base_pb2.CurrencyFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, currency : base_dm.Currency = None) -> None:
        try:
            await self.currency_client.Update(
                lara_django_base_pb2.CurrencyRequest(**currency.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating currency_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.currency_client.Destroy(lara_django_base_pb2.CurrencyDestroyRequest(currency_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting currency_id: {e}")

#_________________  GeoLocation  ______________________


class GeoLocationInterface:
    def __init__(self, channel: grpc.Channel = None, ) -> None:

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        

        # self.geolocation_class_client = (
        #     lara_django_base_pb2_grpc.GeoLocationclassByIRIControllerStub(channel)
        # )
        
        self.geolocation_client = lara_django_base_pb2_grpc.GeoLocationControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.geolocation_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "geolocation_id"

        # self.geolocation_full_client = lara_django_base_pb2_grpc.GeoLocationFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  geolocations:  list[base_dm.GeoLocation] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.GeoLocation]]:
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if geolocation_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.geolocation_class_client.Retrieve(
        #         lara_django_base_pb2.GeoLocationclassRetrieveRequest(iri=geolocation_class_iri)
        #     )
        #     geolocationclass_id = res.geolocationclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving geolocationclass_id: {e}")
        # for geolocation in geolocations:
        #     geolocation.namespace = self.namespace_id
        #     geolocation.geolocation_class = geolocationclass_id

        try:
            create_coroutines = ( self.geolocation_client.Create(lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump())) for geolocation in geolocations )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.geolocation_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating geolocation: {e}")

    @export_file
    async def retrieve(
        self, 
        geolocation_id: str = None,
        geolocation_name: str = None,
        #geolocation_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.GeoLocation]:
        filter_list = []
        results_list = []
        if  geolocation_id is not None:
            try:
                res =  await self.geolocation_client.Retrieve(
                    lara_django_base_pb2.GeoLocationRetrieveRequest(geolocation_id=geolocation_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving geolocation_id: {e}")

        if geolocation_name is not None:
            filter_list.append({"name": geolocation_name})
        # if geolocation_name_full is not None:
        #     filter_list.append({"name_full": geolocation_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.geolocation_client.List(
                        lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving geolocation_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          geolocation_name: str = None,
                          geolocation_name_full: str = None,
                          iri: str = None,) -> str:
        if geolocation_name is not None:
            filter_dict = {"name": geolocation_name}
        elif geolocation_name_full is not None:
            filter_dict = {"name_full": geolocation_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.geolocation_client.List(
                    lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving geolocation_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].geolocation_id
            else:
                raise ValueError(f"Error retrieving geolocation_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.geolocation_client.List(lara_django_base_pb2.GeoLocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.geolocation_client.List(
                lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.geolocation_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.geolocation_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.geolocation_full_client.List(
                lara_django_base_pb2.GeoLocationFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.geolocation_full_client.List(
                lara_django_base_pb2.GeoLocationFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, geolocation : base_dm.GeoLocation = None) -> None:
        try:
            await self.geolocation_client.Update(
                lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating geolocation_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.geolocation_client.Destroy(lara_django_base_pb2.GeoLocationDestroyRequest(geolocation_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting geolocation_id: {e}")

#_________________  Country  ______________________


class CountryInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.country_class_client = (
        #     lara_django_base_pb2_grpc.CountryclassByIRIControllerStub(channel)
        # )
        
        self.country_client = lara_django_base_pb2_grpc.CountryControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.country_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "country_id"

        # self.country_full_client = lara_django_base_pb2_grpc.CountryFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  countries:  list[base_dm.Country] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Country]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # countryclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if country_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.country_class_client.Retrieve(
        #         lara_django_base_pb2.CountryclassRetrieveRequest(iri=country_class_iri)
        #     )
        #     countryclass_id = res.countryclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving countryclass_id: {e}")
        # for country in countrys:
        #     country.namespace = self.namespace_id
        #     country.country_class = countryclass_id

        try:
            create_coroutines = ( self.country_client.Create(lara_django_base_pb2.CountryRequest(**country.model_dump())) for country in countries )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.country_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating country: {e}")

    @export_file
    async def retrieve(
        self, 
        country_id: str = None,
        country_name: str = None,
        #country_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Country]:
        filter_list = []
        results_list = []
        if  country_id is not None:
            try:
                res =  await self.country_client.Retrieve(
                    lara_django_base_pb2.CountryRetrieveRequest(country_id=country_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving country_id: {e}")

        if country_name is not None:
            filter_list.append({"name": country_name})
        # if country_name_full is not None:
        #     filter_list.append({"name_full": country_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.country_client.List(
                        lara_django_base_pb2.CountryListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving country_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          country_name: str = None,
                          country_name_full: str = None,
                          iri: str = None,) -> str:
        if country_name is not None:
            filter_dict = {"name": country_name}
        elif country_name_full is not None:
            filter_dict = {"name_full": country_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.country_client.List(
                    lara_django_base_pb2.CountryListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving country_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].country_id
            else:
                raise ValueError(f"Error retrieving country_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.country_client.List(lara_django_base_pb2.CountryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.country_client.List(
                lara_django_base_pb2.CountryListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.country_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.country_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.country_full_client.List(
                lara_django_base_pb2.CountryFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.country_full_client.List(
                lara_django_base_pb2.CountryFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, country : base_dm.Country = None) -> None:
        try:
            await self.country_client.Update(
                lara_django_base_pb2.CountryRequest(**country.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating country_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.country_client.Destroy(lara_django_base_pb2.CountryDestroyRequest(country_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting country_id: {e}")

#_________________  SubdivisionType  ______________________


class SubdivisionTypeInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.subdivisiontype_class_client = (
        #     lara_django_base_pb2_grpc.SubdivisionTypeclassByIRIControllerStub(channel)
        # )
        
        self.subdivisiontype_client = lara_django_base_pb2_grpc.SubdivisionTypeControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.subdivisiontype_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "subdivisiontype_id"

        # self.subdivisiontype_full_client = lara_django_base_pb2_grpc.SubdivisionTypeFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  subdivisiontypes:  list[base_dm.SubdivisionType] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.SubdivisionType]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # subdivisiontypeclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if subdivisiontype_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.subdivisiontype_class_client.Retrieve(
        #         lara_django_base_pb2.SubdivisionTypeclassRetrieveRequest(iri=subdivisiontype_class_iri)
        #     )
        #     subdivisiontypeclass_id = res.subdivisiontypeclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving subdivisiontypeclass_id: {e}")
        # for subdivisiontype in subdivisiontypes:
        #     subdivisiontype.namespace = self.namespace_id
        #     subdivisiontype.subdivisiontype_class = subdivisiontypeclass_id

        try:
            create_coroutines = ( self.subdivisiontype_client.Create(lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump())) for subdivisiontype in subdivisiontypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.subdivisiontype_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating subdivisiontype: {e}")

    @export_file
    async def retrieve(
        self, 
        subdivisiontype_id: str = None,
        subdivisiontype_name: str = None,
        #subdivisiontype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.SubdivisionType]:
        filter_list = []
        results_list = []
        if  subdivisiontype_id is not None:
            try:
                res =  await self.subdivisiontype_client.Retrieve(
                    lara_django_base_pb2.SubdivisionTypeRetrieveRequest(subdivisiontype_id=subdivisiontype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving subdivisiontype_id: {e}")

        if subdivisiontype_name is not None:
            filter_list.append({"name": subdivisiontype_name})
        # if subdivisiontype_name_full is not None:
        #     filter_list.append({"name_full": subdivisiontype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.subdivisiontype_client.List(
                        lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving subdivisiontype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          subdivisiontype_name: str = None,
                          subdivisiontype_name_full: str = None,
                          iri: str = None,) -> str:
        if subdivisiontype_name is not None:
            filter_dict = {"name": subdivisiontype_name}
        elif subdivisiontype_name_full is not None:
            filter_dict = {"name_full": subdivisiontype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.subdivisiontype_client.List(
                    lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving subdivisiontype_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].subdivisiontype_id
            else:
                raise ValueError(f"Error retrieving subdivisiontype_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.subdivisiontype_client.List(lara_django_base_pb2.SubdivisionTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.subdivisiontype_client.List(
                lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subdivisiontype_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.subdivisiontype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.subdivisiontype_full_client.List(
                lara_django_base_pb2.SubdivisionTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.subdivisiontype_full_client.List(
                lara_django_base_pb2.SubdivisionTypeFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, subdivisiontype : base_dm.SubdivisionType = None) -> None:
        try:
            await self.subdivisiontype_client.Update(
                lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating subdivisiontype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.subdivisiontype_client.Destroy(lara_django_base_pb2.SubdivisionTypeDestroyRequest(subdivisiontype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting subdivisiontype_id: {e}")

#_________________  CountrySubdivision  ______________________


class CountrySubdivisionInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.countrysubdivision_class_client = (
        #     lara_django_base_pb2_grpc.CountrySubdivisionclassByIRIControllerStub(channel)
        # )
        
        self.countrysubdivision_client = lara_django_base_pb2_grpc.CountrySubdivisionControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.countrysubdivision_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "countrysubdivision_id"

        # self.countrysubdivision_full_client = lara_django_base_pb2_grpc.CountrySubdivisionFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  countrysubdivisions:  list[base_dm.CountrySubdivision] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.CountrySubdivision]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # countrysubdivisionclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if countrysubdivision_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.countrysubdivision_class_client.Retrieve(
        #         lara_django_base_pb2.CountrySubdivisionclassRetrieveRequest(iri=countrysubdivision_class_iri)
        #     )
        #     countrysubdivisionclass_id = res.countrysubdivisionclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving countrysubdivisionclass_id: {e}")
        # for countrysubdivision in countrysubdivisions:
        #     countrysubdivision.namespace = self.namespace_id
        #     countrysubdivision.countrysubdivision_class = countrysubdivisionclass_id

        try:
            create_coroutines = ( self.countrysubdivision_client.Create(lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump())) for countrysubdivision in countrysubdivisions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.countrysubdivision_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating countrysubdivision: {e}")

    @export_file
    async def retrieve(
        self, 
        countrysubdivision_id: str = None,
        countrysubdivision_name: str = None,
        #countrysubdivision_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.CountrySubdivision]:
        filter_list = []
        results_list = []
        if  countrysubdivision_id is not None:
            try:
                res =  await self.countrysubdivision_client.Retrieve(
                    lara_django_base_pb2.CountrySubdivisionRetrieveRequest(countrysubdivision_id=countrysubdivision_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving countrysubdivision_id: {e}")

        if countrysubdivision_name is not None:
            filter_list.append({"name": countrysubdivision_name})
        # if countrysubdivision_name_full is not None:
        #     filter_list.append({"name_full": countrysubdivision_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.countrysubdivision_client.List(
                        lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving countrysubdivision_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          countrysubdivision_name: str = None,
                          countrysubdivision_name_full: str = None,
                          iri: str = None,) -> str:
        if countrysubdivision_name is not None:
            filter_dict = {"name": countrysubdivision_name}
        elif countrysubdivision_name_full is not None:
            filter_dict = {"name_full": countrysubdivision_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.countrysubdivision_client.List(
                    lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving countrysubdivision_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].countrysubdivision_id
            else:
                raise ValueError(f"Error retrieving countrysubdivision_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.countrysubdivision_client.List(lara_django_base_pb2.CountrySubdivisionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.countrysubdivision_client.List(
                lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.countrysubdivision_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.countrysubdivision_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, countrysubdivision : base_dm.CountrySubdivision = None) -> None:
        try:
            await self.countrysubdivision_client.Update(
                lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating countrysubdivision_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.countrysubdivision_client.Destroy(lara_django_base_pb2.CountrySubdivisionDestroyRequest(countrysubdivision_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting countrysubdivision_id: {e}")

#_________________  City  ______________________


class CityInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
     

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        

        # self.city_class_client = (
        #     lara_django_base_pb2_grpc.CityclassByIRIControllerStub(channel)
        # )
        
        self.city_client = lara_django_base_pb2_grpc.CityControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.city_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "city_id"

        # self.city_full_client = lara_django_base_pb2_grpc.CityFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  cities:  list[base_dm.City] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.City]]:
    
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if city_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.city_class_client.Retrieve(
        #         lara_django_base_pb2.CityclassRetrieveRequest(iri=city_class_iri)
        #     )
        #     cityclass_id = res.cityclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving cityclass_id: {e}")
        # for city in citys:
        #     city.namespace = self.namespace_id
        #     city.city_class = cityclass_id

        try:
            create_coroutines = ( self.city_client.Create(lara_django_base_pb2.CityRequest(**city.model_dump())) for city in cities )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.city_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating city: {e}")

    @export_file
    async def retrieve(
        self, 
        city_id: str = None,
        city_name: str = None,
        #city_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.City]:
        filter_list = []
        results_list = []
        if  city_id is not None:
            try:
                res =  await self.city_client.Retrieve(
                    lara_django_base_pb2.CityRetrieveRequest(city_id=city_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving city_id: {e}")

        if city_name is not None:
            filter_list.append({"name": city_name})
        # if city_name_full is not None:
        #     filter_list.append({"name_full": city_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.city_client.List(
                        lara_django_base_pb2.CityListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving city_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          city_name: str = None,
                          city_name_full: str = None,
                          iri: str = None,) -> str:
        if city_name is not None:
            filter_dict = {"name": city_name}
        elif city_name_full is not None:
            filter_dict = {"name_full": city_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.city_client.List(
                    lara_django_base_pb2.CityListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving city_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].city_id
            else:
                raise ValueError(f"Error retrieving city_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.city_client.List(lara_django_base_pb2.CityListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.city_client.List(
                lara_django_base_pb2.CityListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.city_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.city_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.city_full_client.List(
                lara_django_base_pb2.CityFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.city_full_client.List(
                lara_django_base_pb2.CityFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, city : base_dm.City = None) -> None:
        try:
            await self.city_client.Update(
                lara_django_base_pb2.CityRequest(**city.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating city_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.city_client.Destroy(lara_django_base_pb2.CityDestroyRequest(city_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting city_id: {e}")

#_________________  Address  ______________________


class AddressInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

     
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
      
        # self.address_class_client = (
        #     lara_django_base_pb2_grpc.AddressclassByIRIControllerStub(channel)
        # )
        
        self.address_client = lara_django_base_pb2_grpc.AddressControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.address_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "address_id"

        # self.address_full_client = lara_django_base_pb2_grpc.AddressFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  addresses:  list[base_dm.Address] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.Address]]:
       
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if address_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.address_class_client.Retrieve(
        #         lara_django_base_pb2.AddressclassRetrieveRequest(iri=address_class_iri)
        #     )
        #     addressclass_id = res.addressclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving addressclass_id: {e}")
        # for address in addresss:
        #     address.namespace = self.namespace_id
        #     address.address_class = addressclass_id

        try:
            create_coroutines = ( self.address_client.Create(lara_django_base_pb2.AddressRequest(**address.model_dump())) for address in addresses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.address_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating address: {e}")

    @export_file
    async def retrieve(
        self, 
        address_id: str = None,
        address_name: str = None,
        #address_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Address]:
        filter_list = []
        results_list = []
        if  address_id is not None:
            try:
                res =  await self.address_client.Retrieve(
                    lara_django_base_pb2.AddressRetrieveRequest(address_id=address_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving address_id: {e}")

        if address_name is not None:
            filter_list.append({"name": address_name})
        # if address_name_full is not None:
        #     filter_list.append({"name_full": address_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.address_client.List(
                        lara_django_base_pb2.AddressListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving address_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          address_name: str = None,
                          address_name_full: str = None,
                          iri: str = None,) -> str:
        if address_name is not None:
            filter_dict = {"name": address_name}
        elif address_name_full is not None:
            filter_dict = {"name_full": address_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.address_client.List(
                    lara_django_base_pb2.AddressListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving address_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].address_id
            else:
                raise ValueError(f"Error retrieving address_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.address_client.List(lara_django_base_pb2.AddressListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.address_client.List(
                lara_django_base_pb2.AddressListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.address_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.address_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.address_full_client.List(
                lara_django_base_pb2.AddressFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.address_full_client.List(
                lara_django_base_pb2.AddressFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, address : base_dm.Address = None) -> None:
        try:
            await self.address_client.Update(
                lara_django_base_pb2.AddressRequest(**address.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating address_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.address_client.Destroy(lara_django_base_pb2.AddressDestroyRequest(address_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting address_id: {e}")

#_________________  RoomCategory  ______________________


class RoomCategoryInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.roomcategory_class_client = (
        #     lara_django_base_pb2_grpc.RoomCategoryclassByIRIControllerStub(channel)
        # )
        
        self.roomcategory_client = lara_django_base_pb2_grpc.RoomCategoryControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.roomcategory_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "roomcategory_id"

        # self.roomcategory_full_client = lara_django_base_pb2_grpc.RoomCategoryFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  roomcategories:  list[base_dm.RoomCategory] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.RoomCategory]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # roomcategoryclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if roomcategory_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.roomcategory_class_client.Retrieve(
        #         lara_django_base_pb2.RoomCategoryclassRetrieveRequest(iri=roomcategory_class_iri)
        #     )
        #     roomcategoryclass_id = res.roomcategoryclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving roomcategoryclass_id: {e}")
        # for roomcategory in roomcategorys:
        #     roomcategory.namespace = self.namespace_id
        #     roomcategory.roomcategory_class = roomcategoryclass_id

        try:
            create_coroutines = ( self.roomcategory_client.Create(lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump())) for roomcategory in roomcategories )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.roomcategory_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating roomcategory: {e}")

    @export_file
    async def retrieve(
        self, 
        roomcategory_id: str = None,
        roomcategory_name: str = None,
        #roomcategory_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.RoomCategory]:
        filter_list = []
        results_list = []
        if  roomcategory_id is not None:
            try:
                res =  await self.roomcategory_client.Retrieve(
                    lara_django_base_pb2.RoomCategoryRetrieveRequest(roomcategory_id=roomcategory_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving roomcategory_id: {e}")

        if roomcategory_name is not None:
            filter_list.append({"name": roomcategory_name})
        # if roomcategory_name_full is not None:
        #     filter_list.append({"name_full": roomcategory_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.roomcategory_client.List(
                        lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving roomcategory_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          roomcategory_name: str = None,
                          roomcategory_name_full: str = None,
                          iri: str = None,) -> str:
        if roomcategory_name is not None:
            filter_dict = {"name": roomcategory_name}
        elif roomcategory_name_full is not None:
            filter_dict = {"name_full": roomcategory_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.roomcategory_client.List(
                    lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving roomcategory_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].roomcategory_id
            else:
                raise ValueError(f"Error retrieving roomcategory_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.roomcategory_client.List(lara_django_base_pb2.RoomCategoryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.roomcategory_client.List(
                lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.roomcategory_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.roomcategory_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.roomcategory_full_client.List(
                lara_django_base_pb2.RoomCategoryFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.roomcategory_full_client.List(
                lara_django_base_pb2.RoomCategoryFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, roomcategory : base_dm.RoomCategory = None) -> None:
        try:
            await self.roomcategory_client.Update(
                lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating roomcategory_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.roomcategory_client.Destroy(lara_django_base_pb2.RoomCategoryDestroyRequest(roomcategory_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting roomcategory_id: {e}")

#_________________  Room  ______________________


class RoomInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.room_class_client = (
        #     lara_django_base_pb2_grpc.RoomclassByIRIControllerStub(channel)
        # )
        
        self.room_client = lara_django_base_pb2_grpc.RoomControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.room_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "room_id"

        # self.room_full_client = lara_django_base_pb2_grpc.RoomFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  rooms:  list[base_dm.Room] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Room]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # roomclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if room_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.room_class_client.Retrieve(
        #         lara_django_base_pb2.RoomclassRetrieveRequest(iri=room_class_iri)
        #     )
        #     roomclass_id = res.roomclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving roomclass_id: {e}")
        # for room in rooms:
        #     room.namespace = self.namespace_id
        #     room.room_class = roomclass_id

        try:
            create_coroutines = ( self.room_client.Create(lara_django_base_pb2.RoomRequest(**room.model_dump())) for room in rooms )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.room_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating room: {e}")

    @export_file
    async def retrieve(
        self, 
        room_id: str = None,
        room_name: str = None,
        #room_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Room]:
        filter_list = []
        results_list = []
        if  room_id is not None:
            try:
                res =  await self.room_client.Retrieve(
                    lara_django_base_pb2.RoomRetrieveRequest(room_id=room_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving room_id: {e}")

        if room_name is not None:
            filter_list.append({"name": room_name})
        # if room_name_full is not None:
        #     filter_list.append({"name_full": room_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.room_client.List(
                        lara_django_base_pb2.RoomListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving room_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          room_name: str = None,
                          room_name_full: str = None,
                          iri: str = None,) -> str:
        if room_name is not None:
            filter_dict = {"name": room_name}
        elif room_name_full is not None:
            filter_dict = {"name_full": room_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.room_client.List(
                    lara_django_base_pb2.RoomListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving room_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].room_id
            else:
                raise ValueError(f"Error retrieving room_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.room_client.List(lara_django_base_pb2.RoomListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.room_client.List(
                lara_django_base_pb2.RoomListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.room_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.room_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.room_full_client.List(
                lara_django_base_pb2.RoomFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.room_full_client.List(
                lara_django_base_pb2.RoomFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, room : base_dm.Room = None) -> None:
        try:
            await self.room_client.Update(
                lara_django_base_pb2.RoomRequest(**room.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating room_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.room_client.Destroy(lara_django_base_pb2.RoomDestroyRequest(room_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting room_id: {e}")

#_________________  Location  ______________________


class LocationInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.location_class_client = (
        #     lara_django_base_pb2_grpc.LocationclassByIRIControllerStub(channel)
        # )
        
        self.location_client = lara_django_base_pb2_grpc.LocationControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.location_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "location_id"

        # self.location_full_client = lara_django_base_pb2_grpc.LocationFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  locations:  list[base_dm.Location] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Location]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # locationclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if location_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.location_class_client.Retrieve(
        #         lara_django_base_pb2.LocationclassRetrieveRequest(iri=location_class_iri)
        #     )
        #     locationclass_id = res.locationclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving locationclass_id: {e}")
        # for location in locations:
        #     location.namespace = self.namespace_id
        #     location.location_class = locationclass_id

        try:
            create_coroutines = ( self.location_client.Create(lara_django_base_pb2.LocationRequest(**location.model_dump())) for location in locations )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.location_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating location: {e}")

    @export_file
    async def retrieve(
        self, 
        location_id: str = None,
        location_name: str = None,
        #location_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Location]:
        filter_list = []
        results_list = []
        if  location_id is not None:
            try:
                res =  await self.location_client.Retrieve(
                    lara_django_base_pb2.LocationRetrieveRequest(location_id=location_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving location_id: {e}")

        if location_name is not None:
            filter_list.append({"name": location_name})
        # if location_name_full is not None:
        #     filter_list.append({"name_full": location_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.location_client.List(
                        lara_django_base_pb2.LocationListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving location_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          location_name: str = None,
                          location_name_full: str = None,
                          iri: str = None,) -> str:
        if location_name is not None:
            filter_dict = {"name": location_name}
        elif location_name_full is not None:
            filter_dict = {"name_full": location_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.location_client.List(
                    lara_django_base_pb2.LocationListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving location_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].location_id
            else:
                raise ValueError(f"Error retrieving location_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.location_client.List(lara_django_base_pb2.LocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.location_client.List(
                lara_django_base_pb2.LocationListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.location_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.location_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.location_full_client.List(
                lara_django_base_pb2.LocationFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.location_full_client.List(
                lara_django_base_pb2.LocationFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, location : base_dm.Location = None) -> None:
        try:
            await self.location_client.Update(
                lara_django_base_pb2.LocationRequest(**location.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating location_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.location_client.Destroy(lara_django_base_pb2.LocationDestroyRequest(location_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting location_id: {e}")

#_________________  LARASyncServer  ______________________


class LARASyncServerInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.larasyncserver_class_client = (
        #     lara_django_base_pb2_grpc.LARASyncServerclassByIRIControllerStub(channel)
        # )
        
        self.larasyncserver_client = lara_django_base_pb2_grpc.LARASyncServerControllerStub(channel)

        # this is required by the import_file decorator, please activate if needed for file upload
        # self.stub = self.larasyncserver_client
        # self.file_chunk = lara_django_base_pb2.FileChunk
        # self.update_item_id = "larasyncserver_id"

        # self.larasyncserver_full_client = lara_django_base_pb2_grpc.LARASyncServerFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    #@create_file  # activate if needed for file upload
    #@create_image  # activate if needed for image upload
    async def create(self,  larasyncservers:  list[base_dm.LARASyncServer] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.LARASyncServer]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # larasyncserverclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if larasyncserver_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.larasyncserver_class_client.Retrieve(
        #         lara_django_base_pb2.LARASyncServerclassRetrieveRequest(iri=larasyncserver_class_iri)
        #     )
        #     larasyncserverclass_id = res.larasyncserverclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving larasyncserverclass_id: {e}")
        # for larasyncserver in larasyncservers:
        #     larasyncserver.namespace = self.namespace_id
        #     larasyncserver.larasyncserver_class = larasyncserverclass_id

        try:
            create_coroutines = ( self.larasyncserver_client.Create(lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump())) for larasyncserver in larasyncservers )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.larasyncserver_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating larasyncserver: {e}")

    @export_file
    async def retrieve(
        self, 
        larasyncserver_id: str = None,
        larasyncserver_name: str = None,
        #larasyncserver_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.LARASyncServer]:
        filter_list = []
        results_list = []
        if  larasyncserver_id is not None:
            try:
                res =  await self.larasyncserver_client.Retrieve(
                    lara_django_base_pb2.LARASyncServerRetrieveRequest(larasyncserver_id=larasyncserver_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving larasyncserver_id: {e}")

        if larasyncserver_name is not None:
            filter_list.append({"name": larasyncserver_name})
        # if larasyncserver_name_full is not None:
        #     filter_list.append({"name_full": larasyncserver_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.larasyncserver_client.List(
                        lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving larasyncserver_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          larasyncserver_name: str = None,
                          larasyncserver_name_full: str = None,
                          iri: str = None,) -> str:
        if larasyncserver_name is not None:
            filter_dict = {"name": larasyncserver_name}
        elif larasyncserver_name_full is not None:
            filter_dict = {"name_full": larasyncserver_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.larasyncserver_client.List(
                    lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving larasyncserver_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].larasyncserver_id
            else:
                raise ValueError(f"Error retrieving larasyncserver_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.larasyncserver_client.List(lara_django_base_pb2.LARASyncServerListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.larasyncserver_client.List(
                lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.larasyncserver_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.larasyncserver_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.larasyncserver_full_client.List(
                lara_django_base_pb2.LARASyncServerFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.larasyncserver_full_client.List(
                lara_django_base_pb2.LARASyncServerFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, larasyncserver : base_dm.LARASyncServer = None) -> None:
        try:
            await self.larasyncserver_client.Update(
                lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating larasyncserver_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.larasyncserver_client.Destroy(lara_django_base_pb2.LARASyncServerDestroyRequest(larasyncserver_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting larasyncserver_id: {e}")

