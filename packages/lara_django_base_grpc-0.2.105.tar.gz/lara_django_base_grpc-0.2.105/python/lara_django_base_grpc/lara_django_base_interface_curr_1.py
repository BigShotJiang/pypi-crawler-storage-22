"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_base high_level_interface *

:details: lara_django_base high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_base
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_base_grpc.lara_django_base_data_model as base_dm

logger = logging.getLogger(__name__)



#_________________  MediaType  ______________________


class MediaTypeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mediatype_client = lara_django_base_pb2_grpc.MediaTypeControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mediatypes:  list[base_dm.MediaType] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.MediaType]]:
        try:
            create_coroutines = ( self.mediatype_client.Create(lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump())) for mediatype in mediatypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mediatype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mediatype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        mediatype_id: str = None,
        mediatype_name: str = None,
        #mediatype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.MediaType]:
        """ retrieve a list of mediatype instances by mediatype_id, mediatype_name or filter_dict,
               returns a list of mediatype data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  mediatype_id is not None:
            try:
                res =  await self.mediatype_client.Retrieve(
                    lara_django_base_pb2.MediaTypeRetrieveRequest(mediatype_id=mediatype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mediatype_id: {e}")

        if mediatype_name is not None:
            filter_list.append({"name": mediatype_name})
        # if mediatype_name_full is not None:
        #     filter_list.append({"name_full": mediatype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mediatype_client.List(
                        lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving mediatype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          mediatype_name: str = None,
                          mediatype_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the mediatype_id for a given mediatype_name,
               mediatype_name_full or iri
        """
        if mediatype_name is not None:
            filter_dict = {"name": mediatype_name}
        elif mediatype_name_full is not None:
            filter_dict = {"name_full": mediatype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mediatype_client.List(
                lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving mediatype_name: {e}")
        if len(results) == 1 :
            return results[0].mediatype_id
        else:
            raise ValueError(f"Error retrieving mediatype_id - no or too many results found.")

    async def get_by_id(self, mediatype_id: str = None) -> base_dm.MediaType:
        """ retrieve a mediatype data model by mediatype_id """
        try:
            res = await self.mediatype_client.Retrieve(
                lara_django_base_pb2.MediaTypeRetrieveRequest(mediatype_id=mediatype_id)
            )
            return base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mediatype_id: {e}")

    async def get_by_name(self, mediatype_name: str = None,
                                namespace_uri : str = None) -> base_dm.MediaType:
        """ retrieve a mediatype data model by mediatype_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.mediatype_client.Retrieve(
                lara_django_base_pb2.MediaTypeRetrieveRequest(name=mediatype_name, namespace=namespace_id)
            )
            return base_dm.MediaType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mediatype_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mediatypes """
        if filter_dict is None:
            res = await self.mediatype_client.List(lara_django_base_pb2.MediaTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mediatype_client.List(
                lara_django_base_pb2.MediaTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mediatype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mediatypes """
        if self.mediatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mediatype_full_client.List(
                lara_django_base_pb2.MediaTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mediatype_full_client.List(
                lara_django_base_pb2.MediaTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mediatype : base_dm.MediaType = None) -> None:
        """ update a mediatype model instance """
        try:
            await self.mediatype_client.Update(
                lara_django_base_pb2.MediaTypeRequest(**mediatype.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mediatype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mediatype by mediatype_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mediatype_client.Destroy(lara_django_base_pb2.MediaTypeDestroyRequest(mediatype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mediatype_id: {e}")

#_________________  DataType  ______________________


class DataTypeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.datatype_client = lara_django_base_pb2_grpc.DataTypeControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  datatypes:  list[base_dm.DataType] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.DataType]]:
        try:
            create_coroutines = ( self.datatype_client.Create(lara_django_base_pb2.DataTypeRequest(**datatype.model_dump())) for datatype in datatypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.datatype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating datatype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        datatype_id: str = None,
        datatype_name: str = None,
        #datatype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.DataType]:
        """ retrieve a list of datatype instances by datatype_id, datatype_name or filter_dict,
               returns a list of datatype data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  datatype_id is not None:
            try:
                res =  await self.datatype_client.Retrieve(
                    lara_django_base_pb2.DataTypeRetrieveRequest(datatype_id=datatype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving datatype_id: {e}")

        if datatype_name is not None:
            filter_list.append({"name": datatype_name})
        # if datatype_name_full is not None:
        #     filter_list.append({"name_full": datatype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.datatype_client.List(
                        lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving datatype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          datatype_name: str = None,
                          datatype_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the datatype_id for a given datatype_name,
               datatype_name_full or iri
        """
        if datatype_name is not None:
            filter_dict = {"name": datatype_name}
        elif datatype_name_full is not None:
            filter_dict = {"name_full": datatype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.datatype_client.List(
                lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving datatype_name: {e}")
        if len(results) == 1 :
            return results[0].datatype_id
        else:
            raise ValueError(f"Error retrieving datatype_id - no or too many results found.")

    async def get_by_id(self, datatype_id: str = None) -> base_dm.DataType:
        """ retrieve a datatype data model by datatype_id """
        try:
            res = await self.datatype_client.Retrieve(
                lara_django_base_pb2.DataTypeRetrieveRequest(datatype_id=datatype_id)
            )
            return base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving datatype_id: {e}")

    async def get_by_name(self, datatype_name: str = None,
                                namespace_uri : str = None) -> base_dm.DataType:
        """ retrieve a datatype data model by datatype_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.datatype_client.Retrieve(
                lara_django_base_pb2.DataTypeRetrieveRequest(name=datatype_name, namespace=namespace_id)
            )
            return base_dm.DataType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving datatype_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all datatypes """
        if filter_dict is None:
            res = await self.datatype_client.List(lara_django_base_pb2.DataTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.datatype_client.List(
                lara_django_base_pb2.DataTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.datatype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all datatypes """
        if self.datatype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.datatype_full_client.List(
                lara_django_base_pb2.DataTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.datatype_full_client.List(
                lara_django_base_pb2.DataTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, datatype : base_dm.DataType = None) -> None:
        """ update a datatype model instance """
        try:
            await self.datatype_client.Update(
                lara_django_base_pb2.DataTypeRequest(**datatype.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating datatype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a datatype by datatype_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.datatype_client.Destroy(lara_django_base_pb2.DataTypeDestroyRequest(datatype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting datatype_id: {e}")

#_________________  Namespace  ______________________


class NamespaceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.id_cache = {}

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri

        self.namespaceURI_client = (
            lara_django_base_pb2_grpc.NamespaceByURIControllerStub(channel)
        )
        self.namespace_client = lara_django_base_pb2_grpc.NamespaceControllerStub(channel)

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str):
        self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  namespaces:  list[base_dm.Namespace] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.Namespace]]:
        try:
            create_coroutines = ( self.namespace_client.Create(lara_django_base_pb2.NamespaceRequest(**namespace.model_dump())) for namespace in namespaces )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.namespace_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating namespace: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_id: str = None,
        namespace_uri: str = None,
        #namespace_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Namespace]:
        """ retrieve a list of namespace instances by namespace_id, namespace_name or filter_dict,
               returns a list of namespace data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  namespace_id is not None:
            try:
                res =  await self.namespace_client.Retrieve(
                    lara_django_base_pb2.NamespaceRetrieveRequest(namespace_id=namespace_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        if namespace_uri is not None:
            filter_list.append({"uri": namespace_uri})
        # if namespace_name_full is not None:
        #     filter_list.append({"name_full": namespace_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.namespace_client.List(
                        lara_django_base_pb2.NamespaceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving namespace_uri: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, namespace_uri: str = None):
        # try:
        #     return self.id_cache[namespace_uri]
        # except KeyError:
        try:
            res = await self.namespaceURI_client.Retrieve(
                    lara_django_base_pb2.NamespaceByURIRetrieveRequest(uri=namespace_uri)
                )
            namespace_id = res.namespace_id
            self.id_cache[namespace_uri] = namespace_id
            return namespace_id
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        # if len(results) == 1 :
        #     return results[0].namespace_id
        # else:
            raise ValueError(f"Error retrieving namespace_id - no or too many results found.")

    async def get_by_id(self, namespace_id: str = None) -> base_dm.Namespace:
        """ retrieve a namespace data model by namespace_id """
        try:
            res = await self.namespace_client.Retrieve(
                lara_django_base_pb2.NamespaceRetrieveRequest(namespace_id=namespace_id)
            )
            return base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    async def get_by_name(self, namespace_name: str = None,
                                namespace_uri : str = None) -> base_dm.Namespace:
        """ retrieve a namespace data model by namespace_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.namespace_client.Retrieve(
                lara_django_base_pb2.NamespaceRetrieveRequest(name=namespace_name, namespace=namespace_id)
            )
            return base_dm.Namespace(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving namespace_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all namespaces """
        if filter_dict is None:
            res = await self.namespace_client.List(lara_django_base_pb2.NamespaceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.namespace_client.List(
                lara_django_base_pb2.NamespaceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.namespace_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all namespaces """
        if self.namespace_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.namespace_full_client.List(
                lara_django_base_pb2.NamespaceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.namespace_full_client.List(
                lara_django_base_pb2.NamespaceFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, namespace : base_dm.Namespace = None) -> None:
        """ update a namespace model instance """
        try:
            await self.namespace_client.Update(
                lara_django_base_pb2.NamespaceRequest(**namespace.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating namespace_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a namespace by namespace_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.namespace_client.Destroy(lara_django_base_pb2.NamespaceDestroyRequest(namespace_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting namespace_id: {e}")

#_________________  Tag  ______________________


class TagInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.tag_client = lara_django_base_pb2_grpc.TagControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  tags:  list[base_dm.Tag] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.Tag]]:
        try:
            create_coroutines = ( self.tag_client.Create(lara_django_base_pb2.TagRequest(**tag.model_dump())) for tag in tags )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.tag_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating tag: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        tag_id: str = None,
        tag_name: str = None,
        #tag_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Tag]:
        """ retrieve a list of tag instances by tag_id, tag_name or filter_dict,
               returns a list of tag data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  tag_id is not None:
            try:
                res =  await self.tag_client.Retrieve(
                    lara_django_base_pb2.TagRetrieveRequest(tag_id=tag_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving tag_id: {e}")

        if tag_name is not None:
            filter_list.append({"name": tag_name})
        # if tag_name_full is not None:
        #     filter_list.append({"name_full": tag_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.tag_client.List(
                        lara_django_base_pb2.TagListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving tag_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          tag_name: str = None,
                          tag_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the tag_id for a given tag_name,
               tag_name_full or iri
        """
        if tag_name is not None:
            filter_dict = {"name": tag_name}
        elif tag_name_full is not None:
            filter_dict = {"name_full": tag_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.tag_client.List(
                lara_django_base_pb2.TagListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving tag_name: {e}")
        if len(results) == 1 :
            return results[0].tag_id
        else:
            raise ValueError(f"Error retrieving tag_id - no or too many results found.")

    async def get_by_id(self, tag_id: str = None) -> base_dm.Tag:
        """ retrieve a tag data model by tag_id """
        try:
            res = await self.tag_client.Retrieve(
                lara_django_base_pb2.TagRetrieveRequest(tag_id=tag_id)
            )
            return base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving tag_id: {e}")

    async def get_by_name(self, tag_name: str = None,
                                namespace_uri : str = None) -> base_dm.Tag:
        """ retrieve a tag data model by tag_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.tag_client.Retrieve(
                lara_django_base_pb2.TagRetrieveRequest(name=tag_name, namespace=namespace_id)
            )
            return base_dm.Tag(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving tag_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all tags """
        if filter_dict is None:
            res = await self.tag_client.List(lara_django_base_pb2.TagListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.tag_client.List(
                lara_django_base_pb2.TagListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.tag_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all tags """
        if self.tag_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.tag_full_client.List(
                lara_django_base_pb2.TagFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.tag_full_client.List(
                lara_django_base_pb2.TagFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, tag : base_dm.Tag = None) -> None:
        """ update a tag model instance """
        try:
            await self.tag_client.Update(
                lara_django_base_pb2.TagRequest(**tag.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating tag_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a tag by tag_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.tag_client.Destroy(lara_django_base_pb2.TagDestroyRequest(tag_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting tag_id: {e}")

#_________________  ItemStatus  ______________________


class ItemStatusInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.itemstatus_client = lara_django_base_pb2_grpc.ItemStatusControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  itemstatus:  list[base_dm.ItemStatus] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.ItemStatus]]:
        try:
            create_coroutines = ( self.itemstatus_client.Create(lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump())) for itemstatus in itemstatus )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.itemstatus_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating itemstatus: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        itemstatus_id: str = None,
        itemstatus_name: str = None,
        #itemstatus_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ItemStatus]:
        """ retrieve a list of itemstatus instances by itemstatus_id, itemstatus_name or filter_dict,
               returns a list of itemstatus data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  itemstatus_id is not None:
            try:
                res =  await self.itemstatus_client.Retrieve(
                    lara_django_base_pb2.ItemStatusRetrieveRequest(itemstatus_id=itemstatus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving itemstatus_id: {e}")

        if itemstatus_name is not None:
            filter_list.append({"name": itemstatus_name})
        # if itemstatus_name_full is not None:
        #     filter_list.append({"name_full": itemstatus_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.itemstatus_client.List(
                        lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving itemstatus_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          itemstatus_name: str = None,
                          itemstatus_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the itemstatus_id for a given itemstatus_name,
               itemstatus_name_full or iri
        """
        if itemstatus_name is not None:
            filter_dict = {"name": itemstatus_name}
        elif itemstatus_name_full is not None:
            filter_dict = {"name_full": itemstatus_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.itemstatus_client.List(
                lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving itemstatus_name: {e}")
        if len(results) == 1 :
            return results[0].itemstatus_id
        else:
            raise ValueError(f"Error retrieving itemstatus_id - no or too many results found.")

    async def get_by_id(self, itemstatus_id: str = None) -> base_dm.ItemStatus:
        """ retrieve a itemstatus data model by itemstatus_id """
        try:
            res = await self.itemstatus_client.Retrieve(
                lara_django_base_pb2.ItemStatusRetrieveRequest(itemstatus_id=itemstatus_id)
            )
            return base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemstatus_id: {e}")

    async def get_by_name(self, itemstatus_name: str = None,
                                namespace_uri : str = None) -> base_dm.ItemStatus:
        """ retrieve a itemstatus data model by itemstatus_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.itemstatus_client.Retrieve(
                lara_django_base_pb2.ItemStatusRetrieveRequest(name=itemstatus_name, namespace=namespace_id)
            )
            return base_dm.ItemStatus(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving itemstatus_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all itemstatuss """
        if filter_dict is None:
            res = await self.itemstatus_client.List(lara_django_base_pb2.ItemStatusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.itemstatus_client.List(
                lara_django_base_pb2.ItemStatusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.itemstatus_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all itemstatuss """
        if self.itemstatus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.itemstatus_full_client.List(
                lara_django_base_pb2.ItemStatusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.itemstatus_full_client.List(
                lara_django_base_pb2.ItemStatusFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, itemstatus : base_dm.ItemStatus = None) -> None:
        """ update a itemstatus model instance """
        try:
            await self.itemstatus_client.Update(
                lara_django_base_pb2.ItemStatusRequest(**itemstatus.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating itemstatus_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a itemstatus by itemstatus_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.itemstatus_client.Destroy(lara_django_base_pb2.ItemStatusDestroyRequest(itemstatus_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting itemstatus_id: {e}")

#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_base_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_base_pb2_grpc.ExtraDataControllerStub(channel)

        self.stub = self.extradata_client
        self.file_chunk = lara_django_base_pb2.FileChunk
        self.update_item_id = "extradata_id"


        # self.extradata_full_client = lara_django_base_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[base_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        extradataclass_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_base_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            extradata.namespace = self.namespace_id
            extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, extradata_name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_base_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given extradata_name,
               extradata_name_full or iri
        """
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")
        if len(results) == 1 :
            return results[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None) -> base_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_base_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            return base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, extradata_name: str = None,
                                namespace_uri : str = None) -> base_dm.ExtraData:
        """ retrieve a extradata data model by extradata_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.extradata_client.Retrieve(
                lara_django_base_pb2.ExtraDataRetrieveRequest(name=extradata_name, namespace=namespace_id)
            )
            return base_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_base_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_base_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_base_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_base_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : base_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            await self.extradata_client.Update(
                lara_django_base_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_base_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  ExternalResource  ______________________


class ExternalResourceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.externalresource_class_client = (
        #     lara_django_base_pb2_grpc.ExternalResourceclassByIRIControllerStub(channel)
        # )

        self.externalresource_client = lara_django_base_pb2_grpc.ExternalResourceControllerStub(channel)


        # self.externalresource_full_client = lara_django_base_pb2_grpc.ExternalResourceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  externalresources:  list[base_dm.ExternalResource] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.ExternalResource]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        externalresourceclass_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if externalresource_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.externalresource_class_client.Retrieve(
        #         lara_django_base_pb2.ExternalResourceclassRetrieveRequest(iri=externalresource_class_iri)
        #     )
        #     externalresourceclass_id = res.externalresourceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving externalresourceclass_id: {e}")
        for externalresource in externalresources:
            externalresource.namespace = self.namespace_id
            externalresource.externalresource_class = externalresourceclass_id

        try:
            create_coroutines = ( self.externalresource_client.Create(lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump())) for externalresource in externalresources )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.externalresource_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating externalresource: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        externalresource_id: str = None,
        externalresource_name: str = None,
        #externalresource_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ExternalResource]:
        """ retrieve a list of externalresource instances by externalresource_id, externalresource_name or filter_dict,
               returns a list of externalresource data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  externalresource_id is not None:
            try:
                res =  await self.externalresource_client.Retrieve(
                    lara_django_base_pb2.ExternalResourceRetrieveRequest(externalresource_id=externalresource_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving externalresource_id: {e}")

        if externalresource_name is not None:
            filter_list.append({"name": externalresource_name})
        # if externalresource_name_full is not None:
        #     filter_list.append({"name_full": externalresource_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.externalresource_client.List(
                        lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving externalresource_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          externalresource_name: str = None,
                          externalresource_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the externalresource_id for a given externalresource_name,
               externalresource_name_full or iri
        """
        if externalresource_name is not None:
            filter_dict = {"name": externalresource_name}
        elif externalresource_name_full is not None:
            filter_dict = {"name_full": externalresource_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.externalresource_client.List(
                lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving externalresource_name: {e}")
        if len(results) == 1 :
            return results[0].externalresource_id
        else:
            raise ValueError(f"Error retrieving externalresource_id - no or too many results found.")

    async def get_by_id(self, externalresource_id: str = None) -> base_dm.ExternalResource:
        """ retrieve a externalresource data model by externalresource_id """
        try:
            res = await self.externalresource_client.Retrieve(
                lara_django_base_pb2.ExternalResourceRetrieveRequest(externalresource_id=externalresource_id)
            )
            return base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving externalresource_id: {e}")

    async def get_by_name(self, externalresource_name: str = None,
                                namespace_uri : str = None) -> base_dm.ExternalResource:
        """ retrieve a externalresource data model by externalresource_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.externalresource_client.Retrieve(
                lara_django_base_pb2.ExternalResourceRetrieveRequest(name=externalresource_name, namespace=namespace_id)
            )
            return base_dm.ExternalResource(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving externalresource_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all externalresources """
        if filter_dict is None:
            res = await self.externalresource_client.List(lara_django_base_pb2.ExternalResourceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.externalresource_client.List(
                lara_django_base_pb2.ExternalResourceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.externalresource_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all externalresources """
        if self.externalresource_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.externalresource_full_client.List(
                lara_django_base_pb2.ExternalResourceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.externalresource_full_client.List(
                lara_django_base_pb2.ExternalResourceFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, externalresource : base_dm.ExternalResource = None) -> None:
        """ update a externalresource model instance """
        try:
            await self.externalresource_client.Update(
                lara_django_base_pb2.ExternalResourceRequest(**externalresource.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating externalresource_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a externalresource by externalresource_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.externalresource_client.Destroy(lara_django_base_pb2.ExternalResourceDestroyRequest(externalresource_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting externalresource_id: {e}")

#_________________  PhysicalUnit  ______________________


class PhysicalUnitInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.physicalunit_client = lara_django_base_pb2_grpc.PhysicalUnitControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  physicalunits:  list[base_dm.PhysicalUnit] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.PhysicalUnit]]:
        try:
            create_coroutines = ( self.physicalunit_client.Create(lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump())) for physicalunit in physicalunits )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalunit_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating physicalunit: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        physicalunit_id: str = None,
        physicalunit_name: str = None,
        #physicalunit_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.PhysicalUnit]:
        """ retrieve a list of physicalunit instances by physicalunit_id, physicalunit_name or filter_dict,
               returns a list of physicalunit data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  physicalunit_id is not None:
            try:
                res =  await self.physicalunit_client.Retrieve(
                    lara_django_base_pb2.PhysicalUnitRetrieveRequest(physicalunit_id=physicalunit_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving physicalunit_id: {e}")

        if physicalunit_name is not None:
            filter_list.append({"name": physicalunit_name})
        # if physicalunit_name_full is not None:
        #     filter_list.append({"name_full": physicalunit_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalunit_client.List(
                        lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving physicalunit_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          physicalunit_name: str = None,
                          physicalunit_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the physicalunit_id for a given physicalunit_name,
               physicalunit_name_full or iri
        """
        if physicalunit_name is not None:
            filter_dict = {"name": physicalunit_name}
        elif physicalunit_name_full is not None:
            filter_dict = {"name_full": physicalunit_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.physicalunit_client.List(
                lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving physicalunit_name: {e}")
        if len(results) == 1 :
            return results[0].physicalunit_id
        else:
            raise ValueError(f"Error retrieving physicalunit_id - no or too many results found.")

    async def get_by_id(self, physicalunit_id: str = None) -> base_dm.PhysicalUnit:
        """ retrieve a physicalunit data model by physicalunit_id """
        try:
            res = await self.physicalunit_client.Retrieve(
                lara_django_base_pb2.PhysicalUnitRetrieveRequest(physicalunit_id=physicalunit_id)
            )
            return base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalunit_id: {e}")

    async def get_by_name(self, physicalunit_name: str = None,
                                namespace_uri : str = None) -> base_dm.PhysicalUnit:
        """ retrieve a physicalunit data model by physicalunit_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.physicalunit_client.Retrieve(
                lara_django_base_pb2.PhysicalUnitRetrieveRequest(name=physicalunit_name, namespace=namespace_id)
            )
            return base_dm.PhysicalUnit(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalunit_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all physicalunits """
        if filter_dict is None:
            res = await self.physicalunit_client.List(lara_django_base_pb2.PhysicalUnitListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalunit_client.List(
                lara_django_base_pb2.PhysicalUnitListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.physicalunit_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all physicalunits """
        if self.physicalunit_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalunit_full_client.List(
                lara_django_base_pb2.PhysicalUnitFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalunit_full_client.List(
                lara_django_base_pb2.PhysicalUnitFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, physicalunit : base_dm.PhysicalUnit = None) -> None:
        """ update a physicalunit model instance """
        try:
            await self.physicalunit_client.Update(
                lara_django_base_pb2.PhysicalUnitRequest(**physicalunit.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating physicalunit_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a physicalunit by physicalunit_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.physicalunit_client.Destroy(lara_django_base_pb2.PhysicalUnitDestroyRequest(physicalunit_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting physicalunit_id: {e}")

#_________________  PhysicalStateMatter  ______________________


class PhysicalStateMatterInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.physicalstatematter_client = lara_django_base_pb2_grpc.PhysicalStateMatterControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  physicalstatesmatter:  list[base_dm.PhysicalStateMatter] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.PhysicalStateMatter]]:
        try:
            create_coroutines = ( self.physicalstatematter_client.Create(lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump())) for physicalstatematter in physicalstatesmatter )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.physicalstatematter_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating physicalstatematter: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        physicalstatematter_id: str = None,
        physicalstatematter_name: str = None,
        #physicalstatematter_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.PhysicalStateMatter]:
        """ retrieve a list of physicalstatematter instances by physicalstatematter_id, physicalstatematter_name or filter_dict,
               returns a list of physicalstatematter data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  physicalstatematter_id is not None:
            try:
                res =  await self.physicalstatematter_client.Retrieve(
                    lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(physicalstatematter_id=physicalstatematter_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving physicalstatematter_id: {e}")

        if physicalstatematter_name is not None:
            filter_list.append({"name": physicalstatematter_name})
        # if physicalstatematter_name_full is not None:
        #     filter_list.append({"name_full": physicalstatematter_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.physicalstatematter_client.List(
                        lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving physicalstatematter_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          physicalstatematter_name: str = None,
                          physicalstatematter_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the physicalstatematter_id for a given physicalstatematter_name,
               physicalstatematter_name_full or iri
        """
        if physicalstatematter_name is not None:
            filter_dict = {"name": physicalstatematter_name}
        elif physicalstatematter_name_full is not None:
            filter_dict = {"name_full": physicalstatematter_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.physicalstatematter_client.List(
                lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter_name: {e}")
        if len(results) == 1 :
            return results[0].physicalstatematter_id
        else:
            raise ValueError(f"Error retrieving physicalstatematter_id - no or too many results found.")

    async def get_by_id(self, physicalstatematter_id: str = None) -> base_dm.PhysicalStateMatter:
        """ retrieve a physicalstatematter data model by physicalstatematter_id """
        try:
            res = await self.physicalstatematter_client.Retrieve(
                lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(physicalstatematter_id=physicalstatematter_id)
            )
            return base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter_id: {e}")

    async def get_by_name(self, physicalstatematter_name: str = None,
                                namespace_uri : str = None) -> base_dm.PhysicalStateMatter:
        """ retrieve a physicalstatematter data model by physicalstatematter_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.physicalstatematter_client.Retrieve(
                lara_django_base_pb2.PhysicalStateMatterRetrieveRequest(name=physicalstatematter_name, namespace=namespace_id)
            )
            return base_dm.PhysicalStateMatter(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving physicalstatematter_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all physicalstatematters """
        if filter_dict is None:
            res = await self.physicalstatematter_client.List(lara_django_base_pb2.PhysicalStateMatterListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.physicalstatematter_client.List(
                lara_django_base_pb2.PhysicalStateMatterListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.physicalstatematter_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all physicalstatematters """
        if self.physicalstatematter_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.physicalstatematter_full_client.List(
                lara_django_base_pb2.PhysicalStateMatterFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, physicalstatematter : base_dm.PhysicalStateMatter = None) -> None:
        """ update a physicalstatematter model instance """
        try:
            await self.physicalstatematter_client.Update(
                lara_django_base_pb2.PhysicalStateMatterRequest(**physicalstatematter.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating physicalstatematter_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a physicalstatematter by physicalstatematter_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.physicalstatematter_client.Destroy(lara_django_base_pb2.PhysicalStateMatterDestroyRequest(physicalstatematter_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting physicalstatematter_id: {e}")

#_________________  ScientificConstant  ______________________


class ScientificConstantInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.scientificconstant_client = lara_django_base_pb2_grpc.ScientificConstantControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  scientificconstants:  list[base_dm.ScientificConstant] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.ScientificConstant]]:
        try:
            create_coroutines = ( self.scientificconstant_client.Create(lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump())) for scientificconstant in scientificconstants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.scientificconstant_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating scientificconstant: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        scientificconstant_id: str = None,
        scientificconstant_name: str = None,
        #scientificconstant_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.ScientificConstant]:
        """ retrieve a list of scientificconstant instances by scientificconstant_id, scientificconstant_name or filter_dict,
               returns a list of scientificconstant data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  scientificconstant_id is not None:
            try:
                res =  await self.scientificconstant_client.Retrieve(
                    lara_django_base_pb2.ScientificConstantRetrieveRequest(scientificconstant_id=scientificconstant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving scientificconstant_id: {e}")

        if scientificconstant_name is not None:
            filter_list.append({"name": scientificconstant_name})
        # if scientificconstant_name_full is not None:
        #     filter_list.append({"name_full": scientificconstant_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.scientificconstant_client.List(
                        lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving scientificconstant_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          scientificconstant_name: str = None,
                          scientificconstant_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the scientificconstant_id for a given scientificconstant_name,
               scientificconstant_name_full or iri
        """
        if scientificconstant_name is not None:
            filter_dict = {"name": scientificconstant_name}
        elif scientificconstant_name_full is not None:
            filter_dict = {"name_full": scientificconstant_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.scientificconstant_client.List(
                lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant_name: {e}")
        if len(results) == 1 :
            return results[0].scientificconstant_id
        else:
            raise ValueError(f"Error retrieving scientificconstant_id - no or too many results found.")

    async def get_by_id(self, scientificconstant_id: str = None) -> base_dm.ScientificConstant:
        """ retrieve a scientificconstant data model by scientificconstant_id """
        try:
            res = await self.scientificconstant_client.Retrieve(
                lara_django_base_pb2.ScientificConstantRetrieveRequest(scientificconstant_id=scientificconstant_id)
            )
            return base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant_id: {e}")

    async def get_by_name(self, scientificconstant_name: str = None,
                                namespace_uri : str = None) -> base_dm.ScientificConstant:
        """ retrieve a scientificconstant data model by scientificconstant_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.scientificconstant_client.Retrieve(
                lara_django_base_pb2.ScientificConstantRetrieveRequest(name=scientificconstant_name, namespace=namespace_id)
            )
            return base_dm.ScientificConstant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving scientificconstant_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all scientificconstants """
        if filter_dict is None:
            res = await self.scientificconstant_client.List(lara_django_base_pb2.ScientificConstantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.scientificconstant_client.List(
                lara_django_base_pb2.ScientificConstantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.scientificconstant_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all scientificconstants """
        if self.scientificconstant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.scientificconstant_full_client.List(
                lara_django_base_pb2.ScientificConstantFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, scientificconstant : base_dm.ScientificConstant = None) -> None:
        """ update a scientificconstant model instance """
        try:
            await self.scientificconstant_client.Update(
                lara_django_base_pb2.ScientificConstantRequest(**scientificconstant.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating scientificconstant_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a scientificconstant by scientificconstant_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.scientificconstant_client.Destroy(lara_django_base_pb2.ScientificConstantDestroyRequest(scientificconstant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting scientificconstant_id: {e}")

#_________________  Currency  ______________________


class CurrencyInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.currency_client = lara_django_base_pb2_grpc.CurrencyControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  currencies:  list[base_dm.Currency] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.Currency]]:
        try:
            create_coroutines = ( self.currency_client.Create(lara_django_base_pb2.CurrencyRequest(**currency.model_dump())) for currency in currencies )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.currency_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating currency: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        currency_id: str = None,
        currency_name: str = None,
        #currency_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Currency]:
        """ retrieve a list of currency instances by currency_id, currency_name or filter_dict,
               returns a list of currency data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  currency_id is not None:
            try:
                res =  await self.currency_client.Retrieve(
                    lara_django_base_pb2.CurrencyRetrieveRequest(currency_id=currency_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving currency_id: {e}")

        if currency_name is not None:
            filter_list.append({"name": currency_name})
        # if currency_name_full is not None:
        #     filter_list.append({"name_full": currency_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.currency_client.List(
                        lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving currency_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          currency_name: str = None,
                          currency_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the currency_id for a given currency_name,
               currency_name_full or iri
        """
        if currency_name is not None:
            filter_dict = {"name": currency_name}
        elif currency_name_full is not None:
            filter_dict = {"name_full": currency_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.currency_client.List(
                lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving currency_name: {e}")
        if len(results) == 1 :
            return results[0].currency_id
        else:
            raise ValueError(f"Error retrieving currency_id - no or too many results found.")

    async def get_by_id(self, currency_id: str = None) -> base_dm.Currency:
        """ retrieve a currency data model by currency_id """
        try:
            res = await self.currency_client.Retrieve(
                lara_django_base_pb2.CurrencyRetrieveRequest(currency_id=currency_id)
            )
            return base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving currency_id: {e}")

    async def get_by_name(self, currency_name: str = None,
                                namespace_uri : str = None) -> base_dm.Currency:
        """ retrieve a currency data model by currency_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.currency_client.Retrieve(
                lara_django_base_pb2.CurrencyRetrieveRequest(name=currency_name, namespace=namespace_id)
            )
            return base_dm.Currency(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving currency_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all currencys """
        if filter_dict is None:
            res = await self.currency_client.List(lara_django_base_pb2.CurrencyListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.currency_client.List(
                lara_django_base_pb2.CurrencyListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.currency_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all currencys """
        if self.currency_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.currency_full_client.List(
                lara_django_base_pb2.CurrencyFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.currency_full_client.List(
                lara_django_base_pb2.CurrencyFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, currency : base_dm.Currency = None) -> None:
        """ update a currency model instance """
        try:
            await self.currency_client.Update(
                lara_django_base_pb2.CurrencyRequest(**currency.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating currency_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a currency by currency_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.currency_client.Destroy(lara_django_base_pb2.CurrencyDestroyRequest(currency_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting currency_id: {e}")

#_________________  GeoLocation  ______________________


class GeoLocationInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.geolocation_client = lara_django_base_pb2_grpc.GeoLocationControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  geolocations:  list[base_dm.GeoLocation] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.GeoLocation]]:
        try:
            create_coroutines = ( self.geolocation_client.Create(lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump())) for geolocation in geolocations )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.geolocation_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating geolocation: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        geolocation_id: str = None,
        geolocation_name: str = None,
        #geolocation_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.GeoLocation]:
        """ retrieve a list of geolocation instances by geolocation_id, geolocation_name or filter_dict,
               returns a list of geolocation data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  geolocation_id is not None:
            try:
                res =  await self.geolocation_client.Retrieve(
                    lara_django_base_pb2.GeoLocationRetrieveRequest(geolocation_id=geolocation_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving geolocation_id: {e}")

        if geolocation_name is not None:
            filter_list.append({"name": geolocation_name})
        # if geolocation_name_full is not None:
        #     filter_list.append({"name_full": geolocation_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.geolocation_client.List(
                        lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving geolocation_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          geolocation_name: str = None,
                          geolocation_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the geolocation_id for a given geolocation_name,
               geolocation_name_full or iri
        """
        if geolocation_name is not None:
            filter_dict = {"name": geolocation_name}
        elif geolocation_name_full is not None:
            filter_dict = {"name_full": geolocation_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.geolocation_client.List(
                lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving geolocation_name: {e}")
        if len(results) == 1 :
            return results[0].geolocation_id
        else:
            raise ValueError(f"Error retrieving geolocation_id - no or too many results found.")

    async def get_by_id(self, geolocation_id: str = None) -> base_dm.GeoLocation:
        """ retrieve a geolocation data model by geolocation_id """
        try:
            res = await self.geolocation_client.Retrieve(
                lara_django_base_pb2.GeoLocationRetrieveRequest(geolocation_id=geolocation_id)
            )
            return base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving geolocation_id: {e}")

    async def get_by_name(self, geolocation_name: str = None,
                                namespace_uri : str = None) -> base_dm.GeoLocation:
        """ retrieve a geolocation data model by geolocation_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.geolocation_client.Retrieve(
                lara_django_base_pb2.GeoLocationRetrieveRequest(name=geolocation_name, namespace=namespace_id)
            )
            return base_dm.GeoLocation(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving geolocation_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all geolocations """
        if filter_dict is None:
            res = await self.geolocation_client.List(lara_django_base_pb2.GeoLocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.geolocation_client.List(
                lara_django_base_pb2.GeoLocationListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.geolocation_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all geolocations """
        if self.geolocation_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.geolocation_full_client.List(
                lara_django_base_pb2.GeoLocationFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.geolocation_full_client.List(
                lara_django_base_pb2.GeoLocationFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, geolocation : base_dm.GeoLocation = None) -> None:
        """ update a geolocation model instance """
        try:
            await self.geolocation_client.Update(
                lara_django_base_pb2.GeoLocationRequest(**geolocation.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating geolocation_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a geolocation by geolocation_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.geolocation_client.Destroy(lara_django_base_pb2.GeoLocationDestroyRequest(geolocation_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting geolocation_id: {e}")

#_________________  Country  ______________________


class CountryInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.country_client = lara_django_base_pb2_grpc.CountryControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  countries:  list[base_dm.Country] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.Country]]:
        try:
            create_coroutines = ( self.country_client.Create(lara_django_base_pb2.CountryRequest(**country.model_dump())) for country in countries )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.country_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating country: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        country_id: str = None,
        country_name: str = None,
        #country_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Country]:
        """ retrieve a list of country instances by country_id, country_name or filter_dict,
               returns a list of country data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  country_id is not None:
            try:
                res =  await self.country_client.Retrieve(
                    lara_django_base_pb2.CountryRetrieveRequest(country_id=country_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving country_id: {e}")

        if country_name is not None:
            filter_list.append({"name": country_name})
        # if country_name_full is not None:
        #     filter_list.append({"name_full": country_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.country_client.List(
                        lara_django_base_pb2.CountryListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving country_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          country_name: str = None,
                          country_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the country_id for a given country_name,
               country_name_full or iri
        """
        if country_name is not None:
            filter_dict = {"name": country_name}
        elif country_name_full is not None:
            filter_dict = {"name_full": country_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.country_client.List(
                lara_django_base_pb2.CountryListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving country_name: {e}")
        if len(results) == 1 :
            return results[0].country_id
        else:
            raise ValueError(f"Error retrieving country_id - no or too many results found.")

    async def get_by_id(self, country_id: str = None) -> base_dm.Country:
        """ retrieve a country data model by country_id """
        try:
            res = await self.country_client.Retrieve(
                lara_django_base_pb2.CountryRetrieveRequest(country_id=country_id)
            )
            return base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving country_id: {e}")

    async def get_by_name(self, country_name: str = None,
                                namespace_uri : str = None) -> base_dm.Country:
        """ retrieve a country data model by country_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.country_client.Retrieve(
                lara_django_base_pb2.CountryRetrieveRequest(name=country_name, namespace=namespace_id)
            )
            return base_dm.Country(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving country_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all countrys """
        if filter_dict is None:
            res = await self.country_client.List(lara_django_base_pb2.CountryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.country_client.List(
                lara_django_base_pb2.CountryListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.country_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all countrys """
        if self.country_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.country_full_client.List(
                lara_django_base_pb2.CountryFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.country_full_client.List(
                lara_django_base_pb2.CountryFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, country : base_dm.Country = None) -> None:
        """ update a country model instance """
        try:
            await self.country_client.Update(
                lara_django_base_pb2.CountryRequest(**country.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating country_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a country by country_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.country_client.Destroy(lara_django_base_pb2.CountryDestroyRequest(country_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting country_id: {e}")

#_________________  SubdivisionType  ______________________


class SubdivisionTypeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.subdivisiontype_client = lara_django_base_pb2_grpc.SubdivisionTypeControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  subdivisiontypes:  list[base_dm.SubdivisionType] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.SubdivisionType]]:
        try:
            create_coroutines = ( self.subdivisiontype_client.Create(lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump())) for subdivisiontype in subdivisiontypes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.subdivisiontype_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating subdivisiontype: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        subdivisiontype_id: str = None,
        subdivisiontype_name: str = None,
        #subdivisiontype_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.SubdivisionType]:
        """ retrieve a list of subdivisiontype instances by subdivisiontype_id, subdivisiontype_name or filter_dict,
               returns a list of subdivisiontype data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  subdivisiontype_id is not None:
            try:
                res =  await self.subdivisiontype_client.Retrieve(
                    lara_django_base_pb2.SubdivisionTypeRetrieveRequest(subdivisiontype_id=subdivisiontype_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving subdivisiontype_id: {e}")

        if subdivisiontype_name is not None:
            filter_list.append({"name": subdivisiontype_name})
        # if subdivisiontype_name_full is not None:
        #     filter_list.append({"name_full": subdivisiontype_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.subdivisiontype_client.List(
                        lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving subdivisiontype_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          subdivisiontype_name: str = None,
                          subdivisiontype_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the subdivisiontype_id for a given subdivisiontype_name,
               subdivisiontype_name_full or iri
        """
        if subdivisiontype_name is not None:
            filter_dict = {"name": subdivisiontype_name}
        elif subdivisiontype_name_full is not None:
            filter_dict = {"name_full": subdivisiontype_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.subdivisiontype_client.List(
                lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype_name: {e}")
        if len(results) == 1 :
            return results[0].subdivisiontype_id
        else:
            raise ValueError(f"Error retrieving subdivisiontype_id - no or too many results found.")

    async def get_by_id(self, subdivisiontype_id: str = None) -> base_dm.SubdivisionType:
        """ retrieve a subdivisiontype data model by subdivisiontype_id """
        try:
            res = await self.subdivisiontype_client.Retrieve(
                lara_django_base_pb2.SubdivisionTypeRetrieveRequest(subdivisiontype_id=subdivisiontype_id)
            )
            return base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype_id: {e}")

    async def get_by_name(self, subdivisiontype_name: str = None,
                                namespace_uri : str = None) -> base_dm.SubdivisionType:
        """ retrieve a subdivisiontype data model by subdivisiontype_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.subdivisiontype_client.Retrieve(
                lara_django_base_pb2.SubdivisionTypeRetrieveRequest(name=subdivisiontype_name, namespace=namespace_id)
            )
            return base_dm.SubdivisionType(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving subdivisiontype_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all subdivisiontypes """
        if filter_dict is None:
            res = await self.subdivisiontype_client.List(lara_django_base_pb2.SubdivisionTypeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.subdivisiontype_client.List(
                lara_django_base_pb2.SubdivisionTypeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subdivisiontype_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all subdivisiontypes """
        if self.subdivisiontype_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.subdivisiontype_full_client.List(
                lara_django_base_pb2.SubdivisionTypeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.subdivisiontype_full_client.List(
                lara_django_base_pb2.SubdivisionTypeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, subdivisiontype : base_dm.SubdivisionType = None) -> None:
        """ update a subdivisiontype model instance """
        try:
            await self.subdivisiontype_client.Update(
                lara_django_base_pb2.SubdivisionTypeRequest(**subdivisiontype.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating subdivisiontype_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a subdivisiontype by subdivisiontype_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.subdivisiontype_client.Destroy(lara_django_base_pb2.SubdivisionTypeDestroyRequest(subdivisiontype_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting subdivisiontype_id: {e}")

#_________________  CountrySubdivision  ______________________


class CountrySubdivisionInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.countrysubdivision_client = lara_django_base_pb2_grpc.CountrySubdivisionControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  countrysubdivisions:  list[base_dm.CountrySubdivision] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.CountrySubdivision]]:
        try:
            create_coroutines = ( self.countrysubdivision_client.Create(lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump())) for countrysubdivision in countrysubdivisions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.countrysubdivision_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating countrysubdivision: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        countrysubdivision_id: str = None,
        countrysubdivision_name: str = None,
        #countrysubdivision_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.CountrySubdivision]:
        """ retrieve a list of countrysubdivision instances by countrysubdivision_id, countrysubdivision_name or filter_dict,
               returns a list of countrysubdivision data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  countrysubdivision_id is not None:
            try:
                res =  await self.countrysubdivision_client.Retrieve(
                    lara_django_base_pb2.CountrySubdivisionRetrieveRequest(countrysubdivision_id=countrysubdivision_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving countrysubdivision_id: {e}")

        if countrysubdivision_name is not None:
            filter_list.append({"name": countrysubdivision_name})
        # if countrysubdivision_name_full is not None:
        #     filter_list.append({"name_full": countrysubdivision_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.countrysubdivision_client.List(
                        lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving countrysubdivision_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          countrysubdivision_name: str = None,
                          countrysubdivision_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the countrysubdivision_id for a given countrysubdivision_name,
               countrysubdivision_name_full or iri
        """
        if countrysubdivision_name is not None:
            filter_dict = {"name": countrysubdivision_name}
        elif countrysubdivision_name_full is not None:
            filter_dict = {"name_full": countrysubdivision_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.countrysubdivision_client.List(
                lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision_name: {e}")
        if len(results) == 1 :
            return results[0].countrysubdivision_id
        else:
            raise ValueError(f"Error retrieving countrysubdivision_id - no or too many results found.")

    async def get_by_id(self, countrysubdivision_id: str = None) -> base_dm.CountrySubdivision:
        """ retrieve a countrysubdivision data model by countrysubdivision_id """
        try:
            res = await self.countrysubdivision_client.Retrieve(
                lara_django_base_pb2.CountrySubdivisionRetrieveRequest(countrysubdivision_id=countrysubdivision_id)
            )
            return base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision_id: {e}")

    async def get_by_name(self, countrysubdivision_name: str = None,
                                namespace_uri : str = None) -> base_dm.CountrySubdivision:
        """ retrieve a countrysubdivision data model by countrysubdivision_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.countrysubdivision_client.Retrieve(
                lara_django_base_pb2.CountrySubdivisionRetrieveRequest(name=countrysubdivision_name, namespace=namespace_id)
            )
            return base_dm.CountrySubdivision(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving countrysubdivision_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all countrysubdivisions """
        if filter_dict is None:
            res = await self.countrysubdivision_client.List(lara_django_base_pb2.CountrySubdivisionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.countrysubdivision_client.List(
                lara_django_base_pb2.CountrySubdivisionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.countrysubdivision_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all countrysubdivisions """
        if self.countrysubdivision_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.countrysubdivision_full_client.List(
                lara_django_base_pb2.CountrySubdivisionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, countrysubdivision : base_dm.CountrySubdivision = None) -> None:
        """ update a countrysubdivision model instance """
        try:
            await self.countrysubdivision_client.Update(
                lara_django_base_pb2.CountrySubdivisionRequest(**countrysubdivision.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating countrysubdivision_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a countrysubdivision by countrysubdivision_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.countrysubdivision_client.Destroy(lara_django_base_pb2.CountrySubdivisionDestroyRequest(countrysubdivision_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting countrysubdivision_id: {e}")

#_________________  City  ______________________


class CityInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.city_client = lara_django_base_pb2_grpc.CityControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  cities:  list[base_dm.City] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.City]]:
        try:
            create_coroutines = ( self.city_client.Create(lara_django_base_pb2.CityRequest(**city.model_dump())) for city in cities )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.city_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating city: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        city_id: str = None,
        city_name: str = None,
        #city_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.City]:
        """ retrieve a list of city instances by city_id, city_name or filter_dict,
               returns a list of city data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  city_id is not None:
            try:
                res =  await self.city_client.Retrieve(
                    lara_django_base_pb2.CityRetrieveRequest(city_id=city_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving city_id: {e}")

        if city_name is not None:
            filter_list.append({"name": city_name})
        # if city_name_full is not None:
        #     filter_list.append({"name_full": city_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.city_client.List(
                        lara_django_base_pb2.CityListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.City(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving city_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          city_name: str = None,
                          city_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the city_id for a given city_name,
               city_name_full or iri
        """
        if city_name is not None:
            filter_dict = {"name": city_name}
        elif city_name_full is not None:
            filter_dict = {"name_full": city_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.city_client.List(
                lara_django_base_pb2.CityListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving city_name: {e}")
        if len(results) == 1 :
            return results[0].city_id
        else:
            raise ValueError(f"Error retrieving city_id - no or too many results found.")

    async def get_by_id(self, city_id: str = None) -> base_dm.City:
        """ retrieve a city data model by city_id """
        try:
            res = await self.city_client.Retrieve(
                lara_django_base_pb2.CityRetrieveRequest(city_id=city_id)
            )
            return base_dm.City(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving city_id: {e}")

    async def get_by_name(self, city_name: str = None,
                                namespace_uri : str = None) -> base_dm.City:
        """ retrieve a city data model by city_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.city_client.Retrieve(
                lara_django_base_pb2.CityRetrieveRequest(name=city_name, namespace=namespace_id)
            )
            return base_dm.City(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving city_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all citys """
        if filter_dict is None:
            res = await self.city_client.List(lara_django_base_pb2.CityListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.city_client.List(
                lara_django_base_pb2.CityListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.city_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all citys """
        if self.city_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.city_full_client.List(
                lara_django_base_pb2.CityFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.city_full_client.List(
                lara_django_base_pb2.CityFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, city : base_dm.City = None) -> None:
        """ update a city model instance """
        try:
            await self.city_client.Update(
                lara_django_base_pb2.CityRequest(**city.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating city_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a city by city_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.city_client.Destroy(lara_django_base_pb2.CityDestroyRequest(city_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting city_id: {e}")

#_________________  Address  ______________________


class AddressInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.address_class_client = (
        #     lara_django_base_pb2_grpc.AddressclassByIRIControllerStub(channel)
        # )

        self.address_client = lara_django_base_pb2_grpc.AddressControllerStub(channel)


        # self.address_full_client = lara_django_base_pb2_grpc.AddressFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  addresses:  list[base_dm.Address] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Address]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        addressclass_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if address_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.address_class_client.Retrieve(
        #         lara_django_base_pb2.AddressclassRetrieveRequest(iri=address_class_iri)
        #     )
        #     addressclass_id = res.addressclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving addressclass_id: {e}")
        for address in addresses:
            address.namespace = self.namespace_id
            address.address_class = addressclass_id

        try:
            create_coroutines = ( self.address_client.Create(lara_django_base_pb2.AddressRequest(**address.model_dump())) for address in addresses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.address_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating address: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        address_id: str = None,
        address_name: str = None,
        #address_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Address]:
        """ retrieve a list of address instances by address_id, address_name or filter_dict,
               returns a list of address data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  address_id is not None:
            try:
                res =  await self.address_client.Retrieve(
                    lara_django_base_pb2.AddressRetrieveRequest(address_id=address_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving address_id: {e}")

        if address_name is not None:
            filter_list.append({"name": address_name})
        # if address_name_full is not None:
        #     filter_list.append({"name_full": address_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.address_client.List(
                        lara_django_base_pb2.AddressListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving address_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          address_name: str = None,
                          address_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the address_id for a given address_name,
               address_name_full or iri
        """
        if address_name is not None:
            filter_dict = {"name": address_name}
        elif address_name_full is not None:
            filter_dict = {"name_full": address_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.address_client.List(
                lara_django_base_pb2.AddressListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving address_name: {e}")
        if len(results) == 1 :
            return results[0].address_id
        else:
            raise ValueError(f"Error retrieving address_id - no or too many results found.")

    async def get_by_id(self, address_id: str = None) -> base_dm.Address:
        """ retrieve a address data model by address_id """
        try:
            res = await self.address_client.Retrieve(
                lara_django_base_pb2.AddressRetrieveRequest(address_id=address_id)
            )
            return base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving address_id: {e}")

    async def get_by_name(self, address_name: str = None,
                                namespace_uri : str = None) -> base_dm.Address:
        """ retrieve a address data model by address_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.address_client.Retrieve(
                lara_django_base_pb2.AddressRetrieveRequest(name=address_name, namespace=namespace_id)
            )
            return base_dm.Address(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving address_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all addresss """
        if filter_dict is None:
            res = await self.address_client.List(lara_django_base_pb2.AddressListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.address_client.List(
                lara_django_base_pb2.AddressListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.address_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all addresss """
        if self.address_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.address_full_client.List(
                lara_django_base_pb2.AddressFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.address_full_client.List(
                lara_django_base_pb2.AddressFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, address : base_dm.Address = None) -> None:
        """ update a address model instance """
        try:
            await self.address_client.Update(
                lara_django_base_pb2.AddressRequest(**address.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating address_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a address by address_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.address_client.Destroy(lara_django_base_pb2.AddressDestroyRequest(address_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting address_id: {e}")

#_________________  RoomCategory  ______________________


class RoomCategoryInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.roomcategory_client = lara_django_base_pb2_grpc.RoomCategoryControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  roomcategories:  list[base_dm.RoomCategory] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.RoomCategory]]:
        try:
            create_coroutines = ( self.roomcategory_client.Create(lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump())) for roomcategory in roomcategories )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.roomcategory_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating roomcategory: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        roomcategory_id: str = None,
        roomcategory_name: str = None,
        #roomcategory_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.RoomCategory]:
        """ retrieve a list of roomcategory instances by roomcategory_id, roomcategory_name or filter_dict,
               returns a list of roomcategory data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  roomcategory_id is not None:
            try:
                res =  await self.roomcategory_client.Retrieve(
                    lara_django_base_pb2.RoomCategoryRetrieveRequest(roomcategory_id=roomcategory_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving roomcategory_id: {e}")

        if roomcategory_name is not None:
            filter_list.append({"name": roomcategory_name})
        # if roomcategory_name_full is not None:
        #     filter_list.append({"name_full": roomcategory_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.roomcategory_client.List(
                        lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving roomcategory_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          roomcategory_name: str = None,
                          roomcategory_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the roomcategory_id for a given roomcategory_name,
               roomcategory_name_full or iri
        """
        if roomcategory_name is not None:
            filter_dict = {"name": roomcategory_name}
        elif roomcategory_name_full is not None:
            filter_dict = {"name_full": roomcategory_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.roomcategory_client.List(
                lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving roomcategory_name: {e}")
        if len(results) == 1 :
            return results[0].roomcategory_id
        else:
            raise ValueError(f"Error retrieving roomcategory_id - no or too many results found.")

    async def get_by_id(self, roomcategory_id: str = None) -> base_dm.RoomCategory:
        """ retrieve a roomcategory data model by roomcategory_id """
        try:
            res = await self.roomcategory_client.Retrieve(
                lara_django_base_pb2.RoomCategoryRetrieveRequest(roomcategory_id=roomcategory_id)
            )
            return base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roomcategory_id: {e}")

    async def get_by_name(self, roomcategory_name: str = None,
                                namespace_uri : str = None) -> base_dm.RoomCategory:
        """ retrieve a roomcategory data model by roomcategory_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.roomcategory_client.Retrieve(
                lara_django_base_pb2.RoomCategoryRetrieveRequest(name=roomcategory_name, namespace=namespace_id)
            )
            return base_dm.RoomCategory(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving roomcategory_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all roomcategorys """
        if filter_dict is None:
            res = await self.roomcategory_client.List(lara_django_base_pb2.RoomCategoryListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.roomcategory_client.List(
                lara_django_base_pb2.RoomCategoryListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.roomcategory_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all roomcategorys """
        if self.roomcategory_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.roomcategory_full_client.List(
                lara_django_base_pb2.RoomCategoryFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.roomcategory_full_client.List(
                lara_django_base_pb2.RoomCategoryFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, roomcategory : base_dm.RoomCategory = None) -> None:
        """ update a roomcategory model instance """
        try:
            await self.roomcategory_client.Update(
                lara_django_base_pb2.RoomCategoryRequest(**roomcategory.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating roomcategory_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a roomcategory by roomcategory_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.roomcategory_client.Destroy(lara_django_base_pb2.RoomCategoryDestroyRequest(roomcategory_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting roomcategory_id: {e}")

#_________________  Room  ______________________


class RoomInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.room_class_client = (
        #     lara_django_base_pb2_grpc.RoomclassByIRIControllerStub(channel)
        # )

        self.room_client = lara_django_base_pb2_grpc.RoomControllerStub(channel)


        # self.room_full_client = lara_django_base_pb2_grpc.RoomFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  rooms:  list[base_dm.Room] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Room]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        roomclass_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if room_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.room_class_client.Retrieve(
        #         lara_django_base_pb2.RoomclassRetrieveRequest(iri=room_class_iri)
        #     )
        #     roomclass_id = res.roomclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving roomclass_id: {e}")
        for room in rooms:
            room.namespace = self.namespace_id
            room.room_class = roomclass_id

        try:
            create_coroutines = ( self.room_client.Create(lara_django_base_pb2.RoomRequest(**room.model_dump())) for room in rooms )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.room_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating room: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        room_id: str = None,
        room_name: str = None,
        #room_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Room]:
        """ retrieve a list of room instances by room_id, room_name or filter_dict,
               returns a list of room data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  room_id is not None:
            try:
                res =  await self.room_client.Retrieve(
                    lara_django_base_pb2.RoomRetrieveRequest(room_id=room_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving room_id: {e}")

        if room_name is not None:
            filter_list.append({"name": room_name})
        # if room_name_full is not None:
        #     filter_list.append({"name_full": room_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.room_client.List(
                        lara_django_base_pb2.RoomListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving room_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          room_name: str = None,
                          room_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the room_id for a given room_name,
               room_name_full or iri
        """
        if room_name is not None:
            filter_dict = {"name": room_name}
        elif room_name_full is not None:
            filter_dict = {"name_full": room_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.room_client.List(
                lara_django_base_pb2.RoomListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving room_name: {e}")
        if len(results) == 1 :
            return results[0].room_id
        else:
            raise ValueError(f"Error retrieving room_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, room_id: str = None) -> base_dm.Room:
        """ retrieve a room data model by room_id """
        try:
            res = await self.room_client.Retrieve(
                lara_django_base_pb2.RoomRetrieveRequest(room_id=room_id)
            )
            return base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving room_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, room_name: str = None,
                                namespace_uri : str = None) -> base_dm.Room:
        """ retrieve a room data model by room_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.room_client.Retrieve(
                lara_django_base_pb2.RoomRetrieveRequest(name=room_name, namespace=namespace_id)
            )
            return base_dm.Room(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving room_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all rooms """
        if filter_dict is None:
            res = await self.room_client.List(lara_django_base_pb2.RoomListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.room_client.List(
                lara_django_base_pb2.RoomListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.room_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all rooms """
        if self.room_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.room_full_client.List(
                lara_django_base_pb2.RoomFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.room_full_client.List(
                lara_django_base_pb2.RoomFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, room : base_dm.Room = None) -> None:
        """ update a room model instance """
        try:
            await self.room_client.Update(
                lara_django_base_pb2.RoomRequest(**room.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating room_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a room by room_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.room_client.Destroy(lara_django_base_pb2.RoomDestroyRequest(room_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting room_id: {e}")

#_________________  Location  ______________________


class LocationInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.location_class_client = (
        #     lara_django_base_pb2_grpc.LocationclassByIRIControllerStub(channel)
        # )

        self.location_client = lara_django_base_pb2_grpc.LocationControllerStub(channel)


        # self.location_full_client = lara_django_base_pb2_grpc.LocationFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  locations:  list[base_dm.Location] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[base_dm.Location]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        locationclass_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if location_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.location_class_client.Retrieve(
        #         lara_django_base_pb2.LocationclassRetrieveRequest(iri=location_class_iri)
        #     )
        #     locationclass_id = res.locationclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving locationclass_id: {e}")
        for location in locations:
            location.namespace = self.namespace_id
            location.location_class = locationclass_id

        try:
            create_coroutines = ( self.location_client.Create(lara_django_base_pb2.LocationRequest(**location.model_dump())) for location in locations )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.location_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating location: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        location_id: str = None,
        location_name: str = None,
        #location_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.Location]:
        """ retrieve a list of location instances by location_id, location_name or filter_dict,
               returns a list of location data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  location_id is not None:
            try:
                res =  await self.location_client.Retrieve(
                    lara_django_base_pb2.LocationRetrieveRequest(location_id=location_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving location_id: {e}")

        if location_name is not None:
            filter_list.append({"name": location_name})
        # if location_name_full is not None:
        #     filter_list.append({"name_full": location_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.location_client.List(
                        lara_django_base_pb2.LocationListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving location_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          location_name: str = None,
                          location_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the location_id for a given location_name,
               location_name_full or iri
        """
        if location_name is not None:
            filter_dict = {"name": location_name}
        elif location_name_full is not None:
            filter_dict = {"name_full": location_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.location_client.List(
                lara_django_base_pb2.LocationListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving location_name: {e}")
        if len(results) == 1 :
            return results[0].location_id
        else:
            raise ValueError(f"Error retrieving location_id - no or too many results found.")

    async def get_by_id(self, location_id: str = None) -> base_dm.Location:
        """ retrieve a location data model by location_id """
        try:
            res = await self.location_client.Retrieve(
                lara_django_base_pb2.LocationRetrieveRequest(location_id=location_id)
            )
            return base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving location_id: {e}")

    async def get_by_name(self, location_name: str = None,
                                namespace_uri : str = None) -> base_dm.Location:
        """ retrieve a location data model by location_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.location_client.Retrieve(
                lara_django_base_pb2.LocationRetrieveRequest(name=location_name, namespace=namespace_id)
            )
            return base_dm.Location(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving location_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all locations """
        if filter_dict is None:
            res = await self.location_client.List(lara_django_base_pb2.LocationListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.location_client.List(
                lara_django_base_pb2.LocationListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.location_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all locations """
        if self.location_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.location_full_client.List(
                lara_django_base_pb2.LocationFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.location_full_client.List(
                lara_django_base_pb2.LocationFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, location : base_dm.Location = None) -> None:
        """ update a location model instance """
        try:
            await self.location_client.Update(
                lara_django_base_pb2.LocationRequest(**location.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating location_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a location by location_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.location_client.Destroy(lara_django_base_pb2.LocationDestroyRequest(location_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting location_id: {e}")

#_________________  LARAExtension  ______________________


class LARAExtensionInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.laraextension_client = lara_django_base_pb2_grpc.LARAExtensionControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  laraextensions:  list[base_dm.LARAExtension] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.LARAExtension]]:
        try:
            create_coroutines = ( self.laraextension_client.Create(lara_django_base_pb2.LARAExtensionRequest(**laraextension.model_dump())) for laraextension in laraextensions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.laraextension_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating laraextension: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        laraextension_id: str = None,
        laraextension_name: str = None,
        #laraextension_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.LARAExtension]:
        """ retrieve a list of laraextension instances by laraextension_id, laraextension_name or filter_dict,
               returns a list of laraextension data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  laraextension_id is not None:
            try:
                res =  await self.laraextension_client.Retrieve(
                    lara_django_base_pb2.LARAExtensionRetrieveRequest(laraextension_id=laraextension_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving laraextension_id: {e}")

        if laraextension_name is not None:
            filter_list.append({"name": laraextension_name})
        # if laraextension_name_full is not None:
        #     filter_list.append({"name_full": laraextension_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.laraextension_client.List(
                        lara_django_base_pb2.LARAExtensionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving laraextension_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          laraextension_name: str = None,
                          laraextension_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the laraextension_id for a given laraextension_name,
               laraextension_name_full or iri
        """
        if laraextension_name is not None:
            filter_dict = {"name": laraextension_name}
        elif laraextension_name_full is not None:
            filter_dict = {"name_full": laraextension_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.laraextension_client.List(
                lara_django_base_pb2.LARAExtensionListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving laraextension_name: {e}")
        if len(results) == 1 :
            return results[0].laraextension_id
        else:
            raise ValueError(f"Error retrieving laraextension_id - no or too many results found.")

    async def get_by_id(self, laraextension_id: str = None) -> base_dm.LARAExtension:
        """ retrieve a laraextension data model by laraextension_id """
        try:
            res = await self.laraextension_client.Retrieve(
                lara_django_base_pb2.LARAExtensionRetrieveRequest(laraextension_id=laraextension_id)
            )
            return base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving laraextension_id: {e}")

    async def get_by_name(self, laraextension_name: str = None,
                                namespace_uri : str = None) -> base_dm.LARAExtension:
        """ retrieve a laraextension data model by laraextension_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.laraextension_client.Retrieve(
                lara_django_base_pb2.LARAExtensionRetrieveRequest(name=laraextension_name, namespace=namespace_id)
            )
            return base_dm.LARAExtension(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving laraextension_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all laraextensions """
        if filter_dict is None:
            res = await self.laraextension_client.List(lara_django_base_pb2.LARAExtensionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.laraextension_client.List(
                lara_django_base_pb2.LARAExtensionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.laraextension_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all laraextensions """
        if self.laraextension_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.laraextension_full_client.List(
                lara_django_base_pb2.LARAExtensionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.laraextension_full_client.List(
                lara_django_base_pb2.LARAExtensionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, laraextension : base_dm.LARAExtension = None) -> None:
        """ update a laraextension model instance """
        try:
            await self.laraextension_client.Update(
                lara_django_base_pb2.LARAExtensionRequest(**laraextension.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating laraextension_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a laraextension by laraextension_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.laraextension_client.Destroy(lara_django_base_pb2.LARAExtensionDestroyRequest(laraextension_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting laraextension_id: {e}")

#_________________  LARASyncServer  ______________________


class LARASyncServerInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.larasyncserver_client = lara_django_base_pb2_grpc.LARASyncServerControllerStub(channel)



    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  larasyncservers:  list[base_dm.LARASyncServer] = None,  ids_only: bool = False) -> Union[list[str], list[base_dm.LARASyncServer]]:
        try:
            create_coroutines = ( self.larasyncserver_client.Create(lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump())) for larasyncserver in larasyncservers )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.larasyncserver_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating larasyncserver: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        larasyncserver_id: str = None,
        larasyncserver_name: str = None,
        #larasyncserver_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[base_dm.LARASyncServer]:
        """ retrieve a list of larasyncserver instances by larasyncserver_id, larasyncserver_name or filter_dict,
               returns a list of larasyncserver data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  larasyncserver_id is not None:
            try:
                res =  await self.larasyncserver_client.Retrieve(
                    lara_django_base_pb2.LARASyncServerRetrieveRequest(larasyncserver_id=larasyncserver_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving larasyncserver_id: {e}")

        if larasyncserver_name is not None:
            filter_list.append({"name": larasyncserver_name})
        # if larasyncserver_name_full is not None:
        #     filter_list.append({"name_full": larasyncserver_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.larasyncserver_client.List(
                        lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving larasyncserver_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          larasyncserver_name: str = None,
                          larasyncserver_name_full: str = None,
                          iri: str = None,) -> str:
        """ retrieve the larasyncserver_id for a given larasyncserver_name,
               larasyncserver_name_full or iri
        """
        if larasyncserver_name is not None:
            filter_dict = {"name": larasyncserver_name}
        elif larasyncserver_name_full is not None:
            filter_dict = {"name_full": larasyncserver_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.larasyncserver_client.List(
                lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver_name: {e}")
        if len(results) == 1 :
            return results[0].larasyncserver_id
        else:
            raise ValueError(f"Error retrieving larasyncserver_id - no or too many results found.")

    async def get_by_id(self, larasyncserver_id: str = None) -> base_dm.LARASyncServer:
        """ retrieve a larasyncserver data model by larasyncserver_id """
        try:
            res = await self.larasyncserver_client.Retrieve(
                lara_django_base_pb2.LARASyncServerRetrieveRequest(larasyncserver_id=larasyncserver_id)
            )
            return base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver_id: {e}")

    async def get_by_name(self, larasyncserver_name: str = None,
                                namespace_uri : str = None) -> base_dm.LARASyncServer:
        """ retrieve a larasyncserver data model by larasyncserver_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            res = await self.larasyncserver_client.Retrieve(
                lara_django_base_pb2.LARASyncServerRetrieveRequest(name=larasyncserver_name, namespace=namespace_id)
            )
            return base_dm.LARASyncServer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving larasyncserver_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all larasyncservers """
        if filter_dict is None:
            res = await self.larasyncserver_client.List(lara_django_base_pb2.LARASyncServerListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.larasyncserver_client.List(
                lara_django_base_pb2.LARASyncServerListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.larasyncserver_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all larasyncservers """
        if self.larasyncserver_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.larasyncserver_full_client.List(
                lara_django_base_pb2.LARASyncServerFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.larasyncserver_full_client.List(
                lara_django_base_pb2.LARASyncServerFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, larasyncserver : base_dm.LARASyncServer = None) -> None:
        """ update a larasyncserver model instance """
        try:
            await self.larasyncserver_client.Update(
                lara_django_base_pb2.LARASyncServerRequest(**larasyncserver.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating larasyncserver_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a larasyncserver by larasyncserver_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.larasyncserver_client.Destroy(lara_django_base_pb2.LARASyncServerDestroyRequest(larasyncserver_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting larasyncserver_id: {e}")
