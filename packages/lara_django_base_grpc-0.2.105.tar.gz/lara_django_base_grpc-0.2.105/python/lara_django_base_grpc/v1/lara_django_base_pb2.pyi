from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AddressDestroyRequest(_message.Message):
    __slots__ = ("address_id",)
    ADDRESS_ID_FIELD_NUMBER: _ClassVar[int]
    address_id: str
    def __init__(self, address_id: _Optional[str] = ...) -> None: ...

class AddressListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class AddressListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[AddressResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[AddressResponse, _Mapping]]] = ...) -> None: ...

class AddressPartialUpdateRequest(_message.Message):
    __slots__ = ("address_id", "namespace", "city", "subdivision", "country", "geolocation", "data_extra", "_partial_update_fields", "iri", "building", "street", "house_number", "supplement", "postal_code", "datetime_last_modified", "description", "search_vector")
    ADDRESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CITY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    BUILDING_FIELD_NUMBER: _ClassVar[int]
    STREET_FIELD_NUMBER: _ClassVar[int]
    HOUSE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    SUPPLEMENT_FIELD_NUMBER: _ClassVar[int]
    POSTAL_CODE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    address_id: str
    namespace: str
    city: str
    subdivision: str
    country: str
    geolocation: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    building: str
    street: str
    house_number: str
    supplement: str
    postal_code: str
    datetime_last_modified: str
    description: str
    search_vector: str
    def __init__(self, address_id: _Optional[str] = ..., namespace: _Optional[str] = ..., city: _Optional[str] = ..., subdivision: _Optional[str] = ..., country: _Optional[str] = ..., geolocation: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., building: _Optional[str] = ..., street: _Optional[str] = ..., house_number: _Optional[str] = ..., supplement: _Optional[str] = ..., postal_code: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class AddressRequest(_message.Message):
    __slots__ = ("address_id", "namespace", "city", "subdivision", "country", "geolocation", "data_extra", "iri", "building", "street", "house_number", "supplement", "postal_code", "datetime_last_modified", "description", "search_vector")
    ADDRESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CITY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    BUILDING_FIELD_NUMBER: _ClassVar[int]
    STREET_FIELD_NUMBER: _ClassVar[int]
    HOUSE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    SUPPLEMENT_FIELD_NUMBER: _ClassVar[int]
    POSTAL_CODE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    address_id: str
    namespace: str
    city: str
    subdivision: str
    country: str
    geolocation: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    building: str
    street: str
    house_number: str
    supplement: str
    postal_code: str
    datetime_last_modified: str
    description: str
    search_vector: str
    def __init__(self, address_id: _Optional[str] = ..., namespace: _Optional[str] = ..., city: _Optional[str] = ..., subdivision: _Optional[str] = ..., country: _Optional[str] = ..., geolocation: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., building: _Optional[str] = ..., street: _Optional[str] = ..., house_number: _Optional[str] = ..., supplement: _Optional[str] = ..., postal_code: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class AddressResponse(_message.Message):
    __slots__ = ("address_id", "namespace", "city", "subdivision", "country", "geolocation", "data_extra", "iri", "building", "street", "house_number", "supplement", "postal_code", "datetime_last_modified", "description", "search_vector")
    ADDRESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CITY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    BUILDING_FIELD_NUMBER: _ClassVar[int]
    STREET_FIELD_NUMBER: _ClassVar[int]
    HOUSE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    SUPPLEMENT_FIELD_NUMBER: _ClassVar[int]
    POSTAL_CODE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    address_id: str
    namespace: str
    city: str
    subdivision: str
    country: str
    geolocation: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    building: str
    street: str
    house_number: str
    supplement: str
    postal_code: str
    datetime_last_modified: str
    description: str
    search_vector: str
    def __init__(self, address_id: _Optional[str] = ..., namespace: _Optional[str] = ..., city: _Optional[str] = ..., subdivision: _Optional[str] = ..., country: _Optional[str] = ..., geolocation: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., building: _Optional[str] = ..., street: _Optional[str] = ..., house_number: _Optional[str] = ..., supplement: _Optional[str] = ..., postal_code: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class AddressRetrieveRequest(_message.Message):
    __slots__ = ("address_id",)
    ADDRESS_ID_FIELD_NUMBER: _ClassVar[int]
    address_id: str
    def __init__(self, address_id: _Optional[str] = ...) -> None: ...

class AddressStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CityDestroyRequest(_message.Message):
    __slots__ = ("city_id",)
    CITY_ID_FIELD_NUMBER: _ClassVar[int]
    city_id: str
    def __init__(self, city_id: _Optional[str] = ...) -> None: ...

class CityListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CityListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[CityResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[CityResponse, _Mapping]]] = ...) -> None: ...

class CityPartialUpdateRequest(_message.Message):
    __slots__ = ("city_id", "country", "subdivision", "_partial_update_fields", "name", "name_local", "timezone", "iri", "description", "search_vector")
    CITY_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    city_id: str
    country: str
    subdivision: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_local: str
    timezone: int
    iri: str
    description: str
    search_vector: str
    def __init__(self, city_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class CityRequest(_message.Message):
    __slots__ = ("city_id", "country", "subdivision", "name", "name_local", "timezone", "iri", "description", "search_vector")
    CITY_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    city_id: str
    country: str
    subdivision: str
    name: str
    name_local: str
    timezone: int
    iri: str
    description: str
    search_vector: str
    def __init__(self, city_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class CityResponse(_message.Message):
    __slots__ = ("city_id", "country", "subdivision", "name", "name_local", "timezone", "iri", "description", "search_vector")
    CITY_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    city_id: str
    country: str
    subdivision: str
    name: str
    name_local: str
    timezone: int
    iri: str
    description: str
    search_vector: str
    def __init__(self, city_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class CityRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class CityRetrieveRequest(_message.Message):
    __slots__ = ("city_id",)
    CITY_ID_FIELD_NUMBER: _ClassVar[int]
    city_id: str
    def __init__(self, city_id: _Optional[str] = ...) -> None: ...

class CityStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CountryDestroyRequest(_message.Message):
    __slots__ = ("country_id",)
    COUNTRY_ID_FIELD_NUMBER: _ClassVar[int]
    country_id: str
    def __init__(self, country_id: _Optional[str] = ...) -> None: ...

class CountryListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CountryListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[CountryResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[CountryResponse, _Mapping]]] = ...) -> None: ...

class CountryPartialUpdateRequest(_message.Message):
    __slots__ = ("country_id", "currency", "_partial_update_fields", "name", "name_local", "alpha2code", "alpha3code", "numeric_code", "phone_code", "icon", "iri", "timezone", "description")
    COUNTRY_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    PHONE_CODE_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    country_id: str
    currency: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_local: str
    alpha2code: str
    alpha3code: str
    numeric_code: int
    phone_code: int
    icon: str
    iri: str
    timezone: int
    description: str
    def __init__(self, country_id: _Optional[str] = ..., currency: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., alpha2code: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., phone_code: _Optional[int] = ..., icon: _Optional[str] = ..., iri: _Optional[str] = ..., timezone: _Optional[int] = ..., description: _Optional[str] = ...) -> None: ...

class CountryRequest(_message.Message):
    __slots__ = ("country_id", "currency", "name", "name_local", "alpha2code", "alpha3code", "numeric_code", "phone_code", "icon", "iri", "timezone", "description")
    COUNTRY_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    PHONE_CODE_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    country_id: str
    currency: str
    name: str
    name_local: str
    alpha2code: str
    alpha3code: str
    numeric_code: int
    phone_code: int
    icon: str
    iri: str
    timezone: int
    description: str
    def __init__(self, country_id: _Optional[str] = ..., currency: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., alpha2code: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., phone_code: _Optional[int] = ..., icon: _Optional[str] = ..., iri: _Optional[str] = ..., timezone: _Optional[int] = ..., description: _Optional[str] = ...) -> None: ...

class CountryResponse(_message.Message):
    __slots__ = ("country_id", "currency", "name", "name_local", "alpha2code", "alpha3code", "numeric_code", "phone_code", "icon", "iri", "timezone", "description")
    COUNTRY_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    PHONE_CODE_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    country_id: str
    currency: str
    name: str
    name_local: str
    alpha2code: str
    alpha3code: str
    numeric_code: int
    phone_code: int
    icon: str
    iri: str
    timezone: int
    description: str
    def __init__(self, country_id: _Optional[str] = ..., currency: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., alpha2code: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., phone_code: _Optional[int] = ..., icon: _Optional[str] = ..., iri: _Optional[str] = ..., timezone: _Optional[int] = ..., description: _Optional[str] = ...) -> None: ...

class CountryRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class CountryRetrieveRequest(_message.Message):
    __slots__ = ("country_id",)
    COUNTRY_ID_FIELD_NUMBER: _ClassVar[int]
    country_id: str
    def __init__(self, country_id: _Optional[str] = ...) -> None: ...

class CountryStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CountrySubdivisionDestroyRequest(_message.Message):
    __slots__ = ("countrysubdivision_id",)
    COUNTRYSUBDIVISION_ID_FIELD_NUMBER: _ClassVar[int]
    countrysubdivision_id: str
    def __init__(self, countrysubdivision_id: _Optional[str] = ...) -> None: ...

class CountrySubdivisionListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CountrySubdivisionListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[CountrySubdivisionResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[CountrySubdivisionResponse, _Mapping]]] = ...) -> None: ...

class CountrySubdivisionPartialUpdateRequest(_message.Message):
    __slots__ = ("countrysubdivision_id", "country", "subdivision_type", "_partial_update_fields", "name", "name_local", "code", "alpha2code", "timezone", "iri", "description")
    COUNTRYSUBDIVISION_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    countrysubdivision_id: str
    country: str
    subdivision_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_local: str
    code: str
    alpha2code: str
    timezone: int
    iri: str
    description: str
    def __init__(self, countrysubdivision_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., code: _Optional[str] = ..., alpha2code: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CountrySubdivisionRequest(_message.Message):
    __slots__ = ("countrysubdivision_id", "country", "subdivision_type", "name", "name_local", "code", "alpha2code", "timezone", "iri", "description")
    COUNTRYSUBDIVISION_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    countrysubdivision_id: str
    country: str
    subdivision_type: str
    name: str
    name_local: str
    code: str
    alpha2code: str
    timezone: int
    iri: str
    description: str
    def __init__(self, countrysubdivision_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision_type: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., code: _Optional[str] = ..., alpha2code: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CountrySubdivisionResponse(_message.Message):
    __slots__ = ("countrysubdivision_id", "country", "subdivision_type", "name", "name_local", "code", "alpha2code", "timezone", "iri", "description")
    COUNTRYSUBDIVISION_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTRY_FIELD_NUMBER: _ClassVar[int]
    SUBDIVISION_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_LOCAL_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    ALPHA2CODE_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    countrysubdivision_id: str
    country: str
    subdivision_type: str
    name: str
    name_local: str
    code: str
    alpha2code: str
    timezone: int
    iri: str
    description: str
    def __init__(self, countrysubdivision_id: _Optional[str] = ..., country: _Optional[str] = ..., subdivision_type: _Optional[str] = ..., name: _Optional[str] = ..., name_local: _Optional[str] = ..., code: _Optional[str] = ..., alpha2code: _Optional[str] = ..., timezone: _Optional[int] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CountrySubdivisionRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class CountrySubdivisionRetrieveRequest(_message.Message):
    __slots__ = ("countrysubdivision_id",)
    COUNTRYSUBDIVISION_ID_FIELD_NUMBER: _ClassVar[int]
    countrysubdivision_id: str
    def __init__(self, countrysubdivision_id: _Optional[str] = ...) -> None: ...

class CountrySubdivisionStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CurrencyDestroyRequest(_message.Message):
    __slots__ = ("currency_id",)
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    def __init__(self, currency_id: _Optional[str] = ...) -> None: ...

class CurrencyListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class CurrencyListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[CurrencyResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[CurrencyResponse, _Mapping]]] = ...) -> None: ...

class CurrencyPartialUpdateRequest(_message.Message):
    __slots__ = ("currency_id", "_partial_update_fields", "name", "iri", "alpha3code", "numeric_code", "symbol", "exchange_rate_eur", "datetime_last_modified", "description")
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_RATE_EUR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    alpha3code: str
    numeric_code: int
    symbol: str
    exchange_rate_eur: float
    datetime_last_modified: str
    description: str
    def __init__(self, currency_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., symbol: _Optional[str] = ..., exchange_rate_eur: _Optional[float] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CurrencyRequest(_message.Message):
    __slots__ = ("currency_id", "name", "iri", "alpha3code", "numeric_code", "symbol", "exchange_rate_eur", "datetime_last_modified", "description")
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_RATE_EUR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    name: str
    iri: str
    alpha3code: str
    numeric_code: int
    symbol: str
    exchange_rate_eur: float
    datetime_last_modified: str
    description: str
    def __init__(self, currency_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., symbol: _Optional[str] = ..., exchange_rate_eur: _Optional[float] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CurrencyResponse(_message.Message):
    __slots__ = ("currency_id", "name", "iri", "alpha3code", "numeric_code", "symbol", "exchange_rate_eur", "datetime_last_modified", "description")
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ALPHA3CODE_FIELD_NUMBER: _ClassVar[int]
    NUMERIC_CODE_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    EXCHANGE_RATE_EUR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    name: str
    iri: str
    alpha3code: str
    numeric_code: int
    symbol: str
    exchange_rate_eur: float
    datetime_last_modified: str
    description: str
    def __init__(self, currency_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., alpha3code: _Optional[str] = ..., numeric_code: _Optional[int] = ..., symbol: _Optional[str] = ..., exchange_rate_eur: _Optional[float] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class CurrencyRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class CurrencyRetrieveRequest(_message.Message):
    __slots__ = ("currency_id",)
    CURRENCY_ID_FIELD_NUMBER: _ClassVar[int]
    currency_id: str
    def __init__(self, currency_id: _Optional[str] = ...) -> None: ...

class CurrencyStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataTypeDestroyRequest(_message.Message):
    __slots__ = ("datatype_id",)
    DATATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    datatype_id: str
    def __init__(self, datatype_id: _Optional[str] = ...) -> None: ...

class DataTypeListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataTypeListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[DataTypeResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[DataTypeResponse, _Mapping]]] = ...) -> None: ...

class DataTypePartialUpdateRequest(_message.Message):
    __slots__ = ("datatype_id", "media_type", "_partial_update_fields", "name", "iri", "description")
    DATATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    datatype_id: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, datatype_id: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class DataTypeRequest(_message.Message):
    __slots__ = ("datatype_id", "media_type", "name", "iri", "description")
    DATATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    datatype_id: str
    media_type: str
    name: str
    iri: str
    description: str
    def __init__(self, datatype_id: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class DataTypeResponse(_message.Message):
    __slots__ = ("datatype_id", "media_type", "name", "iri", "description")
    DATATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    datatype_id: str
    media_type: str
    name: str
    iri: str
    description: str
    def __init__(self, datatype_id: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class DataTypeRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class DataTypeRetrieveRequest(_message.Message):
    __slots__ = ("datatype_id",)
    DATATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    datatype_id: str
    def __init__(self, datatype_id: _Optional[str] = ...) -> None: ...

class DataTypeStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExternalResourceDestroyRequest(_message.Message):
    __slots__ = ("externalresource_id",)
    EXTERNALRESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    externalresource_id: str
    def __init__(self, externalresource_id: _Optional[str] = ...) -> None: ...

class ExternalResourceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExternalResourceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExternalResourceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExternalResourceResponse, _Mapping]]] = ...) -> None: ...

class ExternalResourcePartialUpdateRequest(_message.Message):
    __slots__ = ("externalresource_id", "namespace", "resource_type", "tags", "_partial_update_fields", "name_display", "name", "url", "iri", "prefix", "description", "datetime_last_modified", "search_vector")
    EXTERNALRESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_TYPE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    externalresource_id: str
    namespace: str
    resource_type: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    url: str
    iri: str
    prefix: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, externalresource_id: _Optional[str] = ..., namespace: _Optional[str] = ..., resource_type: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., iri: _Optional[str] = ..., prefix: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExternalResourceRequest(_message.Message):
    __slots__ = ("externalresource_id", "namespace", "resource_type", "tags", "name_display", "name", "url", "iri", "prefix", "description", "datetime_last_modified", "search_vector")
    EXTERNALRESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_TYPE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    externalresource_id: str
    namespace: str
    resource_type: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    url: str
    iri: str
    prefix: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, externalresource_id: _Optional[str] = ..., namespace: _Optional[str] = ..., resource_type: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., iri: _Optional[str] = ..., prefix: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExternalResourceResponse(_message.Message):
    __slots__ = ("externalresource_id", "namespace", "resource_type", "tags", "name_display", "name", "url", "iri", "prefix", "description", "datetime_last_modified", "search_vector")
    EXTERNALRESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_TYPE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PREFIX_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    externalresource_id: str
    namespace: str
    resource_type: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    url: str
    iri: str
    prefix: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, externalresource_id: _Optional[str] = ..., namespace: _Optional[str] = ..., resource_type: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., iri: _Optional[str] = ..., prefix: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExternalResourceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExternalResourceRetrieveRequest(_message.Message):
    __slots__ = ("externalresource_id",)
    EXTERNALRESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    externalresource_id: str
    def __init__(self, externalresource_id: _Optional[str] = ...) -> None: ...

class ExternalResourceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "namespace", "data_type", "media_type", "_partial_update_fields", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    namespace: str
    data_type: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    def __init__(self, extradata_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "namespace", "data_type", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    namespace: str
    data_type: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    def __init__(self, extradata_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "namespace", "data_type", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "file", "image")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    namespace: str
    data_type: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    file: str
    image: str
    def __init__(self, extradata_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class GeoLocationDestroyRequest(_message.Message):
    __slots__ = ("geolocation_id",)
    GEOLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    geolocation_id: str
    def __init__(self, geolocation_id: _Optional[str] = ...) -> None: ...

class GeoLocationListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GeoLocationListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[GeoLocationResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[GeoLocationResponse, _Mapping]]] = ...) -> None: ...

class GeoLocationPartialUpdateRequest(_message.Message):
    __slots__ = ("geolocation_id", "data_extra", "_partial_update_fields", "name", "iri", "coordinates_dd_lat", "coordinates_dd_long", "elevation", "openstreetmap", "googlemap", "datetime_last_modified", "description")
    GEOLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LAT_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LONG_FIELD_NUMBER: _ClassVar[int]
    ELEVATION_FIELD_NUMBER: _ClassVar[int]
    OPENSTREETMAP_FIELD_NUMBER: _ClassVar[int]
    GOOGLEMAP_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    geolocation_id: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    coordinates_dd_lat: float
    coordinates_dd_long: float
    elevation: int
    openstreetmap: str
    googlemap: str
    datetime_last_modified: str
    description: str
    def __init__(self, geolocation_id: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., coordinates_dd_lat: _Optional[float] = ..., coordinates_dd_long: _Optional[float] = ..., elevation: _Optional[int] = ..., openstreetmap: _Optional[str] = ..., googlemap: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class GeoLocationRequest(_message.Message):
    __slots__ = ("geolocation_id", "data_extra", "name", "iri", "coordinates_dd_lat", "coordinates_dd_long", "elevation", "openstreetmap", "googlemap", "datetime_last_modified", "description")
    GEOLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LAT_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LONG_FIELD_NUMBER: _ClassVar[int]
    ELEVATION_FIELD_NUMBER: _ClassVar[int]
    OPENSTREETMAP_FIELD_NUMBER: _ClassVar[int]
    GOOGLEMAP_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    geolocation_id: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    coordinates_dd_lat: float
    coordinates_dd_long: float
    elevation: int
    openstreetmap: str
    googlemap: str
    datetime_last_modified: str
    description: str
    def __init__(self, geolocation_id: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., coordinates_dd_lat: _Optional[float] = ..., coordinates_dd_long: _Optional[float] = ..., elevation: _Optional[int] = ..., openstreetmap: _Optional[str] = ..., googlemap: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class GeoLocationResponse(_message.Message):
    __slots__ = ("geolocation_id", "data_extra", "name", "iri", "coordinates_dd_lat", "coordinates_dd_long", "elevation", "openstreetmap", "googlemap", "datetime_last_modified", "description")
    GEOLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LAT_FIELD_NUMBER: _ClassVar[int]
    COORDINATES_DD_LONG_FIELD_NUMBER: _ClassVar[int]
    ELEVATION_FIELD_NUMBER: _ClassVar[int]
    OPENSTREETMAP_FIELD_NUMBER: _ClassVar[int]
    GOOGLEMAP_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    geolocation_id: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    coordinates_dd_lat: float
    coordinates_dd_long: float
    elevation: int
    openstreetmap: str
    googlemap: str
    datetime_last_modified: str
    description: str
    def __init__(self, geolocation_id: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., coordinates_dd_lat: _Optional[float] = ..., coordinates_dd_long: _Optional[float] = ..., elevation: _Optional[int] = ..., openstreetmap: _Optional[str] = ..., googlemap: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class GeoLocationRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class GeoLocationRetrieveRequest(_message.Message):
    __slots__ = ("geolocation_id",)
    GEOLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    geolocation_id: str
    def __init__(self, geolocation_id: _Optional[str] = ...) -> None: ...

class GeoLocationStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ItemStatusDestroyRequest(_message.Message):
    __slots__ = ("itemstatus_id",)
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    def __init__(self, itemstatus_id: _Optional[str] = ...) -> None: ...

class ItemStatusListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ItemStatusListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ItemStatusResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ItemStatusResponse, _Mapping]]] = ...) -> None: ...

class ItemStatusPartialUpdateRequest(_message.Message):
    __slots__ = ("itemstatus_id", "tags", "_partial_update_fields", "status", "iri", "color", "value", "description")
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    status: str
    iri: str
    color: str
    value: float
    description: str
    def __init__(self, itemstatus_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., iri: _Optional[str] = ..., color: _Optional[str] = ..., value: _Optional[float] = ..., description: _Optional[str] = ...) -> None: ...

class ItemStatusRequest(_message.Message):
    __slots__ = ("itemstatus_id", "tags", "status", "iri", "color", "value", "description")
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    status: str
    iri: str
    color: str
    value: float
    description: str
    def __init__(self, itemstatus_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., iri: _Optional[str] = ..., color: _Optional[str] = ..., value: _Optional[float] = ..., description: _Optional[str] = ...) -> None: ...

class ItemStatusResponse(_message.Message):
    __slots__ = ("itemstatus_id", "tags", "status", "iri", "color", "value", "description")
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    status: str
    iri: str
    color: str
    value: float
    description: str
    def __init__(self, itemstatus_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., iri: _Optional[str] = ..., color: _Optional[str] = ..., value: _Optional[float] = ..., description: _Optional[str] = ...) -> None: ...

class ItemStatusRetrieveRequest(_message.Message):
    __slots__ = ("itemstatus_id",)
    ITEMSTATUS_ID_FIELD_NUMBER: _ClassVar[int]
    itemstatus_id: str
    def __init__(self, itemstatus_id: _Optional[str] = ...) -> None: ...

class ItemStatusStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LARASyncServerDestroyRequest(_message.Message):
    __slots__ = ("laraserver_id",)
    LARASERVER_ID_FIELD_NUMBER: _ClassVar[int]
    laraserver_id: str
    def __init__(self, laraserver_id: _Optional[str] = ...) -> None: ...

class LARASyncServerListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LARASyncServerListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[LARASyncServerResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[LARASyncServerResponse, _Mapping]]] = ...) -> None: ...

class LARASyncServerPartialUpdateRequest(_message.Message):
    __slots__ = ("laraserver_id", "tags", "_partial_update_fields", "name", "url", "port", "server_type", "connection_json", "auth_json", "cert_pub", "description")
    LARASERVER_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_JSON_FIELD_NUMBER: _ClassVar[int]
    AUTH_JSON_FIELD_NUMBER: _ClassVar[int]
    CERT_PUB_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    laraserver_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    url: str
    port: int
    server_type: str
    connection_json: _struct_pb2.Struct
    auth_json: _struct_pb2.Struct
    cert_pub: str
    description: str
    def __init__(self, laraserver_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., port: _Optional[int] = ..., server_type: _Optional[str] = ..., connection_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., auth_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cert_pub: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class LARASyncServerRequest(_message.Message):
    __slots__ = ("laraserver_id", "tags", "name", "url", "port", "server_type", "connection_json", "auth_json", "cert_pub", "description")
    LARASERVER_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_JSON_FIELD_NUMBER: _ClassVar[int]
    AUTH_JSON_FIELD_NUMBER: _ClassVar[int]
    CERT_PUB_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    laraserver_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    url: str
    port: int
    server_type: str
    connection_json: _struct_pb2.Struct
    auth_json: _struct_pb2.Struct
    cert_pub: str
    description: str
    def __init__(self, laraserver_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., port: _Optional[int] = ..., server_type: _Optional[str] = ..., connection_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., auth_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cert_pub: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class LARASyncServerResponse(_message.Message):
    __slots__ = ("laraserver_id", "tags", "name", "url", "port", "server_type", "connection_json", "auth_json", "cert_pub", "description")
    LARASERVER_ID_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    SERVER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_JSON_FIELD_NUMBER: _ClassVar[int]
    AUTH_JSON_FIELD_NUMBER: _ClassVar[int]
    CERT_PUB_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    laraserver_id: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    url: str
    port: int
    server_type: str
    connection_json: _struct_pb2.Struct
    auth_json: _struct_pb2.Struct
    cert_pub: str
    description: str
    def __init__(self, laraserver_id: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., url: _Optional[str] = ..., port: _Optional[int] = ..., server_type: _Optional[str] = ..., connection_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., auth_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., cert_pub: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class LARASyncServerRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class LARASyncServerRetrieveRequest(_message.Message):
    __slots__ = ("laraserver_id",)
    LARASERVER_ID_FIELD_NUMBER: _ClassVar[int]
    laraserver_id: str
    def __init__(self, laraserver_id: _Optional[str] = ...) -> None: ...

class LARASyncServerStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LocationDestroyRequest(_message.Message):
    __slots__ = ("location_id",)
    LOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    location_id: str
    def __init__(self, location_id: _Optional[str] = ...) -> None: ...

class LocationListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class LocationListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[LocationResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[LocationResponse, _Mapping]]] = ...) -> None: ...

class LocationPartialUpdateRequest(_message.Message):
    __slots__ = ("location_id", "namespace", "geolocation", "address", "room", "data_extra", "_partial_update_fields", "name", "barcode", "barcode_json", "location_json", "iri", "url", "datetime_last_modified", "description", "search_vector", "location_type", "parent")
    LOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ROOM_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    LOCATION_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LOCATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    location_id: str
    namespace: str
    geolocation: str
    address: str
    room: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    location_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_last_modified: str
    description: str
    search_vector: str
    location_type: str
    parent: str
    def __init__(self, location_id: _Optional[str] = ..., namespace: _Optional[str] = ..., geolocation: _Optional[str] = ..., address: _Optional[str] = ..., room: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., location_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., location_type: _Optional[str] = ..., parent: _Optional[str] = ...) -> None: ...

class LocationRequest(_message.Message):
    __slots__ = ("location_id", "namespace", "geolocation", "address", "room", "data_extra", "name", "barcode", "barcode_json", "location_json", "iri", "url", "datetime_last_modified", "description", "search_vector", "location_type", "parent")
    LOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ROOM_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    LOCATION_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LOCATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    location_id: str
    namespace: str
    geolocation: str
    address: str
    room: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    location_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_last_modified: str
    description: str
    search_vector: str
    location_type: str
    parent: str
    def __init__(self, location_id: _Optional[str] = ..., namespace: _Optional[str] = ..., geolocation: _Optional[str] = ..., address: _Optional[str] = ..., room: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., location_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., location_type: _Optional[str] = ..., parent: _Optional[str] = ...) -> None: ...

class LocationResponse(_message.Message):
    __slots__ = ("location_id", "namespace", "geolocation", "address", "room", "data_extra", "name", "barcode", "barcode_json", "location_json", "iri", "url", "datetime_last_modified", "description", "search_vector", "lft", "rght", "tree_id", "level", "location_type", "parent")
    LOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GEOLOCATION_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ROOM_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    LOCATION_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    LFT_FIELD_NUMBER: _ClassVar[int]
    RGHT_FIELD_NUMBER: _ClassVar[int]
    TREE_ID_FIELD_NUMBER: _ClassVar[int]
    LEVEL_FIELD_NUMBER: _ClassVar[int]
    LOCATION_TYPE_FIELD_NUMBER: _ClassVar[int]
    PARENT_FIELD_NUMBER: _ClassVar[int]
    location_id: str
    namespace: str
    geolocation: str
    address: str
    room: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    location_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_last_modified: str
    description: str
    search_vector: str
    lft: int
    rght: int
    tree_id: int
    level: int
    location_type: str
    parent: str
    def __init__(self, location_id: _Optional[str] = ..., namespace: _Optional[str] = ..., geolocation: _Optional[str] = ..., address: _Optional[str] = ..., room: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., location_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., lft: _Optional[int] = ..., rght: _Optional[int] = ..., tree_id: _Optional[int] = ..., level: _Optional[int] = ..., location_type: _Optional[str] = ..., parent: _Optional[str] = ...) -> None: ...

class LocationRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class LocationRetrieveRequest(_message.Message):
    __slots__ = ("location_id",)
    LOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    location_id: str
    def __init__(self, location_id: _Optional[str] = ...) -> None: ...

class LocationStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MediaTypeDestroyRequest(_message.Message):
    __slots__ = ("mediatype_id",)
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    def __init__(self, mediatype_id: _Optional[str] = ...) -> None: ...

class MediaTypeListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MediaTypeListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MediaTypeResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MediaTypeResponse, _Mapping]]] = ...) -> None: ...

class MediaTypePartialUpdateRequest(_message.Message):
    __slots__ = ("mediatype_id", "_partial_update_fields", "name", "media_type", "def_filename_extension_regex", "iri", "description")
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    DEF_FILENAME_EXTENSION_REGEX_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    media_type: str
    def_filename_extension_regex: str
    iri: str
    description: str
    def __init__(self, mediatype_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., media_type: _Optional[str] = ..., def_filename_extension_regex: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MediaTypeRequest(_message.Message):
    __slots__ = ("mediatype_id", "name", "media_type", "def_filename_extension_regex", "iri", "description")
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    DEF_FILENAME_EXTENSION_REGEX_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    name: str
    media_type: str
    def_filename_extension_regex: str
    iri: str
    description: str
    def __init__(self, mediatype_id: _Optional[str] = ..., name: _Optional[str] = ..., media_type: _Optional[str] = ..., def_filename_extension_regex: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MediaTypeResponse(_message.Message):
    __slots__ = ("mediatype_id", "name", "media_type", "def_filename_extension_regex", "iri", "description")
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    DEF_FILENAME_EXTENSION_REGEX_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    name: str
    media_type: str
    def_filename_extension_regex: str
    iri: str
    description: str
    def __init__(self, mediatype_id: _Optional[str] = ..., name: _Optional[str] = ..., media_type: _Optional[str] = ..., def_filename_extension_regex: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MediaTypeRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MediaTypeRetrieveRequest(_message.Message):
    __slots__ = ("mediatype_id",)
    MEDIATYPE_ID_FIELD_NUMBER: _ClassVar[int]
    mediatype_id: str
    def __init__(self, mediatype_id: _Optional[str] = ...) -> None: ...

class MediaTypeStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class NamespaceByURIListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class NamespaceByURIListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[NamespaceByURIResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[NamespaceByURIResponse, _Mapping]]] = ...) -> None: ...

class NamespaceByURIResponse(_message.Message):
    __slots__ = ("namespace_id", "uri", "description")
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    uri: str
    description: str
    def __init__(self, namespace_id: _Optional[str] = ..., uri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class NamespaceByURIRetrieveRequest(_message.Message):
    __slots__ = ("uri",)
    URI_FIELD_NUMBER: _ClassVar[int]
    uri: str
    def __init__(self, uri: _Optional[str] = ...) -> None: ...

class NamespaceDestroyRequest(_message.Message):
    __slots__ = ("namespace_id",)
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    def __init__(self, namespace_id: _Optional[str] = ...) -> None: ...

class NamespaceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class NamespaceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[NamespaceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[NamespaceResponse, _Mapping]]] = ...) -> None: ...

class NamespacePartialUpdateRequest(_message.Message):
    __slots__ = ("namespace_id", "_partial_update_fields", "uri", "description")
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    uri: str
    description: str
    def __init__(self, namespace_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., uri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class NamespaceRequest(_message.Message):
    __slots__ = ("namespace_id", "uri", "description")
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    uri: str
    description: str
    def __init__(self, namespace_id: _Optional[str] = ..., uri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class NamespaceResponse(_message.Message):
    __slots__ = ("namespace_id", "uri", "description")
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    uri: str
    description: str
    def __init__(self, namespace_id: _Optional[str] = ..., uri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class NamespaceRetrieveRequest(_message.Message):
    __slots__ = ("namespace_id",)
    NAMESPACE_ID_FIELD_NUMBER: _ClassVar[int]
    namespace_id: str
    def __init__(self, namespace_id: _Optional[str] = ...) -> None: ...

class NamespaceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhysicalStateMatterDestroyRequest(_message.Message):
    __slots__ = ("physicalstatematter_id",)
    PHYSICALSTATEMATTER_ID_FIELD_NUMBER: _ClassVar[int]
    physicalstatematter_id: str
    def __init__(self, physicalstatematter_id: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhysicalStateMatterListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PhysicalStateMatterResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PhysicalStateMatterResponse, _Mapping]]] = ...) -> None: ...

class PhysicalStateMatterPartialUpdateRequest(_message.Message):
    __slots__ = ("physicalstatematter_id", "_partial_update_fields", "name", "iri", "description")
    PHYSICALSTATEMATTER_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalstatematter_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, physicalstatematter_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterRequest(_message.Message):
    __slots__ = ("physicalstatematter_id", "name", "iri", "description")
    PHYSICALSTATEMATTER_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalstatematter_id: str
    name: str
    iri: str
    description: str
    def __init__(self, physicalstatematter_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterResponse(_message.Message):
    __slots__ = ("physicalstatematter_id", "name", "iri", "description")
    PHYSICALSTATEMATTER_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalstatematter_id: str
    name: str
    iri: str
    description: str
    def __init__(self, physicalstatematter_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterRetrieveRequest(_message.Message):
    __slots__ = ("physicalstatematter_id",)
    PHYSICALSTATEMATTER_ID_FIELD_NUMBER: _ClassVar[int]
    physicalstatematter_id: str
    def __init__(self, physicalstatematter_id: _Optional[str] = ...) -> None: ...

class PhysicalStateMatterStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhysicalUnitDestroyRequest(_message.Message):
    __slots__ = ("physicalunit_id",)
    PHYSICALUNIT_ID_FIELD_NUMBER: _ClassVar[int]
    physicalunit_id: str
    def __init__(self, physicalunit_id: _Optional[str] = ...) -> None: ...

class PhysicalUnitListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PhysicalUnitListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PhysicalUnitResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PhysicalUnitResponse, _Mapping]]] = ...) -> None: ...

class PhysicalUnitPartialUpdateRequest(_message.Message):
    __slots__ = ("physicalunit_id", "_partial_update_fields", "name", "symbol", "dimension", "transformation_si", "iri", "description")
    PHYSICALUNIT_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    TRANSFORMATION_SI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalunit_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    symbol: str
    dimension: str
    transformation_si: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, physicalunit_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., dimension: _Optional[str] = ..., transformation_si: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalUnitRequest(_message.Message):
    __slots__ = ("physicalunit_id", "name", "symbol", "dimension", "transformation_si", "iri", "description")
    PHYSICALUNIT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    TRANSFORMATION_SI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalunit_id: str
    name: str
    symbol: str
    dimension: str
    transformation_si: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, physicalunit_id: _Optional[str] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., dimension: _Optional[str] = ..., transformation_si: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalUnitResponse(_message.Message):
    __slots__ = ("physicalunit_id", "name", "symbol", "dimension", "transformation_si", "iri", "description")
    PHYSICALUNIT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    DIMENSION_FIELD_NUMBER: _ClassVar[int]
    TRANSFORMATION_SI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    physicalunit_id: str
    name: str
    symbol: str
    dimension: str
    transformation_si: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, physicalunit_id: _Optional[str] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., dimension: _Optional[str] = ..., transformation_si: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class PhysicalUnitRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class PhysicalUnitRetrieveRequest(_message.Message):
    __slots__ = ("physicalunit_id",)
    PHYSICALUNIT_ID_FIELD_NUMBER: _ClassVar[int]
    physicalunit_id: str
    def __init__(self, physicalunit_id: _Optional[str] = ...) -> None: ...

class PhysicalUnitStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RoomCategoryDestroyRequest(_message.Message):
    __slots__ = ("roomcategory_id",)
    ROOMCATEGORY_ID_FIELD_NUMBER: _ClassVar[int]
    roomcategory_id: str
    def __init__(self, roomcategory_id: _Optional[str] = ...) -> None: ...

class RoomCategoryListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RoomCategoryListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[RoomCategoryResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[RoomCategoryResponse, _Mapping]]] = ...) -> None: ...

class RoomCategoryPartialUpdateRequest(_message.Message):
    __slots__ = ("roomcategory_id", "_partial_update_fields", "category", "iri", "description")
    ROOMCATEGORY_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    roomcategory_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    category: str
    iri: str
    description: str
    def __init__(self, roomcategory_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., category: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class RoomCategoryRequest(_message.Message):
    __slots__ = ("roomcategory_id", "category", "iri", "description")
    ROOMCATEGORY_ID_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    roomcategory_id: str
    category: str
    iri: str
    description: str
    def __init__(self, roomcategory_id: _Optional[str] = ..., category: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class RoomCategoryResponse(_message.Message):
    __slots__ = ("roomcategory_id", "category", "iri", "description")
    ROOMCATEGORY_ID_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    roomcategory_id: str
    category: str
    iri: str
    description: str
    def __init__(self, roomcategory_id: _Optional[str] = ..., category: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class RoomCategoryRetrieveRequest(_message.Message):
    __slots__ = ("roomcategory_id",)
    ROOMCATEGORY_ID_FIELD_NUMBER: _ClassVar[int]
    roomcategory_id: str
    def __init__(self, roomcategory_id: _Optional[str] = ...) -> None: ...

class RoomCategoryStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RoomDestroyRequest(_message.Message):
    __slots__ = ("room_id",)
    ROOM_ID_FIELD_NUMBER: _ClassVar[int]
    room_id: str
    def __init__(self, room_id: _Optional[str] = ...) -> None: ...

class RoomListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RoomListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[RoomResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[RoomResponse, _Mapping]]] = ...) -> None: ...

class RoomPartialUpdateRequest(_message.Message):
    __slots__ = ("room_id", "namespace", "category", "_partial_update_fields", "name", "number", "floor", "phone_number", "room_map", "max_people", "area", "volume", "features", "iri", "description", "datetime_last_modified", "search_vector", "data_extra")
    ROOM_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    FLOOR_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ROOM_MAP_FIELD_NUMBER: _ClassVar[int]
    MAX_PEOPLE_FIELD_NUMBER: _ClassVar[int]
    AREA_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    FEATURES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    room_id: str
    namespace: str
    category: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    number: str
    floor: str
    phone_number: str
    room_map: str
    max_people: int
    area: float
    volume: float
    features: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    search_vector: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, room_id: _Optional[str] = ..., namespace: _Optional[str] = ..., category: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., number: _Optional[str] = ..., floor: _Optional[str] = ..., phone_number: _Optional[str] = ..., room_map: _Optional[str] = ..., max_people: _Optional[int] = ..., area: _Optional[float] = ..., volume: _Optional[float] = ..., features: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ...) -> None: ...

class RoomRequest(_message.Message):
    __slots__ = ("room_id", "namespace", "category", "name", "number", "floor", "phone_number", "room_map", "max_people", "area", "volume", "features", "iri", "description", "datetime_last_modified", "search_vector", "data_extra")
    ROOM_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    FLOOR_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ROOM_MAP_FIELD_NUMBER: _ClassVar[int]
    MAX_PEOPLE_FIELD_NUMBER: _ClassVar[int]
    AREA_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    FEATURES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    room_id: str
    namespace: str
    category: str
    name: str
    number: str
    floor: str
    phone_number: str
    room_map: str
    max_people: int
    area: float
    volume: float
    features: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    search_vector: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, room_id: _Optional[str] = ..., namespace: _Optional[str] = ..., category: _Optional[str] = ..., name: _Optional[str] = ..., number: _Optional[str] = ..., floor: _Optional[str] = ..., phone_number: _Optional[str] = ..., room_map: _Optional[str] = ..., max_people: _Optional[int] = ..., area: _Optional[float] = ..., volume: _Optional[float] = ..., features: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ...) -> None: ...

class RoomResponse(_message.Message):
    __slots__ = ("room_id", "namespace", "category", "name", "number", "floor", "phone_number", "room_map", "max_people", "area", "volume", "features", "iri", "description", "datetime_last_modified", "search_vector", "data_extra")
    ROOM_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NUMBER_FIELD_NUMBER: _ClassVar[int]
    FLOOR_FIELD_NUMBER: _ClassVar[int]
    PHONE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ROOM_MAP_FIELD_NUMBER: _ClassVar[int]
    MAX_PEOPLE_FIELD_NUMBER: _ClassVar[int]
    AREA_FIELD_NUMBER: _ClassVar[int]
    VOLUME_FIELD_NUMBER: _ClassVar[int]
    FEATURES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    room_id: str
    namespace: str
    category: str
    name: str
    number: str
    floor: str
    phone_number: str
    room_map: str
    max_people: int
    area: float
    volume: float
    features: _struct_pb2.Struct
    iri: str
    description: str
    datetime_last_modified: str
    search_vector: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, room_id: _Optional[str] = ..., namespace: _Optional[str] = ..., category: _Optional[str] = ..., name: _Optional[str] = ..., number: _Optional[str] = ..., floor: _Optional[str] = ..., phone_number: _Optional[str] = ..., room_map: _Optional[str] = ..., max_people: _Optional[int] = ..., area: _Optional[float] = ..., volume: _Optional[float] = ..., features: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ...) -> None: ...

class RoomRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class RoomRetrieveRequest(_message.Message):
    __slots__ = ("room_id",)
    ROOM_ID_FIELD_NUMBER: _ClassVar[int]
    room_id: str
    def __init__(self, room_id: _Optional[str] = ...) -> None: ...

class RoomStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ScientificConstantDestroyRequest(_message.Message):
    __slots__ = ("scientificconstant_id",)
    SCIENTIFICCONSTANT_ID_FIELD_NUMBER: _ClassVar[int]
    scientificconstant_id: str
    def __init__(self, scientificconstant_id: _Optional[str] = ...) -> None: ...

class ScientificConstantListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ScientificConstantListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ScientificConstantResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ScientificConstantResponse, _Mapping]]] = ...) -> None: ...

class ScientificConstantPartialUpdateRequest(_message.Message):
    __slots__ = ("scientificconstant_id", "unit", "_partial_update_fields", "name", "symbol", "value", "uncertainty", "data_json", "iri", "url_source", "url_definition", "description", "datetime_last_modified", "search_vector")
    SCIENTIFICCONSTANT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    UNCERTAINTY_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_SOURCE_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    scientificconstant_id: str
    unit: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    symbol: str
    value: float
    uncertainty: float
    data_json: _struct_pb2.Struct
    iri: str
    url_source: str
    url_definition: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, scientificconstant_id: _Optional[str] = ..., unit: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., value: _Optional[float] = ..., uncertainty: _Optional[float] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url_source: _Optional[str] = ..., url_definition: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ScientificConstantRequest(_message.Message):
    __slots__ = ("scientificconstant_id", "unit", "name", "symbol", "value", "uncertainty", "data_json", "iri", "url_source", "url_definition", "description", "datetime_last_modified", "search_vector")
    SCIENTIFICCONSTANT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    UNCERTAINTY_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_SOURCE_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    scientificconstant_id: str
    unit: str
    name: str
    symbol: str
    value: float
    uncertainty: float
    data_json: _struct_pb2.Struct
    iri: str
    url_source: str
    url_definition: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, scientificconstant_id: _Optional[str] = ..., unit: _Optional[str] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., value: _Optional[float] = ..., uncertainty: _Optional[float] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url_source: _Optional[str] = ..., url_definition: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ScientificConstantResponse(_message.Message):
    __slots__ = ("scientificconstant_id", "unit", "name", "symbol", "value", "uncertainty", "data_json", "iri", "url_source", "url_definition", "description", "datetime_last_modified", "search_vector")
    SCIENTIFICCONSTANT_ID_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SYMBOL_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    UNCERTAINTY_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_SOURCE_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    scientificconstant_id: str
    unit: str
    name: str
    symbol: str
    value: float
    uncertainty: float
    data_json: _struct_pb2.Struct
    iri: str
    url_source: str
    url_definition: str
    description: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, scientificconstant_id: _Optional[str] = ..., unit: _Optional[str] = ..., name: _Optional[str] = ..., symbol: _Optional[str] = ..., value: _Optional[float] = ..., uncertainty: _Optional[float] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url_source: _Optional[str] = ..., url_definition: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ScientificConstantRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ScientificConstantRetrieveRequest(_message.Message):
    __slots__ = ("scientificconstant_id",)
    SCIENTIFICCONSTANT_ID_FIELD_NUMBER: _ClassVar[int]
    scientificconstant_id: str
    def __init__(self, scientificconstant_id: _Optional[str] = ...) -> None: ...

class ScientificConstantStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubdivisionTypeDestroyRequest(_message.Message):
    __slots__ = ("subdivisiontype_id",)
    SUBDIVISIONTYPE_ID_FIELD_NUMBER: _ClassVar[int]
    subdivisiontype_id: str
    def __init__(self, subdivisiontype_id: _Optional[str] = ...) -> None: ...

class SubdivisionTypeListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubdivisionTypeListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubdivisionTypeResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubdivisionTypeResponse, _Mapping]]] = ...) -> None: ...

class SubdivisionTypePartialUpdateRequest(_message.Message):
    __slots__ = ("subdivisiontype_id", "_partial_update_fields", "name", "iri", "description")
    SUBDIVISIONTYPE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    subdivisiontype_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, subdivisiontype_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubdivisionTypeRequest(_message.Message):
    __slots__ = ("subdivisiontype_id", "name", "iri", "description")
    SUBDIVISIONTYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    subdivisiontype_id: str
    name: str
    iri: str
    description: str
    def __init__(self, subdivisiontype_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubdivisionTypeResponse(_message.Message):
    __slots__ = ("subdivisiontype_id", "name", "iri", "description")
    SUBDIVISIONTYPE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    subdivisiontype_id: str
    name: str
    iri: str
    description: str
    def __init__(self, subdivisiontype_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubdivisionTypeRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class SubdivisionTypeRetrieveRequest(_message.Message):
    __slots__ = ("subdivisiontype_id",)
    SUBDIVISIONTYPE_ID_FIELD_NUMBER: _ClassVar[int]
    subdivisiontype_id: str
    def __init__(self, subdivisiontype_id: _Optional[str] = ...) -> None: ...

class SubdivisionTypeStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TagDestroyRequest(_message.Message):
    __slots__ = ("tag_id",)
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    tag_id: str
    def __init__(self, tag_id: _Optional[str] = ...) -> None: ...

class TagListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TagListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[TagResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[TagResponse, _Mapping]]] = ...) -> None: ...

class TagPartialUpdateRequest(_message.Message):
    __slots__ = ("tag_id", "_partial_update_fields", "tag", "iri")
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    tag_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    tag: str
    iri: str
    def __init__(self, tag_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., tag: _Optional[str] = ..., iri: _Optional[str] = ...) -> None: ...

class TagRequest(_message.Message):
    __slots__ = ("tag_id", "tag", "iri")
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    tag_id: str
    tag: str
    iri: str
    def __init__(self, tag_id: _Optional[str] = ..., tag: _Optional[str] = ..., iri: _Optional[str] = ...) -> None: ...

class TagResponse(_message.Message):
    __slots__ = ("tag_id", "tag", "iri")
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    tag_id: str
    tag: str
    iri: str
    def __init__(self, tag_id: _Optional[str] = ..., tag: _Optional[str] = ..., iri: _Optional[str] = ...) -> None: ...

class TagRetrieveRequest(_message.Message):
    __slots__ = ("tag_id",)
    TAG_ID_FIELD_NUMBER: _ClassVar[int]
    tag_id: str
    def __init__(self, tag_id: _Optional[str] = ...) -> None: ...

class TagStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
