from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DataDestroyRequest(_message.Message):
    __slots__ = ("data_id",)
    DATA_ID_FIELD_NUMBER: _ClassVar[int]
    data_id: str
    def __init__(self, data_id: _Optional[str] = ...) -> None: ...

class DataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[DataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[DataResponse, _Mapping]]] = ...) -> None: ...

class DataPartialUpdateRequest(_message.Message):
    __slots__ = ("data_id", "data_type", "media_type", "namespace", "method_instance", "process_instance", "procedure_instance", "users", "groups", "visualisations", "data_extra", "tags", "resources_external", "_partial_update_fields", "name", "version", "name_full", "hash_sha256", "hash_blockchain", "acl", "licenses", "datetime_created", "datetime_last_modified", "data_json", "metadata", "iri", "pid", "doi", "pac_id", "file", "thumbnail", "description", "remarks", "name_display", "search_vector")
    DATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    LICENSES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    data_id: str
    data_type: str
    media_type: str
    namespace: str
    method_instance: str
    process_instance: str
    procedure_instance: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    name_full: str
    hash_sha256: str
    hash_blockchain: str
    acl: _struct_pb2.Struct
    licenses: _struct_pb2.Struct
    datetime_created: str
    datetime_last_modified: str
    data_json: _struct_pb2.Struct
    metadata: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    pac_id: str
    file: str
    thumbnail: str
    description: str
    remarks: str
    name_display: str
    search_vector: str
    def __init__(self, data_id: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., namespace: _Optional[str] = ..., method_instance: _Optional[str] = ..., process_instance: _Optional[str] = ..., procedure_instance: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., name_full: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., hash_blockchain: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., licenses: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., pac_id: _Optional[str] = ..., file: _Optional[str] = ..., thumbnail: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class DataRequest(_message.Message):
    __slots__ = ("data_id", "data_type", "media_type", "namespace", "method_instance", "process_instance", "procedure_instance", "users", "groups", "visualisations", "data_extra", "tags", "resources_external", "name", "version", "name_full", "hash_sha256", "hash_blockchain", "acl", "licenses", "datetime_created", "datetime_last_modified", "data_json", "metadata", "iri", "pid", "doi", "pac_id", "file", "thumbnail", "description", "remarks", "name_display", "search_vector")
    DATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    LICENSES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    data_id: str
    data_type: str
    media_type: str
    namespace: str
    method_instance: str
    process_instance: str
    procedure_instance: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    name_full: str
    hash_sha256: str
    hash_blockchain: str
    acl: _struct_pb2.Struct
    licenses: _struct_pb2.Struct
    datetime_created: str
    datetime_last_modified: str
    data_json: _struct_pb2.Struct
    metadata: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    pac_id: str
    file: str
    thumbnail: str
    description: str
    remarks: str
    name_display: str
    search_vector: str
    def __init__(self, data_id: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., namespace: _Optional[str] = ..., method_instance: _Optional[str] = ..., process_instance: _Optional[str] = ..., procedure_instance: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., name_full: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., hash_blockchain: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., licenses: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., pac_id: _Optional[str] = ..., file: _Optional[str] = ..., thumbnail: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class DataResponse(_message.Message):
    __slots__ = ("data_id", "data_type", "media_type", "namespace", "method_instance", "process_instance", "procedure_instance", "users", "groups", "visualisations", "data_extra", "tags", "resources_external", "name", "version", "name_full", "hash_sha256", "hash_blockchain", "acl", "licenses", "datetime_created", "datetime_last_modified", "data_json", "metadata", "iri", "pid", "doi", "pac_id", "file", "thumbnail", "description", "remarks", "name_display", "search_vector")
    DATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    HASH_BLOCKCHAIN_FIELD_NUMBER: _ClassVar[int]
    ACL_FIELD_NUMBER: _ClassVar[int]
    LICENSES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    data_id: str
    data_type: str
    media_type: str
    namespace: str
    method_instance: str
    process_instance: str
    procedure_instance: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    name_full: str
    hash_sha256: str
    hash_blockchain: str
    acl: _struct_pb2.Struct
    licenses: _struct_pb2.Struct
    datetime_created: str
    datetime_last_modified: str
    data_json: _struct_pb2.Struct
    metadata: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    pac_id: str
    file: str
    thumbnail: str
    description: str
    remarks: str
    name_display: str
    search_vector: str
    def __init__(self, data_id: _Optional[str] = ..., data_type: _Optional[str] = ..., media_type: _Optional[str] = ..., namespace: _Optional[str] = ..., method_instance: _Optional[str] = ..., process_instance: _Optional[str] = ..., procedure_instance: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., name_full: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., hash_blockchain: _Optional[str] = ..., acl: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., licenses: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., pac_id: _Optional[str] = ..., file: _Optional[str] = ..., thumbnail: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class DataRetrieveRequest(_message.Message):
    __slots__ = ("data_id",)
    DATA_ID_FIELD_NUMBER: _ClassVar[int]
    data_id: str
    def __init__(self, data_id: _Optional[str] = ...) -> None: ...

class DataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataSubsetDestroyRequest(_message.Message):
    __slots__ = ("datasubset_id",)
    DATASUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    datasubset_id: str
    def __init__(self, datasubset_id: _Optional[str] = ...) -> None: ...

class DataSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DataSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[DataSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[DataSubsetResponse, _Mapping]]] = ...) -> None: ...

class DataSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("datasubset_id", "namespace", "user", "group", "data", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display")
    DATASUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    datasubset_id: str
    namespace: str
    user: str
    group: str
    data: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, datasubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., user: _Optional[str] = ..., group: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class DataSubsetRequest(_message.Message):
    __slots__ = ("datasubset_id", "namespace", "user", "group", "data", "tags", "name", "description", "datetime_last_modified", "name_display")
    DATASUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    datasubset_id: str
    namespace: str
    user: str
    group: str
    data: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, datasubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., user: _Optional[str] = ..., group: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class DataSubsetResponse(_message.Message):
    __slots__ = ("datasubset_id", "namespace", "user", "group", "data", "tags", "name", "description", "datetime_last_modified", "name_display")
    DATASUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    USER_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    datasubset_id: str
    namespace: str
    user: str
    group: str
    data: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    def __init__(self, datasubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., user: _Optional[str] = ..., group: _Optional[str] = ..., data: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ...) -> None: ...

class DataSubsetRetrieveRequest(_message.Message):
    __slots__ = ("datasubset_id",)
    DATASUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    datasubset_id: str
    def __init__(self, datasubset_id: _Optional[str] = ...) -> None: ...

class DataSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EvaluationDestroyRequest(_message.Message):
    __slots__ = ("evaluation_id",)
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    def __init__(self, evaluation_id: _Optional[str] = ...) -> None: ...

class EvaluationListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EvaluationListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[EvaluationResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[EvaluationResponse, _Mapping]]] = ...) -> None: ...

class EvaluationPartialUpdateRequest(_message.Message):
    __slots__ = ("evaluation_id", "namespace", "eval_method_instance", "eval_procedure_instance", "parent_evals", "data_eval", "data_results", "visualisations", "tags", "resources_external", "_partial_update_fields", "name", "version", "hash_sha256", "parameters", "iri", "pid", "doi", "caption", "description", "datetime_created", "datetime_last_modified", "name_display", "search_vector")
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    EVAL_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    EVAL_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PARENT_EVALS_FIELD_NUMBER: _ClassVar[int]
    DATA_EVAL_FIELD_NUMBER: _ClassVar[int]
    DATA_RESULTS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    namespace: str
    eval_method_instance: str
    eval_procedure_instance: str
    parent_evals: _containers.RepeatedScalarFieldContainer[str]
    data_eval: _containers.RepeatedScalarFieldContainer[str]
    data_results: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    hash_sha256: str
    parameters: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    caption: _struct_pb2.Struct
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    def __init__(self, evaluation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., eval_method_instance: _Optional[str] = ..., eval_procedure_instance: _Optional[str] = ..., parent_evals: _Optional[_Iterable[str]] = ..., data_eval: _Optional[_Iterable[str]] = ..., data_results: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EvaluationRequest(_message.Message):
    __slots__ = ("evaluation_id", "namespace", "eval_method_instance", "eval_procedure_instance", "parent_evals", "data_eval", "data_results", "visualisations", "tags", "resources_external", "name", "version", "hash_sha256", "parameters", "iri", "pid", "doi", "caption", "description", "datetime_created", "datetime_last_modified", "name_display", "search_vector")
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    EVAL_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    EVAL_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PARENT_EVALS_FIELD_NUMBER: _ClassVar[int]
    DATA_EVAL_FIELD_NUMBER: _ClassVar[int]
    DATA_RESULTS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    namespace: str
    eval_method_instance: str
    eval_procedure_instance: str
    parent_evals: _containers.RepeatedScalarFieldContainer[str]
    data_eval: _containers.RepeatedScalarFieldContainer[str]
    data_results: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    hash_sha256: str
    parameters: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    caption: _struct_pb2.Struct
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    def __init__(self, evaluation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., eval_method_instance: _Optional[str] = ..., eval_procedure_instance: _Optional[str] = ..., parent_evals: _Optional[_Iterable[str]] = ..., data_eval: _Optional[_Iterable[str]] = ..., data_results: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EvaluationResponse(_message.Message):
    __slots__ = ("evaluation_id", "namespace", "eval_method_instance", "eval_procedure_instance", "parent_evals", "data_eval", "data_results", "visualisations", "tags", "resources_external", "name", "version", "hash_sha256", "parameters", "iri", "pid", "doi", "caption", "description", "datetime_created", "datetime_last_modified", "name_display", "search_vector")
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    EVAL_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    EVAL_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PARENT_EVALS_FIELD_NUMBER: _ClassVar[int]
    DATA_EVAL_FIELD_NUMBER: _ClassVar[int]
    DATA_RESULTS_FIELD_NUMBER: _ClassVar[int]
    VISUALISATIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    DOI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    namespace: str
    eval_method_instance: str
    eval_procedure_instance: str
    parent_evals: _containers.RepeatedScalarFieldContainer[str]
    data_eval: _containers.RepeatedScalarFieldContainer[str]
    data_results: _containers.RepeatedScalarFieldContainer[str]
    visualisations: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    hash_sha256: str
    parameters: _struct_pb2.Struct
    iri: str
    pid: str
    doi: str
    caption: _struct_pb2.Struct
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    def __init__(self, evaluation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., eval_method_instance: _Optional[str] = ..., eval_procedure_instance: _Optional[str] = ..., parent_evals: _Optional[_Iterable[str]] = ..., data_eval: _Optional[_Iterable[str]] = ..., data_results: _Optional[_Iterable[str]] = ..., visualisations: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., doi: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class EvaluationRetrieveRequest(_message.Message):
    __slots__ = ("evaluation_id",)
    EVALUATION_ID_FIELD_NUMBER: _ClassVar[int]
    evaluation_id: str
    def __init__(self, evaluation_id: _Optional[str] = ...) -> None: ...

class EvaluationStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class UploadStatus(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class VisualisationDestroyRequest(_message.Message):
    __slots__ = ("visualisation_id",)
    VISUALISATION_ID_FIELD_NUMBER: _ClassVar[int]
    visualisation_id: str
    def __init__(self, visualisation_id: _Optional[str] = ...) -> None: ...

class VisualisationListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class VisualisationListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[VisualisationResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[VisualisationResponse, _Mapping]]] = ...) -> None: ...

class VisualisationPartialUpdateRequest(_message.Message):
    __slots__ = ("visualisation_id", "namespace", "data_type", "plotting_method_instance", "plotting_procedure_instance", "tags", "resources_external", "_partial_update_fields", "name", "version", "rendering_components", "iri", "caption", "thumbnail", "image", "description", "datetime_created", "datetime_last_modified", "name_display", "order", "search_vector")
    VISUALISATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    RENDERING_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    visualisation_id: str
    namespace: str
    data_type: str
    plotting_method_instance: str
    plotting_procedure_instance: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    rendering_components: _struct_pb2.Struct
    iri: str
    caption: _struct_pb2.Struct
    thumbnail: str
    image: str
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    order: int
    search_vector: str
    def __init__(self, visualisation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., plotting_method_instance: _Optional[str] = ..., plotting_procedure_instance: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., rendering_components: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., thumbnail: _Optional[str] = ..., image: _Optional[str] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., order: _Optional[int] = ..., search_vector: _Optional[str] = ...) -> None: ...

class VisualisationRequest(_message.Message):
    __slots__ = ("visualisation_id", "namespace", "data_type", "plotting_method_instance", "plotting_procedure_instance", "tags", "resources_external", "name", "version", "rendering_components", "iri", "caption", "thumbnail", "image", "description", "datetime_created", "datetime_last_modified", "name_display", "order", "search_vector")
    VISUALISATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    RENDERING_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    visualisation_id: str
    namespace: str
    data_type: str
    plotting_method_instance: str
    plotting_procedure_instance: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    rendering_components: _struct_pb2.Struct
    iri: str
    caption: _struct_pb2.Struct
    thumbnail: str
    image: str
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    order: int
    search_vector: str
    def __init__(self, visualisation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., plotting_method_instance: _Optional[str] = ..., plotting_procedure_instance: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., rendering_components: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., thumbnail: _Optional[str] = ..., image: _Optional[str] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., order: _Optional[int] = ..., search_vector: _Optional[str] = ...) -> None: ...

class VisualisationResponse(_message.Message):
    __slots__ = ("visualisation_id", "namespace", "data_type", "plotting_method_instance", "plotting_procedure_instance", "tags", "resources_external", "name", "version", "rendering_components", "iri", "caption", "thumbnail", "image", "description", "datetime_created", "datetime_last_modified", "name_display", "order", "search_vector")
    VISUALISATION_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_METHOD_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PLOTTING_PROCEDURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    RENDERING_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    THUMBNAIL_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    visualisation_id: str
    namespace: str
    data_type: str
    plotting_method_instance: str
    plotting_procedure_instance: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    name: str
    version: str
    rendering_components: _struct_pb2.Struct
    iri: str
    caption: _struct_pb2.Struct
    thumbnail: str
    image: str
    description: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    order: int
    search_vector: str
    def __init__(self, visualisation_id: _Optional[str] = ..., namespace: _Optional[str] = ..., data_type: _Optional[str] = ..., plotting_method_instance: _Optional[str] = ..., plotting_procedure_instance: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., version: _Optional[str] = ..., rendering_components: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., caption: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., thumbnail: _Optional[str] = ..., image: _Optional[str] = ..., description: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., order: _Optional[int] = ..., search_vector: _Optional[str] = ...) -> None: ...

class VisualisationRetrieveRequest(_message.Message):
    __slots__ = ("visualisation_id",)
    VISUALISATION_ID_FIELD_NUMBER: _ClassVar[int]
    visualisation_id: str
    def __init__(self, visualisation_id: _Optional[str] = ...) -> None: ...
