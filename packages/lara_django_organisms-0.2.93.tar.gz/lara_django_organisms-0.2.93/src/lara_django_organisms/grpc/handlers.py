"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_organisms  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_organisms.grpc.services import (
    ExtraDataService,
    HabitatClassService,
    HabitatParameterService,
    HabitatService,
    TraitService,
    DomainService,
    RegnumService,
    PhylumService,
    ClassisService,
    OrdoService,
    FamiliaService,
    GenusService,
    SpeciesService,
    SubspeciesService,
    VariantService,
    CultivarService,
    OrganismService,
    OrganismsSubsetService
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_organisms", server)

    app_registry.get_grpc_module = lambda: "lara_django_organisms_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(HabitatClassService)

    app_registry.register(HabitatParameterService)

    app_registry.register(HabitatService)

    app_registry.register(TraitService)

    app_registry.register(DomainService)

    app_registry.register(RegnumService)

    app_registry.register(PhylumService)

    app_registry.register(ClassisService)

    app_registry.register(OrdoService)

    app_registry.register(FamiliaService)

    app_registry.register(GenusService)

    app_registry.register(SpeciesService)

    app_registry.register(SubspeciesService)

    app_registry.register(VariantService)

    app_registry.register(CultivarService)

    app_registry.register(OrganismService)

    app_registry.register(OrganismsSubsetService)
