"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_organisms  (LARA-version)

import logging

from django_socio_grpc import proto_serializers
from rest_framework.serializers import UUIDField, PrimaryKeyRelatedField
from lara_django_base.models import (
    Namespace,
    ItemStatus,
    DataType,
    MediaType,
    Namespace,
    Tag,
    PhysicalUnit,
    ExternalResource,
    Location,
    Currency,
)
from lara_django_people.models import (
    Entity,
    Group,
)

from lara_django_organisms.models import (
    ExtraData,
    HabitatClass,
    HabitatParameter,
    Habitat,
    Trait,
    Domain,
    Regnum,
    Phylum,
    Classis,
    Ordo,
    Familia,
    Genus,
    Species,
    Subspecies,
    Variant,
    Cultivar,
    Organism,
    OrganismsSubset,
)

import lara_django_organisms_grpc.v1.lara_django_organisms_pb2 as lara_django_organisms_pb2


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_organisms_pb2.ExtraDataResponse

        proto_class_list = lara_django_organisms_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', file']


class HabitatClassProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = HabitatClass
        proto_class = lara_django_organisms_pb2.HabitatClassResponse

        proto_class_list = lara_django_organisms_pb2.HabitatClassListResponse

        fields = "__all__"  # [name', description']


class HabitatParameterProtoSerializer(proto_serializers.ModelProtoSerializer):
    unit = PrimaryKeyRelatedField(queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = HabitatParameter
        proto_class = lara_django_organisms_pb2.HabitatParameterResponse

        proto_class_list = lara_django_organisms_pb2.HabitatParameterListResponse

        fields = "__all__"  # [name', unit', description']


class HabitatProtoSerializer(proto_serializers.ModelProtoSerializer):
    habitat_class = PrimaryKeyRelatedField(
        queryset=HabitatClass.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    parameters = PrimaryKeyRelatedField(
        queryset=HabitatParameter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = Habitat
        proto_class = lara_django_organisms_pb2.HabitatResponse

        proto_class_list = lara_django_organisms_pb2.HabitatListResponse

        fields = "__all__"  # [name', description']


class TraitProtoSerializer(proto_serializers.ModelProtoSerializer):
    unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = Trait
        proto_class = lara_django_organisms_pb2.TraitResponse

        proto_class_list = lara_django_organisms_pb2.TraitListResponse

        fields = "__all__"  # [feature', unit', description']


class DomainProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Domain
        proto_class = lara_django_organisms_pb2.DomainResponse

        proto_class_list = lara_django_organisms_pb2.DomainListResponse

        fields = "__all__"  # [name', description']


class RegnumProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Regnum
        proto_class = lara_django_organisms_pb2.RegnumResponse

        proto_class_list = lara_django_organisms_pb2.RegnumListResponse

        fields = "__all__"  # [name', description']


class PhylumProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Phylum
        proto_class = lara_django_organisms_pb2.PhylumResponse

        proto_class_list = lara_django_organisms_pb2.PhylumListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class ClassisProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Classis
        proto_class = lara_django_organisms_pb2.ClassisResponse

        proto_class_list = lara_django_organisms_pb2.ClassisListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class OrdoProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Ordo
        proto_class = lara_django_organisms_pb2.OrdoResponse

        proto_class_list = lara_django_organisms_pb2.OrdoListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class FamiliaProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Familia
        proto_class = lara_django_organisms_pb2.FamiliaResponse

        proto_class_list = lara_django_organisms_pb2.FamiliaListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class GenusProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Genus
        proto_class = lara_django_organisms_pb2.GenusResponse

        proto_class_list = lara_django_organisms_pb2.GenusListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class SpeciesProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Species
        proto_class = lara_django_organisms_pb2.SpeciesResponse

        proto_class_list = lara_django_organisms_pb2.SpeciesListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class SubspeciesProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Subspecies
        proto_class = lara_django_organisms_pb2.SubspeciesResponse

        proto_class_list = lara_django_organisms_pb2.SubspeciesListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class VariantProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Variant
        proto_class = lara_django_organisms_pb2.VariantResponse

        proto_class_list = lara_django_organisms_pb2.VariantListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class CultivarProtoSerializer(proto_serializers.ModelProtoSerializer):
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    class Meta:
        model = Cultivar
        proto_class = lara_django_organisms_pb2.CultivarResponse

        proto_class_list = lara_django_organisms_pb2.CultivarListResponse

        fields = "__all__"  # [name', name_common', characteristics', description']


class OrganismProtoSerializer(proto_serializers.ModelProtoSerializer):
    domain = PrimaryKeyRelatedField(
        queryset=Domain.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    regnum = PrimaryKeyRelatedField(
        queryset=Regnum.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    phylum = PrimaryKeyRelatedField(
        queryset=Phylum.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    classis = PrimaryKeyRelatedField(
        queryset=Classis.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    ordo = PrimaryKeyRelatedField(
        queryset=Ordo.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    familia = PrimaryKeyRelatedField(
        queryset=Familia.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    genus = PrimaryKeyRelatedField(queryset=Genus.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    species = PrimaryKeyRelatedField(queryset=Species.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    subspecies = PrimaryKeyRelatedField(
        queryset=Subspecies.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    variant = PrimaryKeyRelatedField(
        queryset=Variant.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    cultivar = PrimaryKeyRelatedField(
        queryset=Cultivar.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    habitats = PrimaryKeyRelatedField(
        queryset=Habitat.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    traits = PrimaryKeyRelatedField(
        queryset=Trait.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    organisms = PrimaryKeyRelatedField(
        queryset=Organism.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Organism
        proto_class = lara_django_organisms_pb2.OrganismResponse

        proto_class_list = lara_django_organisms_pb2.OrganismListResponse

        fields = "__all__"  # [name', name_common', domain', regnum', phylum', classis', ordo', familia', genus', species', subspecies', variant', cultivar', habitat', description']

class OrganismsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    organisms = PrimaryKeyRelatedField(
        queryset=Organism.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
   
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = OrganismsSubset
        proto_class = lara_django_organisms_pb2.OrganismsSubsetResponse

        proto_class_list = lara_django_organisms_pb2.OrganismsSubsetListResponse

        fields = "__all__"  # [name', description']