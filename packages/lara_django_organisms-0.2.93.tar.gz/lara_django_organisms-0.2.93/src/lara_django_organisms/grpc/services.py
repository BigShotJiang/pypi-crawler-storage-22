"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_organisms  (LARA-version)

from django_socio_grpc import generics, mixins

from lara_django_base.grpc.mixins import AsyncUploadModelMixin, AsyncRetrieveByNameModelMixin, AsyncDownloadModelMixin

from .serializers import (
    ExtraDataProtoSerializer,
    HabitatClassProtoSerializer,
    HabitatParameterProtoSerializer,
    HabitatProtoSerializer,
    TraitProtoSerializer,
    DomainProtoSerializer,
    RegnumProtoSerializer,
    PhylumProtoSerializer,
    ClassisProtoSerializer,
    OrdoProtoSerializer,
    FamiliaProtoSerializer,
    GenusProtoSerializer,
    SpeciesProtoSerializer,
    SubspeciesProtoSerializer,
    VariantProtoSerializer,
    CultivarProtoSerializer,
    OrganismProtoSerializer,
    OrganismsSubsetProtoSerializer
)
from ..filters import (
    ExtraDataFilterSet,
    HabitatClassFilterSet,
    HabitatParameterFilterSet,
    HabitatFilterSet,
    TraitFilterSet,
    DomainFilterSet,
    RegnumFilterSet,
    PhylumFilterSet,
    ClassisFilterSet,
    OrdoFilterSet,
    FamiliaFilterSet,
    GenusFilterSet,
    SpeciesFilterSet,
    SubspeciesFilterSet,
    VariantFilterSet,
    CultivarFilterSet,
    OrganismFilterSet,
    OrganismsSubsetFilterSet
)

from lara_django_organisms.models import (
    ExtraData,
    HabitatClass,
    HabitatParameter,
    Habitat,
    Trait,
    Domain,
    Regnum,
    Phylum,
    Classis,
    Ordo,
    Familia,
    Genus,
    Species,
    Subspecies,
    Variant,
    Cultivar,
    Organism,
    OrganismsSubset
)

import lara_django_organisms_grpc.v1.lara_django_organisms_pb2 as lara_django_organisms_pb2

class ExtraDataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_organisms_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class HabitatClassService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = HabitatClass.objects.all()
    serializer_class = HabitatClassProtoSerializer
    filterset_class = HabitatClassFilterSet


class HabitatParameterService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = HabitatParameter.objects.all()
    serializer_class = HabitatParameterProtoSerializer
    filterset_class = HabitatParameterFilterSet


class HabitatService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Habitat.objects.all()
    serializer_class = HabitatProtoSerializer
    filterset_class = HabitatFilterSet


class TraitService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Trait.objects.all()
    serializer_class = TraitProtoSerializer
    filterset_class = TraitFilterSet


class DomainService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Domain.objects.all()
    serializer_class = DomainProtoSerializer
    filterset_class = DomainFilterSet


class RegnumService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Regnum.objects.all()
    serializer_class = RegnumProtoSerializer
    filterset_class = RegnumFilterSet


class PhylumService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Phylum.objects.all()
    serializer_class = PhylumProtoSerializer
    filterset_class = PhylumFilterSet


class ClassisService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Classis.objects.all()
    serializer_class = ClassisProtoSerializer
    filterset_class = ClassisFilterSet


class OrdoService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Ordo.objects.all()
    serializer_class = OrdoProtoSerializer
    filterset_class = OrdoFilterSet


class FamiliaService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Familia.objects.all()
    serializer_class = FamiliaProtoSerializer
    filterset_class = FamiliaFilterSet


class GenusService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Genus.objects.all()
    serializer_class = GenusProtoSerializer
    filterset_class = GenusFilterSet


class SpeciesService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Species.objects.all()
    serializer_class = SpeciesProtoSerializer
    filterset_class = SpeciesFilterSet


class SubspeciesService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Subspecies.objects.all()
    serializer_class = SubspeciesProtoSerializer
    filterset_class = SubspeciesFilterSet


class VariantService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Variant.objects.all()
    serializer_class = VariantProtoSerializer
    filterset_class = VariantFilterSet


class CultivarService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = Cultivar.objects.all()
    serializer_class = CultivarProtoSerializer
    filterset_class = CultivarFilterSet


class OrganismService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_organisms_pb2
    queryset = Organism.objects.all()
    serializer_class = OrganismProtoSerializer
    filterset_class = OrganismFilterSet

class OrganismsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = OrganismsSubset.objects.all()
    serializer_class = OrganismsSubsetProtoSerializer
    filterset_class = OrganismsSubsetFilterSet