"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_organisms Model Context Protocol (MCP) handler *

:details: lara_django_organisms Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

# from mcp_server import ModelQueryToolset

# from .models import Bird


# class BirdQueryTool(ModelQueryToolset):
#     model = Bird

#     def get_queryset(self):
#         """
#         Returns a queryset of all birds with a location.

#         This is used to filter the queryset for the admin interface.
#         self.request can be used to filter the queryset
#         """
#         return super().get_queryset().filter(location__isnull=False)
