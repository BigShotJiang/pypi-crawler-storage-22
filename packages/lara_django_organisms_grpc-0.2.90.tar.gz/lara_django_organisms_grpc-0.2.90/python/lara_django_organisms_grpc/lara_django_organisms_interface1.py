"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms high_level_interface *

:details: lara_django_organisms high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_grpc.v1.lara_django_organisms_pb2 as lara_django_organisms_pb2
import lara_django_organisms_grpc.v1.lara_django_organisms_pb2_grpc as lara_django_organisms_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if

import  lara_django_organisms_grpc.lara_django_organisms_data_model as organisms_dm 



class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_organisms_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_organisms_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    def create(self,  extradata:  organisms_dm.ExtraData = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   extradata_class_id = self.extradata_class_client.Retrieve(
        #         lara_django_organisms_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #   ).extradataclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # extradata.namespace = self.namespace_id
        # extradata.extradata_class = extradata_class_id

        try:
            return self.extradata_client.Create(lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump()))
        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  self.extradata_client.Retrieve(
                    lara_django_organisms_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.extradata_client.List(
                        lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.extradata_client.List(
                        lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    def retrieve_id(self, extradata_name: str = None):
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.extradata_client.List(
                    lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.extradata_client.List(lara_django_organisms_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.extradata_client.List(
                lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    def update(self, extradata : organisms_dm.ExtraData = None):
        try:
            return self.extradata_client.Update(
                lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for extradata_id in id_list:
            try:
                destroy_list.append( self.extradata_client.Destroy(
                        lara_django_organisms_pb2.ExtraDataDestroyRequest(extradata_id=extradata_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting extradata_id: {e}")
        return destroy_list

class HabitatClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitatclass_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatClassclassByIRIControllerStub(channel)
        # )
        
        self.habitatclass_client = lara_django_organisms_pb2_grpc.HabitatClassControllerStub(channel)

        # self.habitatclass_full_client = lara_django_organisms_pb2_grpc.HabitatClassFullControllerStub(
        #     channel
        # )

    def create(self,  habitatclass:  organisms_dm.HabitatClass = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitatclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   habitatclass_class_id = self.habitatclass_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatClassclassRetrieveRequest(iri=habitatclass_class_iri)
        #   ).habitatclassclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatclassclass_id: {e}")
        # habitatclass.namespace = self.namespace_id
        # habitatclass.habitatclass_class = habitatclass_class_id

        try:
            return self.habitatclass_client.Create(lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump()))
        except Exception as e:
            logging.error(f"Error creating habitatclass: {e}")

    def retrieve(
        self, 
        habitatclass_id: str = None,
        habitatclass_name: str = None,
        #habitatclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  habitatclass_id is not None:
            try:
                res =  self.habitatclass_client.Retrieve(
                    lara_django_organisms_pb2.HabitatClassRetrieveRequest(habitatclass_id=habitatclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_id: {e}")

        if habitatclass_name is not None:
            filter_list.append({"name": habitatclass_name})
        # if habitatclass_name_full is not None:
        #     filter_list.append({"name_full": habitatclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.habitatclass_client.List(
                        lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.habitatclass_client.List(
                        lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_name: {e}")

        return results_list

    def retrieve_id(self, habitatclass_name: str = None):
        if habitatclass_name is not None:
            filter_dict = {"name": habitatclass_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.habitatclass_client.List(
                    lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitatclass_id
            else:
                raise ValueError(f"Error retrieving habitatclass_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.habitatclass_client.List(lara_django_organisms_pb2.HabitatClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.habitatclass_client.List(
                lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatclass_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.habitatclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest(), metadata=metadata
            )

    def update(self, habitatclass : organisms_dm.HabitatClass = None):
        try:
            return self.habitatclass_client.Update(
                lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitatclass_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for habitatclass_id in id_list:
            try:
                destroy_list.append( self.habitatclass_client.Destroy(
                        lara_django_organisms_pb2.HabitatClassDestroyRequest(habitatclass_id=habitatclass_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting habitatclass_id: {e}")
        return destroy_list

class HabitatParameterClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitatparameterclass_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatParameterClassclassByIRIControllerStub(channel)
        # )
        
        self.habitatparameterclass_client = lara_django_organisms_pb2_grpc.HabitatParameterClassControllerStub(channel)

        # self.habitatparameterclass_full_client = lara_django_organisms_pb2_grpc.HabitatParameterClassFullControllerStub(
        #     channel
        # )

    def create(self,  habitatparameterclass:  organisms_dm.HabitatParameterClass = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitatparameterclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   habitatparameterclass_class_id = self.habitatparameterclass_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatParameterClassclassRetrieveRequest(iri=habitatparameterclass_class_iri)
        #   ).habitatparameterclassclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatparameterclassclass_id: {e}")
        # habitatparameterclass.namespace = self.namespace_id
        # habitatparameterclass.habitatparameterclass_class = habitatparameterclass_class_id

        try:
            return self.habitatparameterclass_client.Create(lara_django_organisms_pb2.HabitatParameterClassRequest(**habitatparameterclass.model_dump()))
        except Exception as e:
            logging.error(f"Error creating habitatparameterclass: {e}")

    def retrieve(
        self, 
        habitatparameterclass_id: str = None,
        habitatparameterclass_name: str = None,
        #habitatparameterclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  habitatparameterclass_id is not None:
            try:
                res =  self.habitatparameterclass_client.Retrieve(
                    lara_django_organisms_pb2.HabitatParameterClassRetrieveRequest(habitatparameterclass_id=habitatparameterclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatParameterClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitatparameterclass_id: {e}")

        if habitatparameterclass_name is not None:
            filter_list.append({"name": habitatparameterclass_name})
        # if habitatparameterclass_name_full is not None:
        #     filter_list.append({"name_full": habitatparameterclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.habitatparameterclass_client.List(
                        lara_django_organisms_pb2.HabitatParameterClassListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.HabitatParameterClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.habitatparameterclass_client.List(
                        lara_django_organisms_pb2.HabitatParameterClassListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving habitatparameterclass_name: {e}")

        return results_list

    def retrieve_id(self, habitatparameterclass_name: str = None):
        if habitatparameterclass_name is not None:
            filter_dict = {"name": habitatparameterclass_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.habitatparameterclass_client.List(
                    lara_django_organisms_pb2.HabitatParameterClassListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving habitatparameterclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitatparameterclass_id
            else:
                raise ValueError(f"Error retrieving habitatparameterclass_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.habitatparameterclass_client.List(lara_django_organisms_pb2.HabitatParameterClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.habitatparameterclass_client.List(
                lara_django_organisms_pb2.HabitatParameterClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatparameterclass_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.habitatparameterclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.habitatparameterclass_full_client.List(
                lara_django_organisms_pb2.HabitatParameterClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.habitatparameterclass_full_client.List(
                lara_django_organisms_pb2.HabitatParameterClassFullListRequest(), metadata=metadata
            )

    def update(self, habitatparameterclass : organisms_dm.HabitatParameterClass = None):
        try:
            return self.habitatparameterclass_client.Update(
                lara_django_organisms_pb2.HabitatParameterClassRequest(**habitatparameterclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitatparameterclass_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for habitatparameterclass_id in id_list:
            try:
                destroy_list.append( self.habitatparameterclass_client.Destroy(
                        lara_django_organisms_pb2.HabitatParameterClassDestroyRequest(habitatparameterclass_id=habitatparameterclass_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting habitatparameterclass_id: {e}")
        return destroy_list

class HabitatInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitat_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatClassByIRIControllerStub(channel)
        # )
        
        self.habitat_client = lara_django_organisms_pb2_grpc.HabitatControllerStub(channel)

        # self.habitat_full_client = lara_django_organisms_pb2_grpc.HabitatFullControllerStub(
        #     channel
        # )

    def create(self,  habitat:  organisms_dm.Habitat = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitat_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   habitat_class_id = self.habitat_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatClassRetrieveRequest(iri=habitat_class_iri)
        #   ).habitatclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatclass_id: {e}")
        # habitat.namespace = self.namespace_id
        # habitat.habitat_class = habitat_class_id

        try:
            return self.habitat_client.Create(lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump()))
        except Exception as e:
            logging.error(f"Error creating habitat: {e}")

    def retrieve(
        self, 
        habitat_id: str = None,
        habitat_name: str = None,
        #habitat_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  habitat_id is not None:
            try:
                res =  self.habitat_client.Retrieve(
                    lara_django_organisms_pb2.HabitatRetrieveRequest(habitat_id=habitat_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitat_id: {e}")

        if habitat_name is not None:
            filter_list.append({"name": habitat_name})
        # if habitat_name_full is not None:
        #     filter_list.append({"name_full": habitat_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.habitat_client.List(
                        lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.habitat_client.List(
                        lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving habitat_name: {e}")

        return results_list

    def retrieve_id(self, habitat_name: str = None):
        if habitat_name is not None:
            filter_dict = {"name": habitat_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.habitat_client.List(
                    lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving habitat_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitat_id
            else:
                raise ValueError(f"Error retrieving habitat_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.habitat_client.List(lara_django_organisms_pb2.HabitatListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.habitat_client.List(
                lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitat_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.habitat_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest(), metadata=metadata
            )

    def update(self, habitat : organisms_dm.Habitat = None):
        try:
            return self.habitat_client.Update(
                lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitat_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for habitat_id in id_list:
            try:
                destroy_list.append( self.habitat_client.Destroy(
                        lara_django_organisms_pb2.HabitatDestroyRequest(habitat_id=habitat_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting habitat_id: {e}")
        return destroy_list

class FeatureClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.featureclass_class_client = (
        #     lara_django_organisms_pb2_grpc.FeatureclassclassByIRIControllerStub(channel)
        # )
        
        self.featureclass_client = lara_django_organisms_pb2_grpc.FeatureclassControllerStub(channel)

        # self.featureclass_full_client = lara_django_organisms_pb2_grpc.FeatureclassFullControllerStub(
        #     channel
        # )

    def create(self,  featureclass:  organisms_dm.FeatureClass = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if featureclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   featureclass_class_id = self.featureclass_class_client.Retrieve(
        #         lara_django_organisms_pb2.FeatureclassclassRetrieveRequest(iri=featureclass_class_iri)
        #   ).featureclassclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving featureclassclass_id: {e}")
        # featureclass.namespace = self.namespace_id
        # featureclass.featureclass_class = featureclass_class_id

        try:
            return self.featureclass_client.Create(lara_django_organisms_pb2.FeatureclassRequest(**featureclass.model_dump()))
        except Exception as e:
            logging.error(f"Error creating featureclass: {e}")

    def retrieve(
        self, 
        featureclass_id: str = None,
        featureclass_name: str = None,
        #featureclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  featureclass_id is not None:
            try:
                res =  self.featureclass_client.Retrieve(
                    lara_django_organisms_pb2.FeatureclassRetrieveRequest(featureclass_id=featureclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.FeatureClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving featureclass_id: {e}")

        if featureclass_name is not None:
            filter_list.append({"name": featureclass_name})
        # if featureclass_name_full is not None:
        #     filter_list.append({"name_full": featureclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.featureclass_client.List(
                        lara_django_organisms_pb2.FeatureclassListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.FeatureClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.featureclass_client.List(
                        lara_django_organisms_pb2.FeatureclassListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving featureclass_name: {e}")

        return results_list

    def retrieve_id(self, featureclass_name: str = None):
        if featureclass_name is not None:
            filter_dict = {"name": featureclass_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.featureclass_client.List(
                    lara_django_organisms_pb2.FeatureclassListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving featureclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].featureclass_id
            else:
                raise ValueError(f"Error retrieving featureclass_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.featureclass_client.List(lara_django_organisms_pb2.FeatureclassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.featureclass_client.List(
                lara_django_organisms_pb2.FeatureclassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.featureclass_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.featureclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.featureclass_full_client.List(
                lara_django_organisms_pb2.FeatureclassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.featureclass_full_client.List(
                lara_django_organisms_pb2.FeatureclassFullListRequest(), metadata=metadata
            )

    def update(self, featureclass : organisms_dm.FeatureClass = None):
        try:
            return self.featureclass_client.Update(
                lara_django_organisms_pb2.FeatureclassRequest(**featureclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating featureclass_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for featureclass_id in id_list:
            try:
                destroy_list.append( self.featureclass_client.Destroy(
                        lara_django_organisms_pb2.FeatureclassDestroyRequest(featureclass_id=featureclass_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting featureclass_id: {e}")
        return destroy_list

class DomainInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.domain_class_client = (
        #     lara_django_organisms_pb2_grpc.DomainclassByIRIControllerStub(channel)
        # )
        
        self.domain_client = lara_django_organisms_pb2_grpc.DomainControllerStub(channel)

        # self.domain_full_client = lara_django_organisms_pb2_grpc.DomainFullControllerStub(
        #     channel
        # )

    def create(self,  domain:  organisms_dm.Domain = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if domain_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   domain_class_id = self.domain_class_client.Retrieve(
        #         lara_django_organisms_pb2.DomainclassRetrieveRequest(iri=domain_class_iri)
        #   ).domainclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving domainclass_id: {e}")
        # domain.namespace = self.namespace_id
        # domain.domain_class = domain_class_id

        try:
            return self.domain_client.Create(lara_django_organisms_pb2.DomainRequest(**domain.model_dump()))
        except Exception as e:
            logging.error(f"Error creating domain: {e}")

    def retrieve(
        self, 
        domain_id: str = None,
        domain_name: str = None,
        #domain_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  domain_id is not None:
            try:
                res =  self.domain_client.Retrieve(
                    lara_django_organisms_pb2.DomainRetrieveRequest(domain_id=domain_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving domain_id: {e}")

        if domain_name is not None:
            filter_list.append({"name": domain_name})
        # if domain_name_full is not None:
        #     filter_list.append({"name_full": domain_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.domain_client.List(
                        lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.domain_client.List(
                        lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving domain_name: {e}")

        return results_list

    def retrieve_id(self, domain_name: str = None):
        if domain_name is not None:
            filter_dict = {"name": domain_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.domain_client.List(
                    lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving domain_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].domain_id
            else:
                raise ValueError(f"Error retrieving domain_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.domain_client.List(lara_django_organisms_pb2.DomainListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.domain_client.List(
                lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.domain_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.domain_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest(), metadata=metadata
            )

    def update(self, domain : organisms_dm.Domain = None):
        try:
            return self.domain_client.Update(
                lara_django_organisms_pb2.DomainRequest(**domain.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating domain_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for domain_id in id_list:
            try:
                destroy_list.append( self.domain_client.Destroy(
                        lara_django_organisms_pb2.DomainDestroyRequest(domain_id=domain_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting domain_id: {e}")
        return destroy_list

class RegnumInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.regnum_class_client = (
        #     lara_django_organisms_pb2_grpc.RegnumclassByIRIControllerStub(channel)
        # )
        
        self.regnum_client = lara_django_organisms_pb2_grpc.RegnumControllerStub(channel)

        # self.regnum_full_client = lara_django_organisms_pb2_grpc.RegnumFullControllerStub(
        #     channel
        # )

    def create(self,  regnum:  organisms_dm.Regnum = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if regnum_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   regnum_class_id = self.regnum_class_client.Retrieve(
        #         lara_django_organisms_pb2.RegnumclassRetrieveRequest(iri=regnum_class_iri)
        #   ).regnumclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving regnumclass_id: {e}")
        # regnum.namespace = self.namespace_id
        # regnum.regnum_class = regnum_class_id

        try:
            return self.regnum_client.Create(lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump()))
        except Exception as e:
            logging.error(f"Error creating regnum: {e}")

    def retrieve(
        self, 
        regnum_id: str = None,
        regnum_name: str = None,
        #regnum_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  regnum_id is not None:
            try:
                res =  self.regnum_client.Retrieve(
                    lara_django_organisms_pb2.RegnumRetrieveRequest(regnum_id=regnum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving regnum_id: {e}")

        if regnum_name is not None:
            filter_list.append({"name": regnum_name})
        # if regnum_name_full is not None:
        #     filter_list.append({"name_full": regnum_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.regnum_client.List(
                        lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.regnum_client.List(
                        lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving regnum_name: {e}")

        return results_list

    def retrieve_id(self, regnum_name: str = None):
        if regnum_name is not None:
            filter_dict = {"name": regnum_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.regnum_client.List(
                    lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving regnum_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].regnum_id
            else:
                raise ValueError(f"Error retrieving regnum_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.regnum_client.List(lara_django_organisms_pb2.RegnumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.regnum_client.List(
                lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.regnum_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.regnum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest(), metadata=metadata
            )

    def update(self, regnum : organisms_dm.Regnum = None):
        try:
            return self.regnum_client.Update(
                lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating regnum_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for regnum_id in id_list:
            try:
                destroy_list.append( self.regnum_client.Destroy(
                        lara_django_organisms_pb2.RegnumDestroyRequest(regnum_id=regnum_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting regnum_id: {e}")
        return destroy_list

class PhylumInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.phylum_class_client = (
        #     lara_django_organisms_pb2_grpc.PhylumclassByIRIControllerStub(channel)
        # )
        
        self.phylum_client = lara_django_organisms_pb2_grpc.PhylumControllerStub(channel)

        # self.phylum_full_client = lara_django_organisms_pb2_grpc.PhylumFullControllerStub(
        #     channel
        # )

    def create(self,  phylum:  organisms_dm.Phylum = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if phylum_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   phylum_class_id = self.phylum_class_client.Retrieve(
        #         lara_django_organisms_pb2.PhylumclassRetrieveRequest(iri=phylum_class_iri)
        #   ).phylumclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving phylumclass_id: {e}")
        # phylum.namespace = self.namespace_id
        # phylum.phylum_class = phylum_class_id

        try:
            return self.phylum_client.Create(lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump()))
        except Exception as e:
            logging.error(f"Error creating phylum: {e}")

    def retrieve(
        self, 
        phylum_id: str = None,
        phylum_name: str = None,
        #phylum_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  phylum_id is not None:
            try:
                res =  self.phylum_client.Retrieve(
                    lara_django_organisms_pb2.PhylumRetrieveRequest(phylum_id=phylum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving phylum_id: {e}")

        if phylum_name is not None:
            filter_list.append({"name": phylum_name})
        # if phylum_name_full is not None:
        #     filter_list.append({"name_full": phylum_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.phylum_client.List(
                        lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.phylum_client.List(
                        lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving phylum_name: {e}")

        return results_list

    def retrieve_id(self, phylum_name: str = None):
        if phylum_name is not None:
            filter_dict = {"name": phylum_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.phylum_client.List(
                    lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving phylum_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].phylum_id
            else:
                raise ValueError(f"Error retrieving phylum_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.phylum_client.List(lara_django_organisms_pb2.PhylumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.phylum_client.List(
                lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.phylum_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.phylum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest(), metadata=metadata
            )

    def update(self, phylum : organisms_dm.Phylum = None):
        try:
            return self.phylum_client.Update(
                lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating phylum_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for phylum_id in id_list:
            try:
                destroy_list.append( self.phylum_client.Destroy(
                        lara_django_organisms_pb2.PhylumDestroyRequest(phylum_id=phylum_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting phylum_id: {e}")
        return destroy_list

class ClassisInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.classis_class_client = (
        #     lara_django_organisms_pb2_grpc.ClassisclassByIRIControllerStub(channel)
        # )
        
        self.classis_client = lara_django_organisms_pb2_grpc.ClassisControllerStub(channel)

        # self.classis_full_client = lara_django_organisms_pb2_grpc.ClassisFullControllerStub(
        #     channel
        # )

    def create(self,  classis:  organisms_dm.Classis = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if classis_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   classis_class_id = self.classis_class_client.Retrieve(
        #         lara_django_organisms_pb2.ClassisclassRetrieveRequest(iri=classis_class_iri)
        #   ).classisclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving classisclass_id: {e}")
        # classis.namespace = self.namespace_id
        # classis.classis_class = classis_class_id

        try:
            return self.classis_client.Create(lara_django_organisms_pb2.ClassisRequest(**classis.model_dump()))
        except Exception as e:
            logging.error(f"Error creating classis: {e}")

    def retrieve(
        self, 
        classis_id: str = None,
        classis_name: str = None,
        #classis_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  classis_id is not None:
            try:
                res =  self.classis_client.Retrieve(
                    lara_django_organisms_pb2.ClassisRetrieveRequest(classis_id=classis_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving classis_id: {e}")

        if classis_name is not None:
            filter_list.append({"name": classis_name})
        # if classis_name_full is not None:
        #     filter_list.append({"name_full": classis_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.classis_client.List(
                        lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.classis_client.List(
                        lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving classis_name: {e}")

        return results_list

    def retrieve_id(self, classis_name: str = None):
        if classis_name is not None:
            filter_dict = {"name": classis_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.classis_client.List(
                    lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving classis_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].classis_id
            else:
                raise ValueError(f"Error retrieving classis_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.classis_client.List(lara_django_organisms_pb2.ClassisListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.classis_client.List(
                lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.classis_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.classis_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest(), metadata=metadata
            )

    def update(self, classis : organisms_dm.Classis = None):
        try:
            return self.classis_client.Update(
                lara_django_organisms_pb2.ClassisRequest(**classis.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating classis_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for classis_id in id_list:
            try:
                destroy_list.append( self.classis_client.Destroy(
                        lara_django_organisms_pb2.ClassisDestroyRequest(classis_id=classis_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting classis_id: {e}")
        return destroy_list

class OrdoInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.ordo_class_client = (
        #     lara_django_organisms_pb2_grpc.OrdoclassByIRIControllerStub(channel)
        # )
        
        self.ordo_client = lara_django_organisms_pb2_grpc.OrdoControllerStub(channel)

        # self.ordo_full_client = lara_django_organisms_pb2_grpc.OrdoFullControllerStub(
        #     channel
        # )

    def create(self,  ordo:  organisms_dm.Ordo = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if ordo_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   ordo_class_id = self.ordo_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrdoclassRetrieveRequest(iri=ordo_class_iri)
        #   ).ordoclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving ordoclass_id: {e}")
        # ordo.namespace = self.namespace_id
        # ordo.ordo_class = ordo_class_id

        try:
            return self.ordo_client.Create(lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump()))
        except Exception as e:
            logging.error(f"Error creating ordo: {e}")

    def retrieve(
        self, 
        ordo_id: str = None,
        ordo_name: str = None,
        #ordo_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  ordo_id is not None:
            try:
                res =  self.ordo_client.Retrieve(
                    lara_django_organisms_pb2.OrdoRetrieveRequest(ordo_id=ordo_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving ordo_id: {e}")

        if ordo_name is not None:
            filter_list.append({"name": ordo_name})
        # if ordo_name_full is not None:
        #     filter_list.append({"name_full": ordo_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.ordo_client.List(
                        lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.ordo_client.List(
                        lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving ordo_name: {e}")

        return results_list

    def retrieve_id(self, ordo_name: str = None):
        if ordo_name is not None:
            filter_dict = {"name": ordo_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.ordo_client.List(
                    lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving ordo_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].ordo_id
            else:
                raise ValueError(f"Error retrieving ordo_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.ordo_client.List(lara_django_organisms_pb2.OrdoListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.ordo_client.List(
                lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.ordo_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.ordo_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest(), metadata=metadata
            )

    def update(self, ordo : organisms_dm.Ordo = None):
        try:
            return self.ordo_client.Update(
                lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating ordo_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for ordo_id in id_list:
            try:
                destroy_list.append( self.ordo_client.Destroy(
                        lara_django_organisms_pb2.OrdoDestroyRequest(ordo_id=ordo_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting ordo_id: {e}")
        return destroy_list

class FamiliaInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.familia_class_client = (
        #     lara_django_organisms_pb2_grpc.FamiliaclassByIRIControllerStub(channel)
        # )
        
        self.familia_client = lara_django_organisms_pb2_grpc.FamiliaControllerStub(channel)

        # self.familia_full_client = lara_django_organisms_pb2_grpc.FamiliaFullControllerStub(
        #     channel
        # )

    def create(self,  familia:  organisms_dm.Familia = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if familia_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   familia_class_id = self.familia_class_client.Retrieve(
        #         lara_django_organisms_pb2.FamiliaclassRetrieveRequest(iri=familia_class_iri)
        #   ).familiaclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving familiaclass_id: {e}")
        # familia.namespace = self.namespace_id
        # familia.familia_class = familia_class_id

        try:
            return self.familia_client.Create(lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump()))
        except Exception as e:
            logging.error(f"Error creating familia: {e}")

    def retrieve(
        self, 
        familia_id: str = None,
        familia_name: str = None,
        #familia_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  familia_id is not None:
            try:
                res =  self.familia_client.Retrieve(
                    lara_django_organisms_pb2.FamiliaRetrieveRequest(familia_id=familia_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving familia_id: {e}")

        if familia_name is not None:
            filter_list.append({"name": familia_name})
        # if familia_name_full is not None:
        #     filter_list.append({"name_full": familia_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.familia_client.List(
                        lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.familia_client.List(
                        lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving familia_name: {e}")

        return results_list

    def retrieve_id(self, familia_name: str = None):
        if familia_name is not None:
            filter_dict = {"name": familia_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.familia_client.List(
                    lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving familia_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].familia_id
            else:
                raise ValueError(f"Error retrieving familia_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.familia_client.List(lara_django_organisms_pb2.FamiliaListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.familia_client.List(
                lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.familia_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.familia_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest(), metadata=metadata
            )

    def update(self, familia : organisms_dm.Familia = None):
        try:
            return self.familia_client.Update(
                lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating familia_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for familia_id in id_list:
            try:
                destroy_list.append( self.familia_client.Destroy(
                        lara_django_organisms_pb2.FamiliaDestroyRequest(familia_id=familia_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting familia_id: {e}")
        return destroy_list

class GenusInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.genus_class_client = (
        #     lara_django_organisms_pb2_grpc.GenusclassByIRIControllerStub(channel)
        # )
        
        self.genus_client = lara_django_organisms_pb2_grpc.GenusControllerStub(channel)

        # self.genus_full_client = lara_django_organisms_pb2_grpc.GenusFullControllerStub(
        #     channel
        # )

    def create(self,  genus:  organisms_dm.Genus = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if genus_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   genus_class_id = self.genus_class_client.Retrieve(
        #         lara_django_organisms_pb2.GenusclassRetrieveRequest(iri=genus_class_iri)
        #   ).genusclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving genusclass_id: {e}")
        # genus.namespace = self.namespace_id
        # genus.genus_class = genus_class_id

        try:
            return self.genus_client.Create(lara_django_organisms_pb2.GenusRequest(**genus.model_dump()))
        except Exception as e:
            logging.error(f"Error creating genus: {e}")

    def retrieve(
        self, 
        genus_id: str = None,
        genus_name: str = None,
        #genus_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  genus_id is not None:
            try:
                res =  self.genus_client.Retrieve(
                    lara_django_organisms_pb2.GenusRetrieveRequest(genus_id=genus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving genus_id: {e}")

        if genus_name is not None:
            filter_list.append({"name": genus_name})
        # if genus_name_full is not None:
        #     filter_list.append({"name_full": genus_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.genus_client.List(
                        lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.genus_client.List(
                        lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving genus_name: {e}")

        return results_list

    def retrieve_id(self, genus_name: str = None):
        if genus_name is not None:
            filter_dict = {"name": genus_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.genus_client.List(
                    lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving genus_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].genus_id
            else:
                raise ValueError(f"Error retrieving genus_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.genus_client.List(lara_django_organisms_pb2.GenusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.genus_client.List(
                lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.genus_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.genus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest(), metadata=metadata
            )

    def update(self, genus : organisms_dm.Genus = None):
        try:
            return self.genus_client.Update(
                lara_django_organisms_pb2.GenusRequest(**genus.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating genus_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for genus_id in id_list:
            try:
                destroy_list.append( self.genus_client.Destroy(
                        lara_django_organisms_pb2.GenusDestroyRequest(genus_id=genus_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting genus_id: {e}")
        return destroy_list

class SpeciesInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.species_class_client = (
        #     lara_django_organisms_pb2_grpc.SpeciesclassByIRIControllerStub(channel)
        # )
        
        self.species_client = lara_django_organisms_pb2_grpc.SpeciesControllerStub(channel)

        # self.species_full_client = lara_django_organisms_pb2_grpc.SpeciesFullControllerStub(
        #     channel
        # )

    def create(self,  species:  organisms_dm.Species = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if species_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   species_class_id = self.species_class_client.Retrieve(
        #         lara_django_organisms_pb2.SpeciesclassRetrieveRequest(iri=species_class_iri)
        #   ).speciesclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving speciesclass_id: {e}")
        # species.namespace = self.namespace_id
        # species.species_class = species_class_id

        try:
            return self.species_client.Create(lara_django_organisms_pb2.SpeciesRequest(**species.model_dump()))
        except Exception as e:
            logging.error(f"Error creating species: {e}")

    def retrieve(
        self, 
        species_id: str = None,
        species_name: str = None,
        #species_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  species_id is not None:
            try:
                res =  self.species_client.Retrieve(
                    lara_django_organisms_pb2.SpeciesRetrieveRequest(species_id=species_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving species_id: {e}")

        if species_name is not None:
            filter_list.append({"name": species_name})
        # if species_name_full is not None:
        #     filter_list.append({"name_full": species_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.species_client.List(
                        lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.species_client.List(
                        lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving species_name: {e}")

        return results_list

    def retrieve_id(self, species_name: str = None):
        if species_name is not None:
            filter_dict = {"name": species_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.species_client.List(
                    lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving species_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].species_id
            else:
                raise ValueError(f"Error retrieving species_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.species_client.List(lara_django_organisms_pb2.SpeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.species_client.List(
                lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.species_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.species_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest(), metadata=metadata
            )

    def update(self, species : organisms_dm.Species = None):
        try:
            return self.species_client.Update(
                lara_django_organisms_pb2.SpeciesRequest(**species.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating species_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for species_id in id_list:
            try:
                destroy_list.append( self.species_client.Destroy(
                        lara_django_organisms_pb2.SpeciesDestroyRequest(species_id=species_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting species_id: {e}")
        return destroy_list

class SubspeciesInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.subspecies_class_client = (
        #     lara_django_organisms_pb2_grpc.SubspeciesclassByIRIControllerStub(channel)
        # )
        
        self.subspecies_client = lara_django_organisms_pb2_grpc.SubspeciesControllerStub(channel)

        # self.subspecies_full_client = lara_django_organisms_pb2_grpc.SubspeciesFullControllerStub(
        #     channel
        # )

    def create(self,  subspecies:  organisms_dm.Subspecies = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if subspecies_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   subspecies_class_id = self.subspecies_class_client.Retrieve(
        #         lara_django_organisms_pb2.SubspeciesclassRetrieveRequest(iri=subspecies_class_iri)
        #   ).subspeciesclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving subspeciesclass_id: {e}")
        # subspecies.namespace = self.namespace_id
        # subspecies.subspecies_class = subspecies_class_id

        try:
            return self.subspecies_client.Create(lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump()))
        except Exception as e:
            logging.error(f"Error creating subspecies: {e}")

    def retrieve(
        self, 
        subspecies_id: str = None,
        subspecies_name: str = None,
        #subspecies_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  subspecies_id is not None:
            try:
                res =  self.subspecies_client.Retrieve(
                    lara_django_organisms_pb2.SubspeciesRetrieveRequest(subspecies_id=subspecies_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving subspecies_id: {e}")

        if subspecies_name is not None:
            filter_list.append({"name": subspecies_name})
        # if subspecies_name_full is not None:
        #     filter_list.append({"name_full": subspecies_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.subspecies_client.List(
                        lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.subspecies_client.List(
                        lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving subspecies_name: {e}")

        return results_list

    def retrieve_id(self, subspecies_name: str = None):
        if subspecies_name is not None:
            filter_dict = {"name": subspecies_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.subspecies_client.List(
                    lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving subspecies_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].subspecies_id
            else:
                raise ValueError(f"Error retrieving subspecies_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.subspecies_client.List(lara_django_organisms_pb2.SubspeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.subspecies_client.List(
                lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subspecies_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.subspecies_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest(), metadata=metadata
            )

    def update(self, subspecies : organisms_dm.Subspecies = None):
        try:
            return self.subspecies_client.Update(
                lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating subspecies_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for subspecies_id in id_list:
            try:
                destroy_list.append( self.subspecies_client.Destroy(
                        lara_django_organisms_pb2.SubspeciesDestroyRequest(subspecies_id=subspecies_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting subspecies_id: {e}")
        return destroy_list

class VariantInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.variant_class_client = (
        #     lara_django_organisms_pb2_grpc.VariantclassByIRIControllerStub(channel)
        # )
        
        self.variant_client = lara_django_organisms_pb2_grpc.VariantControllerStub(channel)

        # self.variant_full_client = lara_django_organisms_pb2_grpc.VariantFullControllerStub(
        #     channel
        # )

    def create(self,  variant:  organisms_dm.Variant = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if variant_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   variant_class_id = self.variant_class_client.Retrieve(
        #         lara_django_organisms_pb2.VariantclassRetrieveRequest(iri=variant_class_iri)
        #   ).variantclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving variantclass_id: {e}")
        # variant.namespace = self.namespace_id
        # variant.variant_class = variant_class_id

        try:
            return self.variant_client.Create(lara_django_organisms_pb2.VariantRequest(**variant.model_dump()))
        except Exception as e:
            logging.error(f"Error creating variant: {e}")

    def retrieve(
        self, 
        variant_id: str = None,
        variant_name: str = None,
        #variant_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  variant_id is not None:
            try:
                res =  self.variant_client.Retrieve(
                    lara_django_organisms_pb2.VariantRetrieveRequest(variant_id=variant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving variant_id: {e}")

        if variant_name is not None:
            filter_list.append({"name": variant_name})
        # if variant_name_full is not None:
        #     filter_list.append({"name_full": variant_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.variant_client.List(
                        lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.variant_client.List(
                        lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving variant_name: {e}")

        return results_list

    def retrieve_id(self, variant_name: str = None):
        if variant_name is not None:
            filter_dict = {"name": variant_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.variant_client.List(
                    lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving variant_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].variant_id
            else:
                raise ValueError(f"Error retrieving variant_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.variant_client.List(lara_django_organisms_pb2.VariantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.variant_client.List(
                lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.variant_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.variant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest(), metadata=metadata
            )

    def update(self, variant : organisms_dm.Variant = None):
        try:
            return self.variant_client.Update(
                lara_django_organisms_pb2.VariantRequest(**variant.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating variant_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for variant_id in id_list:
            try:
                destroy_list.append( self.variant_client.Destroy(
                        lara_django_organisms_pb2.VariantDestroyRequest(variant_id=variant_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting variant_id: {e}")
        return destroy_list

class CultivarInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.cultivar_class_client = (
        #     lara_django_organisms_pb2_grpc.CultivarclassByIRIControllerStub(channel)
        # )
        
        self.cultivar_client = lara_django_organisms_pb2_grpc.CultivarControllerStub(channel)

        # self.cultivar_full_client = lara_django_organisms_pb2_grpc.CultivarFullControllerStub(
        #     channel
        # )

    def create(self,  cultivar:  organisms_dm.Cultivar = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if cultivar_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   cultivar_class_id = self.cultivar_class_client.Retrieve(
        #         lara_django_organisms_pb2.CultivarclassRetrieveRequest(iri=cultivar_class_iri)
        #   ).cultivarclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving cultivarclass_id: {e}")
        # cultivar.namespace = self.namespace_id
        # cultivar.cultivar_class = cultivar_class_id

        try:
            return self.cultivar_client.Create(lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump()))
        except Exception as e:
            logging.error(f"Error creating cultivar: {e}")

    def retrieve(
        self, 
        cultivar_id: str = None,
        cultivar_name: str = None,
        #cultivar_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  cultivar_id is not None:
            try:
                res =  self.cultivar_client.Retrieve(
                    lara_django_organisms_pb2.CultivarRetrieveRequest(cultivar_id=cultivar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving cultivar_id: {e}")

        if cultivar_name is not None:
            filter_list.append({"name": cultivar_name})
        # if cultivar_name_full is not None:
        #     filter_list.append({"name_full": cultivar_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.cultivar_client.List(
                        lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.cultivar_client.List(
                        lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving cultivar_name: {e}")

        return results_list

    def retrieve_id(self, cultivar_name: str = None):
        if cultivar_name is not None:
            filter_dict = {"name": cultivar_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.cultivar_client.List(
                    lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving cultivar_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].cultivar_id
            else:
                raise ValueError(f"Error retrieving cultivar_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.cultivar_client.List(lara_django_organisms_pb2.CultivarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.cultivar_client.List(
                lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.cultivar_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.cultivar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest(), metadata=metadata
            )

    def update(self, cultivar : organisms_dm.Cultivar = None):
        try:
            return self.cultivar_client.Update(
                lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating cultivar_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for cultivar_id in id_list:
            try:
                destroy_list.append( self.cultivar_client.Destroy(
                        lara_django_organisms_pb2.CultivarDestroyRequest(cultivar_id=cultivar_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting cultivar_id: {e}")
        return destroy_list

class OrganismInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organism_class_client = (
        #     lara_django_organisms_pb2_grpc.OrganismclassByIRIControllerStub(channel)
        # )
        
        self.organism_client = lara_django_organisms_pb2_grpc.OrganismControllerStub(channel)

        # self.organism_full_client = lara_django_organisms_pb2_grpc.OrganismFullControllerStub(
        #     channel
        # )

    def create(self,  organism:  organisms_dm.Organism = None, namespace_uri: str = None):
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organism_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #   organism_class_id = self.organism_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrganismclassRetrieveRequest(iri=organism_class_iri)
        #   ).organismclass_id
        # except Exception as e:
        #     logging.error(f"Error retrieving organismclass_id: {e}")
        # organism.namespace = self.namespace_id
        # organism.organism_class = organism_class_id

        try:
            return self.organism_client.Create(lara_django_organisms_pb2.OrganismRequest(**organism.model_dump()))
        except Exception as e:
            logging.error(f"Error creating organism: {e}")

    def retrieve(
        self, 
        organism_id: str = None,
        organism_name: str = None,
        #organism_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ):
        filter_list = []
        results_list = []
        if  organism_id is not None:
            try:
                res =  self.organism_client.Retrieve(
                    lara_django_organisms_pb2.OrganismRetrieveRequest(organism_id=organism_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organism_id: {e}")

        if organism_name is not None:
            filter_list.append({"name": organism_name})
        # if organism_name_full is not None:
        #     filter_list.append({"name_full": organism_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                if raw:
                    results_list +=  self.organism_client.List(
                        lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                    ).results
                else:
                    results_list += [ organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) for res in self.organism_client.List(
                        lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                    ).results ]
            except Exception as e:
                logging.error(f"Error retrieving organism_name: {e}")

        return results_list

    def retrieve_id(self, organism_name: str = None):
        if organism_name is not None:
            filter_dict = {"name": organism_name}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                results = self.organism_client.List(
                    lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                ).results
            except Exception as e:
                logging.error(f"Error retrieving organism_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organism_id
            else:
                raise ValueError(f"Error retrieving organism_id - no or too many results found.")
        
    def list(self, filter_dict: dict = None, ids_only: bool = False):
        if filter_dict is None:
            res = self.organism_client.List(lara_django_organisms_pb2.OrganismListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = self.organism_client.List(
                lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organism_id for item in res.results]
        else:
            return res.results
            

    def list_full(self, filter_dict: dict = None):
        if self.organism_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest(), metadata=metadata
            )

    def update(self, organism : organisms_dm.Organism = None):
        try:
            return self.organism_client.Update(
                lara_django_organisms_pb2.OrganismRequest(**organism.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organism_id: {e}")

    def delete(self, id_list: list = None, filter_dict: dict = None):
        destroy_list = []
        if filter_dict is not None:
            id_list = self.list(filter_dict, ids_only=True)
    
        for organism_id in id_list:
            try:
                destroy_list.append( self.organism_client.Destroy(
                        lara_django_organisms_pb2.OrganismDestroyRequest(organism_id=organism_id)
                ))
            except Exception as e:
                logging.error(f"Error deleting organism_id: {e}")
        return destroy_list

