"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms high_level_interface *

:details: lara_django_organisms high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_grpc.v1.lara_django_organisms_pb2 as lara_django_organisms_pb2
import lara_django_organisms_grpc.v1.lara_django_organisms_pb2_grpc as lara_django_organisms_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, export_file, import_file, id_cache, update_image

import  lara_django_organisms_grpc.lara_django_organisms_data_model as organisms_dm 



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_organisms_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_organisms_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  extradata:  list[organisms_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_organisms_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_organisms_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_organisms_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_organisms_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_organisms_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, extradata : organisms_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_organisms_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_organisms_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  HabitatClass  ______________________


class HabitatClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitatclass_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatClassclassByIRIControllerStub(channel)
        # )
        
        self.habitatclass_client = lara_django_organisms_pb2_grpc.HabitatClassControllerStub(channel)

        # self.habitatclass_full_client = lara_django_organisms_pb2_grpc.HabitatClassFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  habitatclasses:  list[organisms_dm.HabitatClass] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.HabitatClass]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # habitatclassclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitatclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.habitatclass_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatClassclassRetrieveRequest(iri=habitatclass_class_iri)
        #     )
        #     habitatclassclass_id = res.habitatclassclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatclassclass_id: {e}")
        # for habitatclass in habitatclasss:
        #     habitatclass.namespace = self.namespace_id
        #     habitatclass.habitatclass_class = habitatclassclass_id

        try:
            create_coroutines = ( self.habitatclass_client.Create(lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump())) for habitatclass in habitatclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitatclass_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating habitatclass: {e}")

    @export_file
    async def retrieve(
        self, 
        habitatclass_id: str = None,
        habitatclass_name: str = None,
        #habitatclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.HabitatClass]:
        filter_list = []
        results_list = []
        if  habitatclass_id is not None:
            try:
                res =  await self.habitatclass_client.Retrieve(
                    lara_django_organisms_pb2.HabitatClassRetrieveRequest(habitatclass_id=habitatclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_id: {e}")

        if habitatclass_name is not None:
            filter_list.append({"name": habitatclass_name})
        # if habitatclass_name_full is not None:
        #     filter_list.append({"name_full": habitatclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitatclass_client.List(
                        lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.HabitatClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          habitatclass_name: str = None,
                          habitatclass_name_full: str = None,
                          iri: str = None,) -> str:
        if habitatclass_name is not None:
            filter_dict = {"name": habitatclass_name}
        elif habitatclass_name_full is not None:
            filter_dict = {"name_full": habitatclass_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitatclass_client.List(
                    lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving habitatclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitatclass_id
            else:
                raise ValueError(f"Error retrieving habitatclass_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.habitatclass_client.List(lara_django_organisms_pb2.HabitatClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitatclass_client.List(
                lara_django_organisms_pb2.HabitatClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatclass_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.habitatclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitatclass_full_client.List(
                lara_django_organisms_pb2.HabitatClassFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, habitatclass : organisms_dm.HabitatClass = None) -> None:
        try:
            await self.habitatclass_client.Update(
                lara_django_organisms_pb2.HabitatClassRequest(**habitatclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitatclass_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.habitatclass_client.Destroy(lara_django_organisms_pb2.HabitatClassDestroyRequest(habitatclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting habitatclass_id: {e}")

#_________________  HabitatParameter  ______________________


class HabitatParameterInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitatparameter_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatParameterclassByIRIControllerStub(channel)
        # )
        
        self.habitatparameter_client = lara_django_organisms_pb2_grpc.HabitatParameterControllerStub(channel)

        # self.habitatparameter_full_client = lara_django_organisms_pb2_grpc.HabitatParameterFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  habitatparameters:  list[organisms_dm.HabitatParameter] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.HabitatParameter]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # habitatparameterclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitatparameter_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.habitatparameter_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatParameterclassRetrieveRequest(iri=habitatparameter_class_iri)
        #     )
        #     habitatparameterclass_id = res.habitatparameterclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatparameterclass_id: {e}")
        # for habitatparameter in habitatparameters:
        #     habitatparameter.namespace = self.namespace_id
        #     habitatparameter.habitatparameter_class = habitatparameterclass_id

        try:
            create_coroutines = ( self.habitatparameter_client.Create(lara_django_organisms_pb2.HabitatParameterRequest(**habitatparameter.model_dump())) for habitatparameter in habitatparameters )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitatparameter_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating habitatparameter: {e}")

    @export_file
    async def retrieve(
        self, 
        habitatparameter_id: str = None,
        habitatparameter_name: str = None,
        #habitatparameter_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.HabitatParameter]:
        filter_list = []
        results_list = []
        if  habitatparameter_id is not None:
            try:
                res =  await self.habitatparameter_client.Retrieve(
                    lara_django_organisms_pb2.HabitatParameterRetrieveRequest(habitatparameter_id=habitatparameter_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitatparameter_id: {e}")

        if habitatparameter_name is not None:
            filter_list.append({"name": habitatparameter_name})
        # if habitatparameter_name_full is not None:
        #     filter_list.append({"name_full": habitatparameter_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitatparameter_client.List(
                        lara_django_organisms_pb2.HabitatParameterListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.HabitatParameter(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving habitatparameter_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          habitatparameter_name: str = None,
                          habitatparameter_name_full: str = None,
                          iri: str = None,) -> str:
        if habitatparameter_name is not None:
            filter_dict = {"name": habitatparameter_name}
        elif habitatparameter_name_full is not None:
            filter_dict = {"name_full": habitatparameter_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitatparameter_client.List(
                    lara_django_organisms_pb2.HabitatParameterListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving habitatparameter_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitatparameter_id
            else:
                raise ValueError(f"Error retrieving habitatparameter_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.habitatparameter_client.List(lara_django_organisms_pb2.HabitatParameterListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitatparameter_client.List(
                lara_django_organisms_pb2.HabitatParameterListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitatparameter_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.habitatparameter_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitatparameter_full_client.List(
                lara_django_organisms_pb2.HabitatParameterFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitatparameter_full_client.List(
                lara_django_organisms_pb2.HabitatParameterFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, habitatparameter : organisms_dm.HabitatParameter = None) -> None:
        try:
            await self.habitatparameter_client.Update(
                lara_django_organisms_pb2.HabitatParameterRequest(**habitatparameter.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitatparameter_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.habitatparameter_client.Destroy(lara_django_organisms_pb2.HabitatParameterDestroyRequest(habitatparameter_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting habitatparameter_id: {e}")

#_________________  Habitat  ______________________


class HabitatInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.habitat_class_client = (
        #     lara_django_organisms_pb2_grpc.HabitatclassByIRIControllerStub(channel)
        # )
        
        self.habitat_client = lara_django_organisms_pb2_grpc.HabitatControllerStub(channel)

        # self.habitat_full_client = lara_django_organisms_pb2_grpc.HabitatFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  habitats:  list[organisms_dm.Habitat] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Habitat]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # habitatclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if habitat_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.habitat_class_client.Retrieve(
        #         lara_django_organisms_pb2.HabitatclassRetrieveRequest(iri=habitat_class_iri)
        #     )
        #     habitatclass_id = res.habitatclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving habitatclass_id: {e}")
        # for habitat in habitats:
        #     habitat.namespace = self.namespace_id
        #     habitat.habitat_class = habitatclass_id

        try:
            create_coroutines = ( self.habitat_client.Create(lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump())) for habitat in habitats )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.habitat_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating habitat: {e}")

    @export_file
    async def retrieve(
        self, 
        habitat_id: str = None,
        habitat_name: str = None,
        #habitat_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Habitat]:
        filter_list = []
        results_list = []
        if  habitat_id is not None:
            try:
                res =  await self.habitat_client.Retrieve(
                    lara_django_organisms_pb2.HabitatRetrieveRequest(habitat_id=habitat_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving habitat_id: {e}")

        if habitat_name is not None:
            filter_list.append({"name": habitat_name})
        # if habitat_name_full is not None:
        #     filter_list.append({"name_full": habitat_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitat_client.List(
                        lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Habitat(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving habitat_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          habitat_name: str = None,
                          habitat_name_full: str = None,
                          iri: str = None,) -> str:
        if habitat_name is not None:
            filter_dict = {"name": habitat_name}
        elif habitat_name_full is not None:
            filter_dict = {"name_full": habitat_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.habitat_client.List(
                    lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving habitat_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].habitat_id
            else:
                raise ValueError(f"Error retrieving habitat_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.habitat_client.List(lara_django_organisms_pb2.HabitatListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.habitat_client.List(
                lara_django_organisms_pb2.HabitatListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.habitat_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.habitat_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.habitat_full_client.List(
                lara_django_organisms_pb2.HabitatFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, habitat : organisms_dm.Habitat = None) -> None:
        try:
            await self.habitat_client.Update(
                lara_django_organisms_pb2.HabitatRequest(**habitat.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating habitat_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.habitat_client.Destroy(lara_django_organisms_pb2.HabitatDestroyRequest(habitat_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting habitat_id: {e}")

#_________________  Trait  ______________________


class TraitInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.trait_class_client = (
        #     lara_django_organisms_pb2_grpc.TraitclassByIRIControllerStub(channel)
        # )
        
        self.trait_client = lara_django_organisms_pb2_grpc.TraitControllerStub(channel)

        # self.trait_full_client = lara_django_organisms_pb2_grpc.TraitFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  featureclasses:  list[organisms_dm.Trait] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Trait]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # traitclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if trait_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.trait_class_client.Retrieve(
        #         lara_django_organisms_pb2.TraitclassRetrieveRequest(iri=trait_class_iri)
        #     )
        #     traitclass_id = res.traitclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving traitclass_id: {e}")
        # for trait in traits:
        #     trait.namespace = self.namespace_id
        #     trait.trait_class = traitclass_id

        try:
            create_coroutines = ( self.trait_client.Create(lara_django_organisms_pb2.TraitRequest(**trait.model_dump())) for trait in featureclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.trait_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating trait: {e}")

    @export_file
    async def retrieve(
        self, 
        trait_id: str = None,
        trait_name: str = None,
        #trait_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Trait]:
        filter_list = []
        results_list = []
        if  trait_id is not None:
            try:
                res =  await self.trait_client.Retrieve(
                    lara_django_organisms_pb2.TraitRetrieveRequest(trait_id=trait_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving trait_id: {e}")

        if trait_name is not None:
            filter_list.append({"name": trait_name})
        # if trait_name_full is not None:
        #     filter_list.append({"name_full": trait_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.trait_client.List(
                        lara_django_organisms_pb2.TraitListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Trait(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving trait_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          trait_name: str = None,
                          trait_name_full: str = None,
                          iri: str = None,) -> str:
        if trait_name is not None:
            filter_dict = {"name": trait_name}
        elif trait_name_full is not None:
            filter_dict = {"name_full": trait_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.trait_client.List(
                    lara_django_organisms_pb2.TraitListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving trait_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].trait_id
            else:
                raise ValueError(f"Error retrieving trait_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.trait_client.List(lara_django_organisms_pb2.TraitListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.trait_client.List(
                lara_django_organisms_pb2.TraitListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.trait_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.trait_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.trait_full_client.List(
                lara_django_organisms_pb2.TraitFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.trait_full_client.List(
                lara_django_organisms_pb2.TraitFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, trait : organisms_dm.Trait = None) -> None:
        try:
            await self.trait_client.Update(
                lara_django_organisms_pb2.TraitRequest(**trait.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating trait_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.trait_client.Destroy(lara_django_organisms_pb2.TraitDestroyRequest(trait_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting trait_id: {e}")

#_________________  Domain  ______________________


class DomainInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.domain_class_client = (
        #     lara_django_organisms_pb2_grpc.DomainclassByIRIControllerStub(channel)
        # )
        
        self.domain_client = lara_django_organisms_pb2_grpc.DomainControllerStub(channel)

        # self.domain_full_client = lara_django_organisms_pb2_grpc.DomainFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  domains:  list[organisms_dm.Domain] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Domain]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # domainclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if domain_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.domain_class_client.Retrieve(
        #         lara_django_organisms_pb2.DomainclassRetrieveRequest(iri=domain_class_iri)
        #     )
        #     domainclass_id = res.domainclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving domainclass_id: {e}")
        # for domain in domains:
        #     domain.namespace = self.namespace_id
        #     domain.domain_class = domainclass_id

        try:
            create_coroutines = ( self.domain_client.Create(lara_django_organisms_pb2.DomainRequest(**domain.model_dump())) for domain in domains )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.domain_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating domain: {e}")

    @export_file
    async def retrieve(
        self, 
        domain_id: str = None,
        domain_name: str = None,
        #domain_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Domain]:
        filter_list = []
        results_list = []
        if  domain_id is not None:
            try:
                res =  await self.domain_client.Retrieve(
                    lara_django_organisms_pb2.DomainRetrieveRequest(domain_id=domain_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving domain_id: {e}")

        if domain_name is not None:
            filter_list.append({"name": domain_name})
        # if domain_name_full is not None:
        #     filter_list.append({"name_full": domain_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.domain_client.List(
                        lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Domain(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving domain_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          domain_name: str = None,
                          domain_name_full: str = None,
                          iri: str = None,) -> str:
        if domain_name is not None:
            filter_dict = {"name": domain_name}
        elif domain_name_full is not None:
            filter_dict = {"name_full": domain_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.domain_client.List(
                    lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving domain_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].domain_id
            else:
                raise ValueError(f"Error retrieving domain_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.domain_client.List(lara_django_organisms_pb2.DomainListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.domain_client.List(
                lara_django_organisms_pb2.DomainListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.domain_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.domain_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.domain_full_client.List(
                lara_django_organisms_pb2.DomainFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, domain : organisms_dm.Domain = None) -> None:
        try:
            await self.domain_client.Update(
                lara_django_organisms_pb2.DomainRequest(**domain.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating domain_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.domain_client.Destroy(lara_django_organisms_pb2.DomainDestroyRequest(domain_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting domain_id: {e}")

#_________________  Regnum  ______________________


class RegnumInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.regnum_class_client = (
        #     lara_django_organisms_pb2_grpc.RegnumclassByIRIControllerStub(channel)
        # )
        
        self.regnum_client = lara_django_organisms_pb2_grpc.RegnumControllerStub(channel)

        # self.regnum_full_client = lara_django_organisms_pb2_grpc.RegnumFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  regna:  list[organisms_dm.Regnum] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Regnum]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # regnumclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if regnum_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.regnum_class_client.Retrieve(
        #         lara_django_organisms_pb2.RegnumclassRetrieveRequest(iri=regnum_class_iri)
        #     )
        #     regnumclass_id = res.regnumclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving regnumclass_id: {e}")
        # for regnum in regnums:
        #     regnum.namespace = self.namespace_id
        #     regnum.regnum_class = regnumclass_id

        try:
            create_coroutines = ( self.regnum_client.Create(lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump())) for regnum in regna )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.regnum_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating regnum: {e}")

    @export_file
    async def retrieve(
        self, 
        regnum_id: str = None,
        regnum_name: str = None,
        #regnum_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Regnum]:
        filter_list = []
        results_list = []
        if  regnum_id is not None:
            try:
                res =  await self.regnum_client.Retrieve(
                    lara_django_organisms_pb2.RegnumRetrieveRequest(regnum_id=regnum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving regnum_id: {e}")

        if regnum_name is not None:
            filter_list.append({"name": regnum_name})
        # if regnum_name_full is not None:
        #     filter_list.append({"name_full": regnum_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.regnum_client.List(
                        lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Regnum(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving regnum_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          regnum_name: str = None,
                          regnum_name_full: str = None,
                          iri: str = None,) -> str:
        if regnum_name is not None:
            filter_dict = {"name": regnum_name}
        elif regnum_name_full is not None:
            filter_dict = {"name_full": regnum_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.regnum_client.List(
                    lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving regnum_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].regnum_id
            else:
                raise ValueError(f"Error retrieving regnum_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.regnum_client.List(lara_django_organisms_pb2.RegnumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.regnum_client.List(
                lara_django_organisms_pb2.RegnumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.regnum_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.regnum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.regnum_full_client.List(
                lara_django_organisms_pb2.RegnumFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, regnum : organisms_dm.Regnum = None) -> None:
        try:
            await self.regnum_client.Update(
                lara_django_organisms_pb2.RegnumRequest(**regnum.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating regnum_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.regnum_client.Destroy(lara_django_organisms_pb2.RegnumDestroyRequest(regnum_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting regnum_id: {e}")

#_________________  Phylum  ______________________


class PhylumInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.phylum_class_client = (
        #     lara_django_organisms_pb2_grpc.PhylumclassByIRIControllerStub(channel)
        # )
        
        self.phylum_client = lara_django_organisms_pb2_grpc.PhylumControllerStub(channel)

        # self.phylum_full_client = lara_django_organisms_pb2_grpc.PhylumFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  phyla:  list[organisms_dm.Phylum] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Phylum]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # phylumclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if phylum_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.phylum_class_client.Retrieve(
        #         lara_django_organisms_pb2.PhylumclassRetrieveRequest(iri=phylum_class_iri)
        #     )
        #     phylumclass_id = res.phylumclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving phylumclass_id: {e}")
        # for phylum in phylums:
        #     phylum.namespace = self.namespace_id
        #     phylum.phylum_class = phylumclass_id

        try:
            create_coroutines = ( self.phylum_client.Create(lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump())) for phylum in phyla )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.phylum_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating phylum: {e}")

    @export_file
    async def retrieve(
        self, 
        phylum_id: str = None,
        phylum_name: str = None,
        #phylum_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Phylum]:
        filter_list = []
        results_list = []
        if  phylum_id is not None:
            try:
                res =  await self.phylum_client.Retrieve(
                    lara_django_organisms_pb2.PhylumRetrieveRequest(phylum_id=phylum_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving phylum_id: {e}")

        if phylum_name is not None:
            filter_list.append({"name": phylum_name})
        # if phylum_name_full is not None:
        #     filter_list.append({"name_full": phylum_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.phylum_client.List(
                        lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Phylum(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving phylum_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          phylum_name: str = None,
                          phylum_name_full: str = None,
                          iri: str = None,) -> str:
        if phylum_name is not None:
            filter_dict = {"name": phylum_name}
        elif phylum_name_full is not None:
            filter_dict = {"name_full": phylum_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.phylum_client.List(
                    lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving phylum_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].phylum_id
            else:
                raise ValueError(f"Error retrieving phylum_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.phylum_client.List(lara_django_organisms_pb2.PhylumListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.phylum_client.List(
                lara_django_organisms_pb2.PhylumListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.phylum_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.phylum_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.phylum_full_client.List(
                lara_django_organisms_pb2.PhylumFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, phylum : organisms_dm.Phylum = None) -> None:
        try:
            await self.phylum_client.Update(
                lara_django_organisms_pb2.PhylumRequest(**phylum.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating phylum_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.phylum_client.Destroy(lara_django_organisms_pb2.PhylumDestroyRequest(phylum_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting phylum_id: {e}")

#_________________  Classis  ______________________


class ClassisInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.classis_class_client = (
        #     lara_django_organisms_pb2_grpc.ClassisclassByIRIControllerStub(channel)
        # )
        
        self.classis_client = lara_django_organisms_pb2_grpc.ClassisControllerStub(channel)

        # self.classis_full_client = lara_django_organisms_pb2_grpc.ClassisFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  classes:  list[organisms_dm.Classis] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Classis]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # classisclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if classis_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.classis_class_client.Retrieve(
        #         lara_django_organisms_pb2.ClassisclassRetrieveRequest(iri=classis_class_iri)
        #     )
        #     classisclass_id = res.classisclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving classisclass_id: {e}")
        # for classis in classiss:
        #     classis.namespace = self.namespace_id
        #     classis.classis_class = classisclass_id

        try:
            create_coroutines = ( self.classis_client.Create(lara_django_organisms_pb2.ClassisRequest(**classis.model_dump())) for classis in classes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.classis_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating classis: {e}")

    @export_file
    async def retrieve(
        self, 
        classis_id: str = None,
        classis_name: str = None,
        #classis_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Classis]:
        filter_list = []
        results_list = []
        if  classis_id is not None:
            try:
                res =  await self.classis_client.Retrieve(
                    lara_django_organisms_pb2.ClassisRetrieveRequest(classis_id=classis_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving classis_id: {e}")

        if classis_name is not None:
            filter_list.append({"name": classis_name})
        # if classis_name_full is not None:
        #     filter_list.append({"name_full": classis_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.classis_client.List(
                        lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Classis(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving classis_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          classis_name: str = None,
                          classis_name_full: str = None,
                          iri: str = None,) -> str:
        if classis_name is not None:
            filter_dict = {"name": classis_name}
        elif classis_name_full is not None:
            filter_dict = {"name_full": classis_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.classis_client.List(
                    lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving classis_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].classis_id
            else:
                raise ValueError(f"Error retrieving classis_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.classis_client.List(lara_django_organisms_pb2.ClassisListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.classis_client.List(
                lara_django_organisms_pb2.ClassisListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.classis_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.classis_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.classis_full_client.List(
                lara_django_organisms_pb2.ClassisFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, classis : organisms_dm.Classis = None) -> None:
        try:
            await self.classis_client.Update(
                lara_django_organisms_pb2.ClassisRequest(**classis.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating classis_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.classis_client.Destroy(lara_django_organisms_pb2.ClassisDestroyRequest(classis_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting classis_id: {e}")

#_________________  Ordo  ______________________


class OrdoInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.ordo_class_client = (
        #     lara_django_organisms_pb2_grpc.OrdoclassByIRIControllerStub(channel)
        # )
        
        self.ordo_client = lara_django_organisms_pb2_grpc.OrdoControllerStub(channel)

        # self.ordo_full_client = lara_django_organisms_pb2_grpc.OrdoFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  ordae:  list[organisms_dm.Ordo] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Ordo]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # ordoclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if ordo_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.ordo_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrdoclassRetrieveRequest(iri=ordo_class_iri)
        #     )
        #     ordoclass_id = res.ordoclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving ordoclass_id: {e}")
        # for ordo in ordos:
        #     ordo.namespace = self.namespace_id
        #     ordo.ordo_class = ordoclass_id

        try:
            create_coroutines = ( self.ordo_client.Create(lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump())) for ordo in ordae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.ordo_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating ordo: {e}")

    @export_file
    async def retrieve(
        self, 
        ordo_id: str = None,
        ordo_name: str = None,
        #ordo_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Ordo]:
        filter_list = []
        results_list = []
        if  ordo_id is not None:
            try:
                res =  await self.ordo_client.Retrieve(
                    lara_django_organisms_pb2.OrdoRetrieveRequest(ordo_id=ordo_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving ordo_id: {e}")

        if ordo_name is not None:
            filter_list.append({"name": ordo_name})
        # if ordo_name_full is not None:
        #     filter_list.append({"name_full": ordo_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.ordo_client.List(
                        lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Ordo(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving ordo_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          ordo_name: str = None,
                          ordo_name_full: str = None,
                          iri: str = None,) -> str:
        if ordo_name is not None:
            filter_dict = {"name": ordo_name}
        elif ordo_name_full is not None:
            filter_dict = {"name_full": ordo_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.ordo_client.List(
                    lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving ordo_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].ordo_id
            else:
                raise ValueError(f"Error retrieving ordo_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.ordo_client.List(lara_django_organisms_pb2.OrdoListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.ordo_client.List(
                lara_django_organisms_pb2.OrdoListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.ordo_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.ordo_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.ordo_full_client.List(
                lara_django_organisms_pb2.OrdoFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, ordo : organisms_dm.Ordo = None) -> None:
        try:
            await self.ordo_client.Update(
                lara_django_organisms_pb2.OrdoRequest(**ordo.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating ordo_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.ordo_client.Destroy(lara_django_organisms_pb2.OrdoDestroyRequest(ordo_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting ordo_id: {e}")

#_________________  Familia  ______________________


class FamiliaInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.familia_class_client = (
        #     lara_django_organisms_pb2_grpc.FamiliaclassByIRIControllerStub(channel)
        # )
        
        self.familia_client = lara_django_organisms_pb2_grpc.FamiliaControllerStub(channel)

        # self.familia_full_client = lara_django_organisms_pb2_grpc.FamiliaFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  familiae:  list[organisms_dm.Familia] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Familia]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # familiaclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if familia_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.familia_class_client.Retrieve(
        #         lara_django_organisms_pb2.FamiliaclassRetrieveRequest(iri=familia_class_iri)
        #     )
        #     familiaclass_id = res.familiaclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving familiaclass_id: {e}")
        # for familia in familias:
        #     familia.namespace = self.namespace_id
        #     familia.familia_class = familiaclass_id

        try:
            create_coroutines = ( self.familia_client.Create(lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump())) for familia in familiae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.familia_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating familia: {e}")

    @export_file
    async def retrieve(
        self, 
        familia_id: str = None,
        familia_name: str = None,
        #familia_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Familia]:
        filter_list = []
        results_list = []
        if  familia_id is not None:
            try:
                res =  await self.familia_client.Retrieve(
                    lara_django_organisms_pb2.FamiliaRetrieveRequest(familia_id=familia_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving familia_id: {e}")

        if familia_name is not None:
            filter_list.append({"name": familia_name})
        # if familia_name_full is not None:
        #     filter_list.append({"name_full": familia_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.familia_client.List(
                        lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Familia(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving familia_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          familia_name: str = None,
                          familia_name_full: str = None,
                          iri: str = None,) -> str:
        if familia_name is not None:
            filter_dict = {"name": familia_name}
        elif familia_name_full is not None:
            filter_dict = {"name_full": familia_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.familia_client.List(
                    lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving familia_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].familia_id
            else:
                raise ValueError(f"Error retrieving familia_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.familia_client.List(lara_django_organisms_pb2.FamiliaListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.familia_client.List(
                lara_django_organisms_pb2.FamiliaListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.familia_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.familia_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.familia_full_client.List(
                lara_django_organisms_pb2.FamiliaFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, familia : organisms_dm.Familia = None) -> None:
        try:
            await self.familia_client.Update(
                lara_django_organisms_pb2.FamiliaRequest(**familia.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating familia_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.familia_client.Destroy(lara_django_organisms_pb2.FamiliaDestroyRequest(familia_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting familia_id: {e}")

#_________________  Genus  ______________________


class GenusInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.genus_class_client = (
        #     lara_django_organisms_pb2_grpc.GenusclassByIRIControllerStub(channel)
        # )
        
        self.genus_client = lara_django_organisms_pb2_grpc.GenusControllerStub(channel)

        # self.genus_full_client = lara_django_organisms_pb2_grpc.GenusFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  genera:  list[organisms_dm.Genus] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Genus]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # genusclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if genus_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.genus_class_client.Retrieve(
        #         lara_django_organisms_pb2.GenusclassRetrieveRequest(iri=genus_class_iri)
        #     )
        #     genusclass_id = res.genusclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving genusclass_id: {e}")
        # for genus in genuss:
        #     genus.namespace = self.namespace_id
        #     genus.genus_class = genusclass_id

        try:
            create_coroutines = ( self.genus_client.Create(lara_django_organisms_pb2.GenusRequest(**genus.model_dump())) for genus in genera )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.genus_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating genus: {e}")

    @export_file
    async def retrieve(
        self, 
        genus_id: str = None,
        genus_name: str = None,
        #genus_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Genus]:
        filter_list = []
        results_list = []
        if  genus_id is not None:
            try:
                res =  await self.genus_client.Retrieve(
                    lara_django_organisms_pb2.GenusRetrieveRequest(genus_id=genus_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving genus_id: {e}")

        if genus_name is not None:
            filter_list.append({"name": genus_name})
        # if genus_name_full is not None:
        #     filter_list.append({"name_full": genus_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.genus_client.List(
                        lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Genus(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving genus_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          genus_name: str = None,
                          genus_name_full: str = None,
                          iri: str = None,) -> str:
        if genus_name is not None:
            filter_dict = {"name": genus_name}
        elif genus_name_full is not None:
            filter_dict = {"name_full": genus_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.genus_client.List(
                    lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving genus_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].genus_id
            else:
                raise ValueError(f"Error retrieving genus_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.genus_client.List(lara_django_organisms_pb2.GenusListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.genus_client.List(
                lara_django_organisms_pb2.GenusListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.genus_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.genus_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.genus_full_client.List(
                lara_django_organisms_pb2.GenusFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, genus : organisms_dm.Genus = None) -> None:
        try:
            await self.genus_client.Update(
                lara_django_organisms_pb2.GenusRequest(**genus.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating genus_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.genus_client.Destroy(lara_django_organisms_pb2.GenusDestroyRequest(genus_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting genus_id: {e}")

#_________________  Species  ______________________


class SpeciesInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.species_class_client = (
        #     lara_django_organisms_pb2_grpc.SpeciesclassByIRIControllerStub(channel)
        # )
        
        self.species_client = lara_django_organisms_pb2_grpc.SpeciesControllerStub(channel)

        # self.species_full_client = lara_django_organisms_pb2_grpc.SpeciesFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  speciae:  list[organisms_dm.Species] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Species]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # speciesclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if species_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.species_class_client.Retrieve(
        #         lara_django_organisms_pb2.SpeciesclassRetrieveRequest(iri=species_class_iri)
        #     )
        #     speciesclass_id = res.speciesclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving speciesclass_id: {e}")
        # for species in speciess:
        #     species.namespace = self.namespace_id
        #     species.species_class = speciesclass_id

        try:
            create_coroutines = ( self.species_client.Create(lara_django_organisms_pb2.SpeciesRequest(**species.model_dump())) for species in speciae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.species_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating species: {e}")

    @export_file
    async def retrieve(
        self, 
        species_id: str = None,
        species_name: str = None,
        #species_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Species]:
        filter_list = []
        results_list = []
        if  species_id is not None:
            try:
                res =  await self.species_client.Retrieve(
                    lara_django_organisms_pb2.SpeciesRetrieveRequest(species_id=species_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving species_id: {e}")

        if species_name is not None:
            filter_list.append({"name": species_name})
        # if species_name_full is not None:
        #     filter_list.append({"name_full": species_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.species_client.List(
                        lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Species(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving species_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          species_name: str = None,
                          species_name_full: str = None,
                          iri: str = None,) -> str:
        if species_name is not None:
            filter_dict = {"name": species_name}
        elif species_name_full is not None:
            filter_dict = {"name_full": species_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.species_client.List(
                    lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving species_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].species_id
            else:
                raise ValueError(f"Error retrieving species_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.species_client.List(lara_django_organisms_pb2.SpeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.species_client.List(
                lara_django_organisms_pb2.SpeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.species_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.species_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.species_full_client.List(
                lara_django_organisms_pb2.SpeciesFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, species : organisms_dm.Species = None) -> None:
        try:
            await self.species_client.Update(
                lara_django_organisms_pb2.SpeciesRequest(**species.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating species_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.species_client.Destroy(lara_django_organisms_pb2.SpeciesDestroyRequest(species_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting species_id: {e}")

#_________________  Subspecies  ______________________


class SubspeciesInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.subspecies_class_client = (
        #     lara_django_organisms_pb2_grpc.SubspeciesclassByIRIControllerStub(channel)
        # )
        
        self.subspecies_client = lara_django_organisms_pb2_grpc.SubspeciesControllerStub(channel)

        # self.subspecies_full_client = lara_django_organisms_pb2_grpc.SubspeciesFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  subspecieae:  list[organisms_dm.Subspecies] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Subspecies]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # subspeciesclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if subspecies_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.subspecies_class_client.Retrieve(
        #         lara_django_organisms_pb2.SubspeciesclassRetrieveRequest(iri=subspecies_class_iri)
        #     )
        #     subspeciesclass_id = res.subspeciesclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving subspeciesclass_id: {e}")
        # for subspecies in subspeciess:
        #     subspecies.namespace = self.namespace_id
        #     subspecies.subspecies_class = subspeciesclass_id

        try:
            create_coroutines = ( self.subspecies_client.Create(lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump())) for subspecies in subspecieae )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.subspecies_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating subspecies: {e}")

    @export_file
    async def retrieve(
        self, 
        subspecies_id: str = None,
        subspecies_name: str = None,
        #subspecies_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Subspecies]:
        filter_list = []
        results_list = []
        if  subspecies_id is not None:
            try:
                res =  await self.subspecies_client.Retrieve(
                    lara_django_organisms_pb2.SubspeciesRetrieveRequest(subspecies_id=subspecies_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving subspecies_id: {e}")

        if subspecies_name is not None:
            filter_list.append({"name": subspecies_name})
        # if subspecies_name_full is not None:
        #     filter_list.append({"name_full": subspecies_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.subspecies_client.List(
                        lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Subspecies(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving subspecies_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          subspecies_name: str = None,
                          subspecies_name_full: str = None,
                          iri: str = None,) -> str:
        if subspecies_name is not None:
            filter_dict = {"name": subspecies_name}
        elif subspecies_name_full is not None:
            filter_dict = {"name_full": subspecies_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.subspecies_client.List(
                    lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving subspecies_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].subspecies_id
            else:
                raise ValueError(f"Error retrieving subspecies_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.subspecies_client.List(lara_django_organisms_pb2.SubspeciesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.subspecies_client.List(
                lara_django_organisms_pb2.SubspeciesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.subspecies_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.subspecies_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.subspecies_full_client.List(
                lara_django_organisms_pb2.SubspeciesFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, subspecies : organisms_dm.Subspecies = None) -> None:
        try:
            await self.subspecies_client.Update(
                lara_django_organisms_pb2.SubspeciesRequest(**subspecies.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating subspecies_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.subspecies_client.Destroy(lara_django_organisms_pb2.SubspeciesDestroyRequest(subspecies_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting subspecies_id: {e}")

#_________________  Variant  ______________________


class VariantInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.variant_class_client = (
        #     lara_django_organisms_pb2_grpc.VariantclassByIRIControllerStub(channel)
        # )
        
        self.variant_client = lara_django_organisms_pb2_grpc.VariantControllerStub(channel)

        # self.variant_full_client = lara_django_organisms_pb2_grpc.VariantFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  variants:  list[organisms_dm.Variant] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Variant]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # variantclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if variant_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.variant_class_client.Retrieve(
        #         lara_django_organisms_pb2.VariantclassRetrieveRequest(iri=variant_class_iri)
        #     )
        #     variantclass_id = res.variantclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving variantclass_id: {e}")
        # for variant in variants:
        #     variant.namespace = self.namespace_id
        #     variant.variant_class = variantclass_id

        try:
            create_coroutines = ( self.variant_client.Create(lara_django_organisms_pb2.VariantRequest(**variant.model_dump())) for variant in variants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.variant_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating variant: {e}")

    @export_file
    async def retrieve(
        self, 
        variant_id: str = None,
        variant_name: str = None,
        #variant_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Variant]:
        filter_list = []
        results_list = []
        if  variant_id is not None:
            try:
                res =  await self.variant_client.Retrieve(
                    lara_django_organisms_pb2.VariantRetrieveRequest(variant_id=variant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving variant_id: {e}")

        if variant_name is not None:
            filter_list.append({"name": variant_name})
        # if variant_name_full is not None:
        #     filter_list.append({"name_full": variant_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.variant_client.List(
                        lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Variant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving variant_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          variant_name: str = None,
                          variant_name_full: str = None,
                          iri: str = None,) -> str:
        if variant_name is not None:
            filter_dict = {"name": variant_name}
        elif variant_name_full is not None:
            filter_dict = {"name_full": variant_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.variant_client.List(
                    lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving variant_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].variant_id
            else:
                raise ValueError(f"Error retrieving variant_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.variant_client.List(lara_django_organisms_pb2.VariantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.variant_client.List(
                lara_django_organisms_pb2.VariantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.variant_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.variant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.variant_full_client.List(
                lara_django_organisms_pb2.VariantFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, variant : organisms_dm.Variant = None) -> None:
        try:
            await self.variant_client.Update(
                lara_django_organisms_pb2.VariantRequest(**variant.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating variant_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.variant_client.Destroy(lara_django_organisms_pb2.VariantDestroyRequest(variant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting variant_id: {e}")

#_________________  Cultivar  ______________________


class CultivarInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.cultivar_class_client = (
        #     lara_django_organisms_pb2_grpc.CultivarclassByIRIControllerStub(channel)
        # )
        
        self.cultivar_client = lara_django_organisms_pb2_grpc.CultivarControllerStub(channel)

        # self.cultivar_full_client = lara_django_organisms_pb2_grpc.CultivarFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  cultivars:  list[organisms_dm.Cultivar] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Cultivar]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # cultivarclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if cultivar_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.cultivar_class_client.Retrieve(
        #         lara_django_organisms_pb2.CultivarclassRetrieveRequest(iri=cultivar_class_iri)
        #     )
        #     cultivarclass_id = res.cultivarclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving cultivarclass_id: {e}")
        # for cultivar in cultivars:
        #     cultivar.namespace = self.namespace_id
        #     cultivar.cultivar_class = cultivarclass_id

        try:
            create_coroutines = ( self.cultivar_client.Create(lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump())) for cultivar in cultivars )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.cultivar_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating cultivar: {e}")

    @export_file
    async def retrieve(
        self, 
        cultivar_id: str = None,
        cultivar_name: str = None,
        #cultivar_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Cultivar]:
        filter_list = []
        results_list = []
        if  cultivar_id is not None:
            try:
                res =  await self.cultivar_client.Retrieve(
                    lara_django_organisms_pb2.CultivarRetrieveRequest(cultivar_id=cultivar_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving cultivar_id: {e}")

        if cultivar_name is not None:
            filter_list.append({"name": cultivar_name})
        # if cultivar_name_full is not None:
        #     filter_list.append({"name_full": cultivar_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.cultivar_client.List(
                        lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Cultivar(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving cultivar_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          cultivar_name: str = None,
                          cultivar_name_full: str = None,
                          iri: str = None,) -> str:
        if cultivar_name is not None:
            filter_dict = {"name": cultivar_name}
        elif cultivar_name_full is not None:
            filter_dict = {"name_full": cultivar_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.cultivar_client.List(
                    lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving cultivar_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].cultivar_id
            else:
                raise ValueError(f"Error retrieving cultivar_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.cultivar_client.List(lara_django_organisms_pb2.CultivarListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.cultivar_client.List(
                lara_django_organisms_pb2.CultivarListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.cultivar_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.cultivar_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.cultivar_full_client.List(
                lara_django_organisms_pb2.CultivarFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, cultivar : organisms_dm.Cultivar = None) -> None:
        try:
            await self.cultivar_client.Update(
                lara_django_organisms_pb2.CultivarRequest(**cultivar.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating cultivar_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.cultivar_client.Destroy(lara_django_organisms_pb2.CultivarDestroyRequest(cultivar_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting cultivar_id: {e}")

#_________________  Organism  ______________________


class OrganismInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organism_class_client = (
        #     lara_django_organisms_pb2_grpc.OrganismclassByIRIControllerStub(channel)
        # )
        
        self.organism_client = lara_django_organisms_pb2_grpc.OrganismControllerStub(channel)

        # self.organism_full_client = lara_django_organisms_pb2_grpc.OrganismFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organisms:  list[organisms_dm.Organism] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.Organism]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organism_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organism_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrganismclassRetrieveRequest(iri=organism_class_iri)
        #     )
        #     organismclass_id = res.organismclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismclass_id: {e}")
        # for organism in organisms:
        #     organism.namespace = self.namespace_id
        #     organism.organism_class = organismclass_id

        try:
            create_coroutines = ( self.organism_client.Create(lara_django_organisms_pb2.OrganismRequest(**organism.model_dump())) for organism in organisms )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organism_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organism: {e}")

    @export_file
    async def retrieve(
        self, 
        organism_id: str = None,
        organism_name: str = None,
        #organism_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.Organism]:
        filter_list = []
        results_list = []
        if  organism_id is not None:
            try:
                res =  await self.organism_client.Retrieve(
                    lara_django_organisms_pb2.OrganismRetrieveRequest(organism_id=organism_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organism_id: {e}")

        if organism_name is not None:
            filter_list.append({"name": organism_name})
        # if organism_name_full is not None:
        #     filter_list.append({"name_full": organism_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organism_client.List(
                        lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.Organism(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organism_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organism_name: str = None,
                          organism_name_full: str = None,
                          iri: str = None,) -> str:
        if organism_name is not None:
            filter_dict = {"name": organism_name}
        elif organism_name_full is not None:
            filter_dict = {"name_full": organism_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organism_client.List(
                    lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organism_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organism_id
            else:
                raise ValueError(f"Error retrieving organism_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organism_client.List(lara_django_organisms_pb2.OrganismListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organism_client.List(
                lara_django_organisms_pb2.OrganismListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organism_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organism_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organism_full_client.List(
                lara_django_organisms_pb2.OrganismFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organism : organisms_dm.Organism = None) -> None:
        try:
            await self.organism_client.Update(
                lara_django_organisms_pb2.OrganismRequest(**organism.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organism_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organism_client.Destroy(lara_django_organisms_pb2.OrganismDestroyRequest(organism_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organism_id: {e}")

#_________________  OrganismsSubset  ______________________


class OrganismsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismssubset_class_client = (
        #     lara_django_organisms_pb2_grpc.OrganismsSubsetclassByIRIControllerStub(channel)
        # )
        
        self.organismssubset_client = lara_django_organisms_pb2_grpc.OrganismsSubsetControllerStub(channel)

        # self.organismssubset_full_client = lara_django_organisms_pb2_grpc.OrganismsSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismssubsets:  list[organisms_dm.OrganismsSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_dm.OrganismsSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismssubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismssubset_class_client.Retrieve(
        #         lara_django_organisms_pb2.OrganismsSubsetclassRetrieveRequest(iri=organismssubset_class_iri)
        #     )
        #     organismssubsetclass_id = res.organismssubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismssubsetclass_id: {e}")
        # for organismssubset in organismssubsets:
        #     organismssubset.namespace = self.namespace_id
        #     organismssubset.organismssubset_class = organismssubsetclass_id

        try:
            create_coroutines = ( self.organismssubset_client.Create(lara_django_organisms_pb2.OrganismsSubsetRequest(**organismssubset.model_dump())) for organismssubset in organismssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismssubset: {e}")

    @export_file
    async def retrieve(
        self, 
        organismssubset_id: str = None,
        organismssubset_name: str = None,
        #organismssubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_dm.OrganismsSubset]:
        filter_list = []
        results_list = []
        if  organismssubset_id is not None:
            try:
                res =  await self.organismssubset_client.Retrieve(
                    lara_django_organisms_pb2.OrganismsSubsetRetrieveRequest(organismssubset_id=organismssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_dm.OrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismssubset_id: {e}")

        if organismssubset_name is not None:
            filter_list.append({"name": organismssubset_name})
        # if organismssubset_name_full is not None:
        #     filter_list.append({"name_full": organismssubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismssubset_client.List(
                        lara_django_organisms_pb2.OrganismsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_dm.OrganismsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismssubset_name: str = None,
                          organismssubset_name_full: str = None,
                          iri: str = None,) -> str:
        if organismssubset_name is not None:
            filter_dict = {"name": organismssubset_name}
        elif organismssubset_name_full is not None:
            filter_dict = {"name_full": organismssubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismssubset_client.List(
                    lara_django_organisms_pb2.OrganismsSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismssubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismssubset_id
            else:
                raise ValueError(f"Error retrieving organismssubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismssubset_client.List(lara_django_organisms_pb2.OrganismsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismssubset_client.List(
                lara_django_organisms_pb2.OrganismsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismssubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismssubset_full_client.List(
                lara_django_organisms_pb2.OrganismsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismssubset_full_client.List(
                lara_django_organisms_pb2.OrganismsSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismssubset : organisms_dm.OrganismsSubset = None) -> None:
        try:
            await self.organismssubset_client.Update(
                lara_django_organisms_pb2.OrganismsSubsetRequest(**organismssubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismssubset_client.Destroy(lara_django_organisms_pb2.OrganismsSubsetDestroyRequest(organismssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismssubset_id: {e}")

