# lara_django_organisms_grpc

gRPC interface for lara_django_organisms - A Django-based biological organisms data management system.

## Overview

This package provides a gRPC API layer for the lara_django_organisms project, enabling efficient remote procedure calls for managing organism taxonomic data including domains, kingdoms, phyla, classes, orders, families, genera, species, and cultivars.

## Installation

```bash
pip install lara_django_organisms_grpc
```

Or with uv:

```bash
uv add lara_django_organisms_grpc
```

## Features

- High-performance gRPC interface for organism data operations
- Protocol buffer definitions for structured data exchange
- Support for CRUD operations on taxonomic entities
- Efficient streaming for bulk data operations

## Requirements

- Python 3.13
- grpcio >= 1.73.0

## Development

To install development dependencies:

```bash
uv sync --group dev
```

Run tests:

```bash
pytest
```

## Documentation

Full documentation is available at: https://larasuite.gitlab.io/lara-django-organisms/

## Source

Source code: https://gitlab.com/larasuite/lara-django-organisms

## License

See the main project for license information.
