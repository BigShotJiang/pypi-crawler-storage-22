"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store app *

:details: lara_django_organisms_store app configuration.
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.apps import AppConfig


class LaraDjangoOrganismsStoreConfig(AppConfig):
    name = "lara_django_organisms_store"
    url_path = "organisms-store/"
    # enter a verbose name for your app: lara_django_organisms_store here - this will be used in the admin interface
    verbose_name = "LARA-django Organisms Store"
    # lara_app_icon = 'lara_django_organisms_store_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = "green"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_stor_color = "lime"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_icon = "lara_material_icon.svg"
    verbose_name_short = "Organisms"
    lara_app_description = "Organisms and Organism Store"
    lara_class_apps = [
        {
            "name": "Organisms",
            "path": "lara_django_organisms:organism-list",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Habitats",
            "path": "lara_django_organisms:organism-list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
    ]
    lara_instance_apps = [
        {
            "name": "Organisms Store",
            "path": "lara_django_organisms_store:organism-list",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Habitats Store",
            "path": "lara_django_organisms_store:organism-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
    ]

    def ready(self):
        # add urlpatterns
        from django.urls import include
        from django.urls import path
        from lara_django.urls import urlpatterns

        urlpatterns += [
            path(self.url_path, include("lara_django_organisms_store.urls", namespace="lara_django_organisms_store")),
        ]
