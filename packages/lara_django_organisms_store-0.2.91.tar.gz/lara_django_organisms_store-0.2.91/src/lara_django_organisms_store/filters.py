"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app. 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django_filters.rest_framework import FilterSet, CharFilter, DateRangeFilter

from .models import ExtraData, OrganismInstance


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class OrganismInstanceFilterSet(FilterSet):
    class Meta:
        model = OrganismInstance
        fields = {
            "name": ["exact", "contains"],
            "datetime_manufacturing": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_end_of_warranty": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_delivery": ["lt", "gt", "exact", "range"],
            "barcode": ["exact", "contains"],
            "registration_no": ["exact", "contains"],
            "serial_no": ["exact", "contains"],
            "service_no": ["exact", "contains"],
            "price": ["lt", "gt", "exact", "range"],
            "pid": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "description": ["exact", "contains"],
        }
