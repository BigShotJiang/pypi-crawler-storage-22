"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store admin *

:details: lara_django_organisms_store admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_organisms_store > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Row, Column

from .models import (
    ExtraData,
    OrganismInstance,
    OrganismOrderItem,
    OrganismWishlist,
    OrganismBasket,
    OrganismOrder,
    OrganismsLocalStore,
)


class ExtraDataCreateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            Submit("submit", "Create"),
        )


class ExtraDataUpdateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            Submit("submit", "Update"),
        )


class OrganismInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismInstance
        fields = (
            "namespace",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "image",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "image",
            "resources_external",
            Submit("submit", "Create"),
        )


class OrganismInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismInstance
        fields = (
            "namespace",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "image",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "organism",
            "image",
            "resources_external",
            Submit("submit", "Update"),
        )


class OrganismOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
            Submit("submit", "Create"),
        )


class OrganismOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
            Submit("submit", "Update"),
        )


class OrganismWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class OrganismWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class OrganismBasketCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class OrganismBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class OrganismOrderCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class OrganismOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Update"),
        )


class OrganismsLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = OrganismsLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", "location", Submit("submit", "Create")
        )


class OrganismsLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = OrganismsLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", "location", Submit("submit", "Update")
        )


# from .forms import ExtraDataCreateForm, OrganismInstanceCreateForm, OrganismOrderItemCreateForm, OrganismWishlistCreateForm, OrganismBasketCreateForm, OrganismOrderCreateForm, OrganismsLocalStoreCreateFormExtraDataUpdateForm, OrganismInstanceUpdateForm, OrganismOrderItemUpdateForm, OrganismWishlistUpdateForm, OrganismBasketUpdateForm, OrganismOrderUpdateForm, OrganismsLocalStoreUpdateForm
