"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_organisms_store  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_organisms_store.grpc.services import (
    ExtraDataService,
    OrganismInstanceService,
    OrganismInstancesSubsetService,
    OrganismOrderItemService,
    OrganismWishlistService,
    OrganismBasketService,
    OrganismOrderService,
    OrganismsLocalStoreService,
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_organisms_store", server)

    app_registry.get_grpc_module = lambda: "lara_django_organisms_store_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(OrganismInstanceService)

    app_registry.register(OrganismInstancesSubsetService)

    app_registry.register(OrganismOrderItemService)

    app_registry.register(OrganismWishlistService)

    app_registry.register(OrganismBasketService)

    app_registry.register(OrganismOrderService)

    app_registry.register(OrganismsLocalStoreService)


