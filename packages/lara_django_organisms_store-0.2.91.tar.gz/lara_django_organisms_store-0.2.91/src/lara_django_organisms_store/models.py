"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store models *

:details: lara_django_organisms_store database models.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - remove unwanted models/fields
________________________________________________________________________
"""

import hashlib
import json
import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from lara_django_base.models import ExternalResource
from lara_django_base.models import ExtraDataAbstr
from lara_django_base.models import Location
from lara_django_organisms.models import Organism
from lara_django_people.models import ItemSubsetAbstr
from lara_django_store.models import ItemBasketAbstr
from lara_django_store.models import ItemInstanceAbstr
from lara_django_store.models import ItemOrderAbstr
from lara_django_store.models import OrderItemAbstr

settings.FIXTURES += []


class ExtraData(ExtraDataAbstr):
    """This class can be used to extend data, by extra information,
    e.g. more telephone numbers, customer numbers, ..."""

    model_curi = "lara:organisms-store/ExtraData"

    file = models.FileField(upload_to="organisms_store", blank=True, null=True, help_text="rel. path/filename")

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRIs etc.
        """
        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.hash_sha256 is None:
            if self.data_json is not None:
                to_hash = json.dumps(self.data_json)  # +  str(self.UUID) +
                self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()
            else:
                self.hash_sha256 = hashlib.sha256(str(self.extradata_id).encode("utf-8")).hexdigest()

        if self.name is None or self.name == "":
            if self.name_display is None or self.name_display == "":
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "data",
                        self.hash_sha256[:8],
                    )
                )
            else:
                self.name = self.name_display.replace(" ", "_").lower().strip()

        else:
            self.name = self.name.replace(" ", "_").lower().strip()
        if self.name_full is None or self.name_full == "":
            if self.namespace is not None and self.version is not None:
                self.name_full = f"{self.namespace.uri}/" + "_".join((self.name.replace(" ", "_"), self.version))
            else:
                self.name_full = "_".join((self.name.replace(" ", "_"), self.version))

        if not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}organisms-store/ExtraData/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class OrganismInstance(ItemInstanceAbstr):
    """Organism Instance Model, e.g. a specific plant, animal, fungus, bacteria / strain,  ...
    it can also be used to model a set of organisms instances of similar kind, e.g. a population, a colony, a group, ...
    """

    class SexChoices(models.TextChoices):
        SEX_MALE = "m", _("male")
        SEX_FEMALE = "f", _("female")
        SEX_HERMAPHRPODITE = "h", _("hermaphrodite")
        SEX_MONOECIOUS = "o", _("monoecious")
        SEX_GYNODIOECIOUS = "g", _("gynodioecious")
        SEX_ANDRODIOECIOUS = "a", _("androdioecious")
        SEX_DIOCEIOUS = "d", _("dioecious")
        SEX_TRIOECIOUS = "t", _("trioecious")
        SEX_CONJUGATING = "c", _("conjugating")
        SEX_TRANSFORMING = "r", _("transforming")
        SEX_TRANSDUCING = "u", _("transducing")
        SEX_ASEXUAL = "x", _("asexual")
        SEX_OTHER = "z", _("other sexuality")
        SEX_NOT_SPECIFIED = "n", _("not specified")

    model_curi = "lara:organisms-store/OrganismInstance"
    organisminstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    organism = models.ForeignKey(
        Organism,
        related_name="%(app_label)s_%(class)s_materials_related",
        related_query_name="%(app_label)s_%(class)s_materials_related_query",
        on_delete=models.CASCADE,
        help_text="organism instance is of this organism",
    )
    sex = models.CharField(
        max_length=1,
        choices=SexChoices.choices,
        blank=True,
        null=True,
        # default = SexChoices.SEX_NOT_SPECIFIED,
        help_text="most common (if multiple) sex of organism instance",
    )
    hybrid = models.BooleanField(blank=True, null=True, help_text="is this organism instance a hybrid?")
    chimeric = models.BooleanField(blank=True, null=True, help_text="is this organism instance a chimera?")

    organism_instances = models.ManyToManyField(
        "self",
        related_query_name="%(app_label)s_%(class)s_parents_related_query",
        help_text="parent or compound organism instances of this organism instance, e.g. hybrid, chimera, a colony, a (small) population ",
    )

    traits = models.JSONField(
        blank=True, null=True, help_text="individual traits or features of this organism instance"
    )
    genome = models.URLField(blank=True, null=True, help_text="URL to genome of this organism instance")
    genomes = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_org_instance_genomes_related",
        related_query_name="%(app_label)s_%(class)s_org_instance_genomes_related_query",
        blank=True,
        help_text="genomes of this organism instance",
    )
    habitat = models.JSONField(blank=True, null=True, help_text="habitat of this organism instance")
    image = models.ImageField(
        upload_to="material_store/", blank=True, null=True, help_text="rel. path/filename to image"
    )

    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_oi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_oi_data_extra_related_query",
        help_text="extra data",
    )

    def __str__(self):
        return self.organism.name or ""

    def __repr__(self):
        return self.organism.name or ""

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for full_name"""

        if self.organism is not None:
            if self.name is None or self.name == "":
                self.name = self.organism.name

            if self.name_display is None or self.name_display == "":
                self.name_display = self.organism.name_display

            if self.description is None or self.description == "":
                self.description = self.organism.description
        elif (self.name is None or self.name == "") and self.name_display is not None:
            self.name = self.name_display.strip().replace(" ", "_").lower()

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(uuid.uuid4())[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}organism-store/OrganismInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, force_insert=force_insert, using=using, **kwargs)


class OrganismInstancesSubset(ItemSubsetAbstr):
    """User or group defined subset of organisms"""

    model_curi = "lara:organisms/OrganismInstancesSubset"
    organisminstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organism_instances = models.ManyToManyField(
        OrganismInstance,
        related_name="%(app_label)s_%(class)s_org_instance_subset_related",
        related_query_name="%(app_label)s_%(class)s_org_instance_subset_related_query",
        blank=True,
        help_text="organisms in subset",
        through="OrderedOrganismsInstancesSubset",
    )


class OrderedOrganismsInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between OrganismsInstancesSubset and OrganismInstance.
    This class can be used to store the order of organisms in a subset"""

    model_curi = "lara:organisms-store/OrderedOrganismsInstancesSubset"

    orderedorganisminstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    organism_instance = models.ForeignKey(
        OrganismInstance,
        related_name="%(app_label)s_%(class)s_organism_instance_related",
        related_query_name="%(app_label)s_%(class)s_organism_instance",
        on_delete=models.CASCADE,
        help_text="organism instance in the subset",
    )

    organism_instances_subset = models.ForeignKey(
        OrganismInstancesSubset,
        related_name="%(app_label)s_%(class)s_organisminstancesubset_related",
        related_query_name="%(app_label)s_%(class)s_organisminstancesubset",
        on_delete=models.CASCADE,
        help_text="subset of organism instances",
    )

    order = models.IntegerField(help_text="order of organism instance in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["organism_instance", "organism_instances_subset"],
                name="%(app_label)s_%(class)s_organism_instances_organism_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


class OrganismOrderItem(OrderItemAbstr):
    """Organism Order Item Model for storing device-order-items,"""

    model_curi = "lara:organisms-store/OrganismOrderItem"
    organismorderitem_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organism_instance = models.ForeignKey(
        OrganismInstance,
        related_name="%(app_label)s_%(class)s_organism_instances_related",
        related_query_name="%(app_label)s_%(class)s_organism_instances_related_query",
        on_delete=models.CASCADE,
    )
    organism_wishlist = models.ForeignKey(
        "OrganismWishlist",
        related_name="%(app_label)s_%(class)s_organism_wishlist_related",
        related_query_name="%(app_label)s_%(class)s_organism_wishlist_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="wishlist of organism",
    )
    organism_basket = models.ForeignKey(
        "OrganismBasket",
        related_name="%(app_label)s_%(class)s_organism_basket_related",
        related_query_name="%(app_label)s_%(class)s_organism_basket_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="basket of organism",
    )
    organism_order = models.ForeignKey(
        "OrganismOrder",
        related_name="%(app_label)s_%(class)s_organism_order_related",
        related_query_name="%(app_label)s_%(class)s_organism_order_related_query",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        help_text="order of organism",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_orgi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_orgi_data_extra_related_query",
        help_text="additional data for this order item",
    )

    def __str__(self):
        return self.organism_instance.name or ""

    def __repr__(self):
        return self.organism_instance.name or ""

    class Meta:
        # ordering = ['-datetime_created']
        # verbose_name = "Organism Order Item"
        verbose_name_plural = "Organism Order Items"


class OrganismWishlist(ItemBasketAbstr):
    """Organism Wishlist Model for storing device-wishlists,"""

    model_curi = "lara:organisms-store/OrganismWishlist"
    organismwishlist_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRIs etc.
        """
        if self.name is None or self.name == "":
            self.name = "_".join((timezone.now().strftime("%Y%m%d_%H%M%S"), "organism_wishlist"))

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    # class Meta:
    # ordering = ['-datetime_created']
    # verbose_name = "Organism Wishlist"
    #    verbose_name_plural = "Organism Wishlists"


class OrganismBasket(ItemBasketAbstr):
    """Organism Basket Model for storing organism-baskets,"""

    model_curi = "lara:organisms-store/OrganismBasket"
    organismbasket_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRIs etc.
        """
        if self.name is None or self.name == "":
            self.name = "_".join((timezone.now().strftime("%Y%m%d_%H%M%S"), "organism_basket"))

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    # class Meta:
    # ordering = ['-datetime_created']
    # verbose_name = "Organism Basket"
    #    verbose_name_plural = "Organism Baskets"


class OrganismOrder(ItemOrderAbstr):
    """Organism Order Model for storing organism-orders,"""

    model_curi = "lara:organisms-store/OrganismOrder"
    organismorder_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_quotes = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_quotes_related",
        related_query_name="%(app_label)s_%(class)s_order_quotes_related_query",
        blank=True,
        help_text="Information about quotes for this order, like PDFs, Images, URLs, ...",
    )
    order_invoices = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_invoices_related",
        related_query_name="%(app_label)s_%(class)s_order_invoices_related_query",
        blank=True,
        help_text="Information about invoices for this order, like PDFs, Images, URLs, ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_orgo_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_orgo_data_extra_related_query",
        help_text="additional data for this order",
    )
    
    # class Meta:
    # ordering = ['-datetime_created']
    
    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRIs etc.
        """
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "organism_order",
                    str(uuid.uuid4())[:8],
                )
            )

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

class OrganismsLocalStore(ItemBasketAbstr):
    """Organism LocalStore Model for storing organism-local-stores,
    e.g. a local store of a lab, a company, a university, etc.
    """

    model_curi = "lara:organisms-store/OrganismsLocalStore"
    organismlocalstore_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    organism_instances = models.ManyToManyField(
        OrganismInstance,
        related_name="%(app_label)s_%(class)s_org_instance_loc_related",
        related_query_name="%(app_label)s_%(class)s_org_instance_loc_related_query",
        blank=True,
        help_text="parts in local store",
    )
    location = models.ForeignKey(
        Location,
        related_name="%(app_label)s_%(class)s_org_location_loc_related",
        related_query_name="%(app_label)s_%(class)s_org_location_loc_related_query",
        on_delete=models.CASCADE,
    )
    
    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRIs etc.
        """
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "organism_local_store",
                    str(uuid.uuid4())[:8],
                )
            )

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


