"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store admin *

:details: lara_django_organisms_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_organisms_store >> tables.py" to update this file
________________________________________________________________________
"""
# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_organisms_store
# generated with django-extensions tests_generator  lara_django_organisms_store > tests.py (LARA-version)

import django_tables2 as tables
from django.utils.html import format_html

from .models import ExtraData
from .models import OrganismBasket
from .models import OrganismInstance
from .models import OrganismOrder
from .models import OrganismOrderItem
from .models import OrganismsLocalStore
from .models import OrganismWishlist


class ExtraDataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:extradata-detail', [tables.A('pk')]))

    class Meta:
        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "uri",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
        )


class OrganismInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_organisms_store:organism-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_organisms_store:organism-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_organisms_store:organism-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = OrganismInstance

        fields = (
            "image",
            "name",
            "namespace",
            "barcode1D",
            "url",
            "registration_no",
            "datetime_end_of_warranty",
            "location",
            "description",
            "organism",
            "edit",
            "delete",
        )


class OrganismOrderItemTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismorderitem-detail', [tables.A('pk')]))

    class Meta:
        model = OrganismOrderItem

        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "organism_instance",
        )


class OrganismWishlistTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismwishlist-detail', [tables.A('pk')]))

    class Meta:
        model = OrganismWishlist

        fields = ("namespace", "name", "user", "datetime_created", "datetime_last_modified")


class OrganismBasketTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismbasket-detail', [tables.A('pk')]))

    class Meta:
        model = OrganismBasket

        fields = ("namespace", "name", "user", "datetime_created", "datetime_last_modified")


class OrganismOrderTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismorder-detail', [tables.A('pk')]))

    class Meta:
        model = OrganismOrder

        fields = (
            "namespace",
            "name",
            "iri",
            "user_ordered",
            "user_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_net",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )


class OrganismsLocalStoreTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_organisms_store:organismlocalstore-detail', [tables.A('pk')]))

    class Meta:
        model = OrganismsLocalStore

        fields = (
            "namespace",
            "name",
            "user",
            "datetime_created",
            "datetime_last_modified",
            "location",
        )
