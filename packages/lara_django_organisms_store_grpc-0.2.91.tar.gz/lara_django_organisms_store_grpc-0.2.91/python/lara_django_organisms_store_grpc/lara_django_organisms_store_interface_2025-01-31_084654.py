"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store high_level_interface *

:details: lara_django_organisms_store high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms_store
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2 as lara_django_organisms_store_pb2
import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2_grpc as lara_django_organisms_store_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_organisms_store_grpc.lara_django_organisms_store_data_model as organisms_store_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_store_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_organisms_store_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_upload_chunk = lara_django_organisms_store_pb2.FileUploadChunk


        # self.extradata_full_client = lara_django_organisms_store_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_file  # needed for file upload
    async def create(self,  extradata:  list[organisms_store_dm.ExtraData] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if self._default_namespace_id is not None:
                extradata.namespace = self._default_namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, extradata_name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and extradata_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_organisms_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if extradata_name_display is not None:
        #     filter_list.append({"name_display": extradata_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          extradata_name: str = None,
                          extradata_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given extradata_name,
               extradata_name_display or iri
        """
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_display is not None:
            filter_dict = {"name_display": extradata_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")
        if len(results) == 1 :
            return results[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, extradata_id: str = None) -> organisms_store_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_organisms_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            return organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, extradata_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.ExtraData:
        """ retrieve a extradata data model by extradata_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.ExtraDataRetrieveByNameNSRequest(name=extradata_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_organisms_store_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_file  # needed for file update
    async def update(self, extradata : organisms_store_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            await self.extradata_client.Update(
                lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_organisms_store_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  OrganismInstance  ______________________


class OrganismInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organisminstance_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstanceclassByIRIControllerStub(channel)
        # )

        self.organisminstance_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceControllerStub(channel)
        
        self.update_item_id = "organisminstance_id"
        self.stub = self.organisminstance_client

        self.image_upload_chunk = lara_django_organisms_store_pb2.ImageUploadChunk


        # self.organisminstance_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  organisminstances:  list[organisms_store_dm.OrganismInstance] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismInstance]]:
        """ create a list of organisminstance instances,
               returns a list of organisminstance data model objects or ids_only

        :param organisminstances: list of organisminstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organisminstance data model objects or ids_only
        """
        organisminstanceclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstance_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstanceclassRetrieveRequest(iri=organisminstance_class_iri)
        #     )
        #     organisminstanceclass_id = res.organisminstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organisminstanceclass_id: {e}")
        for organisminstance in organisminstances:
            if self._default_namespace_id is not None:
                organisminstance.namespace = self._default_namespace_id
            # organisminstance.organisminstance_class = organisminstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organisminstance_client.Create(lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump())) for organisminstance in organisminstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organisminstance_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organisminstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organisminstance_id: str = None,
        organisminstance_name: str = None,
        #organisminstance_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstance]:
        """ retrieve a list of organisminstance instances by organisminstance_id, organisminstance_name or filter_dict,
               returns a list of organisminstance data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organisminstance_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organisminstance_id is not None:
            try:
                res =  await self.organisminstance_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstanceRetrieveRequest(organisminstance_id=organisminstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organisminstance_id: {e}")

        if organisminstance_name is not None:
            filter_list.append({"name": organisminstance_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organisminstance_name_display is not None:
        #     filter_list.append({"name_display": organisminstance_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstance_client.List(
                        lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organisminstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organisminstance_name: str = None,
                          organisminstance_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organisminstance_id for a given organisminstance_name,
               organisminstance_name_display or iri
        """
        if organisminstance_name is not None:
            filter_dict = {"name": organisminstance_name}
        elif organisminstance_name_display is not None:
            filter_dict = {"name_display": organisminstance_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organisminstance_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organisminstance_name: {e}")
        if len(results) == 1 :
            return results[0].organisminstance_id
        else:
            raise ValueError(f"Error retrieving organisminstance_id - no or too many results found.")
    
    @download_image  # needed for image download
    async def get_by_id(self, organisminstance_id: str = None) -> organisms_store_dm.OrganismInstance:
        """ retrieve a organisminstance data model by organisminstance_id """
        try:
            res = await self.organisminstance_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismInstanceRetrieveRequest(organisminstance_id=organisminstance_id)
            )
            return organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organisminstance_id: {e}")
    
    @download_image  # needed for image download
    async def get_by_name(self, organisminstance_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismInstance:
        """ retrieve a organisminstance data model by organisminstance_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organisminstance_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismInstanceRetrieveByNameNSRequest(name=organisminstance_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organisminstance_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organisminstances """
        if filter_dict is None:
            res = await self.organisminstance_client.List(lara_django_organisms_store_pb2.OrganismInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstance_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organisminstances """
        if self.organisminstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, organisminstance : organisms_store_dm.OrganismInstance = None) -> None:
        """ update a organisminstance model instance """
        try:
            await self.organisminstance_client.Update(
                lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organisminstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organisminstance by organisminstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organisminstance_client.Destroy(lara_django_organisms_store_pb2.OrganismInstanceDestroyRequest(organisminstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organisminstance_id: {e}")

#_________________  OrganismInstancesSubset  ______________________


class OrganismInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organisminstancessubset_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.organisminstancessubset_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetControllerStub(channel)
        

        # self.organisminstancessubset_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organisminstancessubsets:  list[organisms_store_dm.OrganismInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismInstancesSubset]]:
        """ create a list of organisminstancessubset instances,
               returns a list of organisminstancessubset data model objects or ids_only

        :param organisminstancessubsets: list of organisminstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organisminstancessubset data model objects or ids_only
        """
        organisminstancessubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstancessubset_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstancesSubsetclassRetrieveRequest(iri=organisminstancessubset_class_iri)
        #     )
        #     organisminstancessubsetclass_id = res.organisminstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organisminstancessubsetclass_id: {e}")
        for organisminstancessubset in organisminstancessubsets:
            if self._default_namespace_id is not None:
                organisminstancessubset.namespace = self._default_namespace_id
            # organisminstancessubset.organisminstancessubset_class = organisminstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organisminstancessubset_client.Create(lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump())) for organisminstancessubset in organisminstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organisminstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organisminstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organisminstancessubset_id: str = None,
        organisminstancessubset_name: str = None,
        #organisminstancessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstancesSubset]:
        """ retrieve a list of organisminstancessubset instances by organisminstancessubset_id, organisminstancessubset_name or filter_dict,
               returns a list of organisminstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organisminstancessubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organisminstancessubset_id is not None:
            try:
                res =  await self.organisminstancessubset_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveRequest(organisminstancessubset_id=organisminstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organisminstancessubset_id: {e}")

        if organisminstancessubset_name is not None:
            filter_list.append({"name": organisminstancessubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organisminstancessubset_name_display is not None:
        #     filter_list.append({"name_display": organisminstancessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstancessubset_client.List(
                        lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organisminstancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organisminstancessubset_name: str = None,
                          organisminstancessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organisminstancessubset_id for a given organisminstancessubset_name,
               organisminstancessubset_name_display or iri
        """
        if organisminstancessubset_name is not None:
            filter_dict = {"name": organisminstancessubset_name}
        elif organisminstancessubset_name_display is not None:
            filter_dict = {"name_display": organisminstancessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organisminstancessubset_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset_name: {e}")
        if len(results) == 1 :
            return results[0].organisminstancessubset_id
        else:
            raise ValueError(f"Error retrieving organisminstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, organisminstancessubset_id: str = None) -> organisms_store_dm.OrganismInstancesSubset:
        """ retrieve a organisminstancessubset data model by organisminstancessubset_id """
        try:
            res = await self.organisminstancessubset_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveRequest(organisminstancessubset_id=organisminstancessubset_id)
            )
            return organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset_id: {e}")
    
    async def get_by_name(self, organisminstancessubset_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismInstancesSubset:
        """ retrieve a organisminstancessubset data model by organisminstancessubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organisminstancessubset_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveByNameNSRequest(name=organisminstancessubset_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organisminstancessubsets """
        if filter_dict is None:
            res = await self.organisminstancessubset_client.List(lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstancessubset_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organisminstancessubsets """
        if self.organisminstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organisminstancessubset : organisms_store_dm.OrganismInstancesSubset = None) -> None:
        """ update a organisminstancessubset model instance """
        try:
            await self.organisminstancessubset_client.Update(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organisminstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organisminstancessubset by organisminstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organisminstancessubset_client.Destroy(lara_django_organisms_store_pb2.OrganismInstancesSubsetDestroyRequest(organisminstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organisminstancessubset_id: {e}")

#_________________  OrderedOrganismsInstanceOrganismsInstancesSubset  ______________________


class OrderedOrganismsInstanceOrganismsInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedorganismsinstanceorganismsinstancessubset_client = lara_django_organisms_store_pb2_grpc.OrderedOrganismsInstanceOrganismsInstancesSubsetControllerStub(channel)

        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedorganismsinstanceorganismsinstancessubsets:  list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedorganismsinstanceorganismsinstancessubset_client.Create(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRequest(**orderedorganismsinstanceorganismsinstancessubset.model_dump())) for orderedorganismsinstanceorganismsinstancessubset in orderedorganismsinstanceorganismsinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedorganismsinstanceorganismsinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedorganismsinstanceorganismsinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedorganismsinstanceorganismsinstancessubset_id: str = None,
        orderedorganismsinstanceorganismsinstancessubset_name: str = None,
        #orderedorganismsinstanceorganismsinstancessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset]:
        """ retrieve a list of orderedorganismsinstanceorganismsinstancessubset instances by orderedorganismsinstanceorganismsinstancessubset_id, orderedorganismsinstanceorganismsinstancessubset_name or filter_dict,
               returns a list of orderedorganismsinstanceorganismsinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedorganismsinstanceorganismsinstancessubset_id is not None:
            try:
                res =  await self.orderedorganismsinstanceorganismsinstancessubset_client.Retrieve(
                    lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveRequest(orderedorganismsinstanceorganismsinstancessubset_id=orderedorganismsinstanceorganismsinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id: {e}")

        if orderedorganismsinstanceorganismsinstancessubset_name is not None:
            filter_list.append({"name": orderedorganismsinstanceorganismsinstancessubset_name})
        # if orderedorganismsinstanceorganismsinstancessubset_name_display is not None:
        #     filter_list.append({"name_display": orderedorganismsinstanceorganismsinstancessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(
                        lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedorganismsinstanceorganismsinstancessubset_name: str = None,
                          orderedorganismsinstanceorganismsinstancessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedorganismsinstanceorganismsinstancessubset_id for a given orderedorganismsinstanceorganismsinstancessubset_name,
               orderedorganismsinstanceorganismsinstancessubset_name_display or iri
        """
        if orderedorganismsinstanceorganismsinstancessubset_name is not None:
            filter_dict = {"name": orderedorganismsinstanceorganismsinstancessubset_name}
        elif orderedorganismsinstanceorganismsinstancessubset_name_display is not None:
            filter_dict = {"name_display": orderedorganismsinstanceorganismsinstancessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedorganismsinstanceorganismsinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedorganismsinstanceorganismsinstancessubset_id: str = None) -> organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset:
        """ retrieve a orderedorganismsinstanceorganismsinstancessubset data model by orderedorganismsinstanceorganismsinstancessubset_id """
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.Retrieve(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveRequest(orderedorganismsinstanceorganismsinstancessubset_id=orderedorganismsinstanceorganismsinstancessubset_id)
            )
            return organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id: {e}")
    
    async def get_by_name(self, orderedorganismsinstanceorganismsinstancessubset_name: str = None) -> organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset:
        """ retrieve a orderedorganismsinstanceorganismsinstancessubset data model by orderedorganismsinstanceorganismsinstancessubset_name """
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveByNameNSRequest(name=orderedorganismsinstanceorganismsinstancessubset_name, namespace_uri="")
            )
            return organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedorganismsinstanceorganismsinstancessubsets """
        if filter_dict is None:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedorganismsinstanceorganismsinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedorganismsinstanceorganismsinstancessubsets """
        if self.orderedorganismsinstanceorganismsinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedorganismsinstanceorganismsinstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedorganismsinstanceorganismsinstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedorganismsinstanceorganismsinstancessubset : organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset = None) -> None:
        """ update a orderedorganismsinstanceorganismsinstancessubset model instance """
        try:
            await self.orderedorganismsinstanceorganismsinstancessubset_client.Update(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRequest(**orderedorganismsinstanceorganismsinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedorganismsinstanceorganismsinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedorganismsinstanceorganismsinstancessubset by orderedorganismsinstanceorganismsinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedorganismsinstanceorganismsinstancessubset_client.Destroy(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetDestroyRequest(orderedorganismsinstanceorganismsinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedorganismsinstanceorganismsinstancessubset_id: {e}")

#_________________  OrganismOrderItem  ______________________


class OrganismOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.organismorderitem_client = lara_django_organisms_store_pb2_grpc.OrganismOrderItemControllerStub(channel)

        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organismorderitems:  list[organisms_store_dm.OrganismOrderItem] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismOrderItem]]:
        try:
            create_coroutines = ( self.organismorderitem_client.Create(lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump())) for organismorderitem in organismorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismorderitem: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        organismorderitem_id: str = None,
        organismorderitem_name: str = None,
        #organismorderitem_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrderItem]:
        """ retrieve a list of organismorderitem instances by organismorderitem_id, organismorderitem_name or filter_dict,
               returns a list of organismorderitem data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  organismorderitem_id is not None:
            try:
                res =  await self.organismorderitem_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderItemRetrieveRequest(organismorderitem_id=organismorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismorderitem_id: {e}")

        if organismorderitem_name is not None:
            filter_list.append({"name": organismorderitem_name})
        # if organismorderitem_name_display is not None:
        #     filter_list.append({"name_display": organismorderitem_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorderitem_client.List(
                        lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organismorderitem_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organismorderitem_name: str = None,
                          organismorderitem_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organismorderitem_id for a given organismorderitem_name,
               organismorderitem_name_display or iri
        """
        if organismorderitem_name is not None:
            filter_dict = {"name": organismorderitem_name}
        elif organismorderitem_name_display is not None:
            filter_dict = {"name_display": organismorderitem_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismorderitem_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem_name: {e}")
        if len(results) == 1 :
            return results[0].organismorderitem_id
        else:
            raise ValueError(f"Error retrieving organismorderitem_id - no or too many results found.")
    
    async def get_by_id(self, organismorderitem_id: str = None) -> organisms_store_dm.OrganismOrderItem:
        """ retrieve a organismorderitem data model by organismorderitem_id """
        try:
            res = await self.organismorderitem_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismOrderItemRetrieveRequest(organismorderitem_id=organismorderitem_id)
            )
            return organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem_id: {e}")
    
    async def get_by_name(self, organismorderitem_name: str = None) -> organisms_store_dm.OrganismOrderItem:
        """ retrieve a organismorderitem data model by organismorderitem_name """
        try:
            res = await self.organismorderitem_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismOrderItemRetrieveByNameNSRequest(name=organismorderitem_name, namespace_uri="")
            )
            return organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismorderitems """
        if filter_dict is None:
            res = await self.organismorderitem_client.List(lara_django_organisms_store_pb2.OrganismOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorderitem_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorderitem_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismorderitems """
        if self.organismorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organismorderitem : organisms_store_dm.OrganismOrderItem = None) -> None:
        """ update a organismorderitem model instance """
        try:
            await self.organismorderitem_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismorderitem_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismorderitem by organismorderitem_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismorderitem_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderItemDestroyRequest(organismorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismorderitem_id: {e}")

#_________________  OrganismWishlist  ______________________


class OrganismWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismwishlist_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismWishlistclassByIRIControllerStub(channel)
        # )

        self.organismwishlist_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistControllerStub(channel)
        

        # self.organismwishlist_full_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organismwishlists:  list[organisms_store_dm.OrganismWishlist] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismWishlist]]:
        """ create a list of organismwishlist instances,
               returns a list of organismwishlist data model objects or ids_only

        :param organismwishlists: list of organismwishlist data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismwishlist data model objects or ids_only
        """
        organismwishlistclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismwishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismwishlist_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismWishlistclassRetrieveRequest(iri=organismwishlist_class_iri)
        #     )
        #     organismwishlistclass_id = res.organismwishlistclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismwishlistclass_id: {e}")
        for organismwishlist in organismwishlists:
            if self._default_namespace_id is not None:
                organismwishlist.namespace = self._default_namespace_id
            # organismwishlist.organismwishlist_class = organismwishlistclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismwishlist_client.Create(lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump())) for organismwishlist in organismwishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismwishlist_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismwishlist: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismwishlist_id: str = None,
        organismwishlist_name: str = None,
        #organismwishlist_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismWishlist]:
        """ retrieve a list of organismwishlist instances by organismwishlist_id, organismwishlist_name or filter_dict,
               returns a list of organismwishlist data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organismwishlist_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organismwishlist_id is not None:
            try:
                res =  await self.organismwishlist_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismWishlistRetrieveRequest(organismwishlist_id=organismwishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismwishlist_id: {e}")

        if organismwishlist_name is not None:
            filter_list.append({"name": organismwishlist_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organismwishlist_name_display is not None:
        #     filter_list.append({"name_display": organismwishlist_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismwishlist_client.List(
                        lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organismwishlist_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organismwishlist_name: str = None,
                          organismwishlist_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organismwishlist_id for a given organismwishlist_name,
               organismwishlist_name_display or iri
        """
        if organismwishlist_name is not None:
            filter_dict = {"name": organismwishlist_name}
        elif organismwishlist_name_display is not None:
            filter_dict = {"name_display": organismwishlist_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismwishlist_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist_name: {e}")
        if len(results) == 1 :
            return results[0].organismwishlist_id
        else:
            raise ValueError(f"Error retrieving organismwishlist_id - no or too many results found.")
    
    async def get_by_id(self, organismwishlist_id: str = None) -> organisms_store_dm.OrganismWishlist:
        """ retrieve a organismwishlist data model by organismwishlist_id """
        try:
            res = await self.organismwishlist_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismWishlistRetrieveRequest(organismwishlist_id=organismwishlist_id)
            )
            return organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist_id: {e}")
    
    async def get_by_name(self, organismwishlist_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismWishlist:
        """ retrieve a organismwishlist data model by organismwishlist_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismwishlist_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismWishlistRetrieveByNameNSRequest(name=organismwishlist_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismwishlists """
        if filter_dict is None:
            res = await self.organismwishlist_client.List(lara_django_organisms_store_pb2.OrganismWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismwishlist_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismwishlist_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismwishlists """
        if self.organismwishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organismwishlist : organisms_store_dm.OrganismWishlist = None) -> None:
        """ update a organismwishlist model instance """
        try:
            await self.organismwishlist_client.Update(
                lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismwishlist_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismwishlist by organismwishlist_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismwishlist_client.Destroy(lara_django_organisms_store_pb2.OrganismWishlistDestroyRequest(organismwishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismwishlist_id: {e}")

#_________________  OrganismBasket  ______________________


class OrganismBasketInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismbasket_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismBasketclassByIRIControllerStub(channel)
        # )

        self.organismbasket_client = lara_django_organisms_store_pb2_grpc.OrganismBasketControllerStub(channel)
        

        # self.organismbasket_full_client = lara_django_organisms_store_pb2_grpc.OrganismBasketFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organismbaskets:  list[organisms_store_dm.OrganismBasket] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismBasket]]:
        """ create a list of organismbasket instances,
               returns a list of organismbasket data model objects or ids_only

        :param organismbaskets: list of organismbasket data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismbasket data model objects or ids_only
        """
        organismbasketclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismbasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismbasket_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismBasketclassRetrieveRequest(iri=organismbasket_class_iri)
        #     )
        #     organismbasketclass_id = res.organismbasketclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismbasketclass_id: {e}")
        for organismbasket in organismbaskets:
            if self._default_namespace_id is not None:
                organismbasket.namespace = self._default_namespace_id
            # organismbasket.organismbasket_class = organismbasketclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismbasket_client.Create(lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump())) for organismbasket in organismbaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismbasket_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismbasket: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismbasket_id: str = None,
        organismbasket_name: str = None,
        #organismbasket_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismBasket]:
        """ retrieve a list of organismbasket instances by organismbasket_id, organismbasket_name or filter_dict,
               returns a list of organismbasket data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organismbasket_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organismbasket_id is not None:
            try:
                res =  await self.organismbasket_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismBasketRetrieveRequest(organismbasket_id=organismbasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismbasket_id: {e}")

        if organismbasket_name is not None:
            filter_list.append({"name": organismbasket_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organismbasket_name_display is not None:
        #     filter_list.append({"name_display": organismbasket_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismbasket_client.List(
                        lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organismbasket_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organismbasket_name: str = None,
                          organismbasket_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organismbasket_id for a given organismbasket_name,
               organismbasket_name_display or iri
        """
        if organismbasket_name is not None:
            filter_dict = {"name": organismbasket_name}
        elif organismbasket_name_display is not None:
            filter_dict = {"name_display": organismbasket_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismbasket_client.List(
                lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organismbasket_name: {e}")
        if len(results) == 1 :
            return results[0].organismbasket_id
        else:
            raise ValueError(f"Error retrieving organismbasket_id - no or too many results found.")
    
    async def get_by_id(self, organismbasket_id: str = None) -> organisms_store_dm.OrganismBasket:
        """ retrieve a organismbasket data model by organismbasket_id """
        try:
            res = await self.organismbasket_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismBasketRetrieveRequest(organismbasket_id=organismbasket_id)
            )
            return organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismbasket_id: {e}")
    
    async def get_by_name(self, organismbasket_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismBasket:
        """ retrieve a organismbasket data model by organismbasket_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismbasket_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismBasketRetrieveByNameNSRequest(name=organismbasket_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismbasket_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismbaskets """
        if filter_dict is None:
            res = await self.organismbasket_client.List(lara_django_organisms_store_pb2.OrganismBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismbasket_client.List(
                lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismbasket_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismbaskets """
        if self.organismbasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organismbasket : organisms_store_dm.OrganismBasket = None) -> None:
        """ update a organismbasket model instance """
        try:
            await self.organismbasket_client.Update(
                lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismbasket_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismbasket by organismbasket_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismbasket_client.Destroy(lara_django_organisms_store_pb2.OrganismBasketDestroyRequest(organismbasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismbasket_id: {e}")

#_________________  OrganismOrder  ______________________


class OrganismOrderInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismorder_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismOrderclassByIRIControllerStub(channel)
        # )

        self.organismorder_client = lara_django_organisms_store_pb2_grpc.OrganismOrderControllerStub(channel)
        

        # self.organismorder_full_client = lara_django_organisms_store_pb2_grpc.OrganismOrderFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organismorders:  list[organisms_store_dm.OrganismOrder] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismOrder]]:
        """ create a list of organismorder instances,
               returns a list of organismorder data model objects or ids_only

        :param organismorders: list of organismorder data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismorder data model objects or ids_only
        """
        organismorderclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismorder_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismOrderclassRetrieveRequest(iri=organismorder_class_iri)
        #     )
        #     organismorderclass_id = res.organismorderclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismorderclass_id: {e}")
        for organismorder in organismorders:
            if self._default_namespace_id is not None:
                organismorder.namespace = self._default_namespace_id
            # organismorder.organismorder_class = organismorderclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismorder_client.Create(lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump())) for organismorder in organismorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismorder_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismorder: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismorder_id: str = None,
        organismorder_name: str = None,
        #organismorder_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrder]:
        """ retrieve a list of organismorder instances by organismorder_id, organismorder_name or filter_dict,
               returns a list of organismorder data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organismorder_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organismorder_id is not None:
            try:
                res =  await self.organismorder_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderRetrieveRequest(organismorder_id=organismorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismorder_id: {e}")

        if organismorder_name is not None:
            filter_list.append({"name": organismorder_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organismorder_name_display is not None:
        #     filter_list.append({"name_display": organismorder_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorder_client.List(
                        lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organismorder_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organismorder_name: str = None,
                          organismorder_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organismorder_id for a given organismorder_name,
               organismorder_name_display or iri
        """
        if organismorder_name is not None:
            filter_dict = {"name": organismorder_name}
        elif organismorder_name_display is not None:
            filter_dict = {"name_display": organismorder_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismorder_client.List(
                lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organismorder_name: {e}")
        if len(results) == 1 :
            return results[0].organismorder_id
        else:
            raise ValueError(f"Error retrieving organismorder_id - no or too many results found.")
    
    async def get_by_id(self, organismorder_id: str = None) -> organisms_store_dm.OrganismOrder:
        """ retrieve a organismorder data model by organismorder_id """
        try:
            res = await self.organismorder_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismOrderRetrieveRequest(organismorder_id=organismorder_id)
            )
            return organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorder_id: {e}")
    
    async def get_by_name(self, organismorder_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismOrder:
        """ retrieve a organismorder data model by organismorder_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismorder_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismOrderRetrieveByNameNSRequest(name=organismorder_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorder_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismorders """
        if filter_dict is None:
            res = await self.organismorder_client.List(lara_django_organisms_store_pb2.OrganismOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorder_client.List(
                lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorder_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismorders """
        if self.organismorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organismorder : organisms_store_dm.OrganismOrder = None) -> None:
        """ update a organismorder model instance """
        try:
            await self.organismorder_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismorder_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismorder by organismorder_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismorder_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderDestroyRequest(organismorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismorder_id: {e}")

#_________________  OrganismsLocalStore  ______________________


class OrganismsLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        if default_namespace_uri is not None:
            self._default_namespace_uri = default_namespace_uri

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismslocalstore_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreclassByIRIControllerStub(channel)
        # )

        self.organismslocalstore_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreControllerStub(channel)
        

        # self.organismslocalstore_full_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @default_namespace_uri.setter
    async def default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  organismslocalstores:  list[organisms_store_dm.OrganismsLocalStore] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismsLocalStore]]:
        """ create a list of organismslocalstore instances,
               returns a list of organismslocalstore data model objects or ids_only

        :param organismslocalstores: list of organismslocalstore data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismslocalstore data model objects or ids_only
        """
        organismslocalstoreclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismslocalstore_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismsLocalStoreclassRetrieveRequest(iri=organismslocalstore_class_iri)
        #     )
        #     organismslocalstoreclass_id = res.organismslocalstoreclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismslocalstoreclass_id: {e}")
        for organismslocalstore in organismslocalstores:
            if self._default_namespace_id is not None:
                organismslocalstore.namespace = self._default_namespace_id
            # organismslocalstore.organismslocalstore_class = organismslocalstoreclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismslocalstore_client.Create(lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismslocalstore.model_dump())) for organismslocalstore in organismslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismslocalstore_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismslocalstore: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismslocalstore_id: str = None,
        organismslocalstore_name: str = None,
        #organismslocalstore_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismsLocalStore]:
        """ retrieve a list of organismslocalstore instances by organismslocalstore_id, organismslocalstore_name or filter_dict,
               returns a list of organismslocalstore data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and organismslocalstore_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  organismslocalstore_id is not None:
            try:
                res =  await self.organismslocalstore_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveRequest(organismslocalstore_id=organismslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismslocalstore_id: {e}")

        if organismslocalstore_name is not None:
            filter_list.append({"name": organismslocalstore_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if organismslocalstore_name_display is not None:
        #     filter_list.append({"name_display": organismslocalstore_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismslocalstore_client.List(
                        lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving organismslocalstore_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          organismslocalstore_name: str = None,
                          organismslocalstore_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the organismslocalstore_id for a given organismslocalstore_name,
               organismslocalstore_name_display or iri
        """
        if organismslocalstore_name is not None:
            filter_dict = {"name": organismslocalstore_name}
        elif organismslocalstore_name_display is not None:
            filter_dict = {"name_display": organismslocalstore_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismslocalstore_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore_name: {e}")
        if len(results) == 1 :
            return results[0].organismslocalstore_id
        else:
            raise ValueError(f"Error retrieving organismslocalstore_id - no or too many results found.")
    
    async def get_by_id(self, organismslocalstore_id: str = None) -> organisms_store_dm.OrganismsLocalStore:
        """ retrieve a organismslocalstore data model by organismslocalstore_id """
        try:
            res = await self.organismslocalstore_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveRequest(organismslocalstore_id=organismslocalstore_id)
            )
            return organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore_id: {e}")
    
    async def get_by_name(self, organismslocalstore_name: str = None,
                                namespace_uri : str = None) -> organisms_store_dm.OrganismsLocalStore:
        """ retrieve a organismslocalstore data model by organismslocalstore_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismslocalstore_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveByNameNSRequest(name=organismslocalstore_name, namespace_uri=namespace_uri)
            )
            return organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore_name: {e}")
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismslocalstores """
        if filter_dict is None:
            res = await self.organismslocalstore_client.List(lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismslocalstore_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismslocalstore_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismslocalstores """
        if self.organismslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismslocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismslocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, organismslocalstore : organisms_store_dm.OrganismsLocalStore = None) -> None:
        """ update a organismslocalstore model instance """
        try:
            await self.organismslocalstore_client.Update(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismslocalstore.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismslocalstore_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismslocalstore by organismslocalstore_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismslocalstore_client.Destroy(lara_django_organisms_store_pb2.OrganismsLocalStoreDestroyRequest(organismslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismslocalstore_id: {e}")

