"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store high_level_interface *

:details: lara_django_organisms_store high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms_store
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2 as lara_django_organisms_store_pb2
import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2_grpc as lara_django_organisms_store_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, export_file, import_file, id_cache, update_image

import  lara_django_organisms_store_grpc.lara_django_organisms_store_data_model as organisms_store_dm 



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_store_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_organisms_store_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_organisms_store_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  extradata:  list[organisms_store_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_organisms_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_organisms_store_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, extradata : organisms_store_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_organisms_store_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  OrganismInstance  ______________________


class OrganismInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organisminstance_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstanceclassByIRIControllerStub(channel)
        # )
        
        self.organisminstance_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceControllerStub(channel)

        # self.organisminstance_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organisminstances:  list[organisms_store_dm.OrganismInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organisminstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstance_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstanceclassRetrieveRequest(iri=organisminstance_class_iri)
        #     )
        #     organisminstanceclass_id = res.organisminstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organisminstanceclass_id: {e}")
        # for organisminstance in organisminstances:
        #     organisminstance.namespace = self.namespace_id
        #     organisminstance.organisminstance_class = organisminstanceclass_id

        try:
            create_coroutines = ( self.organisminstance_client.Create(lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump())) for organisminstance in organisminstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organisminstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organisminstance: {e}")

    @export_file
    async def retrieve(
        self, 
        organisminstance_id: str = None,
        organisminstance_name: str = None,
        #organisminstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstance]:
        filter_list = []
        results_list = []
        if  organisminstance_id is not None:
            try:
                res =  await self.organisminstance_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstanceRetrieveRequest(organisminstance_id=organisminstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organisminstance_id: {e}")

        if organisminstance_name is not None:
            filter_list.append({"name": organisminstance_name})
        # if organisminstance_name_full is not None:
        #     filter_list.append({"name_full": organisminstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstance_client.List(
                        lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organisminstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organisminstance_name: str = None,
                          organisminstance_name_full: str = None,
                          iri: str = None,) -> str:
        if organisminstance_name is not None:
            filter_dict = {"name": organisminstance_name}
        elif organisminstance_name_full is not None:
            filter_dict = {"name_full": organisminstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstance_client.List(
                    lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organisminstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organisminstance_id
            else:
                raise ValueError(f"Error retrieving organisminstance_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organisminstance_client.List(lara_django_organisms_store_pb2.OrganismInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstance_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organisminstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organisminstance : organisms_store_dm.OrganismInstance = None) -> None:
        try:
            await self.organisminstance_client.Update(
                lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organisminstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organisminstance_client.Destroy(lara_django_organisms_store_pb2.OrganismInstanceDestroyRequest(organisminstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organisminstance_id: {e}")

#_________________  OrganismInstancesSubset  ______________________


class OrganismInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organisminstancessubset_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetclassByIRIControllerStub(channel)
        # )
        
        self.organisminstancessubset_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetControllerStub(channel)

        # self.organisminstancessubset_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organisminstancessubsets:  list[organisms_store_dm.OrganismInstancesSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismInstancesSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organisminstancessubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstancessubset_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstancesSubsetclassRetrieveRequest(iri=organisminstancessubset_class_iri)
        #     )
        #     organisminstancessubsetclass_id = res.organisminstancessubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organisminstancessubsetclass_id: {e}")
        # for organisminstancessubset in organisminstancessubsets:
        #     organisminstancessubset.namespace = self.namespace_id
        #     organisminstancessubset.organisminstancessubset_class = organisminstancessubsetclass_id

        try:
            create_coroutines = ( self.organisminstancessubset_client.Create(lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump())) for organisminstancessubset in organisminstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organisminstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organisminstancessubset: {e}")

    @export_file
    async def retrieve(
        self, 
        organisminstancessubset_id: str = None,
        organisminstancessubset_name: str = None,
        #organisminstancessubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstancesSubset]:
        filter_list = []
        results_list = []
        if  organisminstancessubset_id is not None:
            try:
                res =  await self.organisminstancessubset_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveRequest(organisminstancessubset_id=organisminstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organisminstancessubset_id: {e}")

        if organisminstancessubset_name is not None:
            filter_list.append({"name": organisminstancessubset_name})
        # if organisminstancessubset_name_full is not None:
        #     filter_list.append({"name_full": organisminstancessubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstancessubset_client.List(
                        lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organisminstancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organisminstancessubset_name: str = None,
                          organisminstancessubset_name_full: str = None,
                          iri: str = None,) -> str:
        if organisminstancessubset_name is not None:
            filter_dict = {"name": organisminstancessubset_name}
        elif organisminstancessubset_name_full is not None:
            filter_dict = {"name_full": organisminstancessubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organisminstancessubset_client.List(
                    lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organisminstancessubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organisminstancessubset_id
            else:
                raise ValueError(f"Error retrieving organisminstancessubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organisminstancessubset_client.List(lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstancessubset_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstancessubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organisminstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organisminstancessubset : organisms_store_dm.OrganismInstancesSubset = None) -> None:
        try:
            await self.organisminstancessubset_client.Update(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organisminstancessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organisminstancessubset_client.Destroy(lara_django_organisms_store_pb2.OrganismInstancesSubsetDestroyRequest(organisminstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organisminstancessubset_id: {e}")

#_________________  OrganismOrderItem  ______________________


class OrganismOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismorderitem_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismOrderItemclassByIRIControllerStub(channel)
        # )
        
        self.organismorderitem_client = lara_django_organisms_store_pb2_grpc.OrganismOrderItemControllerStub(channel)

        # self.organismorderitem_full_client = lara_django_organisms_store_pb2_grpc.OrganismOrderItemFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismorderitems:  list[organisms_store_dm.OrganismOrderItem] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismOrderItem]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismorderitemclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismorderitem_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismorderitem_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismOrderItemclassRetrieveRequest(iri=organismorderitem_class_iri)
        #     )
        #     organismorderitemclass_id = res.organismorderitemclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismorderitemclass_id: {e}")
        # for organismorderitem in organismorderitems:
        #     organismorderitem.namespace = self.namespace_id
        #     organismorderitem.organismorderitem_class = organismorderitemclass_id

        try:
            create_coroutines = ( self.organismorderitem_client.Create(lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump())) for organismorderitem in organismorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismorderitem: {e}")

    @export_file
    async def retrieve(
        self, 
        organismorderitem_id: str = None,
        organismorderitem_name: str = None,
        #organismorderitem_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrderItem]:
        filter_list = []
        results_list = []
        if  organismorderitem_id is not None:
            try:
                res =  await self.organismorderitem_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderItemRetrieveRequest(organismorderitem_id=organismorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismorderitem_id: {e}")

        if organismorderitem_name is not None:
            filter_list.append({"name": organismorderitem_name})
        # if organismorderitem_name_full is not None:
        #     filter_list.append({"name_full": organismorderitem_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorderitem_client.List(
                        lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismorderitem_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismorderitem_name: str = None,
                          organismorderitem_name_full: str = None,
                          iri: str = None,) -> str:
        if organismorderitem_name is not None:
            filter_dict = {"name": organismorderitem_name}
        elif organismorderitem_name_full is not None:
            filter_dict = {"name_full": organismorderitem_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorderitem_client.List(
                    lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismorderitem_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismorderitem_id
            else:
                raise ValueError(f"Error retrieving organismorderitem_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismorderitem_client.List(lara_django_organisms_store_pb2.OrganismOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorderitem_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorderitem_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismorderitem : organisms_store_dm.OrganismOrderItem = None) -> None:
        try:
            await self.organismorderitem_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismorderitem_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismorderitem_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderItemDestroyRequest(organismorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismorderitem_id: {e}")

#_________________  OrganismWishlist  ______________________


class OrganismWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismwishlist_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismWishlistclassByIRIControllerStub(channel)
        # )
        
        self.organismwishlist_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistControllerStub(channel)

        # self.organismwishlist_full_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismwishlists:  list[organisms_store_dm.OrganismWishlist] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismWishlist]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismwishlistclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismwishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismwishlist_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismWishlistclassRetrieveRequest(iri=organismwishlist_class_iri)
        #     )
        #     organismwishlistclass_id = res.organismwishlistclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismwishlistclass_id: {e}")
        # for organismwishlist in organismwishlists:
        #     organismwishlist.namespace = self.namespace_id
        #     organismwishlist.organismwishlist_class = organismwishlistclass_id

        try:
            create_coroutines = ( self.organismwishlist_client.Create(lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump())) for organismwishlist in organismwishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismwishlist_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismwishlist: {e}")

    @export_file
    async def retrieve(
        self, 
        organismwishlist_id: str = None,
        organismwishlist_name: str = None,
        #organismwishlist_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismWishlist]:
        filter_list = []
        results_list = []
        if  organismwishlist_id is not None:
            try:
                res =  await self.organismwishlist_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismWishlistRetrieveRequest(organismwishlist_id=organismwishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismwishlist_id: {e}")

        if organismwishlist_name is not None:
            filter_list.append({"name": organismwishlist_name})
        # if organismwishlist_name_full is not None:
        #     filter_list.append({"name_full": organismwishlist_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismwishlist_client.List(
                        lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismwishlist_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismwishlist_name: str = None,
                          organismwishlist_name_full: str = None,
                          iri: str = None,) -> str:
        if organismwishlist_name is not None:
            filter_dict = {"name": organismwishlist_name}
        elif organismwishlist_name_full is not None:
            filter_dict = {"name_full": organismwishlist_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismwishlist_client.List(
                    lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismwishlist_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismwishlist_id
            else:
                raise ValueError(f"Error retrieving organismwishlist_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismwishlist_client.List(lara_django_organisms_store_pb2.OrganismWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismwishlist_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismwishlist_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismwishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismwishlist : organisms_store_dm.OrganismWishlist = None) -> None:
        try:
            await self.organismwishlist_client.Update(
                lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismwishlist_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismwishlist_client.Destroy(lara_django_organisms_store_pb2.OrganismWishlistDestroyRequest(organismwishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismwishlist_id: {e}")

#_________________  OrganismBasket  ______________________


class OrganismBasketInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismbasket_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismBasketclassByIRIControllerStub(channel)
        # )
        
        self.organismbasket_client = lara_django_organisms_store_pb2_grpc.OrganismBasketControllerStub(channel)

        # self.organismbasket_full_client = lara_django_organisms_store_pb2_grpc.OrganismBasketFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismbaskets:  list[organisms_store_dm.OrganismBasket] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismBasket]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismbasketclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismbasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismbasket_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismBasketclassRetrieveRequest(iri=organismbasket_class_iri)
        #     )
        #     organismbasketclass_id = res.organismbasketclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismbasketclass_id: {e}")
        # for organismbasket in organismbaskets:
        #     organismbasket.namespace = self.namespace_id
        #     organismbasket.organismbasket_class = organismbasketclass_id

        try:
            create_coroutines = ( self.organismbasket_client.Create(lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump())) for organismbasket in organismbaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismbasket_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismbasket: {e}")

    @export_file
    async def retrieve(
        self, 
        organismbasket_id: str = None,
        organismbasket_name: str = None,
        #organismbasket_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismBasket]:
        filter_list = []
        results_list = []
        if  organismbasket_id is not None:
            try:
                res =  await self.organismbasket_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismBasketRetrieveRequest(organismbasket_id=organismbasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismbasket_id: {e}")

        if organismbasket_name is not None:
            filter_list.append({"name": organismbasket_name})
        # if organismbasket_name_full is not None:
        #     filter_list.append({"name_full": organismbasket_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismbasket_client.List(
                        lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismbasket_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismbasket_name: str = None,
                          organismbasket_name_full: str = None,
                          iri: str = None,) -> str:
        if organismbasket_name is not None:
            filter_dict = {"name": organismbasket_name}
        elif organismbasket_name_full is not None:
            filter_dict = {"name_full": organismbasket_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismbasket_client.List(
                    lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismbasket_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismbasket_id
            else:
                raise ValueError(f"Error retrieving organismbasket_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismbasket_client.List(lara_django_organisms_store_pb2.OrganismBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismbasket_client.List(
                lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismbasket_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismbasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismbasket : organisms_store_dm.OrganismBasket = None) -> None:
        try:
            await self.organismbasket_client.Update(
                lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismbasket_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismbasket_client.Destroy(lara_django_organisms_store_pb2.OrganismBasketDestroyRequest(organismbasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismbasket_id: {e}")

#_________________  OrganismOrder  ______________________


class OrganismOrderInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismorder_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismOrderclassByIRIControllerStub(channel)
        # )
        
        self.organismorder_client = lara_django_organisms_store_pb2_grpc.OrganismOrderControllerStub(channel)

        # self.organismorder_full_client = lara_django_organisms_store_pb2_grpc.OrganismOrderFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismorders:  list[organisms_store_dm.OrganismOrder] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismOrder]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismorderclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismorder_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismOrderclassRetrieveRequest(iri=organismorder_class_iri)
        #     )
        #     organismorderclass_id = res.organismorderclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismorderclass_id: {e}")
        # for organismorder in organismorders:
        #     organismorder.namespace = self.namespace_id
        #     organismorder.organismorder_class = organismorderclass_id

        try:
            create_coroutines = ( self.organismorder_client.Create(lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump())) for organismorder in organismorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismorder_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismorder: {e}")

    @export_file
    async def retrieve(
        self, 
        organismorder_id: str = None,
        organismorder_name: str = None,
        #organismorder_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrder]:
        filter_list = []
        results_list = []
        if  organismorder_id is not None:
            try:
                res =  await self.organismorder_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderRetrieveRequest(organismorder_id=organismorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismorder_id: {e}")

        if organismorder_name is not None:
            filter_list.append({"name": organismorder_name})
        # if organismorder_name_full is not None:
        #     filter_list.append({"name_full": organismorder_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorder_client.List(
                        lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismorder_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismorder_name: str = None,
                          organismorder_name_full: str = None,
                          iri: str = None,) -> str:
        if organismorder_name is not None:
            filter_dict = {"name": organismorder_name}
        elif organismorder_name_full is not None:
            filter_dict = {"name_full": organismorder_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismorder_client.List(
                    lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismorder_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismorder_id
            else:
                raise ValueError(f"Error retrieving organismorder_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismorder_client.List(lara_django_organisms_store_pb2.OrganismOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorder_client.List(
                lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorder_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismorder : organisms_store_dm.OrganismOrder = None) -> None:
        try:
            await self.organismorder_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismorder_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismorder_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderDestroyRequest(organismorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismorder_id: {e}")

#_________________  OrganismsLocalStore  ______________________


class OrganismsLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.organismlocalstore_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreclassByIRIControllerStub(channel)
        # )
        
        self.organismlocalstore_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreControllerStub(channel)

        # self.organismlocalstore_full_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  organismlocalstores:  list[organisms_store_dm.OrganismsLocalStore] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismsLocalStore]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # organismlocalstoreclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismlocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismlocalstore_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismsLocalStoreclassRetrieveRequest(iri=organismlocalstore_class_iri)
        #     )
        #     organismlocalstoreclass_id = res.organismlocalstoreclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving organismlocalstoreclass_id: {e}")
        # for organismlocalstore in organismlocalstores:
        #     organismlocalstore.namespace = self.namespace_id
        #     organismlocalstore.organismlocalstore_class = organismlocalstoreclass_id

        try:
            create_coroutines = ( self.organismlocalstore_client.Create(lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismlocalstore.model_dump())) for organismlocalstore in organismlocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismlocalstore_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating organismlocalstore: {e}")

    @export_file
    async def retrieve(
        self, 
        organismlocalstore_id: str = None,
        organismlocalstore_name: str = None,
        #organismlocalstore_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismsLocalStore]:
        filter_list = []
        results_list = []
        if  organismlocalstore_id is not None:
            try:
                res =  await self.organismlocalstore_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveRequest(organismlocalstore_id=organismlocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving organismlocalstore_id: {e}")

        if organismlocalstore_name is not None:
            filter_list.append({"name": organismlocalstore_name})
        # if organismlocalstore_name_full is not None:
        #     filter_list.append({"name_full": organismlocalstore_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismlocalstore_client.List(
                        lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving organismlocalstore_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          organismlocalstore_name: str = None,
                          organismlocalstore_name_full: str = None,
                          iri: str = None,) -> str:
        if organismlocalstore_name is not None:
            filter_dict = {"name": organismlocalstore_name}
        elif organismlocalstore_name_full is not None:
            filter_dict = {"name_full": organismlocalstore_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.organismlocalstore_client.List(
                    lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving organismlocalstore_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].organismlocalstore_id
            else:
                raise ValueError(f"Error retrieving organismlocalstore_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.organismlocalstore_client.List(lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismlocalstore_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismlocalstore_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.organismlocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismlocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismlocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, organismlocalstore : organisms_store_dm.OrganismsLocalStore = None) -> None:
        try:
            await self.organismlocalstore_client.Update(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismlocalstore.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating organismlocalstore_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.organismlocalstore_client.Destroy(lara_django_organisms_store_pb2.OrganismsLocalStoreDestroyRequest(organismlocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting organismlocalstore_id: {e}")

