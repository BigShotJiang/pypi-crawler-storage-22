# LARA Django Organisms Store - gRPC API

This package provides a gRPC interface to the LARA Django Organisms Store, enabling high-performance remote procedure calls for managing organism instances and related data.

## Overview

The `lara_django_organisms_store_grpc` package offers a strongly-typed, efficient gRPC API for interacting with the LARA Django Organisms Store. It supports operations on:

- **OrganismInstances**: Individual organism records with origin, location, and metadata
- **OrganismBaskets**: Collections of organism instances
- **OrganismLocalStore**: Local storage management for organisms
- **OrganismInstancesSubset**: Filtered subsets of organism data
- **ExtraData**: Additional metadata and extended information

## Installation

### Requirements

- Python 3.13.*
- gRPC runtime (`grpcio>=1.73.0`)

### Install from source

```bash
cd api/grpc
pip install .
```

### Development installation

For development with additional tools:

```bash
pip install -e ".[dev]"
```

This includes:
- `grpcio-tools` - For protocol buffer compilation
- `pytest` - Testing framework
- `pytest-cov` - Coverage reporting
- `pytest-asyncio` - Async testing support

## Usage

### Basic Client Example

```python
import grpc
from lara_django_organisms_store_grpc import organism_service_pb2
from lara_django_organisms_store_grpc import organism_service_pb2_grpc

# Create a gRPC channel
channel = grpc.insecure_channel('localhost:50051')

# Create a stub (client)
stub = organism_service_pb2_grpc.OrganismServiceStub(channel)

# Make a request
response = stub.GetOrganism(
    organism_service_pb2.GetOrganismRequest(organism_id="123")
)

print(f"Organism: {response.name}")
```

### Server Setup

The gRPC server is typically integrated with the Django application. Refer to the main LARA Django Organisms Store documentation for server configuration.

## Development

### Running Tests

```bash
pytest
```

### Running Tests with Coverage

```bash
pytest --cov=lara_django_organisms_store_grpc
```

### Regenerating Protocol Buffers

If you modify the `.proto` files, regenerate the Python code:

```bash
cd api
buf generate
```

## API Documentation

For detailed API documentation, see:
- [Main Documentation](https://larasuite.gitlab.io/lara-django-organisms-store/)
- [Protocol Buffer Definitions](../proto/lara_django_organisms_store_grpc/)

## Project Structure

```
api/grpc/
├── README.md                     # This file
├── pyproject.toml                # Package configuration
└── python/                       # Python module root
    └── lara_django_organisms_store_grpc/
        ├── __init__.py
        └── *_pb2.py              # Generated protocol buffer code
```

## Links

- **Documentation**: https://larasuite.gitlab.io/lara-django-organisms-store/
- **Source Code**: https://gitlab.com/larasuite/lara-django-organisms-store
- **Issue Tracker**: https://gitlab.com/larasuite/lara-django-organisms-store/-/issues

## License

See the LICENSE file in the project root for license information.


## Contributing

Contributions are welcome! Please see the [CONTRIBUTING.md](../../CONTRIBUTING.md) file in the project root for guidelines.

## Authors

- Mark Doerr <mark.doerr@uni-greifswald.de>
