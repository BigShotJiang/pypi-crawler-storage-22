from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class OrganismBasketDestroyRequest(_message.Message):
    __slots__ = ("organismbasket_id",)
    ORGANISMBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    organismbasket_id: str
    def __init__(self, organismbasket_id: _Optional[str] = ...) -> None: ...

class OrganismBasketListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismBasketListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismBasketResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismBasketResponse, _Mapping]]] = ...) -> None: ...

class OrganismBasketPartialUpdateRequest(_message.Message):
    __slots__ = ("organismbasket_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismbasket_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismBasketRequest(_message.Message):
    __slots__ = ("organismbasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismbasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismBasketResponse(_message.Message):
    __slots__ = ("organismbasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismbasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismBasketRetrieveRequest(_message.Message):
    __slots__ = ("organismbasket_id",)
    ORGANISMBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    organismbasket_id: str
    def __init__(self, organismbasket_id: _Optional[str] = ...) -> None: ...

class OrganismBasketStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismInstanceDestroyRequest(_message.Message):
    __slots__ = ("organisminstance_id",)
    ORGANISMINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    organisminstance_id: str
    def __init__(self, organisminstance_id: _Optional[str] = ...) -> None: ...

class OrganismInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismInstanceResponse, _Mapping]]] = ...) -> None: ...

class OrganismInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("organisminstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "organism", "organism_instances", "data_extra", "_partial_update_fields", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "sex", "hybrid", "chimeric", "traits", "genome", "habitat", "image", "genomes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    ORGANISMINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEX_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERIC_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HABITAT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    GENOMES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    organisminstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    organism: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    sex: str
    hybrid: bool
    chimeric: bool
    traits: _struct_pb2.Struct
    genome: str
    habitat: _struct_pb2.Struct
    image: str
    genomes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, organisminstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., organism: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., sex: _Optional[str] = ..., hybrid: bool = ..., chimeric: bool = ..., traits: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., genome: _Optional[str] = ..., habitat: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., image: _Optional[str] = ..., genomes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class OrganismInstanceRequest(_message.Message):
    __slots__ = ("organisminstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "organism", "organism_instances", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "sex", "hybrid", "chimeric", "traits", "genome", "habitat", "image", "genomes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    ORGANISMINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEX_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERIC_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HABITAT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    GENOMES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    organisminstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    organism: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    sex: str
    hybrid: bool
    chimeric: bool
    traits: _struct_pb2.Struct
    genome: str
    habitat: _struct_pb2.Struct
    image: str
    genomes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, organisminstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., organism: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., sex: _Optional[str] = ..., hybrid: bool = ..., chimeric: bool = ..., traits: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., genome: _Optional[str] = ..., habitat: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., image: _Optional[str] = ..., genomes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class OrganismInstanceResponse(_message.Message):
    __slots__ = ("organisminstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "organism", "organism_instances", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "sex", "hybrid", "chimeric", "traits", "genome", "habitat", "image", "genomes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    ORGANISMINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEX_FIELD_NUMBER: _ClassVar[int]
    HYBRID_FIELD_NUMBER: _ClassVar[int]
    CHIMERIC_FIELD_NUMBER: _ClassVar[int]
    TRAITS_FIELD_NUMBER: _ClassVar[int]
    GENOME_FIELD_NUMBER: _ClassVar[int]
    HABITAT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    GENOMES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    organisminstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    organism: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    sex: str
    hybrid: bool
    chimeric: bool
    traits: _struct_pb2.Struct
    genome: str
    habitat: _struct_pb2.Struct
    image: str
    genomes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, organisminstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., organism: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., sex: _Optional[str] = ..., hybrid: bool = ..., chimeric: bool = ..., traits: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., genome: _Optional[str] = ..., habitat: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., image: _Optional[str] = ..., genomes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class OrganismInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class OrganismInstanceRetrieveRequest(_message.Message):
    __slots__ = ("organisminstance_id",)
    ORGANISMINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    organisminstance_id: str
    def __init__(self, organisminstance_id: _Optional[str] = ...) -> None: ...

class OrganismInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("organisminstancessubset_id",)
    ORGANISMINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    organisminstancessubset_id: str
    def __init__(self, organisminstancessubset_id: _Optional[str] = ...) -> None: ...

class OrganismInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class OrganismInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("organisminstancessubset_id", "namespace", "group", "organism_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organisminstancessubset_id: str
    namespace: str
    group: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organisminstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismInstancesSubsetRequest(_message.Message):
    __slots__ = ("organisminstancessubset_id", "namespace", "group", "organism_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organisminstancessubset_id: str
    namespace: str
    group: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organisminstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismInstancesSubsetResponse(_message.Message):
    __slots__ = ("organisminstancessubset_id", "namespace", "group", "organism_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ORGANISMINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organisminstancessubset_id: str
    namespace: str
    group: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, organisminstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("organisminstancessubset_id",)
    ORGANISMINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    organisminstancessubset_id: str
    def __init__(self, organisminstancessubset_id: _Optional[str] = ...) -> None: ...

class OrganismInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismOrderDestroyRequest(_message.Message):
    __slots__ = ("organismorder_id",)
    ORGANISMORDER_ID_FIELD_NUMBER: _ClassVar[int]
    organismorder_id: str
    def __init__(self, organismorder_id: _Optional[str] = ...) -> None: ...

class OrganismOrderItemDestroyRequest(_message.Message):
    __slots__ = ("organismorderitem_id",)
    ORGANISMORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    organismorderitem_id: str
    def __init__(self, organismorderitem_id: _Optional[str] = ...) -> None: ...

class OrganismOrderItemListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismOrderItemListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismOrderItemResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismOrderItemResponse, _Mapping]]] = ...) -> None: ...

class OrganismOrderItemPartialUpdateRequest(_message.Message):
    __slots__ = ("organismorderitem_id", "organism_instance", "data_extra", "_partial_update_fields", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "organism_wishlist", "organism_basket", "organism_order")
    ORGANISMORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_BASKET_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_ORDER_FIELD_NUMBER: _ClassVar[int]
    organismorderitem_id: str
    organism_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    organism_wishlist: str
    organism_basket: str
    organism_order: str
    def __init__(self, organismorderitem_id: _Optional[str] = ..., organism_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., organism_wishlist: _Optional[str] = ..., organism_basket: _Optional[str] = ..., organism_order: _Optional[str] = ...) -> None: ...

class OrganismOrderItemRequest(_message.Message):
    __slots__ = ("organismorderitem_id", "organism_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "organism_wishlist", "organism_basket", "organism_order")
    ORGANISMORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_BASKET_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_ORDER_FIELD_NUMBER: _ClassVar[int]
    organismorderitem_id: str
    organism_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    organism_wishlist: str
    organism_basket: str
    organism_order: str
    def __init__(self, organismorderitem_id: _Optional[str] = ..., organism_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., organism_wishlist: _Optional[str] = ..., organism_basket: _Optional[str] = ..., organism_order: _Optional[str] = ...) -> None: ...

class OrganismOrderItemResponse(_message.Message):
    __slots__ = ("organismorderitem_id", "organism_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "organism_wishlist", "organism_basket", "organism_order")
    ORGANISMORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_BASKET_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_ORDER_FIELD_NUMBER: _ClassVar[int]
    organismorderitem_id: str
    organism_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    organism_wishlist: str
    organism_basket: str
    organism_order: str
    def __init__(self, organismorderitem_id: _Optional[str] = ..., organism_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., organism_wishlist: _Optional[str] = ..., organism_basket: _Optional[str] = ..., organism_order: _Optional[str] = ...) -> None: ...

class OrganismOrderItemRetrieveRequest(_message.Message):
    __slots__ = ("organismorderitem_id",)
    ORGANISMORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    organismorderitem_id: str
    def __init__(self, organismorderitem_id: _Optional[str] = ...) -> None: ...

class OrganismOrderItemStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismOrderListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismOrderListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismOrderResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismOrderResponse, _Mapping]]] = ...) -> None: ...

class OrganismOrderPartialUpdateRequest(_message.Message):
    __slots__ = ("organismorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "_partial_update_fields", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "entity_ordered", "entity_ordering", "budget_url")
    ORGANISMORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    organismorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity_ordered: str
    entity_ordering: str
    budget_url: str
    def __init__(self, organismorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ..., budget_url: _Optional[str] = ...) -> None: ...

class OrganismOrderRequest(_message.Message):
    __slots__ = ("organismorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "entity_ordered", "entity_ordering", "budget_url")
    ORGANISMORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    organismorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity_ordered: str
    entity_ordering: str
    budget_url: str
    def __init__(self, organismorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ..., budget_url: _Optional[str] = ...) -> None: ...

class OrganismOrderResponse(_message.Message):
    __slots__ = ("organismorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "entity_ordered", "entity_ordering", "budget_url")
    ORGANISMORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    organismorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity_ordered: str
    entity_ordering: str
    budget_url: str
    def __init__(self, organismorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ..., budget_url: _Optional[str] = ...) -> None: ...

class OrganismOrderRetrieveRequest(_message.Message):
    __slots__ = ("organismorder_id",)
    ORGANISMORDER_ID_FIELD_NUMBER: _ClassVar[int]
    organismorder_id: str
    def __init__(self, organismorder_id: _Optional[str] = ...) -> None: ...

class OrganismOrderStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismWishlistDestroyRequest(_message.Message):
    __slots__ = ("organismwishlist_id",)
    ORGANISMWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    organismwishlist_id: str
    def __init__(self, organismwishlist_id: _Optional[str] = ...) -> None: ...

class OrganismWishlistListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismWishlistListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismWishlistResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismWishlistResponse, _Mapping]]] = ...) -> None: ...

class OrganismWishlistPartialUpdateRequest(_message.Message):
    __slots__ = ("organismwishlist_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismwishlist_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismWishlistRequest(_message.Message):
    __slots__ = ("organismwishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismwishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismWishlistResponse(_message.Message):
    __slots__ = ("organismwishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismwishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismWishlistRetrieveRequest(_message.Message):
    __slots__ = ("organismwishlist_id",)
    ORGANISMWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    organismwishlist_id: str
    def __init__(self, organismwishlist_id: _Optional[str] = ...) -> None: ...

class OrganismWishlistStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismsLocalStoreDestroyRequest(_message.Message):
    __slots__ = ("organismlocalstore_id",)
    ORGANISMLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    organismlocalstore_id: str
    def __init__(self, organismlocalstore_id: _Optional[str] = ...) -> None: ...

class OrganismsLocalStoreListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class OrganismsLocalStoreListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[OrganismsLocalStoreResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[OrganismsLocalStoreResponse, _Mapping]]] = ...) -> None: ...

class OrganismsLocalStorePartialUpdateRequest(_message.Message):
    __slots__ = ("organismlocalstore_id", "namespace", "organism_instances", "location", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismlocalstore_id: str
    namespace: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsLocalStoreRequest(_message.Message):
    __slots__ = ("organismlocalstore_id", "namespace", "organism_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismlocalstore_id: str
    namespace: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsLocalStoreResponse(_message.Message):
    __slots__ = ("organismlocalstore_id", "namespace", "organism_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    ORGANISMLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    organismlocalstore_id: str
    namespace: str
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, organismlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., organism_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class OrganismsLocalStoreRetrieveRequest(_message.Message):
    __slots__ = ("organismlocalstore_id",)
    ORGANISMLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    organismlocalstore_id: str
    def __init__(self, organismlocalstore_id: _Optional[str] = ...) -> None: ...

class OrganismsLocalStoreStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
