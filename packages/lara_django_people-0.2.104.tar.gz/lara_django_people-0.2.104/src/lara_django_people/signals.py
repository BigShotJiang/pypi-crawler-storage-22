from django.dispatch import receiver
from django.db.models.signals import post_save, pre_save
from allauth.account.models import EmailAddress
from django.contrib.postgres.search import SearchVector
from lara_django_base.decorators import postgres_only

from .models import ExtraData,  Entity,  Group


@receiver(post_save, sender=ExtraData)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector('name', weight='A') +
            SearchVector('name_display', weight='B') +
            SearchVector('description', weight='C')
        )
    )

@receiver(post_save, sender=Entity)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector('name_full', weight='A') +
            SearchVector('name_first', weight='B') +
            SearchVector('acronym', weight='C') +
            SearchVector('name_last', weight='D') +
            SearchVector('description', weight='E')
        )
    )

@receiver(post_save, sender=Group)
@postgres_only
def update_search_vector(sender, instance, **kwargs):
    sender.objects.filter(pk=instance.pk).update(
        search_vector=(
            SearchVector('name', weight='A') +
            SearchVector('name_full', weight='B')
        )
    )

# @receiver(post_save, sender=LaraUser)       
# def user_postsave_disa(sender, instance, created, **kwargs):
#     lara_user = instance
    
    # add profile if user is created
    # if created:
    #     entity = Entity.objects.get_or_create(
    #         name_full = lara_user.username,
    #         entity_class = EntityClass.objects.get(name='person'),
    #         # entity_role = EntityRole.objects.get(name='User'),
            
    #     )
    # else:
    #     pass
        # # update allauth emailaddress if exists 
        # try:
        #     email_address = EmailAddress.objects.get_primary(user)
        #     if email_address.email != user.email:
        #         email_address.email = user.email
        #         email_address.verified = False
        #         email_address.save()
        # except:
        #     # if allauth emailaddress doesn't exist create one
        #     EmailAddress.objects.create(
        #         user = user,
        #         email = user.email, 
        #         primary = True,
        #         verified = False
        #     )
from django.dispatch import receiver
from django.db.models.signals import post_save
from lara_django_base.decorators import postgres_only

from .semantics import insert_semantic_data

logger = logging.getLogger('lara_signals')


# @receiver(post_save, sender=Evaluation)
# def semantics_data_handler(sender, instance, created, **kwargs):
#     """Semantic data post_save signal handler.

#        This function is triggered after an instance of the Evaluation model is saved.
#        It calls the insert_semantics function to handle the semantic data insertion
#        into the triplestore, running asynchronously as celery task.
#     """
#     logger.debug("post_save_handler1: %s, %s ", sender, instance)

#     insert_semantic_data(sender, instance, **kwargs)


# @receiver(post_save, sender=Evaluation)
# @postgres_only
# def update_search_vector(sender, instance, **kwargs):
#     sender.objects.filter(pk=instance.pk).update(
#         search_vector=(
#             SearchVector('name', weight='A') +
#             SearchVector('name_display', weight='B') +
#             SearchVector('description', weight='C') +
#             SearchVector('caption', weight='D')
#         )
#     )