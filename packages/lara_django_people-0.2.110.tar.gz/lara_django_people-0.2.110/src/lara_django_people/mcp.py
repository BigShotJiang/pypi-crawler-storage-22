"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_people Model Context Protocol (MCP) handler *

:details: lara_django_people Model Context Protocol (MCP) handler.

:authors: mark doerr <mark.doerr@uni-greifswald.de>

________________________________________________________________________
"""

from mcp_server import ModelQueryToolset

from .models import Contact, Entity, EntityClass, EntityRole, Group

# from .models import Bird

# class BirdQueryTool(ModelQueryToolset):
#     model = Bird

#     def get_queryset(self):
#         """
#         Returns a queryset of all birds with a location.

#         This is used to filter the queryset for the admin interface.
#         self.request can be used to filter the queryset
#         """
#         return super().get_queryset().filter(location__isnull=False)


class EntityClassQueryTool(ModelQueryToolset):  # noqa: D101
    model = EntityClass

class EntityRoleQueryTool(ModelQueryToolset):  # noqa: D101
    model = EntityRole

class EntityQueryTool(ModelQueryToolset):  # noqa: D101
    model = Entity

class GroupQueryTool(ModelQueryToolset):  # noqa: D101
    model = Group

class ContactQueryTool(ModelQueryToolset):  # noqa: D101
    model = Contact

