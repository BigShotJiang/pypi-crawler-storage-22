"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences admin *

:details: lara_django_sequences admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_sequences >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import ExtraData, Sequence, SequenceClass


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    """Admin interface for ExtraData model."""

    list_display = (
        "name",
        "namespace",
        "data_type",
        "description",
        "extradata_id",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(SequenceClass)
class SequenceClassAdmin(admin.ModelAdmin):
    """Admin interface for SequenceClass model."""

    list_display = (
        "name",
        "description",
        "sequenceclass_id",
    )
    search_fields = ("name",)


@admin.register(Sequence)
class SequenceAdmin(admin.ModelAdmin):
    """Admin interface for Sequence model."""

    list_display = (
        "name",
        "namespace",
        "sequence_class",
        "status",
        "description",
        "sequence_id",
    )
    list_filter = ("namespace", "sequence_class", "media_type", "status")
    raw_id_fields = ("tags",)
    search_fields = ("name",)
