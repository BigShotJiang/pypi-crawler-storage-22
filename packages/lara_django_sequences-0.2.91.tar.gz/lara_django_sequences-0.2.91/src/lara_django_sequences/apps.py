"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences app *

:details: lara_django_sequences app configuration.
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.apps import AppConfig


class LaraDjangoSequencesConfig(AppConfig):
    """
    Configuration class for the LARA-django Sequences app.

    This class defines the app's name, URL path, verbose name,
    icon, color, and description.
    It also specifies the apps that will be included in the LARA instance.
    """

    name = "lara_django_sequences"
    url_path = "sequences/"
    # enter a verbose name for your app: lara_django_sequences here - this will be used in the admin interface
    verbose_name = "LARA-django Sequences"
    lara_app_icon = (
        "lara_django_sequences_icon.svg"  # this will be used to display an icon, e.g. in the main LARA menu.
    )
    lara_app_color = "indigo"  # this will be used to highlight the app in the main LARA sidebar and app page
    verbose_name_short = "Sequences"
    lara_app_description = "Sequences and Sequence Sets"
    lara_class_apps = (
        {
            "name": "Sequences",
            "path": "lara_django_people:entity-list",  # "/projects/project/list",
            "icon": "lara_projects_icon.svg",
            "color": lara_app_color,
        },
        {
            "name": "Sequence Sets",
            "path": "lara_django_people:entity-list",  # "/projects/project/list",
            "icon": "lara_projects_icon.svg",
            "color": lara_app_color,
        },
    )
    lara_instance_apps = ()

    def ready(self):
        """
        Ready method for the app configuration.

        This method is called when the app is ready to be used.

        :TODO: add urlpatterns
        It includes the app's URLs in the main LARA URL configuration.
        """
        from django.urls import include, path
        from lara_django.urls import urlpatterns

        urlpatterns += [
            path(self.url_path, include("lara_django_sequences.urls", namespace="lara_django_sequences")),
        ]
