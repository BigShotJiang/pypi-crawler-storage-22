"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_sequences admin *

:details: lara_django_sequences admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_sequences > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from django import forms

from .models import ExtraData, Sequence, SequenceClass


class ExtraDataCreateForm(forms.ModelForm):
    """
    Form for creating ExtraData instances.

    This form includes fields for all attributes of the ExtraData model,
    allowing users to input data for each field.
    It uses crispy forms for better layout and styling.
    """

    class Meta:
        """Meta configuration for ExtraDataCreateForm."""

        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
            Submit("submit", "Create"),
        )


class ExtraDataUpdateForm(forms.ModelForm):
    """
    Form for updating ExtraData instances.

    This form includes the same fields as the create form but with
    an update submit button.
    """

    class Meta:
        """Meta configuration for ExtraDataUpdateForm."""

        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "image",
            "file",
            Submit("submit", "Update"),
        )


class SequenceClassCreateForm(forms.ModelForm):
    """Form for creating SequenceClass instances."""

    class Meta:
        """Meta configuration for SequenceClassCreateForm."""

        model = SequenceClass
        fields = ("name", "iri", "description")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "iri", "description", Submit("submit", "Create"))


class SequenceClassUpdateForm(forms.ModelForm):
    """Form for updating SequenceClass instances."""

    class Meta:
        """Meta configuration for SequenceClassUpdateForm."""

        model = SequenceClass
        fields = ("name", "iri", "description")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "iri", "description", Submit("submit", "Update"))


class SequenceCreateForm(forms.ModelForm):
    """Form for creating Sequence instances."""

    class Meta:
        """Meta configuration for SequenceCreateForm."""

        model = Sequence
        fields = (
            "namespace",
            "name",
            "hash_sha256",
            "sequence_class",
            "media_type",
            "sequence_file",
            "status",
            "description",
            "iri",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "name",
            "hash_sha256",
            "sequence_class",
            "media_type",
            "sequence_file",
            "status",
            "description",
            "iri",
            Submit("submit", "Create"),
        )


class SequenceUpdateForm(forms.ModelForm):
    """Form for updating Sequence instances."""

    class Meta:
        """Meta configuration for SequenceUpdateForm."""

        model = Sequence
        fields = (
            "namespace",
            "name",
            "hash_sha256",
            "sequence_class",
            "media_type",
            "sequence_file",
            "status",
            "description",
            "iri",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "name",
            "hash_sha256",
            "sequence_class",
            "media_type",
            "sequence_file",
            "status",
            "description",
            "iri",
            Submit("submit", "Update"),
        )
