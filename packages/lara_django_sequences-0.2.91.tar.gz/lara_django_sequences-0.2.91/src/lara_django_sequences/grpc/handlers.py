"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_sequences  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry

from lara_django_sequences.grpc.services import ExtraDataService
from lara_django_sequences.grpc.services import SequenceClassService
from lara_django_sequences.grpc.services import SequenceFullService  # SequenceByNameService,
from lara_django_sequences.grpc.services import SequenceService
from lara_django_sequences.grpc.services import SequencesSubsetService


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_sequences", server)

    app_registry.get_grpc_module = lambda: "lara_django_sequences_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(SequenceClassService)

    app_registry.register(SequenceService)

    # app_registry.register(SequenceByNameService)

    app_registry.register(SequenceFullService)

    app_registry.register(SequencesSubsetService)
