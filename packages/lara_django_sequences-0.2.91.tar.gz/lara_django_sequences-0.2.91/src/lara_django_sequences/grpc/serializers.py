"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_sequences  (LARA-version)

from django_socio_grpc import proto_serializers
from lara_django_base.grpc.serializers import ItemStatusProtoSerializer
from lara_django_base.grpc.serializers import MediaTypeProtoSerializer
from lara_django_base.grpc.serializers import NamespaceProtoSerializer
from lara_django_base.models import DataType
from lara_django_base.models import ItemStatus
from lara_django_base.models import MediaType
from lara_django_base.models import Namespace
from lara_django_base.models import Tag
from lara_django_people.models import Entity
from lara_django_people.models import Group
from lara_django_sequences_grpc.v1 import lara_django_sequences_pb2
from rest_framework.serializers import PrimaryKeyRelatedField
from rest_framework.serializers import UUIDField

from lara_django_sequences.models import ExtraData
from lara_django_sequences.models import Sequence
from lara_django_sequences.models import SequenceClass
from lara_django_sequences.models import SequencesSubset


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_sequences_pb2.ExtraDataResponse

        proto_class_list = lara_django_sequences_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', image', file']


class SequenceClassProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = SequenceClass
        proto_class = lara_django_sequences_pb2.SequenceClassResponse

        proto_class_list = lara_django_sequences_pb2.SequenceClassListResponse

        fields = "__all__"  # [name', description']


class SequenceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    sequence_class = PrimaryKeyRelatedField(
        queryset=SequenceClass.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceResponse

        proto_class_list = lara_django_sequences_pb2.SequenceListResponse

        fields = "__all__"  # [namespace', name', name_full', UUID', hash_sha256', sequence_class', sequence', media_type', sequence_file', status', description', URI', IRI']


class SequenceByNameProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    sequence_class = PrimaryKeyRelatedField(
        queryset=SequenceClass.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceResponse

        proto_class_list = lara_django_sequences_pb2.SequenceListResponse

        fields = "__all__"  # [namespace', name', name_full', UUID', hash_sha256', sequence_class', sequence', media_type', sequence_file', status', description', URI', IRI']


class SequencesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    sequences = PrimaryKeyRelatedField(
        queryset=Sequence.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = SequencesSubset
        proto_class = lara_django_sequences_pb2.SequencesSubsetResponse

        proto_class_list = lara_django_sequences_pb2.SequencesSubsetListResponse

        fields = "__all__"


class SequenceFullProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = NamespaceProtoSerializer(read_only=True)
    sequence_class = SequenceClassProtoSerializer(read_only=True)
    media_type = MediaTypeProtoSerializer(read_only=True)
    status = ItemStatusProtoSerializer(read_only=True)

    class Meta:
        model = Sequence
        proto_class = lara_django_sequences_pb2.SequenceFullResponse

        proto_class_list = lara_django_sequences_pb2.SequenceFullListResponse

        fields = "__all__"  # [namespace', name', name_full', UUID', hash_sha256', sequence_class', sequence', media_type', sequence_file', status', description', URI', IRI']
