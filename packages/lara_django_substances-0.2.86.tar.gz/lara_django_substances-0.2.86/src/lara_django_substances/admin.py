"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances admin *

:details: lara_django_substances admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_substances >> admin.py" to update this file
________________________________________________________________________
"""
# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import (
    ExtraData,
    SubstanceClass,
    Isotope,
    IsotopesSubset,
    Substance,
    SubstancesSubset,
    Polymer,
    MixtureComponent,
    Mixture,
    MixturesSubset,
    MoleculeResidue,
    ReactionComponent,
    ReactionComponentsSubset,
    Reaction,
    ReactionsSubset,
    MultiStepReaction,
    MultiStepReactionsSubset
)


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "data_type",
        "namespace",
        "media_type",
        "url",
        "description",
        "extradata_id",
        "file",
        "image",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(SubstanceClass)
class SubstanceClassAdmin(admin.ModelAdmin):
    list_display = ("substanceclass_id", "name", "description")


@admin.register(Isotope)
class IsotopeAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "acronym",
        "synonyms",
        "cas",
        "iupac_name",
        "pubchem_cid",
        "pubchem_sid",
        "url",
        "url_definition",
        "description",
        "isotope_id",
        "num_protons",
        "electron_config",
    )
    raw_id_fields = ("substance_classes", "data_extra", "tags")
    search_fields = ("name",)

@admin.register(IsotopesSubset)
class IsotopesSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
        "isotopessubset_id",
    )
    raw_id_fields = ("isotopes",)

@admin.register(Substance)
class SubstanceAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "acronym",
        "synonyms",
        "cas",
        "iupac_name",
        "pubchem_cid",
        "pubchem_sid",
        "sumformula",
        "smiles",
        "pdb_id",
        "mass_molar",
        "density",
        "melting_point",
        "boiling_point",
        "substance_id",
    )
    raw_id_fields = ("substance_classes", "data_extra", "tags")
    search_fields = ("name",)

@admin.register(SubstancesSubset)
class SubstancesSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
        "substancessubset_id",
    )
    raw_id_fields = ("substances",)

@admin.register(Polymer)
class PolymerAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "acronym",
        "synonyms",
        "cas",
        "iupac_name",
        "pubchem_cid",
        "pubchem_sid",
        "sumformula",
        "description",
        "melting_point",
        "boiling_point",
        "polymer_id",
    )
    list_filter = ("sequence", "media_type")
    raw_id_fields = ("substance_classes", "data_extra", "tags")
    search_fields = ("name",)

@admin.register(MixturesSubset)
class MixturesSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
        "mixturessubset_id",
    )
    raw_id_fields = ("mixtures",)

@admin.register(MixtureComponent)
class MixtureComponentAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "substance",
        "polymer",
        "concentration",
        "description",
        "mixturecomponent_id",
    )
    list_filter = ("substance", "polymer")
    search_fields = ("name",)


@admin.register(Mixture)
class MixtureAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "acronym",
        "synonyms",
        "cas",
        "iupac_name",
        "ec_num",
        "mdl_num",
        "pdb_id",
        "properties",
        "sumformula",
        "remarks",
        "description",
        "mixture_id",
    )
    raw_id_fields = ("substance_classes", "data_extra", "tags", "components")
    search_fields = ("name",)


@admin.register(MoleculeResidue)
class MoleculeResiduesAdmin(admin.ModelAdmin):
    list_display = ("moleculeresidue_id", "name", "substructure", "iri")
    search_fields = ("name",)


@admin.register(ReactionComponent)
class ReactionComponentAdmin(admin.ModelAdmin):
    list_display = (
        "reactioncomponent_id",
        "substance",
        "polymer",
        "mixture",
        "order",
        "stoichiometric_factor",
        "physical_state",
    )
    list_filter = ("substance", "polymer", "mixture", "physical_state")
    raw_id_fields = ("roles",)

@admin.register(ReactionComponentsSubset)
class ReactionComponentsSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
        "reactioncomponentssubset_id",
    )
    raw_id_fields = ("reaction_components",)

@admin.register(Reaction)
class ReactionAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "label",
        "rx_uuid",
        "rinchi",
        "rinchi_key_short",
        "rinchi_key_long",
        "rinchi_web_key",
        "rxno",
        "equilibrium_const",
        "deltag",
        "order",
        "safety_info",
        "description",
        "remarks",
        "reaction_id",
    )
    raw_id_fields = ("components", "data_extra")
    search_fields = ("name",)


@admin.register(ReactionsSubset)
class ReactionsSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
       # "reactions_subset_id",
    )
    raw_id_fields = ("reactions",)



@admin.register(MultiStepReaction)
class MultiStepReactionAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
        "remarks",
        "multistepreaction_id",
    )
    raw_id_fields = ("reactions", "data_extra")
    search_fields = ("name",)


@admin.register(MultiStepReactionsSubset)
class MultiStepReactionsSubsetAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "description",
        "multistepreactionssubset_id",
    )
   