"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances app *

:details: lara_django_substances app configuration. 
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from django.apps import AppConfig


class LaraDjangoSubstancesConfig(AppConfig):
    name = 'lara_django_substances'
    url_path = 'substances/'
    # enter a verbose name for your app: lara_django_substances here - this will be used in the admin interface
    verbose_name = 'LARA-django Substances'
    lara_app_icon = 'lara_django_substances_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = 'teal'  # this will be used to highlight the app in the main LARA sidebar and app page

    def ready(self):
        # add urlpatterns 
        from django.urls import path, include
        from lara_django.urls import urlpatterns

        urlpatterns += [ 
            path(self.url_path, include('lara_django_substances.urls', namespace='lara_django_substances')),
        ]
