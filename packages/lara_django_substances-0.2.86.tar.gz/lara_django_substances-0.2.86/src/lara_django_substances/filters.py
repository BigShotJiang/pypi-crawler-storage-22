"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app. 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from django_filters.rest_framework import FilterSet, CharFilter, DateRangeFilter
import django_filters

from .models import (
    ExtraData,
    Isotope,
    IsotopesSubset,
    Substance,
    SubstancesSubset,
    SubstanceClass,
    Polymer,
    PolymersSubset,
    MixtureComponent,
    Mixture,
    MixturesSubset,
    MoleculeResidue,
    ReactionComponent,
    ReactionComponentsSubset,
    Reaction,
    ReactionsSubset,
    MultiStepReaction,
    MultiStepReactionsSubset,
)

class SubstanceDjFilter(django_filters.FilterSet):
    """Django Filter for Substance model."""

    class Meta:  # noqa: D106
        model = Substance
        fields = ("name", "description", "cas", "smiles", "inchi", "inchikey", "pubchem_cid", "pubchem_sid", 
                  "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", )


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "name_full": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class SubstanceClassFilterSet(FilterSet):
    class Meta:
        model = SubstanceClass
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class IsotopeFilterSet(FilterSet):
    class Meta:
        model = Isotope
        fields = {
            "name": ["exact", "contains"],
            "acronym": ["exact", "contains"],
            "synonyms": ["exact", "contains"],
            "cas": ["exact", "contains"],
            "iupac_name": ["exact", "contains"],
            "pubchem_cid": ["exact", "contains"],
            "pubchem_sid": ["exact", "contains"],
            "pubchem_fingerprint": ["exact", "contains"],
            "chemspider_id": ["exact", "contains"],
            "beilstein_regnum": ["exact", "contains"],
            "ec_num": ["exact", "contains"],
            "mdl_num": ["exact", "contains"],
            "density": ["exact", "lt", "gt", "range"],
            "mass_molar": ["exact", "lt", "gt", "range"],
            "sumformula": ["exact", "contains"],
            "cml": ["exact", "contains"],
            "cdxml": ["exact", "contains"],
            "smiles": ["exact", "contains"],
            "isosmiles": ["exact", "contains"],
            "cansmiles": ["exact", "contains"],
            "inchi": ["exact", "contains"],
            "inchikey": ["exact", "contains"],
            "stdinchi": ["exact", "contains"],
            "pdb_id": ["exact", "contains"],
            "url": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class IsotopesSubsetFilterSet(FilterSet):
    class Meta:
        model = IsotopesSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class SubstanceFilterSet(FilterSet):
    class Meta:
        model = Substance
        fields = {
            "name": ["exact", "contains"],
            "acronym": ["exact", "contains"],
            "synonyms": ["exact", "contains"],
            "cas": ["exact", "contains"],
            "iupac_name": ["exact", "contains"],
            "pubchem_cid": ["exact", "contains"],
            "pubchem_sid": ["exact", "contains"],
            "pubchem_fingerprint": ["exact", "contains"],
            "chemspider_id": ["exact", "contains"],
            "beilstein_regnum": ["exact", "contains"],
            "ec_num": ["exact", "contains"],
            "mdl_num": ["exact", "contains"],
            "density": ["exact", "lt", "gt", "range"],
            "mass_molar": ["exact", "lt", "gt", "range"],
            "sumformula": ["exact", "contains"],
            "cml": ["exact", "contains"],
            "cdxml": ["exact", "contains"],
            "smiles": ["exact", "contains"],
            "isosmiles": ["exact", "contains"],
            "cansmiles": ["exact", "contains"],
            "inchi": ["exact", "contains"],
            "inchikey": ["exact", "contains"],
            "stdinchi": ["exact", "contains"],
            "pdb_id": ["exact", "contains"],
            "url": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class SubstancesSubsetFilterSet(FilterSet):
    class Meta:
        model = SubstancesSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class PolymerFilterSet(FilterSet):
    fields = {
        "name": ["exact", "contains"],
        "acronym": ["exact", "contains"],
        "synonyms": ["exact", "contains"],
        "cas": ["exact", "contains"],
        "iupac_name": ["exact", "contains"],
        "pubchem_cid": ["exact", "contains"],
        "pubchem_sid": ["exact", "contains"],
        "pubchem_fingerprint": ["exact", "contains"],
        "chemspider_id": ["exact", "contains"],
        "beilstein_regnum": ["exact", "contains"],
        "ec_num": ["exact", "contains"],
        "mdl_num": ["exact", "contains"],
        "density": ["exact", "lt", "gt", "range"],
        "mass_molar": ["exact", "lt", "gt", "range"],
        "sumformula": ["exact", "contains"],
        "cml": ["exact", "contains"],
        "cdxml": ["exact", "contains"],
        "smiles": ["exact", "contains"],
        "isosmiles": ["exact", "contains"],
        "cansmiles": ["exact", "contains"],
        "inchi": ["exact", "contains"],
        "inchikey": ["exact", "contains"],
        "stdinchi": ["exact", "contains"],
        "pdb_id": ["exact", "contains"],
        "url": ["exact", "contains"],
        "remarks": ["exact", "contains"],
        "description": ["exact", "contains"],
        "datetime_last_modified": ["lt", "gt", "exact", "range"],
    }

class PolymersSubsetFilterSet(FilterSet):
    class Meta:
        model = PolymersSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class MixtureComponentFilterSet(FilterSet):
    class Meta:
        model = MixtureComponent
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class MixtureFilterSet(FilterSet):
    class Meta:
        model = Mixture
        fields = {
            "name": ["exact", "contains"],
            "acronym": ["exact", "contains"],
            "synonyms": ["exact", "contains"],
            "cas": ["exact", "contains"],
            "iupac_name": ["exact", "contains"],
            "pubchem_cid": ["exact", "contains"],
            "pubchem_sid": ["exact", "contains"],
            "pubchem_fingerprint": ["exact", "contains"],
            "chemspider_id": ["exact", "contains"],
            "beilstein_regnum": ["exact", "contains"],
            "ec_num": ["exact", "contains"],
            "mdl_num": ["exact", "contains"],
            "density": ["exact", "lt", "gt", "range"],
            "mass_molar": ["exact", "lt", "gt", "range"],
            "sumformula": ["exact", "contains"],
            "cml": ["exact", "contains"],
            "cdxml": ["exact", "contains"],
            "smiles": ["exact", "contains"],
            "isosmiles": ["exact", "contains"],
            "cansmiles": ["exact", "contains"],
            "inchi": ["exact", "contains"],
            "inchikey": ["exact", "contains"],
            "stdinchi": ["exact", "contains"],
            "pdb_id": ["exact", "contains"],
            "url": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class MixturesSubsetFilterSet(FilterSet):
    class Meta:
        model = MixturesSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }

class MoleculeResiduesFilterSet(FilterSet):
    class Meta:
        model = MoleculeResidue
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class ReactantFilterSet(FilterSet):
    class Meta:
        model = ReactionComponent
        fields = {
            # "name": ["exact", "contains"],
            # "description": ["exact", "contains"],
        }


class ReactionFilterSet(FilterSet):
    class Meta:
        model = Reaction
        fields = {
            "name": ["exact", "contains"],
            "rinchi": ["exact", "contains"],
            "rinchi_key_short": ["exact", "contains"],
            "rinchi_key_long": ["exact", "contains"],
            "rinchi_web_key": ["exact", "contains"],
            "rxno": ["exact", "contains"],
            "equilibrium_const": ["exact", "lt", "gt", "range"],
            "deltag": ["exact", "lt", "gt", "range"],
            "order": ["exact", "lt", "gt", "range"],
            "remarks": ["exact", "contains"],
            "description": ["exact", "contains"],
        }

class ReactionsSubsetFilterSet(FilterSet):
    class Meta:
        model = ReactionsSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }


class MultiStepReactionFilterSet(FilterSet):
    class Meta:
        model = MultiStepReaction
        fields = {
            "name": ["exact", "contains"],
            "remarks": ["exact", "contains"],
            "description": ["exact", "contains"],
        }


class MultiStepReactionsSubsetFilterSet(FilterSet):
    class Meta:
        model = MultiStepReactionsSubset
        fields = {
            "name": ["exact", "contains"],
            "description": ["exact", "contains"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
        }