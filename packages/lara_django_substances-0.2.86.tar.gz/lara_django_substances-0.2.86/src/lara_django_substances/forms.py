"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances admin *

:details: lara_django_substances admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_substances > forms.py" to update this file
________________________________________________________________________
"""
# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

import tempfile
from typing import ClassVar

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Button, Column, Layout, Row, Submit
from django import forms
from django.forms.renderers import TemplatesSetting
from django.urls import reverse_lazy as rev

from .models import (
    ExtraData,
    Isotope,
    Mixture,
    MixtureComponent,
    MoleculeResidue,
    MultiStepReaction,
    Polymer,
    Reaction,
    ReactionComponent,
    Substance,
    SubstanceClass,
)


class CustomFormRenderer(TemplatesSetting):
    field_template_name = "lara_django_substances/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""
    
    template_name = "lara_django_substances/widgets/searchable_select_multiple.html"
    
    def __init__(self, attrs=None):
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)


class SearchForm(forms.Form):
    name = forms.CharField()

    def search(self):
        # search
        pass


class ExtraDataCreateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )
        widgets = {
            "data_type": forms.Select(attrs={"placeholder": "Data type", "required": True}),
            "name": forms.TextInput(attrs={"placeholder": "Name", "required": True, "rows": 1}),
            "name_full": forms.TextInput(attrs={"placeholder": "Full name", "required": False, "rows": 1}),
            "name_display": forms.TextInput(attrs={"placeholder": "Title", "required": False, "rows": 1}),
            "namespace": forms.Select(attrs={"placeholder": "Namespace", "required": True}),
            "version": forms.TextInput(attrs={"placeholder": "Version", "required": True, "rows": 1}),
            "hash_sha256": forms.TextInput(attrs={"placeholder": "SHA256 hash", "required": False, "rows": 1}),
            "data_json": forms.Textarea(attrs={"placeholder": "Data (JSON)", "required": False, "rows": 4}),
            "media_type": forms.Select(attrs={"placeholder": "Media type", "required": False}),
            "iri": forms.URLInput(attrs={"placeholder": "IRI", "required": False, "rows": 1}),
            "url": forms.URLInput(attrs={"placeholder": "URL", "required": False, "rows": 1}),
            "description": forms.TextInput(attrs={"placeholder": "Description", "required": False, "rows": 4}),
            "file": forms.ClearableFileInput(attrs={"placeholder": "File", "required": False}),
            "image": forms.ClearableFileInput(attrs={"placeholder": "Image file", "required": False}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
            Submit("submit", "Create"),
        )


class ExtraDataUpdateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )
        widgets = {
            "data_type": forms.Select(attrs={"placeholder": "Data type", "required": True}),
            "name": forms.TextInput(attrs={"placeholder": "Name", "required": True, "rows": 1}),
            "name_full": forms.TextInput(attrs={"placeholder": "Full name", "required": False, "rows": 1}),
            "name_display": forms.TextInput(attrs={"placeholder": "Title", "required": False, "rows": 1}),
            "namespace": forms.Select(attrs={"placeholder": "Namespace", "required": True}),
            "version": forms.TextInput(attrs={"placeholder": "Version", "required": True, "rows": 1}),
            "hash_sha256": forms.TextInput(attrs={"placeholder": "SHA256 hash", "required": False, "rows": 1}),
            "data_json": forms.Textarea(attrs={"placeholder": "Data (JSON)", "required": False, "rows": 4}),
            "media_type": forms.Select(attrs={"placeholder": "Media type", "required": False}),
            "iri": forms.URLInput(attrs={"placeholder": "IRI", "required": False, "rows": 1}),
            "url": forms.URLInput(attrs={"placeholder": "URL", "required": False, "rows": 1}),
            "description": forms.TextInput(attrs={"placeholder": "Description", "required": False, "rows": 4}),
            "file": forms.ClearableFileInput(attrs={"placeholder": "File", "required": False}),
            "image": forms.ClearableFileInput(attrs={"placeholder": "Image file", "required": False}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
            Submit("submit", "Update"),
        )


class SubstanceClassCreateForm(forms.ModelForm):
    class Meta:
        model = SubstanceClass
        fields = ("name", "iri", "description")
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "Name", "required": True, "rows": 1}),
            "iri": forms.URLInput(attrs={"placeholder": "IRI", "required": False, "rows": 1}),
            "description": forms.TextInput(attrs={"placeholder": "Description", "required": False, "rows": 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "iri", "description", Submit("submit", "Create"))


class SubstanceClassUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstanceClass
        fields = ("name", "iri", "description")
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "Name", "required": True, "rows": 1}),
            "iri": forms.URLInput(attrs={"placeholder": "IRI", "required": False, "rows": 1}),
            "description": forms.TextInput(attrs={"placeholder": "Description", "required": False, "rows": 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "iri", "description", Submit("submit", "Update"))


## -------------- Isotope -------------- ##


class IsotopeCreateForm(forms.ModelForm):
    """Form for creating a new isotope with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Isotope

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "num_protons",
            "num_neutrons",
            "electron_config",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "electron_config",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "num_protons",
            "num_neutrons",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class IsotopeUpdateForm(forms.ModelForm):
    """Form for updating an existing isotope with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Isotope

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "num_protons",
            "num_neutrons",
            "electron_config",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "electron_config",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "num_protons",
            "num_neutrons",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


## -------------- Substance -------------- ##


class SubstanceAddForm(forms.Form):
    """Form for adding substances via file upload or paste."""

    default_renderer: ClassVar = CustomFormRenderer()

    substance_list_file = forms.FileField(
        required=False,
        widget=forms.FileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        # template_name=FIELD_GROUP_TEMPLATE,
        help_text="Upload a CSV file containing substance data.",
    )

    substance_list = forms.CharField(
        required=False,
        widget=forms.Textarea(
            attrs={
                "class": "textarea textarea-sm textarea-bordered w-full",
                "rows": 3,  # Control textarea height
            }
        ),
        help_text="Paste CAS names of substances here",
    )

    # class Meta:
    #     widgets = {
    #         "substance_list_file": forms.ClearableFileInput(
    #             attrs={"accept": ".csv", "required": False}
    #         ),
    #         "substance_list": forms.Textarea(attrs={"placeholder": "Substance list (CSV)", "required": False}),
    #     }


class SubstanceCreateForm(forms.ModelForm):
    """Form for creating a new substance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Substance

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "computed_properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pdb_id",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "m1_code",
            "m3_code",
            "m5_code",
            "logp",
            "alogp",
            "xlogp",
            "melting_point",
            "boiling_point",
        )

        # Categorize fields by widget type

        text_fields_required: ClassVar = (
            "name",
            "cas",
        )

        text_fields: ClassVar = (
            "acronym",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "m1_code",
            "m3_code",
            "m5_code",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "logp",
            "alogp",
            "xlogp",
            "melting_point",
            "boiling_point",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class SubstanceUpdateForm(forms.ModelForm):
    """Form for updating an existing substance with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Substance

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "computed_properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pdb_id",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "m1_code",
            "m3_code",
            "m5_code",
            "logp",
            "alogp",
            "xlogp",
            "melting_point",
            "boiling_point",
        )

        # Categorize fields by widget type

        text_fields_required: ClassVar = (
            "name",
            "cas",
        )

        text_fields: ClassVar = (
            "acronym",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "m1_code",
            "m3_code",
            "m5_code",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "logp",
            "alogp",
            "xlogp",
            "melting_point",
            "boiling_point",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


## -------------- Polymer -------------- ##


class PolymerCreateForm(forms.ModelForm):
    """Form for creating a new polymer with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Polymer

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "sequence",
            "uniprot_ac",
            "uniprot_id",
            "genebank_id",
            "melting_point",
            "boiling_point",
            "logp",
            "media_type",
            "sequence_file",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "uniprot_ac",
            "uniprot_id",
            "genebank_id",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "melting_point",
            "boiling_point",
            "logp",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "sequence": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "sequence_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class PolymerUpdateForm(forms.ModelForm):
    """Form for updating an existing polymer with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Polymer

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "sequence",
            "uniprot_ac",
            "uniprot_id",
            "genebank_id",
            "melting_point",
            "boiling_point",
            "logp",
            "media_type",
            "sequence_file",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "uniprot_ac",
            "uniprot_id",
            "genebank_id",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "melting_point",
            "boiling_point",
            "logp",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "sequence": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "media_type": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
            "sequence_file": forms.ClearableFileInput(
                attrs={"class": "file-input file-input-sm file-input-bordered w-full"}
            ),
        }


class MixtureComponentCreateForm(forms.ModelForm):
    """Form for creating a new mixture component."""

    class Meta:  # noqa: D106
        model = MixtureComponent
        fields = ("name", "iri", "substance", "polymer", "concentration", "description")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "name",
            "iri",
            "substance",
            "polymer",
            "concentration",
            "description",
            Submit("submit", "Create"),
        )


class MixtureComponentUpdateForm(forms.ModelForm):
    """Form for updating an existing mixture component."""

    class Meta:  # noqa: D106
        model = MixtureComponent
        fields = ("name", "iri", "substance", "polymer", "concentration", "description")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "name",
            "iri",
            "substance",
            "polymer",
            "concentration",
            "description",
            Submit("submit", "Update"),
        )


## -------------- Mixture -------------- ##


class MixtureCreateForm(forms.ModelForm):
    """Form for creating a new mixture with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Mixture

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "components",
            "minchi",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "minchi",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "components": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class MixtureUpdateForm(forms.ModelForm):
    """Form for updating an existing mixture with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Mixture

        fields = (
            "name",
            "acronym",
            "synonyms",
            "substance_classes",
            "iri",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "structure_info",
            "computed_properties",
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
            "physical_state_matter",
            "properties",
            "sumformula",
            "cml",
            "cdxml",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "pac_id",
            "url",
            "url_definition",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
            "remarks",
            "description",
            "components",
            "minchi",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "acronym",
            "cas",
            "iupac_name",
            "iupac_name_traditional",
            "iupac_name_systematic",
            "pubchem_cid",
            "pubchem_sid",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "icsd_id",
            "cod_id",
            "ccdc_id",
            "csd_id",
            "sumformula",
            "smiles",
            "isosmiles",
            "cansmiles",
            "inchi",
            "inchikey",
            "stdinchi",
            "stdinchikey",
            "minchi",
        )

        textarea_fields: ClassVar = (
            "synonyms",
            "pubchem_fingerprint",
            "structure_info",
            "properties",
            "computed_properties",
            "cml",
            "cdxml",
            "mol_raw",
            "mol_2d",
            "mol_3d",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "mass_exact",
            "mass_monoisotopic",
            "mass_molar",
            "density",
        )

        url_fields: ClassVar = ("iri", "url", "url_definition", "pac_id")

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "substance_classes": SearchableSelectMultiple(),
            "physical_state_matter": forms.Select(attrs={"class": "select select-sm select-bordered w-full"}),
            "components": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class MoleculeResiduesCreateForm(forms.ModelForm):
    """Form for creating a new molecule residue."""

    class Meta:  # noqa: D106
        model = MoleculeResidue
        fields = ("name", "substructure", "iri")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "substructure", "iri", Submit("submit", "Create"))


class MoleculeResiduesUpdateForm(forms.ModelForm):
    """Form for updating an existing molecule residue."""

    class Meta:  # noqa: D106
        model = MoleculeResidue
        fields = ("name", "substructure", "iri")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout("name", "substructure", "iri", Submit("submit", "Update"))


class ReactantCreateForm(forms.ModelForm):
    """Form for creating a new reaction component (reactant)."""

    class Meta:  # noqa: D106
        model = ReactionComponent
        fields = (
            "iri",
            "substance",
            "polymer",
            "mixture",
            "order",
            "stoichiometric_factor",
            "physical_state",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "iri",
            "substance",
            "polymer",
            "mixture",
            "order",
            "stoichiometric_factor",
            "physical_state",
            "resources_external",
            Submit("submit", "Create"),
        )


class ReactantUpdateForm(forms.ModelForm):
    """Form for updating an existing reaction component (reactant)."""

    class Meta:  # noqa: D106
        model = ReactionComponent
        fields = (
            "iri",
            "substance",
            "polymer",
            "mixture",
            "order",
            "stoichiometric_factor",
            "physical_state",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "iri",
            "substance",
            "polymer",
            "mixture",
            "order",
            "stoichiometric_factor",
            "physical_state",
            "resources_external",
            Submit("submit", "Update"),
        )


## -------------- Reaction -------------- ##


class ReactionCreateForm(forms.ModelForm):
    """Form for creating a new reaction with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Reaction

        fields = (
            "name",
            "label",
            "rx_uuid",
            "iri",
            "rinchi",
            "rinchi_key_short",
            "rinchi_key_long",
            "rinchi_web_key",
            "rxno",
            "components",
            "properties",
            "parameters",
            "computed_properties",
            "equilibrium_const",
            "deltag",
            "order",
            "safety_info",
            "description",
            "remarks",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "label",
            "rinchi",
            "rinchi_key_short",
            "rinchi_key_long",
            "rinchi_web_key",
            "rxno",
        )

        textarea_fields: ClassVar = (
            "properties",
            "parameters",
            "computed_properties",
            "safety_info",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "equilibrium_const",
            "deltag",
            "order",
        )

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "rx_uuid": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "readonly": True}),
            "components": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class ReactionUpdateForm(forms.ModelForm):
    """Form for updating an existing reaction with all available fields."""

    default_renderer: ClassVar = CustomFormRenderer()

    class Meta:  # noqa: D106
        model = Reaction

        fields = (
            "name",
            "label",
            "rx_uuid",
            "iri",
            "rinchi",
            "rinchi_key_short",
            "rinchi_key_long",
            "rinchi_web_key",
            "rxno",
            "components",
            "properties",
            "parameters",
            "computed_properties",
            "equilibrium_const",
            "deltag",
            "order",
            "safety_info",
            "description",
            "remarks",
            "svg",
            "image",
            "data_extra",
            "resources_external",
            "tags",
        )

        # Categorize fields by widget type
        text_fields_required: ClassVar = ("name",)

        text_fields: ClassVar = (
            "label",
            "rinchi",
            "rinchi_key_short",
            "rinchi_key_long",
            "rinchi_web_key",
            "rxno",
        )

        textarea_fields: ClassVar = (
            "properties",
            "parameters",
            "computed_properties",
            "safety_info",
            "svg",
            "remarks",
            "description",
        )

        number_fields: ClassVar = (
            "equilibrium_const",
            "deltag",
            "order",
        )

        url_fields: ClassVar = ("iri",)

        widgets: ClassVar = {
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "required": True})
                for field in text_fields_required
            },
            **{
                field: forms.TextInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in text_fields
            },
            **{
                field: forms.Textarea(attrs={"class": "textarea textarea-sm textarea-bordered w-full", "rows": 3})
                for field in textarea_fields
            },
            **{
                field: forms.NumberInput(attrs={"class": "input input-sm input-bordered w-full"})
                for field in number_fields
            },
            **{field: forms.URLInput(attrs={"class": "input input-sm input-bordered w-full"}) for field in url_fields},
            "rx_uuid": forms.TextInput(attrs={"class": "input input-sm input-bordered w-full", "readonly": True}),
            "components": SearchableSelectMultiple(),
            "data_extra": SearchableSelectMultiple(),
            "resources_external": SearchableSelectMultiple(),
            "tags": SearchableSelectMultiple(),
            "image": forms.ClearableFileInput(attrs={"class": "file-input file-input-sm file-input-bordered w-full"}),
        }


class MultiStepReactionCreateForm(forms.ModelForm):
    """Form for creating a new multi-step reaction."""

    class Meta:  # noqa: D106
        model = MultiStepReaction
        fields = ("name", "iri", "description", "remarks", "svg", "image", "resources_external")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "name",
            "iri",
            "description",
            "remarks",
            "svg",
            "image",
            "resources_external",
            Submit("submit", "Create"),
        )


class MultiStepReactionUpdateForm(forms.ModelForm):
    """Form for updating an existing multi-step reaction."""

    class Meta:  # noqa: D106
        model = MultiStepReaction
        fields = ("name", "iri", "description", "remarks", "svg", "image", "resources_external")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "name",
            "iri",
            "description",
            "remarks",
            "svg",
            "image",
            "resources_external",
            Submit("submit", "Update"),
        )
