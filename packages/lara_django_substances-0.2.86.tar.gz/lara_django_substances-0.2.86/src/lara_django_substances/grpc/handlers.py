"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_substances  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_substances.grpc.services import (
    ExtraDataService,
    SubstanceClassService,
    IsotopeService,
    IsotopesSubsetService,
    SubstanceService,
    SubstancesSubsetService,
    PolymerService,
    PolymersSubsetService,
    MixtureComponentService,
    MixtureService,
    MixturesSubsetService,
    MoleculeResidueService,
    ReactantService,
    ReactantsSubsetService,
    ReactionService,
    ReactionsSubsetService,
    MultiStepReactionService,
    MultiStepReactionsSubsetService,
    
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_substances", server)

    app_registry.get_grpc_module = lambda: "lara_django_substances_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(SubstanceClassService)

    app_registry.register(IsotopeService)

    app_registry.register(IsotopesSubsetService)

    app_registry.register(SubstanceService)

    app_registry.register(SubstancesSubsetService)

    app_registry.register(PolymerService)

    app_registry.register(PolymersSubsetService)

    app_registry.register(MixtureComponentService)

    app_registry.register(MixtureService)

    app_registry.register(MixturesSubsetService)

    app_registry.register(MoleculeResidueService)

    app_registry.register(ReactantService)

    app_registry.register(ReactantsSubsetService)

    app_registry.register(ReactionService)

    app_registry.register(ReactionsSubsetService)

    app_registry.register(MultiStepReactionService)

    app_registry.register(MultiStepReactionsSubsetService)

