"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_substances  (LARA-version)

import logging

from django_socio_grpc import proto_serializers
from rest_framework.serializers import UUIDField, PrimaryKeyRelatedField


from lara_django_base.models import (
    Namespace,
    DataType,
    MediaType,
    PhysicalUnit,
    PhysicalStateMatter,
    ScientificConstant,
    Tag,
    ItemStatus,
    ExternalResource,
)
from lara_django_sequences.models import Sequence
from lara_django_substances.models import (
    ExtraData,
    SubstanceClass,
    Isotope,
    IsotopesSubset,
    Substance,
    SubstancesSubset,
    Polymer,
    PolymersSubset,
    MixtureComponent,
    Mixture,
    MixturesSubset,
    MoleculeResidue,
    ReactionComponent,
    ReactionComponentsSubset,
    Reaction,
    ReactionsSubset,
    MultiStepReaction,
    MultiStepReactionsSubset,
)
from lara_django_people.models import Entity, Group, LaraUser

import lara_django_substances_grpc.v1.lara_django_substances_pb2 as lara_django_substances_pb2


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_substances_pb2.ExtraDataResponse

        proto_class_list = lara_django_substances_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', file', image']


class SubstanceClassProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = SubstanceClass
        proto_class = lara_django_substances_pb2.SubstanceClassResponse

        proto_class_list = lara_django_substances_pb2.SubstanceClassListResponse

        fields = "__all__"  # [name', description']


class IsotopeProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance_classes = PrimaryKeyRelatedField(
        queryset=SubstanceClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Isotope
        proto_class = lara_django_substances_pb2.IsotopeResponse

        proto_class_list = lara_django_substances_pb2.IsotopeListResponse

        fields = "__all__"  # [name', acronym', synonyms', UUID', IRI', cas', iupac_name', PubChemID', pubchem_fingerprint', chemspider_id', beilstein_regnum', ec_num', mdl_num', pdb_id', computed_properties', mass_molar', density', physical_state_matter', properties', sumformula', cml', cdxml', smiles', isosmiles', cansmiles', inchi', inchikey', stdinchi', stdinchikey', PDB', URL', url_definition',  mol_raw', mol_2d', mol_3d', svg', image', literature', remarks', description', num_protons', electron_config']


class IsotopesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    isotopes = PrimaryKeyRelatedField(
        queryset=Isotope.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = IsotopesSubset
        proto_class = lara_django_substances_pb2.IsotopeResponse

        proto_class_list = lara_django_substances_pb2.IsotopeListResponse

        fields = "__all__"  # [name', description']


class SubstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance_classes = PrimaryKeyRelatedField(
        queryset=SubstanceClass.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Substance
        proto_class = lara_django_substances_pb2.SubstanceResponse

        proto_class_list = lara_django_substances_pb2.SubstanceListResponse

        fields = "__all__"  # [name', acronym', synonyms', UUID', IRI', cas', iupac_name', PubChemID', pubchem_fingerprint', chemspider_id', beilstein_regnum', ec_num', mdl_num', pdb_id', computed_properties', mass_molar', density', physical_state_matter', properties', sumformula', cml', cdxml', smiles', isosmiles', cansmiles', inchi', inchikey', stdinchi', stdinchikey', PDB', URL', url_definition',  mol_raw', mol_2d', mol_3d', svg', image', literature', remarks', description', m1_code', m3_code', m5_code', logp', alogp', xlogp', melting_point', boiling_point']


class SubstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    substances = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = SubstancesSubset
        proto_class = lara_django_substances_pb2.SubstanceResponse

        proto_class_list = lara_django_substances_pb2.SubstanceListResponse

        fields = "__all__"  # [name', description']


class PolymerProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance_classes = PrimaryKeyRelatedField(
        queryset=SubstanceClass.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    sequence = PrimaryKeyRelatedField(
        queryset=Sequence.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = Polymer
        proto_class = lara_django_substances_pb2.PolymerResponse

        proto_class_list = lara_django_substances_pb2.PolymerListResponse

        fields = "__all__"  # [name', acronym', synonyms', UUID', IRI', cas', iupac_name', PubChemID', pubchem_fingerprint', chemspider_id', beilstein_regnum', ec_num', mdl_num', pdb_id', computed_properties', mass_molar', density', physical_state_matter', properties', sumformula', cml', cdxml', smiles', isosmiles', cansmiles', inchi', inchikey', stdinchi', stdinchikey', PDB', URL', url_definition',  mol_raw', mol_2d', mol_3d', svg', image', literature', remarks', description', sequence', melting_point', boiling_point', media_type', sequence_file']

class PolymersSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    polymers = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = PolymersSubset
        proto_class = lara_django_substances_pb2.PolymerResponse

        proto_class_list = lara_django_substances_pb2.PolymerListResponse

        fields = "__all__"  # [name', description']


class MixtureComponentProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    polymer = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    amount_unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    concentration_unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    class Meta:
        model = MixtureComponent
        proto_class = lara_django_substances_pb2.MixtureComponentResponse

        proto_class_list = lara_django_substances_pb2.MixtureComponentListResponse

        fields = "__all__"  # [name', IRI', substance', polymer', concentration',  description']


class MixtureProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance_classes = PrimaryKeyRelatedField(
        queryset=SubstanceClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    components = PrimaryKeyRelatedField(
        queryset=MixtureComponent.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )

    class Meta:
        model = Mixture
        proto_class = lara_django_substances_pb2.MixtureResponse

        proto_class_list = lara_django_substances_pb2.MixtureListResponse

        fields = "__all__"  # [name', acronym', synonyms', UUID', IRI', cas', iupac_name', PubChemID', pubchem_fingerprint', chemspider_id', beilstein_regnum', ec_num', mdl_num', pdb_id', computed_properties', mass_molar', density', properties', sumformula', cml', cdxml', smiles', isosmiles', cansmiles', inchi', inchikey', stdinchi', stdinchikey', PDB',  URL', url_definition',  mol_raw', mol_2d', mol_3d', svg', image', literature', remarks', description', physical_state_matter']

class MixturesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    mixtures = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = MixturesSubset
        proto_class = lara_django_substances_pb2.MixtureResponse

        proto_class_list = lara_django_substances_pb2.MixtureListResponse

        fields = "__all__"  # [name', description']

class MoleculeResidueProtoSerializer(proto_serializers.ModelProtoSerializer):
    class Meta:
        model = MoleculeResidue
        proto_class = lara_django_substances_pb2.MoleculeResidueResponse

        proto_class_list = lara_django_substances_pb2.MoleculeResidueListResponse

        fields = "__all__"  # [name', substructure', IRI']


class ReactantProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    polymer = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    mixture = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    roles = PrimaryKeyRelatedField(queryset=SubstanceClass.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = ReactionComponent
        proto_class = lara_django_substances_pb2.ReactantResponse

        proto_class_list = lara_django_substances_pb2.ReactantListResponse

        fields = "__all__"  # [IRI', substance', polymer', mixture', order', stoichiometric_factor', physical_state', literature']


class ReactantsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    reactants = PrimaryKeyRelatedField(
        queryset=ReactionComponent.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = ReactionComponentsSubset
        proto_class = lara_django_substances_pb2.ReactantResponse

        proto_class_list = lara_django_substances_pb2.ReactantListResponse

        fields = "__all__"


class ReactionProtoSerializer(proto_serializers.ModelProtoSerializer):
    components = PrimaryKeyRelatedField(
        queryset=ReactionComponent.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = Reaction
        proto_class = lara_django_substances_pb2.ReactionResponse

        proto_class_list = lara_django_substances_pb2.ReactionListResponse

        fields = "__all__"  # [name', label', rx_uuid', IRI', rinchi', rinchi_key_short', rinchi_key_long', rinchi_web_key', rxno', equilibrium_const', deltag', order', safety_information', description', remarks', svg', image', literature']


class ReactionsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    reactions = PrimaryKeyRelatedField(
        queryset=Reaction.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = ReactionsSubset
        proto_class = lara_django_substances_pb2.ReactionResponse

        proto_class_list = lara_django_substances_pb2.ReactionListResponse

        fields = "__all__"  # [name', description']


class MultiStepReactionProtoSerializer(proto_serializers.ModelProtoSerializer):
    reactions = PrimaryKeyRelatedField(
        queryset=Reaction.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MultiStepReaction
        proto_class = lara_django_substances_pb2.MultiStepReactionResponse

        proto_class_list = lara_django_substances_pb2.MultiStepReactionListResponse

        fields = "__all__"  # [name', UUID', IRI', description', remarks', svg', image', literature']

class MultiStepReactionsSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    entity = PrimaryKeyRelatedField(queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose"))
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    reactions_multistep = PrimaryKeyRelatedField(
        queryset=MultiStepReaction.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), pk_field=UUIDField(format="hex_verbose"), many=True, required=False, allow_null=True
    )

    class Meta:
        model = MultiStepReactionsSubset
        proto_class = lara_django_substances_pb2.MultiStepReactionResponse

        proto_class_list = lara_django_substances_pb2.MultiStepReactionListResponse

        fields = "__all__"  # [name', description']
