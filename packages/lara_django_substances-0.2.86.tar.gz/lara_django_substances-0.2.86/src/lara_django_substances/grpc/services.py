"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_substances  (LARA-version)

import io
import asyncio
import grpc
from django_socio_grpc.decorators import grpc_action

from django_socio_grpc import generics, mixins
from lara_django_base.grpc.mixins import AsyncUploadModelMixin, AsyncRetrieveByNameModelMixin, AsyncDownloadModelMixin

from .serializers import (
    ExtraDataProtoSerializer,
    SubstanceClassProtoSerializer,
    IsotopeProtoSerializer,
    IsotopesSubsetProtoSerializer,
    SubstanceProtoSerializer,
    SubstancesSubsetProtoSerializer,
    PolymerProtoSerializer,
    PolymersSubsetProtoSerializer,
    MixtureComponentProtoSerializer,
    MixtureProtoSerializer,
    MixturesSubsetProtoSerializer,
    MoleculeResidueProtoSerializer,
    ReactantProtoSerializer,
    ReactantsSubsetProtoSerializer,
    ReactionProtoSerializer,
    ReactionsSubsetProtoSerializer,
    MultiStepReactionProtoSerializer,
    MultiStepReactionsSubsetProtoSerializer,
)
   

from ..filters import (
    ExtraDataFilterSet,
    SubstanceClassFilterSet,
    IsotopeFilterSet,
    IsotopesSubsetFilterSet,
    SubstanceFilterSet,
    SubstancesSubsetFilterSet,
    PolymerFilterSet,
    PolymersSubsetFilterSet,
    MixtureComponentFilterSet,
    MixtureFilterSet,
    MixturesSubsetFilterSet,
    MoleculeResiduesFilterSet,
    ReactantFilterSet,
    ReactionFilterSet,
    ReactionsSubsetFilterSet,
    MultiStepReactionFilterSet,
    MultiStepReactionsSubsetFilterSet,
    
)
from lara_django_substances.models import (
    ExtraData,
    SubstanceClass,
    Isotope,
    IsotopesSubset,
    Substance,
    SubstancesSubset,
    Polymer,
    PolymersSubset,
    MixtureComponent,
    Mixture,
    MixturesSubset,
    MoleculeResidue,
    ReactionComponent,
    ReactionComponentsSubset,
    Reaction,
    ReactionsSubset,
    MultiStepReaction,
    MultiStepReactionsSubset,
)

import lara_django_substances_grpc.v1.lara_django_substances_pb2 as lara_django_substances_pb2

class ExtraDataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer
    filterset_class = ExtraDataFilterSet


class SubstanceClassService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstanceClass.objects.all()
    serializer_class = SubstanceClassProtoSerializer
    filterset_class = SubstanceClassFilterSet


class IsotopeService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = Isotope.objects.all()
    serializer_class = IsotopeProtoSerializer
    filterset_class = IsotopeFilterSet

class IsotopesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = IsotopesSubset.objects.all()
    serializer_class = IsotopesSubsetProtoSerializer
    filterset_class = IsotopesSubsetFilterSet


class SubstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = Substance.objects.all()
    serializer_class = SubstanceProtoSerializer
    filterset_class = SubstanceFilterSet

class SubstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstancesSubset.objects.all()
    serializer_class = SubstancesSubsetProtoSerializer
    filterset_class = SubstancesSubsetFilterSet


class PolymerService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = Polymer.objects.all()
    serializer_class = PolymerProtoSerializer
    filterset_class = PolymerFilterSet

class PolymersSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymersSubset.objects.all()
    serializer_class = PolymersSubsetProtoSerializer
    filterset_class = PolymersSubsetFilterSet


class MixtureComponentService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureComponent.objects.all()
    serializer_class = MixtureComponentProtoSerializer
    filterset_class = MixtureComponentFilterSet


class MixtureService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = Mixture.objects.all()
    serializer_class = MixtureProtoSerializer
    filterset_class = MixtureFilterSet


class MixturesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixturesSubset.objects.all()
    serializer_class = MixturesSubsetProtoSerializer
    filterset_class = MixturesSubsetFilterSet


class MoleculeResidueService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = MoleculeResidue.objects.all()
    serializer_class = MoleculeResidueProtoSerializer
    filterset_class = MoleculeResiduesFilterSet


class ReactantService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = ReactionComponent.objects.all()
    serializer_class = ReactantProtoSerializer
    filterset_class = ReactantFilterSet


class ReactantsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ReactionComponentsSubset.objects.all()
    serializer_class = ReactantsSubsetProtoSerializer
    #filterset_class = ReactantsSubsetFilterSet

class ReactionService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = Reaction.objects.all()
    serializer_class = ReactionProtoSerializer
    filterset_class = ReactionFilterSet

class ReactionsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ReactionsSubset.objects.all()
    serializer_class = ReactionsSubsetProtoSerializer
    filterset_class = ReactionsSubsetFilterSet

class MultiStepReactionService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_pb2
    queryset = MultiStepReaction.objects.all()
    serializer_class = MultiStepReactionProtoSerializer
    filterset_class = MultiStepReactionFilterSet

class MultiStepReactionsSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MultiStepReactionsSubset.objects.all()
    serializer_class = MultiStepReactionsSubsetProtoSerializer
    filterset_class = MultiStepReactionsSubsetFilterSet