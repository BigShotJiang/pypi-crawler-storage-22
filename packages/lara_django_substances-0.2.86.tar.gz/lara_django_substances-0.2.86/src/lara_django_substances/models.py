"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances models *

:details: lara_django_substances database models.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import logging
import datetime
import uuid
import hashlib
import json
from random import randint

from django.utils import timezone
from django.conf import settings
from django.utils.translation import gettext_lazy as _

from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVectorField


from django.db import models
from lara_django_sequences.models import Sequence

from lara_django_base.models import (
    DataType,
    MediaType,
    ExtraDataAbstr,
    ExternalResource,
    Tag,
    PhysicalUnit,
    PhysicalStateMatter,
)
from lara_django_people.models import Entity, LaraUser, ItemSubsetAbstr


settings.FIXTURES += ["1_default_substance_classes_fix"]


class ExtraData(ExtraDataAbstr):
    """This class can be used to extend data, by extra information,
    e.g. UV-vis, IR, NMR spectra of substances, or substance related properties, like enzymatic substrate spectra / activities ...
    """

    model_curi = "lara:substances/ExtraData"

    url_visualization = models.URLField(
        blank=True,
        null=True,
        max_length=512,
        help_text="Universal Resource Locator - URL to external visualization of the data",
    )
    file = models.FileField(
        upload_to="substances",
        blank=True,
        null=True,
        help_text="rel. path/filename to extra data file, preferable in SciDat format.",
    )
    image = models.ImageField(
        upload_to="substances/images/",
        blank=True,
        null=True,
        help_text="extra substance image, e.g. spectrum-thumbnail, ...",
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.hash_sha256 is None:
            if self.data_json is not None:
                to_hash = json.dumps(self.data_json)  # +  str(self.UUID) +
                self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()
            else:
                self.hash_sha256 = hashlib.sha256(
                    str(self.extradata_id).encode("utf-8")
                ).hexdigest()

        if self.name is None or self.name == "":
            if self.name_display is None or self.name_display == "":
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "data",
                        self.hash_sha256[:8],
                    )
                )
            else:
                self.name = self.name_display.replace(" ", "_").lower().strip()

        else:
            self.name = self.name.replace(" ", "_").lower().strip()
        if self.name_full is None or self.name_full == "":
            if self.namespace is not None and self.version is not None:
                self.name_full = f"{self.namespace.uri}/" + "_".join(
                    (self.name.replace(" ", "_"), self.version)
                )
            else:
                self.name_full = "_".join((self.name.replace(" ", "_"), self.version))

        if not self.iri:
            netloc = self.namespace.parse_URI().netloc
            path = self.namespace.parse_URI().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/ExtraData/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class SubstanceClass(models.Model):
    """classes for substances, like amino acid, peptide, protein, nucleotide, DNA,..."""

    model_curi = "lara:substances/SubstanceClass"

    substanceclass_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    name = models.TextField(
        unique=True, help_text="like amino acid, peptide, protein, nucleotide, DNA"
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    description = models.TextField(
        blank=True, null=True, help_text="description of the substance class"
    )

    class Meta:
        verbose_name_plural = "SubstanceClasses"

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/SubstanceClass/{self.name.replace(' ', '_').lower().strip()}"

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

 

class SubstanceAbstr(models.Model):
    """abstract base class for all substances"""

    name = models.TextField(blank=True, help_text="most common name of the substance")
    acronym = models.TextField(
        blank=True, null=True, help_text="acronym, e.g. TFA, DMSO, MBA, 160323MBA"
    )
    synonyms = models.TextField(
        blank=True,
        null=True,
        help_text="comma separated list of synonyms, like 'benzene', 'amylalcohol' ",
    )
    substance_classes = models.ManyToManyField(
        SubstanceClass,
        related_name="%(app_label)s_%(class)s_substance_classes_related",
        related_query_name="%(app_label)s_%(class)s_substance_classes_related_query",
        blank=True,
        help_text="substance class, e.g. salt, complex, nucleotide",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    cas = models.TextField(blank=True, null=True, help_text="Chemical Abstract ")
    iupac_name = models.TextField(
        blank=True, null=True, help_text="IUPAC preferred name"
    )
    iupac_name_traditional = models.TextField(
        blank=True, null=True, help_text="IUPAC traditional name"
    )
    iupac_name_systematic = models.TextField(
        blank=True, null=True, help_text="IUPAC systematic name"
    )
    pubchem_cid = models.TextField(blank=True, null=True, help_text="PubChem CID")
    pubchem_sid = models.TextField(blank=True, null=True, help_text="PubChem SID")
    pubchem_fingerprint = models.TextField(
        blank=True,
        null=True,
        help_text=" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt",
    )
    chemspider_id = models.TextField(
        blank=True, null=True, help_text="s. chemspider.com"
    )
    beilstein_regnum = models.TextField(
        blank=True, null=True, help_text="Beilstein Registry Number"
    )
    ec_num = models.TextField(blank=True, null=True, help_text="EC number")
    mdl_num = models.TextField(blank=True, null=True, help_text="MDL number")

    mass_exact = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.",
    )
    mass_monoisotopic = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text=" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.",
    )
    mass_molar = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number",
    )
    density = models.DecimalField(
        max_digits=20,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="density in g /cm3",
    )
    physical_state_matter = models.ForeignKey(
        PhysicalStateMatter,
        related_name="%(app_label)s_%(class)s_state_of_matter_related",
        related_query_name="%(app_label)s_%(class)s_state_of_matter_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="physical state of matter at 293 K",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON",
    )
    sumformula = models.TextField(
        blank=True, null=True, help_text="sum formula of the substance"
    )
    # note also the version of the files in metadata
    cml = models.TextField(
        blank=True, null=True, help_text="Chemical Markup Language, s. "
    )
    cdxml = models.TextField(blank=True, null=True, help_text="ChemDraw XML")
    smiles = models.TextField(blank=True, null=True, help_text="SMILES")
    isosmiles = models.TextField(blank=True, null=True, help_text="isomeric SMILES")
    cansmiles = models.TextField(blank=True, null=True, help_text="canonical SMILES")
    inchi = models.TextField(blank=True, null=True, help_text="InChi")
    inchikey = models.TextField(blank=True, null=True, help_text="InChiKey")
    stdinchi = models.TextField(blank=True, null=True, help_text="StdInChi")
    stdinchikey = models.TextField(blank=True, null=True, help_text="StdInChiKey")
    pdb_id = models.TextField(
        blank=True, null=True, help_text="Protein Database ID / Code"
    )
    icsd_id = models.TextField(
        blank=True,
        null=True,
        help_text="Inorganic Crystal Structure Database ID / Code",
    )
    cod_id = models.TextField(
        blank=True, null=True, help_text="Crystallography Open Database ID / Code"
    )
    ccdc_id = models.TextField(
        blank=True,
        null=True,
        help_text="Cambridge Crystallographic Data Centre ID / Code",
    )
    csd_id = models.TextField(
        blank=True, null=True, help_text="Cambridge Structural Database ID / Code"
    )
    structure_info = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database",
    )
    url = models.URLField(
        blank=True,
        null=True,
        max_length=512,
        help_text="Universal Resource Locator - URL to external structure database,  link to public structure database",
    )
    # PAC-ID:  https://github.com/ApiniLabs/PAC-ID
    pac_id = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.",
    )
    url_definition = models.URLField(
        blank=True,
        null=True,
        help_text="definition Universal Resource Locator - URL, like wikipedia",
    )
    mol_raw = models.TextField(blank=True, null=True, help_text="mol file raw")
    mol_2d = models.TextField(blank=True, null=True, help_text="mdl mol file 2D")
    mol_3d = models.TextField(blank=True, null=True, help_text="mdl mol file 3D")
    svg = models.TextField(
        blank=True, null=True, help_text="svg image of the substance"
    )
    image = models.ImageField(
        upload_to="substances/",
        blank=True,
        null=True,
        help_text="e.g. png image of substance",
    )  # rel. path/filename to image
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like absorption coefficient",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )
    remarks = models.TextField(
        blank=True, null=True, help_text="some remarks to this substance"
    )
    description = models.TextField(
        blank=True, null=True, help_text="description of the substance"
    )
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="date and time when data was last modified"
    )

    search_vector = SearchVectorField(null=True)

    class Meta:
        abstract = True
        constraints = [
            models.UniqueConstraint(
                fields=["name", "iupac_name", "pubchem_sid", "pubchem_cid"],
                name="%(app_label)s_%(class)s_name_iupac_pubchem_unique",
            )
        ]
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return f"{self.name} ({self.description})" or ""



class Isotope(SubstanceAbstr):
    """_Istope - detailed information about all known isotopes_

    :param SubstanceAbstr: _description_
    :type SubstanceAbstr: _type_
    :return: _description_
    :rtype: _type_
    :yield: _description_
    :rtype: _type_
    """

    model_curi = "lara:substances/Isotope"
    isotope_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    num_protons = models.SmallIntegerField(
        blank=True, null=True, help_text="number of protons"
    )
    num_neutrons = models.SmallIntegerField(
        blank=True, null=True, help_text="number of neutrons"
    )
    # exact mass
    #
    electron_config = models.TextField(
        blank=True, null=True, help_text="electron configuration: e.g. 1s2, 2s2 3p3 "
    )
    # electronegativity
    # electron affinity
    # ion radius
    # van der Waals radius
    # half-life time
    # rel. abundances: earth, moon universe
    # detailed references (international institute)
    # decay modes
    # decay energy
    # decay products
    # decay radiation (alpha, beta, gamma, ...) / decay radiation energy / decay radiation intensity

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/isotope/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class IsotopesSubset(ItemSubsetAbstr):

    model_curi = "lara:substances/IsotopesSubset"

    isotopessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    isotopes = models.ManyToManyField(
        Isotope,
        related_name="%(app_label)s_%(class)s_isotopes_related",
        related_query_name="%(app_label)s_%(class)s_isotopes_related_query",
        blank=True,
        help_text="isotopes of the subset",
        through="OrderedIsotopesSubset",
    )


class OrderedIsotopesSubset(models.Model):
    """Through model for the many-to-many relationship between IsotopesSubset and Isotope.
    This class can be used to store the order of isotopes in a subset"""

    model_curi = "lara:substances/OrderedIsotopesSubset"

    orderedisotopessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    isotope = models.ForeignKey(
        Isotope,
        related_name="%(app_label)s_%(class)s_isotope_related",
        related_query_name="%(app_label)s_%(class)s_isotope",
        on_delete=models.CASCADE,
        help_text="isotope in the subset",
    )

    isotopes_subset = models.ForeignKey(
        IsotopesSubset,
        related_name="%(app_label)s_%(class)s_isotopes_subset_related",
        related_query_name="%(app_label)s_%(class)s_isotopes_subset",
        on_delete=models.CASCADE,
        help_text="subset of isotopes",
    )

    order = models.IntegerField(help_text="order of isotope in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["isotope", "isotopes_subset"],
                name="%(app_label)s_%(class)s_isotope_isotopes_subset_unique",
            ),
        ]
        ordering = ("order",)


class Substance(SubstanceAbstr):
    """Abstractum of a substance. It can represent an element or a compound (polymers, like DNA, peptides, proteins have their own class).
    analytical data should be addable (like UV-vis, NMR, HPLC, .... )
    """

    model_curi = "lara:substances/Substance"
    substance_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    m1_code = models.TextField(
        blank=True, null=True, help_text="monomer one letter code, like 'A', 'T', 'C' "
    )
    m3_code = models.TextField(
        blank=True, null=True, help_text="monomer three letter code, like 'Gly' "
    )
    m5_code = models.TextField(
        blank=True, null=True, help_text="monomer five letter code"
    )
    logp = models.DecimalField(
        max_digits=20,
        decimal_places=12,
        blank=True,
        null=True,
        help_text="experimental log of octanol/water partition coefficient",
    )
    alogp = models.DecimalField(
        max_digits=20,
        decimal_places=12,
        blank=True,
        null=True,
        help_text="calculated log of octanol/water partition coefficient",
    )
    xlogp = models.DecimalField(
        max_digits=20,
        decimal_places=12,
        blank=True,
        null=True,
        help_text="calculated log of octanol/water partition coefficient",
    )
    melting_point = models.DecimalField(
        max_digits=20, decimal_places=9, blank=True, null=True, help_text="in deg K"
    )
    boiling_point = models.DecimalField(
        max_digits=20, decimal_places=9, blank=True, null=True, help_text="in deg K"
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/substance/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class SubstancesSubset(ItemSubsetAbstr):
    """User or group defined subset of substances"""

    model_curi = "lara:substances/SubstancesSubset"
    substancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    substances = models.ManyToManyField(
        Substance,
        related_name="%(app_label)s_%(class)s_substances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        blank=True,
        help_text="substances of the subset",
        through="OrderedSubstancesSubset",
    )


class OrderedSubstancesSubset(models.Model):
    """Through model for the many-to-many relationship between SubstancesSubset and Substance.
    This class can be used to store the order of substances in a subset"""

    model_curi = "lara:substances/OrderedSubstancesSubset"

    orderedsubstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    substance = models.ForeignKey(
        Substance,
        related_name="%(app_label)s_%(class)s_substance_related",
        related_query_name="%(app_label)s_%(class)s_substance",
        on_delete=models.CASCADE,
        help_text="substance in the subset",
    )

    substances_subset = models.ForeignKey(
        SubstancesSubset,
        related_name="%(app_label)s_%(class)s_substances_subset_related",
        related_query_name="%(app_label)s_%(class)s_substances_subset",
        on_delete=models.CASCADE,
        help_text="subset of substances",
    )

    order = models.IntegerField(help_text="order of substance in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["substance", "substances_subset"],
                name="%(app_label)s_%(class)s_substance_substances_subset_unique",
            ),
        ]
        ordering = ("order",)


class Polymer(SubstanceAbstr):
    """__Defined polymers (no mixtures)__
    The polymer class defines how the sequence data is to be interpreted
    DNA_FASTA, DNA_FASTAQ, DNA_GeneBank,
    e.g. DNA1L, RNA1L, Protein1L, Protein3L
    for sequences add expression host and original organism
    units are the same as in substance
    analytical data should be addable (like UV-vis, NMR, HPLC, .... )
    todo: taxanomic info could be added as separate model / app
          host_organism ? could be added to extra data

    !!! mind that many polymers (e.g, PE, PP, PET are mixtures)
    """

    model_curi = "lara:substances/Polymer"
    polymer_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    sequence = media_type = models.ForeignKey(
        Sequence,
        related_name="%(app_label)s_%(class)s_sequences_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="sequence of the polymer",
    )
    uniprot_ac = models.TextField(
        blank=True, null=True, help_text="UniProt Accession Number"
    )
    uniprot_id = models.TextField(
        blank=True, null=True, help_text="UniProtKB/Swiss-Prot/TrEMBL entry name / ID"
    )
    genebank_id = models.TextField(blank=True, null=True, help_text="GeneBank ID")
    melting_point = models.DecimalField(
        max_digits=20, decimal_places=18, null=True, blank=True, help_text="in deg K"
    )
    boiling_point = models.DecimalField(
        max_digits=20, decimal_places=9, null=True, blank=True, help_text="in deg K"
    )
    logp = models.DecimalField(
        max_digits=20,
        decimal_places=9,
        blank=True,
        null=True,
        help_text="experimental log of octanol/water partition coefficient",
    )
    media_type = models.ForeignKey(
        MediaType,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="file type of sequence data (file)",
    )
    sequence_file = models.FileField(
        upload_to="lara_polymer/", blank=True, null=True, help_text="rel. path/filename"
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/polymer/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class PolymersSubset(ItemSubsetAbstr):
    """User or group defined subset of polymers"""

    model_curi = "lara:substances/PolymersSubset"
    polymerssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    polymers = models.ManyToManyField(
        Polymer,
        related_name="%(app_label)s_%(class)s_polymers_related",
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        blank=True,
        help_text="polymers of the subset",
        through="OrderedPolymersSubset",
    )


class OrderedPolymersSubset(models.Model):
    """Through model for the many-to-many relationship between PolymersSubset and Polymer.
    This class can be used to store the order of polymers in a subset"""

    model_curi = "lara:substances/OrderedPolymersSubset"

    orderedpolymerssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    polymer = models.ForeignKey(
        Polymer,
        related_name="%(app_label)s_%(class)s_polymer_related",
        related_query_name="%(app_label)s_%(class)s_polymer",
        on_delete=models.CASCADE,
        help_text="polymer in the subset",
    )

    polymers_subset = models.ForeignKey(
        PolymersSubset,
        related_name="%(app_label)s_%(class)s_polymers_subset_related",
        related_query_name="%(app_label)s_%(class)s_polymers_subset",
        on_delete=models.CASCADE,
        help_text="subset of polymers",
    )

    order = models.IntegerField(help_text="order of polymer in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["polymer", "polymers_subset"],
                name="%(app_label)s_%(class)s_polymer_polymers_subset_unique",
            ),
        ]
        ordering = ("order",)


class MixtureComponent(models.Model):
    """Single component of a mixture"""

    model_curi = "lara:substances/MixtureComponent"
    mixturecomponent_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    name = models.TextField(unique=True, help_text="name of mixture component")
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    substance = models.ForeignKey(
        Substance,
        related_name="%(app_label)s_%(class)s_substances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        help_text="ID of the substance",
    )
    polymer = models.ForeignKey(
        Polymer,
        related_name="%(app_label)s_%(class)s_polymers_related",
        blank=True,
        null=True,
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        on_delete=models.CASCADE,
        help_text="ID of the polymer",
    )
    amount = models.DecimalField(
        max_digits=42,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="amount of substance in mol (in mixtures) - or number of molecules in a complex (protein-ligand, protein-protein, ...)",
    )
    amount_unit = models.ForeignKey(
        PhysicalUnit,
        related_name="%(app_label)s_%(class)s_unit_related",
        related_query_name="%(app_label)s_%(class)s_unit_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="unit of amount of substance or number of molecules in a complex (protein-ligand, protein-protein, ...)",
    )
    concentration = models.DecimalField(
        max_digits=20,
        decimal_places=9,
        blank=True,
        null=True,
        help_text="component (not final !) concentration in mol/l (in mixtures)",
    )
    concentration_unit = models.ForeignKey(
        PhysicalUnit,
        related_name="%(app_label)s_%(class)s_concentration_unit_related",
        related_query_name="%(app_label)s_%(class)s_concentration_unit_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="unit of concentration, e.g. mol/l , kg/l  ...",
    )
    description = models.TextField(blank=True, null=True, help_text="description")
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="datetime of last modification"
    )

    def __str__(self):
        return self.name or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.name is None or self.name == "":
            self.name = f"mix_comp_{str(self.mixturecomponent_id)}"
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/MixtureComponent/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class Mixture(SubstanceAbstr):
    """An (abstract) mixture is a set of (abstract) substances or (abstract) polymers, e.g. a buffer, a medium, 
    an assay composition. Analytical data should be addable (like UV-vis, NMR, HPLC, .... )
    acronyms: PBS, LB, ....
    """

    model_curi = "lara:substances/Mixture"
    mixture_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    components = models.ManyToManyField(
        MixtureComponent,
        related_name="%(app_label)s_%(class)s_components_related",
        related_query_name="%(app_label)s_%(class)s_components_related_query",
        help_text="components of the mixture",
    )
    physical_state_matter = models.ForeignKey(
        PhysicalStateMatter,
        related_name="%(app_label)s_%(class)s_state_of_matter_related",
        related_query_name="%(app_label)s_%(class)s_state_of_matter_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="physical state of matter at 293 K",
    )
    minchi = models.TextField(
        blank=True, null=True, help_text="MInChi - Mixtures InChi"
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/mixture/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class MixturesSubset(ItemSubsetAbstr):
    """User or group defined subset of mixtures"""

    model_curi = "lara:substances/MixturesSubset"
    mixturessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    mixtures = models.ManyToManyField(
        Mixture,
        related_name="%(app_label)s_%(class)s_mixtures_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_related_query",
        blank=True,
        help_text="mixtures of the subset",
        through="OrderedMixturesSubset",
    )


class OrderedMixturesSubset(models.Model):
    """Through model for the many-to-many relationship between MixturesSubset and Mixture.
    This class can be used to store the order of mixtures in a subset"""

    model_curi = "lara:substances/OrderedMixturesSubset"
    orderedmixturessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    mixture = models.ForeignKey(
        Mixture,
        related_name="%(app_label)s_%(class)s_mixture_related",
        related_query_name="%(app_label)s_%(class)s_mixture",
        on_delete=models.CASCADE,
        help_text="mixture in the subset",
    )

    mixtures_subset = models.ForeignKey(
        MixturesSubset,
        related_name="%(app_label)s_%(class)s_mixtures_subset_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_subset",
        on_delete=models.CASCADE,
        help_text="subset of mixtures",
    )

    order = models.IntegerField(help_text="order of mixture in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["mixture", "mixtures_subset"],
                name="%(app_label)s_%(class)s_mixture_mixtures_subset_unique",
            ),
        ]
        ordering = ("order",)


class MoleculeResidue(models.Model):
    """Residues of a molecule"""

    model_curi = "lara:substances/MoleculeResidue"
    moleculeresidue_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    name = models.TextField(blank=True, help_text="name of the residue")
    substructure = models.JSONField(blank=True, help_text="substructure of the residue")
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    description = models.TextField(blank=True, null=True, help_text="description")

    def __str__(self):
        return self.name or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/MoleculeResidue/{self.name.replace(' ', '_').lower().strip()}"

        super().save(*args, **kwargs)


class ReactionComponent(models.Model):
    """A Reaction Component is an (abstract) representation of a substance or mixture
       with a role, an order and a stoichiometric factor.
       They are specific for a certain reaction.
    """

    model_curi = "lara:substances/ReactionComponent"
    reactioncomponent_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    name = models.TextField(
        blank=True, null=True, help_text="name of the reaction component"
    )
    substance = models.ForeignKey(
        Substance,
        related_name="%(app_label)s_%(class)s_substances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="ID of the substance",
    )
    polymer = models.ForeignKey(
        Polymer,
        related_name="%(app_label)s_%(class)s_polymers_related",
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="ID of the polymer",
    )
    mixture = models.ForeignKey(
        Mixture,
        related_name="%(app_label)s_%(class)s_mixtures_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="ID of the mixture",
    )
    order = models.IntegerField(
        null=True,
        blank=True,
        help_text="order in the reaction, in case order of this component plays a role",
    )
    stoichiometric_factor = models.DecimalField(
        max_digits=9,
        decimal_places=3,
        default=1.0,
        null=True,
        blank=True,
        help_text="stoichiometric_factor: neg: starting material, pos: product",
    )
    roles = models.ManyToManyField(
        SubstanceClass,
        related_name="%(app_label)s_%(class)s_reaction_roles__related",
        related_query_name="%(app_label)s_%(class)s_reaction_roles_related_query",
        blank=True,
        help_text="Roles of the Reaction Compontent, like product, solvent, catalyst, co-factor. A component can have mulitple roles.",
    )
    physical_state = models.ForeignKey(
        PhysicalStateMatter,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="e.g. solid, liquid, gas, plasma at reaction conditions",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge, ...",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="datetime of last modification"
    )

    search_vector = SearchVectorField(null=True)

    class Meta:
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.substance.name or self.polymer.name or self.mixture.name or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        self.name = (
            self.substance.name or self.polymer.name or self.mixture.name or ""
        )

        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/reaction_component/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    

class ReactionComponentsSubset(ItemSubsetAbstr):
    """User or group defined subset of reaction components"""

    model_curi = "lara:substances/ReactantionComponentsSubset"
    reactioncomponentssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    reaction_components = models.ManyToManyField(
        ReactionComponent,
        related_name="%(app_label)s_%(class)s_reaction_components_related",
        related_query_name="%(app_label)s_%(class)s_reaction_components_related_query",
        blank=True,
        help_text="reaction components of the subset",
        through="OrderedReactionComponentsSubset",
    )


class OrderedReactionComponentsSubset(models.Model):
    """Through model for the many-to-many relationship between ReactantsSubset and Reactant.
    This class can be used to store the order of reaction_components in a subset"""

    model_curi = "lara:substances/OrderedReactionComponentsSubset"

    orderedreactioncomponentssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    reaction_component = models.ForeignKey(
        ReactionComponent,
        related_name="%(app_label)s_%(class)s_reaction_components_related",
        related_query_name="%(app_label)s_%(class)s_reaction_components_related_query",
        on_delete=models.CASCADE,
        help_text="reaction components in the subset",
    )

    reaction_components_subset = models.ForeignKey(
        ReactionComponentsSubset,
        related_name="%(app_label)s_%(class)s_reaction_components_subset_related",
        related_query_name="%(app_label)s_%(class)s_reaction_components_subset",
        on_delete=models.CASCADE,
        help_text="subset of reaction components",
    )

    order = models.IntegerField(help_text="order of reaction component in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["reaction_component", "reaction_components_subset"],
                name="%(app_label)s_%(class)s_reaction_component_reaction_components_subset_unique",
            ),
        ]
        ordering = ("order",)


class Reaction(models.Model):
    """
    Abstractum of a Chemical reaction with components, conditions and properties.

    Instances of (real) reactions should be modeled as Experiments - in conjuction with ReactionInstances- with procedures, devices, preparation steps, etc.
    TODO: side reactions, branched reactions
    """

    model_curi = "lara:substances/Reaction"
    reaction_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.TextField(blank=True, unique=True, help_text="reaction name")
    label = models.TextField(blank=True, null=True, help_text="(short) label / acronym")
    rx_uuid = models.UUIDField(
        blank=True,
        null=True,
        unique=True,
        default=uuid.uuid4,
        help_text="reaction UUID",
    )
    rinchi = models.TextField(blank=True, null=True, help_text="Reactions InChi string")
    components = models.ManyToManyField(
        ReactionComponent,
        related_name="%(app_label)s_%(class)s_components_related",
        related_query_name="%(app_label)s_%(class)s_components_related_query",
        blank=True,
        help_text="all components of the reaction, also solvents, catalysts, ...",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="properties of the reaction, like reaction class(es), equilibrium constant, speed, order of kinetics, enthalpy, entropy, etc., specified by the reactions_properties model",
    )
    parameters = models.JSONField(
        blank=True,
        null=True,
        help_text="reaction parameters / conditions, like stoichiometry, temperature, durations, pressure, pH, ..., specified by the reactions_parameters model",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    rinchi = models.TextField(blank=True, null=True, help_text="RInChi string")
    rinchi_key_short = models.TextField(
        blank=True, null=True, help_text="short RInChiKey key, s. link"
    )
    rinchi_key_long = models.TextField(
        blank=True, null=True, help_text="long RInChiKey key"
    )
    rinchi_web_key = models.TextField(
        blank=True, null=True, help_text="RInChiKey web key"
    )
    rxno = models.TextField(blank=True, null=True, help_text="rxno")
    equilibrium_const = models.DecimalField(
        max_digits=20,
        decimal_places=9,
        blank=True,
        null=True,
        help_text="literature value of the equilibrium constant",
    )
    deltag = models.DecimalField(
        max_digits=20,
        decimal_places=9,
        blank=True,
        null=True,
        help_text="literature value of the free energy",
    )
    order = models.IntegerField(
        null=True,
        blank=True,
        help_text="order of the reaction in a set of multi-step reactions, in case order plays a role. It does not describe the kinetics",
    )
    safety_info = models.JSONField(
        blank=True,
        null=True,
        help_text="reaction safety information in human and machine readable form, including safety symbols in svg.",
    )
    description = models.TextField(blank=True, null=True, help_text="")
    remarks = models.TextField(blank=True, null=True, help_text="")
    svg = models.TextField(blank=True, null=True, help_text="svg image of the reaction")
    # remove hardcoded link: lara_substances/reactions/
    image = models.ImageField(
        upload_to="substances/reactions/",
        blank=True,
        null=True,
        help_text="rel. path/filename to image",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )

    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like kinetic models, spectra, chromatograms, reaction schemes, ...",
    )
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="datetime of last modification"
    )

    search_vector = SearchVectorField(null=True)

    class Meta:
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.name  # f"{self.rx_uuid}({self.name})" or ""

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/reaction/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

class ReactionsSubset(ItemSubsetAbstr):
    """User or group defined subset of reactions"""

    model_curi = "lara:substances/ReactionsSubset"
    reactionssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    reactions = models.ManyToManyField(
        Reaction,
        related_name="%(app_label)s_%(class)s_reactions_related",
        related_query_name="%(app_label)s_%(class)s_reactions_related_query",
        blank=True,
        help_text="reactions of the subset",
        through="OrderedReactionsSubset",
    )


class OrderedReactionsSubset(models.Model):
    """Through model for the many-to-many relationship between ReactionsSubset and Reaction.
    This class can be used to store the order of reactions in a subset"""

    model_curi = "lara:substances/OrderedReactionsSubset"
    orderedreactionssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    reaction = models.ForeignKey(
        Reaction,
        related_name="%(app_label)s_%(class)s_reaction_related",
        related_query_name="%(app_label)s_%(class)s_reaction",
        on_delete=models.CASCADE,
        help_text="reaction in the subset",
    )

    reactions_subset = models.ForeignKey(
        ReactionsSubset,
        related_name="%(app_label)s_%(class)s_reactions_subset_related",
        related_query_name="%(app_label)s_%(class)s_reactions_subset",
        on_delete=models.CASCADE,
        help_text="subset of reactions",
    )

    order = models.IntegerField(help_text="order of reaction in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["reaction", "reactions_subset"],
                name="%(app_label)s_%(class)s_reaction_reactions_subset_unique",
            ),
        ]
        ordering = ("order",)


class MultiStepReaction(models.Model):
    """
    Multi-step chemical reaction, like a multi step synthesis,
    an enzymatic/biochemical pathway or enzymatic cascade reaction
    TODO: branched reactions / side reactions
    """

    model_curi = "lara:substances/MultiStepReaction"
    multistepreaction_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    name = models.TextField(blank=True, unique=True, help_text="reaction name")
    reactions = models.ManyToManyField(
        Reaction,
        related_name="%(app_label)s_%(class)s_reactions_related",
        related_query_name="%(app_label)s_%(class)s_reactions_related_query",
        blank=True,
        help_text="all involved reactions",
    )
    sequence = models.JSONField(
        blank=True,
        null=True,
        help_text="sequence of sequential and parallel reactions, like, e.g. ['rx1', 'rx2', ['rx3', 'rx4']]",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="properties of the reaction, like reaction class(es), equilibrium constant, speed, order of kinetics, enthalpy, entropy, etc., specified by the reactions_properties model",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    parameters = models.JSONField(
        blank=True,
        null=True,
        help_text="reaction parameters / conditions, like stoichiometry, durations, temperature, pressure, pH, ..., specified by the reactions_parameters model",
    )
    svg = models.TextField(
        blank=True, null=True, help_text="svg image of the reaction scheme."
    )

    image = models.ImageField(
        upload_to="substances/reactions/",
        blank=True,
        null=True,
        help_text="rel. path/filename to image",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    rinchi = models.TextField(blank=True, null=True, help_text="Reactions InChi string")
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like kinetic models, spectra, chromatograms, reaction schemes, ...",
    )
    description = models.TextField(blank=True, null=True, help_text="")
    remarks = models.TextField(blank=True, null=True, help_text="")
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="datetime of last modification"
    )

    search_vector = SearchVectorField(null=True)

    class Meta:
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.name

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/MultiStepReaction/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)
    

class MultiStepReactionsSubset(ItemSubsetAbstr):
    """User or group defined subset of multi-step reactions"""

    model_curi = "lara:substances/MultiStepReactionsSubset"
    multistepreactionssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    reactions_multistep = models.ManyToManyField(
        MultiStepReaction,
        related_name="%(app_label)s_%(class)s_multistepreactions_related",
        related_query_name="%(app_label)s_%(class)s_multistepreactions_related_query",
        blank=True,
        help_text="multi-step reactions of the subset",
        through="OrderedMultiStepReactionsSubset",
    )

class OrderedMultiStepReactionsSubset(models.Model):
    """Through model for the many-to-many relationship between MultiStepReactionsSubset and MultiStepReaction.
    This class can be used to store the order of multi-step reactions in a subset"""

    model_curi = "lara:substances/OrderedMultiStepReactionsSubset"
    orderedmultistepreactionssubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    reactions_multistep = models.ForeignKey(
        MultiStepReaction,
        related_name="%(app_label)s_%(class)s_multistepreaction_related",
        related_query_name="%(app_label)s_%(class)s_multistep_reaction",
        on_delete=models.CASCADE,
        help_text="multi-step reaction in the subset",
    )

    multistepreactions_subset = models.ForeignKey(
        MultiStepReactionsSubset,
        related_name="%(app_label)s_%(class)s_multistepreactions_subset_related",
        related_query_name="%(app_label)s_%(class)s_multistepreactions_subset",
        on_delete=models.CASCADE,
        help_text="subset of multi-step reactions",
    )

    order = models.IntegerField(help_text="order of multi-step reaction in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["reactions_multistep", "multistepreactions_subset"],
                name="%(app_label)s_%(class)s_multistepreaction_multistepreactions_subset_unique",
            ),
        ]
        ordering = ("order",)
