class SubstanceClass(models.Model):
    """classes for substances, like amino acid, peptide, protein, nucleotide, DNA,..."""

    model_curi = "lara:substances/SubstanceClass"

    substanceclass_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )
    name = models.TextField(
        unique=True, help_text="like amino acid, peptide, protein, nucleotide, DNA"
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    description = models.TextField(
        blank=True, null=True, help_text="description of the substance class"
    )

    class Meta:
        verbose_name_plural = "SubstanceClasses"

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/SubstanceClass/{self.name.replace(' ', '_').lower().strip()}"

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

 

class SubstanceAbstr(models.Model):
    """abstract base class for all substances"""

    name = models.TextField(blank=True, help_text="most common name of the substance")
    acronym = models.TextField(
        blank=True, null=True, help_text="acronym, e.g. TFA, DMSO, MBA, 160323MBA"
    )
    synonyms = models.TextField(
        blank=True,
        null=True,
        help_text="comma separated list of synonyms, like 'benzene', 'amylalcohol' ",
    )
    substance_classes = models.ManyToManyField(
        SubstanceClass,
        related_name="%(app_label)s_%(class)s_substance_classes_related",
        related_query_name="%(app_label)s_%(class)s_substance_classes_related_query",
        blank=True,
        help_text="substance class, e.g. salt, complex, nucleotide",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    cas = models.TextField(blank=True, null=True, help_text="Chemical Abstract ")
    iupac_name = models.TextField(
        blank=True, null=True, help_text="IUPAC preferred name"
    )
    iupac_name_traditional = models.TextField(
        blank=True, null=True, help_text="IUPAC traditional name"
    )
    iupac_name_systematic = models.TextField(
        blank=True, null=True, help_text="IUPAC systematic name"
    )
    pubchem_cid = models.TextField(blank=True, null=True, help_text="PubChem CID")
    pubchem_sid = models.TextField(blank=True, null=True, help_text="PubChem SID")
    pubchem_fingerprint = models.TextField(
        blank=True,
        null=True,
        help_text=" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt",
    )
    chemspider_id = models.TextField(
        blank=True, null=True, help_text="s. chemspider.com"
    )
    beilstein_regnum = models.TextField(
        blank=True, null=True, help_text="Beilstein Registry Number"
    )
    ec_num = models.TextField(blank=True, null=True, help_text="EC number")
    mdl_num = models.TextField(blank=True, null=True, help_text="MDL number")

    mass_exact = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.",
    )
    mass_monoisotopic = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text=" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.",
    )
    mass_molar = models.DecimalField(
        max_digits=32,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number",
    )
    density = models.DecimalField(
        max_digits=20,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="density in g /cm3",
    )
    physical_state_matter = models.ForeignKey(
        PhysicalStateMatter,
        related_name="%(app_label)s_%(class)s_state_of_matter_related",
        related_query_name="%(app_label)s_%(class)s_state_of_matter_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="physical state of matter at 293 K",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON",
    )
    sumformula = models.TextField(
        blank=True, null=True, help_text="sum formula of the substance"
    )
    # note also the version of the files in metadata
    cml = models.TextField(
        blank=True, null=True, help_text="Chemical Markup Language, s. "
    )
    cdxml = models.TextField(blank=True, null=True, help_text="ChemDraw XML")
    smiles = models.TextField(blank=True, null=True, help_text="SMILES")
    isosmiles = models.TextField(blank=True, null=True, help_text="isomeric SMILES")
    cansmiles = models.TextField(blank=True, null=True, help_text="canonical SMILES")
    inchi = models.TextField(blank=True, null=True, help_text="InChi")
    inchikey = models.TextField(blank=True, null=True, help_text="InChiKey")
    stdinchi = models.TextField(blank=True, null=True, help_text="StdInChi")
    stdinchikey = models.TextField(blank=True, null=True, help_text="StdInChiKey")
    pdb_id = models.TextField(
        blank=True, null=True, help_text="Protein Database ID / Code"
    )
    icsd_id = models.TextField(
        blank=True,
        null=True,
        help_text="Inorganic Crystal Structure Database ID / Code",
    )
    cod_id = models.TextField(
        blank=True, null=True, help_text="Crystallography Open Database ID / Code"
    )
    ccdc_id = models.TextField(
        blank=True,
        null=True,
        help_text="Cambridge Crystallographic Data Centre ID / Code",
    )
    csd_id = models.TextField(
        blank=True, null=True, help_text="Cambridge Structural Database ID / Code"
    )
    structure_info = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database",
    )
    url = models.URLField(
        blank=True,
        null=True,
        max_length=512,
        help_text="Universal Resource Locator - URL to external structure database,  link to public structure database",
    )
    # PAC-ID:  https://github.com/ApiniLabs/PAC-ID
    pac_id = models.URLField(
        blank=True,
        null=True,
        unique=True,
        help_text="Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.",
    )
    url_definition = models.URLField(
        blank=True,
        null=True,
        help_text="definition Universal Resource Locator - URL, like wikipedia",
    )
    mol_raw = models.TextField(blank=True, null=True, help_text="mol file raw")
    mol_2d = models.TextField(blank=True, null=True, help_text="mdl mol file 2D")
    mol_3d = models.TextField(blank=True, null=True, help_text="mdl mol file 3D")
    svg = models.TextField(
        blank=True, null=True, help_text="svg image of the substance"
    )
    image = models.ImageField(
        upload_to="substances/",
        blank=True,
        null=True,
        help_text="e.g. png image of substance",
    )  # rel. path/filename to image
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like absorption coefficient",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )
    remarks = models.TextField(
        blank=True, null=True, help_text="some remarks to this substance"
    )
    description = models.TextField(
        blank=True, null=True, help_text="description of the substance"
    )
    datetime_last_modified = models.DateTimeField(
        null=True, blank=True, help_text="date and time when data was last modified"
    )

    search_vector = SearchVectorField(null=True)

    class Meta:
        abstract = True
        constraints = [
            models.UniqueConstraint(
                fields=["name", "iupac_name", "pubchem_sid", "pubchem_cid"],
                name="%(app_label)s_%(class)s_name_iupac_pubchem_unique",
            )
        ]
        indexes = (GinIndex(fields=["search_vector"]),)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return f"{self.name} ({self.description})" or ""

