/**
 * Bulk actions for tables (substances, polymers, mixtures, isotopes, reactions)
 * Handles checkbox selection and bulk operations
 */

/**
 * Toggle all checkboxes on/off for any entity type
 * @param {HTMLElement} selectAllCheckbox - The select-all checkbox element
 * @param {string} entityType - The entity type (substance, polymer, mixture, isotope, reaction)
 */
function toggleAllCheckboxes(selectAllCheckbox, entityType = 'substance') {
    const checkboxes = document.querySelectorAll(`.${entityType}-checkbox`);
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
    updateBulkActionButtons(entityType);
}

/**
 * Update visibility of bulk action buttons based on selection
 * @param {string} entityType - The entity type (substance, polymer, mixture, isotope, reaction)
 */
function updateBulkActionButtons(entityType = 'substance') {
    const selectedCheckboxes = document.querySelectorAll(`.${entityType}-checkbox:checked`);
    const deleteBtn = document.getElementById(`bulk-delete-btn-${entityType}`);
    const duplicateBtn = document.getElementById(`bulk-duplicate-btn-${entityType}`);
    
    if (selectedCheckboxes.length > 0) {
        if (deleteBtn) deleteBtn.style.display = 'block';
        if (duplicateBtn) duplicateBtn.style.display = 'block';
    } else {
        if (deleteBtn) deleteBtn.style.display = 'none';
        if (duplicateBtn) duplicateBtn.style.display = 'none';
    }
    
    // Update select-all checkbox state
    const selectAllCheckbox = document.getElementById(`select-all-checkbox-${entityType}`);
    const allCheckboxes = document.querySelectorAll(`.${entityType}-checkbox`);
    if (selectAllCheckbox && allCheckboxes.length > 0) {
        selectAllCheckbox.checked = selectedCheckboxes.length === allCheckboxes.length;
        selectAllCheckbox.indeterminate = selectedCheckboxes.length > 0 && selectedCheckboxes.length < allCheckboxes.length;
    }
}

/**
 * Get array of selected IDs for any entity type
 * @param {string} entityType - The entity type (substance, polymer, mixture, isotope, reaction)
 * @returns {Array<string>} Array of selected entity IDs
 */
function getSelectedIds(entityType) {
    const selectedCheckboxes = document.querySelectorAll(`.${entityType}-checkbox:checked`);
    return Array.from(selectedCheckboxes).map(cb => cb.value);
}

// Legacy function names for backward compatibility
function getSelectedSubstanceIds() {
    return getSelectedIds('substance');
}

function getSelectedPolymerIds() {
    return getSelectedIds('polymer');
}

function getSelectedMixtureIds() {
    return getSelectedIds('mixture');
}

function getSelectedIsotopeIds() {
    return getSelectedIds('isotope');
}

function getSelectedReactionIds() {
    return getSelectedIds('reaction');
}

/**
 * Clear all selections for any entity type
 * @param {string} entityType - The entity type (substance, polymer, mixture, isotope, reaction)
 */
function clearAllSelections(entityType = 'substance') {
    const checkboxes = document.querySelectorAll(`.${entityType}-checkbox`);
    checkboxes.forEach(checkbox => {
        checkbox.checked = false;
    });
    const selectAllCheckbox = document.getElementById(`select-all-checkbox-${entityType}`);
    if (selectAllCheckbox) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    }
    updateBulkActionButtons(entityType);
}

// Listen for HTMX events to maintain checkbox state after table updates
document.body.addEventListener('htmx:afterSwap', function(event) {
    const targetId = event.detail.target.id;
    
    // Check which table was swapped and update corresponding buttons
    const entityTypes = ['substance', 'polymer', 'mixture', 'isotope', 'reaction'];
    entityTypes.forEach(entityType => {
        const tableIds = [`${entityType}s-table`, `${entityType}-table`, `${entityType}-table-body`];
        if (tableIds.includes(targetId)) {
            updateBulkActionButtons(entityType);
        }
    });
});

// Listen for successful bulk operations
document.body.addEventListener('htmx:afterRequest', function(event) {
    const targetId = event.detail.target.id;
    
    // Check which bulk action button was clicked
    const entityTypes = ['substance', 'polymer', 'mixture', 'isotope', 'reaction'];
    entityTypes.forEach(entityType => {
        if (targetId === `bulk-delete-btn-${entityType}` || targetId === `bulk-duplicate-btn-${entityType}`) {
            // Clear selections after successful operation
            if (event.detail.successful) {
                setTimeout(() => clearAllSelections(entityType), 100);
            }
        }
    });
});
