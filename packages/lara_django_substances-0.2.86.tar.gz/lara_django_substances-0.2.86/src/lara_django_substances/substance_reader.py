import asyncio
# from chemdatareader.chemdatareader_impl import ChemDatReader


async def read_substances(csv_file_name: str = None):
    pass
    # cdr = ChemDatReader()
    # await asyncio.gather(cdr.read_csv(csv_filename=csv_file_name))
