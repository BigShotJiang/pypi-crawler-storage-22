"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances admin *

:details: lara_django_substances admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_substances >> tables.py" to update this file
________________________________________________________________________
"""
# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_substances
# generated with django-extensions tests_generator  lara_django_substances > tests.py (LARA-version)

import logging
from django.utils.html import format_html
import django_tables2 as tables


from .models import (
    ExtraData,
    SubstanceClass,
    Isotope,
    Substance,
    Polymer,
    MixtureComponent,
    Mixture,
    MoleculeResidue,
    ReactionComponent,
    Reaction,
    MultiStepReaction,
)

from django.utils.html import format_html


class ImageColumn(tables.Column):
    def render(self, value):
        return format_html('<img src="{url}" height="48px", width="48px">', url=value)


class ExtraDataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:extradata-detail', [tables.A('pk')]))

    class Meta:
        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "uri",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )


class SubstanceClassTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:substanceclass-detail', [tables.A('pk')]))

    class Meta:
        model = SubstanceClass

        fields = ("name", "description")


class IsotopeTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:isotope-detail', [tables.A('pk')]))

    class Meta:
        model = Isotope

        fields = (
            "name",
            "acronym",
            "synonyms",
            "cas",
            "iupac_name",
            "PubChemID",

            "mdl_num",

            "properties",
            "sumformula",

            "inchi",

            "svg",
            "image",
            "remarks",
            "description",
            "num_protons",
            "electron_config",
        )


class PolymerTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_substances:polymer-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_substances:polymer-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_substances:polymer-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    class Meta:
        model = Polymer

        fields = (
            "name",
            "acronym",
            "synonyms",
            "cas",
            "iupac_name",
            "PubChemID",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "properties",
            "sumformula",
            "svg",
            "image",
            "remarks",
            "description",
            "sequence",
            "melting_point",
            "boiling_point",
            "media_type",
            "sequence_file",
        )


class MixtureComponentTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:mixturecomponent-detail', [tables.A('pk')]))

    class Meta:
        model = MixtureComponent

        fields = (
            "name",
            "iri",
            "substance",
            "polymer",
            "concentration",
            "concentration_unit",
            "description",
        )


class MixtureTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_substances:mixture-detail", [tables.A("pk")]))
    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_substances:mixture-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_substances:mixture-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    class Meta:
        model = Mixture

        fields = (
            "name",
            "acronym",
            "synonyms",
            "cas",
            "iupac_name",
            "PubChemID",
            "pubchem_fingerprint",
            "chemspider_id",
            "beilstein_regnum",
            "ec_num",
            "mdl_num",
            "pdb_id",
            "sumformula",
            "svg",
            "image",
            "remarks",
            "description",
        )


class MoleculeResiduesTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:moleculeresidues-detail', [tables.A('pk')]))

    class Meta:
        model = MoleculeResidue

        fields = ("name", "substructure", "iri")


class ReactantTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:reactant-detail', [tables.A('pk')]))

    class Meta:
        model = ReactionComponent

        fields = (
            "iri",
            "substance",
            "polymer",
            "mixture",
            "order",
            "stoichiometric_factor",
            "physical_state",
            "resources_external",
        )


class ReactionTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:reaction-detail', [tables.A('pk')]))

    class Meta:
        model = Reaction

        fields = (
            "name",
            "label",
            "rx_uuid",
            "iri",
            "rinchi",
            "rinchi_key_short",
            "rinchi_key_long",
            "rinchi_web_key",
            "rxno",
            "equilibrium_const",
            "deltag",
            "order",
            "safety_info",
            "description",
            "remarks",
            "svg",
            "image",
            "resources_external",
        )


class MultiStepReactionTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances:multistepreaction-detail', [tables.A('pk')]))

    class Meta:
        model = MultiStepReaction

        fields = ("name", "description", "remarks", "svg", "image", "resources_external")
