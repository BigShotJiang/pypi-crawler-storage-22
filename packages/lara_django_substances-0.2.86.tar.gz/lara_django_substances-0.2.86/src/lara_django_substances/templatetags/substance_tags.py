"""Custom template tags for lara_django_substances."""

from django import template

register = template.Library()


@register.filter
def lookup(obj, field_name):
    """Look up a field value on an object dynamically.
    
    Usage: {{ item|lookup:"field_name" }}
    
    This allows dynamic field access in templates, useful for reusable components.
    """
    try:
        return getattr(obj, field_name)
    except (AttributeError, TypeError):
        return None
