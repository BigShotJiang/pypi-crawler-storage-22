"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances urls *

:details: lara_django_substances urls module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from django.views.generic import TemplateView
from django_socio_grpc.settings import grpc_settings

from . import views

# Add your {cookiecutter.project_slug}} urls here.


# !! this sets the apps namespace to be used in the template
app_name = "lara_django_substances"

# companies and institutions should also be added
# the 'name' attribute is used in templates to address the url independent of the view

urlpatterns = [
    # the 'name' value as called by the {% url %} template tag
    path("substance/overview/", views.SubstanceOverviewView.as_view(), name="substances-overview"),
    path("substance/add/", views.SubstanceAddView.as_view(), name="substance-add"),
    path("substance/create/", views.SubstanceCreateView.as_view(), name="substance-create"),
    path("substance/update/<uuid:pk>/", views.SubstanceUpdateView.as_view(), name="substance-update"),
    path("substance/delete/<uuid:pk>/", views.SubstanceDeleteView.as_view(), name="substance-delete"),
    path("substance/bulk-delete/", views.substance_bulk_delete, name="substance-bulk-delete"),
    path("substance/bulk-duplicate/", views.substance_bulk_duplicate, name="substance-bulk-duplicate"),
    path("substance/row/<uuid:pk>/", views.get_substance_row, name="substance-row"),
    path("substance/search-simple/", views.search_substances, name="substance-search-simple"),
    path("substance/<uuid:pk>/", views.SubstanceDetailView.as_view(), name="substance-detail"),
    # Polymer routes
    path("polymer/overview/", views.PolymerOverviewView.as_view(), name="polymers-overview"),
    path("polymer/list/", views.PolymerOverviewView.as_view(), name="polymer-list"),  # Redirect old route to new view
    path("polymer/create/", views.PolymerCreateView.as_view(), name="polymer-create"),
    path("polymer/update/<uuid:pk>/", views.PolymerUpdateView.as_view(), name="polymer-update"),
    path("polymer/delete/<uuid:pk>/", views.PolymerDeleteView.as_view(), name="polymer-delete"),
    path("polymer/bulk-delete/", views.polymer_bulk_delete, name="polymer-bulk-delete"),
    path("polymer/bulk-duplicate/", views.polymer_bulk_duplicate, name="polymer-bulk-duplicate"),
    path("polymer/<uuid:pk>/", views.PolymerDetailView.as_view(), name="polymer-detail"),
    # Mixture routes
    path("mixture/overview/", views.MixtureOverviewView.as_view(), name="mixtures-overview"),
    path("mixture/list/", views.MixtureOverviewView.as_view(), name="mixture-list"),  # Redirect old route to new view
    path("mixture/create/", views.MixtureCreateView.as_view(), name="mixture-create"),
    path("mixture/update/<uuid:pk>/", views.MixtureUpdateView.as_view(), name="mixture-update"),
    path("mixture/delete/<uuid:pk>/", views.MixtureDeleteView.as_view(), name="mixture-delete"),
    path("mixture/bulk-delete/", views.mixture_bulk_delete, name="mixture-bulk-delete"),
    path("mixture/bulk-duplicate/", views.mixture_bulk_duplicate, name="mixture-bulk-duplicate"),
    path("mixture/<uuid:pk>/", views.MixtureDetailView.as_view(), name="mixture-detail"),
    # Isotope routes
    path("isotope/overview/", views.IsotopeOverviewView.as_view(), name="isotopes-overview"),
    path("isotope/list/", views.IsotopeOverviewView.as_view(), name="isotope-list"),  # Redirect old route to new view
    path("isotope/create/", views.IsotopeCreateView.as_view(), name="isotope-create"),
    path("isotope/update/<uuid:pk>/", views.IsotopeUpdateView.as_view(), name="isotope-update"),
    path("isotope/delete/<uuid:pk>/", views.IsotopeDeleteView.as_view(), name="isotope-delete"),
    path("isotope/bulk-delete/", views.isotope_bulk_delete, name="isotope-bulk-delete"),
    path("isotope/bulk-duplicate/", views.isotope_bulk_duplicate, name="isotope-bulk-duplicate"),
    # Reaction routes
    path("reaction/overview/", views.ReactionOverviewView.as_view(), name="reactions-overview"),
    path("reaction/list/", views.ReactionOverviewView.as_view(), name="reaction-list"),  # Redirect old route to new view
    path("reaction/create/", views.ReactionCreateView.as_view(), name="reaction-create"),
    path("reaction/update/<uuid:pk>/", views.ReactionUpdateView.as_view(), name="reaction-update"),
    path("reaction/delete/<uuid:pk>/", views.ReactionDeleteView.as_view(), name="reaction-delete"),
    path("reaction/bulk-delete/", views.reaction_bulk_delete, name="reaction-bulk-delete"),
    path("reaction/bulk-duplicate/", views.reaction_bulk_duplicate, name="reaction-bulk-duplicate"),
    # old reactions - commented out
    # path('reaction/list/', views.ReactionsListView.as_view(), name='reaction-list'),
    # path('reaction/add/', views.ReactionAddView.as_view(), name='reaction-add'),
    # path('reaction/create/', views.ReactionCreateView.as_view(), name='reaction-create'),
    # path('reaction/update/<uuid:pk>', views.ReactionUpdateView.as_view(), name='reaction-update'),
    # path('reaction/delete/<uuid:pk>', views.ReactionDeleteView.as_view(), name='reaction-delete'),
    # path('reaction/<uuid:pk>/', views.ReactionDetailView.as_view(), name='reaction-detail'),
    # path('', views.IndexView.as_view(), name='index'),
    # path('browse/', views.browse, name='substances-browser'),
    # path('<int:pk>/', views.SubstanceDetail.as_view(), name='substance-detail'),
    # path('substanceslist/', views.SubstancesListView.as_view(), name='substances-list'),
    # path('add/', views.SubstanceCreateView.as_view(), name='substance-create'),
    # ~ path('(?P<pk>[0-9]+)/', views.SubstanceDetail.as_view(), name='substance-detail'),
    # path('search', views.SubstanceSearchView.as_view(), name='search'),
    # path('search-results/', views.SubstanceSearchResults.as_view(), name='search-results'),
    # path('results/', views.results, name='results'),
    # ~ path(r'^(?P<question_id>[0-9]+)/$', views.detail, name='detail'),
    # ~ path(r'^(?P<question_id>[0-9]+)/results/$', views.results, name='results'),
    # ~ path(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
    path("", views.SubstanceOverviewView.as_view(), name="substances-root"),
]

grpc_settings.user_settings["GRPC_HANDLERS"] += ["lara_django_substances.grpc.handlers.grpc_handlers"]
