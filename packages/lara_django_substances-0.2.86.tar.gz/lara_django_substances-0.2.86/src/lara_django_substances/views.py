"""
_____________________________________________________________________.

:PROJECT: LARAsuite

*lara_django_substances views *

:details: lara_django_substances views module.
         - add app specific urls here
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: - for search: look at old versions of the views.py file
.. todo:: -
________________________________________________________________________
"""

import asyncio
import tempfile
from dataclasses import dataclass, field
from typing import List

from django.core.paginator import Paginator
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.decorators import classonlymethod
from django.views.decorators.http import require_http_methods
from django.views.generic import CreateView, DeleteView, DetailView, FormView, ListView, UpdateView
from lara_django_projects.models import Project

from .apps import LaraDjangoSubstancesConfig
from .filters import SubstanceDjFilter
from .forms import (
    IsotopeCreateForm,
    IsotopeUpdateForm,
    MixtureCreateForm,
    MixtureUpdateForm,
    PolymerCreateForm,
    PolymerUpdateForm,
    ReactionCreateForm,
    ReactionUpdateForm,
    SearchForm,
    SubstanceAddForm,
    SubstanceClassCreateForm,
    SubstanceClassUpdateForm,
    SubstanceCreateForm,
    SubstanceUpdateForm,
)
from .models import Isotope, Mixture, MixtureComponent, Polymer, Reaction, Substance
from .substance_reader import read_substances


@dataclass
class SubstancesMenu:
    menu_items: List[dict] = field(
        default_factory=lambda: [
            {"name": "Substances", "path": "lara_django_substances:substances-overview"},
            {"name": "Substance-Store", "path": "lara_django_substances_store:substance-list"},
            {"name": "Isotopes", "path": "lara_django_substances:isotopes-overview"},
            {"name": "Polymers", "path": "lara_django_substances:polymer-list"},
            {"name": "Polymer-Store", "path": "lara_django_substances_store:polymer-list"},
            {"name": "Mixtures", "path": "lara_django_substances:mixture-list"},
            {"name": "Mixture-Store", "path": "lara_django_substances_store:mixture-list"},
            {"name": "Reactions", "path": "lara_django_substances:reaction-list"},
        ]
    )


@dataclass
class SidebarMenu:
    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-500"},
            {"name": "Dashboard", "path": "/dashboard/", "icon": "dashboard", "hover_class": "hover:bg-gray-500"},
            {"name": "Apps", "path": "/apps/", "icon": "apps", "hover_class": "hover:bg-gray-500"},
            {"name": "Projects", "path": "/projects/", "icon": "projects", "hover_class": "hover:bg-red-500"},
            {"name": "Processes", "path": "/processes/", "icon": "processes", "hover_class": "hover:bg-orange-500"},
            {"name": "Data", "path": "/data/", "icon": "data", "hover_class": "hover:bg-sky-500"},
            {
                "name": "Devices",
                "path": "/material/device/list/",
                "icon": "devices",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Parts", "path": "/material/part/list/", "icon": "parts", "hover_class": "hover:bg-amber-500"},
            {
                "name": "Labware",
                "path": "/material/labware/list/",
                "icon": "labware",
                "hover_class": "hover:bg-amber-500",
            },
            {"name": "Substances", "path": "/substances/", "icon": "substances", "hover_class": "hover:bg-teal-500"},
            {"name": "Organisms", "path": "/organisms/", "icon": "organisms", "hover_class": "hover:bg-lime-500"},
            {"name": "People", "path": "/people/", "icon": "people", "hover_class": "hover:bg-blue-500"},
        ]
    )


@dataclass
class BreadcrumbMenu:
    menu_items: list[dict] = field(
        default_factory=lambda: [
            {"name": "Home", "path": "/", "icon": "home", "hover_class": "hover:bg-gray-100 text-underline"},
            {
                "name": "Project1",
                "path": "/projects/",
                "icon": "folder",
                "hover_class": "hover:bg-gray-100 text-underline",
            },
        ]
    )

    def update_paths(self, path_map: dict):
        """
        Update the 'path' of menu_items based on a path_map dictionary.

        path_map should be a dict where keys are menu item names and values are new paths.
        """
        for item in self.menu_items:
            if item["name"] in path_map:
                item["path"] = path_map[item["name"]]

        return self


class SubstanceTemplateSettingsMixin:
    """Mixin to provide common template settings for project views."""

    def get_context_data(self, **kwargs):  # noqa: D102
        context = super().get_context_data(**kwargs)
        projects = Project.objects.exclude(parent=None)
        context["projects"] = projects
        context["projects_latest"] = projects.order_by("-datetime_last_modified")  # projects_latest
        context["menu_items"] = SubstancesMenu().menu_items
        context["app_color"] = LaraDjangoSubstancesConfig.lara_app_color
        context["sidebar_menu_items"] = SidebarMenu().menu_items
        # context["sparql_server_url"] = f"http://{settings.VIRTUOSO_HOST}:{settings.VIRTUOSO_ADMIN_PORT}/sparql/"

        return context

    def get_substances_table_context(self, request, page_size=25):
        """Get context for rendering the substances table with pagination and filtering.

        This helper method centralizes the logic for building context used by
        HTMX responses that return the substances table.

        Args:
            request: The HTTP request object
            page_size: Number of substances per page (default: 25)

        Returns:
            dict: Context dictionary with all data needed for substances_table.html
        """
        # Get all substances with filtering
        substances = Substance.objects.all()
        substance_filter = SubstanceDjFilter(request.GET, queryset=substances)
        filtered_substances = substance_filter.qs

        # Apply sorting
        sort_by = request.GET.get("sort", "name")
        order = request.GET.get("order", "asc")
        if order == "desc":
            filtered_substances = filtered_substances.order_by(f"-{sort_by}")
        else:
            filtered_substances = filtered_substances.order_by(sort_by)

        # Paginate results
        paginator = Paginator(filtered_substances, page_size)
        page_number = request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        # Build context with mixin's common settings
        context = {
            "page_obj": page_obj,
            "filter": substance_filter,
            "substance_count": filtered_substances.count(),
            "substances_list": page_obj.object_list,
            "title": "Substances - List",
            "menu_items": SubstancesMenu().menu_items,
            "sidebar_menu_items": SidebarMenu().menu_items,
            "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            "current_sort": sort_by,
            "current_order": order,
            "form": SubstanceAddForm(),
        }

        return context


class HTMXResponseMixin:
    """Mixin to handle HTMX responses in Create, Update, and Delete views.

    This mixin provides common HTMX response handling for views that need to
    return partial templates or trigger page updates after successful operations.
    """

    htmx_success_template = None  # Override in subclass
    htmx_trigger_event = "success"

    def get_htmx_success_response(self, request):
        """Return HTMX response after successful operation.

        Override this method in subclasses to customize the response.
        By default, returns an empty response with HX-Trigger header.
        """
        response = HttpResponse(status=200)
        response["HX-Trigger"] = self.htmx_trigger_event
        return response


def show_periodic_table(request):
    return redirect("https://ptable.com/")


# links to pubchem, uniprot, chemspider, chembl, c


def show_substance(request, substance_id):
    substance = get_object_or_404(Substance, pk=substance_id)
    return render(request, "lara_django_substances/substance_detail.html", {"substance": substance})


def show_polymer(request, polymer_id):
    polymer = get_object_or_404(Polymer, pk=polymer_id)
    return render(request, "lara_django_substances/polymer_detail.html", {"polymer": polymer})


def show_mixture(request, mixture_id):
    mixture = get_object_or_404(Mixture, pk=mixture_id)
    return render(request, "lara_django_substances/mixture_detail.html", {"mixture": mixture})


class SubstanceOverviewView(SubstanceTemplateSettingsMixin, ListView):
    """Display substances overview with filtering, sorting, and pagination.

    This class-based view replaces the substance_overview function and provides:
    - GET requests: Display the substances table with filtering and sorting
    - Filtering: Using SubstanceDjFilter for advanced filtering
    - Sorting: By any column, ascending or descending
    - Pagination: 25 substances per page
    - HTMX support: Return different partial templates based on request type
    """

    model = Substance
    template_name = "lara_django_substances/substances_overview.html"
    context_object_name = "substances_list"
    paginate_by = 25

    def get_queryset(self):
        """Get filtered and sorted queryset."""
        queryset = super().get_queryset()

        # Apply filter
        self.filter = SubstanceDjFilter(self.request.GET, queryset=queryset)
        filtered_queryset = self.filter.qs

        # Apply sorting
        sort_by = self.request.GET.get("sort", "name")
        order = self.request.GET.get("order", "asc")

        if order == "desc":
            filtered_queryset = filtered_queryset.order_by(f"-{sort_by}")
        else:
            filtered_queryset = filtered_queryset.order_by(sort_by)

        return filtered_queryset

    def get_context_data(self, **kwargs):
        """Add additional context for the template."""
        context = super().get_context_data(**kwargs)

        # Add filter and sorting info
        context["filter"] = self.filter
        context["substance_count"] = self.filter.qs.count()
        context["title"] = "Substances - List"
        context["current_sort"] = self.request.GET.get("sort", "name")
        context["current_order"] = self.request.GET.get("order", "asc")
        context["form"] = SubstanceAddForm()

        return context

    def render_to_response(self, context, **response_kwargs):
        """Render different templates based on HTMX request type."""
        # For HTMX requests, return partial templates
        if self.request.htmx:
            # If the request has a 'full' parameter, return the full table (for cancel from edit)
            if self.request.GET.get("full"):
                return render(
                    self.request,
                    "lara_django_substances/partials/substances_table.html",
                    context,
                )
            # If sorting or pagination is requested, return the table with header (to update sort indicators)
            if self.request.GET.get("sort") or self.request.GET.get("page"):
                return render(
                    self.request,
                    "lara_django_substances/partials/substances_table_only.html",
                    context,
                )
            # Otherwise, return just the table rows (for filtering without sorting)
            return render(
                self.request,
                "lara_django_substances/partials/substances_table_rows.html",
                context,
            )

        # For regular requests, return the full page
        return super().render_to_response(context, **response_kwargs)


class SubstanceDetailView(DetailView):
    model = Substance

    template_name = "lara_django_substances/substance_detail.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Substance - Details"
        context["update_link"] = "lara_django_substances:substance-update"
        context["menu_items"] = SubstancesMenu().menu_items
        return context


class SubstanceAddView(SubstanceTemplateSettingsMixin, FormView):
    template_name = "lara_django_substances/add_form.html"
    form_class = SubstanceAddForm
    # TODO: add success message https://docs.djangoproject.com/en/4.2/ref/contrib/messages/#django.contrib.messages.views.SuccessMessageMixin
    success_url = "/substances/substance/list"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Substance - Add"
        context["create_link"] = "lara_django_substances:substance-create"
        return context

    def form_valid(self, form):
        if form.cleaned_data["substance_list"] is not None:
            # load substance_list from file

            # get file
            substance_list = str(form.cleaned_data["substance_list"])

            print("####### - substance_list - #######:", substance_list)

            asyncio.run(read_substances(csv_file_name=f"{tempfile.gettempdir()}/lara/substances/" + substance_list))

            self.num_sustances_added = 42

        else:
            print(form.cleaned_data)

        return super().form_valid(form)


class SubstanceCreateView(SubstanceTemplateSettingsMixin, CreateView):
    """Create a new substance with support for both regular and HTMX requests.

    This view replaces the old create_new_substance function with a proper
    class-based view that handles:
    - GET requests: Display the empty form
    - POST requests: Process form submission
    - HTMX requests: Return partial templates with proper headers
    - Regular requests: Use standard redirect on success
    """

    model = Substance
    template_name = "lara_django_substances/partials/substance_create_form.html"
    form_class = SubstanceCreateForm
    success_url = "/substances/substance/overview/"

    def get_context_data(self, **kwargs):
        """Add context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Substance - Create new"
        return context

    def form_valid(self, form):
        """Handle successful form submission.

        For HTMX requests:
        - Save the substance
        - Return the full substances table with pagination and filtering
        - Set HX-Trigger header for JavaScript event handling

        For regular requests:
        - Save the substance
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the substances table with all context
        if self.request.htmx:
            context = self.get_substances_table_context(self.request, page_size=25)
            response = render(
                self.request,
                "lara_django_substances/partials/substances_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())

    def form_invalid(self, form):
        """Handle invalid form submission.

        For HTMX requests:
        - Return the form with errors
        - Set headers to retarget and trigger fail event

        For regular requests:
        - Re-render the form with errors
        """
        if self.request.htmx:
            response = self.render_to_response(self.get_context_data(form=form))
            response["HX-Retarget"] = "#substance-create-form"
            response["HX-Reswap"] = "outerHTML"
            response["HX-Trigger-After-Settle"] = "fail"
            return response

        # For regular requests, use default behavior
        return super().form_invalid(form)


class SubstanceUpdateView(SubstanceTemplateSettingsMixin, UpdateView):
    """Update an existing substance with support for both regular and HTMX requests.

    This view handles:
    - GET requests: Display the populated form
    - POST requests: Process form submission
    - HTMX requests: Return partial templates with proper headers
    - Regular requests: Use standard redirect on success
    """

    model = Substance
    template_name = "lara_django_substances/partials/substance_update_form.html"
    form_class = SubstanceUpdateForm
    success_url = "/substances/substance/overview/"

    def get_context_data(self, **kwargs):
        """Add context data for the template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Substance - Update"
        context["delete_link"] = "lara_django_substances:substance-delete"
        context["substance"] = self.object
        return context

    def get(self, request, *args, **kwargs):
        """Handle GET request to show the form."""
        self.object = self.get_object()
        form = self.get_form()
        context = self.get_context_data(form=form)

        # For HTMX requests, return just the form (not wrapped in table row)
        if request.htmx:
            return render(request, "lara_django_substances/partials/substance_update_form.html", context)

        # For regular requests, return the full page
        return self.render_to_response(context)

    def form_valid(self, form):
        """Handle successful form submission.

        For HTMX requests:
        - Save the substance
        - Return the full substances table with pagination and filtering
        - Uses the mixin's helper method for consistent context

        For regular requests:
        - Save the substance
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the full substances table with all context
        if self.request.htmx:
            context = self.get_substances_table_context(self.request, page_size=5)
            return render(self.request, "lara_django_substances/partials/substances_table.html", context)

        # For regular requests, redirect to success URL
        return HttpResponseRedirect(self.get_success_url())


class SubstanceDeleteView(DeleteView):
    model = Substance

    template_name = "lara_django_substances/delete_form.html"
    success_url = "/substances/substance/list"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Substance - Delete"
        context["delete_link"] = "lara_django_substances:substance-delete"
        return context

    def delete(self, request, *args, **kwargs):
        """Handle DELETE request, with special handling for HTMX."""
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()

        # For HTMX requests, return empty response (row will be removed by hx-swap)
        if request.htmx:
            return HttpResponse(status=200)

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(success_url)


class SubstanceSafetyView(ListView):
    model = Substance
    template_name = "lara_django_substances/safety.html"


def search_substances(request):
    """Search for substances by name or CAS number.

    Parameters
    ----------
    request : HttpRequest
        The HTTP request object containing the search query parameter.

    Returns
    -------
    HttpResponse
        Rendered template with filtered substances matching the search query.
    """
    query = request.GET.get("search", "")

    # use the query to filter substances by name or CAS
    substances_list = Substance.objects.filter(Q(name__icontains=query) | Q(cas__icontains=query)).distinct()
    return render(
        request, "lara_django_substances/partials/substances_table_rows.html", {"substances_list": substances_list}
    )


def get_substance_row(request, pk):
    """Get a single substance row for HTMX requests.

    Parameters
    ----------
    request : HttpRequest
        The HTTP request object.
    pk : UUID
        The primary key of the substance.

    Returns
    -------
    HttpResponse
        Rendered substance row template.
    """
    substance = get_object_or_404(Substance, pk=pk)
    return render(request, "lara_django_substances/partials/substance_row.html", {"substance": substance})


@require_http_methods(["POST"])
def substance_bulk_delete(request):
    """Delete multiple substances at once.

    Parameters
    ----------
    request : HttpRequest
        The HTTP request object containing substance_ids in POST data.

    Returns
    -------
    HttpResponse
        Rendered substances table with remaining substances.
    """
    import json
    
    # Get substance IDs from POST data
    substance_ids = request.POST.get('substance_ids')
    deleted_count = 0
    
    if substance_ids:
        try:
            # Parse JSON array of IDs
            ids = json.loads(substance_ids)
            # Delete substances and track count
            deleted_count, _ = Substance.objects.filter(pk__in=ids).delete()
        except (json.JSONDecodeError, ValueError) as e:
            # Log error for debugging
            print(f"Error parsing substance_ids: {e}")
            pass
    
    # Always return updated table (check for HTMX header)
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        # Get current filter and sorting parameters
        queryset = Substance.objects.all()
        
        # Apply filters
        substance_filter = SubstanceDjFilter(request.GET, queryset=queryset)
        filtered_qs = substance_filter.qs
        
        # Apply sorting
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        substances_list = filtered_qs.order_by(sort_field)
        
        # Paginate
        paginator = Paginator(substances_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'substances_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/substances_table_only.html", context)
    
    return redirect('lara_django_substances:substances-overview')


@require_http_methods(["POST"])
def substance_bulk_duplicate(request):
    """Duplicate multiple substances at once.

    Parameters
    ----------
    request : HttpRequest
        The HTTP request object containing substance_ids in POST data.

    Returns
    -------
    HttpResponse
        Rendered substances table with new duplicated substances.
    """
    import json
    
    # Get substance IDs from POST data
    substance_ids = request.POST.get('substance_ids')
    duplicated_count = 0
    
    if substance_ids:
        try:
            # Parse JSON array of IDs
            ids = json.loads(substance_ids)
            # Duplicate substances
            substances_to_duplicate = Substance.objects.filter(pk__in=ids)
            
            for substance in substances_to_duplicate:
                # Create a copy with modified name
                substance.pk = None  # Reset primary key to create new instance
                substance.name = f"{substance.name} (Copy)"
                substance.save()
                duplicated_count += 1
                
        except (json.JSONDecodeError, ValueError) as e:
            # Log error for debugging
            print(f"Error parsing substance_ids: {e}")
            pass
    
    # Always return updated table (check for HTMX header)
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        # Get current filter and sorting parameters
        queryset = Substance.objects.all()
        
        # Apply filters
        substance_filter = SubstanceDjFilter(request.GET, queryset=queryset)
        filtered_qs = substance_filter.qs
        
        # Apply sorting
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        substances_list = filtered_qs.order_by(sort_field)
        
        # Paginate
        paginator = Paginator(substances_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'substances_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/substances_table_only.html", context)
    
    return redirect('lara_django_substances:substances-overview')


### ================ Polymer Views ================


class PolymerOverviewView(SubstanceTemplateSettingsMixin, ListView):
    """Display polymers overview with filtering, sorting, and pagination.

    This view provides:
    - GET requests: Display the polymers table with filtering and sorting
    - Filtering: Using PolymerFilterSet for advanced filtering
    - Sorting: By any column, ascending or descending
    - Pagination: 25 polymers per page
    - HTMX support: Return different partial templates based on request type
    """

    model = Polymer
    template_name = "lara_django_substances/polymers_overview.html"
    context_object_name = "polymers_list"
    paginate_by = 25

    def get_queryset(self):
        """Get filtered and sorted queryset."""
        queryset = super().get_queryset()

        # Apply filter using PolymerFilterSet
        from .filters import PolymerFilterSet
        self.filter = PolymerFilterSet(self.request.GET, queryset=queryset)
        filtered_queryset = self.filter.qs

        # Apply sorting
        sort_by = self.request.GET.get("sort", "name")
        order = self.request.GET.get("order", "asc")

        if order == "desc":
            filtered_queryset = filtered_queryset.order_by(f"-{sort_by}")
        else:
            filtered_queryset = filtered_queryset.order_by(sort_by)

        return filtered_queryset

    def get_context_data(self, **kwargs):
        """Add additional context for the template."""
        context = super().get_context_data(**kwargs)

        # Add filter and sorting info
        context["filter"] = self.filter
        context["polymer_count"] = self.filter.qs.count()
        context["title"] = "Polymers - List"
        context["section_title"] = "Polymers - List"
        context["current_sort"] = self.request.GET.get("sort", "name")
        context["current_order"] = self.request.GET.get("order", "asc")

        return context

    def render_to_response(self, context, **response_kwargs):
        """Render different templates based on HTMX request type."""
        # For HTMX requests, return partial templates
        if self.request.htmx:
            # If the request has a 'full' parameter, return the full table
            if self.request.GET.get("full"):
                return render(
                    self.request,
                    "lara_django_substances/partials/polymers_table.html",
                    context,
                )
            # If sorting or pagination is requested, return the table with header
            if self.request.GET.get("sort") or self.request.GET.get("page"):
                return render(
                    self.request,
                    "lara_django_substances/partials/polymers_table_only.html",
                    context,
                )
            # Otherwise, return just the table rows (for filtering without sorting)
            return render(
                self.request,
                "lara_django_substances/partials/polymers_table_rows.html",
                context,
            )

        # For regular requests, return the full page
        return super().render_to_response(context, **response_kwargs)


class PolymerDetailView(SubstanceTemplateSettingsMixin, DetailView):
    """Display details of a single polymer."""

    model = Polymer
    template_name = "lara_django_substances/polymer_detail.html"

    def get_context_data(self, **kwargs):
        """Add context for the polymer detail template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Polymer - Details"
        context["update_link"] = "lara_django_substances:polymer-update"
        return context


class PolymerCreateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, CreateView):
    """Create a new polymer with HTMX support.

    - GET: Display empty form
    - POST: Create polymer
    - HTMX: Return polymers table on success
    """

    model = Polymer
    template_name = "lara_django_substances/create_form.html"
    form_class = PolymerCreateForm
    success_url = "/substances/polymer/list"

    def get_context_data(self, **kwargs):
        """Add context for the create form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Polymer - Create"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the polymer
        - Return the full polymers table with pagination and filtering
        - Set HX-Trigger header for JavaScript event handling
        
        For regular requests:
        - Save the polymer
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the polymers table
        if self.request.htmx:
            from .filters import PolymerFilterSet
            
            queryset = Polymer.objects.all()
            polymer_filter = PolymerFilterSet(self.request.GET, queryset=queryset)
            filtered_polymers = polymer_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_polymers = filtered_polymers.order_by(f"-{sort_by}")
            else:
                filtered_polymers = filtered_polymers.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_polymers, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": polymer_filter,
                "polymer_count": filtered_polymers.count(),
                "polymers_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/polymers_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class PolymerUpdateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, UpdateView):
    """Update an existing polymer with HTMX support.

    - GET: Display populated form
    - POST: Update polymer
    - HTMX: Return polymers table on success
    """

    model = Polymer
    template_name = "lara_django_substances/update_form.html"
    form_class = PolymerUpdateForm
    success_url = "/substances/polymer/list"

    def get_context_data(self, **kwargs):
        """Add context for the update form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Polymer - Update"
        context["delete_link"] = "lara_django_substances:polymer-delete"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the polymer
        - Return the full polymers table with pagination and filtering
        
        For regular requests:
        - Save the polymer
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the polymers table
        if self.request.htmx:
            from .filters import PolymerFilterSet
            
            queryset = Polymer.objects.all()
            polymer_filter = PolymerFilterSet(self.request.GET, queryset=queryset)
            filtered_polymers = polymer_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_polymers = filtered_polymers.order_by(f"-{sort_by}")
            else:
                filtered_polymers = filtered_polymers.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_polymers, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": polymer_filter,
                "polymer_count": filtered_polymers.count(),
                "polymers_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/polymers_table.html",
                context,
            )
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class PolymerDeleteView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, DeleteView):
    """Delete a polymer with HTMX support.

    - GET: Display confirmation form
    - POST: Delete polymer
    - HTMX: Trigger page refresh on success
    """

    model = Polymer
    template_name = "lara_django_substances/delete_form.html"
    success_url = "/substances/polymer/list"

    def get_context_data(self, **kwargs):
        """Add context for the delete confirmation template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Polymer - Delete"
        context["delete_link"] = "lara_django_substances:polymer-delete"
        return context

    def delete(self, request, *args, **kwargs):
        """Handle DELETE request with HTMX support."""
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()

        # For HTMX requests, trigger page refresh
        if request.htmx:
            return self.get_htmx_success_response(request)

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(success_url)


@require_http_methods(["POST"])
def polymer_bulk_delete(request):
    """Delete multiple polymers at once."""
    import json
    
    polymer_ids = request.POST.get('polymer_ids')
    deleted_count = 0
    
    if polymer_ids:
        try:
            ids = json.loads(polymer_ids)
            deleted_count, _ = Polymer.objects.filter(pk__in=ids).delete()
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing polymer_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Polymer.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        polymers_list = queryset.order_by(sort_field)
        
        paginator = Paginator(polymers_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'polymers_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/polymers_table_only.html", context)
    
    return redirect('lara_django_substances:polymers-overview')


@require_http_methods(["POST"])
def polymer_bulk_duplicate(request):
    """Duplicate multiple polymers at once."""
    import json
    
    polymer_ids = request.POST.get('polymer_ids')
    duplicated_count = 0
    
    if polymer_ids:
        try:
            ids = json.loads(polymer_ids)
            polymers_to_duplicate = Polymer.objects.filter(pk__in=ids)
            
            for polymer in polymers_to_duplicate:
                polymer.pk = None
                polymer.name = f"{polymer.name} (Copy)"
                polymer.save()
                duplicated_count += 1
                
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing polymer_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Polymer.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        polymers_list = queryset.order_by(sort_field)
        
        paginator = Paginator(polymers_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'polymers_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/polymers_table_only.html", context)
    
    return redirect('lara_django_substances:polymers-overview')


### ================ Mixture Views ================


class MixtureOverviewView(SubstanceTemplateSettingsMixin, ListView):
    """Display mixtures overview with filtering, sorting, and pagination.

    This view provides:
    - GET requests: Display the mixtures table with filtering and sorting
    - Filtering: Using MixtureFilterSet for advanced filtering
    - Sorting: By any column, ascending or descending
    - Pagination: 25 mixtures per page
    - HTMX support: Return different partial templates based on request type
    """

    model = Mixture
    template_name = "lara_django_substances/mixtures_overview.html"
    context_object_name = "mixtures_list"
    paginate_by = 25

    def get_queryset(self):
        """Get filtered and sorted queryset."""
        queryset = super().get_queryset()

        # Apply filter using MixtureFilterSet
        from .filters import MixtureFilterSet
        self.filter = MixtureFilterSet(self.request.GET, queryset=queryset)
        filtered_queryset = self.filter.qs

        # Apply sorting
        sort_by = self.request.GET.get("sort", "name")
        order = self.request.GET.get("order", "asc")

        if order == "desc":
            filtered_queryset = filtered_queryset.order_by(f"-{sort_by}")
        else:
            filtered_queryset = filtered_queryset.order_by(sort_by)

        return filtered_queryset

    def get_context_data(self, **kwargs):
        """Add additional context for the template."""
        context = super().get_context_data(**kwargs)

        # Add filter and sorting info
        context["filter"] = self.filter
        context["mixture_count"] = self.filter.qs.count()
        context["title"] = "Mixtures - List"
        context["section_title"] = "Mixtures - List"
        context["current_sort"] = self.request.GET.get("sort", "name")
        context["current_order"] = self.request.GET.get("order", "asc")

        return context

    def render_to_response(self, context, **response_kwargs):
        """Render different templates based on HTMX request type."""
        # For HTMX requests, return partial templates
        if self.request.htmx:
            # If the request has a 'full' parameter, return the full table
            if self.request.GET.get("full"):
                return render(
                    self.request,
                    "lara_django_substances/partials/mixtures_table.html",
                    context,
                )
            # If sorting or pagination is requested, return the table with header
            if self.request.GET.get("sort") or self.request.GET.get("page"):
                return render(
                    self.request,
                    "lara_django_substances/partials/mixtures_table_only.html",
                    context,
                )
            # Otherwise, return just the table rows (for filtering without sorting)
            return render(
                self.request,
                "lara_django_substances/partials/mixtures_table_rows.html",
                context,
                )

        # For regular requests, return the full page
        return super().render_to_response(context, **response_kwargs)


class MixtureDetailView(SubstanceTemplateSettingsMixin, DetailView):
    """Display details of a single mixture."""

    model = Mixture
    template_name = "lara_django_substances/mixture_detail.html"

    def get_context_data(self, **kwargs):
        """Add context for the mixture detail template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Mixture - Details"
        context["update_link"] = "lara_django_substances:mixture-update"
        return context


class MixtureCreateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, CreateView):
    """Create a new mixture with HTMX support.

    - GET: Display empty form
    - POST: Create mixture
    - HTMX: Return mixtures table on success
    """

    model = Mixture
    template_name = "lara_django_substances/create_form.html"
    form_class = MixtureCreateForm
    success_url = "/substances/mixture/list"

    def get_context_data(self, **kwargs):
        """Add context for the create form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Mixture - Create"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the mixture
        - Return the full mixtures table with pagination and filtering
        - Set HX-Trigger header for JavaScript event handling
        
        For regular requests:
        - Save the mixture
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the mixtures table
        if self.request.htmx:
            from .filters import MixtureFilterSet
            
            queryset = Mixture.objects.all()
            mixture_filter = MixtureFilterSet(self.request.GET, queryset=queryset)
            filtered_mixtures = mixture_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_mixtures = filtered_mixtures.order_by(f"-{sort_by}")
            else:
                filtered_mixtures = filtered_mixtures.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_mixtures, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": mixture_filter,
                "mixture_count": filtered_mixtures.count(),
                "mixtures_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/mixtures_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class MixtureUpdateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, UpdateView):
    """Update an existing mixture with HTMX support.

    - GET: Display populated form
    - POST: Update mixture
    - HTMX: Return mixtures table on success
    """

    model = Mixture
    template_name = "lara_django_substances/update_form.html"
    form_class = MixtureUpdateForm
    success_url = "/substances/mixture/list"

    def get_context_data(self, **kwargs):
        """Add context for the update form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Mixture - Update"
        context["delete_link"] = "lara_django_substances:mixture-delete"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the mixture
        - Return the full mixtures table with pagination and filtering
        
        For regular requests:
        - Save the mixture
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the mixtures table
        if self.request.htmx:
            from .filters import MixtureFilterSet
            
            queryset = Mixture.objects.all()
            mixture_filter = MixtureFilterSet(self.request.GET, queryset=queryset)
            filtered_mixtures = mixture_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_mixtures = filtered_mixtures.order_by(f"-{sort_by}")
            else:
                filtered_mixtures = filtered_mixtures.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_mixtures, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": mixture_filter,
                "mixture_count": filtered_mixtures.count(),
                "mixtures_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/mixtures_table.html",
                context,
            )
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class MixtureDeleteView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, DeleteView):
    """Delete a mixture with HTMX support.

    - GET: Display confirmation form
    - POST: Delete mixture
    - HTMX: Trigger page refresh on success
    """

    model = Mixture
    template_name = "lara_django_substances/delete_form.html"
    success_url = "/substances/mixture/list"

    def get_context_data(self, **kwargs):
        """Add context for the delete confirmation template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Mixture - Delete"
        context["delete_link"] = "lara_django_substances:mixture-delete"
        return context

    def delete(self, request, *args, **kwargs):
        """Handle DELETE request with HTMX support."""
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()

        # For HTMX requests, trigger page refresh
        if request.htmx:
            return self.get_htmx_success_response(request)

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(success_url)


@require_http_methods(["POST"])
def mixture_bulk_delete(request):
    """Delete multiple mixtures at once."""
    import json
    
    mixture_ids = request.POST.get('mixture_ids')
    deleted_count = 0
    
    if mixture_ids:
        try:
            ids = json.loads(mixture_ids)
            deleted_count, _ = Mixture.objects.filter(pk__in=ids).delete()
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing mixture_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Mixture.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        mixtures_list = queryset.order_by(sort_field)
        
        paginator = Paginator(mixtures_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'mixtures_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/mixtures_table_only.html", context)
    
    return redirect('lara_django_substances:mixtures-overview')


@require_http_methods(["POST"])
def mixture_bulk_duplicate(request):
    """Duplicate multiple mixtures at once."""
    import json
    
    mixture_ids = request.POST.get('mixture_ids')
    duplicated_count = 0
    
    if mixture_ids:
        try:
            ids = json.loads(mixture_ids)
            mixtures_to_duplicate = Mixture.objects.filter(pk__in=ids)
            
            for mixture in mixtures_to_duplicate:
                mixture.pk = None
                mixture.name = f"{mixture.name} (Copy)"
                mixture.save()
                duplicated_count += 1
                
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing mixture_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Mixture.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        mixtures_list = queryset.order_by(sort_field)
        
        paginator = Paginator(mixtures_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'mixtures_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/mixtures_table_only.html", context)
    
    return redirect('lara_django_substances:mixtures-overview')


### ================ Isotope Views ================


class IsotopeOverviewView(SubstanceTemplateSettingsMixin, ListView):
    """Display isotopes overview with filtering, sorting, and pagination.

    This view provides:
    - GET requests: Display the isotopes table with filtering and sorting
    - Filtering: Using IsotopeFilterSet for advanced filtering
    - Sorting: By any column, ascending or descending
    - Pagination: 25 isotopes per page
    - HTMX support: Return different partial templates based on request type
    """

    model = Isotope
    template_name = "lara_django_substances/isotopes_overview.html"
    context_object_name = "isotopes_list"
    paginate_by = 25

    def get_queryset(self):
        """Get filtered and sorted queryset."""
        queryset = super().get_queryset()

        # Apply filter using IsotopeFilterSet
        from .filters import IsotopeFilterSet
        self.filter = IsotopeFilterSet(self.request.GET, queryset=queryset)
        filtered_queryset = self.filter.qs

        # Apply sorting
        sort_by = self.request.GET.get("sort", "name")
        order = self.request.GET.get("order", "asc")

        if order == "desc":
            filtered_queryset = filtered_queryset.order_by(f"-{sort_by}")
        else:
            filtered_queryset = filtered_queryset.order_by(sort_by)

        return filtered_queryset

    def get_context_data(self, **kwargs):
        """Add additional context for the template."""
        context = super().get_context_data(**kwargs)

        # Add filter and sorting info
        context["filter"] = self.filter
        context["isotope_count"] = self.filter.qs.count()
        context["title"] = "Isotopes - List"
        context["section_title"] = "Isotopes - List"
        context["current_sort"] = self.request.GET.get("sort", "name")
        context["current_order"] = self.request.GET.get("order", "asc")

        return context

    def render_to_response(self, context, **response_kwargs):
        """Render different templates based on HTMX request type."""
        # For HTMX requests, return partial templates
        if self.request.htmx:
            # If the request has a 'full' parameter, return the full table
            if self.request.GET.get("full"):
                return render(
                    self.request,
                    "lara_django_substances/partials/isotopes_table.html",
                    context,
                )
            # If sorting or pagination is requested, return the table with header
            if self.request.GET.get("sort") or self.request.GET.get("page"):
                return render(
                    self.request,
                    "lara_django_substances/partials/isotopes_table_only.html",
                    context,
                )
            # Otherwise, return just the table rows (for filtering without sorting)
            return render(
                self.request,
                "lara_django_substances/partials/isotopes_table_rows.html",
                context,
            )

        # For regular requests, return the full page
        return super().render_to_response(context, **response_kwargs)


class IsotopeCreateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, CreateView):
    """Create a new isotope with HTMX support.

    - GET: Display empty form
    - POST: Create isotope
    - HTMX: Return isotopes table on success
    """

    model = Isotope
    template_name = "lara_django_substances/partials/isotope_create_form.html"
    form_class = IsotopeCreateForm
    success_url = "/substances/isotope/overview/"

    def get_context_data(self, **kwargs):
        """Add context for the create form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Isotope - Create"
        context["form_action"] = reverse("lara_django_substances:isotope-create")
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the isotope
        - Return the full isotopes table with pagination and filtering
        - Set HX-Trigger header for JavaScript event handling
        
        For regular requests:
        - Save the isotope
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the isotopes table
        if self.request.htmx:
            from .filters import IsotopeFilterSet
            
            queryset = Isotope.objects.all()
            isotope_filter = IsotopeFilterSet(self.request.GET, queryset=queryset)
            filtered_isotopes = isotope_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_isotopes = filtered_isotopes.order_by(f"-{sort_by}")
            else:
                filtered_isotopes = filtered_isotopes.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_isotopes, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": isotope_filter,
                "isotope_count": filtered_isotopes.count(),
                "isotopes_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/isotopes_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())
    
    def form_invalid(self, form):
        """Handle invalid form submission.
        
        For HTMX requests:
        - Return the form with errors
        - Set headers to retarget and trigger fail event
        
        For regular requests:
        - Re-render the form with errors
        """
        if self.request.htmx:
            response = self.render_to_response(self.get_context_data(form=form))
            response["HX-Retarget"] = "#isotope-create-form"
            response["HX-Reswap"] = "outerHTML"
            response["HX-Trigger-After-Settle"] = "fail"
            return response
        
        # For regular requests, use default behavior
        return super().form_invalid(form)


class IsotopeUpdateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, UpdateView):
    """Update an existing isotope with HTMX support.

    - GET: Display populated form
    - POST: Update isotope
    - HTMX: Return isotopes table on success
    """

    model = Isotope
    template_name = "lara_django_substances/partials/isotope_update_form.html"
    form_class = IsotopeUpdateForm
    success_url = "/substances/isotope/overview/"

    def get_context_data(self, **kwargs):
        """Add context for the update form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Isotope - Update"
        context["delete_link"] = "lara_django_substances:isotope-delete"
        context["form_action"] = reverse("lara_django_substances:isotope-update", kwargs={"pk": self.object.pk})
        context["isotope"] = self.object
        return context

    def form_valid(self, form):
        """Handle successful form submission."""
        self.object = form.save()

        # For HTMX requests, return the isotopes table
        if self.request.htmx:
            from .filters import IsotopeFilterSet
            
            queryset = Isotope.objects.all()
            isotope_filter = IsotopeFilterSet(self.request.GET, queryset=queryset)
            filtered_isotopes = isotope_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_isotopes = filtered_isotopes.order_by(f"-{sort_by}")
            else:
                filtered_isotopes = filtered_isotopes.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_isotopes, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": isotope_filter,
                "isotope_count": filtered_isotopes.count(),
                "isotopes_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/isotopes_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class IsotopeDeleteView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, DeleteView):
    """Delete an isotope with HTMX support.

    - GET: Display confirmation form
    - POST: Delete isotope
    - HTMX: Trigger page refresh on success
    """

    model = Isotope
    template_name = "lara_django_substances/delete_form.html"
    success_url = "/substances/substance/overview/"

    def get_context_data(self, **kwargs):
        """Add context for the delete confirmation template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Isotope - Delete"
        context["delete_link"] = "lara_django_substances:isotope-delete"
        return context

    def delete(self, request, *args, **kwargs):
        """Handle DELETE request with HTMX support."""
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()

        # For HTMX requests, trigger page refresh
        if request.htmx:
            return self.get_htmx_success_response(request)

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(success_url)


@require_http_methods(["POST"])
def isotope_bulk_delete(request):
    """Delete multiple isotopes at once."""
    import json
    
    isotope_ids = request.POST.get('isotope_ids')
    deleted_count = 0
    
    if isotope_ids:
        try:
            ids = json.loads(isotope_ids)
            deleted_count, _ = Isotope.objects.filter(pk__in=ids).delete()
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing isotope_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Isotope.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        isotopes_list = queryset.order_by(sort_field)
        
        paginator = Paginator(isotopes_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'isotopes_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/isotopes_table_only.html", context)
    
    return redirect('lara_django_substances:isotopes-overview')


@require_http_methods(["POST"])
def isotope_bulk_duplicate(request):
    """Duplicate multiple isotopes at once."""
    import json
    
    isotope_ids = request.POST.get('isotope_ids')
    duplicated_count = 0
    
    if isotope_ids:
        try:
            ids = json.loads(isotope_ids)
            isotopes_to_duplicate = Isotope.objects.filter(pk__in=ids)
            
            for isotope in isotopes_to_duplicate:
                isotope.pk = None
                isotope.name = f"{isotope.name} (Copy)"
                isotope.save()
                duplicated_count += 1
                
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing isotope_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Isotope.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        isotopes_list = queryset.order_by(sort_field)
        
        paginator = Paginator(isotopes_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'isotopes_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/isotopes_table_only.html", context)
    
    return redirect('lara_django_substances:isotopes-overview')


### ================ Reaction Views ================


class ReactionOverviewView(SubstanceTemplateSettingsMixin, ListView):
    """Display reactions overview with filtering, sorting, and pagination.

    This view provides:
    - GET requests: Display the reactions table with filtering and sorting
    - Filtering: Using ReactionFilterSet for advanced filtering
    - Sorting: By any column, ascending or descending
    - Pagination: 25 reactions per page
    - HTMX support: Return different partial templates based on request type
    """

    model = Reaction
    template_name = "lara_django_substances/reactions_overview.html"
    context_object_name = "reactions_list"
    paginate_by = 25

    def get_queryset(self):
        """Get filtered and sorted queryset."""
        queryset = super().get_queryset()

        # Apply filter using ReactionFilterSet
        from .filters import ReactionFilterSet
        self.filter = ReactionFilterSet(self.request.GET, queryset=queryset)
        filtered_queryset = self.filter.qs

        # Apply sorting
        sort_by = self.request.GET.get("sort", "name")
        order = self.request.GET.get("order", "asc")

        if order == "desc":
            filtered_queryset = filtered_queryset.order_by(f"-{sort_by}")
        else:
            filtered_queryset = filtered_queryset.order_by(sort_by)

        return filtered_queryset

    def get_context_data(self, **kwargs):
        """Add additional context for the template."""
        context = super().get_context_data(**kwargs)

        # Add filter and sorting info
        context["filter"] = self.filter
        context["reaction_count"] = self.filter.qs.count()
        context["title"] = "Reactions - List"
        context["section_title"] = "Reactions - List"
        context["current_sort"] = self.request.GET.get("sort", "name")
        context["current_order"] = self.request.GET.get("order", "asc")

        return context

    def render_to_response(self, context, **response_kwargs):
        """Render different templates based on HTMX request type."""
        # For HTMX requests, return partial templates
        if self.request.htmx:
            # If the request has a 'full' parameter, return the full table
            if self.request.GET.get("full"):
                return render(
                    self.request,
                    "lara_django_substances/partials/reactions_table.html",
                    context,
                )
            # If sorting or pagination is requested, return the table with header
            if self.request.GET.get("sort") or self.request.GET.get("page"):
                return render(
                    self.request,
                    "lara_django_substances/partials/reactions_table_only.html",
                    context,
                )
            # Otherwise, return just the table rows (for filtering without sorting)
            return render(
                self.request,
                "lara_django_substances/partials/reactions_table_rows.html",
                context,
            )

        # For regular requests, return the full page
        return super().render_to_response(context, **response_kwargs)


class ReactionCreateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, CreateView):
    """Create a new reaction with HTMX support.

    - GET: Display empty form
    - POST: Create reaction
    - HTMX: Return reactions table on success
    """

    model = Reaction
    template_name = "lara_django_substances/create_form.html"
    form_class = ReactionCreateForm
    success_url = "/substances/reaction/list/"

    def get_context_data(self, **kwargs):
        """Add context for the create form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Reaction - Create"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the reaction
        - Return the full reactions table with pagination and filtering
        - Set HX-Trigger header for JavaScript event handling
        
        For regular requests:
        - Save the reaction
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the reactions table
        if self.request.htmx:
            from .filters import ReactionFilterSet
            
            queryset = Reaction.objects.all()
            reaction_filter = ReactionFilterSet(self.request.GET, queryset=queryset)
            filtered_reactions = reaction_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_reactions = filtered_reactions.order_by(f"-{sort_by}")
            else:
                filtered_reactions = filtered_reactions.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_reactions, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": reaction_filter,
                "reaction_count": filtered_reactions.count(),
                "reactions_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/reactions_table.html",
                context,
            )
            # Trigger success event for client-side JavaScript
            response["HX-Trigger"] = "success"
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class ReactionUpdateView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, UpdateView):
    """Update an existing reaction with HTMX support.

    - GET: Display populated form
    - POST: Update reaction
    - HTMX: Return reactions table on success
    """

    model = Reaction
    template_name = "lara_django_substances/update_form.html"
    form_class = ReactionUpdateForm
    success_url = "/substances/reaction/list/"

    def get_context_data(self, **kwargs):
        """Add context for the update form template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Reaction - Update"
        context["delete_link"] = "lara_django_substances:reaction-delete"
        return context

    def form_valid(self, form):
        """Handle successful form submission.
        
        For HTMX requests:
        - Save the reaction
        - Return the full reactions table with pagination and filtering
        
        For regular requests:
        - Save the reaction
        - Redirect to success_url
        """
        self.object = form.save()

        # For HTMX requests, return the reactions table
        if self.request.htmx:
            from .filters import ReactionFilterSet
            
            queryset = Reaction.objects.all()
            reaction_filter = ReactionFilterSet(self.request.GET, queryset=queryset)
            filtered_reactions = reaction_filter.qs
            
            # Apply sorting
            sort_by = self.request.GET.get("sort", "name")
            order = self.request.GET.get("order", "asc")
            
            if order == "desc":
                filtered_reactions = filtered_reactions.order_by(f"-{sort_by}")
            else:
                filtered_reactions = filtered_reactions.order_by(sort_by)
            
            # Paginate results
            paginator = Paginator(filtered_reactions, 25)
            page_number = self.request.GET.get("page")
            page_obj = paginator.get_page(page_number)
            
            context = {
                "page_obj": page_obj,
                "filter": reaction_filter,
                "reaction_count": filtered_reactions.count(),
                "reactions_list": page_obj.object_list,
                "current_sort": sort_by,
                "current_order": order,
                "app_color": LaraDjangoSubstancesConfig.lara_app_color,
            }
            
            response = render(
                self.request,
                "lara_django_substances/partials/reactions_table.html",
                context,
            )
            return response

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(self.get_success_url())


class ReactionDeleteView(SubstanceTemplateSettingsMixin, HTMXResponseMixin, DeleteView):
    """Delete a reaction with HTMX support.

    - GET: Display confirmation form
    - POST: Delete reaction
    - HTMX: Trigger page refresh on success
    """

    model = Reaction
    template_name = "lara_django_substances/delete_form.html"
    success_url = "/substances/reaction/list/"

    def get_context_data(self, **kwargs):
        """Add context for the delete confirmation template."""
        context = super().get_context_data(**kwargs)
        context["section_title"] = "Reaction - Delete"
        context["delete_link"] = "lara_django_substances:reaction-delete"
        return context

    def delete(self, request, *args, **kwargs):
        """Handle DELETE request with HTMX support."""
        self.object = self.get_object()
        success_url = self.get_success_url()
        self.object.delete()

        # For HTMX requests, trigger page refresh
        if request.htmx:
            return self.get_htmx_success_response(request)

        # For regular requests, redirect to success_url
        return HttpResponseRedirect(success_url)


@require_http_methods(["POST"])
def reaction_bulk_delete(request):
    """Delete multiple reactions at once."""
    import json
    
    reaction_ids = request.POST.get('reaction_ids')
    deleted_count = 0
    
    if reaction_ids:
        try:
            ids = json.loads(reaction_ids)
            deleted_count, _ = Reaction.objects.filter(pk__in=ids).delete()
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing reaction_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Reaction.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        reactions_list = queryset.order_by(sort_field)
        
        paginator = Paginator(reactions_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'reactions_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/reactions_table_only.html", context)
    
    return redirect('lara_django_substances:reactions-overview')


@require_http_methods(["POST"])
def reaction_bulk_duplicate(request):
    """Duplicate multiple reactions at once."""
    import json
    
    reaction_ids = request.POST.get('reaction_ids')
    duplicated_count = 0
    
    if reaction_ids:
        try:
            ids = json.loads(reaction_ids)
            reactions_to_duplicate = Reaction.objects.filter(pk__in=ids)
            
            for reaction in reactions_to_duplicate:
                reaction.pk = None
                reaction.name = f"{reaction.name} (Copy)"
                reaction.save()
                duplicated_count += 1
                
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Error parsing reaction_ids: {e}")
            pass
    
    is_htmx = request.headers.get('HX-Request') == 'true' or hasattr(request, 'htmx')
    
    if is_htmx:
        queryset = Reaction.objects.all()
        sort_field = request.GET.get('sort', 'name')
        order = request.GET.get('order', 'asc')
        if order == 'desc':
            sort_field = f'-{sort_field}'
        reactions_list = queryset.order_by(sort_field)
        
        paginator = Paginator(reactions_list, 25)
        page_number = request.GET.get('page', 1)
        page_obj = paginator.get_page(page_number)
        
        context = {
            'reactions_list': page_obj.object_list,
            'page_obj': page_obj,
            'current_sort': request.GET.get('sort', 'name'),
            'current_order': order,
            'app_color': LaraDjangoSubstancesConfig.lara_app_color,
        }
        return render(request, "lara_django_substances/partials/reactions_table_only.html", context)
    
    return redirect('lara_django_substances:reactions-overview')


### ------------ old helper functions ---


def browse(request):
    mollist = Substance.objects.all()

    nofmols = len(mollist)
    return render(
        request,
        "lara_django_substances/substance_browse.html",
        {"mollist": mollist, "ofmols": nofmols, "currentpath": "?"},
    )


def molecule(request, idnum):
    # Views for individual molecules
    try:
        offset = int(idnum)
    except ValueError:
        raise Http404()
    mol = get_object_or_404(Molecule, pk=idnum)
    quantity = str(mol.amount) + " " + str(mol.unit)
    return render(
        request,
        "molecule.html",
        {
            "mol": mol,
            "molname": mol.name,
            "smiles": mol.smiles,
            "cas": mol.CAS,
            "altname": mol.altname,
            "molfile": mol.molfile,
            "mw": mol.CMW,
            "chn": mol.CHN,
            "hba": mol.HBA,
            "hbd": mol.HBD,
            "logp": mol.logp,
            "tpsa": mol.tpsa,
            "supp": mol.supplier,
            "suppid": mol.supplierID,
            "storage": mol.storageID,
            "comm": mol.comment,
            "quantity": quantity,
            "added": mol.added,
        },
    )


def search(request):
    error = []
    form = SearchForm(request.GET)
    form.is_valid()
    # Basic form validation as defined in forms.py
    if form.is_valid() == False:
        for item in form.errors:
            error.append(form[item].errors)
        return render(request, "search.html", {"error": error, "form": form})
    moltext = form.cleaned_data["moltext"]
    smilesstring = unicode(form.cleaned_data["smiles"])
    minmw = form.cleaned_data["minmw"]
    maxmw = form.cleaned_data["maxmw"]
    minlogp = form.cleaned_data["minlogp"]
    maxlogp = form.cleaned_data["maxlogp"]
    minhba = form.cleaned_data["minhba"]
    maxhba = form.cleaned_data["maxhba"]
    minhbd = form.cleaned_data["minhbd"]
    maxhbd = form.cleaned_data["maxhbd"]
    mintpsa = form.cleaned_data["mintpsa"]
    maxtpsa = form.cleaned_data["maxtpsa"]
    minfsp3 = form.cleaned_data["minfsp3"]
    maxfsp3 = form.cleaned_data["maxfsp3"]
    chn = form.cleaned_data["chn"]
    name = form.cleaned_data["name"]
    storageid = form.cleaned_data["storageid"]
    supplierid = form.cleaned_data["supplierid"]
    supplier = form.cleaned_data["supplier"]
    cas = form.cleaned_data["cas"]
    molclass = form.cleaned_data["molclass"]
    platebarcode = form.cleaned_data["platebarcode"]
    samplebarcode = form.cleaned_data["samplebarcode"]
    storage = form.cleaned_data["storage"]

    # Handling of mol or smi input
    if moltext:
        moltext = pybel.readstring("mol", str(moltext))
        smiles = moltext.write("smi").split("\t")[0]
        print(smiles)
    elif smilesstring:
        smiles = str(smilesstring)
        print(smiles)

    if "similarity" in request.GET or "substructure" in request.GET:
        try:
            test = pybel.readstring("smi", smiles)
            tanimoto = float(form.cleaned_data["tanimoto"])
        except:
            error.append("Molecule or tanimoto index not valid!")

    if error:
        return render(request, "search.html", {"error": error, "form": form})

    if "similarity" in request.GET and smiles:
        # similartiy search
        mollist = id_search(
            cas, name, storageid, supplierid, supplier, chn, molclass, platebarcode, samplebarcode, storage
        )
        mollist = fast_fp_search(mollist, smiles, tanimoto)
        mollist = properties_search(
            mollist, minmw, maxmw, minlogp, maxlogp, minhba, maxhba, minhbd, maxhbd, mintpsa, maxtpsa, minfsp3, maxfsp3
        )
        paginator = Paginator(mollist, 15)
        page = request.GET.get("page")  # get value of query
        nofmols = len(mollist)
        currentpath = request.get_full_path()
        currentpath = get_page_wo_page(currentpath)
        try:
            mollist = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            mollist = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            mollist = paginator.page(paginator.num_pages)
        return render(
            request,
            "browse.html",
            {"mollist": mollist, "currpage": page, "ofmols": nofmols, "currentpath": currentpath},
        )
    elif "substructure" in request.GET and smiles:
        # substructure search
        smarts = smiles
        mollist = id_search(
            cas, name, storageid, supplierid, supplier, chn, molclass, platebarcode, samplebarcode, storage
        )
        mollist = smarts_search(mollist, smarts)
        mollist = properties_search(
            mollist, minmw, maxmw, minlogp, maxlogp, minhba, maxhba, minhbd, maxhbd, mintpsa, maxtpsa, minfsp3, maxfsp3
        )
        paginator = Paginator(mollist, 15)
        page = request.GET.get("page")  # get value of query
        nofmols = len(mollist)
        currentpath = request.get_full_path()
        currentpath = get_page_wo_page(currentpath)
        try:
            mollist = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            mollist = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            mollist = paginator.page(paginator.num_pages)
        return render(
            request,
            "browse.html",
            {"mollist": mollist, "currpage": page, "ofmols": nofmols, "currentpath": currentpath},
        )
    elif "properties" in request.GET:
        # properties and IDs search
        mollist = id_search(
            cas, name, storageid, supplierid, supplier, chn, molclass, platebarcode, samplebarcode, storage
        )
        if cas == "":
            mollist = properties_search(
                mollist,
                minmw,
                maxmw,
                minlogp,
                maxlogp,
                minhba,
                maxhba,
                minhbd,
                maxhbd,
                mintpsa,
                maxtpsa,
                minfsp3,
                maxfsp3,
            )

        paginator = Paginator(mollist, 15)
        page = request.GET.get("page")  # get value of query
        nofmols = len(mollist)
        currentpath = request.get_full_path()
        currentpath = get_page_wo_page(currentpath)

        try:
            mollist = paginator.page(page)
        except PageNotAnInteger:
            # If page is not an integer, deliver first page.
            mollist = paginator.page(1)
        except EmptyPage:
            # If page is out of range (e.g. 9999), deliver last page of results.
            mollist = paginator.page(paginator.num_pages)
        return render(
            request,
            "browse.html",
            {"mollist": mollist, "currpage": page, "ofmols": nofmols, "currentpath": currentpath},
        )
    else:
        form = SearchForm()
    return render(request, "search.html", {"error": error, "form": form})


def statistics(request):
    logp = []
    mw = []
    hba = []
    hbd = []
    tpsa = []
    names = []
    fsp3 = []
    nrb = []
    complexity = []
    for mol in Molecule.objects.all():
        try:
            float(mol.logp)
            float(mol.CMW)
            float(mol.HBA)
            float(mol.HBD)
            float(mol.tpsa)
            float(mol.fsp3)
            float(mol.nrb)
            float(mol.complexity)
            if mol.CMW <= 800:
                logp.append(mol.logp)
                mw.append(mol.CMW)
                hba.append(mol.HBA)
                hbd.append(mol.HBD)
                tpsa.append(mol.tpsa)
                fsp3.append(mol.fsp3 * 100)
                nrb.append(mol.nrb)
                complexity.append(mol.complexity)
                if mol.name == "":
                    names.append("X")
                else:
                    names.append(mol.name)
        except:
            pass
    logpmw = dumps(zip(logp, mw))
    hbamw = dumps(zip(hba, mw))
    hbdmw = dumps(zip(hbd, mw))
    tpsamw = dumps(zip(tpsa, mw))
    # histograms
    mwhist, mwedge = histogram(mw, bins=range(0, 800, 50))
    mwhist = dumps(zip(array(mwedge[:-1]).tolist(), array(mwhist).tolist()))
    fsp3hist, fsp3edge = histogram(fsp3, bins=20)
    fsp3hist = dumps(zip(array(fsp3edge[:-1]).tolist(), array(fsp3hist).tolist()))
    nrbhist, nrbedge = histogram(nrb, bins=[x + 0.5 for x in range(-1, 26, 1)])
    nrbhist = dumps(zip(array(nrbedge[:-1]).tolist(), array(nrbhist).tolist()))
    complexityhist, complexityedge = histogram(complexity, bins=range(0, 160, 10))
    complexityhist = dumps(zip(array(complexityedge[:-1]).tolist(), array(complexityhist).tolist()))
    logphist, logpedge = histogram(logp, bins=[x + 0.5 for x in range(-10, 10, 1)])
    logphist = dumps(zip(array(logpedge[:-1]).tolist(), array(logphist).tolist()))
    hbahist, hbaedge = histogram(hba, bins=[x + 0.5 for x in range(-1, 21, 1)])
    hbahist = dumps(zip(array(hbaedge[:-1]).tolist(), array(hbahist).tolist()))
    hbdhist, hbdedge = histogram(hbd, bins=[x + 0.5 for x in range(-1, 11, 1)])
    hbdhist = dumps(zip(array(hbdedge[:-1]).tolist(), array(hbdhist).tolist()))
    tpsahist, tpsaedge = histogram(tpsa, bins=range(0, 250, 10))
    tpsahist = dumps(zip(array(tpsaedge[:-1]).tolist(), array(tpsahist).tolist()))
    return render(
        request,
        "statistics.html",
        {
            "logpmw": logpmw,
            "hbamw": hbamw,
            "hbdmw": hbdmw,
            "tpsamw": tpsamw,
            "mwhist": mwhist,
            "fsp3hist": fsp3hist,
            "nrbhist": nrbhist,
            "complexityhist": complexityhist,
            "logphist": logphist,
            "hbahist": hbahist,
            "hbdhist": hbdhist,
            "tpsahist": tpsahist,
        },
    )


def searchForm(request):
    return render(request, "lara_django_substances/search.html", context={})


def search_old(request):
    substance_list = []
    search_string = request.POST["search"]
    try:
        curr_substance = Substance.objects.get(acronym=search_string)
        if curr_substance:
            substance_list.append(curr_substance)
        else:
            curr_substance = Substance.objects.get(name=search_string)
            if curr_substance:
                substance_list.append(curr_substance)

    except ValueError:
        logging.error("Error")
        # ~ return render(request, 'polls/detail.html', {
        # ~ 'question': question,
        # ~ 'error_message': "You didn't select a choice.",
        # ~ })
    else:
        context = {"substance_list": substance_list}
        return render(request, "lara_django_substances/results.html", context)
        # return HttpResponseRedirect(reverse('lara_django_substances:results', args=(lara_device_list,)))


def results(request, substance_list):
    context = {"substance_list": substance_list}
    return render(request, "lara_django_substances/results.html", context)


# ~ class IndexView(ListView) :
# ~ model =  Substance
# ~ template_name = 'lara_django_substances/index.html'

# ~ class DevicesListView(ListView) :
# ~ model = Device
# ~ template_name = 'lara_devices/device_list.html'

# ~ table_caption = "List of all LARA devices"
# ~ context = {'table_caption': table_caption}

# ~ def searchForm(request):
# ~ return render(request, 'lara_devices/search.html', context={} )

# ~ class DeviceDetails(DetailView) :
# ~ model = Device
