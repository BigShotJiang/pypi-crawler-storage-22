from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_substances',
     'imports': ['linkml:types'],
     'name': 'lara_django_substances',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_substances_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_substances',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_substances',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_substances',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_substances',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class Sequence(ConfiguredBaseModel):
    """
    <class 'lara_django_sequences.models.Sequence'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class PhysicalStateMatter(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.PhysicalStateMatter'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    pass


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information,
        e.g. UV-vis, IR, NMR spectra of substances, or substance related properties, like enzymatic substrate spectra / activities ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/extradata_id'} })
    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ExtraData/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ExtraData/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Polymer'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/ExtraData/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ExtraData/description'} })
    url_visualization: Optional[str] = Field(None, description="""Universal Resource Locator - URL to external visualization of the data""", json_schema_extra = { "linkml_meta": {'alias': 'url_visualization',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/url_visualization'} })
    file: Optional[str] = Field(None, description="""rel. path/filename to extra data file, preferable in SciDat format.""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:substances/ExtraData/file'} })
    image: Optional[str] = Field(None, description="""extra substance image, e.g. spectrum-thumbnail, ...""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData/image'} })


class SubstanceClass(ConfiguredBaseModel):
    """
    \" classes for substances, like amino acid, peptide, protein, nucleotide, DNA,... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/SubstanceClass',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    substanceclass_id: Optional[str] = Field(None, description="""SubstanceClass - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'substanceclass_id',
         'domain_of': ['SubstanceClass'],
         'slot_uri': 'lara:substances/SubstanceClass/substanceclass_id'} })
    name: str = Field(..., description="""like amino acid, peptide, protein, nucleotide, DNA""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstanceClass/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/SubstanceClass/iri'} })
    description: Optional[str] = Field(None, description="""description of the substance class""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstanceClass/description'} })


class Isotope(ConfiguredBaseModel):
    """
    \" _Istope - detailed information about all known isotopes_

        :param SubstanceAbstr: _description_
        :type SubstanceAbstr: _type_
        :return: _description_
        :rtype: _type_
        :yield: _description_
        :rtype: _type_
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/Isotope',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    name: Optional[str] = Field(None, description="""most common name of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Isotope/name'} })
    acronym: Optional[str] = Field(None, description="""acronym, e.g. TFA, DMSO, MBA, 160323MBA""", json_schema_extra = { "linkml_meta": {'alias': 'acronym',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/acronym'} })
    synonyms: Optional[str] = Field(None, description="""comma separated list of synonyms, like 'benzene', 'amylalcohol' """, json_schema_extra = { "linkml_meta": {'alias': 'synonyms',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/synonyms'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/iri'} })
    cas: Optional[str] = Field(None, description="""Chemical Abstract """, json_schema_extra = { "linkml_meta": {'alias': 'cas',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/cas'} })
    iupac_name: Optional[str] = Field(None, description="""IUPAC preferred name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/iupac_name'} })
    iupac_name_traditional: Optional[str] = Field(None, description="""IUPAC traditional name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_traditional',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/iupac_name_traditional'} })
    iupac_name_systematic: Optional[str] = Field(None, description="""IUPAC systematic name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_systematic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/iupac_name_systematic'} })
    pubchem_cid: Optional[str] = Field(None, description="""PubChem CID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_cid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/pubchem_cid'} })
    pubchem_sid: Optional[str] = Field(None, description="""PubChem SID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_sid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/pubchem_sid'} })
    pubchem_fingerprint: Optional[str] = Field(None, description=""" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_fingerprint',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/pubchem_fingerprint'} })
    chemspider_id: Optional[str] = Field(None, description="""s. chemspider.com""", json_schema_extra = { "linkml_meta": {'alias': 'chemspider_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/chemspider_id'} })
    beilstein_regnum: Optional[str] = Field(None, description="""Beilstein Registry Number""", json_schema_extra = { "linkml_meta": {'alias': 'beilstein_regnum',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/beilstein_regnum'} })
    ec_num: Optional[str] = Field(None, description="""EC number""", json_schema_extra = { "linkml_meta": {'alias': 'ec_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/ec_num'} })
    mdl_num: Optional[str] = Field(None, description="""MDL number""", json_schema_extra = { "linkml_meta": {'alias': 'mdl_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mdl_num'} })
    mass_exact: Optional[float] = Field(None, description="""The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_exact',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mass_exact'} })
    mass_monoisotopic: Optional[float] = Field(None, description=""" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_monoisotopic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mass_monoisotopic'} })
    mass_molar: Optional[float] = Field(None, description="""Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number""", json_schema_extra = { "linkml_meta": {'alias': 'mass_molar',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mass_molar'} })
    density: Optional[float] = Field(None, description="""density in g /cm3""", json_schema_extra = { "linkml_meta": {'alias': 'density',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/density'} })
    physical_state_matter: Optional[str] = Field(None, description="""physical state of matter at 293 K""", json_schema_extra = { "linkml_meta": {'alias': 'physical_state_matter',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:base/PhysicalStateMatter'} })
    properties: Optional[dict] = Field(None, description="""JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/computed_properties'} })
    sumformula: Optional[str] = Field(None, description="""sum formula of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'sumformula',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/sumformula'} })
    cml: Optional[str] = Field(None, description="""Chemical Markup Language, s. """, json_schema_extra = { "linkml_meta": {'alias': 'cml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/cml'} })
    cdxml: Optional[str] = Field(None, description="""ChemDraw XML""", json_schema_extra = { "linkml_meta": {'alias': 'cdxml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/cdxml'} })
    smiles: Optional[str] = Field(None, description="""SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'smiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/smiles'} })
    isosmiles: Optional[str] = Field(None, description="""isomeric SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'isosmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/isosmiles'} })
    cansmiles: Optional[str] = Field(None, description="""canonical SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'cansmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/cansmiles'} })
    inchi: Optional[str] = Field(None, description="""InChi""", json_schema_extra = { "linkml_meta": {'alias': 'inchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/inchi'} })
    inchikey: Optional[str] = Field(None, description="""InChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'inchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/inchikey'} })
    stdinchi: Optional[str] = Field(None, description="""StdInChi""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/stdinchi'} })
    stdinchikey: Optional[str] = Field(None, description="""StdInChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/stdinchikey'} })
    pdb_id: Optional[str] = Field(None, description="""Protein Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'pdb_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/pdb_id'} })
    icsd_id: Optional[str] = Field(None, description="""Inorganic Crystal Structure Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'icsd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/icsd_id'} })
    cod_id: Optional[str] = Field(None, description="""Crystallography Open Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'cod_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/cod_id'} })
    ccdc_id: Optional[str] = Field(None, description="""Cambridge Crystallographic Data Centre ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'ccdc_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/ccdc_id'} })
    csd_id: Optional[str] = Field(None, description="""Cambridge Structural Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'csd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/csd_id'} })
    structure_info: Optional[dict] = Field(None, description="""JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database""", json_schema_extra = { "linkml_meta": {'alias': 'structure_info',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/structure_info'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL to external structure database,  link to public structure database""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/url'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/pac_id'} })
    url_definition: Optional[str] = Field(None, description="""definition Universal Resource Locator - URL, like wikipedia""", json_schema_extra = { "linkml_meta": {'alias': 'url_definition',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/url_definition'} })
    mol_raw: Optional[str] = Field(None, description="""mol file raw""", json_schema_extra = { "linkml_meta": {'alias': 'mol_raw',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mol_raw'} })
    mol_2d: Optional[str] = Field(None, description="""mdl mol file 2D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_2d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mol_2d'} })
    mol_3d: Optional[str] = Field(None, description="""mdl mol file 3D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_3d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Isotope/mol_3d'} })
    svg: Optional[str] = Field(None, description="""svg image of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/svg'} })
    image: Optional[str] = Field(None, description="""e.g. png image of substance""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/image'} })
    remarks: Optional[str] = Field(None, description="""some remarks to this substance""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Isotope/remarks'} })
    description: Optional[str] = Field(None, description="""description of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Isotope/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Isotope/datetime_last_modified'} })
    isotope_id: Optional[str] = Field(None, description="""Isotope - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'isotope_id',
         'domain_of': ['Isotope'],
         'slot_uri': 'lara:substances/Isotope/isotope_id'} })
    num_protons: Optional[int] = Field(None, description="""number of protons""", json_schema_extra = { "linkml_meta": {'alias': 'num_protons',
         'domain_of': ['Isotope'],
         'slot_uri': 'lara:substances/Isotope/num_protons'} })
    num_neutrons: Optional[int] = Field(None, description="""number of neutrons""", json_schema_extra = { "linkml_meta": {'alias': 'num_neutrons',
         'domain_of': ['Isotope'],
         'slot_uri': 'lara:substances/Isotope/num_neutrons'} })
    electron_config: Optional[str] = Field(None, description="""electron configuration: e.g. 1s2, 2s2 3p3 """, json_schema_extra = { "linkml_meta": {'alias': 'electron_config',
         'domain_of': ['Isotope'],
         'slot_uri': 'lara:substances/Isotope/electron_config'} })
    substance_classes: Optional[List[str]] = Field(None, description="""substance class, e.g. salt, complex, nucleotide""", json_schema_extra = { "linkml_meta": {'alias': 'substance_classes',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/SubstanceClass'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like absorption coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })


class IsotopesSubset(ConfiguredBaseModel):
    """
    \" IsotopesSubset(namespace, name_display, name, entity, group, description, datetime_last_modified, isotopessubset_id) \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/IsotopesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset/datetime_last_modified'} })
    isotopessubset_id: Optional[str] = Field(None, description="""IsotopesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'isotopessubset_id',
         'domain_of': ['IsotopesSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset/isotopessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    isotopes: Optional[List[str]] = Field(None, description="""isotopes of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'isotopes',
         'domain_of': ['IsotopesSubset', 'Container'],
         'slot_uri': 'lara:substances/Isotope'} })


class OrderedIsotopesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between IsotopesSubset and Isotope.
        This class can be used to store the order of isotopes in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedIsotopesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedisotopessubset_id: Optional[str] = Field(None, description="""OrderedIsotopesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedisotopessubset_id',
         'domain_of': ['OrderedIsotopesSubset'],
         'slot_uri': 'lara:substances/OrderedIsotopesSubset/orderedisotopessubset_id'} })
    isotope: str = Field(..., description="""isotope in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'isotope',
         'domain_of': ['OrderedIsotopesSubset'],
         'slot_uri': 'lara:substances/Isotope'} })
    isotopes_subset: str = Field(..., description="""subset of isotopes""", json_schema_extra = { "linkml_meta": {'alias': 'isotopes_subset',
         'domain_of': ['OrderedIsotopesSubset'],
         'slot_uri': 'lara:substances/IsotopesSubset'} })
    order: int = Field(..., description="""order of isotope in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedIsotopesSubset/order'} })


class Substance(ConfiguredBaseModel):
    """
    \" Abstractum of a substance. It can represent an element or a compound (polymers, like DNA, peptides, proteins have their own class).
        analytical data should be addable (like UV-vis, NMR, HPLC, .... )
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/Substance',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    name: Optional[str] = Field(None, description="""most common name of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Substance/name'} })
    acronym: Optional[str] = Field(None, description="""acronym, e.g. TFA, DMSO, MBA, 160323MBA""", json_schema_extra = { "linkml_meta": {'alias': 'acronym',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/acronym'} })
    synonyms: Optional[str] = Field(None, description="""comma separated list of synonyms, like 'benzene', 'amylalcohol' """, json_schema_extra = { "linkml_meta": {'alias': 'synonyms',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/synonyms'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/iri'} })
    cas: Optional[str] = Field(None, description="""Chemical Abstract """, json_schema_extra = { "linkml_meta": {'alias': 'cas',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/cas'} })
    iupac_name: Optional[str] = Field(None, description="""IUPAC preferred name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/iupac_name'} })
    iupac_name_traditional: Optional[str] = Field(None, description="""IUPAC traditional name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_traditional',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/iupac_name_traditional'} })
    iupac_name_systematic: Optional[str] = Field(None, description="""IUPAC systematic name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_systematic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/iupac_name_systematic'} })
    pubchem_cid: Optional[str] = Field(None, description="""PubChem CID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_cid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/pubchem_cid'} })
    pubchem_sid: Optional[str] = Field(None, description="""PubChem SID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_sid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/pubchem_sid'} })
    pubchem_fingerprint: Optional[str] = Field(None, description=""" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_fingerprint',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/pubchem_fingerprint'} })
    chemspider_id: Optional[str] = Field(None, description="""s. chemspider.com""", json_schema_extra = { "linkml_meta": {'alias': 'chemspider_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/chemspider_id'} })
    beilstein_regnum: Optional[str] = Field(None, description="""Beilstein Registry Number""", json_schema_extra = { "linkml_meta": {'alias': 'beilstein_regnum',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/beilstein_regnum'} })
    ec_num: Optional[str] = Field(None, description="""EC number""", json_schema_extra = { "linkml_meta": {'alias': 'ec_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/ec_num'} })
    mdl_num: Optional[str] = Field(None, description="""MDL number""", json_schema_extra = { "linkml_meta": {'alias': 'mdl_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mdl_num'} })
    mass_exact: Optional[float] = Field(None, description="""The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_exact',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mass_exact'} })
    mass_monoisotopic: Optional[float] = Field(None, description=""" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_monoisotopic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mass_monoisotopic'} })
    mass_molar: Optional[float] = Field(None, description="""Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number""", json_schema_extra = { "linkml_meta": {'alias': 'mass_molar',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mass_molar'} })
    density: Optional[float] = Field(None, description="""density in g /cm3""", json_schema_extra = { "linkml_meta": {'alias': 'density',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/density'} })
    physical_state_matter: Optional[str] = Field(None, description="""physical state of matter at 293 K""", json_schema_extra = { "linkml_meta": {'alias': 'physical_state_matter',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:base/PhysicalStateMatter'} })
    properties: Optional[dict] = Field(None, description="""JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/computed_properties'} })
    sumformula: Optional[str] = Field(None, description="""sum formula of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'sumformula',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/sumformula'} })
    cml: Optional[str] = Field(None, description="""Chemical Markup Language, s. """, json_schema_extra = { "linkml_meta": {'alias': 'cml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/cml'} })
    cdxml: Optional[str] = Field(None, description="""ChemDraw XML""", json_schema_extra = { "linkml_meta": {'alias': 'cdxml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/cdxml'} })
    smiles: Optional[str] = Field(None, description="""SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'smiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/smiles'} })
    isosmiles: Optional[str] = Field(None, description="""isomeric SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'isosmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/isosmiles'} })
    cansmiles: Optional[str] = Field(None, description="""canonical SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'cansmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/cansmiles'} })
    inchi: Optional[str] = Field(None, description="""InChi""", json_schema_extra = { "linkml_meta": {'alias': 'inchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/inchi'} })
    inchikey: Optional[str] = Field(None, description="""InChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'inchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/inchikey'} })
    stdinchi: Optional[str] = Field(None, description="""StdInChi""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/stdinchi'} })
    stdinchikey: Optional[str] = Field(None, description="""StdInChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/stdinchikey'} })
    pdb_id: Optional[str] = Field(None, description="""Protein Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'pdb_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/pdb_id'} })
    icsd_id: Optional[str] = Field(None, description="""Inorganic Crystal Structure Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'icsd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/icsd_id'} })
    cod_id: Optional[str] = Field(None, description="""Crystallography Open Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'cod_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/cod_id'} })
    ccdc_id: Optional[str] = Field(None, description="""Cambridge Crystallographic Data Centre ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'ccdc_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/ccdc_id'} })
    csd_id: Optional[str] = Field(None, description="""Cambridge Structural Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'csd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/csd_id'} })
    structure_info: Optional[dict] = Field(None, description="""JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database""", json_schema_extra = { "linkml_meta": {'alias': 'structure_info',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/structure_info'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL to external structure database,  link to public structure database""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/url'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/pac_id'} })
    url_definition: Optional[str] = Field(None, description="""definition Universal Resource Locator - URL, like wikipedia""", json_schema_extra = { "linkml_meta": {'alias': 'url_definition',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/url_definition'} })
    mol_raw: Optional[str] = Field(None, description="""mol file raw""", json_schema_extra = { "linkml_meta": {'alias': 'mol_raw',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mol_raw'} })
    mol_2d: Optional[str] = Field(None, description="""mdl mol file 2D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_2d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mol_2d'} })
    mol_3d: Optional[str] = Field(None, description="""mdl mol file 3D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_3d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Substance/mol_3d'} })
    svg: Optional[str] = Field(None, description="""svg image of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/svg'} })
    image: Optional[str] = Field(None, description="""e.g. png image of substance""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/image'} })
    remarks: Optional[str] = Field(None, description="""some remarks to this substance""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Substance/remarks'} })
    description: Optional[str] = Field(None, description="""description of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Substance/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Substance/datetime_last_modified'} })
    substance_id: Optional[str] = Field(None, description="""Substance - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'substance_id',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/substance_id'} })
    m1_code: Optional[str] = Field(None, description="""monomer one letter code, like 'A', 'T', 'C' """, json_schema_extra = { "linkml_meta": {'alias': 'm1_code',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/m1_code'} })
    m3_code: Optional[str] = Field(None, description="""monomer three letter code, like 'Gly' """, json_schema_extra = { "linkml_meta": {'alias': 'm3_code',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/m3_code'} })
    m5_code: Optional[str] = Field(None, description="""monomer five letter code""", json_schema_extra = { "linkml_meta": {'alias': 'm5_code',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/m5_code'} })
    logp: Optional[float] = Field(None, description="""experimental log of octanol/water partition coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'logp',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Substance/logp'} })
    alogp: Optional[float] = Field(None, description="""calculated log of octanol/water partition coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'alogp',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/alogp'} })
    xlogp: Optional[float] = Field(None, description="""calculated log of octanol/water partition coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'xlogp',
         'domain_of': ['Substance'],
         'slot_uri': 'lara:substances/Substance/xlogp'} })
    melting_point: Optional[float] = Field(None, description="""in deg K""", json_schema_extra = { "linkml_meta": {'alias': 'melting_point',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Substance/melting_point'} })
    boiling_point: Optional[float] = Field(None, description="""in deg K""", json_schema_extra = { "linkml_meta": {'alias': 'boiling_point',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Substance/boiling_point'} })
    substance_classes: Optional[List[str]] = Field(None, description="""substance class, e.g. salt, complex, nucleotide""", json_schema_extra = { "linkml_meta": {'alias': 'substance_classes',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/SubstanceClass'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like absorption coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })


class SubstancesSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of substances \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/SubstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset/datetime_last_modified'} })
    substancessubset_id: Optional[str] = Field(None, description="""SubstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'substancessubset_id',
         'domain_of': ['SubstancesSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset/substancessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    substances: Optional[List[str]] = Field(None, description="""substances of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'substances',
         'domain_of': ['SubstancesSubset', 'Container'],
         'slot_uri': 'lara:substances/Substance'} })


class OrderedSubstancesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between SubstancesSubset and Substance.
        This class can be used to store the order of substances in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedSubstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedsubstancessubset_id: Optional[str] = Field(None, description="""OrderedSubstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedsubstancessubset_id',
         'domain_of': ['OrderedSubstancesSubset'],
         'slot_uri': 'lara:substances/OrderedSubstancesSubset/orderedsubstancessubset_id'} })
    substance: str = Field(..., description="""substance in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'substance',
         'domain_of': ['OrderedSubstancesSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Substance'} })
    substances_subset: str = Field(..., description="""subset of substances""", json_schema_extra = { "linkml_meta": {'alias': 'substances_subset',
         'domain_of': ['OrderedSubstancesSubset'],
         'slot_uri': 'lara:substances/SubstancesSubset'} })
    order: int = Field(..., description="""order of substance in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedSubstancesSubset/order'} })


class Polymer(ConfiguredBaseModel):
    """
    \" __Defined polymers (no mixtures)__
        The polymer class defines how the sequence data is to be interpreted
        DNA_FASTA, DNA_FASTAQ, DNA_GeneBank,
        e.g. DNA1L, RNA1L, Protein1L, Protein3L
        for sequences add expression host and original organism
        units are the same as in substance
        analytical data should be addable (like UV-vis, NMR, HPLC, .... )
        todo: taxanomic info could be added as separate model / app
              host_organism ? could be added to extra data

        !!! mind that many polymers (e.g, PE, PP, PET are mixtures)
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/Polymer',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    name: Optional[str] = Field(None, description="""most common name of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Polymer/name'} })
    acronym: Optional[str] = Field(None, description="""acronym, e.g. TFA, DMSO, MBA, 160323MBA""", json_schema_extra = { "linkml_meta": {'alias': 'acronym',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/acronym'} })
    synonyms: Optional[str] = Field(None, description="""comma separated list of synonyms, like 'benzene', 'amylalcohol' """, json_schema_extra = { "linkml_meta": {'alias': 'synonyms',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/synonyms'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/iri'} })
    cas: Optional[str] = Field(None, description="""Chemical Abstract """, json_schema_extra = { "linkml_meta": {'alias': 'cas',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/cas'} })
    iupac_name: Optional[str] = Field(None, description="""IUPAC preferred name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/iupac_name'} })
    iupac_name_traditional: Optional[str] = Field(None, description="""IUPAC traditional name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_traditional',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/iupac_name_traditional'} })
    iupac_name_systematic: Optional[str] = Field(None, description="""IUPAC systematic name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_systematic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/iupac_name_systematic'} })
    pubchem_cid: Optional[str] = Field(None, description="""PubChem CID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_cid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/pubchem_cid'} })
    pubchem_sid: Optional[str] = Field(None, description="""PubChem SID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_sid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/pubchem_sid'} })
    pubchem_fingerprint: Optional[str] = Field(None, description=""" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_fingerprint',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/pubchem_fingerprint'} })
    chemspider_id: Optional[str] = Field(None, description="""s. chemspider.com""", json_schema_extra = { "linkml_meta": {'alias': 'chemspider_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/chemspider_id'} })
    beilstein_regnum: Optional[str] = Field(None, description="""Beilstein Registry Number""", json_schema_extra = { "linkml_meta": {'alias': 'beilstein_regnum',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/beilstein_regnum'} })
    ec_num: Optional[str] = Field(None, description="""EC number""", json_schema_extra = { "linkml_meta": {'alias': 'ec_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/ec_num'} })
    mdl_num: Optional[str] = Field(None, description="""MDL number""", json_schema_extra = { "linkml_meta": {'alias': 'mdl_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mdl_num'} })
    mass_exact: Optional[float] = Field(None, description="""The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_exact',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mass_exact'} })
    mass_monoisotopic: Optional[float] = Field(None, description=""" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_monoisotopic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mass_monoisotopic'} })
    mass_molar: Optional[float] = Field(None, description="""Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number""", json_schema_extra = { "linkml_meta": {'alias': 'mass_molar',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mass_molar'} })
    density: Optional[float] = Field(None, description="""density in g /cm3""", json_schema_extra = { "linkml_meta": {'alias': 'density',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/density'} })
    physical_state_matter: Optional[str] = Field(None, description="""physical state of matter at 293 K""", json_schema_extra = { "linkml_meta": {'alias': 'physical_state_matter',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:base/PhysicalStateMatter'} })
    properties: Optional[dict] = Field(None, description="""JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/computed_properties'} })
    sumformula: Optional[str] = Field(None, description="""sum formula of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'sumformula',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/sumformula'} })
    cml: Optional[str] = Field(None, description="""Chemical Markup Language, s. """, json_schema_extra = { "linkml_meta": {'alias': 'cml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/cml'} })
    cdxml: Optional[str] = Field(None, description="""ChemDraw XML""", json_schema_extra = { "linkml_meta": {'alias': 'cdxml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/cdxml'} })
    smiles: Optional[str] = Field(None, description="""SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'smiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/smiles'} })
    isosmiles: Optional[str] = Field(None, description="""isomeric SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'isosmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/isosmiles'} })
    cansmiles: Optional[str] = Field(None, description="""canonical SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'cansmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/cansmiles'} })
    inchi: Optional[str] = Field(None, description="""InChi""", json_schema_extra = { "linkml_meta": {'alias': 'inchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/inchi'} })
    inchikey: Optional[str] = Field(None, description="""InChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'inchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/inchikey'} })
    stdinchi: Optional[str] = Field(None, description="""StdInChi""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/stdinchi'} })
    stdinchikey: Optional[str] = Field(None, description="""StdInChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/stdinchikey'} })
    pdb_id: Optional[str] = Field(None, description="""Protein Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'pdb_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/pdb_id'} })
    icsd_id: Optional[str] = Field(None, description="""Inorganic Crystal Structure Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'icsd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/icsd_id'} })
    cod_id: Optional[str] = Field(None, description="""Crystallography Open Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'cod_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/cod_id'} })
    ccdc_id: Optional[str] = Field(None, description="""Cambridge Crystallographic Data Centre ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'ccdc_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/ccdc_id'} })
    csd_id: Optional[str] = Field(None, description="""Cambridge Structural Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'csd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/csd_id'} })
    structure_info: Optional[dict] = Field(None, description="""JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database""", json_schema_extra = { "linkml_meta": {'alias': 'structure_info',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/structure_info'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL to external structure database,  link to public structure database""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/url'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/pac_id'} })
    url_definition: Optional[str] = Field(None, description="""definition Universal Resource Locator - URL, like wikipedia""", json_schema_extra = { "linkml_meta": {'alias': 'url_definition',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/url_definition'} })
    mol_raw: Optional[str] = Field(None, description="""mol file raw""", json_schema_extra = { "linkml_meta": {'alias': 'mol_raw',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mol_raw'} })
    mol_2d: Optional[str] = Field(None, description="""mdl mol file 2D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_2d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mol_2d'} })
    mol_3d: Optional[str] = Field(None, description="""mdl mol file 3D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_3d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Polymer/mol_3d'} })
    svg: Optional[str] = Field(None, description="""svg image of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/svg'} })
    image: Optional[str] = Field(None, description="""e.g. png image of substance""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/image'} })
    remarks: Optional[str] = Field(None, description="""some remarks to this substance""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Polymer/remarks'} })
    description: Optional[str] = Field(None, description="""description of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Polymer/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Polymer/datetime_last_modified'} })
    polymer_id: Optional[str] = Field(None, description="""Polymer - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'polymer_id',
         'domain_of': ['Polymer'],
         'slot_uri': 'lara:substances/Polymer/polymer_id'} })
    sequence: Optional[str] = Field(None, description="""sequence of the polymer""", json_schema_extra = { "linkml_meta": {'alias': 'sequence',
         'domain_of': ['Polymer', 'MultiStepReaction'],
         'slot_uri': 'lara:sequences/Sequence'} })
    uniprot_ac: Optional[str] = Field(None, description="""UniProt Accession Number""", json_schema_extra = { "linkml_meta": {'alias': 'uniprot_ac',
         'domain_of': ['Polymer'],
         'slot_uri': 'lara:substances/Polymer/uniprot_ac'} })
    uniprot_id: Optional[str] = Field(None, description="""UniProtKB/Swiss-Prot/TrEMBL entry name / ID""", json_schema_extra = { "linkml_meta": {'alias': 'uniprot_id',
         'domain_of': ['Polymer'],
         'slot_uri': 'lara:substances/Polymer/uniprot_id'} })
    genebank_id: Optional[str] = Field(None, description="""GeneBank ID""", json_schema_extra = { "linkml_meta": {'alias': 'genebank_id',
         'domain_of': ['Polymer'],
         'slot_uri': 'lara:substances/Polymer/genebank_id'} })
    melting_point: Optional[float] = Field(None, description="""in deg K""", json_schema_extra = { "linkml_meta": {'alias': 'melting_point',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Polymer/melting_point'} })
    boiling_point: Optional[float] = Field(None, description="""in deg K""", json_schema_extra = { "linkml_meta": {'alias': 'boiling_point',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Polymer/boiling_point'} })
    logp: Optional[float] = Field(None, description="""experimental log of octanol/water partition coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'logp',
         'domain_of': ['Substance', 'Polymer'],
         'slot_uri': 'lara:substances/Polymer/logp'} })
    media_type: Optional[str] = Field(None, description="""file type of sequence data (file)""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData', 'Polymer'],
         'slot_uri': 'lara:base/MediaType'} })
    sequence_file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'sequence_file',
         'domain_of': ['Polymer'],
         'slot_uri': 'lara:substances/Polymer/sequence_file'} })
    substance_classes: Optional[List[str]] = Field(None, description="""substance class, e.g. salt, complex, nucleotide""", json_schema_extra = { "linkml_meta": {'alias': 'substance_classes',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/SubstanceClass'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like absorption coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })


class PolymersSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of polymers \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/PolymersSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/PolymersSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/PolymersSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/PolymersSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/PolymersSubset/datetime_last_modified'} })
    polymerssubset_id: Optional[str] = Field(None, description="""PolymersSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'polymerssubset_id',
         'domain_of': ['PolymersSubset'],
         'slot_uri': 'lara:substances/PolymersSubset/polymerssubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    polymers: Optional[List[str]] = Field(None, description="""polymers of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'polymers',
         'domain_of': ['PolymersSubset', 'Container'],
         'slot_uri': 'lara:substances/Polymer'} })


class OrderedPolymersSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between PolymersSubset and Polymer.
        This class can be used to store the order of polymers in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedPolymersSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedpolymerssubset_id: Optional[str] = Field(None, description="""OrderedPolymersSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedpolymerssubset_id',
         'domain_of': ['OrderedPolymersSubset'],
         'slot_uri': 'lara:substances/OrderedPolymersSubset/orderedpolymerssubset_id'} })
    polymer: str = Field(..., description="""polymer in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'polymer',
         'domain_of': ['OrderedPolymersSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Polymer'} })
    polymers_subset: str = Field(..., description="""subset of polymers""", json_schema_extra = { "linkml_meta": {'alias': 'polymers_subset',
         'domain_of': ['OrderedPolymersSubset'],
         'slot_uri': 'lara:substances/PolymersSubset'} })
    order: int = Field(..., description="""order of polymer in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedPolymersSubset/order'} })


class MixtureComponent(ConfiguredBaseModel):
    """
    \" Single component of a mixture \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/MixtureComponent',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    mixturecomponent_id: Optional[str] = Field(None, description="""MixtureComponent - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'mixturecomponent_id',
         'domain_of': ['MixtureComponent'],
         'slot_uri': 'lara:substances/MixtureComponent/mixturecomponent_id'} })
    name: str = Field(..., description="""name of mixture component""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixtureComponent/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MixtureComponent/iri'} })
    substance: Optional[str] = Field(None, description="""ID of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'substance',
         'domain_of': ['OrderedSubstancesSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Substance'} })
    polymer: Optional[str] = Field(None, description="""ID of the polymer""", json_schema_extra = { "linkml_meta": {'alias': 'polymer',
         'domain_of': ['OrderedPolymersSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Polymer'} })
    concentration: Optional[float] = Field(None, description="""component (not final !) concentration in mol/l (in mixtures)""", json_schema_extra = { "linkml_meta": {'alias': 'concentration',
         'domain_of': ['MixtureComponent'],
         'slot_uri': 'lara:substances/MixtureComponent/concentration'} })
    concentration_weight: Optional[float] = Field(None, description="""component (not final !) concentration in kg/l (in mixtures)""", json_schema_extra = { "linkml_meta": {'alias': 'concentration_weight',
         'domain_of': ['MixtureComponent'],
         'slot_uri': 'lara:substances/MixtureComponent/concentration_weight'} })
    description: Optional[str] = Field(None, description="""description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixtureComponent/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixtureComponent/datetime_last_modified'} })


class Mixture(ConfiguredBaseModel):
    """
    \" An (abstract) mixture is a set of (abstract) substances or (abstract) polymers, e.g. a buffer, a medium, 
        an assay composition. Analytical data should be addable (like UV-vis, NMR, HPLC, .... )
        acronyms: PBS, LB, ....
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/Mixture',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    name: Optional[str] = Field(None, description="""most common name of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Mixture/name'} })
    acronym: Optional[str] = Field(None, description="""acronym, e.g. TFA, DMSO, MBA, 160323MBA""", json_schema_extra = { "linkml_meta": {'alias': 'acronym',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/acronym'} })
    synonyms: Optional[str] = Field(None, description="""comma separated list of synonyms, like 'benzene', 'amylalcohol' """, json_schema_extra = { "linkml_meta": {'alias': 'synonyms',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/synonyms'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/iri'} })
    cas: Optional[str] = Field(None, description="""Chemical Abstract """, json_schema_extra = { "linkml_meta": {'alias': 'cas',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/cas'} })
    iupac_name: Optional[str] = Field(None, description="""IUPAC preferred name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/iupac_name'} })
    iupac_name_traditional: Optional[str] = Field(None, description="""IUPAC traditional name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_traditional',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/iupac_name_traditional'} })
    iupac_name_systematic: Optional[str] = Field(None, description="""IUPAC systematic name""", json_schema_extra = { "linkml_meta": {'alias': 'iupac_name_systematic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/iupac_name_systematic'} })
    pubchem_cid: Optional[str] = Field(None, description="""PubChem CID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_cid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/pubchem_cid'} })
    pubchem_sid: Optional[str] = Field(None, description="""PubChem SID""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_sid',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/pubchem_sid'} })
    pubchem_fingerprint: Optional[str] = Field(None, description=""" s. ftp://ftp.ncbi.nlm.nih.gov/pubchem/specifications/pubchem_fingerprints.txt""", json_schema_extra = { "linkml_meta": {'alias': 'pubchem_fingerprint',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/pubchem_fingerprint'} })
    chemspider_id: Optional[str] = Field(None, description="""s. chemspider.com""", json_schema_extra = { "linkml_meta": {'alias': 'chemspider_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/chemspider_id'} })
    beilstein_regnum: Optional[str] = Field(None, description="""Beilstein Registry Number""", json_schema_extra = { "linkml_meta": {'alias': 'beilstein_regnum',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/beilstein_regnum'} })
    ec_num: Optional[str] = Field(None, description="""EC number""", json_schema_extra = { "linkml_meta": {'alias': 'ec_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/ec_num'} })
    mdl_num: Optional[str] = Field(None, description="""MDL number""", json_schema_extra = { "linkml_meta": {'alias': 'mdl_num',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mdl_num'} })
    mass_exact: Optional[float] = Field(None, description="""The calculated mass of an ion or a molecule containing most likely isotopic composition for a single random molecule, corresponding to mass of most intense mol/molecule peak in a MS spec. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_exact',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mass_exact'} })
    mass_monoisotopic: Optional[float] = Field(None, description=""" Mass of a molecule calculated using the mass of the most abundant isotope of each element. E.g., Carbon has a monoisotopic mass of 12.000 g/mol. A real number.""", json_schema_extra = { "linkml_meta": {'alias': 'mass_monoisotopic',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mass_monoisotopic'} })
    mass_molar: Optional[float] = Field(None, description="""Molar Mass of a molecule calculated using the average mass of each element weighted for its natural isotopic abundance. E.g., Carbon has two natural isotopes 12 and 13 with relative abundances of 98.9% and 1.1% to yield an average mass of 12.011 g/mol. A real number""", json_schema_extra = { "linkml_meta": {'alias': 'mass_molar',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mass_molar'} })
    density: Optional[float] = Field(None, description="""density in g /cm3""", json_schema_extra = { "linkml_meta": {'alias': 'density',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/density'} })
    properties: Optional[dict] = Field(None, description="""JSON object, containing physical and chemical properties and further classifications, like, e.g. ECC numbers""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/computed_properties'} })
    sumformula: Optional[str] = Field(None, description="""sum formula of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'sumformula',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/sumformula'} })
    cml: Optional[str] = Field(None, description="""Chemical Markup Language, s. """, json_schema_extra = { "linkml_meta": {'alias': 'cml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/cml'} })
    cdxml: Optional[str] = Field(None, description="""ChemDraw XML""", json_schema_extra = { "linkml_meta": {'alias': 'cdxml',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/cdxml'} })
    smiles: Optional[str] = Field(None, description="""SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'smiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/smiles'} })
    isosmiles: Optional[str] = Field(None, description="""isomeric SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'isosmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/isosmiles'} })
    cansmiles: Optional[str] = Field(None, description="""canonical SMILES""", json_schema_extra = { "linkml_meta": {'alias': 'cansmiles',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/cansmiles'} })
    inchi: Optional[str] = Field(None, description="""InChi""", json_schema_extra = { "linkml_meta": {'alias': 'inchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/inchi'} })
    inchikey: Optional[str] = Field(None, description="""InChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'inchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/inchikey'} })
    stdinchi: Optional[str] = Field(None, description="""StdInChi""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchi',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/stdinchi'} })
    stdinchikey: Optional[str] = Field(None, description="""StdInChiKey""", json_schema_extra = { "linkml_meta": {'alias': 'stdinchikey',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/stdinchikey'} })
    pdb_id: Optional[str] = Field(None, description="""Protein Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'pdb_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/pdb_id'} })
    icsd_id: Optional[str] = Field(None, description="""Inorganic Crystal Structure Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'icsd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/icsd_id'} })
    cod_id: Optional[str] = Field(None, description="""Crystallography Open Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'cod_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/cod_id'} })
    ccdc_id: Optional[str] = Field(None, description="""Cambridge Crystallographic Data Centre ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'ccdc_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/ccdc_id'} })
    csd_id: Optional[str] = Field(None, description="""Cambridge Structural Database ID / Code""", json_schema_extra = { "linkml_meta": {'alias': 'csd_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/csd_id'} })
    structure_info: Optional[dict] = Field(None, description="""JSON object, containing references to structural information, like, e.g. links to 3D structures, databases, ..., and the LARA-structure database""", json_schema_extra = { "linkml_meta": {'alias': 'structure_info',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/structure_info'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL to external structure database,  link to public structure database""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/url'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/pac_id'} })
    url_definition: Optional[str] = Field(None, description="""definition Universal Resource Locator - URL, like wikipedia""", json_schema_extra = { "linkml_meta": {'alias': 'url_definition',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/url_definition'} })
    mol_raw: Optional[str] = Field(None, description="""mol file raw""", json_schema_extra = { "linkml_meta": {'alias': 'mol_raw',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mol_raw'} })
    mol_2d: Optional[str] = Field(None, description="""mdl mol file 2D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_2d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mol_2d'} })
    mol_3d: Optional[str] = Field(None, description="""mdl mol file 3D""", json_schema_extra = { "linkml_meta": {'alias': 'mol_3d',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/Mixture/mol_3d'} })
    svg: Optional[str] = Field(None, description="""svg image of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/svg'} })
    image: Optional[str] = Field(None, description="""e.g. png image of substance""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/image'} })
    remarks: Optional[str] = Field(None, description="""some remarks to this substance""", json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Mixture/remarks'} })
    description: Optional[str] = Field(None, description="""description of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Mixture/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Mixture/datetime_last_modified'} })
    mixture_id: Optional[str] = Field(None, description="""Mixture - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'mixture_id',
         'domain_of': ['Mixture'],
         'slot_uri': 'lara:substances/Mixture/mixture_id'} })
    physical_state_matter: Optional[str] = Field(None, description="""physical state of matter at 293 K""", json_schema_extra = { "linkml_meta": {'alias': 'physical_state_matter',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:base/PhysicalStateMatter'} })
    minchi: Optional[str] = Field(None, description="""MInChi - Mixtures InChi""", json_schema_extra = { "linkml_meta": {'alias': 'minchi',
         'domain_of': ['Mixture'],
         'slot_uri': 'lara:substances/Mixture/minchi'} })
    substance_classes: Optional[List[str]] = Field(None, description="""substance class, e.g. salt, complex, nucleotide""", json_schema_extra = { "linkml_meta": {'alias': 'substance_classes',
         'domain_of': ['Isotope', 'Substance', 'Polymer', 'Mixture'],
         'slot_uri': 'lara:substances/SubstanceClass'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like absorption coefficient""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    components: Optional[List[str]] = Field(None, description="""components of the mixture""", json_schema_extra = { "linkml_meta": {'alias': 'components',
         'domain_of': ['Mixture', 'Reaction'],
         'slot_uri': 'lara:substances/MixtureComponent'} })


class MixturesSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of mixtures \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/MixturesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixturesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixturesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixturesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MixturesSubset/datetime_last_modified'} })
    mixturessubset_id: Optional[str] = Field(None, description="""MixturesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'mixturessubset_id',
         'domain_of': ['MixturesSubset'],
         'slot_uri': 'lara:substances/MixturesSubset/mixturessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    mixtures: Optional[List[str]] = Field(None, description="""mixtures of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'mixtures',
         'domain_of': ['MixturesSubset', 'Container'],
         'slot_uri': 'lara:substances/Mixture'} })


class OrderedMixturesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between MixturesSubset and Mixture.
        This class can be used to store the order of mixtures in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedMixturesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedmixturessubset_id: Optional[str] = Field(None, description="""OrderedMixturesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedmixturessubset_id',
         'domain_of': ['OrderedMixturesSubset'],
         'slot_uri': 'lara:substances/OrderedMixturesSubset/orderedmixturessubset_id'} })
    mixture: str = Field(..., description="""mixture in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'mixture',
         'domain_of': ['OrderedMixturesSubset', 'ReactionComponent'],
         'slot_uri': 'lara:substances/Mixture'} })
    mixtures_subset: str = Field(..., description="""subset of mixtures""", json_schema_extra = { "linkml_meta": {'alias': 'mixtures_subset',
         'domain_of': ['OrderedMixturesSubset'],
         'slot_uri': 'lara:substances/MixturesSubset'} })
    order: int = Field(..., description="""order of mixture in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedMixturesSubset/order'} })


class MoleculeResidue(ConfiguredBaseModel):
    """
    \" Residues of a molecule \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/MoleculeResidue',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    moleculeresidue_id: Optional[str] = Field(None, description="""MoleculeResidue - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'moleculeresidue_id',
         'domain_of': ['MoleculeResidue'],
         'slot_uri': 'lara:substances/MoleculeResidue/moleculeresidue_id'} })
    name: Optional[str] = Field(None, description="""name of the residue""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MoleculeResidue/name'} })
    substructure: Optional[dict] = Field(None, description="""substructure of the residue""", json_schema_extra = { "linkml_meta": {'alias': 'substructure',
         'domain_of': ['MoleculeResidue'],
         'slot_uri': 'lara:substances/MoleculeResidue/substructure'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MoleculeResidue/iri'} })
    description: Optional[str] = Field(None, description="""description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MoleculeResidue/description'} })


class ReactionComponent(ConfiguredBaseModel):
    """
    \" A Reaction Component is an (abstract) representation of a substance or mixture
           with a role, an order and a stoichiometric factor.
           They are specific for a certain reaction.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/ReactionComponent',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    reactioncomponent_id: Optional[str] = Field(None, description="""ReactionComponent - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'reactioncomponent_id',
         'domain_of': ['ReactionComponent'],
         'slot_uri': 'lara:substances/ReactionComponent/reactioncomponent_id'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ReactionComponent/iri'} })
    name: Optional[str] = Field(None, description="""name of the reaction component""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionComponent/name'} })
    substance: Optional[str] = Field(None, description="""ID of the substance""", json_schema_extra = { "linkml_meta": {'alias': 'substance',
         'domain_of': ['OrderedSubstancesSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Substance'} })
    polymer: Optional[str] = Field(None, description="""ID of the polymer""", json_schema_extra = { "linkml_meta": {'alias': 'polymer',
         'domain_of': ['OrderedPolymersSubset',
                       'MixtureComponent',
                       'ReactionComponent'],
         'slot_uri': 'lara:substances/Polymer'} })
    mixture: Optional[str] = Field(None, description="""ID of the mixture""", json_schema_extra = { "linkml_meta": {'alias': 'mixture',
         'domain_of': ['OrderedMixturesSubset', 'ReactionComponent'],
         'slot_uri': 'lara:substances/Mixture'} })
    order: Optional[int] = Field(None, description="""order in the reaction, in case order of this component plays a role""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionComponent/order'} })
    stoichiometric_factor: Optional[float] = Field(None, description="""stoichiometric_factor: neg: starting material, pos: product""", json_schema_extra = { "linkml_meta": {'alias': 'stoichiometric_factor',
         'domain_of': ['ReactionComponent'],
         'slot_uri': 'lara:substances/ReactionComponent/stoichiometric_factor'} })
    physical_state: Optional[str] = Field(None, description="""e.g. solid, liquid, gas, plasma at reaction conditions""", json_schema_extra = { "linkml_meta": {'alias': 'physical_state',
         'domain_of': ['ReactionComponent'],
         'slot_uri': 'lara:base/PhysicalStateMatter'} })
    properties: Optional[dict] = Field(None, description="""JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge, ...""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ReactionComponent/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ReactionComponent/computed_properties'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionComponent/datetime_last_modified'} })
    roles: Optional[List[str]] = Field(None, description="""Roles of the Reaction Compontent, like product, solvent, catalyst, co-factor. A component can have mulitple roles.""", json_schema_extra = { "linkml_meta": {'alias': 'roles',
         'domain_of': ['ReactionComponent'],
         'slot_uri': 'lara:substances/SubstanceClass'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })


class ReactionComponentsSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of reaction components \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/ReactantionComponentsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset/datetime_last_modified'} })
    reactioncomponentssubset_id: Optional[str] = Field(None, description="""ReactionComponentsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'reactioncomponentssubset_id',
         'domain_of': ['ReactionComponentsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset/reactioncomponentssubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    reaction_components: Optional[List[str]] = Field(None, description="""reaction components of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reaction_components',
         'domain_of': ['ReactionComponentsSubset'],
         'slot_uri': 'lara:substances/ReactionComponent'} })


class OrderedReactionComponentsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ReactantsSubset and Reactant.
        This class can be used to store the order of reaction_components in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedReactionComponentsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedreactioncomponentssubset_id: Optional[str] = Field(None, description="""OrderedReactionComponentsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedreactioncomponentssubset_id',
         'domain_of': ['OrderedReactionComponentsSubset'],
         'slot_uri': 'lara:substances/OrderedReactionComponentsSubset/orderedreactioncomponentssubset_id'} })
    reaction_component: str = Field(..., description="""reaction components in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reaction_component',
         'domain_of': ['OrderedReactionComponentsSubset'],
         'slot_uri': 'lara:substances/ReactionComponent'} })
    reaction_components_subset: str = Field(..., description="""subset of reaction components""", json_schema_extra = { "linkml_meta": {'alias': 'reaction_components_subset',
         'domain_of': ['OrderedReactionComponentsSubset'],
         'slot_uri': 'lara:substances/ReactantionComponentsSubset'} })
    order: int = Field(..., description="""order of reaction component in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedReactionComponentsSubset/order'} })


class Reaction(ConfiguredBaseModel):
    """
    \" Abstractum of a Chemical reaction with components, conditions and properties.

        Instances of (real) reactions should be modeled as Experiments - in conjuction with ReactionInstances- with procedures, devices, preparation steps, etc.
        TODO: side reactions, branched reactions
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/Reaction',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    reaction_id: Optional[str] = Field(None, description="""Reaction - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'reaction_id',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/reaction_id'} })
    name: Optional[str] = Field(None, description="""reaction name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Reaction/name'} })
    label: Optional[str] = Field(None, description="""(short) label / acronym""", json_schema_extra = { "linkml_meta": {'alias': 'label',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/label'} })
    rx_uuid: Optional[str] = Field(None, description="""reaction UUID""", json_schema_extra = { "linkml_meta": {'alias': 'rx_uuid',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/rx_uuid'} })
    properties: Optional[dict] = Field(None, description="""properties of the reaction, like reaction class(es), equilibrium constant, speed, order of kinetics, enthalpy, entropy, etc., specified by the reactions_properties model""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/properties'} })
    parameters: Optional[dict] = Field(None, description="""reaction parameters / conditions, like stoichiometry, temperature, durations, pressure, pH, ..., specified by the reactions_parameters model""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Reaction', 'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/parameters'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/computed_properties'} })
    rinchi: Optional[str] = Field(None, description="""RInChi string""", json_schema_extra = { "linkml_meta": {'alias': 'rinchi',
         'domain_of': ['Reaction', 'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/rinchi'} })
    rinchi_key_short: Optional[str] = Field(None, description="""short RInChiKey key, s. link""", json_schema_extra = { "linkml_meta": {'alias': 'rinchi_key_short',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/rinchi_key_short'} })
    rinchi_key_long: Optional[str] = Field(None, description="""long RInChiKey key""", json_schema_extra = { "linkml_meta": {'alias': 'rinchi_key_long',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/rinchi_key_long'} })
    rinchi_web_key: Optional[str] = Field(None, description="""RInChiKey web key""", json_schema_extra = { "linkml_meta": {'alias': 'rinchi_web_key',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/rinchi_web_key'} })
    rxno: Optional[str] = Field(None, description="""rxno""", json_schema_extra = { "linkml_meta": {'alias': 'rxno',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/rxno'} })
    equilibrium_const: Optional[float] = Field(None, description="""literature value of the equilibrium constant""", json_schema_extra = { "linkml_meta": {'alias': 'equilibrium_const',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/equilibrium_const'} })
    deltag: Optional[float] = Field(None, description="""literature value of the free energy""", json_schema_extra = { "linkml_meta": {'alias': 'deltag',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/deltag'} })
    order: Optional[int] = Field(None, description="""order of the reaction in a set of multi-step reactions, in case order plays a role. It does not describe the kinetics""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Reaction/order'} })
    safety_info: Optional[dict] = Field(None, description="""reaction safety information in human and machine readable form, including safety symbols in svg.""", json_schema_extra = { "linkml_meta": {'alias': 'safety_info',
         'domain_of': ['Reaction'],
         'slot_uri': 'lara:substances/Reaction/safety_info'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Reaction/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/remarks'} })
    svg: Optional[str] = Field(None, description="""svg image of the reaction""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/svg'} })
    image: Optional[str] = Field(None, description="""rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/image'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/Reaction/iri'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/Reaction/datetime_last_modified'} })
    components: Optional[List[str]] = Field(None, description="""all components of the reaction, also solvents, catalysts, ...""", json_schema_extra = { "linkml_meta": {'alias': 'components',
         'domain_of': ['Mixture', 'Reaction'],
         'slot_uri': 'lara:substances/ReactionComponent'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like kinetic models, spectra, chromatograms, reaction schemes, ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })


class ReactionsSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of reactions \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/ReactionsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset/datetime_last_modified'} })
    reactionssubset_id: Optional[str] = Field(None, description="""ReactionsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'reactionssubset_id',
         'domain_of': ['ReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset/reactionssubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    reactions: Optional[List[str]] = Field(None, description="""reactions of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reactions',
         'domain_of': ['ReactionsSubset', 'MultiStepReaction', 'Container'],
         'slot_uri': 'lara:substances/Reaction'} })


class OrderedReactionsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ReactionsSubset and Reaction.
        This class can be used to store the order of reactions in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedReactionsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedreactionssubset_id: Optional[str] = Field(None, description="""OrderedReactionsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedreactionssubset_id',
         'domain_of': ['OrderedReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedReactionsSubset/orderedreactionssubset_id'} })
    reaction: str = Field(..., description="""reaction in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reaction',
         'domain_of': ['OrderedReactionsSubset'],
         'slot_uri': 'lara:substances/Reaction'} })
    reactions_subset: str = Field(..., description="""subset of reactions""", json_schema_extra = { "linkml_meta": {'alias': 'reactions_subset',
         'domain_of': ['OrderedReactionsSubset'],
         'slot_uri': 'lara:substances/ReactionsSubset'} })
    order: int = Field(..., description="""order of reaction in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedReactionsSubset/order'} })


class MultiStepReaction(ConfiguredBaseModel):
    """
    \" Multi-step chemical reaction, like a multi step synthesis,
        an enzymatic/biochemical pathway or enzymatic cascade reaction
        TODO: branched reactions / side reactions
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/MultiStepReaction',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    multistepreaction_id: Optional[str] = Field(None, description="""MultiStepReaction - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'multistepreaction_id',
         'domain_of': ['MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/multistepreaction_id'} })
    name: Optional[str] = Field(None, description="""reaction name""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReaction/name'} })
    sequence: Optional[dict] = Field(None, description="""sequence of sequential and parallel reactions, like, e.g. ['rx1', 'rx2', ['rx3', 'rx4']]""", json_schema_extra = { "linkml_meta": {'alias': 'sequence',
         'domain_of': ['Polymer', 'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/sequence'} })
    properties: Optional[dict] = Field(None, description="""properties of the reaction, like reaction class(es), equilibrium constant, speed, order of kinetics, enthalpy, entropy, etc., specified by the reactions_properties model""", json_schema_extra = { "linkml_meta": {'alias': 'properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/properties'} })
    computed_properties: Optional[dict] = Field(None, description="""computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...""", json_schema_extra = { "linkml_meta": {'alias': 'computed_properties',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/computed_properties'} })
    parameters: Optional[dict] = Field(None, description="""reaction parameters / conditions, like stoichiometry, durations, temperature, pressure, pH, ..., specified by the reactions_parameters model""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Reaction', 'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/parameters'} })
    svg: Optional[str] = Field(None, description="""svg image of the reaction scheme.""", json_schema_extra = { "linkml_meta": {'alias': 'svg',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/svg'} })
    image: Optional[str] = Field(None, description="""rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/image'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'Substance',
                       'Polymer',
                       'MixtureComponent',
                       'Mixture',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/iri'} })
    rinchi: Optional[str] = Field(None, description="""Reactions InChi string""", json_schema_extra = { "linkml_meta": {'alias': 'rinchi',
         'domain_of': ['Reaction', 'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/rinchi'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReaction/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/MultiStepReaction/remarks'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReaction/datetime_last_modified'} })
    reactions: Optional[List[str]] = Field(None, description="""all involved reactions""", json_schema_extra = { "linkml_meta": {'alias': 'reactions',
         'domain_of': ['ReactionsSubset', 'MultiStepReaction', 'Container'],
         'slot_uri': 'lara:substances/Reaction'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'ReactionComponent',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:base/ExternalResource'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data, like kinetic models, spectra, chromatograms, reaction schemes, ...""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Isotope',
                       'Substance',
                       'Polymer',
                       'Mixture',
                       'Reaction',
                       'MultiStepReaction'],
         'slot_uri': 'lara:substances/ExtraData'} })


class MultiStepReactionsSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of multi-step reactions \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/MultiStepReactionsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['IsotopesSubset',
                       'SubstancesSubset',
                       'PolymersSubset',
                       'MixturesSubset',
                       'ReactionComponentsSubset',
                       'ReactionsSubset',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'SubstanceClass',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'MoleculeResidue',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'MixtureComponent',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset/datetime_last_modified'} })
    multistepreactionssubset_id: Optional[str] = Field(None, description="""MultiStepReactionsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'multistepreactionssubset_id',
         'domain_of': ['MultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset/multistepreactionssubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Isotope',
                       'IsotopesSubset',
                       'Substance',
                       'SubstancesSubset',
                       'Polymer',
                       'PolymersSubset',
                       'Mixture',
                       'MixturesSubset',
                       'ReactionComponent',
                       'ReactionComponentsSubset',
                       'Reaction',
                       'ReactionsSubset',
                       'MultiStepReaction',
                       'MultiStepReactionsSubset'],
         'slot_uri': 'lara:base/Tag'} })
    reactions_multistep: Optional[List[str]] = Field(None, description="""multi-step reactions of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reactions_multistep',
         'domain_of': ['MultiStepReactionsSubset', 'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReaction'} })


class OrderedMultiStepReactionsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between MultiStepReactionsSubset and MultiStepReaction.
        This class can be used to store the order of multi-step reactions in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:substances/OrderedMultiStepReactionsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_substances'})

    orderedmultistepreactionssubset_id: Optional[str] = Field(None, description="""OrderedMultiStepReactionsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedmultistepreactionssubset_id',
         'domain_of': ['OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedMultiStepReactionsSubset/orderedmultistepreactionssubset_id'} })
    reactions_multistep: str = Field(..., description="""multi-step reaction in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'reactions_multistep',
         'domain_of': ['MultiStepReactionsSubset', 'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReaction'} })
    multistepreactions_subset: str = Field(..., description="""subset of multi-step reactions""", json_schema_extra = { "linkml_meta": {'alias': 'multistepreactions_subset',
         'domain_of': ['OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/MultiStepReactionsSubset'} })
    order: int = Field(..., description="""order of multi-step reaction in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedIsotopesSubset',
                       'OrderedSubstancesSubset',
                       'OrderedPolymersSubset',
                       'OrderedMixturesSubset',
                       'ReactionComponent',
                       'OrderedReactionComponentsSubset',
                       'Reaction',
                       'OrderedReactionsSubset',
                       'OrderedMultiStepReactionsSubset'],
         'slot_uri': 'lara:substances/OrderedMultiStepReactionsSubset/order'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_substances',
         'tree_root': True})

    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    substanceclasss: Optional[List[SubstanceClass]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'substanceclasss', 'domain_of': ['Container']} })
    isotopes: Optional[List[Isotope]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'isotopes', 'domain_of': ['IsotopesSubset', 'Container']} })
    isotopessubsets: Optional[List[IsotopesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'isotopessubsets', 'domain_of': ['Container']} })
    orderedisotopessubsets: Optional[List[OrderedIsotopesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedisotopessubsets', 'domain_of': ['Container']} })
    substances: Optional[List[Substance]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'substances', 'domain_of': ['SubstancesSubset', 'Container']} })
    substancessubsets: Optional[List[SubstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'substancessubsets', 'domain_of': ['Container']} })
    orderedsubstancessubsets: Optional[List[OrderedSubstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedsubstancessubsets', 'domain_of': ['Container']} })
    polymers: Optional[List[Polymer]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'polymers', 'domain_of': ['PolymersSubset', 'Container']} })
    polymerssubsets: Optional[List[PolymersSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'polymerssubsets', 'domain_of': ['Container']} })
    orderedpolymerssubsets: Optional[List[OrderedPolymersSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedpolymerssubsets', 'domain_of': ['Container']} })
    mixturecomponents: Optional[List[MixtureComponent]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'mixturecomponents', 'domain_of': ['Container']} })
    mixtures: Optional[List[Mixture]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'mixtures', 'domain_of': ['MixturesSubset', 'Container']} })
    mixturessubsets: Optional[List[MixturesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'mixturessubsets', 'domain_of': ['Container']} })
    orderedmixturessubsets: Optional[List[OrderedMixturesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedmixturessubsets', 'domain_of': ['Container']} })
    moleculeresidues: Optional[List[MoleculeResidue]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'moleculeresidues', 'domain_of': ['Container']} })
    reactioncomponents: Optional[List[ReactionComponent]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'reactioncomponents', 'domain_of': ['Container']} })
    reactioncomponentssubsets: Optional[List[ReactionComponentsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'reactioncomponentssubsets', 'domain_of': ['Container']} })
    orderedreactioncomponentssubsets: Optional[List[OrderedReactionComponentsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedreactioncomponentssubsets', 'domain_of': ['Container']} })
    reactions: Optional[List[Reaction]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'reactions',
         'domain_of': ['ReactionsSubset', 'MultiStepReaction', 'Container']} })
    reactionssubsets: Optional[List[ReactionsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'reactionssubsets', 'domain_of': ['Container']} })
    orderedreactionssubsets: Optional[List[OrderedReactionsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedreactionssubsets', 'domain_of': ['Container']} })
    multistepreactions: Optional[List[MultiStepReaction]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'multistepreactions', 'domain_of': ['Container']} })
    multistepreactionssubsets: Optional[List[MultiStepReactionsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'multistepreactionssubsets', 'domain_of': ['Container']} })
    orderedmultistepreactionssubsets: Optional[List[OrderedMultiStepReactionsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedmultistepreactionssubsets', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
Namespace.model_rebuild()
Entity.model_rebuild()
DataType.model_rebuild()
Sequence.model_rebuild()
Tag.model_rebuild()
Group.model_rebuild()
MediaType.model_rebuild()
ExternalResource.model_rebuild()
PhysicalStateMatter.model_rebuild()
ExtraData.model_rebuild()
SubstanceClass.model_rebuild()
Isotope.model_rebuild()
IsotopesSubset.model_rebuild()
OrderedIsotopesSubset.model_rebuild()
Substance.model_rebuild()
SubstancesSubset.model_rebuild()
OrderedSubstancesSubset.model_rebuild()
Polymer.model_rebuild()
PolymersSubset.model_rebuild()
OrderedPolymersSubset.model_rebuild()
MixtureComponent.model_rebuild()
Mixture.model_rebuild()
MixturesSubset.model_rebuild()
OrderedMixturesSubset.model_rebuild()
MoleculeResidue.model_rebuild()
ReactionComponent.model_rebuild()
ReactionComponentsSubset.model_rebuild()
OrderedReactionComponentsSubset.model_rebuild()
Reaction.model_rebuild()
ReactionsSubset.model_rebuild()
OrderedReactionsSubset.model_rebuild()
MultiStepReaction.model_rebuild()
MultiStepReactionsSubset.model_rebuild()
OrderedMultiStepReactionsSubset.model_rebuild()
Container.model_rebuild()

