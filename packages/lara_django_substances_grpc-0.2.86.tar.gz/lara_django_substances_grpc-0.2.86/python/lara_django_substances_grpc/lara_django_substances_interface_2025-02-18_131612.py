"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances high_level_interface *

:details: lara_django_substances high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_substances
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_substances_grpc.v1.lara_django_substances_pb2 as lara_django_substances_pb2
import lara_django_substances_grpc.v1.lara_django_substances_pb2_grpc as lara_django_substances_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_substances_grpc.lara_django_substances_data_model as substances_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_substances_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_substances_pb2_grpc.ExtraDataControllerStub(channel)

        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_upload_chunk = lara_django_substances_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


        # self.extradata_full_client = lara_django_substances_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[substances_dm.ExtraData] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_substances_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if self._default_namespace_id is not None:
                if extradata.namespace == "" or extradata.namespace == "default":
                    extradata.namespace = self._default_namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_substances_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, extradata_name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and extradata_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_substances_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if extradata_name_display is not None:
        #     filter_list.append({"name_display": extradata_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          extradata_name: str = None,
                          extradata_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given extradata_name,
               extradata_name_display or iri
        """
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_display is not None:
            filter_dict = {"name_display": extradata_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")
        if len(results) == 1 :
            return results[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None) -> substances_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_substances_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            return substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, extradata_name: str = None,
                                namespace_uri : str = None) -> substances_dm.ExtraData:
        """ retrieve a extradata data model by extradata_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.ExtraDataRetrieveByNameNSRequest(name=extradata_name, namespace_uri=namespace_uri)
            )
            return substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving extradata_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_substances_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_substances_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_substances_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : substances_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            await self.extradata_client.Update(
                lara_django_substances_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_substances_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  SubstanceClass  ______________________


class SubstanceClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.substanceclass_client = lara_django_substances_pb2_grpc.SubstanceClassControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substanceclasses:  list[substances_dm.SubstanceClass] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.SubstanceClass]]:
        try:
            create_coroutines = ( self.substanceclass_client.Create(lara_django_substances_pb2.SubstanceClassRequest(**substanceclass.model_dump())) for substanceclass in substanceclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substanceclass: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        substanceclass_id: str = None,
        substanceclass_name: str = None,
        #substanceclass_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.SubstanceClass]:
        """ retrieve a list of substanceclass instances by substanceclass_id, substanceclass_name or filter_dict,
               returns a list of substanceclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  substanceclass_id is not None:
            try:
                res =  await self.substanceclass_client.Retrieve(
                    lara_django_substances_pb2.SubstanceClassRetrieveRequest(substanceclass_id=substanceclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substanceclass_id: {e}")

        if substanceclass_name is not None:
            filter_list.append({"name": substanceclass_name})
        # if substanceclass_name_display is not None:
        #     filter_list.append({"name_display": substanceclass_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceclass_client.List(
                        lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving substanceclass_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          substanceclass_name: str = None,
                          substanceclass_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the substanceclass_id for a given substanceclass_name,
               substanceclass_name_display or iri
        """
        if substanceclass_name is not None:
            filter_dict = {"name": substanceclass_name}
        elif substanceclass_name_display is not None:
            filter_dict = {"name_display": substanceclass_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substanceclass_client.List(
                lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving substanceclass_name: {e}")
        if len(results) == 1 :
            return results[0].substanceclass_id
        else:
            raise ValueError(f"Error retrieving substanceclass_id - no or too many results found.")

    async def get_by_id(self, substanceclass_id: str = None) -> substances_dm.SubstanceClass:
        """ retrieve a substanceclass data model by substanceclass_id """
        try:
            res = await self.substanceclass_client.Retrieve(
                lara_django_substances_pb2.SubstanceClassRetrieveRequest(substanceclass_id=substanceclass_id)
            )
            return substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substanceclass_id: {e}")

    async def get_by_name(self, substanceclass_name: str = None) -> substances_dm.SubstanceClass:
        """ retrieve a substanceclass data model by substanceclass_name """
        try:
            res = await self.substanceclass_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.SubstanceClassRetrieveByNameNSRequest(name=substanceclass_name, namespace_uri="")
            )
            return substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substanceclass_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substanceclasss """
        if filter_dict is None:
            res = await self.substanceclass_client.List(lara_django_substances_pb2.SubstanceClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceclass_client.List(
                lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substanceclasss """
        if self.substanceclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceclass_full_client.List(
                lara_django_substances_pb2.SubstanceClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceclass_full_client.List(
                lara_django_substances_pb2.SubstanceClassFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substanceclass : substances_dm.SubstanceClass = None) -> None:
        """ update a substanceclass model instance """
        try:
            await self.substanceclass_client.Update(
                lara_django_substances_pb2.SubstanceClassRequest(**substanceclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substanceclass_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substanceclass by substanceclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substanceclass_client.Destroy(lara_django_substances_pb2.SubstanceClassDestroyRequest(substanceclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substanceclass_id: {e}")

#_________________  Isotope  ______________________


class IsotopeInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.isotope_client = lara_django_substances_pb2_grpc.IsotopeControllerStub(channel)

        self.update_item_id = "isotope_id"
        self.stub = self.isotope_client

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  isotopes:  list[substances_dm.Isotope] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Isotope]]:
        try:
            create_coroutines = ( self.isotope_client.Create(lara_django_substances_pb2.IsotopeRequest(**isotope.model_dump())) for isotope in isotopes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.isotope_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating isotope: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        isotope_id: str = None,
        isotope_name: str = None,
        #isotope_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Isotope]:
        """ retrieve a list of isotope instances by isotope_id, isotope_name or filter_dict,
               returns a list of isotope data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  isotope_id is not None:
            try:
                res =  await self.isotope_client.Retrieve(
                    lara_django_substances_pb2.IsotopeRetrieveRequest(isotope_id=isotope_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving isotope_id: {e}")

        if isotope_name is not None:
            filter_list.append({"name": isotope_name})
        # if isotope_name_display is not None:
        #     filter_list.append({"name_display": isotope_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotope_client.List(
                        lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving isotope_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          isotope_name: str = None,
                          isotope_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the isotope_id for a given isotope_name,
               isotope_name_display or iri
        """
        if isotope_name is not None:
            filter_dict = {"name": isotope_name}
        elif isotope_name_display is not None:
            filter_dict = {"name_display": isotope_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.isotope_client.List(
                lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving isotope_name: {e}")
        if len(results) == 1 :
            return results[0].isotope_id
        else:
            raise ValueError(f"Error retrieving isotope_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, isotope_id: str = None) -> substances_dm.Isotope:
        """ retrieve a isotope data model by isotope_id """
        try:
            res = await self.isotope_client.Retrieve(
                lara_django_substances_pb2.IsotopeRetrieveRequest(isotope_id=isotope_id)
            )
            return substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving isotope_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, isotope_name: str = None) -> substances_dm.Isotope:
        """ retrieve a isotope data model by isotope_name """
        try:
            res = await self.isotope_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.IsotopeRetrieveByNameNSRequest(name=isotope_name, namespace_uri="")
            )
            return substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving isotope_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all isotopes """
        if filter_dict is None:
            res = await self.isotope_client.List(lara_django_substances_pb2.IsotopeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.isotope_client.List(
                lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.isotope_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all isotopes """
        if self.isotope_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.isotope_full_client.List(
                lara_django_substances_pb2.IsotopeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.isotope_full_client.List(
                lara_django_substances_pb2.IsotopeFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, isotope : substances_dm.Isotope = None) -> None:
        """ update a isotope model instance """
        try:
            await self.isotope_client.Update(
                lara_django_substances_pb2.IsotopeRequest(**isotope.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating isotope_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a isotope by isotope_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.isotope_client.Destroy(lara_django_substances_pb2.IsotopeDestroyRequest(isotope_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting isotope_id: {e}")

#_________________  IsotopesSubset  ______________________


class IsotopesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.isotopessubset_class_client = (
        #     lara_django_substances_pb2_grpc.IsotopesSubsetclassByIRIControllerStub(channel)
        # )

        self.isotopessubset_client = lara_django_substances_pb2_grpc.IsotopesSubsetControllerStub(channel)


        # self.isotopessubset_full_client = lara_django_substances_pb2_grpc.IsotopesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  isotopessubsets:  list[substances_dm.IsotopesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.IsotopesSubset]]:
        """ create a list of isotopessubset instances,
               returns a list of isotopessubset data model objects or ids_only

        :param isotopessubsets: list of isotopessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of isotopessubset data model objects or ids_only
        """
        isotopessubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if isotopessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.isotopessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.IsotopesSubsetclassRetrieveRequest(iri=isotopessubset_class_iri)
        #     )
        #     isotopessubsetclass_id = res.isotopessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving isotopessubsetclass_id: {e}")
        for isotopessubset in isotopessubsets:
            if self._default_namespace_id is not None:
                if isotopessubset.namespace == "" or isotopessubset.namespace == "default":
                    isotopessubset.namespace = self._default_namespace_id
            # isotopessubset.isotopessubset_class = isotopessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.isotopessubset_client.Create(lara_django_substances_pb2.IsotopesSubsetRequest(**isotopessubset.model_dump())) for isotopessubset in isotopessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.isotopessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating isotopessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        isotopessubset_id: str = None,
        isotopessubset_name: str = None,
        #isotopessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.IsotopesSubset]:
        """ retrieve a list of isotopessubset instances by isotopessubset_id, isotopessubset_name or filter_dict,
               returns a list of isotopessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and isotopessubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  isotopessubset_id is not None:
            try:
                res =  await self.isotopessubset_client.Retrieve(
                    lara_django_substances_pb2.IsotopesSubsetRetrieveRequest(isotopessubset_id=isotopessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving isotopessubset_id: {e}")

        if isotopessubset_name is not None:
            filter_list.append({"name": isotopessubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if isotopessubset_name_display is not None:
        #     filter_list.append({"name_display": isotopessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotopessubset_client.List(
                        lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving isotopessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          isotopessubset_name: str = None,
                          isotopessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the isotopessubset_id for a given isotopessubset_name,
               isotopessubset_name_display or iri
        """
        if isotopessubset_name is not None:
            filter_dict = {"name": isotopessubset_name}
        elif isotopessubset_name_display is not None:
            filter_dict = {"name_display": isotopessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.isotopessubset_client.List(
                lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving isotopessubset_name: {e}")
        if len(results) == 1 :
            return results[0].isotopessubset_id
        else:
            raise ValueError(f"Error retrieving isotopessubset_id - no or too many results found.")

    async def get_by_id(self, isotopessubset_id: str = None) -> substances_dm.IsotopesSubset:
        """ retrieve a isotopessubset data model by isotopessubset_id """
        try:
            res = await self.isotopessubset_client.Retrieve(
                lara_django_substances_pb2.IsotopesSubsetRetrieveRequest(isotopessubset_id=isotopessubset_id)
            )
            return substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving isotopessubset_id: {e}")

    async def get_by_name(self, isotopessubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.IsotopesSubset:
        """ retrieve a isotopessubset data model by isotopessubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.isotopessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.IsotopesSubsetRetrieveByNameNSRequest(name=isotopessubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving isotopessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all isotopessubsets """
        if filter_dict is None:
            res = await self.isotopessubset_client.List(lara_django_substances_pb2.IsotopesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.isotopessubset_client.List(
                lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.isotopessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all isotopessubsets """
        if self.isotopessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.isotopessubset_full_client.List(
                lara_django_substances_pb2.IsotopesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.isotopessubset_full_client.List(
                lara_django_substances_pb2.IsotopesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, isotopessubset : substances_dm.IsotopesSubset = None) -> None:
        """ update a isotopessubset model instance """
        try:
            await self.isotopessubset_client.Update(
                lara_django_substances_pb2.IsotopesSubsetRequest(**isotopessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating isotopessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a isotopessubset by isotopessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.isotopessubset_client.Destroy(lara_django_substances_pb2.IsotopesSubsetDestroyRequest(isotopessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting isotopessubset_id: {e}")

#_________________  OrderedIsotopesIsotopesSubset  ______________________


class OrderedIsotopesIsotopesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedisotopesisotopessubset_client = lara_django_substances_pb2_grpc.OrderedIsotopesIsotopesSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedisotopesisotopessubsets:  list[substances_dm.OrderedIsotopesIsotopesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedIsotopesIsotopesSubset]]:
        try:
            create_coroutines = ( self.orderedisotopesisotopessubset_client.Create(lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetRequest(**orderedisotopesisotopessubset.model_dump())) for orderedisotopesisotopessubset in orderedisotopesisotopessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedisotopesisotopessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedisotopesisotopessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedisotopesisotopessubset_id: str = None,
        orderedisotopesisotopessubset_name: str = None,
        #orderedisotopesisotopessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedIsotopesIsotopesSubset]:
        """ retrieve a list of orderedisotopesisotopessubset instances by orderedisotopesisotopessubset_id, orderedisotopesisotopessubset_name or filter_dict,
               returns a list of orderedisotopesisotopessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedisotopesisotopessubset_id is not None:
            try:
                res =  await self.orderedisotopesisotopessubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetRetrieveRequest(orderedisotopesisotopessubset_id=orderedisotopesisotopessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedIsotopesIsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedisotopesisotopessubset_id: {e}")

        if orderedisotopesisotopessubset_name is not None:
            filter_list.append({"name": orderedisotopesisotopessubset_name})
        # if orderedisotopesisotopessubset_name_display is not None:
        #     filter_list.append({"name_display": orderedisotopesisotopessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedisotopesisotopessubset_client.List(
                        lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedIsotopesIsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedisotopesisotopessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedisotopesisotopessubset_name: str = None,
                          orderedisotopesisotopessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedisotopesisotopessubset_id for a given orderedisotopesisotopessubset_name,
               orderedisotopesisotopessubset_name_display or iri
        """
        if orderedisotopesisotopessubset_name is not None:
            filter_dict = {"name": orderedisotopesisotopessubset_name}
        elif orderedisotopesisotopessubset_name_display is not None:
            filter_dict = {"name_display": orderedisotopesisotopessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedisotopesisotopessubset_client.List(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedisotopesisotopessubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedisotopesisotopessubset_id
        else:
            raise ValueError(f"Error retrieving orderedisotopesisotopessubset_id - no or too many results found.")

    async def get_by_id(self, orderedisotopesisotopessubset_id: str = None) -> substances_dm.OrderedIsotopesIsotopesSubset:
        """ retrieve a orderedisotopesisotopessubset data model by orderedisotopesisotopessubset_id """
        try:
            res = await self.orderedisotopesisotopessubset_client.Retrieve(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetRetrieveRequest(orderedisotopesisotopessubset_id=orderedisotopesisotopessubset_id)
            )
            return substances_dm.OrderedIsotopesIsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedisotopesisotopessubset_id: {e}")

    async def get_by_name(self, orderedisotopesisotopessubset_name: str = None) -> substances_dm.OrderedIsotopesIsotopesSubset:
        """ retrieve a orderedisotopesisotopessubset data model by orderedisotopesisotopessubset_name """
        try:
            res = await self.orderedisotopesisotopessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetRetrieveByNameNSRequest(name=orderedisotopesisotopessubset_name, namespace_uri="")
            )
            return substances_dm.OrderedIsotopesIsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedisotopesisotopessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedisotopesisotopessubsets """
        if filter_dict is None:
            res = await self.orderedisotopesisotopessubset_client.List(lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedisotopesisotopessubset_client.List(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedisotopesisotopessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedisotopesisotopessubsets """
        if self.orderedisotopesisotopessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedisotopesisotopessubset_full_client.List(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedisotopesisotopessubset_full_client.List(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedisotopesisotopessubset : substances_dm.OrderedIsotopesIsotopesSubset = None) -> None:
        """ update a orderedisotopesisotopessubset model instance """
        try:
            await self.orderedisotopesisotopessubset_client.Update(
                lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetRequest(**orderedisotopesisotopessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedisotopesisotopessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedisotopesisotopessubset by orderedisotopesisotopessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedisotopesisotopessubset_client.Destroy(lara_django_substances_pb2.OrderedIsotopesIsotopesSubsetDestroyRequest(orderedisotopesisotopessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedisotopesisotopessubset_id: {e}")

#_________________  Substance  ______________________


class SubstanceInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.substance_client = lara_django_substances_pb2_grpc.SubstanceControllerStub(channel)

        self.update_item_id = "substance_id"
        self.stub = self.substance_client

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  substances:  list[substances_dm.Substance] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Substance]]:
        try:
            create_coroutines = ( self.substance_client.Create(lara_django_substances_pb2.SubstanceRequest(**substance.model_dump())) for substance in substances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substance_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substance: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        substance_id: str = None,
        substance_name: str = None,
        #substance_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Substance]:
        """ retrieve a list of substance instances by substance_id, substance_name or filter_dict,
               returns a list of substance data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  substance_id is not None:
            try:
                res =  await self.substance_client.Retrieve(
                    lara_django_substances_pb2.SubstanceRetrieveRequest(substance_id=substance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substance_id: {e}")

        if substance_name is not None:
            filter_list.append({"name": substance_name})
        # if substance_name_display is not None:
        #     filter_list.append({"name_display": substance_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substance_client.List(
                        lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving substance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          substance_name: str = None,
                          substance_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the substance_id for a given substance_name,
               substance_name_display or iri
        """
        if substance_name is not None:
            filter_dict = {"name": substance_name}
        elif substance_name_display is not None:
            filter_dict = {"name_display": substance_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substance_client.List(
                lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving substance_name: {e}")
        if len(results) == 1 :
            return results[0].substance_id
        else:
            raise ValueError(f"Error retrieving substance_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, substance_id: str = None) -> substances_dm.Substance:
        """ retrieve a substance data model by substance_id """
        try:
            res = await self.substance_client.Retrieve(
                lara_django_substances_pb2.SubstanceRetrieveRequest(substance_id=substance_id)
            )
            return substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substance_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, substance_name: str = None) -> substances_dm.Substance:
        """ retrieve a substance data model by substance_name """
        try:
            res = await self.substance_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.SubstanceRetrieveByNameNSRequest(name=substance_name, namespace_uri="")
            )
            return substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substance_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substances """
        if filter_dict is None:
            res = await self.substance_client.List(lara_django_substances_pb2.SubstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substance_client.List(
                lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substances """
        if self.substance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substance_full_client.List(
                lara_django_substances_pb2.SubstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substance_full_client.List(
                lara_django_substances_pb2.SubstanceFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, substance : substances_dm.Substance = None) -> None:
        """ update a substance model instance """
        try:
            await self.substance_client.Update(
                lara_django_substances_pb2.SubstanceRequest(**substance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substance by substance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substance_client.Destroy(lara_django_substances_pb2.SubstanceDestroyRequest(substance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substance_id: {e}")

#_________________  SubstancesSubset  ______________________


class SubstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substancessubset_class_client = (
        #     lara_django_substances_pb2_grpc.SubstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.substancessubset_client = lara_django_substances_pb2_grpc.SubstancesSubsetControllerStub(channel)


        # self.substancessubset_full_client = lara_django_substances_pb2_grpc.SubstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substancessubsets:  list[substances_dm.SubstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.SubstancesSubset]]:
        """ create a list of substancessubset instances,
               returns a list of substancessubset data model objects or ids_only

        :param substancessubsets: list of substancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substancessubset data model objects or ids_only
        """
        substancessubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.SubstancesSubsetclassRetrieveRequest(iri=substancessubset_class_iri)
        #     )
        #     substancessubsetclass_id = res.substancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substancessubsetclass_id: {e}")
        for substancessubset in substancessubsets:
            if self._default_namespace_id is not None:
                if substancessubset.namespace == "" or substancessubset.namespace == "default":
                    substancessubset.namespace = self._default_namespace_id
            # substancessubset.substancessubset_class = substancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substancessubset_client.Create(lara_django_substances_pb2.SubstancesSubsetRequest(**substancessubset.model_dump())) for substancessubset in substancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substancessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substancessubset_id: str = None,
        substancessubset_name: str = None,
        #substancessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.SubstancesSubset]:
        """ retrieve a list of substancessubset instances by substancessubset_id, substancessubset_name or filter_dict,
               returns a list of substancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and substancessubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  substancessubset_id is not None:
            try:
                res =  await self.substancessubset_client.Retrieve(
                    lara_django_substances_pb2.SubstancesSubsetRetrieveRequest(substancessubset_id=substancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substancessubset_id: {e}")

        if substancessubset_name is not None:
            filter_list.append({"name": substancessubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if substancessubset_name_display is not None:
        #     filter_list.append({"name_display": substancessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancessubset_client.List(
                        lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving substancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          substancessubset_name: str = None,
                          substancessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the substancessubset_id for a given substancessubset_name,
               substancessubset_name_display or iri
        """
        if substancessubset_name is not None:
            filter_dict = {"name": substancessubset_name}
        elif substancessubset_name_display is not None:
            filter_dict = {"name_display": substancessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substancessubset_client.List(
                lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving substancessubset_name: {e}")
        if len(results) == 1 :
            return results[0].substancessubset_id
        else:
            raise ValueError(f"Error retrieving substancessubset_id - no or too many results found.")

    async def get_by_id(self, substancessubset_id: str = None) -> substances_dm.SubstancesSubset:
        """ retrieve a substancessubset data model by substancessubset_id """
        try:
            res = await self.substancessubset_client.Retrieve(
                lara_django_substances_pb2.SubstancesSubsetRetrieveRequest(substancessubset_id=substancessubset_id)
            )
            return substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substancessubset_id: {e}")

    async def get_by_name(self, substancessubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.SubstancesSubset:
        """ retrieve a substancessubset data model by substancessubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.SubstancesSubsetRetrieveByNameNSRequest(name=substancessubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substancessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substancessubsets """
        if filter_dict is None:
            res = await self.substancessubset_client.List(lara_django_substances_pb2.SubstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancessubset_client.List(
                lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substancessubsets """
        if self.substancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancessubset_full_client.List(
                lara_django_substances_pb2.SubstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancessubset_full_client.List(
                lara_django_substances_pb2.SubstancesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substancessubset : substances_dm.SubstancesSubset = None) -> None:
        """ update a substancessubset model instance """
        try:
            await self.substancessubset_client.Update(
                lara_django_substances_pb2.SubstancesSubsetRequest(**substancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substancessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substancessubset by substancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substancessubset_client.Destroy(lara_django_substances_pb2.SubstancesSubsetDestroyRequest(substancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substancessubset_id: {e}")

#_________________  OrderedSubstancesSubstancesSubset  ______________________


class OrderedSubstancesSubstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedsubstancessubstancessubset_client = lara_django_substances_pb2_grpc.OrderedSubstancesSubstancesSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedsubstancessubstancessubsets:  list[substances_dm.OrderedSubstancesSubstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedSubstancesSubstancesSubset]]:
        try:
            create_coroutines = ( self.orderedsubstancessubstancessubset_client.Create(lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetRequest(**orderedsubstancessubstancessubset.model_dump())) for orderedsubstancessubstancessubset in orderedsubstancessubstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedsubstancessubstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedsubstancessubstancessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedsubstancessubstancessubset_id: str = None,
        orderedsubstancessubstancessubset_name: str = None,
        #orderedsubstancessubstancessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedSubstancesSubstancesSubset]:
        """ retrieve a list of orderedsubstancessubstancessubset instances by orderedsubstancessubstancessubset_id, orderedsubstancessubstancessubset_name or filter_dict,
               returns a list of orderedsubstancessubstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedsubstancessubstancessubset_id is not None:
            try:
                res =  await self.orderedsubstancessubstancessubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetRetrieveRequest(orderedsubstancessubstancessubset_id=orderedsubstancessubstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedSubstancesSubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedsubstancessubstancessubset_id: {e}")

        if orderedsubstancessubstancessubset_name is not None:
            filter_list.append({"name": orderedsubstancessubstancessubset_name})
        # if orderedsubstancessubstancessubset_name_display is not None:
        #     filter_list.append({"name_display": orderedsubstancessubstancessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedsubstancessubstancessubset_client.List(
                        lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedSubstancesSubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedsubstancessubstancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedsubstancessubstancessubset_name: str = None,
                          orderedsubstancessubstancessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedsubstancessubstancessubset_id for a given orderedsubstancessubstancessubset_name,
               orderedsubstancessubstancessubset_name_display or iri
        """
        if orderedsubstancessubstancessubset_name is not None:
            filter_dict = {"name": orderedsubstancessubstancessubset_name}
        elif orderedsubstancessubstancessubset_name_display is not None:
            filter_dict = {"name_display": orderedsubstancessubstancessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedsubstancessubstancessubset_client.List(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstancessubstancessubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedsubstancessubstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedsubstancessubstancessubset_id - no or too many results found.")

    async def get_by_id(self, orderedsubstancessubstancessubset_id: str = None) -> substances_dm.OrderedSubstancesSubstancesSubset:
        """ retrieve a orderedsubstancessubstancessubset data model by orderedsubstancessubstancessubset_id """
        try:
            res = await self.orderedsubstancessubstancessubset_client.Retrieve(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetRetrieveRequest(orderedsubstancessubstancessubset_id=orderedsubstancessubstancessubset_id)
            )
            return substances_dm.OrderedSubstancesSubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstancessubstancessubset_id: {e}")

    async def get_by_name(self, orderedsubstancessubstancessubset_name: str = None) -> substances_dm.OrderedSubstancesSubstancesSubset:
        """ retrieve a orderedsubstancessubstancessubset data model by orderedsubstancessubstancessubset_name """
        try:
            res = await self.orderedsubstancessubstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetRetrieveByNameNSRequest(name=orderedsubstancessubstancessubset_name, namespace_uri="")
            )
            return substances_dm.OrderedSubstancesSubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstancessubstancessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedsubstancessubstancessubsets """
        if filter_dict is None:
            res = await self.orderedsubstancessubstancessubset_client.List(lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedsubstancessubstancessubset_client.List(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedsubstancessubstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedsubstancessubstancessubsets """
        if self.orderedsubstancessubstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedsubstancessubstancessubset_full_client.List(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedsubstancessubstancessubset_full_client.List(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedsubstancessubstancessubset : substances_dm.OrderedSubstancesSubstancesSubset = None) -> None:
        """ update a orderedsubstancessubstancessubset model instance """
        try:
            await self.orderedsubstancessubstancessubset_client.Update(
                lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetRequest(**orderedsubstancessubstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedsubstancessubstancessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedsubstancessubstancessubset by orderedsubstancessubstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedsubstancessubstancessubset_client.Destroy(lara_django_substances_pb2.OrderedSubstancesSubstancesSubsetDestroyRequest(orderedsubstancessubstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedsubstancessubstancessubset_id: {e}")

#_________________  Polymer  ______________________


class PolymerInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.polymer_client = lara_django_substances_pb2_grpc.PolymerControllerStub(channel)

        self.update_item_id = "polymer_id"
        self.stub = self.polymer_client

        self.file_upload_chunk = lara_django_substances_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  polymers:  list[substances_dm.Polymer] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Polymer]]:
        try:
            create_coroutines = ( self.polymer_client.Create(lara_django_substances_pb2.PolymerRequest(**polymer.model_dump())) for polymer in polymers )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymer_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymer: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        polymer_id: str = None,
        polymer_name: str = None,
        #polymer_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Polymer]:
        """ retrieve a list of polymer instances by polymer_id, polymer_name or filter_dict,
               returns a list of polymer data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  polymer_id is not None:
            try:
                res =  await self.polymer_client.Retrieve(
                    lara_django_substances_pb2.PolymerRetrieveRequest(polymer_id=polymer_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymer_id: {e}")

        if polymer_name is not None:
            filter_list.append({"name": polymer_name})
        # if polymer_name_display is not None:
        #     filter_list.append({"name_display": polymer_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymer_client.List(
                        lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving polymer_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          polymer_name: str = None,
                          polymer_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymer_id for a given polymer_name,
               polymer_name_display or iri
        """
        if polymer_name is not None:
            filter_dict = {"name": polymer_name}
        elif polymer_name_display is not None:
            filter_dict = {"name_display": polymer_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymer_client.List(
                lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving polymer_name: {e}")
        if len(results) == 1 :
            return results[0].polymer_id
        else:
            raise ValueError(f"Error retrieving polymer_id - no or too many results found.")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, polymer_id: str = None) -> substances_dm.Polymer:
        """ retrieve a polymer data model by polymer_id """
        try:
            res = await self.polymer_client.Retrieve(
                lara_django_substances_pb2.PolymerRetrieveRequest(polymer_id=polymer_id)
            )
            return substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymer_id: {e}")

    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, polymer_name: str = None) -> substances_dm.Polymer:
        """ retrieve a polymer data model by polymer_name """
        try:
            res = await self.polymer_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.PolymerRetrieveByNameNSRequest(name=polymer_name, namespace_uri="")
            )
            return substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymer_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymers """
        if filter_dict is None:
            res = await self.polymer_client.List(lara_django_substances_pb2.PolymerListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymer_client.List(
                lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymer_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymers """
        if self.polymer_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymer_full_client.List(
                lara_django_substances_pb2.PolymerFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymer_full_client.List(
                lara_django_substances_pb2.PolymerFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, polymer : substances_dm.Polymer = None) -> None:
        """ update a polymer model instance """
        try:
            await self.polymer_client.Update(
                lara_django_substances_pb2.PolymerRequest(**polymer.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymer_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymer by polymer_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymer_client.Destroy(lara_django_substances_pb2.PolymerDestroyRequest(polymer_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymer_id: {e}")

#_________________  PolymersSubset  ______________________


class PolymersSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerssubset_class_client = (
        #     lara_django_substances_pb2_grpc.PolymersSubsetclassByIRIControllerStub(channel)
        # )

        self.polymerssubset_client = lara_django_substances_pb2_grpc.PolymersSubsetControllerStub(channel)


        # self.polymerssubset_full_client = lara_django_substances_pb2_grpc.PolymersSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerssubsets:  list[substances_dm.PolymersSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.PolymersSubset]]:
        """ create a list of polymerssubset instances,
               returns a list of polymerssubset data model objects or ids_only

        :param polymerssubsets: list of polymerssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerssubset data model objects or ids_only
        """
        polymerssubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.PolymersSubsetclassRetrieveRequest(iri=polymerssubset_class_iri)
        #     )
        #     polymerssubsetclass_id = res.polymerssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerssubsetclass_id: {e}")
        for polymerssubset in polymerssubsets:
            if self._default_namespace_id is not None:
                if polymerssubset.namespace == "" or polymerssubset.namespace == "default":
                    polymerssubset.namespace = self._default_namespace_id
            # polymerssubset.polymerssubset_class = polymerssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerssubset_client.Create(lara_django_substances_pb2.PolymersSubsetRequest(**polymerssubset.model_dump())) for polymerssubset in polymerssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerssubset_id: str = None,
        polymerssubset_name: str = None,
        #polymerssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.PolymersSubset]:
        """ retrieve a list of polymerssubset instances by polymerssubset_id, polymerssubset_name or filter_dict,
               returns a list of polymerssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and polymerssubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  polymerssubset_id is not None:
            try:
                res =  await self.polymerssubset_client.Retrieve(
                    lara_django_substances_pb2.PolymersSubsetRetrieveRequest(polymerssubset_id=polymerssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerssubset_id: {e}")

        if polymerssubset_name is not None:
            filter_list.append({"name": polymerssubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if polymerssubset_name_display is not None:
        #     filter_list.append({"name_display": polymerssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerssubset_client.List(
                        lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving polymerssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          polymerssubset_name: str = None,
                          polymerssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerssubset_id for a given polymerssubset_name,
               polymerssubset_name_display or iri
        """
        if polymerssubset_name is not None:
            filter_dict = {"name": polymerssubset_name}
        elif polymerssubset_name_display is not None:
            filter_dict = {"name_display": polymerssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerssubset_client.List(
                lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving polymerssubset_name: {e}")
        if len(results) == 1 :
            return results[0].polymerssubset_id
        else:
            raise ValueError(f"Error retrieving polymerssubset_id - no or too many results found.")

    async def get_by_id(self, polymerssubset_id: str = None) -> substances_dm.PolymersSubset:
        """ retrieve a polymerssubset data model by polymerssubset_id """
        try:
            res = await self.polymerssubset_client.Retrieve(
                lara_django_substances_pb2.PolymersSubsetRetrieveRequest(polymerssubset_id=polymerssubset_id)
            )
            return substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymerssubset_id: {e}")

    async def get_by_name(self, polymerssubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.PolymersSubset:
        """ retrieve a polymerssubset data model by polymerssubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.PolymersSubsetRetrieveByNameNSRequest(name=polymerssubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymerssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerssubsets """
        if filter_dict is None:
            res = await self.polymerssubset_client.List(lara_django_substances_pb2.PolymersSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerssubset_client.List(
                lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerssubsets """
        if self.polymerssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerssubset_full_client.List(
                lara_django_substances_pb2.PolymersSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerssubset_full_client.List(
                lara_django_substances_pb2.PolymersSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerssubset : substances_dm.PolymersSubset = None) -> None:
        """ update a polymerssubset model instance """
        try:
            await self.polymerssubset_client.Update(
                lara_django_substances_pb2.PolymersSubsetRequest(**polymerssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerssubset by polymerssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerssubset_client.Destroy(lara_django_substances_pb2.PolymersSubsetDestroyRequest(polymerssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerssubset_id: {e}")

#_________________  OrderedPolymersPolymersSubset  ______________________


class OrderedPolymersPolymersSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedpolymerspolymerssubset_client = lara_django_substances_pb2_grpc.OrderedPolymersPolymersSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedpolymerspolymerssubsets:  list[substances_dm.OrderedPolymersPolymersSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedPolymersPolymersSubset]]:
        try:
            create_coroutines = ( self.orderedpolymerspolymerssubset_client.Create(lara_django_substances_pb2.OrderedPolymersPolymersSubsetRequest(**orderedpolymerspolymerssubset.model_dump())) for orderedpolymerspolymerssubset in orderedpolymerspolymerssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedpolymerspolymerssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedpolymerspolymerssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedpolymerspolymerssubset_id: str = None,
        orderedpolymerspolymerssubset_name: str = None,
        #orderedpolymerspolymerssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedPolymersPolymersSubset]:
        """ retrieve a list of orderedpolymerspolymerssubset instances by orderedpolymerspolymerssubset_id, orderedpolymerspolymerssubset_name or filter_dict,
               returns a list of orderedpolymerspolymerssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedpolymerspolymerssubset_id is not None:
            try:
                res =  await self.orderedpolymerspolymerssubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedPolymersPolymersSubsetRetrieveRequest(orderedpolymerspolymerssubset_id=orderedpolymerspolymerssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedPolymersPolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedpolymerspolymerssubset_id: {e}")

        if orderedpolymerspolymerssubset_name is not None:
            filter_list.append({"name": orderedpolymerspolymerssubset_name})
        # if orderedpolymerspolymerssubset_name_display is not None:
        #     filter_list.append({"name_display": orderedpolymerspolymerssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedpolymerspolymerssubset_client.List(
                        lara_django_substances_pb2.OrderedPolymersPolymersSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedPolymersPolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedpolymerspolymerssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedpolymerspolymerssubset_name: str = None,
                          orderedpolymerspolymerssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedpolymerspolymerssubset_id for a given orderedpolymerspolymerssubset_name,
               orderedpolymerspolymerssubset_name_display or iri
        """
        if orderedpolymerspolymerssubset_name is not None:
            filter_dict = {"name": orderedpolymerspolymerssubset_name}
        elif orderedpolymerspolymerssubset_name_display is not None:
            filter_dict = {"name_display": orderedpolymerspolymerssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedpolymerspolymerssubset_client.List(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerspolymerssubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedpolymerspolymerssubset_id
        else:
            raise ValueError(f"Error retrieving orderedpolymerspolymerssubset_id - no or too many results found.")

    async def get_by_id(self, orderedpolymerspolymerssubset_id: str = None) -> substances_dm.OrderedPolymersPolymersSubset:
        """ retrieve a orderedpolymerspolymerssubset data model by orderedpolymerspolymerssubset_id """
        try:
            res = await self.orderedpolymerspolymerssubset_client.Retrieve(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetRetrieveRequest(orderedpolymerspolymerssubset_id=orderedpolymerspolymerssubset_id)
            )
            return substances_dm.OrderedPolymersPolymersSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerspolymerssubset_id: {e}")

    async def get_by_name(self, orderedpolymerspolymerssubset_name: str = None) -> substances_dm.OrderedPolymersPolymersSubset:
        """ retrieve a orderedpolymerspolymerssubset data model by orderedpolymerspolymerssubset_name """
        try:
            res = await self.orderedpolymerspolymerssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetRetrieveByNameNSRequest(name=orderedpolymerspolymerssubset_name, namespace_uri="")
            )
            return substances_dm.OrderedPolymersPolymersSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerspolymerssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedpolymerspolymerssubsets """
        if filter_dict is None:
            res = await self.orderedpolymerspolymerssubset_client.List(lara_django_substances_pb2.OrderedPolymersPolymersSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedpolymerspolymerssubset_client.List(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedpolymerspolymerssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedpolymerspolymerssubsets """
        if self.orderedpolymerspolymerssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedpolymerspolymerssubset_full_client.List(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedpolymerspolymerssubset_full_client.List(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedpolymerspolymerssubset : substances_dm.OrderedPolymersPolymersSubset = None) -> None:
        """ update a orderedpolymerspolymerssubset model instance """
        try:
            await self.orderedpolymerspolymerssubset_client.Update(
                lara_django_substances_pb2.OrderedPolymersPolymersSubsetRequest(**orderedpolymerspolymerssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedpolymerspolymerssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedpolymerspolymerssubset by orderedpolymerspolymerssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedpolymerspolymerssubset_client.Destroy(lara_django_substances_pb2.OrderedPolymersPolymersSubsetDestroyRequest(orderedpolymerspolymerssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedpolymerspolymerssubset_id: {e}")

#_________________  MixtureComponent  ______________________


class MixtureComponentInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mixturecomponent_client = lara_django_substances_pb2_grpc.MixtureComponentControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturecomponents:  list[substances_dm.MixtureComponent] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.MixtureComponent]]:
        try:
            create_coroutines = ( self.mixturecomponent_client.Create(lara_django_substances_pb2.MixtureComponentRequest(**mixturecomponent.model_dump())) for mixturecomponent in mixturecomponents )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturecomponent_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturecomponent: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        mixturecomponent_id: str = None,
        mixturecomponent_name: str = None,
        #mixturecomponent_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MixtureComponent]:
        """ retrieve a list of mixturecomponent instances by mixturecomponent_id, mixturecomponent_name or filter_dict,
               returns a list of mixturecomponent data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  mixturecomponent_id is not None:
            try:
                res =  await self.mixturecomponent_client.Retrieve(
                    lara_django_substances_pb2.MixtureComponentRetrieveRequest(mixturecomponent_id=mixturecomponent_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturecomponent_id: {e}")

        if mixturecomponent_name is not None:
            filter_list.append({"name": mixturecomponent_name})
        # if mixturecomponent_name_display is not None:
        #     filter_list.append({"name_display": mixturecomponent_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturecomponent_client.List(
                        lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving mixturecomponent_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          mixturecomponent_name: str = None,
                          mixturecomponent_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturecomponent_id for a given mixturecomponent_name,
               mixturecomponent_name_display or iri
        """
        if mixturecomponent_name is not None:
            filter_dict = {"name": mixturecomponent_name}
        elif mixturecomponent_name_display is not None:
            filter_dict = {"name_display": mixturecomponent_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturecomponent_client.List(
                lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponent_name: {e}")
        if len(results) == 1 :
            return results[0].mixturecomponent_id
        else:
            raise ValueError(f"Error retrieving mixturecomponent_id - no or too many results found.")

    async def get_by_id(self, mixturecomponent_id: str = None) -> substances_dm.MixtureComponent:
        """ retrieve a mixturecomponent data model by mixturecomponent_id """
        try:
            res = await self.mixturecomponent_client.Retrieve(
                lara_django_substances_pb2.MixtureComponentRetrieveRequest(mixturecomponent_id=mixturecomponent_id)
            )
            return substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponent_id: {e}")

    async def get_by_name(self, mixturecomponent_name: str = None) -> substances_dm.MixtureComponent:
        """ retrieve a mixturecomponent data model by mixturecomponent_name """
        try:
            res = await self.mixturecomponent_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MixtureComponentRetrieveByNameNSRequest(name=mixturecomponent_name, namespace_uri="")
            )
            return substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponent_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturecomponents """
        if filter_dict is None:
            res = await self.mixturecomponent_client.List(lara_django_substances_pb2.MixtureComponentListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturecomponent_client.List(
                lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturecomponent_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturecomponents """
        if self.mixturecomponent_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturecomponent_full_client.List(
                lara_django_substances_pb2.MixtureComponentFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturecomponent_full_client.List(
                lara_django_substances_pb2.MixtureComponentFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturecomponent : substances_dm.MixtureComponent = None) -> None:
        """ update a mixturecomponent model instance """
        try:
            await self.mixturecomponent_client.Update(
                lara_django_substances_pb2.MixtureComponentRequest(**mixturecomponent.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturecomponent_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturecomponent by mixturecomponent_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturecomponent_client.Destroy(lara_django_substances_pb2.MixtureComponentDestroyRequest(mixturecomponent_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturecomponent_id: {e}")

#_________________  Mixture  ______________________


class MixtureInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mixture_client = lara_django_substances_pb2_grpc.MixtureControllerStub(channel)

        self.update_item_id = "mixture_id"
        self.stub = self.mixture_client

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  mixtures:  list[substances_dm.Mixture] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Mixture]]:
        try:
            create_coroutines = ( self.mixture_client.Create(lara_django_substances_pb2.MixtureRequest(**mixture.model_dump())) for mixture in mixtures )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixture_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixture: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        mixture_id: str = None,
        mixture_name: str = None,
        #mixture_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Mixture]:
        """ retrieve a list of mixture instances by mixture_id, mixture_name or filter_dict,
               returns a list of mixture data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  mixture_id is not None:
            try:
                res =  await self.mixture_client.Retrieve(
                    lara_django_substances_pb2.MixtureRetrieveRequest(mixture_id=mixture_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixture_id: {e}")

        if mixture_name is not None:
            filter_list.append({"name": mixture_name})
        # if mixture_name_display is not None:
        #     filter_list.append({"name_display": mixture_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixture_client.List(
                        lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving mixture_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          mixture_name: str = None,
                          mixture_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixture_id for a given mixture_name,
               mixture_name_display or iri
        """
        if mixture_name is not None:
            filter_dict = {"name": mixture_name}
        elif mixture_name_display is not None:
            filter_dict = {"name_display": mixture_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixture_client.List(
                lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving mixture_name: {e}")
        if len(results) == 1 :
            return results[0].mixture_id
        else:
            raise ValueError(f"Error retrieving mixture_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, mixture_id: str = None) -> substances_dm.Mixture:
        """ retrieve a mixture data model by mixture_id """
        try:
            res = await self.mixture_client.Retrieve(
                lara_django_substances_pb2.MixtureRetrieveRequest(mixture_id=mixture_id)
            )
            return substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixture_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, mixture_name: str = None) -> substances_dm.Mixture:
        """ retrieve a mixture data model by mixture_name """
        try:
            res = await self.mixture_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MixtureRetrieveByNameNSRequest(name=mixture_name, namespace_uri="")
            )
            return substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixture_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixtures """
        if filter_dict is None:
            res = await self.mixture_client.List(lara_django_substances_pb2.MixtureListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixture_client.List(
                lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixture_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixtures """
        if self.mixture_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixture_full_client.List(
                lara_django_substances_pb2.MixtureFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixture_full_client.List(
                lara_django_substances_pb2.MixtureFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, mixture : substances_dm.Mixture = None) -> None:
        """ update a mixture model instance """
        try:
            await self.mixture_client.Update(
                lara_django_substances_pb2.MixtureRequest(**mixture.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixture_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixture by mixture_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixture_client.Destroy(lara_django_substances_pb2.MixtureDestroyRequest(mixture_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixture_id: {e}")

#_________________  MixturesSubset  ______________________


class MixturesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturessubset_class_client = (
        #     lara_django_substances_pb2_grpc.MixturesSubsetclassByIRIControllerStub(channel)
        # )

        self.mixturessubset_client = lara_django_substances_pb2_grpc.MixturesSubsetControllerStub(channel)


        # self.mixturessubset_full_client = lara_django_substances_pb2_grpc.MixturesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturessubsets:  list[substances_dm.MixturesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.MixturesSubset]]:
        """ create a list of mixturessubset instances,
               returns a list of mixturessubset data model objects or ids_only

        :param mixturessubsets: list of mixturessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixturessubset data model objects or ids_only
        """
        mixturessubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.MixturesSubsetclassRetrieveRequest(iri=mixturessubset_class_iri)
        #     )
        #     mixturessubsetclass_id = res.mixturessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixturessubsetclass_id: {e}")
        for mixturessubset in mixturessubsets:
            if self._default_namespace_id is not None:
                if mixturessubset.namespace == "" or mixturessubset.namespace == "default":
                    mixturessubset.namespace = self._default_namespace_id
            # mixturessubset.mixturessubset_class = mixturessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixturessubset_client.Create(lara_django_substances_pb2.MixturesSubsetRequest(**mixturessubset.model_dump())) for mixturessubset in mixturessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixturessubset_id: str = None,
        mixturessubset_name: str = None,
        #mixturessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MixturesSubset]:
        """ retrieve a list of mixturessubset instances by mixturessubset_id, mixturessubset_name or filter_dict,
               returns a list of mixturessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and mixturessubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  mixturessubset_id is not None:
            try:
                res =  await self.mixturessubset_client.Retrieve(
                    lara_django_substances_pb2.MixturesSubsetRetrieveRequest(mixturessubset_id=mixturessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturessubset_id: {e}")

        if mixturessubset_name is not None:
            filter_list.append({"name": mixturessubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if mixturessubset_name_display is not None:
        #     filter_list.append({"name_display": mixturessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturessubset_client.List(
                        lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving mixturessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          mixturessubset_name: str = None,
                          mixturessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturessubset_id for a given mixturessubset_name,
               mixturessubset_name_display or iri
        """
        if mixturessubset_name is not None:
            filter_dict = {"name": mixturessubset_name}
        elif mixturessubset_name_display is not None:
            filter_dict = {"name_display": mixturessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturessubset_client.List(
                lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving mixturessubset_name: {e}")
        if len(results) == 1 :
            return results[0].mixturessubset_id
        else:
            raise ValueError(f"Error retrieving mixturessubset_id - no or too many results found.")

    async def get_by_id(self, mixturessubset_id: str = None) -> substances_dm.MixturesSubset:
        """ retrieve a mixturessubset data model by mixturessubset_id """
        try:
            res = await self.mixturessubset_client.Retrieve(
                lara_django_substances_pb2.MixturesSubsetRetrieveRequest(mixturessubset_id=mixturessubset_id)
            )
            return substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixturessubset_id: {e}")

    async def get_by_name(self, mixturessubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.MixturesSubset:
        """ retrieve a mixturessubset data model by mixturessubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixturessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MixturesSubsetRetrieveByNameNSRequest(name=mixturessubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixturessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturessubsets """
        if filter_dict is None:
            res = await self.mixturessubset_client.List(lara_django_substances_pb2.MixturesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturessubset_client.List(
                lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturessubsets """
        if self.mixturessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturessubset_full_client.List(
                lara_django_substances_pb2.MixturesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturessubset_full_client.List(
                lara_django_substances_pb2.MixturesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturessubset : substances_dm.MixturesSubset = None) -> None:
        """ update a mixturessubset model instance """
        try:
            await self.mixturessubset_client.Update(
                lara_django_substances_pb2.MixturesSubsetRequest(**mixturessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturessubset by mixturessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturessubset_client.Destroy(lara_django_substances_pb2.MixturesSubsetDestroyRequest(mixturessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturessubset_id: {e}")

#_________________  OrderedMixturesMixturesSubset  ______________________


class OrderedMixturesMixturesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmixturesmixturessubset_client = lara_django_substances_pb2_grpc.OrderedMixturesMixturesSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedmixturesmixturessubsets:  list[substances_dm.OrderedMixturesMixturesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedMixturesMixturesSubset]]:
        try:
            create_coroutines = ( self.orderedmixturesmixturessubset_client.Create(lara_django_substances_pb2.OrderedMixturesMixturesSubsetRequest(**orderedmixturesmixturessubset.model_dump())) for orderedmixturesmixturessubset in orderedmixturesmixturessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmixturesmixturessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmixturesmixturessubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmixturesmixturessubset_id: str = None,
        orderedmixturesmixturessubset_name: str = None,
        #orderedmixturesmixturessubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedMixturesMixturesSubset]:
        """ retrieve a list of orderedmixturesmixturessubset instances by orderedmixturesmixturessubset_id, orderedmixturesmixturessubset_name or filter_dict,
               returns a list of orderedmixturesmixturessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedmixturesmixturessubset_id is not None:
            try:
                res =  await self.orderedmixturesmixturessubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedMixturesMixturesSubsetRetrieveRequest(orderedmixturesmixturessubset_id=orderedmixturesmixturessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedMixturesMixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmixturesmixturessubset_id: {e}")

        if orderedmixturesmixturessubset_name is not None:
            filter_list.append({"name": orderedmixturesmixturessubset_name})
        # if orderedmixturesmixturessubset_name_display is not None:
        #     filter_list.append({"name_display": orderedmixturesmixturessubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedmixturesmixturessubset_client.List(
                        lara_django_substances_pb2.OrderedMixturesMixturesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedMixturesMixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedmixturesmixturessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedmixturesmixturessubset_name: str = None,
                          orderedmixturesmixturessubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmixturesmixturessubset_id for a given orderedmixturesmixturessubset_name,
               orderedmixturesmixturessubset_name_display or iri
        """
        if orderedmixturesmixturessubset_name is not None:
            filter_dict = {"name": orderedmixturesmixturessubset_name}
        elif orderedmixturesmixturessubset_name_display is not None:
            filter_dict = {"name_display": orderedmixturesmixturessubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmixturesmixturessubset_client.List(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedmixturesmixturessubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedmixturesmixturessubset_id
        else:
            raise ValueError(f"Error retrieving orderedmixturesmixturessubset_id - no or too many results found.")

    async def get_by_id(self, orderedmixturesmixturessubset_id: str = None) -> substances_dm.OrderedMixturesMixturesSubset:
        """ retrieve a orderedmixturesmixturessubset data model by orderedmixturesmixturessubset_id """
        try:
            res = await self.orderedmixturesmixturessubset_client.Retrieve(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetRetrieveRequest(orderedmixturesmixturessubset_id=orderedmixturesmixturessubset_id)
            )
            return substances_dm.OrderedMixturesMixturesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmixturesmixturessubset_id: {e}")

    async def get_by_name(self, orderedmixturesmixturessubset_name: str = None) -> substances_dm.OrderedMixturesMixturesSubset:
        """ retrieve a orderedmixturesmixturessubset data model by orderedmixturesmixturessubset_name """
        try:
            res = await self.orderedmixturesmixturessubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetRetrieveByNameNSRequest(name=orderedmixturesmixturessubset_name, namespace_uri="")
            )
            return substances_dm.OrderedMixturesMixturesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmixturesmixturessubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmixturesmixturessubsets """
        if filter_dict is None:
            res = await self.orderedmixturesmixturessubset_client.List(lara_django_substances_pb2.OrderedMixturesMixturesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmixturesmixturessubset_client.List(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmixturesmixturessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmixturesmixturessubsets """
        if self.orderedmixturesmixturessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmixturesmixturessubset_full_client.List(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmixturesmixturessubset_full_client.List(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedmixturesmixturessubset : substances_dm.OrderedMixturesMixturesSubset = None) -> None:
        """ update a orderedmixturesmixturessubset model instance """
        try:
            await self.orderedmixturesmixturessubset_client.Update(
                lara_django_substances_pb2.OrderedMixturesMixturesSubsetRequest(**orderedmixturesmixturessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmixturesmixturessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmixturesmixturessubset by orderedmixturesmixturessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmixturesmixturessubset_client.Destroy(lara_django_substances_pb2.OrderedMixturesMixturesSubsetDestroyRequest(orderedmixturesmixturessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmixturesmixturessubset_id: {e}")

#_________________  MoleculeResidue  ______________________


class MoleculeResidueInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.moleculeresidue_client = lara_django_substances_pb2_grpc.MoleculeResidueControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  moleculeresidues:  list[substances_dm.MoleculeResidue] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.MoleculeResidue]]:
        try:
            create_coroutines = ( self.moleculeresidue_client.Create(lara_django_substances_pb2.MoleculeResidueRequest(**moleculeresidue.model_dump())) for moleculeresidue in moleculeresidues )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.moleculeresidue_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating moleculeresidue: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        moleculeresidue_id: str = None,
        moleculeresidue_name: str = None,
        #moleculeresidue_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MoleculeResidue]:
        """ retrieve a list of moleculeresidue instances by moleculeresidue_id, moleculeresidue_name or filter_dict,
               returns a list of moleculeresidue data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  moleculeresidue_id is not None:
            try:
                res =  await self.moleculeresidue_client.Retrieve(
                    lara_django_substances_pb2.MoleculeResidueRetrieveRequest(moleculeresidue_id=moleculeresidue_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving moleculeresidue_id: {e}")

        if moleculeresidue_name is not None:
            filter_list.append({"name": moleculeresidue_name})
        # if moleculeresidue_name_display is not None:
        #     filter_list.append({"name_display": moleculeresidue_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.moleculeresidue_client.List(
                        lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving moleculeresidue_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          moleculeresidue_name: str = None,
                          moleculeresidue_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the moleculeresidue_id for a given moleculeresidue_name,
               moleculeresidue_name_display or iri
        """
        if moleculeresidue_name is not None:
            filter_dict = {"name": moleculeresidue_name}
        elif moleculeresidue_name_display is not None:
            filter_dict = {"name_display": moleculeresidue_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.moleculeresidue_client.List(
                lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving moleculeresidue_name: {e}")
        if len(results) == 1 :
            return results[0].moleculeresidue_id
        else:
            raise ValueError(f"Error retrieving moleculeresidue_id - no or too many results found.")

    async def get_by_id(self, moleculeresidue_id: str = None) -> substances_dm.MoleculeResidue:
        """ retrieve a moleculeresidue data model by moleculeresidue_id """
        try:
            res = await self.moleculeresidue_client.Retrieve(
                lara_django_substances_pb2.MoleculeResidueRetrieveRequest(moleculeresidue_id=moleculeresidue_id)
            )
            return substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving moleculeresidue_id: {e}")

    async def get_by_name(self, moleculeresidue_name: str = None) -> substances_dm.MoleculeResidue:
        """ retrieve a moleculeresidue data model by moleculeresidue_name """
        try:
            res = await self.moleculeresidue_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MoleculeResidueRetrieveByNameNSRequest(name=moleculeresidue_name, namespace_uri="")
            )
            return substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving moleculeresidue_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all moleculeresidues """
        if filter_dict is None:
            res = await self.moleculeresidue_client.List(lara_django_substances_pb2.MoleculeResidueListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.moleculeresidue_client.List(
                lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.moleculeresidue_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all moleculeresidues """
        if self.moleculeresidue_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.moleculeresidue_full_client.List(
                lara_django_substances_pb2.MoleculeResidueFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.moleculeresidue_full_client.List(
                lara_django_substances_pb2.MoleculeResidueFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, moleculeresidue : substances_dm.MoleculeResidue = None) -> None:
        """ update a moleculeresidue model instance """
        try:
            await self.moleculeresidue_client.Update(
                lara_django_substances_pb2.MoleculeResidueRequest(**moleculeresidue.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating moleculeresidue_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a moleculeresidue by moleculeresidue_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.moleculeresidue_client.Destroy(lara_django_substances_pb2.MoleculeResidueDestroyRequest(moleculeresidue_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting moleculeresidue_id: {e}")

#_________________  Reactant  ______________________


class ReactantInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.reactant_client = lara_django_substances_pb2_grpc.ReactantControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactants:  list[substances_dm.Reactant] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Reactant]]:
        try:
            create_coroutines = ( self.reactant_client.Create(lara_django_substances_pb2.ReactantRequest(**reactant.model_dump())) for reactant in reactants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactant_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactant: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        reactant_id: str = None,
        reactant_name: str = None,
        #reactant_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Reactant]:
        """ retrieve a list of reactant instances by reactant_id, reactant_name or filter_dict,
               returns a list of reactant data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  reactant_id is not None:
            try:
                res =  await self.reactant_client.Retrieve(
                    lara_django_substances_pb2.ReactantRetrieveRequest(reactant_id=reactant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactant_id: {e}")

        if reactant_name is not None:
            filter_list.append({"name": reactant_name})
        # if reactant_name_display is not None:
        #     filter_list.append({"name_display": reactant_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactant_client.List(
                        lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving reactant_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          reactant_name: str = None,
                          reactant_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactant_id for a given reactant_name,
               reactant_name_display or iri
        """
        if reactant_name is not None:
            filter_dict = {"name": reactant_name}
        elif reactant_name_display is not None:
            filter_dict = {"name_display": reactant_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactant_client.List(
                lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving reactant_name: {e}")
        if len(results) == 1 :
            return results[0].reactant_id
        else:
            raise ValueError(f"Error retrieving reactant_id - no or too many results found.")

    async def get_by_id(self, reactant_id: str = None) -> substances_dm.Reactant:
        """ retrieve a reactant data model by reactant_id """
        try:
            res = await self.reactant_client.Retrieve(
                lara_django_substances_pb2.ReactantRetrieveRequest(reactant_id=reactant_id)
            )
            return substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactant_id: {e}")

    async def get_by_name(self, reactant_name: str = None) -> substances_dm.Reactant:
        """ retrieve a reactant data model by reactant_name """
        try:
            res = await self.reactant_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.ReactantRetrieveByNameNSRequest(name=reactant_name, namespace_uri="")
            )
            return substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactant_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactants """
        if filter_dict is None:
            res = await self.reactant_client.List(lara_django_substances_pb2.ReactantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactant_client.List(
                lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactant_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactants """
        if self.reactant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactant_full_client.List(
                lara_django_substances_pb2.ReactantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactant_full_client.List(
                lara_django_substances_pb2.ReactantFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactant : substances_dm.Reactant = None) -> None:
        """ update a reactant model instance """
        try:
            await self.reactant_client.Update(
                lara_django_substances_pb2.ReactantRequest(**reactant.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactant_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactant by reactant_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactant_client.Destroy(lara_django_substances_pb2.ReactantDestroyRequest(reactant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactant_id: {e}")

#_________________  ReactantsSubset  ______________________


class ReactantsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reactantssubset_class_client = (
        #     lara_django_substances_pb2_grpc.ReactantsSubsetclassByIRIControllerStub(channel)
        # )

        self.reactantssubset_client = lara_django_substances_pb2_grpc.ReactantsSubsetControllerStub(channel)


        # self.reactantssubset_full_client = lara_django_substances_pb2_grpc.ReactantsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactantssubsets:  list[substances_dm.ReactantsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.ReactantsSubset]]:
        """ create a list of reactantssubset instances,
               returns a list of reactantssubset data model objects or ids_only

        :param reactantssubsets: list of reactantssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of reactantssubset data model objects or ids_only
        """
        reactantssubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactantssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactantssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactantsSubsetclassRetrieveRequest(iri=reactantssubset_class_iri)
        #     )
        #     reactantssubsetclass_id = res.reactantssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving reactantssubsetclass_id: {e}")
        for reactantssubset in reactantssubsets:
            if self._default_namespace_id is not None:
                if reactantssubset.namespace == "" or reactantssubset.namespace == "default":
                    reactantssubset.namespace = self._default_namespace_id
            # reactantssubset.reactantssubset_class = reactantssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.reactantssubset_client.Create(lara_django_substances_pb2.ReactantsSubsetRequest(**reactantssubset.model_dump())) for reactantssubset in reactantssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactantssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactantssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        reactantssubset_id: str = None,
        reactantssubset_name: str = None,
        #reactantssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ReactantsSubset]:
        """ retrieve a list of reactantssubset instances by reactantssubset_id, reactantssubset_name or filter_dict,
               returns a list of reactantssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and reactantssubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  reactantssubset_id is not None:
            try:
                res =  await self.reactantssubset_client.Retrieve(
                    lara_django_substances_pb2.ReactantsSubsetRetrieveRequest(reactantssubset_id=reactantssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactantssubset_id: {e}")

        if reactantssubset_name is not None:
            filter_list.append({"name": reactantssubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if reactantssubset_name_display is not None:
        #     filter_list.append({"name_display": reactantssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactantssubset_client.List(
                        lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving reactantssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          reactantssubset_name: str = None,
                          reactantssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactantssubset_id for a given reactantssubset_name,
               reactantssubset_name_display or iri
        """
        if reactantssubset_name is not None:
            filter_dict = {"name": reactantssubset_name}
        elif reactantssubset_name_display is not None:
            filter_dict = {"name_display": reactantssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactantssubset_client.List(
                lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving reactantssubset_name: {e}")
        if len(results) == 1 :
            return results[0].reactantssubset_id
        else:
            raise ValueError(f"Error retrieving reactantssubset_id - no or too many results found.")

    async def get_by_id(self, reactantssubset_id: str = None) -> substances_dm.ReactantsSubset:
        """ retrieve a reactantssubset data model by reactantssubset_id """
        try:
            res = await self.reactantssubset_client.Retrieve(
                lara_django_substances_pb2.ReactantsSubsetRetrieveRequest(reactantssubset_id=reactantssubset_id)
            )
            return substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactantssubset_id: {e}")

    async def get_by_name(self, reactantssubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.ReactantsSubset:
        """ retrieve a reactantssubset data model by reactantssubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.reactantssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.ReactantsSubsetRetrieveByNameNSRequest(name=reactantssubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactantssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactantssubsets """
        if filter_dict is None:
            res = await self.reactantssubset_client.List(lara_django_substances_pb2.ReactantsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactantssubset_client.List(
                lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactantssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactantssubsets """
        if self.reactantssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactantssubset_full_client.List(
                lara_django_substances_pb2.ReactantsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactantssubset_full_client.List(
                lara_django_substances_pb2.ReactantsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactantssubset : substances_dm.ReactantsSubset = None) -> None:
        """ update a reactantssubset model instance """
        try:
            await self.reactantssubset_client.Update(
                lara_django_substances_pb2.ReactantsSubsetRequest(**reactantssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactantssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactantssubset by reactantssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactantssubset_client.Destroy(lara_django_substances_pb2.ReactantsSubsetDestroyRequest(reactantssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactantssubset_id: {e}")

#_________________  OrderedReactantsReactantsSubset  ______________________


class OrderedReactantsReactantsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedreactantsreactantssubset_client = lara_django_substances_pb2_grpc.OrderedReactantsReactantsSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedreactantsreactantssubsets:  list[substances_dm.OrderedReactantsReactantsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedReactantsReactantsSubset]]:
        try:
            create_coroutines = ( self.orderedreactantsreactantssubset_client.Create(lara_django_substances_pb2.OrderedReactantsReactantsSubsetRequest(**orderedreactantsreactantssubset.model_dump())) for orderedreactantsreactantssubset in orderedreactantsreactantssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedreactantsreactantssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedreactantsreactantssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedreactantsreactantssubset_id: str = None,
        orderedreactantsreactantssubset_name: str = None,
        #orderedreactantsreactantssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedReactantsReactantsSubset]:
        """ retrieve a list of orderedreactantsreactantssubset instances by orderedreactantsreactantssubset_id, orderedreactantsreactantssubset_name or filter_dict,
               returns a list of orderedreactantsreactantssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedreactantsreactantssubset_id is not None:
            try:
                res =  await self.orderedreactantsreactantssubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedReactantsReactantsSubsetRetrieveRequest(orderedreactantsreactantssubset_id=orderedreactantsreactantssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedReactantsReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedreactantsreactantssubset_id: {e}")

        if orderedreactantsreactantssubset_name is not None:
            filter_list.append({"name": orderedreactantsreactantssubset_name})
        # if orderedreactantsreactantssubset_name_display is not None:
        #     filter_list.append({"name_display": orderedreactantsreactantssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedreactantsreactantssubset_client.List(
                        lara_django_substances_pb2.OrderedReactantsReactantsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedReactantsReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedreactantsreactantssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedreactantsreactantssubset_name: str = None,
                          orderedreactantsreactantssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedreactantsreactantssubset_id for a given orderedreactantsreactantssubset_name,
               orderedreactantsreactantssubset_name_display or iri
        """
        if orderedreactantsreactantssubset_name is not None:
            filter_dict = {"name": orderedreactantsreactantssubset_name}
        elif orderedreactantsreactantssubset_name_display is not None:
            filter_dict = {"name_display": orderedreactantsreactantssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedreactantsreactantssubset_client.List(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantsreactantssubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedreactantsreactantssubset_id
        else:
            raise ValueError(f"Error retrieving orderedreactantsreactantssubset_id - no or too many results found.")

    async def get_by_id(self, orderedreactantsreactantssubset_id: str = None) -> substances_dm.OrderedReactantsReactantsSubset:
        """ retrieve a orderedreactantsreactantssubset data model by orderedreactantsreactantssubset_id """
        try:
            res = await self.orderedreactantsreactantssubset_client.Retrieve(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetRetrieveRequest(orderedreactantsreactantssubset_id=orderedreactantsreactantssubset_id)
            )
            return substances_dm.OrderedReactantsReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantsreactantssubset_id: {e}")

    async def get_by_name(self, orderedreactantsreactantssubset_name: str = None) -> substances_dm.OrderedReactantsReactantsSubset:
        """ retrieve a orderedreactantsreactantssubset data model by orderedreactantsreactantssubset_name """
        try:
            res = await self.orderedreactantsreactantssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetRetrieveByNameNSRequest(name=orderedreactantsreactantssubset_name, namespace_uri="")
            )
            return substances_dm.OrderedReactantsReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantsreactantssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedreactantsreactantssubsets """
        if filter_dict is None:
            res = await self.orderedreactantsreactantssubset_client.List(lara_django_substances_pb2.OrderedReactantsReactantsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedreactantsreactantssubset_client.List(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedreactantsreactantssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedreactantsreactantssubsets """
        if self.orderedreactantsreactantssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedreactantsreactantssubset_full_client.List(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedreactantsreactantssubset_full_client.List(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedreactantsreactantssubset : substances_dm.OrderedReactantsReactantsSubset = None) -> None:
        """ update a orderedreactantsreactantssubset model instance """
        try:
            await self.orderedreactantsreactantssubset_client.Update(
                lara_django_substances_pb2.OrderedReactantsReactantsSubsetRequest(**orderedreactantsreactantssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedreactantsreactantssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedreactantsreactantssubset by orderedreactantsreactantssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedreactantsreactantssubset_client.Destroy(lara_django_substances_pb2.OrderedReactantsReactantsSubsetDestroyRequest(orderedreactantsreactantssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedreactantsreactantssubset_id: {e}")

#_________________  Reaction  ______________________


class ReactionInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.reaction_client = lara_django_substances_pb2_grpc.ReactionControllerStub(channel)

        self.update_item_id = "reaction_id"
        self.stub = self.reaction_client

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  reactions:  list[substances_dm.Reaction] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.Reaction]]:
        try:
            create_coroutines = ( self.reaction_client.Create(lara_django_substances_pb2.ReactionRequest(**reaction.model_dump())) for reaction in reactions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reaction_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reaction: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        reaction_id: str = None,
        reaction_name: str = None,
        #reaction_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Reaction]:
        """ retrieve a list of reaction instances by reaction_id, reaction_name or filter_dict,
               returns a list of reaction data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  reaction_id is not None:
            try:
                res =  await self.reaction_client.Retrieve(
                    lara_django_substances_pb2.ReactionRetrieveRequest(reaction_id=reaction_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reaction_id: {e}")

        if reaction_name is not None:
            filter_list.append({"name": reaction_name})
        # if reaction_name_display is not None:
        #     filter_list.append({"name_display": reaction_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reaction_client.List(
                        lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving reaction_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          reaction_name: str = None,
                          reaction_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reaction_id for a given reaction_name,
               reaction_name_display or iri
        """
        if reaction_name is not None:
            filter_dict = {"name": reaction_name}
        elif reaction_name_display is not None:
            filter_dict = {"name_display": reaction_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reaction_client.List(
                lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving reaction_name: {e}")
        if len(results) == 1 :
            return results[0].reaction_id
        else:
            raise ValueError(f"Error retrieving reaction_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, reaction_id: str = None) -> substances_dm.Reaction:
        """ retrieve a reaction data model by reaction_id """
        try:
            res = await self.reaction_client.Retrieve(
                lara_django_substances_pb2.ReactionRetrieveRequest(reaction_id=reaction_id)
            )
            return substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reaction_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, reaction_name: str = None) -> substances_dm.Reaction:
        """ retrieve a reaction data model by reaction_name """
        try:
            res = await self.reaction_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.ReactionRetrieveByNameNSRequest(name=reaction_name, namespace_uri="")
            )
            return substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reaction_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactions """
        if filter_dict is None:
            res = await self.reaction_client.List(lara_django_substances_pb2.ReactionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reaction_client.List(
                lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reaction_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactions """
        if self.reaction_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reaction_full_client.List(
                lara_django_substances_pb2.ReactionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reaction_full_client.List(
                lara_django_substances_pb2.ReactionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, reaction : substances_dm.Reaction = None) -> None:
        """ update a reaction model instance """
        try:
            await self.reaction_client.Update(
                lara_django_substances_pb2.ReactionRequest(**reaction.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reaction_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reaction by reaction_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reaction_client.Destroy(lara_django_substances_pb2.ReactionDestroyRequest(reaction_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reaction_id: {e}")

#_________________  ReactionsSubset  ______________________


class ReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reactionssubset_class_client = (
        #     lara_django_substances_pb2_grpc.ReactionsSubsetclassByIRIControllerStub(channel)
        # )

        self.reactionssubset_client = lara_django_substances_pb2_grpc.ReactionsSubsetControllerStub(channel)


        # self.reactionssubset_full_client = lara_django_substances_pb2_grpc.ReactionsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactionssubsets:  list[substances_dm.ReactionsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.ReactionsSubset]]:
        """ create a list of reactionssubset instances,
               returns a list of reactionssubset data model objects or ids_only

        :param reactionssubsets: list of reactionssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of reactionssubset data model objects or ids_only
        """
        reactionssubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactionssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactionssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactionsSubsetclassRetrieveRequest(iri=reactionssubset_class_iri)
        #     )
        #     reactionssubsetclass_id = res.reactionssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving reactionssubsetclass_id: {e}")
        for reactionssubset in reactionssubsets:
            if self._default_namespace_id is not None:
                if reactionssubset.namespace == "" or reactionssubset.namespace == "default":
                    reactionssubset.namespace = self._default_namespace_id
            # reactionssubset.reactionssubset_class = reactionssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.reactionssubset_client.Create(lara_django_substances_pb2.ReactionsSubsetRequest(**reactionssubset.model_dump())) for reactionssubset in reactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactionssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        reactionssubset_id: str = None,
        reactionssubset_name: str = None,
        #reactionssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ReactionsSubset]:
        """ retrieve a list of reactionssubset instances by reactionssubset_id, reactionssubset_name or filter_dict,
               returns a list of reactionssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and reactionssubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  reactionssubset_id is not None:
            try:
                res =  await self.reactionssubset_client.Retrieve(
                    lara_django_substances_pb2.ReactionsSubsetRetrieveRequest(reactionssubset_id=reactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactionssubset_id: {e}")

        if reactionssubset_name is not None:
            filter_list.append({"name": reactionssubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if reactionssubset_name_display is not None:
        #     filter_list.append({"name_display": reactionssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactionssubset_client.List(
                        lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving reactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          reactionssubset_name: str = None,
                          reactionssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactionssubset_id for a given reactionssubset_name,
               reactionssubset_name_display or iri
        """
        if reactionssubset_name is not None:
            filter_dict = {"name": reactionssubset_name}
        elif reactionssubset_name_display is not None:
            filter_dict = {"name_display": reactionssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactionssubset_client.List(
                lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving reactionssubset_name: {e}")
        if len(results) == 1 :
            return results[0].reactionssubset_id
        else:
            raise ValueError(f"Error retrieving reactionssubset_id - no or too many results found.")

    async def get_by_id(self, reactionssubset_id: str = None) -> substances_dm.ReactionsSubset:
        """ retrieve a reactionssubset data model by reactionssubset_id """
        try:
            res = await self.reactionssubset_client.Retrieve(
                lara_django_substances_pb2.ReactionsSubsetRetrieveRequest(reactionssubset_id=reactionssubset_id)
            )
            return substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactionssubset_id: {e}")

    async def get_by_name(self, reactionssubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.ReactionsSubset:
        """ retrieve a reactionssubset data model by reactionssubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.reactionssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.ReactionsSubsetRetrieveByNameNSRequest(name=reactionssubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactionssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactionssubsets """
        if filter_dict is None:
            res = await self.reactionssubset_client.List(lara_django_substances_pb2.ReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactionssubset_client.List(
                lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactionssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactionssubsets """
        if self.reactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactionssubset_full_client.List(
                lara_django_substances_pb2.ReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactionssubset_full_client.List(
                lara_django_substances_pb2.ReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactionssubset : substances_dm.ReactionsSubset = None) -> None:
        """ update a reactionssubset model instance """
        try:
            await self.reactionssubset_client.Update(
                lara_django_substances_pb2.ReactionsSubsetRequest(**reactionssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactionssubset by reactionssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactionssubset_client.Destroy(lara_django_substances_pb2.ReactionsSubsetDestroyRequest(reactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactionssubset_id: {e}")

#_________________  OrderedReactionsReactionsSubset  ______________________


class OrderedReactionsReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedreactionsreactionssubset_client = lara_django_substances_pb2_grpc.OrderedReactionsReactionsSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedreactionsreactionssubsets:  list[substances_dm.OrderedReactionsReactionsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedReactionsReactionsSubset]]:
        try:
            create_coroutines = ( self.orderedreactionsreactionssubset_client.Create(lara_django_substances_pb2.OrderedReactionsReactionsSubsetRequest(**orderedreactionsreactionssubset.model_dump())) for orderedreactionsreactionssubset in orderedreactionsreactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedreactionsreactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedreactionsreactionssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedreactionsreactionssubset_id: str = None,
        orderedreactionsreactionssubset_name: str = None,
        #orderedreactionsreactionssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedReactionsReactionsSubset]:
        """ retrieve a list of orderedreactionsreactionssubset instances by orderedreactionsreactionssubset_id, orderedreactionsreactionssubset_name or filter_dict,
               returns a list of orderedreactionsreactionssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedreactionsreactionssubset_id is not None:
            try:
                res =  await self.orderedreactionsreactionssubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedReactionsReactionsSubsetRetrieveRequest(orderedreactionsreactionssubset_id=orderedreactionsreactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedReactionsReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedreactionsreactionssubset_id: {e}")

        if orderedreactionsreactionssubset_name is not None:
            filter_list.append({"name": orderedreactionsreactionssubset_name})
        # if orderedreactionsreactionssubset_name_display is not None:
        #     filter_list.append({"name_display": orderedreactionsreactionssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedreactionsreactionssubset_client.List(
                        lara_django_substances_pb2.OrderedReactionsReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedReactionsReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedreactionsreactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedreactionsreactionssubset_name: str = None,
                          orderedreactionsreactionssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedreactionsreactionssubset_id for a given orderedreactionsreactionssubset_name,
               orderedreactionsreactionssubset_name_display or iri
        """
        if orderedreactionsreactionssubset_name is not None:
            filter_dict = {"name": orderedreactionsreactionssubset_name}
        elif orderedreactionsreactionssubset_name_display is not None:
            filter_dict = {"name_display": orderedreactionsreactionssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedreactionsreactionssubset_client.List(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedreactionsreactionssubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedreactionsreactionssubset_id
        else:
            raise ValueError(f"Error retrieving orderedreactionsreactionssubset_id - no or too many results found.")

    async def get_by_id(self, orderedreactionsreactionssubset_id: str = None) -> substances_dm.OrderedReactionsReactionsSubset:
        """ retrieve a orderedreactionsreactionssubset data model by orderedreactionsreactionssubset_id """
        try:
            res = await self.orderedreactionsreactionssubset_client.Retrieve(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetRetrieveRequest(orderedreactionsreactionssubset_id=orderedreactionsreactionssubset_id)
            )
            return substances_dm.OrderedReactionsReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactionsreactionssubset_id: {e}")

    async def get_by_name(self, orderedreactionsreactionssubset_name: str = None) -> substances_dm.OrderedReactionsReactionsSubset:
        """ retrieve a orderedreactionsreactionssubset data model by orderedreactionsreactionssubset_name """
        try:
            res = await self.orderedreactionsreactionssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetRetrieveByNameNSRequest(name=orderedreactionsreactionssubset_name, namespace_uri="")
            )
            return substances_dm.OrderedReactionsReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactionsreactionssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedreactionsreactionssubsets """
        if filter_dict is None:
            res = await self.orderedreactionsreactionssubset_client.List(lara_django_substances_pb2.OrderedReactionsReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedreactionsreactionssubset_client.List(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedreactionsreactionssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedreactionsreactionssubsets """
        if self.orderedreactionsreactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedreactionsreactionssubset_full_client.List(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedreactionsreactionssubset_full_client.List(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedreactionsreactionssubset : substances_dm.OrderedReactionsReactionsSubset = None) -> None:
        """ update a orderedreactionsreactionssubset model instance """
        try:
            await self.orderedreactionsreactionssubset_client.Update(
                lara_django_substances_pb2.OrderedReactionsReactionsSubsetRequest(**orderedreactionsreactionssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedreactionsreactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedreactionsreactionssubset by orderedreactionsreactionssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedreactionsreactionssubset_client.Destroy(lara_django_substances_pb2.OrderedReactionsReactionsSubsetDestroyRequest(orderedreactionsreactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedreactionsreactionssubset_id: {e}")

#_________________  MultiStepReaction  ______________________


class MultiStepReactionInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.multistepreaction_client = lara_django_substances_pb2_grpc.MultiStepReactionControllerStub(channel)

        self.update_item_id = "multistepreaction_id"
        self.stub = self.multistepreaction_client

        self.image_upload_chunk = lara_django_substances_pb2.ImageUploadChunk


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  multistepreactions:  list[substances_dm.MultiStepReaction] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.MultiStepReaction]]:
        try:
            create_coroutines = ( self.multistepreaction_client.Create(lara_django_substances_pb2.MultiStepReactionRequest(**multistepreaction.model_dump())) for multistepreaction in multistepreactions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.multistepreaction_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating multistepreaction: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        multistepreaction_id: str = None,
        multistepreaction_name: str = None,
        #multistepreaction_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MultiStepReaction]:
        """ retrieve a list of multistepreaction instances by multistepreaction_id, multistepreaction_name or filter_dict,
               returns a list of multistepreaction data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  multistepreaction_id is not None:
            try:
                res =  await self.multistepreaction_client.Retrieve(
                    lara_django_substances_pb2.MultiStepReactionRetrieveRequest(multistepreaction_id=multistepreaction_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving multistepreaction_id: {e}")

        if multistepreaction_name is not None:
            filter_list.append({"name": multistepreaction_name})
        # if multistepreaction_name_display is not None:
        #     filter_list.append({"name_display": multistepreaction_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreaction_client.List(
                        lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving multistepreaction_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          multistepreaction_name: str = None,
                          multistepreaction_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the multistepreaction_id for a given multistepreaction_name,
               multistepreaction_name_display or iri
        """
        if multistepreaction_name is not None:
            filter_dict = {"name": multistepreaction_name}
        elif multistepreaction_name_display is not None:
            filter_dict = {"name_display": multistepreaction_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.multistepreaction_client.List(
                lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving multistepreaction_name: {e}")
        if len(results) == 1 :
            return results[0].multistepreaction_id
        else:
            raise ValueError(f"Error retrieving multistepreaction_id - no or too many results found.")

    @download_image  # needed for image download
    async def get_by_id(self, multistepreaction_id: str = None) -> substances_dm.MultiStepReaction:
        """ retrieve a multistepreaction data model by multistepreaction_id """
        try:
            res = await self.multistepreaction_client.Retrieve(
                lara_django_substances_pb2.MultiStepReactionRetrieveRequest(multistepreaction_id=multistepreaction_id)
            )
            return substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreaction_id: {e}")

    @download_image  # needed for image download
    async def get_by_name(self, multistepreaction_name: str = None) -> substances_dm.MultiStepReaction:
        """ retrieve a multistepreaction data model by multistepreaction_name """
        try:
            res = await self.multistepreaction_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MultiStepReactionRetrieveByNameNSRequest(name=multistepreaction_name, namespace_uri="")
            )
            return substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreaction_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all multistepreactions """
        if filter_dict is None:
            res = await self.multistepreaction_client.List(lara_django_substances_pb2.MultiStepReactionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreaction_client.List(
                lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreaction_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all multistepreactions """
        if self.multistepreaction_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreaction_full_client.List(
                lara_django_substances_pb2.MultiStepReactionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreaction_full_client.List(
                lara_django_substances_pb2.MultiStepReactionFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, multistepreaction : substances_dm.MultiStepReaction = None) -> None:
        """ update a multistepreaction model instance """
        try:
            await self.multistepreaction_client.Update(
                lara_django_substances_pb2.MultiStepReactionRequest(**multistepreaction.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating multistepreaction_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a multistepreaction by multistepreaction_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.multistepreaction_client.Destroy(lara_django_substances_pb2.MultiStepReactionDestroyRequest(multistepreaction_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting multistepreaction_id: {e}")

#_________________  MultiStepReactionsSubset  ______________________


class MultiStepReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self._default_namespace_uri = None
        self._default_namespace_id = None

        # if default_namespace_uri is not None:
        #     await self.set_default_namespace_uri(default_namespace_uri)

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.multistepreactionssubset_class_client = (
        #     lara_django_substances_pb2_grpc.MultiStepReactionsSubsetclassByIRIControllerStub(channel)
        # )

        self.multistepreactionssubset_client = lara_django_substances_pb2_grpc.MultiStepReactionsSubsetControllerStub(channel)


        # self.multistepreactionssubset_full_client = lara_django_substances_pb2_grpc.MultiStepReactionsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri
    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  multistepreactionssubsets:  list[substances_dm.MultiStepReactionsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.MultiStepReactionsSubset]]:
        """ create a list of multistepreactionssubset instances,
               returns a list of multistepreactionssubset data model objects or ids_only

        :param multistepreactionssubsets: list of multistepreactionssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of multistepreactionssubset data model objects or ids_only
        """
        multistepreactionssubsetclass_id = None

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if multistepreactionssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.multistepreactionssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.MultiStepReactionsSubsetclassRetrieveRequest(iri=multistepreactionssubset_class_iri)
        #     )
        #     multistepreactionssubsetclass_id = res.multistepreactionssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving multistepreactionssubsetclass_id: {e}")
        for multistepreactionssubset in multistepreactionssubsets:
            if self._default_namespace_id is not None:
                if multistepreactionssubset.namespace == "" or multistepreactionssubset.namespace == "default":
                    multistepreactionssubset.namespace = self._default_namespace_id
            # multistepreactionssubset.multistepreactionssubset_class = multistepreactionssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.multistepreactionssubset_client.Create(lara_django_substances_pb2.MultiStepReactionsSubsetRequest(**multistepreactionssubset.model_dump())) for multistepreactionssubset in multistepreactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.multistepreactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating multistepreactionssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        multistepreactionssubset_id: str = None,
        multistepreactionssubset_name: str = None,
        #multistepreactionssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MultiStepReactionsSubset]:
        """ retrieve a list of multistepreactionssubset instances by multistepreactionssubset_id, multistepreactionssubset_name or filter_dict,
               returns a list of multistepreactionssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None and multistepreactionssubset_id is None:
            # TODO: define NoNamespaceURIError
            raise ValueError("No namespace URI is given.")
        filter_list = []
        results_list = []
        if  multistepreactionssubset_id is not None:
            try:
                res =  await self.multistepreactionssubset_client.Retrieve(
                    lara_django_substances_pb2.MultiStepReactionsSubsetRetrieveRequest(multistepreactionssubset_id=multistepreactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving multistepreactionssubset_id: {e}")

        if multistepreactionssubset_name is not None:
            filter_list.append({"name": multistepreactionssubset_name})
        if namespace_uri is not None:
            filter_list.append({"namespace__uri": namespace_uri})
        # if multistepreactionssubset_name_display is not None:
        #     filter_list.append({"name_display": multistepreactionssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreactionssubset_client.List(
                        lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving multistepreactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          multistepreactionssubset_name: str = None,
                          multistepreactionssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the multistepreactionssubset_id for a given multistepreactionssubset_name,
               multistepreactionssubset_name_display or iri
        """
        if multistepreactionssubset_name is not None:
            filter_dict = {"name": multistepreactionssubset_name}
        elif multistepreactionssubset_name_display is not None:
            filter_dict = {"name_display": multistepreactionssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.multistepreactionssubset_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving multistepreactionssubset_name: {e}")
        if len(results) == 1 :
            return results[0].multistepreactionssubset_id
        else:
            raise ValueError(f"Error retrieving multistepreactionssubset_id - no or too many results found.")

    async def get_by_id(self, multistepreactionssubset_id: str = None) -> substances_dm.MultiStepReactionsSubset:
        """ retrieve a multistepreactionssubset data model by multistepreactionssubset_id """
        try:
            res = await self.multistepreactionssubset_client.Retrieve(
                lara_django_substances_pb2.MultiStepReactionsSubsetRetrieveRequest(multistepreactionssubset_id=multistepreactionssubset_id)
            )
            return substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreactionssubset_id: {e}")

    async def get_by_name(self, multistepreactionssubset_name: str = None,
                                namespace_uri : str = None) -> substances_dm.MultiStepReactionsSubset:
        """ retrieve a multistepreactionssubset data model by multistepreactionssubset_name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.multistepreactionssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.MultiStepReactionsSubsetRetrieveByNameNSRequest(name=multistepreactionssubset_name, namespace_uri=namespace_uri)
            )
            return substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreactionssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all multistepreactionssubsets """
        if filter_dict is None:
            res = await self.multistepreactionssubset_client.List(lara_django_substances_pb2.MultiStepReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreactionssubset_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreactionssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all multistepreactionssubsets """
        if self.multistepreactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreactionssubset_full_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreactionssubset_full_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, multistepreactionssubset : substances_dm.MultiStepReactionsSubset = None) -> None:
        """ update a multistepreactionssubset model instance """
        try:
            await self.multistepreactionssubset_client.Update(
                lara_django_substances_pb2.MultiStepReactionsSubsetRequest(**multistepreactionssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating multistepreactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a multistepreactionssubset by multistepreactionssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.multistepreactionssubset_client.Destroy(lara_django_substances_pb2.MultiStepReactionsSubsetDestroyRequest(multistepreactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting multistepreactionssubset_id: {e}")

#_________________  OrderedMultiStepReactionsMultiStepReactionsSubset  ______________________


class OrderedMultiStepReactionsMultiStepReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmultistepreactionsmultistepreactionssubset_client = lara_django_substances_pb2_grpc.OrderedMultiStepReactionsMultiStepReactionsSubsetControllerStub(channel)


    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedmultistepreactionsmultistepreactionssubsets:  list[substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset]]:
        try:
            create_coroutines = ( self.orderedmultistepreactionsmultistepreactionssubset_client.Create(lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetRequest(**orderedmultistepreactionsmultistepreactionssubset.model_dump())) for orderedmultistepreactionsmultistepreactionssubset in orderedmultistepreactionsmultistepreactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmultistepreactionsmultistepreactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmultistepreactionsmultistepreactionssubset: {e}")

    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmultistepreactionsmultistepreactionssubset_id: str = None,
        orderedmultistepreactionsmultistepreactionssubset_name: str = None,
        #orderedmultistepreactionsmultistepreactionssubset_name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset]:
        """ retrieve a list of orderedmultistepreactionsmultistepreactionssubset instances by orderedmultistepreactionsmultistepreactionssubset_id, orderedmultistepreactionsmultistepreactionssubset_name or filter_dict,
               returns a list of orderedmultistepreactionsmultistepreactionssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        filter_list = []
        results_list = []
        if  orderedmultistepreactionsmultistepreactionssubset_id is not None:
            try:
                res =  await self.orderedmultistepreactionsmultistepreactionssubset_client.Retrieve(
                    lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetRetrieveRequest(orderedmultistepreactionsmultistepreactionssubset_id=orderedmultistepreactionsmultistepreactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_id: {e}")

        if orderedmultistepreactionsmultistepreactionssubset_name is not None:
            filter_list.append({"name": orderedmultistepreactionsmultistepreactionssubset_name})
        # if orderedmultistepreactionsmultistepreactionssubset_name_display is not None:
        #     filter_list.append({"name_display": orderedmultistepreactionsmultistepreactionssubset_name_display})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.orderedmultistepreactionsmultistepreactionssubset_client.List(
                        lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logger.error(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          orderedmultistepreactionsmultistepreactionssubset_name: str = None,
                          orderedmultistepreactionsmultistepreactionssubset_name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmultistepreactionsmultistepreactionssubset_id for a given orderedmultistepreactionsmultistepreactionssubset_name,
               orderedmultistepreactionsmultistepreactionssubset_name_display or iri
        """
        if orderedmultistepreactionsmultistepreactionssubset_name is not None:
            filter_dict = {"name": orderedmultistepreactionsmultistepreactionssubset_name}
        elif orderedmultistepreactionsmultistepreactionssubset_name_display is not None:
            filter_dict = {"name_display": orderedmultistepreactionsmultistepreactionssubset_name_display}
        elif iri is not None:
            filter_dict = {"iri": iri}
        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmultistepreactionsmultistepreactionssubset_client.List(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetListRequest(), metadata=metadata
            )
            results = res.results
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_name: {e}")
        if len(results) == 1 :
            return results[0].orderedmultistepreactionsmultistepreactionssubset_id
        else:
            raise ValueError(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_id - no or too many results found.")

    async def get_by_id(self, orderedmultistepreactionsmultistepreactionssubset_id: str = None) -> substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset:
        """ retrieve a orderedmultistepreactionsmultistepreactionssubset data model by orderedmultistepreactionsmultistepreactionssubset_id """
        try:
            res = await self.orderedmultistepreactionsmultistepreactionssubset_client.Retrieve(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetRetrieveRequest(orderedmultistepreactionsmultistepreactionssubset_id=orderedmultistepreactionsmultistepreactionssubset_id)
            )
            return substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_id: {e}")

    async def get_by_name(self, orderedmultistepreactionsmultistepreactionssubset_name: str = None) -> substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset:
        """ retrieve a orderedmultistepreactionsmultistepreactionssubset data model by orderedmultistepreactionsmultistepreactionssubset_name """
        try:
            res = await self.orderedmultistepreactionsmultistepreactionssubset_client.RetrieveByNameNamespace(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetRetrieveByNameNSRequest(name=orderedmultistepreactionsmultistepreactionssubset_name, namespace_uri="")
            )
            return substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactionsmultistepreactionssubset_name: {e}")

    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmultistepreactionsmultistepreactionssubsets """
        if filter_dict is None:
            res = await self.orderedmultistepreactionsmultistepreactionssubset_client.List(lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmultistepreactionsmultistepreactionssubset_client.List(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmultistepreactionsmultistepreactionssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmultistepreactionsmultistepreactionssubsets """
        if self.orderedmultistepreactionsmultistepreactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmultistepreactionsmultistepreactionssubset_full_client.List(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmultistepreactionsmultistepreactionssubset_full_client.List(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedmultistepreactionsmultistepreactionssubset : substances_dm.OrderedMultiStepReactionsMultiStepReactionsSubset = None) -> None:
        """ update a orderedmultistepreactionsmultistepreactionssubset model instance """
        try:
            await self.orderedmultistepreactionsmultistepreactionssubset_client.Update(
                lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetRequest(**orderedmultistepreactionsmultistepreactionssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmultistepreactionsmultistepreactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmultistepreactionsmultistepreactionssubset by orderedmultistepreactionsmultistepreactionssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmultistepreactionsmultistepreactionssubset_client.Destroy(lara_django_substances_pb2.OrderedMultiStepReactionsMultiStepReactionsSubsetDestroyRequest(orderedmultistepreactionsmultistepreactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmultistepreactionsmultistepreactionssubset_id: {e}")
