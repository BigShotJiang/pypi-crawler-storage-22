"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances high_level_interface *

:details: lara_django_substances high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_substances
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_substances_grpc.v1.lara_django_substances_pb2 as lara_django_substances_pb2
import lara_django_substances_grpc.v1.lara_django_substances_pb2_grpc as lara_django_substances_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, export_file, import_file, id_cache, update_image

import  lara_django_substances_grpc.lara_django_substances_data_model as substances_dm 



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_substances_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_substances_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_substances_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  extradata:  list[substances_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_substances_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_substances_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_substances_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_substances_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_substances_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_substances_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_substances_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, extradata : substances_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_substances_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_substances_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  SubstanceClass  ______________________


class SubstanceClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substanceclass_class_client = (
        #     lara_django_substances_pb2_grpc.SubstanceClassclassByIRIControllerStub(channel)
        # )
        
        self.substanceclass_client = lara_django_substances_pb2_grpc.SubstanceClassControllerStub(channel)

        # self.substanceclass_full_client = lara_django_substances_pb2_grpc.SubstanceClassFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substanceclasses:  list[substances_dm.SubstanceClass] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.SubstanceClass]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substanceclassclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceclass_class_client.Retrieve(
        #         lara_django_substances_pb2.SubstanceClassclassRetrieveRequest(iri=substanceclass_class_iri)
        #     )
        #     substanceclassclass_id = res.substanceclassclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substanceclassclass_id: {e}")
        # for substanceclass in substanceclasss:
        #     substanceclass.namespace = self.namespace_id
        #     substanceclass.substanceclass_class = substanceclassclass_id

        try:
            create_coroutines = ( self.substanceclass_client.Create(lara_django_substances_pb2.SubstanceClassRequest(**substanceclass.model_dump())) for substanceclass in substanceclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceclass_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substanceclass: {e}")

    @export_file
    async def retrieve(
        self, 
        substanceclass_id: str = None,
        substanceclass_name: str = None,
        #substanceclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.SubstanceClass]:
        filter_list = []
        results_list = []
        if  substanceclass_id is not None:
            try:
                res =  await self.substanceclass_client.Retrieve(
                    lara_django_substances_pb2.SubstanceClassRetrieveRequest(substanceclass_id=substanceclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substanceclass_id: {e}")

        if substanceclass_name is not None:
            filter_list.append({"name": substanceclass_name})
        # if substanceclass_name_full is not None:
        #     filter_list.append({"name_full": substanceclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceclass_client.List(
                        lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.SubstanceClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substanceclass_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substanceclass_name: str = None,
                          substanceclass_name_full: str = None,
                          iri: str = None,) -> str:
        if substanceclass_name is not None:
            filter_dict = {"name": substanceclass_name}
        elif substanceclass_name_full is not None:
            filter_dict = {"name_full": substanceclass_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceclass_client.List(
                    lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substanceclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substanceclass_id
            else:
                raise ValueError(f"Error retrieving substanceclass_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substanceclass_client.List(lara_django_substances_pb2.SubstanceClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceclass_client.List(
                lara_django_substances_pb2.SubstanceClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceclass_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substanceclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceclass_full_client.List(
                lara_django_substances_pb2.SubstanceClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceclass_full_client.List(
                lara_django_substances_pb2.SubstanceClassFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, substanceclass : substances_dm.SubstanceClass = None) -> None:
        try:
            await self.substanceclass_client.Update(
                lara_django_substances_pb2.SubstanceClassRequest(**substanceclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substanceclass_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substanceclass_client.Destroy(lara_django_substances_pb2.SubstanceClassDestroyRequest(substanceclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substanceclass_id: {e}")

#_________________  Isotope  ______________________


class IsotopeInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.isotope_class_client = (
        #     lara_django_substances_pb2_grpc.IsotopeclassByIRIControllerStub(channel)
        # )
        
        self.isotope_client = lara_django_substances_pb2_grpc.IsotopeControllerStub(channel)

        # self.isotope_full_client = lara_django_substances_pb2_grpc.IsotopeFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  isotopes:  list[substances_dm.Isotope] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Isotope]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # isotopeclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if isotope_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.isotope_class_client.Retrieve(
        #         lara_django_substances_pb2.IsotopeclassRetrieveRequest(iri=isotope_class_iri)
        #     )
        #     isotopeclass_id = res.isotopeclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving isotopeclass_id: {e}")
        # for isotope in isotopes:
        #     isotope.namespace = self.namespace_id
        #     isotope.isotope_class = isotopeclass_id

        try:
            create_coroutines = ( self.isotope_client.Create(lara_django_substances_pb2.IsotopeRequest(**isotope.model_dump())) for isotope in isotopes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.isotope_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating isotope: {e}")

    @export_file
    async def retrieve(
        self, 
        isotope_id: str = None,
        isotope_name: str = None,
        #isotope_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Isotope]:
        filter_list = []
        results_list = []
        if  isotope_id is not None:
            try:
                res =  await self.isotope_client.Retrieve(
                    lara_django_substances_pb2.IsotopeRetrieveRequest(isotope_id=isotope_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving isotope_id: {e}")

        if isotope_name is not None:
            filter_list.append({"name": isotope_name})
        # if isotope_name_full is not None:
        #     filter_list.append({"name_full": isotope_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotope_client.List(
                        lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Isotope(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving isotope_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          isotope_name: str = None,
                          isotope_name_full: str = None,
                          iri: str = None,) -> str:
        if isotope_name is not None:
            filter_dict = {"name": isotope_name}
        elif isotope_name_full is not None:
            filter_dict = {"name_full": isotope_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotope_client.List(
                    lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving isotope_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].isotope_id
            else:
                raise ValueError(f"Error retrieving isotope_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.isotope_client.List(lara_django_substances_pb2.IsotopeListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.isotope_client.List(
                lara_django_substances_pb2.IsotopeListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.isotope_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.isotope_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.isotope_full_client.List(
                lara_django_substances_pb2.IsotopeFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.isotope_full_client.List(
                lara_django_substances_pb2.IsotopeFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, isotope : substances_dm.Isotope = None) -> None:
        try:
            await self.isotope_client.Update(
                lara_django_substances_pb2.IsotopeRequest(**isotope.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating isotope_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.isotope_client.Destroy(lara_django_substances_pb2.IsotopeDestroyRequest(isotope_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting isotope_id: {e}")

#_________________  IsotopesSubset  ______________________


class IsotopesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.isotopessubset_class_client = (
        #     lara_django_substances_pb2_grpc.IsotopesSubsetclassByIRIControllerStub(channel)
        # )
        
        self.isotopessubset_client = lara_django_substances_pb2_grpc.IsotopesSubsetControllerStub(channel)

        # self.isotopessubset_full_client = lara_django_substances_pb2_grpc.IsotopesSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  isotopessubsets:  list[substances_dm.IsotopesSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.IsotopesSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # isotopessubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if isotopessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.isotopessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.IsotopesSubsetclassRetrieveRequest(iri=isotopessubset_class_iri)
        #     )
        #     isotopessubsetclass_id = res.isotopessubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving isotopessubsetclass_id: {e}")
        # for isotopessubset in isotopessubsets:
        #     isotopessubset.namespace = self.namespace_id
        #     isotopessubset.isotopessubset_class = isotopessubsetclass_id

        try:
            create_coroutines = ( self.isotopessubset_client.Create(lara_django_substances_pb2.IsotopesSubsetRequest(**isotopessubset.model_dump())) for isotopessubset in isotopessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.isotopessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating isotopessubset: {e}")

    @export_file
    async def retrieve(
        self, 
        isotopessubset_id: str = None,
        isotopessubset_name: str = None,
        #isotopessubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.IsotopesSubset]:
        filter_list = []
        results_list = []
        if  isotopessubset_id is not None:
            try:
                res =  await self.isotopessubset_client.Retrieve(
                    lara_django_substances_pb2.IsotopesSubsetRetrieveRequest(isotopessubset_id=isotopessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving isotopessubset_id: {e}")

        if isotopessubset_name is not None:
            filter_list.append({"name": isotopessubset_name})
        # if isotopessubset_name_full is not None:
        #     filter_list.append({"name_full": isotopessubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotopessubset_client.List(
                        lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.IsotopesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving isotopessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          isotopessubset_name: str = None,
                          isotopessubset_name_full: str = None,
                          iri: str = None,) -> str:
        if isotopessubset_name is not None:
            filter_dict = {"name": isotopessubset_name}
        elif isotopessubset_name_full is not None:
            filter_dict = {"name_full": isotopessubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.isotopessubset_client.List(
                    lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving isotopessubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].isotopessubset_id
            else:
                raise ValueError(f"Error retrieving isotopessubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.isotopessubset_client.List(lara_django_substances_pb2.IsotopesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.isotopessubset_client.List(
                lara_django_substances_pb2.IsotopesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.isotopessubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.isotopessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.isotopessubset_full_client.List(
                lara_django_substances_pb2.IsotopesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.isotopessubset_full_client.List(
                lara_django_substances_pb2.IsotopesSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, isotopessubset : substances_dm.IsotopesSubset = None) -> None:
        try:
            await self.isotopessubset_client.Update(
                lara_django_substances_pb2.IsotopesSubsetRequest(**isotopessubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating isotopessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.isotopessubset_client.Destroy(lara_django_substances_pb2.IsotopesSubsetDestroyRequest(isotopessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting isotopessubset_id: {e}")

#_________________  Substance  ______________________


class SubstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substance_class_client = (
        #     lara_django_substances_pb2_grpc.SubstanceclassByIRIControllerStub(channel)
        # )
        
        self.substance_client = lara_django_substances_pb2_grpc.SubstanceControllerStub(channel)

        # self.substance_full_client = lara_django_substances_pb2_grpc.SubstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substances:  list[substances_dm.Substance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Substance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substance_class_client.Retrieve(
        #         lara_django_substances_pb2.SubstanceclassRetrieveRequest(iri=substance_class_iri)
        #     )
        #     substanceclass_id = res.substanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substanceclass_id: {e}")
        # for substance in substances:
        #     substance.namespace = self.namespace_id
        #     substance.substance_class = substanceclass_id

        try:
            create_coroutines = ( self.substance_client.Create(lara_django_substances_pb2.SubstanceRequest(**substance.model_dump())) for substance in substances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substance: {e}")

    @export_file
    async def retrieve(
        self, 
        substance_id: str = None,
        substance_name: str = None,
        #substance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Substance]:
        filter_list = []
        results_list = []
        if  substance_id is not None:
            try:
                res =  await self.substance_client.Retrieve(
                    lara_django_substances_pb2.SubstanceRetrieveRequest(substance_id=substance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substance_id: {e}")

        if substance_name is not None:
            filter_list.append({"name": substance_name})
        # if substance_name_full is not None:
        #     filter_list.append({"name_full": substance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substance_client.List(
                        lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Substance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substance_name: str = None,
                          substance_name_full: str = None,
                          iri: str = None,) -> str:
        if substance_name is not None:
            filter_dict = {"name": substance_name}
        elif substance_name_full is not None:
            filter_dict = {"name_full": substance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substance_client.List(
                    lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substance_id
            else:
                raise ValueError(f"Error retrieving substance_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substance_client.List(lara_django_substances_pb2.SubstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substance_client.List(
                lara_django_substances_pb2.SubstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substance_full_client.List(
                lara_django_substances_pb2.SubstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substance_full_client.List(
                lara_django_substances_pb2.SubstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, substance : substances_dm.Substance = None) -> None:
        try:
            await self.substance_client.Update(
                lara_django_substances_pb2.SubstanceRequest(**substance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substance_client.Destroy(lara_django_substances_pb2.SubstanceDestroyRequest(substance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substance_id: {e}")

#_________________  SubstancesSubset  ______________________


class SubstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substancessubset_class_client = (
        #     lara_django_substances_pb2_grpc.SubstancesSubsetclassByIRIControllerStub(channel)
        # )
        
        self.substancessubset_client = lara_django_substances_pb2_grpc.SubstancesSubsetControllerStub(channel)

        # self.substancessubset_full_client = lara_django_substances_pb2_grpc.SubstancesSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substancessubsets:  list[substances_dm.SubstancesSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.SubstancesSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substancessubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.SubstancesSubsetclassRetrieveRequest(iri=substancessubset_class_iri)
        #     )
        #     substancessubsetclass_id = res.substancessubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substancessubsetclass_id: {e}")
        # for substancessubset in substancessubsets:
        #     substancessubset.namespace = self.namespace_id
        #     substancessubset.substancessubset_class = substancessubsetclass_id

        try:
            create_coroutines = ( self.substancessubset_client.Create(lara_django_substances_pb2.SubstancesSubsetRequest(**substancessubset.model_dump())) for substancessubset in substancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substancessubset: {e}")

    @export_file
    async def retrieve(
        self, 
        substancessubset_id: str = None,
        substancessubset_name: str = None,
        #substancessubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.SubstancesSubset]:
        filter_list = []
        results_list = []
        if  substancessubset_id is not None:
            try:
                res =  await self.substancessubset_client.Retrieve(
                    lara_django_substances_pb2.SubstancesSubsetRetrieveRequest(substancessubset_id=substancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substancessubset_id: {e}")

        if substancessubset_name is not None:
            filter_list.append({"name": substancessubset_name})
        # if substancessubset_name_full is not None:
        #     filter_list.append({"name_full": substancessubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancessubset_client.List(
                        lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.SubstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substancessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substancessubset_name: str = None,
                          substancessubset_name_full: str = None,
                          iri: str = None,) -> str:
        if substancessubset_name is not None:
            filter_dict = {"name": substancessubset_name}
        elif substancessubset_name_full is not None:
            filter_dict = {"name_full": substancessubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancessubset_client.List(
                    lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substancessubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substancessubset_id
            else:
                raise ValueError(f"Error retrieving substancessubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substancessubset_client.List(lara_django_substances_pb2.SubstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancessubset_client.List(
                lara_django_substances_pb2.SubstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancessubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancessubset_full_client.List(
                lara_django_substances_pb2.SubstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancessubset_full_client.List(
                lara_django_substances_pb2.SubstancesSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, substancessubset : substances_dm.SubstancesSubset = None) -> None:
        try:
            await self.substancessubset_client.Update(
                lara_django_substances_pb2.SubstancesSubsetRequest(**substancessubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substancessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substancessubset_client.Destroy(lara_django_substances_pb2.SubstancesSubsetDestroyRequest(substancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substancessubset_id: {e}")

#_________________  Polymer  ______________________


class PolymerInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymer_class_client = (
        #     lara_django_substances_pb2_grpc.PolymerclassByIRIControllerStub(channel)
        # )
        
        self.polymer_client = lara_django_substances_pb2_grpc.PolymerControllerStub(channel)

        # self.polymer_full_client = lara_django_substances_pb2_grpc.PolymerFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymers:  list[substances_dm.Polymer] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Polymer]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymer_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymer_class_client.Retrieve(
        #         lara_django_substances_pb2.PolymerclassRetrieveRequest(iri=polymer_class_iri)
        #     )
        #     polymerclass_id = res.polymerclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerclass_id: {e}")
        # for polymer in polymers:
        #     polymer.namespace = self.namespace_id
        #     polymer.polymer_class = polymerclass_id

        try:
            create_coroutines = ( self.polymer_client.Create(lara_django_substances_pb2.PolymerRequest(**polymer.model_dump())) for polymer in polymers )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymer_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymer: {e}")

    @export_file
    async def retrieve(
        self, 
        polymer_id: str = None,
        polymer_name: str = None,
        #polymer_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Polymer]:
        filter_list = []
        results_list = []
        if  polymer_id is not None:
            try:
                res =  await self.polymer_client.Retrieve(
                    lara_django_substances_pb2.PolymerRetrieveRequest(polymer_id=polymer_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymer_id: {e}")

        if polymer_name is not None:
            filter_list.append({"name": polymer_name})
        # if polymer_name_full is not None:
        #     filter_list.append({"name_full": polymer_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymer_client.List(
                        lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Polymer(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymer_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymer_name: str = None,
                          polymer_name_full: str = None,
                          iri: str = None,) -> str:
        if polymer_name is not None:
            filter_dict = {"name": polymer_name}
        elif polymer_name_full is not None:
            filter_dict = {"name_full": polymer_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymer_client.List(
                    lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymer_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymer_id
            else:
                raise ValueError(f"Error retrieving polymer_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymer_client.List(lara_django_substances_pb2.PolymerListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymer_client.List(
                lara_django_substances_pb2.PolymerListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymer_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymer_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymer_full_client.List(
                lara_django_substances_pb2.PolymerFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymer_full_client.List(
                lara_django_substances_pb2.PolymerFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, polymer : substances_dm.Polymer = None) -> None:
        try:
            await self.polymer_client.Update(
                lara_django_substances_pb2.PolymerRequest(**polymer.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymer_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymer_client.Destroy(lara_django_substances_pb2.PolymerDestroyRequest(polymer_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymer_id: {e}")

#_________________  PolymersSubset  ______________________


class PolymersSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerssubset_class_client = (
        #     lara_django_substances_pb2_grpc.PolymersSubsetclassByIRIControllerStub(channel)
        # )
        
        self.polymerssubset_client = lara_django_substances_pb2_grpc.PolymersSubsetControllerStub(channel)

        # self.polymerssubset_full_client = lara_django_substances_pb2_grpc.PolymersSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerssubsets:  list[substances_dm.PolymersSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.PolymersSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerssubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.PolymersSubsetclassRetrieveRequest(iri=polymerssubset_class_iri)
        #     )
        #     polymerssubsetclass_id = res.polymerssubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerssubsetclass_id: {e}")
        # for polymerssubset in polymerssubsets:
        #     polymerssubset.namespace = self.namespace_id
        #     polymerssubset.polymerssubset_class = polymerssubsetclass_id

        try:
            create_coroutines = ( self.polymerssubset_client.Create(lara_django_substances_pb2.PolymersSubsetRequest(**polymerssubset.model_dump())) for polymerssubset in polymerssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerssubset: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerssubset_id: str = None,
        polymerssubset_name: str = None,
        #polymerssubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.PolymersSubset]:
        filter_list = []
        results_list = []
        if  polymerssubset_id is not None:
            try:
                res =  await self.polymerssubset_client.Retrieve(
                    lara_django_substances_pb2.PolymersSubsetRetrieveRequest(polymerssubset_id=polymerssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerssubset_id: {e}")

        if polymerssubset_name is not None:
            filter_list.append({"name": polymerssubset_name})
        # if polymerssubset_name_full is not None:
        #     filter_list.append({"name_full": polymerssubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerssubset_client.List(
                        lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.PolymersSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerssubset_name: str = None,
                          polymerssubset_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerssubset_name is not None:
            filter_dict = {"name": polymerssubset_name}
        elif polymerssubset_name_full is not None:
            filter_dict = {"name_full": polymerssubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerssubset_client.List(
                    lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerssubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerssubset_id
            else:
                raise ValueError(f"Error retrieving polymerssubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerssubset_client.List(lara_django_substances_pb2.PolymersSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerssubset_client.List(
                lara_django_substances_pb2.PolymersSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerssubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerssubset_full_client.List(
                lara_django_substances_pb2.PolymersSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerssubset_full_client.List(
                lara_django_substances_pb2.PolymersSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, polymerssubset : substances_dm.PolymersSubset = None) -> None:
        try:
            await self.polymerssubset_client.Update(
                lara_django_substances_pb2.PolymersSubsetRequest(**polymerssubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerssubset_client.Destroy(lara_django_substances_pb2.PolymersSubsetDestroyRequest(polymerssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerssubset_id: {e}")

#_________________  MixtureComponent  ______________________


class MixtureComponentInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturecomponent_class_client = (
        #     lara_django_substances_pb2_grpc.MixtureComponentclassByIRIControllerStub(channel)
        # )
        
        self.mixturecomponent_client = lara_django_substances_pb2_grpc.MixtureComponentControllerStub(channel)

        # self.mixturecomponent_full_client = lara_django_substances_pb2_grpc.MixtureComponentFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturecomponents:  list[substances_dm.MixtureComponent] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.MixtureComponent]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturecomponentclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturecomponent_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturecomponent_class_client.Retrieve(
        #         lara_django_substances_pb2.MixtureComponentclassRetrieveRequest(iri=mixturecomponent_class_iri)
        #     )
        #     mixturecomponentclass_id = res.mixturecomponentclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturecomponentclass_id: {e}")
        # for mixturecomponent in mixturecomponents:
        #     mixturecomponent.namespace = self.namespace_id
        #     mixturecomponent.mixturecomponent_class = mixturecomponentclass_id

        try:
            create_coroutines = ( self.mixturecomponent_client.Create(lara_django_substances_pb2.MixtureComponentRequest(**mixturecomponent.model_dump())) for mixturecomponent in mixturecomponents )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturecomponent_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturecomponent: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturecomponent_id: str = None,
        mixturecomponent_name: str = None,
        #mixturecomponent_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MixtureComponent]:
        filter_list = []
        results_list = []
        if  mixturecomponent_id is not None:
            try:
                res =  await self.mixturecomponent_client.Retrieve(
                    lara_django_substances_pb2.MixtureComponentRetrieveRequest(mixturecomponent_id=mixturecomponent_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponent_id: {e}")

        if mixturecomponent_name is not None:
            filter_list.append({"name": mixturecomponent_name})
        # if mixturecomponent_name_full is not None:
        #     filter_list.append({"name_full": mixturecomponent_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturecomponent_client.List(
                        lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MixtureComponent(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponent_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturecomponent_name: str = None,
                          mixturecomponent_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturecomponent_name is not None:
            filter_dict = {"name": mixturecomponent_name}
        elif mixturecomponent_name_full is not None:
            filter_dict = {"name_full": mixturecomponent_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturecomponent_client.List(
                    lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponent_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturecomponent_id
            else:
                raise ValueError(f"Error retrieving mixturecomponent_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturecomponent_client.List(lara_django_substances_pb2.MixtureComponentListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturecomponent_client.List(
                lara_django_substances_pb2.MixtureComponentListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturecomponent_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturecomponent_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturecomponent_full_client.List(
                lara_django_substances_pb2.MixtureComponentFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturecomponent_full_client.List(
                lara_django_substances_pb2.MixtureComponentFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, mixturecomponent : substances_dm.MixtureComponent = None) -> None:
        try:
            await self.mixturecomponent_client.Update(
                lara_django_substances_pb2.MixtureComponentRequest(**mixturecomponent.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturecomponent_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturecomponent_client.Destroy(lara_django_substances_pb2.MixtureComponentDestroyRequest(mixturecomponent_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturecomponent_id: {e}")

#_________________  Mixture  ______________________


class MixtureInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixture_class_client = (
        #     lara_django_substances_pb2_grpc.MixtureclassByIRIControllerStub(channel)
        # )
        
        self.mixture_client = lara_django_substances_pb2_grpc.MixtureControllerStub(channel)

        # self.mixture_full_client = lara_django_substances_pb2_grpc.MixtureFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixtures:  list[substances_dm.Mixture] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Mixture]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixtureclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixture_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixture_class_client.Retrieve(
        #         lara_django_substances_pb2.MixtureclassRetrieveRequest(iri=mixture_class_iri)
        #     )
        #     mixtureclass_id = res.mixtureclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixtureclass_id: {e}")
        # for mixture in mixtures:
        #     mixture.namespace = self.namespace_id
        #     mixture.mixture_class = mixtureclass_id

        try:
            create_coroutines = ( self.mixture_client.Create(lara_django_substances_pb2.MixtureRequest(**mixture.model_dump())) for mixture in mixtures )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixture_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixture: {e}")

    @export_file
    async def retrieve(
        self, 
        mixture_id: str = None,
        mixture_name: str = None,
        #mixture_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Mixture]:
        filter_list = []
        results_list = []
        if  mixture_id is not None:
            try:
                res =  await self.mixture_client.Retrieve(
                    lara_django_substances_pb2.MixtureRetrieveRequest(mixture_id=mixture_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixture_id: {e}")

        if mixture_name is not None:
            filter_list.append({"name": mixture_name})
        # if mixture_name_full is not None:
        #     filter_list.append({"name_full": mixture_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixture_client.List(
                        lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Mixture(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixture_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixture_name: str = None,
                          mixture_name_full: str = None,
                          iri: str = None,) -> str:
        if mixture_name is not None:
            filter_dict = {"name": mixture_name}
        elif mixture_name_full is not None:
            filter_dict = {"name_full": mixture_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixture_client.List(
                    lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixture_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixture_id
            else:
                raise ValueError(f"Error retrieving mixture_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixture_client.List(lara_django_substances_pb2.MixtureListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixture_client.List(
                lara_django_substances_pb2.MixtureListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixture_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixture_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixture_full_client.List(
                lara_django_substances_pb2.MixtureFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixture_full_client.List(
                lara_django_substances_pb2.MixtureFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, mixture : substances_dm.Mixture = None) -> None:
        try:
            await self.mixture_client.Update(
                lara_django_substances_pb2.MixtureRequest(**mixture.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixture_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixture_client.Destroy(lara_django_substances_pb2.MixtureDestroyRequest(mixture_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixture_id: {e}")

#_________________  MixturesSubset  ______________________


class MixturesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturessubset_class_client = (
        #     lara_django_substances_pb2_grpc.MixturesSubsetclassByIRIControllerStub(channel)
        # )
        
        self.mixturessubset_client = lara_django_substances_pb2_grpc.MixturesSubsetControllerStub(channel)

        # self.mixturessubset_full_client = lara_django_substances_pb2_grpc.MixturesSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturessubsets:  list[substances_dm.MixturesSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.MixturesSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturessubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturessubset_class_client.Retrieve(
        #         lara_django_substances_pb2.MixturesSubsetclassRetrieveRequest(iri=mixturessubset_class_iri)
        #     )
        #     mixturessubsetclass_id = res.mixturessubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturessubsetclass_id: {e}")
        # for mixturessubset in mixturessubsets:
        #     mixturessubset.namespace = self.namespace_id
        #     mixturessubset.mixturessubset_class = mixturessubsetclass_id

        try:
            create_coroutines = ( self.mixturessubset_client.Create(lara_django_substances_pb2.MixturesSubsetRequest(**mixturessubset.model_dump())) for mixturessubset in mixturessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturessubset: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturessubset_id: str = None,
        mixturessubset_name: str = None,
        #mixturessubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MixturesSubset]:
        filter_list = []
        results_list = []
        if  mixturessubset_id is not None:
            try:
                res =  await self.mixturessubset_client.Retrieve(
                    lara_django_substances_pb2.MixturesSubsetRetrieveRequest(mixturessubset_id=mixturessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturessubset_id: {e}")

        if mixturessubset_name is not None:
            filter_list.append({"name": mixturessubset_name})
        # if mixturessubset_name_full is not None:
        #     filter_list.append({"name_full": mixturessubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturessubset_client.List(
                        lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MixturesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturessubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturessubset_name: str = None,
                          mixturessubset_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturessubset_name is not None:
            filter_dict = {"name": mixturessubset_name}
        elif mixturessubset_name_full is not None:
            filter_dict = {"name_full": mixturessubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturessubset_client.List(
                    lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturessubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturessubset_id
            else:
                raise ValueError(f"Error retrieving mixturessubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturessubset_client.List(lara_django_substances_pb2.MixturesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturessubset_client.List(
                lara_django_substances_pb2.MixturesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturessubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturessubset_full_client.List(
                lara_django_substances_pb2.MixturesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturessubset_full_client.List(
                lara_django_substances_pb2.MixturesSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, mixturessubset : substances_dm.MixturesSubset = None) -> None:
        try:
            await self.mixturessubset_client.Update(
                lara_django_substances_pb2.MixturesSubsetRequest(**mixturessubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturessubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturessubset_client.Destroy(lara_django_substances_pb2.MixturesSubsetDestroyRequest(mixturessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturessubset_id: {e}")

#_________________  MoleculeResidue  ______________________


class MoleculeResidueInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.moleculeresidue_class_client = (
        #     lara_django_substances_pb2_grpc.MoleculeResidueclassByIRIControllerStub(channel)
        # )
        
        self.moleculeresidue_client = lara_django_substances_pb2_grpc.MoleculeResidueControllerStub(channel)

        # self.moleculeresidue_full_client = lara_django_substances_pb2_grpc.MoleculeResidueFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  moleculeresidues:  list[substances_dm.MoleculeResidue] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.MoleculeResidue]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # moleculeresidueclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if moleculeresidue_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.moleculeresidue_class_client.Retrieve(
        #         lara_django_substances_pb2.MoleculeResidueclassRetrieveRequest(iri=moleculeresidue_class_iri)
        #     )
        #     moleculeresidueclass_id = res.moleculeresidueclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving moleculeresidueclass_id: {e}")
        # for moleculeresidue in moleculeresidues:
        #     moleculeresidue.namespace = self.namespace_id
        #     moleculeresidue.moleculeresidue_class = moleculeresidueclass_id

        try:
            create_coroutines = ( self.moleculeresidue_client.Create(lara_django_substances_pb2.MoleculeResidueRequest(**moleculeresidue.model_dump())) for moleculeresidue in moleculeresidues )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.moleculeresidue_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating moleculeresidue: {e}")

    @export_file
    async def retrieve(
        self, 
        moleculeresidue_id: str = None,
        moleculeresidue_name: str = None,
        #moleculeresidue_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MoleculeResidue]:
        filter_list = []
        results_list = []
        if  moleculeresidue_id is not None:
            try:
                res =  await self.moleculeresidue_client.Retrieve(
                    lara_django_substances_pb2.MoleculeResidueRetrieveRequest(moleculeresidue_id=moleculeresidue_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving moleculeresidue_id: {e}")

        if moleculeresidue_name is not None:
            filter_list.append({"name": moleculeresidue_name})
        # if moleculeresidue_name_full is not None:
        #     filter_list.append({"name_full": moleculeresidue_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.moleculeresidue_client.List(
                        lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MoleculeResidue(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving moleculeresidue_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          moleculeresidue_name: str = None,
                          moleculeresidue_name_full: str = None,
                          iri: str = None,) -> str:
        if moleculeresidue_name is not None:
            filter_dict = {"name": moleculeresidue_name}
        elif moleculeresidue_name_full is not None:
            filter_dict = {"name_full": moleculeresidue_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.moleculeresidue_client.List(
                    lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving moleculeresidue_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].moleculeresidue_id
            else:
                raise ValueError(f"Error retrieving moleculeresidue_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.moleculeresidue_client.List(lara_django_substances_pb2.MoleculeResidueListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.moleculeresidue_client.List(
                lara_django_substances_pb2.MoleculeResidueListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.moleculeresidue_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.moleculeresidue_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.moleculeresidue_full_client.List(
                lara_django_substances_pb2.MoleculeResidueFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.moleculeresidue_full_client.List(
                lara_django_substances_pb2.MoleculeResidueFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, moleculeresidue : substances_dm.MoleculeResidue = None) -> None:
        try:
            await self.moleculeresidue_client.Update(
                lara_django_substances_pb2.MoleculeResidueRequest(**moleculeresidue.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating moleculeresidue_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.moleculeresidue_client.Destroy(lara_django_substances_pb2.MoleculeResidueDestroyRequest(moleculeresidue_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting moleculeresidue_id: {e}")

#_________________  Reactant  ______________________


class ReactantInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reactant_class_client = (
        #     lara_django_substances_pb2_grpc.ReactantclassByIRIControllerStub(channel)
        # )
        
        self.reactant_client = lara_django_substances_pb2_grpc.ReactantControllerStub(channel)

        # self.reactant_full_client = lara_django_substances_pb2_grpc.ReactantFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  reactants:  list[substances_dm.Reactant] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Reactant]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # reactantclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactant_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactant_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactantclassRetrieveRequest(iri=reactant_class_iri)
        #     )
        #     reactantclass_id = res.reactantclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving reactantclass_id: {e}")
        # for reactant in reactants:
        #     reactant.namespace = self.namespace_id
        #     reactant.reactant_class = reactantclass_id

        try:
            create_coroutines = ( self.reactant_client.Create(lara_django_substances_pb2.ReactantRequest(**reactant.model_dump())) for reactant in reactants )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactant_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating reactant: {e}")

    @export_file
    async def retrieve(
        self, 
        reactant_id: str = None,
        reactant_name: str = None,
        #reactant_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Reactant]:
        filter_list = []
        results_list = []
        if  reactant_id is not None:
            try:
                res =  await self.reactant_client.Retrieve(
                    lara_django_substances_pb2.ReactantRetrieveRequest(reactant_id=reactant_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving reactant_id: {e}")

        if reactant_name is not None:
            filter_list.append({"name": reactant_name})
        # if reactant_name_full is not None:
        #     filter_list.append({"name_full": reactant_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactant_client.List(
                        lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Reactant(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving reactant_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          reactant_name: str = None,
                          reactant_name_full: str = None,
                          iri: str = None,) -> str:
        if reactant_name is not None:
            filter_dict = {"name": reactant_name}
        elif reactant_name_full is not None:
            filter_dict = {"name_full": reactant_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactant_client.List(
                    lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving reactant_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].reactant_id
            else:
                raise ValueError(f"Error retrieving reactant_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.reactant_client.List(lara_django_substances_pb2.ReactantListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactant_client.List(
                lara_django_substances_pb2.ReactantListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactant_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.reactant_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactant_full_client.List(
                lara_django_substances_pb2.ReactantFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactant_full_client.List(
                lara_django_substances_pb2.ReactantFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, reactant : substances_dm.Reactant = None) -> None:
        try:
            await self.reactant_client.Update(
                lara_django_substances_pb2.ReactantRequest(**reactant.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating reactant_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.reactant_client.Destroy(lara_django_substances_pb2.ReactantDestroyRequest(reactant_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting reactant_id: {e}")

#_________________  ReactantsSubset  ______________________


class ReactantsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reactantssubset_class_client = (
        #     lara_django_substances_pb2_grpc.ReactantsSubsetclassByIRIControllerStub(channel)
        # )
        
        self.reactantssubset_client = lara_django_substances_pb2_grpc.ReactantsSubsetControllerStub(channel)

        # self.reactantssubset_full_client = lara_django_substances_pb2_grpc.ReactantsSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  reactantssubsets:  list[substances_dm.ReactantsSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.ReactantsSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # reactantssubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactantssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactantssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactantsSubsetclassRetrieveRequest(iri=reactantssubset_class_iri)
        #     )
        #     reactantssubsetclass_id = res.reactantssubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving reactantssubsetclass_id: {e}")
        # for reactantssubset in reactantssubsets:
        #     reactantssubset.namespace = self.namespace_id
        #     reactantssubset.reactantssubset_class = reactantssubsetclass_id

        try:
            create_coroutines = ( self.reactantssubset_client.Create(lara_django_substances_pb2.ReactantsSubsetRequest(**reactantssubset.model_dump())) for reactantssubset in reactantssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactantssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating reactantssubset: {e}")

    @export_file
    async def retrieve(
        self, 
        reactantssubset_id: str = None,
        reactantssubset_name: str = None,
        #reactantssubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ReactantsSubset]:
        filter_list = []
        results_list = []
        if  reactantssubset_id is not None:
            try:
                res =  await self.reactantssubset_client.Retrieve(
                    lara_django_substances_pb2.ReactantsSubsetRetrieveRequest(reactantssubset_id=reactantssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving reactantssubset_id: {e}")

        if reactantssubset_name is not None:
            filter_list.append({"name": reactantssubset_name})
        # if reactantssubset_name_full is not None:
        #     filter_list.append({"name_full": reactantssubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactantssubset_client.List(
                        lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ReactantsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving reactantssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          reactantssubset_name: str = None,
                          reactantssubset_name_full: str = None,
                          iri: str = None,) -> str:
        if reactantssubset_name is not None:
            filter_dict = {"name": reactantssubset_name}
        elif reactantssubset_name_full is not None:
            filter_dict = {"name_full": reactantssubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactantssubset_client.List(
                    lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving reactantssubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].reactantssubset_id
            else:
                raise ValueError(f"Error retrieving reactantssubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.reactantssubset_client.List(lara_django_substances_pb2.ReactantsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactantssubset_client.List(
                lara_django_substances_pb2.ReactantsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactantssubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.reactantssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactantssubset_full_client.List(
                lara_django_substances_pb2.ReactantsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactantssubset_full_client.List(
                lara_django_substances_pb2.ReactantsSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, reactantssubset : substances_dm.ReactantsSubset = None) -> None:
        try:
            await self.reactantssubset_client.Update(
                lara_django_substances_pb2.ReactantsSubsetRequest(**reactantssubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating reactantssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.reactantssubset_client.Destroy(lara_django_substances_pb2.ReactantsSubsetDestroyRequest(reactantssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting reactantssubset_id: {e}")

#_________________  Reaction  ______________________


class ReactionInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reaction_class_client = (
        #     lara_django_substances_pb2_grpc.ReactionclassByIRIControllerStub(channel)
        # )
        
        self.reaction_client = lara_django_substances_pb2_grpc.ReactionControllerStub(channel)

        # self.reaction_full_client = lara_django_substances_pb2_grpc.ReactionFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  reactions:  list[substances_dm.Reaction] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.Reaction]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # reactionclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reaction_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reaction_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactionclassRetrieveRequest(iri=reaction_class_iri)
        #     )
        #     reactionclass_id = res.reactionclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving reactionclass_id: {e}")
        # for reaction in reactions:
        #     reaction.namespace = self.namespace_id
        #     reaction.reaction_class = reactionclass_id

        try:
            create_coroutines = ( self.reaction_client.Create(lara_django_substances_pb2.ReactionRequest(**reaction.model_dump())) for reaction in reactions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reaction_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating reaction: {e}")

    @export_file
    async def retrieve(
        self, 
        reaction_id: str = None,
        reaction_name: str = None,
        #reaction_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.Reaction]:
        filter_list = []
        results_list = []
        if  reaction_id is not None:
            try:
                res =  await self.reaction_client.Retrieve(
                    lara_django_substances_pb2.ReactionRetrieveRequest(reaction_id=reaction_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving reaction_id: {e}")

        if reaction_name is not None:
            filter_list.append({"name": reaction_name})
        # if reaction_name_full is not None:
        #     filter_list.append({"name_full": reaction_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reaction_client.List(
                        lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.Reaction(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving reaction_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          reaction_name: str = None,
                          reaction_name_full: str = None,
                          iri: str = None,) -> str:
        if reaction_name is not None:
            filter_dict = {"name": reaction_name}
        elif reaction_name_full is not None:
            filter_dict = {"name_full": reaction_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reaction_client.List(
                    lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving reaction_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].reaction_id
            else:
                raise ValueError(f"Error retrieving reaction_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.reaction_client.List(lara_django_substances_pb2.ReactionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reaction_client.List(
                lara_django_substances_pb2.ReactionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reaction_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.reaction_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reaction_full_client.List(
                lara_django_substances_pb2.ReactionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reaction_full_client.List(
                lara_django_substances_pb2.ReactionFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, reaction : substances_dm.Reaction = None) -> None:
        try:
            await self.reaction_client.Update(
                lara_django_substances_pb2.ReactionRequest(**reaction.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating reaction_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.reaction_client.Destroy(lara_django_substances_pb2.ReactionDestroyRequest(reaction_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting reaction_id: {e}")

#_________________  ReactionsSubset  ______________________


class ReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.reactionssubset_class_client = (
        #     lara_django_substances_pb2_grpc.ReactionsSubsetclassByIRIControllerStub(channel)
        # )
        
        self.reactionssubset_client = lara_django_substances_pb2_grpc.ReactionsSubsetControllerStub(channel)

        # self.reactionssubset_full_client = lara_django_substances_pb2_grpc.ReactionsSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  reactionssubsets:  list[substances_dm.ReactionsSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.ReactionsSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # reactionssubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactionssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactionssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.ReactionsSubsetclassRetrieveRequest(iri=reactionssubset_class_iri)
        #     )
        #     reactionssubsetclass_id = res.reactionssubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving reactionssubsetclass_id: {e}")
        # for reactionssubset in reactionssubsets:
        #     reactionssubset.namespace = self.namespace_id
        #     reactionssubset.reactionssubset_class = reactionssubsetclass_id

        try:
            create_coroutines = ( self.reactionssubset_client.Create(lara_django_substances_pb2.ReactionsSubsetRequest(**reactionssubset.model_dump())) for reactionssubset in reactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating reactionssubset: {e}")

    @export_file
    async def retrieve(
        self, 
        reactionssubset_id: str = None,
        reactionssubset_name: str = None,
        #reactionssubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.ReactionsSubset]:
        filter_list = []
        results_list = []
        if  reactionssubset_id is not None:
            try:
                res =  await self.reactionssubset_client.Retrieve(
                    lara_django_substances_pb2.ReactionsSubsetRetrieveRequest(reactionssubset_id=reactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving reactionssubset_id: {e}")

        if reactionssubset_name is not None:
            filter_list.append({"name": reactionssubset_name})
        # if reactionssubset_name_full is not None:
        #     filter_list.append({"name_full": reactionssubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactionssubset_client.List(
                        lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.ReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving reactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          reactionssubset_name: str = None,
                          reactionssubset_name_full: str = None,
                          iri: str = None,) -> str:
        if reactionssubset_name is not None:
            filter_dict = {"name": reactionssubset_name}
        elif reactionssubset_name_full is not None:
            filter_dict = {"name_full": reactionssubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.reactionssubset_client.List(
                    lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving reactionssubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].reactionssubset_id
            else:
                raise ValueError(f"Error retrieving reactionssubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.reactionssubset_client.List(lara_django_substances_pb2.ReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactionssubset_client.List(
                lara_django_substances_pb2.ReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactionssubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.reactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactionssubset_full_client.List(
                lara_django_substances_pb2.ReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactionssubset_full_client.List(
                lara_django_substances_pb2.ReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, reactionssubset : substances_dm.ReactionsSubset = None) -> None:
        try:
            await self.reactionssubset_client.Update(
                lara_django_substances_pb2.ReactionsSubsetRequest(**reactionssubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating reactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.reactionssubset_client.Destroy(lara_django_substances_pb2.ReactionsSubsetDestroyRequest(reactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting reactionssubset_id: {e}")

#_________________  MultiStepReaction  ______________________


class MultiStepReactionInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.multistepreaction_class_client = (
        #     lara_django_substances_pb2_grpc.MultiStepReactionclassByIRIControllerStub(channel)
        # )
        
        self.multistepreaction_client = lara_django_substances_pb2_grpc.MultiStepReactionControllerStub(channel)

        # self.multistepreaction_full_client = lara_django_substances_pb2_grpc.MultiStepReactionFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  multistepreactions:  list[substances_dm.MultiStepReaction] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.MultiStepReaction]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # multistepreactionclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if multistepreaction_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.multistepreaction_class_client.Retrieve(
        #         lara_django_substances_pb2.MultiStepReactionclassRetrieveRequest(iri=multistepreaction_class_iri)
        #     )
        #     multistepreactionclass_id = res.multistepreactionclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving multistepreactionclass_id: {e}")
        # for multistepreaction in multistepreactions:
        #     multistepreaction.namespace = self.namespace_id
        #     multistepreaction.multistepreaction_class = multistepreactionclass_id

        try:
            create_coroutines = ( self.multistepreaction_client.Create(lara_django_substances_pb2.MultiStepReactionRequest(**multistepreaction.model_dump())) for multistepreaction in multistepreactions )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.multistepreaction_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating multistepreaction: {e}")

    @export_file
    async def retrieve(
        self, 
        multistepreaction_id: str = None,
        multistepreaction_name: str = None,
        #multistepreaction_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MultiStepReaction]:
        filter_list = []
        results_list = []
        if  multistepreaction_id is not None:
            try:
                res =  await self.multistepreaction_client.Retrieve(
                    lara_django_substances_pb2.MultiStepReactionRetrieveRequest(multistepreaction_id=multistepreaction_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving multistepreaction_id: {e}")

        if multistepreaction_name is not None:
            filter_list.append({"name": multistepreaction_name})
        # if multistepreaction_name_full is not None:
        #     filter_list.append({"name_full": multistepreaction_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreaction_client.List(
                        lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MultiStepReaction(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving multistepreaction_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          multistepreaction_name: str = None,
                          multistepreaction_name_full: str = None,
                          iri: str = None,) -> str:
        if multistepreaction_name is not None:
            filter_dict = {"name": multistepreaction_name}
        elif multistepreaction_name_full is not None:
            filter_dict = {"name_full": multistepreaction_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreaction_client.List(
                    lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving multistepreaction_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].multistepreaction_id
            else:
                raise ValueError(f"Error retrieving multistepreaction_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.multistepreaction_client.List(lara_django_substances_pb2.MultiStepReactionListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreaction_client.List(
                lara_django_substances_pb2.MultiStepReactionListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreaction_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.multistepreaction_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreaction_full_client.List(
                lara_django_substances_pb2.MultiStepReactionFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreaction_full_client.List(
                lara_django_substances_pb2.MultiStepReactionFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, multistepreaction : substances_dm.MultiStepReaction = None) -> None:
        try:
            await self.multistepreaction_client.Update(
                lara_django_substances_pb2.MultiStepReactionRequest(**multistepreaction.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating multistepreaction_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.multistepreaction_client.Destroy(lara_django_substances_pb2.MultiStepReactionDestroyRequest(multistepreaction_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting multistepreaction_id: {e}")

#_________________  MultiStepReactionsSubset  ______________________


class MultiStepReactionsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.multistepreactionssubset_class_client = (
        #     lara_django_substances_pb2_grpc.MultiStepReactionsSubsetclassByIRIControllerStub(channel)
        # )
        
        self.multistepreactionssubset_client = lara_django_substances_pb2_grpc.MultiStepReactionsSubsetControllerStub(channel)

        # self.multistepreactionssubset_full_client = lara_django_substances_pb2_grpc.MultiStepReactionsSubsetFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  multistepreactionssubsets:  list[substances_dm.MultiStepReactionsSubset] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_dm.MultiStepReactionsSubset]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # multistepreactionssubsetclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if multistepreactionssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.multistepreactionssubset_class_client.Retrieve(
        #         lara_django_substances_pb2.MultiStepReactionsSubsetclassRetrieveRequest(iri=multistepreactionssubset_class_iri)
        #     )
        #     multistepreactionssubsetclass_id = res.multistepreactionssubsetclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving multistepreactionssubsetclass_id: {e}")
        # for multistepreactionssubset in multistepreactionssubsets:
        #     multistepreactionssubset.namespace = self.namespace_id
        #     multistepreactionssubset.multistepreactionssubset_class = multistepreactionssubsetclass_id

        try:
            create_coroutines = ( self.multistepreactionssubset_client.Create(lara_django_substances_pb2.MultiStepReactionsSubsetRequest(**multistepreactionssubset.model_dump())) for multistepreactionssubset in multistepreactionssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.multistepreactionssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating multistepreactionssubset: {e}")

    @export_file
    async def retrieve(
        self, 
        multistepreactionssubset_id: str = None,
        multistepreactionssubset_name: str = None,
        #multistepreactionssubset_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_dm.MultiStepReactionsSubset]:
        filter_list = []
        results_list = []
        if  multistepreactionssubset_id is not None:
            try:
                res =  await self.multistepreactionssubset_client.Retrieve(
                    lara_django_substances_pb2.MultiStepReactionsSubsetRetrieveRequest(multistepreactionssubset_id=multistepreactionssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving multistepreactionssubset_id: {e}")

        if multistepreactionssubset_name is not None:
            filter_list.append({"name": multistepreactionssubset_name})
        # if multistepreactionssubset_name_full is not None:
        #     filter_list.append({"name_full": multistepreactionssubset_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreactionssubset_client.List(
                        lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_dm.MultiStepReactionsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving multistepreactionssubset_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          multistepreactionssubset_name: str = None,
                          multistepreactionssubset_name_full: str = None,
                          iri: str = None,) -> str:
        if multistepreactionssubset_name is not None:
            filter_dict = {"name": multistepreactionssubset_name}
        elif multistepreactionssubset_name_full is not None:
            filter_dict = {"name_full": multistepreactionssubset_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.multistepreactionssubset_client.List(
                    lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving multistepreactionssubset_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].multistepreactionssubset_id
            else:
                raise ValueError(f"Error retrieving multistepreactionssubset_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.multistepreactionssubset_client.List(lara_django_substances_pb2.MultiStepReactionsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreactionssubset_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreactionssubset_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.multistepreactionssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreactionssubset_full_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreactionssubset_full_client.List(
                lara_django_substances_pb2.MultiStepReactionsSubsetFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, multistepreactionssubset : substances_dm.MultiStepReactionsSubset = None) -> None:
        try:
            await self.multistepreactionssubset_client.Update(
                lara_django_substances_pb2.MultiStepReactionsSubsetRequest(**multistepreactionssubset.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating multistepreactionssubset_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.multistepreactionssubset_client.Destroy(lara_django_substances_pb2.MultiStepReactionsSubsetDestroyRequest(multistepreactionssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting multistepreactionssubset_id: {e}")

