from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "url_visualization", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    URL_VISUALIZATION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    url_visualization: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., url_visualization: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "url_visualization", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    URL_VISUALIZATION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    url_visualization: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., url_visualization: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "url_visualization", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    URL_VISUALIZATION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    url_visualization: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., url_visualization: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class IsotopeDestroyRequest(_message.Message):
    __slots__ = ("isotope_id",)
    ISOTOPE_ID_FIELD_NUMBER: _ClassVar[int]
    isotope_id: str
    def __init__(self, isotope_id: _Optional[str] = ...) -> None: ...

class IsotopeListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class IsotopeListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[IsotopeResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[IsotopeResponse, _Mapping]]] = ...) -> None: ...

class IsotopePartialUpdateRequest(_message.Message):
    __slots__ = ("isotope_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "_partial_update_fields", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "num_protons", "num_neutrons", "electron_config", "search_vector")
    ISOTOPE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NUM_PROTONS_FIELD_NUMBER: _ClassVar[int]
    NUM_NEUTRONS_FIELD_NUMBER: _ClassVar[int]
    ELECTRON_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    isotope_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    num_protons: int
    num_neutrons: int
    electron_config: str
    search_vector: str
    def __init__(self, isotope_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., num_protons: _Optional[int] = ..., num_neutrons: _Optional[int] = ..., electron_config: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class IsotopeRequest(_message.Message):
    __slots__ = ("isotope_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "num_protons", "num_neutrons", "electron_config", "search_vector")
    ISOTOPE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NUM_PROTONS_FIELD_NUMBER: _ClassVar[int]
    NUM_NEUTRONS_FIELD_NUMBER: _ClassVar[int]
    ELECTRON_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    isotope_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    num_protons: int
    num_neutrons: int
    electron_config: str
    search_vector: str
    def __init__(self, isotope_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., num_protons: _Optional[int] = ..., num_neutrons: _Optional[int] = ..., electron_config: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class IsotopeResponse(_message.Message):
    __slots__ = ("isotope_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "num_protons", "num_neutrons", "electron_config", "search_vector")
    ISOTOPE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NUM_PROTONS_FIELD_NUMBER: _ClassVar[int]
    NUM_NEUTRONS_FIELD_NUMBER: _ClassVar[int]
    ELECTRON_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    isotope_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    num_protons: int
    num_neutrons: int
    electron_config: str
    search_vector: str
    def __init__(self, isotope_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., num_protons: _Optional[int] = ..., num_neutrons: _Optional[int] = ..., electron_config: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class IsotopeRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class IsotopeRetrieveRequest(_message.Message):
    __slots__ = ("isotope_id",)
    ISOTOPE_ID_FIELD_NUMBER: _ClassVar[int]
    isotope_id: str
    def __init__(self, isotope_id: _Optional[str] = ...) -> None: ...

class IsotopeStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class IsotopesSubsetDestroyRequest(_message.Message):
    __slots__ = ("isotopessubset_id",)
    ISOTOPESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    isotopessubset_id: str
    def __init__(self, isotopessubset_id: _Optional[str] = ...) -> None: ...

class IsotopesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class IsotopesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[IsotopesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[IsotopesSubsetResponse, _Mapping]]] = ...) -> None: ...

class IsotopesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("isotopessubset_id", "namespace", "group", "isotopes", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    ISOTOPESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    isotopessubset_id: str
    namespace: str
    group: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, isotopessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class IsotopesSubsetRequest(_message.Message):
    __slots__ = ("isotopessubset_id", "namespace", "group", "isotopes", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ISOTOPESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    isotopessubset_id: str
    namespace: str
    group: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, isotopessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class IsotopesSubsetResponse(_message.Message):
    __slots__ = ("isotopessubset_id", "namespace", "group", "isotopes", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    ISOTOPESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    isotopessubset_id: str
    namespace: str
    group: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, isotopessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class IsotopesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("isotopessubset_id",)
    ISOTOPESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    isotopessubset_id: str
    def __init__(self, isotopessubset_id: _Optional[str] = ...) -> None: ...

class IsotopesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureComponentDestroyRequest(_message.Message):
    __slots__ = ("mixturecomponent_id",)
    MIXTURECOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    mixturecomponent_id: str
    def __init__(self, mixturecomponent_id: _Optional[str] = ...) -> None: ...

class MixtureComponentListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureComponentListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureComponentResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureComponentResponse, _Mapping]]] = ...) -> None: ...

class MixtureComponentPartialUpdateRequest(_message.Message):
    __slots__ = ("mixturecomponent_id", "substance", "polymer", "_partial_update_fields", "name", "iri", "concentration", "concentration_weight", "description", "datetime_last_modified")
    MIXTURECOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    mixturecomponent_id: str
    substance: str
    polymer: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    datetime_last_modified: str
    def __init__(self, mixturecomponent_id: _Optional[str] = ..., substance: _Optional[str] = ..., polymer: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class MixtureComponentRequest(_message.Message):
    __slots__ = ("mixturecomponent_id", "substance", "polymer", "name", "iri", "concentration", "concentration_weight", "description", "datetime_last_modified")
    MIXTURECOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    mixturecomponent_id: str
    substance: str
    polymer: str
    name: str
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    datetime_last_modified: str
    def __init__(self, mixturecomponent_id: _Optional[str] = ..., substance: _Optional[str] = ..., polymer: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class MixtureComponentResponse(_message.Message):
    __slots__ = ("mixturecomponent_id", "substance", "polymer", "name", "iri", "concentration", "concentration_weight", "description", "datetime_last_modified")
    MIXTURECOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    mixturecomponent_id: str
    substance: str
    polymer: str
    name: str
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    datetime_last_modified: str
    def __init__(self, mixturecomponent_id: _Optional[str] = ..., substance: _Optional[str] = ..., polymer: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class MixtureComponentRetrieveRequest(_message.Message):
    __slots__ = ("mixturecomponent_id",)
    MIXTURECOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    mixturecomponent_id: str
    def __init__(self, mixturecomponent_id: _Optional[str] = ...) -> None: ...

class MixtureComponentStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureDestroyRequest(_message.Message):
    __slots__ = ("mixture_id",)
    MIXTURE_ID_FIELD_NUMBER: _ClassVar[int]
    mixture_id: str
    def __init__(self, mixture_id: _Optional[str] = ...) -> None: ...

class MixtureListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureResponse, _Mapping]]] = ...) -> None: ...

class MixturePartialUpdateRequest(_message.Message):
    __slots__ = ("mixture_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "components", "_partial_update_fields", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "minchi", "search_vector")
    MIXTURE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    MINCHI_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    mixture_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    components: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    minchi: str
    search_vector: str
    def __init__(self, mixture_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., components: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., minchi: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MixtureRequest(_message.Message):
    __slots__ = ("mixture_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "components", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "minchi", "search_vector")
    MIXTURE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    MINCHI_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    mixture_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    components: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    minchi: str
    search_vector: str
    def __init__(self, mixture_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., components: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., minchi: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MixtureResponse(_message.Message):
    __slots__ = ("mixture_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "components", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "minchi", "search_vector")
    MIXTURE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    MINCHI_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    mixture_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    components: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    minchi: str
    search_vector: str
    def __init__(self, mixture_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., components: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., minchi: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MixtureRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MixtureRetrieveRequest(_message.Message):
    __slots__ = ("mixture_id",)
    MIXTURE_ID_FIELD_NUMBER: _ClassVar[int]
    mixture_id: str
    def __init__(self, mixture_id: _Optional[str] = ...) -> None: ...

class MixtureStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesSubsetDestroyRequest(_message.Message):
    __slots__ = ("mixturessubset_id",)
    MIXTURESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    mixturessubset_id: str
    def __init__(self, mixturessubset_id: _Optional[str] = ...) -> None: ...

class MixturesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixturesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixturesSubsetResponse, _Mapping]]] = ...) -> None: ...

class MixturesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("mixturessubset_id", "namespace", "group", "mixtures", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTURESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturessubset_id: str
    namespace: str
    group: str
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixturessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixtures: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesSubsetRequest(_message.Message):
    __slots__ = ("mixturessubset_id", "namespace", "group", "mixtures", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTURESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturessubset_id: str
    namespace: str
    group: str
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixturessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixtures: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesSubsetResponse(_message.Message):
    __slots__ = ("mixturessubset_id", "namespace", "group", "mixtures", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTURESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturessubset_id: str
    namespace: str
    group: str
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixturessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixtures: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("mixturessubset_id",)
    MIXTURESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    mixturessubset_id: str
    def __init__(self, mixturessubset_id: _Optional[str] = ...) -> None: ...

class MixturesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MoleculeResidueDestroyRequest(_message.Message):
    __slots__ = ("moleculeresidue_id",)
    MOLECULERESIDUE_ID_FIELD_NUMBER: _ClassVar[int]
    moleculeresidue_id: str
    def __init__(self, moleculeresidue_id: _Optional[str] = ...) -> None: ...

class MoleculeResidueListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MoleculeResidueListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MoleculeResidueResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MoleculeResidueResponse, _Mapping]]] = ...) -> None: ...

class MoleculeResiduePartialUpdateRequest(_message.Message):
    __slots__ = ("moleculeresidue_id", "_partial_update_fields", "name", "substructure", "iri", "description")
    MOLECULERESIDUE_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SUBSTRUCTURE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    moleculeresidue_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    substructure: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, moleculeresidue_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., substructure: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MoleculeResidueRequest(_message.Message):
    __slots__ = ("moleculeresidue_id", "name", "substructure", "iri", "description")
    MOLECULERESIDUE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SUBSTRUCTURE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    moleculeresidue_id: str
    name: str
    substructure: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, moleculeresidue_id: _Optional[str] = ..., name: _Optional[str] = ..., substructure: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MoleculeResidueResponse(_message.Message):
    __slots__ = ("moleculeresidue_id", "name", "substructure", "iri", "description")
    MOLECULERESIDUE_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SUBSTRUCTURE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    moleculeresidue_id: str
    name: str
    substructure: _struct_pb2.Struct
    iri: str
    description: str
    def __init__(self, moleculeresidue_id: _Optional[str] = ..., name: _Optional[str] = ..., substructure: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class MoleculeResidueRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MoleculeResidueRetrieveRequest(_message.Message):
    __slots__ = ("moleculeresidue_id",)
    MOLECULERESIDUE_ID_FIELD_NUMBER: _ClassVar[int]
    moleculeresidue_id: str
    def __init__(self, moleculeresidue_id: _Optional[str] = ...) -> None: ...

class MoleculeResidueStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionDestroyRequest(_message.Message):
    __slots__ = ("multistepreaction_id",)
    MULTISTEPREACTION_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreaction_id: str
    def __init__(self, multistepreaction_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MultiStepReactionResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MultiStepReactionResponse, _Mapping]]] = ...) -> None: ...

class MultiStepReactionPartialUpdateRequest(_message.Message):
    __slots__ = ("multistepreaction_id", "reactions", "resources_external", "tags", "data_extra", "_partial_update_fields", "name", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "rinchi", "description", "remarks", "datetime_last_modified", "search_vector")
    MULTISTEPREACTION_ID_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreaction_id: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    rinchi: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, multistepreaction_id: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., rinchi: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionRequest(_message.Message):
    __slots__ = ("multistepreaction_id", "reactions", "resources_external", "tags", "data_extra", "name", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "rinchi", "description", "remarks", "datetime_last_modified", "search_vector")
    MULTISTEPREACTION_ID_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreaction_id: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    rinchi: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, multistepreaction_id: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., rinchi: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionResponse(_message.Message):
    __slots__ = ("multistepreaction_id", "reactions", "resources_external", "tags", "data_extra", "name", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "rinchi", "description", "remarks", "datetime_last_modified", "search_vector")
    MULTISTEPREACTION_ID_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreaction_id: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    rinchi: str
    description: str
    remarks: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, multistepreaction_id: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., rinchi: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MultiStepReactionRetrieveRequest(_message.Message):
    __slots__ = ("multistepreaction_id",)
    MULTISTEPREACTION_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreaction_id: str
    def __init__(self, multistepreaction_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionsSubsetDestroyRequest(_message.Message):
    __slots__ = ("multistepreactionssubset_id",)
    MULTISTEPREACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactionssubset_id: str
    def __init__(self, multistepreactionssubset_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MultiStepReactionsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MultiStepReactionsSubsetResponse, _Mapping]]] = ...) -> None: ...

class MultiStepReactionsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("multistepreactionssubset_id", "namespace", "group", "reactions_multistep", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactionssubset_id: str
    namespace: str
    group: str
    reactions_multistep: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionsSubsetRequest(_message.Message):
    __slots__ = ("multistepreactionssubset_id", "namespace", "group", "reactions_multistep", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactionssubset_id: str
    namespace: str
    group: str
    reactions_multistep: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionsSubsetResponse(_message.Message):
    __slots__ = ("multistepreactionssubset_id", "namespace", "group", "reactions_multistep", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactionssubset_id: str
    namespace: str
    group: str
    reactions_multistep: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("multistepreactionssubset_id",)
    MULTISTEPREACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactionssubset_id: str
    def __init__(self, multistepreactionssubset_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerDestroyRequest(_message.Message):
    __slots__ = ("polymer_id",)
    POLYMER_ID_FIELD_NUMBER: _ClassVar[int]
    polymer_id: str
    def __init__(self, polymer_id: _Optional[str] = ...) -> None: ...

class PolymerListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerResponse, _Mapping]]] = ...) -> None: ...

class PolymerPartialUpdateRequest(_message.Message):
    __slots__ = ("polymer_id", "substance_classes", "sequence", "physical_state_matter", "data_extra", "resources_external", "tags", "_partial_update_fields", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "uniprot_ac", "uniprot_id", "genebank_id", "melting_point", "boiling_point", "logp", "sequence_file", "media_type", "search_vector")
    POLYMER_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_AC_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ID_FIELD_NUMBER: _ClassVar[int]
    GENEBANK_ID_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    polymer_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    sequence: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    uniprot_ac: str
    uniprot_id: str
    genebank_id: str
    melting_point: float
    boiling_point: float
    logp: float
    sequence_file: str
    media_type: str
    search_vector: str
    def __init__(self, polymer_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., sequence: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., uniprot_ac: _Optional[str] = ..., uniprot_id: _Optional[str] = ..., genebank_id: _Optional[str] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., logp: _Optional[float] = ..., sequence_file: _Optional[str] = ..., media_type: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class PolymerRequest(_message.Message):
    __slots__ = ("polymer_id", "substance_classes", "sequence", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "uniprot_ac", "uniprot_id", "genebank_id", "melting_point", "boiling_point", "logp", "sequence_file", "media_type", "search_vector")
    POLYMER_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_AC_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ID_FIELD_NUMBER: _ClassVar[int]
    GENEBANK_ID_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    polymer_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    sequence: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    uniprot_ac: str
    uniprot_id: str
    genebank_id: str
    melting_point: float
    boiling_point: float
    logp: float
    sequence_file: str
    media_type: str
    search_vector: str
    def __init__(self, polymer_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., sequence: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., uniprot_ac: _Optional[str] = ..., uniprot_id: _Optional[str] = ..., genebank_id: _Optional[str] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., logp: _Optional[float] = ..., sequence_file: _Optional[str] = ..., media_type: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class PolymerResponse(_message.Message):
    __slots__ = ("polymer_id", "substance_classes", "sequence", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "uniprot_ac", "uniprot_id", "genebank_id", "melting_point", "boiling_point", "logp", "sequence_file", "media_type", "search_vector")
    POLYMER_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_AC_FIELD_NUMBER: _ClassVar[int]
    UNIPROT_ID_FIELD_NUMBER: _ClassVar[int]
    GENEBANK_ID_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FILE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    polymer_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    sequence: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    uniprot_ac: str
    uniprot_id: str
    genebank_id: str
    melting_point: float
    boiling_point: float
    logp: float
    sequence_file: str
    media_type: str
    search_vector: str
    def __init__(self, polymer_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., sequence: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., uniprot_ac: _Optional[str] = ..., uniprot_id: _Optional[str] = ..., genebank_id: _Optional[str] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., logp: _Optional[float] = ..., sequence_file: _Optional[str] = ..., media_type: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class PolymerRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class PolymerRetrieveRequest(_message.Message):
    __slots__ = ("polymer_id",)
    POLYMER_ID_FIELD_NUMBER: _ClassVar[int]
    polymer_id: str
    def __init__(self, polymer_id: _Optional[str] = ...) -> None: ...

class PolymerStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersSubsetDestroyRequest(_message.Message):
    __slots__ = ("polymerssubset_id",)
    POLYMERSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerssubset_id: str
    def __init__(self, polymerssubset_id: _Optional[str] = ...) -> None: ...

class PolymersSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymersSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymersSubsetResponse, _Mapping]]] = ...) -> None: ...

class PolymersSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("polymerssubset_id", "namespace", "group", "polymers", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerssubset_id: str
    namespace: str
    group: str
    polymers: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymers: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersSubsetRequest(_message.Message):
    __slots__ = ("polymerssubset_id", "namespace", "group", "polymers", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerssubset_id: str
    namespace: str
    group: str
    polymers: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymers: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersSubsetResponse(_message.Message):
    __slots__ = ("polymerssubset_id", "namespace", "group", "polymers", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerssubset_id: str
    namespace: str
    group: str
    polymers: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymers: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersSubsetRetrieveRequest(_message.Message):
    __slots__ = ("polymerssubset_id",)
    POLYMERSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerssubset_id: str
    def __init__(self, polymerssubset_id: _Optional[str] = ...) -> None: ...

class PolymersSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactantDestroyRequest(_message.Message):
    __slots__ = ("reactioncomponent_id",)
    REACTIONCOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponent_id: str
    def __init__(self, reactioncomponent_id: _Optional[str] = ...) -> None: ...

class ReactantListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactantListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactantResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactantResponse, _Mapping]]] = ...) -> None: ...

class ReactantPartialUpdateRequest(_message.Message):
    __slots__ = ("substance", "polymer", "mixture", "roles", "resources_external", "physical_state_matter", "tags", "_partial_update_fields", "iri", "order", "stoichiometric_factor", "properties", "computed_properties", "datetime_last_modified", "physical_state", "search_vector", "reactioncomponent_id", "name")
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    substance: str
    polymer: str
    mixture: str
    roles: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    physical_state: str
    search_vector: str
    reactioncomponent_id: str
    name: str
    def __init__(self, substance: _Optional[str] = ..., polymer: _Optional[str] = ..., mixture: _Optional[str] = ..., roles: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., physical_state: _Optional[str] = ..., search_vector: _Optional[str] = ..., reactioncomponent_id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class ReactantRequest(_message.Message):
    __slots__ = ("substance", "polymer", "mixture", "roles", "resources_external", "physical_state_matter", "tags", "iri", "order", "stoichiometric_factor", "properties", "computed_properties", "datetime_last_modified", "physical_state", "search_vector", "reactioncomponent_id", "name")
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    substance: str
    polymer: str
    mixture: str
    roles: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    physical_state: str
    search_vector: str
    reactioncomponent_id: str
    name: str
    def __init__(self, substance: _Optional[str] = ..., polymer: _Optional[str] = ..., mixture: _Optional[str] = ..., roles: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., physical_state: _Optional[str] = ..., search_vector: _Optional[str] = ..., reactioncomponent_id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class ReactantResponse(_message.Message):
    __slots__ = ("substance", "polymer", "mixture", "roles", "resources_external", "physical_state_matter", "tags", "iri", "order", "stoichiometric_factor", "properties", "computed_properties", "datetime_last_modified", "physical_state", "search_vector", "reactioncomponent_id", "name")
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    substance: str
    polymer: str
    mixture: str
    roles: str
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    physical_state: str
    search_vector: str
    reactioncomponent_id: str
    name: str
    def __init__(self, substance: _Optional[str] = ..., polymer: _Optional[str] = ..., mixture: _Optional[str] = ..., roles: _Optional[str] = ..., resources_external: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., physical_state: _Optional[str] = ..., search_vector: _Optional[str] = ..., reactioncomponent_id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class ReactantRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ReactantRetrieveRequest(_message.Message):
    __slots__ = ("reactioncomponent_id",)
    REACTIONCOMPONENT_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponent_id: str
    def __init__(self, reactioncomponent_id: _Optional[str] = ...) -> None: ...

class ReactantStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactantsSubsetDestroyRequest(_message.Message):
    __slots__ = ("reactioncomponentssubset_id",)
    REACTIONCOMPONENTSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentssubset_id: str
    def __init__(self, reactioncomponentssubset_id: _Optional[str] = ...) -> None: ...

class ReactantsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactantsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactantsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactantsSubsetResponse, _Mapping]]] = ...) -> None: ...

class ReactantsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("namespace", "group", "reactants", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity", "reactioncomponentssubset_id")
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTANTS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENTSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    namespace: str
    group: str
    reactants: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    reactioncomponentssubset_id: str
    def __init__(self, namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactants: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ..., reactioncomponentssubset_id: _Optional[str] = ...) -> None: ...

class ReactantsSubsetRequest(_message.Message):
    __slots__ = ("namespace", "group", "reactants", "tags", "name", "description", "datetime_last_modified", "name_display", "entity", "reactioncomponentssubset_id")
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTANTS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENTSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    namespace: str
    group: str
    reactants: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    reactioncomponentssubset_id: str
    def __init__(self, namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactants: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ..., reactioncomponentssubset_id: _Optional[str] = ...) -> None: ...

class ReactantsSubsetResponse(_message.Message):
    __slots__ = ("namespace", "group", "reactants", "tags", "name", "description", "datetime_last_modified", "name_display", "entity", "reactioncomponentssubset_id", "reaction_components")
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTANTS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    REACTIONCOMPONENTSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    REACTION_COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    namespace: str
    group: str
    reactants: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    reactioncomponentssubset_id: str
    reaction_components: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactants: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ..., reactioncomponentssubset_id: _Optional[str] = ..., reaction_components: _Optional[_Iterable[str]] = ...) -> None: ...

class ReactantsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("reactioncomponentssubset_id",)
    REACTIONCOMPONENTSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentssubset_id: str
    def __init__(self, reactioncomponentssubset_id: _Optional[str] = ...) -> None: ...

class ReactantsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionDestroyRequest(_message.Message):
    __slots__ = ("reaction_id",)
    REACTION_ID_FIELD_NUMBER: _ClassVar[int]
    reaction_id: str
    def __init__(self, reaction_id: _Optional[str] = ...) -> None: ...

class ReactionListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionResponse, _Mapping]]] = ...) -> None: ...

class ReactionPartialUpdateRequest(_message.Message):
    __slots__ = ("reaction_id", "components", "resources_external", "tags", "data_extra", "_partial_update_fields", "name", "label", "rx_uuid", "properties", "parameters", "computed_properties", "rinchi", "rinchi_key_short", "rinchi_key_long", "rinchi_web_key", "rxno", "equilibrium_const", "deltag", "order", "safety_info", "description", "remarks", "svg", "image", "iri", "datetime_last_modified", "search_vector")
    REACTION_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    RX_UUID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_SHORT_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_LONG_FIELD_NUMBER: _ClassVar[int]
    RINCHI_WEB_KEY_FIELD_NUMBER: _ClassVar[int]
    RXNO_FIELD_NUMBER: _ClassVar[int]
    EQUILIBRIUM_CONST_FIELD_NUMBER: _ClassVar[int]
    DELTAG_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reaction_id: str
    components: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    label: str
    rx_uuid: str
    properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    rinchi: str
    rinchi_key_short: str
    rinchi_key_long: str
    rinchi_web_key: str
    rxno: str
    equilibrium_const: float
    deltag: float
    order: int
    safety_info: _struct_pb2.Struct
    description: str
    remarks: str
    svg: str
    image: str
    iri: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, reaction_id: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., label: _Optional[str] = ..., rx_uuid: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., rinchi: _Optional[str] = ..., rinchi_key_short: _Optional[str] = ..., rinchi_key_long: _Optional[str] = ..., rinchi_web_key: _Optional[str] = ..., rxno: _Optional[str] = ..., equilibrium_const: _Optional[float] = ..., deltag: _Optional[float] = ..., order: _Optional[int] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionRequest(_message.Message):
    __slots__ = ("reaction_id", "components", "resources_external", "tags", "data_extra", "name", "label", "rx_uuid", "properties", "parameters", "computed_properties", "rinchi", "rinchi_key_short", "rinchi_key_long", "rinchi_web_key", "rxno", "equilibrium_const", "deltag", "order", "safety_info", "description", "remarks", "svg", "image", "iri", "datetime_last_modified", "search_vector")
    REACTION_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    RX_UUID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_SHORT_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_LONG_FIELD_NUMBER: _ClassVar[int]
    RINCHI_WEB_KEY_FIELD_NUMBER: _ClassVar[int]
    RXNO_FIELD_NUMBER: _ClassVar[int]
    EQUILIBRIUM_CONST_FIELD_NUMBER: _ClassVar[int]
    DELTAG_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reaction_id: str
    components: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    label: str
    rx_uuid: str
    properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    rinchi: str
    rinchi_key_short: str
    rinchi_key_long: str
    rinchi_web_key: str
    rxno: str
    equilibrium_const: float
    deltag: float
    order: int
    safety_info: _struct_pb2.Struct
    description: str
    remarks: str
    svg: str
    image: str
    iri: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, reaction_id: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., label: _Optional[str] = ..., rx_uuid: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., rinchi: _Optional[str] = ..., rinchi_key_short: _Optional[str] = ..., rinchi_key_long: _Optional[str] = ..., rinchi_web_key: _Optional[str] = ..., rxno: _Optional[str] = ..., equilibrium_const: _Optional[float] = ..., deltag: _Optional[float] = ..., order: _Optional[int] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionResponse(_message.Message):
    __slots__ = ("reaction_id", "components", "resources_external", "tags", "data_extra", "name", "label", "rx_uuid", "properties", "parameters", "computed_properties", "rinchi", "rinchi_key_short", "rinchi_key_long", "rinchi_web_key", "rxno", "equilibrium_const", "deltag", "order", "safety_info", "description", "remarks", "svg", "image", "iri", "datetime_last_modified", "search_vector")
    REACTION_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    RX_UUID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    RINCHI_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_SHORT_FIELD_NUMBER: _ClassVar[int]
    RINCHI_KEY_LONG_FIELD_NUMBER: _ClassVar[int]
    RINCHI_WEB_KEY_FIELD_NUMBER: _ClassVar[int]
    RXNO_FIELD_NUMBER: _ClassVar[int]
    EQUILIBRIUM_CONST_FIELD_NUMBER: _ClassVar[int]
    DELTAG_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reaction_id: str
    components: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    label: str
    rx_uuid: str
    properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    rinchi: str
    rinchi_key_short: str
    rinchi_key_long: str
    rinchi_web_key: str
    rxno: str
    equilibrium_const: float
    deltag: float
    order: int
    safety_info: _struct_pb2.Struct
    description: str
    remarks: str
    svg: str
    image: str
    iri: str
    datetime_last_modified: str
    search_vector: str
    def __init__(self, reaction_id: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., label: _Optional[str] = ..., rx_uuid: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., rinchi: _Optional[str] = ..., rinchi_key_short: _Optional[str] = ..., rinchi_key_long: _Optional[str] = ..., rinchi_web_key: _Optional[str] = ..., rxno: _Optional[str] = ..., equilibrium_const: _Optional[float] = ..., deltag: _Optional[float] = ..., order: _Optional[int] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ReactionRetrieveRequest(_message.Message):
    __slots__ = ("reaction_id",)
    REACTION_ID_FIELD_NUMBER: _ClassVar[int]
    reaction_id: str
    def __init__(self, reaction_id: _Optional[str] = ...) -> None: ...

class ReactionStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionsSubsetDestroyRequest(_message.Message):
    __slots__ = ("reactionssubset_id",)
    REACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactionssubset_id: str
    def __init__(self, reactionssubset_id: _Optional[str] = ...) -> None: ...

class ReactionsSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionsSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionsSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionsSubsetResponse, _Mapping]]] = ...) -> None: ...

class ReactionsSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("reactionssubset_id", "namespace", "group", "reactions", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactionssubset_id: str
    namespace: str
    group: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionsSubsetRequest(_message.Message):
    __slots__ = ("reactionssubset_id", "namespace", "group", "reactions", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactionssubset_id: str
    namespace: str
    group: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionsSubsetResponse(_message.Message):
    __slots__ = ("reactionssubset_id", "namespace", "group", "reactions", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactionssubset_id: str
    namespace: str
    group: str
    reactions: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactionssubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionsSubsetRetrieveRequest(_message.Message):
    __slots__ = ("reactionssubset_id",)
    REACTIONSSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactionssubset_id: str
    def __init__(self, reactionssubset_id: _Optional[str] = ...) -> None: ...

class ReactionsSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceClassDestroyRequest(_message.Message):
    __slots__ = ("substanceclass_id",)
    SUBSTANCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    substanceclass_id: str
    def __init__(self, substanceclass_id: _Optional[str] = ...) -> None: ...

class SubstanceClassListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceClassListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceClassResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceClassResponse, _Mapping]]] = ...) -> None: ...

class SubstanceClassPartialUpdateRequest(_message.Message):
    __slots__ = ("substanceclass_id", "_partial_update_fields", "name", "iri", "description")
    SUBSTANCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    substanceclass_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    description: str
    def __init__(self, substanceclass_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubstanceClassRequest(_message.Message):
    __slots__ = ("substanceclass_id", "name", "iri", "description")
    SUBSTANCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    substanceclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, substanceclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubstanceClassResponse(_message.Message):
    __slots__ = ("substanceclass_id", "name", "iri", "description")
    SUBSTANCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    substanceclass_id: str
    name: str
    iri: str
    description: str
    def __init__(self, substanceclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ...) -> None: ...

class SubstanceClassRetrieveRequest(_message.Message):
    __slots__ = ("substanceclass_id",)
    SUBSTANCECLASS_ID_FIELD_NUMBER: _ClassVar[int]
    substanceclass_id: str
    def __init__(self, substanceclass_id: _Optional[str] = ...) -> None: ...

class SubstanceClassStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceDestroyRequest(_message.Message):
    __slots__ = ("substance_id",)
    SUBSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    substance_id: str
    def __init__(self, substance_id: _Optional[str] = ...) -> None: ...

class SubstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceResponse, _Mapping]]] = ...) -> None: ...

class SubstancePartialUpdateRequest(_message.Message):
    __slots__ = ("substance_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "_partial_update_fields", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "m1_code", "m3_code", "m5_code", "logp", "alogp", "xlogp", "melting_point", "boiling_point", "search_vector")
    SUBSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    M1_CODE_FIELD_NUMBER: _ClassVar[int]
    M3_CODE_FIELD_NUMBER: _ClassVar[int]
    M5_CODE_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    ALOGP_FIELD_NUMBER: _ClassVar[int]
    XLOGP_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    substance_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    m1_code: str
    m3_code: str
    m5_code: str
    logp: float
    alogp: float
    xlogp: float
    melting_point: float
    boiling_point: float
    search_vector: str
    def __init__(self, substance_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., m1_code: _Optional[str] = ..., m3_code: _Optional[str] = ..., m5_code: _Optional[str] = ..., logp: _Optional[float] = ..., alogp: _Optional[float] = ..., xlogp: _Optional[float] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class SubstanceRequest(_message.Message):
    __slots__ = ("substance_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "m1_code", "m3_code", "m5_code", "logp", "alogp", "xlogp", "melting_point", "boiling_point", "search_vector")
    SUBSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    M1_CODE_FIELD_NUMBER: _ClassVar[int]
    M3_CODE_FIELD_NUMBER: _ClassVar[int]
    M5_CODE_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    ALOGP_FIELD_NUMBER: _ClassVar[int]
    XLOGP_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    substance_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    m1_code: str
    m3_code: str
    m5_code: str
    logp: float
    alogp: float
    xlogp: float
    melting_point: float
    boiling_point: float
    search_vector: str
    def __init__(self, substance_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., m1_code: _Optional[str] = ..., m3_code: _Optional[str] = ..., m5_code: _Optional[str] = ..., logp: _Optional[float] = ..., alogp: _Optional[float] = ..., xlogp: _Optional[float] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class SubstanceResponse(_message.Message):
    __slots__ = ("substance_id", "substance_classes", "physical_state_matter", "data_extra", "resources_external", "tags", "name", "acronym", "synonyms", "iri", "cas", "iupac_name", "iupac_name_traditional", "iupac_name_systematic", "pubchem_cid", "pubchem_sid", "pubchem_fingerprint", "chemspider_id", "beilstein_regnum", "ec_num", "mdl_num", "mass_exact", "mass_monoisotopic", "mass_molar", "density", "properties", "computed_properties", "sumformula", "cml", "cdxml", "smiles", "isosmiles", "cansmiles", "inchi", "inchikey", "stdinchi", "stdinchikey", "pdb_id", "icsd_id", "cod_id", "ccdc_id", "csd_id", "structure_info", "url", "pac_id", "url_definition", "mol_raw", "mol_2d", "mol_3d", "svg", "image", "remarks", "description", "datetime_last_modified", "m1_code", "m3_code", "m5_code", "logp", "alogp", "xlogp", "melting_point", "boiling_point", "search_vector")
    SUBSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_CLASSES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ACRONYM_FIELD_NUMBER: _ClassVar[int]
    SYNONYMS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CAS_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_TRADITIONAL_FIELD_NUMBER: _ClassVar[int]
    IUPAC_NAME_SYSTEMATIC_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_CID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_SID_FIELD_NUMBER: _ClassVar[int]
    PUBCHEM_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    CHEMSPIDER_ID_FIELD_NUMBER: _ClassVar[int]
    BEILSTEIN_REGNUM_FIELD_NUMBER: _ClassVar[int]
    EC_NUM_FIELD_NUMBER: _ClassVar[int]
    MDL_NUM_FIELD_NUMBER: _ClassVar[int]
    MASS_EXACT_FIELD_NUMBER: _ClassVar[int]
    MASS_MONOISOTOPIC_FIELD_NUMBER: _ClassVar[int]
    MASS_MOLAR_FIELD_NUMBER: _ClassVar[int]
    DENSITY_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    SUMFORMULA_FIELD_NUMBER: _ClassVar[int]
    CML_FIELD_NUMBER: _ClassVar[int]
    CDXML_FIELD_NUMBER: _ClassVar[int]
    SMILES_FIELD_NUMBER: _ClassVar[int]
    ISOSMILES_FIELD_NUMBER: _ClassVar[int]
    CANSMILES_FIELD_NUMBER: _ClassVar[int]
    INCHI_FIELD_NUMBER: _ClassVar[int]
    INCHIKEY_FIELD_NUMBER: _ClassVar[int]
    STDINCHI_FIELD_NUMBER: _ClassVar[int]
    STDINCHIKEY_FIELD_NUMBER: _ClassVar[int]
    PDB_ID_FIELD_NUMBER: _ClassVar[int]
    ICSD_ID_FIELD_NUMBER: _ClassVar[int]
    COD_ID_FIELD_NUMBER: _ClassVar[int]
    CCDC_ID_FIELD_NUMBER: _ClassVar[int]
    CSD_ID_FIELD_NUMBER: _ClassVar[int]
    STRUCTURE_INFO_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    URL_DEFINITION_FIELD_NUMBER: _ClassVar[int]
    MOL_RAW_FIELD_NUMBER: _ClassVar[int]
    MOL_2D_FIELD_NUMBER: _ClassVar[int]
    MOL_3D_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    M1_CODE_FIELD_NUMBER: _ClassVar[int]
    M3_CODE_FIELD_NUMBER: _ClassVar[int]
    M5_CODE_FIELD_NUMBER: _ClassVar[int]
    LOGP_FIELD_NUMBER: _ClassVar[int]
    ALOGP_FIELD_NUMBER: _ClassVar[int]
    XLOGP_FIELD_NUMBER: _ClassVar[int]
    MELTING_POINT_FIELD_NUMBER: _ClassVar[int]
    BOILING_POINT_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    substance_id: str
    substance_classes: _containers.RepeatedScalarFieldContainer[str]
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    acronym: str
    synonyms: str
    iri: str
    cas: str
    iupac_name: str
    iupac_name_traditional: str
    iupac_name_systematic: str
    pubchem_cid: str
    pubchem_sid: str
    pubchem_fingerprint: str
    chemspider_id: str
    beilstein_regnum: str
    ec_num: str
    mdl_num: str
    mass_exact: float
    mass_monoisotopic: float
    mass_molar: float
    density: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    sumformula: str
    cml: str
    cdxml: str
    smiles: str
    isosmiles: str
    cansmiles: str
    inchi: str
    inchikey: str
    stdinchi: str
    stdinchikey: str
    pdb_id: str
    icsd_id: str
    cod_id: str
    ccdc_id: str
    csd_id: str
    structure_info: _struct_pb2.Struct
    url: str
    pac_id: str
    url_definition: str
    mol_raw: str
    mol_2d: str
    mol_3d: str
    svg: str
    image: str
    remarks: str
    description: str
    datetime_last_modified: str
    m1_code: str
    m3_code: str
    m5_code: str
    logp: float
    alogp: float
    xlogp: float
    melting_point: float
    boiling_point: float
    search_vector: str
    def __init__(self, substance_id: _Optional[str] = ..., substance_classes: _Optional[_Iterable[str]] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., acronym: _Optional[str] = ..., synonyms: _Optional[str] = ..., iri: _Optional[str] = ..., cas: _Optional[str] = ..., iupac_name: _Optional[str] = ..., iupac_name_traditional: _Optional[str] = ..., iupac_name_systematic: _Optional[str] = ..., pubchem_cid: _Optional[str] = ..., pubchem_sid: _Optional[str] = ..., pubchem_fingerprint: _Optional[str] = ..., chemspider_id: _Optional[str] = ..., beilstein_regnum: _Optional[str] = ..., ec_num: _Optional[str] = ..., mdl_num: _Optional[str] = ..., mass_exact: _Optional[float] = ..., mass_monoisotopic: _Optional[float] = ..., mass_molar: _Optional[float] = ..., density: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., sumformula: _Optional[str] = ..., cml: _Optional[str] = ..., cdxml: _Optional[str] = ..., smiles: _Optional[str] = ..., isosmiles: _Optional[str] = ..., cansmiles: _Optional[str] = ..., inchi: _Optional[str] = ..., inchikey: _Optional[str] = ..., stdinchi: _Optional[str] = ..., stdinchikey: _Optional[str] = ..., pdb_id: _Optional[str] = ..., icsd_id: _Optional[str] = ..., cod_id: _Optional[str] = ..., ccdc_id: _Optional[str] = ..., csd_id: _Optional[str] = ..., structure_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pac_id: _Optional[str] = ..., url_definition: _Optional[str] = ..., mol_raw: _Optional[str] = ..., mol_2d: _Optional[str] = ..., mol_3d: _Optional[str] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., remarks: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., m1_code: _Optional[str] = ..., m3_code: _Optional[str] = ..., m5_code: _Optional[str] = ..., logp: _Optional[float] = ..., alogp: _Optional[float] = ..., xlogp: _Optional[float] = ..., melting_point: _Optional[float] = ..., boiling_point: _Optional[float] = ..., search_vector: _Optional[str] = ...) -> None: ...

class SubstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class SubstanceRetrieveRequest(_message.Message):
    __slots__ = ("substance_id",)
    SUBSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    substance_id: str
    def __init__(self, substance_id: _Optional[str] = ...) -> None: ...

class SubstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("substancessubset_id",)
    SUBSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    substancessubset_id: str
    def __init__(self, substancessubset_id: _Optional[str] = ...) -> None: ...

class SubstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class SubstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("substancessubset_id", "namespace", "group", "substances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancessubset_id: str
    namespace: str
    group: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesSubsetRequest(_message.Message):
    __slots__ = ("substancessubset_id", "namespace", "group", "substances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancessubset_id: str
    namespace: str
    group: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesSubsetResponse(_message.Message):
    __slots__ = ("substancessubset_id", "namespace", "group", "substances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancessubset_id: str
    namespace: str
    group: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("substancessubset_id",)
    SUBSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    substancessubset_id: str
    def __init__(self, substancessubset_id: _Optional[str] = ...) -> None: ...

class SubstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
