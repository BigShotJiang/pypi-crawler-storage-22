"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store admin *

:details: lara_django_substances_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev admin_generator lara_django_substances_store >> admin.py" to update this file
________________________________________________________________________
"""

# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import (
    ExtraData,
    SubstanceInstance,
    SubstanceOrderItem,
    SubstanceWishlist,
    SubstanceBasket,
    SubstancesOrder,
    SubstancesLocalStore,
    PolymerInstance,
    PolymerOrderItem,
    PolymerWishlist,
    PolymerBasket,
    PolymersOrder,
    PolymersLocalStore,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureOrderItem,
    MixtureWishlist,
    MixtureBasket,
    MixturesOrder,
    MixturesLocalStore,
    ReactionComponentInstance,
    ReactionInstance,
    ReactionInstancesSubset,
)


@admin.register(ExtraData)
class ExtraDataAdmin(admin.ModelAdmin):
    list_display = (
        "name_full",
        "data_type",
        "namespace",
        "iri",
        "url",
        "description",
        "extradata_id",
    )
    list_filter = ("data_type", "namespace", "media_type")


@admin.register(SubstanceInstance)
class SubstanceInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "barcode",
        "registration_no",
        "vendor",
        "price",
        "currency",
        "description",
        "amount_volume",
        "amount_mass",
        "purity",
    )
    list_filter = (
        "namespace",
        "vendor",
        "datetime_manufacturing",
        "datetime_purchase",
        "location",
        "labware_instance",
    )
    raw_id_fields = ("tags", "users", "data_extra")
    search_fields = ("name",)


@admin.register(SubstanceOrderItem)
class SubstanceOrderItemAdmin(admin.ModelAdmin):
    list_display = (
        "substance_instance",
        "quantity",
        "item_price_net",
        "item_price_gross",
        "item_transport_price",
        "item_price_tax",
        "item_discount",
        "total_price_net",
        "substanceorderitem_id",
    )
    list_filter = ("substance_instance",)
    raw_id_fields = ("data_extra",)


@admin.register(SubstanceWishlist)
class SubstanceWishlistAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "substancewishlist_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(SubstanceBasket)
class SubstanceBasketAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(SubstancesOrder)
class SubstancesOrderAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "datetime_order_quote",
        "order_total_price_net",
        "order_total_price_gross",
        "order_currency",
        "order_status",
        "substancesorder_id",
    )
    list_filter = (
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "provider",
        "transport_company",
        "datetime_order_pay",
        "order_currency",
        "order_status",
    )
    raw_id_fields = ("data_extra",)


@admin.register(SubstancesLocalStore)
class SubstancesLocalStoreAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
        "substanceslocalstore_id",
    )
    list_filter = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
    )
    raw_id_fields = ("substance_instances",)


@admin.register(PolymerInstance)
class PolymerInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "polymer",
        "barcode",
        "registration_no",
        "vendor",
        "product_id",
        "serial_no",
        "service_no",
        "price",
        "currency",
        "datetime_purchase",
        "location",
        "description",
        "amount_volume",
        "amount_mass",
        "purity",
    )
    list_filter = (
        "namespace",
        "vendor",
        "datetime_manufacturing",
        "currency",
        "datetime_purchase",
        "location",
        "labware_instance",
        "polymer",
    )
    raw_id_fields = ("tags", "users", "data_extra")
    search_fields = ("name",)


@admin.register(PolymerOrderItem)
class PolymerOrderItemAdmin(admin.ModelAdmin):
    list_display = (
        "polymer_instance",
        "quantity",
        "item_price_net",
        "item_price_gross",
        "total_price_net",
        "polymerorderitem_id",
    )
    list_filter = ("polymer_instance",)
    raw_id_fields = ("data_extra",)


@admin.register(PolymerWishlist)
class PolymerWishlistAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "polymerwishlist_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(PolymerBasket)
class PolymerBasketAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "polymerbasket_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(PolymersOrder)
class PolymersOrderAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "order_id_internal",
        "order_id_external",
        "order_barcode",
        "provider",
        "order_quote_id",
        "datetime_order_quote",
        "order_total_price_net",
        "order_total_price_gross",
        "order_currency",
        "order_status",
        "polymersorder_id",
    )
    list_filter = (
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "provider",
        "transport_company",
        "datetime_order_pay",
        "order_currency",
        "order_status",
    )
    raw_id_fields = ("data_extra",)


@admin.register(PolymersLocalStore)
class PolymersLocalStoreAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
    )
    list_filter = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
    )
    raw_id_fields = ("polymer_instances",)


@admin.register(MixtureComponentInstance)
class MixtureComponentInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "concentration",
        
        "barcode",
        "registration_no",
        "vendor",
        "product_id",
        "location",
        "description",
        "amount_volume",
        "amount_mass",
        "purity",
    )
    list_filter = (
        "namespace",
        "vendor",
        "datetime_purchase",
        "location",
        "labware_instance",
    )
    raw_id_fields = ("tags", "users", "data_extra")
    search_fields = ("name",)


@admin.register(MixtureInstance)
class MixtureInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "barcode",
        "registration_no",
        "vendor",
        "product_id",
        "datetime_manufacturing",
        "price",
        "currency",
        "datetime_purchase",
        "location",
        "description",
        "amount_volume",
        "amount_mass",
        "purity",
        "labware_instance",
    )
    list_filter = (
        "namespace",
        "vendor",
        "datetime_manufacturing",
        "currency",
        "datetime_purchase",
        "location",
        "labware_instance",
    )
    raw_id_fields = ("tags", "users", "data_extra", "components")
    search_fields = ("name",)


@admin.register(MixtureOrderItem)
class MixtureOrderItemAdmin(admin.ModelAdmin):
    list_display = (
        "quantity",
        "item_price_net",
        "item_price_gross",
        "total_price_net",
        "mixture_instance",
        "mixtureorderitem_id",
    )
    list_filter = ("mixture_instance",)
    raw_id_fields = ("data_extra",)


@admin.register(MixtureWishlist)
class MixtureWishlistAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "mixturewishlist_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(MixtureBasket)
class MixtureBasketAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "mixturebasket_id",
    )
    list_filter = ("namespace", "entity", "datetime_created", "datetime_last_modified")


@admin.register(MixturesOrder)
class MixturesOrderAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "datetime_order_quote",
        "order_total_price_net",
        "order_total_price_gross",
        "order_currency",
        "order_status",
        "mixturesorder_id",
    )
    list_filter = (
        "namespace",
        "entity_ordered",
        "entity_ordering",
        "datetime_order",
        "provider",
        "transport_company",
        "datetime_order_pay",
        "order_currency",
        "order_status",
    )
    raw_id_fields = ("data_extra",)


@admin.register(MixturesLocalStore)
class MixturesLocalStoreAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
        "mixturelocalstore_id",
    )
    list_filter = (
        "namespace",
        "entity",
        "datetime_created",
        "datetime_last_modified",
        "location",
    )
    raw_id_fields = ("mixture_instances",)


@admin.register(ReactionComponentInstance)
class ReactionComponentInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "concentration",
        "barcode",
    )
    list_filter = (
        "namespace",
        "vendor",
        "datetime_purchase",
        "location",
    )
    raw_id_fields = ("tags",)
    search_fields = ("name",)


@admin.register(ReactionInstance)
class ReactionInstanceAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "name",
        "barcode",
        "location",
        "description",
    )
    list_filter = (
        "namespace",
        "location",
    )
    raw_id_fields = ("tags", "users", "data_extra", "component_instances")
    search_fields = ("name",)


@admin.register(ReactionInstancesSubset)
class ReactionInstancesSubsetAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "description",
    )
    raw_id_fields = ("tags",)
    search_fields = ("name",)
