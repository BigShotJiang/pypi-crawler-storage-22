"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store app *

:details: lara_django_substances_store app configuration.
         This provides a generic django app configuration mechanism.
         For more details see:
         https://docs.djangoproject.com/en/4.0/ref/applications/
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from django.apps import AppConfig


class LaraDjangoSubstancesStoreConfig(AppConfig):
    name = "lara_django_substances_store"
    url_path = "substances-store/"
    # enter a verbose name for your app: lara_django_substances_store here - this will be used in the admin interface
    verbose_name = "LARA-django Substances Store"
    # lara_app_icon = 'lara_django_substances_store_icon.svg'  # this will be used to display an icon, e.g. in the main LARA menu.
    lara_app_color = "teal"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_stor_color = "cyan"  # this will be used to highlight the app in the main LARA sidebar and app page
    lara_app_icon = "lara_material_icon.svg"
    verbose_name_short = "Substances"
    lara_app_description = "Store for Substances, Polymers, Mixtures"
    lara_class_apps = [
        {
            "name": "Substances",
            "path": "lara_django_substances:substances-overview",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Polymers",
            "path": "lara_django_substances:polymers-overview",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Mixtures",
            "path": "lara_django_substances:mixtures-overview",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
        {
            "name": "Reactions",
            "path": "lara_django_substances:reactions-overview",
            "icon": lara_app_icon,
            "color": lara_app_color,
        },
    ]
    lara_instance_apps = [
        {
            "name": "Substance Store",
            "path": "lara_django_substances_store:substance-list",  # "/projects/project/list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Polymer Store",
            "path": "lara_django_substances_store:polymer-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Mixtures Store",
            "path": "lara_django_substances_store:mixture-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
        {
            "name": "Reaction Store",
            "path": "lara_django_substances_store:substance-list",
            "icon": lara_app_icon,
            "color": lara_app_stor_color,
        },
    ]

    def ready(self):
        # add urlpatterns
        from django.urls import path, include
        from lara_django.urls import urlpatterns

        urlpatterns += [
            path(self.url_path, include("lara_django_substances_store.urls", namespace="lara_django_substances_store")),
        ]
