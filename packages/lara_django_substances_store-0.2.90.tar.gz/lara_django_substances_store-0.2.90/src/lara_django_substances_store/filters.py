"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_data filter app *

:details: lara_django_data filter app. 
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from django_filters.rest_framework import FilterSet, CharFilter, DateRangeFilter

from .models import ExtraData, SubstanceInstance, PolymerInstance, MixtureComponentInstance, MixtureInstance


class ExtraDataFilterSet(FilterSet):
    class Meta:
        model = ExtraData
        fields = {
            "name_display": ["exact", "contains"],
            "name": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            "datetime_created": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
        }


class SubstanceInstanceFilterSet(FilterSet):
    class Meta:
        model = SubstanceInstance
        fields = {
            "name": ["exact", "contains"],
            "datetime_manufacturing": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_end_of_warranty": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_delivery": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
            "barcode": ["exact", "contains"],
            "registration_no": ["exact", "contains"],
            "serial_no": ["exact", "contains"],
            "service_no": ["exact", "contains"],
            "amount_volume": ["lt", "gt", "exact", "range"],
            "amount_mass": ["lt", "gt", "exact", "range"],
            "price": ["lt", "gt", "exact", "range"],
            "purity": ["lt", "gt", "exact", "range"],
            "pid": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            # 'substance': ['exact'],
            # 'substance__name': ['exact', 'contains'],
            # 'substance__name_full': ['exact', 'contains'],
            # 'substance__description': ['exact', 'contains'],
            # 'datetime_created': ['lt', 'gt'],
        }


class PolymerInstanceFilterSet(FilterSet):
    class Meta:
        model = PolymerInstance
        fields = {
            "name": ["exact", "contains"],
            "datetime_manufacturing": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_end_of_warranty": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_delivery": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
            "barcode": ["exact", "contains"],
            "registration_no": ["exact", "contains"],
            "serial_no": ["exact", "contains"],
            "service_no": ["exact", "contains"],
            "amount_volume": ["lt", "gt", "exact", "range"],
            "amount_mass": ["lt", "gt", "exact", "range"],
            "price": ["lt", "gt", "exact", "range"],
            "purity": ["lt", "gt", "exact", "range"],
            "pid": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            # 'polymer': ['exact'],
            # 'polymer__name': ['exact', 'contains'],
            # 'polymer__name_full': ['exact', 'contains'],
            # 'polymer__description': ['exact', 'contains'],
            # 'datetime_created': ['lt', 'gt'],
        }


class MixtureComponentInstanceFilterSet(FilterSet):
    class Meta:
        model = MixtureComponentInstance
        fields = {
            "name": ["exact", "contains"],
            "datetime_manufacturing": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_end_of_warranty": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_delivery": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
            "barcode": ["exact", "contains"],
            "registration_no": ["exact", "contains"],
            "serial_no": ["exact", "contains"],
            "service_no": ["exact", "contains"],
            "amount_volume": ["lt", "gt", "exact", "range"],
            "amount_mass": ["lt", "gt", "exact", "range"],
            "price": ["lt", "gt", "exact", "range"],
            "purity": ["lt", "gt", "exact", "range"],
            "pid": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            # 'mixture_component': ['exact'],
            # 'mixture_component__name': ['exact', 'contains'],
            # 'mixture_component__name_full': ['exact', 'contains'],
            # 'mixture_component__description': ['exact', 'contains'],
            # 'datetime_created': ['lt', 'gt'],
        }


class MixtureInstanceFilterSet(FilterSet):
    class Meta:
        model = MixtureInstance
        fields = {
            "name": ["exact", "contains"],
            "datetime_manufacturing": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_end_of_warranty": ["lt", "gt", "exact", "range"],
            "datetime_last_modified": ["lt", "gt", "exact", "range"],
            "datetime_purchase": ["lt", "gt", "exact", "range"],
            "datetime_delivery": ["lt", "gt", "exact", "range"],
            "description": ["exact", "contains"],
            "barcode": ["exact", "contains"],
            "registration_no": ["exact", "contains"],
            "serial_no": ["exact", "contains"],
            "service_no": ["exact", "contains"],
            "amount_volume": ["lt", "gt", "exact", "range"],
            "amount_mass": ["lt", "gt", "exact", "range"],
            "price": ["lt", "gt", "exact", "range"],
            "purity": ["lt", "gt", "exact", "range"],
            "pid": ["exact", "contains"],
            "iri": ["exact", "contains"],
            "url": ["exact", "contains"],
            # 'mixture': ['exact'],
            # 'mixture__name': ['exact', 'contains'],
            # 'mixture__name_full': ['exact', 'contains'],
            # 'mixture__description': ['exact', 'contains'],
            # 'datetime_created': ['lt', 'gt'],
        }
