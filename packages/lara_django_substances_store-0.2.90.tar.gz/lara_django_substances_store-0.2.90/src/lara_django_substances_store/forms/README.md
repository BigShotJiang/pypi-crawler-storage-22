# Forms Module Structure

This directory contains the forms for `lara_django_substances_store`, organized by entity type for better maintainability and modularity.

## Module Organization

### `base.py`
Contains base classes and utilities used across all forms:
- `CustomFormRenderer`: Custom form renderer using custom field templates
- `SearchableSelectMultiple`: Custom widget for searchable multi-select using Alpine.js

### `extra_data.py`
Forms for the `ExtraData` model:
- `ExtraDataCreateForm`
- `ExtraDataUpdateForm`

### `substance_instance.py`
Forms for `SubstanceInstance` and related ordering/basket models:
- `SubstanceInstanceCreateForm` / `SubstanceInstanceUpdateForm`
- `SubstanceOrderItemCreateForm` / `SubstanceOrderItemUpdateForm`
- `SubstanceWishlistCreateForm` / `SubstanceWishlistUpdateForm`
- `SubstanceBasketCreateForm` / `SubstanceBasketUpdateForm`
- `SubstancesOrderCreateForm` / `SubstancesOrderUpdateForm`
- `SubstancesLocalStoreCreateForm` / `SubstancesLocalStoreUpdateForm`

### `polymer_instance.py`
Forms for `PolymerInstance` and related ordering/basket models:
- `PolymerInstanceCreateForm` / `PolymerInstanceUpdateForm`
- `PolymerOrderItemCreateForm` / `PolymerOrderItemUpdateForm`
- `PolymerWishlistCreateForm` / `PolymerWishlistUpdateForm`
- `PolymerBasketCreateForm` / `PolymerBasketUpdateForm`
- `PolymersOrderCreateForm` / `PolymersOrderUpdateForm`
- `PolymersLocalStoreCreateForm` / `PolymersLocalStoreUpdateForm`

### `mixture.py`
Forms for `MixtureInstance`, `MixtureComponentInstance` and related models:
- `MixtureComponentInstanceCreateForm` / `MixtureComponentInstanceUpdateForm`
- `MixtureInstanceCreateForm` / `MixtureInstanceUpdateForm`
- `MixtureOrderItemCreateForm` / `MixtureOrderItemUpdateForm`
- `MixtureWishlistCreateForm` / `MixtureWishlistUpdateForm`
- `MixtureBasketCreateForm` / `MixtureBasketUpdateForm`
- `MixturesOrderCreateForm` / `MixturesOrderUpdateForm`
- `MixturesLocalStoreCreateForm` / `MixturesLocalStoreUpdateForm`

### `__init__.py`
Package initialization file that imports all forms from submodules for backward compatibility.
This ensures that existing code using `from .forms import FormName` continues to work.

## Usage

### Import from the package (recommended):
```python
from lara_django_substances_store.forms import SubstanceInstanceCreateForm
```

### Import from specific module (for clarity):
```python
from lara_django_substances_store.forms.substance_instance import SubstanceInstanceCreateForm
```

### Import multiple forms:
```python
from lara_django_substances_store.forms import (
    SubstanceInstanceCreateForm,
    SubstanceInstanceUpdateForm,
    PolymerInstanceCreateForm,
)
```

## Benefits of This Structure

1. **Modularity**: Each module focuses on a specific entity type
2. **Maintainability**: Easier to find and modify forms for a specific entity
3. **Backward Compatibility**: Existing imports continue to work through `__init__.py`
4. **Reduced File Size**: Smaller, more manageable files instead of one large file
5. **Better Organization**: Clear separation of concerns

## Migration Notes

The original `forms.py` file has been renamed to `forms_old.py` as a backup.
All imports from `.forms` continue to work without modification due to the `__init__.py` re-exports.
