"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store forms package *

:details: Forms package for lara_django_substances_store.
         Organized into separate modules by entity type.
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: Import all forms from submodules for backward compatibility
.. todo:: -
________________________________________________________________________
"""

# Base classes and widgets
from .base import CustomFormRenderer, SearchableSelectMultiple

# ExtraData forms
from .extra_data import ExtraDataCreateForm, ExtraDataUpdateForm

# Mixture forms
from .mixture_instance import (
    MixtureBasketCreateForm,
    MixtureBasketUpdateForm,
    MixtureComponentInstanceCreateForm,
    MixtureComponentInstanceUpdateForm,
    MixtureInstanceCreateForm,
    MixtureInstanceUpdateForm,
    MixtureOrderItemCreateForm,
    MixtureOrderItemUpdateForm,
    MixturesLocalStoreCreateForm,
    MixturesLocalStoreUpdateForm,
    MixturesOrderCreateForm,
    MixturesOrderUpdateForm,
    MixtureWishlistCreateForm,
    MixtureWishlistUpdateForm,
)

# Polymer forms
from .polymer_instance import (
    PolymerBasketCreateForm,
    PolymerBasketUpdateForm,
    PolymerInstanceCreateForm,
    PolymerInstanceUpdateForm,
    PolymerOrderItemCreateForm,
    PolymerOrderItemUpdateForm,
    PolymersLocalStoreCreateForm,
    PolymersLocalStoreUpdateForm,
    PolymersOrderCreateForm,
    PolymersOrderUpdateForm,
    PolymerWishlistCreateForm,
    PolymerWishlistUpdateForm,
)

# Substance instance forms
from .substance_instance import (
    SubstanceBasketCreateForm,
    SubstanceBasketUpdateForm,
    SubstanceInstanceCreateForm,
    SubstanceInstanceUpdateForm,
    SubstanceOrderItemCreateForm,
    SubstanceOrderItemUpdateForm,
    SubstancesLocalStoreCreateForm,
    SubstancesLocalStoreUpdateForm,
    SubstancesOrderCreateForm,
    SubstancesOrderUpdateForm,
    SubstanceWishlistCreateForm,
    SubstanceWishlistUpdateForm,
)

__all__ = [
    # Base
    "CustomFormRenderer",
    "SearchableSelectMultiple",
    # ExtraData
    "ExtraDataCreateForm",
    "ExtraDataUpdateForm",
    # Substance Instance
    "SubstanceInstanceCreateForm",
    "SubstanceInstanceUpdateForm",
    "SubstanceOrderItemCreateForm",
    "SubstanceOrderItemUpdateForm",
    "SubstanceWishlistCreateForm",
    "SubstanceWishlistUpdateForm",
    "SubstanceBasketCreateForm",
    "SubstanceBasketUpdateForm",
    "SubstancesOrderCreateForm",
    "SubstancesOrderUpdateForm",
    "SubstancesLocalStoreCreateForm",
    "SubstancesLocalStoreUpdateForm",
    # Polymer Instance
    "PolymerInstanceCreateForm",
    "PolymerInstanceUpdateForm",
    "PolymerOrderItemCreateForm",
    "PolymerOrderItemUpdateForm",
    "PolymerWishlistCreateForm",
    "PolymerWishlistUpdateForm",
    "PolymerBasketCreateForm",
    "PolymerBasketUpdateForm",
    "PolymersOrderCreateForm",
    "PolymersOrderUpdateForm",
    "PolymersLocalStoreCreateForm",
    "PolymersLocalStoreUpdateForm",
    # Mixture Instance
    "MixtureComponentInstanceCreateForm",
    "MixtureComponentInstanceUpdateForm",
    "MixtureInstanceCreateForm",
    "MixtureInstanceUpdateForm",
    "MixtureOrderItemCreateForm",
    "MixtureOrderItemUpdateForm",
    "MixtureWishlistCreateForm",
    "MixtureWishlistUpdateForm",
    "MixtureBasketCreateForm",
    "MixtureBasketUpdateForm",
    "MixturesOrderCreateForm",
    "MixturesOrderUpdateForm",
    "MixturesLocalStoreCreateForm",
    "MixturesLocalStoreUpdateForm",
]
