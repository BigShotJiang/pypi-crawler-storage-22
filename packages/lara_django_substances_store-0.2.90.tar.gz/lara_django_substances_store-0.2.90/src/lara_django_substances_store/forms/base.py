"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store forms base *

:details: Base classes and utilities for forms.
         - CustomFormRenderer for custom field templates
         - SearchableSelectMultiple widget for better UX
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from typing import ClassVar

from django import forms
from django.forms.renderers import TemplatesSetting


class CustomFormRenderer(TemplatesSetting):
    """Custom form renderer using custom field template."""

    field_template_name = "lara_django_substances/forms/field_group.html"


class SearchableSelectMultiple(forms.SelectMultiple):
    """Custom widget for searchable multi-select using Alpine.js."""

    template_name = "lara_django_substances/widgets/searchable_select_multiple.html"

    def __init__(self, attrs=None):
        default_attrs = {"class": "searchable-select-multiple"}
        if attrs:
            default_attrs.update(attrs)
        super().__init__(attrs=default_attrs)
