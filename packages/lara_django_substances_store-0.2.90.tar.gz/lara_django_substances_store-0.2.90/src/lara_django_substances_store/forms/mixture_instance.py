"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store mixture forms *

:details: Forms for MixtureInstance, MixtureComponentInstance and related models.
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from django import forms

from ..models import (
    MixtureBasket,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureOrderItem,
    MixturesLocalStore,
    MixturesOrder,
    MixtureWishlist,
)


class MixtureComponentInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureComponentInstance
        fields = (
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class MixtureComponentInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureComponentInstance
        fields = (
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class MixtureInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureInstance
        fields = (
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class MixtureInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureInstance
        fields = (
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class MixtureOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
            Submit("submit", "Create"),
        )


class MixtureOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
            Submit("submit", "Update"),
        )


class MixtureWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixtureWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class MixtureBasketCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixtureBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixturesOrderCreateForm(forms.ModelForm):
    class Meta:
        model = MixturesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class MixturesOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = MixturesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Update"),
        )


class MixturesLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = MixturesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class MixturesLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = MixturesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Update"),
        )

