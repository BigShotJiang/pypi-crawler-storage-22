"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store polymer instance forms *

:details: Forms for PolymerInstance and related models (Orders, Baskets, Wishlists, LocalStore).
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from django import forms

from ..models import (
    PolymerBasket,
    PolymerInstance,
    PolymerOrderItem,
    PolymersLocalStore,
    PolymersOrder,
    PolymerWishlist,
)


class PolymerInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerInstance
        fields = (
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class PolymerInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerInstance
        fields = (
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class PolymerOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
            Submit("submit", "Create"),
        )


class PolymerOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
            Submit("submit", "Update"),
        )


class PolymerWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerBasketCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymersOrderCreateForm(forms.ModelForm):
    class Meta:
        model = PolymersOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class PolymersOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymersOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class PolymersLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = PolymersLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class PolymersLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymersLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )

