"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store substance instance forms *

:details: Forms for SubstanceInstance and related models (Orders, Baskets, Wishlists, LocalStore).
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from django import forms

from ..models import (
    SubstanceBasket,
    SubstanceInstance,
    SubstanceOrderItem,
    SubstancesLocalStore,
    SubstancesOrder,
    SubstanceWishlist,
)


class SubstanceInstanceCreateForm(forms.ModelForm):
    """Form for creating SubstanceInstance entries."""

    class Meta:  # noqa: D106
        model = SubstanceInstance
        fields = (
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class SubstanceInstanceUpdateForm(forms.ModelForm):
    """Form for updating SubstanceInstance entries."""

    class Meta:  # noqa: D106
        model = SubstanceInstance
        fields = (
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class SubstanceOrderItemCreateForm(forms.ModelForm):
    """Form for creating SubstanceOrderItem entries."""

    class Meta:  # noqa: D106
        model = SubstanceOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
            Submit("submit", "Create"),
        )


class SubstanceOrderItemUpdateForm(forms.ModelForm):
    """Form for updating SubstanceOrderItem entries."""

    class Meta:  # noqa: D106
        model = SubstanceOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
            Submit("submit", "Update"),
        )


class SubstanceWishlistCreateForm(forms.ModelForm):
    """Form for creating SubstanceWishlist entries."""

    class Meta:  # noqa: D106
        model = SubstanceWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class SubstanceWishlistUpdateForm(forms.ModelForm):
    """Form for updating SubstanceWishlist entries."""

    class Meta:  # noqa: D106
        model = SubstanceWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class SubstanceBasketCreateForm(forms.ModelForm):
    """Form for creating SubstanceBasket entries."""

    class Meta:  # noqa: D106
        model = SubstanceBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class SubstanceBasketUpdateForm(forms.ModelForm):
    """Form for updating SubstanceBasket entries."""

    class Meta:  # noqa: D106
        model = SubstanceBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class SubstancesOrderCreateForm(forms.ModelForm):
    """Form for creating SubstancesOrder entries."""

    class Meta:  # noqa: D106
        model = SubstancesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class SubstancesOrderUpdateForm(forms.ModelForm):
    """Form for updating SubstancesOrder entries."""

    class Meta:  # noqa: D106
        model = SubstancesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Update"),
        )


class SubstancesLocalStoreCreateForm(forms.ModelForm):
    """Form for creating SubstancesLocalStore entries."""

    class Meta:  # noqa: D106
        model = SubstancesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class SubstancesLocalStoreUpdateForm(forms.ModelForm):
    """Form for updating SubstancesLocalStore entries."""

    class Meta:  # noqa: D106
        model = SubstancesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Update"),
        )
