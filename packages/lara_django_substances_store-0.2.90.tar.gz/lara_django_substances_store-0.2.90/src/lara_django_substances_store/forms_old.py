"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store admin *

:details: lara_django_substances_store admin module admin backend configuration.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev forms_generator -c lara_django_substances_store > forms.py" to update this file
________________________________________________________________________
"""

# django crispy forms s. https://github.com/django-crispy-forms/django-crispy-forms for []
# generated with django-extensions forms_generator -c  [] > forms.py (LARA-version)

from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Row, Column

from .models import (
    ExtraData,
    SubstanceInstance,
    SubstanceOrderItem,
    SubstanceWishlist,
    SubstanceBasket,
    SubstancesOrder,
    SubstancesLocalStore,
    PolymerInstance,
    PolymerOrderItem,
    PolymerWishlist,
    PolymerBasket,
    PolymersOrder,
    PolymersLocalStore,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureOrderItem,
    MixtureWishlist,
    MixtureBasket,
    MixturesOrder,
    MixturesLocalStore,
)


class ExtraDataCreateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
            Submit("submit", "Create"),
        )


class ExtraDataUpdateForm(forms.ModelForm):
    class Meta:
        model = ExtraData
        fields = (
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "data_type",
            "name",
            "name_full",
            "name_display",
            "namespace",
            "version",
            "hash_sha256",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
            Submit("submit", "Update"),
        )


class SubstanceInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = SubstanceInstance
        fields = (
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class SubstanceInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstanceInstance
        fields = (
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class SubstanceOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = SubstanceOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
            Submit("submit", "Create"),
        )


class SubstanceOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstanceOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
            Submit("submit", "Update"),
        )


class SubstanceWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = SubstanceWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class SubstanceWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstanceWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class SubstanceBasketCreateForm(forms.ModelForm):
    class Meta:
        model = SubstanceBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class SubstanceBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstanceBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class SubstancesOrderCreateForm(forms.ModelForm):
    class Meta:
        model = SubstancesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class SubstancesOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstancesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Update"),
        )


class SubstancesLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = SubstancesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class SubstancesLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = SubstancesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Update"),
        )


class PolymerInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerInstance
        fields = (
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class PolymerInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerInstance
        fields = (
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "polymer",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class PolymerOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
            Submit("submit", "Create"),
        )


class PolymerOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
            Submit("submit", "Update"),
        )


class PolymerWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerBasketCreateForm(forms.ModelForm):
    class Meta:
        model = PolymerBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymerBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymerBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class PolymersOrderCreateForm(forms.ModelForm):
    class Meta:
        model = PolymersOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class PolymersOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymersOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class PolymersLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = PolymersLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class PolymersLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = PolymersLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class MixtureComponentInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureComponentInstance
        fields = (
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class MixtureComponentInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureComponentInstance
        fields = (
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "substance_instance",
            "polymer_instance",
            "concentration",
            
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class MixtureInstanceCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureInstance
        fields = (
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Create"),
        )


class MixtureInstanceUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureInstance
        fields = (
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "mixture",
            "name",
            "barcode",
            "barcode_json",
            "url",
            "pid",
            "iri",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "datetime_manufacturing",
            "price",
            "currency",
            "datetime_purchase",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "status",
            "entities_responsible",
            "hash_sha256",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "physical_state_matter",
            "labware_instance",
            "resources_external",
            Submit("submit", "Update"),
        )


class MixtureOrderItemCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
            Submit("submit", "Create"),
        )


class MixtureOrderItemUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureOrderItem
        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
            Submit("submit", "Update"),
        )


class MixtureWishlistCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixtureWishlistUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureWishlist
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Update")
        )


class MixtureBasketCreateForm(forms.ModelForm):
    class Meta:
        model = MixtureBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixtureBasketUpdateForm(forms.ModelForm):
    class Meta:
        model = MixtureBasket
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace", "entity", "datetime_created", "datetime_last_modified", Submit("submit", "Create")
        )


class MixturesOrderCreateForm(forms.ModelForm):
    class Meta:
        model = MixturesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Create"),
        )


class MixturesOrderUpdateForm(forms.ModelForm):
    class Meta:
        model = MixturesOrder
        fields = (
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
            Submit("submit", "Update"),
        )


class MixturesLocalStoreCreateForm(forms.ModelForm):
    class Meta:
        model = MixturesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Create"),
        )


class MixturesLocalStoreUpdateForm(forms.ModelForm):
    class Meta:
        model = MixturesLocalStore
        fields = ("namespace", "entity", "datetime_created", "datetime_last_modified", "location")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            "namespace",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
            Submit("submit", "Update"),
        )


# from .forms import ExtraDataCreateForm, SubstanceInstanceCreateForm, SubstanceOrderItemCreateForm, SubstanceWishlistCreateForm, SubstanceBasketCreateForm, SubstancesOrderCreateForm, SubstancesLocalStoreCreateForm, PolymerInstanceCreateForm, PolymerOrderItemCreateForm, PolymerWishlistCreateForm, PolymerBasketCreateForm, PolymersOrderCreateForm, PolymersLocalStoreCreateForm, MixtureComponentInstanceCreateForm, MixtureInstanceCreateForm, MixtureOrderItemCreateForm, MixtureWishlistCreateForm, MixtureBasketCreateForm, MixturesOrderCreateForm, MixturesLocalStoreCreateFormExtraDataUpdateForm, SubstanceInstanceUpdateForm, SubstanceOrderItemUpdateForm, SubstanceWishlistUpdateForm, SubstanceBasketUpdateForm, SubstancesOrderUpdateForm, SubstancesLocalStoreUpdateForm, PolymerInstanceUpdateForm, PolymerOrderItemUpdateForm, PolymerWishlistUpdateForm, PolymerBasketUpdateForm, PolymersOrderUpdateForm, PolymersLocalStoreUpdateForm, MixtureComponentInstanceUpdateForm, MixtureInstanceUpdateForm, MixtureOrderItemUpdateForm, MixtureWishlistUpdateForm, MixtureBasketUpdateForm, MixturesOrderUpdateForm, MixturesLocalStoreUpdateForm
