"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC handlers*

:details: lara_django_myproj gRPC handlers.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

# generated with django-socio-grpc generateprpcinterface lara_django_substances_store  (LARA-version)

# import logging
from django_socio_grpc.services.app_handler_registry import AppHandlerRegistry
from lara_django_substances_store.grpc.services import (
    ExtraDataService,
    SubstanceInstanceService,
    SubstanceInstancesSubsetService,
    SubstanceOrderItemService,
    SubstancesWishlistService,
    SubstanceBasketService,
    SubstancesOrderService,
    SubstancesLocalStoreService,
    PolymerInstanceService,
    PolymerInstancesSubsetService,
    PolymerOrderItemService,
    PolymerWishlistService,
    PolymerBasketService,
    PolymersOrderService,
    PolymersLocalStoreService,
    MixtureComponentInstanceService,
    MixtureInstanceService,
    MixtureInstancesSubsetService,
    MixtureOrderItemService,
    MixtureWishlistService,
    MixtureBasketService,
    MixturesOrderService,
    MixturesLocalStoreService,
    ReactionComponentInstancesService,
    ReactionComponentInstancesSubsetService,
    ReactionInstanceService,
    ReactionInstancesSubsetService,
    MultiStepReactionInstancesService,
    MultiStepReactionInstancesSubsetService,
)


def grpc_handlers(server):
    app_registry = AppHandlerRegistry("lara_django_substances_store", server)

    app_registry.get_grpc_module = lambda: "lara_django_substances_store_grpc.v1"

    app_registry.register(ExtraDataService)

    app_registry.register(SubstanceInstanceService)

    app_registry.register(SubstanceInstancesSubsetService)

    app_registry.register(SubstanceOrderItemService)

    app_registry.register(SubstancesWishlistService)

    app_registry.register(SubstanceBasketService)

    app_registry.register(SubstancesOrderService)

    app_registry.register(SubstancesLocalStoreService)

    app_registry.register(PolymerInstanceService)

    app_registry.register(PolymerInstancesSubsetService)

    app_registry.register(PolymerOrderItemService)

    app_registry.register(PolymerWishlistService)

    app_registry.register(PolymerBasketService)

    app_registry.register(PolymersOrderService)

    app_registry.register(PolymersLocalStoreService)

    app_registry.register(MixtureComponentInstanceService)

    app_registry.register(MixtureInstanceService)

    app_registry.register(MixtureInstancesSubsetService)

    app_registry.register(MixtureOrderItemService)

    app_registry.register(MixtureWishlistService)

    app_registry.register(MixtureBasketService)

    app_registry.register(MixturesOrderService)

    app_registry.register(MixturesLocalStoreService)

    app_registry.register(ReactionComponentInstancesService)

    app_registry.register(ReactionComponentInstancesSubsetService)

    app_registry.register(ReactionInstanceService)

    app_registry.register(ReactionInstancesSubsetService)

    app_registry.register(MultiStepReactionInstancesService)

    app_registry.register(MultiStepReactionInstancesSubsetService)
