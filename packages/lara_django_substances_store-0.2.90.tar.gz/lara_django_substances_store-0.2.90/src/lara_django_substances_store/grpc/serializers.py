"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC serializer*

:details: lara_django_myproj gRPC serializer.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_substances_store  (LARA-version)

import logging

from django_socio_grpc import proto_serializers
from rest_framework.serializers import UUIDField, PrimaryKeyRelatedField
from lara_django_base.models import (
    Namespace,
    DataType,
    MediaType,
    PhysicalUnit,
    PhysicalStateMatter,
    ScientificConstant,
    Tag,
    ItemStatus,
    ExternalResource,
    Location,
    Currency,
)
from lara_django_people.models import (
    Entity,
    Group,
)

from lara_django_material_store.models import (
    LabwareInstance,
)

from lara_django_substances.models import (
    SubstanceClass,
    Isotope,
    Substance,
    Polymer,
    Mixture,
    ReactionComponent,
    Reaction,
    MultiStepReaction,
)
from lara_django_substances_store.models import (
    ExtraData,
    SubstanceInstance,
    SubstanceInstancesSubset,
    SubstanceOrderItem,
    SubstanceWishlist,
    SubstanceBasket,
    SubstancesOrder,
    SubstancesLocalStore,
    PolymerInstance,
    PolymerInstancesSubset,
    PolymerOrderItem,
    PolymerWishlist,
    PolymerBasket,
    PolymersOrder,
    PolymersLocalStore,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureInstancesSubset,
    MixtureOrderItem,
    MixtureWishlist,
    MixtureBasket,
    MixturesOrder,
    MixturesLocalStore,
    ReactionComponentInstance,
    ReactionComponentInstancesSubset,
    ReactionInstance,
    ReactionInstancesSubset,
    MultiStepReactionInstance,
    MultiStepReactionInstancesSubset,
)

import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2 as lara_django_substances_store_pb2


class ExtraDataProtoSerializer(proto_serializers.ModelProtoSerializer):
    data_type = PrimaryKeyRelatedField(
        queryset=DataType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    media_type = PrimaryKeyRelatedField(
        queryset=MediaType.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ExtraData
        proto_class = lara_django_substances_store_pb2.ExtraDataResponse

        proto_class_list = lara_django_substances_store_pb2.ExtraDataListResponse

        fields = "__all__"  # [data_type', namespace', URI', text', XML', JSON', bin', media_type', IRI', URL', description', file', image']


class SubstanceInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    substance = PrimaryKeyRelatedField(
        queryset=Substance.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    isotopes = PrimaryKeyRelatedField(
        queryset=Isotope.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = SubstanceInstance
        proto_class = lara_django_substances_store_pb2.SubstanceInstanceResponse

        proto_class_list = (
            lara_django_substances_store_pb2.SubstanceInstanceListResponse
        )

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle', IRI', registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency', datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256', description', amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes', hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature', substance']


class SubstanceInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = SubstanceInstancesSubset
        proto_class = lara_django_substances_store_pb2.SubstanceInstancesSubsetResponse

        proto_class_list = (
            lara_django_substances_store_pb2.SubstanceInstancesSubsetListResponse
        )

        fields = "__all__"


class SubstanceOrderItemProtoSerializer(proto_serializers.ModelProtoSerializer):
    substance_instance = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
    )
    substance_wishlist = PrimaryKeyRelatedField(
        queryset=SubstanceWishlist.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    substance_basket = PrimaryKeyRelatedField(
        queryset=SubstanceBasket.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    substance_order = PrimaryKeyRelatedField(
        queryset=SubstancesOrder.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = SubstanceOrderItem
        proto_class = lara_django_substances_store_pb2.SubstanceOrderItemResponse

        proto_class_list = (
            lara_django_substances_store_pb2.SubstanceOrderItemListResponse
        )

        fields = "__all__"  # [quantity', item_price_net', item_price_gross', item_transport_price', item_price_tax', item_toll', toll_number', item_discount', total_price_net', substance_instance']


class SubstancesWishlistProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = SubstanceWishlist
        proto_class = lara_django_substances_store_pb2.SubstancesWishlistResponse

        proto_class_list = (
            lara_django_substances_store_pb2.SubstancesWishlistListResponse
        )

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class SubstanceBasketProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = SubstanceBasket
        proto_class = lara_django_substances_store_pb2.SubstanceBasketResponse

        proto_class_list = lara_django_substances_store_pb2.SubstanceBasketListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class SubstancesOrderProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordered = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordering = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordered = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordering = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    provider = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    transport_company = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    order_currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    order_status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    order_quotes = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    order_invoices = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = SubstancesOrder
        proto_class = lara_django_substances_store_pb2.SubstancesOrderResponse

        proto_class_list = lara_django_substances_store_pb2.SubstancesOrderListResponse

        fields = "__all__"  # [namespace', name_full', IRI', entity_ordered', entity_ordering', datetime_order', order_barcode', provider', datetime_order_quote', datetime_order_invoice', transport_company', transport_price', budget_url', datetime_order_pay', order_total_price_net', order_total_price_gross', order_total_price_tax', order_total_price_toll', order_currency', order_status']


class SubstancesLocalStoreProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    substance_instances = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = SubstancesLocalStore
        proto_class = lara_django_substances_store_pb2.SubstancesLocalStoreResponse

        proto_class_list = (
            lara_django_substances_store_pb2.SubstancesLocalStoreListResponse
        )

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified', location']


class PolymerInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    polymer = PrimaryKeyRelatedField(
        queryset=Polymer.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    isotopes = PrimaryKeyRelatedField(
        queryset=Isotope.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = PolymerInstance
        proto_class = lara_django_substances_store_pb2.PolymerInstanceResponse

        proto_class_list = lara_django_substances_store_pb2.PolymerInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle', IRI', registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency', datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256', description', amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes', hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature', polymer']


class PolymerInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = PolymerInstancesSubset
        proto_class = lara_django_substances_store_pb2.PolymerInstancesSubsetResponse

        proto_class_list = (
            lara_django_substances_store_pb2.PolymerInstancesSubsetListResponse
        )

        fields = "__all__"


class PolymerOrderItemProtoSerializer(proto_serializers.ModelProtoSerializer):
    polymer_instance = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    polymer_wishlist = PrimaryKeyRelatedField(
        queryset=PolymerWishlist.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    polymer_basket = PrimaryKeyRelatedField(
        queryset=PolymerBasket.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    polymers_order = PrimaryKeyRelatedField(
        queryset=PolymersOrder.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = PolymerOrderItem
        proto_class = lara_django_substances_store_pb2.PolymerOrderItemResponse

        proto_class_list = lara_django_substances_store_pb2.PolymerOrderItemListResponse

        fields = "__all__"  # [quantity', item_price_net', item_price_gross', item_transport_price', item_price_tax', item_toll', toll_number', item_discount', total_price_net', polymer_instance']


class PolymerWishlistProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = PolymerWishlist
        proto_class = lara_django_substances_store_pb2.PolymerWishlistResponse

        proto_class_list = lara_django_substances_store_pb2.PolymerWishlistListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class PolymerBasketProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = PolymerBasket
        proto_class = lara_django_substances_store_pb2.PolymerBasketResponse

        proto_class_list = lara_django_substances_store_pb2.PolymerBasketListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class PolymersOrderProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordered = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordering = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordered = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordering = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    provider = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    transport_company = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    order_currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    order_status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    order_quotes = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    order_invoices = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )

    class Meta:
        model = PolymersOrder
        proto_class = lara_django_substances_store_pb2.PolymersOrderResponse

        proto_class_list = lara_django_substances_store_pb2.PolymersOrderListResponse

        fields = "__all__"  # [namespace', name_full', IRI', entity_ordered', entity_ordering', datetime_order', order_barcode', provider', datetime_order_quote', datetime_order_invoice', transport_company', transport_price', budget_url', datetime_order_pay', order_total_price_net', order_total_price_gross', order_total_price_tax', order_total_price_toll', order_currency', order_status']


class PolymersLocalStoreProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    polymer_instances = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = PolymersLocalStore
        proto_class = lara_django_substances_store_pb2.PolymersLocalStoreResponse

        proto_class_list = (
            lara_django_substances_store_pb2.PolymersLocalStoreListResponse
        )

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified', location']


class MixtureComponentInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    amount_unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    concentration_unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )

    substance_instance = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    polymer_instance = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixtureComponentInstance
        proto_class = lara_django_substances_store_pb2.MixtureComponentInstanceResponse

        proto_class_list = (
            lara_django_substances_store_pb2.MixtureComponentInstanceListResponse
        )

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle',
                             # registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency',
                             # datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256',
                             # amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes',
                             # hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature',
                             # IRI', substance', polymer', concentration',  'description']


class MixtureInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    mixture = PrimaryKeyRelatedField(
        queryset=Mixture.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    components = PrimaryKeyRelatedField(
        queryset=MixtureComponentInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixtureInstance
        proto_class = lara_django_substances_store_pb2.MixtureInstanceResponse

        proto_class_list = lara_django_substances_store_pb2.MixtureInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle', IRI', registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency', datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256', description', amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes', hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature', mixture']


class MixtureInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixtureInstancesSubset
        proto_class = lara_django_substances_store_pb2.MixtureInstancesSubsetResponse

        proto_class_list = (
            lara_django_substances_store_pb2.MixtureInstancesSubsetListResponse
        )

        fields = "__all__"


class MixtureOrderItemProtoSerializer(proto_serializers.ModelProtoSerializer):
    mixture_instance = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    mixture_wishlist = PrimaryKeyRelatedField(
        queryset=MixtureWishlist.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    mixture_basket = PrimaryKeyRelatedField(
        queryset=MixtureBasket.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    mixtures_order = PrimaryKeyRelatedField(
        queryset=MixturesOrder.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixtureOrderItem
        proto_class = lara_django_substances_store_pb2.MixtureOrderItemResponse

        proto_class_list = lara_django_substances_store_pb2.MixtureOrderItemListResponse

        fields = "__all__"  # [quantity', item_price_net', item_price_gross', item_transport_price', item_price_tax', item_toll', toll_number', item_discount', total_price_net', mixture_instance']


class MixtureWishlistProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = MixtureWishlist
        proto_class = lara_django_substances_store_pb2.MixtureWishlistResponse

        proto_class_list = lara_django_substances_store_pb2.MixtureWishlistListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class MixtureBasketProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    class Meta:
        model = MixtureBasket
        proto_class = lara_django_substances_store_pb2.MixtureBasketResponse

        proto_class_list = lara_django_substances_store_pb2.MixtureBasketListResponse

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified']


class MixturesOrderProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordered = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity_ordering = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordered = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group_ordering = PrimaryKeyRelatedField(
        queryset=Group.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    provider = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    transport_company = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    order_currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    order_status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )

    order_quotes = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    order_invoices = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixturesOrder
        proto_class = lara_django_substances_store_pb2.MixturesOrderResponse

        proto_class_list = lara_django_substances_store_pb2.MixturesOrderListResponse

        fields = "__all__"  # [namespace', name_full', IRI', entity_ordered', entity_ordering', datetime_order', order_barcode', provider', datetime_order_quote', datetime_order_invoice', transport_company', transport_price', budget_url', datetime_order_pay', order_total_price_net', order_total_price_gross', order_total_price_tax', order_total_price_toll', order_currency', order_status']


class MixturesLocalStoreProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    mixture_instances = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MixturesLocalStore
        proto_class = lara_django_substances_store_pb2.MixturesLocalStoreResponse

        proto_class_list = (
            lara_django_substances_store_pb2.MixturesLocalStoreListResponse
        )

        fields = "__all__"  # [namespace', name_full', entity', datetime_created', datetime_last_modified', location']


class ReactionComponentInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    concentration_unit = PrimaryKeyRelatedField(
        queryset=PhysicalUnit.objects.all(), pk_field=UUIDField(format="hex_verbose"), required=False, allow_null=True
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    substance_instance = PrimaryKeyRelatedField(
        queryset=SubstanceInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    polymer_instance = PrimaryKeyRelatedField(
        queryset=PolymerInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    mixture_instance = PrimaryKeyRelatedField(
        queryset=MixtureInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    roles = PrimaryKeyRelatedField(
        queryset=SubstanceClass.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ReactionComponentInstance
        proto_class = lara_django_substances_store_pb2.ReactionComponentInstanceResponse

        proto_class_list = lara_django_substances_store_pb2.ReactionComponentInstanceListResponse

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle', IRI', registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency', datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256', description', amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes', hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature', substance_instance', polymer_instance', mixture_instance', roles']


class ReactionComponentInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    reaction_component_instances = PrimaryKeyRelatedField(
        queryset=ReactionComponentInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ReactionComponentInstancesSubset
        proto_class = lara_django_substances_store_pb2.ReactionComponentInstancesSubsetResponse

        proto_class_list = (
            lara_django_substances_store_pb2.ReactionComponentInstancesSubsetListResponse
        )

        fields = "__all__"


class ReactionInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    reaction_base = PrimaryKeyRelatedField(
        queryset=Reaction.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    component_instances = PrimaryKeyRelatedField(
        queryset=ReactionComponentInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ReactionInstance
        proto_class = lara_django_substances_store_pb2.ReactionInstanceResponse

        proto_class_list = lara_django_substances_store_pb2.ReactionInstanceListResponse

        fields = "__all__"


class ReactionInstancesSubsetProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    reaction_instances = PrimaryKeyRelatedField(
        queryset=ReactionInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = ReactionInstancesSubset
        proto_class = lara_django_substances_store_pb2.ReactionInstancesSubsetResponse

        proto_class_list = (
            lara_django_substances_store_pb2.ReactionInstancesSubsetListResponse
        )

        fields = "__all__"


class MultiStepReactionInstanceProtoSerializer(proto_serializers.ModelProtoSerializer):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    vendor = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    currency = PrimaryKeyRelatedField(
        queryset=Currency.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    location = PrimaryKeyRelatedField(
        queryset=Location.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    status = PrimaryKeyRelatedField(
        queryset=ItemStatus.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    entities_responsible = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    entities_own = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    users = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    groups = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    resources_external = PrimaryKeyRelatedField(
        queryset=ExternalResource.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )
    labware_instance = PrimaryKeyRelatedField(
        queryset=LabwareInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    physical_state_matter = PrimaryKeyRelatedField(
        queryset=PhysicalStateMatter.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )

    reaction_instances = PrimaryKeyRelatedField(
        queryset=ReactionInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    data_extra = PrimaryKeyRelatedField(
        queryset=ExtraData.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MultiStepReactionInstance
        proto_class = lara_django_substances_store_pb2.MultiStepReactionInstanceResponse

        proto_class_list = (
            lara_django_substances_store_pb2.MultiStepReactionInstanceListResponse
        )

        fields = "__all__"  # [namespace', name', name_full', barcode', barcode_json', UUID', URL', handle', IRI', registration_no', vendor', serial_no', service_no', datetime_manufacturing', price', currency', datetime_purchase', datetime_delivery', datetime_end_of_warranty', location', hash_sha256', description', amount_volume', amount_mass', purity', ph', physical_state_matter', labware', hazard_classes', hazard_statements', precautionary_statements', hazard_symbols', storage_class', literature', reaction_instances']


class MultiStepReactionInstancesSubsetProtoSerializer(
    proto_serializers.ModelProtoSerializer
):
    namespace = PrimaryKeyRelatedField(
        queryset=Namespace.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    entity = PrimaryKeyRelatedField(
        queryset=Entity.objects.all(), pk_field=UUIDField(format="hex_verbose")
    )
    group = PrimaryKeyRelatedField(
        queryset=Group.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        required=False,
        allow_null=True,
    )
    reactions_multistep_instances = PrimaryKeyRelatedField(
        queryset=MultiStepReactionInstance.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
    )
    tags = PrimaryKeyRelatedField(
        queryset=Tag.objects.all(),
        pk_field=UUIDField(format="hex_verbose"),
        many=True,
        required=False,
        allow_null=True,
    )

    class Meta:
        model = MultiStepReactionInstancesSubset
        proto_class = (
            lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetResponse
        )

        proto_class_list = (
            lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetListResponse
        )

        fields = "__all__"
