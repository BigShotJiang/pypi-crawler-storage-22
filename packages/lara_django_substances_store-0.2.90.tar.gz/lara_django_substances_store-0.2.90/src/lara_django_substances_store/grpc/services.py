"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_myproj gRPC services*

:details: lara_django_myproj gRPC services.
         - 
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

## generated with django-socio-grpc generateprpcinterface lara_django_substances_store  (LARA-version)

from django_socio_grpc import generics, mixins
from lara_django_base.grpc.mixins import AsyncUploadModelMixin, AsyncRetrieveByNameModelMixin, AsyncDownloadModelMixin

from .serializers import (
    ExtraDataProtoSerializer,
    SubstanceInstanceProtoSerializer,
    SubstanceInstancesSubsetProtoSerializer,
    SubstanceOrderItemProtoSerializer,
    SubstancesWishlistProtoSerializer,
    SubstanceBasketProtoSerializer,
    SubstancesOrderProtoSerializer,
    SubstancesLocalStoreProtoSerializer,
    PolymerInstanceProtoSerializer,
    PolymerInstancesSubsetProtoSerializer,
    PolymerOrderItemProtoSerializer,
    PolymerWishlistProtoSerializer,
    PolymerBasketProtoSerializer,
    PolymersOrderProtoSerializer,
    PolymersLocalStoreProtoSerializer,
    MixtureComponentInstanceProtoSerializer,
    MixtureInstanceProtoSerializer,
    MixtureInstancesSubsetProtoSerializer,
    MixtureOrderItemProtoSerializer,
    MixtureWishlistProtoSerializer,
    MixtureBasketProtoSerializer,
    MixturesOrderProtoSerializer,
    MixturesLocalStoreProtoSerializer,
    ReactionComponentInstanceProtoSerializer,
    ReactionComponentInstancesSubsetProtoSerializer,
    ReactionInstanceProtoSerializer,
    ReactionInstancesSubsetProtoSerializer,
    MultiStepReactionInstanceProtoSerializer,
    MultiStepReactionInstancesSubsetProtoSerializer,

)

from ..filters import (
    SubstanceInstanceFilterSet,
    PolymerInstanceFilterSet,
    MixtureComponentInstanceFilterSet,
    MixtureInstanceFilterSet,
)
from lara_django_substances_store.models import (
    ExtraData,
    SubstanceInstance,
    SubstanceInstancesSubset,
    SubstanceOrderItem,
    SubstanceWishlist,
    SubstanceBasket,
    SubstancesOrder,
    SubstancesLocalStore,
    PolymerInstance,
    PolymerInstancesSubset,
    PolymerOrderItem,
    PolymerWishlist,
    PolymerBasket,
    PolymersOrder,
    PolymersLocalStore,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureInstancesSubset,
    MixtureOrderItem,
    MixtureWishlist,
    MixtureBasket,
    MixturesOrder,
    MixturesLocalStore,
    ReactionComponentInstance,
    ReactionComponentInstancesSubset,
    ReactionInstance,
    ReactionInstancesSubset,
    MultiStepReactionInstance,
    MultiStepReactionInstancesSubset,
)
import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2 as lara_django_substances_store_pb2

class ExtraDataService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = ExtraData.objects.all()
    serializer_class = ExtraDataProtoSerializer


class SubstanceInstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = SubstanceInstance.objects.all()
    serializer_class = SubstanceInstanceProtoSerializer
    filterset_class = SubstanceInstanceFilterSet

class SubstanceInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstanceInstancesSubset.objects.all()
    serializer_class = SubstanceInstancesSubsetProtoSerializer
    # filterset_class = SubstanceInstancesSubsetFilterSet


class SubstanceOrderItemService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstanceOrderItem.objects.all()
    serializer_class = SubstanceOrderItemProtoSerializer


class SubstancesWishlistService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstanceWishlist.objects.all()
    serializer_class = SubstancesWishlistProtoSerializer


class SubstanceBasketService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstanceBasket.objects.all()
    serializer_class = SubstanceBasketProtoSerializer


class SubstancesOrderService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = SubstancesOrder.objects.all()
    serializer_class = SubstancesOrderProtoSerializer


class SubstancesLocalStoreService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = SubstancesLocalStore.objects.all()
    serializer_class = SubstancesLocalStoreProtoSerializer


class PolymerInstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = PolymerInstance.objects.all()
    serializer_class = PolymerInstanceProtoSerializer
    filterset_class = PolymerInstanceFilterSet

class PolymerInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymerInstancesSubset.objects.all()
    serializer_class = PolymerInstancesSubsetProtoSerializer
    # filterset_class = PolymerInstancesSubsetFilterSet


class PolymerOrderItemService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymerOrderItem.objects.all()
    serializer_class = PolymerOrderItemProtoSerializer


class PolymerWishlistService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymerWishlist.objects.all()
    serializer_class = PolymerWishlistProtoSerializer


class PolymerBasketService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymerBasket.objects.all()
    serializer_class = PolymerBasketProtoSerializer


class PolymersOrderService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = PolymersOrder.objects.all()
    serializer_class = PolymersOrderProtoSerializer


class PolymersLocalStoreService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = PolymersLocalStore.objects.all()
    serializer_class = PolymersLocalStoreProtoSerializer


class MixtureComponentInstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureComponentInstance.objects.all()
    serializer_class = MixtureComponentInstanceProtoSerializer
    filterset_class = MixtureComponentInstanceFilterSet


class MixtureInstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = MixtureInstance.objects.all()
    serializer_class = MixtureInstanceProtoSerializer
    filterset_class = MixtureInstanceFilterSet

class MixtureInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureInstancesSubset.objects.all()
    serializer_class = MixtureInstancesSubsetProtoSerializer
    # filterset_class = MixtureInstancesSubsetFilterSet


class MixtureOrderItemService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureOrderItem.objects.all()
    serializer_class = MixtureOrderItemProtoSerializer


class MixtureWishlistService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureWishlist.objects.all()
    serializer_class = MixtureWishlistProtoSerializer


class MixtureBasketService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixtureBasket.objects.all()
    serializer_class = MixtureBasketProtoSerializer


class MixturesOrderService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixturesOrder.objects.all()
    serializer_class = MixturesOrderProtoSerializer


class MixturesLocalStoreService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MixturesLocalStore.objects.all()
    serializer_class = MixturesLocalStoreProtoSerializer

class ReactionComponentInstancesService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = ReactionComponentInstance.objects.all()
    serializer_class = ReactionComponentInstanceProtoSerializer
    # filterset_class = ReactionComponentInstanceFilterSet

class ReactionComponentInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = ReactionComponentInstancesSubset.objects.all()
    serializer_class = ReactionComponentInstancesSubsetProtoSerializer
    # filterset_class = ReactionComponentInstancesSubsetFilterSet

class ReactionInstanceService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = ReactionInstance.objects.all()
    serializer_class = ReactionInstanceProtoSerializer
    # filterset_class = ReactionInstanceFilterSet

class ReactionInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = ReactionInstancesSubset.objects.all()
    serializer_class = ReactionInstancesSubsetProtoSerializer
    # filterset_class = ReactionInstancesSubsetFilterSet

class MultiStepReactionInstancesService(generics.AsyncModelService, mixins.AsyncStreamModelMixin, AsyncUploadModelMixin,
    AsyncRetrieveByNameModelMixin,
    AsyncDownloadModelMixin,):
    pb2 = lara_django_substances_store_pb2
    queryset = MultiStepReactionInstance.objects.all()
    serializer_class = MultiStepReactionInstanceProtoSerializer
    # filterset_class = MultiStepReactionInstanceFilterSet

class MultiStepReactionInstancesSubsetService(generics.AsyncModelService, mixins.AsyncStreamModelMixin):
    queryset = MultiStepReactionInstancesSubset.objects.all()
    serializer_class = MultiStepReactionInstancesSubsetProtoSerializer
    # filterset_class = MultiStepReactionInstancesSubsetFilterSet