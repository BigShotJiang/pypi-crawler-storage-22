"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store models *

:details: lara_django_substances_store database models.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - remove unwanted models/fields
________________________________________________________________________
"""

import logging
from datetime import date, datetime, timedelta
import uuid
import hashlib
import json
from random import randint

from django.utils import timezone
from django.conf import settings
from django.utils.translation import gettext_lazy as _

from django.contrib.postgres.indexes import GinIndex
from django.contrib.postgres.search import SearchVectorField


from django.db import models

from lara_django_base.models import (
    DataType,
    MediaType,
    ExtraDataAbstr,
    ExternalResource,
    Namespace,
    Tag,
    PhysicalUnit,
    PhysicalStateMatter,
)
from lara_django_people.models import Entity, ItemSubsetAbstr
from lara_django_store.models import (
    ItemInstanceAbstr,
    OrderItemAbstr,
    ItemOrderAbstr,
    ItemBasketAbstr,
)

from lara_django_substances.models import (
    SubstanceClass,
    Isotope,
    Substance,
    Polymer,
    MixtureComponent,
    Mixture,
    ReactionComponent,
    Reaction,
    MultiStepReaction,
)
from lara_django_material_store.models import LabwareInstance


# from lara_django_processes.models import ProcdureInstance # !! circular import

from lara_django_base.models import (
    ExtraDataAbstr,
    Currency,
    DataType,
    MediaType,
    Namespace,
    Tag,
    Location,
    ItemStatus,
)

settings.FIXTURES += []


class ExtraData(ExtraDataAbstr):
    """This class can be used to extend data, by extra information,
    e.g. more telephone numbers, customer numbers, ..."""

    model_curi = "lara:substances-store/ExtraData"

    file = models.FileField(
        upload_to="substances_store",
        blank=True,
        null=True,
        help_text="rel. path/filename",
    )
    image = models.ImageField(
        upload_to="substances_store/images/",
        blank=True,
        null=True,
        help_text="extra substance image",
    )

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for name_full
        """

        if self.version is None or self.version == "":
            self.version = "0.0.1"

        if self.hash_sha256 is None:
            if self.data_json is not None:
                to_hash = json.dumps(self.data_json)  # +  str(self.UUID) +
                self.hash_sha256 = hashlib.sha256(to_hash.encode("utf-8")).hexdigest()
            else:
                self.hash_sha256 = hashlib.sha256(str(self.extradata_id).encode("utf-8")).hexdigest()

        if self.name is None or self.name == "":
            if self.name_display is None or self.name_display == "":
                self.name = "_".join(
                    (
                        timezone.now().strftime("%Y%m%d_%H%M%S"),
                        "data",
                        self.hash_sha256[:8],
                    )
                )
            else:
                self.name = self.name_display.replace(" ", "_").lower().strip()

        else:
            self.name = self.name.replace(" ", "_").lower().strip()
        if self.name_full is None or self.name_full == "":
            if self.namespace is not None and self.version is not None:
                self.name_full = f"{self.namespace.uri}/" + "_".join((self.name.replace(" ", "_"), self.version))
            else:
                self.name_full = "_".join((self.name.replace(" ", "_"), self.version))

        if not self.iri:
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path

            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/ExtraData/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class SubstanceInstanceAbstr(ItemInstanceAbstr):
    amount_volume = models.DecimalField(max_digits=20, decimal_places=16, blank=True, null=True, help_text="in L")
    amount_mass = models.DecimalField(max_digits=20, decimal_places=16, blank=True, null=True, help_text="in g")
    purity = models.DecimalField(blank=True, null=True, decimal_places=16, max_digits=16, help_text="in /1")
    purity_info = models.JSONField(blank=True, null=True, help_text="purity information")

    isotopes = models.ManyToManyField(
        Isotope,
        related_name="%(app_label)s_%(class)s_isotopes_related",
        related_query_name="%(app_label)s_%(class)s_isotopes_related_query",
        blank=True,
        help_text="isotopes",
    )

    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge,  ...",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    physical_state_matter = models.ForeignKey(
        PhysicalStateMatter,
        related_name="%(app_label)s_%(class)s_state_of_matter_related",
        related_query_name="%(app_label)s_%(class)s_state_of_matter_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="physical state of matter at 293 K of this particular instance",
    )
    labware_instance = models.ForeignKey(
        LabwareInstance,
        related_name="%(app_label)s_%(class)s_labware_related",
        related_query_name="%(app_label)s_%(class)s_labware_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="labware of the substance instance",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="substance extra data that is not covered by the default fields",
    )
    search_vector = SearchVectorField(null=True)

    class Meta:
        abstract = True
        indexes = (GinIndex(fields=["search_vector"]),)


class SubstanceInstance(SubstanceInstanceAbstr):
    """Substance Instance, i.e. a specific instance of a substance that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/SubstanceInstance"
    substanceinstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    substance = models.ForeignKey(
        Substance,
        related_name="%(app_label)s_%(class)s_subtances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""

        if self.substance is not None:
            if self.name is None or self.name == "":
                self.name = self.substance.name

            if self.name_display is None or self.name_display == "":
                self.name_display = self.substance.name_display

            if self.description is None or self.description == "":
                self.description = self.substance.description
        else:
            if (self.name is None or self.name == "") and self.name_display is not None:
                self.name = self.name_display.strip().replace(" ", "_").lower()

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(self.substanceinstance_id)[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/SubstanceInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    class Meta:
        # verbose_name = "Substance Instance"
        # verbose_name_plural = "Substance Instances"
        db_table_comment = "Instance of a substance, e.g. the bottle of water, the bottle of ethanol, ..."


class SubstanceInstancesSubset(ItemSubsetAbstr):
    """Substance Instances Subset, i.e. a specific instance of a substance that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/SubstanceInstancesSubset"
    substanceinstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    substance_instances = models.ManyToManyField(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substances_instance_related",
        related_query_name="%(app_label)s_%(class)s_substances_instance_related_query",
        blank=True,
        help_text="user or group defined substance instances subset",
        through="OrderedSubstanceInstancesSubstanceInstancesSubset",
    )


class OrderedSubstanceInstancesSubstanceInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between SubstanceInstancesSubset and SubstanceInstance.
    This class can be used to store the order of substances in a subset"""

    model_curi = "lara:substances-store/OrderedSubstanceInstancesSubstanceInstancesSubset"
    orderedsubstanceinstancesubstanceinstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    substance_instance = models.ForeignKey(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substance_instance_related",
        related_query_name="%(app_label)s_%(class)s_substance_instance",
        on_delete=models.CASCADE,
        help_text="substance instance in the subset",
    )

    substance_instances_subset = models.ForeignKey(
        SubstanceInstancesSubset,
        related_name="%(app_label)s_%(class)s_substance_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_substance_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of substance instances",
    )

    order = models.IntegerField(help_text="order of substance in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["substance_instance", "substance_instances_subset"],
                name="%(app_label)s_%(class)s_substance_instance_substance_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


class SubstanceOrderItem(OrderItemAbstr):
    """Substance Order Item Model for ordering substances ...
    :param OrderItemAbstr: _description_
    :type OrderItemAbstr: _type_
    """

    model_curi = "lara:substances-store/SubstanceOrderItem"
    substanceorderitem_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    substance_instance = models.ForeignKey(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substances_instance_related",
        related_query_name="%(app_label)s_%(class)s_substances_instance_related_query",
        on_delete=models.CASCADE,
    )
    substance_wishlist = models.ForeignKey(
        'SubstanceWishlist',
        related_name="%(app_label)s_%(class)s_substances_wishlist_related",
        related_query_name="%(app_label)s_%(class)s_substances_wishlist_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    substance_basket = models.ForeignKey(
        'SubstanceBasket',
        related_name="%(app_label)s_%(class)s_substances_basket_related",
        related_query_name="%(app_label)s_%(class)s_substances_basket_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    substance_order = models.ForeignKey(
        'SubstancesOrder',
        related_name="%(app_label)s_%(class)s_substances_order_related",
        related_query_name="%(app_label)s_%(class)s_substances_order_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_oi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_oi_data_extra_related_query",
        help_text="extra data",
    )

    def __str__(self):
        return self.substance_instance.name or ""

    def __repr__(self):
        return self.substance_instance.name or ""

    class Meta:
        # verbose_name = "Substance Order Item"
        # verbose_name_plural = "Substance Order Items"
        db_table_comment = "Substance Order Item Model for ordering substances ..."


class SubstanceWishlist(ItemBasketAbstr):
    """Substances Wishlist Model for wishing substances ...
    :param ItemWishlistAbstr: _description_
    :type ItemWishlistAbstr: _type_
    """

    model_curi = "lara:substances-store/SubstanceWishlist"
    substancewishlist_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "substance_wishlist",
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    class Meta:
        # verbose_name = "Substances Wishlist"
        # verbose_name_plural = "Substances Wishlists"
        db_table_comment = "Substances Wishlist Model for wishing substances ..."


class SubstanceBasket(ItemBasketAbstr):
    """Substances Basket Model for ordering substances and put them into a basket"""

    model_curi = "lara:substances-store/SubstanceBasket"
    substancebasket_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "substance_basket",
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

class SubstancesOrder(ItemOrderAbstr):
    """Order Substances Model ...
    :param ItemOrderAbstr: _description_
    :type ItemOrderAbstr: _type_
    """

    model_curi = "lara:substances-store/SubstancesOrder"
    substancesorder_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_quotes = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_quotes_related",
        related_query_name="%(app_label)s_%(class)s_order_quotes_related_query",
        blank=True,
        help_text="Information about quotes for this order, like PDFs, Images, URLs, ...",
    )
    order_invoices = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_invoices_related",
        related_query_name="%(app_label)s_%(class)s_order_invoices_related_query",
        blank=True,
        help_text="Information about invoices for this order, like PDFs, Images, URLs, ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_po_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_po_data_extra_related_query",
        help_text="extra data",
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "substances_order",
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    # class Meta:
    # ordering = ['-datetime_created']
    # verbose_name = "Order Substancess"
    # verbose_name_plural = "Order Substancess"


class SubstancesLocalStore(ItemBasketAbstr):
    """Substances Local Store Model ...
    this can be used to store substances in a local store, e.g. in a lab"""

    model_curi = "lara:substances-store/SubstancesLocalStore"
    substanceslocalstore_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    substance_instances = models.ManyToManyField(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substances_inst_loc_related",
        related_query_name="%(app_label)s_%(class)s_substances_inst_loc_related_query",
        blank=True,
        help_text="substances in local store",
    )
    location = models.ForeignKey(
        Location,
        related_name="%(app_label)s_%(class)s_substances_loc_related",
        related_query_name="%(app_label)s_%(class)s_substances_loc_related_query",
        on_delete=models.CASCADE,
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "substances_local_store",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class PolymerInstance(SubstanceInstanceAbstr):
    """Polymer Instance"""

    model_curi = "lara:substances-store/PolymerInstance"
    polymerinstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    polymer = models.ForeignKey(
        Polymer,
        related_name="%(app_label)s_%(class)s_polymers_related",
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""

        if self.polymer is not None:
            if self.name is None or self.name == "":
                self.name = self.polymer.name

            if self.name_display is None or self.name_display == "":
                self.name_display = self.polymer.name_display

            if self.description is None or self.description == "":
                self.description = self.polymer.description
        else:
            if (self.name is None or self.name == "") and self.name_display is not None:
                self.name = self.name_display.strip().replace(" ", "_").lower()

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(self.polymerinstance_id)[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/PolymerInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.polymer.name if self.polymer and self.polymer.name else ""

    def __repr__(self):
        return self.polymer.name if self.polymer and self.polymer.name else ""


class PolymerInstancesSubset(ItemSubsetAbstr):
    """Polymer Instance Subset, i.e. a specific instance of a polymer that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/PolymerInstancseSubset"
    polymerinstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    polymer_instances = models.ManyToManyField(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_instance_related",
        related_query_name="%(app_label)s_%(class)s_polymers_instance_related_query",
        blank=True,
        help_text="user or group defined polymer instances subset",
        through="OrderedPolymerInstancesSubset",
    )


class OrderedPolymerInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between PolymerInstancesSubset and PolymerInstance.
    This class can be used to store the order of polymers in a subset"""

    model_curi = "lara:substances-store/OrderedPolymerInstancesSubset"
    orderedpolymerinstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    polymer_instance = models.ForeignKey(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymer_instance_related",
        related_query_name="%(app_label)s_%(class)s_polymer_instance",
        on_delete=models.CASCADE,
        help_text="polymer instance in the subset",
    )

    polymer_instances_subset = models.ForeignKey(
        PolymerInstancesSubset,
        related_name="%(app_label)s_%(class)s_polymer_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_polymer_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of polymer instances",
    )

    order = models.IntegerField(help_text="order of polymer in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["polymer_instance", "polymer_instances_subset"],
                name="%(app_label)s_%(class)s_polymer_instance_polymer_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


# _______________ Ordering / Wishlists ______________


class PolymerOrderItem(OrderItemAbstr):
    """Polymer Order Item Model for ordering polymers ...
    :param OrderItemAbstr: _description_
    :type OrderItemAbstr: _type_
    """

    model_curi = "lara:substances-store/PolymerOrderItem"
    polymerorderitem_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    polymer_instance = models.ForeignKey(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_instance_related",
        related_query_name="%(app_label)s_%(class)s_polymers_instance_related_query",
        on_delete=models.CASCADE,
    )
    polymer_wishlist = models.ForeignKey(
        'PolymerWishlist',
        related_name="%(app_label)s_%(class)s_polymers_wishlist_related",
        related_query_name="%(app_label)s_%(class)s_polymers_wishlist_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    polymer_basket = models.ForeignKey(
        'PolymerBasket',
        related_name="%(app_label)s_%(class)s_polymers_basket_related",
        related_query_name="%(app_label)s_%(class)s_polymers_basket_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    polymers_order = models.ForeignKey(
        'PolymersOrder',
        related_name="%(app_label)s_%(class)s_polymers_order_related",
        related_query_name="%(app_label)s_%(class)s_polymers_order_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_oi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_oi_data_extra_related_query",
        help_text="extra data",
    )

    def __str__(self):
        return self.polymer.name or ""

    def __repr__(self):
        return self.polymer.name or ""


class PolymerWishlist(ItemBasketAbstr):
    """Polymer Wishlist Model for wishing polymers ...
    :param ItemWishlistAbstr: _description_
    :type ItemWishlistAbstr: _type_
    """

    model_curi = "lara:substances-store/PolymerWishlist"
    polymerwishlist_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "polymer_wishlist",

                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class PolymerBasket(ItemBasketAbstr):
    """Polymer Basket Model for ordering polymers and put them into a basket"""

    model_curi = "lara:substances-store/PolymerBasket"
    polymerbasket_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "polymer_basket",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class PolymersOrder(ItemOrderAbstr):
    """Order Polymers Model ...
    :param ItemOrderAbstr: _description_
    :type ItemOrderAbstr: _type_
    """

    model_curi = "lara:substances-store/PolymersOrder"
    polymersorder_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_quotes = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_quotes_related",
        related_query_name="%(app_label)s_%(class)s_order_quotes_related_query",
        blank=True,
        help_text="Information about quotes for this order, like PDFs, Images, URLs, ...",
    )
    order_invoices = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_invoices_related",
        related_query_name="%(app_label)s_%(class)s_order_invoices_related_query",
        blank=True,
        help_text="Information about invoices for this order, like PDFs, Images, URLs, ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_po_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_po_data_extra_related_query",
        help_text="extra data",
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "polymers_order",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    # class Meta:
    # ordering = ['-datetime_created']
    # verbose_name = "Order Polymers"
    # verbose_name_plural = "Order Polymers"


class PolymersLocalStore(ItemBasketAbstr):
    """Polymer Local Store Model ...
    this can be used to store polymers in a local store, e.g. in a lab"""

    model_curi = "lara:substances-store/PolymersLocalStore"
    polymerlocalstore_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    polymer_instances = models.ManyToManyField(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_inst_loc_related",
        related_query_name="%(app_label)s_%(class)s_polymers_inst_loc_related_query",
        blank=True,
        help_text="polymers in local store",
    )
    location = models.ForeignKey(
        Location,
        related_name="%(app_label)s_%(class)s_polymers_loc_related",
        related_query_name="%(app_label)s_%(class)s_polymers_loc_related_query",
        on_delete=models.CASCADE,
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "polymers_local_store",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class MixtureComponentInstance(SubstanceInstanceAbstr):
    """Mixture Component Instance"""

    model_curi = "lara:substances-store/MixtureComponentInstance"
    mixturecomponentinstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    substance_instance = models.ForeignKey(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        help_text="substance instance",
    )
    polymer_instance = models.ForeignKey(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_related",
        blank=True,
        null=True,
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        on_delete=models.CASCADE,
        help_text="polymer instance",
    )
    amount = models.DecimalField(
        max_digits=42,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="amount of substance in mol (in mixtures)",
    )
    amount_unit = models.ForeignKey(
        PhysicalUnit,
        related_name="%(app_label)s_%(class)s_unit_related",
        related_query_name="%(app_label)s_%(class)s_unit_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="amount of substance in mol (in mixtures) - or number of molecules in a complex (protein-ligand, protein-protein, ...)",
    )
    concentration = models.DecimalField(
        max_digits=20,
        decimal_places=16,
        blank=True,
        null=True,
        help_text="concentration in mol/l",
    )
    concentration_unit = models.ForeignKey(
        PhysicalUnit,
        related_name="%(app_label)s_%(class)s_concentration_unit_related",
        related_query_name="%(app_label)s_%(class)s_concentration_unit_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="unit of concentration, e.g. mol/l , kg/l  ...",
    )
    description = models.TextField(blank=True, help_text="description")

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            if self.substance_instance is not None:
                self.name = self.substance_instance.name
            elif self.polymer_instance is not None:
                self.name = self.polymer_instance.name

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(uuid.uuid4())[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/MixtureComponentInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class MixtureInstance(SubstanceInstanceAbstr):
    """Mixture Instance"""

    model_curi = "lara:substances-store/MixtureInstance"
    mixtureinstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    components = models.ManyToManyField(
        MixtureComponentInstance,
        related_name="%(app_label)s_%(class)s_components_related",
        related_query_name="%(app_label)s_%(class)s_components_related_query",
        help_text="components of the mixture instance",
        blank=True,
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge, ...",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    mixture = models.ForeignKey(
        Mixture,
        related_name="%(app_label)s_%(class)s_mixtures_related",
        blank=True,
        null=True,
        related_query_name="%(app_label)s_%(class)s_mixtures_related_query",
        on_delete=models.CASCADE,
        help_text="abstract reference mixture",
    )
    procedure_url = models.URLField(
        blank=True,
        null=True,
        max_length=512,
        help_text="URL to the (instance) procedure of the mixture production",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_mi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_mi_data_extra_related_query",
        help_text="extra data",
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.mixture is not None:
            if self.name is None or self.name == "":
                self.name = self.mixture.name

            if self.name_display is None or self.name_display == "":
                self.name_display = self.mixture.name_display

            if self.description is None or self.description == "":
                self.description = self.mixture.description
        else:
            if (self.name is None or self.name == "") and self.name_display is not None:
                self.name = self.name_display.strip().replace(" ", "_").lower()

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(uuid.uuid4())[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/MixtureInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


class MixtureInstancesSubset(ItemSubsetAbstr):
    """Mixture Instance Subset, i.e. a specific instance of a mixture that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/MixtureInstancesSubset"
    mixtureinstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    mixture_instances = models.ManyToManyField(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixture_instance_related",
        related_query_name="%(app_label)s_%(class)s_mixture_instance_related_query",
        help_text="mixture instances",
        through="OrderedMixtureInstancesSubset",
    )

    def __str__(self):
        return self.mixture_instances.name or ""

    def __repr__(self):
        return self.mixture_instances.name or ""

    class Meta:
        # verbose_name = "Mixture Instance Subset"
        # verbose_name_plural = "Mixture Instance Subsets"
        db_table_comment = "Mixture Instance Subset, i.e. a specific instance of a mixture that is stored in a lab, like a bottle of water, a bottle of ethanol, ..."


class OrderedMixtureInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between MixtureInstancesSubset and MixtureInstance.
    This class can be used to store the order of mixtures in a subset"""

    model_curi = "lara:substances-store/OrderedMixtureInstancesSubset"
    orderedmixtureinstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    mixture_instance = models.ForeignKey(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixture_instance_related",
        related_query_name="%(app_label)s_%(class)s_mixture_instance",
        on_delete=models.CASCADE,
        help_text="mixture instance in the subset",
    )

    mixture_instances_subset = models.ForeignKey(
        MixtureInstancesSubset,
        related_name="%(app_label)s_%(class)s_mixture_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_mixture_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of mixture instances",
    )

    order = models.IntegerField(help_text="order of mixture in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["mixture_instance", "mixture_instances_subset"],
                name="%(app_label)s_%(class)s_mixture_instance_mixture_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


# _______________ Ordering / Wishlists ______________


class MixtureOrderItem(OrderItemAbstr):
    """Mixture Order Item Model for ordering mixtures ...
    :param OrderItemAbstr: _description_
    :type OrderItemAbstr: _type_
    """

    model_curi = "lara:substances-store/MixtureOrderItem"
    mixtureorderitem_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    mixture_instance = models.ForeignKey(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixtures_instance_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_instance_related_query",
        on_delete=models.CASCADE,
    )
    mixture_wishlist = models.ForeignKey(
        'MixtureWishlist',
        related_name="%(app_label)s_%(class)s_mixtures_wishlist_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_wishlist_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    mixture_basket = models.ForeignKey(
        'MixtureBasket',
        related_name="%(app_label)s_%(class)s_mixtures_basket_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_basket_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    mixtures_order = models.ForeignKey(
        'MixturesOrder',
        related_name="%(app_label)s_%(class)s_mixtures_order_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_order_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_oi_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_oi_data_extra_related_query",
        help_text="extra data",
    )

    def __str__(self):
        return self.mixture.name or ""

    def __repr__(self):
        return self.mixture.name or ""


class MixtureWishlist(ItemBasketAbstr):
    """Mixture Wishlist Model for wishing mixtures ...
    :param ItemWishlistAbstr: _description_
    :type ItemWishlistAbstr: _type_
    """

    model_curi = "lara:substances-store/MixtureWishlist"
    mixturewishlist_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "mixture_wishlist",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""



class MixtureBasket(ItemBasketAbstr):
    """Mixture Basket Model for ordering mixtures and put them into a basket"""

    model_curi = "lara:substances-store/MixtureBasket"
    mixturebasket_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)


    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "mixture_basket",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""



class MixturesOrder(ItemOrderAbstr):
    """Order Mixtures Model"""

    model_curi = "lara:substances-store/MixturesOrder"
    mixturesorder_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    order_quotes = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_quotes_related",
        related_query_name="%(app_label)s_%(class)s_order_quotes_related_query",
        blank=True,
        help_text="Information about quotes for this order, like PDFs, Images, URLs, ...",
    )
    order_invoices = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_order_invoices_related",
        related_query_name="%(app_label)s_%(class)s_order_invoices_related_query",
        blank=True,
        help_text="Information about invoices for this order, like PDFs, Images, URLs, ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_po_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_po_data_extra_related_query",
        help_text="extra data",
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "mixtures_order",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    # class Meta:
    # ordering = ['-datetime_created']
    # verbose_name = "Order Mixtures"
    # verbose_name_plural = "Order Mixtures"


class MixturesLocalStore(ItemBasketAbstr):
    """Mixture Local Store Model ...
    this can be used to store mixtures in a local store, e.g. in a lab"""

    model_curi = "lara:substances-store/MixturesLocalStore"
    mixturelocalstore_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    mixture_instances = models.ManyToManyField(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixtures_inst_loc_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_inst_loc_related_query",
        blank=True,
        help_text="mixtures in local store",
    )
    location = models.ForeignKey(
        Location,
        related_name="%(app_label)s_%(class)s_mixtures_loc_related",
        related_query_name="%(app_label)s_%(class)s_mixtures_loc_related_query",
        on_delete=models.CASCADE,
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.name is None or self.name == "":
            self.name = "_".join(
                (
                    timezone.now().strftime("%Y%m%d_%H%M%S"),
                    "mixtures_local_store",
                    str(uuid.uuid4())[:8],
                )
            )

        if self.datetime_created is None:
            self.datetime_created = timezone.now()

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""


# _______________ Reactants and Reaction Instances ______________


class ReactionComponentInstance(ItemInstanceAbstr):
    """Reaction Component Instance"""

    model_curi = "lara:substances-store/ReactionComponentInstance"
    reactioncomponentinstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    substance_instance = models.ForeignKey(
        SubstanceInstance,
        related_name="%(app_label)s_%(class)s_substances_related",
        related_query_name="%(app_label)s_%(class)s_substances_related_query",
        blank=True,
        null=True,
        on_delete=models.CASCADE,
        help_text="substance instance",
    )
    polymer_instance = models.ForeignKey(
        PolymerInstance,
        related_name="%(app_label)s_%(class)s_polymers_related",
        blank=True,
        null=True,
        related_query_name="%(app_label)s_%(class)s_polymers_related_query",
        on_delete=models.CASCADE,
        help_text="polymer instance",
    )
    mixture_instance = models.ForeignKey(
        MixtureInstance,
        related_name="%(app_label)s_%(class)s_mixtures_related",
        blank=True,
        null=True,
        related_query_name="%(app_label)s_%(class)s_mixtures_related_query",
        on_delete=models.CASCADE,
        help_text="mixture instance",
    )
    concentration = models.DecimalField(
        max_digits=20,
        decimal_places=9,
        blank=True,
        null=True,
        help_text="concentration in a given unit (e.g. mol/l, kg/l, ...)",
    )
    concentration_unit = models.ForeignKey(
        PhysicalUnit,
        related_name="%(app_label)s_%(class)s_concentration_unit_related",
        related_query_name="%(app_label)s_%(class)s_concentration_unit_related_query",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="unit of concentration, e.g. mol/l , kg/l  ...",
    )
    order = models.IntegerField(
        null=True,
        blank=True,
        help_text="order in the reaction, in case order of the reaction components plays a role",
    )
    stoichiometric_factor = models.DecimalField(
        max_digits=9,
        decimal_places=3,
        default=1.0,
        null=True,
        blank=True,
        help_text="stoichiometric_factor: neg: educt, pos: product",
    )
    roles = models.ManyToManyField(
        SubstanceClass,
        related_name="%(app_label)s_%(class)s_roles_related",
        related_query_name="%(app_label)s_%(class)s_roles_related_query",
        blank=True,
        help_text="roles of the reaction_component, like educt, product, solvent, catalyst, role educt, product, solvent, co-factor",
    )
    physical_state = models.ForeignKey(
        PhysicalStateMatter,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="e.g. solid, liquid, gas, plasma at reaction conditions",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge, ...",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )

    def save(self, *args, force_insert=None, using=None, **kwargs):
        """Here we generate some default values for IRIs etc"""
        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(uuid.uuid4())[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/ReactionComponentInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)

    def __str__(self):

        return self.name or ""

    def __repr__(self):
        return self.name or ""


class ReactionComponentInstancesSubset(ItemSubsetAbstr):
    """ReactionComponent Instance Subset, i.e. a specific instance of a reaction_component that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/ReactionComponentInstancesSubset"
    reactioncomponentinstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reaction_component_instances = models.ManyToManyField(
        ReactionComponentInstance,
        related_name="%(app_label)s_%(class)s_reaction_components_related",
        related_query_name="%(app_label)s_%(class)s_reaction_components_related_query",
        help_text="reaction_components of the reaction instance",
        through="OrderedReactionComponentInstancesSubset",
    )


class OrderedReactionComponentInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between ReactionComponentInstancesSubset and ReactionComponentInstance.
    This class can be used to store the order of reaction components in a subset"""

    model_curi = "lara:substances-store/OrderedReactionComponentInstancesSubset"
    orderedreactioncomponentinstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    reaction_component_instance = models.ForeignKey(
        ReactionComponentInstance,
        related_name="%(app_label)s_%(class)s_reaction_component_instance_related",
        related_query_name="%(app_label)s_%(class)s_reaction_component_instance",
        on_delete=models.CASCADE,
        help_text="reaction component instance in the subset",
    )

    reaction_component_instances_subset = models.ForeignKey(
        ReactionComponentInstancesSubset,
        related_name="%(app_label)s_%(class)s_reaction_component_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_reaction_component_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of reaction component instances",
    )

    order = models.IntegerField(help_text="order of reaction component in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["reaction_component_instance", "reaction_component_instances_subset"],
                name="%(app_label)s_%(class)s_reaction_component_instance_reaction_component_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


class ReactionInstance(ItemInstanceAbstr):
    """Reaction Instance represents a concrete reaction in, e.g., a lab."""

    model_curi = "lara:substances-store/ReactionInstance"

    reactioninstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    component_instances = models.ManyToManyField(
        ReactionComponentInstance,
        related_name="%(app_label)s_%(class)s_reaction_components_related",
        related_query_name="%(app_label)s_%(class)s_reaction_components_related_query",
        help_text="reaction components of the reaction instance",
    )
    # TODO: check, if we can use a ForeignKey to procedure here
    reaction_base = models.ForeignKey(
        Reaction,
        related_name="%(app_label)s_%(class)s_reactions_related",
        related_query_name="%(app_label)s_%(class)s_reactions_related_query",
        on_delete=models.CASCADE,
        help_text="abstract reference reaction",
    )
    procedure_url = models.URLField(
        blank=True,
        null=True,
        max_length=512,
        help_text="URL to the (instance) procedure of the reaction production",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="JSON object, containing physical and chemical properties and further classifications, like, e.g. excited states, charge, ...",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        blank=True,
        related_name="%(app_label)s_%(class)s_ri_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_ri_data_extra_related_query",
        help_text="extra data",
    )

    def __str__(self):
        return self.name or ""

    def __repr__(self):
        return self.name or ""

    def save(self, *args, force_insert=None, using=None, **kwargs):

        if self.barcode == "" or self.barcode is None:
            self.barcode = f"AUTO_{str(uuid.uuid4())[:8]}"

        reg_no = self.registration_no or self.barcode or ""

        if self.iri is None or self.iri == "":
            netloc = self.namespace.parse_uri().netloc
            path = self.namespace.parse_uri().path
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances-store/ReactionInstance/{netloc}{path}/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class ReactionInstancesSubset(ItemSubsetAbstr):
    """Reaction Instance Subset, i.e. a specific instance of a reaction that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/ReactionInstancesSubset"
    reactioninstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reaction_instances = models.ManyToManyField(
        ReactionInstance,
        related_name="%(app_label)s_%(class)s_reactions_related",
        related_query_name="%(app_label)s_%(class)s_reactions_related_query",
        help_text="reactions of the reaction instance",
        through="OrderedReactionInstancesSubset",
    )

    class Meta:
        # verbose_name = "Reaction Instance Subset"
        # verbose_name_plural = "Reaction Instance Subsets"
        db_table_comment = "Reaction Instance Subset, i.e. a specific instance of a reaction that is stored in a lab, like a bottle of water, a bottle of ethanol, ..."


class OrderedReactionInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between ReactionInstancesSubset and ReactionInstance.
    This class can be used to store the order of reactions in a subset"""

    model_curi = "lara:substances-store/OrderedReactionInstancesSubset"
    orderedreactioninstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    reaction_instance = models.ForeignKey(
        ReactionInstance,
        related_name="%(app_label)s_%(class)s_reaction_instance_related",
        related_query_name="%(app_label)s_%(class)s_reaction_instance",
        on_delete=models.CASCADE,
        help_text="reaction instance in the subset",
    )

    reaction_instances_subset = models.ForeignKey(
        ReactionInstancesSubset,
        related_name="%(app_label)s_%(class)s_reaction_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_reaction_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of reaction instances",
    )

    order = models.IntegerField(help_text="order of reaction in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["reaction_instance", "reaction_instances_subset"],
                name="%(app_label)s_%(class)s_reaction_instance_reaction_instances_subset_unique",
            ),
        ]
        ordering = ("order",)


class MultiStepReactionInstance(ItemInstanceAbstr):
    """Multistep Reaction Instance"""

    model_curi = "lara:substances-store/MultiStepReactionInstance"
    multistepreactioninstance_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    reaction_instances = models.ManyToManyField(
        ReactionInstance,
        related_name="%(app_label)s_%(class)s_reactions_related",
        related_query_name="%(app_label)s_%(class)s_reactions_related_query",
        help_text="reactions of the multistep reaction instance",
    )
    sequence = models.JSONField(
        blank=True,
        null=True,
        help_text="sequence of sequential and parallel reactions, like, e.g. ['rx1', 'rx2', ['rx3', 'rx4']]",
    )
    properties = models.JSONField(
        blank=True,
        null=True,
        help_text="properties of the reaction, like reaction class(es), equilibrium constant, speed, order of kinetics, enthalpy, entropy, etc., specified by the reactions_properties model",
    )
    computed_properties = models.JSONField(
        blank=True,
        null=True,
        help_text="computed physical and chemical properties JSON, like, e.g. predicted excited states, electron / charge distributions, volume ...",
    )
    parameters = models.JSONField(
        blank=True,
        null=True,
        help_text="reaction parameters / conditions, like stoichiometry, durations, temperature, pressure, pH, ..., specified by the reactions_parameters model",
    )
    svg = models.TextField(blank=True, help_text="svg image of the reaction scheme.")

    image = models.ImageField(
        upload_to="substances/reactions/",
        blank=True,
        null=True,
        help_text="rel. path/filename to image",
    )
    iri = models.URLField(
        blank=True,
        null=True,
        unique=True,
        max_length=512,
        help_text="International Resource Identifier - IRI: is used for semantic representation ",
    )
    resources_external = models.ManyToManyField(
        ExternalResource,
        related_name="%(app_label)s_%(class)s_external_resources_related",
        related_query_name="%(app_label)s_%(class)s_external_resources_related_query",
        blank=True,
        help_text="external resources, like literature, websites, manuals, ...",
    )
    tags = models.ManyToManyField(
        Tag,
        blank=True,
        related_name="%(app_label)s_%(class)s_tags_related",
        related_query_name="%(app_label)s_%(class)s_tags_related_query",
        help_text="tags",
    )
    data_extra = models.ManyToManyField(
        ExtraData,
        related_name="%(app_label)s_%(class)s_data_extra_related",
        related_query_name="%(app_label)s_%(class)s_data_extra_related_query",
        blank=True,
        help_text="extra data, like kinetic models, spectra, chromatograms, reaction schemes, ...",
    )
    description = models.TextField(blank=True, help_text="")
    remarks = models.TextField(blank=True, help_text="")
    datetime_last_modified = models.DateTimeField(null=True, blank=True, help_text="datetime of last modification")

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.name

    def save(self, *args, **kwargs):
        """
        Here we generate some default values for IRI
        """
        if self.iri is None or self.iri == "":
            self.iri = f"{settings.LARA_PREFIXES['lara']}substances/MultiStepReaction/{self.name.replace(' ', '_').lower().strip()}"

        self.datetime_last_modified = timezone.now()

        super().save(*args, **kwargs)


class MultiStepReactionInstancesSubset(ItemSubsetAbstr):
    """Multistep Reaction Instance Subset, i.e. a specific instance of a multistep reaction that is stored in a lab,
    like a bottle of water, a bottle of ethanol, ...
    """

    model_curi = "lara:substances-store/MultiStepReactionsInstanceSubset"
    multistepreactioninstancessubset_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reactions_multistep_instances = models.ManyToManyField(
        MultiStepReactionInstance,
        related_name="%(app_label)s_%(class)s_multistep_reactions_related",
        related_query_name="%(app_label)s_%(class)s_multistep_reactions_related_query",
        help_text="multistep reactions of the multistep reaction instance",
        through="OrderedMultiStepReactionInstancesSubset",
    )

    class Meta:
        # verbose_name = "Multistep Reaction Instance Subset"
        # verbose_name_plural = "Multistep Reaction Instance Subsets"
        db_table_comment = "Multistep Reaction Instance Subset, i.e. a specific instance of a multistep reaction that is selected by a user or group."


class OrderedMultiStepReactionInstancesSubset(models.Model):
    """Through model for the many-to-many relationship between MultiStepReactionInstancesSubset and MultiStepReactionInstance.
    This class can be used to store the order of multistep reactions in a subset"""

    model_curi = "lara:substances-store/OrderedMultiStepReactionInstancesSubset"
    orderedmultistepreactioninstancessubset_id = models.UUIDField(
        primary_key=True, default=uuid.uuid4, editable=False
    )

    multistep_reaction_instance = models.ForeignKey(
        MultiStepReactionInstance,
        related_name="%(app_label)s_%(class)s_multistep_reaction_instance_related",
        related_query_name="%(app_label)s_%(class)s_multistep_reaction_instance",
        on_delete=models.CASCADE,
        help_text="multistep reaction instance in the subset",
    )

    multistep_reaction_instances_subset = models.ForeignKey(
        MultiStepReactionInstancesSubset,
        related_name="%(app_label)s_%(class)s_multistep_reaction_instances_subset_related",
        related_query_name="%(app_label)s_%(class)s_multistep_reaction_instances_subset",
        on_delete=models.CASCADE,
        help_text="subset of multistep reaction instances",
    )

    order = models.IntegerField(help_text="order of multistep reaction in subset")

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["multistep_reaction_instance", "multistep_reaction_instances_subset"],
                name="%(app_label)s_%(class)s_ms_reaction_instance_ms_reaction_instances_subset_unique",
            ),
        ]
        ordering = ("order",)
