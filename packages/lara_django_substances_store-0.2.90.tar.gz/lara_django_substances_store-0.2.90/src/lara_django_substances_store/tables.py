"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store admin *

:details: lara_django_substances_store admin module admin backend configuration.
         -
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - run "lara-django-dev tables_generator lara_django_substances_store >> tables.py" to update this file
________________________________________________________________________
"""
# django Tests s. https://docs.djangoproject.com/en/4.1/topics/testing/overview/ for lara_django_substances_store
# generated with django-extensions tests_generator  lara_django_substances_store > tests.py (LARA-version)

import logging
from django.utils.html import format_html
import django_tables2 as tables


from .models import (
    ExtraData,
    SubstanceInstance,
    SubstanceOrderItem,
    SubstanceWishlist,
    SubstanceBasket,
    SubstancesOrder,
    SubstancesLocalStore,
    PolymerInstance,
    PolymerOrderItem,
    PolymerWishlist,
    PolymerBasket,
    PolymersOrder,
    PolymersLocalStore,
    MixtureComponentInstance,
    MixtureInstance,
    MixtureOrderItem,
    MixtureWishlist,
    MixtureBasket,
    MixturesOrder,
    MixturesLocalStore,
)


class ExtraDataTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:extradata-detail', [tables.A('pk')]))

    class Meta:
        model = ExtraData

        fields = (
            "data_type",
            "namespace",
            "uri",
            "data_json",
            "media_type",
            "iri",
            "url",
            "description",
            "file",
            "image",
        )


class SubstanceInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_substances_store:substance-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_substances_store:substance-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_substances_store:substance-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = SubstanceInstance

        fields = (
            "name",
            "namespace",
            "substance",
            "substance" "barcode1D",
            "registration_no",
            "vendor",

            "price",
            "currency",


            "location",
            # "description",
            "amount_volume",
            "amount_mass",
            "purity",

            "safety_info",
            "storage_info",
        )


class SubstanceOrderItemTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:substanceorderitem-detail', [tables.A('pk')]))

    class Meta:
        model = SubstanceOrderItem

        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "substance_instance",
        )


class SubstanceWishlistTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:substanceswishlist-detail', [tables.A('pk')]))

    class Meta:
        model = SubstanceWishlist

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class SubstanceBasketTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:substancebasket-detail', [tables.A('pk')]))

    class Meta:
        model = SubstanceBasket

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class SubstancesOrderTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:substancesorder-detail', [tables.A('pk')]))

    class Meta:
        model = SubstancesOrder

        fields = (
            "namespace",
            "name",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_net",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )


class SubstancesLocalStoreTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:substanceslocalstore-detail', [tables.A('pk')]))

    class Meta:
        model = SubstancesLocalStore

        fields = (
            "namespace",
            "name",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
        )


class PolymerInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_substances_store:polymer-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_substances_store:polymer-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_substances_store:polymer-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = PolymerInstance

        fields = (
            "name",
            "namespace",
            "barcode1D",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "price",
            "currency",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "labware_instance",
            "safety_info",
            "storage_info",
            "hazard_symbols",
            "polymer",
        )


class PolymerOrderItemTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:polymerorderitem-detail', [tables.A('pk')]))

    class Meta:
        model = PolymerOrderItem

        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "polymer_instance",
        )


class PolymerWishlistTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:polymerwishlist-detail', [tables.A('pk')]))

    class Meta:
        model = PolymerWishlist

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class PolymerBasketTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:polymerbasket-detail', [tables.A('pk')]))

    class Meta:
        model = PolymerBasket

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class PolymersOrderTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:polymersorder-detail', [tables.A('pk')]))

    class Meta:
        model = PolymersOrder

        fields = (
            "namespace",
            "name",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_net",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )


class PolymersLocalStoreTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:polymerlocalstore-detail', [tables.A('pk')]))

    class Meta:
        model = PolymersLocalStore

        fields = (
            "namespace",
            "name",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
        )


class MixtureComponentInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # name = tables.Column(linkify=('lara_django_substances_store:mixturecomponentinstance-detail', [tables.A('pk')]))

    class Meta:
        model = MixtureComponentInstance

        fields = (
            "namespace",
            "name",
            "name",
            "barcode1D",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "price",
            "currency",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "labware_instance",
            "safety_info",
            "storage_info",
            "hazard_symbols",
            "mix_component",
        )


class MixtureInstanceTable(tables.Table):
    # adding link to column <column-to-be-linked>
    name = tables.Column(linkify=("lara_django_substances_store:mixture-detail", [tables.A("pk")]))

    edit = tables.Column(
        empty_values=(),
        verbose_name="Edit",
        default="Edit",
        linkify={
            "viewname": "lara_django_substances_store:mixture-update",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-warning btn-sm"}},
    )

    delete = tables.Column(
        empty_values=(),
        verbose_name="Delete",
        default="Delete",
        linkify={
            "viewname": "lara_django_substances_store:mixture-delete",
            "args": [(tables.A("pk"))],
        },
        attrs={"a": {"class": "btn btn-danger btn-sm"}},
    )

    def render_edit(self):
        return format_html('<i class="bi bi-pencil-square"></i>')

    def render_delete(self):
        return format_html('<i class="bi bi-trash"></i>')

    class Meta:
        model = MixtureInstance

        fields = (
            "name",
            "namespace",
            "barcode1D",
            "registration_no",
            "vendor",
            "serial_no",
            "service_no",
            "price",
            "currency",
            "datetime_delivery",
            "datetime_end_of_warranty",
            "location",
            "description",
            "amount_volume",
            "amount_mass",
            "purity",
            "labware_instance",
            "safety_info",
            "storage_info",
            "hazard_symbols",
            "mixture",
        )


class MixtureOrderItemTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:mixtureorderitem-detail', [tables.A('pk')]))

    class Meta:
        model = MixtureOrderItem

        fields = (
            "quantity",
            "item_price_net",
            "item_price_gross",
            "item_transport_price",
            "item_price_tax",
            "item_toll",
            "toll_number",
            "item_discount",
            "total_price_net",
            "mixture_instance",
        )


class MixtureWishlistTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:mixturewishlist-detail', [tables.A('pk')]))

    class Meta:
        model = MixtureWishlist

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class MixtureBasketTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:mixturebasket-detail', [tables.A('pk')]))

    class Meta:
        model = MixtureBasket

        fields = ("namespace", "name", "entity", "datetime_created", "datetime_last_modified")


class MixturesOrderTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:mixturesorder-detail', [tables.A('pk')]))

    class Meta:
        model = MixturesOrder

        fields = (
            "namespace",
            "name",
            "iri",
            "entity_ordered",
            "entity_ordering",
            "datetime_order",
            "order_barcode",
            "provider",
            "datetime_order_quote",
            "datetime_order_invoice",
            "transport_company",
            "transport_price",
            "budget_url",
            "datetime_order_pay",
            "order_total_price_net",
            "order_total_price_gross",
            "order_total_price_tax",
            "order_total_price_toll",
            "order_currency",
            "order_status",
        )


class MixturesLocalStoreTable(tables.Table):
    # adding link to column <column-to-be-linked>
    # <column-to-be-linked> = tables.Column(linkify=('lara_django_substances_store:mixturelocalstore-detail', [tables.A('pk')]))

    class Meta:
        model = MixturesLocalStore

        fields = (
            "namespace",
            "name",
            "entity",
            "datetime_created",
            "datetime_last_modified",
            "location",
        )
