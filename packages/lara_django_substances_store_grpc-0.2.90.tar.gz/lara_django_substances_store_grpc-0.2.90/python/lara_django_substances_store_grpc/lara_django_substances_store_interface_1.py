"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store high_level_interface *

:details: lara_django_substances_store high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_substances_store
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2 as lara_django_substances_store_pb2
import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2_grpc as lara_django_substances_store_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, export_file, import_file, id_cache, update_image

import  lara_django_substances_store_grpc.lara_django_substances_store_data_model as substances_store_dm 



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_substances_store_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_substances_store_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_substances_store_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  extradata:  list[substances_store_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_substances_store_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_substances_store_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_substances_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_substances_store_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_substances_store_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_substances_store_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_substances_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_substances_store_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_substances_store_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, extradata : substances_store_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_substances_store_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_substances_store_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  SubstanceInstance  ______________________


class SubstanceInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substanceinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceInstanceclassByIRIControllerStub(channel)
        # )
        
        self.substanceinstance_client = lara_django_substances_store_pb2_grpc.SubstanceInstanceControllerStub(channel)

        # self.substanceinstance_full_client = lara_django_substances_store_pb2_grpc.SubstanceInstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substanceinstances:  list[substances_store_dm.SubstanceInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substanceinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceInstanceclassRetrieveRequest(iri=substanceinstance_class_iri)
        #     )
        #     substanceinstanceclass_id = res.substanceinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substanceinstanceclass_id: {e}")
        # for substanceinstance in substanceinstances:
        #     substanceinstance.namespace = self.namespace_id
        #     substanceinstance.substanceinstance_class = substanceinstanceclass_id

        try:
            create_coroutines = ( self.substanceinstance_client.Create(lara_django_substances_store_pb2.SubstanceInstanceRequest(**substanceinstance.model_dump())) for substanceinstance in substanceinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substanceinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        substanceinstance_id: str = None,
        substanceinstance_name: str = None,
        #substanceinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceInstance]:
        filter_list = []
        results_list = []
        if  substanceinstance_id is not None:
            try:
                res =  await self.substanceinstance_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceInstanceRetrieveRequest(substanceinstance_id=substanceinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substanceinstance_id: {e}")

        if substanceinstance_name is not None:
            filter_list.append({"name": substanceinstance_name})
        # if substanceinstance_name_full is not None:
        #     filter_list.append({"name_full": substanceinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceinstance_client.List(
                        lara_django_substances_store_pb2.SubstanceInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstanceInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substanceinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substanceinstance_name: str = None,
                          substanceinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if substanceinstance_name is not None:
            filter_dict = {"name": substanceinstance_name}
        elif substanceinstance_name_full is not None:
            filter_dict = {"name_full": substanceinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceinstance_client.List(
                    lara_django_substances_store_pb2.SubstanceInstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substanceinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substanceinstance_id
            else:
                raise ValueError(f"Error retrieving substanceinstance_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substanceinstance_client.List(lara_django_substances_store_pb2.SubstanceInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceinstance_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substanceinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceinstance_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceinstance_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substanceinstance : substances_store_dm.SubstanceInstance = None) -> None:
        try:
            await self.substanceinstance_client.Update(
                lara_django_substances_store_pb2.SubstanceInstanceRequest(**substanceinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substanceinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substanceinstance_client.Destroy(lara_django_substances_store_pb2.SubstanceInstanceDestroyRequest(substanceinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substanceinstance_id: {e}")

#_________________  SubstanceOrderItem  ______________________


class SubstanceOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substanceorderitem_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceOrderItemclassByIRIControllerStub(channel)
        # )
        
        self.substanceorderitem_client = lara_django_substances_store_pb2_grpc.SubstanceOrderItemControllerStub(channel)

        # self.substanceorderitem_full_client = lara_django_substances_store_pb2_grpc.SubstanceOrderItemFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substanceorderitems:  list[substances_store_dm.SubstanceOrderItem] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceOrderItem]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substanceorderitemclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceorderitem_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceorderitem_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceOrderItemclassRetrieveRequest(iri=substanceorderitem_class_iri)
        #     )
        #     substanceorderitemclass_id = res.substanceorderitemclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substanceorderitemclass_id: {e}")
        # for substanceorderitem in substanceorderitems:
        #     substanceorderitem.namespace = self.namespace_id
        #     substanceorderitem.substanceorderitem_class = substanceorderitemclass_id

        try:
            create_coroutines = ( self.substanceorderitem_client.Create(lara_django_substances_store_pb2.SubstanceOrderItemRequest(**substanceorderitem.model_dump())) for substanceorderitem in substanceorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substanceorderitem: {e}")

    @export_file
    async def retrieve(
        self, 
        substanceorderitem_id: str = None,
        substanceorderitem_name: str = None,
        #substanceorderitem_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceOrderItem]:
        filter_list = []
        results_list = []
        if  substanceorderitem_id is not None:
            try:
                res =  await self.substanceorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceOrderItemRetrieveRequest(substanceorderitem_id=substanceorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substanceorderitem_id: {e}")

        if substanceorderitem_name is not None:
            filter_list.append({"name": substanceorderitem_name})
        # if substanceorderitem_name_full is not None:
        #     filter_list.append({"name_full": substanceorderitem_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceorderitem_client.List(
                        lara_django_substances_store_pb2.SubstanceOrderItemListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substanceorderitem_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substanceorderitem_name: str = None,
                          substanceorderitem_name_full: str = None,
                          iri: str = None,) -> str:
        if substanceorderitem_name is not None:
            filter_dict = {"name": substanceorderitem_name}
        elif substanceorderitem_name_full is not None:
            filter_dict = {"name_full": substanceorderitem_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceorderitem_client.List(
                    lara_django_substances_store_pb2.SubstanceOrderItemListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substanceorderitem_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substanceorderitem_id
            else:
                raise ValueError(f"Error retrieving substanceorderitem_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substanceorderitem_client.List(lara_django_substances_store_pb2.SubstanceOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceorderitem_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceorderitem_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substanceorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceorderitem_full_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceorderitem_full_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substanceorderitem : substances_store_dm.SubstanceOrderItem = None) -> None:
        try:
            await self.substanceorderitem_client.Update(
                lara_django_substances_store_pb2.SubstanceOrderItemRequest(**substanceorderitem.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substanceorderitem_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substanceorderitem_client.Destroy(lara_django_substances_store_pb2.SubstanceOrderItemDestroyRequest(substanceorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substanceorderitem_id: {e}")

#_________________  SubstanceWishlist  ______________________


class SubstanceWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substancewishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstancewishlistclassByIRIControllerStub(channel)
        # )
        
        self.substancewishlist_client = lara_django_substances_store_pb2_grpc.SubstancewishlistControllerStub(channel)

        # self.substancewishlist_full_client = lara_django_substances_store_pb2_grpc.SubstancewishlistFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substancewishlists:  list[substances_store_dm.SubstanceWishlist] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceWishlist]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substancewishlistclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancewishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancewishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstancewishlistclassRetrieveRequest(iri=substancewishlist_class_iri)
        #     )
        #     substancewishlistclass_id = res.substancewishlistclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substancewishlistclass_id: {e}")
        # for substancewishlist in substancewishlists:
        #     substancewishlist.namespace = self.namespace_id
        #     substancewishlist.substancewishlist_class = substancewishlistclass_id

        try:
            create_coroutines = ( self.substancewishlist_client.Create(lara_django_substances_store_pb2.SubstancewishlistRequest(**substancewishlist.model_dump())) for substancewishlist in substancewishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substancewishlist_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substancewishlist: {e}")

    @export_file
    async def retrieve(
        self, 
        substancewishlist_id: str = None,
        substancewishlist_name: str = None,
        #substancewishlist_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceWishlist]:
        filter_list = []
        results_list = []
        if  substancewishlist_id is not None:
            try:
                res =  await self.substancewishlist_client.Retrieve(
                    lara_django_substances_store_pb2.SubstancewishlistRetrieveRequest(substancewishlist_id=substancewishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substancewishlist_id: {e}")

        if substancewishlist_name is not None:
            filter_list.append({"name": substancewishlist_name})
        # if substancewishlist_name_full is not None:
        #     filter_list.append({"name_full": substancewishlist_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancewishlist_client.List(
                        lara_django_substances_store_pb2.SubstancewishlistListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstanceWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substancewishlist_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substancewishlist_name: str = None,
                          substancewishlist_name_full: str = None,
                          iri: str = None,) -> str:
        if substancewishlist_name is not None:
            filter_dict = {"name": substancewishlist_name}
        elif substancewishlist_name_full is not None:
            filter_dict = {"name_full": substancewishlist_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancewishlist_client.List(
                    lara_django_substances_store_pb2.SubstancewishlistListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substancewishlist_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substancewishlist_id
            else:
                raise ValueError(f"Error retrieving substancewishlist_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substancewishlist_client.List(lara_django_substances_store_pb2.SubstancewishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancewishlist_client.List(
                lara_django_substances_store_pb2.SubstancewishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancewishlist_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substancewishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancewishlist_full_client.List(
                lara_django_substances_store_pb2.SubstancewishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancewishlist_full_client.List(
                lara_django_substances_store_pb2.SubstancewishlistFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substancewishlist : substances_store_dm.SubstanceWishlist = None) -> None:
        try:
            await self.substancewishlist_client.Update(
                lara_django_substances_store_pb2.SubstancewishlistRequest(**substancewishlist.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substancewishlist_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substancewishlist_client.Destroy(lara_django_substances_store_pb2.SubstancewishlistDestroyRequest(substancewishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substancewishlist_id: {e}")

#_________________  SubstanceBasket  ______________________


class SubstanceBasketInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substancebasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceBasketclassByIRIControllerStub(channel)
        # )
        
        self.substancebasket_client = lara_django_substances_store_pb2_grpc.SubstanceBasketControllerStub(channel)

        # self.substancebasket_full_client = lara_django_substances_store_pb2_grpc.SubstanceBasketFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substancebaskets:  list[substances_store_dm.SubstanceBasket] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceBasket]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substancebasketclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancebasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancebasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceBasketclassRetrieveRequest(iri=substancebasket_class_iri)
        #     )
        #     substancebasketclass_id = res.substancebasketclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substancebasketclass_id: {e}")
        # for substancebasket in substancebaskets:
        #     substancebasket.namespace = self.namespace_id
        #     substancebasket.substancebasket_class = substancebasketclass_id

        try:
            create_coroutines = ( self.substancebasket_client.Create(lara_django_substances_store_pb2.SubstanceBasketRequest(**substancebasket.model_dump())) for substancebasket in substancebaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substancebasket_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substancebasket: {e}")

    @export_file
    async def retrieve(
        self, 
        substancebasket_id: str = None,
        substancebasket_name: str = None,
        #substancebasket_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceBasket]:
        filter_list = []
        results_list = []
        if  substancebasket_id is not None:
            try:
                res =  await self.substancebasket_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceBasketRetrieveRequest(substancebasket_id=substancebasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substancebasket_id: {e}")

        if substancebasket_name is not None:
            filter_list.append({"name": substancebasket_name})
        # if substancebasket_name_full is not None:
        #     filter_list.append({"name_full": substancebasket_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancebasket_client.List(
                        lara_django_substances_store_pb2.SubstanceBasketListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstanceBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substancebasket_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substancebasket_name: str = None,
                          substancebasket_name_full: str = None,
                          iri: str = None,) -> str:
        if substancebasket_name is not None:
            filter_dict = {"name": substancebasket_name}
        elif substancebasket_name_full is not None:
            filter_dict = {"name_full": substancebasket_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancebasket_client.List(
                    lara_django_substances_store_pb2.SubstanceBasketListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substancebasket_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substancebasket_id
            else:
                raise ValueError(f"Error retrieving substancebasket_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substancebasket_client.List(lara_django_substances_store_pb2.SubstanceBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancebasket_client.List(
                lara_django_substances_store_pb2.SubstanceBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancebasket_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substancebasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancebasket_full_client.List(
                lara_django_substances_store_pb2.SubstanceBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancebasket_full_client.List(
                lara_django_substances_store_pb2.SubstanceBasketFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substancebasket : substances_store_dm.SubstanceBasket = None) -> None:
        try:
            await self.substancebasket_client.Update(
                lara_django_substances_store_pb2.SubstanceBasketRequest(**substancebasket.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substancebasket_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substancebasket_client.Destroy(lara_django_substances_store_pb2.SubstanceBasketDestroyRequest(substancebasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substancebasket_id: {e}")

#_________________  SubstancesOrder  ______________________


class SubstancesOrderInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substancesorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstancesOrderclassByIRIControllerStub(channel)
        # )
        
        self.substancesorder_client = lara_django_substances_store_pb2_grpc.SubstancesOrderControllerStub(channel)

        # self.substancesorder_full_client = lara_django_substances_store_pb2_grpc.SubstancesOrderFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substancesorders:  list[substances_store_dm.SubstancesOrder] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstancesOrder]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substancesorderclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancesorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancesorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstancesOrderclassRetrieveRequest(iri=substancesorder_class_iri)
        #     )
        #     substancesorderclass_id = res.substancesorderclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substancesorderclass_id: {e}")
        # for substancesorder in substancesorders:
        #     substancesorder.namespace = self.namespace_id
        #     substancesorder.substancesorder_class = substancesorderclass_id

        try:
            create_coroutines = ( self.substancesorder_client.Create(lara_django_substances_store_pb2.SubstancesOrderRequest(**substancesorder.model_dump())) for substancesorder in substancesorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substancesorder_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substancesorder: {e}")

    @export_file
    async def retrieve(
        self, 
        substancesorder_id: str = None,
        substancesorder_name: str = None,
        #substancesorder_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstancesOrder]:
        filter_list = []
        results_list = []
        if  substancesorder_id is not None:
            try:
                res =  await self.substancesorder_client.Retrieve(
                    lara_django_substances_store_pb2.SubstancesOrderRetrieveRequest(substancesorder_id=substancesorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstancesOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substancesorder_id: {e}")

        if substancesorder_name is not None:
            filter_list.append({"name": substancesorder_name})
        # if substancesorder_name_full is not None:
        #     filter_list.append({"name_full": substancesorder_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancesorder_client.List(
                        lara_django_substances_store_pb2.SubstancesOrderListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstancesOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substancesorder_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substancesorder_name: str = None,
                          substancesorder_name_full: str = None,
                          iri: str = None,) -> str:
        if substancesorder_name is not None:
            filter_dict = {"name": substancesorder_name}
        elif substancesorder_name_full is not None:
            filter_dict = {"name_full": substancesorder_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substancesorder_client.List(
                    lara_django_substances_store_pb2.SubstancesOrderListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substancesorder_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substancesorder_id
            else:
                raise ValueError(f"Error retrieving substancesorder_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substancesorder_client.List(lara_django_substances_store_pb2.SubstancesOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancesorder_client.List(
                lara_django_substances_store_pb2.SubstancesOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancesorder_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substancesorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancesorder_full_client.List(
                lara_django_substances_store_pb2.SubstancesOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancesorder_full_client.List(
                lara_django_substances_store_pb2.SubstancesOrderFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substancesorder : substances_store_dm.SubstancesOrder = None) -> None:
        try:
            await self.substancesorder_client.Update(
                lara_django_substances_store_pb2.SubstancesOrderRequest(**substancesorder.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substancesorder_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substancesorder_client.Destroy(lara_django_substances_store_pb2.SubstancesOrderDestroyRequest(substancesorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substancesorder_id: {e}")

#_________________  SubstancesLocalStore  ______________________


class SubstancesLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.substanceslocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstancesLocalStoreclassByIRIControllerStub(channel)
        # )
        
        self.substanceslocalstore_client = lara_django_substances_store_pb2_grpc.SubstancesLocalStoreControllerStub(channel)

        # self.substanceslocalstore_full_client = lara_django_substances_store_pb2_grpc.SubstancesLocalStoreFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  substanceslocalstores:  list[substances_store_dm.SubstancesLocalStore] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstancesLocalStore]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # substanceslocalstoreclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceslocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstancesLocalStoreclassRetrieveRequest(iri=substanceslocalstore_class_iri)
        #     )
        #     substanceslocalstoreclass_id = res.substanceslocalstoreclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving substanceslocalstoreclass_id: {e}")
        # for substanceslocalstore in substanceslocalstores:
        #     substanceslocalstore.namespace = self.namespace_id
        #     substanceslocalstore.substanceslocalstore_class = substanceslocalstoreclass_id

        try:
            create_coroutines = ( self.substanceslocalstore_client.Create(lara_django_substances_store_pb2.SubstancesLocalStoreRequest(**substanceslocalstore.model_dump())) for substanceslocalstore in substanceslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceslocalstore_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating substanceslocalstore: {e}")

    @export_file
    async def retrieve(
        self, 
        substanceslocalstore_id: str = None,
        substanceslocalstore_name: str = None,
        #substanceslocalstore_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.SubstancesLocalStore]:
        filter_list = []
        results_list = []
        if  substanceslocalstore_id is not None:
            try:
                res =  await self.substanceslocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.SubstancesLocalStoreRetrieveRequest(substanceslocalstore_id=substanceslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstancesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving substanceslocalstore_id: {e}")

        if substanceslocalstore_name is not None:
            filter_list.append({"name": substanceslocalstore_name})
        # if substanceslocalstore_name_full is not None:
        #     filter_list.append({"name_full": substanceslocalstore_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceslocalstore_client.List(
                        lara_django_substances_store_pb2.SubstancesLocalStoreListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.SubstancesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving substanceslocalstore_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          substanceslocalstore_name: str = None,
                          substanceslocalstore_name_full: str = None,
                          iri: str = None,) -> str:
        if substanceslocalstore_name is not None:
            filter_dict = {"name": substanceslocalstore_name}
        elif substanceslocalstore_name_full is not None:
            filter_dict = {"name_full": substanceslocalstore_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.substanceslocalstore_client.List(
                    lara_django_substances_store_pb2.SubstancesLocalStoreListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving substanceslocalstore_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].substanceslocalstore_id
            else:
                raise ValueError(f"Error retrieving substanceslocalstore_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.substanceslocalstore_client.List(lara_django_substances_store_pb2.SubstancesLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceslocalstore_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceslocalstore_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.substanceslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceslocalstore_full_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceslocalstore_full_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, substanceslocalstore : substances_store_dm.SubstancesLocalStore = None) -> None:
        try:
            await self.substanceslocalstore_client.Update(
                lara_django_substances_store_pb2.SubstancesLocalStoreRequest(**substanceslocalstore.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating substanceslocalstore_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.substanceslocalstore_client.Destroy(lara_django_substances_store_pb2.SubstancesLocalStoreDestroyRequest(substanceslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting substanceslocalstore_id: {e}")

#_________________  PolymerInstance  ______________________


class PolymerInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerInstanceClassByIRIControllerStub(channel)
        # )
        
        self.polymerinstance_client = lara_django_substances_store_pb2_grpc.PolymerInstanceControllerStub(channel)

        # self.polymerinstance_full_client = lara_django_substances_store_pb2_grpc.PolymerInstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerinstances:  list[substances_store_dm.PolymerInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerInstanceClassRetrieveRequest(iri=polymerinstance_class_iri)
        #     )
        #     polymerinstanceclass_id = res.polymerinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerinstanceclass_id: {e}")
        # for polymerinstance in polymerinstances:
        #     polymerinstance.namespace = self.namespace_id
        #     polymerinstance.polymerinstance_class = polymerinstanceclass_id

        try:
            create_coroutines = ( self.polymerinstance_client.Create(lara_django_substances_store_pb2.PolymerInstanceRequest(**polymerinstance.model_dump())) for polymerinstance in polymerinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerinstance_id: str = None,
        polymerinstance_name: str = None,
        #polymerinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymerInstance]:
        filter_list = []
        results_list = []
        if  polymerinstance_id is not None:
            try:
                res =  await self.polymerinstance_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerInstanceRetrieveRequest(polymerinstance_id=polymerinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerinstance_id: {e}")

        if polymerinstance_name is not None:
            filter_list.append({"name": polymerinstance_name})
        # if polymerinstance_name_full is not None:
        #     filter_list.append({"name_full": polymerinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerinstance_client.List(
                        lara_django_substances_store_pb2.PolymerInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymerInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerinstance_name: str = None,
                          polymerinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerinstance_name is not None:
            filter_dict = {"name": polymerinstance_name}
        elif polymerinstance_name_full is not None:
            filter_dict = {"name_full": polymerinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerinstance_client.List(
                    lara_django_substances_store_pb2.PolymerInstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerinstance_id
            else:
                raise ValueError(f"Error retrieving polymerinstance_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerinstance_client.List(lara_django_substances_store_pb2.PolymerInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerinstance_client.List(
                lara_django_substances_store_pb2.PolymerInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerinstance_full_client.List(
                lara_django_substances_store_pb2.PolymerInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerinstance_full_client.List(
                lara_django_substances_store_pb2.PolymerInstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymerinstance : substances_store_dm.PolymerInstance = None) -> None:
        try:
            await self.polymerinstance_client.Update(
                lara_django_substances_store_pb2.PolymerInstanceRequest(**polymerinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerinstance_client.Destroy(lara_django_substances_store_pb2.PolymerInstanceDestroyRequest(polymerinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerinstance_id: {e}")

#_________________  PolymerOrderItem  ______________________


class PolymerOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerorderitem_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerOrderItemclassByIRIControllerStub(channel)
        # )
        
        self.polymerorderitem_client = lara_django_substances_store_pb2_grpc.PolymerOrderItemControllerStub(channel)

        # self.polymerorderitem_full_client = lara_django_substances_store_pb2_grpc.PolymerOrderItemFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerorderitems:  list[substances_store_dm.PolymerOrderItem] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerOrderItem]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerorderitemclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerorderitem_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerorderitem_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerOrderItemclassRetrieveRequest(iri=polymerorderitem_class_iri)
        #     )
        #     polymerorderitemclass_id = res.polymerorderitemclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerorderitemclass_id: {e}")
        # for polymerorderitem in polymerorderitems:
        #     polymerorderitem.namespace = self.namespace_id
        #     polymerorderitem.polymerorderitem_class = polymerorderitemclass_id

        try:
            create_coroutines = ( self.polymerorderitem_client.Create(lara_django_substances_store_pb2.PolymerOrderItemRequest(**polymerorderitem.model_dump())) for polymerorderitem in polymerorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerorderitem: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerorderitem_id: str = None,
        polymerorderitem_name: str = None,
        #polymerorderitem_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymerOrderItem]:
        filter_list = []
        results_list = []
        if  polymerorderitem_id is not None:
            try:
                res =  await self.polymerorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerOrderItemRetrieveRequest(polymerorderitem_id=polymerorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerorderitem_id: {e}")

        if polymerorderitem_name is not None:
            filter_list.append({"name": polymerorderitem_name})
        # if polymerorderitem_name_full is not None:
        #     filter_list.append({"name_full": polymerorderitem_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerorderitem_client.List(
                        lara_django_substances_store_pb2.PolymerOrderItemListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerorderitem_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerorderitem_name: str = None,
                          polymerorderitem_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerorderitem_name is not None:
            filter_dict = {"name": polymerorderitem_name}
        elif polymerorderitem_name_full is not None:
            filter_dict = {"name_full": polymerorderitem_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerorderitem_client.List(
                    lara_django_substances_store_pb2.PolymerOrderItemListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerorderitem_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerorderitem_id
            else:
                raise ValueError(f"Error retrieving polymerorderitem_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerorderitem_client.List(lara_django_substances_store_pb2.PolymerOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerorderitem_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerorderitem_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerorderitem_full_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerorderitem_full_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymerorderitem : substances_store_dm.PolymerOrderItem = None) -> None:
        try:
            await self.polymerorderitem_client.Update(
                lara_django_substances_store_pb2.PolymerOrderItemRequest(**polymerorderitem.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerorderitem_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerorderitem_client.Destroy(lara_django_substances_store_pb2.PolymerOrderItemDestroyRequest(polymerorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerorderitem_id: {e}")

#_________________  PolymerWishlist  ______________________


class PolymerWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerwishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerWishlistclassByIRIControllerStub(channel)
        # )
        
        self.polymerwishlist_client = lara_django_substances_store_pb2_grpc.PolymerWishlistControllerStub(channel)

        # self.polymerwishlist_full_client = lara_django_substances_store_pb2_grpc.PolymerWishlistFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerwishlists:  list[substances_store_dm.PolymerWishlist] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerWishlist]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerwishlistclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerwishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerwishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerWishlistclassRetrieveRequest(iri=polymerwishlist_class_iri)
        #     )
        #     polymerwishlistclass_id = res.polymerwishlistclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerwishlistclass_id: {e}")
        # for polymerwishlist in polymerwishlists:
        #     polymerwishlist.namespace = self.namespace_id
        #     polymerwishlist.polymerwishlist_class = polymerwishlistclass_id

        try:
            create_coroutines = ( self.polymerwishlist_client.Create(lara_django_substances_store_pb2.PolymerWishlistRequest(**polymerwishlist.model_dump())) for polymerwishlist in polymerwishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerwishlist_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerwishlist: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerwishlist_id: str = None,
        polymerwishlist_name: str = None,
        #polymerwishlist_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymerWishlist]:
        filter_list = []
        results_list = []
        if  polymerwishlist_id is not None:
            try:
                res =  await self.polymerwishlist_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerWishlistRetrieveRequest(polymerwishlist_id=polymerwishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerwishlist_id: {e}")

        if polymerwishlist_name is not None:
            filter_list.append({"name": polymerwishlist_name})
        # if polymerwishlist_name_full is not None:
        #     filter_list.append({"name_full": polymerwishlist_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerwishlist_client.List(
                        lara_django_substances_store_pb2.PolymerWishlistListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymerWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerwishlist_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerwishlist_name: str = None,
                          polymerwishlist_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerwishlist_name is not None:
            filter_dict = {"name": polymerwishlist_name}
        elif polymerwishlist_name_full is not None:
            filter_dict = {"name_full": polymerwishlist_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerwishlist_client.List(
                    lara_django_substances_store_pb2.PolymerWishlistListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerwishlist_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerwishlist_id
            else:
                raise ValueError(f"Error retrieving polymerwishlist_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerwishlist_client.List(lara_django_substances_store_pb2.PolymerWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerwishlist_client.List(
                lara_django_substances_store_pb2.PolymerWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerwishlist_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerwishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerwishlist_full_client.List(
                lara_django_substances_store_pb2.PolymerWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerwishlist_full_client.List(
                lara_django_substances_store_pb2.PolymerWishlistFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymerwishlist : substances_store_dm.PolymerWishlist = None) -> None:
        try:
            await self.polymerwishlist_client.Update(
                lara_django_substances_store_pb2.PolymerWishlistRequest(**polymerwishlist.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerwishlist_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerwishlist_client.Destroy(lara_django_substances_store_pb2.PolymerWishlistDestroyRequest(polymerwishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerwishlist_id: {e}")

#_________________  PolymerBasket  ______________________


class PolymerBasketInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerbasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerBasketClassByIRIControllerStub(channel)
        # )
        
        self.polymerbasket_client = lara_django_substances_store_pb2_grpc.PolymerBasketControllerStub(channel)

        # self.polymerbasket_full_client = lara_django_substances_store_pb2_grpc.PolymerBasketFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerbaskets:  list[substances_store_dm.PolymerBasket] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerBasket]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerbasketclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerbasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerbasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerBasketClassRetrieveRequest(iri=polymerbasket_class_iri)
        #     )
        #     polymerbasketclass_id = res.polymerbasketclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerbasketclass_id: {e}")
        # for polymerbasket in polymerbaskets:
        #     polymerbasket.namespace = self.namespace_id
        #     polymerbasket.polymerbasket_class = polymerbasketclass_id

        try:
            create_coroutines = ( self.polymerbasket_client.Create(lara_django_substances_store_pb2.PolymerBasketRequest(**polymerbasket.model_dump())) for polymerbasket in polymerbaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerbasket_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerbasket: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerbasket_id: str = None,
        polymerbasket_name: str = None,
        #polymerbasket_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymerBasket]:
        filter_list = []
        results_list = []
        if  polymerbasket_id is not None:
            try:
                res =  await self.polymerbasket_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerBasketRetrieveRequest(polymerbasket_id=polymerbasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerbasket_id: {e}")

        if polymerbasket_name is not None:
            filter_list.append({"name": polymerbasket_name})
        # if polymerbasket_name_full is not None:
        #     filter_list.append({"name_full": polymerbasket_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerbasket_client.List(
                        lara_django_substances_store_pb2.PolymerBasketListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymerBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerbasket_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerbasket_name: str = None,
                          polymerbasket_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerbasket_name is not None:
            filter_dict = {"name": polymerbasket_name}
        elif polymerbasket_name_full is not None:
            filter_dict = {"name_full": polymerbasket_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerbasket_client.List(
                    lara_django_substances_store_pb2.PolymerBasketListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerbasket_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerbasket_id
            else:
                raise ValueError(f"Error retrieving polymerbasket_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerbasket_client.List(lara_django_substances_store_pb2.PolymerBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerbasket_client.List(
                lara_django_substances_store_pb2.PolymerBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerbasket_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerbasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerbasket_full_client.List(
                lara_django_substances_store_pb2.PolymerBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerbasket_full_client.List(
                lara_django_substances_store_pb2.PolymerBasketFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymerbasket : substances_store_dm.PolymerBasket = None) -> None:
        try:
            await self.polymerbasket_client.Update(
                lara_django_substances_store_pb2.PolymerBasketRequest(**polymerbasket.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerbasket_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerbasket_client.Destroy(lara_django_substances_store_pb2.PolymerBasketDestroyRequest(polymerbasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerbasket_id: {e}")

#_________________  PolymersOrder  ______________________


class PolymersOrderInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymersorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymersOrderclassByIRIControllerStub(channel)
        # )
        
        self.polymersorder_client = lara_django_substances_store_pb2_grpc.PolymersOrderControllerStub(channel)

        # self.polymersorder_full_client = lara_django_substances_store_pb2_grpc.PolymersOrderFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymersorders:  list[substances_store_dm.PolymersOrder] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymersOrder]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymersorderclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymersorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymersorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymersOrderclassRetrieveRequest(iri=polymersorder_class_iri)
        #     )
        #     polymersorderclass_id = res.polymersorderclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymersorderclass_id: {e}")
        # for polymersorder in polymersorders:
        #     polymersorder.namespace = self.namespace_id
        #     polymersorder.polymersorder_class = polymersorderclass_id

        try:
            create_coroutines = ( self.polymersorder_client.Create(lara_django_substances_store_pb2.PolymersOrderRequest(**polymersorder.model_dump())) for polymersorder in polymersorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymersorder_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymersorder: {e}")

    @export_file
    async def retrieve(
        self, 
        polymersorder_id: str = None,
        polymersorder_name: str = None,
        #polymersorder_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymersOrder]:
        filter_list = []
        results_list = []
        if  polymersorder_id is not None:
            try:
                res =  await self.polymersorder_client.Retrieve(
                    lara_django_substances_store_pb2.PolymersOrderRetrieveRequest(polymersorder_id=polymersorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymersOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymersorder_id: {e}")

        if polymersorder_name is not None:
            filter_list.append({"name": polymersorder_name})
        # if polymersorder_name_full is not None:
        #     filter_list.append({"name_full": polymersorder_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymersorder_client.List(
                        lara_django_substances_store_pb2.PolymersOrderListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymersOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymersorder_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymersorder_name: str = None,
                          polymersorder_name_full: str = None,
                          iri: str = None,) -> str:
        if polymersorder_name is not None:
            filter_dict = {"name": polymersorder_name}
        elif polymersorder_name_full is not None:
            filter_dict = {"name_full": polymersorder_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymersorder_client.List(
                    lara_django_substances_store_pb2.PolymersOrderListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymersorder_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymersorder_id
            else:
                raise ValueError(f"Error retrieving polymersorder_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymersorder_client.List(lara_django_substances_store_pb2.PolymersOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymersorder_client.List(
                lara_django_substances_store_pb2.PolymersOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymersorder_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymersorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymersorder_full_client.List(
                lara_django_substances_store_pb2.PolymersOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymersorder_full_client.List(
                lara_django_substances_store_pb2.PolymersOrderFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymersorder : substances_store_dm.PolymersOrder = None) -> None:
        try:
            await self.polymersorder_client.Update(
                lara_django_substances_store_pb2.PolymersOrderRequest(**polymersorder.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymersorder_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymersorder_client.Destroy(lara_django_substances_store_pb2.PolymersOrderDestroyRequest(polymersorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymersorder_id: {e}")

#_________________  PolymersLocalStore  ______________________


class PolymersLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.polymerlocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymersLocalStoreclassByIRIControllerStub(channel)
        # )
        
        self.polymerlocalstore_client = lara_django_substances_store_pb2_grpc.PolymersLocalStoreControllerStub(channel)

        # self.polymerlocalstore_full_client = lara_django_substances_store_pb2_grpc.PolymersLocalStoreFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  polymerlocalstores:  list[substances_store_dm.PolymersLocalStore] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymersLocalStore]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # polymerlocalstoreclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerlocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerlocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymersLocalStoreclassRetrieveRequest(iri=polymerlocalstore_class_iri)
        #     )
        #     polymerlocalstoreclass_id = res.polymerlocalstoreclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving polymerlocalstoreclass_id: {e}")
        # for polymerlocalstore in polymerlocalstores:
        #     polymerlocalstore.namespace = self.namespace_id
        #     polymerlocalstore.polymerlocalstore_class = polymerlocalstoreclass_id

        try:
            create_coroutines = ( self.polymerlocalstore_client.Create(lara_django_substances_store_pb2.PolymersLocalStoreRequest(**polymerlocalstore.model_dump())) for polymerlocalstore in polymerlocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerlocalstore_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating polymerlocalstore: {e}")

    @export_file
    async def retrieve(
        self, 
        polymerlocalstore_id: str = None,
        polymerlocalstore_name: str = None,
        #polymerlocalstore_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.PolymersLocalStore]:
        filter_list = []
        results_list = []
        if  polymerlocalstore_id is not None:
            try:
                res =  await self.polymerlocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.PolymersLocalStoreRetrieveRequest(polymerlocalstore_id=polymerlocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymersLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving polymerlocalstore_id: {e}")

        if polymerlocalstore_name is not None:
            filter_list.append({"name": polymerlocalstore_name})
        # if polymerlocalstore_name_full is not None:
        #     filter_list.append({"name_full": polymerlocalstore_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerlocalstore_client.List(
                        lara_django_substances_store_pb2.PolymersLocalStoreListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.PolymersLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving polymerlocalstore_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          polymerlocalstore_name: str = None,
                          polymerlocalstore_name_full: str = None,
                          iri: str = None,) -> str:
        if polymerlocalstore_name is not None:
            filter_dict = {"name": polymerlocalstore_name}
        elif polymerlocalstore_name_full is not None:
            filter_dict = {"name_full": polymerlocalstore_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.polymerlocalstore_client.List(
                    lara_django_substances_store_pb2.PolymersLocalStoreListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving polymerlocalstore_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].polymerlocalstore_id
            else:
                raise ValueError(f"Error retrieving polymerlocalstore_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.polymerlocalstore_client.List(lara_django_substances_store_pb2.PolymersLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerlocalstore_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerlocalstore_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.polymerlocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerlocalstore_full_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerlocalstore_full_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, polymerlocalstore : substances_store_dm.PolymersLocalStore = None) -> None:
        try:
            await self.polymerlocalstore_client.Update(
                lara_django_substances_store_pb2.PolymersLocalStoreRequest(**polymerlocalstore.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating polymerlocalstore_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.polymerlocalstore_client.Destroy(lara_django_substances_store_pb2.PolymersLocalStoreDestroyRequest(polymerlocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting polymerlocalstore_id: {e}")

#_________________  MixtureComponentInstance  ______________________


class MixtureComponentInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturecomponentinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureComponentInstanceClassByIRIControllerStub(channel)
        # )
        
        self.mixturecomponentinstance_client = lara_django_substances_store_pb2_grpc.MixtureComponentInstanceControllerStub(channel)

        # self.mixturecomponentinstance_full_client = lara_django_substances_store_pb2_grpc.MixtureComponentInstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturecomponentinstances:  list[substances_store_dm.MixtureComponentInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureComponentInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturecomponentinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturecomponentinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturecomponentinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureComponentInstanceClassRetrieveRequest(iri=mixturecomponentinstance_class_iri)
        #     )
        #     mixturecomponentinstanceclass_id = res.mixturecomponentinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturecomponentinstanceclass_id: {e}")
        # for mixturecomponentinstance in mixturecomponentinstances:
        #     mixturecomponentinstance.namespace = self.namespace_id
        #     mixturecomponentinstance.mixturecomponentinstance_class = mixturecomponentinstanceclass_id

        try:
            create_coroutines = ( self.mixturecomponentinstance_client.Create(lara_django_substances_store_pb2.MixtureComponentInstanceRequest(**mixturecomponentinstance.model_dump())) for mixturecomponentinstance in mixturecomponentinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturecomponentinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturecomponentinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturecomponentinstance_id: str = None,
        mixturecomponentinstance_name: str = None,
        #mixturecomponentinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixtureComponentInstance]:
        filter_list = []
        results_list = []
        if  mixturecomponentinstance_id is not None:
            try:
                res =  await self.mixturecomponentinstance_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureComponentInstanceRetrieveRequest(mixturecomponentinstance_id=mixturecomponentinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureComponentInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponentinstance_id: {e}")

        if mixturecomponentinstance_name is not None:
            filter_list.append({"name": mixturecomponentinstance_name})
        # if mixturecomponentinstance_name_full is not None:
        #     filter_list.append({"name_full": mixturecomponentinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturecomponentinstance_client.List(
                        lara_django_substances_store_pb2.MixtureComponentInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixtureComponentInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponentinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturecomponentinstance_name: str = None,
                          mixturecomponentinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturecomponentinstance_name is not None:
            filter_dict = {"name": mixturecomponentinstance_name}
        elif mixturecomponentinstance_name_full is not None:
            filter_dict = {"name_full": mixturecomponentinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturecomponentinstance_client.List(
                    lara_django_substances_store_pb2.MixtureComponentInstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturecomponentinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturecomponentinstance_id
            else:
                raise ValueError(f"Error retrieving mixturecomponentinstance_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturecomponentinstance_client.List(lara_django_substances_store_pb2.MixtureComponentInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturecomponentinstance_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturecomponentinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturecomponentinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturecomponentinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturecomponentinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixturecomponentinstance : substances_store_dm.MixtureComponentInstance = None) -> None:
        try:
            await self.mixturecomponentinstance_client.Update(
                lara_django_substances_store_pb2.MixtureComponentInstanceRequest(**mixturecomponentinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturecomponentinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturecomponentinstance_client.Destroy(lara_django_substances_store_pb2.MixtureComponentInstanceDestroyRequest(mixturecomponentinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturecomponentinstance_id: {e}")

#_________________  MixtureInstance  ______________________


class MixtureInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixtureinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureInstanceClassByIRIControllerStub(channel)
        # )
        
        self.mixtureinstance_client = lara_django_substances_store_pb2_grpc.MixtureInstanceControllerStub(channel)

        # self.mixtureinstance_full_client = lara_django_substances_store_pb2_grpc.MixtureInstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureinstances:  list[substances_store_dm.MixtureInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixtureinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixtureinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixtureinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureInstanceClassRetrieveRequest(iri=mixtureinstance_class_iri)
        #     )
        #     mixtureinstanceclass_id = res.mixtureinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixtureinstanceclass_id: {e}")
        # for mixtureinstance in mixtureinstances:
        #     mixtureinstance.namespace = self.namespace_id
        #     mixtureinstance.mixtureinstance_class = mixtureinstanceclass_id

        try:
            create_coroutines = ( self.mixtureinstance_client.Create(lara_django_substances_store_pb2.MixtureInstanceRequest(**mixtureinstance.model_dump())) for mixtureinstance in mixtureinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixtureinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixtureinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        mixtureinstance_id: str = None,
        mixtureinstance_name: str = None,
        #mixtureinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixtureInstance]:
        filter_list = []
        results_list = []
        if  mixtureinstance_id is not None:
            try:
                res =  await self.mixtureinstance_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureInstanceRetrieveRequest(mixtureinstance_id=mixtureinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixtureinstance_id: {e}")

        if mixtureinstance_name is not None:
            filter_list.append({"name": mixtureinstance_name})
        # if mixtureinstance_name_full is not None:
        #     filter_list.append({"name_full": mixtureinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixtureinstance_client.List(
                        lara_django_substances_store_pb2.MixtureInstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixtureInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixtureinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixtureinstance_name: str = None,
                          mixtureinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if mixtureinstance_name is not None:
            filter_dict = {"name": mixtureinstance_name}
        elif mixtureinstance_name_full is not None:
            filter_dict = {"name_full": mixtureinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixtureinstance_client.List(
                    lara_django_substances_store_pb2.MixtureInstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixtureinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixtureinstance_id
            else:
                raise ValueError(f"Error retrieving mixtureinstance_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixtureinstance_client.List(lara_django_substances_store_pb2.MixtureInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureinstance_client.List(
                lara_django_substances_store_pb2.MixtureInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixtureinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureInstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixtureinstance : substances_store_dm.MixtureInstance = None) -> None:
        try:
            await self.mixtureinstance_client.Update(
                lara_django_substances_store_pb2.MixtureInstanceRequest(**mixtureinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixtureinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixtureinstance_client.Destroy(lara_django_substances_store_pb2.MixtureInstanceDestroyRequest(mixtureinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixtureinstance_id: {e}")

#_________________  MixtureOrderItem  ______________________


class MixtureOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixtureorderitem_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureOrderItemclassByIRIControllerStub(channel)
        # )
        
        self.mixtureorderitem_client = lara_django_substances_store_pb2_grpc.MixtureOrderItemControllerStub(channel)

        # self.mixtureorderitem_full_client = lara_django_substances_store_pb2_grpc.MixtureOrderItemFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureorderitems:  list[substances_store_dm.MixtureOrderItem] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureOrderItem]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixtureorderitemclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixtureorderitem_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixtureorderitem_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureOrderItemclassRetrieveRequest(iri=mixtureorderitem_class_iri)
        #     )
        #     mixtureorderitemclass_id = res.mixtureorderitemclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixtureorderitemclass_id: {e}")
        # for mixtureorderitem in mixtureorderitems:
        #     mixtureorderitem.namespace = self.namespace_id
        #     mixtureorderitem.mixtureorderitem_class = mixtureorderitemclass_id

        try:
            create_coroutines = ( self.mixtureorderitem_client.Create(lara_django_substances_store_pb2.MixtureOrderItemRequest(**mixtureorderitem.model_dump())) for mixtureorderitem in mixtureorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixtureorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixtureorderitem: {e}")

    @export_file
    async def retrieve(
        self, 
        mixtureorderitem_id: str = None,
        mixtureorderitem_name: str = None,
        #mixtureorderitem_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixtureOrderItem]:
        filter_list = []
        results_list = []
        if  mixtureorderitem_id is not None:
            try:
                res =  await self.mixtureorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureOrderItemRetrieveRequest(mixtureorderitem_id=mixtureorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixtureorderitem_id: {e}")

        if mixtureorderitem_name is not None:
            filter_list.append({"name": mixtureorderitem_name})
        # if mixtureorderitem_name_full is not None:
        #     filter_list.append({"name_full": mixtureorderitem_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixtureorderitem_client.List(
                        lara_django_substances_store_pb2.MixtureOrderItemListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixtureorderitem_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixtureorderitem_name: str = None,
                          mixtureorderitem_name_full: str = None,
                          iri: str = None,) -> str:
        if mixtureorderitem_name is not None:
            filter_dict = {"name": mixtureorderitem_name}
        elif mixtureorderitem_name_full is not None:
            filter_dict = {"name_full": mixtureorderitem_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixtureorderitem_client.List(
                    lara_django_substances_store_pb2.MixtureOrderItemListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixtureorderitem_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixtureorderitem_id
            else:
                raise ValueError(f"Error retrieving mixtureorderitem_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixtureorderitem_client.List(lara_django_substances_store_pb2.MixtureOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureorderitem_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureorderitem_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixtureorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureorderitem_full_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureorderitem_full_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixtureorderitem : substances_store_dm.MixtureOrderItem = None) -> None:
        try:
            await self.mixtureorderitem_client.Update(
                lara_django_substances_store_pb2.MixtureOrderItemRequest(**mixtureorderitem.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixtureorderitem_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixtureorderitem_client.Destroy(lara_django_substances_store_pb2.MixtureOrderItemDestroyRequest(mixtureorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixtureorderitem_id: {e}")

#_________________  MixtureWishlist  ______________________


class MixtureWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturewishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureWishlistclassByIRIControllerStub(channel)
        # )
        
        self.mixturewishlist_client = lara_django_substances_store_pb2_grpc.MixtureWishlistControllerStub(channel)

        # self.mixturewishlist_full_client = lara_django_substances_store_pb2_grpc.MixtureWishlistFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturewishlists:  list[substances_store_dm.MixtureWishlist] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureWishlist]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturewishlistclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturewishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturewishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureWishlistclassRetrieveRequest(iri=mixturewishlist_class_iri)
        #     )
        #     mixturewishlistclass_id = res.mixturewishlistclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturewishlistclass_id: {e}")
        # for mixturewishlist in mixturewishlists:
        #     mixturewishlist.namespace = self.namespace_id
        #     mixturewishlist.mixturewishlist_class = mixturewishlistclass_id

        try:
            create_coroutines = ( self.mixturewishlist_client.Create(lara_django_substances_store_pb2.MixtureWishlistRequest(**mixturewishlist.model_dump())) for mixturewishlist in mixturewishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturewishlist_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturewishlist: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturewishlist_id: str = None,
        mixturewishlist_name: str = None,
        #mixturewishlist_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixtureWishlist]:
        filter_list = []
        results_list = []
        if  mixturewishlist_id is not None:
            try:
                res =  await self.mixturewishlist_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureWishlistRetrieveRequest(mixturewishlist_id=mixturewishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturewishlist_id: {e}")

        if mixturewishlist_name is not None:
            filter_list.append({"name": mixturewishlist_name})
        # if mixturewishlist_name_full is not None:
        #     filter_list.append({"name_full": mixturewishlist_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturewishlist_client.List(
                        lara_django_substances_store_pb2.MixtureWishlistListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixtureWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturewishlist_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturewishlist_name: str = None,
                          mixturewishlist_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturewishlist_name is not None:
            filter_dict = {"name": mixturewishlist_name}
        elif mixturewishlist_name_full is not None:
            filter_dict = {"name_full": mixturewishlist_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturewishlist_client.List(
                    lara_django_substances_store_pb2.MixtureWishlistListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturewishlist_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturewishlist_id
            else:
                raise ValueError(f"Error retrieving mixturewishlist_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturewishlist_client.List(lara_django_substances_store_pb2.MixtureWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturewishlist_client.List(
                lara_django_substances_store_pb2.MixtureWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturewishlist_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturewishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturewishlist_full_client.List(
                lara_django_substances_store_pb2.MixtureWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturewishlist_full_client.List(
                lara_django_substances_store_pb2.MixtureWishlistFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixturewishlist : substances_store_dm.MixtureWishlist = None) -> None:
        try:
            await self.mixturewishlist_client.Update(
                lara_django_substances_store_pb2.MixtureWishlistRequest(**mixturewishlist.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturewishlist_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturewishlist_client.Destroy(lara_django_substances_store_pb2.MixtureWishlistDestroyRequest(mixturewishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturewishlist_id: {e}")

#_________________  MixtureBasket  ______________________


class MixtureBasketInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturebasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureBasketClassByIRIControllerStub(channel)
        # )
        
        self.mixturebasket_client = lara_django_substances_store_pb2_grpc.MixtureBasketControllerStub(channel)

        # self.mixturebasket_full_client = lara_django_substances_store_pb2_grpc.MixtureBasketFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturebaskets:  list[substances_store_dm.MixtureBasket] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureBasket]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturebasketclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturebasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturebasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureBasketClassRetrieveRequest(iri=mixturebasket_class_iri)
        #     )
        #     mixturebasketclass_id = res.mixturebasketclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturebasketclass_id: {e}")
        # for mixturebasket in mixturebaskets:
        #     mixturebasket.namespace = self.namespace_id
        #     mixturebasket.mixturebasket_class = mixturebasketclass_id

        try:
            create_coroutines = ( self.mixturebasket_client.Create(lara_django_substances_store_pb2.MixtureBasketRequest(**mixturebasket.model_dump())) for mixturebasket in mixturebaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturebasket_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturebasket: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturebasket_id: str = None,
        mixturebasket_name: str = None,
        #mixturebasket_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixtureBasket]:
        filter_list = []
        results_list = []
        if  mixturebasket_id is not None:
            try:
                res =  await self.mixturebasket_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureBasketRetrieveRequest(mixturebasket_id=mixturebasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturebasket_id: {e}")

        if mixturebasket_name is not None:
            filter_list.append({"name": mixturebasket_name})
        # if mixturebasket_name_full is not None:
        #     filter_list.append({"name_full": mixturebasket_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturebasket_client.List(
                        lara_django_substances_store_pb2.MixtureBasketListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixtureBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturebasket_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturebasket_name: str = None,
                          mixturebasket_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturebasket_name is not None:
            filter_dict = {"name": mixturebasket_name}
        elif mixturebasket_name_full is not None:
            filter_dict = {"name_full": mixturebasket_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturebasket_client.List(
                    lara_django_substances_store_pb2.MixtureBasketListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturebasket_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturebasket_id
            else:
                raise ValueError(f"Error retrieving mixturebasket_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturebasket_client.List(lara_django_substances_store_pb2.MixtureBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturebasket_client.List(
                lara_django_substances_store_pb2.MixtureBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturebasket_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturebasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturebasket_full_client.List(
                lara_django_substances_store_pb2.MixtureBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturebasket_full_client.List(
                lara_django_substances_store_pb2.MixtureBasketFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixturebasket : substances_store_dm.MixtureBasket = None) -> None:
        try:
            await self.mixturebasket_client.Update(
                lara_django_substances_store_pb2.MixtureBasketRequest(**mixturebasket.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturebasket_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturebasket_client.Destroy(lara_django_substances_store_pb2.MixtureBasketDestroyRequest(mixturebasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturebasket_id: {e}")

#_________________  MixturesOrder  ______________________


class MixturesOrderInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturesorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixturesOrderclassByIRIControllerStub(channel)
        # )
        
        self.mixturesorder_client = lara_django_substances_store_pb2_grpc.MixturesOrderControllerStub(channel)

        # self.mixturesorder_full_client = lara_django_substances_store_pb2_grpc.MixturesOrderFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturesorders:  list[substances_store_dm.MixturesOrder] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixturesOrder]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturesorderclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturesorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturesorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixturesOrderclassRetrieveRequest(iri=mixturesorder_class_iri)
        #     )
        #     mixturesorderclass_id = res.mixturesorderclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturesorderclass_id: {e}")
        # for mixturesorder in mixturesorders:
        #     mixturesorder.namespace = self.namespace_id
        #     mixturesorder.mixturesorder_class = mixturesorderclass_id

        try:
            create_coroutines = ( self.mixturesorder_client.Create(lara_django_substances_store_pb2.MixturesOrderRequest(**mixturesorder.model_dump())) for mixturesorder in mixturesorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturesorder_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturesorder: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturesorder_id: str = None,
        mixturesorder_name: str = None,
        #mixturesorder_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixturesOrder]:
        filter_list = []
        results_list = []
        if  mixturesorder_id is not None:
            try:
                res =  await self.mixturesorder_client.Retrieve(
                    lara_django_substances_store_pb2.MixturesOrderRetrieveRequest(mixturesorder_id=mixturesorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixturesOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturesorder_id: {e}")

        if mixturesorder_name is not None:
            filter_list.append({"name": mixturesorder_name})
        # if mixturesorder_name_full is not None:
        #     filter_list.append({"name_full": mixturesorder_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturesorder_client.List(
                        lara_django_substances_store_pb2.MixturesOrderListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixturesOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturesorder_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturesorder_name: str = None,
                          mixturesorder_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturesorder_name is not None:
            filter_dict = {"name": mixturesorder_name}
        elif mixturesorder_name_full is not None:
            filter_dict = {"name_full": mixturesorder_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturesorder_client.List(
                    lara_django_substances_store_pb2.MixturesOrderListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturesorder_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturesorder_id
            else:
                raise ValueError(f"Error retrieving mixturesorder_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturesorder_client.List(lara_django_substances_store_pb2.MixturesOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturesorder_client.List(
                lara_django_substances_store_pb2.MixturesOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturesorder_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturesorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturesorder_full_client.List(
                lara_django_substances_store_pb2.MixturesOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturesorder_full_client.List(
                lara_django_substances_store_pb2.MixturesOrderFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixturesorder : substances_store_dm.MixturesOrder = None) -> None:
        try:
            await self.mixturesorder_client.Update(
                lara_django_substances_store_pb2.MixturesOrderRequest(**mixturesorder.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturesorder_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturesorder_client.Destroy(lara_django_substances_store_pb2.MixturesOrderDestroyRequest(mixturesorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturesorder_id: {e}")

#_________________  MixturesLocalStore  ______________________


class MixturesLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.mixturelocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixturesLocalStoreclassByIRIControllerStub(channel)
        # )
        
        self.mixturelocalstore_client = lara_django_substances_store_pb2_grpc.MixturesLocalStoreControllerStub(channel)

        # self.mixturelocalstore_full_client = lara_django_substances_store_pb2_grpc.MixturesLocalStoreFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  mixturelocalstores:  list[substances_store_dm.MixturesLocalStore] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixturesLocalStore]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # mixturelocalstoreclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturelocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturelocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixturesLocalStoreclassRetrieveRequest(iri=mixturelocalstore_class_iri)
        #     )
        #     mixturelocalstoreclass_id = res.mixturelocalstoreclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving mixturelocalstoreclass_id: {e}")
        # for mixturelocalstore in mixturelocalstores:
        #     mixturelocalstore.namespace = self.namespace_id
        #     mixturelocalstore.mixturelocalstore_class = mixturelocalstoreclass_id

        try:
            create_coroutines = ( self.mixturelocalstore_client.Create(lara_django_substances_store_pb2.MixturesLocalStoreRequest(**mixturelocalstore.model_dump())) for mixturelocalstore in mixturelocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixturelocalstore_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating mixturelocalstore: {e}")

    @export_file
    async def retrieve(
        self, 
        mixturelocalstore_id: str = None,
        mixturelocalstore_name: str = None,
        #mixturelocalstore_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[substances_store_dm.MixturesLocalStore]:
        filter_list = []
        results_list = []
        if  mixturelocalstore_id is not None:
            try:
                res =  await self.mixturelocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.MixturesLocalStoreRetrieveRequest(mixturelocalstore_id=mixturelocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixturesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving mixturelocalstore_id: {e}")

        if mixturelocalstore_name is not None:
            filter_list.append({"name": mixturelocalstore_name})
        # if mixturelocalstore_name_full is not None:
        #     filter_list.append({"name_full": mixturelocalstore_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturelocalstore_client.List(
                        lara_django_substances_store_pb2.MixturesLocalStoreListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ substances_store_dm.MixturesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving mixturelocalstore_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          mixturelocalstore_name: str = None,
                          mixturelocalstore_name_full: str = None,
                          iri: str = None,) -> str:
        if mixturelocalstore_name is not None:
            filter_dict = {"name": mixturelocalstore_name}
        elif mixturelocalstore_name_full is not None:
            filter_dict = {"name_full": mixturelocalstore_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.mixturelocalstore_client.List(
                    lara_django_substances_store_pb2.MixturesLocalStoreListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving mixturelocalstore_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].mixturelocalstore_id
            else:
                raise ValueError(f"Error retrieving mixturelocalstore_id - no or too many results found.")
            
        
    async def list(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.mixturelocalstore_client.List(lara_django_substances_store_pb2.MixturesLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturelocalstore_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturelocalstore_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.mixturelocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturelocalstore_full_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturelocalstore_full_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image(stub,  file_chunk_method=None)
    async def update(self, mixturelocalstore : substances_store_dm.MixturesLocalStore = None) -> None:
        try:
            await self.mixturelocalstore_client.Update(
                lara_django_substances_store_pb2.MixturesLocalStoreRequest(**mixturelocalstore.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating mixturelocalstore_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list(filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.mixturelocalstore_client.Destroy(lara_django_substances_store_pb2.MixturesLocalStoreDestroyRequest(mixturelocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting mixturelocalstore_id: {e}")

