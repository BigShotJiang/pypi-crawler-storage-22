"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_substances_store high_level_interface *

:details: lara_django_substances_store high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_substances_store
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2 as lara_django_substances_store_pb2
import lara_django_substances_store_grpc.v1.lara_django_substances_store_pb2_grpc as lara_django_substances_store_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_substances_store_grpc.lara_django_substances_store_data_model as substances_store_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_substances_store_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_substances_store_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_substances_store_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_substances_store_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_substances_store_pb2.ImageUploadChunk


        # self.extradata_full_client = lara_django_substances_store_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[substances_store_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_substances_store_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if extradata.namespace == "" or extradata.namespace == "default":
                    extradata.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_substances_store_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_substances_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_substances_store_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> substances_store_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_substances_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = substances_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    @download_image  # needed for image download
    async def get_image(self, extradata_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = extradata_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_substances_store_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_substances_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_substances_store_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_substances_store_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : substances_store_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            await self.extradata_client.Update(
                lara_django_substances_store_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_substances_store_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  SubstanceInstance  ______________________


class SubstanceInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substanceinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceInstanceclassByIRIControllerStub(channel)
        # )

        self.substanceinstance_client = lara_django_substances_store_pb2_grpc.SubstanceInstanceControllerStub(channel)
        

        # self.substanceinstance_full_client = lara_django_substances_store_pb2_grpc.SubstanceInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substanceinstances:  list[substances_store_dm.SubstanceInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceInstance]]:
        """ create a list of substanceinstance instances,
               returns a list of substanceinstance data model objects or ids_only

        :param substanceinstances: list of substanceinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substanceinstance data model objects or ids_only
        """
        substanceinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceInstanceclassRetrieveRequest(iri=substanceinstance_class_iri)
        #     )
        #     substanceinstanceclass_id = res.substanceinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substanceinstanceclass_id: {e}")
        for substanceinstance in substanceinstances:
            if substanceinstance.namespace == "" or substanceinstance.namespace == "default":
                    substanceinstance.namespace = namespace_id
            # substanceinstance.substanceinstance_class = substanceinstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substanceinstance_client.Create(lara_django_substances_store_pb2.SubstanceInstanceRequest(**substanceinstance.model_dump())) for substanceinstance in substanceinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substanceinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substanceinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substanceinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceInstance]:
        """ retrieve a list of substanceinstance instances by substanceinstance_id, name or filter_dict,
               returns a list of substanceinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substanceinstance_id is not None:
            try:
                res =  await self.substanceinstance_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceInstanceRetrieveRequest(substanceinstance_id=substanceinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substanceinstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substanceinstance_client.List(
                    lara_django_substances_store_pb2.SubstanceInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstanceInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substanceinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substanceinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substanceinstance_id
        else:
            raise ValueError(f"Error retrieving substanceinstance_id - no or too many results found.")
    
    async def get_by_id(self, substanceinstance_id: str = None, id_only: bool = False) -> substances_store_dm.SubstanceInstance:
        """ retrieve a substanceinstance data model by substanceinstance_id """
        try:
            res = await self.substanceinstance_client.Retrieve(
                lara_django_substances_store_pb2.SubstanceInstanceRetrieveRequest(substanceinstance_id=substanceinstance_id)
            )
            item = substances_store_dm.SubstanceInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substanceinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substanceinstance_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstanceInstance | str:
        """ retrieve a substanceinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substanceinstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstanceInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substanceinstance_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstanceInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving substanceinstance name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substanceinstances """
        if filter_dict is None:
            res = await self.substanceinstance_client.List(lara_django_substances_store_pb2.SubstanceInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceinstance_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substanceinstances """
        if self.substanceinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceinstance_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceinstance_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substanceinstance : substances_store_dm.SubstanceInstance = None) -> None:
        """ update a substanceinstance model instance """
        try:
            await self.substanceinstance_client.Update(
                lara_django_substances_store_pb2.SubstanceInstanceRequest(**substanceinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substanceinstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substanceinstance by substanceinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substanceinstance_client.Destroy(lara_django_substances_store_pb2.SubstanceInstanceDestroyRequest(substanceinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substanceinstance_id: {e}")

#_________________  SubstanceInstancesSubset  ______________________


class SubstanceInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substanceinstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.substanceinstancessubset_client = lara_django_substances_store_pb2_grpc.SubstanceInstancesSubsetControllerStub(channel)
        

        # self.substanceinstancessubset_full_client = lara_django_substances_store_pb2_grpc.SubstanceInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substanceinstancessubsets:  list[substances_store_dm.SubstanceInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceInstancesSubset]]:
        """ create a list of substanceinstancessubset instances,
               returns a list of substanceinstancessubset data model objects or ids_only

        :param substanceinstancessubsets: list of substanceinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substanceinstancessubset data model objects or ids_only
        """
        substanceinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceinstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceInstancesSubsetclassRetrieveRequest(iri=substanceinstancessubset_class_iri)
        #     )
        #     substanceinstancessubsetclass_id = res.substanceinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substanceinstancessubsetclass_id: {e}")
        for substanceinstancessubset in substanceinstancessubsets:
            if substanceinstancessubset.namespace == "" or substanceinstancessubset.namespace == "default":
                    substanceinstancessubset.namespace = namespace_id
            # substanceinstancessubset.substanceinstancessubset_class = substanceinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substanceinstancessubset_client.Create(lara_django_substances_store_pb2.SubstanceInstancesSubsetRequest(**substanceinstancessubset.model_dump())) for substanceinstancessubset in substanceinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substanceinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substanceinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substanceinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceInstancesSubset]:
        """ retrieve a list of substanceinstancessubset instances by substanceinstancessubset_id, name or filter_dict,
               returns a list of substanceinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substanceinstancessubset_id is not None:
            try:
                res =  await self.substanceinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceInstancesSubsetRetrieveRequest(substanceinstancessubset_id=substanceinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substanceinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substanceinstancessubset_client.List(
                    lara_django_substances_store_pb2.SubstanceInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substanceinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substanceinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substanceinstancessubset_id
        else:
            raise ValueError(f"Error retrieving substanceinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, substanceinstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.SubstanceInstancesSubset:
        """ retrieve a substanceinstancessubset data model by substanceinstancessubset_id """
        try:
            res = await self.substanceinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetRetrieveRequest(substanceinstancessubset_id=substanceinstancessubset_id)
            )
            item = substances_store_dm.SubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substanceinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substanceinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstanceInstancesSubset | str:
        """ retrieve a substanceinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substanceinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substanceinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstanceInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving substanceinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substanceinstancessubsets """
        if filter_dict is None:
            res = await self.substanceinstancessubset_client.List(lara_django_substances_store_pb2.SubstanceInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceinstancessubset_client.List(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substanceinstancessubsets """
        if self.substanceinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceinstancessubset_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceinstancessubset_full_client.List(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substanceinstancessubset : substances_store_dm.SubstanceInstancesSubset = None) -> None:
        """ update a substanceinstancessubset model instance """
        try:
            await self.substanceinstancessubset_client.Update(
                lara_django_substances_store_pb2.SubstanceInstancesSubsetRequest(**substanceinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substanceinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substanceinstancessubset by substanceinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substanceinstancessubset_client.Destroy(lara_django_substances_store_pb2.SubstanceInstancesSubsetDestroyRequest(substanceinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substanceinstancessubset_id: {e}")

#_________________  OrderedSubstanceInstancesSubstanceInstancesSubset  ______________________


class OrderedSubstanceInstancesSubstanceInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedsubstanceinstancessubstanceinstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedSubstanceInstancesSubstanceInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedsubstanceinstancessubstanceinstancessubsets:  list[substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedsubstanceinstancessubstanceinstancessubset_client.Create(lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetRequest(**orderedsubstanceinstancessubstanceinstancessubset.model_dump())) for orderedsubstanceinstancessubstanceinstancessubset in orderedsubstanceinstancessubstanceinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedsubstanceinstancessubstanceinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedsubstanceinstancessubstanceinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedsubstanceinstancessubstanceinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset]:
        """ retrieve a list of orderedsubstanceinstancessubstanceinstancessubset instances by orderedsubstanceinstancessubstanceinstancessubset_id, name or filter_dict,
               returns a list of orderedsubstanceinstancessubstanceinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedsubstanceinstancessubstanceinstancessubset_id is not None:
            try:
                res =  await self.orderedsubstanceinstancessubstanceinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetRetrieveRequest(orderedsubstanceinstancessubstanceinstancessubset_id=orderedsubstanceinstancessubstanceinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedsubstanceinstancessubstanceinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedsubstanceinstancessubstanceinstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstanceinstancessubstanceinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedsubstanceinstancessubstanceinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedsubstanceinstancessubstanceinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedsubstanceinstancessubstanceinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedsubstanceinstancessubstanceinstancessubset_id: str = None) -> substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset:
        """ retrieve a orderedsubstanceinstancessubstanceinstancessubset data model by orderedsubstanceinstancessubstanceinstancessubset_id """
        try:
            res = await self.orderedsubstanceinstancessubstanceinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetRetrieveRequest(orderedsubstanceinstancessubstanceinstancessubset_id=orderedsubstanceinstancessubstanceinstancessubset_id)
            )
            return substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstanceinstancessubstanceinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset | str:
        """ retrieve a orderedsubstanceinstancessubstanceinstancessubset data model by name """
        try:
            res = await self.orderedsubstanceinstancessubstanceinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedsubstanceinstancessubstanceinstancessubset_id"]
            else:
                return substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedsubstanceinstancessubstanceinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedsubstanceinstancessubstanceinstancessubsets """
        if filter_dict is None:
            res = await self.orderedsubstanceinstancessubstanceinstancessubset_client.List(lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedsubstanceinstancessubstanceinstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedsubstanceinstancessubstanceinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedsubstanceinstancessubstanceinstancessubsets """
        if self.orderedsubstanceinstancessubstanceinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedsubstanceinstancessubstanceinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedsubstanceinstancessubstanceinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedsubstanceinstancessubstanceinstancessubset : substances_store_dm.OrderedSubstanceInstancesSubstanceInstancesSubset = None) -> None:
        """ update a orderedsubstanceinstancessubstanceinstancessubset model instance """
        try:
            await self.orderedsubstanceinstancessubstanceinstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetRequest(**orderedsubstanceinstancessubstanceinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedsubstanceinstancessubstanceinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedsubstanceinstancessubstanceinstancessubset by orderedsubstanceinstancessubstanceinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedsubstanceinstancessubstanceinstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedSubstanceInstancesSubstanceInstancesSubsetDestroyRequest(orderedsubstanceinstancessubstanceinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedsubstanceinstancessubstanceinstancessubset_id: {e}")

#_________________  SubstanceOrderItem  ______________________


class SubstanceOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.substanceorderitem_client = lara_django_substances_store_pb2_grpc.SubstanceOrderItemControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substanceorderitems:  list[substances_store_dm.SubstanceOrderItem] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.SubstanceOrderItem]]:
        try:
            create_coroutines = ( self.substanceorderitem_client.Create(lara_django_substances_store_pb2.SubstanceOrderItemRequest(**substanceorderitem.model_dump())) for substanceorderitem in substanceorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.substanceorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substanceorderitem: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        substanceorderitem_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceOrderItem]:
        """ retrieve a list of substanceorderitem instances by substanceorderitem_id, name or filter_dict,
               returns a list of substanceorderitem data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  substanceorderitem_id is not None:
            try:
                res =  await self.substanceorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceOrderItemRetrieveRequest(substanceorderitem_id=substanceorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substanceorderitem_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substanceorderitem_client.List(
                    lara_django_substances_store_pb2.SubstanceOrderItemListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substanceorderitem name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the substanceorderitem_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].substanceorderitem_id
        else:
            raise ValueError(f"Error retrieving substanceorderitem_id - no or too many results found.")
    
    async def get_by_id(self, substanceorderitem_id: str = None) -> substances_store_dm.SubstanceOrderItem:
        """ retrieve a substanceorderitem data model by substanceorderitem_id """
        try:
            res = await self.substanceorderitem_client.Retrieve(
                lara_django_substances_store_pb2.SubstanceOrderItemRetrieveRequest(substanceorderitem_id=substanceorderitem_id)
            )
            return substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substanceorderitem_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.SubstanceOrderItem | str:
        """ retrieve a substanceorderitem data model by name """
        try:
            res = await self.substanceorderitem_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstanceOrderItemRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["substanceorderitem_id"]
            else:
                return substances_store_dm.SubstanceOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving substanceorderitem name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substanceorderitems """
        if filter_dict is None:
            res = await self.substanceorderitem_client.List(lara_django_substances_store_pb2.SubstanceOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceorderitem_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceorderitem_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substanceorderitems """
        if self.substanceorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceorderitem_full_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceorderitem_full_client.List(
                lara_django_substances_store_pb2.SubstanceOrderItemFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substanceorderitem : substances_store_dm.SubstanceOrderItem = None) -> None:
        """ update a substanceorderitem model instance """
        try:
            await self.substanceorderitem_client.Update(
                lara_django_substances_store_pb2.SubstanceOrderItemRequest(**substanceorderitem.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substanceorderitem_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substanceorderitem by substanceorderitem_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substanceorderitem_client.Destroy(lara_django_substances_store_pb2.SubstanceOrderItemDestroyRequest(substanceorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substanceorderitem_id: {e}")

#_________________  SubstanceWishlist  ______________________


class SubstanceWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substancewishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceWishlistclassByIRIControllerStub(channel)
        # )

        self.substancewishlist_client = lara_django_substances_store_pb2_grpc.SubstanceWishlistControllerStub(channel)
        

        # self.substancewishlist_full_client = lara_django_substances_store_pb2_grpc.SubstanceWishlistFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substancewishlists:  list[substances_store_dm.SubstanceWishlist] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceWishlist]]:
        """ create a list of substancewishlist instances,
               returns a list of substancewishlist data model objects or ids_only

        :param substancewishlists: list of substancewishlist data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substancewishlist data model objects or ids_only
        """
        substancewishlistclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancewishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancewishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceWishlistclassRetrieveRequest(iri=substancewishlist_class_iri)
        #     )
        #     substancewishlistclass_id = res.substancewishlistclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substancewishlistclass_id: {e}")
        for substancewishlist in substancewishlists:
            if substancewishlist.namespace == "" or substancewishlist.namespace == "default":
                    substancewishlist.namespace = namespace_id
            # substancewishlist.substancewishlist_class = substancewishlistclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substancewishlist_client.Create(lara_django_substances_store_pb2.SubstanceWishlistRequest(**substancewishlist.model_dump())) for substancewishlist in substancewishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substancewishlist_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substancewishlist: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substancewishlist_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceWishlist]:
        """ retrieve a list of substancewishlist instances by substancewishlist_id, name or filter_dict,
               returns a list of substancewishlist data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substancewishlist_id is not None:
            try:
                res =  await self.substancewishlist_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceWishlistRetrieveRequest(substancewishlist_id=substancewishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substancewishlist_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substancewishlist_client.List(
                    lara_django_substances_store_pb2.SubstanceWishlistListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstanceWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substancewishlist name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substancewishlist_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substancewishlist_id
        else:
            raise ValueError(f"Error retrieving substancewishlist_id - no or too many results found.")
    
    async def get_by_id(self, substancewishlist_id: str = None, id_only: bool = False) -> substances_store_dm.SubstanceWishlist:
        """ retrieve a substancewishlist data model by substancewishlist_id """
        try:
            res = await self.substancewishlist_client.Retrieve(
                lara_django_substances_store_pb2.SubstanceWishlistRetrieveRequest(substancewishlist_id=substancewishlist_id)
            )
            item = substances_store_dm.SubstanceWishlist(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substancewishlist_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substancewishlist_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstanceWishlist | str:
        """ retrieve a substancewishlist data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substancewishlist_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstanceWishlistRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substancewishlist_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstanceWishlist(**item)
        except Exception as e:
            logger.error(f"Error retrieving substancewishlist name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substancewishlists """
        if filter_dict is None:
            res = await self.substancewishlist_client.List(lara_django_substances_store_pb2.SubstanceWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancewishlist_client.List(
                lara_django_substances_store_pb2.SubstanceWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancewishlist_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substancewishlists """
        if self.substancewishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancewishlist_full_client.List(
                lara_django_substances_store_pb2.SubstanceWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancewishlist_full_client.List(
                lara_django_substances_store_pb2.SubstanceWishlistFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substancewishlist : substances_store_dm.SubstanceWishlist = None) -> None:
        """ update a substancewishlist model instance """
        try:
            await self.substancewishlist_client.Update(
                lara_django_substances_store_pb2.SubstanceWishlistRequest(**substancewishlist.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substancewishlist_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substancewishlist by substancewishlist_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substancewishlist_client.Destroy(lara_django_substances_store_pb2.SubstanceWishlistDestroyRequest(substancewishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substancewishlist_id: {e}")

#_________________  SubstanceBasket  ______________________


class SubstanceBasketInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substancebasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstanceBasketclassByIRIControllerStub(channel)
        # )

        self.substancebasket_client = lara_django_substances_store_pb2_grpc.SubstanceBasketControllerStub(channel)
        

        # self.substancebasket_full_client = lara_django_substances_store_pb2_grpc.SubstanceBasketFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substancebaskets:  list[substances_store_dm.SubstanceBasket] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstanceBasket]]:
        """ create a list of substancebasket instances,
               returns a list of substancebasket data model objects or ids_only

        :param substancebaskets: list of substancebasket data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substancebasket data model objects or ids_only
        """
        substancebasketclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancebasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancebasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstanceBasketclassRetrieveRequest(iri=substancebasket_class_iri)
        #     )
        #     substancebasketclass_id = res.substancebasketclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substancebasketclass_id: {e}")
        for substancebasket in substancebaskets:
            if substancebasket.namespace == "" or substancebasket.namespace == "default":
                    substancebasket.namespace = namespace_id
            # substancebasket.substancebasket_class = substancebasketclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substancebasket_client.Create(lara_django_substances_store_pb2.SubstanceBasketRequest(**substancebasket.model_dump())) for substancebasket in substancebaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substancebasket_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substancebasket: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substancebasket_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstanceBasket]:
        """ retrieve a list of substancebasket instances by substancebasket_id, name or filter_dict,
               returns a list of substancebasket data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substancebasket_id is not None:
            try:
                res =  await self.substancebasket_client.Retrieve(
                    lara_django_substances_store_pb2.SubstanceBasketRetrieveRequest(substancebasket_id=substancebasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstanceBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substancebasket_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substancebasket_client.List(
                    lara_django_substances_store_pb2.SubstanceBasketListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstanceBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substancebasket name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substancebasket_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substancebasket_id
        else:
            raise ValueError(f"Error retrieving substancebasket_id - no or too many results found.")
    
    async def get_by_id(self, substancebasket_id: str = None, id_only: bool = False) -> substances_store_dm.SubstanceBasket:
        """ retrieve a substancebasket data model by substancebasket_id """
        try:
            res = await self.substancebasket_client.Retrieve(
                lara_django_substances_store_pb2.SubstanceBasketRetrieveRequest(substancebasket_id=substancebasket_id)
            )
            item = substances_store_dm.SubstanceBasket(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substancebasket_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substancebasket_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstanceBasket | str:
        """ retrieve a substancebasket data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substancebasket_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstanceBasketRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substancebasket_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstanceBasket(**item)
        except Exception as e:
            logger.error(f"Error retrieving substancebasket name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substancebaskets """
        if filter_dict is None:
            res = await self.substancebasket_client.List(lara_django_substances_store_pb2.SubstanceBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancebasket_client.List(
                lara_django_substances_store_pb2.SubstanceBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancebasket_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substancebaskets """
        if self.substancebasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancebasket_full_client.List(
                lara_django_substances_store_pb2.SubstanceBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancebasket_full_client.List(
                lara_django_substances_store_pb2.SubstanceBasketFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substancebasket : substances_store_dm.SubstanceBasket = None) -> None:
        """ update a substancebasket model instance """
        try:
            await self.substancebasket_client.Update(
                lara_django_substances_store_pb2.SubstanceBasketRequest(**substancebasket.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substancebasket_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substancebasket by substancebasket_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substancebasket_client.Destroy(lara_django_substances_store_pb2.SubstanceBasketDestroyRequest(substancebasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substancebasket_id: {e}")

#_________________  SubstancesOrder  ______________________


class SubstancesOrderInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substancesorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstancesOrderclassByIRIControllerStub(channel)
        # )

        self.substancesorder_client = lara_django_substances_store_pb2_grpc.SubstancesOrderControllerStub(channel)
        

        # self.substancesorder_full_client = lara_django_substances_store_pb2_grpc.SubstancesOrderFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substancesorders:  list[substances_store_dm.SubstancesOrder] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstancesOrder]]:
        """ create a list of substancesorder instances,
               returns a list of substancesorder data model objects or ids_only

        :param substancesorders: list of substancesorder data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substancesorder data model objects or ids_only
        """
        substancesorderclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substancesorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substancesorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstancesOrderclassRetrieveRequest(iri=substancesorder_class_iri)
        #     )
        #     substancesorderclass_id = res.substancesorderclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substancesorderclass_id: {e}")
        for substancesorder in substancesorders:
            if substancesorder.namespace == "" or substancesorder.namespace == "default":
                    substancesorder.namespace = namespace_id
            # substancesorder.substancesorder_class = substancesorderclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substancesorder_client.Create(lara_django_substances_store_pb2.SubstancesOrderRequest(**substancesorder.model_dump())) for substancesorder in substancesorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substancesorder_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substancesorder: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substancesorder_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstancesOrder]:
        """ retrieve a list of substancesorder instances by substancesorder_id, name or filter_dict,
               returns a list of substancesorder data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substancesorder_id is not None:
            try:
                res =  await self.substancesorder_client.Retrieve(
                    lara_django_substances_store_pb2.SubstancesOrderRetrieveRequest(substancesorder_id=substancesorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstancesOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substancesorder_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substancesorder_client.List(
                    lara_django_substances_store_pb2.SubstancesOrderListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstancesOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substancesorder name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substancesorder_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substancesorder_id
        else:
            raise ValueError(f"Error retrieving substancesorder_id - no or too many results found.")
    
    async def get_by_id(self, substancesorder_id: str = None, id_only: bool = False) -> substances_store_dm.SubstancesOrder:
        """ retrieve a substancesorder data model by substancesorder_id """
        try:
            res = await self.substancesorder_client.Retrieve(
                lara_django_substances_store_pb2.SubstancesOrderRetrieveRequest(substancesorder_id=substancesorder_id)
            )
            item = substances_store_dm.SubstancesOrder(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substancesorder_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substancesorder_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstancesOrder | str:
        """ retrieve a substancesorder data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substancesorder_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstancesOrderRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substancesorder_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstancesOrder(**item)
        except Exception as e:
            logger.error(f"Error retrieving substancesorder name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substancesorders """
        if filter_dict is None:
            res = await self.substancesorder_client.List(lara_django_substances_store_pb2.SubstancesOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substancesorder_client.List(
                lara_django_substances_store_pb2.SubstancesOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substancesorder_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substancesorders """
        if self.substancesorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substancesorder_full_client.List(
                lara_django_substances_store_pb2.SubstancesOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substancesorder_full_client.List(
                lara_django_substances_store_pb2.SubstancesOrderFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substancesorder : substances_store_dm.SubstancesOrder = None) -> None:
        """ update a substancesorder model instance """
        try:
            await self.substancesorder_client.Update(
                lara_django_substances_store_pb2.SubstancesOrderRequest(**substancesorder.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substancesorder_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substancesorder by substancesorder_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substancesorder_client.Destroy(lara_django_substances_store_pb2.SubstancesOrderDestroyRequest(substancesorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substancesorder_id: {e}")

#_________________  SubstancesLocalStore  ______________________


class SubstancesLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.substanceslocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.SubstancesLocalStoreclassByIRIControllerStub(channel)
        # )

        self.substanceslocalstore_client = lara_django_substances_store_pb2_grpc.SubstancesLocalStoreControllerStub(channel)
        

        # self.substanceslocalstore_full_client = lara_django_substances_store_pb2_grpc.SubstancesLocalStoreFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  substanceslocalstores:  list[substances_store_dm.SubstancesLocalStore] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.SubstancesLocalStore]]:
        """ create a list of substanceslocalstore instances,
               returns a list of substanceslocalstore data model objects or ids_only

        :param substanceslocalstores: list of substanceslocalstore data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of substanceslocalstore data model objects or ids_only
        """
        substanceslocalstoreclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if substanceslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.substanceslocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.SubstancesLocalStoreclassRetrieveRequest(iri=substanceslocalstore_class_iri)
        #     )
        #     substanceslocalstoreclass_id = res.substanceslocalstoreclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving substanceslocalstoreclass_id: {e}")
        for substanceslocalstore in substanceslocalstores:
            if substanceslocalstore.namespace == "" or substanceslocalstore.namespace == "default":
                    substanceslocalstore.namespace = namespace_id
            # substanceslocalstore.substanceslocalstore_class = substanceslocalstoreclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.substanceslocalstore_client.Create(lara_django_substances_store_pb2.SubstancesLocalStoreRequest(**substanceslocalstore.model_dump())) for substanceslocalstore in substanceslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("substanceslocalstore_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating substanceslocalstore: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        substanceslocalstore_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.SubstancesLocalStore]:
        """ retrieve a list of substanceslocalstore instances by substanceslocalstore_id, name or filter_dict,
               returns a list of substanceslocalstore data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  substanceslocalstore_id is not None:
            try:
                res =  await self.substanceslocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.SubstancesLocalStoreRetrieveRequest(substanceslocalstore_id=substanceslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.SubstancesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving substanceslocalstore_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.substanceslocalstore_client.List(
                    lara_django_substances_store_pb2.SubstancesLocalStoreListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.SubstancesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving substanceslocalstore name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the substanceslocalstore_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].substanceslocalstore_id
        else:
            raise ValueError(f"Error retrieving substanceslocalstore_id - no or too many results found.")
    
    async def get_by_id(self, substanceslocalstore_id: str = None, id_only: bool = False) -> substances_store_dm.SubstancesLocalStore:
        """ retrieve a substanceslocalstore data model by substanceslocalstore_id """
        try:
            res = await self.substanceslocalstore_client.Retrieve(
                lara_django_substances_store_pb2.SubstancesLocalStoreRetrieveRequest(substanceslocalstore_id=substanceslocalstore_id)
            )
            item = substances_store_dm.SubstancesLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.substanceslocalstore_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving substanceslocalstore_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.SubstancesLocalStore | str:
        """ retrieve a substanceslocalstore data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.substanceslocalstore_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.SubstancesLocalStoreRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["substanceslocalstore_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.SubstancesLocalStore(**item)
        except Exception as e:
            logger.error(f"Error retrieving substanceslocalstore name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all substanceslocalstores """
        if filter_dict is None:
            res = await self.substanceslocalstore_client.List(lara_django_substances_store_pb2.SubstancesLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.substanceslocalstore_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.substanceslocalstore_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all substanceslocalstores """
        if self.substanceslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.substanceslocalstore_full_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.substanceslocalstore_full_client.List(
                lara_django_substances_store_pb2.SubstancesLocalStoreFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, substanceslocalstore : substances_store_dm.SubstancesLocalStore = None) -> None:
        """ update a substanceslocalstore model instance """
        try:
            await self.substanceslocalstore_client.Update(
                lara_django_substances_store_pb2.SubstancesLocalStoreRequest(**substanceslocalstore.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating substanceslocalstore_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a substanceslocalstore by substanceslocalstore_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.substanceslocalstore_client.Destroy(lara_django_substances_store_pb2.SubstancesLocalStoreDestroyRequest(substanceslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting substanceslocalstore_id: {e}")

#_________________  PolymerInstance  ______________________


class PolymerInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymerinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerInstanceclassByIRIControllerStub(channel)
        # )

        self.polymerinstance_client = lara_django_substances_store_pb2_grpc.PolymerInstanceControllerStub(channel)
        

        # self.polymerinstance_full_client = lara_django_substances_store_pb2_grpc.PolymerInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerinstances:  list[substances_store_dm.PolymerInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerInstance]]:
        """ create a list of polymerinstance instances,
               returns a list of polymerinstance data model objects or ids_only

        :param polymerinstances: list of polymerinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerinstance data model objects or ids_only
        """
        polymerinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerInstanceclassRetrieveRequest(iri=polymerinstance_class_iri)
        #     )
        #     polymerinstanceclass_id = res.polymerinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerinstanceclass_id: {e}")
        for polymerinstance in polymerinstances:
            if polymerinstance.namespace == "" or polymerinstance.namespace == "default":
                    polymerinstance.namespace = namespace_id
            # polymerinstance.polymerinstance_class = polymerinstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerinstance_client.Create(lara_django_substances_store_pb2.PolymerInstanceRequest(**polymerinstance.model_dump())) for polymerinstance in polymerinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymerinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymerInstance]:
        """ retrieve a list of polymerinstance instances by polymerinstance_id, name or filter_dict,
               returns a list of polymerinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymerinstance_id is not None:
            try:
                res =  await self.polymerinstance_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerInstanceRetrieveRequest(polymerinstance_id=polymerinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerinstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerinstance_client.List(
                    lara_django_substances_store_pb2.PolymerInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymerInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymerinstance_id
        else:
            raise ValueError(f"Error retrieving polymerinstance_id - no or too many results found.")
    
    async def get_by_id(self, polymerinstance_id: str = None, id_only: bool = False) -> substances_store_dm.PolymerInstance:
        """ retrieve a polymerinstance data model by polymerinstance_id """
        try:
            res = await self.polymerinstance_client.Retrieve(
                lara_django_substances_store_pb2.PolymerInstanceRetrieveRequest(polymerinstance_id=polymerinstance_id)
            )
            item = substances_store_dm.PolymerInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymerinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymerinstance_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymerInstance | str:
        """ retrieve a polymerinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerinstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymerInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymerinstance_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymerInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymerinstance name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerinstances """
        if filter_dict is None:
            res = await self.polymerinstance_client.List(lara_django_substances_store_pb2.PolymerInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerinstance_client.List(
                lara_django_substances_store_pb2.PolymerInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerinstances """
        if self.polymerinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerinstance_full_client.List(
                lara_django_substances_store_pb2.PolymerInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerinstance_full_client.List(
                lara_django_substances_store_pb2.PolymerInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerinstance : substances_store_dm.PolymerInstance = None) -> None:
        """ update a polymerinstance model instance """
        try:
            await self.polymerinstance_client.Update(
                lara_django_substances_store_pb2.PolymerInstanceRequest(**polymerinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerinstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerinstance by polymerinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerinstance_client.Destroy(lara_django_substances_store_pb2.PolymerInstanceDestroyRequest(polymerinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerinstance_id: {e}")

#_________________  PolymerInstancesSubset  ______________________


class PolymerInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymerinstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.polymerinstancessubset_client = lara_django_substances_store_pb2_grpc.PolymerInstancesSubsetControllerStub(channel)
        

        # self.polymerinstancessubset_full_client = lara_django_substances_store_pb2_grpc.PolymerInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerinstancessubsets:  list[substances_store_dm.PolymerInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerInstancesSubset]]:
        """ create a list of polymerinstancessubset instances,
               returns a list of polymerinstancessubset data model objects or ids_only

        :param polymerinstancessubsets: list of polymerinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerinstancessubset data model objects or ids_only
        """
        polymerinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerinstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerInstancesSubsetclassRetrieveRequest(iri=polymerinstancessubset_class_iri)
        #     )
        #     polymerinstancessubsetclass_id = res.polymerinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerinstancessubsetclass_id: {e}")
        for polymerinstancessubset in polymerinstancessubsets:
            if polymerinstancessubset.namespace == "" or polymerinstancessubset.namespace == "default":
                    polymerinstancessubset.namespace = namespace_id
            # polymerinstancessubset.polymerinstancessubset_class = polymerinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerinstancessubset_client.Create(lara_django_substances_store_pb2.PolymerInstancesSubsetRequest(**polymerinstancessubset.model_dump())) for polymerinstancessubset in polymerinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymerinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymerInstancesSubset]:
        """ retrieve a list of polymerinstancessubset instances by polymerinstancessubset_id, name or filter_dict,
               returns a list of polymerinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymerinstancessubset_id is not None:
            try:
                res =  await self.polymerinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerInstancesSubsetRetrieveRequest(polymerinstancessubset_id=polymerinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerinstancessubset_client.List(
                    lara_django_substances_store_pb2.PolymerInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymerinstancessubset_id
        else:
            raise ValueError(f"Error retrieving polymerinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, polymerinstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.PolymerInstancesSubset:
        """ retrieve a polymerinstancessubset data model by polymerinstancessubset_id """
        try:
            res = await self.polymerinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.PolymerInstancesSubsetRetrieveRequest(polymerinstancessubset_id=polymerinstancessubset_id)
            )
            item = substances_store_dm.PolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymerinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymerinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymerInstancesSubset | str:
        """ retrieve a polymerinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymerInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymerinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymerInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymerinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerinstancessubsets """
        if filter_dict is None:
            res = await self.polymerinstancessubset_client.List(lara_django_substances_store_pb2.PolymerInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerinstancessubset_client.List(
                lara_django_substances_store_pb2.PolymerInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerinstancessubsets """
        if self.polymerinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerinstancessubset_full_client.List(
                lara_django_substances_store_pb2.PolymerInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerinstancessubset_full_client.List(
                lara_django_substances_store_pb2.PolymerInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerinstancessubset : substances_store_dm.PolymerInstancesSubset = None) -> None:
        """ update a polymerinstancessubset model instance """
        try:
            await self.polymerinstancessubset_client.Update(
                lara_django_substances_store_pb2.PolymerInstancesSubsetRequest(**polymerinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerinstancessubset by polymerinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerinstancessubset_client.Destroy(lara_django_substances_store_pb2.PolymerInstancesSubsetDestroyRequest(polymerinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerinstancessubset_id: {e}")

#_________________  OrderedPolymerInstancesPolymerInstancesSubset  ______________________


class OrderedPolymerInstancesPolymerInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedpolymerinstancespolymerinstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedPolymerInstancesPolymerInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedpolymerinstancespolymerinstancessubsets:  list[substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedpolymerinstancespolymerinstancessubset_client.Create(lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetRequest(**orderedpolymerinstancespolymerinstancessubset.model_dump())) for orderedpolymerinstancespolymerinstancessubset in orderedpolymerinstancespolymerinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedpolymerinstancespolymerinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedpolymerinstancespolymerinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedpolymerinstancespolymerinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset]:
        """ retrieve a list of orderedpolymerinstancespolymerinstancessubset instances by orderedpolymerinstancespolymerinstancessubset_id, name or filter_dict,
               returns a list of orderedpolymerinstancespolymerinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedpolymerinstancespolymerinstancessubset_id is not None:
            try:
                res =  await self.orderedpolymerinstancespolymerinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetRetrieveRequest(orderedpolymerinstancespolymerinstancessubset_id=orderedpolymerinstancespolymerinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedpolymerinstancespolymerinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedpolymerinstancespolymerinstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerinstancespolymerinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedpolymerinstancespolymerinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedpolymerinstancespolymerinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedpolymerinstancespolymerinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedpolymerinstancespolymerinstancessubset_id: str = None) -> substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset:
        """ retrieve a orderedpolymerinstancespolymerinstancessubset data model by orderedpolymerinstancespolymerinstancessubset_id """
        try:
            res = await self.orderedpolymerinstancespolymerinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetRetrieveRequest(orderedpolymerinstancespolymerinstancessubset_id=orderedpolymerinstancespolymerinstancessubset_id)
            )
            return substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerinstancespolymerinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset | str:
        """ retrieve a orderedpolymerinstancespolymerinstancessubset data model by name """
        try:
            res = await self.orderedpolymerinstancespolymerinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedpolymerinstancespolymerinstancessubset_id"]
            else:
                return substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedpolymerinstancespolymerinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedpolymerinstancespolymerinstancessubsets """
        if filter_dict is None:
            res = await self.orderedpolymerinstancespolymerinstancessubset_client.List(lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedpolymerinstancespolymerinstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedpolymerinstancespolymerinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedpolymerinstancespolymerinstancessubsets """
        if self.orderedpolymerinstancespolymerinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedpolymerinstancespolymerinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedpolymerinstancespolymerinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedpolymerinstancespolymerinstancessubset : substances_store_dm.OrderedPolymerInstancesPolymerInstancesSubset = None) -> None:
        """ update a orderedpolymerinstancespolymerinstancessubset model instance """
        try:
            await self.orderedpolymerinstancespolymerinstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetRequest(**orderedpolymerinstancespolymerinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedpolymerinstancespolymerinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedpolymerinstancespolymerinstancessubset by orderedpolymerinstancespolymerinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedpolymerinstancespolymerinstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedPolymerInstancesPolymerInstancesSubsetDestroyRequest(orderedpolymerinstancespolymerinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedpolymerinstancespolymerinstancessubset_id: {e}")

#_________________  PolymerOrderItem  ______________________


class PolymerOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.polymerorderitem_client = lara_django_substances_store_pb2_grpc.PolymerOrderItemControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerorderitems:  list[substances_store_dm.PolymerOrderItem] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.PolymerOrderItem]]:
        try:
            create_coroutines = ( self.polymerorderitem_client.Create(lara_django_substances_store_pb2.PolymerOrderItemRequest(**polymerorderitem.model_dump())) for polymerorderitem in polymerorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.polymerorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerorderitem: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        polymerorderitem_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymerOrderItem]:
        """ retrieve a list of polymerorderitem instances by polymerorderitem_id, name or filter_dict,
               returns a list of polymerorderitem data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  polymerorderitem_id is not None:
            try:
                res =  await self.polymerorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerOrderItemRetrieveRequest(polymerorderitem_id=polymerorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerorderitem_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerorderitem_client.List(
                    lara_django_substances_store_pb2.PolymerOrderItemListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerorderitem name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerorderitem_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].polymerorderitem_id
        else:
            raise ValueError(f"Error retrieving polymerorderitem_id - no or too many results found.")
    
    async def get_by_id(self, polymerorderitem_id: str = None) -> substances_store_dm.PolymerOrderItem:
        """ retrieve a polymerorderitem data model by polymerorderitem_id """
        try:
            res = await self.polymerorderitem_client.Retrieve(
                lara_django_substances_store_pb2.PolymerOrderItemRetrieveRequest(polymerorderitem_id=polymerorderitem_id)
            )
            return substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymerorderitem_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.PolymerOrderItem | str:
        """ retrieve a polymerorderitem data model by name """
        try:
            res = await self.polymerorderitem_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymerOrderItemRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["polymerorderitem_id"]
            else:
                return substances_store_dm.PolymerOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving polymerorderitem name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerorderitems """
        if filter_dict is None:
            res = await self.polymerorderitem_client.List(lara_django_substances_store_pb2.PolymerOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerorderitem_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerorderitem_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerorderitems """
        if self.polymerorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerorderitem_full_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerorderitem_full_client.List(
                lara_django_substances_store_pb2.PolymerOrderItemFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerorderitem : substances_store_dm.PolymerOrderItem = None) -> None:
        """ update a polymerorderitem model instance """
        try:
            await self.polymerorderitem_client.Update(
                lara_django_substances_store_pb2.PolymerOrderItemRequest(**polymerorderitem.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerorderitem_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerorderitem by polymerorderitem_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerorderitem_client.Destroy(lara_django_substances_store_pb2.PolymerOrderItemDestroyRequest(polymerorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerorderitem_id: {e}")

#_________________  PolymerWishlist  ______________________


class PolymerWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymerwishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerWishlistclassByIRIControllerStub(channel)
        # )

        self.polymerwishlist_client = lara_django_substances_store_pb2_grpc.PolymerWishlistControllerStub(channel)
        

        # self.polymerwishlist_full_client = lara_django_substances_store_pb2_grpc.PolymerWishlistFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerwishlists:  list[substances_store_dm.PolymerWishlist] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerWishlist]]:
        """ create a list of polymerwishlist instances,
               returns a list of polymerwishlist data model objects or ids_only

        :param polymerwishlists: list of polymerwishlist data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerwishlist data model objects or ids_only
        """
        polymerwishlistclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerwishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerwishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerWishlistclassRetrieveRequest(iri=polymerwishlist_class_iri)
        #     )
        #     polymerwishlistclass_id = res.polymerwishlistclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerwishlistclass_id: {e}")
        for polymerwishlist in polymerwishlists:
            if polymerwishlist.namespace == "" or polymerwishlist.namespace == "default":
                    polymerwishlist.namespace = namespace_id
            # polymerwishlist.polymerwishlist_class = polymerwishlistclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerwishlist_client.Create(lara_django_substances_store_pb2.PolymerWishlistRequest(**polymerwishlist.model_dump())) for polymerwishlist in polymerwishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymerwishlist_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerwishlist: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerwishlist_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymerWishlist]:
        """ retrieve a list of polymerwishlist instances by polymerwishlist_id, name or filter_dict,
               returns a list of polymerwishlist data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymerwishlist_id is not None:
            try:
                res =  await self.polymerwishlist_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerWishlistRetrieveRequest(polymerwishlist_id=polymerwishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerwishlist_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerwishlist_client.List(
                    lara_django_substances_store_pb2.PolymerWishlistListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymerWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerwishlist name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerwishlist_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymerwishlist_id
        else:
            raise ValueError(f"Error retrieving polymerwishlist_id - no or too many results found.")
    
    async def get_by_id(self, polymerwishlist_id: str = None, id_only: bool = False) -> substances_store_dm.PolymerWishlist:
        """ retrieve a polymerwishlist data model by polymerwishlist_id """
        try:
            res = await self.polymerwishlist_client.Retrieve(
                lara_django_substances_store_pb2.PolymerWishlistRetrieveRequest(polymerwishlist_id=polymerwishlist_id)
            )
            item = substances_store_dm.PolymerWishlist(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymerwishlist_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymerwishlist_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymerWishlist | str:
        """ retrieve a polymerwishlist data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerwishlist_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymerWishlistRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymerwishlist_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymerWishlist(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymerwishlist name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerwishlists """
        if filter_dict is None:
            res = await self.polymerwishlist_client.List(lara_django_substances_store_pb2.PolymerWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerwishlist_client.List(
                lara_django_substances_store_pb2.PolymerWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerwishlist_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerwishlists """
        if self.polymerwishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerwishlist_full_client.List(
                lara_django_substances_store_pb2.PolymerWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerwishlist_full_client.List(
                lara_django_substances_store_pb2.PolymerWishlistFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerwishlist : substances_store_dm.PolymerWishlist = None) -> None:
        """ update a polymerwishlist model instance """
        try:
            await self.polymerwishlist_client.Update(
                lara_django_substances_store_pb2.PolymerWishlistRequest(**polymerwishlist.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerwishlist_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerwishlist by polymerwishlist_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerwishlist_client.Destroy(lara_django_substances_store_pb2.PolymerWishlistDestroyRequest(polymerwishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerwishlist_id: {e}")

#_________________  PolymerBasket  ______________________


class PolymerBasketInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymerbasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymerBasketclassByIRIControllerStub(channel)
        # )

        self.polymerbasket_client = lara_django_substances_store_pb2_grpc.PolymerBasketControllerStub(channel)
        

        # self.polymerbasket_full_client = lara_django_substances_store_pb2_grpc.PolymerBasketFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerbaskets:  list[substances_store_dm.PolymerBasket] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymerBasket]]:
        """ create a list of polymerbasket instances,
               returns a list of polymerbasket data model objects or ids_only

        :param polymerbaskets: list of polymerbasket data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerbasket data model objects or ids_only
        """
        polymerbasketclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerbasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerbasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymerBasketclassRetrieveRequest(iri=polymerbasket_class_iri)
        #     )
        #     polymerbasketclass_id = res.polymerbasketclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerbasketclass_id: {e}")
        for polymerbasket in polymerbaskets:
            if polymerbasket.namespace == "" or polymerbasket.namespace == "default":
                    polymerbasket.namespace = namespace_id
            # polymerbasket.polymerbasket_class = polymerbasketclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerbasket_client.Create(lara_django_substances_store_pb2.PolymerBasketRequest(**polymerbasket.model_dump())) for polymerbasket in polymerbaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymerbasket_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerbasket: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerbasket_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymerBasket]:
        """ retrieve a list of polymerbasket instances by polymerbasket_id, name or filter_dict,
               returns a list of polymerbasket data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymerbasket_id is not None:
            try:
                res =  await self.polymerbasket_client.Retrieve(
                    lara_django_substances_store_pb2.PolymerBasketRetrieveRequest(polymerbasket_id=polymerbasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymerBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerbasket_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerbasket_client.List(
                    lara_django_substances_store_pb2.PolymerBasketListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymerBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerbasket name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerbasket_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymerbasket_id
        else:
            raise ValueError(f"Error retrieving polymerbasket_id - no or too many results found.")
    
    async def get_by_id(self, polymerbasket_id: str = None, id_only: bool = False) -> substances_store_dm.PolymerBasket:
        """ retrieve a polymerbasket data model by polymerbasket_id """
        try:
            res = await self.polymerbasket_client.Retrieve(
                lara_django_substances_store_pb2.PolymerBasketRetrieveRequest(polymerbasket_id=polymerbasket_id)
            )
            item = substances_store_dm.PolymerBasket(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymerbasket_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymerbasket_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymerBasket | str:
        """ retrieve a polymerbasket data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerbasket_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymerBasketRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymerbasket_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymerBasket(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymerbasket name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerbaskets """
        if filter_dict is None:
            res = await self.polymerbasket_client.List(lara_django_substances_store_pb2.PolymerBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerbasket_client.List(
                lara_django_substances_store_pb2.PolymerBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerbasket_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerbaskets """
        if self.polymerbasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerbasket_full_client.List(
                lara_django_substances_store_pb2.PolymerBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerbasket_full_client.List(
                lara_django_substances_store_pb2.PolymerBasketFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerbasket : substances_store_dm.PolymerBasket = None) -> None:
        """ update a polymerbasket model instance """
        try:
            await self.polymerbasket_client.Update(
                lara_django_substances_store_pb2.PolymerBasketRequest(**polymerbasket.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerbasket_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerbasket by polymerbasket_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerbasket_client.Destroy(lara_django_substances_store_pb2.PolymerBasketDestroyRequest(polymerbasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerbasket_id: {e}")

#_________________  PolymersOrder  ______________________


class PolymersOrderInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymersorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymersOrderclassByIRIControllerStub(channel)
        # )

        self.polymersorder_client = lara_django_substances_store_pb2_grpc.PolymersOrderControllerStub(channel)
        

        # self.polymersorder_full_client = lara_django_substances_store_pb2_grpc.PolymersOrderFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymersorders:  list[substances_store_dm.PolymersOrder] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymersOrder]]:
        """ create a list of polymersorder instances,
               returns a list of polymersorder data model objects or ids_only

        :param polymersorders: list of polymersorder data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymersorder data model objects or ids_only
        """
        polymersorderclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymersorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymersorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymersOrderclassRetrieveRequest(iri=polymersorder_class_iri)
        #     )
        #     polymersorderclass_id = res.polymersorderclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymersorderclass_id: {e}")
        for polymersorder in polymersorders:
            if polymersorder.namespace == "" or polymersorder.namespace == "default":
                    polymersorder.namespace = namespace_id
            # polymersorder.polymersorder_class = polymersorderclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymersorder_client.Create(lara_django_substances_store_pb2.PolymersOrderRequest(**polymersorder.model_dump())) for polymersorder in polymersorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymersorder_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymersorder: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymersorder_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymersOrder]:
        """ retrieve a list of polymersorder instances by polymersorder_id, name or filter_dict,
               returns a list of polymersorder data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymersorder_id is not None:
            try:
                res =  await self.polymersorder_client.Retrieve(
                    lara_django_substances_store_pb2.PolymersOrderRetrieveRequest(polymersorder_id=polymersorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymersOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymersorder_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymersorder_client.List(
                    lara_django_substances_store_pb2.PolymersOrderListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymersOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymersorder name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymersorder_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymersorder_id
        else:
            raise ValueError(f"Error retrieving polymersorder_id - no or too many results found.")
    
    async def get_by_id(self, polymersorder_id: str = None, id_only: bool = False) -> substances_store_dm.PolymersOrder:
        """ retrieve a polymersorder data model by polymersorder_id """
        try:
            res = await self.polymersorder_client.Retrieve(
                lara_django_substances_store_pb2.PolymersOrderRetrieveRequest(polymersorder_id=polymersorder_id)
            )
            item = substances_store_dm.PolymersOrder(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymersorder_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymersorder_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymersOrder | str:
        """ retrieve a polymersorder data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymersorder_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymersOrderRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymersorder_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymersOrder(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymersorder name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymersorders """
        if filter_dict is None:
            res = await self.polymersorder_client.List(lara_django_substances_store_pb2.PolymersOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymersorder_client.List(
                lara_django_substances_store_pb2.PolymersOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymersorder_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymersorders """
        if self.polymersorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymersorder_full_client.List(
                lara_django_substances_store_pb2.PolymersOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymersorder_full_client.List(
                lara_django_substances_store_pb2.PolymersOrderFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymersorder : substances_store_dm.PolymersOrder = None) -> None:
        """ update a polymersorder model instance """
        try:
            await self.polymersorder_client.Update(
                lara_django_substances_store_pb2.PolymersOrderRequest(**polymersorder.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymersorder_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymersorder by polymersorder_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymersorder_client.Destroy(lara_django_substances_store_pb2.PolymersOrderDestroyRequest(polymersorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymersorder_id: {e}")

#_________________  PolymersLocalStore  ______________________


class PolymersLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.polymerslocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.PolymersLocalStoreclassByIRIControllerStub(channel)
        # )

        self.polymerslocalstore_client = lara_django_substances_store_pb2_grpc.PolymersLocalStoreControllerStub(channel)
        

        # self.polymerslocalstore_full_client = lara_django_substances_store_pb2_grpc.PolymersLocalStoreFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  polymerslocalstores:  list[substances_store_dm.PolymersLocalStore] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.PolymersLocalStore]]:
        """ create a list of polymerslocalstore instances,
               returns a list of polymerslocalstore data model objects or ids_only

        :param polymerslocalstores: list of polymerslocalstore data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of polymerslocalstore data model objects or ids_only
        """
        polymerslocalstoreclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if polymerslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.polymerslocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.PolymersLocalStoreclassRetrieveRequest(iri=polymerslocalstore_class_iri)
        #     )
        #     polymerslocalstoreclass_id = res.polymerslocalstoreclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving polymerslocalstoreclass_id: {e}")
        for polymerslocalstore in polymerslocalstores:
            if polymerslocalstore.namespace == "" or polymerslocalstore.namespace == "default":
                    polymerslocalstore.namespace = namespace_id
            # polymerslocalstore.polymerslocalstore_class = polymerslocalstoreclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.polymerslocalstore_client.Create(lara_django_substances_store_pb2.PolymersLocalStoreRequest(**polymerslocalstore.model_dump())) for polymerslocalstore in polymerslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("polymerslocalstore_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating polymerslocalstore: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        polymerslocalstore_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.PolymersLocalStore]:
        """ retrieve a list of polymerslocalstore instances by polymerslocalstore_id, name or filter_dict,
               returns a list of polymerslocalstore data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  polymerslocalstore_id is not None:
            try:
                res =  await self.polymerslocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.PolymersLocalStoreRetrieveRequest(polymerslocalstore_id=polymerslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.PolymersLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving polymerslocalstore_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.polymerslocalstore_client.List(
                    lara_django_substances_store_pb2.PolymersLocalStoreListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.PolymersLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving polymerslocalstore name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the polymerslocalstore_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].polymerslocalstore_id
        else:
            raise ValueError(f"Error retrieving polymerslocalstore_id - no or too many results found.")
    
    async def get_by_id(self, polymerslocalstore_id: str = None, id_only: bool = False) -> substances_store_dm.PolymersLocalStore:
        """ retrieve a polymerslocalstore data model by polymerslocalstore_id """
        try:
            res = await self.polymerslocalstore_client.Retrieve(
                lara_django_substances_store_pb2.PolymersLocalStoreRetrieveRequest(polymerslocalstore_id=polymerslocalstore_id)
            )
            item = substances_store_dm.PolymersLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.polymerslocalstore_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving polymerslocalstore_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.PolymersLocalStore | str:
        """ retrieve a polymerslocalstore data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.polymerslocalstore_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.PolymersLocalStoreRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["polymerslocalstore_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.PolymersLocalStore(**item)
        except Exception as e:
            logger.error(f"Error retrieving polymerslocalstore name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all polymerslocalstores """
        if filter_dict is None:
            res = await self.polymerslocalstore_client.List(lara_django_substances_store_pb2.PolymersLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.polymerslocalstore_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.polymerslocalstore_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all polymerslocalstores """
        if self.polymerslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.polymerslocalstore_full_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.polymerslocalstore_full_client.List(
                lara_django_substances_store_pb2.PolymersLocalStoreFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, polymerslocalstore : substances_store_dm.PolymersLocalStore = None) -> None:
        """ update a polymerslocalstore model instance """
        try:
            await self.polymerslocalstore_client.Update(
                lara_django_substances_store_pb2.PolymersLocalStoreRequest(**polymerslocalstore.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating polymerslocalstore_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a polymerslocalstore by polymerslocalstore_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.polymerslocalstore_client.Destroy(lara_django_substances_store_pb2.PolymersLocalStoreDestroyRequest(polymerslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting polymerslocalstore_id: {e}")

#_________________  MixtureComponentInstance  ______________________


class MixtureComponentInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixturecomponentinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureComponentInstanceclassByIRIControllerStub(channel)
        # )

        self.mixturecomponentinstance_client = lara_django_substances_store_pb2_grpc.MixtureComponentInstanceControllerStub(channel)
        

        # self.mixturecomponentinstance_full_client = lara_django_substances_store_pb2_grpc.MixtureComponentInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturecomponentinstances:  list[substances_store_dm.MixtureComponentInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureComponentInstance]]:
        """ create a list of mixturecomponentinstance instances,
               returns a list of mixturecomponentinstance data model objects or ids_only

        :param mixturecomponentinstances: list of mixturecomponentinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixturecomponentinstance data model objects or ids_only
        """
        mixturecomponentinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturecomponentinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturecomponentinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureComponentInstanceclassRetrieveRequest(iri=mixturecomponentinstance_class_iri)
        #     )
        #     mixturecomponentinstanceclass_id = res.mixturecomponentinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixturecomponentinstanceclass_id: {e}")
        for mixturecomponentinstance in mixturecomponentinstances:
            if mixturecomponentinstance.namespace == "" or mixturecomponentinstance.namespace == "default":
                    mixturecomponentinstance.namespace = namespace_id
            # mixturecomponentinstance.mixturecomponentinstance_class = mixturecomponentinstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixturecomponentinstance_client.Create(lara_django_substances_store_pb2.MixtureComponentInstanceRequest(**mixturecomponentinstance.model_dump())) for mixturecomponentinstance in mixturecomponentinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixturecomponentinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturecomponentinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixturecomponentinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureComponentInstance]:
        """ retrieve a list of mixturecomponentinstance instances by mixturecomponentinstance_id, name or filter_dict,
               returns a list of mixturecomponentinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixturecomponentinstance_id is not None:
            try:
                res =  await self.mixturecomponentinstance_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureComponentInstanceRetrieveRequest(mixturecomponentinstance_id=mixturecomponentinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureComponentInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturecomponentinstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturecomponentinstance_client.List(
                    lara_django_substances_store_pb2.MixtureComponentInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureComponentInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponentinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturecomponentinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixturecomponentinstance_id
        else:
            raise ValueError(f"Error retrieving mixturecomponentinstance_id - no or too many results found.")
    
    async def get_by_id(self, mixturecomponentinstance_id: str = None, id_only: bool = False) -> substances_store_dm.MixtureComponentInstance:
        """ retrieve a mixturecomponentinstance data model by mixturecomponentinstance_id """
        try:
            res = await self.mixturecomponentinstance_client.Retrieve(
                lara_django_substances_store_pb2.MixtureComponentInstanceRetrieveRequest(mixturecomponentinstance_id=mixturecomponentinstance_id)
            )
            item = substances_store_dm.MixtureComponentInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixturecomponentinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponentinstance_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixtureComponentInstance | str:
        """ retrieve a mixturecomponentinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixturecomponentinstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureComponentInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixturecomponentinstance_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixtureComponentInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixturecomponentinstance name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturecomponentinstances """
        if filter_dict is None:
            res = await self.mixturecomponentinstance_client.List(lara_django_substances_store_pb2.MixtureComponentInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturecomponentinstance_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturecomponentinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturecomponentinstances """
        if self.mixturecomponentinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturecomponentinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturecomponentinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureComponentInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturecomponentinstance : substances_store_dm.MixtureComponentInstance = None) -> None:
        """ update a mixturecomponentinstance model instance """
        try:
            await self.mixturecomponentinstance_client.Update(
                lara_django_substances_store_pb2.MixtureComponentInstanceRequest(**mixturecomponentinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturecomponentinstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturecomponentinstance by mixturecomponentinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturecomponentinstance_client.Destroy(lara_django_substances_store_pb2.MixtureComponentInstanceDestroyRequest(mixturecomponentinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturecomponentinstance_id: {e}")

#_________________  MixtureInstance  ______________________


class MixtureInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixtureinstance_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureInstanceclassByIRIControllerStub(channel)
        # )

        self.mixtureinstance_client = lara_django_substances_store_pb2_grpc.MixtureInstanceControllerStub(channel)
        

        # self.mixtureinstance_full_client = lara_django_substances_store_pb2_grpc.MixtureInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureinstances:  list[substances_store_dm.MixtureInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureInstance]]:
        """ create a list of mixtureinstance instances,
               returns a list of mixtureinstance data model objects or ids_only

        :param mixtureinstances: list of mixtureinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixtureinstance data model objects or ids_only
        """
        mixtureinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixtureinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixtureinstance_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureInstanceclassRetrieveRequest(iri=mixtureinstance_class_iri)
        #     )
        #     mixtureinstanceclass_id = res.mixtureinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixtureinstanceclass_id: {e}")
        for mixtureinstance in mixtureinstances:
            if mixtureinstance.namespace == "" or mixtureinstance.namespace == "default":
                    mixtureinstance.namespace = namespace_id
            # mixtureinstance.mixtureinstance_class = mixtureinstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixtureinstance_client.Create(lara_django_substances_store_pb2.MixtureInstanceRequest(**mixtureinstance.model_dump())) for mixtureinstance in mixtureinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixtureinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixtureinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixtureinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureInstance]:
        """ retrieve a list of mixtureinstance instances by mixtureinstance_id, name or filter_dict,
               returns a list of mixtureinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixtureinstance_id is not None:
            try:
                res =  await self.mixtureinstance_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureInstanceRetrieveRequest(mixtureinstance_id=mixtureinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixtureinstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixtureinstance_client.List(
                    lara_django_substances_store_pb2.MixtureInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixtureinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixtureinstance_id
        else:
            raise ValueError(f"Error retrieving mixtureinstance_id - no or too many results found.")
    
    async def get_by_id(self, mixtureinstance_id: str = None, id_only: bool = False) -> substances_store_dm.MixtureInstance:
        """ retrieve a mixtureinstance data model by mixtureinstance_id """
        try:
            res = await self.mixtureinstance_client.Retrieve(
                lara_django_substances_store_pb2.MixtureInstanceRetrieveRequest(mixtureinstance_id=mixtureinstance_id)
            )
            item = substances_store_dm.MixtureInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixtureinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstance_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixtureInstance | str:
        """ retrieve a mixtureinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixtureinstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixtureinstance_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixtureInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstance name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixtureinstances """
        if filter_dict is None:
            res = await self.mixtureinstance_client.List(lara_django_substances_store_pb2.MixtureInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureinstance_client.List(
                lara_django_substances_store_pb2.MixtureInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixtureinstances """
        if self.mixtureinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureinstance_full_client.List(
                lara_django_substances_store_pb2.MixtureInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixtureinstance : substances_store_dm.MixtureInstance = None) -> None:
        """ update a mixtureinstance model instance """
        try:
            await self.mixtureinstance_client.Update(
                lara_django_substances_store_pb2.MixtureInstanceRequest(**mixtureinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixtureinstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixtureinstance by mixtureinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixtureinstance_client.Destroy(lara_django_substances_store_pb2.MixtureInstanceDestroyRequest(mixtureinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixtureinstance_id: {e}")

#_________________  MixtureInstancesSubset  ______________________


class MixtureInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixtureinstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.mixtureinstancessubset_client = lara_django_substances_store_pb2_grpc.MixtureInstancesSubsetControllerStub(channel)
        

        # self.mixtureinstancessubset_full_client = lara_django_substances_store_pb2_grpc.MixtureInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureinstancessubsets:  list[substances_store_dm.MixtureInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureInstancesSubset]]:
        """ create a list of mixtureinstancessubset instances,
               returns a list of mixtureinstancessubset data model objects or ids_only

        :param mixtureinstancessubsets: list of mixtureinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixtureinstancessubset data model objects or ids_only
        """
        mixtureinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixtureinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixtureinstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureInstancesSubsetclassRetrieveRequest(iri=mixtureinstancessubset_class_iri)
        #     )
        #     mixtureinstancessubsetclass_id = res.mixtureinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixtureinstancessubsetclass_id: {e}")
        for mixtureinstancessubset in mixtureinstancessubsets:
            if mixtureinstancessubset.namespace == "" or mixtureinstancessubset.namespace == "default":
                    mixtureinstancessubset.namespace = namespace_id
            # mixtureinstancessubset.mixtureinstancessubset_class = mixtureinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixtureinstancessubset_client.Create(lara_django_substances_store_pb2.MixtureInstancesSubsetRequest(**mixtureinstancessubset.model_dump())) for mixtureinstancessubset in mixtureinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixtureinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixtureinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixtureinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureInstancesSubset]:
        """ retrieve a list of mixtureinstancessubset instances by mixtureinstancessubset_id, name or filter_dict,
               returns a list of mixtureinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixtureinstancessubset_id is not None:
            try:
                res =  await self.mixtureinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureInstancesSubsetRetrieveRequest(mixtureinstancessubset_id=mixtureinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixtureinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixtureinstancessubset_client.List(
                    lara_django_substances_store_pb2.MixtureInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixtureinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixtureinstancessubset_id
        else:
            raise ValueError(f"Error retrieving mixtureinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, mixtureinstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.MixtureInstancesSubset:
        """ retrieve a mixtureinstancessubset data model by mixtureinstancessubset_id """
        try:
            res = await self.mixtureinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.MixtureInstancesSubsetRetrieveRequest(mixtureinstancessubset_id=mixtureinstancessubset_id)
            )
            item = substances_store_dm.MixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixtureinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixtureInstancesSubset | str:
        """ retrieve a mixtureinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixtureinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixtureinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixtureInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixtureinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixtureinstancessubsets """
        if filter_dict is None:
            res = await self.mixtureinstancessubset_client.List(lara_django_substances_store_pb2.MixtureInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureinstancessubset_client.List(
                lara_django_substances_store_pb2.MixtureInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixtureinstancessubsets """
        if self.mixtureinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureinstancessubset_full_client.List(
                lara_django_substances_store_pb2.MixtureInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureinstancessubset_full_client.List(
                lara_django_substances_store_pb2.MixtureInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixtureinstancessubset : substances_store_dm.MixtureInstancesSubset = None) -> None:
        """ update a mixtureinstancessubset model instance """
        try:
            await self.mixtureinstancessubset_client.Update(
                lara_django_substances_store_pb2.MixtureInstancesSubsetRequest(**mixtureinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixtureinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixtureinstancessubset by mixtureinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixtureinstancessubset_client.Destroy(lara_django_substances_store_pb2.MixtureInstancesSubsetDestroyRequest(mixtureinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixtureinstancessubset_id: {e}")

#_________________  OrderedMixtureInstancesMixtureInstancesSubset  ______________________


class OrderedMixtureInstancesMixtureInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmixtureinstancesmixtureinstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedMixtureInstancesMixtureInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedmixtureinstancesmixtureinstancessubsets:  list[substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedmixtureinstancesmixtureinstancessubset_client.Create(lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetRequest(**orderedmixtureinstancesmixtureinstancessubset.model_dump())) for orderedmixtureinstancesmixtureinstancessubset in orderedmixtureinstancesmixtureinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmixtureinstancesmixtureinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmixtureinstancesmixtureinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmixtureinstancesmixtureinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset]:
        """ retrieve a list of orderedmixtureinstancesmixtureinstancessubset instances by orderedmixtureinstancesmixtureinstancessubset_id, name or filter_dict,
               returns a list of orderedmixtureinstancesmixtureinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedmixtureinstancesmixtureinstancessubset_id is not None:
            try:
                res =  await self.orderedmixtureinstancesmixtureinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetRetrieveRequest(orderedmixtureinstancesmixtureinstancessubset_id=orderedmixtureinstancesmixtureinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmixtureinstancesmixtureinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmixtureinstancesmixtureinstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedmixtureinstancesmixtureinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmixtureinstancesmixtureinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedmixtureinstancesmixtureinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedmixtureinstancesmixtureinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedmixtureinstancesmixtureinstancessubset_id: str = None) -> substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset:
        """ retrieve a orderedmixtureinstancesmixtureinstancessubset data model by orderedmixtureinstancesmixtureinstancessubset_id """
        try:
            res = await self.orderedmixtureinstancesmixtureinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetRetrieveRequest(orderedmixtureinstancesmixtureinstancessubset_id=orderedmixtureinstancesmixtureinstancessubset_id)
            )
            return substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmixtureinstancesmixtureinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset | str:
        """ retrieve a orderedmixtureinstancesmixtureinstancessubset data model by name """
        try:
            res = await self.orderedmixtureinstancesmixtureinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedmixtureinstancesmixtureinstancessubset_id"]
            else:
                return substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmixtureinstancesmixtureinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmixtureinstancesmixtureinstancessubsets """
        if filter_dict is None:
            res = await self.orderedmixtureinstancesmixtureinstancessubset_client.List(lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmixtureinstancesmixtureinstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmixtureinstancesmixtureinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmixtureinstancesmixtureinstancessubsets """
        if self.orderedmixtureinstancesmixtureinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmixtureinstancesmixtureinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmixtureinstancesmixtureinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedmixtureinstancesmixtureinstancessubset : substances_store_dm.OrderedMixtureInstancesMixtureInstancesSubset = None) -> None:
        """ update a orderedmixtureinstancesmixtureinstancessubset model instance """
        try:
            await self.orderedmixtureinstancesmixtureinstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetRequest(**orderedmixtureinstancesmixtureinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmixtureinstancesmixtureinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmixtureinstancesmixtureinstancessubset by orderedmixtureinstancesmixtureinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmixtureinstancesmixtureinstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedMixtureInstancesMixtureInstancesSubsetDestroyRequest(orderedmixtureinstancesmixtureinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmixtureinstancesmixtureinstancessubset_id: {e}")

#_________________  MixtureOrderItem  ______________________


class MixtureOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.mixtureorderitem_client = lara_django_substances_store_pb2_grpc.MixtureOrderItemControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureorderitems:  list[substances_store_dm.MixtureOrderItem] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.MixtureOrderItem]]:
        try:
            create_coroutines = ( self.mixtureorderitem_client.Create(lara_django_substances_store_pb2.MixtureOrderItemRequest(**mixtureorderitem.model_dump())) for mixtureorderitem in mixtureorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.mixtureorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixtureorderitem: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        mixtureorderitem_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureOrderItem]:
        """ retrieve a list of mixtureorderitem instances by mixtureorderitem_id, name or filter_dict,
               returns a list of mixtureorderitem data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  mixtureorderitem_id is not None:
            try:
                res =  await self.mixtureorderitem_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureOrderItemRetrieveRequest(mixtureorderitem_id=mixtureorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixtureorderitem_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixtureorderitem_client.List(
                    lara_django_substances_store_pb2.MixtureOrderItemListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixtureorderitem name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixtureorderitem_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].mixtureorderitem_id
        else:
            raise ValueError(f"Error retrieving mixtureorderitem_id - no or too many results found.")
    
    async def get_by_id(self, mixtureorderitem_id: str = None) -> substances_store_dm.MixtureOrderItem:
        """ retrieve a mixtureorderitem data model by mixtureorderitem_id """
        try:
            res = await self.mixtureorderitem_client.Retrieve(
                lara_django_substances_store_pb2.MixtureOrderItemRetrieveRequest(mixtureorderitem_id=mixtureorderitem_id)
            )
            return substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixtureorderitem_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.MixtureOrderItem | str:
        """ retrieve a mixtureorderitem data model by name """
        try:
            res = await self.mixtureorderitem_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureOrderItemRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["mixtureorderitem_id"]
            else:
                return substances_store_dm.MixtureOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving mixtureorderitem name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixtureorderitems """
        if filter_dict is None:
            res = await self.mixtureorderitem_client.List(lara_django_substances_store_pb2.MixtureOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureorderitem_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureorderitem_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixtureorderitems """
        if self.mixtureorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureorderitem_full_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureorderitem_full_client.List(
                lara_django_substances_store_pb2.MixtureOrderItemFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixtureorderitem : substances_store_dm.MixtureOrderItem = None) -> None:
        """ update a mixtureorderitem model instance """
        try:
            await self.mixtureorderitem_client.Update(
                lara_django_substances_store_pb2.MixtureOrderItemRequest(**mixtureorderitem.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixtureorderitem_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixtureorderitem by mixtureorderitem_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixtureorderitem_client.Destroy(lara_django_substances_store_pb2.MixtureOrderItemDestroyRequest(mixtureorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixtureorderitem_id: {e}")

#_________________  MixtureWishlist  ______________________


class MixtureWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixturewishlist_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureWishlistclassByIRIControllerStub(channel)
        # )

        self.mixturewishlist_client = lara_django_substances_store_pb2_grpc.MixtureWishlistControllerStub(channel)
        

        # self.mixturewishlist_full_client = lara_django_substances_store_pb2_grpc.MixtureWishlistFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturewishlists:  list[substances_store_dm.MixtureWishlist] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureWishlist]]:
        """ create a list of mixturewishlist instances,
               returns a list of mixturewishlist data model objects or ids_only

        :param mixturewishlists: list of mixturewishlist data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixturewishlist data model objects or ids_only
        """
        mixturewishlistclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturewishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturewishlist_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureWishlistclassRetrieveRequest(iri=mixturewishlist_class_iri)
        #     )
        #     mixturewishlistclass_id = res.mixturewishlistclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixturewishlistclass_id: {e}")
        for mixturewishlist in mixturewishlists:
            if mixturewishlist.namespace == "" or mixturewishlist.namespace == "default":
                    mixturewishlist.namespace = namespace_id
            # mixturewishlist.mixturewishlist_class = mixturewishlistclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixturewishlist_client.Create(lara_django_substances_store_pb2.MixtureWishlistRequest(**mixturewishlist.model_dump())) for mixturewishlist in mixturewishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixturewishlist_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturewishlist: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixturewishlist_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureWishlist]:
        """ retrieve a list of mixturewishlist instances by mixturewishlist_id, name or filter_dict,
               returns a list of mixturewishlist data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixturewishlist_id is not None:
            try:
                res =  await self.mixturewishlist_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureWishlistRetrieveRequest(mixturewishlist_id=mixturewishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturewishlist_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturewishlist_client.List(
                    lara_django_substances_store_pb2.MixtureWishlistListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixturewishlist name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturewishlist_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixturewishlist_id
        else:
            raise ValueError(f"Error retrieving mixturewishlist_id - no or too many results found.")
    
    async def get_by_id(self, mixturewishlist_id: str = None, id_only: bool = False) -> substances_store_dm.MixtureWishlist:
        """ retrieve a mixturewishlist data model by mixturewishlist_id """
        try:
            res = await self.mixturewishlist_client.Retrieve(
                lara_django_substances_store_pb2.MixtureWishlistRetrieveRequest(mixturewishlist_id=mixturewishlist_id)
            )
            item = substances_store_dm.MixtureWishlist(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixturewishlist_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixturewishlist_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixtureWishlist | str:
        """ retrieve a mixturewishlist data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixturewishlist_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureWishlistRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixturewishlist_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixtureWishlist(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixturewishlist name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturewishlists """
        if filter_dict is None:
            res = await self.mixturewishlist_client.List(lara_django_substances_store_pb2.MixtureWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturewishlist_client.List(
                lara_django_substances_store_pb2.MixtureWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturewishlist_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturewishlists """
        if self.mixturewishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturewishlist_full_client.List(
                lara_django_substances_store_pb2.MixtureWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturewishlist_full_client.List(
                lara_django_substances_store_pb2.MixtureWishlistFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturewishlist : substances_store_dm.MixtureWishlist = None) -> None:
        """ update a mixturewishlist model instance """
        try:
            await self.mixturewishlist_client.Update(
                lara_django_substances_store_pb2.MixtureWishlistRequest(**mixturewishlist.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturewishlist_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturewishlist by mixturewishlist_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturewishlist_client.Destroy(lara_django_substances_store_pb2.MixtureWishlistDestroyRequest(mixturewishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturewishlist_id: {e}")

#_________________  MixtureBasket  ______________________


class MixtureBasketInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixturebasket_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixtureBasketclassByIRIControllerStub(channel)
        # )

        self.mixturebasket_client = lara_django_substances_store_pb2_grpc.MixtureBasketControllerStub(channel)
        

        # self.mixturebasket_full_client = lara_django_substances_store_pb2_grpc.MixtureBasketFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturebaskets:  list[substances_store_dm.MixtureBasket] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixtureBasket]]:
        """ create a list of mixturebasket instances,
               returns a list of mixturebasket data model objects or ids_only

        :param mixturebaskets: list of mixturebasket data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixturebasket data model objects or ids_only
        """
        mixturebasketclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturebasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturebasket_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixtureBasketclassRetrieveRequest(iri=mixturebasket_class_iri)
        #     )
        #     mixturebasketclass_id = res.mixturebasketclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixturebasketclass_id: {e}")
        for mixturebasket in mixturebaskets:
            if mixturebasket.namespace == "" or mixturebasket.namespace == "default":
                    mixturebasket.namespace = namespace_id
            # mixturebasket.mixturebasket_class = mixturebasketclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixturebasket_client.Create(lara_django_substances_store_pb2.MixtureBasketRequest(**mixturebasket.model_dump())) for mixturebasket in mixturebaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixturebasket_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturebasket: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixturebasket_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixtureBasket]:
        """ retrieve a list of mixturebasket instances by mixturebasket_id, name or filter_dict,
               returns a list of mixturebasket data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixturebasket_id is not None:
            try:
                res =  await self.mixturebasket_client.Retrieve(
                    lara_django_substances_store_pb2.MixtureBasketRetrieveRequest(mixturebasket_id=mixturebasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixtureBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturebasket_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturebasket_client.List(
                    lara_django_substances_store_pb2.MixtureBasketListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixtureBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixturebasket name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturebasket_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixturebasket_id
        else:
            raise ValueError(f"Error retrieving mixturebasket_id - no or too many results found.")
    
    async def get_by_id(self, mixturebasket_id: str = None, id_only: bool = False) -> substances_store_dm.MixtureBasket:
        """ retrieve a mixturebasket data model by mixturebasket_id """
        try:
            res = await self.mixturebasket_client.Retrieve(
                lara_django_substances_store_pb2.MixtureBasketRetrieveRequest(mixturebasket_id=mixturebasket_id)
            )
            item = substances_store_dm.MixtureBasket(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixturebasket_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixturebasket_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixtureBasket | str:
        """ retrieve a mixturebasket data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixturebasket_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixtureBasketRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixturebasket_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixtureBasket(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixturebasket name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturebaskets """
        if filter_dict is None:
            res = await self.mixturebasket_client.List(lara_django_substances_store_pb2.MixtureBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturebasket_client.List(
                lara_django_substances_store_pb2.MixtureBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturebasket_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturebaskets """
        if self.mixturebasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturebasket_full_client.List(
                lara_django_substances_store_pb2.MixtureBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturebasket_full_client.List(
                lara_django_substances_store_pb2.MixtureBasketFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturebasket : substances_store_dm.MixtureBasket = None) -> None:
        """ update a mixturebasket model instance """
        try:
            await self.mixturebasket_client.Update(
                lara_django_substances_store_pb2.MixtureBasketRequest(**mixturebasket.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturebasket_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturebasket by mixturebasket_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturebasket_client.Destroy(lara_django_substances_store_pb2.MixtureBasketDestroyRequest(mixturebasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturebasket_id: {e}")

#_________________  MixturesOrder  ______________________


class MixturesOrderInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixturesorder_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixturesOrderclassByIRIControllerStub(channel)
        # )

        self.mixturesorder_client = lara_django_substances_store_pb2_grpc.MixturesOrderControllerStub(channel)
        

        # self.mixturesorder_full_client = lara_django_substances_store_pb2_grpc.MixturesOrderFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixturesorders:  list[substances_store_dm.MixturesOrder] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixturesOrder]]:
        """ create a list of mixturesorder instances,
               returns a list of mixturesorder data model objects or ids_only

        :param mixturesorders: list of mixturesorder data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixturesorder data model objects or ids_only
        """
        mixturesorderclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixturesorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixturesorder_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixturesOrderclassRetrieveRequest(iri=mixturesorder_class_iri)
        #     )
        #     mixturesorderclass_id = res.mixturesorderclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixturesorderclass_id: {e}")
        for mixturesorder in mixturesorders:
            if mixturesorder.namespace == "" or mixturesorder.namespace == "default":
                    mixturesorder.namespace = namespace_id
            # mixturesorder.mixturesorder_class = mixturesorderclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixturesorder_client.Create(lara_django_substances_store_pb2.MixturesOrderRequest(**mixturesorder.model_dump())) for mixturesorder in mixturesorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixturesorder_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixturesorder: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixturesorder_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixturesOrder]:
        """ retrieve a list of mixturesorder instances by mixturesorder_id, name or filter_dict,
               returns a list of mixturesorder data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixturesorder_id is not None:
            try:
                res =  await self.mixturesorder_client.Retrieve(
                    lara_django_substances_store_pb2.MixturesOrderRetrieveRequest(mixturesorder_id=mixturesorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixturesOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixturesorder_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixturesorder_client.List(
                    lara_django_substances_store_pb2.MixturesOrderListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixturesOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixturesorder name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixturesorder_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixturesorder_id
        else:
            raise ValueError(f"Error retrieving mixturesorder_id - no or too many results found.")
    
    async def get_by_id(self, mixturesorder_id: str = None, id_only: bool = False) -> substances_store_dm.MixturesOrder:
        """ retrieve a mixturesorder data model by mixturesorder_id """
        try:
            res = await self.mixturesorder_client.Retrieve(
                lara_django_substances_store_pb2.MixturesOrderRetrieveRequest(mixturesorder_id=mixturesorder_id)
            )
            item = substances_store_dm.MixturesOrder(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixturesorder_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixturesorder_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixturesOrder | str:
        """ retrieve a mixturesorder data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixturesorder_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixturesOrderRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixturesorder_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixturesOrder(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixturesorder name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixturesorders """
        if filter_dict is None:
            res = await self.mixturesorder_client.List(lara_django_substances_store_pb2.MixturesOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixturesorder_client.List(
                lara_django_substances_store_pb2.MixturesOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixturesorder_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixturesorders """
        if self.mixturesorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixturesorder_full_client.List(
                lara_django_substances_store_pb2.MixturesOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixturesorder_full_client.List(
                lara_django_substances_store_pb2.MixturesOrderFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixturesorder : substances_store_dm.MixturesOrder = None) -> None:
        """ update a mixturesorder model instance """
        try:
            await self.mixturesorder_client.Update(
                lara_django_substances_store_pb2.MixturesOrderRequest(**mixturesorder.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixturesorder_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixturesorder by mixturesorder_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixturesorder_client.Destroy(lara_django_substances_store_pb2.MixturesOrderDestroyRequest(mixturesorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixturesorder_id: {e}")

#_________________  MixturesLocalStore  ______________________


class MixturesLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.mixtureslocalstore_class_client = (
        #     lara_django_substances_store_pb2_grpc.MixturesLocalStoreclassByIRIControllerStub(channel)
        # )

        self.mixtureslocalstore_client = lara_django_substances_store_pb2_grpc.MixturesLocalStoreControllerStub(channel)
        

        # self.mixtureslocalstore_full_client = lara_django_substances_store_pb2_grpc.MixturesLocalStoreFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  mixtureslocalstores:  list[substances_store_dm.MixturesLocalStore] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MixturesLocalStore]]:
        """ create a list of mixtureslocalstore instances,
               returns a list of mixtureslocalstore data model objects or ids_only

        :param mixtureslocalstores: list of mixtureslocalstore data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of mixtureslocalstore data model objects or ids_only
        """
        mixtureslocalstoreclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if mixtureslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.mixtureslocalstore_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MixturesLocalStoreclassRetrieveRequest(iri=mixtureslocalstore_class_iri)
        #     )
        #     mixtureslocalstoreclass_id = res.mixtureslocalstoreclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving mixtureslocalstoreclass_id: {e}")
        for mixtureslocalstore in mixtureslocalstores:
            if mixtureslocalstore.namespace == "" or mixtureslocalstore.namespace == "default":
                    mixtureslocalstore.namespace = namespace_id
            # mixtureslocalstore.mixtureslocalstore_class = mixtureslocalstoreclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.mixtureslocalstore_client.Create(lara_django_substances_store_pb2.MixturesLocalStoreRequest(**mixtureslocalstore.model_dump())) for mixtureslocalstore in mixtureslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("mixtureslocalstore_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating mixtureslocalstore: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        mixtureslocalstore_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MixturesLocalStore]:
        """ retrieve a list of mixtureslocalstore instances by mixtureslocalstore_id, name or filter_dict,
               returns a list of mixtureslocalstore data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  mixtureslocalstore_id is not None:
            try:
                res =  await self.mixtureslocalstore_client.Retrieve(
                    lara_django_substances_store_pb2.MixturesLocalStoreRetrieveRequest(mixtureslocalstore_id=mixtureslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MixturesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving mixtureslocalstore_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.mixtureslocalstore_client.List(
                    lara_django_substances_store_pb2.MixturesLocalStoreListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MixturesLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving mixtureslocalstore name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the mixtureslocalstore_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].mixtureslocalstore_id
        else:
            raise ValueError(f"Error retrieving mixtureslocalstore_id - no or too many results found.")
    
    async def get_by_id(self, mixtureslocalstore_id: str = None, id_only: bool = False) -> substances_store_dm.MixturesLocalStore:
        """ retrieve a mixtureslocalstore data model by mixtureslocalstore_id """
        try:
            res = await self.mixtureslocalstore_client.Retrieve(
                lara_django_substances_store_pb2.MixturesLocalStoreRetrieveRequest(mixtureslocalstore_id=mixtureslocalstore_id)
            )
            item = substances_store_dm.MixturesLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.mixtureslocalstore_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving mixtureslocalstore_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MixturesLocalStore | str:
        """ retrieve a mixtureslocalstore data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.mixtureslocalstore_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MixturesLocalStoreRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["mixtureslocalstore_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MixturesLocalStore(**item)
        except Exception as e:
            logger.error(f"Error retrieving mixtureslocalstore name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all mixtureslocalstores """
        if filter_dict is None:
            res = await self.mixtureslocalstore_client.List(lara_django_substances_store_pb2.MixturesLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.mixtureslocalstore_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.mixtureslocalstore_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all mixtureslocalstores """
        if self.mixtureslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.mixtureslocalstore_full_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.mixtureslocalstore_full_client.List(
                lara_django_substances_store_pb2.MixturesLocalStoreFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, mixtureslocalstore : substances_store_dm.MixturesLocalStore = None) -> None:
        """ update a mixtureslocalstore model instance """
        try:
            await self.mixtureslocalstore_client.Update(
                lara_django_substances_store_pb2.MixturesLocalStoreRequest(**mixtureslocalstore.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating mixtureslocalstore_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a mixtureslocalstore by mixtureslocalstore_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.mixtureslocalstore_client.Destroy(lara_django_substances_store_pb2.MixturesLocalStoreDestroyRequest(mixtureslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting mixtureslocalstore_id: {e}")

#_________________  ReactantInstance  ______________________


class ReactantInstanceInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.reactantinstance_client = lara_django_substances_store_pb2_grpc.ReactantInstanceControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactantinstances:  list[substances_store_dm.ReactantInstance] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.ReactantInstance]]:
        try:
            create_coroutines = ( self.reactantinstance_client.Create(lara_django_substances_store_pb2.ReactantInstanceRequest(**reactantinstance.model_dump())) for reactantinstance in reactantinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactantinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactantinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        reactantinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.ReactantInstance]:
        """ retrieve a list of reactantinstance instances by reactantinstance_id, name or filter_dict,
               returns a list of reactantinstance data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  reactantinstance_id is not None:
            try:
                res =  await self.reactantinstance_client.Retrieve(
                    lara_django_substances_store_pb2.ReactantInstanceRetrieveRequest(reactantinstance_id=reactantinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ReactantInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactantinstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactantinstance_client.List(
                    lara_django_substances_store_pb2.ReactantInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.ReactantInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving reactantinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactantinstance_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].reactantinstance_id
        else:
            raise ValueError(f"Error retrieving reactantinstance_id - no or too many results found.")
    
    async def get_by_id(self, reactantinstance_id: str = None) -> substances_store_dm.ReactantInstance:
        """ retrieve a reactantinstance data model by reactantinstance_id """
        try:
            res = await self.reactantinstance_client.Retrieve(
                lara_django_substances_store_pb2.ReactantInstanceRetrieveRequest(reactantinstance_id=reactantinstance_id)
            )
            return substances_store_dm.ReactantInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactantinstance_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.ReactantInstance | str:
        """ retrieve a reactantinstance data model by name """
        try:
            res = await self.reactantinstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.ReactantInstanceRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["reactantinstance_id"]
            else:
                return substances_store_dm.ReactantInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactantinstance name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactantinstances """
        if filter_dict is None:
            res = await self.reactantinstance_client.List(lara_django_substances_store_pb2.ReactantInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactantinstance_client.List(
                lara_django_substances_store_pb2.ReactantInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactantinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactantinstances """
        if self.reactantinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactantinstance_full_client.List(
                lara_django_substances_store_pb2.ReactantInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactantinstance_full_client.List(
                lara_django_substances_store_pb2.ReactantInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactantinstance : substances_store_dm.ReactantInstance = None) -> None:
        """ update a reactantinstance model instance """
        try:
            await self.reactantinstance_client.Update(
                lara_django_substances_store_pb2.ReactantInstanceRequest(**reactantinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactantinstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactantinstance by reactantinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactantinstance_client.Destroy(lara_django_substances_store_pb2.ReactantInstanceDestroyRequest(reactantinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactantinstance_id: {e}")

#_________________  ReactantInstancesSubset  ______________________


class ReactantInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.reactantinstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.ReactantInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.reactantinstancessubset_client = lara_django_substances_store_pb2_grpc.ReactantInstancesSubsetControllerStub(channel)
        

        # self.reactantinstancessubset_full_client = lara_django_substances_store_pb2_grpc.ReactantInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactantinstancessubsets:  list[substances_store_dm.ReactantInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.ReactantInstancesSubset]]:
        """ create a list of reactantinstancessubset instances,
               returns a list of reactantinstancessubset data model objects or ids_only

        :param reactantinstancessubsets: list of reactantinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of reactantinstancessubset data model objects or ids_only
        """
        reactantinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactantinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactantinstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.ReactantInstancesSubsetclassRetrieveRequest(iri=reactantinstancessubset_class_iri)
        #     )
        #     reactantinstancessubsetclass_id = res.reactantinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving reactantinstancessubsetclass_id: {e}")
        for reactantinstancessubset in reactantinstancessubsets:
            if reactantinstancessubset.namespace == "" or reactantinstancessubset.namespace == "default":
                    reactantinstancessubset.namespace = namespace_id
            # reactantinstancessubset.reactantinstancessubset_class = reactantinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.reactantinstancessubset_client.Create(lara_django_substances_store_pb2.ReactantInstancesSubsetRequest(**reactantinstancessubset.model_dump())) for reactantinstancessubset in reactantinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("reactantinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactantinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        reactantinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.ReactantInstancesSubset]:
        """ retrieve a list of reactantinstancessubset instances by reactantinstancessubset_id, name or filter_dict,
               returns a list of reactantinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  reactantinstancessubset_id is not None:
            try:
                res =  await self.reactantinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.ReactantInstancesSubsetRetrieveRequest(reactantinstancessubset_id=reactantinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactantinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactantinstancessubset_client.List(
                    lara_django_substances_store_pb2.ReactantInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.ReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving reactantinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactantinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].reactantinstancessubset_id
        else:
            raise ValueError(f"Error retrieving reactantinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, reactantinstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.ReactantInstancesSubset:
        """ retrieve a reactantinstancessubset data model by reactantinstancessubset_id """
        try:
            res = await self.reactantinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.ReactantInstancesSubsetRetrieveRequest(reactantinstancessubset_id=reactantinstancessubset_id)
            )
            item = substances_store_dm.ReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.reactantinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving reactantinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.ReactantInstancesSubset | str:
        """ retrieve a reactantinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.reactantinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.ReactantInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["reactantinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.ReactantInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving reactantinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactantinstancessubsets """
        if filter_dict is None:
            res = await self.reactantinstancessubset_client.List(lara_django_substances_store_pb2.ReactantInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactantinstancessubset_client.List(
                lara_django_substances_store_pb2.ReactantInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactantinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactantinstancessubsets """
        if self.reactantinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactantinstancessubset_full_client.List(
                lara_django_substances_store_pb2.ReactantInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactantinstancessubset_full_client.List(
                lara_django_substances_store_pb2.ReactantInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactantinstancessubset : substances_store_dm.ReactantInstancesSubset = None) -> None:
        """ update a reactantinstancessubset model instance """
        try:
            await self.reactantinstancessubset_client.Update(
                lara_django_substances_store_pb2.ReactantInstancesSubsetRequest(**reactantinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactantinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactantinstancessubset by reactantinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactantinstancessubset_client.Destroy(lara_django_substances_store_pb2.ReactantInstancesSubsetDestroyRequest(reactantinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactantinstancessubset_id: {e}")

#_________________  OrderedReactantInstancesReactantInstancesSubset  ______________________


class OrderedReactantInstancesReactantInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedreactantinstancesreactantinstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedReactantInstancesReactantInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedreactantinstancesreactantinstancessubsets:  list[substances_store_dm.OrderedReactantInstancesReactantInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedReactantInstancesReactantInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedreactantinstancesreactantinstancessubset_client.Create(lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetRequest(**orderedreactantinstancesreactantinstancessubset.model_dump())) for orderedreactantinstancesreactantinstancessubset in orderedreactantinstancesreactantinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedreactantinstancesreactantinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedreactantinstancesreactantinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedreactantinstancesreactantinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedReactantInstancesReactantInstancesSubset]:
        """ retrieve a list of orderedreactantinstancesreactantinstancessubset instances by orderedreactantinstancesreactantinstancessubset_id, name or filter_dict,
               returns a list of orderedreactantinstancesreactantinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedreactantinstancesreactantinstancessubset_id is not None:
            try:
                res =  await self.orderedreactantinstancesreactantinstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetRetrieveRequest(orderedreactantinstancesreactantinstancessubset_id=orderedreactantinstancesreactantinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedReactantInstancesReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedreactantinstancesreactantinstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedreactantinstancesreactantinstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedReactantInstancesReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantinstancesreactantinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedreactantinstancesreactantinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedreactantinstancesreactantinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedreactantinstancesreactantinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedreactantinstancesreactantinstancessubset_id: str = None) -> substances_store_dm.OrderedReactantInstancesReactantInstancesSubset:
        """ retrieve a orderedreactantinstancesreactantinstancessubset data model by orderedreactantinstancesreactantinstancessubset_id """
        try:
            res = await self.orderedreactantinstancesreactantinstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetRetrieveRequest(orderedreactantinstancesreactantinstancessubset_id=orderedreactantinstancesreactantinstancessubset_id)
            )
            return substances_store_dm.OrderedReactantInstancesReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantinstancesreactantinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedReactantInstancesReactantInstancesSubset | str:
        """ retrieve a orderedreactantinstancesreactantinstancessubset data model by name """
        try:
            res = await self.orderedreactantinstancesreactantinstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedreactantinstancesreactantinstancessubset_id"]
            else:
                return substances_store_dm.OrderedReactantInstancesReactantInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactantinstancesreactantinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedreactantinstancesreactantinstancessubsets """
        if filter_dict is None:
            res = await self.orderedreactantinstancesreactantinstancessubset_client.List(lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedreactantinstancesreactantinstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedreactantinstancesreactantinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedreactantinstancesreactantinstancessubsets """
        if self.orderedreactantinstancesreactantinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedreactantinstancesreactantinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedreactantinstancesreactantinstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedreactantinstancesreactantinstancessubset : substances_store_dm.OrderedReactantInstancesReactantInstancesSubset = None) -> None:
        """ update a orderedreactantinstancesreactantinstancessubset model instance """
        try:
            await self.orderedreactantinstancesreactantinstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetRequest(**orderedreactantinstancesreactantinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedreactantinstancesreactantinstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedreactantinstancesreactantinstancessubset by orderedreactantinstancesreactantinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedreactantinstancesreactantinstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedReactantInstancesReactantInstancesSubsetDestroyRequest(orderedreactantinstancesreactantinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedreactantinstancesreactantinstancessubset_id: {e}")

#_________________  ReactionInstance  ______________________


class ReactionInstanceInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.reactioninstance_client = lara_django_substances_store_pb2_grpc.ReactionInstanceControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactioninstances:  list[substances_store_dm.ReactionInstance] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.ReactionInstance]]:
        try:
            create_coroutines = ( self.reactioninstance_client.Create(lara_django_substances_store_pb2.ReactionInstanceRequest(**reactioninstance.model_dump())) for reactioninstance in reactioninstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.reactioninstance_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactioninstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        reactioninstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.ReactionInstance]:
        """ retrieve a list of reactioninstance instances by reactioninstance_id, name or filter_dict,
               returns a list of reactioninstance data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  reactioninstance_id is not None:
            try:
                res =  await self.reactioninstance_client.Retrieve(
                    lara_django_substances_store_pb2.ReactionInstanceRetrieveRequest(reactioninstance_id=reactioninstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ReactionInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactioninstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactioninstance_client.List(
                    lara_django_substances_store_pb2.ReactionInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.ReactionInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving reactioninstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactioninstance_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].reactioninstance_id
        else:
            raise ValueError(f"Error retrieving reactioninstance_id - no or too many results found.")
    
    async def get_by_id(self, reactioninstance_id: str = None) -> substances_store_dm.ReactionInstance:
        """ retrieve a reactioninstance data model by reactioninstance_id """
        try:
            res = await self.reactioninstance_client.Retrieve(
                lara_django_substances_store_pb2.ReactionInstanceRetrieveRequest(reactioninstance_id=reactioninstance_id)
            )
            return substances_store_dm.ReactionInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactioninstance_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.ReactionInstance | str:
        """ retrieve a reactioninstance data model by name """
        try:
            res = await self.reactioninstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.ReactionInstanceRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["reactioninstance_id"]
            else:
                return substances_store_dm.ReactionInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving reactioninstance name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactioninstances """
        if filter_dict is None:
            res = await self.reactioninstance_client.List(lara_django_substances_store_pb2.ReactionInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactioninstance_client.List(
                lara_django_substances_store_pb2.ReactionInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactioninstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactioninstances """
        if self.reactioninstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactioninstance_full_client.List(
                lara_django_substances_store_pb2.ReactionInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactioninstance_full_client.List(
                lara_django_substances_store_pb2.ReactionInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactioninstance : substances_store_dm.ReactionInstance = None) -> None:
        """ update a reactioninstance model instance """
        try:
            await self.reactioninstance_client.Update(
                lara_django_substances_store_pb2.ReactionInstanceRequest(**reactioninstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactioninstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactioninstance by reactioninstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactioninstance_client.Destroy(lara_django_substances_store_pb2.ReactionInstanceDestroyRequest(reactioninstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactioninstance_id: {e}")

#_________________  ReactionInstancesSubset  ______________________


class ReactionInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.reactioninstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.ReactionInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.reactioninstancessubset_client = lara_django_substances_store_pb2_grpc.ReactionInstancesSubsetControllerStub(channel)
        

        # self.reactioninstancessubset_full_client = lara_django_substances_store_pb2_grpc.ReactionInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  reactioninstancessubsets:  list[substances_store_dm.ReactionInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.ReactionInstancesSubset]]:
        """ create a list of reactioninstancessubset instances,
               returns a list of reactioninstancessubset data model objects or ids_only

        :param reactioninstancessubsets: list of reactioninstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of reactioninstancessubset data model objects or ids_only
        """
        reactioninstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if reactioninstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.reactioninstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.ReactionInstancesSubsetclassRetrieveRequest(iri=reactioninstancessubset_class_iri)
        #     )
        #     reactioninstancessubsetclass_id = res.reactioninstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving reactioninstancessubsetclass_id: {e}")
        for reactioninstancessubset in reactioninstancessubsets:
            if reactioninstancessubset.namespace == "" or reactioninstancessubset.namespace == "default":
                    reactioninstancessubset.namespace = namespace_id
            # reactioninstancessubset.reactioninstancessubset_class = reactioninstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.reactioninstancessubset_client.Create(lara_django_substances_store_pb2.ReactionInstancesSubsetRequest(**reactioninstancessubset.model_dump())) for reactioninstancessubset in reactioninstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("reactioninstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating reactioninstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        reactioninstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.ReactionInstancesSubset]:
        """ retrieve a list of reactioninstancessubset instances by reactioninstancessubset_id, name or filter_dict,
               returns a list of reactioninstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  reactioninstancessubset_id is not None:
            try:
                res =  await self.reactioninstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.ReactionInstancesSubsetRetrieveRequest(reactioninstancessubset_id=reactioninstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.ReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving reactioninstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.reactioninstancessubset_client.List(
                    lara_django_substances_store_pb2.ReactionInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.ReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving reactioninstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the reactioninstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].reactioninstancessubset_id
        else:
            raise ValueError(f"Error retrieving reactioninstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, reactioninstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.ReactionInstancesSubset:
        """ retrieve a reactioninstancessubset data model by reactioninstancessubset_id """
        try:
            res = await self.reactioninstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.ReactionInstancesSubsetRetrieveRequest(reactioninstancessubset_id=reactioninstancessubset_id)
            )
            item = substances_store_dm.ReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.reactioninstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving reactioninstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.ReactionInstancesSubset | str:
        """ retrieve a reactioninstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.reactioninstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.ReactionInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["reactioninstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.ReactionInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving reactioninstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all reactioninstancessubsets """
        if filter_dict is None:
            res = await self.reactioninstancessubset_client.List(lara_django_substances_store_pb2.ReactionInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.reactioninstancessubset_client.List(
                lara_django_substances_store_pb2.ReactionInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.reactioninstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all reactioninstancessubsets """
        if self.reactioninstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.reactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.ReactionInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.reactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.ReactionInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, reactioninstancessubset : substances_store_dm.ReactionInstancesSubset = None) -> None:
        """ update a reactioninstancessubset model instance """
        try:
            await self.reactioninstancessubset_client.Update(
                lara_django_substances_store_pb2.ReactionInstancesSubsetRequest(**reactioninstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating reactioninstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a reactioninstancessubset by reactioninstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.reactioninstancessubset_client.Destroy(lara_django_substances_store_pb2.ReactionInstancesSubsetDestroyRequest(reactioninstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting reactioninstancessubset_id: {e}")

#_________________  OrderedReactionInstancesReactionInstancesSubset  ______________________


class OrderedReactionInstancesReactionInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedreactioninstancesreactioninstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedReactionInstancesReactionInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedreactioninstancesreactioninstancessubsets:  list[substances_store_dm.OrderedReactionInstancesReactionInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedReactionInstancesReactionInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedreactioninstancesreactioninstancessubset_client.Create(lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetRequest(**orderedreactioninstancesreactioninstancessubset.model_dump())) for orderedreactioninstancesreactioninstancessubset in orderedreactioninstancesreactioninstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedreactioninstancesreactioninstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedreactioninstancesreactioninstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedreactioninstancesreactioninstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedReactionInstancesReactionInstancesSubset]:
        """ retrieve a list of orderedreactioninstancesreactioninstancessubset instances by orderedreactioninstancesreactioninstancessubset_id, name or filter_dict,
               returns a list of orderedreactioninstancesreactioninstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedreactioninstancesreactioninstancessubset_id is not None:
            try:
                res =  await self.orderedreactioninstancesreactioninstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetRetrieveRequest(orderedreactioninstancesreactioninstancessubset_id=orderedreactioninstancesreactioninstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedReactionInstancesReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedreactioninstancesreactioninstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedreactioninstancesreactioninstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedReactionInstancesReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedreactioninstancesreactioninstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedreactioninstancesreactioninstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedreactioninstancesreactioninstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedreactioninstancesreactioninstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedreactioninstancesreactioninstancessubset_id: str = None) -> substances_store_dm.OrderedReactionInstancesReactionInstancesSubset:
        """ retrieve a orderedreactioninstancesreactioninstancessubset data model by orderedreactioninstancesreactioninstancessubset_id """
        try:
            res = await self.orderedreactioninstancesreactioninstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetRetrieveRequest(orderedreactioninstancesreactioninstancessubset_id=orderedreactioninstancesreactioninstancessubset_id)
            )
            return substances_store_dm.OrderedReactionInstancesReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactioninstancesreactioninstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedReactionInstancesReactionInstancesSubset | str:
        """ retrieve a orderedreactioninstancesreactioninstancessubset data model by name """
        try:
            res = await self.orderedreactioninstancesreactioninstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedreactioninstancesreactioninstancessubset_id"]
            else:
                return substances_store_dm.OrderedReactionInstancesReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedreactioninstancesreactioninstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedreactioninstancesreactioninstancessubsets """
        if filter_dict is None:
            res = await self.orderedreactioninstancesreactioninstancessubset_client.List(lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedreactioninstancesreactioninstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedreactioninstancesreactioninstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedreactioninstancesreactioninstancessubsets """
        if self.orderedreactioninstancesreactioninstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedreactioninstancesreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedreactioninstancesreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedreactioninstancesreactioninstancessubset : substances_store_dm.OrderedReactionInstancesReactionInstancesSubset = None) -> None:
        """ update a orderedreactioninstancesreactioninstancessubset model instance """
        try:
            await self.orderedreactioninstancesreactioninstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetRequest(**orderedreactioninstancesreactioninstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedreactioninstancesreactioninstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedreactioninstancesreactioninstancessubset by orderedreactioninstancesreactioninstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedreactioninstancesreactioninstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedReactionInstancesReactionInstancesSubsetDestroyRequest(orderedreactioninstancesreactioninstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedreactioninstancesreactioninstancessubset_id: {e}")

#_________________  MultiStepReactionInstance  ______________________


class MultiStepReactionInstanceInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.multistepreactioninstance_client = lara_django_substances_store_pb2_grpc.MultiStepReactionInstanceControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "multistepreactioninstance_id"
        self.stub = self.multistepreactioninstance_client

        self.image_upload_chunk = lara_django_substances_store_pb2.ImageUploadChunk

    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @upload_image  # needed for image upload
    async def create(self,  multistepreactioninstances:  list[substances_store_dm.MultiStepReactionInstance] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.MultiStepReactionInstance]]:
        try:
            create_coroutines = ( self.multistepreactioninstance_client.Create(lara_django_substances_store_pb2.MultiStepReactionInstanceRequest(**multistepreactioninstance.model_dump())) for multistepreactioninstance in multistepreactioninstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.multistepreactioninstance_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating multistepreactioninstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        multistepreactioninstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MultiStepReactionInstance]:
        """ retrieve a list of multistepreactioninstance instances by multistepreactioninstance_id, name or filter_dict,
               returns a list of multistepreactioninstance data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  multistepreactioninstance_id is not None:
            try:
                res =  await self.multistepreactioninstance_client.Retrieve(
                    lara_django_substances_store_pb2.MultiStepReactionInstanceRetrieveRequest(multistepreactioninstance_id=multistepreactioninstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MultiStepReactionInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving multistepreactioninstance_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.multistepreactioninstance_client.List(
                    lara_django_substances_store_pb2.MultiStepReactionInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MultiStepReactionInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the multistepreactioninstance_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].multistepreactioninstance_id
        else:
            raise ValueError(f"Error retrieving multistepreactioninstance_id - no or too many results found.")
    
    @download_image  # needed for image download
    async def get_by_id(self, multistepreactioninstance_id: str = None) -> substances_store_dm.MultiStepReactionInstance:
        """ retrieve a multistepreactioninstance data model by multistepreactioninstance_id """
        try:
            res = await self.multistepreactioninstance_client.Retrieve(
                lara_django_substances_store_pb2.MultiStepReactionInstanceRetrieveRequest(multistepreactioninstance_id=multistepreactioninstance_id)
            )
            return substances_store_dm.MultiStepReactionInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstance_id: {e}")
    
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.MultiStepReactionInstance | str:
        """ retrieve a multistepreactioninstance data model by name """
        try:
            res = await self.multistepreactioninstance_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MultiStepReactionInstanceRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["multistepreactioninstance_id"]
            else:
                return substances_store_dm.MultiStepReactionInstance(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstance name: {e}")
    
    
    
    @download_image  # needed for image download
    async def get_image(self, multistepreactioninstance_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = multistepreactioninstance_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all multistepreactioninstances """
        if filter_dict is None:
            res = await self.multistepreactioninstance_client.List(lara_django_substances_store_pb2.MultiStepReactionInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreactioninstance_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreactioninstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all multistepreactioninstances """
        if self.multistepreactioninstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreactioninstance_full_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreactioninstance_full_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    @update_image  # needed for image update
    async def update(self, multistepreactioninstance : substances_store_dm.MultiStepReactionInstance = None) -> None:
        """ update a multistepreactioninstance model instance """
        try:
            await self.multistepreactioninstance_client.Update(
                lara_django_substances_store_pb2.MultiStepReactionInstanceRequest(**multistepreactioninstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating multistepreactioninstance_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a multistepreactioninstance by multistepreactioninstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.multistepreactioninstance_client.Destroy(lara_django_substances_store_pb2.MultiStepReactionInstanceDestroyRequest(multistepreactioninstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting multistepreactioninstance_id: {e}")

#_________________  MultiStepReactionInstancesSubset  ______________________


class MultiStepReactionInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.multistepreactioninstancessubset_class_client = (
        #     lara_django_substances_store_pb2_grpc.MultiStepReactionInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.multistepreactioninstancessubset_client = lara_django_substances_store_pb2_grpc.MultiStepReactionInstancesSubsetControllerStub(channel)
        

        # self.multistepreactioninstancessubset_full_client = lara_django_substances_store_pb2_grpc.MultiStepReactionInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  multistepreactioninstancessubsets:  list[substances_store_dm.MultiStepReactionInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[substances_store_dm.MultiStepReactionInstancesSubset]]:
        """ create a list of multistepreactioninstancessubset instances,
               returns a list of multistepreactioninstancessubset data model objects or ids_only

        :param multistepreactioninstancessubsets: list of multistepreactioninstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of multistepreactioninstancessubset data model objects or ids_only
        """
        multistepreactioninstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if multistepreactioninstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.multistepreactioninstancessubset_class_client.Retrieve(
        #         lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetclassRetrieveRequest(iri=multistepreactioninstancessubset_class_iri)
        #     )
        #     multistepreactioninstancessubsetclass_id = res.multistepreactioninstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving multistepreactioninstancessubsetclass_id: {e}")
        for multistepreactioninstancessubset in multistepreactioninstancessubsets:
            if multistepreactioninstancessubset.namespace == "" or multistepreactioninstancessubset.namespace == "default":
                    multistepreactioninstancessubset.namespace = namespace_id
            # multistepreactioninstancessubset.multistepreactioninstancessubset_class = multistepreactioninstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.multistepreactioninstancessubset_client.Create(lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetRequest(**multistepreactioninstancessubset.model_dump())) for multistepreactioninstancessubset in multistepreactioninstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("multistepreactioninstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating multistepreactioninstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        multistepreactioninstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.MultiStepReactionInstancesSubset]:
        """ retrieve a list of multistepreactioninstancessubset instances by multistepreactioninstancessubset_id, name or filter_dict,
               returns a list of multistepreactioninstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  multistepreactioninstancessubset_id is not None:
            try:
                res =  await self.multistepreactioninstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetRetrieveRequest(multistepreactioninstancessubset_id=multistepreactioninstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.MultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving multistepreactioninstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.multistepreactioninstancessubset_client.List(
                    lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.MultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          iri: str = None,) -> str:
        """ retrieve the multistepreactioninstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, raw=True)

        if len(results_list) == 1 :
            return results_list[0].multistepreactioninstancessubset_id
        else:
            raise ValueError(f"Error retrieving multistepreactioninstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, multistepreactioninstancessubset_id: str = None, id_only: bool = False) -> substances_store_dm.MultiStepReactionInstancesSubset:
        """ retrieve a multistepreactioninstancessubset data model by multistepreactioninstancessubset_id """
        try:
            res = await self.multistepreactioninstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetRetrieveRequest(multistepreactioninstancessubset_id=multistepreactioninstancessubset_id)
            )
            item = substances_store_dm.MultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.multistepreactioninstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> substances_store_dm.MultiStepReactionInstancesSubset | str:
        """ retrieve a multistepreactioninstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.multistepreactioninstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["multistepreactioninstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return substances_store_dm.MultiStepReactionInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving multistepreactioninstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all multistepreactioninstancessubsets """
        if filter_dict is None:
            res = await self.multistepreactioninstancessubset_client.List(lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.multistepreactioninstancessubset_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.multistepreactioninstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all multistepreactioninstancessubsets """
        if self.multistepreactioninstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.multistepreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.multistepreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, multistepreactioninstancessubset : substances_store_dm.MultiStepReactionInstancesSubset = None) -> None:
        """ update a multistepreactioninstancessubset model instance """
        try:
            await self.multistepreactioninstancessubset_client.Update(
                lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetRequest(**multistepreactioninstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating multistepreactioninstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a multistepreactioninstancessubset by multistepreactioninstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.multistepreactioninstancessubset_client.Destroy(lara_django_substances_store_pb2.MultiStepReactionInstancesSubsetDestroyRequest(multistepreactioninstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting multistepreactioninstancessubset_id: {e}")

#_________________  OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset  ______________________


class OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client = lara_django_substances_store_pb2_grpc.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def create(self,  orderedmultistepreactioninstancesmultistepreactioninstancessubsets:  list[substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.Create(lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetRequest(**orderedmultistepreactioninstancesmultistepreactioninstancessubset.model_dump())) for orderedmultistepreactioninstancesmultistepreactioninstancessubset in orderedmultistepreactioninstancesmultistepreactioninstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmultistepreactioninstancesmultistepreactioninstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmultistepreactioninstancesmultistepreactioninstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = {},
        raw : bool = False
        ) -> list[substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset]:
        """ retrieve a list of orderedmultistepreactioninstancesmultistepreactioninstancessubset instances by orderedmultistepreactioninstancesmultistepreactioninstancessubset_id, name or filter_dict,
               returns a list of orderedmultistepreactioninstancesmultistepreactioninstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedmultistepreactioninstancesmultistepreactioninstancessubset_id is not None:
            try:
                res =  await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.Retrieve(
                    lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetRetrieveRequest(orderedmultistepreactioninstancesmultistepreactioninstancessubset_id=orderedmultistepreactioninstancesmultistepreactioninstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: {e}")

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.List(
                    lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactioninstancesmultistepreactioninstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmultistepreactioninstancesmultistepreactioninstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedmultistepreactioninstancesmultistepreactioninstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedmultistepreactioninstancesmultistepreactioninstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: str = None) -> substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset:
        """ retrieve a orderedmultistepreactioninstancesmultistepreactioninstancessubset data model by orderedmultistepreactioninstancesmultistepreactioninstancessubset_id """
        try:
            res = await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.Retrieve(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetRetrieveRequest(orderedmultistepreactioninstancesmultistepreactioninstancessubset_id=orderedmultistepreactioninstancesmultistepreactioninstancessubset_id)
            )
            return substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset | str:
        """ retrieve a orderedmultistepreactioninstancesmultistepreactioninstancessubset data model by name """
        try:
            res = await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.RetrieveByNameNamespace(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedmultistepreactioninstancesmultistepreactioninstancessubset_id"]
            else:
                return substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmultistepreactioninstancesmultistepreactioninstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmultistepreactioninstancesmultistepreactioninstancessubsets """
        if filter_dict is None:
            res = await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.List(lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.List(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmultistepreactioninstancesmultistepreactioninstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmultistepreactioninstancesmultistepreactioninstancessubsets """
        if self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_full_client.List(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file(relation_resolver=lambda x: x)
    async def update(self, orderedmultistepreactioninstancesmultistepreactioninstancessubset : substances_store_dm.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubset = None) -> None:
        """ update a orderedmultistepreactioninstancesmultistepreactioninstancessubset model instance """
        try:
            await self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.Update(
                lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetRequest(**orderedmultistepreactioninstancesmultistepreactioninstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: {e}")
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmultistepreactioninstancesmultistepreactioninstancessubset by orderedmultistepreactioninstancesmultistepreactioninstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmultistepreactioninstancesmultistepreactioninstancessubset_client.Destroy(lara_django_substances_store_pb2.OrderedMultiStepReactionInstancesMultiStepReactionInstancesSubsetDestroyRequest(orderedmultistepreactioninstancesmultistepreactioninstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmultistepreactioninstancesmultistepreactioninstancessubset_id: {e}")

