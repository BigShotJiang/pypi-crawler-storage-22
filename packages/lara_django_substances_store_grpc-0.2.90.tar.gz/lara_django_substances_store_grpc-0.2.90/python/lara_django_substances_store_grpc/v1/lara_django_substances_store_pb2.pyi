from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "file", "image", "name_display", "search_vector")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    file: str
    image: str
    name_display: str
    search_vector: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., file: _Optional[str] = ..., image: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class MixtureBasketDestroyRequest(_message.Message):
    __slots__ = ("mixturebasket_id",)
    MIXTUREBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    mixturebasket_id: str
    def __init__(self, mixturebasket_id: _Optional[str] = ...) -> None: ...

class MixtureBasketListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureBasketListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureBasketResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureBasketResponse, _Mapping]]] = ...) -> None: ...

class MixtureBasketPartialUpdateRequest(_message.Message):
    __slots__ = ("mixturebasket_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturebasket_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureBasketRequest(_message.Message):
    __slots__ = ("mixturebasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturebasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureBasketResponse(_message.Message):
    __slots__ = ("mixturebasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturebasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureBasketRetrieveRequest(_message.Message):
    __slots__ = ("mixturebasket_id",)
    MIXTUREBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    mixturebasket_id: str
    def __init__(self, mixturebasket_id: _Optional[str] = ...) -> None: ...

class MixtureBasketStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureComponentInstanceDestroyRequest(_message.Message):
    __slots__ = ("mixturecomponentinstance_id",)
    MIXTURECOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    mixturecomponentinstance_id: str
    def __init__(self, mixturecomponentinstance_id: _Optional[str] = ...) -> None: ...

class MixtureComponentInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureComponentInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureComponentInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureComponentInstanceResponse, _Mapping]]] = ...) -> None: ...

class MixtureComponentInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("mixturecomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "substance_instance", "polymer_instance", "data_extra", "_partial_update_fields", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "iri", "concentration", "concentration_weight", "description", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTURECOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixturecomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    substance_instance: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixturecomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureComponentInstanceRequest(_message.Message):
    __slots__ = ("mixturecomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "substance_instance", "polymer_instance", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "iri", "concentration", "concentration_weight", "description", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTURECOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixturecomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    substance_instance: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixturecomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureComponentInstanceResponse(_message.Message):
    __slots__ = ("mixturecomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "substance_instance", "polymer_instance", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "iri", "concentration", "concentration_weight", "description", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTURECOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixturecomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    substance_instance: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    iri: str
    concentration: float
    concentration_weight: float
    description: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixturecomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., description: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureComponentInstanceRetrieveRequest(_message.Message):
    __slots__ = ("mixturecomponentinstance_id",)
    MIXTURECOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    mixturecomponentinstance_id: str
    def __init__(self, mixturecomponentinstance_id: _Optional[str] = ...) -> None: ...

class MixtureComponentInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureInstanceDestroyRequest(_message.Message):
    __slots__ = ("mixtureinstance_id",)
    MIXTUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureinstance_id: str
    def __init__(self, mixtureinstance_id: _Optional[str] = ...) -> None: ...

class MixtureInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureInstanceResponse, _Mapping]]] = ...) -> None: ...

class MixtureInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("mixtureinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "mixture", "components", "data_extra", "_partial_update_fields", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "procedure_url", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixtureinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    mixture: str
    components: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    procedure_url: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixtureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., mixture: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_url: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureInstanceRequest(_message.Message):
    __slots__ = ("mixtureinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "mixture", "components", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "procedure_url", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixtureinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    mixture: str
    components: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    procedure_url: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixtureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., mixture: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_url: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureInstanceResponse(_message.Message):
    __slots__ = ("mixtureinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "mixture", "components", "data_extra", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "procedure_url", "isotopes", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    MIXTUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_FIELD_NUMBER: _ClassVar[int]
    COMPONENTS_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    mixtureinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    mixture: str
    components: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    procedure_url: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, mixtureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., mixture: _Optional[str] = ..., components: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_url: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class MixtureInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MixtureInstanceRetrieveRequest(_message.Message):
    __slots__ = ("mixtureinstance_id",)
    MIXTUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureinstance_id: str
    def __init__(self, mixtureinstance_id: _Optional[str] = ...) -> None: ...

class MixtureInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("mixtureinstancessubset_id",)
    MIXTUREINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureinstancessubset_id: str
    def __init__(self, mixtureinstancessubset_id: _Optional[str] = ...) -> None: ...

class MixtureInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class MixtureInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("mixtureinstancessubset_id", "namespace", "group", "mixture_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTUREINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixtureinstancessubset_id: str
    namespace: str
    group: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixtureinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureInstancesSubsetRequest(_message.Message):
    __slots__ = ("mixtureinstancessubset_id", "namespace", "group", "mixture_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTUREINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixtureinstancessubset_id: str
    namespace: str
    group: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixtureinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureInstancesSubsetResponse(_message.Message):
    __slots__ = ("mixtureinstancessubset_id", "namespace", "group", "mixture_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MIXTUREINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixtureinstancessubset_id: str
    namespace: str
    group: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, mixtureinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("mixtureinstancessubset_id",)
    MIXTUREINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureinstancessubset_id: str
    def __init__(self, mixtureinstancessubset_id: _Optional[str] = ...) -> None: ...

class MixtureInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureOrderItemDestroyRequest(_message.Message):
    __slots__ = ("mixtureorderitem_id",)
    MIXTUREORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureorderitem_id: str
    def __init__(self, mixtureorderitem_id: _Optional[str] = ...) -> None: ...

class MixtureOrderItemListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureOrderItemListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureOrderItemResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureOrderItemResponse, _Mapping]]] = ...) -> None: ...

class MixtureOrderItemPartialUpdateRequest(_message.Message):
    __slots__ = ("mixtureorderitem_id", "mixture_instance", "data_extra", "_partial_update_fields", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "mixture_wishlist", "mixture_basket", "mixtures_order")
    MIXTUREORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_BASKET_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_ORDER_FIELD_NUMBER: _ClassVar[int]
    mixtureorderitem_id: str
    mixture_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    mixture_wishlist: str
    mixture_basket: str
    mixtures_order: str
    def __init__(self, mixtureorderitem_id: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., mixture_wishlist: _Optional[str] = ..., mixture_basket: _Optional[str] = ..., mixtures_order: _Optional[str] = ...) -> None: ...

class MixtureOrderItemRequest(_message.Message):
    __slots__ = ("mixtureorderitem_id", "mixture_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "mixture_wishlist", "mixture_basket", "mixtures_order")
    MIXTUREORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_BASKET_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_ORDER_FIELD_NUMBER: _ClassVar[int]
    mixtureorderitem_id: str
    mixture_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    mixture_wishlist: str
    mixture_basket: str
    mixtures_order: str
    def __init__(self, mixtureorderitem_id: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., mixture_wishlist: _Optional[str] = ..., mixture_basket: _Optional[str] = ..., mixtures_order: _Optional[str] = ...) -> None: ...

class MixtureOrderItemResponse(_message.Message):
    __slots__ = ("mixtureorderitem_id", "mixture_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "mixture_wishlist", "mixture_basket", "mixtures_order")
    MIXTUREORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_BASKET_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_ORDER_FIELD_NUMBER: _ClassVar[int]
    mixtureorderitem_id: str
    mixture_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    mixture_wishlist: str
    mixture_basket: str
    mixtures_order: str
    def __init__(self, mixtureorderitem_id: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., mixture_wishlist: _Optional[str] = ..., mixture_basket: _Optional[str] = ..., mixtures_order: _Optional[str] = ...) -> None: ...

class MixtureOrderItemRetrieveRequest(_message.Message):
    __slots__ = ("mixtureorderitem_id",)
    MIXTUREORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    mixtureorderitem_id: str
    def __init__(self, mixtureorderitem_id: _Optional[str] = ...) -> None: ...

class MixtureOrderItemStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureWishlistDestroyRequest(_message.Message):
    __slots__ = ("mixturewishlist_id",)
    MIXTUREWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    mixturewishlist_id: str
    def __init__(self, mixturewishlist_id: _Optional[str] = ...) -> None: ...

class MixtureWishlistListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixtureWishlistListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixtureWishlistResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixtureWishlistResponse, _Mapping]]] = ...) -> None: ...

class MixtureWishlistPartialUpdateRequest(_message.Message):
    __slots__ = ("mixturewishlist_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturewishlist_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureWishlistRequest(_message.Message):
    __slots__ = ("mixturewishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturewishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureWishlistResponse(_message.Message):
    __slots__ = ("mixturewishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTUREWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturewishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixtureWishlistRetrieveRequest(_message.Message):
    __slots__ = ("mixturewishlist_id",)
    MIXTUREWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    mixturewishlist_id: str
    def __init__(self, mixturewishlist_id: _Optional[str] = ...) -> None: ...

class MixtureWishlistStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesLocalStoreDestroyRequest(_message.Message):
    __slots__ = ("mixturelocalstore_id",)
    MIXTURELOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    mixturelocalstore_id: str
    def __init__(self, mixturelocalstore_id: _Optional[str] = ...) -> None: ...

class MixturesLocalStoreListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesLocalStoreListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixturesLocalStoreResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixturesLocalStoreResponse, _Mapping]]] = ...) -> None: ...

class MixturesLocalStorePartialUpdateRequest(_message.Message):
    __slots__ = ("mixturelocalstore_id", "namespace", "mixture_instances", "location", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTURELOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturelocalstore_id: str
    namespace: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturelocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesLocalStoreRequest(_message.Message):
    __slots__ = ("mixturelocalstore_id", "namespace", "mixture_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTURELOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturelocalstore_id: str
    namespace: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturelocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesLocalStoreResponse(_message.Message):
    __slots__ = ("mixturelocalstore_id", "namespace", "mixture_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    MIXTURELOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    mixturelocalstore_id: str
    namespace: str
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, mixturelocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MixturesLocalStoreRetrieveRequest(_message.Message):
    __slots__ = ("mixturelocalstore_id",)
    MIXTURELOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    mixturelocalstore_id: str
    def __init__(self, mixturelocalstore_id: _Optional[str] = ...) -> None: ...

class MixturesLocalStoreStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesOrderDestroyRequest(_message.Message):
    __slots__ = ("mixturesorder_id",)
    MIXTURESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    mixturesorder_id: str
    def __init__(self, mixturesorder_id: _Optional[str] = ...) -> None: ...

class MixturesOrderListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MixturesOrderListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MixturesOrderResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MixturesOrderResponse, _Mapping]]] = ...) -> None: ...

class MixturesOrderPartialUpdateRequest(_message.Message):
    __slots__ = ("mixturesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "_partial_update_fields", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    MIXTURESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    mixturesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, mixturesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class MixturesOrderRequest(_message.Message):
    __slots__ = ("mixturesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    MIXTURESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    mixturesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, mixturesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class MixturesOrderResponse(_message.Message):
    __slots__ = ("mixturesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    MIXTURESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    mixturesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, mixturesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class MixturesOrderRetrieveRequest(_message.Message):
    __slots__ = ("mixturesorder_id",)
    MIXTURESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    mixturesorder_id: str
    def __init__(self, mixturesorder_id: _Optional[str] = ...) -> None: ...

class MixturesOrderStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionInstanceDestroyRequest(_message.Message):
    __slots__ = ("multistepreactioninstance_id",)
    MULTISTEPREACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstance_id: str
    def __init__(self, multistepreactioninstance_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MultiStepReactionInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MultiStepReactionInstanceResponse, _Mapping]]] = ...) -> None: ...

class MultiStepReactionInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("multistepreactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "reaction_instances", "data_extra", "_partial_update_fields", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "description", "remarks", "datetime_last_modified", "entities_responsible", "entities_own", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "hardware_config", "software_config", "search_vector")
    MULTISTEPREACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    description: str
    remarks: str
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, multistepreactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceRequest(_message.Message):
    __slots__ = ("multistepreactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "reaction_instances", "data_extra", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "description", "remarks", "datetime_last_modified", "entities_responsible", "entities_own", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "hardware_config", "software_config", "search_vector")
    MULTISTEPREACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    description: str
    remarks: str
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, multistepreactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceResponse(_message.Message):
    __slots__ = ("multistepreactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "reaction_instances", "data_extra", "sequence", "properties", "computed_properties", "parameters", "svg", "image", "iri", "description", "remarks", "datetime_last_modified", "entities_responsible", "entities_own", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "hardware_config", "software_config", "search_vector")
    MULTISTEPREACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    SVG_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    sequence: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    parameters: _struct_pb2.Struct
    svg: str
    image: str
    iri: str
    description: str
    remarks: str
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, multistepreactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., sequence: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., svg: _Optional[str] = ..., image: _Optional[str] = ..., iri: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceRetrieveRequest(_message.Message):
    __slots__ = ("multistepreactioninstance_id",)
    MULTISTEPREACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstance_id: str
    def __init__(self, multistepreactioninstance_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("multistepreactioninstancessubset_id",)
    MULTISTEPREACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstancessubset_id: str
    def __init__(self, multistepreactioninstancessubset_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MultiStepReactionInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MultiStepReactionInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MultiStepReactionInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class MultiStepReactionInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("multistepreactioninstancessubset_id", "namespace", "group", "reactions_multistep_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstancessubset_id: str
    namespace: str
    group: str
    reactions_multistep_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstancesSubsetRequest(_message.Message):
    __slots__ = ("multistepreactioninstancessubset_id", "namespace", "group", "reactions_multistep_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstancessubset_id: str
    namespace: str
    group: str
    reactions_multistep_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstancesSubsetResponse(_message.Message):
    __slots__ = ("multistepreactioninstancessubset_id", "namespace", "group", "reactions_multistep_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    MULTISTEPREACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTIONS_MULTISTEP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstancessubset_id: str
    namespace: str
    group: str
    reactions_multistep_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, multistepreactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reactions_multistep_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("multistepreactioninstancessubset_id",)
    MULTISTEPREACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    multistepreactioninstancessubset_id: str
    def __init__(self, multistepreactioninstancessubset_id: _Optional[str] = ...) -> None: ...

class MultiStepReactionInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerBasketDestroyRequest(_message.Message):
    __slots__ = ("polymerbasket_id",)
    POLYMERBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerbasket_id: str
    def __init__(self, polymerbasket_id: _Optional[str] = ...) -> None: ...

class PolymerBasketListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerBasketListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerBasketResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerBasketResponse, _Mapping]]] = ...) -> None: ...

class PolymerBasketPartialUpdateRequest(_message.Message):
    __slots__ = ("polymerbasket_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerbasket_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerBasketRequest(_message.Message):
    __slots__ = ("polymerbasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerbasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerBasketResponse(_message.Message):
    __slots__ = ("polymerbasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerbasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerbasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerBasketRetrieveRequest(_message.Message):
    __slots__ = ("polymerbasket_id",)
    POLYMERBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerbasket_id: str
    def __init__(self, polymerbasket_id: _Optional[str] = ...) -> None: ...

class PolymerBasketStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerInstanceDestroyRequest(_message.Message):
    __slots__ = ("polymerinstance_id",)
    POLYMERINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    polymerinstance_id: str
    def __init__(self, polymerinstance_id: _Optional[str] = ...) -> None: ...

class PolymerInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerInstanceResponse, _Mapping]]] = ...) -> None: ...

class PolymerInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("polymerinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "polymer", "isotopes", "_partial_update_fields", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    POLYMERINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    polymerinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    polymer: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, polymerinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., polymer: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class PolymerInstanceRequest(_message.Message):
    __slots__ = ("polymerinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "polymer", "isotopes", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    POLYMERINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    polymerinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    polymer: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, polymerinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., polymer: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class PolymerInstanceResponse(_message.Message):
    __slots__ = ("polymerinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "polymer", "isotopes", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    POLYMERINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    POLYMER_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    polymerinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    polymer: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, polymerinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., polymer: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class PolymerInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class PolymerInstanceRetrieveRequest(_message.Message):
    __slots__ = ("polymerinstance_id",)
    POLYMERINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    polymerinstance_id: str
    def __init__(self, polymerinstance_id: _Optional[str] = ...) -> None: ...

class PolymerInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("polymerinstancessubset_id",)
    POLYMERINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerinstancessubset_id: str
    def __init__(self, polymerinstancessubset_id: _Optional[str] = ...) -> None: ...

class PolymerInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class PolymerInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("polymerinstancessubset_id", "namespace", "group", "polymer_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerinstancessubset_id: str
    namespace: str
    group: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerInstancesSubsetRequest(_message.Message):
    __slots__ = ("polymerinstancessubset_id", "namespace", "group", "polymer_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerinstancessubset_id: str
    namespace: str
    group: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerInstancesSubsetResponse(_message.Message):
    __slots__ = ("polymerinstancessubset_id", "namespace", "group", "polymer_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    POLYMERINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerinstancessubset_id: str
    namespace: str
    group: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, polymerinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("polymerinstancessubset_id",)
    POLYMERINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    polymerinstancessubset_id: str
    def __init__(self, polymerinstancessubset_id: _Optional[str] = ...) -> None: ...

class PolymerInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerOrderItemDestroyRequest(_message.Message):
    __slots__ = ("polymerorderitem_id",)
    POLYMERORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    polymerorderitem_id: str
    def __init__(self, polymerorderitem_id: _Optional[str] = ...) -> None: ...

class PolymerOrderItemListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerOrderItemListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerOrderItemResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerOrderItemResponse, _Mapping]]] = ...) -> None: ...

class PolymerOrderItemPartialUpdateRequest(_message.Message):
    __slots__ = ("polymerorderitem_id", "polymer_instance", "data_extra", "_partial_update_fields", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "polymer_wishlist", "polymer_basket", "polymers_order")
    POLYMERORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    POLYMER_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    POLYMER_BASKET_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_ORDER_FIELD_NUMBER: _ClassVar[int]
    polymerorderitem_id: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    polymer_wishlist: str
    polymer_basket: str
    polymers_order: str
    def __init__(self, polymerorderitem_id: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., polymer_wishlist: _Optional[str] = ..., polymer_basket: _Optional[str] = ..., polymers_order: _Optional[str] = ...) -> None: ...

class PolymerOrderItemRequest(_message.Message):
    __slots__ = ("polymerorderitem_id", "polymer_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "polymer_wishlist", "polymer_basket", "polymers_order")
    POLYMERORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    POLYMER_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    POLYMER_BASKET_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_ORDER_FIELD_NUMBER: _ClassVar[int]
    polymerorderitem_id: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    polymer_wishlist: str
    polymer_basket: str
    polymers_order: str
    def __init__(self, polymerorderitem_id: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., polymer_wishlist: _Optional[str] = ..., polymer_basket: _Optional[str] = ..., polymers_order: _Optional[str] = ...) -> None: ...

class PolymerOrderItemResponse(_message.Message):
    __slots__ = ("polymerorderitem_id", "polymer_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "polymer_wishlist", "polymer_basket", "polymers_order")
    POLYMERORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    POLYMER_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    POLYMER_BASKET_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_ORDER_FIELD_NUMBER: _ClassVar[int]
    polymerorderitem_id: str
    polymer_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    polymer_wishlist: str
    polymer_basket: str
    polymers_order: str
    def __init__(self, polymerorderitem_id: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., polymer_wishlist: _Optional[str] = ..., polymer_basket: _Optional[str] = ..., polymers_order: _Optional[str] = ...) -> None: ...

class PolymerOrderItemRetrieveRequest(_message.Message):
    __slots__ = ("polymerorderitem_id",)
    POLYMERORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    polymerorderitem_id: str
    def __init__(self, polymerorderitem_id: _Optional[str] = ...) -> None: ...

class PolymerOrderItemStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerWishlistDestroyRequest(_message.Message):
    __slots__ = ("polymerwishlist_id",)
    POLYMERWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    polymerwishlist_id: str
    def __init__(self, polymerwishlist_id: _Optional[str] = ...) -> None: ...

class PolymerWishlistListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymerWishlistListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymerWishlistResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymerWishlistResponse, _Mapping]]] = ...) -> None: ...

class PolymerWishlistPartialUpdateRequest(_message.Message):
    __slots__ = ("polymerwishlist_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerwishlist_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerWishlistRequest(_message.Message):
    __slots__ = ("polymerwishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerwishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerWishlistResponse(_message.Message):
    __slots__ = ("polymerwishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerwishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerwishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymerWishlistRetrieveRequest(_message.Message):
    __slots__ = ("polymerwishlist_id",)
    POLYMERWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    polymerwishlist_id: str
    def __init__(self, polymerwishlist_id: _Optional[str] = ...) -> None: ...

class PolymerWishlistStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersLocalStoreDestroyRequest(_message.Message):
    __slots__ = ("polymerlocalstore_id",)
    POLYMERLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    polymerlocalstore_id: str
    def __init__(self, polymerlocalstore_id: _Optional[str] = ...) -> None: ...

class PolymersLocalStoreListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersLocalStoreListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymersLocalStoreResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymersLocalStoreResponse, _Mapping]]] = ...) -> None: ...

class PolymersLocalStorePartialUpdateRequest(_message.Message):
    __slots__ = ("polymerlocalstore_id", "namespace", "polymer_instances", "location", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerlocalstore_id: str
    namespace: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersLocalStoreRequest(_message.Message):
    __slots__ = ("polymerlocalstore_id", "namespace", "polymer_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerlocalstore_id: str
    namespace: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersLocalStoreResponse(_message.Message):
    __slots__ = ("polymerlocalstore_id", "namespace", "polymer_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    POLYMERLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    polymerlocalstore_id: str
    namespace: str
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, polymerlocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class PolymersLocalStoreRetrieveRequest(_message.Message):
    __slots__ = ("polymerlocalstore_id",)
    POLYMERLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    polymerlocalstore_id: str
    def __init__(self, polymerlocalstore_id: _Optional[str] = ...) -> None: ...

class PolymersLocalStoreStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersOrderDestroyRequest(_message.Message):
    __slots__ = ("polymersorder_id",)
    POLYMERSORDER_ID_FIELD_NUMBER: _ClassVar[int]
    polymersorder_id: str
    def __init__(self, polymersorder_id: _Optional[str] = ...) -> None: ...

class PolymersOrderListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class PolymersOrderListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[PolymersOrderResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[PolymersOrderResponse, _Mapping]]] = ...) -> None: ...

class PolymersOrderPartialUpdateRequest(_message.Message):
    __slots__ = ("polymersorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "_partial_update_fields", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    POLYMERSORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    polymersorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, polymersorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class PolymersOrderRequest(_message.Message):
    __slots__ = ("polymersorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    POLYMERSORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    polymersorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, polymersorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class PolymersOrderResponse(_message.Message):
    __slots__ = ("polymersorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    POLYMERSORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    polymersorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, polymersorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class PolymersOrderRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class PolymersOrderRetrieveRequest(_message.Message):
    __slots__ = ("polymersorder_id",)
    POLYMERSORDER_ID_FIELD_NUMBER: _ClassVar[int]
    polymersorder_id: str
    def __init__(self, polymersorder_id: _Optional[str] = ...) -> None: ...

class PolymersOrderStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionComponentInstanceDestroyRequest(_message.Message):
    __slots__ = ("reactioncomponentinstance_id",)
    REACTIONCOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstance_id: str
    def __init__(self, reactioncomponentinstance_id: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionComponentInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionComponentInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionComponentInstanceResponse, _Mapping]]] = ...) -> None: ...

class ReactionComponentInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("reactioncomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "entities_responsible", "entities_own", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance_instance", "polymer_instance", "mixture_instance", "roles", "_partial_update_fields", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "datetime_last_modified", "search_vector", "iri", "concentration", "concentration_weight", "order", "stoichiometric_factor", "properties", "computed_properties", "physical_state")
    REACTIONCOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance_instance: str
    polymer_instance: str
    mixture_instance: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    datetime_last_modified: str
    search_vector: str
    iri: str
    concentration: float
    concentration_weight: float
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    physical_state: str
    def __init__(self, reactioncomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., physical_state: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceRequest(_message.Message):
    __slots__ = ("reactioncomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "entities_responsible", "entities_own", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance_instance", "polymer_instance", "mixture_instance", "roles", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "datetime_last_modified", "search_vector", "iri", "concentration", "concentration_weight", "order", "stoichiometric_factor", "properties", "computed_properties", "physical_state")
    REACTIONCOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance_instance: str
    polymer_instance: str
    mixture_instance: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    datetime_last_modified: str
    search_vector: str
    iri: str
    concentration: float
    concentration_weight: float
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    physical_state: str
    def __init__(self, reactioncomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., physical_state: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceResponse(_message.Message):
    __slots__ = ("reactioncomponentinstance_id", "namespace", "vendor", "currency", "location", "status", "entities_responsible", "entities_own", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance_instance", "polymer_instance", "mixture_instance", "roles", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "datetime_last_modified", "search_vector", "iri", "concentration", "concentration_weight", "order", "stoichiometric_factor", "properties", "computed_properties", "physical_state")
    REACTIONCOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_FIELD_NUMBER: _ClassVar[int]
    CONCENTRATION_WEIGHT_FIELD_NUMBER: _ClassVar[int]
    ORDER_FIELD_NUMBER: _ClassVar[int]
    STOICHIOMETRIC_FACTOR_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance_instance: str
    polymer_instance: str
    mixture_instance: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    datetime_last_modified: str
    search_vector: str
    iri: str
    concentration: float
    concentration_weight: float
    order: int
    stoichiometric_factor: float
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    physical_state: str
    def __init__(self, reactioncomponentinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance_instance: _Optional[str] = ..., polymer_instance: _Optional[str] = ..., mixture_instance: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., search_vector: _Optional[str] = ..., iri: _Optional[str] = ..., concentration: _Optional[float] = ..., concentration_weight: _Optional[float] = ..., order: _Optional[int] = ..., stoichiometric_factor: _Optional[float] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., physical_state: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceRetrieveRequest(_message.Message):
    __slots__ = ("reactioncomponentinstance_id",)
    REACTIONCOMPONENTINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstance_id: str
    def __init__(self, reactioncomponentinstance_id: _Optional[str] = ...) -> None: ...

class ReactionComponentInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionComponentInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("reactioncomponentinstancessubset_id",)
    REACTIONCOMPONENTINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstancessubset_id: str
    def __init__(self, reactioncomponentinstancessubset_id: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionComponentInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionComponentInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionComponentInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class ReactionComponentInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("reactioncomponentinstancessubset_id", "namespace", "entity", "group", "reaction_component_instances", "tags", "_partial_update_fields", "name_display", "name", "description", "datetime_last_modified")
    REACTIONCOMPONENTINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstancessubset_id: str
    namespace: str
    entity: str
    group: str
    reaction_component_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(self, reactioncomponentinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., group: _Optional[str] = ..., reaction_component_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetRequest(_message.Message):
    __slots__ = ("reactioncomponentinstancessubset_id", "namespace", "entity", "group", "reaction_component_instances", "tags", "name_display", "name", "description", "datetime_last_modified")
    REACTIONCOMPONENTINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstancessubset_id: str
    namespace: str
    entity: str
    group: str
    reaction_component_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(self, reactioncomponentinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., group: _Optional[str] = ..., reaction_component_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetResponse(_message.Message):
    __slots__ = ("reactioncomponentinstancessubset_id", "namespace", "entity", "group", "reaction_component_instances", "tags", "name_display", "name", "description", "datetime_last_modified")
    REACTIONCOMPONENTINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstancessubset_id: str
    namespace: str
    entity: str
    group: str
    reaction_component_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    description: str
    datetime_last_modified: str
    def __init__(self, reactioncomponentinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., entity: _Optional[str] = ..., group: _Optional[str] = ..., reaction_component_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("reactioncomponentinstancessubset_id",)
    REACTIONCOMPONENTINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioncomponentinstancessubset_id: str
    def __init__(self, reactioncomponentinstancessubset_id: _Optional[str] = ...) -> None: ...

class ReactionComponentInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionInstanceDestroyRequest(_message.Message):
    __slots__ = ("reactioninstance_id",)
    REACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    reactioninstance_id: str
    def __init__(self, reactioninstance_id: _Optional[str] = ...) -> None: ...

class ReactionInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionInstanceResponse, _Mapping]]] = ...) -> None: ...

class ReactionInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("reactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "_partial_update_fields", "iri", "procedure_url", "properties", "computed_properties", "datetime_last_modified", "entities_responsible", "entities_own", "reaction_base", "component_instances", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "search_vector")
    REACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    REACTION_BASE_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    procedure_url: str
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    reaction_base: str
    component_instances: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, reactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., procedure_url: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., reaction_base: _Optional[str] = ..., component_instances: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionInstanceRequest(_message.Message):
    __slots__ = ("reactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "iri", "procedure_url", "properties", "computed_properties", "datetime_last_modified", "entities_responsible", "entities_own", "reaction_base", "component_instances", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "search_vector")
    REACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    REACTION_BASE_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    procedure_url: str
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    reaction_base: str
    component_instances: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, reactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., procedure_url: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., reaction_base: _Optional[str] = ..., component_instances: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionInstanceResponse(_message.Message):
    __slots__ = ("reactioninstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "iri", "procedure_url", "properties", "computed_properties", "datetime_last_modified", "entities_responsible", "entities_own", "reaction_base", "component_instances", "name_display", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "hardware_config", "software_config", "search_vector")
    REACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_URL_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    REACTION_BASE_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    reactioninstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    iri: str
    procedure_url: str
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    datetime_last_modified: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    reaction_base: str
    component_instances: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    def __init__(self, reactioninstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., iri: _Optional[str] = ..., procedure_url: _Optional[str] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ..., reaction_base: _Optional[str] = ..., component_instances: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ...) -> None: ...

class ReactionInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ReactionInstanceRetrieveRequest(_message.Message):
    __slots__ = ("reactioninstance_id",)
    REACTIONINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    reactioninstance_id: str
    def __init__(self, reactioninstance_id: _Optional[str] = ...) -> None: ...

class ReactionInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("reactioninstancessubset_id",)
    REACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioninstancessubset_id: str
    def __init__(self, reactioninstancessubset_id: _Optional[str] = ...) -> None: ...

class ReactionInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ReactionInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ReactionInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ReactionInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class ReactionInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("reactioninstancessubset_id", "namespace", "group", "reaction_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactioninstancessubset_id: str
    namespace: str
    group: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionInstancesSubsetRequest(_message.Message):
    __slots__ = ("reactioninstancessubset_id", "namespace", "group", "reaction_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactioninstancessubset_id: str
    namespace: str
    group: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionInstancesSubsetResponse(_message.Message):
    __slots__ = ("reactioninstancessubset_id", "namespace", "group", "reaction_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    REACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    REACTION_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    reactioninstancessubset_id: str
    namespace: str
    group: str
    reaction_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, reactioninstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., reaction_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class ReactionInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("reactioninstancessubset_id",)
    REACTIONINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    reactioninstancessubset_id: str
    def __init__(self, reactioninstancessubset_id: _Optional[str] = ...) -> None: ...

class ReactionInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceBasketDestroyRequest(_message.Message):
    __slots__ = ("substancebasket_id",)
    SUBSTANCEBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    substancebasket_id: str
    def __init__(self, substancebasket_id: _Optional[str] = ...) -> None: ...

class SubstanceBasketListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceBasketListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceBasketResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceBasketResponse, _Mapping]]] = ...) -> None: ...

class SubstanceBasketPartialUpdateRequest(_message.Message):
    __slots__ = ("substancebasket_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancebasket_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceBasketRequest(_message.Message):
    __slots__ = ("substancebasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancebasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceBasketResponse(_message.Message):
    __slots__ = ("substancebasket_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancebasket_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancebasket_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceBasketRetrieveRequest(_message.Message):
    __slots__ = ("substancebasket_id",)
    SUBSTANCEBASKET_ID_FIELD_NUMBER: _ClassVar[int]
    substancebasket_id: str
    def __init__(self, substancebasket_id: _Optional[str] = ...) -> None: ...

class SubstanceBasketStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceInstanceDestroyRequest(_message.Message):
    __slots__ = ("substanceinstance_id",)
    SUBSTANCEINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    substanceinstance_id: str
    def __init__(self, substanceinstance_id: _Optional[str] = ...) -> None: ...

class SubstanceInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceInstanceResponse, _Mapping]]] = ...) -> None: ...

class SubstanceInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("substanceinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance", "isotopes", "_partial_update_fields", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    SUBSTANCEINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    substanceinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, substanceinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class SubstanceInstanceRequest(_message.Message):
    __slots__ = ("substanceinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance", "isotopes", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    SUBSTANCEINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    substanceinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, substanceinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class SubstanceInstanceResponse(_message.Message):
    __slots__ = ("substanceinstance_id", "namespace", "vendor", "currency", "location", "status", "users", "groups", "tags", "resources_external", "labware_instance", "physical_state_matter", "data_extra", "substance", "isotopes", "name", "barcode", "barcode_json", "url", "pid", "pac_id", "iri", "registration_no", "product_id", "serial_no", "service_no", "datetime_manufacturing", "price", "charges", "datetime_purchase", "datetime_delivery", "datetime_end_of_warranty", "amount", "storage_info", "safety_info", "legal_info", "hash_sha256", "color", "description", "datetime_last_modified", "amount_volume", "amount_mass", "purity", "purity_info", "properties", "computed_properties", "name_display", "hardware_config", "software_config", "search_vector", "entities_responsible", "entities_own")
    SUBSTANCEINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    VENDOR_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    USERS_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_STATE_MATTER_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_FIELD_NUMBER: _ClassVar[int]
    ISOTOPES_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BARCODE_FIELD_NUMBER: _ClassVar[int]
    BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    REGISTRATION_NO_FIELD_NUMBER: _ClassVar[int]
    PRODUCT_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NO_FIELD_NUMBER: _ClassVar[int]
    SERVICE_NO_FIELD_NUMBER: _ClassVar[int]
    DATETIME_MANUFACTURING_FIELD_NUMBER: _ClassVar[int]
    PRICE_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_PURCHASE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_DELIVERY_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_OF_WARRANTY_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    STORAGE_INFO_FIELD_NUMBER: _ClassVar[int]
    SAFETY_INFO_FIELD_NUMBER: _ClassVar[int]
    LEGAL_INFO_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_VOLUME_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_MASS_FIELD_NUMBER: _ClassVar[int]
    PURITY_FIELD_NUMBER: _ClassVar[int]
    PURITY_INFO_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    HARDWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_CONFIG_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    ENTITIES_OWN_FIELD_NUMBER: _ClassVar[int]
    substanceinstance_id: str
    namespace: str
    vendor: str
    currency: str
    location: str
    status: str
    users: _containers.RepeatedScalarFieldContainer[str]
    groups: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    labware_instance: str
    physical_state_matter: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    substance: str
    isotopes: _containers.RepeatedScalarFieldContainer[str]
    name: str
    barcode: str
    barcode_json: _struct_pb2.Struct
    url: str
    pid: str
    pac_id: str
    iri: str
    registration_no: str
    product_id: str
    serial_no: str
    service_no: str
    datetime_manufacturing: str
    price: float
    charges: _struct_pb2.Struct
    datetime_purchase: str
    datetime_delivery: str
    datetime_end_of_warranty: str
    amount: int
    storage_info: _struct_pb2.Struct
    safety_info: _struct_pb2.Struct
    legal_info: _struct_pb2.Struct
    hash_sha256: str
    color: str
    description: str
    datetime_last_modified: str
    amount_volume: float
    amount_mass: float
    purity: float
    purity_info: _struct_pb2.Struct
    properties: _struct_pb2.Struct
    computed_properties: _struct_pb2.Struct
    name_display: str
    hardware_config: _struct_pb2.Struct
    software_config: _struct_pb2.Struct
    search_vector: str
    entities_responsible: _containers.RepeatedScalarFieldContainer[str]
    entities_own: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, substanceinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., vendor: _Optional[str] = ..., currency: _Optional[str] = ..., location: _Optional[str] = ..., status: _Optional[str] = ..., users: _Optional[_Iterable[str]] = ..., groups: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., labware_instance: _Optional[str] = ..., physical_state_matter: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., substance: _Optional[str] = ..., isotopes: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., barcode: _Optional[str] = ..., barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., url: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., iri: _Optional[str] = ..., registration_no: _Optional[str] = ..., product_id: _Optional[str] = ..., serial_no: _Optional[str] = ..., service_no: _Optional[str] = ..., datetime_manufacturing: _Optional[str] = ..., price: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_purchase: _Optional[str] = ..., datetime_delivery: _Optional[str] = ..., datetime_end_of_warranty: _Optional[str] = ..., amount: _Optional[int] = ..., storage_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., safety_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., legal_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., hash_sha256: _Optional[str] = ..., color: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., amount_volume: _Optional[float] = ..., amount_mass: _Optional[float] = ..., purity: _Optional[float] = ..., purity_info: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., computed_properties: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., name_display: _Optional[str] = ..., hardware_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., software_config: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., search_vector: _Optional[str] = ..., entities_responsible: _Optional[_Iterable[str]] = ..., entities_own: _Optional[_Iterable[str]] = ...) -> None: ...

class SubstanceInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class SubstanceInstanceRetrieveRequest(_message.Message):
    __slots__ = ("substanceinstance_id",)
    SUBSTANCEINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    substanceinstance_id: str
    def __init__(self, substanceinstance_id: _Optional[str] = ...) -> None: ...

class SubstanceInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceInstancesSubsetDestroyRequest(_message.Message):
    __slots__ = ("substanceinstancessubset_id",)
    SUBSTANCEINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    substanceinstancessubset_id: str
    def __init__(self, substanceinstancessubset_id: _Optional[str] = ...) -> None: ...

class SubstanceInstancesSubsetListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceInstancesSubsetListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceInstancesSubsetResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceInstancesSubsetResponse, _Mapping]]] = ...) -> None: ...

class SubstanceInstancesSubsetPartialUpdateRequest(_message.Message):
    __slots__ = ("substanceinstancessubset_id", "namespace", "group", "substance_instances", "tags", "_partial_update_fields", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCEINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceinstancessubset_id: str
    namespace: str
    group: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substanceinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceInstancesSubsetRequest(_message.Message):
    __slots__ = ("substanceinstancessubset_id", "namespace", "group", "substance_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCEINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceinstancessubset_id: str
    namespace: str
    group: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substanceinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceInstancesSubsetResponse(_message.Message):
    __slots__ = ("substanceinstancessubset_id", "namespace", "group", "substance_instances", "tags", "name", "description", "datetime_last_modified", "name_display", "entity")
    SUBSTANCEINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceinstancessubset_id: str
    namespace: str
    group: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name: str
    description: str
    datetime_last_modified: str
    name_display: str
    entity: str
    def __init__(self, substanceinstancessubset_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstanceInstancesSubsetRetrieveRequest(_message.Message):
    __slots__ = ("substanceinstancessubset_id",)
    SUBSTANCEINSTANCESSUBSET_ID_FIELD_NUMBER: _ClassVar[int]
    substanceinstancessubset_id: str
    def __init__(self, substanceinstancessubset_id: _Optional[str] = ...) -> None: ...

class SubstanceInstancesSubsetStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceOrderItemDestroyRequest(_message.Message):
    __slots__ = ("substanceorderitem_id",)
    SUBSTANCEORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    substanceorderitem_id: str
    def __init__(self, substanceorderitem_id: _Optional[str] = ...) -> None: ...

class SubstanceOrderItemListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstanceOrderItemListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstanceOrderItemResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstanceOrderItemResponse, _Mapping]]] = ...) -> None: ...

class SubstanceOrderItemPartialUpdateRequest(_message.Message):
    __slots__ = ("substanceorderitem_id", "substance_instance", "data_extra", "_partial_update_fields", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "substance_wishlist", "substance_basket", "substance_order")
    SUBSTANCEORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_BASKET_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_ORDER_FIELD_NUMBER: _ClassVar[int]
    substanceorderitem_id: str
    substance_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    substance_wishlist: str
    substance_basket: str
    substance_order: str
    def __init__(self, substanceorderitem_id: _Optional[str] = ..., substance_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., substance_wishlist: _Optional[str] = ..., substance_basket: _Optional[str] = ..., substance_order: _Optional[str] = ...) -> None: ...

class SubstanceOrderItemRequest(_message.Message):
    __slots__ = ("substanceorderitem_id", "substance_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "substance_wishlist", "substance_basket", "substance_order")
    SUBSTANCEORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_BASKET_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_ORDER_FIELD_NUMBER: _ClassVar[int]
    substanceorderitem_id: str
    substance_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    substance_wishlist: str
    substance_basket: str
    substance_order: str
    def __init__(self, substanceorderitem_id: _Optional[str] = ..., substance_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., substance_wishlist: _Optional[str] = ..., substance_basket: _Optional[str] = ..., substance_order: _Optional[str] = ...) -> None: ...

class SubstanceOrderItemResponse(_message.Message):
    __slots__ = ("substanceorderitem_id", "substance_instance", "data_extra", "quantity", "item_price_net", "item_price_gross", "item_transport_price", "item_price_tax", "item_toll", "toll_number", "item_discount", "charges", "total_price_net", "provider", "position", "status", "substance_wishlist", "substance_basket", "substance_order")
    SUBSTANCEORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCE_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    QUANTITY_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ITEM_TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    ITEM_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ITEM_TOLL_FIELD_NUMBER: _ClassVar[int]
    TOLL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ITEM_DISCOUNT_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_WISHLIST_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_BASKET_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_ORDER_FIELD_NUMBER: _ClassVar[int]
    substanceorderitem_id: str
    substance_instance: str
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    quantity: int
    item_price_net: float
    item_price_gross: float
    item_transport_price: float
    item_price_tax: float
    item_toll: float
    toll_number: str
    item_discount: float
    charges: _struct_pb2.Struct
    total_price_net: float
    provider: str
    position: int
    status: str
    substance_wishlist: str
    substance_basket: str
    substance_order: str
    def __init__(self, substanceorderitem_id: _Optional[str] = ..., substance_instance: _Optional[str] = ..., data_extra: _Optional[_Iterable[str]] = ..., quantity: _Optional[int] = ..., item_price_net: _Optional[float] = ..., item_price_gross: _Optional[float] = ..., item_transport_price: _Optional[float] = ..., item_price_tax: _Optional[float] = ..., item_toll: _Optional[float] = ..., toll_number: _Optional[str] = ..., item_discount: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., total_price_net: _Optional[float] = ..., provider: _Optional[str] = ..., position: _Optional[int] = ..., status: _Optional[str] = ..., substance_wishlist: _Optional[str] = ..., substance_basket: _Optional[str] = ..., substance_order: _Optional[str] = ...) -> None: ...

class SubstanceOrderItemRetrieveRequest(_message.Message):
    __slots__ = ("substanceorderitem_id",)
    SUBSTANCEORDERITEM_ID_FIELD_NUMBER: _ClassVar[int]
    substanceorderitem_id: str
    def __init__(self, substanceorderitem_id: _Optional[str] = ...) -> None: ...

class SubstanceOrderItemStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesLocalStoreDestroyRequest(_message.Message):
    __slots__ = ("substanceslocalstore_id",)
    SUBSTANCESLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    substanceslocalstore_id: str
    def __init__(self, substanceslocalstore_id: _Optional[str] = ...) -> None: ...

class SubstancesLocalStoreListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesLocalStoreListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstancesLocalStoreResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstancesLocalStoreResponse, _Mapping]]] = ...) -> None: ...

class SubstancesLocalStorePartialUpdateRequest(_message.Message):
    __slots__ = ("substanceslocalstore_id", "namespace", "substance_instances", "location", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCESLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceslocalstore_id: str
    namespace: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substanceslocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesLocalStoreRequest(_message.Message):
    __slots__ = ("substanceslocalstore_id", "namespace", "substance_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCESLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceslocalstore_id: str
    namespace: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substanceslocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesLocalStoreResponse(_message.Message):
    __slots__ = ("substanceslocalstore_id", "namespace", "substance_instances", "location", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCESLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substanceslocalstore_id: str
    namespace: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    location: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substanceslocalstore_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., location: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesLocalStoreRetrieveRequest(_message.Message):
    __slots__ = ("substanceslocalstore_id",)
    SUBSTANCESLOCALSTORE_ID_FIELD_NUMBER: _ClassVar[int]
    substanceslocalstore_id: str
    def __init__(self, substanceslocalstore_id: _Optional[str] = ...) -> None: ...

class SubstancesLocalStoreStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesOrderDestroyRequest(_message.Message):
    __slots__ = ("substancesorder_id",)
    SUBSTANCESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    substancesorder_id: str
    def __init__(self, substancesorder_id: _Optional[str] = ...) -> None: ...

class SubstancesOrderListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesOrderListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstancesOrderResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstancesOrderResponse, _Mapping]]] = ...) -> None: ...

class SubstancesOrderPartialUpdateRequest(_message.Message):
    __slots__ = ("substancesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "_partial_update_fields", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    SUBSTANCESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    substancesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, substancesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class SubstancesOrderRequest(_message.Message):
    __slots__ = ("substancesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    SUBSTANCESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    substancesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, substancesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class SubstancesOrderResponse(_message.Message):
    __slots__ = ("substancesorder_id", "namespace", "group_ordered", "group_ordering", "provider", "transport_company", "order_currency", "order_status", "order_quotes", "order_invoices", "data_extra", "name", "order_id_internal", "order_id_external", "order_barcode", "order_barcode_json", "iri", "datetime_order", "order_quote_id", "datetime_order_quote", "order_invoice_id", "datetime_order_invoice", "transport_tracking_id", "transport_price", "datetime_order_pay", "order_total_price_net", "order_total_price_gross", "order_total_price_tax", "order_total_price_toll", "charges", "datetime_last_modified", "name_display", "search_vector", "budget_url", "entity_ordered", "entity_ordering")
    SUBSTANCESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERED_FIELD_NUMBER: _ClassVar[int]
    GROUP_ORDERING_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_COMPANY_FIELD_NUMBER: _ClassVar[int]
    ORDER_CURRENCY_FIELD_NUMBER: _ClassVar[int]
    ORDER_STATUS_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTES_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICES_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_INTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_ID_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_FIELD_NUMBER: _ClassVar[int]
    ORDER_BARCODE_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_FIELD_NUMBER: _ClassVar[int]
    ORDER_QUOTE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_QUOTE_FIELD_NUMBER: _ClassVar[int]
    ORDER_INVOICE_ID_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_INVOICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_TRACKING_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_PRICE_FIELD_NUMBER: _ClassVar[int]
    DATETIME_ORDER_PAY_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_NET_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_GROSS_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TAX_FIELD_NUMBER: _ClassVar[int]
    ORDER_TOTAL_PRICE_TOLL_FIELD_NUMBER: _ClassVar[int]
    CHARGES_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    BUDGET_URL_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERED_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ORDERING_FIELD_NUMBER: _ClassVar[int]
    substancesorder_id: str
    namespace: str
    group_ordered: str
    group_ordering: str
    provider: str
    transport_company: str
    order_currency: str
    order_status: str
    order_quotes: _containers.RepeatedScalarFieldContainer[str]
    order_invoices: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    name: str
    order_id_internal: str
    order_id_external: str
    order_barcode: str
    order_barcode_json: _struct_pb2.Struct
    iri: str
    datetime_order: str
    order_quote_id: str
    datetime_order_quote: str
    order_invoice_id: str
    datetime_order_invoice: str
    transport_tracking_id: str
    transport_price: float
    datetime_order_pay: str
    order_total_price_net: float
    order_total_price_gross: float
    order_total_price_tax: float
    order_total_price_toll: float
    charges: _struct_pb2.Struct
    datetime_last_modified: str
    name_display: str
    search_vector: str
    budget_url: str
    entity_ordered: str
    entity_ordering: str
    def __init__(self, substancesorder_id: _Optional[str] = ..., namespace: _Optional[str] = ..., group_ordered: _Optional[str] = ..., group_ordering: _Optional[str] = ..., provider: _Optional[str] = ..., transport_company: _Optional[str] = ..., order_currency: _Optional[str] = ..., order_status: _Optional[str] = ..., order_quotes: _Optional[_Iterable[str]] = ..., order_invoices: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., order_id_internal: _Optional[str] = ..., order_id_external: _Optional[str] = ..., order_barcode: _Optional[str] = ..., order_barcode_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., datetime_order: _Optional[str] = ..., order_quote_id: _Optional[str] = ..., datetime_order_quote: _Optional[str] = ..., order_invoice_id: _Optional[str] = ..., datetime_order_invoice: _Optional[str] = ..., transport_tracking_id: _Optional[str] = ..., transport_price: _Optional[float] = ..., datetime_order_pay: _Optional[str] = ..., order_total_price_net: _Optional[float] = ..., order_total_price_gross: _Optional[float] = ..., order_total_price_tax: _Optional[float] = ..., order_total_price_toll: _Optional[float] = ..., charges: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., budget_url: _Optional[str] = ..., entity_ordered: _Optional[str] = ..., entity_ordering: _Optional[str] = ...) -> None: ...

class SubstancesOrderRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class SubstancesOrderRetrieveRequest(_message.Message):
    __slots__ = ("substancesorder_id",)
    SUBSTANCESORDER_ID_FIELD_NUMBER: _ClassVar[int]
    substancesorder_id: str
    def __init__(self, substancesorder_id: _Optional[str] = ...) -> None: ...

class SubstancesOrderStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesWishlistDestroyRequest(_message.Message):
    __slots__ = ("substancewishlist_id",)
    SUBSTANCEWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    substancewishlist_id: str
    def __init__(self, substancewishlist_id: _Optional[str] = ...) -> None: ...

class SubstancesWishlistListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubstancesWishlistListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[SubstancesWishlistResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[SubstancesWishlistResponse, _Mapping]]] = ...) -> None: ...

class SubstancesWishlistPartialUpdateRequest(_message.Message):
    __slots__ = ("substancewishlist_id", "namespace", "_partial_update_fields", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancewishlist_id: str
    namespace: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesWishlistRequest(_message.Message):
    __slots__ = ("substancewishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancewishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesWishlistResponse(_message.Message):
    __slots__ = ("substancewishlist_id", "namespace", "name", "datetime_created", "datetime_last_modified", "name_display", "search_vector", "entity")
    SUBSTANCEWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    substancewishlist_id: str
    namespace: str
    name: str
    datetime_created: str
    datetime_last_modified: str
    name_display: str
    search_vector: str
    entity: str
    def __init__(self, substancewishlist_id: _Optional[str] = ..., namespace: _Optional[str] = ..., name: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., name_display: _Optional[str] = ..., search_vector: _Optional[str] = ..., entity: _Optional[str] = ...) -> None: ...

class SubstancesWishlistRetrieveRequest(_message.Message):
    __slots__ = ("substancewishlist_id",)
    SUBSTANCEWISHLIST_ID_FIELD_NUMBER: _ClassVar[int]
    substancewishlist_id: str
    def __init__(self, substancewishlist_id: _Optional[str] = ...) -> None: ...

class SubstancesWishlistStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
