.. include:: ../sources/multi/docs/specification.rst

This returns the following:

.. include:: ../build/docs-work/multi_source_schema.json
   :literal:
