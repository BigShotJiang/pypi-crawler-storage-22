import warnings

warnings.filterwarnings('ignore', category=UserWarning, message='.*pkg_resources.*')

from .client import Client
