from .table import Table
from .app_dashboard import *
from .app_role import *
from .app_role_member import *
from .app_workflow import *


class App:
    app_token = None

    def __init__(self, client: lark.Client, app_token: str = None) -> None:
        self.client = client
        if app_token:
            self.app_token = app_token

        self.app_dashboard = App_dashboard(client=self.client)
        self.app_role = App_role(client=self.client)
        self.app_role_member = App_role_member(client=self.client)
        self.app_workflow = App_workflow(client=self.client)

    def table(self, table_id: str = None) -> Table:
        return Table(client=self.client, app_token=self.app_token, table_id=table_id)
