import lark_oapi as lark


class App_dashboard:
    def __init__(self, client: lark.Client) -> None:
        self.client = client
