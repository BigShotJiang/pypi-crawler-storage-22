import lark_oapi as lark


class App_role_member:
    def __init__(self, client: lark.Client) -> None:
        self.client = client