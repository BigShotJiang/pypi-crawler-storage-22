import inspect
import lark_oapi as lark
from lark_oapi.api.bitable.v1 import *
from lark_oapi.api.bitable.v1.model.delete_app_table_field_request_body import DeleteAppTableFieldRequestBody
from lark_oapi.api.bitable.v1.model.list_app_table_field_request_body import ListAppTableFieldRequestBody


def get_all_params():
    """在函数内部调用，获取所有传入的参数"""
    frame = inspect.currentframe().f_back  # 获取调用者的帧
    args, _, _, values = inspect.getargvalues(frame)

    params = {}
    for arg in args:
        if arg != 'self':  # 排除 self 参数
            params[arg] = values[arg]
    return params


class Field:
    def __init__(self, client: lark.Client, app_token: str = None, table_id: str = None) -> None:
        self.client = client
        self.app_token = app_token
        self.table_id = table_id

    def _general_request(self, request_class, **kwargs):
        # 构造请求对象
        request = request_class.builder()
        for k, v in kwargs.items():
            if v:
                getattr(request, k)(v)
        request = request.build()
        return request

    def _fill_default_params(self, params: dict) -> dict:
        """填充默认的 app_token 和 table_id"""
        if not params.get('app_token'):
            params['app_token'] = self.app_token
        if not params.get('table_id'):
            params['table_id'] = self.table_id
        return params

    def create(self, request_body: AppTableField, app_token: str = None, table_id: str = None,
               client_token: str = None) -> CreateAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableFieldRequest, **params)
        # 发起请求
        response: CreateAppTableFieldResponse = self.client.bitable.v1.app_table_field.create(request)
        return response

    async def acreate(self, request_body: AppTableField, app_token: str = None, table_id: str = None,
                      client_token: str = None) -> CreateAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableFieldRequest, **params)
        # 发起请求
        response: CreateAppTableFieldResponse = await self.client.bitable.v1.app_table_field.acreate(request)
        return response

    def update(self, field_id: str, request_body: AppTableField, app_token: str = None, table_id: str = None,
               client_token: str = None) -> UpdateAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=UpdateAppTableFieldRequest, **params)
        # 发起请求
        response: UpdateAppTableFieldResponse = self.client.bitable.v1.app_table_field.update(request)
        return response

    async def aupdate(self, field_id: str, request_body: AppTableField, app_token: str = None, table_id: str = None,
                      client_token: str = None) -> UpdateAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=UpdateAppTableFieldRequest, **params)
        # 发起请求
        response: UpdateAppTableFieldResponse = await self.client.bitable.v1.app_table_field.aupdate(request)
        return response

    def list(self, app_token: str = None, table_id: str = None, view_id: str = None, text_field_as_array: bool = None,
             page_size: int = 20, page_token: str = None) -> ListAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableFieldRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableFieldRequest, **params)
        # 发起请求
        response: ListAppTableFieldResponse = self.client.bitable.v1.app_table_field.list(request)
        return response

    async def alist(self, app_token: str = None, table_id: str = None, view_id: str = None, text_field_as_array: bool = None,
             page_size: int = 20, page_token: str = None) -> ListAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableFieldRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableFieldRequest, **params)
        # 发起请求
        response: ListAppTableFieldResponse = await self.client.bitable.v1.app_table_field.alist(request)
        return response

    def delete(self, field_id: str, app_token: str = None, table_id: str = None) -> DeleteAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableFieldRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableFieldRequest, **params)
        # 发起请求
        response: DeleteAppTableFieldResponse = self.client.bitable.v1.app_table_field.delete(request)
        return response

    async def adelete(self, field_id: str, app_token: str = None, table_id: str = None) -> DeleteAppTableFieldResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableFieldRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableFieldRequest, **params)
        # 发起请求
        response: DeleteAppTableFieldResponse = await self.client.bitable.v1.app_table_field.adelete(request)
        return response
