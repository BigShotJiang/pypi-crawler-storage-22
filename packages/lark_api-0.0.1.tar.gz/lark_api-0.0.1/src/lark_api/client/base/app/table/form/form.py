import inspect
import lark_oapi as lark
from lark_oapi.api.bitable.v1 import *
from lark_oapi.api.bitable.v1.model.get_app_table_form_request_body import GetAppTableFormRequestBody
from .field import *


def get_all_params():
    """在函数内部调用，获取所有传入的参数"""
    frame = inspect.currentframe().f_back  # 获取调用者的帧
    args, _, _, values = inspect.getargvalues(frame)

    params = {}
    for arg in args:
        if arg != 'self':  # 排除 self 参数
            params[arg] = values[arg]
    return params


class Form:
    app_token = None
    table_id = None
    form_id = None

    def __init__(self, client: lark.Client, app_token: str = None, table_id: str = None, form_id: str = None) -> None:
        self.client = client
        self.app_token = app_token
        self.table_id = table_id
        self.form_id = form_id
        self.field = Field(client=self.client, app_token=self.app_token, table_id=self.table_id, form_id=self.form_id)

    def _general_request(self, request_class, **kwargs):
        # 构造请求对象
        request = request_class.builder()
        for k, v in kwargs.items():
            if v:
                getattr(request, k)(v)
        request = request.build()
        return request

    def _fill_default_params(self, params: dict) -> dict:
        """填充默认的 app_token 和 table_id"""
        if not params.get('app_token'):
            params['app_token'] = self.app_token
        if not params.get('table_id'):
            params['table_id'] = self.table_id
        if not params.get('form_id'):
            params['form_id'] = self.form_id
        return params

    def patch(self, request_body: AppTableForm, app_token: str = None, table_id: str = None,
              form_id: str = None) -> PatchAppTableFormResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableFormRequest, **params)
        # 发起请求
        response: PatchAppTableFormResponse = self.client.bitable.v1.app_table_form.patch(request)
        return response

    async def apatch(self, request_body: AppTableForm, app_token: str = None, table_id: str = None,
                     form_id: str = None) -> PatchAppTableFormResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableFormRequest, **params)
        # 发起请求
        response: PatchAppTableFormResponse = await self.client.bitable.v1.app_table_form.apatch(request)
        return response

    def get(self, app_token: str = None, table_id: str = None, form_id: str = None) -> GetAppTableFormResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = GetAppTableFormRequestBody.builder().build()
        request = self._general_request(request_class=GetAppTableFormRequest, **params)
        # 发起请求
        response: GetAppTableFormResponse = self.client.bitable.v1.app_table_form.get(request)
        return response

    async def aget(self, app_token: str = None, table_id: str = None, form_id: str = None) -> GetAppTableFormResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = GetAppTableFormRequestBody.builder().build()
        request = self._general_request(request_class=GetAppTableFormRequest, **params)
        # 发起请求
        response: GetAppTableFormResponse = await self.client.bitable.v1.app_table_form.aget(request)
        return response
