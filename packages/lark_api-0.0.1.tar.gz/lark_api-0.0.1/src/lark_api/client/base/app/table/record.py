import inspect
import lark_oapi as lark
from lark_oapi.api.bitable.v1 import *


def get_all_params():
    """在函数内部调用，获取所有传入的参数"""
    frame = inspect.currentframe().f_back  # 获取调用者的帧
    args, _, _, values = inspect.getargvalues(frame)

    params = {}
    for arg in args:
        if arg != 'self':  # 排除 self 参数
            params[arg] = values[arg]
    return params


class Record:
    def __init__(self, client: lark.Client, app_token: str = None, table_id: str = None) -> None:
        self.client = client
        self.app_token = app_token
        self.table_id = table_id

    def _general_request(self, request_class, **kwargs):
        # 构造请求对象
        request = request_class.builder()
        for k, v in kwargs.items():
            if v:
                getattr(request, k)(v)
        request = request.build()
        return request

    def _fill_default_params(self, params: dict) -> dict:
        """填充默认的 app_token 和 table_id"""
        if not params.get('app_token'):
            params['app_token'] = self.app_token
        if not params.get('table_id'):
            params['table_id'] = self.table_id
        return params

    def create(self, request_body: AppTableRecord, app_token: str = None, table_id: str = None,
               user_id_type: str = None, client_token: str = None,
               ignore_consistency_check: bool = None) -> CreateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableRecordRequest, **params)
        # 发起请求
        response: CreateAppTableRecordResponse = self.client.bitable.v1.app_table_record.create(request)
        return response

    async def acreate(self, request_body: AppTableRecord, app_token: str = None, table_id: str = None,
                      user_id_type: str = None, client_token: str = None,
                      ignore_consistency_check: bool = None) -> CreateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableRecordRequest, **params)
        # 发起请求
        response: CreateAppTableRecordResponse = await self.client.bitable.v1.app_table_record.acreate(request)
        return response

    def update(self, record_id: str, request_body: AppTableRecord, app_token: str = None, table_id: str = None,
               user_id_type: str = None, ignore_consistency_check: bool = None) -> UpdateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=UpdateAppTableRecordRequest, **params)
        # 发起请求
        response: UpdateAppTableRecordResponse = self.client.bitable.v1.app_table_record.update(request)
        return response

    async def aupdate(self, record_id: str, request_body: AppTableRecord = None, app_token: str = None,
                      table_id: str = None,
                      user_id_type: str = None, ignore_consistency_check: bool = None) -> UpdateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=UpdateAppTableRecordRequest, **params)
        # 发起请求
        response: UpdateAppTableRecordResponse = await self.client.bitable.v1.app_table_record.aupdate(request)
        return response

    def search(self, request_body: SearchAppTableRecordRequestBody, app_token: str = None, table_id: str = None,
               user_id_type: str = None,
               page_token: str = None, page_size: int = 20) -> SearchAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=SearchAppTableRecordRequest, **params)
        # 发起请求
        response: SearchAppTableRecordResponse = self.client.bitable.v1.app_table_record.search(request)
        return response

    async def asearch(self, request_body: SearchAppTableRecordRequestBody, app_token: str = None,
                      table_id: str = None,
                      user_id_type: str = None,
                      page_token: str = None, page_size: int = 20) -> SearchAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=SearchAppTableRecordRequest, **params)
        # 发起请求
        response: SearchAppTableRecordResponse = await self.client.bitable.v1.app_table_record.asearch(request)
        return response

    def delete(self, record_id: str, app_token: str = None, table_id: str = None) -> DeleteAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=DeleteAppTableRecordRequest, **params)
        # 发起请求
        response: DeleteAppTableRecordResponse = self.client.bitable.v1.app_table_record.delete(request)
        return response

    async def adelete(self, record_id: str, app_token: str = None,
                      table_id: str = None) -> DeleteAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=DeleteAppTableRecordRequest, **params)
        # 发起请求
        response: DeleteAppTableRecordResponse = await self.client.bitable.v1.app_table_record.adelete(request)
        return response

    def batch_create(self, request_body: BatchCreateAppTableRecordRequestBody, app_token: str = None,
                     table_id: str = None, user_id_type: str = None, client_token: str = None,
                     ignore_consistency_check: bool = None) -> BatchCreateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchCreateAppTableRecordRequest, **params)
        # 发起请求
        response: BatchCreateAppTableRecordResponse = self.client.bitable.v1.app_table_record.batch_create(request)
        return response

    async def abatch_create(self, request_body: BatchCreateAppTableRecordRequestBody, app_token: str = None,
                            table_id: str = None, user_id_type: str = None, client_token: str = None,
                            ignore_consistency_check: bool = None) -> BatchCreateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchCreateAppTableRecordRequest, **params)
        # 发起请求
        response: BatchCreateAppTableRecordResponse = await self.client.bitable.v1.app_table_record.abatch_create(
            request)
        return response

    def batch_update(self, request_body: BatchUpdateAppTableRecordRequestBody,
                     app_token: str = None, table_id: str = None, user_id_type: str = None,
                     ignore_consistency_check: bool = None) -> BatchUpdateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchUpdateAppTableRecordRequest, **params)
        # 发起请求
        response: BatchUpdateAppTableRecordResponse = self.client.bitable.v1.app_table_record.batch_update(request)
        return response

    async def abatch_update(self, request_body: BatchUpdateAppTableRecordRequestBody,
                            app_token: str = None, table_id: str = None, user_id_type: str = None,
                            ignore_consistency_check: bool = None) -> BatchUpdateAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchUpdateAppTableRecordRequest, **params)
        # 发起请求
        response: BatchUpdateAppTableRecordResponse = await self.client.bitable.v1.app_table_record.abatch_update(
            request)
        return response

    def batch_get(self, request_body: BatchGetAppTableRecordRequestBody = None,
                  app_token: str = None, table_id: str = None) -> BatchGetAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchGetAppTableRecordRequest, **params)
        # 发起请求
        response: BatchGetAppTableRecordResponse = self.client.bitable.v1.app_table_record.batch_get(request)
        return response

    async def abatch_get(self, request_body: BatchGetAppTableRecordRequestBody = None,
                         app_token: str = None, table_id: str = None) -> BatchGetAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchGetAppTableRecordRequest, **params)
        # 发起请求
        response: BatchGetAppTableRecordResponse = await self.client.bitable.v1.app_table_record.abatch_get(request)
        return response

    def batch_delete(self, request_body: BatchDeleteAppTableRecordRequestBody = None,
                     app_token: str = None, table_id: str = None) -> BatchDeleteAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchDeleteAppTableRecordRequest, **params)
        # 发起请求
        response: BatchDeleteAppTableRecordResponse = self.client.bitable.v1.app_table_record.batch_delete(request)
        return response

    async def abatch_delete(self, request_body: BatchDeleteAppTableRecordRequestBody = None,
                           app_token: str = None, table_id: str = None) -> BatchDeleteAppTableRecordResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchDeleteAppTableRecordRequest, **params)
        # 发起请求
        response: BatchDeleteAppTableRecordResponse = await self.client.bitable.v1.app_table_record.abatch_delete(
            request)
        return response