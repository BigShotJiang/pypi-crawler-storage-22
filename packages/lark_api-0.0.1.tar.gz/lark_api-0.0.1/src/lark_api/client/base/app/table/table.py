from lark_oapi.api.bitable.v1.model.delete_app_table_request_body import DeleteAppTableRequestBody
from lark_oapi.api.bitable.v1.model.list_app_table_request_body import ListAppTableRequestBody

from .view import *
from .record import *
from .field import *
from .form import *


def get_all_params():
    """在函数内部调用，获取所有传入的参数"""
    frame = inspect.currentframe().f_back  # 获取调用者的帧
    args, _, _, values = inspect.getargvalues(frame)

    params = {}
    for arg in args:
        if arg != 'self':  # 排除 self 参数
            params[arg] = values[arg]
    return params


class Table:
    app_token = None
    table_id = None

    def __init__(self, client: lark.Client, app_token: str = None, table_id: str = None) -> None:
        self.client = client
        self.app_token = app_token
        self.table_id = table_id

        self.view = View(client=self.client, app_token=self.app_token, table_id=self.table_id)
        self.record = Record(client=self.client, app_token=self.app_token, table_id=self.table_id)
        self.field = Field(client=self.client, app_token=self.app_token, table_id=self.table_id)

    def form(self, form_id: str = None) -> Form:
        return Form(client=self.client, app_token=self.app_token, table_id=self.table_id, form_id=form_id)

    def _general_request(self, request_class, **kwargs):
        # 构造请求对象
        request = request_class.builder()
        for k, v in kwargs.items():
            if v:
                getattr(request, k)(v)
        request = request.build()
        return request

    def _fill_default_params(self, params: dict) -> dict:
        """填充默认的 app_token 和 table_id"""
        if not params.get('app_token'):
            params['app_token'] = self.app_token
        if not params.get('table_id'):
            params['table_id'] = self.table_id
        return params

    def create(self, request_body: CreateAppTableRequestBody, app_token: str = None) -> CreateAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableRequest, **params)
        # 发起请求
        response: CreateAppTableResponse = self.client.bitable.v1.app_table.create(request)
        return response

    async def acreate(self, request_body: CreateAppTableRequestBody, app_token: str = None) -> CreateAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableRequest, **params)
        # 发起请求
        response: CreateAppTableResponse = await self.client.bitable.v1.app_table.acreate(request)
        return response

    def batch_create(self, request_body: BatchCreateAppTableRequestBody,
                     app_token: str = None) -> BatchCreateAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchCreateAppTableRequest, **params)
        # 发起请求
        response: BatchCreateAppTableResponse = self.client.bitable.v1.app_table.batch_create(request)
        return response

    async def abatch_create(self, request_body: BatchCreateAppTableRequestBody,
                            app_token: str = None) -> BatchCreateAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchCreateAppTableRequest, **params)
        # 发起请求
        response: BatchCreateAppTableResponse = await self.client.bitable.v1.app_table.abatch_create(request)
        return response

    def patch(self, request_body: PatchAppTableRequestBody, app_token: str = None,
              table_id: str = None) -> PatchAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableRequest, **params)
        # 发起请求
        response: PatchAppTableResponse = self.client.bitable.v1.app_table.patch(request)
        return response

    async def apatch(self, request_body: PatchAppTableRequestBody, app_token: str = None,
                     table_id: str = None) -> PatchAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableRequest, **params)
        # 发起请求
        response: PatchAppTableResponse = await self.client.bitable.v1.app_table.apatch(request)
        return response

    def list(self, app_token: str = None, page_size: int = 20, page_token: str = None) -> ListAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableRequest, **params)
        # 发起请求
        response: ListAppTableResponse = self.client.bitable.v1.app_table.list(request)
        return response

    async def alist(self, app_token: str = None, page_size: int = 20, page_token: str = None) -> ListAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableRequest, **params)
        # 发起请求
        response: ListAppTableResponse = await self.client.bitable.v1.app_table.alist(request)
        return response

    def delete(self, app_token: str = None, table_id: str = None) -> DeleteAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableRequest, **params)
        # 发起请求
        response: DeleteAppTableResponse = self.client.bitable.v1.app_table.delete(request)
        return response

    async def adelete(self, app_token: str = None, table_id: str = None) -> DeleteAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableRequest, **params)
        # 发起请求
        response: DeleteAppTableResponse = await self.client.bitable.v1.app_table.adelete(request)
        return response

    def batch_delete(self, request_body: BatchDeleteAppTableRequestBody,
                     app_token: str = None) -> BatchDeleteAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchDeleteAppTableRequest, **params)
        # 发起请求
        response: BatchDeleteAppTableResponse = self.client.bitable.v1.app_table.batch_delete(request)
        return response

    async def abatch_delete(self, request_body: BatchDeleteAppTableRequestBody,
                            app_token: str = None) -> BatchDeleteAppTableResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=BatchDeleteAppTableRequest, **params)
        # 发起请求
        response: BatchDeleteAppTableResponse = await self.client.bitable.v1.app_table.abatch_delete(request)
        return response
