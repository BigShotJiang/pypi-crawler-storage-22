import inspect
import lark_oapi as lark
from lark_oapi.api.bitable.v1 import *
from lark_oapi.api.bitable.v1.model.delete_app_table_view_request_body import DeleteAppTableViewRequestBody
from lark_oapi.api.bitable.v1.model.get_app_table_view_request_body import GetAppTableViewRequestBody
from lark_oapi.api.bitable.v1.model.list_app_table_view_request_body import ListAppTableViewRequestBody


def get_all_params():
    """在函数内部调用，获取所有传入的参数"""
    frame = inspect.currentframe().f_back  # 获取调用者的帧
    args, _, _, values = inspect.getargvalues(frame)

    params = {}
    for arg in args:
        if arg != 'self':  # 排除 self 参数
            params[arg] = values[arg]
    return params


class View:
    def __init__(self, client: lark.Client, app_token: str = None, table_id: str = None) -> None:
        self.client = client
        self.app_token = app_token
        self.table_id = table_id

    def _general_request(self, request_class, **kwargs):
        # 构造请求对象
        request = request_class.builder()
        for k, v in kwargs.items():
            if v:
                getattr(request, k)(v)
        request = request.build()
        return request

    def _fill_default_params(self, params: dict) -> dict:
        """填充默认的 app_token 和 table_id"""
        if not params.get('app_token'):
            params['app_token'] = self.app_token
        if not params.get('table_id'):
            params['table_id'] = self.table_id
        return params

    def create(self, request_body: ReqView, app_token: str = None,
               table_id: str = None) -> CreateAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableViewRequest, **params)
        # 发起请求
        response: CreateAppTableViewResponse = self.client.bitable.v1.app_table_view.create(request)
        return response

    async def acreate(self, request_body: ReqView, app_token: str = None,
                      table_id: str = None) -> CreateAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=CreateAppTableViewRequest, **params)
        # 发起请求
        response: CreateAppTableViewResponse = await self.client.bitable.v1.app_table_view.acreate(request)
        return response

    def patch(self, view_id: str, request_body: PatchAppTableViewRequestBody, app_token: str = None,
              table_id: str = None) -> PatchAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableViewRequest, **params)
        # 发起请求
        response: PatchAppTableViewResponse = self.client.bitable.v1.app_table_view.patch(request)
        return response

    async def apatch(self, view_id: str, request_body: PatchAppTableViewRequestBody, app_token: str = None,
                     table_id: str = None) -> PatchAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        request = self._general_request(request_class=PatchAppTableViewRequest, **params)
        # 发起请求
        response: PatchAppTableViewResponse = await self.client.bitable.v1.app_table_view.apatch(request)
        return response

    def list(self, app_token: str = None, table_id: str = None) -> ListAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableViewRequest, **params)
        # 发起请求
        response: ListAppTableViewResponse = self.client.bitable.v1.app_table_view.list(request)
        return response

    async def alist(self, app_token: str = None, table_id: str = None) -> ListAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = ListAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=ListAppTableViewRequest, **params)
        # 发起请求
        response: ListAppTableViewResponse = await self.client.bitable.v1.app_table_view.alist(request)
        return response

    def get(self, view_id: str, app_token: str = None, table_id: str = None) -> GetAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = GetAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=GetAppTableViewRequest, **params)
        # 发起请求
        response: GetAppTableViewResponse = self.client.bitable.v1.app_table_view.get(request)
        return response

    async def aget(self, view_id: str, app_token: str = None, table_id: str = None) -> GetAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = GetAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=GetAppTableViewRequest, **params)
        # 发起请求
        response: GetAppTableViewResponse = await self.client.bitable.v1.app_table_view.aget(request)
        return response

    def delete(self, view_id: str, app_token: str = None, table_id: str = None) -> DeleteAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableViewRequest, **params)
        # 发起请求
        response: DeleteAppTableViewResponse = self.client.bitable.v1.app_table_view.delete(request)
        return response

    async def adelete(self, view_id: str, app_token: str = None, table_id: str = None) -> DeleteAppTableViewResponse:
        params = get_all_params()
        params = self._fill_default_params(params)
        params['request_body'] = DeleteAppTableViewRequestBody.builder().build()
        request = self._general_request(request_class=DeleteAppTableViewRequest, **params)
        # 发起请求
        response: DeleteAppTableViewResponse = await self.client.bitable.v1.app_table_view.adelete(request)
        return response
