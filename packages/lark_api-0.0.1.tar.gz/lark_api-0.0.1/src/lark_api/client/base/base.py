import lark_oapi as lark
from .app import *


class Base:
    def __init__(self, client: lark.Client) -> None:
        self.client = client

    def app(self,app_token:str=None):
        return App(client=self.client,app_token=app_token)
