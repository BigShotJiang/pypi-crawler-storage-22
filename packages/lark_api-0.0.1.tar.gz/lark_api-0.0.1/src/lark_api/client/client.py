import lark_oapi as lark

from .base import Base


class Client:
    app_id = None
    app_secret = None
    client = None

    def __init__(self, app_id: str = None, app_secret: str = None) -> None:
        if app_id:
            self.app_id = app_id
        if app_secret:
            self.app_secret = app_secret
        self.build()
        self.base = Base(client=self.client)

    def build(self) -> None:
        client_builder = lark.Client.builder()
        client_builder.app_id(self.app_id)
        client_builder.app_secret(self.app_secret)
        client_builder.log_level(lark.LogLevel.INFO)
        self.client = client_builder.build()
