from setuptools import setup, find_packages

setup(
    name='lark_api',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
        'lark_oapi',
    ],
)