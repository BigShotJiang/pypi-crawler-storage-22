# primecheck

A lightweight Python library to check whether a number is prime.

## Installation
```bash
pip install larprime
