
from setuptools import setup, find_packages

setup(
    name="larprime",
    version="1.0.0",
    author="nimalpranav",
    author_email="codesanimalpranav@email.com",
    description="Simple Python library to check prime numbers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.6",
)
