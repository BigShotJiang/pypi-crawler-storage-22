"""
LASER ASD - Lip Landmark Assisted Speaker Detection

A PyTorch implementation of LASER ASD for Active Speaker Detection.

Original repository: https://github.com/plnguyen2908/LASER_ASD
"""

from .wrapper import LaserASDModel, create_laser_model

__version__ = "0.1.1"
__all__ = ["LaserASDModel", "create_laser_model", "__version__"]
