"""LASER ASD utilities"""
