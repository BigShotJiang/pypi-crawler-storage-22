Name reserved for security reasons.
LaserSell is not distributed via this registry.
Official downloads and documentation:
https://dl.lasersell.io
