MESSAGE = "Name reserved for security reasons.\nLaserSell is not distributed via this registry.\nOfficial downloads and documentation:\nhttps://dl.lasersell.io"
raise RuntimeError(MESSAGE)
