"""Top-level package for latdraw."""

__author__ = """Stuart Derek Walker"""
__email__ = "stuart.walker@desy.de"
__version__ = "0.3.1"


from .latdraw import draw, draw_survey
from latdraw.plot import (
    plot_optics,
    subplots_with_lattice,
    two_axes_figure,
)
from latdraw.convert import from_ocelot
from . import optics
from . import latdraw

__all__ = [
    "latdraw",
    "plot_optics",
    "draw",
    "draw_survey",
    "optics",
    "subplots_with_lattice",
    "two_axes_figure",
    "from_ocelot",
]
