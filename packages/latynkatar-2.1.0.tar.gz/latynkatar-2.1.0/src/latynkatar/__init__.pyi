from .latynkatar import convert as convert, convert_latin as convert_latin, convert_old as convert_old

__all__ = ['convert', 'convert_old', 'convert_latin']
