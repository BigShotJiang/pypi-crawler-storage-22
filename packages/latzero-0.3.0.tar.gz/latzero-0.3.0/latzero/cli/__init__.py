"""
latzero.cli - Command-line interface.
"""

from .main import main

__all__ = ['main']
