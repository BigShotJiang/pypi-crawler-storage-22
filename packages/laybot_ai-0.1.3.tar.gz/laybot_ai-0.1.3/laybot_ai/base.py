# base.py
from __future__ import annotations
from typing import Any, Dict, Tuple

def flatten_vendor_extra(body: Dict[str, Any]) -> Dict[str, Any]:
    extra = body.get("vendor_extra")
    if isinstance(extra, dict):
        body = {**body, **extra}
        body.pop("vendor_extra", None)
    return body

def looks_like_laybot(base: str) -> bool:
    return "api.laybot.cn" in (base or "")

class Base:
    """
    PHP SDK Base::ready 的 Python 同构实现：
    - vendor_extra flatten
    - endpoint 覆盖
    - LayBot 自动注入 capability；直连官方自动移除 capability
    """
    def __init__(self, cli, *, is_laybot: bool):
        self.cli = cli
        self.is_laybot = is_laybot

    def ready(self, body: Dict[str, Any], cap: str, def_path: str) -> Tuple[str, Dict[str, Any]]:
        body = flatten_vendor_extra(body)

        path = body.pop("endpoint", None) or def_path

        if self.is_laybot and cap:
            body["capability"] = cap
        else:
            body.pop("capability", None)

        return path, body
