# vendor.py
from __future__ import annotations

DEFAULT = "laybot"

def _bearer(k: str) -> dict:
    return {"Authorization": f"Bearer {k}"} if k else {}

_VENDOR_TABLE: dict[str, dict] = {
    "laybot": {
        "base": "https://api.laybot.cn",
        "ep": {"chat": "/v1/chat", "embed": "/v1/chat", "doc": "/v1/doc"},
        "hdr": lambda k: {"X-API-Key": k} if k else {},
    },
    "openai": {
        "base": "https://api.openai.com",
        "ep": {"chat": "/v1/chat/completions", "embed": "/v1/embeddings"},
        "hdr": _bearer,
    },
    "deepseek": {
        "base": "https://api.deepseek.com",
        "ep": {"chat": "/chat/completions", "embed": "/v1/embeddings"},
        "hdr": _bearer,
    },
    "grok": {
        "base": "https://api.groq.com",
        "ep": {"chat": "/openai/v1/chat/completions", "embed": "/openai/v1/embeddings"},
        "hdr": _bearer,
    },
    "azure-openai": {
        "base": "https://{RESOURCE}.openai.azure.com",
        "ep": {
            "chat": "/openai/deployments/{DEPLOY}/chat/completions?api-version=2024-05-01-preview",
            "embed": "/openai/deployments/{DEPLOY}/embeddings?api-version=2024-05-01-preview",
        },
        "hdr": lambda k: {"api-key": k} if k else {},
    },

    # Gemini Developer API（base 可替换为代理域名）
    "gemini": {
        "base": "https://generativelanguage.googleapis.com",
        "ep": {
            "chat": "/v1beta/models/{MODEL}:generateContent",
            "chat_stream": "/v1beta/models/{MODEL}:streamGenerateContent",
        },
        # 代理可能无鉴权；有 key 时可走 header
        "hdr": lambda k: {"x-goog-api-key": k} if k else {},
        # 也可用 query ?key=
        "query_key_name": "key",
    },
}

def info(vendor: str) -> dict:
    return _VENDOR_TABLE.get(vendor, _VENDOR_TABLE[DEFAULT])

def default_base(vendor: str) -> str:
    return info(vendor)["base"]

def default_ep(vendor: str, cap: str) -> str | None:
    return info(vendor)["ep"].get(cap)

def patch_hdr(vendor: str, api_key: str) -> dict:
    hdr_fn = info(vendor).get("hdr")
    return hdr_fn(api_key) if hdr_fn else {}

def query_key_name(vendor: str) -> str:
    return info(vendor).get("query_key_name", "key")
