# ContextLayer Python SDK

> Git for AI Context - store, version, and retrieve AI context from anywhere.

## Installation

```bash
pip install layer-context
```

## Quick Start

```python
from layer_context import CL

# Initialize with your API key (find it in your ContextLayer dashboard)
cl = CL(api_key="cl_sk_...")

# Create a block
cl.create_block("system-prompt")

# Get a block handle
block = cl.block("system-prompt")

# Append context
block.append("You are a helpful assistant.")
block.append("Always respond in markdown.")

# Read the compiled context
print(block.get_context())
# Output: "You are a helpful assistant.\nAlways respond in markdown."

# Update (replace) the entire context
block.update("You are a coding assistant. Use Python examples.")

# Delete specific content
block.delete("Use Python examples.")

# Read updated context
print(block.get_context())
# Output: "You are a coding assistant."
```

## Versioning

```python
# Create a new version (version 2)
block.create_version()

# Write to version 2
block.append("Version 2 instructions here.", version=2)

# Read from version 2
print(block.get_context(version=2))

# Version 1 is still intact
print(block.get_context(version=1))
```

## Managing Blocks

```python
# List all blocks
blocks = cl.list_blocks()
for b in blocks:
    print(b["name"])

# View entry history
history = block.get_history(version=1)
for entry in history:
    print(f"{entry['action']}: {entry['content']}")
```

## API Key

1. Sign up at [get-context-layer.lovable.app](https://get-context-layer.lovable.app)
2. Create a project
3. Copy your API key from the project dashboard
4. Use it to initialize the SDK

## License

MIT
