# Context Layer

Python SDK for [ContextLayer](https://get-context-layer.lovable.app) — versioned context infrastructure for AI apps.

## Installation

```bash
pip install layer-context
```

## Quick Start

```python
from layer_context import CL

cl = CL(api_key="cl_sk_your_key_here")

# Create a block
cl.create_block("support_faq")

# Append context
cl.append("support_faq", "How do I reset my password? Go to settings > security.")
cl.append("support_faq", "How do I change my email? Go to settings > account.")

# Get compiled context
context = cl.get("support_faq")
print(context)

# Update (replaces all context)
cl.update("support_faq", "Complete new FAQ content here...")

# Delete specific content
cl.delete("support_faq", "Some text to remove")

# Create a new version
cl.create_version("support_faq")

# Work with specific versions
cl.append("support_faq", "V2 content", version=2)
context_v2 = cl.get("support_faq", version=2)

# View history
entries = cl.history("support_faq")

# List all blocks
blocks = cl.list_blocks()
```

## License

MIT
