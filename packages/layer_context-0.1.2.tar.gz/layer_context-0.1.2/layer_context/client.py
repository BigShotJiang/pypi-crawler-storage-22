"""ContextLayer Python SDK client."""

import requests
from typing import Optional, List, Dict, Any


class CLError(Exception):
    """Base exception for ContextLayer SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class Block:
    """Handle for interacting with a specific block."""

    def __init__(self, client: "CL", name: str):
        self._client = client
        self.name = name

    def append(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Append content to this block version."""
        return self._client._post(
            f"/blocks/{self.name}/append",
            {"content": content, "version": version},
        )

    def update(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Replace all context in this block version."""
        return self._client._post(
            f"/blocks/{self.name}/update",
            {"content": content, "version": version},
        )

    def delete(self, content: str, version: int = 1) -> Dict[str, Any]:
        """Delete matching content from this block version."""
        return self._client._post(
            f"/blocks/{self.name}/delete",
            {"content": content, "version": version},
        )

    def get_context(self, version: int = 1) -> str:
        """Get compiled context string for this block version."""
        data = self._client._get(
            f"/blocks/{self.name}/context", params={"version": version}
        )
        return data.get("context", "")

    def get_history(self, version: int = 1) -> List[Dict[str, Any]]:
        """Get entry history for this block version."""
        return self._client._get(
            f"/blocks/{self.name}/history", params={"version": version}
        )

    def create_version(self) -> Dict[str, Any]:
        """Create a new version of this block."""
        return self._client._post(f"/blocks/{self.name}/versions", {})

    def __repr__(self) -> str:
        return f"Block(name={self.name!r})"


class CL:
    """ContextLayer SDK client.

    Usage::

        from layer_context import CL

        cl = CL(api_key="cl_sk_your_key_here")
        cl.create_block("support_faq")
        block = cl.block("support_faq")
        block.append("How do I reset my password? Go to settings > security.")
        print(block.get_context())
    """

    DEFAULT_BASE_URL = "https://btzlqtczxsjbzuvtwamc.supabase.co/functions/v1/context-api"

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        if not api_key:
            raise CLError("API key is required")
        self._api_key = api_key
        self._base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            }
        )

    def _get(self, path: str, params: Optional[Dict] = None) -> Any:
        url = f"{self._base_url}{path}"
        resp = self._session.get(url, params=params)
        return self._handle_response(resp)

    def _post(self, path: str, body: Dict) -> Any:
        url = f"{self._base_url}{path}"
        resp = self._session.post(url, json=body)
        return self._handle_response(resp)

    @staticmethod
    def _handle_response(resp: requests.Response) -> Any:
        try:
            data = resp.json()
        except ValueError:
            raise CLError(f"Invalid response from server: {resp.text}", resp.status_code)

        if not resp.ok:
            msg = data.get("error", "Unknown error") if isinstance(data, dict) else str(data)
            raise CLError(msg, resp.status_code)

        return data

    # ── Block operations ──────────────────────────────────

    def create_block(self, name: str) -> Dict[str, Any]:
        """Create a new block in the project."""
        return self._post("/blocks", {"name": name})

    def block(self, name: str) -> Block:
        """Get a handle for an existing block."""
        return Block(self, name)

    def list_blocks(self) -> List[Dict[str, Any]]:
        """List all blocks in the project."""
        return self._get("/blocks")

    # ── Convenience shortcuts (flat API) ──────────────────

    def append(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Append content to a block."""
        return self.block(block_name).append(content, version)

    def update(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Replace all context in a block."""
        return self.block(block_name).update(content, version)

    def delete(self, block_name: str, content: str, version: int = 1) -> Dict[str, Any]:
        """Delete matching content from a block."""
        return self.block(block_name).delete(content, version)

    def get(self, block_name: str, version: int = 1) -> str:
        """Get compiled context for a block."""
        return self.block(block_name).get_context(version)

    def history(self, block_name: str, version: int = 1) -> List[Dict[str, Any]]:
        """Get entry history for a block."""
        return self.block(block_name).get_history(version)

    def create_version(self, block_name: str) -> Dict[str, Any]:
        """Create a new version of a block."""
        return self.block(block_name).create_version()