"""Auth package for lazy_ninja."""

from .base import register_auth_routes

__all__ = ["register_auth_routes"]
