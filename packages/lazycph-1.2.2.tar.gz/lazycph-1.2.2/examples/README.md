These are some example source files you can use to test LazyCPH. Just open these with LazyCPH and watch them echo stdin back.
