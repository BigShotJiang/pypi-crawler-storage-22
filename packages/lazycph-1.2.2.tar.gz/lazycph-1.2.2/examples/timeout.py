from time import sleep

sleep(8)
