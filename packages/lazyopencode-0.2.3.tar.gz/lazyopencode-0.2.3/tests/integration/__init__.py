"""Integration tests for LazyOpenCode."""
