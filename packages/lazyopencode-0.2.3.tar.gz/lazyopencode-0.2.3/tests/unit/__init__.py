"""Unit tests for LazyOpenCode."""
