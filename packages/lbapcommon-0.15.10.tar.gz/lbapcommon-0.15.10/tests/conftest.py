###############################################################################
# (c) Copyright 2024 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
import pytest


def pytest_addoption(parser):
    """Add custom command-line options for fixture management."""
    parser.addoption(
        "--update-fixtures",
        action="store_true",
        default=False,
        help="Update reference fixture files instead of comparing against them",
    )


@pytest.fixture
def update_fixtures(request):
    """Fixture that returns True if --update-fixtures was passed."""
    return request.config.getoption("--update-fixtures")
