###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""PIDGen2 resampling workflow for LbExec.

Workflow:
1. For each input file, discover all DecayTrees inside TDirectories
2. For each tree, process all track configurations (chaining outputs)
3. Merge all processed trees into the final output file

Supports two modes:
- Single-track mode: Use --sample, --dataset, --variable, etc. for one track
- Multi-track mode: Use --tracks-json for multiple tracks processed in sequence
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from LbExec.options import Options
from LbExec.utils import read_xml_file_catalog, resolve_input_files, write_summary_xml


def _parse_kernel_spec(kernel_spec: str) -> str | tuple[int, ...]:
    """Parse a kernel specification string.

    Args:
        kernel_spec: Either a named kernel (e.g., 'default', 'syst1') or
                     colon-separated integers for custom widths (e.g., '2:2:2:2').

    Returns:
        The kernel name as string, or a tuple of integers for custom widths.
    """
    if ":" in kernel_spec and all(
        part.strip().isdigit() for part in kernel_spec.split(":")
    ):
        # Custom kernel widths: "2:2:2:2" -> (2, 2, 2, 2)
        return tuple(int(x) for x in kernel_spec.split(":"))
    # Named kernel: return as-is
    return kernel_spec


def _parse_kernels_json(
    kernels_json: str,
) -> list[tuple[str | tuple[int, ...], list[int]]]:
    """Parse JSON-encoded kernels configuration.

    Args:
        kernels_json: JSON string like '[["default", [0, 1, 2, 3]], ["syst1", [0]]]'

    Returns:
        List of tuples: [(kernel_name_or_widths, seeds_list), ...]
        where kernel_name_or_widths is either a string or tuple of ints.
    """
    kernels_list = json.loads(kernels_json)
    result = []
    for kernel_spec, seeds in kernels_list:
        kernel = _parse_kernel_spec(kernel_spec)
        result.append((kernel, seeds))
    return result


def _discover_decay_trees(
    input_file: str, tree_pattern: str = r".*/DecayTree"
) -> list[str]:
    """Discover all DecayTrees in TDirectories within a ROOT file.

    Args:
        input_file: Path to the ROOT file
        tree_pattern: Regex pattern to match tree paths (default: any DecayTree)

    Returns:
        List of tree paths (e.g., ["TupleName/DecayTree", ...])
    """
    import uproot  # type: ignore[import-untyped]

    trees = []
    pattern = re.compile(tree_pattern)

    with uproot.open(input_file) as f:
        for key in f.keys():
            # Keys come as "name;cycle", strip the cycle number
            key_name = key.split(";")[0]
            if pattern.match(key_name):
                trees.append(key_name)

    return sorted(trees)


def resample(options: Options, *extra_args):
    """Resample PID variables using PIDGen2.

    This workflow:
    1. Discovers all DecayTrees in each input file
    2. For each tree, processes all track configurations (chaining)
    3. Merges all outputs into the final output file
    """
    parser = argparse.ArgumentParser(
        description="PIDGen2 resampling",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Single-track arguments (used when --tracks-json is not provided)
    parser.add_argument("--sample", help="Calibration sample name")
    parser.add_argument("--dataset", help="Dataset name (polarity_year)")
    parser.add_argument("--variable", help="Variable to resample")
    parser.add_argument("--branches", default="pt:eta:ntr", help="Input branches")
    parser.add_argument("--pidgen", default="pidgen", help="Output PID variable name")
    parser.add_argument("--stat", default="pidstat", help="Statistics variable name")

    # Multi-track mode: JSON array of track configurations
    parser.add_argument(
        "--tracks-json",
        default=None,
        help=(
            "JSON array of track configs, each with: sample, dataset, variable, "
            "branches, pidgen, stat."
        ),
    )

    # Tree discovery options
    parser.add_argument(
        "--input-tree",
        default=None,
        help="Specific input tree path (if None, auto-discover all DecayTrees)",
    )
    parser.add_argument(
        "--tree-pattern",
        default=r".*/DecayTree",
        help="Regex pattern for auto-discovering trees",
    )
    parser.add_argument(
        "--outtree",
        default=None,
        help="Output tree name (if None, preserves input tree path structure)",
    )

    # Shared arguments (apply to all tracks)
    parser.add_argument("--library", default="ak", help="Library to use")
    parser.add_argument(
        "--local_storage", default="/eos/lhcb/wg/PID/PIDGen2/templates/"
    )
    parser.add_argument(
        "--global_storage",
        default="root://eoslhcb.cern.ch//eos/lhcb/wg/PID/PIDGen2/templates/",
    )
    parser.add_argument("--cachedir", default=None, help="Cache directory")

    # Integer arguments
    parser.add_argument("--resampling_seed", type=int, default=10000)
    parser.add_argument("--maxfiles", type=int, default=0)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--stop", type=int, default=-1)
    parser.add_argument("--step_size", type=int, default=50000)

    # Float arguments
    parser.add_argument("--nan", type=float, default=-1000.0)

    # Boolean flags
    parser.add_argument("--usecache", action="store_true")
    parser.add_argument("--eta_from_p", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--parabolic", action="store_true")

    # Kernel arguments
    parser.add_argument(
        "--kernels",
        action="append",
        default=None,
        help="Simple kernel names (can be specified multiple times)",
    )
    parser.add_argument(
        "--kernels-json",
        default=None,
        help="JSON-encoded kernels with seeds",
    )
    parser.add_argument("--scale", default=None, help="Scale factors (comma-separated)")

    args = parser.parse_args(extra_args)

    # Convert scale from comma-separated string to list of floats if provided
    scale = None
    if args.scale is not None:
        scale = [float(x) for x in args.scale.split(",")]

    # Process kernels
    kernels = None
    if args.kernels_json is not None:
        kernels = _parse_kernels_json(args.kernels_json)
    elif args.kernels is not None:
        kernels = [(_parse_kernel_spec(k), [0]) for k in args.kernels]

    # Build list of track configurations
    if args.tracks_json is not None:
        tracks = json.loads(args.tracks_json)
    else:
        if not all([args.sample, args.dataset, args.variable]):
            parser.error(
                "Either --tracks-json or all of --sample, --dataset, --variable "
                "are required"
            )
        tracks = [
            {
                "sample": args.sample,
                "dataset": args.dataset,
                "variable": args.variable,
                "branches": args.branches,
                "pidgen": args.pidgen,
                "stat": args.stat,
            }
        ]

    # Import dependencies
    from pidgen2.resample import (  # type: ignore[import-not-found]  # noqa: E501  # pylint: disable=import-error
        resample as pidgen2_resample,
    )

    # Resolve input files
    input_files = options.input_files
    if options.xml_file_catalog:
        file_catalog = read_xml_file_catalog(options.xml_file_catalog)
        input_files = resolve_input_files(options.input_files, file_catalog)

    # Open output file once for all trees
    import uproot  # type: ignore[import-untyped]

    print(f"\n** Creating output file: {options.output_file}")

    with uproot.recreate(
        options.output_file, compression=uproot.ZSTD(4)
    ) as final_output:
        for file_idx, input_file in enumerate(input_files):
            print(
                f"** Processing input file {file_idx + 1}/{len(input_files)}: {input_file}"
            )

            # Discover trees to process
            if args.input_tree:
                trees_to_process = [args.input_tree]
            else:
                trees_to_process = _discover_decay_trees(input_file, args.tree_pattern)
                if not trees_to_process:
                    print(
                        f"  Warning: No trees matching '{args.tree_pattern}' found in {input_file}"
                    )
                    continue
                print(f"  Found {len(trees_to_process)} trees: {trees_to_process}")

            # Process each tree in this file
            for tree_idx, input_tree in enumerate(trees_to_process):
                print(f"  -> Tree {tree_idx + 1}/{len(trees_to_process)}: {input_tree}")

                # Determine output tree name - preserve structure if not explicitly set
                output_tree = args.outtree if args.outtree is not None else input_tree

                # Input location (file:tree)
                current_input = f"{input_file}:{input_tree}"

                # Seed counter - increment for each track to ensure independence
                current_seed = args.resampling_seed + (file_idx * 100) + (tree_idx * 10)

                # Adjust stop parameter: -1 means "all events", convert to None for pidgen2
                stop_param = args.stop if args.stop > 0 else None

                # Strategy: Use friend mode for all tracks, then merge at the end
                # This avoids chaining and allows independent processing
                friend_files = []

                # Process each track independently in friend mode
                for track_idx, track in enumerate(tracks):
                    current_seed += 1

                    print(
                        f"     Track {track_idx + 1}/{len(tracks)}: "
                        f"sample={track['sample']}, branches={track['branches']}"
                    )

                    # Create friend file for this track
                    friend_output = str(
                        Path(options.output_file).with_suffix(
                            f".friend_{file_idx}_{tree_idx}_{track_idx}.root"
                        )
                    )
                    friend_files.append(friend_output)

                    # Run resampling for this track in friend mode
                    pidgen2_resample(
                        resampling_seed=current_seed,
                        input=current_input,
                        output=friend_output,
                        outtree=output_tree,
                        sample=track["sample"],
                        dataset=track["dataset"],
                        variable=track["variable"],
                        branches=track["branches"],
                        pidgen=track["pidgen"],
                        stat=track["stat"],
                        maxfiles=args.maxfiles,
                        start=args.start,
                        stop=stop_param,
                        usecache=args.usecache,
                        interactive=False,
                        kernels=kernels,
                        verbose=args.verbose,
                        friend=True,  # Force friend mode for all tracks
                        library=args.library,
                        step_size=args.step_size,
                        local_storage=args.local_storage,
                        global_storage=args.global_storage,
                        cachedir=args.cachedir,
                        eta_from_p=args.eta_from_p,
                        nan=args.nan,
                        scale=scale,
                        parabolic=args.parabolic,
                        filter_func=None,
                    )

                # Now merge the original input with all friend trees directly into final output
                print(
                    f"     Merging input + {len(friend_files)} friend trees into {output_tree}"
                )

            # Use chunked processing with parallel iteration over all files
            chunk_size = args.step_size

            # Create iterators for input and all friend files
            input_iter = uproot.iterate(
                current_input, step_size=chunk_size, library="ak"
            )
            friend_iters = [
                uproot.iterate(
                    f"{friend_file}:{output_tree}", step_size=chunk_size, library="ak"
                )
                for friend_file in friend_files
            ]

            chunk_idx = 0
            for input_chunk in input_iter:
                # Get chunk size from input
                input_len = len(input_chunk)

                if args.verbose:
                    print(
                        f"       Processing chunk {chunk_idx + 1} for merging (input: {input_len} entries)"
                    )

                # Start with input branches
                combined_chunk = {
                    name: input_chunk[name] for name in input_chunk.fields
                }

                # Add branches from each friend tree (iterate them in parallel)
                for friend_idx, friend_iter in enumerate(friend_iters):
                    try:
                        friend_chunk = next(friend_iter)
                        friend_len = len(friend_chunk)

                        # Check alignment
                        if friend_len != input_len:
                            print(
                                f"       ERROR: Chunk size mismatch at chunk {chunk_idx + 1}: "
                                f"input={input_len}, friend {friend_idx + 1}={friend_len}"
                            )
                            raise ValueError(
                                f"Chunk alignment error: input has {input_len} entries, "
                                f"friend file {friend_idx + 1} has {friend_len} entries"
                            )

                        if args.verbose:
                            print(
                                f"         Friend {friend_idx + 1}: {friend_len} entries, {len(friend_chunk.fields)} branches"
                            )

                        # Add friend branches to combined data
                        for branch_name in friend_chunk.fields:
                            combined_chunk[branch_name] = friend_chunk[branch_name]
                    except StopIteration as exc:
                        # This shouldn't happen if all files have same number of entries
                        print(
                            f"       ERROR: Friend file {friend_idx + 1} ended early at chunk {chunk_idx + 1}"
                        )
                        raise ValueError(
                            f"Friend file {friend_idx + 1} has fewer entries than input file"
                        ) from exc

                # Write this chunk directly to final output
                final_len = (
                    len(list(combined_chunk.values())[0]) if combined_chunk else 0
                )
                if args.verbose:
                    print(
                        f"         Combined chunk: {final_len} entries, {len(combined_chunk)} total branches"
                    )

                if chunk_idx == 0:
                    final_output[output_tree] = combined_chunk
                else:
                    final_output[output_tree].extend(combined_chunk)

                chunk_idx += 1

                # Clean up friend files
                for friend_file in friend_files:
                    try:
                        Path(friend_file).unlink()
                    except OSError as e:
                        print(f"     Warning: Could not delete {friend_file}: {e}")

    # All trees merged, write summary
    write_summary_xml(options, [options.output_file])
    print(f"** Completed PIDGen2 resampling -> {options.output_file}")
