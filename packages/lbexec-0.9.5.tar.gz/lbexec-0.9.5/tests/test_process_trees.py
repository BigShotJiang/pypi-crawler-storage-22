###############################################################################
# (c) Copyright 2024 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Tests for the process_trees decorator."""

import os
from pathlib import Path

import pytest
import uproot

from LbExec import process_trees
from LbExec.options import DataOptions, TupleClass

TEST_FILES_DIR = Path(__file__).parent / "test_files"
LUMI_ONLY_FILE = str(TEST_FILES_DIR / "lumi_only.root")


def test_process_trees_lumi_only_preserves_lumi_tree(tmp_path):
    """Test that lumi trees are preserved in output even when ignore_lumi_tree=True.

    When the input file contains only a lumi tree and ignore_lumi_tree=True (default),
    the lumi tree should still be copied to the output file unchanged, rather than
    being completely ignored which would result in no output.
    """
    output_file = str(tmp_path / "output.root")

    @process_trees
    def my_filter(tree_name, rdf):
        # This should not be called for lumi trees when ignore_lumi_tree=True
        return rdf

    opts = DataOptions(
        input_files=[LUMI_ONLY_FILE],
        output_file=output_file,
    )

    my_filter(opts)

    # The output file should exist
    assert os.path.exists(output_file), "Output file was not created"

    # The output file should contain the lumi tree
    with uproot.open(output_file) as rf:
        keys = [key.split(";")[0] for key in rf.keys()]
        assert (
            "GetIntegratedLuminosity/LumiTuple" in keys
        ), f"Lumi tree not found in output. Keys: {keys}"


def test_process_trees_with_data_and_lumi(tmp_path):
    """Test that both data trees and lumi trees are preserved.

    When input has both data trees and lumi trees, the data trees should be
    processed through the filter function while lumi trees are copied unchanged.
    """
    import ROOT

    # Create a test file with both data trees and lumi tree using ROOT directly
    # to avoid uproot RNTuple compatibility issues
    input_file = str(tmp_path / "input_with_data_and_lumi.root")
    output_file = str(tmp_path / "output.root")

    # Create input file with ROOT
    rf = ROOT.TFile.Open(input_file, "RECREATE")

    # Create events1/DecayTree
    rf.mkdir("events1")
    rf.cd("events1")
    tree1 = ROOT.TTree("DecayTree", "DecayTree")
    x1 = ROOT.std.vector("float")()
    tree1.Branch("x", x1)
    for i in range(10):
        x1.clear()
        x1.push_back(float(i))
        tree1.Fill()
    tree1.Write()

    # Create events2/DecayTree
    rf.cd("/")
    rf.mkdir("events2")
    rf.cd("events2")
    tree2 = ROOT.TTree("DecayTree", "DecayTree")
    x2 = ROOT.std.vector("float")()
    tree2.Branch("x", x2)
    for i in range(10):
        x2.clear()
        x2.push_back(float(i * 2))
        tree2.Fill()
    tree2.Write()

    # Create GetIntegratedLuminosity/LumiTuple
    rf.cd("/")
    rf.mkdir("GetIntegratedLuminosity")
    rf.cd("GetIntegratedLuminosity")
    lumi_tree = ROOT.TTree("LumiTuple", "LumiTuple")
    lumi_val = ROOT.std.vector("float")()
    lumi_tree.Branch("lumi", lumi_val)
    for i in range(5):
        lumi_val.clear()
        lumi_val.push_back(float(i * 100))
        lumi_tree.Fill()
    lumi_tree.Write()

    rf.Close()

    filter_called_for = []

    @process_trees
    def my_filter(tree_name, rdf):
        filter_called_for.append(tree_name)
        return rdf

    opts = DataOptions(
        input_files=[input_file],
        output_file=output_file,
    )

    my_filter(opts)

    # Filter should have been called for data trees but not lumi tree
    assert "events1/DecayTree" in filter_called_for
    assert "events2/DecayTree" in filter_called_for
    assert "GetIntegratedLuminosity/LumiTuple" not in filter_called_for

    # Output should contain all trees including lumi
    with uproot.open(output_file) as rf:
        keys = [key.split(";")[0] for key in rf.keys()]
        assert "events1/DecayTree" in keys
        assert "events2/DecayTree" in keys
        assert "GetIntegratedLuminosity/LumiTuple" in keys


def test_process_trees_ignore_lumi_tree_false(tmp_path):
    """Test that lumi trees are processed when ignore_lumi_tree=False."""
    output_file = str(tmp_path / "output.root")

    filter_called_for = []

    @process_trees(ignore_lumi_tree=False)
    def my_filter(tree_name, rdf):
        filter_called_for.append(tree_name)
        return rdf

    opts = DataOptions(
        input_files=[LUMI_ONLY_FILE],
        output_file=output_file,
    )

    my_filter(opts)

    # Filter should have been called for the lumi tree
    assert "GetIntegratedLuminosity/LumiTuple" in filter_called_for

    # Output should contain the lumi tree
    with uproot.open(output_file) as rf:
        keys = [key.split(";")[0] for key in rf.keys()]
        assert "GetIntegratedLuminosity/LumiTuple" in keys


def test_process_trees_rntuple_output(tmp_path):
    """Test that RNTuple output is created when tuple_class=RNTuple."""
    import awkward as ak
    import ROOT

    # Create input file as RNTuple using uproot (default in 5.7+)
    input_file = str(tmp_path / "input.root")
    output_file = str(tmp_path / "output.root")

    # Create RNTuple input using uproot's default (RNTuple in 5.7+)
    with uproot.recreate(input_file) as f:
        f["events/DecayTree"] = {"x": ak.Array([[float(i)] for i in range(10)])}

    @process_trees
    def my_filter(tree_name, rdf):
        return rdf

    opts = DataOptions(
        input_files=[input_file],
        output_file=output_file,
        tuple_class=TupleClass.RNTUPLE,
    )

    my_filter(opts)

    # The output file should exist and contain an RNTuple
    assert os.path.exists(output_file), "Output file was not created"

    # Verify RNTuple was created by checking with ROOT
    rntuple = ROOT.RNTupleReader.Open("events/DecayTree", output_file)
    assert rntuple is not None, "Failed to open as RNTuple"
    assert (
        rntuple.GetNEntries() == 10
    ), f"Expected 10 entries, got {rntuple.GetNEntries()}"


def test_process_trees_rntuple_with_lumi(tmp_path):
    """Test RNTuple output preserves lumi trees correctly."""
    import awkward as ak
    import ROOT

    input_file = str(tmp_path / "input_with_lumi.root")
    output_file = str(tmp_path / "output.root")

    # Create input file as RNTuple using uproot
    with uproot.recreate(input_file) as f:
        f["events/DecayTree"] = {"x": ak.Array([[float(i)] for i in range(10)])}
        f["GetIntegratedLuminosity/LumiTuple"] = {
            "lumi": ak.Array([[float(i * 100)] for i in range(5)])
        }

    filter_called_for = []

    @process_trees
    def my_filter(tree_name, rdf):
        filter_called_for.append(tree_name)
        return rdf

    opts = DataOptions(
        input_files=[input_file],
        output_file=output_file,
        tuple_class=TupleClass.RNTUPLE,
    )

    my_filter(opts)

    # Filter should have been called for data tree but not lumi tree
    assert "events/DecayTree" in filter_called_for
    assert "GetIntegratedLuminosity/LumiTuple" not in filter_called_for

    # Verify output has both as RNTuples
    data_rntuple = ROOT.RNTupleReader.Open("events/DecayTree", output_file)
    assert data_rntuple.GetNEntries() == 10

    lumi_rntuple = ROOT.RNTupleReader.Open(
        "GetIntegratedLuminosity/LumiTuple", output_file
    )
    assert lumi_rntuple.GetNEntries() == 5


def test_process_trees_rntuple_pass_all_trees(tmp_path):
    """Test RNTuple output with pass_all_trees=True."""
    import awkward as ak
    import ROOT

    input_file = str(tmp_path / "input.root")
    output_file = str(tmp_path / "output.root")

    # Create input file as RNTuple using uproot
    with uproot.recreate(input_file) as f:
        f["events1/DecayTree"] = {"x": ak.Array([[float(i)] for i in range(10)])}
        f["events2/DecayTree"] = {"x": ak.Array([[float(i * 2)] for i in range(15)])}

    @process_trees(pass_all_trees=True)
    def my_filter(tree_dict):
        return tree_dict

    opts = DataOptions(
        input_files=[input_file],
        output_file=output_file,
        tuple_class=TupleClass.RNTUPLE,
    )

    my_filter(opts)

    # Verify both trees were created as RNTuples
    rntuple1 = ROOT.RNTupleReader.Open("events1/DecayTree", output_file)
    assert rntuple1.GetNEntries() == 10

    rntuple2 = ROOT.RNTupleReader.Open("events2/DecayTree", output_file)
    assert rntuple2.GetNEntries() == 15


def test_process_trees_ttree_output_explicit(tmp_path):
    """Test that TTree output is created when tuple_class=TTree (explicit)."""
    import ROOT

    input_file = str(tmp_path / "input.root")
    output_file = str(tmp_path / "output.root")

    rf = ROOT.TFile.Open(input_file, "RECREATE")
    rf.mkdir("events")
    rf.cd("events")
    tree = ROOT.TTree("DecayTree", "DecayTree")
    x = ROOT.std.vector("float")()
    tree.Branch("x", x)
    for i in range(10):
        x.clear()
        x.push_back(float(i))
        tree.Fill()
    tree.Write()
    rf.Close()

    @process_trees
    def my_filter(tree_name, rdf):
        return rdf

    opts = DataOptions(
        input_files=[input_file],
        output_file=output_file,
        tuple_class=TupleClass.TTREE,  # Explicitly specify TTree
    )

    my_filter(opts)

    # Verify output is a TTree (not RNTuple)
    out_rf = ROOT.TFile.Open(output_file)
    events_dir = out_rf.Get("events")
    assert events_dir is not None

    tree = events_dir.Get("DecayTree")
    assert tree is not None, "TTree not found"
    assert tree.GetEntries() == 10
    assert tree.ClassName() == "TTree"
    out_rf.Close()
