# lbt-ladybug

Collection of all Ladybug core Python libraries.

Note that this Python package does not contain any code and it simply exists to
provide a shortcut for installing all of the ladybug core libraries together.
