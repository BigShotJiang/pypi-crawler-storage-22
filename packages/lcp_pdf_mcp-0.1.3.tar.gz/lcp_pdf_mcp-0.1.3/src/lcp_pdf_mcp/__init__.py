"""
PDF Tools MCP Server
提供 PDF 分割、合併功能的 MCP 伺服器
"""
__version__ = "0.1.3"