import lcp_delta.common.constants as constants

MAIN_BASE_URL = constants.MAIN_BASE_URL
SERIES_BASE_URL = constants.SERIES_BASE_URL
PUSH_SERVICE_BASE_URL = constants.PUSH_SERVICE_BASE_URL
EPEX_BASE_URL = constants.EPEX_BASE_URL
FREE_API_BASE_URL = constants.FREE_API_BASE_URL