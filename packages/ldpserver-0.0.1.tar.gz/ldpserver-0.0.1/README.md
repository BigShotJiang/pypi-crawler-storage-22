# LDP-server

A basic LDP-server implementation based on [FastAPI].

This implementation follows the [Linked Data Platform 1.0] recommendation:

>Linked Data Platform (LDP) defines a set of rules for HTTP operations on web resources, some based on RDF, to provide an architecture for read-write Linked Data on the web. 


[FastAPI]: https://github.com/fastapi/fastapi
[Linked Data Platform 1.0]: https://www.w3.org/TR/2015/REC-ldp-20150226/
