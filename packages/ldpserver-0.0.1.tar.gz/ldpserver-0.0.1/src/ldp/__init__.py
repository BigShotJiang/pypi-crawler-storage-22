from enum import StrEnum

# prefixes and namespaces defined as JSON-LD context
CONTEXT = {
    "dcterms": "http://purl.org/dc/terms/",
    "ldp": "http://www.w3.org/ns/ldp#",
}


class ResourceType(StrEnum):
    RESOURCE = "ldp:Resource"
    CONTAINER = "ldp:Container"
    BASIC_CONTAINER = "ldp:BasicContainer"
    DIRECT_CONTAINER = "ldp:DirectContainer"
    INDIRECT_CONTAINER = "ldp:IndirectContainer"
