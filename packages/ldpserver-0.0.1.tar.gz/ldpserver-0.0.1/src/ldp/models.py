from logging import getLogger

from pydantic import BaseModel, Field, ConfigDict

from ldp import CONTEXT, ResourceType

logger = getLogger(__name__)


class Resource(BaseModel):
    # store any additional data in the __pydantic_extra__ dict
    model_config = ConfigDict(extra="allow")

    uri: str = Field(alias="@id")
    resource_types: list[ResourceType] = Field(alias="@type")
    context: dict = Field(alias="@context", default=CONTEXT)


class Container(Resource):
    contains: list | dict = Field(alias="ldp:contains")
