from pathlib import Path
from typing import Dict, Any, Optional

from leaf_publisher.toml_utils import load_toml

TOOL_CONFIG_SECTION = "tool.leaf-publisher"


def load_project_pyproject(project_dir: Path) -> Optional[Dict[str, Any]]:
    """加载项目根目录下的 pyproject.toml，若不存在返回 None"""
    pyproject_path = project_dir / 'pyproject.toml'
    if not pyproject_path.exists():
        return None
    return load_toml(pyproject_path)


def get_publisher_config(pyproject_data: Dict[str, Any]) -> Dict[str, Any]:
    """从 pyproject 字典中提取 [tool.leaf-publisher] 配置"""
    tool = pyproject_data.get("tool", {})
    return tool.get("leaf-publisher", {}).copy()