import sys
from typing import Set

# Python 3.10 以下版本的内置模块备用列表
FALLBACK_STDLIB_MODULES: Set[str] = {
    'string', 're', 'difflib', 'textwrap', 'unicodedata', 'stringprep', 'readline', 'rlcompleter', 'struct',
    'codecs', 'datetime', 'calendar', 'collections', 'heapq', 'bisect', 'array', 'weakref', 'types', 'copy',
    'pprint', 'reprlib', 'enum', 'numbers', 'math', 'cmath', 'decimal', 'fractions', 'random', 'statistics',
    'itertools', 'functools', 'operator', 'pathlib', 'fileinput', 'stat', 'filecmp', 'tempfile', 'glob',
    'fnmatch', 'linecache', 'shutil', 'macpath', 'pickle', 'copyreg', 'shelve', 'marshal', 'dbm', 'sqlite3',
    'zlib', 'gzip', 'bz2', 'lzma', 'zipfile', 'tarfile', 'csv', 'configparser', 'netrc', 'xdrlib', 'plistlib',
    'hashlib', 'hmac', 'secrets', 'os', 'io', 'time', 'argparse', 'getopt', 'logging', 'getpass', 'curses',
    'platform', 'errno', 'ctypes', 'threading', 'multiprocessing', 'concurrent', 'subprocess', 'sched',
    'queue', '_thread', '_dummy_thread', 'dummy_threading', 'contextvars', 'asyncio', 'socket', 'ssl',
    'select', 'selectors', 'asyncore', 'asynchat', 'signal', 'mmap', 'email', 'json', 'mailcap', 'mailbox',
    'mimetypes', 'base64', 'binhex', 'binascii', 'quopri', 'uu', 'html', 'xml', 'webbrowser', 'cgi', 'cgitb',
    'wsgiref', 'urllib', 'http', 'ftplib', 'poplib', 'imaplib', 'nntplib', 'smtplib', 'smtpd', 'telnetlib',
    'uuid', 'socketserver', 'xmlrpc', 'ipaddress', 'audioop', 'aifc', 'sunau', 'wave', 'chunk', 'colorsys',
    'imghdr', 'sndhdr', 'ossaudiodev', 'gettext', 'locale', 'turtle', 'cmd', 'shlex', 'tkinter', 'typing',
    'pydoc', 'doctest', 'unittest', '2to3', 'test', 'bdb', 'faulthandler', 'pdb', 'timeit', 'trace',
    'tracemalloc', 'distutils', 'ensurepip', 'venv', 'zipapp', 'sys', 'sysconfig', 'builtins', '__main__',
    'warnings', 'dataclasses', 'contextlib', 'abc', 'atexit', 'traceback', '__future__', 'gc', 'inspect',
    'site', 'code', 'codeop', 'zipimport', 'pkgutil', 'modulefinder', 'runpy', 'importlib', 'parser', 'ast',
    'symtable', 'symbol', 'token', 'keyword', 'tokenize', 'tabnanny', 'pyclbr', 'py_compile', 'compileall',
    'dis', 'pickletools', 'formatter', 'msilib', 'msvcrt', 'winreg', 'winsound', 'posix', 'pwd', 'spwd', 'grp',
    'crypt', 'termios', 'tty', 'pty', 'fcntl', 'pipes', 'resource', 'nis', 'optparse', 'imp'
}


def get_stdlib_modules() -> Set[str]:
    """
    返回当前 Python 版本的标准库模块名集合。
    Python 3.10+ 使用 sys.stdlib_module_names，否则使用备用列表。
    """
    if hasattr(sys, 'stdlib_module_names'):
        return sys.stdlib_module_names
    return FALLBACK_STDLIB_MODULES