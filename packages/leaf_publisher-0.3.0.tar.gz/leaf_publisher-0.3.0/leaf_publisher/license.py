import shutil
from datetime import datetime
from pathlib import Path

from leaf_publisher.git_utils import get_git_config


def get_license_templates_dir() -> Path:
    """返回许可证模板目录路径"""
    return Path(__file__).parent / 'data' / 'licenses'


def list_available_licenses() -> list:
    """列出可用的许可证ID（不含扩展名）"""
    templates_dir = get_license_templates_dir()
    if not templates_dir.exists():
        return []
    return [f.stem for f in templates_dir.glob('*.txt')]


def write_license(project_dir: Path, license_id: str = None, license_file: Path = None) -> bool:
    """
    生成 LICENSE 文件到项目根目录。
    如果指定 license_file，直接复制该文件。
    否则根据 license_id 从模板生成。
    返回是否成功。
    """
    if license_file:
        src = Path(license_file)
        if not src.exists():
            print(f"❌ 许可证文件不存在：{src}")
            return False
        dst = project_dir / 'LICENSE'
        shutil.copy2(src, dst)
        print(f"✅ 已复制许可证文件到 {dst}")
        return True

    if license_id:
        templates_dir = get_license_templates_dir()
        template_path = templates_dir / f"{license_id}.txt"
        if not template_path.exists():
            available = ', '.join(list_available_licenses())
            print(f"❌ 未知许可证 ID: {license_id}。可用: {available}")
            return False
        # 读取模板，替换占位符
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        year = str(datetime.now().year)
        fullname = get_git_config('user.name') or input("请输入作者姓名用于许可证: ").strip()
        content = content.replace('[year]', year).replace('[fullname]', fullname)
        dst = project_dir / 'LICENSE'
        with open(dst, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 已生成 {license_id} 许可证文件到 {dst}")
        return True

    return False