# SSH

This directory contains the public and private SSH keys that provide access to the Docker container over SSH when debugging with Rider. These keys come from [phusion/baseimage-docker](https://github.com/phusion/baseimage-docker/tree/master/image/services/sshd/keys).
