"""Lean declaration extraction and processing tools.

This package contains modules for extracting, parsing, and enriching
Lean mathematical declarations from documentation files.
"""
