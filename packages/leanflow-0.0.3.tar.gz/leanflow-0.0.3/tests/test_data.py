# ===========================================================================
# TypeCheck Test Data
# ===========================================================================

TYPECHECK_DATA = {
    "pass_with_mathlib": {
        "statement1": """abbrev conjecture : Prop := True
theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "header": "import Mathlib",
        "expected": True,
        "description": "Valid Lean code with Mathlib import should typecheck",
    },
    "fail_without_mathlib": {
        "statement1": """abbrev conjecture : Prop := True
theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "header": None,
        "expected": False,
        "description": "Lean code requiring Mathlib should fail without import",
    },
}

# ===========================================================================
# BEq_plus Test Data
# ===========================================================================

BEQ_PLUS_DATA = {
    "fail_different_statements": {
        "statement1": """theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "statement2": """theorem brualdi_ch12_34
  (V : Type) [Fintype V]
  (G : SimpleGraph V)
 (X : SimpleGraph V)
  : (disconnected G → connected (complement G)) ↔ conjecture :=
sorry""",
        "header": """import Mathlib
abbrev conjecture : Prop := True""",
        "expected": False,
        "description": "Different statements should not be behaviorally equivalent",
    },
    "pass_same_statement": {
        "statement1": """theorem logic_base (p q : Prop) : ¬(p ∨ q) ↔ ¬p ∧ ¬q := by sorry""",
    "statement2": """theorem logic_var (p q : Prop) : ¬p ∧ ¬q ↔ ¬(q ∨ p) := by sorry""",
        "header": """import Mathlib""",
        "expected": True,
        "description": "Same statement should be behaviorally equivalent",
    },
}

# ===========================================================================
# BEq_l Test Data
# ===========================================================================

BEQ_L_DATA = {
    "fail_different_statements": {
        "statement1": """theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "statement2": """theorem brualdi_ch12_34
  (V : Type) [Fintype V]
  (G : SimpleGraph V)
 (X : SimpleGraph V)
  : (disconnected G → connected (complement G)) ↔ conjecture :=
sorry""",
        "header": """import Mathlib
abbrev conjecture : Prop := True""",
        "expected": False,
        "description": "Different statements should not be logically equivalent",
    },
    "pass_same_statement": {
        "statement1": """theorem brualdi_ch8_9 (h : ℕ → ℤ) (k n : ℕ): (fwdDiff 1)^[k] h n = ∑ j ∈ Finset.range (k + 1),
    (-1 : ℤ) ^ (k - j) * Nat.choose k j * h (n + j) := by sorry""",
        "statement2": """theorem brualdi_ch8_9 (h : ℕ → ℤ) (k n : ℕ): (fwdDiff 1)^[k] h n = ∑ j ∈ Finset.range (k + 1 + 0),
    (-1 : ℤ) ^ (k - j) * Nat.choose k j * h (n + j + 0) := by sorry""",
        "header": """import Mathlib""",
        "expected": True,
        "description": "Same statement should be logically equivalent",
    },
}

# ===========================================================================
# BEq Test Data (vLLM-based batch metric with multiprocessing)
# ===========================================================================

BEQ_DATA = {
    "fail_different_statements": {
        "formal_statement": """theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "formal_statement_generated": """theorem brualdi_ch12_34
  (V : Type) [Fintype V]
  (G : SimpleGraph V)
 (X : SimpleGraph V)
  : (disconnected G → connected (complement G)) ↔ conjecture :=
sorry""",
        "header": """import Mathlib
abbrev conjecture : Prop := True""",
        "expected": False,
        "description": "Different statements should not be behaviorally equivalent",
    },
    "pass_same_statement": {
        "formal_statement": """theorem brualdi_ch8_9 (h : ℕ → ℤ) (k n : ℕ): (fwdDiff 1)^[k] h n = ∑ j ∈ Finset.range (k + 1),
    (-1 : ℤ) ^ (k - j) * Nat.choose k j * h (n + j) := by sorry""",
        "formal_statement_generated": """theorem brualdi_ch8_9_variant (h : ℕ → ℤ) (k n : ℕ) : 
  (fwdDiff 1)^[k] h n = ∑ i ∈ Finset.range (k + 1), 
    (-1 : ℤ) ^ i * Nat.choose k i * h (n + k - i) := by sorry""",
        "header": """import Mathlib""",
        "expected": True,
        "description": "Same statement should be behaviorally equivalent",
    },
}

# ===========================================================================
# EquivRfl Test Data
# ===========================================================================

EQUIV_RFL_DATA = {
    "pass_equivalent_conjectures": {
        "conjecture1": "abbrev conjecture : Nat := 18",
        "conjecture2": "abbrev conjecture : Nat := 2*9",
        "expected": True,
        "description": "Identical conjectures should be equivalent by reflection",
    },
    "fail_different_conjectures": {
        "conjecture1": "abbrev conjecture : Nat := 18",
        "conjecture2": "abbrev conjecture : Nat := 3/2",
        "expected": False,
        "description": "Different conjectures should not be equivalent",
    },
}

# ===========================================================================
# ConJudge Test Data (LLM-as-a-judge)
# ===========================================================================

CONJUDGE_DATA = {
    "pass_correct_conjecture": {
        "formal_conjecture": "abbrev conjecture : Nat := 18",
        "formal_statement": """abbrev conjecture : Nat := 18
theorem putnam_1986_a1
    (S : Set ℝ) (f : ℝ → ℝ)
    (hS : S = {x : ℝ | x ^ 4 + 36 ≤ 13 * x ^ 2})
    (hf : f = fun x ↦ x ^ 3 - 3 * x) :
    IsGreatest
    {f x | x ∈ S}
    conjecture :=
  sorry""",
        "formal_statement_generated": """theorem putnam_1986_a1
  (f : ℝ → ℝ := λ x => x^3 - 3 * x)
  (constraint : ℝ → Prop := λ x => x^4 + 36 ≤ 13 * x^2)
  : IsGreatest {y | ∃ x : ℝ, constraint x ∧ f x = y} = 10 + 8 :=
sorry""",
        "expected": True,
        "description": "Generated statement contains correct conjecture value (18 = 10 + 8) - may fail with weak LLM",
    },
    "fail_incorrect_conjecture": {
        "formal_conjecture": "abbrev conjecture : Nat := 18",
        "formal_statement": """abbrev conjecture : Nat := 18
theorem putnam_1986_a1
    (S : Set ℝ) (f : ℝ → ℝ)
    (hS : S = {x : ℝ | x ^ 4 + 36 ≤ 13 * x ^ 2})
    (hf : f = fun x ↦ x ^ 3 - 3 * x) :
    IsGreatest
    {f x | x ∈ S}
    conjecture :=
  sorry""",
        "formal_statement_generated": """theorem putnam_1986_a1
  (f : ℝ → ℝ := λ x => x^3 - 3 * x)
  (constraint : ℝ → Prop := λ x => x^4 + 36 ≤ 13 * x^2)
  : IsGreatest {y | ∃ x : ℝ, constraint x ∧ f x = y} = 6*2 :=
sorry""",
        "expected": False,
        "description": "Generated statement has incorrect conjecture (6*2 = 12 ≠ 18) - may fail with weak LLM",
    },
}

# ===========================================================================
# LLMGrader Test Data (LLM-as-a-judge)
# ===========================================================================

LLM_GRADER_DATA = {
    "fail_different_statements": {
        "statement1": """theorem brualdi_ch12_34 {V : Type*} (G : SimpleGraph V) (h : ¬ G.Connected) :
    Gᶜ.Connected ↔ conjecture := by sorry""",
        "statement2": """theorem brualdi_ch12_34
  (V : Type) [Fintype V]
  (G : SimpleGraph V)
 (X : SimpleGraph V)
  : (disconnected G → connected (complement G)) ↔ conjecture :=
sorry""",
        "header": """import Mathlib
abbrev conjecture : Prop := True""",
        "expected": False,
        "description": "Different statements should not be behaviorally equivalent",
    },
    "pass_same_statement": {
        "statement1": """theorem brualdi_ch8_9 (h : ℕ → ℤ) (k n : ℕ): (fwdDiff 1)^[k] h n = ∑ j ∈ Finset.range (k + 1),
    (-1 : ℤ) ^ (k - j) * Nat.choose k j * h (n + j) := by sorry""",
        "statement2": """theorem brualdi_ch8_9_variant (h : ℕ → ℤ) (k n : ℕ) : 
  (fwdDiff 1)^[k] h n = ∑ i ∈ Finset.range (k + 1), 
    (-1 : ℤ) ^ i * Nat.choose k i * h (n + k - i) := by sorry""",
        "header": """import Mathlib""",
        "expected": True,
        "description": "Same statement should be behaviorally equivalent",
    },
}

# ===========================================================================
# REPL Test Data
# ===========================================================================

REPL_TEST_COMMANDS = {
    "simple_check": {
        "command": "#check 1 + 1",
        "should_succeed": True,
        "description": "Simple arithmetic check",
    },
    "with_mathlib": {
        "command": "#check Nat.add_comm",
        "header": "import Mathlib",
        "should_succeed": True,
        "description": "Check Mathlib theorem",
    },
    "tactic_proof": {
        "theorem": "theorem test_theorem : True := by trivial",
        "header": "import Mathlib",
        "should_succeed": True,
        "description": "Simple tactic mode proof",
    },
}
