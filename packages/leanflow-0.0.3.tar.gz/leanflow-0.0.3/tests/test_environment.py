import pytest
from pathlib import Path

from leanflow import EnvironmentManager


@pytest.mark.slow
def test_download_default_version(lean_version):
    """Test downloading the default Lean version."""
    config = {"lean_version": lean_version}
    manager = EnvironmentManager(config)
    
    resolved = manager.resolve_config()
    
    assert "project_path" in resolved
    assert "repl_path" in resolved
    assert Path(resolved["project_path"]).exists()
    assert Path(resolved["repl_path"]).exists()


@pytest.mark.slow
def test_download_alternate_version(alternate_lean_version):
    """Test downloading an alternate Lean version (v4.18.0)."""
    config = {"lean_version": alternate_lean_version}
    manager = EnvironmentManager(config)
    
    resolved = manager.resolve_config()
    
    assert "project_path" in resolved
    assert "repl_path" in resolved
    assert Path(resolved["project_path"]).exists()
    assert Path(resolved["repl_path"]).exists()
    # Verify it's the correct version by checking the path
    assert alternate_lean_version in resolved["repl_path"]


def test_environment_reuse(lean_version):
    """Test that cached environments are reused."""
    config = {"lean_version": lean_version}
    
    # First call
    manager1 = EnvironmentManager(config)
    resolved1 = manager1.resolve_config()
    
    # Second call should reuse the same environment
    manager2 = EnvironmentManager(config)
    resolved2 = manager2.resolve_config()
    
    assert resolved1 == resolved2


def test_version_normalization():
    """Test that version numbers are normalized correctly."""
    # Version without 'v' prefix
    config1 = {"lean_version": "4.21.0"}
    manager1 = EnvironmentManager(config1)
    assert manager1._normalize_version("4.21.0") == "v4.21.0"
    
    # Version with 'v' prefix
    config2 = {"lean_version": "v4.21.0"}
    manager2 = EnvironmentManager(config2)
    assert manager2._normalize_version("v4.21.0") == "v4.21.0"


def test_project_path_fallback():
    """Test using explicit project_path instead of version."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        project_path = Path(tmpdir) / "test_project"
        project_path.mkdir()
        
        # Create minimal lakefile
        (project_path / "lakefile.lean").write_text("-- test lakefile")
        
        config = {"project_path": str(project_path)}
        manager = EnvironmentManager(config)
        
        resolved = manager.resolve_config()
        assert Path(resolved["project_path"]) == project_path
