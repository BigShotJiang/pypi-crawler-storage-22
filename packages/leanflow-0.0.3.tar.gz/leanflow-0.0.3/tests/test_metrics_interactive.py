import pytest

from leanflow import TypeCheck, BEqPlus, BEqL, EquivRfl
from tests.test_data import TYPECHECK_DATA, BEQ_PLUS_DATA, BEQ_L_DATA, EQUIV_RFL_DATA


# ============================================================================
# TypeCheck Tests
# ============================================================================

def test_typecheck_pass(repl_config):
    """Test TypeCheck with valid code and Mathlib."""
    test_case = TYPECHECK_DATA["pass_with_mathlib"]
    metric = TypeCheck(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


def test_typecheck_fail(repl_config):
    """Test TypeCheck without required imports."""
    test_case = TYPECHECK_DATA["fail_without_mathlib"]
    metric = TypeCheck(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# BEq_plus Tests
# ============================================================================

def test_beq_plus_basic_pass(repl_config):
    """Test BEq_plus with same statement."""
    test_case = BEQ_PLUS_DATA["pass_same_statement"]
    metric = BEqPlus(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]

def test_beq_plus_pass(repl_config):
    """Test BEq_plus with same statement."""
    test_case = BEQ_PLUS_DATA["pass_same_statement"]
    metric = BEqPlus(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


def test_beq_plus_fail(repl_config):
    """Test BEq_plus with different statements."""
    test_case = BEQ_PLUS_DATA["fail_different_statements"]
    metric = BEqPlus(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# BEq_l Tests
# ============================================================================

def test_beq_l_basic_pass(repl_config):
    """Test BEq_l with same statement."""
    test_case = BEQ_L_DATA["pass_same_statement"]
    metric = BEqL(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]

def test_beq_l_pass(repl_config):
    """Test BEq_l with same statement."""
    test_case = BEQ_L_DATA["pass_same_statement"]
    metric = BEqL(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


def test_beq_l_fail(repl_config):
    """Test BEq_l with different statements."""
    test_case = BEQ_L_DATA["fail_different_statements"]
    metric = BEqL(repl_config=repl_config)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# EquivRfl Tests
# ============================================================================

def test_equiv_rfl_pass(repl_config):
    """Test EquivRfl with equivalent conjectures."""
    test_case = EQUIV_RFL_DATA["pass_equivalent_conjectures"]
    metric = EquivRfl(repl_config=repl_config)
    
    result = metric.compute(
        test_case["conjecture1"],
        test_case["conjecture2"]
    )
    
    assert result == test_case["expected"], test_case["description"]


def test_equiv_rfl_fail(repl_config):
    """Test EquivRfl with different conjectures."""
    test_case = EQUIV_RFL_DATA["fail_different_conjectures"]
    metric = EquivRfl(repl_config=repl_config)
    
    result = metric.compute(
        test_case["conjecture1"],
        test_case["conjecture2"]
    )
    
    assert result == test_case["expected"], test_case["description"]
