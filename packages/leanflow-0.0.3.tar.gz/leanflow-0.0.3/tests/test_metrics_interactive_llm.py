"""
Run with: pytest -m llm

To skip these tests, run: pytest -m "not llm"
"""

import pytest

from leanflow import ConJudge, LLMGrader, BEq
from tests.test_data import CONJUDGE_DATA, LLM_GRADER_DATA, BEQ_DATA


@pytest.fixture(scope="module")
def llm_metric_config(llm_api_config, repl_config):
    """Configuration for LLM-as-a-judge metrics."""
    # import requests

    # # Check if LLM API server is running
    # base_url = llm_api_config.get("base_url")
    # if base_url:
    #     try:
    #         response = requests.get(base_url, timeout=5)
    #         response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
    #     except requests.exceptions.ConnectionError:
    #         pytest.fail(f"LLM API server at {base_url} is not running. Please start the server to run LLM tests.")
    #     except requests.exceptions.Timeout:
    #         pytest.fail(f"LLM API server at {base_url} timed out. Please check the server.")
    #     except requests.exceptions.RequestException as e:
    #         pytest.fail(f"Failed to connect to LLM API server at {base_url}: {e}")
    # else:
    #     pytest.fail("llm_api_config does not contain 'base_url'. Cannot check server status.")

    return {
        "repl_config": repl_config,
        "api_config": llm_api_config,
        "sampling_params": {
            "max_tokens": 1024,
            "temperature": 0.0,
        },
        "backtranslation": {
            "model": "internlm2-math-plus-20b",
            # "model": "Qwen/Qwen2.5-Math-1.5B-Instruct",
        },
        "comparison": {
            "model": "qwen3-14b",
            # "model": "Qwen/Qwen2.5-Math-1.5B-Instruct",
        },
        "tactic_generator": {
            "model": "internlm2-math-plus-20b",
            # "model": "Qwen/Qwen2.5-Math-1.5B-Instruct",
        },
    }

# ============================================================================
# ConJudge Tests
# ============================================================================

@pytest.mark.llm
def test_conjudge_pass(llm_metric_config):
    """Test ConJudge with correct conjecture."""
    test_case = CONJUDGE_DATA["pass_correct_conjecture"]
    metric = ConJudge(**llm_metric_config)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "conjudge" in result
    
    print(f"\n{"="*60}")
    # print(f"ConJudge Test: {test_case["name"]}")
    print(f"Result: {result["conjudge"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["conjudge"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")


@pytest.mark.llm
def test_conjudge_fail(llm_metric_config):
    """Test ConJudge with incorrect conjecture."""
    test_case = CONJUDGE_DATA["fail_incorrect_conjecture"]
    metric = ConJudge(**llm_metric_config)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "conjudge" in result
    
    print(f"\n{"="*60}")
    # print(f"ConJudge Test: {test_case["name"]}")
    print(f"Result: {result["conjudge"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["conjudge"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")


@pytest.mark.llm
def test_conjudge_batch(llm_metric_config):
    """Test ConJudge with batch of examples."""
    metric = ConJudge(**llm_metric_config)
    test_cases = list(CONJUDGE_DATA.values())
    results = metric.compute(test_cases)
    
    assert len(results) == len(test_cases)
    assert all("conjudge" in r for r in results)
    assert all("conjudge_raw" in r for r in results)
    
    # Print batch results
    print(f"\n{"="*60}")
    print("ConJudge Batch Test Results:")
    for test_case, result in zip(test_cases, results):
        match = "✓" if result["conjudge"] == test_case["expected"] else "✗ (weak LLM may fail)"
        print(f"  {match}")
        print(f"    Result: {result["conjudge"]}, Expected: {test_case["expected"]}")
    print(f"{"="*60}")


# ============================================================================
# LLMGrader Tests
# ============================================================================

@pytest.mark.llm
def test_llm_grader_pass(llm_metric_config):
    """Test LLMGrader with equivalent statements."""
    test_case = LLM_GRADER_DATA["pass_same_statement"]
    metric = LLMGrader(**llm_metric_config)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "llm_grader" in result
    
    # Print results for transparency with weak LLM
    print(f"\n{"="*60}")
    # print(f"LLMGrader Test: {test_case["name"]}")
    print(f"Result: {result["llm_grader"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["llm_grader"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")


@pytest.mark.llm
def test_llm_grader_fail(llm_metric_config):
    """Test LLMGrader with different statements."""
    test_case = LLM_GRADER_DATA["fail_different_statements"]
    metric = LLMGrader(**llm_metric_config)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "llm_grader" in result
    
    # Print results for transparency with weak LLM
    print(f"\n{"="*60}")
    # print(f"LLMGrader Test: {test_case["name"]}")
    print(f"Result: {result["llm_grader"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["llm_grader"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")


@pytest.mark.llm
def test_llm_grader_batch(llm_metric_config):
    """Test LLMGrader with batch of examples."""
    metric = LLMGrader(**llm_metric_config)
    test_cases = list(LLM_GRADER_DATA.values())
    results = metric.compute(test_cases)
    
    assert len(results) == len(test_cases)
    assert all("llm_grader" in r for r in results)
    assert all("llm_grader_raw" in r for r in results)
    assert all("formal_statement_backtranslation" in r for r in results)
    assert all("formal_statement_generated_backtranslation" in r for r in results)

# ============================================================================
# BEq Tests
# ============================================================================

@pytest.mark.llm
def test_beq(llm_metric_config):
    """Test BEq with same statement."""
    test_case = BEQ_DATA["pass_same_statement"]
    metric = BEq(**llm_metric_config)

    print(metric.__dict__)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "beq" in result

    print(f"\n{"="*60}")
    # print(f"BEq Test: {test_case["name"]}")
    print(f"Result: {result["beq"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["beq"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")

@pytest.mark.llm
def test_beq_fail(llm_metric_config):
    """Test BEq with different statements."""
    test_case = BEQ_DATA["fail_different_statements"]
    metric = BEq(**llm_metric_config)
    
    results = metric.compute([test_case])
    
    assert len(results) == 1
    result = results[0]
    assert "beq" in result

    print(f"\n{"="*60}")
    # print(f"BEq Test: {test_case["name"]}")
    print(f"Result: {result["beq"]}")
    print(f"Expected: {test_case["expected"]}")
    print(f"Match: {"✓" if result["beq"] == test_case["expected"] else "✗ (weak LLM may fail)"}")
    print(f"Description: {test_case["description"]}")
    print(f"{"="*60}")
