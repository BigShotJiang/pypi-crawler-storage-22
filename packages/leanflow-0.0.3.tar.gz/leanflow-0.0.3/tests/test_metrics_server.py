import pytest
from leanflow import Client, TypeCheck, BEqPlus, BEqL, EquivRfl
from tests.test_data import TYPECHECK_DATA, BEQ_PLUS_DATA, BEQ_L_DATA, EQUIV_RFL_DATA


import pytest_asyncio

@pytest_asyncio.fixture
def client(client_config):
    """Create a client instance for testing."""
    client = Client(**client_config)
    yield client

# ============================================================================
# TypeCheck Tests (Server)
# ============================================================================

@pytest.mark.server
def test_typecheck_pass_server(client):
    """Test TypeCheck via server with valid code."""
    test_case = TYPECHECK_DATA["pass_with_mathlib"]
    metric = TypeCheck(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


@pytest.mark.server
def test_typecheck_fail_server(client):
    """Test TypeCheck without required imports."""
    test_case = TYPECHECK_DATA["fail_without_mathlib"]
    metric = TypeCheck(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# BEq_plus Tests (Server)
# ============================================================================

@pytest.mark.server
def test_beq_plus_basic_server(client):
    """Test BEq_plus via server with same statement."""
    test_case = BEQ_PLUS_DATA["pass_same_statement"]
    metric = BEqPlus(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]

@pytest.mark.server
def test_beq_plus_pass_server(client):
    """Test BEq_plus via server with same statement."""
    test_case = BEQ_PLUS_DATA["pass_same_statement"]
    metric = BEqPlus(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    assert result == test_case["expected"], test_case["description"]


@pytest.mark.server
def test_beq_plus_fail_server(client):
    """Test BEq_plus via server with different statements."""
    test_case = BEQ_PLUS_DATA["fail_different_statements"]
    metric = BEqPlus(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# BEq_l Tests (Server)
# ============================================================================

@pytest.mark.server
def test_beq_l_basic_server(client):
    """Test BEq_l via server with same statement."""
    test_case = BEQ_L_DATA["pass_same_statement"]
    metric = BEqL(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement1"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]

@pytest.mark.server
def test_beq_l_pass_server(client):
    """Test BEq_l via server with same statement."""
    test_case = BEQ_L_DATA["pass_same_statement"]
    metric = BEqL(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


@pytest.mark.server
def test_beq_l_fail_server(client):
    """Test BEq_l via server with different statements."""
    test_case = BEQ_L_DATA["fail_different_statements"]
    metric = BEqL(client=client)
    
    result = metric.compute(
        test_case["statement1"],
        test_case["statement2"],
        header=test_case["header"]
    )
    
    assert result == test_case["expected"], test_case["description"]


# ============================================================================
# EquivRfl Tests (Server)
# ============================================================================

@pytest.mark.server
def test_equiv_rfl_pass_server(client):
    """Test EquivRfl via server with equivalent conjectures."""
    test_case = EQUIV_RFL_DATA["pass_equivalent_conjectures"]
    metric = EquivRfl(client=client)
    
    result = metric.compute(
        test_case["conjecture1"],
        test_case["conjecture2"]
    )
    
    assert result == test_case["expected"], test_case["description"]


@pytest.mark.server
def test_equiv_rfl_fail_server(client):
    """Test EquivRfl via server with different conjectures."""
    test_case = EQUIV_RFL_DATA["fail_different_conjectures"]
    metric = EquivRfl(client=client)
    
    result = metric.compute(
        test_case["conjecture1"],
        test_case["conjecture2"]
    )
    
    assert result == test_case["expected"], test_case["description"]
