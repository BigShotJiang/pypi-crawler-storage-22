import pytest
import asyncio
from pathlib import Path

from leanflow import REPL, LeanError, Environment
from tests.test_data import REPL_TEST_COMMANDS


@pytest.mark.asyncio
async def test_repl_basic_command(repl_config):
    """Test basic REPL command execution."""
    async with REPL(**repl_config) as repl:
        result = await repl.run("#check 1 + 1")
        assert isinstance(result, Environment)
        assert result.env is not None


@pytest.mark.asyncio
async def test_repl_with_header(repl_config):
    """Test REPL initialization with header."""
    async with REPL(header="import Mathlib", **repl_config) as repl:
        # Check that a Mathlib theorem is available
        test_data = REPL_TEST_COMMANDS["with_mathlib"]
        result = await repl.run(test_data["command"])
        assert isinstance(result, Environment), f"Expected Environment, got {type(result)}"


@pytest.mark.asyncio
async def test_repl_run_file_async(repl_config, temp_lean_file):
    """Test running a Lean file."""
    async with REPL(**repl_config) as repl:
        result = await repl.run_file_async(temp_lean_file)
        # File should either succeed or return a LeanError
        assert isinstance(result, (Environment, LeanError))


@pytest.mark.asyncio
async def test_repl_tactic_mode(repl_config):
    """Test tactic mode execution."""
    async with REPL(header="import Mathlib", **repl_config) as repl:
        # First, create a theorem with a proof state
        env_result = await repl.run("theorem test_theorem : True := by")        
        
        if isinstance(env_result, LeanError):
            pytest.skip(f"Could not create proof state: {env_result.message}")
        
        # Note: Properly testing tactic mode requires accessing proof states
        # This is a simplified test - full implementation would use ProofState
        assert isinstance(env_result, (Environment, LeanError))


@pytest.mark.asyncio
async def test_repl_sequential_commands(repl_config):
    """Test that sequential commands maintain environment continuity."""
    async with REPL(header="import Mathlib", **repl_config) as repl:
        # Define a constant in one command
        result1 = await repl.run("def myConst : Nat := 42")
        assert isinstance(result1, Environment)
        
        # Use it in the next command
        result2 = await repl.run("#check myConst", env=result1)
        assert isinstance(result2, Environment)


@pytest.mark.asyncio
async def test_repl_error_handling(repl_config):
    """Test that REPL handles errors gracefully."""
    async with REPL(**repl_config) as repl:
        # Invalid Lean code should return an Environment with error messages
        result = await repl.run("invalid lean code here")
        assert isinstance(result, Environment)
        assert len(result.messages) > 0
        assert result.messages[0].severity == "error"
        
        # REPL should still work after an error
        result2 = await repl.run("#check 1 + 1")
        assert isinstance(result2, Environment)


@pytest.mark.asyncio
async def test_repl_multiple_commands_list(repl_config):
    """Test running multiple commands as a list."""
    async with REPL(header="import Mathlib", **repl_config) as repl:
        commands = [
            "def x : Nat := 1",
            "def y : Nat := 2",
            "#check x + y"
        ]
        results = await repl.run(commands)
        assert isinstance(results, list)
        assert len(results) == 3
        # All should succeed
        assert all(isinstance(r, Environment) for r in results)
