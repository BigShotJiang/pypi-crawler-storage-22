"""
Run with: pytest -m server
Skip with: pytest -m "not server"
"""

import pytest
import asyncio

from leanflow import Client, Environment


@pytest.fixture(scope="module")
async def client(client_config):
    """Create a client instance for testing."""
    client = Client(**client_config)
    yield client
    await client.close()


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_basic_command(client_config):
    """Test basic command execution via server."""
    async with Client(**client_config) as client:
        result = await client.run("#check 1 + 1")
        assert isinstance(result, Environment)
        assert result.env is not None


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_with_mathlib(client_config):
    """Test command requiring Mathlib via server."""
    async with Client(**client_config) as client:
        # The server should have Mathlib available in its configuration
        result = await client.run("import Mathlib\n#check Nat.add_comm")
        # May succeed or fail depending on server configuration
        assert isinstance(result, Environment)


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_sequential_commands(client_config):
    """Test sequential commands maintain environment continuity."""
    async with Client(**client_config) as client:
        # Define a constant
        result1 = await client.run("def myConst : Nat := 42")
        assert isinstance(result1, Environment)
        
        # Use it in next command
        result2 = await client.run("#check myConst", env=result1)
        assert isinstance(result2, Environment)


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_multiple_commands(client_config):
    """Test running multiple commands as a list."""
    async with Client(**client_config) as client:
        commands = [
            "def x : Nat := 1",
            "def y : Nat := 2",
            "#check x + y"
        ]
        results = await client.run(commands)
        assert isinstance(results, list)
        assert len(results) == 3
        # All should succeed
        assert all(isinstance(r, Environment) for r in results)


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_error_handling(client_config):
    """Test server handles errors gracefully."""
    async with Client(**client_config) as client:
        # Invalid Lean code
        result = await client.run("invalid lean code here")
        assert isinstance(result, Environment)
        assert len(result.messages) > 0
        assert result.messages[0].severity == "error"
        
        # Server should still work after error
        result2 = await client.run("#check 1 + 1")
        assert isinstance(result2, Environment)


@pytest.mark.server
@pytest.mark.asyncio
async def test_server_concurrent_requests(client_config):
    """Test server handles concurrent requests."""
    async with Client(**client_config) as client:
        # Send multiple requests concurrently
        tasks = [
            client.run(f"def x{i} : Nat := {i}")
            for i in range(5)
        ]
        
        results = await asyncio.gather(*tasks)
        
        assert len(results) == 5
        assert all(isinstance(r, Environment) for r in results)
