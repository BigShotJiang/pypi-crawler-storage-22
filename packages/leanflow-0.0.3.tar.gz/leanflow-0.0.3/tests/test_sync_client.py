"""Tests for the synchronous Client wrapper (SyncClient).

These tests verify that the SyncClient provides a working synchronous interface
to the LeanFlow server without requiring async/await.

These tests require a running LeanFlow server. Configure the server URL below.
"""
import pytest

from leanflow import SyncClient, Environment


# Server configuration - matches leanflow/server.yaml
SERVER_URL = "http://localhost:8081"


@pytest.fixture
def sync_client():
    """Provide a SyncClient connected to the test server."""
    with SyncClient(base_url=SERVER_URL, timeout=300) as client:
        yield client


class TestSyncClientBasic:
    """Basic functionality tests for SyncClient."""

    def test_context_manager_basic(self):
        """Test SyncClient works as a context manager."""
        with SyncClient(base_url=SERVER_URL) as client:
            result = client.run("#check 1 + 1")
            assert isinstance(result, Environment)
            assert result.env is not None

    def test_single_command(self, sync_client):
        """Test running a single command."""
        result = sync_client.run("#eval 2 + 2")
        assert isinstance(result, Environment)
        # Check that there's an info message with the result
        assert any(m.severity == "info" for m in result.messages)

    def test_multiple_commands_list(self, sync_client):
        """Test running multiple commands as a list."""
        commands = [
            "def x : Nat := 1",
            "def y : Nat := 2",
            "#eval x + y"
        ]
        results = sync_client.run(commands)
        assert isinstance(results, list)
        assert len(results) == 3
        # All should be Environment (success)
        assert all(isinstance(r, Environment) for r in results)


class TestSyncClientServerStatus:
    """Tests for server status checking."""

    def test_status_check(self, sync_client):
        """Test that status() returns True for running server."""
        status = sync_client.status()
        assert status is True


class TestSyncClientStateManagement:
    """Tests for environment and state management."""

    def test_sequential_commands_maintain_state(self, sync_client):
        """Test that sequential commands maintain environment."""
        # Define a constant
        result1 = sync_client.run("def myServerValue : Nat := 42")
        assert isinstance(result1, Environment)

        # Use it in the next command (should work due to state)
        result2 = sync_client.run("#check myServerValue")
        assert isinstance(result2, Environment)

    def test_explicit_env_passing(self, sync_client):
        """Test explicit environment passing."""
        # Create an environment with a definition
        env1 = sync_client.run("def serverConst : Nat := 100")
        assert isinstance(env1, Environment)

        # Use explicit env parameter
        env2 = sync_client.run("#eval serverConst", env=env1.env)
        assert isinstance(env2, Environment)


class TestSyncClientErrorHandling:
    """Tests for error handling."""

    def test_invalid_code_returns_error_messages(self, sync_client):
        """Test that invalid Lean code returns error messages."""
        result = sync_client.run("this is not valid lean code")
        assert isinstance(result, Environment)
        assert len(result.messages) > 0
        assert any(m.severity == "error" for m in result.messages)

    def test_recovery_after_error(self, sync_client):
        """Test that client recovers after an error."""
        # First command: invalid
        result1 = sync_client.run("invalid code")
        assert isinstance(result1, Environment)
        assert any(m.severity == "error" for m in result1.messages)

        # Second command: valid - should still work
        result2 = sync_client.run("#check Nat")
        assert isinstance(result2, Environment)


class TestSyncClientManualManagement:
    """Tests for manual close management."""

    def test_manual_close(self):
        """Test manual close() method."""
        client = SyncClient(base_url=SERVER_URL)
        # Enter context manually
        client.__enter__()

        try:
            result = client.run("#check Bool")
            assert isinstance(result, Environment)
        finally:
            client.close()
