"""Tests for the synchronous REPL wrapper (SyncREPL).

These tests verify that the SyncREPL provides a working synchronous interface
to the Lean REPL without requiring async/await.
"""

from leanflow import SyncREPL, Environment


class TestSyncREPLBasic:
    """Basic functionality tests for SyncREPL."""

    def test_context_manager_basic(self, repl_config):
        """Test SyncREPL works as a context manager."""
        with SyncREPL(**repl_config) as repl:
            result = repl.run("#check 1 + 1")
            assert isinstance(result, Environment)
            assert result.env is not None

    def test_single_command(self, repl_config):
        """Test running a single command."""
        with SyncREPL(**repl_config) as repl:
            result = repl.run("#eval 2 + 2")
            assert isinstance(result, Environment)
            # Check that there's an info message with the result
            assert any(m.severity == "info" for m in result.messages)

    def test_multiple_commands_list(self, repl_config):
        """Test running multiple commands as a list."""
        with SyncREPL(**repl_config) as repl:
            commands = [
                "def x : Nat := 1",
                "def y : Nat := 2", 
                "#eval x + y"
            ]
            results = repl.run(commands)
            assert isinstance(results, list)
            assert len(results) == 3
            # All should be Environment (success)
            assert all(isinstance(r, Environment) for r in results)


class TestSyncREPLStateManagement:
    """Tests for environment and state management."""

    def test_sequential_commands_maintain_state(self, repl_config):
        """Test that sequential commands maintain environment."""
        with SyncREPL(**repl_config) as repl:
            # Define a constant
            result1 = repl.run("def myValue : Nat := 42")
            assert isinstance(result1, Environment)
            
            # Use it in the next command (should work due to state)
            result2 = repl.run("#check myValue")
            assert isinstance(result2, Environment)

    def test_explicit_env_passing(self, repl_config):
        """Test explicit environment passing."""
        with SyncREPL(**repl_config) as repl:
            # Create an environment with a definition
            env1 = repl.run("def testConst : Nat := 100")
            assert isinstance(env1, Environment)
            
            # Use explicit env parameter
            env2 = repl.run("#eval testConst", env=env1)
            assert isinstance(env2, Environment)


class TestSyncREPLErrorHandling:
    """Tests for error handling."""

    def test_invalid_code_returns_error_messages(self, repl_config):
        """Test that invalid Lean code returns error messages."""
        with SyncREPL(**repl_config) as repl:
            result = repl.run("this is not valid lean code")
            assert isinstance(result, Environment)
            assert len(result.messages) > 0
            assert any(m.severity == "error" for m in result.messages)

    def test_recovery_after_error(self, repl_config):
        """Test that REPL recovers after an error."""
        with SyncREPL(**repl_config) as repl:
            # First command: invalid
            result1 = repl.run("invalid code")
            assert isinstance(result1, Environment)
            assert any(m.severity == "error" for m in result1.messages)
            
            # Second command: valid - should still work
            result2 = repl.run("#check Nat")
            assert isinstance(result2, Environment)


class TestSyncREPLManualManagement:
    """Tests for manual start/close management."""

    def test_manual_start_close(self, repl_config):
        """Test manual start() and close() methods."""
        repl = SyncREPL(**repl_config)
        repl.start()
        
        try:
            result = repl.run("#check Bool")
            assert isinstance(result, Environment)
        finally:
            repl.close()
