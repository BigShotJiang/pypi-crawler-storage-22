import orjson
import leangeo
import logging
import atexit
import time
import threading
import math
import gc
import os
import fcntl
from typing import Union, List, Tuple, Optional, Any
from contextlib import contextmanager

# Set up basic logging
logger = logging.getLogger(__name__)

# --- Locks and Trackers ---

class CollectionLock:
    def __init__(self, collection_path: str):
        self.lock_path = os.path.join(collection_path, '.collection.lock')
        self.lock_file = None
        self._thread_lock = threading.RLock()
        self._ensure_lock_file()
    
    def _ensure_lock_file(self):
        os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
        if not os.path.exists(self.lock_path):
            try:
                open(self.lock_path, 'a').close()
            except OSError:
                pass
    
    @contextmanager
    def read_lock(self):
        with self._thread_lock:
            self._ensure_lock_file()
            self.lock_file = open(self.lock_path, 'r')
            try:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_SH)
                yield
            finally:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                self.lock_file.close()
                self.lock_file = None
    
    @contextmanager
    def write_lock(self):
        with self._thread_lock:
            self._ensure_lock_file()
            self.lock_file = open(self.lock_path, 'r')
            try:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(self.lock_file.fileno(), fcntl.LOCK_UN)
                self.lock_file.close()
                self.lock_file = None

class NoOpLock:
    @contextmanager
    def read_lock(self): yield
    @contextmanager
    def write_lock(self): yield

class VersionTracker:
    def __init__(self, collection_path: str):
        self.version_path = os.path.join(collection_path, '.version')
        self._ensure_version_file()
    
    def _ensure_version_file(self):
        os.makedirs(os.path.dirname(self.version_path), exist_ok=True)
        if not os.path.exists(self.version_path):
            self._write_version(0)
    
    def _write_version(self, version: int):
        with open(self.version_path, 'w') as f:
            f.write(str(version))
            f.flush()
            os.fsync(f.fileno())
    
    def get_version(self) -> int:
        try:
            with open(self.version_path, 'r') as f:
                return int(f.read().strip())
        except (FileNotFoundError, ValueError):
            return 0
    
    def increment_version(self):
        current = self.get_version()
        self._write_version(current + 1)

class NoOpVersionTracker:
    def get_version(self) -> int: return 0
    def increment_version(self): pass

# --- Main Engine ---

class LeanGeoEngine:
    def __init__(self, storage_path: str, auto_persist: bool = True, thread_safe: bool = False):
        self.base_path = storage_path
        self.thread_safe = thread_safe
        
        if self.thread_safe:
            if not os.path.exists(storage_path):
                os.makedirs(storage_path)
            self.lock = CollectionLock(storage_path)
            self.tracker = VersionTracker(storage_path)
        else:
            self.lock = NoOpLock()
            self.tracker = NoOpVersionTracker()
        
        self._inner = leangeo.LeanGeo(storage_path)
        self.local_version = self.tracker.get_version()
        
        self.last_access_time = time.time()
        self.start_time = time.time()
        self.maintenance_interval = 86400
        self.idle_threshold = 3600
        self.stop_maintenance = False
        
        self.m_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.m_thread.start()
        
        if auto_persist:
            atexit.register(self.persist)

    def _needs_reload(self) -> bool:
        if not self.thread_safe: return False
        return self.tracker.get_version() > self.local_version

    def _reload(self):
        if not self.thread_safe: return
        self._inner = leangeo.LeanGeo(self.base_path)
        self.local_version = self.tracker.get_version()

    def _update_version_after_write(self):
        if self.thread_safe:
            self.tracker.increment_version()
            self.local_version = self.tracker.get_version()

    def _ensure_json_string(self, data: Union[str, dict, None]) -> Optional[str]:
        if data is None: return None
        if isinstance(data, dict):
            return orjson.dumps(self._sanitize_metadata(data)).decode('utf-8')
        return data

    def _sanitize_metadata(self, meta: Any) -> Any:
        if isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta): return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta

    def _parse_json_result(self, metadata_str: str) -> dict:
        if not metadata_str: return {}
        try:
            return orjson.loads(metadata_str)
        except (orjson.JSONDecodeError, TypeError) as e:
            logger.error(f"Failed to parse metadata: {e}")
            return {}

    def _update_access_time(self):
        self.last_access_time = time.time()

    def _maintenance_loop(self):
        while not self.stop_maintenance:
            time.sleep(60)
            if time.time() - self.start_time > self.maintenance_interval:
                if time.time() - self.last_access_time > self.idle_threshold:
                    try: self.persist()
                    except Exception: pass
                    self.start_time = time.time()

    # --- Write Operations ---

    def add(self, id: str, lat: float, lon: float, metadata: Union[str, dict], skip_index: Optional[List[str]] = None) -> None:
        self._update_access_time()
        with self.lock.write_lock():
            if self.thread_safe and self._needs_reload(): self._reload()
            meta_str = self._ensure_json_string(metadata)
            self._inner.add(id, float(lat), float(lon), meta_str, skip_index)
            if self.thread_safe:
                self._update_version_after_write()

    def persist(self) -> None:
        with self.lock.write_lock():
            if self.thread_safe and self._needs_reload(): self._reload()
            try:
                gc.collect()
                self._inner.persist()
                if self.thread_safe: self._update_version_after_write()
            except Exception as e:
                logger.error(f"Persist failed: {e}")

    def vacuum(self) -> None:
        self._update_access_time()
        with self.lock.write_lock():
            if self.thread_safe and self._needs_reload(): self._reload()
            self._inner.vacuum()
            if self.thread_safe: self._update_version_after_write()

    def delete(self, id: str) -> None:
        self._update_access_time()
        with self.lock.write_lock():
            if self.thread_safe and self._needs_reload(): self._reload()
            self._inner.delete(id)
            if self.thread_safe: self._update_version_after_write()

    def delete_by_filter(self, filters: Union[str, dict]) -> int:
        self._update_access_time()
        with self.lock.write_lock():
            if self.thread_safe and self._needs_reload(): self._reload()
            f_str = self._ensure_json_string(filters)
            count = self._inner.delete_by_filter(f_str)
            if self.thread_safe: self._update_version_after_write()
            return count

    # --- Read Operations ---

    def count(self) -> int:
        if self.thread_safe and self._needs_reload():
            with self.lock.write_lock():
                if self._needs_reload(): self._reload()
                return self._inner.count()
        else:
            with self.lock.read_lock():
                return self._inner.count()

    def search_knn(self, lat: float, lon: float, k: int, filters: Union[str, dict, None] = None) -> List[Tuple[str, float, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filters)
        
        if self.thread_safe and self._needs_reload():
            with self.lock.write_lock():
                if self._needs_reload(): self._reload()
                results = self._inner.search_knn(float(lat), float(lon), int(k), f_str)
        else:
            with self.lock.read_lock():
                results = self._inner.search_knn(float(lat), float(lon), int(k), f_str)
                
        return [(r[0], r[1], self._parse_json_result(r[2])) for r in results]

    def search_radius(self, lat: float, lon: float, radius_m: float, filters: Union[str, dict, None] = None) -> List[Tuple[str, float, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filters)

        if self.thread_safe and self._needs_reload():
            with self.lock.write_lock():
                if self._needs_reload(): self._reload()
                results = self._inner.search_radius(float(lat), float(lon), float(radius_m), f_str)
        else:
            with self.lock.read_lock():
                results = self._inner.search_radius(float(lat), float(lon), float(radius_m), f_str)

        return [(r[0], r[1], self._parse_json_result(r[2])) for r in results]

    def search_box(self, top_left: Tuple[float, float], bottom_right: Tuple[float, float], filters: Union[str, dict, None] = None) -> List[Tuple[str, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filters)

        if self.thread_safe and self._needs_reload():
            with self.lock.write_lock():
                if self._needs_reload(): self._reload()
                results = self._inner.search_box(top_left, bottom_right, f_str)
        else:
            with self.lock.read_lock():
                results = self._inner.search_box(top_left, bottom_right, f_str)

        return [(r[0], self._parse_json_result(r[1])) for r in results]

    def search_bbox(self, min_lat: float, max_lat: float, min_lon: float, max_lon: float, filters: Union[str, dict, None] = None) -> List[str]:
        top_left = (max_lat, min_lon)
        bottom_right = (min_lat, max_lon)
        results = self.search_box(top_left, bottom_right, filters)
        return [r[0] for r in results]

    def search_polygon(self, points: List[Tuple[float, float]], filters: Union[str, dict, None] = None) -> List[Tuple[str, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filters)

        if self.thread_safe and self._needs_reload():
            with self.lock.write_lock():
                if self._needs_reload(): self._reload()
                results = self._inner.search_polygon(points, f_str)
        else:
            with self.lock.read_lock():
                results = self._inner.search_polygon(points, f_str)

        return [(r[0], self._parse_json_result(r[1])) for r in results]

    def close(self):
        self.stop_maintenance = True
        if self.m_thread.is_alive():
            self.m_thread.join(timeout=2)
        self.persist()