"""
LeanGeo - High-performance coordinate database with metadata filtering and collections
"""
from typing import List, Dict, Any, Optional, Tuple
import os
import fcntl

# Import PyGeoDB class from the Rust extension module
from . import leangeo
_PyGeoDB = leangeo.PyGeoDB

__version__ = "0.2.0"
__all__ = ["LeanGeoEngine"]


class LeanGeoEngine:
    """
    A high-performance coordinate database with spatial indexing and metadata filtering.
    
    Features:
    - Automatic persistence with memory-mapped storage
    - O(1) complexity for numeric filtering via bit-sliced index
    - MongoDB-style query operators
    - Spatial queries: polygon, bounding box, radius
    - Delete by metadata filter
    - Skip indexing for specific fields
    - Optional thread-safety for multiprocessing scenarios
    
    Examples:
        >>> db = LeanGeoEngine()  # In-memory
        >>> db = LeanGeoEngine(path="/data/points.db")  # Persistent (auto-saves)
        >>> db = LeanGeoEngine(path="/data/points.db", thread_safe=True)  # Multi-process safe
        >>> db.insert(40.7128, -74.0060, {"city": "NYC", "population": 8000000})
        >>> results = db.query_radius(40.7128, -74.0060, 10000)
    """
    
    def __init__(self, path: Optional[str] = None, capacity: int = 10000, thread_safe: bool = False):
        """
        Initialize the database.
        
        Args:
            path: Optional folder path for persistent storage. If provided, collections
                  will be stored as {path}/{collection}.db. The folder will be created if it doesn't exist.
            capacity: Initial capacity hint for the database
            thread_safe: Enable thread-safety for multiprocessing (requires path).
                        Uses file locking and version tracking for cross-process consistency.
        """
        self._base_path = path
        self._capacity = capacity
        self._thread_safe = thread_safe and path is not None
        self._collections: Dict[str, Any] = {}  # Cache of PyGeoDB instances per collection
        self._versions: Dict[str, int] = {}  # Version tracking per collection
        
        # Create directory if path is provided and doesn't exist
        if self._base_path:
            os.makedirs(self._base_path, exist_ok=True)
        
        if self._thread_safe and not path:
            raise ValueError("thread_safe=True requires a file path")
    
    def _get_collection_path(self, collection: str) -> Optional[str]:
        """Get the file path for a specific collection."""
        if not self._base_path:
            return None
        
        # Always treat _base_path as a directory
        return os.path.join(self._base_path, f"{collection}.db")
    
    def _get_or_create_collection(self, collection: str):
        """Get or create a PyGeoDB instance for the given collection."""
        if collection not in self._collections:
            path = self._get_collection_path(collection)
            self._collections[collection] = _PyGeoDB(path, self._capacity)
            self._versions[collection] = self._read_version(collection) if self._thread_safe else 0
        return self._collections[collection]
    
    def _get_lock_path(self, collection: str) -> str:
        """Get lock file path for a collection."""
        path = self._get_collection_path(collection)
        return f"{path}.lock"
    
    def _get_version_path(self, collection: str) -> str:
        """Get version file path for a collection."""
        path = self._get_collection_path(collection)
        return f"{path}.version"
    
    def _read_version(self, collection: str) -> int:
        """Read current version from version file."""
        if not self._thread_safe:
            return 0
        version_path = self._get_version_path(collection)
        if os.path.exists(version_path):
            try:
                with open(version_path, 'r') as f:
                    return int(f.read().strip())
            except (IOError, ValueError):
                return 0
        return 0
    
    def _write_version(self, collection: str, version: int):
        """Write new version to version file."""
        if not self._thread_safe:
            return
        version_path = self._get_version_path(collection)
        with open(version_path, 'w') as f:
            f.write(str(version))
    
    def _increment_version(self, collection: str):
        """Increment version after write operation."""
        if not self._thread_safe:
            return
        self._versions[collection] = self._versions.get(collection, 0) + 1
        self._write_version(collection, self._versions[collection])
    
    def _check_and_reload(self, collection: str):
        """Check if data needs reloading based on version."""
        if not self._thread_safe:
            return
        
        disk_version = self._read_version(collection)
        if disk_version != self._versions.get(collection, 0):
            # Version mismatch - another process modified the data
            # Recreate the database to reload from disk
            path = self._get_collection_path(collection)
            self._collections[collection] = _PyGeoDB(path, self._capacity)
            self._versions[collection] = disk_version
    
    def _acquire_read_lock(self, collection: str):
        """Acquire shared lock for read operations."""
        if not self._thread_safe:
            return None
        
        lock_path = self._get_lock_path(collection)
        lock_file = open(lock_path, 'a+')
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_SH)
        return lock_file
    
    def _acquire_write_lock(self, collection: str):
        """Acquire exclusive lock for write operations."""
        if not self._thread_safe:
            return None
        
        lock_path = self._get_lock_path(collection)
        lock_file = open(lock_path, 'a+')
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        return lock_file
    
    def _release_lock(self, lock_file):
        """Release file lock."""
        if lock_file:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
            lock_file.close()
    
    def insert(
        self,
        latitude: float,
        longitude: float,
        metadata: Dict[str, Any],
        skip_index: Optional[List[str]] = None,
        collection: str = "default"
    ) -> int:
        """
        Insert a single point.
        
        Args:
            latitude: Latitude coordinate
            longitude: Longitude coordinate
            metadata: Dictionary of metadata
            skip_index: Optional list of field names to skip from indexing
                       (useful for large text fields that won't be queried)
            collection: Collection name (default: "default")
            
        Returns:
            ID of the inserted point
            
        Examples:
            >>> db.insert(40.7, -74.0, {"city": "NYC"})
            >>> db.insert(40.7, -74.0, {"user": "Alice"}, collection="users")
        """
        lock_file = self._acquire_write_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            result = db.insert(latitude, longitude, metadata, skip_index)
            self._increment_version(collection)
            return result
        finally:
            self._release_lock(lock_file)
    
    def insert_batch(
        self,
        points: List[Tuple[float, float, Dict[str, Any]]],
        skip_index: Optional[List[str]] = None,
        collection: str = "default"
    ) -> List[int]:
        """
        Insert multiple points efficiently in batch.
        
        Args:
            points: List of (latitude, longitude, metadata) tuples
            skip_index: Optional list of field names to skip from indexing
            collection: Collection name (default: "default")
            
        Returns:
            List of IDs for the inserted points
            
        Examples:
            >>> points = [(40.7, -74.0, {"city": "NYC"}), (34.05, -118.24, {"city": "LA"})]
            >>> db.insert_batch(points)
            >>> db.insert_batch(points, collection="users")
        """
        lock_file = self._acquire_write_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            result = db.insert_batch(points, skip_index)
            self._increment_version(collection)
            return result
        finally:
            self._release_lock(lock_file)
    
    def flush(self, collection: str = "default"):
        """
        Flush data to disk (no-op for backward compatibility).
        
        Note: LeanGeoEngine uses automatic persistence with memory-mapped storage.
        Data is automatically saved during insert operations, so manual flushing
        is not required. This method exists only for backward compatibility.
        
        Args:
            collection: Collection name (default: "default")
        """
        # Auto-flush is already handled in insert operations
        pass
    
    def get_file_path(self, collection: str = "default") -> Optional[str]:
        """
        Get the file path for a specific collection.
        
        Args:
            collection: Collection name (default: "default")
            
        Returns:
            File path for the collection, or None if in-memory only
            
        Examples:
            >>> db = LeanGeoEngine(path="/data/points.db")
            >>> db.get_file_path()  # Returns "/data/points_default.db"
            >>> db.get_file_path("users")  # Returns "/data/points_users.db"
        """
        return self._get_collection_path(collection)
    
    def query_bbox(
        self,
        min_lat: float,
        min_lon: float,
        max_lat: float,
        max_lon: float,
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        """
        Query points within a bounding box.
        
        Args:
            min_lat: Minimum latitude
            min_lon: Minimum longitude
            max_lat: Maximum latitude
            max_lon: Maximum longitude
            filter: Optional metadata filter query
            collection: Collection name (default: "default")
            
        Returns:
            List of matching points
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.query_bbox(min_lat, min_lon, max_lat, max_lon, filter)
        finally:
            self._release_lock(lock_file)
    
    def query_polygon(
        self,
        coordinates: List[Tuple[float, float]],
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        """
        Query points within a polygon.
        
        Args:
            coordinates: List of (longitude, latitude) tuples defining the polygon
            filter: Optional metadata filter query
            collection: Collection name (default: "default")
            
        Returns:
            List of matching points
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.query_polygon(coordinates, filter)
        finally:
            self._release_lock(lock_file)
    
    def query_radius(
        self,
        center_lat: float,
        center_lon: float,
        radius_meters: float,
        filter: Optional[Dict[str, Any]] = None,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        """
        Query points within a radius from a center point.
        
        Args:
            center_lat: Center latitude
            center_lon: Center longitude
            radius_meters: Radius in meters
            filter: Optional metadata filter query
            collection: Collection name (default: "default")
            
        Returns:
            List of matching points
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.query_radius(center_lat, center_lon, radius_meters, filter)
        finally:
            self._release_lock(lock_file)
    
    def query(self, filter: Dict[str, Any], limit: Optional[int] = None, collection: str = "default") -> List[Dict[str, Any]]:
        """
        Query all points with metadata filtering.
        
        Args:
            filter: Metadata filter query (MongoDB-style operators)
            limit: Maximum number of results (default: 10,000)
            collection: Collection name (default: "default")
            
        Returns:
            List of matching points
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.query(filter, limit)
        finally:
            self._release_lock(lock_file)
    
    def exists(self, filter: Dict[str, Any], collection: str = "default") -> bool:
        """
        Check if any point exists matching the given metadata filter.
        
        Args:
            filter: Metadata filter query
            collection: Collection name (default: "default")
            
        Returns:
            True if at least one matching point exists
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.exists(filter)
        finally:
            self._release_lock(lock_file)
    
    def delete_by_metadata(self, filter: Dict[str, Any], collection: str = "default") -> int:
        """
        Delete all points matching the given metadata filter.
        
        Args:
            filter: Metadata filter query (same syntax as query())
            collection: Collection name (default: "default")
            
        Returns:
            Number of points deleted
            
        Examples:
            >>> db.delete_by_metadata({"status": "archived"})
            42
            >>> db.delete_by_metadata({"created": {"$lt": "2020-01-01"}}, collection="users")
            156
        """
        lock_file = self._acquire_write_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            result = db.delete_by_metadata(filter)
            self._increment_version(collection)
            return result
        finally:
            self._release_lock(lock_file)
    
    def count(self, collection: str = "default") -> int:
        """
        Get the number of indexed points.
        
        Args:
            collection: Collection name (default: "default")
        
        Returns:
            Total count of points in the collection
        """
        lock_file = self._acquire_read_lock(collection)
        try:
            self._check_and_reload(collection)
            db = self._get_or_create_collection(collection)
            return db.count()
        finally:
            self._release_lock(lock_file)
    
    def __len__(self) -> int:
        """Return the number of points in the default collection."""
        return self.count("default")
