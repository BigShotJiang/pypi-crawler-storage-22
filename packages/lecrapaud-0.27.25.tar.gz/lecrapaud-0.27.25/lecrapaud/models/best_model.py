from sqlalchemy import (
    Column,
    Integer,
    String,
    DateTime,
    Date,
    Float,
    JSON,
    Table,
    ForeignKey,
    BigInteger,
    Index,
    TIMESTAMP,
    UniqueConstraint,
)
from sqlalchemy import desc, asc, cast, text, func

from sqlalchemy.orm import relationship, Mapped, mapped_column, DeclarativeBase

from lecrapaud.db.session import get_db
from lecrapaud.models.base import Base
from lecrapaud.config import LECRAPAUD_TABLE_PREFIX


class BestModel(Base):
    __tablename__ = f"{LECRAPAUD_TABLE_PREFIX}_best_models"

    id = Column(BigInteger, primary_key=True, index=True, autoincrement=True)
    created_at = Column(
        TIMESTAMP(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    params = Column(JSON)
    thresholds = Column(JSON)
    score = Column(JSON)
    model_path = Column(String(255))
    model_type_id = Column(
        BigInteger,
        ForeignKey(f"{LECRAPAUD_TABLE_PREFIX}_model_types.id", ondelete="CASCADE"),
    )
    model_id = Column(
        BigInteger,
        ForeignKey(f"{LECRAPAUD_TABLE_PREFIX}_models.id", ondelete="SET NULL"),
    )
    target_id = Column(
        BigInteger,
        ForeignKey(f"{LECRAPAUD_TABLE_PREFIX}_targets.id", ondelete="CASCADE"),
        nullable=False,
    )
    experiment_id = Column(
        BigInteger,
        ForeignKey(f"{LECRAPAUD_TABLE_PREFIX}_experiments.id", ondelete="CASCADE"),
        nullable=False,
    )

    model_type = relationship("ModelType", lazy="selectin")
    model = relationship(
        "Model",
        foreign_keys=[model_id],
        lazy="selectin",
        post_update=True,  # Break circular dependency: insert first, then update FK
    )
    models = relationship(
        "Model",
        back_populates="best_model",
        cascade="all, delete-orphan",
        lazy="selectin",
        foreign_keys="[Model.best_model_id]",
    )
    experiment = relationship(
        "Experiment", back_populates="best_models", lazy="selectin"
    )
    target = relationship("Target", back_populates="best_models", lazy="selectin")

    __table_args__ = (
        UniqueConstraint(
            "target_id", "experiment_id", name="uq_best_model_composite"
        ),
    )
