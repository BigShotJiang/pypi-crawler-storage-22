import numpy as np


def build_features(all_problems, user_data):

    solved = set()
    
    all_qs = user_data.get("problemsetQuestionList", {}).get("questions", [])
    if not all_qs:
        all_qs = user_data.get("data", {}).get("problemsetQuestionList", {}).get("questions", [])
    
    for s in all_qs:
        solved.add(s["titleSlug"])

    X = []
    meta = []

    for p in all_problems:
        slug = p["titleSlug"]
        is_solved = 1 if slug in solved else 0
        
        diff_map = {"Easy": 1, "Medium": 2, "Hard": 3}
        diff = diff_map.get(p["difficulty"], 2)
        tags = len(p.get("topicTags", []))
        ac_rate = p.get("acRate", 50)

        X.append([is_solved, diff, tags, ac_rate])
        meta.append({
            "id": p.get("questionFrontendId"),
            "slug": slug,
            "difficulty": p["difficulty"]
        })

    return np.array(X), meta
