from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

def recommendation(X, meta, solved_slugs, n=5):
    if X.size == 0:
        return []

    weak_idx = (X[:, 0] == 0)
    weak_features = X[weak_idx]

    if len(weak_features) < 5:
        return []

    user_profile = np.mean(weak_features, axis=0).reshape(1, -1)
    similarities = cosine_similarity(user_profile, X).flatten()
    related_indices = np.argsort(similarities)[::-1]

    recs = []
    for i in related_indices:
        p_meta = meta[i]
        
        if p_meta['slug'] in solved_slugs:
            continue
            
        recs.append(p_meta)
        
        if len(recs) >= n:
            break

    return recs