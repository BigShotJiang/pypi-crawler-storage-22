"""Utility functions for LegacyLipi."""
