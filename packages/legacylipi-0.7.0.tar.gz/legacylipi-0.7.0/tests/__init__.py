"""Tests for LegacyLipi."""
