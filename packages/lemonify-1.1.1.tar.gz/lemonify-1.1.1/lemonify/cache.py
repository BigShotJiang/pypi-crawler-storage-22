# imports
from collections import OrderedDict


# functions
class responsecache:
    def __init__(self, limit=25):
        self.limit = limit
        self.data = OrderedDict()

    def get(self, text):
        if text in self.data:
            self.data.move_to_end(text)
            return self.data[text]
        return None

    def set(self, text, result):
        self.data[text] = result
        self.data.move_to_end(text)
        if len(self.data) > self.limit:
            self.data.popitem(last=False)
