from setuptools import setup, Extension, find_packages

setup(
    name="lemonify",
    version="1.1.1",
    packages=find_packages(),
    ext_modules=[Extension("lemonify.core", ["lemonify/core.c"])],
    install_requires=["requests"],
    author="Blaze",
    description="Lemon is a free, lightweight text classifier to indentify toxicity, insult, sexuality, threat, neutrality from a sentance",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
