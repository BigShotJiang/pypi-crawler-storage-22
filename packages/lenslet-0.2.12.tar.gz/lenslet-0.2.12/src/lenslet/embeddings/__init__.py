"""Embedding detection and similarity search utilities."""
