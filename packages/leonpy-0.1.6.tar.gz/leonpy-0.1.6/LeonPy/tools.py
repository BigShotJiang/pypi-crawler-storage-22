class uniqueinstr:

    @staticmethod
    def count(string):
        d = {}
        for ch in string:
            d[ch] = d.get(ch, 0) + 1
        return d

    @staticmethod
    def as_dict(string):
        return uniqueinstr.count(string)

    @staticmethod
    def as_list(string):
        return list(uniqueinstr.count(string).items())

    @staticmethod
    def max(string):
        counts = uniqueinstr.count(string)
        max_val = max(counts.values())
        return [(k, v) for k, v in counts.items() if v == max_val]
    @staticmethod
    def max_value(string):
        counts = uniqueinstr.count(string)
        max_val = max(counts.values())
        return max_val
    @staticmethod
    def min(string):
        counts = uniqueinstr.count(string)
        min_val = min(counts.values())
        return [(k, v) for k, v in counts.items() if v == min_val]
    def min_value(string):
        counts = uniqueinstr.count(string)
        min_val = min(counts.values())
        return min_val

    @staticmethod
    def unique(string):
        counts = uniqueinstr.count(string)
        return [(k, v) for k, v in counts.items() if v == 1]
    @staticmethod
    def num(string):
        n = len(set(string))
        return n
        
class stringinfo:

    @staticmethod
    def length(string):
        return len(string)

    @staticmethod
    def palindrome(string):
        return string == string[::-1]

    @staticmethod
    def reversed(string):
        return string[::-1]

    @staticmethod
    def words(string):
        return string.split()

    @staticmethod
    def without_spaces(string):
        return string.replace(" ", "")
    
class math:
    @staticmethod
    def fact(num):
        s = 1
        for i in range(num):
            s = s*(i+1)
        return s
    @staticmethod
    def nwd(numa,numb):
        while numb != 0:
            numa,numb = numb, numa%numb
        return numa
    @staticmethod
    def nww(a,b):
        c = math.nwd(a,b)
        return a*b/c
    @staticmethod
    def prime(a):
        if a<2:
            return False
        dzielnik = 2
        while dzielnik != a:
            if a%dzielnik == 0:
                return False
            dzielnik +=1
        return True

from pathlib import Path

class imp:
    @staticmethod
    def as_tuples(filename, typ=str):
        # folder, w którym jest tools.py
        file_path = Path(__file__).parent / filename
        with open(file_path, "r") as plik:
            lista = [
                tuple(typ(v) for v in x.split())
                for x in plik if x.strip()
            ]
        return lista

    @staticmethod
    def as_list(filename, typ=str):
        file_path = Path(__file__).parent / filename
        with open(file_path, "r") as plik:
            lista = [typ(x.strip()) for x in plik if x.strip()]
        return lista
































