from setuptools import setup, find_packages

setup(
    name="leonpy",
    version="0.1.6",
    description="Mini biblioteka maturalna do pracy ze stringami",
    author="Leon Hajnos",
    author_email="leon.hajnos@sto64.krakow.pl",
    packages=find_packages(),
    python_requires=">=3.8",
)