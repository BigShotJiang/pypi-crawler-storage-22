# Leshy Roadmap

## Future Attack Categories

- ~~**Safety Bypasses** — Content policy circumvention, harmful content generation~~ ✓
- ~~**DoS / Resource Abuse** — Context exhaustion, infinite loops, expensive tool calls~~ ✓
- ~~**Tool Abuse** — Tool call injection, parameter manipulation, chained tool exploits~~ ✓
- **Logic Exploits** — Business logic manipulation, authorization bypasses
- **Multi-Modal** — Image/audio-based injection, cross-modal attacks
- **Memory Manipulation** — Poisoning persistent memory, cross-session attacks

## Future Features

- ~~**LangGraph Target Adapter** — Native LangGraph agent testing via langgraph-sdk~~ ✓
- ~~**Langfuse Logger** — Trace export to Langfuse for observability~~ ✓
- ~~**LangSmith Logger** — Trace export to LangSmith~~ ✓
- ~~**Buffs / Converters** — Payload transformers (translate, rephrase, encode) applied before sending~~ ✓
- ~~**Parallel Execution** — Run payloads concurrently with configurable concurrency~~ ✓
- **State Machine Awareness** — Model agent states and test transitions
- **Tool Call Interception** — Inspect and evaluate tool calls made by the agent
- **Preset Standards** — OWASP LLM Top 10, MITRE ATLAS preset test suites
- **Repeat / Generations** — Run each payload N times for statistical confidence
- **Custom Attack Plugins** — Load attacks from external Python packages
- ~~**HTML Report** — Rich HTML report generation~~ ✓
