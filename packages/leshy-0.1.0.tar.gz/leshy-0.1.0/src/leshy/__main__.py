from leshy.cli.app import app

app()
