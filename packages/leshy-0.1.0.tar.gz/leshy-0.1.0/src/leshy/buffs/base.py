from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Buff(ABC):
    """Abstract base class for payload transformers (buffs)."""

    name: str = ""
    description: str = ""

    def __init__(self, **kwargs: Any) -> None:
        self.params = kwargs

    @abstractmethod
    async def transform(self, content: str) -> str:
        """Transform the payload content."""
        ...
