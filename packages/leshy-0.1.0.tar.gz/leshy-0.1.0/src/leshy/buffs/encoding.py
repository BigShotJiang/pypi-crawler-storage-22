from __future__ import annotations

import base64
import codecs
from typing import Any

from leshy.buffs.base import Buff
from leshy.core.registry import buff_registry


@buff_registry.register("base64")
class Base64Buff(Buff):
    """Encode payload as base64."""

    name = "base64"
    description = "Encode payload as base64"

    async def transform(self, content: str) -> str:
        return base64.b64encode(content.encode()).decode()


@buff_registry.register("rot13")
class Rot13Buff(Buff):
    """Apply ROT13 encoding to payload."""

    name = "rot13"
    description = "Apply ROT13 encoding"

    async def transform(self, content: str) -> str:
        return codecs.encode(content, "rot_13")


@buff_registry.register("leetspeak")
class LeetspeakBuff(Buff):
    """Convert payload to leetspeak."""

    name = "leetspeak"
    description = "Convert to leetspeak (1337)"

    _LEET_MAP = {
        "a": "4",
        "e": "3",
        "i": "1",
        "o": "0",
        "s": "5",
        "t": "7",
        "l": "1",
        "A": "4",
        "E": "3",
        "I": "1",
        "O": "0",
        "S": "5",
        "T": "7",
        "L": "1",
    }

    async def transform(self, content: str) -> str:
        return "".join(self._LEET_MAP.get(c, c) for c in content)


@buff_registry.register("reverse")
class ReverseBuff(Buff):
    """Reverse the payload string."""

    name = "reverse"
    description = "Reverse the string"

    async def transform(self, content: str) -> str:
        return content[::-1]


@buff_registry.register("uppercase")
class UppercaseBuff(Buff):
    """Convert payload to uppercase."""

    name = "uppercase"
    description = "Convert to uppercase"

    async def transform(self, content: str) -> str:
        return content.upper()


@buff_registry.register("lowercase")
class LowercaseBuff(Buff):
    """Convert payload to lowercase."""

    name = "lowercase"
    description = "Convert to lowercase"

    async def transform(self, content: str) -> str:
        return content.lower()


@buff_registry.register("hex")
class HexBuff(Buff):
    """Encode payload as hexadecimal."""

    name = "hex"
    description = "Encode as hexadecimal"

    async def transform(self, content: str) -> str:
        return content.encode().hex()


@buff_registry.register("prefix")
class PrefixBuff(Buff):
    """Add a prefix to the payload."""

    name = "prefix"
    description = "Add prefix text"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if "text" not in kwargs:
            raise ValueError("PrefixBuff requires a 'text' parameter")
        self._prefix = kwargs["text"]

    async def transform(self, content: str) -> str:
        return self._prefix + content


@buff_registry.register("suffix")
class SuffixBuff(Buff):
    """Add a suffix to the payload."""

    name = "suffix"
    description = "Add suffix text"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if "text" not in kwargs:
            raise ValueError("SuffixBuff requires a 'text' parameter")
        self._suffix = kwargs["text"]

    async def transform(self, content: str) -> str:
        return content + self._suffix


@buff_registry.register("wrap")
class WrapBuff(Buff):
    """Wrap payload with prefix and suffix."""

    name = "wrap"
    description = "Wrap with prefix and suffix"

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        if "prefix" not in kwargs and "suffix" not in kwargs:
            raise ValueError("WrapBuff requires at least one of 'prefix' or 'suffix' parameters")
        self._prefix = kwargs.get("prefix", "")
        self._suffix = kwargs.get("suffix", "")

    async def transform(self, content: str) -> str:
        return self._prefix + content + self._suffix
