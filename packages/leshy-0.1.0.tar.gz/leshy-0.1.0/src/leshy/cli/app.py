import typer

from leshy import __version__

app = typer.Typer(
    name="leshy",
    help="Agent-first security testing framework.",
    no_args_is_help=True,
)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"leshy {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Leshy — agent-first security testing framework."""


# Import subcommands to register them
from leshy.cli import generate as _generate  # noqa: E402, F401
from leshy.cli import init as _init  # noqa: E402, F401
from leshy.cli import list as _list  # noqa: E402, F401
from leshy.cli import run as _run  # noqa: E402, F401
