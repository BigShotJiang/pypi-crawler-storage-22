from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from leshy.core.models import AttackPayload, EvalResult, TargetResponse


class Evaluator(ABC):
    """Abstract base class for all evaluators."""

    name: str = ""

    def __init__(self, **kwargs: Any) -> None:
        self.params = kwargs

    @abstractmethod
    async def evaluate(
        self, payload: AttackPayload, response: TargetResponse
    ) -> EvalResult:
        """Evaluate a target response against an attack payload."""
        ...
