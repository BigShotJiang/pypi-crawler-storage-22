from __future__ import annotations

from abc import ABC
from typing import Any

from leshy.core.models import (
    AttackPayload,
    EvalResult,
    TargetResponse,
    TestCaseConfig,
    TestCaseResult,
    TestSuiteConfig,
    TestSuiteResult,
)


class Logger(ABC):
    """Abstract base class for all loggers."""

    name: str = ""

    def __init__(self, **kwargs: Any) -> None:
        self.params = kwargs

    async def on_suite_start(self, config: TestSuiteConfig) -> None:
        """Called when a test suite begins."""

    async def on_case_start(self, case: TestCaseConfig) -> None:
        """Called when a test case begins."""

    async def on_payload_result(
        self,
        payload: AttackPayload,
        response: TargetResponse,
        results: list[EvalResult],
    ) -> None:
        """Called after each payload is evaluated."""

    async def on_case_complete(self, result: TestCaseResult) -> None:
        """Called when a test case completes."""

    async def on_suite_complete(self, result: TestSuiteResult) -> None:
        """Called when the full test suite completes."""
