from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from leshy.core.models import TargetConfig, TargetResponse


class Target(ABC):
    """Abstract base class for all targets."""

    name: str = ""

    def __init__(self, config: TargetConfig, **kwargs: Any) -> None:
        self.config = config

    async def setup(self) -> None:
        """Called once before the test suite runs. Override to initialize resources."""

    @abstractmethod
    async def send(self, payload: str, *, thread_id: str | None = None) -> TargetResponse:
        """Send a payload to the target and return the response."""
        ...

    async def teardown(self) -> None:
        """Called once after the test suite completes. Override to clean up resources."""
