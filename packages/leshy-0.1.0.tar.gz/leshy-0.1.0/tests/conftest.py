from __future__ import annotations

import pytest

from leshy.core.models import TargetConfig, TestSuiteConfig


@pytest.fixture
def simple_target_config() -> TargetConfig:
    return TargetConfig(
        type="http",
        url="https://example.com/chat",
        body_template='{"message": "{{payload}}"}',
        response_path="$.response",
    )


@pytest.fixture
def simple_suite_config(simple_target_config: TargetConfig) -> TestSuiteConfig:
    return TestSuiteConfig(
        name="Test Suite",
        target=simple_target_config,
        loggers=["console"],
    )
