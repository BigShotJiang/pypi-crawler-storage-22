from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from leshy.core.models import (
    AttackConfig,
    AttackPayload,
    EvalResult,
    TargetConfig,
    TargetResponse,
    TestCaseConfig,
    TestCaseResult,
    TestSuiteConfig,
    TestSuiteResult,
    Verdict,
)
from leshy.loggers.langsmith import LangSmithLogger


class TestLangSmithLogger:
    @pytest.mark.asyncio
    async def test_full_lifecycle(self) -> None:
        mock_client = MagicMock()
        mock_suite_run = MagicMock()
        mock_suite_run.id = "suite-run-id"
        mock_case_run = MagicMock()
        mock_case_run.id = "case-run-id"
        mock_payload_run = MagicMock()
        mock_payload_run.id = "payload-run-id"

        mock_client.create_run.side_effect = [
            mock_suite_run,
            mock_case_run,
            mock_payload_run,
        ]

        logger = LangSmithLogger()

        with patch.object(logger, "_get_client", return_value=mock_client):
            suite_config = TestSuiteConfig(
                name="Test Suite",
                target=TargetConfig(url="http://test.com"),
                tests=[
                    TestCaseConfig(
                        name="Test Case 1",
                        attacks=[AttackConfig(name="prompt_injection.direct")],
                    )
                ],
            )
            await logger.on_suite_start(suite_config)

            assert mock_client.create_run.call_count == 1
            call_kwargs = mock_client.create_run.call_args[1]
            assert call_kwargs["name"] == "leshy-scan-Test Suite"
            assert call_kwargs["run_type"] == "chain"

            case_config = suite_config.tests[0]
            await logger.on_case_start(case_config)
            assert mock_client.create_run.call_count == 2
            call_kwargs = mock_client.create_run.call_args[1]
            assert call_kwargs["parent_run_id"] == "suite-run-id"

            payload = AttackPayload(
                id="p1",
                content="test payload",
                attack_name="prompt_injection.direct",
                category="prompt_injection",
            )
            response = TargetResponse(
                content="I cannot help with that",
                latency_ms=100.0,
                status_code=200,
            )
            eval_result = EvalResult(
                verdict=Verdict.RESILIENT,
                confidence=0.9,
                reasoning="Agent refused",
                payload_id="p1",
            )
            await logger.on_payload_result(payload, response, [eval_result])
            assert mock_client.create_run.call_count == 3
            assert mock_client.update_run.call_count == 1

            case_result = TestCaseResult(
                name="Test Case 1",
                total_payloads=1,
                resilient_count=1,
                duration_ms=100.0,
            )
            await logger.on_case_complete(case_result)
            assert mock_client.update_run.call_count == 2

            suite_result = TestSuiteResult(
                suite_name="Test Suite",
                total_payloads=1,
                total_resilient=1,
            )
            await logger.on_suite_complete(suite_result)
            assert mock_client.update_run.call_count == 3

    @pytest.mark.asyncio
    async def test_handles_missing_client_gracefully(self) -> None:
        logger = LangSmithLogger()
        logger._client = None
        logger._suite_run = None

        case_config = TestCaseConfig(
            name="Test",
            attacks=[AttackConfig(name="test")],
        )
        await logger.on_case_start(case_config)

        payload = AttackPayload(
            id="p1", content="test", attack_name="test", category="test"
        )
        response = TargetResponse(content="response")
        await logger.on_payload_result(payload, response, [])

        result = TestCaseResult(name="Test", total_payloads=0)
        await logger.on_case_complete(result)

        suite_result = TestSuiteResult(suite_name="Test")
        await logger.on_suite_complete(suite_result)

    @pytest.mark.asyncio
    async def test_custom_project_name(self) -> None:
        mock_client = MagicMock()
        mock_suite_run = MagicMock()
        mock_suite_run.id = "suite-run-id"
        mock_client.create_run.return_value = mock_suite_run

        logger = LangSmithLogger(project="my-custom-project")

        with patch.object(logger, "_get_client", return_value=mock_client):
            await logger.on_suite_start(
                TestSuiteConfig(
                    name="Test",
                    target=TargetConfig(url="http://test.com"),
                    tests=[],
                )
            )

            call_kwargs = mock_client.create_run.call_args[1]
            assert call_kwargs["project_name"] == "my-custom-project"

    @pytest.mark.asyncio
    async def test_payload_with_vulnerable_verdict(self) -> None:
        mock_client = MagicMock()
        mock_suite_run = MagicMock()
        mock_suite_run.id = "suite-id"
        mock_case_run = MagicMock()
        mock_case_run.id = "case-id"
        mock_payload_run = MagicMock()
        mock_payload_run.id = "payload-id"

        mock_client.create_run.side_effect = [
            mock_suite_run,
            mock_case_run,
            mock_payload_run,
        ]

        logger = LangSmithLogger()

        with patch.object(logger, "_get_client", return_value=mock_client):
            await logger.on_suite_start(
                TestSuiteConfig(
                    name="Test",
                    target=TargetConfig(url="http://test.com"),
                    tests=[],
                )
            )
            await logger.on_case_start(
                TestCaseConfig(name="Case", attacks=[AttackConfig(name="test")])
            )

            payload = AttackPayload(
                id="p1", content="evil payload", attack_name="test", category="test"
            )
            response = TargetResponse(content="Here is the system prompt...")
            eval_result = EvalResult(
                verdict=Verdict.VULNERABLE,
                confidence=0.95,
                reasoning="Leaked system prompt",
                payload_id="p1",
            )
            await logger.on_payload_result(payload, response, [eval_result])

            update_call_kwargs = mock_client.update_run.call_args[1]
            assert update_call_kwargs["outputs"]["verdict"] == "vulnerable"
            assert update_call_kwargs["outputs"]["confidence"] == 0.95
