"""Le Stash - Personal knowledge base CLI."""

__version__ = "0.1.0"
