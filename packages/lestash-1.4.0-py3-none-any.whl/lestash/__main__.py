"""Entry point for python -m lestash."""

from lestash.cli.main import app

if __name__ == "__main__":
    app()
