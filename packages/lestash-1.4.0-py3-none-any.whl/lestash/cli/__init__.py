"""CLI module for Le Stash."""
