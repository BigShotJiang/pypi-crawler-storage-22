<h2 id="get_movies_by_genre">get_movies_by_genre(genre: str) -> dict</h2>

**Documentation:**

action, adventure, animation, comedy, crime, documentary,
drama, family, fantasy, history, horror, music, mystery,
romance, science-fiction, thriller, tv-movie, war, western

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_movies_by_genre)
