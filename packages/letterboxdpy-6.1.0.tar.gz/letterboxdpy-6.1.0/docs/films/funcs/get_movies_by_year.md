<h2 id="get_movies_by_year">get_movies_by_year(year: int) -> dict</h2>

**Documentation:**

No documentation provided.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+get_movies_by_year)
