<h2 id="top_users">top_users(n: int) -> List</h2>

**Documentation:**

No documentation provided.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+top_users)
