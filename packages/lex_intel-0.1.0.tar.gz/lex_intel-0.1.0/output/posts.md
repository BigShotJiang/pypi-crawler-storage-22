## Post 1: linkedin (high, en)
Ant Group open-sources Ring-2.5-1T, world's first trillion-parameter reasoning model with hybrid linear architecture. 10x memory reduction, 3x throughput improvement on 32K+ text generation. Major breakthrough for open-source AI.

---

## Post 2: devto (high, en)
**Ant Group open sources world's first trillion-parameter hybrid linear reasoning model**

Ant Group open-sources Ring-2.5-1T, world's first trillion-parameter reasoning model with hybrid linear architecture. 10x memory reduction, 3x throughput improvement on 32K+ text generation. Major breakthrough for open-source AI.

---

## Post 3: linkedin (high, zh)
蚂蚁集团开源Ring-2.5-1T万亿参数思考模型，全球首个混合线性架构。32K长文本生成访存降低10倍，吞吐提升3倍。开源领域重大突破。

---

## Post 4: linkedin (high, en)
ByteDance launches Doubao 2.0, achieving gold medals in IMO, CMO math competitions and ICPC programming contests. Outperforms Gemini 3 Pro on real-world complex task execution.

---

## Post 5: devto (high, en)
**ByteDance launches Doubao 2.0 focusing on complex real-world tasks**

ByteDance launches Doubao 2.0, achieving gold medals in IMO, CMO math competitions and ICPC programming contests. Outperforms Gemini 3 Pro on real-world complex task execution.

---

## Post 6: linkedin (high, zh)
字节跳动发布豆包2.0，斩获IMO、CMO数学竞赛及ICPC编程竞赛金牌，超越Gemini 3 Pro。真实世界复杂任务执行能力大幅提升。

---

## Post 7: linkedin (high, en)
Tsinghua-affiliated Qianjue Technology completes Pre-A++ round, raising hundreds of millions in two months. Investors include Vertex Ventures, Zhilu Capital. Scaling full-size robot deployment.

---

## Post 8: devto (high, en)
**Tsinghua-affiliated embodied AI company raises hundreds of millions**

Tsinghua-affiliated Qianjue Technology completes Pre-A++ round, raising hundreds of millions in two months. Investors include Vertex Ventures, Zhilu Capital. Scaling full-size robot deployment.

---

## Post 9: linkedin (high, zh)
清华系千诀科技完成Pre-A++轮融资，两月内融资数亿元。投资方包括祥峰资本、智路资本等。进军全尺寸机器人规模化交付。

---

## Post 10: linkedin (medium, en)
Baidu's Wenxin Assistant achieves 4x MAU growth during Spring Festival. Image generation calls up 50x, video generation up 40x. AI entry point advantage established.

---

## Post 11: devto (medium, en)
**Baidu positions for AI entry point with 4x Wenxin growth**

Baidu's Wenxin Assistant achieves 4x MAU growth during Spring Festival. Image generation calls up 50x, video generation up 40x. AI entry point advantage established.

---

## Post 12: linkedin (medium, zh)
百度文心助手春节期间MAU同比增长4倍，生图功能调用量增长50倍，生视频功能增长40倍。AI入口优势确立。

---

## Post 13: linkedin (medium, en)
Former Honor CEO Zhao Ming appointed co-chairman of Qianli Technology, stock hits daily limit. Market recognizes his terminal operations and AI commercialization expertise.

---

## Post 14: devto (medium, en)
**Former Honor CEO Zhao Ming joins Qianli Technology, stock surges**

Former Honor CEO Zhao Ming appointed co-chairman of Qianli Technology, stock hits daily limit. Market recognizes his terminal operations and AI commercialization expertise.

---

## Post 15: linkedin (medium, zh)
前荣耀CEO赵明出任千里科技联席董事长，公司股价涨停。市场高度认可其终端运营与AI商业化经验。

---

