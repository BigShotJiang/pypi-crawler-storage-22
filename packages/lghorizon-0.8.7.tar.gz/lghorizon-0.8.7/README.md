# LG Horizon Api

Python library to control multiple LG Horizon boxes
