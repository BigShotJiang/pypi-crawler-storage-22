from typing import Final

DEFAULT_HTTPX_TIMEOUT: Final[int] = 3
