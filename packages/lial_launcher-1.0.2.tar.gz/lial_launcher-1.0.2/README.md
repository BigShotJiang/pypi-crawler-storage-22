# lial-launcher

**lial-launcher** est une librairie Python pour gérer le lancement et la mise à jour d'applications Windows avec support des configurations locales et réseau, gestion des mises à jour, et impersonation d'utilisateur.

## Installation

```bash
pip install lial-launcher

