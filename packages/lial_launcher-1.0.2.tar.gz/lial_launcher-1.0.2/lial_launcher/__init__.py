"""
Launcher Tools
===============

Ce package contient les classes pour gérer le launcher et les informations utilisateur.

Modules principaux :
- launcher : contient Launcher et UserInfo
"""
from .launcher import Launcher, UserInfo
