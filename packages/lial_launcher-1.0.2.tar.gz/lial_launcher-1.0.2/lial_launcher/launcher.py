import contextlib
import logging
import os
import json
import shutil
import sys
import zipfile

import win32security

from datetime import datetime

import time
import win32event
import win32con
import subprocess


from dataclasses import dataclass


@dataclass
class UserInfo:
    """
    Représente les informations de connexion d'un utilisateur.

    Attributes:
        login (str): Nom de l'utilisateur.
        password (str): Mot de passe de l'utilisateur.
        domain (str): Domaine Windows, facultatif.
    """
    login: str
    password: str
    domain: str = ""

    @classmethod
    def from_dict(cls, data: dict):
        """
        Crée un objet UserInfo à partir d'un dictionnaire.

        Args:
            data (dict): Dictionnaire contenant 'login', 'password' et optionnellement 'domain'.

        Returns:
            UserInfo: Instance créée à partir du dictionnaire.
        """
        return cls(
            login=data.get("login", ""),
            password=data.get("password", ""),
            domain=data.get("domain", "")
        )


class Launcher:
    """
    Launcher pour gérer les mises à jour et le lancement d'une application.

    Attributes:
        base_dir (str): Chemin du dossier local de l'application.
        id_programme (str): Identifiant du programme/application.
        nom_application (str): Nom de l'exécutable principal.
        nom_launcher (str): Nom de l'exécutable du launcher (optionnel).
        logger (logging.Logger): Logger pour les messages d'activité.
        user_info (UserInfo): Informations de l'utilisateur pour l'impersonation.
        mutex_name (str): Nom du mutex utilisé pour détecter si l'application est ouverte.
        event_close (str): Nom de l'event pour demander la fermeture de l'application.
        local_dir (str): Chemin complet du dossier local de l'application.
        network_dir (str): Chemin du dossier réseau où se trouvent les mises à jour.
        config_local (dict): Configuration locale chargée depuis config.json.
        config_network (dict): Configuration réseau chargée depuis config.json.
        version (str): Version actuelle de l'application.
        """
    def __init__(self, base_dir: str, id_programme: str, network_dir: str, nom_application: str,
                 nom_launcher: str | None = None, chemin_log: str | None = None,
                 user_info: dict | None = None, mutex_name: str | None = None,
                 event_close: str | None = None):
        """
        Initialise le launcher avec les chemins, le logger et les informations utilisateur.

        Args:
            base_dir (str): Chemin du dossier local de l'application.
            id_programme (str): Identifiant du programme/application.
            network_dir (str): Chemin du dossier réseau où se trouvent les mises à jour.
            nom_application (str): Nom de l'exécutable principal.
            nom_launcher (str, optional): Nom de l'exécutable du launcher. Defaults to nom_application.
            chemin_log (str, optional): Chemin du fichier log. Defaults to None.
            user_info (dict | None, optional): Informations utilisateur pour l'impersonation. Defaults to None.
            mutex_name (str | None, optional): Nom du mutex pour vérifier si l'application est ouverte. Defaults to None.
            event_close (str | None, optional): Nom de l'event pour demander la fermeture de l'application. Defaults to None.
        """
        super().__init__()
        self.base_dir = base_dir
        self.id_programme = id_programme
        self.nom_application = nom_application
        if nom_launcher:
            self.nom_launcher = nom_launcher
        else:
            self.nom_launcher = nom_application
        self.logger = logging.getLogger(f"Launcher_{self.id_programme}")
        if chemin_log and not self.logger.handlers:
            handler = logging.FileHandler(chemin_log, encoding="utf-8")
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        self.user_info = UserInfo.from_dict(user_info)
        self.mutex_name = mutex_name
        self.event_close = event_close
        self.local_dir = os.path.join(self.base_dir, self.id_programme)

        self.network_dir = network_dir

        self.config_local = None
        self.config_network = None
        self.version = None

    def get_all_config(self):
        """
        Récupère toutes les configurations locales présentes dans le dossier de base.

        Returns:
            dict: Dictionnaire {nom_dossier: config} pour chaque sous-dossier avec config.json valide.
        """
        all_config = {}
        if not os.path.exists(self.base_dir):
            return all_config

        for name in os.listdir(self.base_dir):
            full_path = os.path.join(self.base_dir, name)

            if os.path.isdir(full_path):
                config = self.check_config(full_path)
                if config:
                    all_config[name] = config

        return all_config

    def check_update_only(self):
        """
        Vérifie si une mise à jour est nécessaire sans l'appliquer.

        Returns:
            dict: Contient :
                - update_needed (bool) : True si une mise à jour est nécessaire
                - network_config (dict ou None) : configuration réseau si disponible
        """

        with self.impersonate(self.user_info):
            self.config_local = self.check_config(self.local_dir)
            self.config_network = self.check_config(self.network_dir)
            return {
                "update_needed": self.get_update(),
                "network_config": self.config_network
            }

    def apply_update(self):
        """
        Applique la mise à jour si elle est nécessaire.
        """
        if self.get_update():
            self.update()

    def run(self):
        """
        Lancer l'application principale.
        """
        # 🚀 Lancer l'application
        chemin_exe = self.trouver_exe(local=True)
        if chemin_exe is None:
            return
        if self.launch_application(chemin_exe):
            self.fermer_launcher()

    def update(self):
        """
        Applique la mise à jour depuis le dossier réseau vers le dossier local.

        Étapes :
            1. Fermer l'application si elle est ouverte.
            2. Télécharger et décompresser le ZIP de mise à jour.
            3. Créer ou mettre à jour config.json local.
            4. Masquer les dossiers locaux et de base.

        Returns:
            None
        """
        self.version = self.config_network.get("version")
        self.logger.info(f"Launcher : Mise à jour (version {self.version}) de l'application en cours.")
        if self.fermer_application_si_ouverte() is True:
            if not self.attendre_fermeture_application():
                self.logger.error("Launcher : Impossible de mettre à jour (application encore ouverte).")
                return
        time.sleep(1)
        nom_zip = f"V {self.version}.zip"
        with self.impersonate(self.user_info):
            chemin_zip = self.trouver_zip(self.network_dir, nom_zip)
            if chemin_zip is None:
                return

            if not self.unzip_file(chemin_zip, self.local_dir):
                return

            self.create_config_local()
            self.hide_folder(self.base_dir)
            self.hide_folder(self.local_dir)
            self.logger.info(f"Launcher : Mise à jour (version {self.version}) terminé.")

    def lancer_launcher(self):
        """
        Lancer le launcher directement depuis le réseau.

        Utilise l'impersonation si user_info est fourni.

        Returns:
            bool: True si lancement réussi, False sinon.
        """
        try:
            with self.impersonate(self.user_info):
                chemin_exe = self.trouver_exe(local=False)
                if chemin_exe is None:
                    return False
                if self.launch_application(chemin_exe):
                    self.fermer_launcher()
                sys.exit(0)
        except Exception as e:
            print(e)
            self.logger.error(str(e))

    def trouver_exe(self, local=True):
        """
        Retourne le chemin complet de l'exécutable principal.

        Args:
            local (bool): True pour chercher dans le dossier local, False pour le dossier réseau.

        Returns:
            str | None: Chemin complet si trouvé, sinon None.
        """
        if local:
            dossier = self.local_dir
            nom = self.nom_application
        else:
            dossier = self.network_dir
            nom = self.nom_launcher
        exe = os.path.join(dossier, self.nom_application)
        if not exe.lower().endswith(".exe"):
            exe += ".exe"
        if os.path.exists(exe):
            return exe
        self.logger.error(f"Launcher : Application {nom} non trouvé")
        return None

    def launch_application(self, chemin_exe):
        """
        Lance l'application principale via subprocess.

        Args:
            chemin_exe (str): Chemin de l'exécutable.

        Returns:
            bool: True si le lancement a réussi, False sinon.
        """
        try:
            subprocess.Popen(
                [chemin_exe],
                cwd=self.local_dir,
                close_fds=True
            )
            print("Application lancée")
            return True
        except Exception as e:
            print(f"Impossible de lancer l'application : {e}")
            self.logger.error("Launcher : Impossible de lancer l'application : {e}")
            return False

    @staticmethod
    def hide_folder(path):
        """
        Masque un dossier sous Windows (attributs +h +s).

        Args:
            path (str): Chemin du dossier à masquer.

        Returns:
            None
        """
        subprocess.run(
            ["attrib", "+h", "+s", path],
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

    @staticmethod
    def fermer_launcher():
        """
        Ferme immédiatement le launcher.

        Returns:
            None
        """
        sys.exit(0)

    def get_update(self):
        """
        Vérifie si une mise à jour est nécessaire.

        Compare :
            - version locale vs version réseau
            - date + heure locale vs réseau

        Returns:
            bool: True si une mise à jour est nécessaire, False sinon.
        """
        if self.config_local is None:
            return True
        elif self.config_network is None:
            return False

        else:
            version_local = self.config_local.get("version")
            self.version = self.config_network.get("version")

            date_local = self.config_local.get("date")
            heure_local = self.config_local.get("heure")

            date_network = self.config_network.get("date")
            heure_network = self.config_network.get("heure")

            # Comparaison version
            if self.comparer_versions(version_local, self.version):
                return True

            # Comparaison date + heure
            elif self.comparer_date_heure(date_local, heure_local, date_network, heure_network):
                return True

            else:
                return False

    def attendre_fermeture_application(self, timeout: int = 10) -> bool:
        """
        Attend que l'application se ferme en vérifiant le mutex.

        Args:
            timeout (int): Temps maximal à attendre en secondes.

        Returns:
            bool: True si application fermée, False si timeout atteint.
        """
        if not self.mutex_name:
            return True
        start = time.time()

        while time.time() - start < timeout:
            try:
                win32event.OpenMutex(
                    win32con.SYNCHRONIZE,
                    False,
                    self.mutex_name
                )
                # Si on arrive ici → mutex existe → appli encore ouverte
                time.sleep(0.3)

            except Exception:
                # OpenMutex a échoué → mutex n'existe plus
                self.logger.info("Launcher : Application fermée")
                return True
        self.logger.error("Launcher : Timeout : application toujours ouverte")
        return False

    def fermer_application_si_ouverte(self) -> bool:
        """
        Envoie un signal à l'application pour qu'elle se ferme via l'Event Windows.

        Returns:
            bool: True si la demande a été envoyée, False sinon.
        """
        if not self.event_close:
            return False
        try:
            event = win32event.OpenEvent(
                win32con.EVENT_MODIFY_STATE,
                False,
                self.event_close
            )
            win32event.SetEvent(event)
            self.logger.info("Launcher : Demande de fermeture envoyée à l'application")
            return True
        except Exception:
            # Event inexistant → appli probablement fermée
            self.logger.info("Launcher : Aucune application à fermer")
            return False

    def unzip_file(self, chemin_zip: str, dest_dir: str) -> bool:
        """
        Décompresse un fichier ZIP vers le dossier destination, en supprimant au préalable le contenu existant.

        Args:
            chemin_zip (str): Chemin du fichier ZIP.
            dest_dir (str): Chemin du dossier où extraire le ZIP.

        Returns:
            bool: True si la décompression a réussi, False sinon.
        """
        try:
            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir, exist_ok=True)

            # 🔥 Supprimer uniquement le contenu
            for item in os.listdir(dest_dir):
                full_path = os.path.join(dest_dir, item)

                for i in range(3):
                    try:
                        if os.path.isdir(full_path):
                            shutil.rmtree(full_path)
                        else:
                            os.remove(full_path)
                        break
                    except PermissionError:
                        self.logger.error(f"Tentative {i + 1} échouée pour {full_path}")
                        time.sleep(1)
                else:
                    self.logger.error(f"Suppression impossible : {full_path}")
                    return False

            # 📦 Extraction
            with zipfile.ZipFile(chemin_zip, "r") as zip_ref:
                zip_ref.extractall(dest_dir)

            print("Décompression terminée")
            return True

        except Exception as e:
            self.logger.error(f"Launcher : Erreur décompression : {e}")
            return False

    def create_config_local(self):
        """
        Crée ou met à jour le fichier config.json local avec la version et la date/heure actuelle.

        Returns:
            None
        """
        now = datetime.now()

        config = {"version": self.version,
                  "date": now.strftime("%Y-%m-%d"),
                  "heure": now.strftime("%H:%M")}

        chemin_config = os.path.join(self.local_dir, "config.json")

        with open(chemin_config, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=4, ensure_ascii=False)

    @contextlib.contextmanager
    def impersonate(self, user_info: UserInfo):
        """
        Context manager pour exécuter des actions avec un autre utilisateur Windows.

        Args:
            user_info (UserInfo): Informations de connexion (login, password, domain).

        Yields:
            None
        """
        handle = None
        try:
            if user_info:
                if user_info.domain:
                    handle = win32security.LogonUser(
                        user_info.login,
                        user_info.domain,
                        user_info.password,
                        win32con.LOGON32_LOGON_NEW_CREDENTIALS,
                        win32con.LOGON32_PROVIDER_WINNT50

                    )
                else:
                    handle = win32security.LogonUser(
                        user_info.login,
                        user_info.domain,
                        user_info.password,
                        win32con.LOGON32_LOGON_INTERACTIVE,
                        win32con.LOGON32_PROVIDER_DEFAULT)
                win32security.ImpersonateLoggedOnUser(handle)
            yield
        finally:
            if user_info:
                win32security.RevertToSelf()
                if handle:
                    handle.Close()

    def trouver_zip(self, network_dir: str, nom_zip: str) -> str | None:
        """
        Retourne le chemin complet d'un fichier ZIP sur le réseau.

        Args:
            network_dir (str): Dossier réseau où chercher le ZIP.
            nom_zip (str): Nom du fichier ZIP.

        Returns:
            str | None: Chemin complet si trouvé, sinon None.
        """
        chemin_zip = os.path.join(network_dir, nom_zip)

        if not os.path.exists(chemin_zip):
            print(f"ZIP introuvable : {chemin_zip}")
            self.logger.error(f"Launcher : ZIP introuvable : {chemin_zip}")
            return None

        print(f"ZIP trouvé : {chemin_zip}")
        return chemin_zip

    @staticmethod
    def comparer_versions(v1: str, v2: str) -> bool:
        """
        Compare deux versions au format X.Y.Z.

        Args:
            v1 (str): Version locale.
            v2 (str): Version réseau.

        Returns:
            bool: True si v1 < v2 (mise à jour nécessaire), False sinon.
        """
        t1 = tuple(map(int, v1.split(".")))
        t2 = tuple(map(int, v2.split(".")))
        return t1 < t2

    @staticmethod
    def comparer_date_heure(d1: str, h1: str, d2: str, h2: str) -> bool:
        """
        Compare deux dates et heures.

        Args:
            d1 (str): Date locale "YYYY-MM-DD".
            h1 (str): Heure locale "HH:MM".
            d2 (str): Date réseau "YYYY-MM-DD".
            h2 (str): Heure réseau "HH:MM".

        Returns:
            bool: True si (d1 h1) < (d2 h2), False sinon.
        """
        dt1 = datetime.strptime(f"{d1} {h1}", "%Y-%m-%d %H:%M")
        dt2 = datetime.strptime(f"{d2} {h2}", "%Y-%m-%d %H:%M")
        return dt1 < dt2

    @staticmethod
    def check_config(dossier: str) -> dict | None:
        """
        Vérifie si le fichier config.json existe et est valide dans un dossier.

        Args:
            dossier (str): Chemin du dossier à vérifier.

        Returns:
            dict | None: Contenu du fichier JSON si valide, sinon None.
        """
        chemin_config = os.path.join(dossier, "config.json")

        if not os.path.exists(chemin_config):
            print(f"config.json introuvable dans {dossier}")
            return None

        try:
            with open(chemin_config, "r", encoding="utf-8") as f:
                data = json.load(f)

            return data

        except json.JSONDecodeError:
            print(f"config.json invalide dans {dossier}")
            return None
        except Exception as e:
            print(f"Erreur lors de la lecture : {e}")
            return None
