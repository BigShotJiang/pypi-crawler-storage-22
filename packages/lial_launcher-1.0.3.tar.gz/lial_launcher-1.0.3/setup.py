from setuptools import setup, find_packages

setup(
    name="lial-launcher",
    version="1.0.3",
    author="MOINE Adrien",
    description="Library to manage app launching and updating",
    packages=find_packages(),
    install_requires=[
        "pywin32",
    ],
    python_requires=">=3.10",
)

# ./setup.py sdist bdist_wheel

# twine upload dist/*
