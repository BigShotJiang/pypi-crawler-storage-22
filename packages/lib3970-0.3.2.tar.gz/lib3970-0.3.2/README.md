# About
lib3970 is a collection of functions an classes used by FRC team 3970.
