from __future__ import annotations

from xfintech.data.source.baostock.stock.stockinfo.stockinfo import StockInfo

__all__ = ["StockInfo"]
