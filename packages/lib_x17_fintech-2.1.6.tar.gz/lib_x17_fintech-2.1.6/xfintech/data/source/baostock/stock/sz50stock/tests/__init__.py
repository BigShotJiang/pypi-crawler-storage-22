"""Tests for sz50index module."""
