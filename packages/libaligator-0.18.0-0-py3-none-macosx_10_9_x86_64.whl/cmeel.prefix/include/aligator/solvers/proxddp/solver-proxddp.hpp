/// @file solver-proxddp.hpp
/// @brief  Definitions for the proximal trajectory optimization algorithm.
/// @copyright Copyright (C) 2022-2024 LAAS-CNRS, 2022-2025 INRIA
#pragma once

#include "aligator/overloads.hpp"
#include "aligator/utils/string-hash.hpp"
#include "aligator/core/linesearch-armijo.hpp"
#include "aligator/core/linesearch-nonmonotone.hpp"
#include "aligator/core/filter.hpp"
#include "aligator/core/callback-base.hpp"
#include "aligator/core/enums.hpp"
#include "aligator/core/mimalloc-resource.hpp"
#include "aligator/utils/logger.hpp"
#include "aligator/gar/riccati-base.hpp"

#include "workspace.hpp"
#include "results.hpp"

#include <boost/unordered_map.hpp>
#include <boost/version.hpp>
#include <variant>

namespace aligator {

enum class LQSolverChoice { SERIAL, PARALLEL, STAGEDENSE };

/// @brief A proximal, augmented Lagrangian-type solver for trajectory
/// optimization.
///
/// @details This class implements the Proximal Differential Dynamic Programming
/// algorithm, a variant of the augmented Lagrangian method for trajectory
/// optimization. The paper "PROXDDP: Proximal Constrained Trajectory
/// Optimization" by Jallet et al (2023) is the reference [1] for this
/// implementation.
template <typename _Scalar> struct SolverProxDDPTpl {
public:
  using Scalar = _Scalar;
  ALIGATOR_DYNAMIC_TYPEDEFS(Scalar);
  using Problem = TrajOptProblemTpl<Scalar>;
  using Workspace = WorkspaceTpl<Scalar>;
  using Results = ResultsTpl<Scalar>;
  using StageFunctionData = StageFunctionDataTpl<Scalar>;
  using CostData = CostDataAbstractTpl<Scalar>;
  using StageModel = StageModelTpl<Scalar>;
  using StageData = StageDataTpl<Scalar>;
  using CallbackPtr = shared_ptr<CallbackBaseTpl<Scalar>>;
  // boost::unordered_map support heterogeneous lookup (whereas std:: doesn't
  // until C++20). we just need to provide the right extended hash function and
  // transparent comparison op
  using CallbackMap = boost::unordered_map<std::string, CallbackPtr,
                                           ExtendedStringHash, std::equal_to<>>;
  using ConstraintStack = ConstraintStackTpl<Scalar>;
  using CstrSet = ConstraintSetTpl<Scalar>;
  using TrajOptData = TrajOptDataTpl<Scalar>;
  using LinearSolverPtr = std::unique_ptr<gar::RiccatiSolverBase<Scalar>>;

  struct LinesearchVariant {
    using VariantType = std::variant<std::monostate, ArmijoLinesearch<Scalar>,
                                     NonmonotoneLinesearch<Scalar>>;

    Scalar run(const std::function<Scalar(Scalar)> &fun, const Scalar phi0,
               const Scalar dphi0, Scalar &alpha_try) {
      return std::visit(
          overloads{[](std::monostate &) {
                      return std::numeric_limits<Scalar>::quiet_NaN();
                    },
                    [&](auto &method) {
                      return method.run(fun, phi0, dphi0, alpha_try);
                    }},
          impl_);
    }

    void reset() {
      std::visit(overloads{[](std::monostate &) {},
                           [&](auto &method) { method.reset(); }},
                 impl_);
    }

    [[nodiscard]] bool isValid() const { return impl_.index() > 0ul; }

    operator const VariantType &() const { return impl_; }

  private:
    explicit LinesearchVariant() {}
    void init(StepAcceptanceStrategy strat,
              const LinesearchOptions<Scalar> &options) {
      switch (strat) {
      case StepAcceptanceStrategy::LINESEARCH_ARMIJO:
        impl_ = ArmijoLinesearch(options);
        break;
      case StepAcceptanceStrategy::LINESEARCH_NONMONOTONE:
        impl_ = NonmonotoneLinesearch(options);
        break;
      default:
        ALIGATOR_RUNTIME_ERROR(
            "Provided StepAcceptanceStrategy value is invalid.");
        break;
      }
    }
    friend SolverProxDDPTpl;
    VariantType impl_;
  };

  struct AlmParams {
    /// \f$\alpha_\eta\f$ for primal tolerance (failure)
    Scalar prim_alpha = 0.1;
    /// \f$\beta_\eta\f$ for primal tolerance (success)
    Scalar prim_beta = 0.9;
    /// \f$\alpha_\eta\f$ for dual tolerance (failure)
    Scalar dual_alpha = 1.;
    /// \f$\beta_\eta\f$ for dual tolerance (success)
    Scalar dual_beta = 1.;
    /// Scale factor for ALM parameter.
    Scalar mu_update_factor = 0.01;
    /// Lower bound on AL parameter
    Scalar mu_lower_bound = 1e-8;
  };

  /// Subproblem tolerance
  Scalar inner_tol_;
  /// Desired primal feasibility (for each outer loop)
  Scalar prim_tol_;
  /// Solver tolerance \f$\epsilon > 0\f$. When sync_dual_tol is false, this
  /// will be the desired primal feasibility, where the dual feasibility
  /// tolerance is controlled by SolverProxDDPTpl::target_tol_dual.
  Scalar target_tol_;
  Scalar mu_init_; //< Initial AL parameter

  /// @name Inertia-correcting heuristic
  /// @{

  Scalar reg_min = 1e-10;         //< Minimal nonzero regularization
  Scalar reg_max = 1e9;           //< Maximum regularization value
  Scalar reg_init = 1e-9;         //< Initial regularization value (can be zero)
  Scalar reg_inc_k_ = 10.;        //< Regularization increase factor
  Scalar reg_inc_first_k_ = 100.; //< Regularization increase (critical)
  Scalar reg_dec_k_ = 1. / 3.;    //< Regularization decrease factor
  Scalar preg_ = reg_init;        //< Primal regularization value
  Scalar preg_last_ = 0.;         //< Last "good" regularization value

  /// @}

  Scalar inner_tol0 = 1.; //< Initial BCL inner subproblem tolerance
  Scalar prim_tol0 = 1.;  //< Initial BCL constraint infeasibility tolerance

  /// Logger
  Logger logger{};

  /// Solver verbosity level.
  VerboseLevel verbose_;
  /// Choice of linear solver
  LQSolverChoice linear_solver_choice = LQSolverChoice::SERIAL;
  /// Type of Hessian approximation. Default is Gauss-Newton.
  HessianApprox hess_approx_;
  /// Linesearch options.
  LinesearchOptions<Scalar> ls_params;
  /// Type of Lagrange multiplier update.
  MultiplierUpdateMode multiplier_update_mode = MultiplierUpdateMode::NEWTON;
  /// Linesearch mode.
  LinesearchMode ls_mode = LinesearchMode::PRIMAL;
  /// Weight of the dual variables in the primal-dual linesearch.
  Scalar dual_weight = 1.0;
  /// Type of rollout for the forward pass.
  RolloutType rollout_type_ = RolloutType::LINEAR;
  /// Parameters for the BCL outer loop of the augmented Lagrangian algorithm.
  AlmParams bcl_params;
  /// Step acceptance mode.
  StepAcceptanceStrategy sa_strategy_;

  bool force_initial_condition_ = true; //< Force initial condition @f$ x_0 @f$.
  size_t max_refinement_steps_ = 0;     //< Max KKT system refinement iters.
  Scalar refinement_threshold_ = 1e-13; //< Target tol. for the KKT system.
  size_t max_iters;                     //< Max number of Newton iterations.
  size_t max_al_iters = 100;            //< Maximum number of ALM iterations.

  mimalloc_resource memory_resource_; //< Memory resource
  polymorphic_allocator allocator_;   //< Main allocator
  Workspace workspace_;               //< Solver workspace
  Results results_;                   //< Solver results
  LinearSolverPtr linear_solver_;     //< LQR subproblem solver
  FilterTpl<Scalar> filter_;          //< Filter linesearch
  LinesearchVariant linesearch_;      //< Linesearch routine

public:
  SolverProxDDPTpl(const Scalar tol = 1e-6, const Scalar mu_init = 0.01,
                   const size_t max_iters = 1000,
                   VerboseLevel verbose = VerboseLevel::QUIET,
                   StepAcceptanceStrategy sa_strategy =
                       StepAcceptanceStrategy::LINESEARCH_NONMONOTONE,
                   HessianApprox hess_approx = HessianApprox::GAUSS_NEWTON);

  [[nodiscard]] inline size_t getNumThreads() const { return num_threads_; }
  void setNumThreads(const size_t num_threads);

  [[nodiscard]] Scalar getDualTolerance() const { return target_dual_tol_; }
  /// Manually set desired dual feasibility tolerance.
  void setDualTolerance(const Scalar tol) {
    target_dual_tol_ = tol;
    sync_dual_tol_ = false;
  }

  /// @brief    Try a step of size \f$\alpha\f$.
  /// @returns  A primal-dual trial point
  ///           \f$(\bfx \oplus\alpha\delta\bfx, \bfu+\alpha\delta\bfu,
  ///           \bmlam+\alpha\delta\bmlam)\f$
  /// @returns  The trajectory cost.
  Scalar tryLinearStep(const Problem &problem, const Scalar alpha);

  /// @brief    Policy rollout using the full nonlinear dynamics. The feedback
  /// gains need to be computed first. This will evaluate all the terms in the
  /// problem into the problem data, similar to TrajOptProblemTpl::evaluate().
  /// @returns  The trajectory cost.
  Scalar tryNonlinearRollout(const Problem &problem, const Scalar alpha);

  Scalar forwardPass(const Problem &problem, const Scalar alpha);

  void updateLQSubproblem();

  /// @brief Allocate new workspace and results instances according to the
  /// specifications of @p problem.
  /// @param problem  The problem instance with respect to which memory will be
  /// allocated.
  void setup(const Problem &problem);
  void cycleProblem(const Problem &problem, const shared_ptr<StageData> &data);

  /// @brief Run the numerical solver.
  /// @param problem  The trajectory optimization problem to solve.
  /// @param xs_init  Initial trajectory guess.
  /// @param us_init  Initial control sequence guess.
  /// @param vs_init  Initial path multiplier guess.
  /// @param lams_init  Initial co-state guess.
  /// @pre  You must call SolverProxDDP::setup beforehand to allocate a
  /// workspace and results.
  bool run(const Problem &problem, const std::vector<VectorXs> &xs_init = {},
           const std::vector<VectorXs> &us_init = {},
           const std::vector<VectorXs> &vs_init = {},
           const std::vector<VectorXs> &lams_init = {});

  /// @brief    Perform the inner loop of the algorithm (augmented Lagrangian
  /// minimization).
  bool innerLoop(const Problem &problem);

  /// @brief Compute stationarity criterion (dual infeasibility).
  void computeCriterion();

  /// @name callbacks
  /// \{

  /// @brief    Add a callback to the solver instance.
  void registerCallback(std::string_view name, CallbackPtr cb) {
#if defined(BOOST_VERSION) && BOOST_VERSION >= 107500
    callbacks_.insert_or_assign(name, cb);
#else
    callbacks_.insert_or_assign(std::string(name), cb);
#endif
  }

  /// @brief    Remove all callbacks from the instance.
  void clearCallbacks() noexcept { callbacks_.clear(); }

  const CallbackMap &getCallbacks() const { return callbacks_; }

  [[nodiscard]] bool removeCallback(std::string_view name) {
#if defined(BOOST_VERSION) && BOOST_VERSION >= 107500
    return callbacks_.erase(name);
#else
    return callbacks_.erase(std::string(name));
#endif
  }

  [[nodiscard]] auto getCallbackNames() const {
    std::vector<std::string_view> keys;
    for (const auto &item : callbacks_) {
      keys.push_back(item.first);
    }
    return keys;
  }

  [[nodiscard]] CallbackPtr getCallback(std::string_view name) const {
#if defined(BOOST_VERSION) && BOOST_VERSION >= 107500
    auto cb = callbacks_.find(name);
#else
    auto cb = callbacks_.find(std::string(name));
#endif
    if (cb != end(callbacks_)) {
      return cb->second;
    }
    return nullptr;
  }

  /// @brief    Invoke callbacks.
  void invokeCallbacks() {
    for (const auto &cb : callbacks_) {
      cb.second->call(workspace_, results_);
    }
  }
  /// \}

  /// Compute the multiplier estimates, along with the shifted, projected
  /// constraint values.
  /// @return bool: whether the op succeeded.
  /// @todo For now we take the state values to use to compute the dynamics'
  /// defects.
  bool computeMultipliers(const Problem &problem,
                          const std::vector<VectorXs> &xs,
                          const std::vector<VectorXs> &lams,
                          const std::vector<VectorXs> &vs);

  inline Scalar mu() const { return mu_penal_; }
  inline Scalar mu_inv() const { return 1. / mu_penal_; }
  /// Used in linesearch.
  inline Scalar mu_dyn() const { return 0.1 * mu_penal_; }

protected:
  Scalar target_dual_tol_; //< Solver desired dual feasibility (default: same as
                           // target_tol_)
  bool sync_dual_tol_ = true; //< If true, dual tolerance will be set to
                              // target_tol_ when run() is called.
  CallbackMap callbacks_;     //< Solver callbacks
  size_t num_threads_ = 1;    //< Number of threads
  /// Dual proximal/ALM penalty parameter \f$\mu\f$. This is the global
  /// parameter. There might be individual scaling for stagewise constraints.
  Scalar mu_penal_ = mu_init_;

  void updateTolsOnFailure() noexcept {
    const Scalar arg = std::min(mu_penal_, 0.99);
    prim_tol_ = prim_tol0 * std::pow(arg, bcl_params.prim_alpha);
    inner_tol_ = inner_tol0 * std::pow(arg, bcl_params.dual_alpha);
  }

  void updateTolsOnSuccess() noexcept {
    const Scalar arg = std::min(mu_penal_, 0.99);
    prim_tol_ = prim_tol_ * std::pow(arg, bcl_params.prim_beta);
    inner_tol_ = inner_tol_ * std::pow(arg, bcl_params.dual_beta);
  }

  /// Set dual proximal/ALM penalty parameter.
  inline void setAlmPenalty(Scalar new_mu) noexcept {
    mu_penal_ = std::max(new_mu, bcl_params.mu_lower_bound);
  }

  /// Initialize primal regularization for the inner loop.
  /// See sec. 3.1 of the IPOPT paper [Wächter, Biegler 2006]
  /// This called before first bwd pass attempt
  inline void initializeRegularization() noexcept {
    if (preg_last_ == 0.) {
      // this is the 1st iteration
      preg_ = std::max(reg_init, reg_min);
    } else {
      // attempt decrease from last "good" value
      preg_ = std::max(reg_min, preg_last_ * reg_dec_k_);
    }
  }

  inline void increaseRegularization() noexcept {
    if (preg_last_ == 0.)
      preg_ *= reg_inc_first_k_;
    else
      preg_ *= reg_inc_k_;
  }
};

#ifdef ALIGATOR_ENABLE_TEMPLATE_INSTANTIATION
extern template struct SolverProxDDPTpl<context::Scalar>;
#endif
} // namespace aligator
