#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "aligator::aligator" for configuration "Release"
set_property(TARGET aligator::aligator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(aligator::aligator PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "mimalloc"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libaligator.0.18.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libaligator.0.18.0.dylib"
  )

list(APPEND _cmake_import_check_targets aligator::aligator )
list(APPEND _cmake_import_check_files_for_aligator::aligator "${_IMPORT_PREFIX}/lib/libaligator.0.18.0.dylib" )

# Import target "aligator::croc_compat" for configuration "Release"
set_property(TARGET aligator::croc_compat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(aligator::croc_compat PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libaligator_croc_compat.0.18.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libaligator_croc_compat.0.18.0.dylib"
  )

list(APPEND _cmake_import_check_targets aligator::croc_compat )
list(APPEND _cmake_import_check_files_for_aligator::croc_compat "${_IMPORT_PREFIX}/lib/libaligator_croc_compat.0.18.0.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
