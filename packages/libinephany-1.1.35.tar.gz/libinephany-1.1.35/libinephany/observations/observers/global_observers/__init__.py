# ======================================================================================================================
#
# GLOBAL OBSERVERS PACKAGE
#
# This package contains all global observer classes used for collecting observations
# across the entire training process, not specific to individual agents.
#
# ======================================================================================================================


from .gradient_observers import GlobalFirstOrderGradients, GlobalSecondOrderGradients
from .hyperparameter_observers import InitialHyperparameters, ModelFamilyOneHot, OptimizerTypeOneHot
from .loss_observers import (
    BestObservedValidationLoss,
    LHOPTLossRatio,
    LHOPTTrainingLoss,
    LHOPTValidationLoss,
    LossRatio,
    PercentileOfLossAtEachCheckpoint,
    TrainingLoss,
    ValidationLoss,
)
from .model_observers import (
    GlobalActivations,
    GlobalLAMBTrustRatio,
    GlobalLogRatioOfUpdateAndPreviousParamNormEnvStepObserver,
    GlobalParameters,
    GlobalParameterUpdates,
    NumberOfLayers,
)
from .progress_observers import EpochsCompleted, ProgressAtEachCheckpoint, StagnationObserver, TrainingProgress

__all__ = [
    InitialHyperparameters.__name__,
    OptimizerTypeOneHot.__name__,
    ModelFamilyOneHot.__name__,
    TrainingLoss.__name__,
    ValidationLoss.__name__,
    BestObservedValidationLoss.__name__,
    LossRatio.__name__,
    GlobalFirstOrderGradients.__name__,
    GlobalSecondOrderGradients.__name__,
    GlobalActivations.__name__,
    GlobalParameterUpdates.__name__,
    GlobalParameters.__name__,
    GlobalLAMBTrustRatio.__name__,
    NumberOfLayers.__name__,
    GlobalLogRatioOfUpdateAndPreviousParamNormEnvStepObserver.__name__,
    TrainingProgress.__name__,
    EpochsCompleted.__name__,
    ProgressAtEachCheckpoint.__name__,
    LHOPTTrainingLoss.__name__,
    LHOPTValidationLoss.__name__,
    LHOPTLossRatio.__name__,
    PercentileOfLossAtEachCheckpoint.__name__,
    StagnationObserver.__name__,
]
