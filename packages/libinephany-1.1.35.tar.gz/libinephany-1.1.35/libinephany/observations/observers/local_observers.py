# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import math
from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from libinephany.observations import observation_utils, statistic_trackers
from libinephany.observations.observation_utils import StatisticStorageTypes, compute_cdf_feature
from libinephany.observations.observers.base_observers import LocalObserver
from libinephany.pydantic_models.schemas.observation_models import ObservationInputs
from libinephany.pydantic_models.schemas.tensor_statistics import TensorStatistics
from libinephany.pydantic_models.states.hyperparameter_states import HyperparameterStates
from libinephany.utils.enums import ModuleTypes
from libinephany.utils.exceptions import warn_once
from libinephany.utils.transforms import HyperparameterTransformType

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class LHOPTBaseLocalObserver(LocalObserver, ABC):
    """
    Base class for LHOPT outer step observers to eliminate duplicate code.
    """

    def __init__(
        self,
        decay_factor: float = 1.25,
        **kwargs,
    ) -> None:
        """
        :param decay_factor: Decay factor for CDF calculation in [1, 2.5, 5, 10, 20]
        :param kwargs: Other observation keyword arguments.
        """
        super().__init__(**kwargs)

        # Store time series data for CDF calculation
        self._time_series: list[tuple[float, float]] = []  # (time, value) pairs
        self._current_time: float = 0.0

        self.decay_factor = max(0.0, decay_factor)

    @property
    def can_standardize(self) -> bool:
        """
        This observer has its own CDF calculation, no need to standardize.
        :return: Whether the observation can be standardized.
        """
        return False

    @staticmethod
    def _compute_log_ratio(numerator: float, denominator: float) -> float:
        """
        Compute the log ratio.

        :param numerator: Numerator value
        :param denominator: Denominator value
        :return: Log ratio value
        """
        return float(np.clip(np.log(abs(numerator)) - np.log(abs(denominator)), a_min=-100, a_max=100))

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the StatisticStorageTypes
        enumeration class.
        """
        return StatisticStorageTypes.VECTOR

    def _compute_cdf_feature(self, value: float) -> float:
        """
        Compute CDF feature for the given value.
        training loss will be added to the time series after this call.
        :param value: The value to compute CDF feature for
        :return: CDF feature value
        """
        return compute_cdf_feature(value, self._time_series, self.decay_factor, self._current_time)

    def _update_time(self) -> None:
        """Update the current time counter."""
        self._current_time += 1.0

    @abstractmethod
    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        """

        ...

    def reset(self) -> None:
        """Reset the observer by clearing the time series."""
        self._time_series = []
        self._current_time = 0.0


class LogRatioOfPreviousAndCurrentParamNormEnvStepObserver(LHOPTBaseLocalObserver):

    def __init__(self, tanh_bound: float = 10.0, **kwargs):
        super().__init__(**kwargs)
        self.tanh_bound = tanh_bound
        self._previous_param_norm: float | None = None

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [tanh_feature, cdf_feature]

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.ParameterStatistics.__name__]

        agent_stats = statistics[self.parameter_group_name]

        current_param_norm = agent_stats.norm  # type: ignore[union-attr]

        if self._previous_param_norm is None:
            self._previous_param_norm = current_param_norm
            self._compute_cdf_feature(0.0)  # default value since we can't compute log ratio yet
            self._update_time()
            return [0.0, 0.0]

        log_ratio = self._compute_log_ratio(current_param_norm, self._previous_param_norm)
        tanh_feature = math.tanh(max(-self.tanh_bound, min(self.tanh_bound, log_ratio)))
        cdf_feature = self._compute_cdf_feature(log_ratio)
        self._update_time()
        self._previous_param_norm = current_param_norm

        return [tanh_feature, cdf_feature]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.ParameterStatistics.__name__: dict(include_statistics=self.include_statistics),
        }

    def reset(self) -> None:
        """
        Reset the observer by clearing the previous parameter norm and time series.
        """

        super().reset()
        self._previous_param_norm = None


class LHOPTMomentumGradientRatio(LHOPTBaseLocalObserver):
    """
    This is a local observer from the OpenAI paper "Learning to Optimize with Reinforcement Learning"
    https://arxiv.org/abs/2305.18291.

    It returns two-dimensional observations: [raw_value, cdf_feature] for momentum gradient ratio values.
    """

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [raw_value, cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.MomentumGradientRatioStatistics.__name__]

        raw_value = statistics[self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        return [raw_value, cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.MomentumGradientRatioStatistics.__name__: dict(
                sample_frequency=1,
            ),
        }


class LogRatioOfUpdateAndPreviousParamNormEnvStepObserver(LHOPTBaseLocalObserver):

    def __init__(self, tanh_bound: float = 10.0, **kwargs):
        super().__init__(**kwargs)
        self.tanh_bound = tanh_bound
        self._previous_param_norm: float | None = None

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [tanh_feature, cdf_feature]

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistics models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: List containing [raw_log_ratio, cdf_feature].
        """

        update_statistics = tracked_statistics[statistic_trackers.ParameterUpdateStatistics.__name__]
        param_statistics = tracked_statistics[statistic_trackers.ParameterStatistics.__name__]
        update_norm = update_statistics[self.parameter_group_name].norm  # type: ignore[union-attr]

        current_param_norm = param_statistics[self.parameter_group_name].norm  # type: ignore[union-attr]

        if self._previous_param_norm is None:
            self._previous_param_norm = current_param_norm
            self._compute_cdf_feature(0.0)  # default value since we can't compute log ratio yet
            self._update_time()
            return [0.0, 0.0]

        log_ratio = self._compute_log_ratio(update_norm, self._previous_param_norm)
        tanh_feature = math.tanh(max(-self.tanh_bound, min(self.tanh_bound, log_ratio)))
        cdf_feature = self._compute_cdf_feature(log_ratio)

        self._update_time()
        self._previous_param_norm = current_param_norm

        return [tanh_feature, cdf_feature]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.ParameterUpdateStatistics.__name__: dict(include_statistics=self.include_statistics),
            statistic_trackers.ParameterStatistics.__name__: dict(include_statistics=self.include_statistics),
        }

    def reset(self) -> None:
        """
        Reset the observer by clearing the previous parameter norm and time series.
        """

        super().reset()
        self._previous_param_norm = None


class LHOPTAverageParameterUpdateMagnitudeObserver(LHOPTBaseLocalObserver):
    def __init__(
        self,
        *,
        use_log_transform: bool = True,
        **kwargs,
    ) -> None:
        """
        :param use_log_transform: Whether to transform the raw_feature return of the Observer by ln(N).
        :param kwargs: Miscellaneous keyword arguments.
        """

        super().__init__(**kwargs)

        self.use_log_transform = use_log_transform

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [raw_feature, cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.AverageParameterUpdateMagnitudeStatistics.__name__]

        raw_feature = statistics[self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_feature)  # type: ignore[arg-type]
        self._update_time()

        if self.use_log_transform:
            raw_feature = math.log(max(raw_feature, 1e-10))  # type: ignore[type-var,arg-type]

        return [raw_feature, cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.AverageParameterUpdateMagnitudeStatistics.__name__: dict(sample_frequency=1)}


class LHOPTLAMBTrustRatio(LHOPTBaseLocalObserver):

    def __init__(
        self,
        *,
        use_log_transform: bool = True,
        **kwargs,
    ) -> None:
        """
        :param use_log_transform: Whether to transform the LAMB trust ratio by taking ln(1 + R).
        :param kwargs: Other observation keyword arguments.
        """

        super().__init__(**kwargs)

        self.use_log_transform = use_log_transform

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [raw_value, cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.LHOPTLAMBTrustRatioStatistics.__name__]

        raw_value = statistics[self.parameter_group_name]
        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        return [raw_value, cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.LHOPTLAMBTrustRatioStatistics.__name__: dict(
                use_log_transform=self.use_log_transform,
                sample_frequency=1,
            )
        }


class CosineSimilarityObserverOfGradientAndMomentum(LHOPTBaseLocalObserver):
    """
    This is a local observer from the OpenAI paper "Learning to Optimize with Reinforcement Learning"
    https://arxiv.org/abs/2305.18291.

    It returns two-dimensional observations: [raw_value, cdf_feature] for cosine similarity of gradient and momentum values.
    """

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 3  # [raw_value, cdf_feature, logit_of_cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[
            statistic_trackers.CosineSimilarityObserverOfGradientAndMomentumStatistics.__name__
        ]

        raw_value = statistics[self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        # Handle edge cases for logit calculation
        if cdf_feature <= 0.0 or cdf_feature >= 1.0:
            warn_once(f"CDF should always be in the range [0, 1], got {cdf_feature}.")
            logit_of_cdf_feature = 0.0
        else:
            logit_of_cdf_feature = math.log(cdf_feature / (1 - cdf_feature))

        return [raw_value, cdf_feature, logit_of_cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.CosineSimilarityObserverOfGradientAndMomentumStatistics.__name__: dict(
                sample_frequency=1,
            )
        }


class CosineSimilarityObserverOfGradientAndUpdate(LHOPTBaseLocalObserver):
    """
    This is a local observer from the OpenAI paper "Learning to Optimize with Reinforcement Learning"
    https://arxiv.org/abs/2305.18291.

    It returns two-dimensional observations: [raw_value, cdf_feature] for cosine similarity of gradient and update values.
    """

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 3  # [raw_value, cdf_feature, logit_of_cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[
            statistic_trackers.CosineSimilarityObserverOfGradientAndUpdateStatistics.__name__
        ]

        raw_value = statistics[self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        # Handle edge cases for logit calculation
        if cdf_feature <= 0.0 or cdf_feature >= 1.0:
            warn_once(f"CDF should always be in the range [0, 1], got {cdf_feature}.")
            logit_of_cdf_feature = 0.0
        else:
            logit_of_cdf_feature = math.log(cdf_feature / (1 - cdf_feature))

        return [raw_value, cdf_feature, logit_of_cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.CosineSimilarityObserverOfGradientAndUpdateStatistics.__name__: dict(
                sample_frequency=1,
            )
        }


class CosineSimilarityOfGradientAndParameter(LHOPTBaseLocalObserver):
    """
    This is a local observer from the OpenAI paper "Learning to Optimize with Reinforcement Learning"
    https://arxiv.org/abs/2305.18291.

    It returns two-dimensional observations: [raw_value, cdf_feature] for cosine similarity of gradient and parameter values.
    """

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 3  # [raw_value, cdf_feature, logit_of_cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.CosineSimilarityOfGradientAndParameterStatistics.__name__]

        raw_value = statistics[self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        # Handle edge cases for logit calculation
        if cdf_feature <= 0.0 or cdf_feature >= 1.0:
            warn_once(f"CDF should always be in the range [0, 1], got {cdf_feature}.")
            logit_of_cdf_feature = 0.0
        else:
            logit_of_cdf_feature = math.log(cdf_feature / (1 - cdf_feature))

        return [raw_value, cdf_feature, logit_of_cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.CosineSimilarityOfGradientAndParameterStatistics.__name__: dict(
                sample_frequency=1,
            )
        }


class LHOPTGradientVarianceFraction(LHOPTBaseLocalObserver):
    """
    This is a local observer from the OpenAI paper "Learning to Optimize with Reinforcement Learning"
    https://arxiv.org/abs/2305.18291.

    It returns two-dimensional observations: [raw_value, cdf_feature] for gradient variance fraction values.
    """

    def __init__(
        self,
        *,
        variance_threshold: float = 1e-6,
        **kwargs,
    ) -> None:
        """
        :param variance_threshold: Threshold for variance comparison in gradient variance fraction calculation
        :param kwargs: Other observation keyword arguments.
        """
        super().__init__(**kwargs)
        self.variance_threshold = variance_threshold

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [raw_value, cdf_feature]

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        raw_value = tracked_statistics[statistic_trackers.GradientVarianceFraction.__name__][self.parameter_group_name]

        cdf_feature = self._compute_cdf_feature(raw_value)  # type: ignore[arg-type]
        self._update_time()

        return [raw_value, cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.GradientVarianceFraction.__name__: dict(
                variance_threshold=self.variance_threshold, sample_frequency=1
            ),
        }


class FirstOrderGradients(LocalObserver):

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.TENSOR_STATISTICS

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.FirstOrderGradients.__name__]

        if self.parameter_group_name not in statistics:
            return TensorStatistics()

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.FirstOrderGradients.__name__: dict(include_statistics=self.include_statistics)}


class SecondOrderGradients(LocalObserver):
    # todo (tristan): we have reason to believe that this observer/tracker is wrong!
    # In fact has never been used correctly.
    # For now advised against using it

    def __init__(
        self,
        *,
        compute_hessian_diagonal: bool = False,
        **kwargs,
    ) -> None:
        """
        :param compute_hessian_diagonal: Whether to compute the Hessian diagonal to determine second order gradients
        or use the squared first order gradients as approximations in the same way Adam does.
        :param kwargs: Miscellaneous keyword arguments.
        """

        super().__init__(**kwargs)

        self.compute_hessian_diagonal = compute_hessian_diagonal

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.TENSOR_STATISTICS

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.SecondOrderGradients.__name__]

        if self.parameter_group_name not in statistics:
            return TensorStatistics()

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {
            statistic_trackers.SecondOrderGradients.__name__: dict(
                include_statistics=self.include_statistics, compute_hessian_diagonal=self.compute_hessian_diagonal
            )
        }


class Activations(LocalObserver):

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.TENSOR_STATISTICS

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.ActivationStatistics.__name__]

        if self.parameter_group_name not in statistics:
            return TensorStatistics()

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.ActivationStatistics.__name__: dict(include_statistics=self.include_statistics)}


class ParameterUpdates(LocalObserver):

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.TENSOR_STATISTICS

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.ParameterUpdateStatistics.__name__]

        if self.parameter_group_name not in statistics:
            return TensorStatistics()

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.ParameterUpdateStatistics.__name__: dict(include_statistics=self.include_statistics)}


class Parameters(LocalObserver):

    @property
    def requires_include_statistics(self) -> bool:
        """
        :return: Whether the observation requires include_statistics to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.TENSOR_STATISTICS

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.ParameterStatistics.__name__]

        if self.parameter_group_name not in statistics:
            return TensorStatistics()

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.ParameterStatistics.__name__: dict(include_statistics=self.include_statistics)}


class NumberOfParameters(LocalObserver):

    def __init__(
        self,
        *,
        use_log_transform: bool = True,
        **kwargs,
    ) -> None:
        """
        :param use_log_transform: Whether to transform the return of the Observer by ln(1 + N).
        :param kwargs: Miscellaneous keyword arguments.
        """

        super().__init__(**kwargs)

        self.use_log_transform = use_log_transform

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.FLOAT

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """
        count = tracked_statistics[statistic_trackers.NumberOfParameters.__name__][self.parameter_group_name]

        if self.use_log_transform:
            return math.log(1 + count)  # type: ignore

        else:
            return count

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.NumberOfParameters.__name__: None}


class LAMBTrustRatio(LocalObserver):

    def __init__(
        self,
        *,
        use_log_transform: bool = True,
        **kwargs,
    ) -> None:
        """
        :param use_log_transform: Whether to transform the LAMB trust ratio by taking ln(1 + R).
        :param kwargs: Other observation keyword arguments.
        """

        super().__init__(**kwargs)

        self.use_log_transform = use_log_transform

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.FLOAT

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        statistics = tracked_statistics[statistic_trackers.LAMBTrustRatioStatistics.__name__]

        if self.parameter_group_name not in statistics:
            return 0.0

        agent_stats = statistics[self.parameter_group_name]

        return agent_stats

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.LAMBTrustRatioStatistics.__name__: dict(use_log_transform=self.use_log_transform)}


class ActionOneHot(LocalObserver):

    DISCRETE_INDEX = 0

    @property
    def is_discrete(self) -> bool:
        """
        :return: Whether the agent is using discrete actions.
        """

        valid_actions = self.number_of_discrete_actions is not None and self.number_of_discrete_actions > 0
        return self.action_scheme_index == self.DISCRETE_INDEX and valid_actions

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        if self.is_discrete:
            return self.number_of_discrete_actions

        return 0

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        if not self.is_discrete:
            return []

        return observation_utils.create_one_hot_observation(
            vector_length=self.vector_length, one_hot_index=action_taken if action_taken is None else int(action_taken)
        )

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class PreviousActionRepresentation(LocalObserver):
    """
    Observer that returns the representation of the previous action taken by the agent.

    This observer tracks the previous action and returns it in an appropriate format:
    - For discrete actions: returns one-hot encoding of the previous action
    - For continuous actions: returns the previous action value directly
    """

    DISCRETE_INDEX = 0

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._previous_action: float | int | None = None

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return self.number_of_discrete_actions if self.is_discrete else 1

    @property
    def is_discrete(self) -> bool:
        """
        :return: Whether the agent is using discrete actions.
        """

        valid_actions = self.number_of_discrete_actions is not None and self.number_of_discrete_actions > 0
        return self.action_scheme_index == self.DISCRETE_INDEX and valid_actions

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """
        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in.
        """
        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        Returns the representation of the previous action.

        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Previous action representation (one-hot vector for discrete, float for continuous).
        """

        if self._previous_action is None:
            result = [0.0] * self.vector_length
        else:
            if self.is_discrete:
                result = observation_utils.create_one_hot_observation(
                    vector_length=self.vector_length, one_hot_index=int(self._previous_action)
                )
            else:
                result = [float(self._previous_action)]

        self._previous_action = action_taken

        return result

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """
        return {}

    def reset(self) -> None:
        """Resets the observer by clearing the previous action."""
        self._previous_action = None


class DepthOneHot(LocalObserver):

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        return 3

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        return observation_utils.create_one_hot_depth_encoding(
            agent_controlled_modules=list(self.observer_config.agent_modules.keys()),
            parameter_group_name=self.parameter_group_name,
        )

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class ModuleTypeOneHot(LocalObserver):

    MODULE_TYPE_TO_IDX = {
        "convolutional": 0,
        "attention": 1,
        "linear": 2,
        "embedding": 3,
        "lstm": 4,
    }

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        return len(ModuleTypes)

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        agent_modules = self.observer_config.agent_modules
        module_type = agent_modules[self.parameter_group_name]

        if module_type in {field.value for field in ModuleTypes}:
            one_hot_index = ModuleTypes.get_index(module_type)

        else:
            one_hot_index = None

        return observation_utils.create_one_hot_observation(
            vector_length=self.vector_length, one_hot_index=one_hot_index
        )

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class CurrentHyperparameters(LocalObserver):

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        if self.include_hparams is None:
            raise ValueError(f"{self.__class__.__name__} must be provided with include_hparams.")

        available_hparams = HyperparameterStates.get_layerwise_hyperparameters()

        return len([hparam for hparam in available_hparams if hparam in self.include_hparams])

    @property
    def requires_include_hparams(self) -> bool:
        """
        :return: Whether the observation requires include_hparams to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        current_internal_values = hyperparameter_states[self.parameter_group_name].get_current_internal_values(
            include_hparams=self.include_hparams
        )

        self._cached_observation = current_internal_values

        return list(current_internal_values.values())

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class CurrentHyperparameterDeltas(LocalObserver):

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        if self.include_hparams is None:
            raise ValueError(f"{self.__class__.__name__} must be provided with include_hparams.")

        available_hparams = HyperparameterStates.get_layerwise_hyperparameters()

        return len([hparam for hparam in available_hparams if hparam in self.include_hparams])

    @property
    def requires_include_hparams(self) -> bool:
        """
        :return: Whether the observation requires include_hparams to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None
        assert self.include_hparams is not None

        current_deltas = hyperparameter_states[self.parameter_group_name].get_current_deltas(
            include_hparams=self.include_hparams
        )

        self._cached_observation = current_deltas

        return list(current_deltas.values())

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class HyperparameterTransformTypes(LocalObserver):

    TRANSFORM_TYPE_TO_IDX = dict(((s, i) for i, s in enumerate(HyperparameterTransformType)))

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        if self.include_hparams is None:
            raise ValueError(f"{self.__class__.__name__} must be provided with include_hparams.")

        available_hparams = HyperparameterStates.get_layerwise_hyperparameters()

        return len(HyperparameterTransformType) * len(
            [hparam for hparam in available_hparams if hparam in self.include_hparams]
        )

    @property
    def requires_include_hparams(self) -> bool:
        """
        :return: Whether the observation requires include_hparams to be provided.
        """

        return True

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None
        assert self.include_hparams is not None

        parameter_group_hparams = hyperparameter_states[self.parameter_group_name]
        hyperparameter_transform_types = parameter_group_hparams.get_hyperparameter_transform_types(
            include_hparams=self.include_hparams
        )
        hyperparameter_transform_types_onehot_list = [
            observation_utils.create_one_hot_observation(
                vector_length=len(HyperparameterTransformType), one_hot_index=self.TRANSFORM_TYPE_TO_IDX[transform_type]
            )
            for transform_type in hyperparameter_transform_types.values()
        ]
        hyperparameter_transform_types_onehot_concat = observation_utils.concatenate_lists(
            hyperparameter_transform_types_onehot_list
        )

        return hyperparameter_transform_types_onehot_concat

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class SinusoidalDepth(LocalObserver):

    def __init__(self, dimensionality: int = 16, **kwargs) -> None:
        """
        :param dimensionality:
        :param kwargs: Miscellaneous keyword arguments.
        """

        super().__init__(**kwargs)

        assert dimensionality % 2 == 0, "Dimensionality of a sinusoidal depth encoding must be even."

        self.dimensionality = dimensionality

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """

        return self.dimensionality

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        return observation_utils.create_sinusoidal_depth_encoding(
            agent_controlled_modules=list(self.observer_config.agent_modules.keys()),
            parameter_group_name=self.parameter_group_name,
            dimensionality=self.dimensionality,
        )

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class PercentageDepth(LocalObserver):

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.FLOAT

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        assert self.parameter_group_name is not None

        modules = list(self.observer_config.agent_modules.keys())
        depth = modules.index(self.parameter_group_name)

        return depth / len(modules)

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {}


class LogOfNoiseScaleObserver(LocalObserver):
    # todo (tristan): we have reason to believe that this observer/tracker is wrong!
    # In fact has never been used correctly.
    # For now advised against using it

    def __init__(
        self,
        *,
        decay_factor: float = 1.25,
        **kwargs,
    ) -> None:
        """
        :param decay_factor: Decay factor for CDF calculation in [1, 2.5, 5, 10, 20]
        or use the squared first order gradients as approximations in the same way Adam does.
        :param kwargs: Miscellaneous keyword arguments.
        """

        super().__init__(**kwargs)

        self.decay_factor = max(0.0, decay_factor)

        # Store time series data for CDF calculation
        self._time_series: list[tuple[float, float]] = []  # (time, value) pairs
        self._current_time: float = 0.0

    @property
    def can_standardize(self) -> bool:
        """
        :return: Whether the observation can be standardized.
        """

        return False

    @property
    def can_inform(self) -> bool:
        """
        :return: Whether observations from the observer can be used in the agent info dictionary.
        """

        return False

    @property
    def vector_length(self) -> int:
        """
        :return: Length of the vector returned by this observation if it returns a vector.
        """
        return 2  # [log_noise_scale, cdf_feature]

    def _get_observation_format(self) -> StatisticStorageTypes:
        """
        :return: Format the observation returns data in. Must be one of the enum attributes in the StatisticStorageTypes
        enumeration class.
        """

        return StatisticStorageTypes.VECTOR

    def _update_time(self) -> None:
        """Update the current time counter."""
        self._current_time += 1.0

    def _compute_cdf_feature(self, value: float) -> float:
        """
        Compute CDF feature for the given value.
        training loss will be added to the time series after this call.
        :param value: The value to compute CDF feature for
        :return: CDF feature value
        """
        return compute_cdf_feature(value, self._time_series, self.decay_factor, self._current_time)

    def _observe(
        self,
        observation_inputs: ObservationInputs,
        hyperparameter_states: HyperparameterStates,
        tracked_statistics: dict[str, dict[str, float | TensorStatistics]],
        action_taken: float | int | None,
        num_categories: int | None,
    ) -> float | int | list[int | float] | TensorStatistics:
        """
        :param observation_inputs: Observation input metrics not calculated with statistic trackers.
        :param hyperparameter_states: HyperparameterStates that manages the hyperparameters.
        :param tracked_statistics: Dictionary mapping statistic tracker class names to dictionaries mapping module
        names to floats or TensorStatistic models.
        :param action_taken: Action taken by the agent this class instance is assigned to.
        :param num_categories: Number of categories, used to normalised loss based observations.
        :return: Single float/int, list of floats/ints or TensorStatistics model to add to the observation vector.
        """

        statistics = tracked_statistics[statistic_trackers.LogOfNoiseScaleStatistics.__name__]
        raw_value = statistics[self.parameter_group_name]

        assert isinstance(raw_value, float), f"Expected float, got {type(raw_value)}"  # to avoid type errors with mypy

        batch_size = hyperparameter_states.global_hparams.batch_size.external_value
        learning_rate = hyperparameter_states.parameter_group_hparams[
            self.parameter_group_name
        ].learning_rate.external_value

        log_b_over_epsilon = math.log(batch_size / learning_rate)
        log_noise_scale = raw_value + log_b_over_epsilon

        cdf_feature = self._compute_cdf_feature(log_noise_scale)  # type: ignore[arg-type]
        self._update_time()

        return [log_noise_scale, cdf_feature]  # type: ignore[list-item]

    def get_required_trackers(self) -> dict[str, dict[str, Any] | None]:
        """
        :return: Dictionary mapping statistic tracker class names to kwargs for the class or None if no kwargs are
        needed.
        """

        return {statistic_trackers.LogOfNoiseScaleStatistics.__name__: dict(sample_frequency=1)}

    def reset(self) -> None:
        """Reset the observer by clearing the time series."""
        self._time_series = []
        self._current_time = 0.0
