/*
 * SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION.
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once

#define KvikIO_VERSION_MAJOR 26
#define KvikIO_VERSION_MINOR 2
#define KvikIO_VERSION_PATCH 0
