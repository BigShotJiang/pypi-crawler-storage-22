============library.core
============
User documentation
