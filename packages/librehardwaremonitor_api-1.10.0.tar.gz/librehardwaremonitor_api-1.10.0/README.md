# LibreHardwareMonitor API Client
A Python library for interacting with the [LibreHardwareMonitor](https://github.com/LibreHardwareMonitor/LibreHardwareMonitor) API.

## Overview
This library provides a simple interface for fetching data from the API provided by the inbuilt LibreHardwareMonitor web server.

## Installation
To install the library, run the following command:
```bash
pip install librehardwaremonitor-api
```

## Usage
The `LibreHardwareMonitorClient` takes the following parameters:
* Required:
  * `host` (str): hostname or IP address of your system
  * `port` (int): port used by Libre Hardware Monitor (default: 8085)
* Optional:
  * `username` (str): if you have set up authentication for the webserver in Libre Hardware Monitor
  * `password` (str): if you have set up authentication for the webserver in Libre Hardware Monitor
  * `session` (aiohttp.ClientSession): provide a aiohttp.ClientSession

The library provides one callable method:

* `get_data`: Returns a `LibreHardwareMonitorData` object containing the computer name, main hardware device names and all sensor data from your Libre Hardware Monitor instance.

`LibreHardwareMonitorData` has 3 properties with the following structure:
```
LibreHardwareMonitorData(
    computer_name: str
    # for example: "MY_COMPUTER"

    main_device_ids_and_names: dict[DeviceId, DeviceName]
    # for example:
    # {
    #     "amdcpu-0": "AMD Ryzen 7 7800X3D",
    #     "gpu-nvidia-0": "NVIDIA GeForce RTX 4080 SUPER"
    # }
    # the dictionary keys represent a unique device id.

    sensor_data: dict[str, LibreHardwareMonitorSensorData]
    # for example
    # {
    #     "amdcpu-0-power-0": {
    #         "name": Package Power",
    #         "value": "25.6",
    #         "type": "Power",
    #         "min": "25.2",
    #         "max": "76.4",
    #         "unit": "W",
    #         "device_id": "amdcpu-0",
    #         "device_name": "AMD Ryzen 7 7800X3D",
    #         "device_type": "CPU",
    #         "sensor_id": "amdcpu-0-power-0"
    #     },
    #     "amdcpu-0-power-1" : { ... },
    #     ...
    # }
    # the dictionary keys represent a unique sensor id.
)
```

## Example
```
import asyncio
from librehardwaremonitor_api import LibreHardwareMonitorClient

async def main():
    client = LibreHardwareMonitorClient("192.168.1.100", 8085)

    lhm_data = await client.get_data()
    print(lhm_data.computer_name)
    print(lhm_data.main_device_ids_and_names)
    print(lhm_data.sensor_data)

asyncio.run(main())
```

## Development

This package uses uv as project manager.  
To set up a dev environment, clone the project and run 
````
uv sync
````
inside the project's root directory.  
Set up pre-commit hooks with:
```
uv run pre-commit install
```
Optionally, execute manually via:
```
uv run pre-commit run --all-files
```
