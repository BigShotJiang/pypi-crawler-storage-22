"""Libreria — Progetto di esempio per il corso Python."""
from .config import DURATA_PRESTITO_GIORNI,MAX_PRESTITI,NOME_LIBRERIA
from .models.libro import Libro
from .models.utente import Utente
from .services.prestiti import gestisci_prestito,restituisci_libro
from .services.ricerca import cerca_per_autore,cerca_per_titolo