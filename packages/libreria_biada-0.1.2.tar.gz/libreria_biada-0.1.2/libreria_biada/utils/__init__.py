"""Utility del progetto Libreria."""
from .formattazione import formatta_messaggio,formatta_catalogo 