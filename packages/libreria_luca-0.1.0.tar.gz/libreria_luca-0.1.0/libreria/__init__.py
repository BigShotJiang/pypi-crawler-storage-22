"""Libreria — Progetto di esempio per il corso Python."""
from .models import Libro, Utente
from.services import restituisci_libro, gestisci_prestito, cerca_per_autore, cerca_per_titolo
from .utils import formatta_catalogo, formatta_messaggio
from .config import MAX_PRESTITI, DURATA_PRESTITO_GIORNI, NOME_LIBRERIA