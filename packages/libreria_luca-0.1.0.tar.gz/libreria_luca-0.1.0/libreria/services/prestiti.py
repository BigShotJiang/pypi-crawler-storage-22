"""Servizio gestione prestiti."""

from libreria.utils.formattazione import formatta_messaggio


def gestisci_prestito(libro, utente):
    """Gestisce il prestito di un libro a un utente.

    Args:
        libro: Il libro da prestare.
        utente: L'utente che richiede il prestito.

    Returns:
        True se il prestito è andato a buon fine, False altrimenti.
    """
    if not libro.disponibile:
        print(formatta_messaggio(
            f"'{libro.titolo}' non è disponibile", successo=False
        ))
        return False

    if not utente.puo_prendere_in_prestito():
        print(formatta_messaggio(
            f"{utente.nome_completo} ha raggiunto il limite prestiti",
            successo=False
        ))
        return False

    libro.disponibile = False
    utente.aggiungi_prestito(libro)
    print(formatta_messaggio(
        f"'{libro.titolo}' prestato a {utente.nome_completo}"
    ))
    return True


def restituisci_libro(libro, utente):
    """Gestisce la restituzione di un libro.

    Args:
        libro: Il libro da restituire.
        utente: L'utente che restituisce il libro.
    """
    libro.disponibile = True
    utente.rimuovi_prestito(libro)
    print(formatta_messaggio(
        f"'{libro.titolo}' restituito da {utente.nome_completo}"
    ))
