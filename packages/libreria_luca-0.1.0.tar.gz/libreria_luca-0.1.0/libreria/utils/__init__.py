"""Utility del progetto Libreria."""
from formattazione import formatta_catalogo, formatta_messaggio 