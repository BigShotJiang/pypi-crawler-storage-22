from .models import Libro, Utente
from .utils import formatta_messaggio, formatta_catalogo
from .services import *
from .config import NOME_LIBRERIA,DURATA_PRESTITO_GIORNI,MAX_PRESTITI