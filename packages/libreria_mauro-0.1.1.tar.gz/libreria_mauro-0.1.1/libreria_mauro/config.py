"""Configurazione globale del progetto Libreria."""

MAX_PRESTITI = 3          # massimo libri in prestito per utente
DURATA_PRESTITO_GIORNI = 30
NOME_LIBRERIA = "Libreria Python"
