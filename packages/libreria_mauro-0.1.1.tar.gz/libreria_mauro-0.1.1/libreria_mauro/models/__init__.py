"""Modelli dati del progetto Libreria."""

from .libro import Libro
from .utente import Utente
