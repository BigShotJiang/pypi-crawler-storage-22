"""Modello Libro."""


class Libro:
    """Rappresenta un libro nella libreria."""

    def __init__(self, titolo, autore):
        self.titolo = titolo
        self.autore = autore
        self.disponibile = True

    def __str__(self):
        stato = "Disponibile" if self.disponibile else "In prestito"
        return f"{self.titolo} di {self.autore} ({stato})"

    def __repr__(self):
        return f"Libro('{self.titolo}', '{self.autore}')"
