"""Modello Utente."""

from libreria_mauro.config import MAX_PRESTITI


class Utente:
    """Rappresenta un utente della libreria."""

    def __init__(self, nome, cognome):
        self.nome = nome
        self.cognome = cognome
        self._libri_in_prestito = []

    @property
    def nome_completo(self):
        return f"{self.nome} {self.cognome}"

    @property
    def num_prestiti(self):
        return len(self._libri_in_prestito)

    def puo_prendere_in_prestito(self):
        """Verifica se l'utente può prendere altri libri."""
        return self.num_prestiti < MAX_PRESTITI

    def aggiungi_prestito(self, libro):
        """Aggiunge un libro alla lista prestiti dell'utente."""
        self._libri_in_prestito.append(libro)

    def rimuovi_prestito(self, libro):
        """Rimuove un libro dalla lista prestiti dell'utente."""
        self._libri_in_prestito.remove(libro)

    def lista_prestiti(self):
        """Restituisce la lista dei libri in prestito."""
        return list(self._libri_in_prestito)

    def __str__(self):
        return f"{self.nome_completo} ({self.num_prestiti}/{MAX_PRESTITI} prestiti)"
