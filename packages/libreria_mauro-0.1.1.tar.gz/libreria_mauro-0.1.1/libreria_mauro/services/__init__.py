"""Servizi del progetto Libreria."""

from .prestiti import gestisci_prestito, restituisci_libro
from .ricerca import cerca_per_titolo, cerca_per_autore
