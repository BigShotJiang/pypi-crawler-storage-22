"""Servizio ricerca libri."""


def cerca_per_titolo(catalogo, titolo):
    """Cerca libri per titolo (ricerca parziale, case-insensitive).

    Args:
        catalogo: Lista di oggetti Libro.
        titolo: Stringa da cercare nel titolo.

    Returns:
        Lista di libri che contengono la stringa nel titolo.
    """
    titolo_lower = titolo.lower()
    return [
        libro for libro in catalogo
        if titolo_lower in libro.titolo.lower()
    ]


def cerca_per_autore(catalogo, autore):
    """Cerca libri per autore (ricerca parziale, case-insensitive).

    Args:
        catalogo: Lista di oggetti Libro.
        autore: Stringa da cercare nell'autore.

    Returns:
        Lista di libri il cui autore contiene la stringa cercata.
    """
    autore_lower = autore.lower()
    return [
        libro for libro in catalogo
        if autore_lower in libro.autore.lower()
    ]
