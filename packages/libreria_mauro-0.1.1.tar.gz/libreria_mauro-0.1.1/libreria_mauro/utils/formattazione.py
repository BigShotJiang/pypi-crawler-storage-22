"""Funzioni di utilità per la formattazione dell'output."""


def formatta_messaggio(testo, successo=True):
    """Formatta un messaggio con un indicatore di stato.

    Args:
        testo: Il messaggio da formattare.
        successo: True per successo (✓), False per errore (✗).

    Returns:
        Stringa formattata con indicatore.
    """
    simbolo = "✓" if successo else "✗"
    return f"[{simbolo}] {testo}"


def formatta_catalogo(catalogo):
    """Formatta l'intero catalogo in una stringa leggibile.

    Args:
        catalogo: Lista di oggetti Libro.

    Returns:
        Stringa con l'elenco formattato dei libri.
    """
    if not catalogo:
        return "Il catalogo è vuoto."

    righe = ["═══ Catalogo Libreria ═══"]
    for i, libro in enumerate(catalogo, 1):
        righe.append(f"  {i}. {libro}")
    righe.append(f"  Totale: {len(catalogo)} libri")
    return "\n".join(righe)
