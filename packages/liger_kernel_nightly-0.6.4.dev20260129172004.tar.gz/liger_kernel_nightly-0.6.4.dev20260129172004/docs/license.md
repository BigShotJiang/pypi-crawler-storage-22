This project is licensed under the [BSD 2-CLAUSE](https://github.com/linkedin/Liger-Kernel/blob/main/LICENSE) License (see `LICENSE` for details).
It also includes components from projects licensed under:

- Apache License 2.0 (see `LICENSE-APACHE-2.0` for details).
- MIT License (see `LICENSE-MIT-AutoAWQ` for details).
- MIT License (see `LICENSE-MIT-Efficient Cross Entropy` for details).
- MIT License (see `LICENSE-MIT-llmc` for details).
- MIT License (see `LICENSE-MIT-triton` for details).