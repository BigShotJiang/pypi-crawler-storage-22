# Pyarmor 8.4.7 (basic), 004363, 2026-02-16T21:38:44.830102
from .pyarmor_runtime import __pyarmor__
