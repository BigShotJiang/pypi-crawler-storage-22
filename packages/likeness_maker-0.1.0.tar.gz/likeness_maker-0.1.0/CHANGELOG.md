# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-02-07

### Added

- Core library for creating likeness scoring models
  - `LikenessModel` class with fit, score, and weight optimization
  - Desirability functions: ADS (Asymmetric Double Sigmoid), Gaussian, Linear
  - Shannon entropy-based weight optimization
  - JSON serialization for model persistence

- Molecular module (optional, requires RDKit)
  - SDF/SMILES file reading
  - Molecular descriptor calculation (MW, ALOGP, HBD, HBA, PSA, ROTB, AROM, etc.)
  - Presets: `qed`, `qed-simple`, `lipinski`

- CLI (optional, requires typer)
  - `likeness-maker train` - Train models from molecular data
  - `likeness-maker score` - Score molecules with trained models
  - `likeness-maker list-presets` - List available presets
  - `likeness-maker list-descriptors` - List available descriptors

- Visualization module (optional, requires matplotlib)
  - `plot_desirability` - Plot desirability curves
  - `plot_score_distribution` - Score histograms with KDE
  - `plot_weights` - Feature weight bar charts
  - `plot_radar` - Spider charts for feature desirabilities
  - `plot_model_comparison` - Scatter matrix for model comparison

- Multiple optimizer backends (optional)
  - Optuna integration
  - scikit-optimize integration
  - pymoo integration

- CI/CD with GitHub Actions
  - Automated testing (Python 3.12, 3.13)
  - Linting and type checking

[0.1.0]: https://github.com/N283T/likeness-maker/releases/tag/v0.1.0
