# Likeness Maker

[![PyPI version](https://badge.fury.io/py/likeness-maker.svg)](https://badge.fury.io/py/likeness-maker)
[![CI](https://github.com/N283T/likeness-maker/actions/workflows/ci.yml/badge.svg)](https://github.com/N283T/likeness-maker/actions/workflows/ci.yml)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A Python library for creating custom "likeness" scoring metrics, inspired by the QED (Quantitative Estimate of Drug-likeness) approach.

## Overview

Likeness Maker allows you to create scoring functions that evaluate how similar a sample is to a reference dataset. It implements desirability functions and weighted geometric mean scoring, making it suitable for:

- Drug-likeness scoring (like QED)
- Quality metrics for any multi-feature dataset
- Custom similarity metrics

## Installation

```bash
pip install likeness-maker
```

Or with uv:

```bash
uv add likeness-maker
```

For molecular features (RDKit-based):

```bash
pip install likeness-maker[molecular]
```

For CLI:

```bash
pip install likeness-maker[cli]
```

## Quick Start

### Command Line Interface

Train a model from approved drugs and score new compounds:

```bash
# Train using QED-like descriptors
likeness-maker train approved_drugs.sdf -o druglikeness.json --preset qed-simple

# Score candidate molecules
likeness-maker score candidates.sdf -m druglikeness.json -o scored.csv

# List available presets
likeness-maker list-presets

# List available descriptors
likeness-maker list-descriptors
```

### Python API (Molecular)

```python
from likeness_maker.core import LikenessModel
from likeness_maker.molecular import (
    read_sdf,
    filter_valid_molecules,
    calculate_descriptors_batch,
    descriptors_to_feature_set,
    get_preset,
)

# Load reference molecules
df = read_sdf("approved_drugs.sdf")
df = filter_valid_molecules(df)
mols = df["mol"].tolist()

# Calculate descriptors
descriptor_names = ("MW", "ALOGP", "HBD", "HBA", "PSA", "ROTB", "AROM")
features = calculate_descriptors_batch(mols, descriptor_names)

# Train model
feature_set = descriptors_to_feature_set(descriptor_names)
model = LikenessModel(feature_set=feature_set)
model = model.fit(features, function_type="ads")
model = model.optimize_weights(features)  # Shannon entropy optimization

# Save model
model.to_json("druglikeness.json")

# Score new molecules
new_df = read_sdf("candidates.sdf")
new_mols = filter_valid_molecules(new_df)["mol"].tolist()
new_features = calculate_descriptors_batch(new_mols, descriptor_names)
scores = model.score(new_features)
```

### Python API (Generic)

The core library works with any numerical features, not just molecular descriptors:

```python
import numpy as np
from likeness_maker.core import LikenessModel, FeatureSet, FeatureDefinition

# Define your features
feature_set = FeatureSet(features=(
    FeatureDefinition(name="temperature", lower_bound=0, upper_bound=100),
    FeatureDefinition(name="pressure", lower_bound=0, upper_bound=10),
))

# Create reference data (what "good" samples look like)
reference_data = np.random.normal(loc=[25.0, 1.0], scale=[2.0, 0.1], size=(100, 2))

# Fit the model
model = LikenessModel(feature_set=feature_set)
fitted_model = model.fit(reference_data, function_type="gaussian")

# Score new samples
test_data = np.array([
    [25.0, 1.0],   # Should score high (similar to reference)
    [50.0, 5.0],   # Should score low (different from reference)
])
scores = fitted_model.score(test_data)
print(scores)  # e.g., [0.95, 0.12]
```

## Features

### Desirability Functions

- **ADS (Asymmetric Double Sigmoid)**: The function used in QED, suitable for bell-shaped preferences with asymmetric tails
- **Gaussian**: Symmetric bell curve centered on optimal value
- **Linear**: Simple linear ramp from bad to good (or inverted)

### Scoring

- **Geometric Mean**: Weighted geometric mean of individual desirabilities
- **Entropy-based Weights**: Automatic weight optimization using Shannon entropy (features with more discriminating power get higher weights)
- **Custom Weights**: Manually assign importance to each feature

### Presets

Built-in configurations for common use cases:

| Preset | Description | Features |
|--------|-------------|----------|
| `qed` | Original QED (8 features including ALERTS) | MW, ALOGP, HBD, HBA, PSA, ROTB, AROM, ALERTS |
| `qed-simple` | QED without structural alerts (7 features) | MW, ALOGP, HBD, HBA, PSA, ROTB, AROM |
| `lipinski` | Lipinski's Rule of Five | MW, ALOGP, HBD, HBA |

```python
from likeness_maker.molecular import get_preset, list_presets

# List available presets
print(list_presets())  # ['qed', 'qed-simple', 'lipinski']

# Get a preset configuration
preset = get_preset("qed-simple")
print(preset.description)
print(preset.feature_set.names)
```

### Available Molecular Descriptors

| Name | Description | RDKit Function |
|------|-------------|----------------|
| MW | Molecular Weight | MolWt |
| ALOGP | Wildman-Crippen LogP | MolLogP |
| HBD | Hydrogen Bond Donors | NumHDonors |
| HBA | Hydrogen Bond Acceptors | NumHAcceptors |
| PSA | Polar Surface Area | TPSA |
| ROTB | Rotatable Bonds | NumRotatableBonds |
| AROM | Aromatic Rings | NumAromaticRings |
| FRAC_CSP3 | Fraction of sp3 Carbons | FractionCSP3 |
| HEAVY_ATOMS | Heavy Atom Count | HeavyAtomCount |
| RINGS | Ring Count | RingCount |

> **Note:** The `qed` preset includes ALERTS (Structural Alerts) with pre-fitted parameters, but this descriptor is not available for calculation on new molecules.

### Serialization

Models can be saved and loaded as JSON:

```python
# Save
fitted_model.to_json("my_model.json")

# Load
loaded_model = LikenessModel.from_json("my_model.json")
```

## Architecture

The library is designed with two layers:

```
likeness_maker/
├── core/                    # Generic library (NO RDKit dependency)
│   ├── types.py             # FeatureSet, FeatureDefinition
│   ├── desirability.py      # ADS, Linear, Gaussian functions
│   ├── fitters.py           # Curve fitting (scipy)
│   ├── scoring.py           # Geometric mean scoring
│   ├── weighting.py         # Shannon entropy optimization
│   └── model.py             # LikenessModel (main API)
│
├── molecular/               # Molecule-specific (RDKit dependency)
│   ├── descriptors.py       # RDKit descriptor calculation
│   ├── io.py                # SMILES/SDF file reading
│   └── presets.py           # QED, Lipinski preset configs
│
└── cli/                     # Command-line interface
    ├── main.py              # Entry point (typer)
    ├── train.py             # Training subcommand
    └── score.py             # Scoring subcommand
```

## CLI Reference

### train

Train a likeness model from reference molecules.

```bash
likeness-maker train INPUT_FILE -o OUTPUT_MODEL [OPTIONS]
```

Options:
- `-o, --output`: Output model file (JSON)
- `-p, --preset`: Use a preset (qed, qed-simple, lipinski)
- `-d, --descriptors`: Comma-separated descriptor names
- `-f, --function`: Desirability function type (ads, linear, gaussian)
- `--optimize-weights / --no-optimize-weights`: Optimize weights using entropy

### score

Score molecules using a trained model.

```bash
likeness-maker score INPUT_FILE -m MODEL_FILE [OPTIONS]
```

Options:
- `-m, --model`: Trained model file (JSON)
- `-o, --output`: Output CSV file
- `--smiles-col`: SMILES column name for CSV input

### list-presets

List available preset configurations.

```bash
likeness-maker list-presets
```

### list-descriptors

List available molecular descriptors.

```bash
likeness-maker list-descriptors
```

## Examples

Interactive examples are available in the `examples/` directory using [marimo](https://marimo.io/):

```bash
# Run the getting started notebook
uv run marimo edit examples/getting_started.py
```

## Development

```bash
# Clone repository
git clone https://github.com/N283T/likeness-maker.git
cd likeness-maker

# Install dependencies
uv sync --all-extras --dev

# Run tests
uv run pytest

# Type checking
uv run ty check

# Linting
uv run ruff check .

# Format
uv run ruff format .
```

## References

- Bickerton, G.R., et al. (2012). Quantifying the chemical beauty of drugs. *Nature Chemistry*, 4(2), 90-98. [DOI: 10.1038/nchem.1243](https://doi.org/10.1038/nchem.1243)

## License

MIT
