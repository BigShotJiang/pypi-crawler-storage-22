# /// script
# requires-python = ">=3.12"
# dependencies = [
#     "marimo",
#     "likeness-maker[molecular]",
# ]
# ///

import marimo

__generated_with = "0.10.19"
app = marimo.App(width="medium")


@app.cell(hide_code=True)
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        # Likeness Maker - Getting Started

        This notebook demonstrates how to use the Likeness Maker library to create custom scoring metrics.
        """
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 1. Basic Usage (Generic Features)

        The core library works with any numerical features, not just molecular descriptors.
        """
    )
    return


@app.cell
def _():
    import numpy as np

    from likeness_maker.core import FeatureDefinition, FeatureSet, LikenessModel

    return FeatureDefinition, FeatureSet, LikenessModel, np


@app.cell
def _(FeatureDefinition, FeatureSet):
    # Define features with optional bounds
    feature_set = FeatureSet(
        features=(
            FeatureDefinition(name="temperature", lower_bound=0, upper_bound=100),
            FeatureDefinition(name="pressure", lower_bound=0, upper_bound=10),
            FeatureDefinition(name="humidity", lower_bound=0, upper_bound=100),
        )
    )

    print(f"Features: {feature_set.names}")
    print(f"Number of features: {len(feature_set)}")
    return (feature_set,)


@app.cell
def _(np):
    # Generate synthetic reference data
    # This represents "ideal" conditions
    np.random.seed(42)
    reference_data = np.column_stack(
        [
            np.random.normal(25.0, 2.0, 100),  # temperature around 25°C
            np.random.normal(1.0, 0.1, 100),  # pressure around 1 atm
            np.random.normal(50.0, 5.0, 100),  # humidity around 50%
        ]
    )

    print(f"Reference data shape: {reference_data.shape}")
    print(f"Temperature range: {reference_data[:, 0].min():.1f} - {reference_data[:, 0].max():.1f}")
    print(f"Pressure range: {reference_data[:, 1].min():.2f} - {reference_data[:, 1].max():.2f}")
    print(f"Humidity range: {reference_data[:, 2].min():.1f} - {reference_data[:, 2].max():.1f}")
    return (reference_data,)


@app.cell
def _(LikenessModel, feature_set, reference_data):
    # Create and fit the model
    model = LikenessModel(feature_set=feature_set)
    fitted_model = model.fit(reference_data, function_type="gaussian")

    print(f"Model fitted with {len(fitted_model.fitted_functions)} functions")
    print(f"Weight scheme: {fitted_model.weight_scheme}")
    return fitted_model, model


@app.cell
def _(fitted_model, np):
    # Score new samples
    test_data = np.array(
        [
            [25.0, 1.0, 50.0],  # Ideal conditions
            [30.0, 1.2, 60.0],  # Slightly off
            [40.0, 2.0, 80.0],  # Far from ideal
            [10.0, 0.5, 20.0],  # Very different
        ]
    )

    scores = fitted_model.score(test_data)

    for i, (sample, score) in enumerate(zip(test_data, scores, strict=True)):
        print(
            f"Sample {i + 1}: T={sample[0]:.0f}°C, P={sample[1]:.1f}atm, H={sample[2]:.0f}% -> Score: {score:.3f}"
        )
    return scores, test_data


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 2. Detailed Scoring

        Get per-feature desirability scores to understand which features contribute most.
        """
    )
    return


@app.cell
def _(fitted_model, test_data):
    # Get detailed breakdown
    detailed = fitted_model.score_detailed(test_data)
    detailed  # noqa: B018 (marimo display)
    return (detailed,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 3. Model Serialization

        Save and load models as JSON files.
        """
    )
    return


@app.cell
def _(LikenessModel, fitted_model, np, scores, test_data):
    import os
    import tempfile

    # Save model
    with tempfile.TemporaryDirectory() as tmpdir:
        model_path = os.path.join(tmpdir, "model.json")
        fitted_model.to_json(model_path)

        # Load and use
        loaded_model = LikenessModel.from_json(model_path)
        loaded_scores = loaded_model.score(test_data)

        print("Original scores:", scores)
        print("Loaded scores:  ", loaded_scores)
        print("Match:", np.allclose(scores, loaded_scores))
    return loaded_model, loaded_scores, model_path, os, tempfile, tmpdir


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 4. Molecular Features (RDKit)

        The molecular module provides RDKit-based descriptor calculation.

        > **Note:** This section requires RDKit. Install with: `pip install likeness-maker[molecular]`
        """
    )
    return


@app.cell
def _():
    from rdkit import Chem

    from likeness_maker.molecular import (
        DESCRIPTOR_REGISTRY,
        calculate_descriptors,
        calculate_descriptors_batch,
        descriptors_to_feature_set,
    )

    return (
        Chem,
        DESCRIPTOR_REGISTRY,
        calculate_descriptors,
        calculate_descriptors_batch,
        descriptors_to_feature_set,
    )


@app.cell
def _(DESCRIPTOR_REGISTRY):
    # Available descriptors
    print("Available descriptors:")
    for name, defn in DESCRIPTOR_REGISTRY.items():
        print(f"  {name}: {defn.full_name}")
    return defn, name


@app.cell
def _(Chem):
    # Create some molecules
    smiles_list = [
        "CC(=O)Oc1ccccc1C(=O)O",  # Aspirin
        "CC(C)Cc1ccc(cc1)C(C)C(=O)O",  # Ibuprofen
        "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",  # Caffeine
        "c1ccc2c(c1)cc3ccc4cccc5ccc2c3c45",  # Coronene (large PAH)
    ]

    mols = [Chem.MolFromSmiles(smi) for smi in smiles_list]
    mol_names = ["Aspirin", "Ibuprofen", "Caffeine", "Coronene"]
    return mol_names, mols, smiles_list


@app.cell
def _(calculate_descriptors, mols):
    # Calculate descriptors for a single molecule
    aspirin = mols[0]
    descriptors = calculate_descriptors(aspirin)
    print("Aspirin descriptors:")
    for desc_name, value in descriptors.items():
        print(f"  {desc_name}: {value:.2f}")
    return aspirin, desc_name, descriptors, value


@app.cell
def _(calculate_descriptors_batch, mol_names, mols):
    # Batch calculation
    descriptor_names = ("MW", "ALOGP", "HBD", "HBA", "PSA")
    features = calculate_descriptors_batch(mols, descriptor_names)

    print(f"Descriptor matrix shape: {features.shape}")
    print("\nDescriptors for each molecule:")
    for i, mol_name in enumerate(mol_names):
        print(f"  {mol_name}: {features[i]}")
    return descriptor_names, features, i, mol_name


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 5. Using Presets

        Built-in configurations for common use cases like QED and Lipinski.
        """
    )
    return


@app.cell
def _():
    from likeness_maker.molecular import get_preset, list_presets

    return get_preset, list_presets


@app.cell
def _(list_presets):
    # Available presets
    print("Available presets:", list_presets())
    return


@app.cell
def _(get_preset):
    # Load QED-simple preset (without structural alerts)
    qed_preset = get_preset("qed-simple")

    print(f"Preset: {qed_preset.name}")
    print(f"Description: {qed_preset.description}")
    print(f"Features: {qed_preset.feature_set.names}")
    print(f"Weights: {qed_preset.weights}")
    return (qed_preset,)


@app.cell
def _(LikenessModel, calculate_descriptors_batch, mol_names, mols, qed_preset):
    # Create model from preset
    qed_model = LikenessModel(
        feature_set=qed_preset.feature_set,
        fitted_functions=qed_preset.fitted_functions,
        weights=qed_preset.weights,
    )

    # Calculate QED-like scores
    qed_descriptors = calculate_descriptors_batch(mols, tuple(qed_preset.feature_set.names))
    qed_scores = qed_model.score(qed_descriptors)

    print("QED-like scores:")
    for mol_name, qed_score in zip(mol_names, qed_scores, strict=True):
        print(f"  {mol_name}: {qed_score:.3f}")
    return qed_descriptors, qed_model, qed_score, qed_scores


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## 6. Training a Custom Model

        Train a model on your own reference dataset.
        """
    )
    return


@app.cell
def _(Chem):
    # Create a set of "drug-like" reference molecules
    drug_smiles = [
        "CC(=O)Oc1ccccc1C(=O)O",  # Aspirin
        "CC(C)Cc1ccc(cc1)C(C)C(=O)O",  # Ibuprofen
        "CN1C=NC2=C1C(=O)N(C(=O)N2C)C",  # Caffeine
        "CC(=O)Nc1ccc(cc1)O",  # Paracetamol
        "OC(=O)Cc1ccccc1Nc2c(Cl)cccc2Cl",  # Diclofenac
        "COc1ccc2[nH]c(nc2c1)S(=O)Cc3ncc(C)c(OC)c3C",  # Omeprazole
        "CC(C)NCC(O)c1ccc(O)c(O)c1",  # Isoprenaline
        "CNCCC=C1c2ccccc2CCc3ccccc13",  # Amitriptyline
        "CN1CCN(CC1)c2ccc(cc2)OCC3COC(Cn4ccnc4)(O3)c5ccc(Cl)cc5Cl",  # Ketoconazole
        "CC(=O)OCC(=O)C12C(C)CC3C4CCC5=CC(=O)CCC5(C)C4CCC3(F)C12C",  # Fluocinonide
        "COc1ccc2cc(CCC(=O)O)ccc2c1",  # Naproxen (simplified)
        "Cc1ccc(cc1)c2cc(nn2c3ccc(cc3)S(=O)(=O)N)C(F)(F)F",  # Celecoxib
    ]

    drug_mols = [Chem.MolFromSmiles(smi) for smi in drug_smiles]
    print(f"Reference molecules: {len(drug_mols)}")
    return drug_mols, drug_smiles


@app.cell
def _(
    LikenessModel,
    calculate_descriptors_batch,
    descriptors_to_feature_set,
    drug_mols,
):
    # Calculate descriptors
    custom_descriptor_names = ("MW", "ALOGP", "HBD", "HBA", "PSA", "ROTB")
    drug_features = calculate_descriptors_batch(drug_mols, custom_descriptor_names)

    # Build feature set
    custom_feature_set = descriptors_to_feature_set(custom_descriptor_names)

    # Train model with ADS functions
    custom_model = LikenessModel(feature_set=custom_feature_set)
    custom_model = custom_model.fit(drug_features, function_type="ads")

    # Optimize weights using entropy
    custom_model = custom_model.optimize_weights(drug_features)

    print(f"Weight scheme: {custom_model.weight_scheme}")
    print(f"Weights: {custom_model.weights}")
    return (
        custom_descriptor_names,
        custom_feature_set,
        custom_model,
        drug_features,
    )


@app.cell
def _(Chem, calculate_descriptors_batch, custom_descriptor_names, custom_model):
    # Score test molecules
    custom_test_smiles = [
        "CC(=O)Nc1ccc(cc1)O",  # Paracetamol (drug-like)
        "c1ccccc1",  # Benzene (not drug-like)
        "CCCCCCCCCCCCCCCCCCCC",  # Long alkane (not drug-like)
    ]
    custom_test_names = ["Paracetamol", "Benzene", "Icosane"]
    custom_test_mols = [Chem.MolFromSmiles(smi) for smi in custom_test_smiles]
    custom_test_features = calculate_descriptors_batch(custom_test_mols, custom_descriptor_names)

    custom_scores = custom_model.score(custom_test_features)

    print("Custom model scores:")
    for test_name, custom_score in zip(custom_test_names, custom_scores, strict=True):
        print(f"  {test_name}: {custom_score:.3f}")
    return (
        custom_score,
        custom_scores,
        custom_test_features,
        custom_test_mols,
        custom_test_names,
        custom_test_smiles,
        test_name,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
        ## Summary

        Key concepts covered:

        1. **FeatureSet & FeatureDefinition**: Define your features with optional bounds
        2. **LikenessModel.fit()**: Train desirability functions on reference data
        3. **LikenessModel.score()**: Score new samples against the model
        4. **Presets**: Use built-in configurations (qed, qed-simple, lipinski)
        5. **Serialization**: Save/load models as JSON
        6. **Weight optimization**: Use Shannon entropy to optimize feature weights
        """
    )
    return


if __name__ == "__main__":
    app.run()
