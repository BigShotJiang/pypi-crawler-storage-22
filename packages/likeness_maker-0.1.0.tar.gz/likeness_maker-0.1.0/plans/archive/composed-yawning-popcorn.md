# Likeness Maker - Implementation Plan

## Overview

QED (Quantitative Estimate of Drug-likeness) のアプローチを汎用化し、任意のデータセットで"likeness"指標を作成できるツールを開発する。

## Architecture

```
likeness_maker/
├── core/                    # Generic library (NO RDKit dependency)
│   ├── types.py             # FeatureSet, FeatureDefinition
│   ├── desirability.py      # ADS, Linear, Gaussian functions
│   ├── fitters.py           # Curve fitting (scipy)
│   ├── scoring.py           # Geometric mean scoring
│   ├── weighting.py         # Shannon entropy optimization
│   └── model.py             # LikenessModel (main API)
│
├── molecular/               # Molecule-specific (RDKit dependency)
│   ├── descriptors.py       # RDKit descriptor calculation
│   ├── io.py                # SMILES/SDF file reading
│   ├── alerts.py            # Structural alerts (SMARTS)
│   └── presets.py           # QED, Lipinski preset configs
│
└── cli/                     # Command-line interface
    ├── main.py              # Entry point (typer)
    ├── train.py             # Training subcommand
    └── score.py             # Scoring subcommand
```

## Key Design Decisions

1. **Two-layer separation**: Core library is RDKit-independent (generic), molecular layer adds chemistry
2. **Immutable dataclasses**: All data structures are frozen for safety
3. **Plugin registry**: Extensible desirability functions
4. **JSON serialization**: Human-readable model files

## Implementation Strategy

**進め方**: Phase 1から順番に実装
**テストデータ**: 後で決定（まずはコア実装を優先）

## Implementation Phases

### Phase 1: Core Library Foundation ✅ COMPLETE
- [x] Project structure setup (`src/likeness_maker/`)
- [x] `core/types.py` - FeatureSet, FeatureDefinition dataclasses
- [x] `core/desirability.py` - ADS, Linear desirability functions
- [x] `core/fitters.py` - ADS curve fitting with scipy
- [x] `core/scoring.py` - Geometric mean scoring
- [x] Unit tests for core components (pytest)

### Phase 2: Weight Optimization ✅ COMPLETE
- [x] `core/weighting.py` - Shannon entropy weight optimization
- [x] `core/model.py` - LikenessModel class (train/score API)
- [x] JSON serialization/deserialization
- [x] Integration tests

### Phase 3: Molecular Layer ✅ COMPLETE
- [x] `molecular/io.py` - SMILES/SDF file reading
- [x] `molecular/descriptors.py` - RDKit descriptor calculation
- [ ] `molecular/alerts.py` - Structural alerts (deferred)
- [x] `molecular/presets.py` - QED, Lipinski presets
- [x] Tests with real molecule data (DrugBank approved)

### Phase 4: CLI ✅ COMPLETE
- [x] `cli/main.py` - typer CLI setup
- [x] `cli/train.py` - `likeness-maker train` command
- [x] `cli/score.py` - `likeness-maker score` command
- [x] CLI tests

### Phase 5: Documentation & Polish ✅ COMPLETE
- [x] README with examples
- [x] Example notebook (examples/getting_started.ipynb)

## Technical Details

### QED Mathematical Approach

**Desirability Function**: Asymmetric Double Sigmoid (ADS)
```
d(x) = a + b / (1 + exp(-(x - c + d/2) / e)) * (1 - 1 / (1 + exp(-(x - c - d/2) / f)))
```

**Final Score**: Weighted geometric mean
```
QED = exp(sum(w_i * ln(d_i)) / sum(w_i))
```

**Weight Optimization**: Shannon entropy maximization

### Dependencies

```toml
[project]
dependencies = [
    "numpy>=1.24",
    "pandas>=2.0",
    "scipy>=1.10",
]

[project.optional-dependencies]
molecular = ["rdkit>=2023.03"]
cli = ["typer>=0.9", "rich>=13.0"]
```

## Usage Examples

### Python Library (Generic)
```python
from likeness_maker.core import LikenessModel, FeatureSet, FeatureDefinition

feature_set = FeatureSet(features=(
    FeatureDefinition("temperature"),
    FeatureDefinition("pressure"),
))

model = LikenessModel(feature_set=feature_set)
model = model.fit(reference_data, function_type="ads")
scores = model.score(new_data)
```

### Python Library (Molecular)
```python
from likeness_maker.molecular import MolecularDescriptorCalculator, read_molecules
from likeness_maker.core import LikenessModel

ref_df = read_molecules("approved_drugs.sdf")
calculator = MolecularDescriptorCalculator(descriptor_names=("MW", "ALOGP", "HBD", "HBA"))
descriptors = calculator.calculate_batch(ref_df['Molecule'])

model = LikenessModel(feature_set=calculator.to_feature_set())
model = model.fit(descriptors)
```

### CLI
```bash
likeness-maker train approved_drugs.sdf -o druglikeness.json --descriptors qed
likeness-maker score candidates.csv --model druglikeness.json -o scored.csv
```

## Verification

- [x] Core unit tests pass (97% coverage)
- [x] Integration tests with real molecule data
- [x] CLI tests (13 tests)
- [x] `uv run pytest` passes (151 tests, 95% coverage)
- [x] `ruff check .` passes
- [x] `ty check` passes

---
- [x] **DONE** - All phases complete
