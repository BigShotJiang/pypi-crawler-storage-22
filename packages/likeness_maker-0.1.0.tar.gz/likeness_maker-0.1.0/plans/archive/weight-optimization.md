# Weight Optimization Enhancement Plan

## Overview

重み最適化機能を拡張し、Optuna等を使った目的関数ベースの最適化を追加する。

## 現状

```python
# 現在: entropy ベースのみ
model = model.optimize_weights(features)  # Shannon entropy
```

- `compute_entropy_weights()`: 各特徴量の desirability 分布のエントロピーで重み付け
- `optimize_weights_iterative()`: 勾配法でスコア分布のエントロピー最大化（未使用）

## 目標

```python
# 目的関数ベースの最適化
model = model.optimize_weights(
    features,
    labels=labels,              # active/inactive ラベル
    objective="roc_auc",        # 目的関数
    optimizer="optuna",         # 最適化手法
    n_trials=100,               # Optuna trials
)
```

## 設計

### 目的関数 (Objectives)

| Name | Description | Requires Labels |
|------|-------------|-----------------|
| `entropy` | Score distribution entropy (現状) | No |
| `roc_auc` | ROC-AUC score | Yes |
| `enrichment` | Enrichment factor at X% | Yes |
| `bedroc` | BEDROC (早期認識重視) | Yes |

### 最適化手法 (Optimizers)

| Name | Library | Description |
|------|---------|-------------|
| `entropy` | numpy | 現状の Shannon entropy ベース |
| `optuna` | optuna | TPE/CMA-ES ベイズ最適化 |
| `scipy` | scipy | SLSQP/L-BFGS-B 勾配法 |

### ファイル構成

```
src/likeness_maker/core/
├── weighting.py          # 既存 (entropy weights)
├── objectives.py         # NEW: 目的関数定義
└── optimizers/           # NEW: 最適化手法
    ├── __init__.py
    ├── base.py           # BaseOptimizer ABC
    ├── entropy.py        # EntropyOptimizer (現状移植)
    ├── optuna.py         # OptunaOptimizer
    └── scipy.py          # ScipyOptimizer
```

### API設計

```python
# core/objectives.py
def roc_auc_objective(scores: NDArray, labels: NDArray) -> float:
    """Higher is better."""
    from sklearn.metrics import roc_auc_score
    return roc_auc_score(labels, scores)

def enrichment_objective(scores: NDArray, labels: NDArray, fraction: float = 0.01) -> float:
    """Enrichment factor at top X%."""
    ...

OBJECTIVE_REGISTRY = {
    "entropy": entropy_objective,
    "roc_auc": roc_auc_objective,
    "enrichment": enrichment_objective,
}
```

```python
# core/optimizers/optuna.py
class OptunaOptimizer(BaseOptimizer):
    def optimize(
        self,
        desirabilities: NDArray,
        labels: NDArray | None,
        objective_fn: Callable,
        n_trials: int = 100,
    ) -> NDArray:
        import optuna

        def objective(trial):
            weights = [trial.suggest_float(f"w_{i}", 0.01, 1.0) for i in range(n_features)]
            weights = np.array(weights) / sum(weights)
            scores = weighted_geometric_mean(desirabilities, weights)
            return objective_fn(scores, labels)

        study = optuna.create_study(direction="maximize")
        study.optimize(objective, n_trials=n_trials)
        return normalize(study.best_params)
```

```python
# model.py の変更
def optimize_weights(
    self,
    features: NDArray,
    labels: NDArray | None = None,
    objective: str = "entropy",
    optimizer: str = "entropy",
    **optimizer_kwargs,
) -> LikenessModel:
    """Optimize feature weights.

    Args:
        features: Feature values.
        labels: Binary labels for supervised objectives (0/1).
        objective: Objective function ("entropy", "roc_auc", "enrichment").
        optimizer: Optimization method ("entropy", "optuna", "scipy").
        **optimizer_kwargs: Additional args (n_trials, etc.)
    """
    ...
```

### 依存関係

```toml
[project.optional-dependencies]
optimize = ["optuna>=3.0", "scikit-learn>=1.0"]
```

## Implementation Phases

### Phase 1: 基盤 ✅
- [x] `core/objectives.py` - 目的関数レジストリ
- [x] `core/optimizers/base.py` - BaseOptimizer ABC
- [x] `core/optimizers/entropy.py` - 現状の移植

### Phase 2: Optuna ✅
- [x] `core/optimizers/optuna_opt.py` - Optuna optimizer
- [x] Tests with mock labels

### Phase 3: Scipy ✅
- [x] `core/optimizers/scipy_opt.py` - Scipy optimizer
- [x] Comparison tests

### Phase 4: Integration ✅
- [x] `model.optimize_weights()` 拡張
- [x] CLI `--optimizer` オプション追加
- [x] Documentation update

## Verification

```python
# テストケース
def test_optuna_improves_auc():
    model = model.fit(features)

    # Before
    scores_before = model.score(test_features)
    auc_before = roc_auc_score(test_labels, scores_before)

    # Optimize
    model = model.optimize_weights(
        features, labels,
        objective="roc_auc",
        optimizer="optuna",
        n_trials=50,
    )

    # After
    scores_after = model.score(test_features)
    auc_after = roc_auc_score(test_labels, scores_after)

    assert auc_after >= auc_before
```

## Design Decisions

1. **ラベルの扱い**: 別引数 `labels` で渡す
2. **Cross-validation**: Optuna 内で K-fold CV（過学習防止）
3. **Feature selection**: `min_weight` パラメータで制御
   - Default: `min_weight=0.01` (QED と同様、全特徴量使用)
   - `min_weight=0.0` で特徴量選択モード

```python
model.optimize_weights(
    features,
    labels=labels,
    objective="roc_auc",
    optimizer="optuna",
    n_trials=100,
    cv_folds=5,           # Optuna 内で 5-fold CV
    min_weight=0.01,      # 最小重み (0.0 で特徴量選択可)
)
```

---
- [x] **DONE** - Implementation complete
