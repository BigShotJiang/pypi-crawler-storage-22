# Paper Draft: Likeness-Maker

## Overview

likeness-makerについてのApplication Note / Short Communicationを書く。

---

## Target Journals

| Journal | Type | Length | IF | Notes |
|---------|------|--------|-----|-------|
| **JCIM** | Application Note | 2-4 pages | 6.2 | 化学情報学の主要誌 |
| **Bioinformatics** | Application Note | 2 pages | 5.8 | 汎用性アピール可 |
| **J Cheminform** | Software | 4-6 pages | 8.6 | Open access, 詳細書ける |
| **F1000Research** | Software Tool | flexible | 3.0 | 査読後公開、早い |

**第一候補**: J Cheminform (詳細に書ける、OA)

---

## Title Ideas

- "Likeness-Maker: A Generalized Framework for Creating QED-like Scoring Functions"
- "Beyond QED: A Flexible Framework for Building Domain-Specific Likeness Scores"
- "Likeness-Maker: Extensible Desirability-Based Scoring for Molecular Design"

---

## Abstract Structure (150-200 words)

1. **Background**: QEDはdrug-likenessの定量評価に成功したが、特定ドメインに特化
2. **Problem**: 任意のデータセット (NP, fragments, proteins) に適用できる汎用ツールがない
3. **Solution**: likeness-makerを開発 - 11種のdesirability関数、14種のオプティマイザ
4. **Results**: QED再現 + NP-likeness case study
5. **Availability**: GitHub, PyPI, MCP server

---

## Paper Structure

### 1. Introduction
- QEDの成功と限界
- 他のlikeness指標 (NP-likeness, lead-likeness)
- 汎用フレームワークの必要性
- 本研究の貢献

### 2. Methods / Implementation
- アーキテクチャ (core vs molecular layer)
- Desirability関数 (11種)
- 重み最適化 (14種)
- Per-feature customization

### 3. Results
#### 3.1 QED Reproduction
- ChEMBL approved drugsでオリジナルQEDと比較
- 相関 (Pearson r > 0.95期待)

#### 3.2 NP-likeness Case Study
- COCONUT データ
- Drug vs NP 分離性能
- 既存NP-likeness scorerとの比較

#### 3.3 Beyond Molecules (Optional)
- タンパク質特徴量への応用例

### 4. Discussion
- 他手法との比較
- Limitations
- Future work (MCP server, more case studies)

### 5. Availability
- GitHub URL
- PyPI package
- Documentation
- License (MIT)

---

## Figures

| Fig | Content | Type |
|-----|---------|------|
| 1 | Framework overview | Schematic |
| 2 | Desirability function gallery | Multi-panel |
| 3 | QED comparison scatter plot | Results |
| 4 | NP-likeness ROC curve | Results |
| 5 | (Optional) Protein case study | Results |

---

## Novel Contributions

1. **汎用フレームワーク** - ドメイン非依存
2. **Desirability関数の比較** - ADS vs 他10種
3. **Optimizer比較** - Entropy vs Bayesian vs Evolutionary
4. **Per-feature function type** - 柔軟なカスタマイズ
5. **Supervised objectives** - ラベル付きデータ対応
6. **(Bonus) MCP integration** - AI-assisted model building

---

## Timeline

| Week | Task |
|------|------|
| 1 | Case studies完了 (QED, NP-likeness) |
| 2 | 図表作成 |
| 3 | 本文執筆 |
| 4 | 内部レビュー・修正 |
| 5 | 投稿準備・Submit |

---

## Prior Work (References)

1. Bickerton et al. (2012) - QED original paper
2. Ertl et al. (2008) - NP-likeness score
3. Lipinski et al. (2001) - Rule of 5
4. Harrington (1965) - Desirability functions origin

---

## Tasks

- [ ] Case studies完了 (Phase 2)
- [ ] 図表作成
- [ ] 本文執筆
- [ ] 共著者確認
- [ ] 投稿

---
- [ ] **DONE** - Paper submitted
