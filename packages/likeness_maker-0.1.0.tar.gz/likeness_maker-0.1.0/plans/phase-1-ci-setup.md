# Phase 1: CI/CD Setup

## Goal

GitHub Actionsを使ったCI/CDパイプラインの構築。

## Tasks

### 1. Basic CI Pipeline
- [ ] `.github/workflows/ci.yml` 作成
- [ ] Python 3.12 + uv セットアップ
- [ ] pytest + coverage (80%以上で失敗)
- [ ] ruff check + ruff format --check
- [ ] ty check

### 2. Matrix Testing (Optional)
- [ ] Python 3.11, 3.12, 3.13 対応確認
- [ ] OS: ubuntu-latest (macOS/Windowsは後で)

### 3. Branch Protection Update
- [ ] CI通過を必須に設定
- [ ] Status checks required

### 4. Badges
- [ ] README.md にCI badge追加
- [ ] Coverage badge (codecov or shields.io)

## Workflow Example

```yaml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync --all-extras
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run ty check
      - run: uv run pytest --cov=src --cov-fail-under=80
```

## Notes

- RDKitはoptional dependencyなので、molecular testsはskipされる可能性
- `--all-extras`でrdkitも含めるか検討

---
- [ ] **DONE** - Phase complete
