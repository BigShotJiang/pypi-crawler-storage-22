# Phase 1.5: Visualization

## Goal

モデルの解釈・分析のための可視化機能を追加。Case Studiesで活用する。

---

## Features

### 1. Desirability Curves
個々の特徴量のdesirability関数をプロット。

```python
from likeness_maker.viz import plot_desirability

plot_desirability(model, feature="MW", x_range=(100, 800))
# → Desirability curve with data distribution overlay
```

### 2. Score Distribution
スコアの分布をヒストグラム/KDEでプロット。

```python
from likeness_maker.viz import plot_score_distribution

plot_score_distribution(scores, bins=50, kde=True)
# → Histogram with KDE overlay
```

### 3. Radar Chart (Spider Plot)
複数特徴量のdesirability値をレーダーチャートで可視化。

```python
from likeness_maker.viz import plot_radar

plot_radar(model, sample)  # Single molecule
plot_radar(model, samples, aggregate="mean")  # Average of dataset
```

### 4. Feature Importance / Weights
重みの棒グラフ。

```python
from likeness_maker.viz import plot_weights

plot_weights(model)
# → Bar chart of feature weights
```

### 5. Model Comparison
複数モデルのスコア相関。

```python
from likeness_maker.viz import plot_model_comparison

plot_model_comparison(
    models={"QED": model_qed, "Custom": model_custom},
    data=test_data
)
# → Scatter plot matrix with correlation coefficients
```

### 6. Score Heatmap (Optional)
2つの特徴量に対するスコアのヒートマップ。

```python
from likeness_maker.viz import plot_score_heatmap

plot_score_heatmap(model, x_feature="MW", y_feature="ALOGP")
# → 2D heatmap of likeness scores
```

---

## Implementation

### Structure
```
src/likeness_maker/
├── viz/
│   ├── __init__.py
│   ├── desirability.py   # Desirability curve plots
│   ├── distribution.py   # Score distribution plots
│   ├── radar.py          # Radar/spider charts
│   ├── comparison.py     # Model comparison plots
│   └── utils.py          # Common utilities
```

### Dependencies
```toml
[project.optional-dependencies]
viz = ["matplotlib>=3.7", "seaborn>=0.12"]
```

### Design Principles
- Matplotlib backend (widely compatible)
- Optional seaborn for prettier defaults
- Return `Figure` objects for customization
- Save to file option (`savefig`)
- Consistent color scheme

---

## Tasks

### Core
- [ ] `plot_desirability()` - 関数カーブ + データ分布
- [ ] `plot_score_distribution()` - ヒストグラム/KDE
- [ ] `plot_weights()` - 重み棒グラフ

### Advanced
- [ ] `plot_radar()` - レーダーチャート
- [ ] `plot_model_comparison()` - モデル比較散布図
- [ ] `plot_score_heatmap()` - 2D ヒートマップ

### Integration
- [ ] Example notebook更新
- [ ] CLI `likeness-maker plot` サブコマンド (optional)

---

## Example Output

```
┌─────────────────────────────────────────┐
│  Desirability Functions                 │
│                                         │
│  MW        ████████░░░░ (weight: 0.21)  │
│  ALOGP     ██████████░░ (weight: 0.27)  │
│  HBD       ████░░░░░░░░ (weight: 0.10)  │
│  HBA       ██████░░░░░░ (weight: 0.15)  │
│  PSA       ████████████ (weight: 0.32)  │
│                                         │
│  Overall Likeness Score: 0.73           │
└─────────────────────────────────────────┘
```

---
- [ ] **DONE** - Phase complete
