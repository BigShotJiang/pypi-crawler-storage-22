# Phase 2: Case Studies / 試験運用

## Goal

likeness-makerの実用性を検証するケーススタディの実施。

---

## Case Study 1: QED Comparison (ChEMBL)

### 概要
ChEMBLのapproved drugsを使って、オリジナルQEDと本ツールで作成したモデルを比較。

### データ
- ChEMBL approved drugs (~2,500 compounds)
- または DrugBank approved (~2,600)

### 実験
- [ ] データ取得・前処理
- [ ] オリジナルQED関数でスコア計算 (RDKit `qed()`)
- [ ] likeness-makerでモデル訓練 (function_type="ads")
- [ ] スコア相関分析 (Pearson, Spearman)
- [ ] 各desirability関数の比較 (ads vs gaussian vs sigmoid)
- [ ] 重み最適化手法の比較 (entropy vs optuna)

### 検証ポイント
- オリジナルQEDとの再現性
- 異なるdesirability関数での性能差
- 最適化手法による違い

---

## Case Study 2: Natural Product-likeness

### 概要
COCONUT (Collection of Open Natural Products) を使ってNP-likenessスコアを作成。

### データ
- COCONUT database (~400,000 NPs)
- サンプリング: 10,000-50,000 compounds

### 実験
- [ ] COCONUT データ取得
- [ ] 記述子選択 (MW, ALOGP, HBD, HBA, ROTB, AROM, Fsp3, etc.)
- [ ] モデル訓練
- [ ] 既存NP-likeness scorer との比較 (RDKit `NaturalProductScorer`)
- [ ] Drug vs NP の分離性能 (ROC-AUC)

### 検証ポイント
- NP特有の化学空間を捉えられるか
- Drug-likenessとの違い
- 記述子選択の影響

---

## Case Study 3: Protein Feature-likeness (応用)

### 概要
化合物以外への応用可能性の検証。タンパク質の特徴量でlikeness指標を作成。

### アイデア
| 応用 | 特徴量 | 参照データセット |
|------|--------|------------------|
| Enzyme-likeness | AA composition, pI, MW | Swiss-Prot enzymes |
| Antibody-likeness | CDR特性, 疎水性 | Known therapeutic Abs |
| Druggable protein | Pocket特性 | Known drug targets |

### 実験 (Enzyme-likenessの例)
- [ ] UniProt enzyme データ取得
- [ ] 特徴量計算 (Biopython / ProtParam)
  - Molecular weight
  - Isoelectric point
  - Amino acid composition
  - GRAVY (hydropathy)
  - Instability index
- [ ] FeatureSet定義
- [ ] モデル訓練・評価

### 検証ポイント
- 化合物以外でも有効か
- 特徴量の解釈可能性
- 実用性 (enzyme prediction等)

---

## Deliverables

各Case Studyで:
1. Jupyter notebook (`examples/case_study_*.ipynb`)
2. 訓練済みモデル (`models/*.json`)
3. 結果のサマリー

---
- [ ] **DONE** - Phase complete
