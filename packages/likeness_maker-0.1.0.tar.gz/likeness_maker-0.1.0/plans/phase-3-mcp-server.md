# Phase 3: MCP Server

## Goal

Model Context Protocol (MCP) サーバーを実装し、AIと対話しながらlikeness指標を作成・調整できるようにする。

---

## Concept

```
User: "このデータセットでdrug-likenessモデルを作って"
AI: [train_model tool] → モデル作成
AI: "モデルを作成しました。MW, ALOGP, HBD, HBA, PSA, ROTBの6特徴量で訓練しました"

User: "MWをもっと重視したい"
AI: [adjust_weights tool] → 重み調整
AI: "MWの重みを0.15→0.25に変更しました。スコア分布はこうなります..."

User: "HBDは5以上でペナルティをかけたい"
AI: [set_function tool] → 関数変更
AI: "HBDをstep関数(threshold=5, invert=True)に変更しました"
```

---

## Tools

### 1. Model Management
| Tool | Description | Parameters |
|------|-------------|------------|
| `create_model` | 新規モデル作成 | feature_names, descriptions |
| `fit_model` | データからモデル訓練 | data_path, function_type |
| `load_model` | 既存モデル読み込み | model_path |
| `save_model` | モデル保存 | model_path |
| `get_model_info` | モデル情報取得 | - |

### 2. Function Configuration
| Tool | Description | Parameters |
|------|-------------|------------|
| `list_desirabilities` | 利用可能な関数一覧 | - |
| `set_function` | 特徴の関数を設定 | feature, type, params |
| `get_function` | 現在の関数設定取得 | feature |
| `visualize_function` | 関数をプロット | feature, x_range |

### 3. Weight Optimization
| Tool | Description | Parameters |
|------|-------------|------------|
| `list_optimizers` | 利用可能なオプティマイザ | - |
| `optimize_weights` | 重み最適化 | method, objective |
| `set_weights` | 手動で重み設定 | weights (dict) |
| `get_weights` | 現在の重み取得 | - |

### 4. Scoring & Analysis
| Tool | Description | Parameters |
|------|-------------|------------|
| `score_molecules` | 分子スコアリング | smiles_list or file |
| `score_detailed` | 詳細スコア取得 | smiles |
| `compare_models` | モデル比較 | model_paths |
| `plot_distribution` | スコア分布表示 | data_path |

### 5. Data Handling
| Tool | Description | Parameters |
|------|-------------|------------|
| `load_molecules` | 分子データ読み込み | file_path |
| `calculate_descriptors` | 記述子計算 | smiles, descriptor_names |
| `list_descriptors` | 利用可能な記述子 | - |

---

## Resources

| Resource | URI | Description |
|----------|-----|-------------|
| `model://current` | 現在のモデル | JSON形式 |
| `model://history` | モデル変更履歴 | 操作ログ |
| `data://molecules` | ロード済み分子 | SMILES一覧 |

---

## Implementation

### Structure
```
src/likeness_maker/
├── mcp/
│   ├── __init__.py
│   ├── server.py      # FastMCP server
│   ├── tools.py       # Tool implementations
│   └── resources.py   # Resource handlers
```

### Tech Stack
- FastMCP (Python MCP SDK)
- State management for current model
- Matplotlib/Plotly for visualizations

---

## Tasks

### 1. Setup
- [ ] `fastmcp` dependency追加
- [ ] 基本サーバー構造作成
- [ ] Claude Desktop設定例

### 2. Core Tools
- [ ] `create_model`, `fit_model`, `load_model`, `save_model`
- [ ] `set_function`, `get_function`
- [ ] `optimize_weights`, `set_weights`
- [ ] `score_molecules`, `score_detailed`

### 3. Analysis Tools
- [ ] `visualize_function` (関数カーブ)
- [ ] `plot_distribution` (スコア分布)
- [ ] `compare_models`

### 4. Documentation
- [ ] README with usage examples
- [ ] Claude Desktop config example

---

## Example Session

```python
# Server startup
uvx likeness-maker-mcp

# Claude Desktop config
{
  "mcpServers": {
    "likeness-maker": {
      "command": "uvx",
      "args": ["likeness-maker-mcp"]
    }
  }
}
```

---
- [ ] **DONE** - Phase complete
