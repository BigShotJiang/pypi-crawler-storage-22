# Phase 4: Web UI & PyPI Publishing

## Goal

Web UIでインタラクティブな操作を可能にし、PyPIで公開して広く使えるようにする。

---

## Part A: PyPI Publishing

### Package Name
- `likeness-maker` (available確認済み想定)

### Tasks
- [ ] `pyproject.toml` metadata整備
  - description, keywords, classifiers
  - project URLs (homepage, documentation, repository)
- [ ] `README.md` PyPI向け調整 (badges, install instructions)
- [ ] `CHANGELOG.md` 作成
- [ ] GitHub Release作成
- [ ] PyPI公開 (`uv publish` or `twine`)

### pyproject.toml Example
```toml
[project]
name = "likeness-maker"
version = "0.1.0"
description = "Create QED-like likeness scoring models from any dataset"
readme = "README.md"
license = "MIT"
authors = [{ name = "N283T" }]
keywords = ["cheminformatics", "drug-likeness", "qed", "scoring"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Science/Research",
    "Topic :: Scientific/Engineering :: Chemistry",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.12",
]

[project.urls]
Homepage = "https://github.com/N283T/likeness-maker"
Documentation = "https://github.com/N283T/likeness-maker#readme"
Repository = "https://github.com/N283T/likeness-maker"
```

### CI/CD for Publishing
```yaml
# .github/workflows/publish.yml
on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv build
      - run: uv publish
        env:
          UV_PUBLISH_TOKEN: ${{ secrets.PYPI_TOKEN }}
```

---

## Part B: Web UI (Streamlit)

### Why Streamlit
- 簡単、Pythonだけで書ける
- データサイエンス向け
- 無料でStreamlit Cloudにデプロイ可能

### Features

#### 1. Model Training
- ファイルアップロード (SDF, CSV)
- 記述子選択
- Desirability関数タイプ選択
- 重み最適化設定
- Train button → モデル作成

#### 2. Model Inspection
- Desirability curves表示
- 重みバーチャート
- モデルダウンロード (JSON)

#### 3. Scoring
- SMILES入力 or ファイルアップロード
- スコア計算・表示
- Radar chart for individual molecules
- 結果ダウンロード (CSV)

#### 4. Model Comparison
- 複数モデルアップロード
- 同一データでスコア比較
- 散布図・相関

### Structure
```
src/likeness_maker/
├── app/
│   ├── __init__.py
│   ├── main.py           # Streamlit entry point
│   ├── pages/
│   │   ├── 1_train.py
│   │   ├── 2_inspect.py
│   │   ├── 3_score.py
│   │   └── 4_compare.py
│   └── components/
│       ├── file_upload.py
│       └── visualizations.py
```

### Deployment Options
| Option | Cost | Notes |
|--------|------|-------|
| Streamlit Cloud | Free | Easy, limited resources |
| Hugging Face Spaces | Free | Popular for ML demos |
| Self-hosted | Varies | Full control |

### Tasks
- [ ] Basic Streamlit app structure
- [ ] Training page
- [ ] Scoring page
- [ ] Visualization integration
- [ ] Streamlit Cloud deployment
- [ ] README instructions

---

## Alternative: Gradio

Gradio pros:
- Even simpler API
- Hugging Face integration
- API endpoint auto-generated

```python
import gradio as gr

def score_molecule(smiles: str, model_file) -> dict:
    model = LikenessModel.from_json(model_file)
    # ... score and return

demo = gr.Interface(
    fn=score_molecule,
    inputs=["text", "file"],
    outputs="json"
)
demo.launch()
```

→ 最初はGradioでMVP、後でStreamlitで本格UIも選択肢

---

## Priority

1. **PyPI公開** - 影響大、工数小
2. **Gradio MVP** - 簡単なデモ用
3. **Streamlit本格UI** - 時間があれば

---
- [ ] **DONE** - Phase complete
