"""Likeness Maker - A tool for creating likeness scoring models."""

from likeness_maker.core.model import LikenessModel
from likeness_maker.core.types import FeatureDefinition, FeatureSet

__version__ = "0.1.0"
__all__ = ["FeatureDefinition", "FeatureSet", "LikenessModel", "__version__"]
