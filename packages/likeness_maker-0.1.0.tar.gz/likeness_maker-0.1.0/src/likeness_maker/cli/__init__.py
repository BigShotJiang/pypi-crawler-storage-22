"""Command-line interface for likeness-maker."""

from likeness_maker.cli.main import app

__all__ = ["app"]
