"""Main CLI entry point for likeness-maker."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="likeness-maker",
    help="Create and apply likeness scoring models.",
    add_completion=False,
)

console = Console()


@app.command()
def train(
    input_file: Annotated[
        Path,
        typer.Argument(help="Input file (SDF or CSV with SMILES)"),
    ],
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Output model file (JSON)"),
    ],
    preset: Annotated[
        str | None,
        typer.Option("--preset", "-p", help="Use a preset (qed, qed-simple, lipinski)"),
    ] = None,
    descriptors: Annotated[
        str | None,
        typer.Option("--descriptors", "-d", help="Comma-separated descriptor names"),
    ] = None,
    function_type: Annotated[
        str,
        typer.Option(
            "--function", "-f", help="Desirability function type (see list-desirabilities)"
        ),
    ] = "ads",
    optimize_weights: Annotated[
        bool,
        typer.Option("--optimize-weights", help="Optimize weights"),
    ] = True,
    optimizer: Annotated[
        Literal[
            "entropy",
            "optuna",
            "scipy",
            "differential_evolution",
            "dual_annealing",
            "basinhopping",
            "nelder_mead",
            "grid",
            "random",
            "sobol",
            "skopt",
            "forest",
            "nsga2",
            "nsga3",
        ],
        typer.Option("--optimizer", help="Weight optimization method (see list-optimizers)"),
    ] = "entropy",
    objective: Annotated[
        Literal["entropy", "roc_auc", "enrichment", "bedroc"],
        typer.Option("--objective", help="Objective function for optimization"),
    ] = "entropy",
    n_trials: Annotated[
        int,
        typer.Option("--n-trials", help="Number of Optuna trials"),
    ] = 100,
    labels_file: Annotated[
        Path | None,
        typer.Option("--labels", "-l", help="CSV file with activity labels (column: 'label')"),
    ] = None,
) -> None:
    """Train a likeness model from reference molecules.

    Examples:
        likeness-maker train drugs.sdf -o model.json --preset qed-simple
        likeness-maker train compounds.csv -o model.json -d MW,ALOGP,HBD,HBA
        likeness-maker train actives.sdf -o model.json --optimizer optuna --objective roc_auc -l labels.csv
    """
    from likeness_maker.cli.train import run_train

    run_train(
        input_file=input_file,
        output=output,
        preset=preset,
        descriptors=descriptors,
        function_type=function_type,
        optimize_weights=optimize_weights,
        optimizer=optimizer,
        objective=objective,
        n_trials=n_trials,
        labels_file=labels_file,
        console=console,
    )


@app.command()
def score(
    input_file: Annotated[
        Path,
        typer.Argument(help="Input file (SDF or CSV with SMILES)"),
    ],
    model: Annotated[
        Path,
        typer.Option("--model", "-m", help="Trained model file (JSON)"),
    ],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Output file (CSV)"),
    ] = None,
    smiles_column: Annotated[
        str,
        typer.Option("--smiles-col", help="SMILES column name for CSV input"),
    ] = "smiles",
) -> None:
    """Score molecules using a trained likeness model.

    Examples:
        likeness-maker score candidates.sdf -m model.json -o scored.csv
        likeness-maker score compounds.csv -m model.json --smiles-col SMILES
    """
    from likeness_maker.cli.score import run_score

    run_score(
        input_file=input_file,
        model=model,
        output=output,
        smiles_column=smiles_column,
        console=console,
    )


@app.command()
def list_presets() -> None:
    """List available preset configurations."""
    from likeness_maker.molecular import get_preset
    from likeness_maker.molecular import list_presets as get_presets

    presets = get_presets()

    table = Table(title="Available Presets")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Features", justify="right")

    for name in presets:
        preset = get_preset(name)
        feature_count = len(preset.feature_set.features)
        table.add_row(name, preset.description, str(feature_count))

    console.print(table)


@app.command()
def list_descriptors() -> None:
    """List available molecular descriptors."""
    from likeness_maker.molecular import DESCRIPTOR_REGISTRY

    table = Table(title="Available Descriptors")
    table.add_column("Name", style="cyan")
    table.add_column("Full Name")
    table.add_column("RDKit Name")

    for name, defn in DESCRIPTOR_REGISTRY.items():
        table.add_row(name, defn.full_name, defn.rdkit_name)

    console.print(table)


@app.command()
def list_desirabilities() -> None:
    """List available desirability function types."""
    from likeness_maker.core.desirability import list_desirabilities as get_desirabilities

    # Function descriptions
    descriptions = {
        "ads": "Asymmetric Double Sigmoid (original QED)",
        "linear": "Linear ramp from x_min to x_max",
        "gaussian": "Bell curve centered at mean",
        "sigmoid": "S-curve with smooth transition",
        "step": "Binary threshold (Heaviside)",
        "smoothstep": "Smooth S-curve with exact 0/1 edges",
        "triangular": "Tent function peaking at center",
        "trapezoidal": "Plateau with linear ramps",
        "exponential": "Exponential decay from reference",
        "double_linear": "Asymmetric triangular (different slopes)",
        "power": "Power function (adjustable curvature)",
    }

    table = Table(title="Available Desirability Functions")
    table.add_column("Name", style="cyan")
    table.add_column("Description")

    for name in get_desirabilities():
        desc = descriptions.get(name, "")
        table.add_row(name, desc)

    console.print(table)


@app.command()
def list_optimizers() -> None:
    """List available weight optimization methods."""
    from likeness_maker.core.optimizers import list_optimizers as get_optimizers

    # Optimizer descriptions
    descriptions = {
        "entropy": "Grid search to maximize score entropy (original QED)",
        "optuna": "Bayesian optimization with TPE/CMA-ES",
        "scipy": "Gradient-based optimization (L-BFGS-B, SLSQP)",
        "differential_evolution": "Stochastic global optimization",
        "dual_annealing": "Simulated annealing with local search",
        "basinhopping": "Basin hopping (Monte Carlo + local min)",
        "nelder_mead": "Simplex method (gradient-free)",
        "grid": "Exhaustive grid search",
        "random": "Random sampling",
        "sobol": "Sobol quasi-random sequence",
        "skopt": "Gaussian Process Bayesian optimization",
        "forest": "Random Forest based optimization",
        "nsga2": "Multi-objective NSGA-II",
        "nsga3": "Multi-objective NSGA-III (many-objective)",
    }

    dependencies = {
        "optuna": "optuna",
        "skopt": "scikit-optimize",
        "forest": "scikit-optimize",
        "nsga2": "pymoo",
        "nsga3": "pymoo",
    }

    table = Table(title="Available Optimizers")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Requires", style="yellow")

    for name in get_optimizers():
        desc = descriptions.get(name, "")
        dep = dependencies.get(name, "")
        table.add_row(name, desc, dep)

    console.print(table)


@app.callback()
def main() -> None:
    """Likeness-maker: Create and apply likeness scoring models.

    A tool for building QED-like scoring models from reference datasets.
    """


if __name__ == "__main__":
    app()
