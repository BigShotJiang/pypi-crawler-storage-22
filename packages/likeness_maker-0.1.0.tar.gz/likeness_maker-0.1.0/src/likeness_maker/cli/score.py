"""Scoring command implementation."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from rich.console import Console


def run_score(
    input_file: Path,
    model: Path,
    output: Path | None,
    smiles_column: str,
    console: Console,
) -> None:
    """Run the scoring workflow.

    Args:
        input_file: Path to input file (SDF or CSV).
        model: Path to trained model file.
        output: Optional path to output CSV file.
        smiles_column: SMILES column name for CSV input.
        console: Rich console for output.
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.table import Table

    from likeness_maker.core import LikenessModel
    from likeness_maker.molecular import (
        calculate_descriptors_batch,
        filter_valid_molecules,
        read_sdf,
        read_smiles,
    )

    # Validate inputs
    if not input_file.exists():
        console.print(f"[red]Error:[/red] File not found: {input_file}")
        raise SystemExit(1)

    if not model.exists():
        console.print(f"[red]Error:[/red] Model file not found: {model}")
        raise SystemExit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Load model
        task = progress.add_task("Loading model...", total=None)

        likeness_model = LikenessModel.from_json(model)
        descriptor_names = tuple(f.name for f in likeness_model.feature_set.features)

        progress.update(task, description="Loading molecules...")

        # Load molecules
        if input_file.suffix.lower() in (".sdf", ".sd", ".mol"):
            df = read_sdf(input_file)
        else:
            df = read_smiles(input_file, smiles_column=smiles_column)

        original_count = len(df)
        df_valid = filter_valid_molecules(df)
        valid_count = len(df_valid)

        progress.update(task, description=f"Loaded {valid_count} valid molecules")

        if valid_count == 0:
            console.print("[red]Error:[/red] No valid molecules found")
            raise SystemExit(1)

        if valid_count < original_count:
            console.print(
                f"[yellow]Warning:[/yellow] {original_count - valid_count} "
                "invalid molecules excluded"
            )

        progress.update(task, description=f"Calculating {len(descriptor_names)} descriptors...")

        # Calculate descriptors
        mols = df_valid["mol"].tolist()
        features = calculate_descriptors_batch(mols, descriptor_names)

        progress.update(task, description="Scoring molecules...")

        # Score molecules
        scores = likeness_model.score(features)

        # Add scores to dataframe
        df_valid = df_valid.copy()
        df_valid["likeness_score"] = scores

        # Mark molecules with NaN features
        nan_mask = np.isnan(features).any(axis=1)
        df_valid.loc[nan_mask, "likeness_score"] = np.nan

        progress.update(task, description="[green]Complete![/green]")

    # Print summary statistics
    valid_scores = scores[~np.isnan(scores)]
    console.print()

    table = Table(title="Score Statistics")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", justify="right")

    table.add_row("Molecules scored", str(len(valid_scores)))
    table.add_row("Mean score", f"{np.mean(valid_scores):.3f}")
    table.add_row("Std deviation", f"{np.std(valid_scores):.3f}")
    table.add_row("Min score", f"{np.min(valid_scores):.3f}")
    table.add_row("Max score", f"{np.max(valid_scores):.3f}")
    table.add_row("Median score", f"{np.median(valid_scores):.3f}")

    console.print(table)

    # Score distribution
    console.print()
    console.print("[bold]Score Distribution:[/bold]")
    bins = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    hist, _ = np.histogram(valid_scores, bins=bins)
    for i in range(len(bins) - 1):
        pct = hist[i] / len(valid_scores) * 100
        bar = "█" * int(pct / 2)
        console.print(f"  {bins[i]:.1f}-{bins[i + 1]:.1f}: {bar} {hist[i]:>4} ({pct:.1f}%)")

    # Save output
    if output:
        # Remove mol column (not serializable)
        output_df = df_valid.drop(columns=["mol"], errors="ignore")
        output_df.to_csv(output, index=False)
        console.print()
        console.print(f"[bold]Results saved to:[/bold] {output}")
    else:
        # Print top 10 scores
        console.print()
        console.print("[bold]Top 10 Scores:[/bold]")
        top_10 = df_valid.nlargest(10, "likeness_score")

        top_table = Table()
        top_table.add_column("Rank", style="cyan", justify="right")
        top_table.add_column("Score", justify="right")

        # Add identifier columns if available
        id_cols = [c for c in ["name", "Name", "ID", "SMILES", "smiles"] if c in top_10.columns]
        if id_cols:
            top_table.add_column("Identifier")

        for i, (_, row) in enumerate(top_10.iterrows(), 1):
            score_str = f"{row['likeness_score']:.3f}"
            if id_cols:
                identifier = str(row[id_cols[0]])[:50]
                top_table.add_row(str(i), score_str, identifier)
            else:
                top_table.add_row(str(i), score_str)

        console.print(top_table)
