"""Training command implementation."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from rich.console import Console


def run_train(
    input_file: Path,
    output: Path,
    preset: str | None,
    descriptors: str | None,
    function_type: str,
    optimize_weights: bool,
    optimizer: str,
    objective: str,
    n_trials: int,
    labels_file: Path | None,
    console: Console,
) -> None:
    """Run the training workflow.

    Args:
        input_file: Path to input file (SDF or CSV).
        output: Path to output model file.
        preset: Optional preset name.
        descriptors: Optional comma-separated descriptor names.
        function_type: Desirability function type.
        optimize_weights: Whether to optimize weights.
        optimizer: Weight optimization method.
        objective: Objective function for optimization.
        n_trials: Number of Optuna trials.
        labels_file: Optional CSV file with activity labels.
        console: Rich console for output.
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn

    from likeness_maker.core import LikenessModel
    from likeness_maker.molecular import (
        calculate_descriptors_batch,
        descriptors_to_feature_set,
        filter_valid_molecules,
        get_preset,
        read_sdf,
        read_smiles,
    )

    # Validate inputs
    if not input_file.exists():
        console.print(f"[red]Error:[/red] File not found: {input_file}")
        raise SystemExit(1)

    if preset and descriptors:
        console.print("[red]Error:[/red] Cannot use both --preset and --descriptors")
        raise SystemExit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Load molecules
        task = progress.add_task("Loading molecules...", total=None)

        if input_file.suffix.lower() in (".sdf", ".sd", ".mol"):
            df = read_sdf(input_file)
        else:
            df = read_smiles(input_file)

        df = filter_valid_molecules(df)
        n_molecules = len(df)
        progress.update(task, description=f"Loaded {n_molecules} molecules")

        if n_molecules == 0:
            console.print("[red]Error:[/red] No valid molecules found")
            raise SystemExit(1)

        # Determine descriptors
        if preset:
            progress.update(task, description=f"Using preset: {preset}")
            preset_config = get_preset(preset)
            descriptor_names = tuple(f.name for f in preset_config.feature_set.features)
            feature_set = preset_config.feature_set
            # Use preset's fitted functions if available
            use_preset_functions = True
        else:
            if descriptors:
                descriptor_names = tuple(d.strip() for d in descriptors.split(","))
            else:
                # Default QED descriptors (without ALERTS)
                descriptor_names = ("MW", "ALOGP", "HBD", "HBA", "PSA", "ROTB", "AROM")
            feature_set = descriptors_to_feature_set(descriptor_names)
            use_preset_functions = False
            preset_config = None

        progress.update(task, description=f"Calculating {len(descriptor_names)} descriptors...")

        # Calculate descriptors
        mols = df["mol"].tolist()
        features = calculate_descriptors_batch(mols, descriptor_names)

        # Remove rows with NaN
        valid_mask = ~np.isnan(features).any(axis=1)
        features = features[valid_mask]
        n_valid = len(features)

        if n_valid < n_molecules:
            console.print(
                f"[yellow]Warning:[/yellow] {n_molecules - n_valid} molecules "
                "had invalid descriptors and were excluded"
            )

        progress.update(task, description="Training model...")

        # Train model
        # Load labels if provided
        labels = None
        if labels_file:
            import pandas as pd

            progress.update(task, description="Loading labels...")
            labels_df = pd.read_csv(labels_file)
            if "label" not in labels_df.columns:
                console.print("[red]Error:[/red] Labels file must have 'label' column")
                raise SystemExit(1)
            labels = labels_df["label"].values[valid_mask].astype(np.float64)

        if use_preset_functions and preset_config is not None:
            # Use preset's pre-fitted desirability functions
            model = LikenessModel(
                feature_set=feature_set,
                fitted_functions=preset_config.fitted_functions,
                weights=preset_config.weights,
            )
            console.print(f"[green]Using preset functions from {preset}[/green]")
        else:
            # Fit new model
            model = LikenessModel(feature_set=feature_set)
            model = model.fit(features, function_type=function_type)

            if optimize_weights:
                progress.update(task, description=f"Optimizing weights ({optimizer})...")
                optimizer_kwargs = {}
                if optimizer == "optuna":
                    optimizer_kwargs["n_trials"] = n_trials
                model = model.optimize_weights(
                    features,
                    labels=labels,
                    objective=objective,
                    optimizer=optimizer,
                    **optimizer_kwargs,
                )

        progress.update(task, description="Saving model...")

        # Save model
        output.parent.mkdir(parents=True, exist_ok=True)
        model.to_json(output)

        progress.update(task, description="[green]Complete![/green]")

    # Print summary
    console.print()
    console.print(f"[bold]Model saved to:[/bold] {output}")
    console.print(f"[bold]Features:[/bold] {len(descriptor_names)}")
    console.print(f"[bold]Training samples:[/bold] {n_valid}")

    if not use_preset_functions:
        console.print(f"[bold]Function type:[/bold] {function_type}")
        console.print(f"[bold]Weights optimized:[/bold] {optimize_weights}")
        if optimize_weights:
            console.print(f"[bold]Optimizer:[/bold] {optimizer}")
            console.print(f"[bold]Objective:[/bold] {objective}")
            if labels is not None:
                console.print(f"[bold]Labels:[/bold] {len(labels)} samples")
