"""Core likeness scoring library (generic, no RDKit dependency)."""

from likeness_maker.core.desirability import (
    AsymmetricDoubleSigmoid,
    BaseDesirabilityFunction,
    DoubleLinearDesirability,
    ExponentialDesirability,
    GaussianDesirability,
    LinearDesirability,
    PowerDesirability,
    SigmoidDesirability,
    SmoothStepDesirability,
    StepDesirability,
    TrapezoidalDesirability,
    TriangularDesirability,
    list_desirabilities,
)
from likeness_maker.core.model import LikenessModel
from likeness_maker.core.objectives import (
    ObjectiveFunction,
    get_objective,
    list_objectives,
)
from likeness_maker.core.optimizers import (
    BaseOptimizer,
    get_optimizer,
    list_optimizers,
)
from likeness_maker.core.scoring import batch_score, geometric_mean_score
from likeness_maker.core.types import FeatureDefinition, FeatureSet, FittedDesirability
from likeness_maker.core.weighting import (
    compute_entropy_weights,
    optimize_weights_iterative,
    shannon_entropy,
)

__all__ = [
    "AsymmetricDoubleSigmoid",
    "BaseDesirabilityFunction",
    "BaseOptimizer",
    "DoubleLinearDesirability",
    "ExponentialDesirability",
    "FeatureDefinition",
    "FeatureSet",
    "FittedDesirability",
    "GaussianDesirability",
    "LikenessModel",
    "LinearDesirability",
    "ObjectiveFunction",
    "PowerDesirability",
    "SigmoidDesirability",
    "SmoothStepDesirability",
    "StepDesirability",
    "TrapezoidalDesirability",
    "TriangularDesirability",
    "batch_score",
    "compute_entropy_weights",
    "geometric_mean_score",
    "get_objective",
    "get_optimizer",
    "list_desirabilities",
    "list_objectives",
    "list_optimizers",
    "optimize_weights_iterative",
    "shannon_entropy",
]
