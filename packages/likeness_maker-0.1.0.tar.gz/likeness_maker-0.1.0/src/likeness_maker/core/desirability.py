"""Desirability function implementations.

This module provides various desirability functions that map raw feature values
to scores in [0, 1]. The primary function is the Asymmetric Double Sigmoid (ADS)
used in the QED paper.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


class BaseDesirabilityFunction(ABC):
    """Base class for desirability functions.

    All desirability functions must:
    - Accept numpy arrays and return arrays of the same shape
    - Return values in [0, 1]
    - Be serializable via get_parameters() and from_parameters()
    """

    @abstractmethod
    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute desirability scores.

        Args:
            x: Array of raw feature values.

        Returns:
            Array of desirability scores in [0, 1].
        """
        ...

    @abstractmethod
    def get_parameters(self) -> dict[str, float]:
        """Return function parameters.

        Returns:
            Dictionary mapping parameter names to values.
        """
        ...

    @classmethod
    @abstractmethod
    def from_parameters(cls, **params: float) -> BaseDesirabilityFunction:
        """Reconstruct function from parameters.

        Args:
            **params: Parameter values.

        Returns:
            New instance with the given parameters.
        """
        ...


@dataclass(frozen=True, slots=True)
class AsymmetricDoubleSigmoid(BaseDesirabilityFunction):
    """Asymmetric Double Sigmoid (ADS) desirability function.

    This is the desirability function used in the QED paper. It creates
    an asymmetric bell-shaped curve that can model preferences for
    intermediate values with different penalties for too-high vs too-low.

    The function form is:
        d(x) = a + b / (1 + exp(-(x - c + d/2) / e)) * (1 - 1 / (1 + exp(-(x - c - d/2) / f)))

    Normalized by d_max to ensure output in [0, 1].

    Attributes:
        a: Baseline offset.
        b: Amplitude.
        c: Center/inflection point.
        d: Width of plateau region.
        e: Left slope steepness.
        f: Right slope steepness.
        d_max: Maximum value for normalization.
    """

    a: float
    b: float
    c: float
    d: float
    e: float
    f: float
    d_max: float

    def __post_init__(self) -> None:
        """Validate parameters to prevent division by zero."""
        if self.e <= 0:
            msg = f"Parameter 'e' must be positive, got {self.e}"
            raise ValueError(msg)
        if self.f <= 0:
            msg = f"Parameter 'f' must be positive, got {self.f}"
            raise ValueError(msg)
        if self.d_max <= 0:
            msg = f"Parameter 'd_max' must be positive, got {self.d_max}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute ADS desirability scores.

        Args:
            x: Array of raw feature values.

        Returns:
            Array of desirability scores in [0, 1].
        """
        x = np.asarray(x, dtype=np.float64)

        # Compute the two sigmoid components
        exp1 = 1 + np.exp(-1 * (x - self.c + self.d / 2) / self.e)
        exp2 = 1 + np.exp(-1 * (x - self.c - self.d / 2) / self.f)

        # Combine into ADS function
        dx = self.a + self.b / exp1 * (1 - 1 / exp2)

        # Normalize and clip to [0, 1]
        return np.clip(dx / self.d_max, 0.0, 1.0)

    def get_parameters(self) -> dict[str, float]:
        """Return ADS parameters."""
        return {
            "a": self.a,
            "b": self.b,
            "c": self.c,
            "d": self.d,
            "e": self.e,
            "f": self.f,
            "d_max": self.d_max,
        }

    @classmethod
    def from_parameters(cls, **params: float) -> AsymmetricDoubleSigmoid:
        """Create ADS function from parameters."""
        return cls(
            a=params["a"],
            b=params["b"],
            c=params["c"],
            d=params["d"],
            e=params["e"],
            f=params["f"],
            d_max=params["d_max"],
        )


@dataclass(frozen=True, slots=True)
class LinearDesirability(BaseDesirabilityFunction):
    """Simple linear ramp desirability function.

    Maps values linearly from 0 at x_min to 1 at x_max (or vice versa
    if invert=True).

    Attributes:
        x_min: Value where desirability = 0 (or 1 if inverted).
        x_max: Value where desirability = 1 (or 0 if inverted).
        invert: If True, high values are undesirable.
    """

    x_min: float
    x_max: float
    invert: bool = False

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute linear desirability scores.

        Args:
            x: Array of raw feature values.

        Returns:
            Array of desirability scores in [0, 1].
        """
        x = np.asarray(x, dtype=np.float64)

        # Handle edge case where x_min == x_max
        if self.x_max == self.x_min:
            return np.ones_like(x)

        d = (x - self.x_min) / (self.x_max - self.x_min)
        if self.invert:
            d = 1.0 - d
        return np.clip(d, 0.0, 1.0)

    def get_parameters(self) -> dict[str, float]:
        """Return linear function parameters."""
        return {
            "x_min": self.x_min,
            "x_max": self.x_max,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> LinearDesirability:
        """Create linear function from parameters."""
        return cls(
            x_min=params["x_min"],
            x_max=params["x_max"],
            invert=bool(params.get("invert", 0)),
        )


@dataclass(frozen=True, slots=True)
class GaussianDesirability(BaseDesirabilityFunction):
    """Gaussian/bell-curve desirability function.

    Values near the center have high desirability, with desirability
    falling off symmetrically according to a Gaussian.

    Attributes:
        center: Value of maximum desirability.
        sigma: Standard deviation (spread of the bell curve).
    """

    center: float
    sigma: float

    def __post_init__(self) -> None:
        """Validate parameters to prevent division by zero."""
        if self.sigma <= 0:
            msg = f"Parameter 'sigma' must be positive, got {self.sigma}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute Gaussian desirability scores.

        Args:
            x: Array of raw feature values.

        Returns:
            Array of desirability scores in [0, 1].
        """
        x = np.asarray(x, dtype=np.float64)
        return np.exp(-0.5 * ((x - self.center) / self.sigma) ** 2)

    def get_parameters(self) -> dict[str, float]:
        """Return Gaussian function parameters."""
        return {
            "center": self.center,
            "sigma": self.sigma,
        }

    @classmethod
    def from_parameters(cls, **params: float) -> GaussianDesirability:
        """Create Gaussian function from parameters."""
        return cls(
            center=params["center"],
            sigma=params["sigma"],
        )


@dataclass(frozen=True, slots=True)
class SigmoidDesirability(BaseDesirabilityFunction):
    """Standard sigmoid (logistic) desirability function.

    S-shaped curve transitioning smoothly from 0 to 1.
    Useful when you want a smooth threshold-like behavior.

    Attributes:
        center: Inflection point (where desirability = 0.5).
        steepness: Controls transition sharpness (higher = steeper).
        invert: If True, transitions from 1 to 0.
    """

    center: float
    steepness: float
    invert: bool = False

    def __post_init__(self) -> None:
        """Validate parameters."""
        if self.steepness <= 0:
            msg = f"Parameter 'steepness' must be positive, got {self.steepness}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute sigmoid desirability scores."""
        x = np.asarray(x, dtype=np.float64)
        d = 1.0 / (1.0 + np.exp(-self.steepness * (x - self.center)))
        if self.invert:
            d = 1.0 - d
        return d

    def get_parameters(self) -> dict[str, float]:
        """Return sigmoid function parameters."""
        return {
            "center": self.center,
            "steepness": self.steepness,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> SigmoidDesirability:
        """Create sigmoid function from parameters."""
        return cls(
            center=params["center"],
            steepness=params["steepness"],
            invert=bool(params.get("invert", 0)),
        )


@dataclass(frozen=True, slots=True)
class StepDesirability(BaseDesirabilityFunction):
    """Step (Heaviside) desirability function.

    Binary threshold: 0 below threshold, 1 at/above threshold.
    Useful for hard cutoffs like Lipinski's Rule of 5.

    Attributes:
        threshold: Cutoff value.
        invert: If True, 1 below threshold, 0 above.
    """

    threshold: float
    invert: bool = False

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute step desirability scores."""
        x = np.asarray(x, dtype=np.float64)
        d = np.where(x >= self.threshold, 1.0, 0.0)
        if self.invert:
            d = 1.0 - d
        return d

    def get_parameters(self) -> dict[str, float]:
        """Return step function parameters."""
        return {
            "threshold": self.threshold,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> StepDesirability:
        """Create step function from parameters."""
        return cls(
            threshold=params["threshold"],
            invert=bool(params.get("invert", 0)),
        )


@dataclass(frozen=True, slots=True)
class SmoothStepDesirability(BaseDesirabilityFunction):
    """Smooth step desirability function (smoothstep).

    Smooth S-curve between two edges using Hermite interpolation.
    Similar to sigmoid but with exact 0 and 1 at the edges.

    Attributes:
        edge0: Value where desirability = 0.
        edge1: Value where desirability = 1.
        invert: If True, transitions from 1 to 0.
    """

    edge0: float
    edge1: float
    invert: bool = False

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute smooth step desirability scores."""
        x = np.asarray(x, dtype=np.float64)

        # Normalize to [0, 1]
        if self.edge1 == self.edge0:
            t = np.where(x >= self.edge0, 1.0, 0.0)
        else:
            t = np.clip((x - self.edge0) / (self.edge1 - self.edge0), 0.0, 1.0)

        # Smoothstep: 3t^2 - 2t^3
        d = t * t * (3.0 - 2.0 * t)

        if self.invert:
            d = 1.0 - d
        return d

    def get_parameters(self) -> dict[str, float]:
        """Return smooth step function parameters."""
        return {
            "edge0": self.edge0,
            "edge1": self.edge1,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> SmoothStepDesirability:
        """Create smooth step function from parameters."""
        return cls(
            edge0=params["edge0"],
            edge1=params["edge1"],
            invert=bool(params.get("invert", 0)),
        )


@dataclass(frozen=True, slots=True)
class TriangularDesirability(BaseDesirabilityFunction):
    """Triangular (tent) desirability function.

    Peaks at center, linearly decreasing to 0 at edges.
    Useful when optimal value is known but deviation is tolerated.

    Attributes:
        center: Peak value where desirability = 1.
        width: Distance from center to edge (both sides).
    """

    center: float
    width: float

    def __post_init__(self) -> None:
        """Validate parameters."""
        if self.width <= 0:
            msg = f"Parameter 'width' must be positive, got {self.width}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute triangular desirability scores."""
        x = np.asarray(x, dtype=np.float64)
        d = 1.0 - np.abs(x - self.center) / self.width
        return np.clip(d, 0.0, 1.0)

    def get_parameters(self) -> dict[str, float]:
        """Return triangular function parameters."""
        return {
            "center": self.center,
            "width": self.width,
        }

    @classmethod
    def from_parameters(cls, **params: float) -> TriangularDesirability:
        """Create triangular function from parameters."""
        return cls(
            center=params["center"],
            width=params["width"],
        )


@dataclass(frozen=True, slots=True)
class TrapezoidalDesirability(BaseDesirabilityFunction):
    """Trapezoidal desirability function.

    Plateau of desirability = 1 in center, with linear ramps on sides.
    Useful when a range of values is equally acceptable.

    Attributes:
        low_edge: Start of left ramp.
        low_plateau: Start of plateau (desirability = 1).
        high_plateau: End of plateau (desirability = 1).
        high_edge: End of right ramp.
    """

    low_edge: float
    low_plateau: float
    high_plateau: float
    high_edge: float

    def __post_init__(self) -> None:
        """Validate parameters."""
        if not (self.low_edge <= self.low_plateau <= self.high_plateau <= self.high_edge):
            msg = (
                f"Parameters must satisfy low_edge <= low_plateau <= high_plateau <= high_edge, "
                f"got {self.low_edge}, {self.low_plateau}, {self.high_plateau}, {self.high_edge}"
            )
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute trapezoidal desirability scores."""
        x = np.asarray(x, dtype=np.float64)

        d = np.zeros_like(x)

        # Left ramp
        if self.low_plateau > self.low_edge:
            left_mask = (x >= self.low_edge) & (x < self.low_plateau)
            d[left_mask] = (x[left_mask] - self.low_edge) / (self.low_plateau - self.low_edge)

        # Plateau
        plateau_mask = (x >= self.low_plateau) & (x <= self.high_plateau)
        d[plateau_mask] = 1.0

        # Right ramp
        if self.high_edge > self.high_plateau:
            right_mask = (x > self.high_plateau) & (x <= self.high_edge)
            d[right_mask] = (self.high_edge - x[right_mask]) / (self.high_edge - self.high_plateau)

        return d

    def get_parameters(self) -> dict[str, float]:
        """Return trapezoidal function parameters."""
        return {
            "low_edge": self.low_edge,
            "low_plateau": self.low_plateau,
            "high_plateau": self.high_plateau,
            "high_edge": self.high_edge,
        }

    @classmethod
    def from_parameters(cls, **params: float) -> TrapezoidalDesirability:
        """Create trapezoidal function from parameters."""
        return cls(
            low_edge=params["low_edge"],
            low_plateau=params["low_plateau"],
            high_plateau=params["high_plateau"],
            high_edge=params["high_edge"],
        )


@dataclass(frozen=True, slots=True)
class ExponentialDesirability(BaseDesirabilityFunction):
    """Exponential decay desirability function.

    Desirability decreases exponentially from a reference point.
    Useful for penalizing large deviations from optimal.

    Attributes:
        reference: Value where desirability = 1.
        decay_rate: Rate of exponential decay.
        invert: If True, desirability increases away from reference.
    """

    reference: float
    decay_rate: float
    invert: bool = False

    def __post_init__(self) -> None:
        """Validate parameters."""
        if self.decay_rate <= 0:
            msg = f"Parameter 'decay_rate' must be positive, got {self.decay_rate}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute exponential desirability scores."""
        x = np.asarray(x, dtype=np.float64)
        d = np.exp(-self.decay_rate * np.abs(x - self.reference))
        if self.invert:
            d = 1.0 - d
        return d

    def get_parameters(self) -> dict[str, float]:
        """Return exponential function parameters."""
        return {
            "reference": self.reference,
            "decay_rate": self.decay_rate,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> ExponentialDesirability:
        """Create exponential function from parameters."""
        return cls(
            reference=params["reference"],
            decay_rate=params["decay_rate"],
            invert=bool(params.get("invert", 0)),
        )


@dataclass(frozen=True, slots=True)
class DoubleLinearDesirability(BaseDesirabilityFunction):
    """Double linear (asymmetric triangular) desirability function.

    Like triangular but with different slopes on each side.
    Useful when penalties differ for going above vs below optimal.

    Attributes:
        center: Peak value where desirability = 1.
        left_width: Distance from center to left edge.
        right_width: Distance from center to right edge.
    """

    center: float
    left_width: float
    right_width: float

    def __post_init__(self) -> None:
        """Validate parameters."""
        if self.left_width <= 0:
            msg = f"Parameter 'left_width' must be positive, got {self.left_width}"
            raise ValueError(msg)
        if self.right_width <= 0:
            msg = f"Parameter 'right_width' must be positive, got {self.right_width}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute double linear desirability scores."""
        x = np.asarray(x, dtype=np.float64)
        d = np.zeros_like(x)

        # Left side
        left_mask = x < self.center
        d[left_mask] = 1.0 - (self.center - x[left_mask]) / self.left_width

        # Right side
        right_mask = x >= self.center
        d[right_mask] = 1.0 - (x[right_mask] - self.center) / self.right_width

        return np.clip(d, 0.0, 1.0)

    def get_parameters(self) -> dict[str, float]:
        """Return double linear function parameters."""
        return {
            "center": self.center,
            "left_width": self.left_width,
            "right_width": self.right_width,
        }

    @classmethod
    def from_parameters(cls, **params: float) -> DoubleLinearDesirability:
        """Create double linear function from parameters."""
        return cls(
            center=params["center"],
            left_width=params["left_width"],
            right_width=params["right_width"],
        )


@dataclass(frozen=True, slots=True)
class PowerDesirability(BaseDesirabilityFunction):
    """Power function desirability.

    Desirability = ((x - x_min) / (x_max - x_min))^power
    Power < 1 gives diminishing returns, power > 1 accelerating returns.

    Attributes:
        x_min: Value where desirability = 0.
        x_max: Value where desirability = 1.
        power: Exponent (1.0 = linear).
        invert: If True, high values are undesirable.
    """

    x_min: float
    x_max: float
    power: float = 1.0
    invert: bool = False

    def __post_init__(self) -> None:
        """Validate parameters."""
        if self.power <= 0:
            msg = f"Parameter 'power' must be positive, got {self.power}"
            raise ValueError(msg)

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Compute power desirability scores."""
        x = np.asarray(x, dtype=np.float64)

        if self.x_max == self.x_min:
            return np.ones_like(x)

        d = np.clip((x - self.x_min) / (self.x_max - self.x_min), 0.0, 1.0)
        d = np.power(d, self.power)

        if self.invert:
            d = 1.0 - d
        return d

    def get_parameters(self) -> dict[str, float]:
        """Return power function parameters."""
        return {
            "x_min": self.x_min,
            "x_max": self.x_max,
            "power": self.power,
            "invert": float(self.invert),
        }

    @classmethod
    def from_parameters(cls, **params: float) -> PowerDesirability:
        """Create power function from parameters."""
        return cls(
            x_min=params["x_min"],
            x_max=params["x_max"],
            power=params.get("power", 1.0),
            invert=bool(params.get("invert", 0)),
        )


# Registry for extensibility
DESIRABILITY_REGISTRY: dict[str, type[BaseDesirabilityFunction]] = {
    "ads": AsymmetricDoubleSigmoid,
    "linear": LinearDesirability,
    "gaussian": GaussianDesirability,
    "sigmoid": SigmoidDesirability,
    "step": StepDesirability,
    "smoothstep": SmoothStepDesirability,
    "triangular": TriangularDesirability,
    "trapezoidal": TrapezoidalDesirability,
    "exponential": ExponentialDesirability,
    "double_linear": DoubleLinearDesirability,
    "power": PowerDesirability,
}


def register_desirability(name: str, cls: type[BaseDesirabilityFunction]) -> None:
    """Register a custom desirability function type.

    Args:
        name: Identifier for the function type.
        cls: Class implementing BaseDesirabilityFunction.
    """
    DESIRABILITY_REGISTRY[name] = cls


def get_desirability_class(name: str) -> type[BaseDesirabilityFunction]:
    """Get desirability function class by name.

    Args:
        name: Identifier for the function type.

    Returns:
        The corresponding class.

    Raises:
        ValueError: If name is not registered.
    """
    if name not in DESIRABILITY_REGISTRY:
        available = list(DESIRABILITY_REGISTRY.keys())
        msg = f"Unknown desirability function: {name}. Available: {available}"
        raise ValueError(msg)
    return DESIRABILITY_REGISTRY[name]


def list_desirabilities() -> list[str]:
    """List available desirability function types.

    Returns:
        List of registered function type names.
    """
    return list(DESIRABILITY_REGISTRY.keys())
