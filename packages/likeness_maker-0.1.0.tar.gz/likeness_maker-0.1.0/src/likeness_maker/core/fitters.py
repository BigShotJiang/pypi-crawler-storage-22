"""Curve fitting for desirability functions.

This module provides fitters that learn desirability function parameters
from reference data distributions.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, Protocol, cast

import numpy as np
from scipy import optimize

from likeness_maker.core.desirability import (
    AsymmetricDoubleSigmoid,
    BaseDesirabilityFunction,
    DoubleLinearDesirability,
    ExponentialDesirability,
    GaussianDesirability,
    LinearDesirability,
    PowerDesirability,
    SigmoidDesirability,
    SmoothStepDesirability,
    StepDesirability,
    TrapezoidalDesirability,
    TriangularDesirability,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


@dataclass(frozen=True, slots=True)
class FitResult:
    """Result of fitting a desirability function.

    Attributes:
        parameters: Fitted parameter values.
        r_squared: Goodness of fit (1.0 = perfect fit).
        function: The fitted desirability function instance.
    """

    parameters: dict[str, float]
    r_squared: float
    function: BaseDesirabilityFunction


class FitterProtocol(Protocol):
    """Protocol for desirability function fitters."""

    def fit(
        self,
        values: NDArray[np.float64],
        **kwargs,
    ) -> FitResult:
        """Fit a desirability function to data distribution.

        Args:
            values: Reference data values.
            **kwargs: Fitter-specific parameters.

        Returns:
            FitResult with fitted function and metrics.
        """
        ...


class ADSFitter:
    """Fitter for Asymmetric Double Sigmoid functions.

    Fits ADS parameters to the histogram of reference values using
    non-linear least squares optimization (Levenberg-Marquardt).
    """

    def fit(
        self,
        values: NDArray[np.float64],
        bins: int | Literal["auto"] = "auto",
        initial_guess: dict[str, float] | None = None,
        maxfev: int = 10000,
    ) -> FitResult:
        """Fit ADS function to reference data distribution.

        Args:
            values: Reference data values.
            bins: Number of histogram bins or "auto".
            initial_guess: Initial parameter estimates.
            maxfev: Maximum function evaluations for optimizer.

        Returns:
            FitResult with fitted ADS function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]  # Remove NaNs

        if len(values) < 10:
            msg = f"Need at least 10 values for fitting, got {len(values)}"
            raise ValueError(msg)

        # Compute histogram (density-normalized)
        hist, bin_edges = np.histogram(values, bins=bins, density=True)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

        # ADS function for curve_fit
        def ads_func(x, a, b, c, d, e, f):
            with np.errstate(over="ignore"):
                exp1 = 1 + np.exp(-1 * (x - c + d / 2) / e)
                exp2 = 1 + np.exp(-1 * (x - c - d / 2) / f)
            return a + b / exp1 * (1 - 1 / exp2)

        # Initial parameter guess
        if initial_guess is None:
            initial_guess = self._estimate_initial_params(values, bin_centers, hist)

        p0 = [initial_guess.get(k, 1.0) for k in ["a", "b", "c", "d", "e", "f"]]

        # Bounds to ensure numerical stability
        val_range = values.max() - values.min()
        bounds = (
            [0, 0, values.min() - val_range, 0, 0.001, 0.001],
            [np.inf, np.inf, values.max() + val_range, val_range * 2, np.inf, np.inf],
        )

        try:
            popt, _ = optimize.curve_fit(
                ads_func,
                bin_centers,
                hist,
                p0=p0,
                bounds=bounds,
                maxfev=maxfev,
            )
        except RuntimeError as e:
            msg = f"Failed to fit ADS function: {e}"
            raise ValueError(msg) from e

        # Calculate d_max for normalization
        x_range = np.linspace(values.min(), values.max(), 1000)
        d_max = ads_func(x_range, *popt).max()

        # Ensure d_max is positive
        d_max = max(d_max, 1e-10)

        params = dict(zip(["a", "b", "c", "d", "e", "f"], popt, strict=True))
        params["d_max"] = d_max

        # Calculate R-squared
        y_pred = ads_func(bin_centers, *popt)
        ss_res = np.sum((hist - y_pred) ** 2)
        ss_tot = np.sum((hist - hist.mean()) ** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 1.0

        func = AsymmetricDoubleSigmoid(**params)
        return FitResult(parameters=params, r_squared=r_squared, function=func)

    def _estimate_initial_params(
        self,
        values: NDArray[np.float64],
        bin_centers: NDArray[np.float64],
        hist: NDArray[np.float64],
    ) -> dict[str, float]:
        """Estimate initial ADS parameters from data."""
        std = float(np.std(values))
        if std == 0:
            std = 1.0

        return {
            "a": float(max(hist.min(), 0)),
            "b": float(hist.max() - max(hist.min(), 0)),
            "c": float(np.median(values)),
            "d": std,
            "e": std / 2,
            "f": std / 2,
        }


class LinearFitter:
    """Fitter for linear desirability functions.

    Uses percentiles to determine the linear ramp endpoints.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        percentile_low: float = 5,
        percentile_high: float = 95,
        invert: bool = False,
    ) -> FitResult:
        """Fit linear function to reference data.

        Args:
            values: Reference data values.
            percentile_low: Percentile for x_min.
            percentile_high: Percentile for x_max.
            invert: If True, high values are undesirable.

        Returns:
            FitResult with fitted linear function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        x_min = float(np.percentile(values, percentile_low))
        x_max = float(np.percentile(values, percentile_high))

        params = {"x_min": x_min, "x_max": x_max, "invert": float(invert)}
        func = LinearDesirability(x_min=x_min, x_max=x_max, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class GaussianFitter:
    """Fitter for Gaussian desirability functions.

    Estimates center and sigma from the data distribution.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        use_median: bool = False,
    ) -> FitResult:
        """Fit Gaussian function to reference data.

        Args:
            values: Reference data values.
            use_median: If True, use median instead of mean for center.

        Returns:
            FitResult with fitted Gaussian function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        center = float(np.median(values) if use_median else np.mean(values))
        sigma = float(np.std(values))

        # Ensure sigma is positive
        sigma = max(sigma, 1e-10)

        params = {"center": center, "sigma": sigma}
        func = GaussianDesirability(center=center, sigma=sigma)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class SigmoidFitter:
    """Fitter for sigmoid desirability functions.

    Estimates center from median and steepness from data range.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        percentile_low: float = 10,
        percentile_high: float = 90,
        invert: bool = False,
    ) -> FitResult:
        """Fit sigmoid function to reference data.

        Args:
            values: Reference data values.
            percentile_low: Low percentile for steepness estimation.
            percentile_high: High percentile for steepness estimation.
            invert: If True, high values are undesirable.

        Returns:
            FitResult with fitted sigmoid function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        center = float(np.median(values))

        # Estimate steepness from percentile range
        p_low = float(np.percentile(values, percentile_low))
        p_high = float(np.percentile(values, percentile_high))
        range_width = p_high - p_low

        # steepness such that sigmoid goes from ~0.1 to ~0.9 over this range
        # sigmoid(steepness * range/2) = 0.9 => steepness * range/2 = 2.2
        steepness = 4.4 / max(range_width, 1e-10)

        params = {"center": center, "steepness": steepness, "invert": float(invert)}
        func = SigmoidDesirability(center=center, steepness=steepness, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class StepFitter:
    """Fitter for step (threshold) desirability functions.

    Uses a percentile as the threshold.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        percentile: float = 50,
        invert: bool = False,
    ) -> FitResult:
        """Fit step function to reference data.

        Args:
            values: Reference data values.
            percentile: Percentile to use as threshold.
            invert: If True, values below threshold are desirable.

        Returns:
            FitResult with fitted step function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        threshold = float(np.percentile(values, percentile))

        params = {"threshold": threshold, "invert": float(invert)}
        func = StepDesirability(threshold=threshold, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class SmoothStepFitter:
    """Fitter for smooth step desirability functions.

    Uses percentiles for edge positions.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        percentile_low: float = 10,
        percentile_high: float = 90,
        invert: bool = False,
    ) -> FitResult:
        """Fit smooth step function to reference data.

        Args:
            values: Reference data values.
            percentile_low: Percentile for edge0.
            percentile_high: Percentile for edge1.
            invert: If True, high values are undesirable.

        Returns:
            FitResult with fitted smooth step function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        edge0 = float(np.percentile(values, percentile_low))
        edge1 = float(np.percentile(values, percentile_high))

        params = {"edge0": edge0, "edge1": edge1, "invert": float(invert)}
        func = SmoothStepDesirability(edge0=edge0, edge1=edge1, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class TriangularFitter:
    """Fitter for triangular desirability functions.

    Estimates center from median and width from standard deviation.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        use_median: bool = True,
        width_multiplier: float = 2.0,
    ) -> FitResult:
        """Fit triangular function to reference data.

        Args:
            values: Reference data values.
            use_median: If True, use median for center (else mean).
            width_multiplier: Multiplier for std to get width.

        Returns:
            FitResult with fitted triangular function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        center = float(np.median(values) if use_median else np.mean(values))
        width = float(np.std(values) * width_multiplier)
        width = max(width, 1e-10)

        params = {"center": center, "width": width}
        func = TriangularDesirability(center=center, width=width)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class TrapezoidalFitter:
    """Fitter for trapezoidal desirability functions.

    Uses percentiles to define the four corner points.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        p_low_edge: float = 5,
        p_low_plateau: float = 25,
        p_high_plateau: float = 75,
        p_high_edge: float = 95,
    ) -> FitResult:
        """Fit trapezoidal function to reference data.

        Args:
            values: Reference data values.
            p_low_edge: Percentile for low_edge.
            p_low_plateau: Percentile for low_plateau.
            p_high_plateau: Percentile for high_plateau.
            p_high_edge: Percentile for high_edge.

        Returns:
            FitResult with fitted trapezoidal function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        low_edge = float(np.percentile(values, p_low_edge))
        low_plateau = float(np.percentile(values, p_low_plateau))
        high_plateau = float(np.percentile(values, p_high_plateau))
        high_edge = float(np.percentile(values, p_high_edge))

        params = {
            "low_edge": low_edge,
            "low_plateau": low_plateau,
            "high_plateau": high_plateau,
            "high_edge": high_edge,
        }
        func = TrapezoidalDesirability(
            low_edge=low_edge,
            low_plateau=low_plateau,
            high_plateau=high_plateau,
            high_edge=high_edge,
        )

        return FitResult(parameters=params, r_squared=1.0, function=func)


class ExponentialFitter:
    """Fitter for exponential desirability functions.

    Estimates reference from median and decay from standard deviation.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        use_median: bool = True,
        decay_multiplier: float = 1.0,
        invert: bool = False,
    ) -> FitResult:
        """Fit exponential function to reference data.

        Args:
            values: Reference data values.
            use_median: If True, use median for reference (else mean).
            decay_multiplier: Multiplier for 1/std to get decay rate.
            invert: If True, desirability increases away from reference.

        Returns:
            FitResult with fitted exponential function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        reference = float(np.median(values) if use_median else np.mean(values))
        std = float(np.std(values))
        decay_rate = decay_multiplier / max(std, 1e-10)

        params = {
            "reference": reference,
            "decay_rate": decay_rate,
            "invert": float(invert),
        }
        func = ExponentialDesirability(reference=reference, decay_rate=decay_rate, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


class DoubleLinearFitter:
    """Fitter for double linear (asymmetric triangular) desirability functions.

    Estimates center from median and widths from percentile ranges.
    """

    def fit(
        self,
        values: NDArray[np.float64],
        use_median: bool = True,
        percentile_left: float = 10,
        percentile_right: float = 90,
    ) -> FitResult:
        """Fit double linear function to reference data.

        Args:
            values: Reference data values.
            use_median: If True, use median for center (else mean).
            percentile_left: Percentile for left width estimation.
            percentile_right: Percentile for right width estimation.

        Returns:
            FitResult with fitted double linear function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        center = float(np.median(values) if use_median else np.mean(values))
        p_left = float(np.percentile(values, percentile_left))
        p_right = float(np.percentile(values, percentile_right))

        left_width = max(center - p_left, 1e-10)
        right_width = max(p_right - center, 1e-10)

        params = {
            "center": center,
            "left_width": left_width,
            "right_width": right_width,
        }
        func = DoubleLinearDesirability(
            center=center, left_width=left_width, right_width=right_width
        )

        return FitResult(parameters=params, r_squared=1.0, function=func)


class PowerFitter:
    """Fitter for power desirability functions.

    Uses percentiles for range, defaults to linear (power=1).
    """

    def fit(
        self,
        values: NDArray[np.float64],
        percentile_low: float = 5,
        percentile_high: float = 95,
        power: float = 1.0,
        invert: bool = False,
    ) -> FitResult:
        """Fit power function to reference data.

        Args:
            values: Reference data values.
            percentile_low: Percentile for x_min.
            percentile_high: Percentile for x_max.
            power: Exponent (1.0 = linear).
            invert: If True, high values are undesirable.

        Returns:
            FitResult with fitted power function.
        """
        values = np.asarray(values, dtype=np.float64)
        values = values[~np.isnan(values)]

        x_min = float(np.percentile(values, percentile_low))
        x_max = float(np.percentile(values, percentile_high))

        params = {
            "x_min": x_min,
            "x_max": x_max,
            "power": power,
            "invert": float(invert),
        }
        func = PowerDesirability(x_min=x_min, x_max=x_max, power=power, invert=invert)

        return FitResult(parameters=params, r_squared=1.0, function=func)


# Registry for fitters (uses concrete types that satisfy FitterProtocol)
FITTER_REGISTRY = {
    "ads": ADSFitter(),
    "linear": LinearFitter(),
    "gaussian": GaussianFitter(),
    "sigmoid": SigmoidFitter(),
    "step": StepFitter(),
    "smoothstep": SmoothStepFitter(),
    "triangular": TriangularFitter(),
    "trapezoidal": TrapezoidalFitter(),
    "exponential": ExponentialFitter(),
    "double_linear": DoubleLinearFitter(),
    "power": PowerFitter(),
}


def register_fitter(name: str, fitter: FitterProtocol) -> None:
    """Register a custom fitter.

    Args:
        name: Identifier for the fitter.
        fitter: Fitter instance implementing FitterProtocol.
    """
    FITTER_REGISTRY[name] = fitter


def get_fitter(name: str) -> FitterProtocol:
    """Get fitter by name.

    Args:
        name: Identifier for the fitter.

    Returns:
        The corresponding fitter.

    Raises:
        ValueError: If name is not registered.
    """
    if name not in FITTER_REGISTRY:
        available = list(FITTER_REGISTRY.keys())
        msg = f"Unknown fitter: {name}. Available: {available}"
        raise ValueError(msg)
    return cast(FitterProtocol, FITTER_REGISTRY[name])


def list_fitters() -> list[str]:
    """List available fitter types.

    Returns:
        List of registered fitter names.
    """
    return list(FITTER_REGISTRY.keys())
