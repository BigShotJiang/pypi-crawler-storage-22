"""Main LikenessModel class.

This module provides the primary API for training and using likeness models.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd

from likeness_maker.core.desirability import get_desirability_class
from likeness_maker.core.fitters import get_fitter
from likeness_maker.core.scoring import batch_score, individual_desirabilities
from likeness_maker.core.types import FeatureDefinition, FeatureSet, FittedDesirability

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from likeness_maker.core.desirability import BaseDesirabilityFunction


@dataclass
class LikenessModel:
    """Generic likeness scoring model.

    This is the main entry point for the core library. It can be trained
    on any numerical features (not just molecular descriptors).

    Attributes:
        feature_set: Definition of features used by this model.
        fitted_functions: Mapping from feature name to fitted desirability.
        weights: Optional feature weights for scoring.
        weight_scheme: Name of the weight optimization method used.
    """

    feature_set: FeatureSet
    fitted_functions: dict[str, FittedDesirability] = field(default_factory=dict)
    weights: NDArray[np.float64] | None = None
    weight_scheme: str = "uniform"

    def fit(
        self,
        features: NDArray[np.float64] | pd.DataFrame,
        function_type: str | dict[str, str] | list[str] = "ads",
        weights: NDArray[np.float64] | None = None,
        fitter_kwargs: dict[str, dict[str, Any]] | None = None,
    ) -> LikenessModel:
        """Fit desirability functions to reference data.

        Creates a new model with fitted desirability functions learned
        from the reference data distribution.

        Args:
            features: Reference data, shape (n_samples, n_features).
                Can be numpy array or pandas DataFrame.
            function_type: Type of desirability function to fit. Can be:
                - str: Same function for all features (e.g., "ads")
                - dict: Mapping from feature name to function type
                  (e.g., {"MW": "gaussian", "ALOGP": "sigmoid"})
                - list: Function types in feature order
                  (e.g., ["gaussian", "sigmoid", "linear"])
            weights: Optional fixed weights (default: uniform).
            fitter_kwargs: Optional per-feature fitter parameters.
                Mapping from feature name to kwargs dict for the fitter.
                (e.g., {"MW": {"use_median": True}, "HBD": {"percentile": 90}})

        Returns:
            New LikenessModel with fitted functions.

        Examples:
            >>> # Same function for all features
            >>> model.fit(features, function_type="gaussian")

            >>> # Different functions per feature
            >>> model.fit(features, function_type={
            ...     "MW": "gaussian",
            ...     "ALOGP": "sigmoid",
            ...     "HBD": "step",
            ... })

            >>> # Custom fitter parameters
            >>> model.fit(features, function_type="trapezoidal", fitter_kwargs={
            ...     "MW": {"p_low_plateau": 20, "p_high_plateau": 80},
            ... })
        """
        # Convert DataFrame to numpy if needed
        if isinstance(features, pd.DataFrame):
            features = features[list(self.feature_set.names)].to_numpy()
        features = np.asarray(features, dtype=np.float64)

        if features.shape[1] != len(self.feature_set):
            msg = f"Expected {len(self.feature_set)} features, got {features.shape[1]}"
            raise ValueError(msg)

        # Normalize function_type to dict
        if isinstance(function_type, str):
            func_types = {name: function_type for name in self.feature_set.names}
        elif isinstance(function_type, list):
            if len(function_type) != len(self.feature_set):
                msg = f"function_type list length ({len(function_type)}) != features ({len(self.feature_set)})"
                raise ValueError(msg)
            func_types = dict(zip(self.feature_set.names, function_type, strict=True))
        else:
            # dict
            func_types = function_type
            # Validate all features are covered
            for name in self.feature_set.names:
                if name not in func_types:
                    msg = f"function_type dict missing feature: {name}"
                    raise ValueError(msg)

        fitter_kwargs = fitter_kwargs or {}
        fitted_functions = {}

        for i, feature_def in enumerate(self.feature_set.features):
            values = features[:, i]
            feat_name = feature_def.name
            feat_func_type = func_types[feat_name]

            fitter = get_fitter(feat_func_type)
            kwargs = fitter_kwargs.get(feat_name, {})
            result = fitter.fit(values, **kwargs)

            fitted_functions[feat_name] = FittedDesirability(
                feature_name=feat_name,
                function_type=feat_func_type,
                parameters=result.parameters,
                r_squared=result.r_squared,
            )

        # Determine weights
        if weights is not None:
            final_weights = np.asarray(weights, dtype=np.float64)
            weight_scheme = "custom"
        else:
            final_weights = np.ones(len(self.feature_set), dtype=np.float64)
            weight_scheme = "uniform"

        # Return new model (immutability)
        return LikenessModel(
            feature_set=self.feature_set,
            fitted_functions=fitted_functions,
            weights=final_weights,
            weight_scheme=weight_scheme,
        )

    def score(
        self,
        features: NDArray[np.float64] | pd.DataFrame,
    ) -> NDArray[np.float64]:
        """Score samples against the fitted model.

        Args:
            features: Data to score, shape (n_samples, n_features).

        Returns:
            Likeness scores in [0, 1], shape (n_samples,).

        Raises:
            ValueError: If model is not fitted.
        """
        if not self.fitted_functions:
            msg = "Model is not fitted. Call fit() first."
            raise ValueError(msg)

        # Convert DataFrame to numpy if needed
        if isinstance(features, pd.DataFrame):
            features = features[list(self.feature_set.names)].to_numpy()
        features = np.asarray(features, dtype=np.float64)

        if features.ndim == 1:
            features = features.reshape(1, -1)

        if features.shape[1] != len(self.feature_set):
            msg = f"Expected {len(self.feature_set)} features, got {features.shape[1]}"
            raise ValueError(msg)

        # Get desirability functions in order
        funcs = self._get_ordered_functions()

        return batch_score(features, funcs, self.weights)

    def score_detailed(
        self,
        features: NDArray[np.float64] | pd.DataFrame,
    ) -> pd.DataFrame:
        """Score with per-feature desirability breakdown.

        Returns DataFrame with:
            - One column per feature (d_{feature_name}) for desirability score
            - 'likeness_score' column for final weighted score

        Args:
            features: Data to score, shape (n_samples, n_features).

        Returns:
            DataFrame with desirabilities and final scores.
        """
        if not self.fitted_functions:
            msg = "Model is not fitted. Call fit() first."
            raise ValueError(msg)

        # Convert DataFrame to numpy if needed
        if isinstance(features, pd.DataFrame):
            features = features[list(self.feature_set.names)].to_numpy()
        features = np.asarray(features, dtype=np.float64)

        if features.ndim == 1:
            features = features.reshape(1, -1)

        # Get desirability functions in order
        funcs = self._get_ordered_functions()

        # Compute individual desirabilities
        desirabilities = individual_desirabilities(features, funcs)

        # Build result DataFrame
        result = {}
        for i, name in enumerate(self.feature_set.names):
            result[f"d_{name}"] = desirabilities[:, i]

        result["likeness_score"] = self.score(features)

        return pd.DataFrame(result)

    def _get_ordered_functions(self) -> list[BaseDesirabilityFunction]:
        """Get desirability functions in feature order."""
        funcs: list[BaseDesirabilityFunction] = []
        for name in self.feature_set.names:
            fitted = self.fitted_functions[name]
            cls = get_desirability_class(fitted.function_type)
            func = cls.from_parameters(**fitted.parameters)
            funcs.append(func)
        return funcs

    def set_function(
        self,
        feature_name: str,
        function_type: str,
        parameters: dict[str, float],
    ) -> LikenessModel:
        """Set a desirability function manually with specific parameters.

        This allows using custom parameters instead of fitting from data.
        Useful for reproducing published models or fine-tuning.

        Args:
            feature_name: Name of the feature to set.
            function_type: Type of desirability function.
            parameters: Function parameters (must match function's expected params).

        Returns:
            New LikenessModel with the specified function.

        Raises:
            ValueError: If feature_name is not in feature_set.

        Examples:
            >>> # Set custom Gaussian for molecular weight
            >>> model = model.set_function(
            ...     "MW",
            ...     "gaussian",
            ...     {"center": 350.0, "sigma": 100.0},
            ... )

            >>> # Set custom step threshold for HBD
            >>> model = model.set_function(
            ...     "HBD",
            ...     "step",
            ...     {"threshold": 5.0, "invert": 1.0},
            ... )
        """
        if feature_name not in self.feature_set.names:
            available = list(self.feature_set.names)
            msg = f"Unknown feature: {feature_name}. Available: {available}"
            raise ValueError(msg)

        # Validate function type and parameters by instantiating
        cls = get_desirability_class(function_type)
        cls.from_parameters(**parameters)  # Will raise if invalid

        # Create new fitted function
        new_fitted = FittedDesirability(
            feature_name=feature_name,
            function_type=function_type,
            parameters=parameters,
            r_squared=1.0,  # Manual specification = perfect "fit"
        )

        # Copy existing functions and update
        new_fitted_functions = dict(self.fitted_functions)
        new_fitted_functions[feature_name] = new_fitted

        return LikenessModel(
            feature_set=self.feature_set,
            fitted_functions=new_fitted_functions,
            weights=self.weights.copy() if self.weights is not None else None,
            weight_scheme=self.weight_scheme,
        )

    def set_functions(
        self,
        functions: dict[str, tuple[str, dict[str, float]]],
    ) -> LikenessModel:
        """Set multiple desirability functions manually.

        Convenience method for setting multiple functions at once.

        Args:
            functions: Mapping from feature name to (function_type, parameters).

        Returns:
            New LikenessModel with the specified functions.

        Examples:
            >>> model = model.set_functions({
            ...     "MW": ("gaussian", {"center": 350.0, "sigma": 100.0}),
            ...     "HBD": ("step", {"threshold": 5.0, "invert": 0.0}),
            ...     "ALOGP": ("sigmoid", {"center": 2.5, "steepness": 1.0, "invert": 0.0}),
            ... })
        """
        result = self
        for feature_name, (function_type, parameters) in functions.items():
            result = result.set_function(feature_name, function_type, parameters)
        return result

    def optimize_weights(
        self,
        features: NDArray[np.float64] | pd.DataFrame,
        labels: NDArray[np.float64] | None = None,
        objective: str = "entropy",
        optimizer: str = "entropy",
        **optimizer_kwargs: Any,
    ) -> LikenessModel:
        """Optimize feature weights.

        Supports multiple optimization strategies and objective functions.

        Args:
            features: Data to compute desirabilities on, shape (n_samples, n_features).
            labels: Optional binary labels (0/1) for supervised objectives like
                ROC-AUC, enrichment, or BEDROC. Shape (n_samples,).
            objective: Objective function to maximize. Options:
                - "entropy": Score distribution entropy (unsupervised, default)
                - "roc_auc": ROC-AUC score (requires labels)
                - "enrichment": Enrichment factor at top 1% (requires labels)
                - "bedroc": BEDROC score (requires labels)
            optimizer: Optimization method. Options:
                - "entropy": Grid search to maximize score entropy (original QED)
                - "optuna": Bayesian optimization with Optuna
                - "scipy": Gradient-based optimization with scipy
                - "differential_evolution": Stochastic global optimization
                - "dual_annealing": Simulated annealing with local search
                - "basinhopping": Basin hopping (Monte Carlo + local min)
                - "nelder_mead": Simplex method (gradient-free)
                - "grid": Exhaustive grid search
                - "random": Random sampling
                - "sobol": Sobol quasi-random sequence
                - "skopt": Gaussian Process Bayesian optimization
                - "forest": Random Forest based optimization
                - "nsga2": Multi-objective NSGA-II
                - "nsga3": Multi-objective NSGA-III
            **optimizer_kwargs: Additional parameters for the optimizer:
                - n_trials (int): Number of Optuna trials (default: 100)
                - cv_folds (int): Cross-validation folds (default: 0)
                - min_weight (float): Minimum weight value (default: 0.01)
                - n_points (int): Grid points per dimension for entropy (default: 5)

        Returns:
            New LikenessModel with optimized weights.

        Raises:
            ValueError: If model is not fitted or if supervised objective
                is used without labels.

        Examples:
            >>> # Unsupervised (original QED approach)
            >>> model = model.optimize_weights(features)

            >>> # Supervised with Optuna
            >>> model = model.optimize_weights(
            ...     features,
            ...     labels=labels,
            ...     objective="roc_auc",
            ...     optimizer="optuna",
            ...     n_trials=100,
            ... )
        """
        from likeness_maker.core.objectives import get_objective
        from likeness_maker.core.optimizers import get_optimizer

        if not self.fitted_functions:
            msg = "Model is not fitted. Call fit() first."
            raise ValueError(msg)

        # Validate supervised objectives require labels
        supervised_objectives = {"roc_auc", "enrichment", "bedroc"}
        if objective in supervised_objectives and labels is None:
            msg = f"Objective '{objective}' requires labels. Please provide the 'labels' parameter."
            raise ValueError(msg)

        # Convert DataFrame to numpy if needed
        if isinstance(features, pd.DataFrame):
            features = features[list(self.feature_set.names)].to_numpy()
        features = np.asarray(features, dtype=np.float64)

        if features.shape[1] != len(self.feature_set):
            msg = f"Expected {len(self.feature_set)} features, got {features.shape[1]}"
            raise ValueError(msg)

        if labels is not None:
            labels = np.asarray(labels, dtype=np.float64)
            if len(labels) != len(features):
                msg = f"Labels length ({len(labels)}) != features length ({len(features)})"
                raise ValueError(msg)

        # Compute desirabilities
        funcs = self._get_ordered_functions()
        desirabilities = individual_desirabilities(features, funcs)

        # Get objective function
        objective_fn = get_objective(objective)

        # Get and run optimizer
        # Parameters that can be passed to optimizer __init__
        init_params = {
            "n_trials",
            "cv_folds",
            "min_weight",
            "n_bins",
            "n_points",
            "method",
            "max_iterations",
            "tolerance",
            "sampler",
            "seed",
            "show_progress",
        }
        optimizer_cls = get_optimizer(optimizer)
        optimizer_instance = optimizer_cls(
            **{k: v for k, v in optimizer_kwargs.items() if k in init_params}
        )
        # Pass only remaining kwargs to optimize()
        result = optimizer_instance.optimize(
            desirabilities=desirabilities,
            objective_fn=objective_fn,
            labels=labels,
            **{k: v for k, v in optimizer_kwargs.items() if k not in init_params},
        )

        # Build weight scheme name
        weight_scheme = f"{optimizer}_{objective}" if optimizer != "entropy" else "entropy"

        # Return new model with optimized weights
        return LikenessModel(
            feature_set=self.feature_set,
            fitted_functions=self.fitted_functions,
            weights=result.weights,
            weight_scheme=weight_scheme,
        )

    def to_json(self, path: str | Path) -> None:
        """Serialize model to JSON file.

        Args:
            path: Output file path.
        """
        data = {
            "version": "1.0",
            "feature_set": [
                {
                    "name": f.name,
                    "description": f.description,
                    "lower_bound": f.lower_bound,
                    "upper_bound": f.upper_bound,
                }
                for f in self.feature_set.features
            ],
            "fitted_functions": {name: fd.to_dict() for name, fd in self.fitted_functions.items()},
            "weights": self.weights.tolist() if self.weights is not None else None,
            "weight_scheme": self.weight_scheme,
        }
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def from_json(cls, path: str | Path) -> LikenessModel:
        """Load model from JSON file.

        Args:
            path: Input file path.

        Returns:
            Loaded LikenessModel.
        """
        with open(path) as f:
            data = json.load(f)

        # Reconstruct feature set
        features = tuple(
            FeatureDefinition(
                name=fd["name"],
                description=fd.get("description", ""),
                lower_bound=fd.get("lower_bound"),
                upper_bound=fd.get("upper_bound"),
            )
            for fd in data["feature_set"]
        )
        feature_set = FeatureSet(features=features)

        # Reconstruct fitted functions
        fitted_functions = {
            name: FittedDesirability.from_dict(fd) for name, fd in data["fitted_functions"].items()
        }

        # Reconstruct weights
        weights = np.array(data["weights"]) if data["weights"] is not None else None

        return cls(
            feature_set=feature_set,
            fitted_functions=fitted_functions,
            weights=weights,
            weight_scheme=data.get("weight_scheme", "uniform"),
        )
