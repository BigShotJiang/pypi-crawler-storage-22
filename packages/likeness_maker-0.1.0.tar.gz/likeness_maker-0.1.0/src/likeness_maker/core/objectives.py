"""Objective functions for weight optimization.

This module provides objective functions that can be used to optimize
feature weights. Each objective returns a score where higher is better.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Protocol

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


class ObjectiveFunction(Protocol):
    """Protocol for objective functions."""

    def __call__(
        self,
        scores: NDArray[np.float64],
        labels: NDArray[np.float64] | None = None,
    ) -> float:
        """Compute objective value.

        Args:
            scores: Predicted scores, shape (n_samples,).
            labels: Binary labels (0/1), shape (n_samples,). Required for
                supervised objectives.

        Returns:
            Objective value (higher is better).
        """
        ...


def entropy_objective(
    scores: NDArray[np.float64],
    labels: NDArray[np.float64] | None = None,
    n_bins: int = 10,
) -> float:
    """Maximize entropy of score distribution.

    This is the unsupervised objective from the QED paper.
    Higher entropy means better discrimination between samples.

    Args:
        scores: Predicted scores in [0, 1].
        labels: Not used (unsupervised objective).
        n_bins: Number of bins for histogram.

    Returns:
        Shannon entropy of score distribution.
    """
    # Remove NaN values
    scores = scores[~np.isnan(scores)]
    if len(scores) == 0:
        return 0.0

    # Create histogram
    hist, _ = np.histogram(scores, bins=n_bins, range=(0.0, 1.0))

    # Convert to probabilities
    probs = hist / hist.sum()

    # Filter out zero probabilities
    probs = probs[probs > 0]

    # Calculate entropy
    entropy = -np.sum(probs * np.log2(probs))

    return float(entropy)


def roc_auc_objective(
    scores: NDArray[np.float64],
    labels: NDArray[np.float64] | None = None,
) -> float:
    """Maximize ROC-AUC score.

    Args:
        scores: Predicted scores.
        labels: Binary labels (0/1). Required.

    Returns:
        ROC-AUC score in [0, 1].

    Raises:
        ValueError: If labels is None or has only one class.
    """
    if labels is None:
        msg = "roc_auc_objective requires labels"
        raise ValueError(msg)

    # Remove NaN values
    mask = ~np.isnan(scores)
    scores = scores[mask]
    labels = labels[mask]

    if len(np.unique(labels)) < 2:
        msg = "roc_auc_objective requires both positive and negative samples"
        raise ValueError(msg)

    # Lazy import to avoid hard dependency
    from sklearn.metrics import roc_auc_score

    return float(roc_auc_score(labels, scores))


def enrichment_objective(
    scores: NDArray[np.float64],
    labels: NDArray[np.float64] | None = None,
    fraction: float = 0.01,
) -> float:
    """Maximize enrichment factor at top X%.

    Enrichment factor measures how many more actives are found in the
    top fraction compared to random selection.

    Args:
        scores: Predicted scores.
        labels: Binary labels (0/1). Required.
        fraction: Top fraction to consider (default: 1%).

    Returns:
        Enrichment factor (1.0 = random, higher = better).

    Raises:
        ValueError: If labels is None.
    """
    if labels is None:
        msg = "enrichment_objective requires labels"
        raise ValueError(msg)

    # Remove NaN values
    mask = ~np.isnan(scores)
    scores = scores[mask]
    labels = labels[mask]

    n_samples = len(scores)
    n_actives = labels.sum()

    if n_actives == 0 or n_samples == 0:
        return 0.0

    # Sort by score descending
    sorted_indices = np.argsort(scores)[::-1]
    sorted_labels = labels[sorted_indices]

    # Calculate enrichment at top fraction
    n_top = max(1, int(n_samples * fraction))
    actives_in_top = sorted_labels[:n_top].sum()

    # Expected actives in random selection
    expected = n_top * (n_actives / n_samples)

    if expected == 0:
        return 0.0

    return float(actives_in_top / expected)


def bedroc_objective(
    scores: NDArray[np.float64],
    labels: NDArray[np.float64] | None = None,
    alpha: float = 20.0,
) -> float:
    """Maximize BEDROC (Boltzmann-Enhanced Discrimination of ROC).

    BEDROC emphasizes early recognition of actives, which is important
    in virtual screening where only top-ranked compounds are tested.

    Args:
        scores: Predicted scores.
        labels: Binary labels (0/1). Required.
        alpha: Exponential weighting factor. Higher alpha emphasizes
            earlier recognition more strongly. Default 20.0 corresponds
            to 80% of the score coming from top 8% of ranked list.

    Returns:
        BEDROC score in [0, 1].

    Raises:
        ValueError: If labels is None.
    """
    if labels is None:
        msg = "bedroc_objective requires labels"
        raise ValueError(msg)

    # Remove NaN values
    mask = ~np.isnan(scores)
    scores = scores[mask]
    labels = labels[mask]

    n_samples = len(scores)
    n_actives = int(labels.sum())

    if n_actives == 0 or n_samples == 0:
        return 0.0

    # Sort by score descending
    sorted_indices = np.argsort(scores)[::-1]
    sorted_labels = labels[sorted_indices]

    # Get ranks of actives (1-indexed)
    active_ranks = np.where(sorted_labels == 1)[0] + 1

    # Calculate BEDROC components
    s = np.sum(np.exp(-alpha * active_ranks / n_samples))

    # Random expectation
    ra = n_actives / n_samples
    ri = (1 - np.exp(-alpha)) / (np.exp(alpha / n_samples) - 1)
    random_sum = ra * ri

    # Ideal case (all actives at top)
    ideal_sum = (1 - np.exp(-alpha * ra)) / (1 - np.exp(-alpha / n_samples))

    # BEDROC formula
    if ideal_sum - random_sum == 0:
        return 0.0

    bedroc = (s - random_sum) / (ideal_sum - random_sum)

    return float(np.clip(bedroc, 0.0, 1.0))


# Registry of available objectives
OBJECTIVE_REGISTRY: dict[str, Callable[..., float]] = {
    "entropy": entropy_objective,
    "roc_auc": roc_auc_objective,
    "enrichment": enrichment_objective,
    "bedroc": bedroc_objective,
}


def get_objective(name: str) -> Callable[..., float]:
    """Get objective function by name.

    Args:
        name: Objective name.

    Returns:
        Objective function.

    Raises:
        ValueError: If objective not found.
    """
    if name not in OBJECTIVE_REGISTRY:
        available = list(OBJECTIVE_REGISTRY.keys())
        msg = f"Unknown objective: {name}. Available: {available}"
        raise ValueError(msg)

    return OBJECTIVE_REGISTRY[name]


def list_objectives() -> list[str]:
    """List available objective names.

    Returns:
        List of objective names.
    """
    return list(OBJECTIVE_REGISTRY.keys())
