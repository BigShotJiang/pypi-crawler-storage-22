"""Weight optimizers for likeness models.

This package provides different optimization strategies for finding
optimal feature weights.

Available optimizers:
- entropy: Grid search to maximize score entropy (original QED approach)
- optuna: Bayesian optimization with TPE/CMA-ES
- scipy: Gradient-based optimization (L-BFGS-B, SLSQP)
- differential_evolution: Stochastic global optimization
- dual_annealing: Simulated annealing with local search
- basinhopping: Basin hopping (Monte Carlo + local min)
- nelder_mead: Simplex method (gradient-free)
- grid: Exhaustive grid search
- random: Random sampling
- sobol: Sobol quasi-random sequence
- skopt: Gaussian Process Bayesian optimization
- forest: Random Forest based optimization
- nsga2: Multi-objective NSGA-II
- nsga3: Multi-objective NSGA-III (many-objective)
"""

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult
from likeness_maker.core.optimizers.entropy import EntropyOptimizer
from likeness_maker.core.optimizers.grid_random import (
    GridSearchOptimizer,
    RandomSearchOptimizer,
    SobolSearchOptimizer,
)
from likeness_maker.core.optimizers.optuna_opt import OptunaOptimizer
from likeness_maker.core.optimizers.pymoo_opt import (
    MultiObjectiveResult,
    NSGA2Optimizer,
    NSGA3Optimizer,
)
from likeness_maker.core.optimizers.scipy_global import (
    BasinHoppingOptimizer,
    DifferentialEvolutionOptimizer,
    DualAnnealingOptimizer,
    NelderMeadOptimizer,
)
from likeness_maker.core.optimizers.scipy_opt import ScipyOptimizer
from likeness_maker.core.optimizers.skopt_opt import ForestOptimizer, SkoptOptimizer

__all__ = [
    "BaseOptimizer",
    "BasinHoppingOptimizer",
    "DifferentialEvolutionOptimizer",
    "DualAnnealingOptimizer",
    "EntropyOptimizer",
    "ForestOptimizer",
    "GridSearchOptimizer",
    "MultiObjectiveResult",
    "NSGA2Optimizer",
    "NSGA3Optimizer",
    "NelderMeadOptimizer",
    "OptimizerResult",
    "OptunaOptimizer",
    "RandomSearchOptimizer",
    "ScipyOptimizer",
    "SkoptOptimizer",
    "SobolSearchOptimizer",
    "get_optimizer",
    "list_optimizers",
    "register_optimizer",
]


# Registry of available optimizers
OPTIMIZER_REGISTRY: dict[str, type[BaseOptimizer]] = {
    # Original optimizers
    "entropy": EntropyOptimizer,
    "optuna": OptunaOptimizer,
    "scipy": ScipyOptimizer,
    # Scipy global optimizers
    "differential_evolution": DifferentialEvolutionOptimizer,
    "dual_annealing": DualAnnealingOptimizer,
    "basinhopping": BasinHoppingOptimizer,
    "nelder_mead": NelderMeadOptimizer,
    # Grid and random search
    "grid": GridSearchOptimizer,
    "random": RandomSearchOptimizer,
    "sobol": SobolSearchOptimizer,
    # Scikit-optimize
    "skopt": SkoptOptimizer,
    "forest": ForestOptimizer,
    # Multi-objective (pymoo)
    "nsga2": NSGA2Optimizer,
    "nsga3": NSGA3Optimizer,
}


def get_optimizer(name: str) -> type[BaseOptimizer]:
    """Get optimizer class by name.

    Args:
        name: Optimizer name.

    Returns:
        Optimizer class.

    Raises:
        ValueError: If optimizer not found.
    """
    if name not in OPTIMIZER_REGISTRY:
        available = list(OPTIMIZER_REGISTRY.keys())
        msg = f"Unknown optimizer: {name}. Available: {available}"
        raise ValueError(msg)

    return OPTIMIZER_REGISTRY[name]


def list_optimizers() -> list[str]:
    """List available optimizer names.

    Returns:
        List of optimizer names.
    """
    return list(OPTIMIZER_REGISTRY.keys())


def register_optimizer(name: str, optimizer_cls: type[BaseOptimizer]) -> None:
    """Register a new optimizer.

    Args:
        name: Optimizer name.
        optimizer_cls: Optimizer class.
    """
    OPTIMIZER_REGISTRY[name] = optimizer_cls
