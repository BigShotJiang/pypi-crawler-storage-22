"""Base optimizer interface.

This module defines the protocol that all optimizers must follow.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


@dataclass(frozen=True)
class OptimizerResult:
    """Result from weight optimization.

    Attributes:
        weights: Optimized weights, shape (n_features,), sum to 1.0.
        objective_value: Final objective function value.
        converged: Whether optimization converged.
        n_iterations: Number of iterations (or trials) used.
        extra: Additional optimizer-specific information.
    """

    weights: NDArray[np.float64]
    objective_value: float
    converged: bool = True
    n_iterations: int = 0
    extra: dict[str, Any] | None = None


class BaseOptimizer(ABC):
    """Base class for weight optimizers.

    All optimizers must implement the `optimize` method which takes
    desirabilities and returns optimized weights.
    """

    @abstractmethod
    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize feature weights.

        Args:
            desirabilities: Per-sample, per-feature desirability values,
                shape (n_samples, n_features), values in [0, 1].
            objective_fn: Objective function that takes (scores, labels) and
                returns a value to maximize.
            labels: Optional binary labels (0/1) for supervised objectives,
                shape (n_samples,).
            **kwargs: Additional optimizer-specific parameters.

        Returns:
            OptimizerResult with optimized weights.
        """
        ...

    @staticmethod
    def compute_scores(
        desirabilities: NDArray[np.float64],
        weights: NDArray[np.float64],
    ) -> NDArray[np.float64]:
        """Compute weighted geometric mean scores.

        Args:
            desirabilities: Shape (n_samples, n_features).
            weights: Shape (n_features,), should sum to 1.0.

        Returns:
            Scores, shape (n_samples,).
        """
        # Clip to avoid log(0)
        d_clipped = np.clip(desirabilities, 1e-10, 1.0)

        # Weighted geometric mean: exp(sum(w * log(d)))
        log_d = np.log(d_clipped)
        weighted_log = log_d * weights
        scores = np.exp(weighted_log.sum(axis=1))

        return scores

    @staticmethod
    def normalize_weights(
        weights: NDArray[np.float64],
        min_weight: float = 0.0,
    ) -> NDArray[np.float64]:
        """Normalize weights to sum to 1.0.

        Args:
            weights: Raw weights.
            min_weight: Minimum weight value (0.0 allows feature selection).

        Returns:
            Normalized weights that sum to 1.0 and respect min_weight.
        """
        # First clip to min_weight
        weights = np.clip(weights, min_weight, None)
        total = weights.sum()

        if total <= 0:
            return np.ones_like(weights) / len(weights)

        # Normalize
        normalized = weights / total

        # If min_weight > 0, we need to renormalize to ensure both
        # sum to 1.0 and min_weight constraint are satisfied
        if min_weight > 0 and len(weights) > 0 and normalized.min() < min_weight:
            normalized = np.clip(normalized, min_weight, None)
            normalized = normalized / normalized.sum()

        return normalized
