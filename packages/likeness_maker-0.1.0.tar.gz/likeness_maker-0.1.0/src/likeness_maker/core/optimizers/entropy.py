"""Entropy-based weight optimizer.

This optimizer uses grid search to find weights that maximize the Shannon
entropy of the final score distribution, as described in the original QED paper.

Reference:
    Bickerton et al. (2012) "Quantifying the chemical beauty of drugs"
    Nature Chemistry 4, 90-98
"""

from __future__ import annotations

from collections.abc import Callable
from itertools import product
from typing import TYPE_CHECKING, Any

import numpy as np

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class EntropyOptimizer(BaseOptimizer):
    """Weight optimizer using grid search to maximize score entropy.

    This is the original QED approach: search over a grid of weight
    combinations (0.0, 0.25, 0.5, 0.75, 1.0 for each feature) and select
    the weights that maximize the Shannon entropy of the final score
    distribution.

    The rationale is that weights yielding high entropy in the final
    scores provide better discrimination between drug-like and non-drug-like
    compounds.
    """

    def __init__(
        self,
        n_points: int = 5,
        n_bins: int = 10,
        min_weight: float = 0.0,
    ) -> None:
        """Initialize entropy optimizer.

        Args:
            n_points: Number of grid points per weight dimension.
                Default 5 gives [0.0, 0.25, 0.5, 0.75, 1.0] as in original QED.
            n_bins: Number of bins for histogram-based entropy calculation.
            min_weight: Minimum weight value (default 0.0 for original QED).
        """
        self.n_points = n_points
        self.n_bins = n_bins
        self.min_weight = min_weight

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using grid search to maximize score entropy.

        This follows the original QED method: exhaustive search over all
        weight combinations to find the one that maximizes the Shannon
        entropy of the final score distribution.

        Note: The objective_fn parameter is ignored; entropy of the score
        distribution is always used as the objective.

        Args:
            desirabilities: Shape (n_samples, n_features).
            objective_fn: Ignored (entropy is always used).
            labels: Ignored (unsupervised method).
            **kwargs: Override n_points or min_weight.

        Returns:
            OptimizerResult with entropy-maximizing weights.
        """
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        n_points = kwargs.get("n_points", self.n_points)
        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        # Create grid: [0.0, 0.25, 0.5, 0.75, 1.0] for n_points=5
        grid_1d = np.linspace(min_weight, 1.0, n_points)

        # Warn if grid is too large
        total_points = n_points**n_features
        if total_points > 1000000:
            import warnings

            warnings.warn(
                f"Grid search will evaluate {total_points:,} points. "
                f"Consider using fewer features or reducing n_points.",
                stacklevel=2,
            )

        best_entropy = float("-inf")
        best_weights: NDArray[np.float64] | None = None
        n_evaluated = 0

        for raw_weights in product(grid_1d, repeat=n_features):
            raw_weights_arr = np.array(raw_weights)

            # Skip all-zero weights
            if raw_weights_arr.sum() == 0:
                continue

            weights = self.normalize_weights(raw_weights_arr, min_weight=0.0)
            scores = self.compute_scores(desirabilities, weights)

            # Calculate entropy of score distribution
            entropy = self._shannon_entropy(scores)
            n_evaluated += 1

            if entropy > best_entropy:
                best_entropy = entropy
                best_weights = weights

        if best_weights is None:
            # Fallback to uniform weights
            best_weights = np.ones(n_features) / n_features
            scores = self.compute_scores(desirabilities, best_weights)
            best_entropy = self._shannon_entropy(scores)

        # Compute objective value using the provided function
        final_scores = self.compute_scores(desirabilities, best_weights)
        objective_value = objective_fn(final_scores, labels)

        return OptimizerResult(
            weights=best_weights,
            objective_value=objective_value,
            converged=True,
            n_iterations=n_evaluated,
            extra={
                "method": "grid_search",
                "n_points": n_points,
                "total_combinations": total_points,
                "best_entropy": best_entropy,
            },
        )

    def _shannon_entropy(self, values: NDArray[np.float64]) -> float:
        """Calculate Shannon entropy of a distribution.

        Args:
            values: Array of values in [0, 1].

        Returns:
            Shannon entropy in bits.
        """
        # Remove NaN values
        values = values[~np.isnan(values)]
        if len(values) == 0:
            return 0.0

        # Create histogram
        hist, _ = np.histogram(values, bins=self.n_bins, range=(0.0, 1.0))

        # Convert to probabilities
        probs = hist / hist.sum()

        # Filter out zero probabilities
        probs = probs[probs > 0]

        # Calculate entropy: H = -sum(p * log2(p))
        entropy = -np.sum(probs * np.log2(probs))

        return float(entropy)
