"""Grid and Random search optimizers.

Simple but effective baseline optimization methods.
"""

from __future__ import annotations

from collections.abc import Callable
from itertools import product
from typing import TYPE_CHECKING, Any

import numpy as np

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class GridSearchOptimizer(BaseOptimizer):
    """Weight optimizer using exhaustive grid search.

    Evaluates all combinations of weights on a discrete grid.
    Simple and guaranteed to find the global optimum on the grid,
    but scales poorly with number of features.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        n_points: int = 10,
    ) -> None:
        """Initialize Grid Search optimizer.

        Args:
            min_weight: Minimum weight value.
            n_points: Number of points per dimension.
                Total evaluations = n_points^n_features.
        """
        self.min_weight = min_weight
        self.n_points = n_points

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using grid search."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_points = kwargs.get("n_points", self.n_points)
        n_features = desirabilities.shape[1]

        # Warn if grid is too large
        total_points = n_points**n_features
        if total_points > 100000:
            import warnings

            warnings.warn(
                f"Grid search will evaluate {total_points:,} points. "
                "Consider using random search or reducing n_points.",
                stacklevel=2,
            )

        # Create grid
        grid_1d = np.linspace(min_weight, 1.0, n_points)
        grid = list(product(grid_1d, repeat=n_features))

        best_value = float("-inf")
        best_weights = None
        n_evaluated = 0

        for raw_weights in grid:
            raw_weights = np.array(raw_weights)
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)

            try:
                value = objective_fn(scores, labels)
                n_evaluated += 1

                if value > best_value:
                    best_value = value
                    best_weights = weights
            except ValueError:
                continue

        if best_weights is None:
            # Fallback to uniform
            best_weights = np.ones(n_features) / n_features
            best_value = 0.0

        return OptimizerResult(
            weights=best_weights,
            objective_value=best_value,
            converged=True,
            n_iterations=n_evaluated,
            extra={
                "n_points_per_dim": n_points,
                "total_grid_points": total_points,
            },
        )


class RandomSearchOptimizer(BaseOptimizer):
    """Weight optimizer using random search.

    Samples random weight combinations and returns the best.
    Often surprisingly competitive with more sophisticated methods,
    especially for small compute budgets.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        n_samples: int = 1000,
        seed: int | None = None,
        distribution: str = "uniform",
    ) -> None:
        """Initialize Random Search optimizer.

        Args:
            min_weight: Minimum weight value.
            n_samples: Number of random samples to evaluate.
            seed: Random seed for reproducibility.
            distribution: Sampling distribution ("uniform" or "dirichlet").
        """
        self.min_weight = min_weight
        self.n_samples = n_samples
        self.seed = seed
        self.distribution = distribution

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using random search."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_samples = kwargs.get("n_samples", self.n_samples)
        n_features = desirabilities.shape[1]

        rng = np.random.default_rng(self.seed)

        best_value = float("-inf")
        best_weights = None
        n_evaluated = 0

        for _ in range(n_samples):
            if self.distribution == "dirichlet":
                # Dirichlet gives weights that naturally sum to 1
                raw_weights = rng.dirichlet(np.ones(n_features))
            else:
                # Uniform random
                raw_weights = rng.uniform(min_weight, 1.0, n_features)

            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)

            try:
                value = objective_fn(scores, labels)
                n_evaluated += 1

                if value > best_value:
                    best_value = value
                    best_weights = weights.copy()
            except ValueError:
                continue

        if best_weights is None:
            best_weights = np.ones(n_features) / n_features
            best_value = 0.0

        return OptimizerResult(
            weights=best_weights,
            objective_value=best_value,
            converged=True,
            n_iterations=n_evaluated,
            extra={
                "n_samples": n_samples,
                "distribution": self.distribution,
            },
        )


class SobolSearchOptimizer(BaseOptimizer):
    """Weight optimizer using Sobol sequence (quasi-random).

    Uses Sobol low-discrepancy sequence for more uniform coverage
    of the search space compared to pure random sampling.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        n_samples: int = 1000,
        seed: int | None = None,
    ) -> None:
        """Initialize Sobol Search optimizer.

        Args:
            min_weight: Minimum weight value.
            n_samples: Number of Sobol samples to evaluate.
            seed: Random seed for reproducibility.
        """
        self.min_weight = min_weight
        self.n_samples = n_samples
        self.seed = seed

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Sobol sequence."""
        from scipy.stats import qmc

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_samples = kwargs.get("n_samples", self.n_samples)
        n_features = desirabilities.shape[1]

        # Generate Sobol sequence
        sampler = qmc.Sobol(d=n_features, seed=self.seed)
        samples = sampler.random(n_samples)

        # Scale to [min_weight, 1.0]
        samples = min_weight + samples * (1.0 - min_weight)

        best_value = float("-inf")
        best_weights = None
        n_evaluated = 0

        for raw_weights in samples:
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)

            try:
                value = objective_fn(scores, labels)
                n_evaluated += 1

                if value > best_value:
                    best_value = value
                    best_weights = weights.copy()
            except ValueError:
                continue

        if best_weights is None:
            best_weights = np.ones(n_features) / n_features
            best_value = 0.0

        return OptimizerResult(
            weights=best_weights,
            objective_value=best_value,
            converged=True,
            n_iterations=n_evaluated,
            extra={
                "n_samples": n_samples,
                "method": "sobol",
            },
        )
