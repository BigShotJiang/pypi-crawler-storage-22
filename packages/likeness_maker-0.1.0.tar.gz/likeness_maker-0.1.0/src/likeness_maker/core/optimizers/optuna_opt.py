"""Optuna-based weight optimizer.

This optimizer uses Optuna for Bayesian optimization of feature weights.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import numpy as np

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class OptunaOptimizer(BaseOptimizer):
    """Weight optimizer using Optuna Bayesian optimization.

    Uses TPE (Tree-structured Parzen Estimator) or CMA-ES to find
    optimal weights that maximize the given objective function.

    Requires optuna to be installed: `pip install optuna`
    """

    def __init__(
        self,
        n_trials: int = 100,
        min_weight: float = 0.01,
        cv_folds: int = 0,
        sampler: str = "tpe",
        seed: int | None = None,
        show_progress: bool = False,
    ) -> None:
        """Initialize Optuna optimizer.

        Args:
            n_trials: Number of optimization trials.
            min_weight: Minimum weight value. Set to 0.0 for feature selection.
            cv_folds: Number of cross-validation folds (0 = no CV).
            sampler: Sampler type ("tpe" or "cmaes").
            seed: Random seed for reproducibility.
            show_progress: Show Optuna progress bar.
        """
        self.n_trials = n_trials
        self.min_weight = min_weight
        self.cv_folds = cv_folds
        self.sampler = sampler
        self.seed = seed
        self.show_progress = show_progress

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Optuna.

        Args:
            desirabilities: Shape (n_samples, n_features).
            objective_fn: Objective to maximize.
            labels: Optional labels for supervised objectives.
            **kwargs: Override any init parameters.

        Returns:
            OptimizerResult with optimized weights.

        Raises:
            ImportError: If optuna is not installed.
        """
        try:
            import optuna
        except ImportError as e:
            msg = "optuna is required for OptunaOptimizer. Install with: pip install optuna"
            raise ImportError(msg) from e

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        # Allow kwargs to override init params
        n_trials = kwargs.get("n_trials", self.n_trials)
        min_weight = kwargs.get("min_weight", self.min_weight)
        cv_folds = kwargs.get("cv_folds", self.cv_folds)

        n_features = desirabilities.shape[1]

        # Create sampler
        if self.sampler == "cmaes":
            sampler = optuna.samplers.CmaEsSampler(seed=self.seed)
        else:
            sampler = optuna.samplers.TPESampler(seed=self.seed)

        # Suppress optuna logging if not showing progress
        if not self.show_progress:
            optuna.logging.set_verbosity(optuna.logging.WARNING)

        def objective(trial: optuna.Trial) -> float:
            # Suggest weights for each feature
            raw_weights = np.array(
                [trial.suggest_float(f"w_{i}", min_weight, 1.0) for i in range(n_features)]
            )

            # Normalize weights
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)

            if cv_folds > 1:
                # Cross-validation
                return self._cv_objective(desirabilities, labels, weights, objective_fn, cv_folds)
            else:
                # Full dataset
                scores = self.compute_scores(desirabilities, weights)
                return objective_fn(scores, labels)

        # Create and run study
        study = optuna.create_study(direction="maximize", sampler=sampler)
        study.optimize(
            objective,
            n_trials=n_trials,
            show_progress_bar=self.show_progress,
        )

        # Extract best weights
        best_raw = np.array([study.best_params[f"w_{i}"] for i in range(n_features)])
        best_weights = self.normalize_weights(best_raw, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=study.best_value,
            converged=True,
            n_iterations=len(study.trials),
            extra={
                "best_trial": study.best_trial.number,
                "raw_weights": best_raw.tolist(),
            },
        )

    def _cv_objective(
        self,
        desirabilities: NDArray[np.float64],
        labels: NDArray[np.float64] | None,
        weights: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        cv_folds: int,
    ) -> float:
        """Compute cross-validated objective value.

        Args:
            desirabilities: Full desirability matrix.
            labels: Full labels array (or None).
            weights: Current weights to evaluate.
            objective_fn: Objective function.
            cv_folds: Number of folds.

        Returns:
            Mean objective value across folds.
        """
        n_samples = len(desirabilities)
        indices = np.arange(n_samples)
        np.random.shuffle(indices)

        fold_size = n_samples // cv_folds
        fold_values = []

        for fold in range(cv_folds):
            start = fold * fold_size
            end = start + fold_size if fold < cv_folds - 1 else n_samples

            # Validation indices
            val_indices = indices[start:end]

            # Compute scores on validation set
            val_desirabilities = desirabilities[val_indices]
            val_labels = labels[val_indices] if labels is not None else None

            scores = self.compute_scores(val_desirabilities, weights)
            try:
                fold_value = objective_fn(scores, val_labels)
                fold_values.append(fold_value)
            except ValueError:
                # Handle cases like single-class folds in ROC-AUC
                continue

        return float(np.mean(fold_values)) if fold_values else 0.0
