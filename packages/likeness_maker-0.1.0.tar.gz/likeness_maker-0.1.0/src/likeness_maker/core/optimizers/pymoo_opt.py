"""Multi-objective optimization using pymoo.

Supports NSGA-II, NSGA-III, and other multi-objective algorithms.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Any

import numpy as np

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class MultiObjectiveResult:
    """Result from multi-objective optimization.

    Attributes:
        pareto_weights: Array of Pareto-optimal weight vectors,
            shape (n_solutions, n_features).
        pareto_objectives: Objective values for each solution,
            shape (n_solutions, n_objectives).
        best_compromise: Single best compromise solution (weights).
        objective_names: Names of the objectives.
    """

    def __init__(
        self,
        pareto_weights: NDArray[np.float64],
        pareto_objectives: NDArray[np.float64],
        objective_names: list[str],
    ) -> None:
        self.pareto_weights = pareto_weights
        self.pareto_objectives = pareto_objectives
        self.objective_names = objective_names

        # Find best compromise (closest to ideal point)
        ideal = pareto_objectives.max(axis=0)
        nadir = pareto_objectives.min(axis=0)

        # Normalize objectives
        if np.all(ideal == nadir):
            # All solutions are the same
            self.best_compromise = pareto_weights[0]
            self.best_compromise_idx = 0
        else:
            normalized = (pareto_objectives - nadir) / (ideal - nadir + 1e-10)
            # Distance to ideal (1, 1, ...)
            distances = np.sqrt(np.sum((1 - normalized) ** 2, axis=1))
            self.best_compromise_idx = int(np.argmin(distances))
            self.best_compromise = pareto_weights[self.best_compromise_idx]


class NSGA2Optimizer(BaseOptimizer):
    """Multi-objective optimizer using NSGA-II.

    NSGA-II (Non-dominated Sorting Genetic Algorithm II) is a popular
    evolutionary multi-objective optimization algorithm.

    Returns a set of Pareto-optimal solutions trading off between
    multiple objectives.

    Requires pymoo: pip install pymoo
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        population_size: int = 100,
        n_generations: int = 100,
        seed: int | None = None,
    ) -> None:
        """Initialize NSGA-II optimizer.

        Args:
            min_weight: Minimum weight value.
            population_size: Population size.
            n_generations: Number of generations.
            seed: Random seed for reproducibility.
        """
        self.min_weight = min_weight
        self.population_size = population_size
        self.n_generations = n_generations
        self.seed = seed

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using NSGA-II.

        Note: For multi-objective optimization, use optimize_multi() instead.
        This method uses only a single objective for compatibility.
        """
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        # For single objective, delegate to internal method
        result = self._optimize_single(
            desirabilities=desirabilities,
            objective_fn=objective_fn,
            labels=labels,
            **kwargs,
        )
        return result

    def optimize_multi(
        self,
        desirabilities: NDArray[np.float64],
        objective_fns: Sequence[Callable[[NDArray[np.float64], NDArray[np.float64] | None], float]],
        objective_names: Sequence[str],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> MultiObjectiveResult:
        """Optimize weights for multiple objectives.

        Args:
            desirabilities: Shape (n_samples, n_features).
            objective_fns: List of objective functions to maximize.
            objective_names: Names for each objective.
            labels: Optional labels for supervised objectives.
            **kwargs: Override init parameters.

        Returns:
            MultiObjectiveResult with Pareto-optimal solutions.
        """
        try:
            from pymoo.algorithms.moo.nsga2 import NSGA2
            from pymoo.core.problem import Problem
            from pymoo.optimize import minimize as pymoo_minimize
            from pymoo.termination import get_termination
        except ImportError as e:
            msg = "pymoo is required. Install with: pip install pymoo"
            raise ImportError(msg) from e

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]
        n_objectives = len(objective_fns)

        class WeightProblem(Problem):
            def __init__(prob_self) -> None:
                super().__init__(
                    n_var=n_features,
                    n_obj=n_objectives,
                    n_constr=0,
                    xl=np.full(n_features, min_weight),
                    xu=np.ones(n_features),
                )

            def _evaluate(prob_self, x: NDArray, out: dict, *args: Any, **kw: Any) -> None:
                # x has shape (pop_size, n_features)
                f = np.zeros((len(x), n_objectives))

                for i, raw_weights in enumerate(x):
                    weights = self.normalize_weights(raw_weights, min_weight=min_weight)
                    scores = self.compute_scores(desirabilities, weights)

                    for j, obj_fn in enumerate(objective_fns):
                        try:
                            # Negate because pymoo minimizes
                            f[i, j] = -obj_fn(scores, labels)
                        except ValueError:
                            f[i, j] = 1e10

                out["F"] = f

        problem = WeightProblem()
        algorithm = NSGA2(pop_size=self.population_size)
        termination = get_termination("n_gen", self.n_generations)

        result = pymoo_minimize(
            problem,
            algorithm,
            termination,
            seed=self.seed,
            verbose=False,
        )

        # Extract Pareto front
        pareto_weights = np.array(
            [self.normalize_weights(x, min_weight=min_weight) for x in result.X]
        )
        pareto_objectives = -result.F  # Convert back to maximization

        return MultiObjectiveResult(
            pareto_weights=pareto_weights,
            pareto_objectives=pareto_objectives,
            objective_names=list(objective_names),
        )

    def _optimize_single(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Single-objective optimization using NSGA-II."""
        try:
            from pymoo.algorithms.soo.nonconvex.ga import GA
            from pymoo.core.problem import Problem
            from pymoo.optimize import minimize as pymoo_minimize
            from pymoo.termination import get_termination
        except ImportError as e:
            msg = "pymoo is required. Install with: pip install pymoo"
            raise ImportError(msg) from e

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        class WeightProblem(Problem):
            def __init__(prob_self) -> None:
                super().__init__(
                    n_var=n_features,
                    n_obj=1,
                    n_constr=0,
                    xl=np.full(n_features, min_weight),
                    xu=np.ones(n_features),
                )

            def _evaluate(prob_self, x: NDArray, out: dict, *args: Any, **kw: Any) -> None:
                f = np.zeros(len(x))

                for i, raw_weights in enumerate(x):
                    weights = self.normalize_weights(raw_weights, min_weight=min_weight)
                    scores = self.compute_scores(desirabilities, weights)

                    try:
                        f[i] = -objective_fn(scores, labels)
                    except ValueError:
                        f[i] = 1e10

                out["F"] = f.reshape(-1, 1)

        problem = WeightProblem()
        algorithm = GA(pop_size=self.population_size)
        termination = get_termination("n_gen", self.n_generations)

        result = pymoo_minimize(
            problem,
            algorithm,
            termination,
            seed=self.seed,
            verbose=False,
        )

        best_weights = self.normalize_weights(result.X, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.F[0],
            converged=True,
            n_iterations=self.n_generations,
            extra={
                "algorithm": "GA",
                "population_size": self.population_size,
            },
        )


class NSGA3Optimizer(NSGA2Optimizer):
    """Multi-objective optimizer using NSGA-III.

    NSGA-III is better suited for many-objective optimization
    (more than 3 objectives) than NSGA-II.
    """

    def optimize_multi(
        self,
        desirabilities: NDArray[np.float64],
        objective_fns: Sequence[Callable[[NDArray[np.float64], NDArray[np.float64] | None], float]],
        objective_names: Sequence[str],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> MultiObjectiveResult:
        """Optimize weights for multiple objectives using NSGA-III."""
        try:
            from pymoo.algorithms.moo.nsga3 import NSGA3
            from pymoo.core.problem import Problem
            from pymoo.optimize import minimize as pymoo_minimize
            from pymoo.termination import get_termination
            from pymoo.util.ref_dirs import get_reference_directions
        except ImportError as e:
            msg = "pymoo is required. Install with: pip install pymoo"
            raise ImportError(msg) from e

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]
        n_objectives = len(objective_fns)

        class WeightProblem(Problem):
            def __init__(prob_self) -> None:
                super().__init__(
                    n_var=n_features,
                    n_obj=n_objectives,
                    n_constr=0,
                    xl=np.full(n_features, min_weight),
                    xu=np.ones(n_features),
                )

            def _evaluate(prob_self, x: NDArray, out: dict, *args: Any, **kw: Any) -> None:
                f = np.zeros((len(x), n_objectives))

                for i, raw_weights in enumerate(x):
                    weights = self.normalize_weights(raw_weights, min_weight=min_weight)
                    scores = self.compute_scores(desirabilities, weights)

                    for j, obj_fn in enumerate(objective_fns):
                        try:
                            f[i, j] = -obj_fn(scores, labels)
                        except ValueError:
                            f[i, j] = 1e10

                out["F"] = f

        problem = WeightProblem()

        # Reference directions for NSGA-III
        ref_dirs = get_reference_directions("das-dennis", n_objectives, n_partitions=12)

        algorithm = NSGA3(pop_size=self.population_size, ref_dirs=ref_dirs)
        termination = get_termination("n_gen", self.n_generations)

        result = pymoo_minimize(
            problem,
            algorithm,
            termination,
            seed=self.seed,
            verbose=False,
        )

        pareto_weights = np.array(
            [self.normalize_weights(x, min_weight=min_weight) for x in result.X]
        )
        pareto_objectives = -result.F

        return MultiObjectiveResult(
            pareto_weights=pareto_weights,
            pareto_objectives=pareto_objectives,
            objective_names=list(objective_names),
        )
