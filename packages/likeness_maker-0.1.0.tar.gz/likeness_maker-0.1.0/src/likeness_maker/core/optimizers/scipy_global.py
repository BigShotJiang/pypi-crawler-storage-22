"""Scipy global optimization methods.

This module provides global optimization methods from scipy.optimize:
- Differential Evolution
- Dual Annealing
- Basin Hopping
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import numpy as np
from scipy import optimize

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class DifferentialEvolutionOptimizer(BaseOptimizer):
    """Weight optimizer using Differential Evolution.

    Differential Evolution is a stochastic global optimization algorithm
    that is particularly effective for continuous optimization problems.
    It's population-based and doesn't require gradient information.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        max_iterations: int = 100,
        population_size: int = 15,
        mutation: tuple[float, float] = (0.5, 1.0),
        recombination: float = 0.7,
        strategy: str = "best1bin",
        seed: int | None = None,
        workers: int = 1,
    ) -> None:
        """Initialize Differential Evolution optimizer.

        Args:
            min_weight: Minimum weight value.
            max_iterations: Maximum number of generations.
            population_size: Population size multiplier.
            mutation: Mutation constant (dithering range).
            recombination: Recombination constant (crossover probability).
            strategy: Differential evolution strategy.
            seed: Random seed for reproducibility.
            workers: Number of parallel workers (-1 for all CPUs).
        """
        self.min_weight = min_weight
        self.max_iterations = max_iterations
        self.population_size = population_size
        self.mutation = mutation
        self.recombination = recombination
        self.strategy = strategy
        self.seed = seed
        self.workers = workers

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Differential Evolution."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: NDArray[np.float64]) -> float:
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        # Bounds for each weight
        bounds = [(min_weight, 1.0) for _ in range(n_features)]

        result = optimize.differential_evolution(
            neg_objective,
            bounds,
            maxiter=self.max_iterations,
            popsize=self.population_size,
            mutation=self.mutation,
            recombination=self.recombination,
            strategy=self.strategy,
            seed=self.seed,
            workers=self.workers,
            updating="deferred" if self.workers != 1 else "immediate",
        )

        best_weights = self.normalize_weights(result.x, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=result.success,
            n_iterations=result.nit,
            extra={
                "message": result.message,
                "n_function_evals": result.nfev,
            },
        )


class DualAnnealingOptimizer(BaseOptimizer):
    """Weight optimizer using Dual Annealing.

    Dual Annealing combines Classical Simulated Annealing with a
    fast local search method. Good for finding global minimum in
    presence of many local minima.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        max_iterations: int = 1000,
        initial_temp: float = 5230.0,
        restart_temp_ratio: float = 2e-5,
        visit: float = 2.62,
        accept: float = -5.0,
        seed: int | None = None,
        no_local_search: bool = False,
    ) -> None:
        """Initialize Dual Annealing optimizer.

        Args:
            min_weight: Minimum weight value.
            max_iterations: Maximum number of global iterations.
            initial_temp: Initial temperature.
            restart_temp_ratio: Temperature ratio for restart.
            visit: Parameter for visiting distribution.
            accept: Parameter for acceptance distribution.
            seed: Random seed for reproducibility.
            no_local_search: If True, skip local search step.
        """
        self.min_weight = min_weight
        self.max_iterations = max_iterations
        self.initial_temp = initial_temp
        self.restart_temp_ratio = restart_temp_ratio
        self.visit = visit
        self.accept = accept
        self.seed = seed
        self.no_local_search = no_local_search

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Dual Annealing."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: NDArray[np.float64]) -> float:
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        bounds = [(min_weight, 1.0) for _ in range(n_features)]

        result = optimize.dual_annealing(
            neg_objective,
            bounds,
            maxiter=self.max_iterations,
            initial_temp=self.initial_temp,
            restart_temp_ratio=self.restart_temp_ratio,
            visit=self.visit,
            accept=self.accept,
            seed=self.seed,
            no_local_search=self.no_local_search,
        )

        best_weights = self.normalize_weights(result.x, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=result.success,
            n_iterations=result.nit,
            extra={
                "message": result.message,
                "n_function_evals": result.nfev,
            },
        )


class BasinHoppingOptimizer(BaseOptimizer):
    """Weight optimizer using Basin Hopping.

    Basin Hopping is a global optimization algorithm that combines
    random perturbation with local minimization. Good for rugged
    energy landscapes with many local minima.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        n_iterations: int = 100,
        temperature: float = 1.0,
        step_size: float = 0.5,
        seed: int | None = None,
    ) -> None:
        """Initialize Basin Hopping optimizer.

        Args:
            min_weight: Minimum weight value.
            n_iterations: Number of basin hopping iterations.
            temperature: Temperature for Metropolis criterion.
            step_size: Initial step size for random displacement.
            seed: Random seed for reproducibility.
        """
        self.min_weight = min_weight
        self.n_iterations = n_iterations
        self.temperature = temperature
        self.step_size = step_size
        self.seed = seed

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Basin Hopping."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: NDArray[np.float64]) -> float:
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        # Initial guess (seed is passed directly to basinhopping)
        x0 = np.ones(n_features) / n_features

        # Bounds
        bounds = [(min_weight, 1.0) for _ in range(n_features)]
        minimizer_kwargs = {
            "method": "L-BFGS-B",
            "bounds": bounds,
        }

        result = optimize.basinhopping(
            neg_objective,
            x0,
            niter=self.n_iterations,
            T=self.temperature,
            stepsize=self.step_size,
            minimizer_kwargs=minimizer_kwargs,
            seed=self.seed,
        )

        best_weights = self.normalize_weights(result.x, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=True,  # Basin hopping doesn't have a convergence flag
            n_iterations=result.nit,
            extra={
                "message": result.message,
                "n_function_evals": result.nfev,
                "minimization_failures": result.minimization_failures,
            },
        )


class NelderMeadOptimizer(BaseOptimizer):
    """Weight optimizer using Nelder-Mead simplex method.

    Nelder-Mead is a gradient-free optimization method that uses
    a simplex (n+1 vertices in n dimensions) to explore the space.
    Simple and robust for small dimensions.
    """

    def __init__(
        self,
        min_weight: float = 0.01,
        max_iterations: int = 200,
        tolerance: float = 1e-6,
    ) -> None:
        """Initialize Nelder-Mead optimizer.

        Args:
            min_weight: Minimum weight value.
            max_iterations: Maximum number of iterations.
            tolerance: Tolerance for termination.
        """
        self.min_weight = min_weight
        self.max_iterations = max_iterations
        self.tolerance = tolerance

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Nelder-Mead."""
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: NDArray[np.float64]) -> float:
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        x0 = np.ones(n_features) / n_features

        result = optimize.minimize(
            neg_objective,
            x0,
            method="Nelder-Mead",
            options={
                "maxiter": self.max_iterations,
                "xatol": self.tolerance,
                "fatol": self.tolerance,
            },
        )

        best_weights = self.normalize_weights(result.x, min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=result.success,
            n_iterations=result.nit,
            extra={
                "message": result.message,
                "n_function_evals": result.nfev,
            },
        )
