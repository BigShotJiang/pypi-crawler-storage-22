"""Scipy-based weight optimizer.

This optimizer uses scipy.optimize for gradient-based optimization.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import numpy as np
from scipy.optimize import minimize

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class ScipyOptimizer(BaseOptimizer):
    """Weight optimizer using scipy.optimize.

    Uses gradient-based methods (SLSQP or L-BFGS-B) to find optimal
    weights that maximize the given objective function.
    """

    def __init__(
        self,
        method: str = "SLSQP",
        min_weight: float = 0.01,
        max_iterations: int = 100,
        tolerance: float = 1e-6,
    ) -> None:
        """Initialize scipy optimizer.

        Args:
            method: Optimization method ("SLSQP" or "L-BFGS-B").
            min_weight: Minimum weight value.
            max_iterations: Maximum number of iterations.
            tolerance: Convergence tolerance.
        """
        self.method = method
        self.min_weight = min_weight
        self.max_iterations = max_iterations
        self.tolerance = tolerance

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using scipy.optimize.minimize.

        Args:
            desirabilities: Shape (n_samples, n_features).
            objective_fn: Objective to maximize.
            labels: Optional labels for supervised objectives.
            **kwargs: Override any init parameters.

        Returns:
            OptimizerResult with optimized weights.
        """
        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        # Allow kwargs to override init params
        min_weight = kwargs.get("min_weight", self.min_weight)
        max_iterations = kwargs.get("max_iterations", self.max_iterations)
        tolerance = kwargs.get("tolerance", self.tolerance)

        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: NDArray[np.float64]) -> float:
            """Negative objective (scipy minimizes)."""
            weights = self.normalize_weights(raw_weights, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                # Return large value for invalid configurations
                return 1e10

        # Initial weights (uniform)
        x0 = np.ones(n_features) / n_features

        # Bounds for each weight
        bounds = [(min_weight, 1.0) for _ in range(n_features)]

        # Constraint: weights sum to 1
        constraints = {"type": "eq", "fun": lambda w: np.sum(w) - 1.0}

        # Run optimization
        result = minimize(
            neg_objective,
            x0,
            method=self.method,
            bounds=bounds,
            constraints=constraints if self.method == "SLSQP" else None,
            options={"maxiter": max_iterations, "ftol": tolerance},
        )

        # Normalize final weights
        best_weights = self.normalize_weights(result.x, min_weight=min_weight)
        best_value = -result.fun  # Convert back to positive

        return OptimizerResult(
            weights=best_weights,
            objective_value=best_value,
            converged=result.success,
            n_iterations=result.nit if hasattr(result, "nit") else 0,
            extra={
                "scipy_message": result.message,
                "raw_weights": result.x.tolist(),
            },
        )
