"""Scikit-optimize (skopt) based optimizer.

Uses Gaussian Process based Bayesian optimization.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import numpy as np

from likeness_maker.core.optimizers.base import BaseOptimizer, OptimizerResult

if TYPE_CHECKING:
    from numpy.typing import NDArray


class SkoptOptimizer(BaseOptimizer):
    """Weight optimizer using scikit-optimize (Gaussian Process).

    Uses Gaussian Process based Bayesian optimization from scikit-optimize.
    More theoretically grounded than TPE (used in Optuna), but can be
    slower for high-dimensional problems.

    Requires scikit-optimize: pip install scikit-optimize
    """

    def __init__(
        self,
        n_calls: int = 100,
        n_initial_points: int = 10,
        min_weight: float = 0.01,
        acq_func: str = "gp_hedge",
        seed: int | None = None,
        verbose: bool = False,
    ) -> None:
        """Initialize skopt optimizer.

        Args:
            n_calls: Number of function evaluations.
            n_initial_points: Number of random initial points.
            min_weight: Minimum weight value.
            acq_func: Acquisition function. Options:
                - "gp_hedge": Probabilistic choice among LCB, EI, PI
                - "LCB": Lower Confidence Bound
                - "EI": Expected Improvement
                - "PI": Probability of Improvement
            seed: Random seed for reproducibility.
            verbose: Print progress.
        """
        self.n_calls = n_calls
        self.n_initial_points = n_initial_points
        self.min_weight = min_weight
        self.acq_func = acq_func
        self.seed = seed
        self.verbose = verbose

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Gaussian Process Bayesian optimization."""
        try:
            from skopt import gp_minimize
            from skopt.space import Real
        except ImportError as e:
            msg = "scikit-optimize is required. Install with: pip install scikit-optimize"
            raise ImportError(msg) from e

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_calls = kwargs.get("n_calls", self.n_calls)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: list[float]) -> float:
            weights_arr = np.array(raw_weights)
            weights = self.normalize_weights(weights_arr, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        # Define search space
        space = [Real(min_weight, 1.0, name=f"w_{i}") for i in range(n_features)]

        result = gp_minimize(
            neg_objective,
            space,
            n_calls=n_calls,
            n_initial_points=self.n_initial_points,
            acq_func=self.acq_func,
            random_state=self.seed,
            verbose=self.verbose,
        )

        best_weights = self.normalize_weights(np.array(result.x), min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=True,
            n_iterations=len(result.x_iters),
            extra={
                "n_calls": n_calls,
                "acq_func": self.acq_func,
                "all_objectives": [-v for v in result.func_vals.tolist()],
            },
        )


class ForestOptimizer(BaseOptimizer):
    """Weight optimizer using Random Forest based optimization.

    Uses Random Forest surrogate model instead of Gaussian Process.
    Faster than GP for high-dimensional problems.

    Requires scikit-optimize: pip install scikit-optimize
    """

    def __init__(
        self,
        n_calls: int = 100,
        n_initial_points: int = 10,
        min_weight: float = 0.01,
        base_estimator: str = "RF",
        acq_func: str = "EI",
        seed: int | None = None,
        verbose: bool = False,
    ) -> None:
        """Initialize forest optimizer.

        Args:
            n_calls: Number of function evaluations.
            n_initial_points: Number of random initial points.
            min_weight: Minimum weight value.
            base_estimator: Surrogate model. Options:
                - "RF": Random Forest
                - "ET": Extra Trees
                - "GBRT": Gradient Boosted Trees
            acq_func: Acquisition function.
            seed: Random seed for reproducibility.
            verbose: Print progress.
        """
        self.n_calls = n_calls
        self.n_initial_points = n_initial_points
        self.min_weight = min_weight
        self.base_estimator = base_estimator
        self.acq_func = acq_func
        self.seed = seed
        self.verbose = verbose

    def optimize(
        self,
        desirabilities: NDArray[np.float64],
        objective_fn: Callable[[NDArray[np.float64], NDArray[np.float64] | None], float],
        labels: NDArray[np.float64] | None = None,
        **kwargs: Any,
    ) -> OptimizerResult:
        """Optimize weights using Random Forest Bayesian optimization."""
        try:
            from skopt import forest_minimize
            from skopt.space import Real
        except ImportError as e:
            msg = "scikit-optimize is required. Install with: pip install scikit-optimize"
            raise ImportError(msg) from e

        if desirabilities.ndim != 2:
            msg = f"Expected 2D array, got {desirabilities.ndim}D"
            raise ValueError(msg)

        min_weight = kwargs.get("min_weight", self.min_weight)
        n_calls = kwargs.get("n_calls", self.n_calls)
        n_features = desirabilities.shape[1]

        def neg_objective(raw_weights: list[float]) -> float:
            weights_arr = np.array(raw_weights)
            weights = self.normalize_weights(weights_arr, min_weight=min_weight)
            scores = self.compute_scores(desirabilities, weights)
            try:
                return -objective_fn(scores, labels)
            except ValueError:
                return 1e10

        space = [Real(min_weight, 1.0, name=f"w_{i}") for i in range(n_features)]

        result = forest_minimize(
            neg_objective,
            space,
            n_calls=n_calls,
            n_initial_points=self.n_initial_points,
            base_estimator=self.base_estimator,
            acq_func=self.acq_func,
            random_state=self.seed,
            verbose=self.verbose,
        )

        best_weights = self.normalize_weights(np.array(result.x), min_weight=min_weight)

        return OptimizerResult(
            weights=best_weights,
            objective_value=-result.fun,
            converged=True,
            n_iterations=len(result.x_iters),
            extra={
                "n_calls": n_calls,
                "base_estimator": self.base_estimator,
                "acq_func": self.acq_func,
            },
        )
