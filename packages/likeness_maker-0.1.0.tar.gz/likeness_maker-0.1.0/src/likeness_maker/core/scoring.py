"""Likeness score computation.

This module provides functions for computing likeness scores from
desirability values using weighted geometric mean (the QED approach).
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from likeness_maker.core.desirability import BaseDesirabilityFunction


def geometric_mean_score(
    desirabilities: NDArray[np.float64],
    weights: NDArray[np.float64] | None = None,
) -> float:
    """Compute weighted geometric mean of desirability scores.

    This is the QED formula:
        score = exp(sum(w_i * ln(d_i)) / sum(w_i))

    Args:
        desirabilities: Array of desirability scores [0, 1] for each feature.
        weights: Optional weights for each feature (default: uniform).

    Returns:
        Likeness score in [0, 1].
    """
    desirabilities = np.asarray(desirabilities, dtype=np.float64)

    if weights is None:
        weights = np.ones(len(desirabilities), dtype=np.float64)
    else:
        weights = np.asarray(weights, dtype=np.float64)

    if len(desirabilities) != len(weights):
        msg = f"Length mismatch: desirabilities={len(desirabilities)}, weights={len(weights)}"
        raise ValueError(msg)

    # Clip to avoid log(0)
    desirabilities = np.clip(desirabilities, 1e-10, 1.0)

    # Weighted geometric mean via log transform
    log_sum = np.sum(weights * np.log(desirabilities))
    weight_sum = np.sum(weights)

    if weight_sum == 0:
        return 0.0

    return math.exp(log_sum / weight_sum)


def batch_score(
    features: NDArray[np.float64],
    desirability_functions: Sequence[BaseDesirabilityFunction],
    weights: NDArray[np.float64] | None = None,
) -> NDArray[np.float64]:
    """Score multiple samples efficiently.

    Computes likeness scores for a batch of samples using their
    feature values and fitted desirability functions.

    Args:
        features: Feature matrix, shape (n_samples, n_features).
        desirability_functions: List of desirability functions, one per feature.
        weights: Optional feature weights (default: uniform).

    Returns:
        Array of likeness scores, shape (n_samples,).
    """
    features = np.asarray(features, dtype=np.float64)

    if features.ndim == 1:
        features = features.reshape(1, -1)

    n_samples, n_features = features.shape

    if len(desirability_functions) != n_features:
        msg = f"Got {n_features} features but {len(desirability_functions)} functions"
        raise ValueError(msg)

    # Compute all desirabilities
    desirabilities = np.zeros((n_samples, n_features), dtype=np.float64)
    for i, func in enumerate(desirability_functions):
        desirabilities[:, i] = func(features[:, i])

    # Compute geometric mean for each sample
    if weights is None:
        weights = np.ones(n_features, dtype=np.float64)
    else:
        weights = np.asarray(weights, dtype=np.float64)

    desirabilities = np.clip(desirabilities, 1e-10, 1.0)
    log_sum = np.sum(weights * np.log(desirabilities), axis=1)
    weight_sum = np.sum(weights)

    if weight_sum == 0:
        return np.zeros(n_samples, dtype=np.float64)

    return np.exp(log_sum / weight_sum)


def individual_desirabilities(
    features: NDArray[np.float64],
    desirability_functions: Sequence[BaseDesirabilityFunction],
) -> NDArray[np.float64]:
    """Compute individual desirability scores for each feature.

    Useful for debugging and understanding which features contribute
    to low likeness scores.

    Args:
        features: Feature matrix, shape (n_samples, n_features).
        desirability_functions: List of desirability functions.

    Returns:
        Desirability matrix, shape (n_samples, n_features).
    """
    features = np.asarray(features, dtype=np.float64)

    if features.ndim == 1:
        features = features.reshape(1, -1)

    n_samples, n_features = features.shape

    if len(desirability_functions) != n_features:
        msg = f"Got {n_features} features but {len(desirability_functions)} functions"
        raise ValueError(msg)

    desirabilities = np.zeros((n_samples, n_features), dtype=np.float64)
    for i, func in enumerate(desirability_functions):
        desirabilities[:, i] = func(features[:, i])

    return desirabilities
