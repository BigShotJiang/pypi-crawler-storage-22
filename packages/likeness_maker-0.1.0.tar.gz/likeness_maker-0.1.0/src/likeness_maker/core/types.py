"""Core type definitions for likeness scoring."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import numpy as np
    from numpy.typing import NDArray


class DesirabilityFunction(Protocol):
    """Protocol for desirability functions.

    Desirability functions map raw feature values to scores in [0, 1],
    where 1 indicates maximum desirability.
    """

    def __call__(self, x: NDArray[np.float64]) -> NDArray[np.float64]:
        """Map raw values to desirability scores [0, 1].

        Args:
            x: Array of raw feature values.

        Returns:
            Array of desirability scores in [0, 1].
        """
        ...

    def get_parameters(self) -> dict[str, float]:
        """Return the fitted parameters of this function.

        Returns:
            Dictionary mapping parameter names to values.
        """
        ...


@dataclass(frozen=True, slots=True)
class FeatureDefinition:
    """Defines a single feature/descriptor.

    Attributes:
        name: Unique identifier for the feature.
        description: Human-readable description.
        lower_bound: Physical lower bound (e.g., MW >= 0).
        upper_bound: Physical upper bound (e.g., humidity <= 100).
    """

    name: str
    description: str = ""
    lower_bound: float | None = None
    upper_bound: float | None = None


@dataclass(frozen=True, slots=True)
class FeatureSet:
    """Immutable collection of feature definitions.

    A FeatureSet defines the features used in a likeness model.
    The order of features is significant and preserved.

    Attributes:
        features: Tuple of feature definitions.
    """

    features: tuple[FeatureDefinition, ...]

    def __post_init__(self) -> None:
        """Validate that feature names are unique."""
        names = [f.name for f in self.features]
        if len(names) != len(set(names)):
            duplicates = [n for n in names if names.count(n) > 1]
            msg = f"Duplicate feature names: {list(set(duplicates))}"
            raise ValueError(msg)

    @property
    def names(self) -> tuple[str, ...]:
        """Return tuple of feature names in order."""
        return tuple(f.name for f in self.features)

    def __len__(self) -> int:
        """Return number of features."""
        return len(self.features)

    def __getitem__(self, key: int | str) -> FeatureDefinition:
        """Get feature by index or name.

        Args:
            key: Integer index or feature name.

        Returns:
            The corresponding FeatureDefinition.

        Raises:
            KeyError: If feature name not found.
            IndexError: If index out of range.
        """
        if isinstance(key, int):
            return self.features[key]
        for feature in self.features:
            if feature.name == key:
                return feature
        raise KeyError(f"Feature '{key}' not found")

    def __contains__(self, name: str) -> bool:
        """Check if feature name exists."""
        return name in self.names


@dataclass(frozen=True, slots=True)
class FittedDesirability:
    """A desirability function with its fitted parameters.

    Stores the result of fitting a desirability function to reference data.

    Attributes:
        feature_name: Name of the feature this function applies to.
        function_type: Type of desirability function (e.g., "ads", "linear").
        parameters: Fitted parameter values.
        r_squared: Goodness of fit (1.0 = perfect fit).
    """

    feature_name: str
    function_type: str
    parameters: dict[str, float]
    r_squared: float

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "feature_name": self.feature_name,
            "function_type": self.function_type,
            "parameters": self.parameters,
            "r_squared": self.r_squared,
        }

    @classmethod
    def from_dict(cls, data: dict) -> FittedDesirability:
        """Create from dictionary."""
        return cls(
            feature_name=data["feature_name"],
            function_type=data["function_type"],
            parameters=data["parameters"],
            r_squared=data["r_squared"],
        )
