"""Weight optimization using Shannon entropy.

This module implements the weight optimization approach from the QED paper,
which uses Shannon entropy to determine feature importance.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def shannon_entropy(values: NDArray[np.float64], n_bins: int = 10) -> float:
    """Calculate Shannon entropy of a distribution.

    Args:
        values: Array of values to compute entropy for.
        n_bins: Number of bins for discretization.

    Returns:
        Shannon entropy in bits (log base 2).
    """
    # Remove NaN values
    values = values[~np.isnan(values)]
    if len(values) == 0:
        return 0.0

    # Create histogram
    hist, _ = np.histogram(values, bins=n_bins, range=(0.0, 1.0))

    # Convert to probabilities
    probs = hist / hist.sum()

    # Filter out zero probabilities (log(0) is undefined)
    probs = probs[probs > 0]

    # Calculate entropy: H = -sum(p * log2(p))
    entropy = -np.sum(probs * np.log2(probs))

    return float(entropy)


def compute_entropy_weights(
    desirabilities: NDArray[np.float64],
    n_bins: int = 10,
    normalize: bool = True,
) -> NDArray[np.float64]:
    """Compute feature weights based on Shannon entropy.

    Features with higher entropy (more spread across bins) get higher weights
    because they have more discriminating power.

    Args:
        desirabilities: 2D array of shape (n_samples, n_features) with
            desirability values in [0, 1].
        n_bins: Number of bins for entropy calculation.
        normalize: If True, normalize weights to sum to 1.

    Returns:
        Array of weights for each feature.

    Raises:
        ValueError: If desirabilities is not 2D.
    """
    if desirabilities.ndim != 2:
        msg = f"Expected 2D array, got {desirabilities.ndim}D"
        raise ValueError(msg)
    if desirabilities.shape[0] == 0:
        msg = "desirabilities array cannot be empty"
        raise ValueError(msg)

    n_features = desirabilities.shape[1]
    entropies = np.zeros(n_features)

    for i in range(n_features):
        entropies[i] = shannon_entropy(desirabilities[:, i], n_bins=n_bins)

    weights = entropies / entropies.sum() if normalize and entropies.sum() > 0 else entropies
    return weights


def optimize_weights_iterative(
    desirabilities: NDArray[np.float64],
    n_bins: int = 10,
    max_iterations: int = 100,
    tolerance: float = 1e-6,
) -> NDArray[np.float64]:
    """Optimize weights iteratively to maximize score entropy.

    This implements an iterative optimization where weights are adjusted
    to maximize the entropy of the final score distribution.

    Args:
        desirabilities: 2D array of shape (n_samples, n_features).
        n_bins: Number of bins for entropy calculation.
        max_iterations: Maximum number of iterations.
        tolerance: Convergence tolerance for weight changes.

    Returns:
        Optimized weights for each feature, normalized to sum to 1.0.

    Raises:
        ValueError: If desirabilities is not 2D or is empty.
    """
    if desirabilities.ndim != 2:
        msg = f"Expected 2D array, got {desirabilities.ndim}D"
        raise ValueError(msg)
    if desirabilities.shape[0] == 0:
        msg = "desirabilities array cannot be empty"
        raise ValueError(msg)

    n_features = desirabilities.shape[1]

    # Start with uniform weights
    weights = np.ones(n_features) / n_features

    # Pre-compute log desirabilities (constant across iterations)
    log_d = np.log(np.clip(desirabilities, 1e-10, 1.0))

    for _ in range(max_iterations):
        # Calculate weighted geometric mean scores
        weighted_log = log_d * weights
        scores = np.exp(weighted_log.sum(axis=1))

        # Calculate entropy of scores
        score_entropy = shannon_entropy(scores, n_bins=n_bins)

        # Gradient estimation: perturb each weight and measure entropy change
        gradients = np.zeros(n_features)
        delta = 0.01

        for i in range(n_features):
            # Perturb weight up
            weights_up = weights.copy()
            weights_up[i] += delta
            weights_up = weights_up / weights_up.sum()

            weighted_log_up = log_d * weights_up
            scores_up = np.exp(weighted_log_up.sum(axis=1))
            entropy_up = shannon_entropy(scores_up, n_bins=n_bins)

            gradients[i] = (entropy_up - score_entropy) / delta

        # Update weights in gradient direction
        new_weights = weights + 0.1 * gradients
        new_weights = np.clip(new_weights, 0.01, None)  # Ensure positive
        new_weights = new_weights / new_weights.sum()  # Normalize

        # Check convergence
        if np.max(np.abs(new_weights - weights)) < tolerance:
            break

        weights = new_weights

    return weights
