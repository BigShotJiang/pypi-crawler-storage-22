"""Molecular layer for likeness scoring (requires RDKit)."""

try:
    from rdkit import Chem  # noqa: F401
except ImportError as e:
    msg = (
        "The molecular layer requires RDKit. Install with: pip install 'likeness-maker[molecular]'"
    )
    raise ImportError(msg) from e

from likeness_maker.molecular.descriptors import (
    DESCRIPTOR_REGISTRY,
    QED_DESCRIPTORS,
    calculate_descriptor,
    calculate_descriptors,
    calculate_descriptors_batch,
    descriptors_to_feature_set,
    list_available_descriptors,
)
from likeness_maker.molecular.io import (
    filter_valid_molecules,
    molecules_from_smiles,
    read_sdf,
    read_smiles,
)
from likeness_maker.molecular.presets import (
    PresetConfig,
    get_lipinski_preset,
    get_preset,
    get_qed_preset,
    get_qed_simple_preset,
    list_presets,
)

__all__ = [
    "DESCRIPTOR_REGISTRY",
    "QED_DESCRIPTORS",
    "PresetConfig",
    "calculate_descriptor",
    "calculate_descriptors",
    "calculate_descriptors_batch",
    "descriptors_to_feature_set",
    "filter_valid_molecules",
    "get_lipinski_preset",
    "get_preset",
    "get_qed_preset",
    "get_qed_simple_preset",
    "list_available_descriptors",
    "list_presets",
    "molecules_from_smiles",
    "read_sdf",
    "read_smiles",
]
