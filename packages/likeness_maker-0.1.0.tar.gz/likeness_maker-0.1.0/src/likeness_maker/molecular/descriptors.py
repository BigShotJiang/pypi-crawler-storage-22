"""Molecular descriptor calculation using RDKit.

This module provides functions for calculating molecular descriptors
that can be used with the likeness scoring system.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from numpy.typing import NDArray
    from rdkit.Chem import Mol

from likeness_maker.core.types import FeatureDefinition, FeatureSet

# Standard QED descriptors
QED_DESCRIPTORS = (
    "MW",  # Molecular weight
    "ALOGP",  # Wildman-Crippen LogP
    "HBA",  # Hydrogen bond acceptors
    "HBD",  # Hydrogen bond donors
    "PSA",  # Polar surface area
    "ROTB",  # Rotatable bonds
    "AROM",  # Aromatic rings
    "ALERTS",  # Structural alerts (not a standard descriptor)
)


@dataclass(frozen=True, slots=True)
class DescriptorDefinition:
    """Definition of a molecular descriptor.

    Attributes:
        name: Short identifier.
        full_name: Full descriptive name.
        rdkit_name: Name used by RDKit's Descriptors module.
        lower_bound: Physical lower bound.
        upper_bound: Physical upper bound.
    """

    name: str
    full_name: str
    rdkit_name: str
    lower_bound: float | None = None
    upper_bound: float | None = None


# Registry of available descriptors
DESCRIPTOR_REGISTRY: dict[str, DescriptorDefinition] = {
    "MW": DescriptorDefinition(
        name="MW",
        full_name="Molecular Weight",
        rdkit_name="MolWt",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "ALOGP": DescriptorDefinition(
        name="ALOGP",
        full_name="Wildman-Crippen LogP",
        rdkit_name="MolLogP",
        lower_bound=None,
        upper_bound=None,
    ),
    "HBA": DescriptorDefinition(
        name="HBA",
        full_name="Hydrogen Bond Acceptors",
        rdkit_name="NumHAcceptors",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "HBD": DescriptorDefinition(
        name="HBD",
        full_name="Hydrogen Bond Donors",
        rdkit_name="NumHDonors",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "PSA": DescriptorDefinition(
        name="PSA",
        full_name="Polar Surface Area",
        rdkit_name="TPSA",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "ROTB": DescriptorDefinition(
        name="ROTB",
        full_name="Rotatable Bonds",
        rdkit_name="NumRotatableBonds",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "AROM": DescriptorDefinition(
        name="AROM",
        full_name="Aromatic Rings",
        rdkit_name="NumAromaticRings",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "FRAC_CSP3": DescriptorDefinition(
        name="FRAC_CSP3",
        full_name="Fraction of sp3 Carbons",
        rdkit_name="FractionCSP3",
        lower_bound=0.0,
        upper_bound=1.0,
    ),
    "HEAVY_ATOMS": DescriptorDefinition(
        name="HEAVY_ATOMS",
        full_name="Heavy Atom Count",
        rdkit_name="HeavyAtomCount",
        lower_bound=0.0,
        upper_bound=None,
    ),
    "RINGS": DescriptorDefinition(
        name="RINGS",
        full_name="Ring Count",
        rdkit_name="RingCount",
        lower_bound=0.0,
        upper_bound=None,
    ),
}


def get_descriptor_function(rdkit_name: str):
    """Get the RDKit descriptor function by name.

    Args:
        rdkit_name: Name of the descriptor in RDKit's Descriptors module.

    Returns:
        Callable that computes the descriptor for a molecule.
    """
    from rdkit.Chem import Descriptors

    if hasattr(Descriptors, rdkit_name):
        return getattr(Descriptors, rdkit_name)

    msg = (
        f"Unknown RDKit descriptor: {rdkit_name}. Check rdkit.Chem.Descriptors for available names."
    )
    raise ValueError(msg)


def calculate_descriptor(mol: Mol, descriptor_name: str) -> float:
    """Calculate a single descriptor for a molecule.

    Args:
        mol: RDKit Mol object.
        descriptor_name: Name of the descriptor (from DESCRIPTOR_REGISTRY).

    Returns:
        Descriptor value.
    """
    if descriptor_name not in DESCRIPTOR_REGISTRY:
        msg = (
            f"Unknown descriptor: {descriptor_name}. Available: {list(DESCRIPTOR_REGISTRY.keys())}"
        )
        raise ValueError(msg)

    defn = DESCRIPTOR_REGISTRY[descriptor_name]
    func = get_descriptor_function(defn.rdkit_name)
    return float(func(mol))


def calculate_descriptors(
    mol: Mol,
    descriptor_names: tuple[str, ...] | None = None,
) -> dict[str, float]:
    """Calculate multiple descriptors for a molecule.

    Args:
        mol: RDKit Mol object.
        descriptor_names: Tuple of descriptor names. If None, uses QED descriptors
            (excluding ALERTS which requires separate handling).

    Returns:
        Dictionary mapping descriptor names to values.
    """
    if descriptor_names is None:
        # Default to QED descriptors (excluding ALERTS)
        descriptor_names = tuple(d for d in QED_DESCRIPTORS if d != "ALERTS")

    return {name: calculate_descriptor(mol, name) for name in descriptor_names}


def calculate_descriptors_batch(
    mols: list[Mol | None] | pd.Series,
    descriptor_names: tuple[str, ...] | None = None,
) -> NDArray[np.float64]:
    """Calculate descriptors for a batch of molecules.

    Args:
        mols: List or Series of RDKit Mol objects (None for invalid).
        descriptor_names: Tuple of descriptor names.

    Returns:
        2D array of shape (n_molecules, n_descriptors).
    """
    if descriptor_names is None:
        descriptor_names = tuple(d for d in QED_DESCRIPTORS if d != "ALERTS")

    results = []
    for mol in mols:
        if mol is None:
            results.append([np.nan] * len(descriptor_names))
        else:
            row = [calculate_descriptor(mol, name) for name in descriptor_names]
            results.append(row)

    return np.array(results, dtype=np.float64)


def descriptors_to_feature_set(
    descriptor_names: tuple[str, ...] | None = None,
) -> FeatureSet:
    """Create a FeatureSet from descriptor definitions.

    Args:
        descriptor_names: Tuple of descriptor names.

    Returns:
        FeatureSet with corresponding FeatureDefinitions.
    """
    if descriptor_names is None:
        descriptor_names = tuple(d for d in QED_DESCRIPTORS if d != "ALERTS")

    features = []
    for name in descriptor_names:
        if name not in DESCRIPTOR_REGISTRY:
            msg = f"Unknown descriptor: {name}"
            raise ValueError(msg)

        defn = DESCRIPTOR_REGISTRY[name]
        features.append(
            FeatureDefinition(
                name=defn.name,
                description=defn.full_name,
                lower_bound=defn.lower_bound,
                upper_bound=defn.upper_bound,
            )
        )

    return FeatureSet(features=tuple(features))


def list_available_descriptors() -> list[str]:
    """List all available descriptor names.

    Returns:
        List of descriptor names.
    """
    return list(DESCRIPTOR_REGISTRY.keys())
