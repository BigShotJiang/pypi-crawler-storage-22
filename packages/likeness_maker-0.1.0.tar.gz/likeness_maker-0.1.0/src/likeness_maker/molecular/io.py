"""Molecular file I/O utilities.

This module provides functions for reading molecular data from various formats.
"""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from collections.abc import Iterator

    from rdkit.Chem import Mol


def read_sdf(path: str | Path, remove_hydrogens: bool = True) -> pd.DataFrame:
    """Read molecules from an SDF file.

    Args:
        path: Path to the SDF file.
        remove_hydrogens: If True, remove explicit hydrogens.

    Returns:
        DataFrame with 'mol' column containing RDKit Mol objects and
        any properties from the SDF as additional columns.

    Warns:
        UserWarning: If any molecules failed to parse.
    """
    from rdkit import Chem

    path = Path(path)
    if not path.exists():
        msg = f"File not found: {path}"
        raise FileNotFoundError(msg)

    supplier = Chem.SDMolSupplier(str(path), removeHs=remove_hydrogens)

    records = []
    failed_count = 0
    for mol in supplier:
        if mol is None:
            failed_count += 1
            continue

        record: dict = {"mol": mol}
        # Extract all properties
        for prop in mol.GetPropsAsDict():
            record[prop] = mol.GetProp(prop)
        records.append(record)

    if failed_count > 0:
        warnings.warn(
            f"Skipped {failed_count} molecule(s) that failed to parse from {path}",
            stacklevel=2,
        )

    return pd.DataFrame(records)


def read_smiles(
    path: str | Path,
    smiles_column: str = "smiles",
    name_column: str | None = None,
    delimiter: str = ",",
) -> pd.DataFrame:
    """Read molecules from a SMILES file (CSV/TSV).

    Args:
        path: Path to the file.
        smiles_column: Name of the column containing SMILES.
        name_column: Name of the column containing molecule names (optional).
        delimiter: Column delimiter.

    Returns:
        DataFrame with 'mol' column containing RDKit Mol objects.

    Warns:
        UserWarning: If any SMILES failed to parse.
    """
    from rdkit import Chem

    path = Path(path)
    if not path.exists():
        msg = f"File not found: {path}"
        raise FileNotFoundError(msg)

    df = pd.read_csv(path, delimiter=delimiter)

    if smiles_column not in df.columns:
        msg = f"Column '{smiles_column}' not found. Available: {list(df.columns)}"
        raise ValueError(msg)

    mols = []
    failed_count = 0
    for smi in df[smiles_column]:
        if pd.notna(smi):
            mol = Chem.MolFromSmiles(smi)
            if mol is None:
                failed_count += 1
        else:
            mol = None
        mols.append(mol)

    if failed_count > 0:
        warnings.warn(
            f"Failed to parse {failed_count} SMILES string(s) from {path}",
            stacklevel=2,
        )

    df["mol"] = mols
    return df


def molecules_from_smiles(smiles_list: list[str]) -> Iterator[Mol | None]:
    """Convert a list of SMILES to RDKit Mol objects.

    Args:
        smiles_list: List of SMILES strings.

    Yields:
        RDKit Mol objects (or None for invalid SMILES).
    """
    from rdkit import Chem

    for smi in smiles_list:
        yield Chem.MolFromSmiles(smi) if smi else None


def filter_valid_molecules(df: pd.DataFrame, mol_column: str = "mol") -> pd.DataFrame:
    """Filter DataFrame to keep only rows with valid molecules.

    Args:
        df: DataFrame with molecule column.
        mol_column: Name of the molecule column.

    Returns:
        Filtered DataFrame with only valid molecules.
    """
    return df[df[mol_column].notna()].reset_index(drop=True)
