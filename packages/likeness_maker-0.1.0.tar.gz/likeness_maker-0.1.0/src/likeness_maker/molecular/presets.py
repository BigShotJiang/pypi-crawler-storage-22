"""Preset configurations for common likeness models.

This module provides preset configurations for well-known molecular
property profiles like QED (drug-likeness) and Lipinski's Rule of Five.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

from likeness_maker.core.types import FeatureDefinition, FeatureSet, FittedDesirability


@dataclass(frozen=True, slots=True)
class PresetConfig:
    """Configuration for a preset likeness model.

    Attributes:
        name: Preset name.
        description: Human-readable description.
        feature_set: Features used in the model.
        fitted_functions: Pre-fitted desirability functions.
        weights: Feature weights.
    """

    name: str
    description: str
    feature_set: FeatureSet
    fitted_functions: dict[str, FittedDesirability]
    weights: NDArray[np.float64]


# Original QED parameters from Bickerton et al. 2012
# These are the ADS function parameters for each property
QED_ADS_PARAMETERS = {
    "MW": {
        "a": 2.817,
        "b": 392.575,
        "c": 290.749,
        "d": 2.420,
        "e": 49.223,
        "f": 65.371,
        "d_max": 104.981,
    },
    "ALOGP": {
        "a": 3.172,
        "b": 137.862,
        "c": 2.534,
        "d": 4.581,
        "e": 0.822,
        "f": 0.576,
        "d_max": 131.319,
    },
    "HBD": {
        "a": 1.618,
        "b": 1010.051,
        "c": 0.985,
        "d": 2.954,
        "e": 1.294,
        "f": 0.439,
        "d_max": 1000.000,
    },
    "HBA": {
        "a": 2.948,
        "b": 160.461,
        "c": 3.615,
        "d": 4.435,
        "e": 0.290,
        "f": 1.300,
        "d_max": 148.775,
    },
    "PSA": {
        "a": 1.876,
        "b": 125.224,
        "c": 62.903,
        "d": 87.834,
        "e": 12.014,
        "f": 28.512,
        "d_max": 116.534,
    },
    "ROTB": {
        "a": 0.010,
        "b": 272.409,
        "c": 2.558,
        "d": 1.565,
        "e": 2.040,
        "f": 1.144,
        "d_max": 105.441,
    },
    "AROM": {
        "a": 3.217,
        "b": 957.799,
        "c": 2.274,
        "d": 2.075,
        "e": 1.043,
        "f": 1.130,
        "d_max": 949.906,
    },
    "ALERTS": {
        "a": 0.010,
        "b": 1.000,
        "c": 0.000,
        "d": 0.010,
        "e": 0.010,
        "f": 0.010,
        "d_max": 1.000,
    },
}

# QED weights (from the paper)
QED_WEIGHTS = np.array([0.66, 0.46, 0.05, 0.61, 0.06, 0.65, 0.48, 0.95])

# QED descriptor order
QED_DESCRIPTOR_ORDER = ("MW", "ALOGP", "HBD", "HBA", "PSA", "ROTB", "AROM", "ALERTS")


def get_qed_preset() -> PresetConfig:
    """Get the original QED preset configuration.

    Returns:
        PresetConfig with QED parameters from Bickerton et al. 2012.

    Note:
        The ALERTS descriptor requires separate structural alert checking.
        For basic use without ALERTS, use get_qed_simple_preset().
    """
    features = []
    fitted_funcs = {}

    for name in QED_DESCRIPTOR_ORDER:
        features.append(
            FeatureDefinition(
                name=name,
                description=f"QED {name} descriptor",
            )
        )

        params = QED_ADS_PARAMETERS[name]
        fitted_funcs[name] = FittedDesirability(
            feature_name=name,
            function_type="ads",
            parameters=params,
            r_squared=1.0,  # These are literature values, not fitted
        )

    return PresetConfig(
        name="QED",
        description="Quantitative Estimate of Drug-likeness (Bickerton et al. 2012)",
        feature_set=FeatureSet(features=tuple(features)),
        fitted_functions=fitted_funcs,
        weights=QED_WEIGHTS,
    )


def get_qed_simple_preset() -> PresetConfig:
    """Get a simplified QED preset without structural alerts.

    Returns:
        PresetConfig with QED parameters but excluding ALERTS.
    """
    # Exclude ALERTS
    descriptor_order = tuple(d for d in QED_DESCRIPTOR_ORDER if d != "ALERTS")

    features = []
    fitted_funcs = {}

    for name in descriptor_order:
        features.append(
            FeatureDefinition(
                name=name,
                description=f"QED {name} descriptor",
            )
        )

        params = QED_ADS_PARAMETERS[name]
        fitted_funcs[name] = FittedDesirability(
            feature_name=name,
            function_type="ads",
            parameters=params,
            r_squared=1.0,
        )

    # Weights without ALERTS (indices 0-6, excluding 7)
    weights = QED_WEIGHTS[:7]
    # Renormalize
    weights = weights / weights.sum()

    return PresetConfig(
        name="QED-simple",
        description="Simplified QED without structural alerts",
        feature_set=FeatureSet(features=tuple(features)),
        fitted_functions=fitted_funcs,
        weights=weights,
    )


# Lipinski's Rule of Five thresholds
LIPINSKI_THRESHOLDS = {
    "MW": {"max": 500.0},
    "ALOGP": {"max": 5.0},
    "HBD": {"max": 5.0},
    "HBA": {"max": 10.0},
}


def get_lipinski_preset() -> PresetConfig:
    """Get a Lipinski Rule of Five preset.

    This uses linear desirability functions where:
    - Values within limits get desirability 1.0
    - Values exceeding limits get decreasing desirability

    Returns:
        PresetConfig for Lipinski Rule of Five.
    """
    features = []
    fitted_funcs = {}

    for name, thresholds in LIPINSKI_THRESHOLDS.items():
        max_val = thresholds["max"]

        features.append(
            FeatureDefinition(
                name=name,
                description=f"Lipinski {name}",
                upper_bound=max_val,
            )
        )

        # Linear function: 1.0 at 0, 0.0 at 2x the limit
        fitted_funcs[name] = FittedDesirability(
            feature_name=name,
            function_type="linear",
            parameters={
                "x_min": 0.0,
                "x_max": max_val * 2,
                "invert": 1.0,  # Higher is worse
            },
            r_squared=1.0,
        )

    # Equal weights
    weights = np.ones(len(LIPINSKI_THRESHOLDS)) / len(LIPINSKI_THRESHOLDS)

    return PresetConfig(
        name="Lipinski",
        description="Lipinski's Rule of Five",
        feature_set=FeatureSet(features=tuple(features)),
        fitted_functions=fitted_funcs,
        weights=weights,
    )


def _create_preset_registry() -> dict[str, PresetConfig]:
    """Create the preset registry."""
    return {
        "qed": get_qed_preset(),
        "qed-simple": get_qed_simple_preset(),
        "lipinski": get_lipinski_preset(),
    }


# Cached preset registry (created lazily)
_PRESET_CACHE: dict[str, PresetConfig] | None = None


def _get_preset_registry() -> dict[str, PresetConfig]:
    """Get the preset registry, creating it if needed."""
    global _PRESET_CACHE
    if _PRESET_CACHE is None:
        _PRESET_CACHE = _create_preset_registry()
    return _PRESET_CACHE


def get_preset(name: str) -> PresetConfig:
    """Get a preset configuration by name.

    Args:
        name: Preset name (case-insensitive).

    Returns:
        PresetConfig for the requested preset.

    Raises:
        ValueError: If preset name is not found.
    """
    registry = _get_preset_registry()
    name_lower = name.lower()
    if name_lower not in registry:
        available = list(registry.keys())
        msg = f"Unknown preset: {name}. Available: {available}"
        raise ValueError(msg)

    return registry[name_lower]


def list_presets() -> list[str]:
    """List available preset names.

    Returns:
        List of preset names.
    """
    return list(_get_preset_registry().keys())
