"""Visualization module for likeness-maker.

This module provides plotting functions for model analysis and interpretation.
Requires matplotlib and optionally seaborn.

Install with: pip install likeness-maker[viz]
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# Lazy imports to avoid requiring matplotlib at import time
if TYPE_CHECKING:
    from likeness_maker.viz.comparison import (
        plot_correlation_heatmap,
        plot_model_comparison,
        plot_score_scatter,
    )
    from likeness_maker.viz.desirability import plot_desirability
    from likeness_maker.viz.distribution import plot_score_comparison, plot_score_distribution
    from likeness_maker.viz.radar import plot_radar, plot_radar_comparison
    from likeness_maker.viz.weights import plot_weight_comparison, plot_weights


def __getattr__(name: str):
    """Lazy import of visualization functions."""
    if name == "plot_desirability":
        from likeness_maker.viz.desirability import plot_desirability

        return plot_desirability
    if name == "plot_score_distribution":
        from likeness_maker.viz.distribution import plot_score_distribution

        return plot_score_distribution
    if name == "plot_score_comparison":
        from likeness_maker.viz.distribution import plot_score_comparison

        return plot_score_comparison
    if name == "plot_weights":
        from likeness_maker.viz.weights import plot_weights

        return plot_weights
    if name == "plot_weight_comparison":
        from likeness_maker.viz.weights import plot_weight_comparison

        return plot_weight_comparison
    if name == "plot_radar":
        from likeness_maker.viz.radar import plot_radar

        return plot_radar
    if name == "plot_radar_comparison":
        from likeness_maker.viz.radar import plot_radar_comparison

        return plot_radar_comparison
    if name == "plot_model_comparison":
        from likeness_maker.viz.comparison import plot_model_comparison

        return plot_model_comparison
    if name == "plot_score_scatter":
        from likeness_maker.viz.comparison import plot_score_scatter

        return plot_score_scatter
    if name == "plot_correlation_heatmap":
        from likeness_maker.viz.comparison import plot_correlation_heatmap

        return plot_correlation_heatmap

    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


__all__ = [
    "plot_correlation_heatmap",
    "plot_desirability",
    "plot_model_comparison",
    "plot_radar",
    "plot_radar_comparison",
    "plot_score_comparison",
    "plot_score_distribution",
    "plot_score_scatter",
    "plot_weight_comparison",
    "plot_weights",
]
