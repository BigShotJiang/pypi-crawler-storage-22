"""Model comparison visualization."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from likeness_maker.viz.utils import COLORS, DEFAULT_DPI, save_or_show

if TYPE_CHECKING:
    from matplotlib.figure import Figure, SubFigure
    from numpy.typing import NDArray

    from likeness_maker.core.model import LikenessModel


def plot_model_comparison(
    models: dict[str, LikenessModel],
    data: NDArray[np.float64],
    *,
    title: str = "Model Score Comparison",
    figsize: tuple[float, float] | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot scatter matrix comparing scores from multiple models.

    Args:
        models: Mapping from model name to LikenessModel.
        data: Feature data to score, shape (n_samples, n_features).
        title: Plot title.
        figsize: Figure size.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.viz.utils import get_color

    model_names = list(models.keys())
    n_models = len(model_names)

    if n_models < 2:
        msg = "Need at least 2 models for comparison"
        raise ValueError(msg)

    # Compute scores for each model
    scores = {}
    for name, model in models.items():
        scores[name] = model.score(data)

    # Create scatter matrix
    if figsize is None:
        figsize = (4 * n_models, 4 * n_models)

    fig, axes = plt.subplots(n_models, n_models, figsize=figsize)

    for i, name_i in enumerate(model_names):
        for j, name_j in enumerate(model_names):
            ax = axes[i, j]

            if i == j:
                # Diagonal: histogram
                ax.hist(
                    scores[name_i],
                    bins=30,
                    alpha=0.7,
                    color=get_color(i),
                    edgecolor="white",
                )
                ax.set_xlim(0, 1)
            else:
                # Off-diagonal: scatter plot
                ax.scatter(
                    scores[name_j],
                    scores[name_i],
                    alpha=0.5,
                    s=10,
                    color=COLORS["primary"],
                )

                # Add correlation
                corr = np.corrcoef(scores[name_j], scores[name_i])[0, 1]
                ax.text(
                    0.05,
                    0.95,
                    f"r = {corr:.3f}",
                    transform=ax.transAxes,
                    verticalalignment="top",
                    fontsize=10,
                    bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.8},
                )

                # Add identity line
                ax.plot([0, 1], [0, 1], "--", color="gray", alpha=0.5)
                ax.set_xlim(0, 1)
                ax.set_ylim(0, 1)

            # Labels
            if i == n_models - 1:
                ax.set_xlabel(name_j)
            if j == 0:
                ax.set_ylabel(name_i)

    fig.suptitle(title, fontsize=14, y=1.02)
    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def plot_score_scatter(
    model1: LikenessModel,
    model2: LikenessModel,
    data: NDArray[np.float64],
    *,
    name1: str = "Model 1",
    name2: str = "Model 2",
    title: str | None = None,
    figsize: tuple[float, float] | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot scatter plot comparing scores from two models.

    Args:
        model1: First LikenessModel.
        model2: Second LikenessModel.
        data: Feature data to score.
        name1: Name for first model.
        name2: Name for second model.
        title: Plot title.
        figsize: Figure size.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    scores1 = model1.score(data)
    scores2 = model2.score(data)

    fig, ax = plt.subplots(figsize=figsize or (8, 8))

    ax.scatter(scores1, scores2, alpha=0.5, s=20, color=COLORS["primary"])

    # Add correlation
    corr = np.corrcoef(scores1, scores2)[0, 1]
    ax.text(
        0.05,
        0.95,
        f"Pearson r = {corr:.4f}",
        transform=ax.transAxes,
        verticalalignment="top",
        fontsize=12,
        bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.8},
    )

    # Add identity line
    ax.plot([0, 1], [0, 1], "--", color="gray", alpha=0.5, label="y = x")

    # Add regression line (requires scipy)
    try:
        from scipy import stats

        slope, intercept, _, _, _ = stats.linregress(scores1, scores2)
        x_line = np.array([0, 1])
        y_line = slope * x_line + intercept
        ax.plot(
            x_line,
            y_line,
            "-",
            color=COLORS["secondary"],
            alpha=0.7,
            label=f"y = {slope:.3f}x + {intercept:.3f}",
        )
    except ImportError:
        pass  # scipy not available

    ax.set_xlabel(name1)
    ax.set_ylabel(name2)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title(title or f"{name1} vs {name2}")
    ax.legend(loc="lower right")
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.3)

    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def plot_correlation_heatmap(
    models: dict[str, LikenessModel],
    data: NDArray[np.float64],
    *,
    title: str = "Score Correlation Matrix",
    figsize: tuple[float, float] | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot correlation heatmap of model scores.

    Args:
        models: Mapping from model name to LikenessModel.
        data: Feature data to score.
        title: Plot title.
        figsize: Figure size.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    model_names = list(models.keys())
    n_models = len(model_names)

    # Compute scores
    scores = np.column_stack([model.score(data) for model in models.values()])

    # Compute correlation matrix
    corr_matrix = np.corrcoef(scores.T)

    fig, ax = plt.subplots(figsize=figsize or (8, 6))

    im = ax.imshow(corr_matrix, cmap="RdBu_r", vmin=-1, vmax=1)

    # Add colorbar
    cbar = ax.figure.colorbar(im, ax=ax)
    cbar.ax.set_ylabel("Correlation", rotation=-90, va="bottom")

    # Set ticks
    ax.set_xticks(np.arange(n_models))
    ax.set_yticks(np.arange(n_models))
    ax.set_xticklabels(model_names, rotation=45, ha="right")
    ax.set_yticklabels(model_names)

    # Add text annotations
    for i in range(n_models):
        for j in range(n_models):
            color = "white" if abs(corr_matrix[i, j]) > 0.5 else "black"
            ax.text(j, i, f"{corr_matrix[i, j]:.2f}", ha="center", va="center", color=color)

    ax.set_title(title)
    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)
