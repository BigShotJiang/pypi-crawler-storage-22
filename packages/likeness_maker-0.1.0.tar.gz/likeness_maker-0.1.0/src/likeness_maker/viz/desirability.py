"""Desirability curve visualization."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from likeness_maker.core.desirability import get_desirability_class
from likeness_maker.viz.utils import COLORS, DEFAULT_DPI, DEFAULT_FIGSIZE, save_or_show

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure, SubFigure
    from numpy.typing import NDArray

    from likeness_maker.core.model import LikenessModel


def plot_desirability(
    model: LikenessModel,
    feature: str | None = None,
    x_range: tuple[float, float] | None = None,
    n_points: int = 200,
    data: NDArray[np.float64] | None = None,
    *,
    show_data: bool = True,
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot desirability function curve for a feature.

    Args:
        model: Fitted LikenessModel.
        feature: Feature name to plot. If None, plots all features in a grid.
        x_range: Range of x values (min, max). If None, uses feature bounds or data range.
        n_points: Number of points for curve.
        data: Optional reference data to overlay as histogram.
        show_data: Whether to show data distribution overlay.
        figsize: Figure size.
        ax: Existing axes to plot on (only for single feature).
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    if feature is None:
        # Plot all features in a grid
        return _plot_all_desirabilities(
            model,
            x_range,
            n_points,
            data,
            show_data=show_data,
            figsize=figsize,
            savefig=savefig,
            show=show,
        )

    # Single feature plot
    if feature not in model.fitted_functions:
        msg = f"Feature '{feature}' not found in model. Available: {list(model.fitted_functions.keys())}"
        raise ValueError(msg)

    fitted = model.fitted_functions[feature]
    feature_idx = model.feature_set.names.index(feature)
    feature_def = model.feature_set.features[feature_idx]

    # Create desirability function instance from fitted parameters
    desirability_cls = get_desirability_class(fitted.function_type)
    desirability_func = desirability_cls.from_parameters(**fitted.parameters)

    # Determine x range
    if x_range is None:
        if data is not None:
            x_min, x_max = data[:, feature_idx].min(), data[:, feature_idx].max()
            margin = (x_max - x_min) * 0.1
            x_range = (x_min - margin, x_max + margin)
        elif feature_def.lower_bound is not None and feature_def.upper_bound is not None:
            x_range = (feature_def.lower_bound, feature_def.upper_bound)
        else:
            x_range = (0.0, 1.0)

    # Create figure if needed
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize or DEFAULT_FIGSIZE)
    else:
        fig = ax.figure

    # Generate curve
    x = np.linspace(x_range[0], x_range[1], n_points)
    y = desirability_func(x)

    # Plot curve
    ax.plot(x, y, color=COLORS["primary"], linewidth=2, label="Desirability")

    # Overlay data distribution
    if show_data and data is not None:
        ax2 = ax.twinx()
        ax2.hist(
            data[:, feature_idx],
            bins=30,
            alpha=0.3,
            color=COLORS["secondary"],
            density=True,
            label="Data distribution",
        )
        ax2.set_ylabel("Density", color=COLORS["secondary"])
        ax2.tick_params(axis="y", labelcolor=COLORS["secondary"])

    ax.set_xlabel(feature)
    ax.set_ylabel("Desirability", color=COLORS["primary"])
    ax.tick_params(axis="y", labelcolor=COLORS["primary"])
    ax.set_ylim(0, 1.05)
    ax.set_title(f"Desirability: {feature}")
    ax.grid(True, alpha=0.3)

    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def _plot_all_desirabilities(
    model: LikenessModel,
    x_range: tuple[float, float] | None,
    n_points: int,
    data: NDArray[np.float64] | None,
    *,
    show_data: bool,
    figsize: tuple[float, float] | None,
    savefig: str | Path | None,
    show: bool,
) -> Figure | SubFigure:
    """Plot all desirability functions in a grid."""
    import matplotlib.pyplot as plt

    n_features = len(model.fitted_functions)
    if n_features == 0:
        msg = "Model has no fitted functions"
        raise ValueError(msg)

    # Calculate grid dimensions
    n_cols = min(3, n_features)
    n_rows = (n_features + n_cols - 1) // n_cols

    if figsize is None:
        figsize = (5 * n_cols, 4 * n_rows)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
    if n_features == 1:
        axes = np.array([[axes]])
    elif n_rows == 1:
        axes = axes.reshape(1, -1)
    elif n_cols == 1:
        axes = axes.reshape(-1, 1)

    for idx, feature in enumerate(model.fitted_functions):
        row, col = divmod(idx, n_cols)
        ax = axes[row, col]

        plot_desirability(
            model,
            feature=feature,
            x_range=x_range,
            n_points=n_points,
            data=data,
            show_data=show_data,
            ax=ax,
            show=False,
        )

    # Hide empty subplots
    for idx in range(n_features, n_rows * n_cols):
        row, col = divmod(idx, n_cols)
        axes[row, col].set_visible(False)

    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)
