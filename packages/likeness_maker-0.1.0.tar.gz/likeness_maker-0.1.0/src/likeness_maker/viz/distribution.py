"""Score distribution visualization."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from likeness_maker.viz.utils import COLORS, DEFAULT_DPI, DEFAULT_FIGSIZE, save_or_show

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure, SubFigure
    from numpy.typing import NDArray


def plot_score_distribution(
    scores: NDArray[np.float64],
    bins: int = 50,
    *,
    kde: bool = True,
    cumulative: bool = False,
    title: str = "Score Distribution",
    xlabel: str = "Score",
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot distribution of likeness scores.

    Args:
        scores: Array of likeness scores.
        bins: Number of histogram bins.
        kde: Whether to overlay kernel density estimate.
        cumulative: Whether to show cumulative distribution.
        title: Plot title.
        xlabel: X-axis label.
        figsize: Figure size.
        ax: Existing axes to plot on.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    scores = np.asarray(scores).flatten()

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize or DEFAULT_FIGSIZE)
    else:
        fig = ax.figure

    # Plot histogram
    ax.hist(
        scores,
        bins=bins,
        density=True,
        alpha=0.7,
        color=COLORS["primary"],
        edgecolor="white",
        cumulative=cumulative,
        label="Histogram",
    )

    # Add KDE overlay
    if kde and not cumulative:
        try:
            from scipy import stats

            kde_obj = stats.gaussian_kde(scores)
            x = np.linspace(scores.min(), scores.max(), 200)
            ax.plot(x, kde_obj(x), color=COLORS["secondary"], linewidth=2, label="KDE")
        except ImportError:
            pass  # scipy not available

    # Add statistics
    mean_score = np.mean(scores)
    median_score = np.median(scores)
    ax.axvline(
        mean_score,
        color=COLORS["tertiary"],
        linestyle="--",
        linewidth=1.5,
        label=f"Mean: {mean_score:.3f}",
    )
    ax.axvline(
        median_score,
        color=COLORS["quaternary"],
        linestyle=":",
        linewidth=1.5,
        label=f"Median: {median_score:.3f}",
    )

    ax.set_xlabel(xlabel)
    ax.set_ylabel("Cumulative Density" if cumulative else "Density")
    ax.set_title(title)
    ax.legend(loc="best")
    ax.grid(True, alpha=0.3)

    # Set x limits for scores (typically 0-1)
    if scores.min() >= 0 and scores.max() <= 1:
        ax.set_xlim(-0.02, 1.02)

    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def plot_score_comparison(
    scores_dict: dict[str, NDArray[np.float64]],
    bins: int = 30,
    *,
    alpha: float = 0.5,
    title: str = "Score Comparison",
    xlabel: str = "Score",
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot overlapping score distributions for comparison.

    Args:
        scores_dict: Mapping from label to scores array.
        bins: Number of histogram bins.
        alpha: Histogram transparency.
        title: Plot title.
        xlabel: X-axis label.
        figsize: Figure size.
        ax: Existing axes to plot on.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.viz.utils import get_color

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize or DEFAULT_FIGSIZE)
    else:
        fig = ax.figure

    for idx, (label, scores) in enumerate(scores_dict.items()):
        scores = np.asarray(scores).flatten()
        ax.hist(
            scores,
            bins=bins,
            density=True,
            alpha=alpha,
            color=get_color(idx),
            edgecolor="white",
            label=f"{label} (n={len(scores)})",
        )

    ax.set_xlabel(xlabel)
    ax.set_ylabel("Density")
    ax.set_title(title)
    ax.legend(loc="best")
    ax.grid(True, alpha=0.3)

    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)
