"""Radar/spider chart visualization."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Literal

import numpy as np

from likeness_maker.core.desirability import get_desirability_class
from likeness_maker.viz.utils import DEFAULT_DPI, save_or_show

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure, SubFigure
    from numpy.typing import NDArray

    from likeness_maker.core.model import LikenessModel


def plot_radar(
    model: LikenessModel,
    samples: NDArray[np.float64],
    *,
    aggregate: Literal["none", "mean", "median"] | None = None,
    labels: list[str] | None = None,
    title: str = "Feature Desirabilities",
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot radar chart of feature desirabilities.

    Args:
        model: Fitted LikenessModel.
        samples: Sample data, shape (n_samples, n_features) or (n_features,).
        aggregate: How to aggregate multiple samples:
            - None or "none": Plot each sample as separate line
            - "mean": Plot mean desirabilities
            - "median": Plot median desirabilities
        labels: Labels for each sample (when aggregate is None).
        title: Plot title.
        figsize: Figure size.
        ax: Existing polar axes to plot on.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.core.scoring import individual_desirabilities
    from likeness_maker.viz.utils import get_color

    samples = np.asarray(samples)
    if samples.ndim == 1:
        samples = samples.reshape(1, -1)

    # Get feature names and desirabilities
    feature_names = list(model.fitted_functions.keys())
    n_features = len(feature_names)

    # Create desirability function instances from fitted parameters
    func_list = []
    for name in feature_names:
        fitted = model.fitted_functions[name]
        cls = get_desirability_class(fitted.function_type)
        func_list.append(cls.from_parameters(**fitted.parameters))

    # Compute desirabilities for each sample
    desirabilities = individual_desirabilities(samples, func_list)

    # Create figure with polar axes
    if ax is None:
        fig, ax = plt.subplots(
            figsize=figsize or (8, 8),
            subplot_kw={"projection": "polar"},
        )
    else:
        fig = ax.figure

    # Calculate angles for radar chart
    angles = np.linspace(0, 2 * np.pi, n_features, endpoint=False).tolist()
    angles += angles[:1]  # Close the polygon

    # Handle aggregation
    if aggregate == "mean":
        values = np.mean(desirabilities, axis=0).tolist()
        values += values[:1]
        ax.plot(angles, values, "o-", linewidth=2, color=get_color(0), label="Mean")
        ax.fill(angles, values, alpha=0.25, color=get_color(0))
    elif aggregate == "median":
        values = np.median(desirabilities, axis=0).tolist()
        values += values[:1]
        ax.plot(angles, values, "o-", linewidth=2, color=get_color(0), label="Median")
        ax.fill(angles, values, alpha=0.25, color=get_color(0))
    else:
        # Plot each sample
        n_samples = min(len(samples), 10)  # Limit to 10 samples for readability
        for i in range(n_samples):
            values = desirabilities[i].tolist()
            values += values[:1]
            label = labels[i] if labels and i < len(labels) else f"Sample {i + 1}"
            ax.plot(angles, values, "o-", linewidth=1.5, color=get_color(i), label=label, alpha=0.7)

    # Set up the radar chart
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(feature_names)
    ax.set_ylim(0, 1)
    ax.set_title(title, y=1.08)

    # Add legend if multiple lines
    if aggregate is None and len(samples) > 1:
        ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.0))
    elif aggregate in ("mean", "median"):
        ax.legend(loc="upper right", bbox_to_anchor=(1.2, 1.0))

    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def plot_radar_comparison(
    models: dict[str, LikenessModel],
    sample: NDArray[np.float64],
    *,
    title: str = "Model Comparison",
    figsize: tuple[float, float] | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Compare desirabilities across models on a single sample.

    Args:
        models: Mapping from model name to LikenessModel.
        sample: Single sample, shape (n_features,).
        title: Plot title.
        figsize: Figure size.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.viz.utils import get_color

    sample = np.asarray(sample).flatten()

    # Get all unique feature names
    all_features: set[str] = set()
    for model in models.values():
        all_features.update(model.fitted_functions.keys())
    feature_names = sorted(all_features)
    n_features = len(feature_names)

    fig, ax = plt.subplots(
        figsize=figsize or (8, 8),
        subplot_kw={"projection": "polar"},
    )

    angles = np.linspace(0, 2 * np.pi, n_features, endpoint=False).tolist()
    angles += angles[:1]

    for idx, (model_name, model) in enumerate(models.items()):
        # Get desirabilities for features this model has
        values = []
        for feature in feature_names:
            if feature in model.fitted_functions:
                sample_idx = model.feature_set.names.index(feature)
                fitted = model.fitted_functions[feature]
                # Create function instance from fitted parameters
                cls = get_desirability_class(fitted.function_type)
                func = cls.from_parameters(**fitted.parameters)
                values.append(func(np.array([sample[sample_idx]]))[0])
            else:
                values.append(0.0)

        values += values[:1]
        ax.plot(angles, values, "o-", linewidth=2, color=get_color(idx), label=model_name)
        ax.fill(angles, values, alpha=0.1, color=get_color(idx))

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(feature_names)
    ax.set_ylim(0, 1)
    ax.set_title(title, y=1.08)
    ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.0))

    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)
