"""Common utilities for visualization module."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from matplotlib.figure import Figure, SubFigure

# Default color palette (colorblind-friendly)
COLORS = {
    "primary": "#1f77b4",  # Blue
    "secondary": "#ff7f0e",  # Orange
    "tertiary": "#2ca02c",  # Green
    "quaternary": "#d62728",  # Red
    "quinary": "#9467bd",  # Purple
    "senary": "#8c564b",  # Brown
    "septenary": "#e377c2",  # Pink
    "octonary": "#7f7f7f",  # Gray
}

# Color palette as list for iteration
COLOR_PALETTE = list(COLORS.values())

# Default figure settings
DEFAULT_FIGSIZE = (8, 6)
DEFAULT_DPI = 100


def setup_style() -> None:
    """Apply default matplotlib style settings."""
    try:
        import matplotlib.pyplot as plt

        plt.style.use("seaborn-v0_8-whitegrid")
    except OSError:
        # Fallback if seaborn style not available
        pass


def save_or_show(
    fig: Figure | SubFigure,
    savefig: str | Path | None = None,
    dpi: int = 150,
    *,
    show: bool = True,
) -> Figure | SubFigure:
    """Save figure to file and/or display it.

    Args:
        fig: Matplotlib figure to save/show.
        savefig: Path to save figure. If None, figure is not saved.
        dpi: Resolution for saved figure.
        show: Whether to display the figure (default: True).

    Returns:
        The input figure (for chaining).
    """
    if savefig is not None:
        fig.savefig(savefig, dpi=dpi, bbox_inches="tight")

    if show:
        import matplotlib.pyplot as plt

        plt.show()

    return fig


def get_color(index: int) -> str:
    """Get color from palette by index (wraps around).

    Args:
        index: Color index.

    Returns:
        Hex color string.
    """
    return COLOR_PALETTE[index % len(COLOR_PALETTE)]
