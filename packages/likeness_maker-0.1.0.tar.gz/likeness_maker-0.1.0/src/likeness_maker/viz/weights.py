"""Feature weight visualization."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from likeness_maker.viz.utils import DEFAULT_DPI, DEFAULT_FIGSIZE, save_or_show

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure, SubFigure

    from likeness_maker.core.model import LikenessModel


def plot_weights(
    model: LikenessModel,
    *,
    horizontal: bool = False,
    show_values: bool = True,
    title: str = "Feature Weights",
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Plot feature weights as a bar chart.

    Args:
        model: LikenessModel with weights.
        horizontal: Whether to use horizontal bars.
        show_values: Whether to show weight values on bars.
        title: Plot title.
        figsize: Figure size.
        ax: Existing axes to plot on.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.viz.utils import get_color

    feature_names = list(model.fitted_functions.keys())
    n_features = len(feature_names)

    weights = np.ones(n_features) / n_features if model.weights is None else model.weights

    if ax is None:
        if figsize is None:
            figsize = (10, max(4, n_features * 0.5)) if horizontal else DEFAULT_FIGSIZE
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    colors = [get_color(i) for i in range(n_features)]
    y_pos = np.arange(n_features)

    if horizontal:
        bars = ax.barh(y_pos, weights, color=colors, edgecolor="white")
        ax.set_yticks(y_pos)
        ax.set_yticklabels(feature_names)
        ax.set_xlabel("Weight")
        ax.set_xlim(0, max(weights) * 1.15)

        if show_values:
            for bar, weight in zip(bars, weights, strict=True):
                ax.text(
                    bar.get_width() + 0.01,
                    bar.get_y() + bar.get_height() / 2,
                    f"{weight:.3f}",
                    va="center",
                    fontsize=10,
                )
    else:
        bars = ax.bar(y_pos, weights, color=colors, edgecolor="white")
        ax.set_xticks(y_pos)
        ax.set_xticklabels(feature_names, rotation=45, ha="right")
        ax.set_ylabel("Weight")
        ax.set_ylim(0, max(weights) * 1.15)

        if show_values:
            for bar, weight in zip(bars, weights, strict=True):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.01,
                    f"{weight:.3f}",
                    ha="center",
                    fontsize=10,
                )

    ax.set_title(f"{title} ({model.weight_scheme})")
    ax.grid(True, alpha=0.3, axis="x" if horizontal else "y")

    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)


def plot_weight_comparison(
    models: dict[str, LikenessModel],
    *,
    figsize: tuple[float, float] | None = None,
    ax: Axes | None = None,
    savefig: str | Path | None = None,
    show: bool = True,
) -> Figure | SubFigure:
    """Compare weights across multiple models.

    Args:
        models: Mapping from model name to LikenessModel.
        figsize: Figure size.
        ax: Existing axes to plot on.
        savefig: Path to save figure.
        show: Whether to display the figure.

    Returns:
        Matplotlib Figure object.
    """
    import matplotlib.pyplot as plt

    from likeness_maker.viz.utils import get_color

    # Get all unique feature names
    all_features: set[str] = set()
    for model in models.values():
        all_features.update(model.fitted_functions.keys())
    feature_names = sorted(all_features)
    n_features = len(feature_names)
    n_models = len(models)

    if ax is None:
        if figsize is None:
            figsize = (max(10, n_features * 1.5), 6)
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    x = np.arange(n_features)
    width = 0.8 / n_models

    for idx, (model_name, model) in enumerate(models.items()):
        weights = []
        for feature in feature_names:
            if feature in model.fitted_functions:
                feat_idx = list(model.fitted_functions.keys()).index(feature)
                if model.weights is not None:
                    weights.append(model.weights[feat_idx])
                else:
                    weights.append(1.0 / len(model.fitted_functions))
            else:
                weights.append(0.0)

        offset = (idx - n_models / 2 + 0.5) * width
        ax.bar(
            x + offset,
            weights,
            width,
            label=model_name,
            color=get_color(idx),
            edgecolor="white",
        )

    ax.set_xlabel("Feature")
    ax.set_ylabel("Weight")
    ax.set_title("Weight Comparison")
    ax.set_xticks(x)
    ax.set_xticklabels(feature_names, rotation=45, ha="right")
    ax.legend()
    ax.grid(True, alpha=0.3, axis="y")

    plt.tight_layout()
    return save_or_show(fig, savefig, DEFAULT_DPI, show=show)
