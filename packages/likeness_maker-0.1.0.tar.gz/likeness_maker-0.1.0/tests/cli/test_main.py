"""Tests for CLI main module."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from likeness_maker.cli.main import app

runner = CliRunner()


class TestHelpCommands:
    """Tests for help commands."""

    def test_main_help(self):
        """Test main help output."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "likeness-maker" in result.output.lower() or "create" in result.output.lower()

    def test_train_help(self):
        """Test train command help."""
        result = runner.invoke(app, ["train", "--help"])

        assert result.exit_code == 0
        assert "train" in result.output.lower()

    def test_score_help(self):
        """Test score command help."""
        result = runner.invoke(app, ["score", "--help"])

        assert result.exit_code == 0
        assert "score" in result.output.lower()


class TestListCommands:
    """Tests for list commands."""

    def test_list_presets(self):
        """Test list-presets command."""
        result = runner.invoke(app, ["list-presets"])

        assert result.exit_code == 0
        assert "qed" in result.output.lower()
        assert "lipinski" in result.output.lower()

    def test_list_descriptors(self):
        """Test list-descriptors command."""
        result = runner.invoke(app, ["list-descriptors"])

        assert result.exit_code == 0
        assert "MW" in result.output
        assert "ALOGP" in result.output


class TestTrainCommand:
    """Tests for train command."""

    def test_train_file_not_found(self, tmp_path):
        """Test error when input file not found."""
        result = runner.invoke(
            app,
            ["train", "nonexistent.sdf", "-o", str(tmp_path / "model.json")],
        )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_train_preset_and_descriptors_error(self, tmp_path, sample_sdf_file):
        """Test error when both preset and descriptors specified."""
        result = runner.invoke(
            app,
            [
                "train",
                str(sample_sdf_file),
                "-o",
                str(tmp_path / "model.json"),
                "--preset",
                "qed-simple",
                "--descriptors",
                "MW,ALOGP",
            ],
        )

        assert result.exit_code == 1
        assert "cannot use both" in result.output.lower()

    def test_train_with_preset(self, tmp_path, sample_sdf_file):
        """Test training with a preset."""
        output_path = tmp_path / "model.json"

        result = runner.invoke(
            app,
            [
                "train",
                str(sample_sdf_file),
                "-o",
                str(output_path),
                "--preset",
                "lipinski",
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()
        assert "saved" in result.output.lower()

    def test_train_with_custom_descriptors(self, tmp_path, sample_sdf_file):
        """Test training with custom descriptors."""
        output_path = tmp_path / "model.json"

        result = runner.invoke(
            app,
            [
                "train",
                str(sample_sdf_file),
                "-o",
                str(output_path),
                "--descriptors",
                "MW,ALOGP",
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()


class TestScoreCommand:
    """Tests for score command."""

    def test_score_file_not_found(self, tmp_path):
        """Test error when input file not found."""
        result = runner.invoke(
            app,
            ["score", "nonexistent.sdf", "-m", str(tmp_path / "model.json")],
        )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_score_model_not_found(self, tmp_path, sample_sdf_file):
        """Test error when model file not found."""
        result = runner.invoke(
            app,
            ["score", str(sample_sdf_file), "-m", "nonexistent.json"],
        )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_score_with_output(self, tmp_path, sample_sdf_file):
        """Test scoring with output file."""
        model_path = tmp_path / "model.json"
        output_path = tmp_path / "scores.csv"

        # First train a model
        runner.invoke(
            app,
            [
                "train",
                str(sample_sdf_file),
                "-o",
                str(model_path),
                "--preset",
                "lipinski",
            ],
        )

        # Then score
        result = runner.invoke(
            app,
            [
                "score",
                str(sample_sdf_file),
                "-m",
                str(model_path),
                "-o",
                str(output_path),
            ],
        )

        assert result.exit_code == 0
        assert output_path.exists()
        assert "saved" in result.output.lower()

    def test_score_without_output(self, tmp_path, sample_sdf_file):
        """Test scoring without output file displays top 10."""
        model_path = tmp_path / "model.json"

        # Train a model first
        runner.invoke(
            app,
            [
                "train",
                str(sample_sdf_file),
                "-o",
                str(model_path),
                "--preset",
                "lipinski",
            ],
        )

        # Score without output
        result = runner.invoke(
            app,
            ["score", str(sample_sdf_file), "-m", str(model_path)],
        )

        assert result.exit_code == 0
        assert "top 10" in result.output.lower()


@pytest.fixture
def sample_sdf_file(tmp_path: Path) -> Path:
    """Create a sample SDF file for testing."""
    from rdkit import Chem

    filepath = tmp_path / "test.sdf"

    # Create enough molecules for fitting (need at least 10)
    smiles_list = [
        "CCO",
        "CC(=O)O",
        "c1ccccc1",
        "CCN",
        "CCCC",
        "CCCCC",
        "CCCCCC",
        "c1ccc(O)cc1",
        "c1ccc(N)cc1",
        "CC(C)C",
        "CCC(C)C",
        "CCCO",
    ]
    writer = Chem.SDWriter(str(filepath))

    for smi in smiles_list:
        mol = Chem.MolFromSmiles(smi)
        mol.SetProp("Name", smi)
        writer.write(mol)

    writer.close()
    return filepath
