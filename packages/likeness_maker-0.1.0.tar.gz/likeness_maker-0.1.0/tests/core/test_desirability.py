"""Tests for desirability functions."""

import numpy as np
import pytest

from likeness_maker.core.desirability import (
    AsymmetricDoubleSigmoid,
    DoubleLinearDesirability,
    ExponentialDesirability,
    GaussianDesirability,
    LinearDesirability,
    PowerDesirability,
    SigmoidDesirability,
    SmoothStepDesirability,
    StepDesirability,
    TrapezoidalDesirability,
    TriangularDesirability,
    get_desirability_class,
    list_desirabilities,
    register_desirability,
)


class TestLinearDesirability:
    """Tests for LinearDesirability function."""

    def test_basic(self):
        """Test basic linear mapping."""
        func = LinearDesirability(x_min=0.0, x_max=100.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.5, 1.0])

    def test_clipping(self):
        """Test that values are clipped to [0, 1]."""
        func = LinearDesirability(x_min=0.0, x_max=100.0)
        x = np.array([-50.0, 150.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 1.0])

    def test_inverted(self):
        """Test inverted linear mapping (high values are bad)."""
        func = LinearDesirability(x_min=0.0, x_max=100.0, invert=True)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [1.0, 0.5, 0.0])

    def test_equal_bounds(self):
        """Test behavior when x_min == x_max."""
        func = LinearDesirability(x_min=50.0, x_max=50.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [1.0, 1.0, 1.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = LinearDesirability(x_min=10.0, x_max=90.0, invert=True)
        params = func.get_parameters()
        assert params["x_min"] == 10.0
        assert params["x_max"] == 90.0
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = LinearDesirability(x_min=5.0, x_max=95.0, invert=False)
        restored = LinearDesirability.from_parameters(**original.get_parameters())
        x = np.array([5.0, 50.0, 95.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestGaussianDesirability:
    """Tests for GaussianDesirability function."""

    def test_sigma_zero_raises(self):
        """Test that sigma=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"sigma.*must be positive"):
            GaussianDesirability(center=50.0, sigma=0.0)

    def test_sigma_negative_raises(self):
        """Test that negative sigma raises ValueError."""
        with pytest.raises(ValueError, match=r"sigma.*must be positive"):
            GaussianDesirability(center=50.0, sigma=-5.0)

    def test_center_is_max(self):
        """Test that center value gives desirability 1.0."""
        func = GaussianDesirability(center=50.0, sigma=10.0)
        result = func(np.array([50.0]))
        np.testing.assert_almost_equal(result[0], 1.0)

    def test_symmetric(self):
        """Test that function is symmetric around center."""
        func = GaussianDesirability(center=50.0, sigma=10.0)
        x = np.array([40.0, 60.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], result[1])

    def test_falloff(self):
        """Test that desirability decreases away from center."""
        func = GaussianDesirability(center=50.0, sigma=10.0)
        x = np.array([50.0, 40.0, 30.0, 20.0])
        result = func(x)
        assert all(result[i] > result[i + 1] for i in range(len(result) - 1))

    def test_sigma_effect(self):
        """Test that larger sigma gives slower falloff."""
        narrow = GaussianDesirability(center=50.0, sigma=5.0)
        wide = GaussianDesirability(center=50.0, sigma=20.0)
        x = np.array([40.0])
        assert wide(x)[0] > narrow(x)[0]

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = GaussianDesirability(center=25.0, sigma=7.5)
        params = func.get_parameters()
        assert params["center"] == 25.0
        assert params["sigma"] == 7.5

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = GaussianDesirability(center=30.0, sigma=15.0)
        restored = GaussianDesirability.from_parameters(**original.get_parameters())
        x = np.array([10.0, 30.0, 50.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestAsymmetricDoubleSigmoid:
    """Tests for AsymmetricDoubleSigmoid function."""

    def test_e_zero_raises(self):
        """Test that e=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"'e'.*must be positive"):
            AsymmetricDoubleSigmoid(a=0.0, b=100.0, c=50.0, d=10.0, e=0.0, f=10.0, d_max=100.0)

    def test_f_zero_raises(self):
        """Test that f=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"'f'.*must be positive"):
            AsymmetricDoubleSigmoid(a=0.0, b=100.0, c=50.0, d=10.0, e=10.0, f=0.0, d_max=100.0)

    def test_d_max_zero_raises(self):
        """Test that d_max=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"'d_max'.*must be positive"):
            AsymmetricDoubleSigmoid(a=0.0, b=100.0, c=50.0, d=10.0, e=10.0, f=10.0, d_max=0.0)

    def test_negative_parameters_raise(self):
        """Test that negative e, f, d_max raise ValueError."""
        with pytest.raises(ValueError, match=r"'e'.*must be positive"):
            AsymmetricDoubleSigmoid(a=0.0, b=100.0, c=50.0, d=10.0, e=-5.0, f=10.0, d_max=100.0)

    def test_output_range(self):
        """Test that output is always in [0, 1]."""
        # Use parameters similar to QED MW function
        func = AsymmetricDoubleSigmoid(
            a=2.817,
            b=392.575,
            c=290.749,
            d=2.420,
            e=49.223,
            f=65.371,
            d_max=104.981,
        )
        x = np.linspace(0, 1000, 100)
        result = func(x)
        assert np.all(result >= 0.0)
        assert np.all(result <= 1.0)

    def test_has_maximum(self):
        """Test that function has a maximum near center."""
        func = AsymmetricDoubleSigmoid(a=0.0, b=100.0, c=50.0, d=10.0, e=10.0, f=10.0, d_max=100.0)
        x = np.linspace(0, 100, 1000)
        result = func(x)
        max_idx = np.argmax(result)
        # Maximum should be around index 500 (center of 1000 samples)
        # Allow range of 400-600 (corresponding to x=40-60)
        assert 400 < max_idx < 600

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = AsymmetricDoubleSigmoid(a=1.0, b=2.0, c=3.0, d=4.0, e=5.0, f=6.0, d_max=7.0)
        params = func.get_parameters()
        assert params == {
            "a": 1.0,
            "b": 2.0,
            "c": 3.0,
            "d": 4.0,
            "e": 5.0,
            "f": 6.0,
            "d_max": 7.0,
        }

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = AsymmetricDoubleSigmoid(
            a=0.5, b=50.0, c=100.0, d=20.0, e=15.0, f=25.0, d_max=50.0
        )
        restored = AsymmetricDoubleSigmoid.from_parameters(**original.get_parameters())
        x = np.array([50.0, 100.0, 150.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestRegistry:
    """Tests for desirability function registry."""

    def test_get_known_classes(self):
        """Test getting known function classes."""
        assert get_desirability_class("ads") is AsymmetricDoubleSigmoid
        assert get_desirability_class("linear") is LinearDesirability
        assert get_desirability_class("gaussian") is GaussianDesirability

    def test_get_unknown_class(self):
        """Test error for unknown function type."""
        with pytest.raises(ValueError, match="Unknown desirability function"):
            get_desirability_class("unknown_type")

    def test_register_custom(self):
        """Test registering a custom function type."""
        from dataclasses import dataclass

        from likeness_maker.core.desirability import BaseDesirabilityFunction

        @dataclass(frozen=True)
        class ConstantDesirability(BaseDesirabilityFunction):
            value: float

            def __call__(self, x):
                return np.full_like(x, self.value, dtype=np.float64)

            def get_parameters(self):
                return {"value": self.value}

            @classmethod
            def from_parameters(cls, **params):
                return cls(value=params["value"])

        register_desirability("constant", ConstantDesirability)
        assert get_desirability_class("constant") is ConstantDesirability

    def test_list_desirabilities(self):
        """Test listing all registered desirabilities."""
        desirabilities = list_desirabilities()
        assert "ads" in desirabilities
        assert "linear" in desirabilities
        assert "gaussian" in desirabilities
        assert "sigmoid" in desirabilities
        assert "step" in desirabilities
        assert "smoothstep" in desirabilities
        assert "triangular" in desirabilities
        assert "trapezoidal" in desirabilities
        assert "exponential" in desirabilities
        assert "double_linear" in desirabilities
        assert "power" in desirabilities


class TestSigmoidDesirability:
    """Tests for SigmoidDesirability function."""

    def test_steepness_zero_raises(self):
        """Test that steepness=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"steepness.*must be positive"):
            SigmoidDesirability(center=50.0, steepness=0.0)

    def test_steepness_negative_raises(self):
        """Test that negative steepness raises ValueError."""
        with pytest.raises(ValueError, match=r"steepness.*must be positive"):
            SigmoidDesirability(center=50.0, steepness=-1.0)

    def test_center_is_midpoint(self):
        """Test that center value gives desirability 0.5."""
        func = SigmoidDesirability(center=50.0, steepness=1.0)
        result = func(np.array([50.0]))
        np.testing.assert_almost_equal(result[0], 0.5)

    def test_s_curve(self):
        """Test S-curve shape: low → high."""
        func = SigmoidDesirability(center=50.0, steepness=0.5)
        x = np.array([0.0, 25.0, 50.0, 75.0, 100.0])
        result = func(x)
        # Should be monotonically increasing
        assert all(result[i] < result[i + 1] for i in range(len(result) - 1))
        assert result[0] < 0.1  # Low at start
        assert result[-1] > 0.9  # High at end

    def test_inverted(self):
        """Test inverted sigmoid (high → low)."""
        func = SigmoidDesirability(center=50.0, steepness=0.5, invert=True)
        x = np.array([0.0, 100.0])
        result = func(x)
        assert result[0] > result[1]  # Inverted

    def test_steepness_effect(self):
        """Test that higher steepness gives sharper transition."""
        shallow = SigmoidDesirability(center=50.0, steepness=0.1)
        steep = SigmoidDesirability(center=50.0, steepness=1.0)
        x = np.array([55.0])
        # Steep function should be closer to 1.0 at x=55
        assert steep(x)[0] > shallow(x)[0]

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = SigmoidDesirability(center=30.0, steepness=0.5, invert=True)
        params = func.get_parameters()
        assert params["center"] == 30.0
        assert params["steepness"] == 0.5
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = SigmoidDesirability(center=40.0, steepness=0.3, invert=False)
        restored = SigmoidDesirability.from_parameters(**original.get_parameters())
        x = np.array([20.0, 40.0, 60.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestStepDesirability:
    """Tests for StepDesirability function."""

    def test_basic(self):
        """Test basic step function."""
        func = StepDesirability(threshold=50.0)
        x = np.array([0.0, 49.9, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_equal(result, [0.0, 0.0, 1.0, 1.0])

    def test_inverted(self):
        """Test inverted step function."""
        func = StepDesirability(threshold=50.0, invert=True)
        x = np.array([0.0, 49.9, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_equal(result, [1.0, 1.0, 0.0, 0.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = StepDesirability(threshold=75.0, invert=True)
        params = func.get_parameters()
        assert params["threshold"] == 75.0
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = StepDesirability(threshold=25.0, invert=False)
        restored = StepDesirability.from_parameters(**original.get_parameters())
        x = np.array([0.0, 25.0, 50.0])
        np.testing.assert_array_equal(original(x), restored(x))


class TestSmoothStepDesirability:
    """Tests for SmoothStepDesirability function."""

    def test_basic(self):
        """Test basic smooth step function."""
        func = SmoothStepDesirability(edge0=0.0, edge1=100.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], 0.0)
        np.testing.assert_almost_equal(result[1], 0.5)
        np.testing.assert_almost_equal(result[2], 1.0)

    def test_clipping(self):
        """Test values outside edges are clipped."""
        func = SmoothStepDesirability(edge0=20.0, edge1=80.0)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], 0.0)
        np.testing.assert_almost_equal(result[1], 1.0)

    def test_smoothness(self):
        """Test smooth transition (S-curve shape)."""
        func = SmoothStepDesirability(edge0=0.0, edge1=100.0)
        x = np.linspace(0, 100, 100)
        result = func(x)
        # Check monotonically increasing
        assert all(result[i] <= result[i + 1] for i in range(len(result) - 1))

    def test_inverted(self):
        """Test inverted smooth step."""
        func = SmoothStepDesirability(edge0=0.0, edge1=100.0, invert=True)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], 1.0)
        np.testing.assert_almost_equal(result[1], 0.0)

    def test_equal_edges(self):
        """Test behavior when edge0 == edge1."""
        func = SmoothStepDesirability(edge0=50.0, edge1=50.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_almost_equal(result, [0.0, 1.0, 1.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = SmoothStepDesirability(edge0=10.0, edge1=90.0, invert=True)
        params = func.get_parameters()
        assert params["edge0"] == 10.0
        assert params["edge1"] == 90.0
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = SmoothStepDesirability(edge0=20.0, edge1=80.0)
        restored = SmoothStepDesirability.from_parameters(**original.get_parameters())
        x = np.array([0.0, 50.0, 100.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestTriangularDesirability:
    """Tests for TriangularDesirability function."""

    def test_width_zero_raises(self):
        """Test that width=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"width.*must be positive"):
            TriangularDesirability(center=50.0, width=0.0)

    def test_width_negative_raises(self):
        """Test that negative width raises ValueError."""
        with pytest.raises(ValueError, match=r"width.*must be positive"):
            TriangularDesirability(center=50.0, width=-10.0)

    def test_center_is_max(self):
        """Test that center value gives desirability 1.0."""
        func = TriangularDesirability(center=50.0, width=25.0)
        result = func(np.array([50.0]))
        np.testing.assert_almost_equal(result[0], 1.0)

    def test_edge_values(self):
        """Test that edge values give desirability 0.0."""
        func = TriangularDesirability(center=50.0, width=25.0)
        x = np.array([25.0, 75.0])  # Edges at center ± width
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.0])

    def test_symmetric(self):
        """Test that function is symmetric around center."""
        func = TriangularDesirability(center=50.0, width=30.0)
        x = np.array([40.0, 60.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], result[1])

    def test_clipping(self):
        """Test values beyond edges are clipped to 0."""
        func = TriangularDesirability(center=50.0, width=20.0)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = TriangularDesirability(center=30.0, width=15.0)
        params = func.get_parameters()
        assert params["center"] == 30.0
        assert params["width"] == 15.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = TriangularDesirability(center=60.0, width=20.0)
        restored = TriangularDesirability.from_parameters(**original.get_parameters())
        x = np.array([40.0, 60.0, 80.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestTrapezoidalDesirability:
    """Tests for TrapezoidalDesirability function."""

    def test_invalid_order_raises(self):
        """Test that invalid parameter order raises ValueError."""
        with pytest.raises(
            ValueError, match=r"low_edge <= low_plateau <= high_plateau <= high_edge"
        ):
            TrapezoidalDesirability(
                low_edge=50.0, low_plateau=20.0, high_plateau=80.0, high_edge=90.0
            )

    def test_basic(self):
        """Test basic trapezoidal function."""
        func = TrapezoidalDesirability(
            low_edge=20.0, low_plateau=40.0, high_plateau=60.0, high_edge=80.0
        )
        x = np.array([0.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 100.0])
        result = func(x)
        # Expected: [0, 0, 0.5, 1, 1, 1, 0.5, 0, 0]
        expected = [0.0, 0.0, 0.5, 1.0, 1.0, 1.0, 0.5, 0.0, 0.0]
        np.testing.assert_array_almost_equal(result, expected)

    def test_plateau_region(self):
        """Test that plateau region has desirability 1.0."""
        func = TrapezoidalDesirability(
            low_edge=10.0, low_plateau=30.0, high_plateau=70.0, high_edge=90.0
        )
        x = np.array([30.0, 50.0, 70.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [1.0, 1.0, 1.0])

    def test_ramp_regions(self):
        """Test linear ramps."""
        func = TrapezoidalDesirability(
            low_edge=0.0, low_plateau=20.0, high_plateau=80.0, high_edge=100.0
        )
        x = np.array([10.0, 90.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], 0.5)  # Midway up left ramp
        np.testing.assert_almost_equal(result[1], 0.5)  # Midway down right ramp

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = TrapezoidalDesirability(
            low_edge=10.0, low_plateau=30.0, high_plateau=60.0, high_edge=80.0
        )
        params = func.get_parameters()
        assert params["low_edge"] == 10.0
        assert params["low_plateau"] == 30.0
        assert params["high_plateau"] == 60.0
        assert params["high_edge"] == 80.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = TrapezoidalDesirability(
            low_edge=15.0, low_plateau=35.0, high_plateau=65.0, high_edge=85.0
        )
        restored = TrapezoidalDesirability.from_parameters(**original.get_parameters())
        x = np.array([0.0, 25.0, 50.0, 75.0, 100.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestExponentialDesirability:
    """Tests for ExponentialDesirability function."""

    def test_decay_rate_zero_raises(self):
        """Test that decay_rate=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"decay_rate.*must be positive"):
            ExponentialDesirability(reference=50.0, decay_rate=0.0)

    def test_decay_rate_negative_raises(self):
        """Test that negative decay_rate raises ValueError."""
        with pytest.raises(ValueError, match=r"decay_rate.*must be positive"):
            ExponentialDesirability(reference=50.0, decay_rate=-0.1)

    def test_reference_is_max(self):
        """Test that reference value gives desirability 1.0."""
        func = ExponentialDesirability(reference=50.0, decay_rate=0.1)
        result = func(np.array([50.0]))
        np.testing.assert_almost_equal(result[0], 1.0)

    def test_exponential_decay(self):
        """Test exponential decay away from reference."""
        func = ExponentialDesirability(reference=50.0, decay_rate=0.1)
        x = np.array([50.0, 60.0, 70.0])
        result = func(x)
        # Should decrease exponentially
        assert result[0] > result[1] > result[2]

    def test_symmetric(self):
        """Test symmetric decay both directions."""
        func = ExponentialDesirability(reference=50.0, decay_rate=0.1)
        x = np.array([40.0, 60.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], result[1])

    def test_inverted(self):
        """Test inverted exponential."""
        func = ExponentialDesirability(reference=50.0, decay_rate=0.1, invert=True)
        x = np.array([50.0, 100.0])
        result = func(x)
        np.testing.assert_almost_equal(result[0], 0.0)  # At reference
        assert result[1] > result[0]  # Increases away

    def test_decay_rate_effect(self):
        """Test that higher decay_rate gives faster falloff."""
        slow = ExponentialDesirability(reference=50.0, decay_rate=0.05)
        fast = ExponentialDesirability(reference=50.0, decay_rate=0.2)
        x = np.array([60.0])
        assert slow(x)[0] > fast(x)[0]

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = ExponentialDesirability(reference=30.0, decay_rate=0.15, invert=True)
        params = func.get_parameters()
        assert params["reference"] == 30.0
        assert params["decay_rate"] == 0.15
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = ExponentialDesirability(reference=40.0, decay_rate=0.08)
        restored = ExponentialDesirability.from_parameters(**original.get_parameters())
        x = np.array([20.0, 40.0, 60.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestDoubleLinearDesirability:
    """Tests for DoubleLinearDesirability function."""

    def test_left_width_zero_raises(self):
        """Test that left_width=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"left_width.*must be positive"):
            DoubleLinearDesirability(center=50.0, left_width=0.0, right_width=20.0)

    def test_right_width_zero_raises(self):
        """Test that right_width=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"right_width.*must be positive"):
            DoubleLinearDesirability(center=50.0, left_width=20.0, right_width=0.0)

    def test_center_is_max(self):
        """Test that center value gives desirability 1.0."""
        func = DoubleLinearDesirability(center=50.0, left_width=30.0, right_width=20.0)
        result = func(np.array([50.0]))
        np.testing.assert_almost_equal(result[0], 1.0)

    def test_asymmetric_slopes(self):
        """Test different slopes on each side."""
        func = DoubleLinearDesirability(center=50.0, left_width=20.0, right_width=40.0)
        # 10 units from center on left side (width 20) vs 20 units on right (width 40)
        x = np.array([40.0, 70.0])
        result = func(x)
        # Both should be 0.5 (halfway to edge)
        np.testing.assert_almost_equal(result[0], 0.5)
        np.testing.assert_almost_equal(result[1], 0.5)

    def test_edges_are_zero(self):
        """Test that edge values give desirability 0.0."""
        func = DoubleLinearDesirability(center=50.0, left_width=30.0, right_width=20.0)
        x = np.array([20.0, 70.0])  # At edges
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.0])

    def test_clipping(self):
        """Test values beyond edges are clipped to 0."""
        func = DoubleLinearDesirability(center=50.0, left_width=30.0, right_width=20.0)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = DoubleLinearDesirability(center=40.0, left_width=15.0, right_width=25.0)
        params = func.get_parameters()
        assert params["center"] == 40.0
        assert params["left_width"] == 15.0
        assert params["right_width"] == 25.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = DoubleLinearDesirability(center=60.0, left_width=20.0, right_width=30.0)
        restored = DoubleLinearDesirability.from_parameters(**original.get_parameters())
        x = np.array([40.0, 60.0, 90.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))


class TestPowerDesirability:
    """Tests for PowerDesirability function."""

    def test_power_zero_raises(self):
        """Test that power=0 raises ValueError."""
        with pytest.raises(ValueError, match=r"power.*must be positive"):
            PowerDesirability(x_min=0.0, x_max=100.0, power=0.0)

    def test_power_negative_raises(self):
        """Test that negative power raises ValueError."""
        with pytest.raises(ValueError, match=r"power.*must be positive"):
            PowerDesirability(x_min=0.0, x_max=100.0, power=-1.0)

    def test_linear_case(self):
        """Test power=1 gives linear behavior."""
        func = PowerDesirability(x_min=0.0, x_max=100.0, power=1.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.5, 1.0])

    def test_square_case(self):
        """Test power=2 gives quadratic behavior."""
        func = PowerDesirability(x_min=0.0, x_max=100.0, power=2.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.25, 1.0])

    def test_sqrt_case(self):
        """Test power=0.5 gives sqrt behavior."""
        func = PowerDesirability(x_min=0.0, x_max=100.0, power=0.5)
        x = np.array([0.0, 25.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 0.5, 1.0])

    def test_inverted(self):
        """Test inverted power function."""
        func = PowerDesirability(x_min=0.0, x_max=100.0, power=1.0, invert=True)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [1.0, 0.0])

    def test_clipping(self):
        """Test values are clipped to [0, 1]."""
        func = PowerDesirability(x_min=20.0, x_max=80.0, power=1.0)
        x = np.array([0.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [0.0, 1.0])

    def test_equal_bounds(self):
        """Test behavior when x_min == x_max."""
        func = PowerDesirability(x_min=50.0, x_max=50.0, power=2.0)
        x = np.array([0.0, 50.0, 100.0])
        result = func(x)
        np.testing.assert_array_almost_equal(result, [1.0, 1.0, 1.0])

    def test_get_parameters(self):
        """Test parameter extraction."""
        func = PowerDesirability(x_min=10.0, x_max=90.0, power=0.5, invert=True)
        params = func.get_parameters()
        assert params["x_min"] == 10.0
        assert params["x_max"] == 90.0
        assert params["power"] == 0.5
        assert params["invert"] == 1.0

    def test_from_parameters(self):
        """Test reconstruction from parameters."""
        original = PowerDesirability(x_min=0.0, x_max=100.0, power=1.5)
        restored = PowerDesirability.from_parameters(**original.get_parameters())
        x = np.array([0.0, 50.0, 100.0])
        np.testing.assert_array_almost_equal(original(x), restored(x))
