"""Tests for desirability function fitters."""

import numpy as np
import pytest

from likeness_maker.core.fitters import (
    ADSFitter,
    DoubleLinearFitter,
    ExponentialFitter,
    GaussianFitter,
    LinearFitter,
    PowerFitter,
    SigmoidFitter,
    SmoothStepFitter,
    StepFitter,
    TrapezoidalFitter,
    TriangularFitter,
    get_fitter,
    list_fitters,
)


class TestLinearFitter:
    """Tests for LinearFitter."""

    def test_fit_basic(self):
        """Test basic linear fitting."""
        fitter = LinearFitter()
        values = np.linspace(10, 90, 100)
        result = fitter.fit(values, percentile_low=5, percentile_high=95)

        assert result.r_squared == 1.0  # Linear fitter always returns 1.0
        assert "x_min" in result.parameters
        assert "x_max" in result.parameters
        # Check that x_min and x_max are close to the percentiles
        assert result.parameters["x_min"] < 20
        assert result.parameters["x_max"] > 80

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = LinearFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0
        # Test that the function gives low values for high inputs
        high_value = result.function(np.array([95.0]))
        low_value = result.function(np.array([5.0]))
        assert low_value[0] > high_value[0]


class TestGaussianFitter:
    """Tests for GaussianFitter."""

    def test_fit_basic(self):
        """Test basic Gaussian fitting."""
        fitter = GaussianFitter()
        # Generate normally distributed data
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 1000)
        result = fitter.fit(values)

        # Center should be close to 50
        assert abs(result.parameters["center"] - 50) < 2
        # Sigma should be close to 10
        assert abs(result.parameters["sigma"] - 10) < 2

    def test_fit_with_median(self):
        """Test fitting using median instead of mean."""
        fitter = GaussianFitter()
        # Skewed data where median != mean
        values = np.array([1, 2, 3, 4, 5, 100])  # Outlier skews mean
        result_mean = fitter.fit(values, use_median=False)
        result_median = fitter.fit(values, use_median=True)

        assert result_median.parameters["center"] < result_mean.parameters["center"]


class TestADSFitter:
    """Tests for ADSFitter."""

    def test_fit_normal_distribution(self):
        """Test fitting ADS to normally distributed data."""
        fitter = ADSFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(300, 50, 1000)
        result = fitter.fit(values)

        # Check that center is close to mean
        assert abs(result.parameters["c"] - 300) < 30
        # Check that R-squared is reasonable
        assert result.r_squared > 0.5

    def test_fit_requires_minimum_samples(self):
        """Test that fitting requires minimum number of samples."""
        fitter = ADSFitter()
        values = np.array([1, 2, 3])  # Only 3 values

        with pytest.raises(ValueError, match="Need at least 10 values"):
            fitter.fit(values)

    def test_fit_handles_nan(self):
        """Test that NaN values are removed before fitting."""
        fitter = ADSFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(100, 20, 100)
        # Add some NaN values
        values_with_nan = np.append(values, [np.nan, np.nan, np.nan])

        result = fitter.fit(values_with_nan)
        assert result.r_squared > 0.3

    def test_fitted_function_output_range(self):
        """Test that fitted function outputs are in [0, 1]."""
        fitter = ADSFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(500, 100, 500)
        result = fitter.fit(values)

        # Test over wide range
        test_values = np.linspace(0, 1000, 100)
        outputs = result.function(test_values)

        assert np.all(outputs >= 0.0)
        assert np.all(outputs <= 1.0)


class TestFitterRegistry:
    """Tests for fitter registry."""

    def test_get_known_fitters(self):
        """Test getting known fitters."""
        assert get_fitter("ads") is not None
        assert get_fitter("linear") is not None
        assert get_fitter("gaussian") is not None

    def test_get_unknown_fitter(self):
        """Test error for unknown fitter."""
        with pytest.raises(ValueError, match="Unknown fitter"):
            get_fitter("unknown_fitter")

    def test_list_fitters(self):
        """Test listing all registered fitters."""
        fitters = list_fitters()
        assert "ads" in fitters
        assert "linear" in fitters
        assert "gaussian" in fitters
        assert "sigmoid" in fitters
        assert "step" in fitters
        assert "smoothstep" in fitters
        assert "triangular" in fitters
        assert "trapezoidal" in fitters
        assert "exponential" in fitters
        assert "double_linear" in fitters
        assert "power" in fitters


class TestSigmoidFitter:
    """Tests for SigmoidFitter."""

    def test_fit_basic(self):
        """Test basic sigmoid fitting."""
        fitter = SigmoidFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 15, 500)
        result = fitter.fit(values)

        # Center should be close to median
        assert abs(result.parameters["center"] - 50) < 5
        # Steepness should be positive
        assert result.parameters["steepness"] > 0

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = SigmoidFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0
        # Test that the function gives high values for low inputs
        high_value = result.function(np.array([10.0]))
        low_value = result.function(np.array([90.0]))
        assert high_value[0] > low_value[0]

    def test_fitted_function_output_range(self):
        """Test that fitted function outputs are in [0, 1]."""
        fitter = SigmoidFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(100, 30, 500)
        result = fitter.fit(values)

        test_values = np.linspace(0, 200, 100)
        outputs = result.function(test_values)

        assert np.all(outputs >= 0.0)
        assert np.all(outputs <= 1.0)


class TestStepFitter:
    """Tests for StepFitter."""

    def test_fit_basic(self):
        """Test basic step fitting."""
        fitter = StepFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, percentile=50)

        # Threshold should be near 50
        assert abs(result.parameters["threshold"] - 50) < 5

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = StepFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0
        # High value should be desirable (inverted)
        high_value = result.function(np.array([10.0]))
        low_value = result.function(np.array([90.0]))
        assert high_value[0] > low_value[0]

    def test_different_percentiles(self):
        """Test fitting with different percentiles."""
        fitter = StepFitter()
        values = np.linspace(0, 100, 100)

        result_25 = fitter.fit(values, percentile=25)
        result_75 = fitter.fit(values, percentile=75)

        assert result_25.parameters["threshold"] < result_75.parameters["threshold"]


class TestSmoothStepFitter:
    """Tests for SmoothStepFitter."""

    def test_fit_basic(self):
        """Test basic smooth step fitting."""
        fitter = SmoothStepFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 15, 500)
        result = fitter.fit(values)

        # Edges should be from percentiles
        assert result.parameters["edge0"] < result.parameters["edge1"]

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = SmoothStepFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0

    def test_fitted_function_smoothness(self):
        """Test that fitted function is smooth."""
        fitter = SmoothStepFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values)

        test_values = np.linspace(0, 100, 100)
        outputs = result.function(test_values)

        # Check monotonically increasing
        assert all(outputs[i] <= outputs[i + 1] for i in range(len(outputs) - 1))


class TestTriangularFitter:
    """Tests for TriangularFitter."""

    def test_fit_basic(self):
        """Test basic triangular fitting."""
        fitter = TriangularFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)
        result = fitter.fit(values)

        # Center should be close to median
        assert abs(result.parameters["center"] - 50) < 5
        # Width should be positive
        assert result.parameters["width"] > 0

    def test_width_multiplier(self):
        """Test different width multipliers."""
        fitter = TriangularFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)

        result_narrow = fitter.fit(values, width_multiplier=1.0)
        result_wide = fitter.fit(values, width_multiplier=3.0)

        assert result_wide.parameters["width"] > result_narrow.parameters["width"]

    def test_fitted_function_output_range(self):
        """Test that fitted function outputs are in [0, 1]."""
        fitter = TriangularFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(100, 20, 500)
        result = fitter.fit(values)

        test_values = np.linspace(0, 200, 100)
        outputs = result.function(test_values)

        assert np.all(outputs >= 0.0)
        assert np.all(outputs <= 1.0)


class TestTrapezoidalFitter:
    """Tests for TrapezoidalFitter."""

    def test_fit_basic(self):
        """Test basic trapezoidal fitting."""
        fitter = TrapezoidalFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 15, 500)
        result = fitter.fit(values)

        # Check parameter ordering
        assert result.parameters["low_edge"] <= result.parameters["low_plateau"]
        assert result.parameters["low_plateau"] <= result.parameters["high_plateau"]
        assert result.parameters["high_plateau"] <= result.parameters["high_edge"]

    def test_different_percentiles(self):
        """Test fitting with different percentile settings."""
        fitter = TrapezoidalFitter()
        values = np.linspace(0, 100, 100)

        result = fitter.fit(
            values, p_low_edge=10, p_low_plateau=30, p_high_plateau=70, p_high_edge=90
        )

        # Check that percentiles are reflected in parameters
        assert result.parameters["low_edge"] < result.parameters["low_plateau"]
        assert result.parameters["high_plateau"] < result.parameters["high_edge"]

    def test_fitted_function_plateau(self):
        """Test that plateau region has desirability 1.0."""
        fitter = TrapezoidalFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)
        result = fitter.fit(values)

        # Test points in the plateau region
        plateau_mid = (result.parameters["low_plateau"] + result.parameters["high_plateau"]) / 2
        outputs = result.function(np.array([plateau_mid]))
        np.testing.assert_almost_equal(outputs[0], 1.0)


class TestExponentialFitter:
    """Tests for ExponentialFitter."""

    def test_fit_basic(self):
        """Test basic exponential fitting."""
        fitter = ExponentialFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)
        result = fitter.fit(values)

        # Reference should be close to median
        assert abs(result.parameters["reference"] - 50) < 5
        # Decay rate should be positive
        assert result.parameters["decay_rate"] > 0

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = ExponentialFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0

    def test_decay_multiplier(self):
        """Test different decay multipliers."""
        fitter = ExponentialFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)

        result_slow = fitter.fit(values, decay_multiplier=0.5)
        result_fast = fitter.fit(values, decay_multiplier=2.0)

        assert result_fast.parameters["decay_rate"] > result_slow.parameters["decay_rate"]

    def test_fitted_function_reference_is_max(self):
        """Test that reference point gives desirability 1.0."""
        fitter = ExponentialFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)
        result = fitter.fit(values)

        ref_output = result.function(np.array([result.parameters["reference"]]))
        np.testing.assert_almost_equal(ref_output[0], 1.0)


class TestDoubleLinearFitter:
    """Tests for DoubleLinearFitter."""

    def test_fit_basic(self):
        """Test basic double linear fitting."""
        fitter = DoubleLinearFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 15, 500)
        result = fitter.fit(values)

        # Center should be close to median
        assert abs(result.parameters["center"] - 50) < 5
        # Widths should be positive
        assert result.parameters["left_width"] > 0
        assert result.parameters["right_width"] > 0

    def test_asymmetric_distribution(self):
        """Test fitting with asymmetric distribution."""
        fitter = DoubleLinearFitter()
        # Create skewed distribution
        rng = np.random.default_rng(42)
        values = np.concatenate([rng.uniform(0, 50, 300), rng.uniform(50, 100, 100)])
        result = fitter.fit(values)

        # Left width should differ from right width
        assert result.parameters["left_width"] != result.parameters["right_width"]

    def test_fitted_function_center_is_max(self):
        """Test that center gives desirability 1.0."""
        fitter = DoubleLinearFitter()
        rng = np.random.default_rng(42)
        values = rng.normal(50, 10, 500)
        result = fitter.fit(values)

        center_output = result.function(np.array([result.parameters["center"]]))
        np.testing.assert_almost_equal(center_output[0], 1.0)


class TestPowerFitter:
    """Tests for PowerFitter."""

    def test_fit_basic(self):
        """Test basic power fitting."""
        fitter = PowerFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values)

        # Check parameters
        assert "x_min" in result.parameters
        assert "x_max" in result.parameters
        assert result.parameters["power"] == 1.0  # Default

    def test_fit_with_power(self):
        """Test fitting with specified power."""
        fitter = PowerFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, power=2.0)

        assert result.parameters["power"] == 2.0

    def test_fit_inverted(self):
        """Test fitting with invert=True."""
        fitter = PowerFitter()
        values = np.linspace(0, 100, 100)
        result = fitter.fit(values, invert=True)

        assert result.parameters["invert"] == 1.0

    def test_fitted_function_shape(self):
        """Test that power affects curve shape."""
        fitter = PowerFitter()
        values = np.linspace(0, 100, 100)

        result_linear = fitter.fit(values, power=1.0)
        result_square = fitter.fit(values, power=2.0)

        test_x = np.array([50.0])
        linear_output = result_linear.function(test_x)
        square_output = result_square.function(test_x)

        # Linear: 50% gives 0.5, Square: 50% gives 0.25
        assert linear_output[0] > square_output[0]
