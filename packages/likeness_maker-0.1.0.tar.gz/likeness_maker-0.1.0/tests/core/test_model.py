"""Tests for LikenessModel class."""

import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from likeness_maker.core.model import LikenessModel
from likeness_maker.core.types import FeatureDefinition, FeatureSet


@pytest.fixture
def simple_feature_set():
    """Create a simple feature set for testing."""
    return FeatureSet(
        features=(
            FeatureDefinition(name="feature_a"),
            FeatureDefinition(name="feature_b"),
        )
    )


@pytest.fixture
def reference_data():
    """Generate synthetic reference data."""
    rng = np.random.default_rng(42)
    return np.column_stack(
        [
            rng.normal(100, 20, 200),  # feature_a: centered at 100
            rng.normal(50, 10, 200),  # feature_b: centered at 50
        ]
    )


class TestLikenessModelFitting:
    """Tests for model fitting."""

    def test_fit_returns_new_model(self, simple_feature_set, reference_data):
        """Test that fit returns a new model instance."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="ads")

        assert fitted is not model
        assert len(fitted.fitted_functions) == 2

    def test_fit_with_dataframe(self, simple_feature_set):
        """Test fitting with pandas DataFrame."""
        rng = np.random.default_rng(42)
        df = pd.DataFrame(
            {
                "feature_a": rng.normal(100, 20, 200),
                "feature_b": rng.normal(50, 10, 200),
            }
        )

        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(df, function_type="linear")

        assert len(fitted.fitted_functions) == 2
        assert "feature_a" in fitted.fitted_functions
        assert "feature_b" in fitted.fitted_functions

    def test_fit_with_different_function_types(self, simple_feature_set, reference_data):
        """Test fitting with different function types."""
        from typing import Literal

        model = LikenessModel(feature_set=simple_feature_set)

        func_types: list[Literal["ads", "linear", "gaussian"]] = ["ads", "linear", "gaussian"]
        for func_type in func_types:
            fitted = model.fit(reference_data, function_type=func_type)
            assert fitted.fitted_functions["feature_a"].function_type == func_type

    def test_fit_with_custom_weights(self, simple_feature_set, reference_data):
        """Test fitting with custom weights."""
        model = LikenessModel(feature_set=simple_feature_set)
        weights = np.array([0.8, 0.2])
        fitted = model.fit(reference_data, weights=weights)

        np.testing.assert_array_equal(fitted.weights, weights)
        assert fitted.weight_scheme == "custom"

    def test_fit_dimension_mismatch(self, simple_feature_set):
        """Test error when feature count doesn't match."""
        model = LikenessModel(feature_set=simple_feature_set)
        # 3 features instead of 2
        wrong_data = np.random.rand(100, 3)

        with pytest.raises(ValueError, match="Expected 2 features"):
            model.fit(wrong_data)


class TestLikenessModelScoring:
    """Tests for model scoring."""

    def test_score_not_fitted(self, simple_feature_set):
        """Test error when scoring before fitting."""
        model = LikenessModel(feature_set=simple_feature_set)
        test_data = np.array([[100, 50]])

        with pytest.raises(ValueError, match="Model is not fitted"):
            model.score(test_data)

    def test_score_single_sample(self, simple_feature_set, reference_data):
        """Test scoring a single sample."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="gaussian")

        # Sample at the center of both distributions
        test_data = np.array([[100.0, 50.0]])
        scores = fitted.score(test_data)

        assert len(scores) == 1
        assert 0.5 < scores[0] <= 1.0  # Should be high score

    def test_score_multiple_samples(self, simple_feature_set, reference_data):
        """Test scoring multiple samples."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="gaussian")

        test_data = np.array(
            [
                [100.0, 50.0],  # Good sample
                [200.0, 100.0],  # Poor sample (far from centers)
            ]
        )
        scores = fitted.score(test_data)

        assert len(scores) == 2
        assert scores[0] > scores[1]

    def test_score_with_dataframe(self, simple_feature_set, reference_data):
        """Test scoring with pandas DataFrame."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="linear")

        test_df = pd.DataFrame(
            {
                "feature_a": [100.0, 150.0],
                "feature_b": [50.0, 75.0],
            }
        )
        scores = fitted.score(test_df)

        assert len(scores) == 2

    def test_score_dimension_mismatch(self, simple_feature_set, reference_data):
        """Test error when test data has wrong dimensions."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data)

        wrong_data = np.array([[1.0, 2.0, 3.0]])  # 3 features instead of 2
        with pytest.raises(ValueError, match="Expected 2 features"):
            fitted.score(wrong_data)


class TestLikenessModelDetailedScoring:
    """Tests for detailed scoring."""

    def test_score_detailed_not_fitted(self, simple_feature_set):
        """Test error when calling score_detailed before fitting."""
        model = LikenessModel(feature_set=simple_feature_set)
        test_data = np.array([[100, 50]])

        with pytest.raises(ValueError, match="Model is not fitted"):
            model.score_detailed(test_data)

    def test_score_detailed(self, simple_feature_set, reference_data):
        """Test detailed scoring returns DataFrame with all columns."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="gaussian")

        test_data = np.array([[100.0, 50.0], [150.0, 75.0]])
        result = fitted.score_detailed(test_data)

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert "d_feature_a" in result.columns
        assert "d_feature_b" in result.columns
        assert "likeness_score" in result.columns

    def test_detailed_desirabilities_in_range(self, simple_feature_set, reference_data):
        """Test that detailed desirabilities are in [0, 1]."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data)

        test_data = np.random.rand(10, 2) * 200  # Random test data
        result = fitted.score_detailed(test_data)

        for col in ["d_feature_a", "d_feature_b", "likeness_score"]:
            assert result[col].min() >= 0.0
            assert result[col].max() <= 1.0


class TestLikenessModelSerialization:
    """Tests for model serialization."""

    def test_to_json(self, simple_feature_set, reference_data):
        """Test saving model to JSON."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "model.json"
            fitted.to_json(path)

            assert path.exists()
            # File should be readable JSON
            import json

            with open(path) as f:
                data = json.load(f)
            assert "feature_set" in data
            assert "fitted_functions" in data

    def test_from_json(self, simple_feature_set, reference_data):
        """Test loading model from JSON."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "model.json"
            fitted.to_json(path)

            loaded = LikenessModel.from_json(path)

            assert len(loaded.feature_set) == len(fitted.feature_set)
            assert loaded.feature_set.names == fitted.feature_set.names
            assert len(loaded.fitted_functions) == len(fitted.fitted_functions)

    def test_serialization_roundtrip(self, simple_feature_set, reference_data):
        """Test that serialization preserves scoring behavior."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="linear")

        test_data = np.array([[100.0, 50.0], [150.0, 75.0]])
        original_scores = fitted.score(test_data)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "model.json"
            fitted.to_json(path)
            loaded = LikenessModel.from_json(path)

        loaded_scores = loaded.score(test_data)
        np.testing.assert_array_almost_equal(original_scores, loaded_scores)

    def test_serialization_with_custom_weights(self, simple_feature_set, reference_data):
        """Test serialization preserves custom weights."""
        model = LikenessModel(feature_set=simple_feature_set)
        weights = np.array([0.7, 0.3])
        fitted = model.fit(reference_data, weights=weights)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "model.json"
            fitted.to_json(path)
            loaded = LikenessModel.from_json(path)

        assert loaded.weights is not None
        np.testing.assert_array_almost_equal(loaded.weights, weights)
        assert loaded.weight_scheme == "custom"


class TestLikenessModelPerFeatureFitting:
    """Tests for per-feature function type fitting."""

    def test_fit_with_dict_function_type(self, simple_feature_set, reference_data):
        """Test fitting with dict function_type (feature -> type mapping)."""
        model = LikenessModel(feature_set=simple_feature_set)
        function_types = {
            "feature_a": "gaussian",
            "feature_b": "linear",
        }
        fitted = model.fit(reference_data, function_type=function_types)

        assert fitted.fitted_functions["feature_a"].function_type == "gaussian"
        assert fitted.fitted_functions["feature_b"].function_type == "linear"

    def test_fit_with_list_function_type(self, simple_feature_set, reference_data):
        """Test fitting with list function_type (in feature order)."""
        model = LikenessModel(feature_set=simple_feature_set)
        function_types = ["sigmoid", "triangular"]
        fitted = model.fit(reference_data, function_type=function_types)

        assert fitted.fitted_functions["feature_a"].function_type == "sigmoid"
        assert fitted.fitted_functions["feature_b"].function_type == "triangular"

    def test_fit_with_list_wrong_length_raises(self, simple_feature_set, reference_data):
        """Test that list function_type with wrong length raises error."""
        model = LikenessModel(feature_set=simple_feature_set)
        function_types = ["gaussian", "linear", "step"]  # 3 instead of 2

        with pytest.raises(ValueError, match="function_type list length"):
            model.fit(reference_data, function_type=function_types)

    def test_fit_with_dict_missing_feature_raises(self, simple_feature_set, reference_data):
        """Test that dict function_type with missing feature raises error."""
        model = LikenessModel(feature_set=simple_feature_set)
        function_types = {
            "feature_a": "gaussian",
            # Missing feature_b
        }

        with pytest.raises(ValueError, match="function_type dict missing feature"):
            model.fit(reference_data, function_type=function_types)

    def test_fit_with_fitter_kwargs(self, simple_feature_set, reference_data):
        """Test fitting with per-feature fitter kwargs."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitter_kwargs = {
            "feature_a": {"use_median": True},
        }
        fitted = model.fit(
            reference_data,
            function_type="gaussian",
            fitter_kwargs=fitter_kwargs,
        )

        # Should complete without error
        assert len(fitted.fitted_functions) == 2


class TestLikenessModelSetFunction:
    """Tests for manual function specification."""

    def test_set_function_basic(self, simple_feature_set):
        """Test setting a single function manually."""
        model = LikenessModel(feature_set=simple_feature_set)
        updated = model.set_function(
            "feature_a",
            "gaussian",
            {"center": 100.0, "sigma": 20.0},
        )

        assert updated is not model  # Immutability
        assert "feature_a" in updated.fitted_functions
        assert updated.fitted_functions["feature_a"].function_type == "gaussian"
        assert updated.fitted_functions["feature_a"].parameters["center"] == 100.0
        assert updated.fitted_functions["feature_a"].parameters["sigma"] == 20.0

    def test_set_function_unknown_feature_raises(self, simple_feature_set):
        """Test that setting unknown feature raises error."""
        model = LikenessModel(feature_set=simple_feature_set)

        with pytest.raises(ValueError, match="Unknown feature"):
            model.set_function(
                "unknown_feature",
                "gaussian",
                {"center": 100.0, "sigma": 20.0},
            )

    def test_set_function_invalid_params_raises(self, simple_feature_set):
        """Test that invalid parameters raise error."""
        model = LikenessModel(feature_set=simple_feature_set)

        with pytest.raises((ValueError, TypeError)):
            model.set_function(
                "feature_a",
                "gaussian",
                {"center": 100.0, "sigma": -5.0},  # Invalid: sigma must be positive
            )

    def test_set_function_preserves_other_functions(self, simple_feature_set, reference_data):
        """Test that set_function preserves other fitted functions."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="linear")

        # Set only feature_a
        updated = fitted.set_function(
            "feature_a",
            "gaussian",
            {"center": 100.0, "sigma": 20.0},
        )

        # feature_b should still be linear
        assert updated.fitted_functions["feature_b"].function_type == "linear"
        # feature_a should be updated
        assert updated.fitted_functions["feature_a"].function_type == "gaussian"

    def test_set_function_preserves_weights(self, simple_feature_set, reference_data):
        """Test that set_function preserves weights."""
        model = LikenessModel(feature_set=simple_feature_set)
        weights = np.array([0.7, 0.3])
        fitted = model.fit(reference_data, weights=weights)

        updated = fitted.set_function(
            "feature_a",
            "gaussian",
            {"center": 100.0, "sigma": 20.0},
        )

        assert updated.weights is not None
        np.testing.assert_array_almost_equal(updated.weights, weights)

    def test_set_function_scoring_works(self, simple_feature_set, reference_data):
        """Test that model with set_function can score."""
        model = LikenessModel(feature_set=simple_feature_set)

        # Set both features manually
        model = model.set_function(
            "feature_a",
            "gaussian",
            {"center": 100.0, "sigma": 30.0},
        )
        model = model.set_function(
            "feature_b",
            "linear",
            {"x_min": 20.0, "x_max": 80.0, "invert": 0.0},
        )

        # Should be able to score
        test_data = np.array([[100.0, 50.0], [150.0, 30.0]])
        scores = model.score(test_data)

        assert len(scores) == 2
        assert all(0.0 <= s <= 1.0 for s in scores)


class TestLikenessModelSetFunctions:
    """Tests for bulk manual function specification."""

    def test_set_functions_basic(self, simple_feature_set):
        """Test setting multiple functions at once."""
        model = LikenessModel(feature_set=simple_feature_set)
        updated = model.set_functions(
            {
                "feature_a": ("gaussian", {"center": 100.0, "sigma": 20.0}),
                "feature_b": ("sigmoid", {"center": 50.0, "steepness": 0.5, "invert": 0.0}),
            }
        )

        assert updated.fitted_functions["feature_a"].function_type == "gaussian"
        assert updated.fitted_functions["feature_b"].function_type == "sigmoid"

    def test_set_functions_partial(self, simple_feature_set, reference_data):
        """Test setting only some functions."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type="linear")

        # Only update feature_a
        updated = fitted.set_functions(
            {
                "feature_a": ("gaussian", {"center": 100.0, "sigma": 20.0}),
            }
        )

        assert updated.fitted_functions["feature_a"].function_type == "gaussian"
        assert updated.fitted_functions["feature_b"].function_type == "linear"

    def test_set_functions_scoring_works(self, simple_feature_set):
        """Test that model with set_functions can score."""
        model = LikenessModel(feature_set=simple_feature_set)
        model = model.set_functions(
            {
                "feature_a": ("triangular", {"center": 100.0, "width": 50.0}),
                "feature_b": ("step", {"threshold": 50.0, "invert": 0.0}),
            }
        )

        test_data = np.array([[100.0, 60.0]])
        scores = model.score(test_data)

        assert len(scores) == 1
        assert 0.0 <= scores[0] <= 1.0


class TestLikenessModelAllDesirabilityTypes:
    """Tests for all desirability function types in fitting."""

    @pytest.fixture
    def three_feature_set(self):
        """Create a feature set with three features."""
        return FeatureSet(
            features=(
                FeatureDefinition(name="feat_1"),
                FeatureDefinition(name="feat_2"),
                FeatureDefinition(name="feat_3"),
            )
        )

    @pytest.fixture
    def three_feature_data(self):
        """Generate synthetic data for three features."""
        rng = np.random.default_rng(42)
        return np.column_stack(
            [
                rng.normal(100, 20, 200),
                rng.normal(50, 10, 200),
                rng.normal(75, 15, 200),
            ]
        )

    @pytest.mark.parametrize(
        "func_type",
        [
            "ads",
            "linear",
            "gaussian",
            "sigmoid",
            "step",
            "smoothstep",
            "triangular",
            "trapezoidal",
            "exponential",
            "double_linear",
            "power",
        ],
    )
    def test_fit_with_all_function_types(self, simple_feature_set, reference_data, func_type):
        """Test that all function types can be fitted."""
        model = LikenessModel(feature_set=simple_feature_set)
        fitted = model.fit(reference_data, function_type=func_type)

        # Should have fitted functions
        assert len(fitted.fitted_functions) == 2
        assert all(ff.function_type == func_type for ff in fitted.fitted_functions.values())

        # Should be able to score
        test_data = np.array([[100.0, 50.0]])
        scores = fitted.score(test_data)
        assert len(scores) == 1
        assert 0.0 <= scores[0] <= 1.0

    def test_fit_with_mixed_function_types(self, three_feature_set, three_feature_data):
        """Test fitting with different function types per feature."""
        model = LikenessModel(feature_set=three_feature_set)
        function_types = {
            "feat_1": "gaussian",
            "feat_2": "sigmoid",
            "feat_3": "trapezoidal",
        }
        fitted = model.fit(three_feature_data, function_type=function_types)

        assert fitted.fitted_functions["feat_1"].function_type == "gaussian"
        assert fitted.fitted_functions["feat_2"].function_type == "sigmoid"
        assert fitted.fitted_functions["feat_3"].function_type == "trapezoidal"

        # Should score correctly
        test_data = np.array([[100.0, 50.0, 75.0]])
        scores = fitted.score(test_data)
        assert 0.0 <= scores[0] <= 1.0
