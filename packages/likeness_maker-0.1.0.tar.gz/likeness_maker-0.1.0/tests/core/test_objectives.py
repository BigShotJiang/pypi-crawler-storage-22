"""Tests for objective functions."""

import numpy as np
import pytest

from likeness_maker.core.objectives import (
    OBJECTIVE_REGISTRY,
    bedroc_objective,
    enrichment_objective,
    entropy_objective,
    get_objective,
    list_objectives,
    roc_auc_objective,
)


class TestEntropyObjective:
    """Tests for entropy_objective function."""

    def test_uniform_distribution_max_entropy(self) -> None:
        """Uniform distribution should have high entropy."""
        # Uniform distribution across [0, 1]
        scores = np.linspace(0, 1, 100)
        entropy = entropy_objective(scores)

        # Should have reasonable entropy (close to log2(10) for 10 bins)
        assert entropy > 2.0

    def test_concentrated_distribution_low_entropy(self) -> None:
        """Concentrated distribution should have low entropy."""
        # All values in one bin
        scores = np.ones(100) * 0.5
        entropy = entropy_objective(scores)

        # Should have zero entropy (all in one bin)
        assert entropy == 0.0

    def test_empty_scores_returns_zero(self) -> None:
        """Empty scores should return 0."""
        scores = np.array([])
        assert entropy_objective(scores) == 0.0

    def test_nan_values_ignored(self) -> None:
        """NaN values should be ignored."""
        scores = np.array([0.1, 0.2, np.nan, 0.3, 0.4])
        # Should work without error
        entropy = entropy_objective(scores)
        assert entropy >= 0.0

    def test_labels_ignored(self) -> None:
        """Labels parameter should be ignored."""
        scores = np.linspace(0, 1, 100)
        labels = np.zeros(100)

        e1 = entropy_objective(scores, labels=None)
        e2 = entropy_objective(scores, labels=labels)

        assert e1 == e2


class TestRocAucObjective:
    """Tests for roc_auc_objective function."""

    def test_perfect_separation(self) -> None:
        """Perfect separation should give AUC = 1.0."""
        scores = np.array([0.1, 0.2, 0.3, 0.8, 0.9, 1.0])
        labels = np.array([0.0, 0.0, 0.0, 1.0, 1.0, 1.0])

        auc = roc_auc_objective(scores, labels)
        assert auc == 1.0

    def test_random_separation(self) -> None:
        """Random separation should give AUC around 0.5."""
        np.random.seed(42)
        scores = np.random.rand(100)
        labels = np.random.randint(0, 2, 100).astype(float)

        auc = roc_auc_objective(scores, labels)
        assert 0.3 < auc < 0.7

    def test_requires_labels(self) -> None:
        """Should raise ValueError if labels is None."""
        scores = np.array([0.1, 0.2, 0.3])
        with pytest.raises(ValueError, match="requires labels"):
            roc_auc_objective(scores, labels=None)

    def test_requires_both_classes(self) -> None:
        """Should raise ValueError if only one class present."""
        scores = np.array([0.1, 0.2, 0.3])
        labels = np.ones(3)

        with pytest.raises(ValueError, match="both positive and negative"):
            roc_auc_objective(scores, labels)


class TestEnrichmentObjective:
    """Tests for enrichment_objective function."""

    def test_perfect_enrichment(self) -> None:
        """Perfect ranking should give high enrichment."""
        scores = np.array([0.9, 0.8, 0.1, 0.2, 0.3])
        labels = np.array([1.0, 1.0, 0.0, 0.0, 0.0])

        # Top 40% should contain both actives
        ef = enrichment_objective(scores, labels, fraction=0.4)
        assert ef > 2.0  # Better than random

    def test_random_ranking(self) -> None:
        """Random ranking should give EF around 1.0."""
        np.random.seed(42)
        scores = np.random.rand(1000)
        labels = np.zeros(1000)
        labels[:100] = 1.0  # 10% actives
        np.random.shuffle(labels)

        ef = enrichment_objective(scores, labels, fraction=0.1)
        # Should be around 1.0 (random)
        assert 0.5 < ef < 2.0

    def test_requires_labels(self) -> None:
        """Should raise ValueError if labels is None."""
        scores = np.array([0.1, 0.2, 0.3])
        with pytest.raises(ValueError, match="requires labels"):
            enrichment_objective(scores, labels=None)

    def test_no_actives_returns_zero(self) -> None:
        """No actives should return 0."""
        scores = np.array([0.1, 0.2, 0.3])
        labels = np.zeros(3)

        ef = enrichment_objective(scores, labels)
        assert ef == 0.0


class TestBedrocObjective:
    """Tests for bedroc_objective function."""

    def test_perfect_ranking(self) -> None:
        """Perfect ranking should give high BEDROC."""
        # Create data where high scores perfectly predict actives
        scores = np.concatenate([np.linspace(0.9, 1.0, 10), np.linspace(0.0, 0.5, 90)])
        labels = np.concatenate([np.ones(10), np.zeros(90)])

        bedroc = bedroc_objective(scores, labels)
        # Perfect ranking should give high BEDROC (close to 1.0)
        assert bedroc > 0.7  # High but may not be exactly 1.0

    def test_worst_ranking(self) -> None:
        """Worst ranking should give low BEDROC."""
        # Create data where high scores predict inactives (reverse)
        scores = np.concatenate([np.linspace(0.0, 0.1, 10), np.linspace(0.5, 1.0, 90)])
        labels = np.concatenate([np.ones(10), np.zeros(90)])

        bedroc = bedroc_objective(scores, labels)
        # Worst ranking should give low BEDROC
        assert bedroc < 0.3

    def test_requires_labels(self) -> None:
        """Should raise ValueError if labels is None."""
        scores = np.array([0.1, 0.2, 0.3])
        with pytest.raises(ValueError, match="requires labels"):
            bedroc_objective(scores, labels=None)

    def test_no_actives_returns_zero(self) -> None:
        """No actives should return 0."""
        scores = np.array([0.1, 0.2, 0.3])
        labels = np.zeros(3)

        bedroc = bedroc_objective(scores, labels)
        assert bedroc == 0.0


class TestObjectiveRegistry:
    """Tests for objective registry functions."""

    def test_list_objectives(self) -> None:
        """Should list all available objectives."""
        objectives = list_objectives()
        assert "entropy" in objectives
        assert "roc_auc" in objectives
        assert "enrichment" in objectives
        assert "bedroc" in objectives

    def test_get_objective(self) -> None:
        """Should return correct objective function."""
        fn = get_objective("entropy")
        assert fn == entropy_objective

        fn = get_objective("roc_auc")
        assert fn == roc_auc_objective

    def test_get_unknown_objective(self) -> None:
        """Should raise ValueError for unknown objective."""
        with pytest.raises(ValueError, match="Unknown objective"):
            get_objective("nonexistent")

    def test_registry_completeness(self) -> None:
        """All objectives in registry should be callable."""
        for _name, fn in OBJECTIVE_REGISTRY.items():
            assert callable(fn)
