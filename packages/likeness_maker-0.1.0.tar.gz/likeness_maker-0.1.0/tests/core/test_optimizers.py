"""Tests for weight optimizers."""

import numpy as np
import pytest
from numpy.testing import assert_almost_equal

from likeness_maker.core.objectives import entropy_objective, roc_auc_objective
from likeness_maker.core.optimizers import (
    OPTIMIZER_REGISTRY,
    BaseOptimizer,
    EntropyOptimizer,
    OptimizerResult,
    ScipyOptimizer,
    get_optimizer,
    list_optimizers,
)


class TestOptimizerResult:
    """Tests for OptimizerResult dataclass."""

    def test_create_result(self) -> None:
        """Should create result with all fields."""
        weights = np.array([0.3, 0.3, 0.4])
        result = OptimizerResult(
            weights=weights,
            objective_value=0.85,
            converged=True,
            n_iterations=50,
        )

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value == 0.85
        assert result.converged is True
        assert result.n_iterations == 50

    def test_result_is_frozen(self) -> None:
        """Result should be immutable."""
        result = OptimizerResult(
            weights=np.array([0.5, 0.5]),
            objective_value=0.5,
        )

        with pytest.raises(AttributeError):  # FrozenInstanceError
            result.weights = np.array([0.6, 0.4])


class TestBaseOptimizer:
    """Tests for BaseOptimizer static methods."""

    def test_compute_scores(self) -> None:
        """Should compute weighted geometric mean correctly."""
        desirabilities = np.array(
            [
                [0.8, 0.6],
                [0.4, 0.9],
            ]
        )
        weights = np.array([0.5, 0.5])

        scores = BaseOptimizer.compute_scores(desirabilities, weights)

        # Geometric mean: sqrt(0.8 * 0.6) = 0.693
        # Geometric mean: sqrt(0.4 * 0.9) = 0.6
        assert_almost_equal(scores[0], np.sqrt(0.8 * 0.6), decimal=3)
        assert_almost_equal(scores[1], np.sqrt(0.4 * 0.9), decimal=3)

    def test_normalize_weights(self) -> None:
        """Should normalize weights to sum to 1."""
        raw = np.array([2.0, 3.0, 5.0])
        weights = BaseOptimizer.normalize_weights(raw)

        assert_almost_equal(weights.sum(), 1.0)
        assert_almost_equal(weights, np.array([0.2, 0.3, 0.5]))

    def test_normalize_weights_with_min(self) -> None:
        """Should clip weights below min_weight."""
        raw = np.array([0.001, 0.5, 0.499])
        weights = BaseOptimizer.normalize_weights(raw, min_weight=0.1)

        # After normalization, min should be at least min_weight
        # (within numerical tolerance)
        assert weights.min() >= 0.1 - 0.01
        assert_almost_equal(weights.sum(), 1.0)


class TestEntropyOptimizer:
    """Tests for EntropyOptimizer (original QED grid search method)."""

    def test_optimize_basic(self) -> None:
        """Should find weights that maximize score entropy."""
        np.random.seed(42)
        desirabilities = np.random.rand(100, 2)

        optimizer = EntropyOptimizer(n_points=5)  # Original QED: 5 points
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.converged is True
        assert result.objective_value > 0

    def test_grid_search_exhaustive(self) -> None:
        """Should evaluate all grid combinations."""
        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)

        optimizer = EntropyOptimizer(n_points=3)  # 3^2 = 9 combinations
        result = optimizer.optimize(desirabilities, entropy_objective)

        # Total is 9, but (0,0) is skipped = 8 evaluated
        assert result.extra["total_combinations"] == 9
        assert result.n_iterations == 8  # Skip all-zero

    def test_optimize_returns_extra_info(self) -> None:
        """Should return grid search info in extra."""
        desirabilities = np.random.rand(50, 2)

        optimizer = EntropyOptimizer(n_points=5)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert result.extra["method"] == "grid_search"
        assert result.extra["n_points"] == 5
        assert result.extra["total_combinations"] == 25  # 5^2
        assert "best_entropy" in result.extra

    def test_original_qed_grid(self) -> None:
        """Default settings should match original QED (5 points, 0.0-1.0)."""
        optimizer = EntropyOptimizer()

        assert optimizer.n_points == 5
        assert optimizer.min_weight == 0.0

    def test_invalid_input_dimension(self) -> None:
        """Should raise ValueError for 1D input."""
        with pytest.raises(ValueError, match="2D array"):
            EntropyOptimizer().optimize(
                np.array([0.1, 0.2, 0.3]),
                entropy_objective,
            )


class TestScipyOptimizer:
    """Tests for ScipyOptimizer."""

    def test_optimize_entropy(self) -> None:
        """Should find reasonable weights for entropy objective."""
        np.random.seed(42)
        desirabilities = np.random.rand(100, 3)

        optimizer = ScipyOptimizer(max_iterations=50)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0

    def test_optimize_supervised(self) -> None:
        """Should work with supervised objectives."""
        np.random.seed(42)
        # Create data where feature 0 is highly predictive
        labels = np.concatenate([np.zeros(50), np.ones(50)])
        desirabilities = np.column_stack(
            [
                # Feature 0: strong separation
                np.concatenate([np.linspace(0.1, 0.3, 50), np.linspace(0.7, 0.9, 50)]),
                # Feature 1: random noise
                np.random.rand(100) * 0.5 + 0.25,
            ]
        )

        optimizer = ScipyOptimizer(max_iterations=100)
        result = optimizer.optimize(desirabilities, roc_auc_objective, labels=labels)

        # Feature 0 should get higher weight (it's predictive)
        # Note: scipy optimization may not always find optimal, so we just check it runs
        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0.5  # Should be better than random

    def test_min_weight_constraint(self) -> None:
        """Should respect min_weight constraint."""
        desirabilities = np.random.rand(50, 3)

        optimizer = ScipyOptimizer(min_weight=0.1)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert result.weights.min() >= 0.1 - 0.01  # Small tolerance

    def test_invalid_input_dimension(self) -> None:
        """Should raise ValueError for 1D input."""
        with pytest.raises(ValueError, match="2D array"):
            ScipyOptimizer().optimize(
                np.array([0.1, 0.2, 0.3]),
                entropy_objective,
            )


class TestOptunaOptimizer:
    """Tests for OptunaOptimizer."""

    @pytest.fixture
    def optuna_available(self) -> bool:
        """Check if optuna is available."""
        import importlib.util

        return importlib.util.find_spec("optuna") is not None

    def test_optuna_import_error(self, optuna_available: bool) -> None:
        """Should raise ImportError if optuna not installed."""
        if optuna_available:
            pytest.skip("Optuna is installed")

        from likeness_maker.core.optimizers import OptunaOptimizer

        optimizer = OptunaOptimizer(n_trials=5)
        with pytest.raises(ImportError, match="optuna is required"):
            optimizer.optimize(np.random.rand(10, 2), entropy_objective)

    def test_optimize_basic(self, optuna_available: bool) -> None:
        """Should find reasonable weights."""
        if not optuna_available:
            pytest.skip("Optuna not installed")

        from likeness_maker.core.optimizers import OptunaOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)

        optimizer = OptunaOptimizer(n_trials=10, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.n_iterations == 10

    def test_optimize_with_labels(self, optuna_available: bool) -> None:
        """Should work with supervised objectives."""
        if not optuna_available:
            pytest.skip("Optuna not installed")

        from likeness_maker.core.optimizers import OptunaOptimizer

        np.random.seed(42)
        labels = np.concatenate([np.zeros(25), np.ones(25)])
        desirabilities = np.column_stack(
            [
                np.concatenate([np.random.rand(25) * 0.3, np.random.rand(25) * 0.3 + 0.7]),
                np.random.rand(50),
            ]
        )

        optimizer = OptunaOptimizer(n_trials=20, seed=42)
        result = optimizer.optimize(desirabilities, roc_auc_objective, labels=labels)

        # Feature 0 is predictive, should have higher weight
        assert result.weights[0] > result.weights[1]


class TestDifferentialEvolutionOptimizer:
    """Tests for DifferentialEvolutionOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights."""
        from likeness_maker.core.optimizers import DifferentialEvolutionOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = DifferentialEvolutionOptimizer(max_iterations=20, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0

    def test_converged_flag(self) -> None:
        """Should report convergence status."""
        from likeness_maker.core.optimizers import DifferentialEvolutionOptimizer

        desirabilities = np.random.rand(30, 2)
        optimizer = DifferentialEvolutionOptimizer(max_iterations=10, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert isinstance(result.converged, bool)


class TestDualAnnealingOptimizer:
    """Tests for DualAnnealingOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights."""
        from likeness_maker.core.optimizers import DualAnnealingOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = DualAnnealingOptimizer(max_iterations=50, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestBasinHoppingOptimizer:
    """Tests for BasinHoppingOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights."""
        from likeness_maker.core.optimizers import BasinHoppingOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = BasinHoppingOptimizer(n_iterations=10, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestNelderMeadOptimizer:
    """Tests for NelderMeadOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights."""
        from likeness_maker.core.optimizers import NelderMeadOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = NelderMeadOptimizer(max_iterations=100)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestGridSearchOptimizer:
    """Tests for GridSearchOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights with grid search."""
        from likeness_maker.core.optimizers import GridSearchOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)  # 2 features for fast grid

        optimizer = GridSearchOptimizer(n_points=5)  # 5^2 = 25 evaluations
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0

    def test_extra_info(self) -> None:
        """Should include grid info in extra."""
        from likeness_maker.core.optimizers import GridSearchOptimizer

        desirabilities = np.random.rand(20, 2)
        optimizer = GridSearchOptimizer(n_points=3)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert "n_points_per_dim" in result.extra
        assert "total_grid_points" in result.extra


class TestRandomSearchOptimizer:
    """Tests for RandomSearchOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights with random search."""
        from likeness_maker.core.optimizers import RandomSearchOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = RandomSearchOptimizer(n_samples=100, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0

    def test_dirichlet_distribution(self) -> None:
        """Should work with Dirichlet sampling."""
        from likeness_maker.core.optimizers import RandomSearchOptimizer

        desirabilities = np.random.rand(50, 3)
        optimizer = RandomSearchOptimizer(n_samples=50, distribution="dirichlet", seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)


class TestSobolSearchOptimizer:
    """Tests for SobolSearchOptimizer."""

    def test_optimize_basic(self) -> None:
        """Should find reasonable weights with Sobol sequence."""
        from likeness_maker.core.optimizers import SobolSearchOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 3)

        optimizer = SobolSearchOptimizer(n_samples=64, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestSkoptOptimizer:
    """Tests for SkoptOptimizer (Gaussian Process)."""

    @pytest.fixture
    def skopt_available(self) -> bool:
        """Check if scikit-optimize is available."""
        import importlib.util

        return importlib.util.find_spec("skopt") is not None

    def test_optimize_basic(self, skopt_available: bool) -> None:
        """Should find reasonable weights."""
        if not skopt_available:
            pytest.skip("scikit-optimize not installed")

        from likeness_maker.core.optimizers import SkoptOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)

        optimizer = SkoptOptimizer(n_calls=15, n_initial_points=5, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestForestOptimizer:
    """Tests for ForestOptimizer (Random Forest based)."""

    @pytest.fixture
    def skopt_available(self) -> bool:
        """Check if scikit-optimize is available."""
        import importlib.util

        return importlib.util.find_spec("skopt") is not None

    def test_optimize_basic(self, skopt_available: bool) -> None:
        """Should find reasonable weights."""
        if not skopt_available:
            pytest.skip("scikit-optimize not installed")

        from likeness_maker.core.optimizers import ForestOptimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)

        optimizer = ForestOptimizer(n_calls=15, n_initial_points=5, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)
        assert result.objective_value > 0


class TestNSGA2Optimizer:
    """Tests for NSGA2Optimizer (multi-objective)."""

    @pytest.fixture
    def pymoo_available(self) -> bool:
        """Check if pymoo is available."""
        import importlib.util

        return importlib.util.find_spec("pymoo") is not None

    def test_single_objective(self, pymoo_available: bool) -> None:
        """Should work with single objective."""
        if not pymoo_available:
            pytest.skip("pymoo not installed")

        from likeness_maker.core.optimizers import NSGA2Optimizer

        np.random.seed(42)
        desirabilities = np.random.rand(50, 2)

        optimizer = NSGA2Optimizer(population_size=20, n_generations=10, seed=42)
        result = optimizer.optimize(desirabilities, entropy_objective)

        assert_almost_equal(result.weights.sum(), 1.0)

    def test_multi_objective(self, pymoo_available: bool) -> None:
        """Should return Pareto front for multiple objectives."""
        if not pymoo_available:
            pytest.skip("pymoo not installed")

        from likeness_maker.core.optimizers import NSGA2Optimizer

        np.random.seed(42)
        labels = np.concatenate([np.zeros(25), np.ones(25)])
        desirabilities = np.column_stack(
            [
                np.concatenate([np.random.rand(25) * 0.3, np.random.rand(25) * 0.3 + 0.7]),
                np.random.rand(50),
            ]
        )

        optimizer = NSGA2Optimizer(population_size=20, n_generations=10, seed=42)
        result = optimizer.optimize_multi(
            desirabilities,
            objective_fns=[entropy_objective, roc_auc_objective],
            objective_names=["entropy", "roc_auc"],
            labels=labels,
        )

        # Should have multiple Pareto-optimal solutions
        assert result.pareto_weights.shape[0] >= 1
        assert result.pareto_objectives.shape[1] == 2  # 2 objectives
        assert result.objective_names == ["entropy", "roc_auc"]

        # Best compromise should be valid weights
        assert_almost_equal(result.best_compromise.sum(), 1.0)


class TestNSGA3Optimizer:
    """Tests for NSGA3Optimizer (many-objective)."""

    @pytest.fixture
    def pymoo_available(self) -> bool:
        """Check if pymoo is available."""
        import importlib.util

        return importlib.util.find_spec("pymoo") is not None

    def test_multi_objective(self, pymoo_available: bool) -> None:
        """Should return Pareto front for multiple objectives."""
        if not pymoo_available:
            pytest.skip("pymoo not installed")

        from likeness_maker.core.optimizers import NSGA3Optimizer

        np.random.seed(42)
        labels = np.concatenate([np.zeros(25), np.ones(25)])
        desirabilities = np.column_stack(
            [
                np.concatenate([np.random.rand(25) * 0.3, np.random.rand(25) * 0.3 + 0.7]),
                np.random.rand(50),
            ]
        )

        optimizer = NSGA3Optimizer(population_size=20, n_generations=10, seed=42)
        result = optimizer.optimize_multi(
            desirabilities,
            objective_fns=[entropy_objective, roc_auc_objective],
            objective_names=["entropy", "roc_auc"],
            labels=labels,
        )

        # Should have Pareto-optimal solutions
        assert result.pareto_weights.shape[0] >= 1
        assert_almost_equal(result.best_compromise.sum(), 1.0)


class TestOptimizerRegistry:
    """Tests for optimizer registry functions."""

    def test_list_optimizers(self) -> None:
        """Should list all available optimizers."""
        optimizers = list_optimizers()
        assert "entropy" in optimizers
        assert "optuna" in optimizers
        assert "scipy" in optimizers
        # New optimizers
        assert "differential_evolution" in optimizers
        assert "dual_annealing" in optimizers
        assert "basinhopping" in optimizers
        assert "nelder_mead" in optimizers
        assert "grid" in optimizers
        assert "random" in optimizers
        assert "sobol" in optimizers
        assert "skopt" in optimizers
        assert "forest" in optimizers
        assert "nsga2" in optimizers
        assert "nsga3" in optimizers

    def test_get_optimizer(self) -> None:
        """Should return correct optimizer class."""
        cls = get_optimizer("entropy")
        assert cls == EntropyOptimizer

        cls = get_optimizer("scipy")
        assert cls == ScipyOptimizer

    def test_get_unknown_optimizer(self) -> None:
        """Should raise ValueError for unknown optimizer."""
        with pytest.raises(ValueError, match="Unknown optimizer"):
            get_optimizer("nonexistent")

    def test_registry_completeness(self) -> None:
        """All optimizers in registry should be BaseOptimizer subclasses."""
        for _name, cls in OPTIMIZER_REGISTRY.items():
            assert issubclass(cls, BaseOptimizer)

    def test_all_optimizers_count(self) -> None:
        """Should have 14 optimizers registered."""
        assert len(list_optimizers()) == 14
