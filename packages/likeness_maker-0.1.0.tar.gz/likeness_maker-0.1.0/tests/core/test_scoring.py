"""Tests for likeness scoring functions."""

import numpy as np
import pytest

from likeness_maker.core.desirability import GaussianDesirability, LinearDesirability
from likeness_maker.core.scoring import batch_score, geometric_mean_score, individual_desirabilities


class TestGeometricMeanScore:
    """Tests for geometric_mean_score function."""

    def test_all_ones(self):
        """Test that all ones gives score of 1."""
        desirabilities = np.array([1.0, 1.0, 1.0])
        score = geometric_mean_score(desirabilities)
        np.testing.assert_almost_equal(score, 1.0)

    def test_all_zeros(self):
        """Test that all zeros gives very low score."""
        desirabilities = np.array([0.0, 0.0, 0.0])
        score = geometric_mean_score(desirabilities)
        assert score < 1e-9

    def test_uniform_weights(self):
        """Test geometric mean with uniform weights."""
        # Geometric mean of [0.5, 0.5, 0.5] = 0.5
        desirabilities = np.array([0.5, 0.5, 0.5])
        score = geometric_mean_score(desirabilities)
        np.testing.assert_almost_equal(score, 0.5)

    def test_geometric_mean_property(self):
        """Test that it's actually a geometric mean."""
        # Geometric mean of [1, 2, 4] = (1 * 2 * 4)^(1/3) = 8^(1/3) = 2
        # But our desirabilities are clipped to [0, 1]
        desirabilities = np.array([0.25, 0.5, 1.0])
        # (0.25 * 0.5 * 1.0)^(1/3) = 0.125^(1/3) = 0.5
        score = geometric_mean_score(desirabilities)
        np.testing.assert_almost_equal(score, 0.5)

    def test_weighted_score(self):
        """Test with custom weights."""
        desirabilities = np.array([0.1, 1.0])

        # With weight on second feature only
        weights = np.array([0.0, 1.0])
        score_weighted = geometric_mean_score(desirabilities, weights)
        # Should be close to 1.0 since only second feature matters
        np.testing.assert_almost_equal(score_weighted, 1.0)

        # With uniform weights: (0.1 * 1.0)^0.5 ≈ 0.316
        score_uniform = geometric_mean_score(desirabilities)
        assert score_uniform < score_weighted  # Uniform should be lower

    def test_length_mismatch(self):
        """Test error when lengths don't match."""
        desirabilities = np.array([0.5, 0.5])
        weights = np.array([1.0, 1.0, 1.0])

        with pytest.raises(ValueError, match="Length mismatch"):
            geometric_mean_score(desirabilities, weights)

    def test_all_zero_weights(self):
        """Test behavior with all-zero weights."""
        desirabilities = np.array([0.5, 0.5, 0.5])
        weights = np.array([0.0, 0.0, 0.0])
        # Should handle gracefully - either return default score or raise
        # Current implementation returns 0 when sum of weights is 0
        score = geometric_mean_score(desirabilities, weights)
        # Just verify it returns a number without crashing
        assert isinstance(score, (float, np.floating))


class TestBatchScore:
    """Tests for batch_score function."""

    def test_single_sample(self):
        """Test scoring a single sample."""
        features = np.array([[50.0, 1.0]])  # Both at optimal values
        functions = [
            GaussianDesirability(center=50.0, sigma=10.0),
            LinearDesirability(x_min=0.0, x_max=1.0),
        ]
        scores = batch_score(features, functions)
        assert len(scores) == 1
        # Both features are at optimal values (1.0 each)
        # Geometric mean of (1.0, 1.0) = 1.0
        np.testing.assert_almost_equal(scores[0], 1.0, decimal=2)

    def test_multiple_samples(self):
        """Test scoring multiple samples."""
        features = np.array(
            [
                [50.0, 0.5],  # Good sample
                [100.0, 0.0],  # Poor sample
            ]
        )
        functions = [
            GaussianDesirability(center=50.0, sigma=10.0),
            LinearDesirability(x_min=0.0, x_max=1.0),
        ]
        scores = batch_score(features, functions)
        assert len(scores) == 2
        # First sample should score higher
        assert scores[0] > scores[1]

    def test_with_weights(self):
        """Test scoring with custom weights."""
        features = np.array([[0.0, 1.0]])  # First feature bad, second good
        functions = [
            LinearDesirability(x_min=0.0, x_max=100.0),  # 0.0 -> 0.0
            LinearDesirability(x_min=0.0, x_max=1.0),  # 1.0 -> 1.0
        ]
        # Weight only the good feature
        weights = np.array([0.0, 1.0])
        scores = batch_score(features, functions, weights)
        np.testing.assert_almost_equal(scores[0], 1.0)

    def test_function_count_mismatch(self):
        """Test error when function count doesn't match features."""
        features = np.array([[1.0, 2.0, 3.0]])
        functions = [LinearDesirability(x_min=0.0, x_max=1.0)]

        with pytest.raises(ValueError, match="Got 3 features but 1 functions"):
            batch_score(features, functions)

    def test_1d_input(self):
        """Test that 1D input is handled correctly."""
        features = np.array([50.0, 0.5])  # 1D array
        functions = [
            GaussianDesirability(center=50.0, sigma=10.0),
            LinearDesirability(x_min=0.0, x_max=1.0),
        ]
        scores = batch_score(features, functions)
        assert len(scores) == 1


class TestIndividualDesirabilities:
    """Tests for individual_desirabilities function."""

    def test_basic(self):
        """Test computing individual desirabilities."""
        features = np.array(
            [
                [50.0, 0.5],
                [0.0, 1.0],
            ]
        )
        functions = [
            GaussianDesirability(center=50.0, sigma=10.0),
            LinearDesirability(x_min=0.0, x_max=1.0),
        ]
        desirabilities = individual_desirabilities(features, functions)

        assert desirabilities.shape == (2, 2)
        # First sample, first feature: at center, should be 1.0
        np.testing.assert_almost_equal(desirabilities[0, 0], 1.0)
        # First sample, second feature: at 0.5, should be 0.5
        np.testing.assert_almost_equal(desirabilities[0, 1], 0.5)

    def test_output_shape(self):
        """Test output shape matches input."""
        n_samples, n_features = 10, 3
        features = np.random.rand(n_samples, n_features) * 100
        functions = [LinearDesirability(x_min=0.0, x_max=100.0) for _ in range(n_features)]
        desirabilities = individual_desirabilities(features, functions)
        assert desirabilities.shape == (n_samples, n_features)
