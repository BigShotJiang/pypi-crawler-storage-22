"""Tests for core type definitions."""

import pytest

from likeness_maker.core.types import FeatureDefinition, FeatureSet, FittedDesirability


class TestFeatureDefinition:
    """Tests for FeatureDefinition dataclass."""

    def test_create_minimal(self):
        """Test creating feature with only name."""
        feature = FeatureDefinition(name="temperature")
        assert feature.name == "temperature"
        assert feature.description == ""
        assert feature.lower_bound is None
        assert feature.upper_bound is None

    def test_create_full(self):
        """Test creating feature with all attributes."""
        feature = FeatureDefinition(
            name="humidity",
            description="Relative humidity percentage",
            lower_bound=0.0,
            upper_bound=100.0,
        )
        assert feature.name == "humidity"
        assert feature.description == "Relative humidity percentage"
        assert feature.lower_bound == 0.0
        assert feature.upper_bound == 100.0

    def test_immutable(self):
        """Test that FeatureDefinition is immutable."""
        feature = FeatureDefinition(name="test")
        with pytest.raises(AttributeError):
            feature.name = "changed"  # type: ignore[misc]


class TestFeatureSet:
    """Tests for FeatureSet dataclass."""

    def test_duplicate_names_raises(self):
        """Test that duplicate feature names raise ValueError."""
        with pytest.raises(ValueError, match="Duplicate feature names"):
            FeatureSet(
                features=(
                    FeatureDefinition(name="same_name"),
                    FeatureDefinition(name="other"),
                    FeatureDefinition(name="same_name"),
                )
            )

    def test_create(self):
        """Test creating a feature set."""
        features = (
            FeatureDefinition(name="a"),
            FeatureDefinition(name="b"),
            FeatureDefinition(name="c"),
        )
        fs = FeatureSet(features=features)
        assert len(fs) == 3
        assert fs.names == ("a", "b", "c")

    def test_getitem_by_index(self):
        """Test accessing feature by index."""
        features = (
            FeatureDefinition(name="first"),
            FeatureDefinition(name="second"),
        )
        fs = FeatureSet(features=features)
        assert fs[0].name == "first"
        assert fs[1].name == "second"

    def test_getitem_by_name(self):
        """Test accessing feature by name."""
        features = (
            FeatureDefinition(name="alpha"),
            FeatureDefinition(name="beta"),
        )
        fs = FeatureSet(features=features)
        assert fs["alpha"].name == "alpha"
        assert fs["beta"].name == "beta"

    def test_getitem_not_found(self):
        """Test KeyError for unknown feature name."""
        fs = FeatureSet(features=(FeatureDefinition(name="only"),))
        with pytest.raises(KeyError):
            _ = fs["unknown"]

    def test_contains(self):
        """Test 'in' operator for feature names."""
        fs = FeatureSet(
            features=(
                FeatureDefinition(name="present"),
                FeatureDefinition(name="also_present"),
            )
        )
        assert "present" in fs
        assert "also_present" in fs
        assert "missing" not in fs

    def test_immutable(self):
        """Test that FeatureSet is immutable."""
        fs = FeatureSet(features=(FeatureDefinition(name="test"),))
        with pytest.raises(AttributeError):
            fs.features = ()  # type: ignore[misc]


class TestFittedDesirability:
    """Tests for FittedDesirability dataclass."""

    def test_create(self):
        """Test creating a fitted desirability."""
        fd = FittedDesirability(
            feature_name="MW",
            function_type="ads",
            parameters={"a": 1.0, "b": 2.0},
            r_squared=0.95,
        )
        assert fd.feature_name == "MW"
        assert fd.function_type == "ads"
        assert fd.parameters == {"a": 1.0, "b": 2.0}
        assert fd.r_squared == 0.95

    def test_to_dict(self):
        """Test serialization to dictionary."""
        fd = FittedDesirability(
            feature_name="test",
            function_type="linear",
            parameters={"x_min": 0.0, "x_max": 100.0},
            r_squared=1.0,
        )
        d = fd.to_dict()
        assert d["feature_name"] == "test"
        assert d["function_type"] == "linear"
        assert d["parameters"] == {"x_min": 0.0, "x_max": 100.0}
        assert d["r_squared"] == 1.0

    def test_from_dict(self):
        """Test deserialization from dictionary."""
        data = {
            "feature_name": "pressure",
            "function_type": "gaussian",
            "parameters": {"center": 50.0, "sigma": 10.0},
            "r_squared": 0.98,
        }
        fd = FittedDesirability.from_dict(data)
        assert fd.feature_name == "pressure"
        assert fd.function_type == "gaussian"
        assert fd.parameters == {"center": 50.0, "sigma": 10.0}
        assert fd.r_squared == 0.98

    def test_roundtrip(self):
        """Test serialization roundtrip."""
        original = FittedDesirability(
            feature_name="roundtrip",
            function_type="ads",
            parameters={"a": 1.5, "b": 2.5, "c": 3.5},
            r_squared=0.99,
        )
        restored = FittedDesirability.from_dict(original.to_dict())
        assert restored == original
