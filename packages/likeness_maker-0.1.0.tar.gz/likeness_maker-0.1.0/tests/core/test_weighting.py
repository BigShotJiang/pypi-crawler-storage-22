"""Tests for weight optimization functions."""

import numpy as np
import pytest

from likeness_maker.core.weighting import (
    compute_entropy_weights,
    optimize_weights_iterative,
    shannon_entropy,
)


class TestShannonEntropy:
    """Tests for shannon_entropy function."""

    def test_uniform_distribution(self):
        """Test entropy of uniform distribution (maximum entropy)."""
        # Uniform distribution across 10 bins should have high entropy
        values = np.linspace(0, 1, 1000)
        entropy = shannon_entropy(values, n_bins=10)
        # Maximum entropy for 10 bins is log2(10) ≈ 3.32
        assert entropy > 3.0

    def test_single_value(self):
        """Test entropy of constant values (zero entropy)."""
        values = np.full(100, 0.5)
        entropy = shannon_entropy(values, n_bins=10)
        assert entropy == 0.0

    def test_bimodal_distribution(self):
        """Test entropy of bimodal distribution."""
        values = np.concatenate([np.full(50, 0.1), np.full(50, 0.9)])
        entropy = shannon_entropy(values, n_bins=10)
        # Two bins with equal probability: log2(2) = 1.0
        assert 0.9 < entropy < 1.1

    def test_empty_values(self):
        """Test entropy of empty array."""
        values = np.array([])
        entropy = shannon_entropy(values)
        assert entropy == 0.0

    def test_nan_values_ignored(self):
        """Test that NaN values are ignored."""
        values = np.array([0.1, 0.2, np.nan, 0.3, np.nan, 0.4])
        entropy = shannon_entropy(values, n_bins=10)
        assert entropy > 0.0


class TestComputeEntropyWeights:
    """Tests for compute_entropy_weights function."""

    def test_basic(self):
        """Test basic weight computation."""
        rng = np.random.default_rng(42)
        # Feature 0: uniform (high entropy)
        # Feature 1: concentrated (low entropy)
        desirabilities = np.column_stack(
            [
                rng.uniform(0, 1, 100),
                np.full(100, 0.5) + rng.normal(0, 0.01, 100),
            ]
        )
        desirabilities = np.clip(desirabilities, 0, 1)

        weights = compute_entropy_weights(desirabilities)

        assert len(weights) == 2
        # First feature should have higher weight (more entropy)
        assert weights[0] > weights[1]

    def test_normalized(self):
        """Test that weights sum to 1 when normalized."""
        rng = np.random.default_rng(42)
        desirabilities = rng.uniform(0, 1, (100, 5))

        weights = compute_entropy_weights(desirabilities, normalize=True)

        np.testing.assert_almost_equal(weights.sum(), 1.0)

    def test_unnormalized(self):
        """Test unnormalized weights."""
        rng = np.random.default_rng(42)
        desirabilities = rng.uniform(0, 1, (100, 3))

        weights = compute_entropy_weights(desirabilities, normalize=False)

        # Unnormalized weights are raw entropies
        assert weights.sum() != 1.0 or np.allclose(weights, 1 / 3)

    def test_invalid_dimensions(self):
        """Test error for 1D input."""
        values = np.array([0.1, 0.2, 0.3])

        with pytest.raises(ValueError, match="Expected 2D"):
            compute_entropy_weights(values)

    def test_all_same_entropy(self):
        """Test when all features have same entropy."""
        rng = np.random.default_rng(42)
        # All features uniformly distributed
        desirabilities = rng.uniform(0, 1, (100, 4))

        weights = compute_entropy_weights(desirabilities)

        # All weights should be roughly equal
        np.testing.assert_array_almost_equal(weights, np.full(4, 0.25), decimal=1)

    def test_empty_samples_raises(self):
        """Test error for 0 samples."""
        desirabilities = np.empty((0, 3))

        with pytest.raises(ValueError, match="empty"):
            compute_entropy_weights(desirabilities)

    def test_all_nan_column(self):
        """Test handling of a column with all NaN values."""
        rng = np.random.default_rng(42)
        desirabilities = np.column_stack(
            [
                rng.uniform(0, 1, 100),
                np.full(100, np.nan),  # All NaN
            ]
        )

        weights = compute_entropy_weights(desirabilities, normalize=True)

        # Should not raise, second weight should be 0
        assert len(weights) == 2
        assert weights[1] == 0.0


class TestOptimizeWeightsIterative:
    """Tests for optimize_weights_iterative function."""

    def test_invalid_dimensions(self):
        """Test error for 1D input."""
        values = np.array([0.1, 0.2, 0.3])

        with pytest.raises(ValueError, match="Expected 2D"):
            optimize_weights_iterative(values)

    def test_empty_samples_raises(self):
        """Test error for 0 samples."""
        desirabilities = np.empty((0, 3))

        with pytest.raises(ValueError, match="empty"):
            optimize_weights_iterative(desirabilities)

    def test_basic_optimization(self):
        """Test that optimization runs and returns valid weights."""
        rng = np.random.default_rng(42)
        desirabilities = rng.uniform(0.1, 0.9, (200, 3))

        weights = optimize_weights_iterative(desirabilities, max_iterations=10)

        assert len(weights) == 3
        assert all(w > 0 for w in weights)
        np.testing.assert_almost_equal(weights.sum(), 1.0)

    def test_convergence(self):
        """Test that optimization converges."""
        rng = np.random.default_rng(42)
        desirabilities = rng.uniform(0.1, 0.9, (100, 2))

        # With many iterations, should converge
        weights = optimize_weights_iterative(desirabilities, max_iterations=50, tolerance=1e-4)

        # Just check it returns valid weights
        assert len(weights) == 2
        np.testing.assert_almost_equal(weights.sum(), 1.0)

    def test_different_features_get_different_weights(self):
        """Test that features with different distributions get different weights."""
        rng = np.random.default_rng(42)
        # Feature 0: wide distribution (more discriminating)
        # Feature 1: narrow distribution (less discriminating)
        desirabilities = np.column_stack(
            [
                rng.uniform(0.1, 0.9, 200),
                np.clip(rng.normal(0.5, 0.05, 200), 0.1, 0.9),
            ]
        )

        weights = optimize_weights_iterative(desirabilities, max_iterations=20)

        # Weights should differ
        assert abs(weights[0] - weights[1]) > 0.01


class TestWeightingIntegration:
    """Integration tests for weighting with LikenessModel."""

    def test_entropy_weights_with_model(self):
        """Test using entropy weights with LikenessModel."""
        from likeness_maker.core import FeatureDefinition, FeatureSet, LikenessModel

        rng = np.random.default_rng(42)
        reference = rng.uniform(0, 100, (200, 2))

        feature_set = FeatureSet(
            features=(
                FeatureDefinition(name="feature_a"),
                FeatureDefinition(name="feature_b"),
            )
        )

        model = LikenessModel(feature_set=feature_set)
        fitted = model.fit(reference, function_type="linear")

        # Get individual desirabilities
        test_data = rng.uniform(0, 100, (50, 2))
        from likeness_maker.core.scoring import individual_desirabilities

        funcs = [
            fitted.fitted_functions["feature_a"],
            fitted.fitted_functions["feature_b"],
        ]
        from likeness_maker.core.desirability import get_desirability_class

        desirability_funcs = [
            get_desirability_class(f.function_type).from_parameters(**f.parameters) for f in funcs
        ]
        desirabilities = individual_desirabilities(test_data, desirability_funcs)

        # Compute entropy weights
        weights = compute_entropy_weights(desirabilities)

        assert len(weights) == 2
        np.testing.assert_almost_equal(weights.sum(), 1.0)
