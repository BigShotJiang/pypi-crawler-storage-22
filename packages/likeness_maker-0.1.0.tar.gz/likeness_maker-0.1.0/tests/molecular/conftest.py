"""Pytest fixtures for molecular tests."""

from pathlib import Path

import pytest


@pytest.fixture
def sample_sdf_file(tmp_path: Path) -> Path:
    """Create a sample SDF file for testing.

    Args:
        tmp_path: Pytest's temporary directory fixture.

    Returns:
        Path to the created SDF file.
    """
    from rdkit import Chem

    filepath = tmp_path / "test.sdf"

    mol = Chem.MolFromSmiles("CCO")
    mol.SetProp("Name", "ethanol")

    writer = Chem.SDWriter(str(filepath))
    writer.write(mol)
    writer.close()

    return filepath
