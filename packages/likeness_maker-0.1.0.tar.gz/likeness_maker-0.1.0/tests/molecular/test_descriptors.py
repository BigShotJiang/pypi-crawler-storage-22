"""Tests for molecular descriptor calculation."""

import numpy as np
import pytest


class TestDescriptorRegistry:
    """Tests for descriptor registry."""

    def test_registry_contains_standard_descriptors(self):
        """Test that registry contains standard descriptors."""
        from likeness_maker.molecular.descriptors import DESCRIPTOR_REGISTRY

        expected = ["MW", "ALOGP", "HBA", "HBD", "PSA", "ROTB", "AROM"]
        for name in expected:
            assert name in DESCRIPTOR_REGISTRY

    def test_descriptor_definition_fields(self):
        """Test descriptor definition has required fields."""
        from likeness_maker.molecular.descriptors import DESCRIPTOR_REGISTRY

        mw = DESCRIPTOR_REGISTRY["MW"]
        assert mw.name == "MW"
        assert mw.full_name == "Molecular Weight"
        assert mw.rdkit_name == "MolWt"
        assert mw.lower_bound == 0.0


class TestGetDescriptorFunction:
    """Tests for get_descriptor_function."""

    def test_valid_descriptor(self):
        """Test getting a valid descriptor function."""
        from likeness_maker.molecular.descriptors import get_descriptor_function

        func = get_descriptor_function("MolWt")
        assert callable(func)

    def test_invalid_descriptor(self):
        """Test error for invalid descriptor name."""
        from likeness_maker.molecular.descriptors import get_descriptor_function

        with pytest.raises(ValueError, match="Unknown RDKit descriptor"):
            get_descriptor_function("InvalidDescriptor")


class TestCalculateDescriptor:
    """Tests for calculate_descriptor function."""

    def test_calculate_mw(self):
        """Test calculating molecular weight."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptor

        mol = Chem.MolFromSmiles("CCO")  # Ethanol
        mw = calculate_descriptor(mol, "MW")

        assert isinstance(mw, float)
        assert 45 < mw < 47  # Ethanol MW ~46.07

    def test_calculate_logp(self):
        """Test calculating LogP."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptor

        mol = Chem.MolFromSmiles("c1ccccc1")  # Benzene
        logp = calculate_descriptor(mol, "ALOGP")

        assert isinstance(logp, float)

    def test_invalid_descriptor_name(self):
        """Test error for unknown descriptor."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptor

        mol = Chem.MolFromSmiles("CCO")
        with pytest.raises(ValueError, match="Unknown descriptor"):
            calculate_descriptor(mol, "INVALID")


class TestCalculateDescriptors:
    """Tests for calculate_descriptors function."""

    def test_default_descriptors(self):
        """Test calculating default descriptors."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptors

        mol = Chem.MolFromSmiles("CCO")
        result = calculate_descriptors(mol)

        # Default excludes ALERTS
        assert "MW" in result
        assert "ALOGP" in result
        assert "ALERTS" not in result

    def test_custom_descriptors(self):
        """Test calculating custom subset of descriptors."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptors

        mol = Chem.MolFromSmiles("CCO")
        result = calculate_descriptors(mol, descriptor_names=("MW", "HBD"))

        assert len(result) == 2
        assert "MW" in result
        assert "HBD" in result


class TestCalculateDescriptorsBatch:
    """Tests for calculate_descriptors_batch function."""

    def test_batch_calculation(self):
        """Test batch descriptor calculation."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptors_batch

        mols = [
            Chem.MolFromSmiles("CCO"),
            Chem.MolFromSmiles("CC(=O)O"),
            Chem.MolFromSmiles("c1ccccc1"),
        ]
        result = calculate_descriptors_batch(mols)

        assert result.shape[0] == 3
        assert result.shape[1] == 7  # 7 descriptors (QED without ALERTS)

    def test_batch_with_none(self):
        """Test batch handles None molecules."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptors_batch

        mols = [
            Chem.MolFromSmiles("CCO"),
            None,  # Invalid
            Chem.MolFromSmiles("CC"),
        ]
        result = calculate_descriptors_batch(mols)

        assert result.shape[0] == 3
        assert not np.isnan(result[0]).any()
        assert np.isnan(result[1]).all()  # All NaN for None
        assert not np.isnan(result[2]).any()

    def test_batch_custom_descriptors(self):
        """Test batch with custom descriptor subset."""
        from rdkit import Chem

        from likeness_maker.molecular.descriptors import calculate_descriptors_batch

        mols = [Chem.MolFromSmiles("CCO")]
        result = calculate_descriptors_batch(mols, descriptor_names=("MW", "PSA"))

        assert result.shape == (1, 2)


class TestDescriptorsToFeatureSet:
    """Tests for descriptors_to_feature_set function."""

    def test_default_feature_set(self):
        """Test creating default feature set."""
        from likeness_maker.molecular.descriptors import descriptors_to_feature_set

        fs = descriptors_to_feature_set()

        assert len(fs.features) == 7
        assert fs.features[0].name == "MW"

    def test_custom_feature_set(self):
        """Test creating custom feature set."""
        from likeness_maker.molecular.descriptors import descriptors_to_feature_set

        fs = descriptors_to_feature_set(descriptor_names=("MW", "ALOGP"))

        assert len(fs.features) == 2
        assert fs.features[0].name == "MW"
        assert fs.features[1].name == "ALOGP"

    def test_feature_bounds(self):
        """Test that feature bounds are set correctly."""
        from likeness_maker.molecular.descriptors import descriptors_to_feature_set

        fs = descriptors_to_feature_set(descriptor_names=("MW", "FRAC_CSP3"))

        mw_feature = fs.features[0]
        frac_feature = fs.features[1]

        assert mw_feature.lower_bound == 0.0
        assert frac_feature.lower_bound == 0.0
        assert frac_feature.upper_bound == 1.0

    def test_invalid_descriptor(self):
        """Test error for unknown descriptor."""
        from likeness_maker.molecular.descriptors import descriptors_to_feature_set

        with pytest.raises(ValueError, match="Unknown descriptor"):
            descriptors_to_feature_set(descriptor_names=("INVALID",))


class TestListAvailableDescriptors:
    """Tests for list_available_descriptors function."""

    def test_list_descriptors(self):
        """Test listing available descriptors."""
        from likeness_maker.molecular.descriptors import list_available_descriptors

        descriptors = list_available_descriptors()

        assert isinstance(descriptors, list)
        assert "MW" in descriptors
        assert "ALOGP" in descriptors
        assert len(descriptors) >= 7
