"""Tests for molecular I/O functions."""

import pandas as pd
import pytest


class TestReadSdf:
    """Tests for read_sdf function."""

    def test_read_valid_sdf(self, sample_sdf_file):
        """Test reading a valid SDF file."""
        from likeness_maker.molecular.io import read_sdf

        df = read_sdf(sample_sdf_file)

        assert len(df) > 0
        assert "mol" in df.columns
        assert df["mol"].notna().all()

    def test_read_sdf_with_properties(self, sample_sdf_file):
        """Test that SDF properties are extracted."""
        from likeness_maker.molecular.io import read_sdf

        df = read_sdf(sample_sdf_file)

        # Properties should be extracted as columns
        assert len(df.columns) >= 1  # At least 'mol' column

    def test_file_not_found(self):
        """Test error when file doesn't exist."""
        from likeness_maker.molecular.io import read_sdf

        with pytest.raises(FileNotFoundError):
            read_sdf("nonexistent.sdf")


class TestReadSmiles:
    """Tests for read_smiles function."""

    def test_read_valid_smiles(self, tmp_path):
        """Test reading a valid SMILES file."""
        from likeness_maker.molecular.io import read_smiles

        csv_file = tmp_path / "test.csv"
        csv_file.write_text("smiles,name\nCCO,ethanol\nCC(=O)O,acetic_acid\n")

        df = read_smiles(csv_file)

        assert len(df) == 2
        assert "mol" in df.columns
        assert "smiles" in df.columns
        assert df["mol"].notna().all()

    def test_read_tsv_smiles(self, tmp_path):
        """Test reading a TSV SMILES file."""
        from likeness_maker.molecular.io import read_smiles

        tsv_file = tmp_path / "test.tsv"
        tsv_file.write_text("smiles\tname\nCCO\tethanol\n")

        df = read_smiles(tsv_file, delimiter="\t")

        assert len(df) == 1
        assert df["mol"].notna().all()

    def test_missing_column(self, tmp_path):
        """Test error when SMILES column is missing."""
        from likeness_maker.molecular.io import read_smiles

        csv_file = tmp_path / "test.csv"
        csv_file.write_text("name,value\ntest,1\n")

        with pytest.raises(ValueError, match="Column 'smiles' not found"):
            read_smiles(csv_file)


class TestMoleculesFromSmiles:
    """Tests for molecules_from_smiles function."""

    def test_valid_smiles(self):
        """Test converting valid SMILES."""
        from likeness_maker.molecular.io import molecules_from_smiles

        smiles = ["CCO", "CC(=O)O", "c1ccccc1"]
        mols = list(molecules_from_smiles(smiles))

        assert len(mols) == 3
        assert all(mol is not None for mol in mols)

    def test_invalid_smiles(self):
        """Test handling invalid SMILES."""
        from likeness_maker.molecular.io import molecules_from_smiles

        smiles = ["CCO", "invalid_smiles_xxx", "CC"]
        mols = list(molecules_from_smiles(smiles))

        assert len(mols) == 3
        assert mols[0] is not None
        assert mols[1] is None  # Invalid
        assert mols[2] is not None


class TestFilterValidMolecules:
    """Tests for filter_valid_molecules function."""

    def test_filter(self):
        """Test filtering invalid molecules."""
        from likeness_maker.molecular.io import filter_valid_molecules, molecules_from_smiles

        smiles = ["CCO", "invalid", "CC"]
        mols = list(molecules_from_smiles(smiles))
        df = pd.DataFrame({"mol": mols, "smiles": smiles})

        filtered = filter_valid_molecules(df)

        assert len(filtered) == 2
        assert filtered["mol"].notna().all()
