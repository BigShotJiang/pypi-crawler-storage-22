"""Tests for molecular presets."""

import numpy as np
import pytest


class TestQEDPreset:
    """Tests for QED preset configuration."""

    def test_qed_preset_structure(self):
        """Test QED preset has correct structure."""
        from likeness_maker.molecular.presets import get_qed_preset

        preset = get_qed_preset()

        assert preset.name == "QED"
        assert "Bickerton" in preset.description
        assert len(preset.feature_set.features) == 8
        assert len(preset.fitted_functions) == 8
        assert len(preset.weights) == 8

    def test_qed_descriptor_order(self):
        """Test QED descriptors are in correct order."""
        from likeness_maker.molecular.presets import QED_DESCRIPTOR_ORDER, get_qed_preset

        preset = get_qed_preset()

        for i, name in enumerate(QED_DESCRIPTOR_ORDER):
            assert preset.feature_set.features[i].name == name

    def test_qed_weights(self):
        """Test QED weights match paper values."""
        from likeness_maker.molecular.presets import QED_WEIGHTS, get_qed_preset

        preset = get_qed_preset()

        np.testing.assert_array_almost_equal(preset.weights, QED_WEIGHTS)

    def test_qed_ads_parameters(self):
        """Test QED ADS parameters are present."""
        from likeness_maker.molecular.presets import get_qed_preset

        preset = get_qed_preset()

        # Check MW parameters
        mw_func = preset.fitted_functions["MW"]
        assert mw_func.function_type == "ads"
        assert "a" in mw_func.parameters
        assert "b" in mw_func.parameters
        assert "d_max" in mw_func.parameters


class TestQEDSimplePreset:
    """Tests for simplified QED preset."""

    def test_qed_simple_excludes_alerts(self):
        """Test QED-simple excludes ALERTS descriptor."""
        from likeness_maker.molecular.presets import get_qed_simple_preset

        preset = get_qed_simple_preset()

        assert preset.name == "QED-simple"
        assert len(preset.feature_set.features) == 7
        assert "ALERTS" not in [f.name for f in preset.feature_set.features]

    def test_qed_simple_weights_normalized(self):
        """Test QED-simple weights are normalized."""
        from likeness_maker.molecular.presets import get_qed_simple_preset

        preset = get_qed_simple_preset()

        assert np.isclose(preset.weights.sum(), 1.0)


class TestLipinskiPreset:
    """Tests for Lipinski Rule of Five preset."""

    def test_lipinski_preset_structure(self):
        """Test Lipinski preset has correct structure."""
        from likeness_maker.molecular.presets import get_lipinski_preset

        preset = get_lipinski_preset()

        assert preset.name == "Lipinski"
        assert len(preset.feature_set.features) == 4
        assert len(preset.fitted_functions) == 4

    def test_lipinski_descriptors(self):
        """Test Lipinski uses correct descriptors."""
        from likeness_maker.molecular.presets import get_lipinski_preset

        preset = get_lipinski_preset()
        names = [f.name for f in preset.feature_set.features]

        assert "MW" in names
        assert "ALOGP" in names
        assert "HBD" in names
        assert "HBA" in names

    def test_lipinski_equal_weights(self):
        """Test Lipinski has equal weights."""
        from likeness_maker.molecular.presets import get_lipinski_preset

        preset = get_lipinski_preset()

        expected = np.ones(4) / 4
        np.testing.assert_array_almost_equal(preset.weights, expected)

    def test_lipinski_linear_functions(self):
        """Test Lipinski uses linear desirability functions."""
        from likeness_maker.molecular.presets import get_lipinski_preset

        preset = get_lipinski_preset()

        for func in preset.fitted_functions.values():
            assert func.function_type == "linear"


class TestPresetRegistry:
    """Tests for preset registry functions."""

    def test_get_preset_by_name(self):
        """Test getting preset by name."""
        from likeness_maker.molecular.presets import get_preset

        preset = get_preset("qed")
        assert preset.name == "QED"

        preset = get_preset("QED")  # Case insensitive
        assert preset.name == "QED"

    def test_get_preset_invalid_name(self):
        """Test error for invalid preset name."""
        from likeness_maker.molecular.presets import get_preset

        with pytest.raises(ValueError, match="Unknown preset"):
            get_preset("nonexistent")

    def test_list_presets(self):
        """Test listing available presets."""
        from likeness_maker.molecular.presets import list_presets

        presets = list_presets()

        assert "qed" in presets
        assert "qed-simple" in presets
        assert "lipinski" in presets


class TestPresetConfig:
    """Tests for PresetConfig dataclass."""

    def test_preset_config_immutable(self):
        """Test PresetConfig is immutable."""
        from likeness_maker.molecular.presets import get_qed_preset

        preset = get_qed_preset()

        with pytest.raises(AttributeError):
            preset.name = "Modified"  # type: ignore[misc]
