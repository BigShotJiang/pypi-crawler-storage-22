"""Tests for visualization module."""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pytest

from likeness_maker.core import FeatureDefinition, FeatureSet, LikenessModel


@pytest.fixture
def simple_model() -> LikenessModel:
    """Create a simple fitted model for testing."""
    feature_set = FeatureSet(
        features=(
            FeatureDefinition(name="feature_a", lower_bound=0, upper_bound=100),
            FeatureDefinition(name="feature_b", lower_bound=0, upper_bound=10),
            FeatureDefinition(name="feature_c", lower_bound=0, upper_bound=50),
        )
    )
    np.random.seed(42)
    reference_data = np.column_stack(
        [
            np.random.normal(50, 10, 100),
            np.random.normal(5, 1, 100),
            np.random.normal(25, 5, 100),
        ]
    )
    model = LikenessModel(feature_set=feature_set)
    return model.fit(reference_data, function_type="gaussian")


@pytest.fixture
def weighted_model(simple_model: LikenessModel) -> LikenessModel:
    """Create a model with entropy-optimized weights."""
    np.random.seed(42)
    reference_data = np.column_stack(
        [
            np.random.normal(50, 10, 100),
            np.random.normal(5, 1, 100),
            np.random.normal(25, 5, 100),
        ]
    )
    return simple_model.optimize_weights(reference_data)


@pytest.fixture
def test_data() -> np.ndarray:
    """Create test data for scoring."""
    np.random.seed(123)
    return np.column_stack(
        [
            np.random.normal(50, 15, 50),
            np.random.normal(5, 2, 50),
            np.random.normal(25, 8, 50),
        ]
    )


class TestPlotDesirability:
    """Tests for plot_desirability function."""

    def test_single_feature(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot single feature desirability."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_desirability

        fig = plot_desirability(
            simple_model,
            feature="feature_a",
            data=test_data,
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_all_features(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot all features in grid."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_desirability

        fig = plot_desirability(
            simple_model,
            feature=None,
            data=test_data,
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_invalid_feature(self, simple_model: LikenessModel) -> None:
        """Should raise error for invalid feature."""
        from likeness_maker.viz import plot_desirability

        with pytest.raises(ValueError, match="not found"):
            plot_desirability(simple_model, feature="nonexistent", show=False)

    def test_save_figure(self, simple_model: LikenessModel) -> None:
        """Should save figure to file."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_desirability

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "desirability.png"
            fig = plot_desirability(
                simple_model,
                feature="feature_a",
                savefig=path,
                show=False,
            )
            assert path.exists()
            import matplotlib.pyplot as plt

            plt.close(fig)


class TestPlotScoreDistribution:
    """Tests for plot_score_distribution function."""

    def test_basic_histogram(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot score histogram."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_score_distribution

        scores = simple_model.score(test_data)
        fig = plot_score_distribution(scores, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_with_kde(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot with KDE overlay."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_score_distribution

        scores = simple_model.score(test_data)
        fig = plot_score_distribution(scores, kde=True, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_cumulative(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot cumulative distribution."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_score_distribution

        scores = simple_model.score(test_data)
        fig = plot_score_distribution(scores, cumulative=True, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotScoreComparison:
    """Tests for plot_score_comparison function."""

    def test_multiple_distributions(self) -> None:
        """Should plot overlapping distributions."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_score_comparison

        np.random.seed(42)
        scores_dict = {
            "Group A": np.random.beta(5, 2, 100),
            "Group B": np.random.beta(2, 5, 100),
        }
        fig = plot_score_comparison(scores_dict, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotWeights:
    """Tests for plot_weights function."""

    def test_uniform_weights(self, simple_model: LikenessModel) -> None:
        """Should plot uniform weights."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_weights

        fig = plot_weights(simple_model, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_optimized_weights(self, weighted_model: LikenessModel) -> None:
        """Should plot optimized weights."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_weights

        fig = plot_weights(weighted_model, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_horizontal(self, simple_model: LikenessModel) -> None:
        """Should plot horizontal bars."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_weights

        fig = plot_weights(simple_model, horizontal=True, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotWeightComparison:
    """Tests for plot_weight_comparison function."""

    def test_compare_models(
        self, simple_model: LikenessModel, weighted_model: LikenessModel
    ) -> None:
        """Should compare weights across models."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_weight_comparison

        fig = plot_weight_comparison(
            {"Uniform": simple_model, "Entropy": weighted_model},
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotRadar:
    """Tests for plot_radar function."""

    def test_single_sample(self, simple_model: LikenessModel) -> None:
        """Should plot radar for single sample."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_radar

        sample = np.array([50.0, 5.0, 25.0])
        fig = plot_radar(simple_model, sample, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_multiple_samples(self, simple_model: LikenessModel) -> None:
        """Should plot radar for multiple samples."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_radar

        samples = np.array(
            [
                [50.0, 5.0, 25.0],
                [60.0, 6.0, 30.0],
            ]
        )
        fig = plot_radar(simple_model, samples, show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_aggregate_mean(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot mean aggregated radar."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_radar

        fig = plot_radar(simple_model, test_data, aggregate="mean", show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_aggregate_median(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should plot median aggregated radar."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_radar

        fig = plot_radar(simple_model, test_data, aggregate="median", show=False)
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotRadarComparison:
    """Tests for plot_radar_comparison function."""

    def test_compare_models(
        self,
        simple_model: LikenessModel,
        weighted_model: LikenessModel,
    ) -> None:
        """Should compare desirabilities across models."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_radar_comparison

        sample = np.array([50.0, 5.0, 25.0])
        fig = plot_radar_comparison(
            {"Uniform": simple_model, "Entropy": weighted_model},
            sample,
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotModelComparison:
    """Tests for plot_model_comparison function."""

    def test_compare_two_models(
        self,
        simple_model: LikenessModel,
        weighted_model: LikenessModel,
        test_data: np.ndarray,
    ) -> None:
        """Should create scatter matrix for two models."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_model_comparison

        fig = plot_model_comparison(
            {"Uniform": simple_model, "Entropy": weighted_model},
            test_data,
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)

    def test_single_model_error(self, simple_model: LikenessModel, test_data: np.ndarray) -> None:
        """Should raise error for single model."""
        from likeness_maker.viz import plot_model_comparison

        with pytest.raises(ValueError, match="at least 2"):
            plot_model_comparison({"Single": simple_model}, test_data, show=False)


class TestPlotScoreScatter:
    """Tests for plot_score_scatter function."""

    def test_two_models(
        self,
        simple_model: LikenessModel,
        weighted_model: LikenessModel,
        test_data: np.ndarray,
    ) -> None:
        """Should create scatter plot for two models."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_score_scatter

        fig = plot_score_scatter(
            simple_model,
            weighted_model,
            test_data,
            name1="Uniform",
            name2="Entropy",
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestPlotCorrelationHeatmap:
    """Tests for plot_correlation_heatmap function."""

    def test_heatmap(
        self,
        simple_model: LikenessModel,
        weighted_model: LikenessModel,
        test_data: np.ndarray,
    ) -> None:
        """Should create correlation heatmap."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz import plot_correlation_heatmap

        fig = plot_correlation_heatmap(
            {"Uniform": simple_model, "Entropy": weighted_model},
            test_data,
            show=False,
        )
        assert fig is not None
        import matplotlib.pyplot as plt

        plt.close(fig)


class TestUtilsFunctions:
    """Tests for utility functions."""

    def test_setup_style(self) -> None:
        """Should apply style without error."""
        import matplotlib

        matplotlib.use("Agg")

        from likeness_maker.viz.utils import setup_style

        # Should not raise an error
        setup_style()

    def test_get_color(self) -> None:
        """Should return colors from palette."""
        from likeness_maker.viz.utils import get_color

        # Should return valid hex colors
        assert get_color(0).startswith("#")
        assert get_color(1).startswith("#")

        # Should wrap around
        assert get_color(0) == get_color(8)  # 8 colors in palette


class TestModuleImports:
    """Tests for module-level imports."""

    def test_lazy_imports(self) -> None:
        """Should support lazy imports."""
        from likeness_maker import viz

        assert hasattr(viz, "plot_desirability")
        assert hasattr(viz, "plot_score_distribution")
        assert hasattr(viz, "plot_weights")
        assert hasattr(viz, "plot_radar")
        assert hasattr(viz, "plot_model_comparison")

    def test_all_exports(self) -> None:
        """Should export all public functions."""
        from likeness_maker import viz

        expected = [
            "plot_desirability",
            "plot_score_distribution",
            "plot_score_comparison",
            "plot_weights",
            "plot_weight_comparison",
            "plot_radar",
            "plot_radar_comparison",
            "plot_model_comparison",
            "plot_score_scatter",
            "plot_correlation_heatmap",
        ]
        for name in expected:
            assert name in viz.__all__
