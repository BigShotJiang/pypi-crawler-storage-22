__version__ = "0.1.0"
from .simulator import LineageSim
