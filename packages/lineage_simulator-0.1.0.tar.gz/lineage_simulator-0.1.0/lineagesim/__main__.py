from lineagesim.cli import main

main()
