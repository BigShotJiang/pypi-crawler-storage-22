"""Command-line interface for LineageSim."""

import argparse
import sys
from typing import List, Optional

import anndata as ad
import numpy as np
import pandas as pd

from lineagesim.simulator import LineageSim


def cmd_generate(args: argparse.Namespace) -> None:
    """Run the ``generate`` subcommand."""
    sim = LineageSim(seed=args.seed)
    tree, expression = sim.generate_dataset(
        n_cells=args.n_cells,
        n_genes=args.n_genes,
        n_CIF=args.n_cif,
        sigma=args.sigma,
        beta=args.beta,
        gene_effect_prob=args.gene_effect_prob,
        scale_s=args.scale_s,
        protocol=args.protocol,
        skip_technical_noise=args.skip_technical_noise,
        commit_depth=args.commit_depth,
    )

    nodes = tree["nodes"]
    assert isinstance(nodes, list)
    obs = pd.DataFrame(
        {
            "node_id": [int(n["id"]) for n in nodes],
            "parent": [
                int(n["parent"]) if n["parent"] is not None else -1 for n in nodes
            ],
            "depth": [int(n["depth"]) for n in nodes],
            "fate": [int(n["fate"]) if n["fate"] is not None else -1 for n in nodes],
            "is_leaf": [bool(n["is_leaf"]) for n in nodes],
            "fate_prob": [float(n.get("fate_prob", 0.5)) for n in nodes],
            "committed_count": [int(n.get("committed_count", 0)) for n in nodes],
            "division_time": [float(n["division_time"]) for n in nodes],
        }
    )
    obs.index = pd.Index([str(i) for i in range(len(obs))])

    X = np.asarray(expression, dtype=np.float32)
    adata = ad.AnnData(X=X, obs=obs)
    adata.uns["lineagesim"] = {
        "seed": args.seed,
        "beta": args.beta,
        "sigma": args.sigma,
        "n_CIF": args.n_cif,
        "protocol": args.protocol,
        "commit_depth": args.commit_depth,
        "root_id": int(tree["root_id"]),
        "max_depth": int(tree["max_depth"]),
        "n_cells": int(tree["n_cells"]),
    }

    try:
        ad.settings.allow_write_nullable_strings = True
    except AttributeError:
        pass
    adata.write_h5ad(args.output)
    print(f"\nSaved {adata.shape[0]} cells x {adata.shape[1]} genes → {args.output}")


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        prog="lineagesim",
        description="LineageSim — cell fate trajectory simulator for single-cell lineage tracing data",
    )
    sub = parser.add_subparsers(dest="command")

    gen = sub.add_parser(
        "generate",
        help="Generate a synthetic lineage-traced scRNA-seq dataset",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    gen.add_argument(
        "-o",
        "--output",
        default="lineagesim_output.h5ad",
        help="Output .h5ad file path",
    )
    gen.add_argument("--seed", type=int, default=12, help="Random seed")
    gen.add_argument(
        "--n-cells", type=int, default=8192, help="Number of cells to simulate"
    )
    gen.add_argument(
        "--n-genes", type=int, default=1000, help="Number of genes to simulate"
    )
    gen.add_argument(
        "--n-cif",
        type=int,
        default=32,
        help="Number of Cell Identity Factors (latent dimensions)",
    )
    gen.add_argument(
        "--sigma", type=float, default=0.2, help="Brownian motion noise std dev"
    )
    gen.add_argument(
        "--beta",
        type=float,
        default=0.2,
        help="Fate signal strength",
    )
    gen.add_argument(
        "--gene-effect-prob",
        type=float,
        default=0.3,
        help="Probability that a CIF affects a gene",
    )
    gen.add_argument(
        "--scale-s", type=float, default=1.0, help="Transcription rate scaling factor"
    )
    gen.add_argument(
        "--protocol",
        choices=["UMI", "nonUMI"],
        default="UMI",
        help="Sequencing protocol",
    )
    gen.add_argument(
        "--skip-technical-noise",
        action="store_true",
        help="Return true counts without technical noise",
    )
    gen.add_argument(
        "--commit-depth",
        type=int,
        default=7,
        help="Depth at which fate commitment occurs",
    )

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "generate":
        cmd_generate(args)
