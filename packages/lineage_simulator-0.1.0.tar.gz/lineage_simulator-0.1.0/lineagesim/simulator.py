"""LineageSim: A Single-Cell Lineage Simulator with Fate-Aware Gene Expression."""

from collections import deque
from typing import Dict, List, Tuple, Union

import numpy as np
from scipy.special import expit


# Type definitions
NodeDict = Dict[str, Union[int, float, bool, List[int], None]]
TreeDict = Dict[str, Union[List[NodeDict], int, float]]


class LineageSim:
    # Tree generation
    MAX_DIVISIONS = 25
    MIN_ACTIVE_CELLS = 10
    ADDITIONAL_ACTIVE_CELLS = 20
    MAX_DEPTH_FOR_REACTIVATION = 10

    # Technical noise
    MIN_CAPTURE_RATE = 0.0005
    MIN_SEQUENCING_DEPTH = 200

    def __init__(self, seed: int = 42):
        self.seed = seed
        np.random.seed(seed)

    def generate_phylogenetic_tree(self, n_cells: int) -> TreeDict:
        """
        Generate a realistic lineage tree with variable division timing.
        This creates cells at different depths to simulate temporal sampling.

        Args:
            n_cells: Number of cells to generate

        Returns:
            Dictionary with tree structure and metadata
        """
        print(f"Generating realistic lineage tree for {n_cells} cells")

        # Start with a root cell
        root: NodeDict = {
            "id": 0,
            "parent": None,
            "depth": 0,
            "fate": None,
            "is_leaf": True,
            "division_time": 0.0,
            "children": [],
        }
        tree_nodes: list[NodeDict] = [root]
        active_cells: list[NodeDict] = [root]

        # Simulate cell divisions over time to reach target cell count
        for division_round in range(self.MAX_DIVISIONS):
            if len(tree_nodes) >= n_cells:
                break

            # 1. Adjust division probability based on how many cells we need
            cells_remaining = n_cells - len(tree_nodes)
            cells_that_can_divide = len(active_cells)
            if cells_that_can_divide > 0:
                # Calculate division probability needed to reach target
                target_divisions = min(cells_remaining // 2, cells_that_can_divide)
                base_division_prob = max(
                    0.3, min(0.9, target_divisions / cells_that_can_divide)
                )
            else:
                base_division_prob = 0.5
            # Decrease probability in later rounds to create depth diversity
            division_prob = base_division_prob * max(0.3, 1.0 - division_round * 0.05)

            # 2. Divide cells
            next_active_cells = []
            for cell in active_cells:
                if len(tree_nodes) >= n_cells:
                    break

                if np.random.random() < division_prob:
                    cell["is_leaf"] = False
                    for daughter_idx in range(2):
                        if len(tree_nodes) >= n_cells:
                            break
                        node_id = len(tree_nodes)
                        daughter: NodeDict = {
                            "id": node_id,
                            "parent": cell["id"],
                            "depth": int(cell["depth"]) + 1,  # type: ignore
                            "fate": None,
                            "is_leaf": True,
                            "division_time": division_round + 1,
                            "children": [],
                        }
                        cell["children"].append(node_id)  # type: ignore
                        tree_nodes.append(daughter)
                        next_active_cells.append(daughter)
                else:
                    next_active_cells.append(cell)

            # 3. If we're running low on dividing cells, restart some leaf cells
            # that haven't reached max depth yet
            if (
                len(next_active_cells) < self.MIN_ACTIVE_CELLS
                and len(tree_nodes) < n_cells
            ):
                leaf_cells = [
                    node
                    for node in tree_nodes
                    if node["is_leaf"] and int(node["depth"]) < self.MAX_DEPTH_FOR_REACTIVATION  # type: ignore
                ]
                if leaf_cells:
                    next_active_cells.extend(
                        np.random.choice(
                            leaf_cells,
                            min(self.ADDITIONAL_ACTIVE_CELLS, len(leaf_cells)),
                            replace=False,
                        )
                    )

            active_cells = next_active_cells

            # Stop early if we have enough cells
            if len(tree_nodes) >= n_cells:
                break

        leaf_depths = [int(node["depth"]) for node in tree_nodes if node["is_leaf"]]  # type: ignore
        print(
            f"""\
Generated {len(tree_nodes)} cells
Leaf depths: min={min(leaf_depths)}, max={max(leaf_depths)}, unique={len(set(leaf_depths))}
Depth distribution: {sorted(set(leaf_depths))}"""
        )

        return {
            "nodes": tree_nodes,
            "root_id": int(root["id"]),  # type: ignore
            "max_depth": max(leaf_depths),
            "n_cells": len(tree_nodes),
        }

    def _assign_fate(self, tree, commit_depth: int, frac_one=0.5):
        """
        Partition the tree at commit_depth into disjoint clades and
        probabilistically assign binary fates targeting a ~frac_one split.
        Each cell's assigned fate propagates to all descendants.
        """
        nodes = tree["nodes"]

        # Find clade roots: top-down DFS, stop at commit_depth or at leaves
        clade_roots = []
        stack = [tree["root_id"]]
        while stack:
            node = nodes[stack.pop()]
            if node["is_leaf"] or node["depth"] >= commit_depth:
                clade_roots.append(node["id"])
            else:
                stack.extend(node["children"])

        # Assign fates probabilistically and propagate to all descendants
        clades_by_fate = [0, 0]
        cells_by_fate = [0, 0]
        for clade_root in clade_roots:
            fate = 1 if np.random.random() < frac_one else 0
            clades_by_fate[fate] += 1
            subtree = [clade_root]
            while subtree:
                node = nodes[subtree.pop()]
                node["fate"] = fate
                cells_by_fate[fate] += 1
                subtree.extend(node["children"])

        print(
            f"""Fate commitment: {clades_by_fate[0]}+{clades_by_fate[1]} clades, {cells_by_fate[0]}+{cells_by_fate[1]} cells (fate_0+fate_1)"""
        )

    def _compute_fate_bias(self, tree):
        """Compute fate_prob for each node: fraction of committed descendants with fate 1."""
        nodes = tree["nodes"]

        for node in sorted(nodes, key=lambda n: n["depth"], reverse=True):
            if node["is_leaf"]:
                node["fate_prob"] = float(node["fate"])
                node["committed_count"] = 1
            else:
                children = [nodes[c] for c in node["children"]]
                total = sum(c["committed_count"] for c in children)
                node["committed_count"] = total + (1 if node["fate"] is not None else 0)
                node["fate_prob"] = (
                    float(node["fate"])
                    if node["fate"] is not None  # committed cells
                    else (
                        sum(c["fate_prob"] * c["committed_count"] for c in children)
                        / total
                    )  # pre-commit cell
                )

    def simulate_cell_identity_factors(
        self,
        tree: TreeDict,
        beta: float,
        n_CIF: int,
        sigma: float,
        commit_depth: int,
    ) -> np.ndarray:
        """
        Simulate Cell Identity Factors (CIFs) for ALL tree nodes using Brownian motion.
        This allows us to build true ancestor->descendant trajectories.

        Implements the formula from the paper:
            CIF = CIF_parent + ε + β · M(d) · (2p − 1)

        where ε ~ N(0, σ²) is Brownian noise, β is fate signal strength,
        M(d) is a depth-dependent scaling function, and p is fate probability.

        Args:
            tree: Phylogenetic tree structure
            n_CIF: Number of Cell Identity Factors
            sigma: Standard deviation for Brownian motion (σ in paper)
            beta: Fate signal strength (β in paper). Higher values create more
                distinct expression between cells with different fate biases.
            commit_depth: Depth at which fate commitment occurs (D in paper)

        Returns:
            CIF matrix (n_nodes x n_CIF) for ALL nodes in tree
        """
        nodes = tree["nodes"]
        assert isinstance(nodes, list)
        n_nodes = len(nodes)

        print(
            f"Simulating {n_CIF} Cell Identity Factors for ALL {n_nodes} tree nodes | Sigma: {sigma}, Beta (fate signal strength): {beta}"
        )

        # Initialize CIF matrix
        CIF_matrix = np.zeros((n_nodes, n_CIF))
        root_id = tree["root_id"]
        CIF_matrix[root_id, :] = 1.0  # root CIF is set to all 1s by default

        # BFS
        queue = deque([root_id])
        while queue:
            parent_id = queue.popleft()
            parent_node = nodes[parent_id]

            for child_id in parent_node["children"]:
                child_node = nodes[child_id]

                # Brownian noise: ε ~ N(0, σ²) vectorized across all CIF dims
                epsilon = np.random.normal(0, sigma, size=n_CIF)

                # Fate bias term: β · M(d) · (2p − 1)
                depth_multiplier = self._get_progressive_bias_multiplier(
                    depth=int(child_node["depth"]), commit_depth=commit_depth
                )
                fate_prob = float(child_node["fate_prob"])
                fate_bias = beta * depth_multiplier * (2 * fate_prob - 1)

                # CIF = CIF_parent + ε + fate_bias
                CIF_matrix[child_id] = CIF_matrix[parent_id] + epsilon + fate_bias
                queue.append(child_id)

        return CIF_matrix

    def _get_progressive_bias_multiplier(self, depth: int, commit_depth: int) -> float:
        """
        Get progressive commitment bias multiplier based on depth.

        Progressive commitment model uses relative thresholds based on commit_depth:
        - Depth 0 to ~43% of commit_depth: Weak bias (early commitment)
        - Depth ~43% to commit_depth: Strong bias (intermediate)
        - Depth > commit_depth: Very strong bias (post-commitment)
        """
        early_threshold = int(commit_depth * 3 / 7)  # ~43% of commit_depth

        if depth <= early_threshold:
            # Early commitment - weak predictive signal
            return 0.4
        elif depth <= commit_depth:
            # Intermediate commitment - strong signal
            return 0.8
        else:
            # Post-commitment - very strong signal strength
            return 1.2

    def CIF_to_gene_expression(
        self,
        CIF_matrix: np.ndarray,
        n_genes: int,
        gene_effect_prob: float,
        scale_s: float,
    ) -> np.ndarray:
        """
        Convert Cell Identity Factors to gene expression using kinetic model.
        Uses a 3-parameter kinetic model (kon, koff, s).

        Args:
            CIF_matrix: CIF matrix (n_cells x n_CIF)
            n_genes: Number of genes to simulate
            gene_effect_prob: Probability that a CIF affects a gene
            scale_s: Scaling factor for transcription rate

        Returns:
            True gene expression matrix (n_cells x n_genes) - count data
        """
        n_cells, n_CIF = CIF_matrix.shape
        print(
            f"""Converting CIFs to {n_genes} gene expression using kinetic model
        Gene effect probability: {gene_effect_prob}, Scale s: {scale_s}"""
        )
        # Generate gene effects for 3 kinetic parameters
        gene_effects = self._generate_gene_effects(
            n_genes=n_genes, n_CIF=n_CIF, prob=gene_effect_prob
        )
        # Compute kinetic parameters for each cell-gene combination
        kinetic_params = self._compute_kinetic_parameters(
            CIF_matrix=CIF_matrix, gene_effects=gene_effects, scale_s=scale_s
        )
        # Generate true counts using beta-Poisson model
        true_counts = self._generate_true_counts(kinetic_params=kinetic_params)
        return true_counts

    def _generate_gene_effects(
        self, n_genes: int, n_CIF: int, prob: float
    ) -> List[np.ndarray]:
        """Generate gene effect matrices for kon, koff, s parameters."""
        gene_effects = []
        for _ in range(3):  # kon, koff, s
            mask = np.random.random((n_genes, n_CIF)) < prob
            effects = np.zeros((n_genes, n_CIF))
            effects[mask] = np.random.normal(0, 1.0, size=mask.sum())
            gene_effects.append(effects)
        return gene_effects

    def _compute_kinetic_parameters(
        self, CIF_matrix: np.ndarray, gene_effects: List[np.ndarray], scale_s: float
    ) -> Dict[str, np.ndarray]:
        """Compute kinetic parameters (kon, koff, s) from CIFs and gene effects."""

        # Parameter ranges (log scale)
        param_ranges = {
            "kon": (-2, 2),  # log10 scale
            "koff": (-2, 2),  # log10 scale
            "s": (0, 4),  # log10 scale
        }

        params = {}
        param_names = ["kon", "koff", "s"]

        for i, param_name in enumerate(param_names):
            # Compute raw parameter values: CIF_matrix @ gene_effects[i].T
            raw_params = CIF_matrix @ gene_effects[i].T
            # Convert to parameter range using logistic function
            normalized = expit(raw_params)
            # Scale to parameter range
            min_val, max_val = param_ranges[param_name]
            scaled_params = normalized * (max_val - min_val) + min_val
            # Convert from log scale
            if param_name in ["kon", "koff"]:
                params[param_name] = 10**scaled_params
            else:  # s parameter
                params[param_name] = 10**scaled_params * scale_s
        return params

    def _generate_true_counts(
        self, kinetic_params: Dict[str, np.ndarray]
    ) -> np.ndarray:
        """Generate true gene expression counts using beta-Poisson model."""
        kon = kinetic_params["kon"]
        koff = kinetic_params["koff"]
        s = kinetic_params["s"]

        # Vectorized beta-Poisson: sample activation probabilities, then counts
        p = np.random.beta(kon, koff)
        true_counts = np.random.poisson(p * s)
        return true_counts

    def add_technical_noise(
        self,
        true_counts: np.ndarray,
        protocol: str,
        capture_efficiency_mean: float = 0.1,
        capture_efficiency_sd: float = 0.002,
        pcr_efficiency: float = 0.8,
        n_pcr_cycles: int = 16,
        sequencing_depth_mean: float = 5000,
        sequencing_depth_sd: float = 1000,
    ) -> np.ndarray:
        """
        Add sophisticated technical noise.
        Simulates capture, amplification, and sequencing steps.

        Args:
            true_counts: True gene expression counts
            protocol: Sequencing protocol ("UMI" or "nonUMI")
            capture_efficiency_mean: Mean capture efficiency
            capture_efficiency_sd: SD of capture efficiency
            pcr_efficiency: PCR amplification efficiency
            n_pcr_cycles: Number of PCR cycles
            sequencing_depth_mean: Mean sequencing depth per cell
            sequencing_depth_sd: SD of sequencing depth

        Returns:
            Observed gene expression matrix with technical noise
        """
        n_cells, n_genes = true_counts.shape

        print(f"Adding technical noise using {protocol} protocol")
        print(
            f"Capture efficiency: {capture_efficiency_mean:.3f} ± "
            f"{capture_efficiency_sd:.3f}"
        )

        observed_counts = np.zeros_like(true_counts)

        for cell_idx in range(n_cells):
            # Cell-specific capture efficiency
            capture_rate = self._sample_capture_efficiency(
                mean=capture_efficiency_mean, sd=capture_efficiency_sd
            )
            # Cell-specific sequencing depth
            seq_depth = self._sample_sequencing_depth(
                mean=sequencing_depth_mean, sd=sequencing_depth_sd
            )
            # Simulate technical process for this cell
            cell_observed = self._simulate_cell_technical_process(
                true_counts_cell=true_counts[cell_idx],
                protocol=protocol,
                capture_rate=capture_rate,
                pcr_efficiency=pcr_efficiency,
                n_pcr_cycles=n_pcr_cycles,
                seq_depth=seq_depth,
            )
            observed_counts[cell_idx] = cell_observed

        return observed_counts

    def _sample_capture_efficiency(self, mean: float, sd: float) -> float:
        """Sample capture efficiency with lower bound."""
        rate = np.random.normal(mean, sd)
        return max(rate, self.MIN_CAPTURE_RATE)

    def _sample_sequencing_depth(self, mean: float, sd: float) -> int:
        """Sample sequencing depth with lower bound."""
        depth = int(np.random.normal(mean, sd))
        return max(depth, self.MIN_SEQUENCING_DEPTH)

    def _simulate_cell_technical_process(
        self,
        true_counts_cell: np.ndarray,
        protocol: str,
        capture_rate: float,
        pcr_efficiency: float,
        n_pcr_cycles: int,
        seq_depth: int,
    ) -> np.ndarray:
        """Simulate the complete technical process for one cell."""

        # Step 1: Capture step - binomial sampling
        captured_counts = np.random.binomial(true_counts_cell, capture_rate)

        # Step 2: PCR amplification
        amplified_counts = captured_counts.copy().astype(float)
        for cycle in range(n_pcr_cycles):
            # Each molecule can be amplified with PCR efficiency
            new_molecules = np.random.binomial(
                amplified_counts.astype(int), pcr_efficiency
            )
            amplified_counts += new_molecules

        # Step 3: Sequencing subsampling
        total_molecules = int(np.sum(amplified_counts))
        if total_molecules == 0:
            return np.zeros_like(true_counts_cell)

        if protocol == "UMI":
            # UMI protocol: de-duplicate PCR copies, but still count unique captured molecules
            umi_counts = captured_counts.astype(int)

            total_molecules = int(umi_counts.sum())
            if total_molecules == 0:
                observed_counts = np.zeros_like(true_counts_cell)
            elif total_molecules <= seq_depth:
                # All captured molecules are observed
                observed_counts = umi_counts
            else:
                # Subsample molecules to the sequencing depth
                probs = umi_counts / total_molecules
                observed_counts = np.random.multinomial(seq_depth, probs)
        else:
            # Non-UMI protocol: count all amplified molecules
            if total_molecules <= seq_depth:
                observed_counts = amplified_counts.astype(int)
            else:
                # Multinomial subsampling
                probs = amplified_counts / total_molecules
                observed_counts = np.random.multinomial(seq_depth, probs)
        return observed_counts

    def generate_dataset(
        self,
        n_cells: int = 8192,
        n_genes: int = 3000,
        n_CIF: int = 32,
        sigma: float = 0.2,
        beta: float = 0.2,
        gene_effect_prob: float = 0.3,
        scale_s: float = 1.0,
        protocol: str = "UMI",
        skip_technical_noise: bool = False,
        commit_depth: int = 7,
    ) -> Tuple[TreeDict, np.ndarray]:
        """
        Main entry method for generating data: a lineage tree of cells and their gene expression.

        Args:
            n_cells: Number of cells to simulate
            n_genes: Number of genes to simulate
            n_CIF: Number of Cell Identity Factors (latent dimensions)
            sigma: Standard deviation for Brownian motion noise (σ in paper)
            beta: Fate signal strength (β in paper). Higher values create more
                distinct expression between cells with different fate biases.
            gene_effect_prob: Probability that a CIF affects a gene
            scale_s: Scaling factor for transcription rate
            protocol: Sequencing protocol ("UMI" or "nonUMI")
            skip_technical_noise: If True, return true counts without technical noise
            commit_depth: Depth at which fate commitment occurs (D in paper)

        Returns:
            Tuple of (tree structure, observed gene expression matrix)
        """
        print("=== LineageSim Generation ===")
        print(f"Cells: {n_cells}, Genes: {n_genes}")

        # Phase 1: Tree generation
        tree = self.generate_phylogenetic_tree(n_cells=n_cells)

        # Phase 2: Fate assignment
        self._assign_fate(tree, commit_depth=commit_depth)
        self._compute_fate_bias(tree)

        # Phase 3: CIF simulation (latent representation)
        CIF_matrix = self.simulate_cell_identity_factors(
            tree=tree, beta=beta, n_CIF=n_CIF, sigma=sigma, commit_depth=commit_depth
        )

        # Phase 4: Gene expression readout
        true_counts = self.CIF_to_gene_expression(
            CIF_matrix=CIF_matrix,
            n_genes=n_genes,
            gene_effect_prob=gene_effect_prob,
            scale_s=scale_s,
        )
        if skip_technical_noise:
            print("Skipping technical noise")
            observed_counts = true_counts.astype(float)
        else:
            observed_counts = self.add_technical_noise(
                true_counts=true_counts, protocol=protocol
            )

        return tree, observed_counts
