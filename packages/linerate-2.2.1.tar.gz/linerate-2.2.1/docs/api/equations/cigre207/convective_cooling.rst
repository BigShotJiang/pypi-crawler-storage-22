Convective cooling in CIGRE207
------------------------------

.. automodule:: linerate.equations.cigre207.convective_cooling
    :members:
