Solar heating in CIGRE207
-------------------------

.. automodule:: linerate.equations.cigre207.solar_heating
    :members:
