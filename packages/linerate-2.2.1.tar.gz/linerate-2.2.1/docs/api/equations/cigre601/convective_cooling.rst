Convective cooling in CIGRE601
------------------------------

.. automodule:: linerate.equations.cigre601.convective_cooling
    :members:
