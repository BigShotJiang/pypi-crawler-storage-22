Solar heating in CIGRE601
-------------------------

.. automodule:: linerate.equations.cigre601.solar_heating
    :members:
