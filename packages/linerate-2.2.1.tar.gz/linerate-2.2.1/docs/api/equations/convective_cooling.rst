Convective cooling
------------------

.. automodule:: linerate.equations.convective_cooling
    :members:
