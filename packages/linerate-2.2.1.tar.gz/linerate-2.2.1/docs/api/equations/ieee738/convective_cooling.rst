Convective cooling in IEEE-738
------------------------------

.. automodule:: linerate.equations.ieee738.convective_cooling
    :members:
