Solar heating in IEEE-738
-------------------------

.. automodule:: linerate.equations.ieee738.solar_heating
    :members:
