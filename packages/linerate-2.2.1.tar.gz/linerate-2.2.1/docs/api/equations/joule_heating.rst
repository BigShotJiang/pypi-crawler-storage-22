Joule heating
-------------

.. automodule:: linerate.equations.joule_heating
    :members:
