Mathematical utilities
----------------------

.. automodule:: linerate.equations.math
    :members:
