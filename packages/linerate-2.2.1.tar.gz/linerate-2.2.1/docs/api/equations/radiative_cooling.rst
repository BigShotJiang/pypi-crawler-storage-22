Radiative cooling
-----------------

.. automodule:: linerate.equations.radiative_cooling
    :members:
