Solar angles
-------------

.. automodule:: linerate.equations.solar_angles
    :members:
