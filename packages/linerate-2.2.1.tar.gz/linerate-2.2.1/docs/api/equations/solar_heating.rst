Solar heating
-------------

.. automodule:: linerate.equations.solar_heating
    :members:
