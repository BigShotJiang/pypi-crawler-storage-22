The ``model`` module
--------------------

.. automodule:: linerate.model

.. autoclass:: linerate.model.ThermalModel
    :inherited-members:

.. autoclass:: linerate.model.Cigre601
    :inherited-members:

.. autoclass:: linerate.model.IEEE738
    :inherited-members:

.. autoclass:: linerate.model.Cigre207
    :inherited-members:
