.. _solver:

The ``solver`` module
---------------------

.. automodule:: linerate.solver
    :members:
