The ``types`` module
--------------------

.. automodule:: linerate.types
    :members:
