from .linreg_core import *

__doc__ = linreg_core.__doc__
if hasattr(linreg_core, "__all__"):
    __all__ = linreg_core.__all__