# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-02-02
### Added
- Initial standalone release of lint-gost-tex.
