//! Integration tests for linthis CLI.

mod integration;
