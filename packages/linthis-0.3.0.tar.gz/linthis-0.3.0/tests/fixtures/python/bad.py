import os
import sys
x=1
y =  2
def foo():
    unused_var = 42
    print("hello")
