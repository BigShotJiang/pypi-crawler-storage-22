def foo():print("hello")
x=1
y=2
