// Well-formatted Rust file
fn main() {
    let x = 1;
    let y = 2;
    println!("{}", x + y);
}

fn well_formatted(a: i32, b: i32) -> i32 {
    a + b
}
