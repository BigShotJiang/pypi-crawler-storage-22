// Test file with Oxlint violations

// Unused variable
var unused = 1;

// Using == instead of ===
if (someVar == 2) {
  // Console statement
  console.log("test");
}

// Using var instead of const/let
var oldStyle = "bad";

// debugger statement
debugger;

// Empty function
function empty() {}
