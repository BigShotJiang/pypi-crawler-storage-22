"""Pytest configuration for output/reporting unit tests.

Tests in this directory focus on output manager functionality and report generation
for linting results and tool execution summaries.
"""

# Add any output-specific fixtures here in the future
