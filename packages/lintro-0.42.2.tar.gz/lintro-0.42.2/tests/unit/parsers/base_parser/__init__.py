"""Tests for base_parser utilities."""
