"""Base classes and utilities for tool implementations."""
