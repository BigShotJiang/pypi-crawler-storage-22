function foo(x, y, z) {
  return x + y + z;
}
const obj = { a: 1, b: 2, c: 3 };
