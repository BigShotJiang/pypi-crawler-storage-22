"""Pytest configuration for exception unit tests.

Tests in this directory focus on custom exception handling and error scenarios
in the Lintro codebase.
"""

# Add any exception-specific fixtures here in the future
