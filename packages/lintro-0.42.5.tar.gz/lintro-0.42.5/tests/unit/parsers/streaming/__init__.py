"""Streaming parser tests."""
