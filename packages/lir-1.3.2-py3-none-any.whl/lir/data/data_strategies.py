from collections.abc import Iterable
from enum import Enum

import numpy as np
import sklearn
from sklearn.model_selection import GroupKFold, GroupShuffleSplit, KFold

from lir.data.models import DataStrategy, FeatureData


class BinaryTrainTestSplit(DataStrategy):
    """Representation of a train/test split.

    The input data should have hypothesis labels. This split assigns instances of both classes to the training set and
    the test set.
    """

    def __init__(self, test_size: float | int, seed: int | None = None):
        self.test_size = test_size
        self.seed = seed

    def apply(self, instances: FeatureData) -> Iterable[tuple[FeatureData, FeatureData]]:
        """Allow iteration by looping over the resulting train/test split(s)."""
        indexes = np.arange(len(instances))
        indexes_train, indexes_test = sklearn.model_selection.train_test_split(
            indexes, stratify=instances.labels, test_size=self.test_size, shuffle=True, random_state=self.seed
        )

        yield instances[indexes_train], instances[indexes_test]


class BinaryCrossValidation(DataStrategy):
    """Representation of a K-fold cross validation iterator over each train/test split fold.

    The input data should have class labels. This split assigns instances of both classes to each "fold" subset.

    This method might be referenced in the YAML registry as follows:
    ```
    data_strategies:
      binary_cross_validation: lir.data.data_strategies.BinaryCrossValidation
    ```

    In the benchmark configuration YAML, this validation can be referenced as follows:
    ```
    splits:
      strategy: binary_cross_validation
    ```
    """

    def __init__(self, folds: int, seed: int | None = None):
        self.folds = folds
        self.seed = seed
        self.shuffle = True if self.seed is not None else False  # noqa: SIM210

    def apply(self, instances: FeatureData) -> Iterable[tuple[FeatureData, FeatureData]]:
        """Allow iteration by looping over the resulting train/test split(s)."""
        kf = KFold(n_splits=self.folds, shuffle=self.shuffle, random_state=self.seed)
        for _i, (train_index, test_index) in enumerate(kf.split(instances.features, y=instances.labels)):
            yield instances[train_index], instances[test_index]


class MulticlassTrainTestSplit(DataStrategy):
    """Representation of a multi-class train/test split.

    The input data should have source_ids. This split assigns all instances of a source to either the training set or
    the test set.
    """

    def __init__(self, test_size: float | int, seed: int | None = None):
        self.test_size = test_size
        self.seed = seed

    def apply(self, instances: FeatureData) -> Iterable[tuple[FeatureData, FeatureData]]:
        """Allow iteration by looping over the resulting train/test split(s)."""
        splitter = GroupShuffleSplit(test_size=self.test_size, n_splits=1, random_state=self.seed)
        ((train_index, test_index),) = splitter.split(instances.features, instances.source_ids, instances.source_ids)

        yield instances[train_index], instances[test_index]


class MulticlassCrossValidation(DataStrategy):
    """
    Representation of a K-fold cross validation iterator over train/test splits.

    The input data should have source_ids. This split assigns all instances of a source to the same "fold" subset.

    This method might be referenced in the YAML registry as follows:
    ```
    data_strategies:
      multiclass_cross_validation: lir.data.data_strategies.MulticlassCrossValidation
    ```

    In the benchmark configuration YAML, this validation can be referenced as follows:
    ```
    data:
      [...]
      splits:
        strategy: multiclass_cross_validation
        folds: 5
    ```
    """

    def __init__(self, folds: int):
        self.folds = folds

    def apply(self, instances: FeatureData) -> Iterable[tuple[FeatureData, FeatureData]]:
        """Allow iteration by looping over the resulting train/test split(s)."""
        kf = GroupKFold(n_splits=self.folds)

        for _i, (train_index, test_index) in enumerate(kf.split(instances.features, groups=instances.source_ids)):
            yield instances[train_index], instances[test_index]


class RoleAssignment(Enum):
    """Indicate whether the data is part of the train or the test split."""

    TRAIN = 'train'
    TEST = 'test'


class PredefinedTrainTestSplit(DataStrategy):
    """
    Splits data into a training set and a test set, according to pre-existing assignments in the data.

    Presumes a `role_assignments` field in the data, which has the value "train" for instances that will be part of the
    training set, and "test" for instances in the test set.

    In the benchmark configuration YAML, this validation can be referenced as follows:
    ```
    cross_validation_splits:
        strategy: predefined_train_test_split
        data_origin: ${data}
    ```
    """

    def apply(self, instances: FeatureData) -> Iterable[tuple[FeatureData, FeatureData]]:
        """Split the FeatureData into a train and a test split."""
        if 'role_assignments' not in instances.all_fields:
            raise ValueError('`role_assignments` field is missing')

        training_set = instances[instances.role_assignments == RoleAssignment.TRAIN.value]  # type: ignore
        test_set = instances[instances.role_assignments == RoleAssignment.TEST.value]  # type: ignore
        yield training_set, test_set
