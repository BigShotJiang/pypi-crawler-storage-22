# listele function

Prints the given iterable in a listed format with columns and spacing.

---

```python
listele(li:list|dict, column:int, /, *, spaces:int=30, find:str="", reverse:bool=False)
"""
- li      : An iterable
- column  : Output column number
- spaces  : Spaces between elements
- find    : Filters the output with given string
- reverse : Prints elements top to bottom instead of left to right (disabled by default)
"""
```

```python
# Usage example:

from listele import listele

import sysconfig
li = dir(sysconfig)         # list type object
di = sysconfig.get_paths()  # dict type object

print("Output1:")
listele(li, 4)

print("\n\nOutput2:")
listele(li, 4, find="path")

print("\n\nOutput3:")
listele(di, 2, spaces=70)

print("\n\nOutput4:")
listele(di, 1, find="include")

print("\n\nOutput5:")
listele([1, 2, 3, 4, 5], 3, reverse=True)
```

