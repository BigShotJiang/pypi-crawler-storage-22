* [ ] Change to use ruff
* [ ] Automate the release process via GH actions. [Article](https://simonwillison.net/2024/Jan/16/python-lib-pypi/)

* [] Sort by frecency.
* [] Add completions when an attach database command is run.
* [] Add behave tests.
