# Contributing

```{include} ../CONTRIBUTING.md
```
