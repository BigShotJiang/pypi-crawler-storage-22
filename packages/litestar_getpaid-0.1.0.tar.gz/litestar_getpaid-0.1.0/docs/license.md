# License

```{literalinclude} ../LICENSE
```
