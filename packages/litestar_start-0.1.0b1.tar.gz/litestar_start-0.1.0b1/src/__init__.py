"""Litestar Start - Interactive CLI to scaffold Litestar projects."""

__version__ = "0.1.0b1"
__all__ = ["__version__"]
