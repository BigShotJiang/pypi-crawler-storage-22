# Litmus HD

Litmus HD is a lightweight, production-ready SDK for detecting hallucinations in Large Language Model (LLM) outputs. It uses mathematical projections (Type-I Bivector Projection) on embeddings to verify claims against a provided context.

## Installation

```bash
pip install litmus-hd
```

## Quick Start

```python
from litmus_hd import LitmusDetector

# Initialize detector (loads a small efficient model by default)
detector = LitmusDetector()

# Context (Evidence)
context = "The capital of France is Paris. It is known for the Eiffel Tower."

# Output (Claim to verify)
output = "The capital of France is Berlin."

# Check for hallucinations
result = detector.check(
    context=context,
    output=output
)

print(f"Is Hallucination: {result.is_hallucination}")
print(f"Support Score: {result.score}")
print(f"Details: {result.details}")
```

## LitmusResult Fields

- `is_hallucination` (bool): True if the support score is below the threshold.
- `score` (float): A value between 0 and 1 indicating how well the output is supported by the context. Higher is better.
- `details` (dict): Contains breakdown of scores per sentence/claim.

## How it works

Litmus HD uses a small BERT-based model (MiniLM-L6-v2) to generate embeddings for both the context and the output. It then uses geometric projections in the embedding space to determine if the facts in the output are best represented by the linear subspaces spanned by the context facts.
