import torch
from typing import List, Optional
try:
    from transformers import AutoTokenizer, AutoModel
except ImportError:
    AutoTokenizer = None
    AutoModel = None

class ModelManager:
    """
    Manages loading the transformer model and tokenizer, and generating embeddings.
    """
    def __init__(self, model_name: str = 'sentence-transformers/all-MiniLM-L6-v2', device: str = 'cpu'):
        if AutoTokenizer is None or AutoModel is None:
            raise ImportError("The 'transformers' library is required. Please install it with 'pip install transformers'.")
            
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name).to(self.device)
        self.model.eval()

    def embed_texts(self, texts: List[str]) -> torch.Tensor:
        """
        Embed a list of texts using mean pooling.
        
        Args:
            texts: List of strings to embed.
            
        Returns:
            torch.Tensor of shape (num_texts, embedding_dim)
        """
        if not texts:
            return torch.tensor([]).to(self.device)

        inputs = self.tokenizer(
            texts, padding=True, truncation=True, 
            max_length=512, return_tensors="pt"
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            embeddings = outputs.last_hidden_state
            attention_mask = inputs['attention_mask']
            
            # Mean pooling
            mask_expanded = attention_mask.unsqueeze(-1).expand(
                embeddings.size()
            ).float()
            sum_embeddings = torch.sum(embeddings * mask_expanded, dim=1)
            sum_mask = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
            emb = sum_embeddings / sum_mask
        
        return torch.nn.functional.normalize(emb, p=2, dim=1)
