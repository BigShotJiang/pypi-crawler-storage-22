from typing import Union, List, Optional
from .model_utils import ModelManager
from .math_ops import calculate_bivector_support
from .result import LitmusResult
from .context import LitmusContext
from .output import LitmusOutput

class LitmusDetector:
    """
    High-level detector for hallucinations.
    """
    def __init__(self, model_name: str = 'sentence-transformers/all-MiniLM-L6-v2', threshold: float = 0.7, device: str = 'cpu'):
        self.model_manager = ModelManager(model_name=model_name, device=device)
        self.threshold = threshold

    def check(self, context: Union[str, LitmusContext], output: Union[str, LitmusOutput]) -> LitmusResult:
        """
        Check if the output is supported by the context.
        
        Args:
            context: The context or evidence. Can be a string (will be split into sentences) or LitmusContext.
            output: The output or claims to verify. Can be a string (will be split into sentences) or LitmusOutput.
            
        Returns:
            LitmusResult object containing score and details.
        """
        # Standardize inputs
        if not isinstance(context, LitmusContext):
            context = LitmusContext(context)
        if not isinstance(output, LitmusOutput):
            output = LitmusOutput(output)
            
        evidence_texts = context.sentences
        claim_texts = output.sentences
        
        # Embed
        evidence_embs = self.model_manager.embed_texts(evidence_texts)
        claim_embs = self.model_manager.embed_texts(claim_texts)
        
        if len(claim_embs) == 0:
             return LitmusResult(
                score=1.0, 
                is_hallucination=False, 
                details={'reason': 'No claims found to verify.'}
            )

        # Calculate support for each claim
        results = []
        min_support = 1.0
        
        for i, claim_emb in enumerate(claim_embs):
            claim_text = claim_texts[i]
            res = calculate_bivector_support(claim_emb, evidence_embs, threshold=self.threshold)
            res['claim'] = claim_text
            results.append(res)
            
            if res['support'] < min_support:
                min_support = res['support']
        
        # Aggregation logic: 
        # If any claim is unsupported (below threshold), we flag it.
        # Overall score can be the minimum support score across all claims.
        is_hallucination = min_support < self.threshold
        
        return LitmusResult(
            score=min_support,
            is_hallucination=is_hallucination,
            details={
                'claim_scores': results,
                'threshold': self.threshold
            }
        )
