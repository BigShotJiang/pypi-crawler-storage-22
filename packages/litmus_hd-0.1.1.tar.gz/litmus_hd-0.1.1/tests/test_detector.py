import pytest
import torch
from unittest.mock import MagicMock, patch
from litmus_hd import LitmusDetector, LitmusResult

# Mock ModelManager to avoid loading real models during tests
@pytest.fixture
def mock_model_manager():
    with patch("litmus_hd.detector.ModelManager") as MockManager:
        instance = MockManager.return_value
        # Mock embed_texts to return random tensors of shape (N, 3)
        instance.embed_texts.side_effect = lambda texts: torch.randn(len(texts), 3) if texts else torch.tensor([])
        yield instance

def test_detector_instantiation(mock_model_manager):
    detector = LitmusDetector()
    assert detector is not None

def test_detector_check_structure(mock_model_manager):
    detector = LitmusDetector()
    # Mock return values for embeddings to control the math outcome strictly if needed,
    # or just test structure with random values.
    # Let's mock the actual math return to test the detector logic.
    
    with patch("litmus_hd.detector.calculate_bivector_support") as mock_calc:
        mock_calc.return_value = {
            'support': 0.9,
            'unsupported_score': 0.1,
            'best_pair': (0, 1),
            'method': 'bivector'
        }
        
        result = detector.check("context sentence one. context sentence two.", "claim sentence.")
        
        assert isinstance(result, LitmusResult)
        assert result.score == 0.9
        assert not result.is_hallucination
        assert 'claim_scores' in result.details

def test_detector_hallucination_flag(mock_model_manager):
    detector = LitmusDetector(threshold=0.8)
    
    with patch("litmus_hd.detector.calculate_bivector_support") as mock_calc:
        # Return low support
        mock_calc.return_value = {
            'support': 0.5,
            'unsupported_score': 0.5,
            'best_pair': (0, 1),
            'method': 'bivector'
        }
        
        result = detector.check("context", "claim")
        assert result.is_hallucination is True
