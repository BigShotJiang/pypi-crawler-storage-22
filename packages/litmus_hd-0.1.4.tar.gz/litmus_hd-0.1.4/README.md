# Litmus Hallucination Detector 

Litmus Hallucination Detector is an SDK for detecting hallucinations in Large Language Model (LLM) outputs. It uses geometric algebra on embeddings to verify outputs against a provided context.

## Installation

```bash
pip install litmus-hd
```

## Quick Start

### 1. Context Grounding (Type I - Default)

Checks if claims are supported by the provided context.

```python
from litmus_hd import LitmusDetector

# Initialize grounding detector (default)
detector = LitmusDetector(metric='context-grounding')

context = "The capital of France is Paris."
output = "Paris is the capital of France."

result = detector.check(context=context, output=output)
print(f"Outcome: {'Supported' if not result.is_hallucination else 'Hallucination'}")
print(f"Support Score: {result.score}")
```

**Output:**
```text
Outcome: Supported
Support Score: 1.0
```

### 2. Context Contradiction (Type II)

Checks if claims actively contradict the provided context.

```python
# Initialize contradiction detector
detector = LitmusDetector(metric='context-contradiction')

context = ["Revenue increased 15%."]
output = ["Revenue decreased 15%."]

result = detector.check(context=context, output=output)
print(f"Is Hallucination: {result.is_hallucination}")
print(f"Contradiction Score: {result.score}")
```

**Output:**
```text
Is Hallucination: True
Contradiction Score: 0.9998
```

### 3. Relational Inversion (Type III)

Detects if the logical relationship between entities is flipped or if there's a direct contradiction/negation.

```python
# Initialize relational inversion detector
detector = LitmusDetector(metric='relational-inversion')

context = ["Alice hired Bob."]
output = ["Bob hired Alice."] # Relational Inversion

result = detector.check(context=context, output=output)
print(f"Status: {result.details['claim_scores'][0]['type']}")
```

**Output:**
```text
Status: Relational Inversion
```

### 4. Unified All Metric (`metric='all'`)

Runs all metrics in a hierarchical sequence (Type I -> Type III) and returns the first detected hallucination.

```python
# Initialize unified detector
detector = LitmusDetector(metric='all')

context = "The cat caught the mouse."
output = "The mouse caught the cat."

result = detector.check(context=context, output=output)
print(f"Status: {result.details['claim_scores'][0]['status']}")
print(f"Type: {result.details['claim_scores'][0]['type']}")
```

**Output:**
```text
Status: Hallucination
Type: Relational Inversion
```

## Metrics

| Metric | Type | Model | Description |
|--------|------|-------|-------------|
| `context-grounding` | Type I | `all-MiniLM-L6-v2` | Checks if claims are *supported* by evidence. |
| `context-contradiction` | Type II | `nli-deberta-v3-base` | Checks if claims *contradict* evidence. |
| `relational-inversion` | Type III | `nli-deberta-v3-base` | Checks for *entity inversions* or *contradictions*. |
| `all` | Aggregate | Multiple | Hierarchical check (Type I -> Type III). |

## How it works

Litmus HD uses mathematical projections to verify claims:
- **Type I** projects embeddings onto the subspace spanned by context facts.
- **Type II** projects cross-encoded pairs onto a contradiction discriminant.
- **Type III** compares projection magnitudes on specialized Inversion vs. Contradiction subspaces.

## License

This project is licensed under the MIT License

