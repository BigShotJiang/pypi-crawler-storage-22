import os
import logging

# Suppress warnings
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import Union, List, Optional
from .model_utils import ModelManager
from .result import LitmusResult
from .context import LitmusContext
from .output import LitmusOutput
from .strategies import get_strategy_class

class LitmusDetector:
    """
    High-level detector for hallucinations.
    Supports multiple metrics via strategy pattern.
    """
    def __init__(self, 
                 metric: str = 'context-grounding',
                 model_name: Optional[str] = None, 
                 threshold: Optional[float] = None, 
                 device: str = 'cpu'):
        
        self.metric = metric
        self.device = device
        self.threshold = threshold
        self.model_name = model_name
        
        # Cache for sub-detectors used in 'all' metric
        self._sub_detectors = {}
        
        if metric != 'all':
            self._setup_single_strategy(metric, model_name, threshold, device)

    def _setup_single_strategy(self, metric, model_name, threshold, device):
        if metric == 'context-grounding':
            m_name = model_name or 'sentence-transformers/all-MiniLM-L6-v2'
            thresh = threshold if threshold is not None else 0.7
            m_type = 'bi-encoder'
        elif metric in ['context-contradiction', 'relational-inversion']:
            m_name = model_name or 'cross-encoder/nli-deberta-v3-base'
            thresh = threshold if threshold is not None else (0.5 if metric == 'relational-inversion' else 0.3)
            m_type = 'cross-encoder'
        else:
            raise ValueError(f"Unsupported metric: {metric}")

        self.threshold = thresh
        self.model_manager = ModelManager(
            model_name=m_name, 
            device=device,
            model_type=m_type
        )
        
        StrategyClass = get_strategy_class(metric)
        self.strategy = StrategyClass(self.model_manager, threshold=thresh)

    def check(self, context: Union[str, LitmusContext, List[str]], output: Union[str, LitmusOutput, List[str]]) -> LitmusResult:
        """
        Check if the output is supported by the context.
        """
        # Standardize inputs
        if isinstance(context, str):
            context = LitmusContext(context)
        elif isinstance(context, list):
            context = LitmusContext(context)
            
        if isinstance(output, str):
            output = LitmusOutput(output)
        elif isinstance(output, list):
            output = LitmusOutput(output)
            
        evidence_texts = context.sentences
        claim_texts = output.sentences
        
        if self.metric == 'all':
            return self._check_all(evidence_texts, claim_texts)
        
        # Delegate to strategy
        raw_result = self.strategy.detect(evidence_texts, claim_texts)
        return LitmusResult(
            score=raw_result['score'],
            is_hallucination=raw_result['is_hallucination'],
            details=raw_result['details']
        )

    def _get_sub_detector(self, metric):
        if metric not in self._sub_detectors:
            # We pass the device and model_name if provided, otherwise let it use defaults
            self._sub_detectors[metric] = LitmusDetector(metric=metric, device=self.device)
        return self._sub_detectors[metric]

    def _check_all(self, evidence, claims) -> LitmusResult:
        """
        Hierarchical check: Type I -> Type III
        """
        det_ground = self._get_sub_detector('context-grounding')
        det_inv = self._get_sub_detector('relational-inversion')
        
        res_ground = det_ground.check(evidence, claims)
        
        # If Grounding detected hallucinations, we might stop or combine.
        # Requirement: First Type I, if found -> result. Otherwise Type III.
        
        if res_ground.is_hallucination:
            # Format details for 'all' metric consistency
            claim_scores = []
            for r in res_ground.details['claim_scores']:
                claim_scores.append({
                    'claim': r['claim'],
                    'status': 'Hallucination' if r['support'] < det_ground.threshold else 'Not Hallucination',
                    'type': 'Context Grounding Failure' if r['support'] < det_ground.threshold else 'None',
                    'score': r['support']
                })
            return LitmusResult(
                score=res_ground.score,
                is_hallucination=True,
                details={
                    'claim_scores': claim_scores,
                    'metric': 'all',
                    'primary_metric': 'context-grounding'
                }
            )
            
        # If Type I says OK, check Type III
        res_inv = det_inv.check(evidence, claims)
        
        claim_scores = []
        for r in res_inv.details['claim_scores']:
            status = 'Hallucination' if r['is_hallucination'] else 'Not Hallucination'
            h_type = r['type'] if r['is_hallucination'] else 'None'
            claim_scores.append({
                'claim': r['claim'],
                'status': status,
                'type': h_type,
                'score': r['score']
            })
            
        return LitmusResult(
            score=res_inv.score,
            is_hallucination=res_inv.is_hallucination,
            details={
                'claim_scores': claim_scores,
                'metric': 'all',
                'primary_metric': 'relational-inversion'
            }
        )


