import os
import logging

# Suppress HF Hub warning
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1" 

import torch
from typing import List, Optional
try:
    from transformers import AutoTokenizer, AutoModel, logging as transformers_logging
    # Suppress detailed loading logs
    transformers_logging.set_verbosity_error()
except ImportError:
    AutoTokenizer = None
    AutoModel = None

class ModelManager:
    """
    Manages loading transformer models and tokenizers.
    Supports both bi-encoders (for embeddings) and cross-encoders (for classification).
    """
    def __init__(self, model_name: str, device: str = 'cpu', model_type: str = 'bi-encoder'):
        if AutoTokenizer is None or AutoModel is None:
            raise ImportError("The 'transformers' library is required. Please install it with 'pip install transformers'.")
            
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        if model_type == 'cross-encoder':
            from transformers import AutoModelForSequenceClassification
            self.model = AutoModelForSequenceClassification.from_pretrained(model_name).to(self.device)
        else:
            self.model = AutoModel.from_pretrained(model_name).to(self.device)
            
        self.model.eval()
        self.model_type = model_type

    def embed_texts(self, texts: List[str]) -> torch.Tensor:
        """
        Embed a list of texts using mean pooling (Bi-encoder only).
        """
        if self.model_type != 'bi-encoder':
             raise ValueError("embed_texts is only available for bi-encoder models.")

        if not texts:
            return torch.tensor([]).to(self.device)

        inputs = self.tokenizer(
            texts, padding=True, truncation=True, 
            max_length=512, return_tensors="pt"
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            embeddings = outputs.last_hidden_state
            attention_mask = inputs['attention_mask']
            
            # Mean pooling
            mask_expanded = attention_mask.unsqueeze(-1).expand(
                embeddings.size()
            ).float()
            sum_embeddings = torch.sum(embeddings * mask_expanded, dim=1)
            sum_mask = torch.clamp(mask_expanded.sum(dim=1), min=1e-9)
            emb = sum_embeddings / sum_mask
        
        return torch.nn.functional.normalize(emb, p=2, dim=1)


    def get_pooled_embedding(self, text1: str, text2: str) -> torch.Tensor:
        """
        Get the pooled embedding for a pair of texts (Cross-encoder only).
        Captures the input to the classifier head.
        """
        if self.model_type != 'cross-encoder':
             raise ValueError("get_pooled_embedding is only available for cross-encoder models.")

        # Hook to capture features
        features = {}
        def hook_fn(module, input, output):
            features['pooled'] = input[0].detach()
        
        # Register hook on the classifier layer
        hook = self.model.classifier.register_forward_hook(hook_fn)
        
        inputs = self.tokenizer(
            text1, text2,
            return_tensors="pt", 
            padding=True, 
            truncation=True
        ).to(self.device)
        
        with torch.no_grad():
            _ = self.model(**inputs)
            
        hook.remove()
        return features['pooled'].squeeze()

    def get_probs(self, text1: str, text2: str) -> torch.Tensor:
        """
        Get classification probabilities for a pair.
        """
        if self.model_type != 'cross-encoder':
             raise ValueError("get_probs is available only for cross-encoder models.")

        inputs = self.tokenizer(
            text1, text2,
            return_tensors="pt", 
            padding=True, 
            truncation=True
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
            probs = torch.nn.functional.softmax(logits, dim=-1).squeeze()
            
        return probs
