import os
import logging

# Suppress warnings
os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN_WARNING"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from typing import Union, List, Optional
from .model_utils import ModelManager
from .result import LitmusResult
from .context import LitmusContext
from .output import LitmusOutput
from .strategies import get_strategy_class

class LitmusDetector:
    """
    High-level detector for hallucinations.
    Supports multiple metrics via strategy pattern.
    """
    def __init__(self, 
                 metric: str = 'context-grounding',
                 model_name: Optional[str] = None, 
                 threshold: Optional[float] = None, 
                 device: str = 'cpu'):
        
        self.metric = metric
        self.device = device
        self.threshold = threshold
        self.model_name = model_name
        
        self._setup_single_strategy(metric, model_name, threshold, device)

    def _setup_single_strategy(self, metric, model_name, threshold, device):
        if metric == 'context-grounding':
            m_name = model_name or 'sentence-transformers/all-MiniLM-L6-v2'
            thresh = threshold if threshold is not None else 0.7
            m_type = 'bi-encoder'
        elif metric in ['context-contradiction', 'relational-inversion']:
            m_name = model_name or 'cross-encoder/nli-deberta-v3-base'
            thresh = threshold if threshold is not None else (0.5 if metric == 'relational-inversion' else 0.3)
            m_type = 'cross-encoder'
        elif metric == 'instruction-drift':
            m_name = model_name or 'sentence-transformers/all-MiniLM-L6-v2'
            thresh = threshold if threshold is not None else 0.3
            m_type = 'bi-encoder'
        else:
            raise ValueError(f"Unsupported metric: {metric}")

        self.threshold = thresh
        self.model_manager = ModelManager(
            model_name=m_name, 
            device=device,
            model_type=m_type
        )
        
        StrategyClass = get_strategy_class(metric)
        self.strategy = StrategyClass(self.model_manager, threshold=thresh)

    def check(self, 
              context: Union[str, LitmusContext, List[str]], 
              output: Union[str, LitmusOutput, List[str]],
              query: Optional[str] = None,
              threshold: Optional[float] = None) -> LitmusResult:
        """
        Check if the output is supported by the context.
        
        For instruction-drift metric, query parameter is required.
        
        Args:
            context: The context/evidence to check against
            output: The output/claims to verify
            query: Required for instruction-drift metric
            threshold: Optional threshold override (0.0 to 1.0)
        """
        # Validate query for instruction-drift
        if self.metric == 'instruction-drift' and query is None:
            raise ValueError("query parameter is required for instruction-drift metric")
        
        # Validate threshold if provided
        if threshold is not None:
            if not (0.0 <= threshold <= 1.0):
                raise ValueError("threshold must be between 0.0 and 1.0 inclusive")
            # Temporarily update strategy threshold
            original_threshold = self.strategy.threshold
            self.strategy.threshold = threshold
        
        # Standardize inputs
        if isinstance(context, str):
            context = LitmusContext(context)
        elif isinstance(context, list):
            context = LitmusContext(context)
            
        if isinstance(output, str):
            output = LitmusOutput(output)
        elif isinstance(output, list):
            output = LitmusOutput(output)
            
        evidence_texts = context.sentences
        claim_texts = output.sentences
        
        # Delegate to strategy
        if self.metric == 'instruction-drift':
            raw_result = self.strategy.detect(query, evidence_texts, claim_texts)
        else:
            raw_result = self.strategy.detect(evidence_texts, claim_texts)
        
        # Restore original threshold if we temporarily changed it
        if threshold is not None:
            self.strategy.threshold = original_threshold
            
        return LitmusResult(
            score=raw_result['score'],
            is_hallucination=raw_result['is_hallucination'],
            details=raw_result['details']
        )


