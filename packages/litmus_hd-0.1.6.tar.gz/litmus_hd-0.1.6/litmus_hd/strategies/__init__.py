from .grounding import ContextGroundingStrategy
from .contradiction import ContextContradictionStrategy
from .inversion import RelationalInversionStrategy
from .drift import InstructionDriftStrategy

STRATEGIES = {
    'context-grounding': ContextGroundingStrategy,
    'context-contradiction': ContextContradictionStrategy,
    'relational-inversion': RelationalInversionStrategy,
    'instruction-drift': InstructionDriftStrategy
}

def get_strategy_class(metric: str):
    if metric not in STRATEGIES:
        raise ValueError(f"Unknown metric '{metric}'. Available metrics: {list(STRATEGIES.keys())}")
    return STRATEGIES[metric]
