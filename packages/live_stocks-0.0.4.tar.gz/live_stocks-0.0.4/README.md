# Live Stocks

This package can get the current price and graph cryto and stocks.

This package includes functions to get the current price of popular crypto and stocks. This package also includes symbol to name and name to symbol.

Usage:

To get the current price of a crypto that is not present in the pre-defined functions, use `get_crypto_price(symbol=...)`

To get the current price of a stock that is not present in the pre-defined functions, use `get_stock_price(symbol=...)`

To draw the graph for a crypto that is not present in the pre-defined functions, use `draw_graph(price_func=lambda: get_crypto_price(symbol=...), stock_name=..., max_points=..., update_time=..., show_timestamps=...)`

To draw the graph for a stock that is not present in the pre-defined functions, use `draw_graph(price_func=lambda: get_stock_price(symbol=...), stock_name=..., max_points=..., update_time=..., show_timestamps=...)`

To get the name of a stock/crypto symbol use `name_to_symbol(company_name=..., autocorrect=...)`

To get the stock/crypto symbol from the stock/crypto name use `symbol_to_name(company_name=..., autocorrect=...)`.

Versions:

Version 0.0.1: Base code with primary functions added.

Version 0.0.2: Documentation for crypto functions added and more parameters for draw_graph.

Version 0.0.3: Documentation for stock functions added.

(Latest) Version 0.0.4: Symbol -> Stock/Crypto name, Stock/Crypto name -> Symbol.

Version 0.0.5: Add getting and graphing the history of a stock/crypto.
