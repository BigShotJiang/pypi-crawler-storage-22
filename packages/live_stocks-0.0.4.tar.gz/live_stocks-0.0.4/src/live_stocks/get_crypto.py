import websocket
import json
import time
import threading
from decimal import Decimal

def get_crypto_price(symbol: str) -> float:
    """
    Gets the live crypto price for a symbol.

    :param symbol: Symbol must be in the form Symbol-Currency such as BTC-USD

    :return float: The value of the crypto at the time the function is called.
    """
    price_data = {"value": None}

    def on_message(ws, message):
        try:
            data = json.loads(message)
            if "price" in data:
                price_data["value"] = float(data["price"])
                ws.close()
        except Exception:
            pass

    def on_open(ws):
        subscribe_message = {
            "type": "subscribe",
            "channels": [{"name": "ticker", "product_ids": [symbol]}]
        }
        ws.send(json.dumps(subscribe_message))

    ws = websocket.WebSocketApp(
        "wss://ws-feed.exchange.coinbase.com",
        on_message=on_message,
        on_open=on_open
    )

    wst = threading.Thread(target=ws.run_forever, daemon=True)
    wst.start()

    timeout = Decimal(time.time()) + Decimal("10")
    while price_data["value"] is None and Decimal(time.time()) < timeout:
        time.sleep(0.1)

    return price_data["value"]
