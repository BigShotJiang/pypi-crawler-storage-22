import yfinance as yf

def get_stock_price(symbol: str) -> float:
    """
    Gets the current stock price from a symbol

    :param symbol: The symbol of the stock

    :return float: The current price of the symbol
    """
    try:
        ticker = yf.Ticker(symbol)
        data = ticker.history(period="1d", interval="1m")
        if not data.empty:
            return round(data["Close"].iloc[-1], 2)
        else:
            print(f"No data found for {symbol}")
            return None
    except Exception as e:
        print(f"Error fetching stock price for {symbol}: {e}")
        return None
