import yfinance as yf
from enum import Enum
from matplotlib import pyplot as plt

def _plot_points_with_lines(points, stock_name, length):
    plt.cla()
    if not points:
        return

    x_vals, y_vals = zip(*points)
    plt.plot(x_vals, y_vals, color='blue', linestyle='-', linewidth=2, label=f'{stock_name} Price ({length})')

    if len(x_vals) >= 3:
        mid_index = len(x_vals) // 2
        tick_positions = [x_vals[0], x_vals[mid_index], x_vals[-1]]
        tick_labels = [str(x_vals[0]), str(x_vals[mid_index]), str(x_vals[-1])]
        plt.xticks(tick_positions, tick_labels)
    else:
        plt.xticks(x_vals, [str(x) for x in x_vals])

    plt.title(f"{stock_name} Price (USD)")
    plt.xlabel("Time")
    plt.ylabel("Price (USD)")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.pause(0.1)

class lengths(Enum):
    ONE_DAY = "1d"
    FIVE_DAYS = "5d"
    ONE_MONTH = "1mo"
    THREE_MONTHS = "3mo"
    SIX_MONTHS = "6mo"
    ONE_YEAR = "1y"
    TWO_YEARS = "2y"
    FIVE_YEARS = "5y"
    TEN_YEARS = "10y"
    YEAR_TO_DATE = "ytd"
    ALL = "max"

class intervals(Enum):
    ONE_MINUTE = "1m"
    TWO_MINUTES = "2m"
    FIVE_MINUTES = "5m"
    FIFTEEN_MINUTES = "15m"
    THIRTY_MINUTES = "30m"
    HALF_AN_HOUR = "30m"
    ONE_HOUR = "1h"
    NINETY_MINUTES = "90m"
    FOUR_HOURS = "4h"
    ONE_DAY = "1d"
    FIVE_DAYS = "5d"
    ONE_WEEK = "1wk"
    ONE_MONTH = "1mo"
    THREE_MONTHS = "3mo"

def get_history(symbol: str, length = lengths.ONE_DAY, interval = intervals.ONE_MINUTE):
    ticker = yf.Ticker(symbol)
    data = ticker.history(period=length, interval=interval)["Open"]
    dictionary = data.to_dict()
    return_dict = {}
    values = list(dictionary.values())
    keys = list(map(lambda x: str(x).removesuffix("-05:00"), dictionary.keys()))
    for i in range(len(values)):
        return_dict[keys[i]] = values[i]

    return return_dict

def graph_history(symbol: str, length = "10y", interval = "1mo", live=False):
    def get_points():
        history = get_history(symbol, length, interval)
        points = []
        for timestamp, price in history.items():
            points.append((timestamp, price))
        return points

    if not live:
        points = get_points()

    while True:
        if live:
            points = get_points()
        _plot_points_with_lines(points, "TSLA", length)