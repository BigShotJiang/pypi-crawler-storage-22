from .data_models import (
    BasicResult
)