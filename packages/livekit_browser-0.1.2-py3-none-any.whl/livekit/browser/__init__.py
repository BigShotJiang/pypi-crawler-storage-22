"""CEF (Chromium Embedded Framework) bindings for LiveKit.

Install the engine with ``livekit.browser.download()`` and then create a
``BrowserContext`` to render web pages off-screen.
"""

from .proc import AudioData, BrowserContext, BrowserPage, PaintData
from .download import download, get_resources_dir
from .version import __version__

__all__ = [
    "AudioData",
    "BrowserContext",
    "BrowserPage",
    "PaintData",
    "download",
    "get_resources_dir",
]
