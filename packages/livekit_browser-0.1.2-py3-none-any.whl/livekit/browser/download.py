from __future__ import annotations

import logging
import os
import platform
import sys
import tarfile
import urllib.request
from pathlib import Path

from .version import __version__

logger = logging.getLogger("livekit.browser")

_GITHUB_RELEASE_URL = (
    "https://github.com/livekit/agents/releases/download"
    "/browser-v{version}/lkcef-{platform}.tar.gz"
)


def _detect_platform() -> str:
    system = sys.platform
    machine = platform.machine().lower()

    if system.startswith("darwin"):
        return "macos_arm64" if machine == "arm64" else "macos_x64"
    elif system.startswith("linux"):
        if machine in ("aarch64", "arm64"):
            return "linux_arm64"
        return "linux_x64"
    else:
        raise RuntimeError(f"Unsupported platform: {system} {machine}")


def _default_cache_dir() -> Path:
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "livekit" / "browser"
    return Path.home() / ".cache" / "livekit" / "browser"


def download(*, version: str | None = None, dest: Path | None = None) -> Path:
    """Download CEF binaries for the current platform from GitHub Releases.

    Args:
        version: Version to download. Defaults to this package's version.
        dest: Destination directory. Defaults to ~/.cache/livekit/browser/<version>/<platform>/.

    Returns:
        Path to the directory containing the downloaded binaries.
    """
    if version is None:
        version = __version__

    plat = _detect_platform()

    if dest is None:
        dest = _default_cache_dir() / version / plat

    marker = dest / ".downloaded"
    if marker.exists():
        logger.debug("CEF binaries already downloaded at %s", dest)
        return dest

    url = _GITHUB_RELEASE_URL.format(version=version, platform=plat)
    logger.info("Downloading CEF binaries from %s", url)

    dest.mkdir(parents=True, exist_ok=True)

    tarball = dest / "lkcef.tar.gz"
    try:
        urllib.request.urlretrieve(url, tarball)

        with tarfile.open(tarball, "r:gz") as tf:
            tf.extractall(path=dest)

        marker.touch()
        logger.info("CEF binaries downloaded to %s", dest)
    finally:
        tarball.unlink(missing_ok=True)

    return dest


def get_resources_dir(*, version: str | None = None) -> Path:
    """Return path to downloaded CEF resources.

    Raises:
        FileNotFoundError: If CEF binaries have not been downloaded yet.
    """
    if version is None:
        version = __version__

    plat = _detect_platform()
    dest = _default_cache_dir() / version / plat
    marker = dest / ".downloaded"

    if not marker.exists():
        raise FileNotFoundError(
            f"CEF binaries not found at {dest}. "
            f"Run `livekit.browser.download()` or `python -m livekit.browser.download` first."
        )

    return dest
