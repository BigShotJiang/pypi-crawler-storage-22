import io
from dataclasses import dataclass, field
from typing import ClassVar

import numpy as np

from livekit.agents.ipc import channel

# Max frame dimensions for shared memory buffer
# Increase these if you need larger browser windows
SHM_MAX_WIDTH = 3840  # 4K width
SHM_MAX_HEIGHT = 2160  # 4K height



@dataclass
class InitializeContextRequest:
    MSG_ID: ClassVar[int] = 0
    dev_mode: bool = False
    remote_debugging_port: int = 0
    root_cache_path: str = ""

    def write(self, b: io.BytesIO) -> None:
        channel.write_bool(b, self.dev_mode)
        channel.write_int(b, self.remote_debugging_port)
        channel.write_string(b, self.root_cache_path)

    def read(self, b: io.BytesIO) -> None:
        self.dev_mode = channel.read_bool(b)
        self.remote_debugging_port = channel.read_int(b)
        self.root_cache_path = channel.read_string(b)


@dataclass
class ContextInitializedResponse:
    MSG_ID: ClassVar[int] = 1


@dataclass
class CreateBrowserRequest:
    MSG_ID: ClassVar[int] = 2
    page_id: int = -1
    url: str = ""
    framerate: int = 0
    width: int = 0
    height: int = 0
    shm_names: list[str] = field(default_factory=list)

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_string(b, self.url)
        channel.write_int(b, self.framerate)
        channel.write_int(b, self.width)
        channel.write_int(b, self.height)
        channel.write_int(b, len(self.shm_names))
        for name in self.shm_names:
            channel.write_string(b, name)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.url = channel.read_string(b)
        self.framerate = channel.read_int(b)
        self.width = channel.read_int(b)
        self.height = channel.read_int(b)
        num_shm = channel.read_int(b)
        self.shm_names = []
        for _ in range(num_shm):
            self.shm_names.append(channel.read_string(b))


@dataclass
class CreateBrowserResponse:
    """
    This is going to wait for the created_callback to be called.
    (The create_browser function will be async)
    """

    MSG_ID: ClassVar[int] = 3
    page_id: int = -1
    browser_id: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.browser_id)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.browser_id = channel.read_int(b)


@dataclass
class AcquirePaintData:
    MSG_ID: ClassVar[int] = 4
    page_id: int = -1
    buffer_id: int = 0
    width: int = 0
    height: int = 0
    dirty_rects: list[tuple[int, int, int, int]] = field(default_factory=list)

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.buffer_id)
        channel.write_int(b, self.width)
        channel.write_int(b, self.height)
        channel.write_int(b, len(self.dirty_rects))
        for rect in self.dirty_rects:
            channel.write_int(b, rect[0])
            channel.write_int(b, rect[1])
            channel.write_int(b, rect[2])
            channel.write_int(b, rect[3])

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.buffer_id = channel.read_int(b)
        self.width = channel.read_int(b)
        self.height = channel.read_int(b)
        num_rects = channel.read_int(b)
        self.dirty_rects = []
        for _ in range(num_rects):
            x = channel.read_int(b)
            y = channel.read_int(b)
            width = channel.read_int(b)
            height = channel.read_int(b)
            self.dirty_rects.append((x, y, width, height))


@dataclass
class ReleasePaintData:
    MSG_ID: ClassVar[int] = 5
    page_id: int = -1
    buffer_id: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.buffer_id)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.buffer_id = channel.read_int(b)


@dataclass
class CloseBrowserRequest:
    MSG_ID: ClassVar[int] = 6
    page_id: int = -1

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)


@dataclass
class BrowserClosed:
    MSG_ID: ClassVar[int] = 7
    page_id: int = -1

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)


@dataclass
class AudioStreamStarted:
    MSG_ID: ClassVar[int] = 8
    page_id: int = -1
    sample_rate: int = 0
    channels: int = 0
    frames_per_buffer: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.sample_rate)
        channel.write_int(b, self.channels)
        channel.write_int(b, self.frames_per_buffer)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.sample_rate = channel.read_int(b)
        self.channels = channel.read_int(b)
        self.frames_per_buffer = channel.read_int(b)


@dataclass
class AudioStreamStopped:
    MSG_ID: ClassVar[int] = 9
    page_id: int = -1

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)


@dataclass
class AcquireAudioData:
    MSG_ID: ClassVar[int] = 10
    page_id: int = -1
    sample_rate: int = 0
    channels: int = 0
    frames: int = 0
    pts: int = 0
    data: bytes = b""

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.sample_rate)
        channel.write_int(b, self.channels)
        channel.write_int(b, self.frames)
        channel.write_long(b, self.pts)
        channel.write_bytes(b, self.data)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.sample_rate = channel.read_int(b)
        self.channels = channel.read_int(b)
        self.frames = channel.read_int(b)
        self.pts = channel.read_long(b)
        self.data = channel.read_bytes(b)


@dataclass
class SendMouseMoveEvent:
    MSG_ID: ClassVar[int] = 11
    page_id: int = -1
    x: int = 0
    y: int = 0
    mouse_leave: bool = False

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.x)
        channel.write_int(b, self.y)
        channel.write_bool(b, self.mouse_leave)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.x = channel.read_int(b)
        self.y = channel.read_int(b)
        self.mouse_leave = channel.read_bool(b)


@dataclass
class SendMouseClickEvent:
    MSG_ID: ClassVar[int] = 12
    page_id: int = -1
    x: int = 0
    y: int = 0
    button_type: int = 0
    mouse_up: bool = False
    click_count: int = 1

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.x)
        channel.write_int(b, self.y)
        channel.write_int(b, self.button_type)
        channel.write_bool(b, self.mouse_up)
        channel.write_int(b, self.click_count)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.x = channel.read_int(b)
        self.y = channel.read_int(b)
        self.button_type = channel.read_int(b)
        self.mouse_up = channel.read_bool(b)
        self.click_count = channel.read_int(b)


@dataclass
class SendMouseWheelEvent:
    MSG_ID: ClassVar[int] = 13
    page_id: int = -1
    x: int = 0
    y: int = 0
    delta_x: int = 0
    delta_y: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.x)
        channel.write_int(b, self.y)
        channel.write_int(b, self.delta_x)
        channel.write_int(b, self.delta_y)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.x = channel.read_int(b)
        self.y = channel.read_int(b)
        self.delta_x = channel.read_int(b)
        self.delta_y = channel.read_int(b)


@dataclass
class SendKeyEvent:
    MSG_ID: ClassVar[int] = 14
    page_id: int = -1
    type: int = 0
    modifiers: int = 0
    windows_key_code: int = 0
    native_key_code: int = 0
    character: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.type)
        channel.write_int(b, self.modifiers)
        channel.write_int(b, self.windows_key_code)
        channel.write_int(b, self.native_key_code)
        channel.write_int(b, self.character)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.type = channel.read_int(b)
        self.modifiers = channel.read_int(b)
        self.windows_key_code = channel.read_int(b)
        self.native_key_code = channel.read_int(b)
        self.character = channel.read_int(b)


@dataclass
class SendFocusEvent:
    MSG_ID: ClassVar[int] = 15
    page_id: int = -1
    set_focus: bool = True

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_bool(b, self.set_focus)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.set_focus = channel.read_bool(b)


@dataclass
class CursorChanged:
    MSG_ID: ClassVar[int] = 16
    page_id: int = -1
    cursor_type: int = 0

    def write(self, b: io.BytesIO) -> None:
        channel.write_int(b, self.page_id)
        channel.write_int(b, self.cursor_type)

    def read(self, b: io.BytesIO) -> None:
        self.page_id = channel.read_int(b)
        self.cursor_type = channel.read_int(b)


IPC_MESSAGES = {
    InitializeContextRequest.MSG_ID: InitializeContextRequest,
    ContextInitializedResponse.MSG_ID: ContextInitializedResponse,
    CreateBrowserRequest.MSG_ID: CreateBrowserRequest,
    CreateBrowserResponse.MSG_ID: CreateBrowserResponse,
    AcquirePaintData.MSG_ID: AcquirePaintData,
    ReleasePaintData.MSG_ID: ReleasePaintData,
    CloseBrowserRequest.MSG_ID: CloseBrowserRequest,
    BrowserClosed.MSG_ID: BrowserClosed,
    AudioStreamStarted.MSG_ID: AudioStreamStarted,
    AudioStreamStopped.MSG_ID: AudioStreamStopped,
    AcquireAudioData.MSG_ID: AcquireAudioData,
    SendMouseMoveEvent.MSG_ID: SendMouseMoveEvent,
    SendMouseClickEvent.MSG_ID: SendMouseClickEvent,
    SendMouseWheelEvent.MSG_ID: SendMouseWheelEvent,
    SendKeyEvent.MSG_ID: SendKeyEvent,
    SendFocusEvent.MSG_ID: SendFocusEvent,
    CursorChanged.MSG_ID: CursorChanged,
}


def copy_paint_data(
    acq: AcquirePaintData,
    old_width: int,
    old_height: int,
    source: memoryview,
    dest: memoryview,
):
    # Validate frame dimensions fit in SHM buffer
    if acq.width > SHM_MAX_WIDTH or acq.height > SHM_MAX_HEIGHT:
        raise ValueError(
            f"Frame size {acq.width}x{acq.height} exceeds max {SHM_MAX_WIDTH}x{SHM_MAX_HEIGHT}"
        )

    dirty_rects = acq.dirty_rects

    source_arr = np.ndarray(
        (acq.height, acq.width),
        dtype=np.uint32,
        buffer=source,
    )
    dest_arr = np.ndarray(
        (acq.height, acq.width),
        dtype=np.uint32,
        buffer=dest,
    )

    has_fullscreen_rect = len(dirty_rects) == 1 and dirty_rects[0] == (
        0,
        0,
        acq.width,
        acq.height,
    )
    if old_width != acq.width or old_height != acq.height or has_fullscreen_rect:
        np.copyto(dest_arr, source_arr)
    else:
        for rect in dirty_rects:
            x, y, w, h = rect
            dest_arr[y : y + h, x : x + w] = source_arr[y : y + h, x : x + w]
