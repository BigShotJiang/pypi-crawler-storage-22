"""Version information for llama-cpp-py-sync."""

__version__ = "0.8067"
__llama_cpp_commit__ = "ff4affb4c"
__llama_cpp_tag__ = "b8067"
