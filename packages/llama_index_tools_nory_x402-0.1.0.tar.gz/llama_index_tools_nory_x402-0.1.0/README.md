# Nory x402 Payment Tools for LlamaIndex

Enable your LlamaIndex AI agents to make blockchain payments using the x402 HTTP payment protocol.

## Features

- **Multi-chain support**: Solana and 7 EVM chains (Base, Polygon, Arbitrum, Optimism, Avalanche, Sei, IoTeX)
- **Sub-400ms settlement**: Fast payment finality for real-time agent interactions
- **x402 HTTP protocol**: Native support for HTTP 402 Payment Required responses
- **Simple integration**: Drop-in tool spec for any LlamaIndex agent

## Installation

```bash
pip install llama-index-tools-nory-x402
```

## Quick Start

```python
from llama_index.agent.openai import OpenAIAgent
from llama_index_tools_nory_x402 import NoryX402ToolSpec

# Create the tool spec
tool_spec = NoryX402ToolSpec()

# Create an agent with payment capabilities
agent = OpenAIAgent.from_tools(tool_spec.to_tool_list())

# Use the agent
response = agent.chat("Check if the Nory payment service is healthy")
print(response)
```

## Available Tools

### `get_payment_requirements`

Get x402 payment requirements for accessing a paid resource.

```python
requirements = tool_spec.get_payment_requirements(
    resource="/api/premium/data",
    amount="0.10",  # $0.10 USDC
    network="solana-mainnet"
)
```

### `verify_payment`

Verify a signed payment transaction before settlement.

```python
result = tool_spec.verify_payment(payload="base64-encoded-payload")
```

### `settle_payment`

Settle a payment on-chain with ~400ms settlement time.

```python
result = tool_spec.settle_payment(payload="base64-encoded-payload")
```

### `lookup_transaction`

Look up transaction status.

```python
status = tool_spec.lookup_transaction(
    transaction_id="tx-signature",
    network="solana-mainnet"
)
```

### `health_check`

Check Nory service health and see supported networks.

```python
health = tool_spec.health_check()
```

## Supported Networks

| Network | Chain Type |
|---------|------------|
| `solana-mainnet` | Solana |
| `solana-devnet` | Solana (testnet) |
| `base-mainnet` | EVM (Base) |
| `polygon-mainnet` | EVM (Polygon) |
| `arbitrum-mainnet` | EVM (Arbitrum) |
| `optimism-mainnet` | EVM (Optimism) |
| `avalanche-mainnet` | EVM (Avalanche) |
| `sei-mainnet` | EVM (Sei) |
| `iotex-mainnet` | EVM (IoTeX) |

## Authentication

For public endpoints, no API key is required. For authenticated endpoints:

```python
tool_spec = NoryX402ToolSpec(api_key="your-api-key")
```

## How It Works

1. Your agent encounters an HTTP 402 Payment Required response
2. Use `get_payment_requirements` to learn how much to pay
3. Sign and encode the payment transaction (client-side)
4. Use `verify_payment` to validate before submission
5. Use `settle_payment` to execute the payment on-chain
6. Access the paid resource with the payment receipt

## Links

- [Nory](https://noryx402.com) - Payment infrastructure for AI agents
- [x402 Protocol](https://www.x402.org/) - HTTP payment protocol specification
- [LlamaIndex](https://www.llamaindex.ai/) - Data framework for LLM applications

## License

MIT
