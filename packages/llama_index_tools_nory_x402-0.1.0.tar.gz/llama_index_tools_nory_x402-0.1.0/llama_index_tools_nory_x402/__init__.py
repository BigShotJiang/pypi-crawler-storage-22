"""Nory x402 Payment Tools for LlamaIndex.

This package provides tools for AI agents to make payments using the x402 HTTP protocol.
Supports Solana and 7 EVM chains with sub-400ms settlement.

Example:
    ```python
    from llama_index.agent import OpenAIAgent
    from llama_index_tools_nory_x402 import NoryX402ToolSpec

    # Create the tool spec
    tool_spec = NoryX402ToolSpec(api_key="optional-api-key")

    # Create an agent with the tools
    agent = OpenAIAgent.from_tools(tool_spec.to_tool_list())

    # Use the agent
    response = agent.chat("Check if the Nory payment service is healthy")
    ```
"""

from llama_index_tools_nory_x402.base import NoryX402ToolSpec

__all__ = ["NoryX402ToolSpec"]
__version__ = "0.1.0"
