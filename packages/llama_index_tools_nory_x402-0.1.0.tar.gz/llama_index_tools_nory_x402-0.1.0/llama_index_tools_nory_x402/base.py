"""Nory x402 Payment Tool Spec for LlamaIndex.

Tools for AI agents to make payments using the x402 HTTP protocol.
Supports Solana and 7 EVM chains with sub-400ms settlement.
"""

import json
from typing import Dict, List, Literal, Optional

import requests
from llama_index.core.tools.tool_spec.base import BaseToolSpec

NORY_API_BASE = "https://noryx402.com"

NoryNetwork = Literal[
    "solana-mainnet",
    "solana-devnet",
    "base-mainnet",
    "polygon-mainnet",
    "arbitrum-mainnet",
    "optimism-mainnet",
    "avalanche-mainnet",
    "sei-mainnet",
    "iotex-mainnet",
]


class NoryX402ToolSpec(BaseToolSpec):
    """Tool spec for making payments using the x402 HTTP protocol via Nory.

    Nory provides payment infrastructure for AI agents, supporting Solana and
    7 EVM chains (Base, Polygon, Arbitrum, Optimism, Avalanche, Sei, IoTeX)
    with sub-400ms settlement times.

    Use these tools when encountering HTTP 402 Payment Required responses.

    Args:
        api_key: Nory API key (optional for public endpoints).

    Example:
        ```python
        from llama_index.agent import OpenAIAgent
        from llama_index_tools_nory_x402 import NoryX402ToolSpec

        tool_spec = NoryX402ToolSpec()
        agent = OpenAIAgent.from_tools(tool_spec.to_tool_list())
        response = agent.chat("Check if Nory payment service is healthy")
        ```
    """

    spec_functions: List[str] = [
        "get_payment_requirements",
        "verify_payment",
        "settle_payment",
        "lookup_transaction",
        "health_check",
    ]

    def __init__(self, api_key: Optional[str] = None) -> None:
        """Initialize the Nory x402 tool spec.

        Args:
            api_key: Nory API key (optional for public endpoints).
        """
        self.api_key = api_key

    def _get_headers(self, content_type: bool = False) -> Dict[str, str]:
        """Get request headers with optional auth."""
        headers: Dict[str, str] = {}
        if content_type:
            headers["Content-Type"] = "application/json"
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def get_payment_requirements(
        self,
        resource: str,
        amount: str,
        network: Optional[str] = None,
    ) -> str:
        """Get x402 payment requirements for accessing a paid resource.

        Use this when you encounter an HTTP 402 Payment Required response
        and need to know how much to pay and where to send payment.

        Args:
            resource: The resource path requiring payment (e.g., /api/premium/data).
            amount: Amount in human-readable format (e.g., '0.10' for $0.10 USDC).
            network: Preferred blockchain network. Options: solana-mainnet,
                solana-devnet, base-mainnet, polygon-mainnet, arbitrum-mainnet,
                optimism-mainnet, avalanche-mainnet, sei-mainnet, iotex-mainnet.

        Returns:
            JSON string with payment requirements including amount, supported networks,
            and wallet address.
        """
        params: Dict[str, str] = {"resource": resource, "amount": amount}
        if network:
            params["network"] = network

        response = requests.get(
            f"{NORY_API_BASE}/api/x402/requirements",
            params=params,
            headers=self._get_headers(),
            timeout=30,
        )
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)

    def verify_payment(self, payload: str) -> str:
        """Verify a signed payment transaction before settlement.

        Use this to validate that a payment transaction is correct
        before submitting it to the blockchain.

        Args:
            payload: Base64-encoded payment payload containing signed transaction.

        Returns:
            JSON string with verification result including validity and payer info.
        """
        response = requests.post(
            f"{NORY_API_BASE}/api/x402/verify",
            json={"payload": payload},
            headers=self._get_headers(content_type=True),
            timeout=30,
        )
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)

    def settle_payment(self, payload: str) -> str:
        """Settle a payment on-chain with ~400ms settlement time.

        Use this to submit a verified payment transaction to the blockchain.
        Settlement typically completes in under 400ms.

        Args:
            payload: Base64-encoded payment payload.

        Returns:
            JSON string with settlement result including transaction ID and network.
        """
        response = requests.post(
            f"{NORY_API_BASE}/api/x402/settle",
            json={"payload": payload},
            headers=self._get_headers(content_type=True),
            timeout=30,
        )
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)

    def lookup_transaction(self, transaction_id: str, network: str) -> str:
        """Look up transaction status.

        Use this to check the status of a previously submitted payment
        including confirmations and current state.

        Args:
            transaction_id: Transaction ID or signature.
            network: Network where the transaction was submitted. Options:
                solana-mainnet, solana-devnet, base-mainnet, polygon-mainnet,
                arbitrum-mainnet, optimism-mainnet, avalanche-mainnet,
                sei-mainnet, iotex-mainnet.

        Returns:
            JSON string with transaction status (pending, confirmed, failed)
            and confirmations.
        """
        response = requests.get(
            f"{NORY_API_BASE}/api/x402/transactions/{transaction_id}",
            params={"network": network},
            headers=self._get_headers(),
            timeout=30,
        )
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)

    def health_check(self) -> str:
        """Check Nory service health and see supported networks.

        Use this to verify the payment service is operational
        before attempting payments.

        Returns:
            JSON string with health status and list of supported blockchain networks.
        """
        response = requests.get(
            f"{NORY_API_BASE}/api/x402/health",
            timeout=30,
        )
        response.raise_for_status()
        return json.dumps(response.json(), indent=2)
