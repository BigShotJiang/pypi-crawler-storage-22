import pytest

from llg3d import main, solvers


def test_parse_args():
    args = main.parse_args(["--N", "100"])
    assert args.N == 100


@pytest.mark.xfail(
    not solvers.LIB_AVAILABLE["mpi4py"], reason="mpi4py is not installed"
)
def test_main_mpi(cli_args: list[str]):
    cli_args.extend(["--solver", "mpi"])
    main.main(cli_args)


@pytest.mark.mpi_skip()
def test_main_numpy(cli_args: list[str]):
    cli_args.extend(["--solver", "numpy"])
    main.main(cli_args)


@pytest.mark.xfail(
    not solvers.LIB_AVAILABLE["pyopencl"], reason="pyopencl is not installed"
)
@pytest.mark.mpi_skip()
def test_main_opencl(cli_args: list[str]):
    if "Cobalt" not in cli_args:
        pytest.xfail("OpenCL test only valid for Cobalt element.")
    if "single" not in cli_args:
        pytest.xfail("OpenCL test only valid for single precision.")
    cli_args.extend(["--solver", "opencl"])
    main.main(cli_args)


@pytest.mark.jax
@pytest.mark.xfail(not solvers.LIB_AVAILABLE["jax"], reason="jax is not installed")
@pytest.mark.mpi_skip()
def test_main_jax(cli_args: list[str]):
    cli_args.extend(["--solver", "jax"])
    main.main(cli_args)
