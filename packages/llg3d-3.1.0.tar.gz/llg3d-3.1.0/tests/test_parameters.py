from llg3d import solvers
from llg3d.parameters import DEFAULT_RUN_PARAMETERS, RunParameters


def test_get_default_parameters():
    assert isinstance(DEFAULT_RUN_PARAMETERS, RunParameters)
    assert DEFAULT_RUN_PARAMETERS.element == "Cobalt"
    assert DEFAULT_RUN_PARAMETERS.precision == "double"
    assert DEFAULT_RUN_PARAMETERS.solver == "numpy" if solvers.size == 1 else "mpi"
    assert DEFAULT_RUN_PARAMETERS.N == 5000


def test_str_parameter():
    d = {
        "element": "Cobalt",
        "N": 500,
        "dt": 1e-14,
        "Jx": 300,
        "Jy": 21,
        "Jz": 21,
        "dx": 1e-09,
        "T": 1100,
        "H_ext": 0.0,
        "start_averaging": 2000,
        "n_mean": 1,
        "n_profile": 100,
        "blocking": True,
        "solver": "numpy",
    }
    expected = f"""\
element         : Cobalt
N               = 500
dt              = 1e-14
Jx              = 300
Jy              = 21
Jz              = 21
dx              = 1e-09
T               = 1100
H_ext           = 0.0
init_type       : 0
result_file     : run.npz
start_averaging = 2000
n_mean          = 1
n_profile       = 100
solver          : numpy
precision       : double
blocking        = True
seed            = 12345
device          : auto
profiling       = False
np              = {solvers.size}
"""
    assert str(RunParameters(**d)) == expected
