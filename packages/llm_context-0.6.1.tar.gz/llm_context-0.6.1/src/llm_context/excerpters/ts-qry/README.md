# Credits

Many of these query files were originally based on the tags.scm files from https://github.com/paul-gauthier/aider - licensed under the Apache 2.0 license.