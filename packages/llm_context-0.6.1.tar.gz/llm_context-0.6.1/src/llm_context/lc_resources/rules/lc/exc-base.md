---
description: Base excerpt mode mappings and default configurations
excerpt-modes:
  "*.py": code-outliner
  "*.js": code-outliner
  "*.ts": code-outliner
  "*.jsx": code-outliner
  "*.tsx": code-outliner
  "*.java": code-outliner
  "*.cpp": code-outliner
  "*.c": code-outliner
  "*.cs": code-outliner
  "*.go": code-outliner
  "*.rs": code-outliner
  "*.rb": code-outliner
  "*.php": code-outliner
  "*.ex": code-outliner
  "*.elm": code-outliner
  "*.svelte": sfc
  "*.md": markdown
excerpt-config:
  sfc:
    with-style: false
    with-template: false
excerpt-config:
  markdown:
    with-code-blocks: true
    with-lists: true
    with-tables: true
    with-blockquotes: true
    with-thematic-breaks: true
---
