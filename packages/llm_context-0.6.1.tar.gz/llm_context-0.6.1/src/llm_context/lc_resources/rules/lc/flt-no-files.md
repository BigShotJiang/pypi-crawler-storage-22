---
description: Excludes all files from both full and outline selections. Use for minimal project contexts that include only metadata or notes, ideal for high-level planning.
compose:
  filters: [lc/flt-no-full, lc/flt-no-outline]
---
