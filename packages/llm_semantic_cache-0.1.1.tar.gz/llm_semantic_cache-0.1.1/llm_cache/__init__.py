"""LLM Cache - Multi-tier caching platform for LLM embeddings and semantic search.

This package provides:
- Multi-tier caching (Local HNSW → Redis → Vector DB)
- Semantic search with configurable embeddings
- Chat memory with conversation history
- Graph-based conversation indexing (optional)

Quick Start:
    >>> from llm_cache import QueryService, ChatMemory, CacheConfig
    >>> 
    >>> # Initialize query service
    >>> service = QueryService()
    >>> results = await service.query("What is machine learning?")
    >>> 
    >>> # Or use chat memory
    >>> memory = ChatMemory()
    >>> await memory.add_message("user", "Hello!")
    >>> context = await memory.get_relevant_context("How are you?")

Installation:
    pip install llm-cache
    pip install llm-cache[openai]    # With OpenAI support
    pip install llm-cache[graph]     # With Neo4j graph support
    pip install llm-cache[all]       # All optional dependencies
"""

__version__ = "0.1.0"
__author__ = "Saptarshi Borgohain"
__email__ = "saptarshi@llmcache.dev"

# Core configuration
from llm_cache.config import (
    CacheConfig,
    HNSWConfig,
    RedisConfig,
    FaissConfig,
    EmbeddingConfig,
    load_config,
)

# Main services
from llm_cache.query_service import QueryService
from llm_cache.chat_memory import ChatMemory
from llm_cache.embedder import (
    Embedder,
    SentenceTransformerEmbedder,
    MockEmbedder,
    create_embedder,
)

# Cache layers
from llm_cache.cache.local_hnsw import LocalHNSWCache
from llm_cache.cache.redis_cache import RedisCache

# Storage adapters
from llm_cache.storage.vector_db_interface import VectorDBAdapter
from llm_cache.storage.faiss_adapter import FaissAdapter

# Utilities
from llm_cache.keys import query_key, content_fingerprint

__all__ = [
    # Version info
    "__version__",
    "__author__",
    # Configuration
    "CacheConfig",
    "HNSWConfig", 
    "RedisConfig",
    "FaissConfig",
    "EmbeddingConfig",
    "load_config",
    # Services
    "QueryService",
    "ChatMemory",
    # Embedders
    "Embedder",
    "SentenceTransformerEmbedder",
    "MockEmbedder",
    "create_embedder",
    # Cache
    "LocalHNSWCache",
    "RedisCache",
    # Storage
    "VectorDBAdapter",
    "FaissAdapter",
    # Utils
    "query_key",
    "content_fingerprint",
]
