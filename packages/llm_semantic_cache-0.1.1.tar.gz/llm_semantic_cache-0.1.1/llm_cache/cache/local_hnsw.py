"""Local HNSW cache implementation using hnswlib.

This module provides a wrapper around hnswlib for fast in-memory approximate
nearest neighbor search. Used as Tier A (hot cache) in the caching hierarchy.

Features:
- Fast KNN queries (~1-5ms)
- Configurable HNSW parameters (M, ef_construction, ef_search)
- LRU-style eviction when cache is full
- Persistent snapshots
"""

import logging
import pickle
from pathlib import Path
from typing import Optional

import hnswlib
import numpy as np

logger = logging.getLogger(__name__)


class LocalHNSWCache:
    """Local HNSW index for hot cache queries.
    
    Wraps hnswlib to provide fast approximate nearest neighbor search
    for frequently accessed queries.
    
    Attributes:
        dimension: Vector dimension
        max_elements: Maximum number of vectors to store
        M: HNSW M parameter (connections per node)
        ef_construction: HNSW construction parameter
        ef_search: HNSW search parameter
        space: Distance metric ('l2', 'cosine', 'ip')
        index: hnswlib Index object
    """
    
    def __init__(
        self,
        dimension: int,
        max_elements: int = 10_000,
        M: int = 16,
        ef_construction: int = 200,
        ef_search: int = 50,
        space: str = "l2",
    ):
        """Initialize local HNSW cache.
        
        Args:
            dimension: Vector dimension
            max_elements: Maximum cache size (evict when full)
            M: Number of bi-directional links per node
            ef_construction: Construction-time parameter (higher = better quality)
            ef_search: Search-time parameter (higher = better recall)
            space: Distance metric ('l2', 'cosine', 'ip')
        """
        self.dimension = dimension
        self.max_elements = max_elements
        self.M = M
        self.ef_construction = ef_construction
        self.ef_search = ef_search
        self.space = space
        
        # Create index
        self.index = hnswlib.Index(space=space, dim=dimension)
        self.index.init_index(
            max_elements=max_elements,
            ef_construction=ef_construction,
            M=M,
        )
        self.index.set_ef(ef_search)
        
        # Track IDs and access counts for eviction
        self.id_to_internal: dict[str, int] = {}
        self.internal_to_id: dict[int, str] = {}
        self.access_counts: dict[str, int] = {}
        self.next_internal_id = 0
        
        logger.info(
            f"Initialized LocalHNSWCache: dim={dimension}, max={max_elements}, "
            f"M={M}, space={space}"
        )
    
    def add_items(
        self,
        ids: list[str],
        vectors: np.ndarray,
    ) -> None:
        """Add or update vectors in the cache.
        
        Args:
            ids: List of document IDs
            vectors: Array of vectors, shape (len(ids), dimension)
        """
        if len(ids) != len(vectors):
            raise ValueError(
                f"Length mismatch: {len(ids)} ids vs {len(vectors)} vectors"
            )
        
        # Check if we need to evict
        current_count = self.index.get_current_count()
        new_unique_ids = [id for id in ids if id not in self.id_to_internal]
        
        if current_count + len(new_unique_ids) > self.max_elements:
            # Need to evict least popular items
            num_to_evict = current_count + len(new_unique_ids) - self.max_elements
            self._evict_items(num_to_evict)
        
        # Add items
        internal_ids = []
        for doc_id in ids:
            if doc_id in self.id_to_internal:
                # Update existing
                internal_id = self.id_to_internal[doc_id]
            else:
                # Add new
                internal_id = self.next_internal_id
                self.id_to_internal[doc_id] = internal_id
                self.internal_to_id[internal_id] = doc_id
                self.access_counts[doc_id] = 0
                self.next_internal_id += 1
            
            internal_ids.append(internal_id)
        
        # Add to HNSW index
        self.index.add_items(vectors, internal_ids)
        
        logger.debug(f"Added {len(ids)} items to local HNSW cache")
    
    def knn_query(
        self,
        vector: np.ndarray,
        k: int = 5,
    ) -> list[tuple[str, float]]:
        """Query for k nearest neighbors.
        
        Args:
            vector: Query vector
            k: Number of neighbors
            
        Returns:
            List of (doc_id, distance) tuples
        """
        if self.index.get_current_count() == 0:
            return []
        
        # Ensure 2D
        if vector.ndim == 1:
            vector = vector.reshape(1, -1)
        
        # Query
        k = min(k, self.index.get_current_count())
        internal_ids, distances = self.index.knn_query(vector, k=k)
        
        # Convert to doc IDs and update access counts
        results = []
        for internal_id, distance in zip(internal_ids[0], distances[0]):
            if internal_id in self.internal_to_id:
                doc_id = self.internal_to_id[internal_id]
                self.access_counts[doc_id] += 1
                results.append((doc_id, float(distance)))
        
        logger.debug(f"HNSW query returned {len(results)} results")
        return results
    
    def get(self, doc_id: str) -> Optional[np.ndarray]:
        """Get vector by ID (if cached).
        
        Args:
            doc_id: Document ID
            
        Returns:
            Vector if found, None otherwise
        """
        if doc_id not in self.id_to_internal:
            return None
        
        internal_id = self.id_to_internal[doc_id]
        
        try:
            # Get vector by ID (not all hnswlib versions support this)
            vector = self.index.get_items([internal_id])[0]
            self.access_counts[doc_id] += 1
            return vector
        except Exception:
            return None
    
    def contains(self, doc_id: str) -> bool:
        """Check if document is in cache.
        
        Args:
            doc_id: Document ID
            
        Returns:
            True if cached
        """
        return doc_id in self.id_to_internal
    
    def _evict_items(self, num_to_evict: int) -> None:
        """Evict least popular items from cache.
        
        Args:
            num_to_evict: Number of items to evict
        """
        # TODO: Production-safe eviction requires rebuilding index
        # For now, evict least accessed items and mark as deleted
        
        # Sort by access count
        sorted_ids = sorted(
            self.access_counts.items(),
            key=lambda x: x[1]
        )
        
        evicted = 0
        for doc_id, _ in sorted_ids:
            if evicted >= num_to_evict:
                break
            
            # Remove from mappings
            if doc_id in self.id_to_internal:
                internal_id = self.id_to_internal[doc_id]
                del self.id_to_internal[doc_id]
                del self.internal_to_id[internal_id]
                del self.access_counts[doc_id]
                evicted += 1
        
        logger.info(f"Evicted {evicted} items from HNSW cache")
        
        # Note: Actual vector deletion from hnswlib index requires rebuild
        # In production, periodically rebuild index with remaining items
    
    def count(self) -> int:
        """Get number of items in cache.
        
        Returns:
            Item count
        """
        return self.index.get_current_count()
    
    def clear(self) -> None:
        """Clear all items from cache."""
        self.index = hnswlib.Index(space=self.space, dim=self.dimension)
        self.index.init_index(
            max_elements=self.max_elements,
            ef_construction=self.ef_construction,
            M=self.M,
        )
        self.index.set_ef(self.ef_search)
        
        self.id_to_internal.clear()
        self.internal_to_id.clear()
        self.access_counts.clear()
        self.next_internal_id = 0
        
        logger.info("Cleared HNSW cache")
    
    def save(self, path: str) -> None:
        """Save index and mappings to disk.
        
        Args:
            path: Path to save
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save HNSW index
        index_path = str(path.with_suffix(".hnsw"))
        self.index.save_index(index_path)
        
        # Save mappings
        meta_path = str(path.with_suffix(".meta"))
        with open(meta_path, "wb") as f:
            pickle.dump({
                "id_to_internal": self.id_to_internal,
                "internal_to_id": self.internal_to_id,
                "access_counts": self.access_counts,
                "next_internal_id": self.next_internal_id,
            }, f)
        
        logger.info(f"Saved HNSW cache to {index_path}")
    
    def load(self, path: str) -> None:
        """Load index and mappings from disk.
        
        Args:
            path: Path to load from
        """
        path = Path(path)
        
        # Load HNSW index
        index_path = str(path.with_suffix(".hnsw"))
        self.index.load_index(index_path, max_elements=self.max_elements)
        self.index.set_ef(self.ef_search)
        
        # Load mappings
        meta_path = str(path.with_suffix(".meta"))
        with open(meta_path, "rb") as f:
            data = pickle.load(f)
        
        self.id_to_internal = data["id_to_internal"]
        self.internal_to_id = data["internal_to_id"]
        self.access_counts = data["access_counts"]
        self.next_internal_id = data["next_internal_id"]
        
        logger.info(f"Loaded HNSW cache from {index_path} ({self.count()} items)")
