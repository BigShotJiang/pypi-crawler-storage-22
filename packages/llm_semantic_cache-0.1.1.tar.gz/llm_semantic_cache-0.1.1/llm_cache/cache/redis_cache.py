"""Redis cache layer for distributed query result caching.

This module implements Tier B (Redis cache-aside) in the caching hierarchy.
Stores cached query results and document metadata with TTL-based eviction.
"""

import json
import logging
from typing import Optional

import redis

logger = logging.getLogger(__name__)


class RedisCache:
    """Redis cache for query results and document metadata.
    
    Implements cache-aside pattern with separate namespaces for:
    - Query results: cache:query:{query_key} -> list of results
    - Document metadata: meta:doc:{doc_id} -> metadata dict
    
    Attributes:
        client: Redis client instance
        ttl_seconds: Default TTL for cached entries
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        ttl_seconds: int = 3600,
        max_connections: int = 10,
        socket_timeout: int = 5,
    ):
        """Initialize Redis cache.
        
        Args:
            host: Redis server hostname
            port: Redis server port
            db: Redis database number
            password: Redis password (optional)
            ttl_seconds: Default TTL for cache entries
            max_connections: Connection pool size
            socket_timeout: Socket timeout in seconds
        """
        self.ttl_seconds = ttl_seconds
        
        # Create connection pool
        pool = redis.ConnectionPool(
            host=host,
            port=port,
            db=db,
            password=password,
            max_connections=max_connections,
            socket_timeout=socket_timeout,
            socket_connect_timeout=socket_timeout,
            decode_responses=True,  # Auto-decode bytes to strings
        )
        
        self.client = redis.Redis(connection_pool=pool)
        
        # Test connection
        try:
            self.client.ping()
            logger.info(f"Connected to Redis: {host}:{port}, db={db}")
        except redis.ConnectionError as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    def get_query_cache(self, query_key: str) -> Optional[list[dict]]:
        """Get cached query results.
        
        Args:
            query_key: Query key (from keys.query_key())
            
        Returns:
            List of result dicts if cached, None otherwise
            
        Example result format:
            [
                {"id": "doc1", "score": 0.95, "text": "..."},
                {"id": "doc2", "score": 0.89, "text": "..."},
            ]
        """
        cache_key = f"cache:query:{query_key}"
        
        try:
            cached = self.client.get(cache_key)
            if cached:
                logger.debug(f"Redis cache HIT: {query_key[:16]}...")
                return json.loads(cached)
            else:
                logger.debug(f"Redis cache MISS: {query_key[:16]}...")
                return None
        except (redis.RedisError, json.JSONDecodeError) as e:
            logger.error(f"Redis get error: {e}")
            return None
    
    def set_query_cache(
        self,
        query_key: str,
        results: list[dict],
        ttl: Optional[int] = None,
    ) -> bool:
        """Set cached query results.
        
        Args:
            query_key: Query key
            results: List of result dicts
            ttl: TTL in seconds (uses default if None)
            
        Returns:
            True if successful
        """
        cache_key = f"cache:query:{query_key}"
        ttl = ttl or self.ttl_seconds
        
        try:
            serialized = json.dumps(results)
            self.client.setex(cache_key, ttl, serialized)
            logger.debug(f"Cached query results: {query_key[:16]}... (ttl={ttl}s)")
            return True
        except (redis.RedisError, json.JSONEncodeError) as e:
            logger.error(f"Redis set error: {e}")
            return False
    
    def delete_query_cache(self, query_key: str) -> bool:
        """Delete cached query results.
        
        Args:
            query_key: Query key
            
        Returns:
            True if deleted
        """
        cache_key = f"cache:query:{query_key}"
        
        try:
            deleted = self.client.delete(cache_key)
            return deleted > 0
        except redis.RedisError as e:
            logger.error(f"Redis delete error: {e}")
            return False
    
    def get_meta(self, doc_id: str) -> Optional[dict]:
        """Get document metadata.
        
        Args:
            doc_id: Document ID
            
        Returns:
            Metadata dict if found, None otherwise
        """
        meta_key = f"meta:doc:{doc_id}"
        
        try:
            cached = self.client.get(meta_key)
            if cached:
                return json.loads(cached)
            else:
                return None
        except (redis.RedisError, json.JSONDecodeError) as e:
            logger.error(f"Redis meta get error: {e}")
            return None
    
    def set_meta(
        self,
        doc_id: str,
        metadata: dict,
        ttl: Optional[int] = None,
    ) -> bool:
        """Set document metadata.
        
        Args:
            doc_id: Document ID
            metadata: Metadata dictionary
            ttl: TTL in seconds (uses default if None)
            
        Returns:
            True if successful
        """
        meta_key = f"meta:doc:{doc_id}"
        ttl = ttl or self.ttl_seconds
        
        try:
            serialized = json.dumps(metadata)
            self.client.setex(meta_key, ttl, serialized)
            return True
        except (redis.RedisError, json.JSONEncodeError) as e:
            logger.error(f"Redis meta set error: {e}")
            return False
    
    def batch_get_meta(self, doc_ids: list[str]) -> dict[str, dict]:
        """Get multiple document metadata entries.
        
        Args:
            doc_ids: List of document IDs
            
        Returns:
            Dict mapping doc_id -> metadata (only for found entries)
        """
        if not doc_ids:
            return {}
        
        pipeline = self.client.pipeline()
        meta_keys = [f"meta:doc:{doc_id}" for doc_id in doc_ids]
        
        for key in meta_keys:
            pipeline.get(key)
        
        try:
            results = pipeline.execute()
            
            metadata_map = {}
            for doc_id, result in zip(doc_ids, results):
                if result:
                    try:
                        metadata_map[doc_id] = json.loads(result)
                    except json.JSONDecodeError:
                        logger.warning(f"Invalid JSON for doc {doc_id}")
            
            return metadata_map
        except redis.RedisError as e:
            logger.error(f"Redis batch get error: {e}")
            return {}
    
    def batch_set_meta(
        self,
        doc_metadata: dict[str, dict],
        ttl: Optional[int] = None,
    ) -> bool:
        """Set multiple document metadata entries.
        
        Args:
            doc_metadata: Dict mapping doc_id -> metadata
            ttl: TTL in seconds
            
        Returns:
            True if successful
        """
        if not doc_metadata:
            return True
        
        ttl = ttl or self.ttl_seconds
        pipeline = self.client.pipeline()
        
        for doc_id, metadata in doc_metadata.items():
            meta_key = f"meta:doc:{doc_id}"
            try:
                serialized = json.dumps(metadata)
                pipeline.setex(meta_key, ttl, serialized)
            except json.JSONEncodeError as e:
                logger.warning(f"Failed to serialize metadata for {doc_id}: {e}")
        
        try:
            pipeline.execute()
            logger.debug(f"Batch set {len(doc_metadata)} metadata entries")
            return True
        except redis.RedisError as e:
            logger.error(f"Redis batch set error: {e}")
            return False
    
    def increment_hit_count(self, query_key: str) -> int:
        """Increment hit counter for query (for popularity tracking).
        
        Args:
            query_key: Query key
            
        Returns:
            New hit count
        """
        counter_key = f"hits:query:{query_key}"
        
        try:
            count = self.client.incr(counter_key)
            # Set expiry if this is first hit
            if count == 1:
                self.client.expire(counter_key, self.ttl_seconds)
            return count
        except redis.RedisError as e:
            logger.error(f"Redis incr error: {e}")
            return 0
    
    def get_top_queries(self, limit: int = 100) -> list[tuple[str, int]]:
        """Get most popular queries by hit count.
        
        Args:
            limit: Maximum number of queries to return
            
        Returns:
            List of (query_key, hit_count) tuples
        """
        try:
            # Scan for all hit counter keys
            cursor = 0
            hit_counts = {}
            
            while True:
                cursor, keys = self.client.scan(
                    cursor,
                    match="hits:query:*",
                    count=100,
                )
                
                for key in keys:
                    count = self.client.get(key)
                    if count:
                        query_key = key.replace("hits:query:", "")
                        hit_counts[query_key] = int(count)
                
                if cursor == 0:
                    break
            
            # Sort by count and return top N
            sorted_queries = sorted(
                hit_counts.items(),
                key=lambda x: x[1],
                reverse=True,
            )
            
            return sorted_queries[:limit]
        except redis.RedisError as e:
            logger.error(f"Redis top queries error: {e}")
            return []
    
    def clear_cache(self) -> bool:
        """Clear all cache entries (preserves metadata).
        
        Returns:
            True if successful
        """
        try:
            cursor = 0
            deleted = 0
            
            while True:
                cursor, keys = self.client.scan(
                    cursor,
                    match="cache:query:*",
                    count=100,
                )
                
                if keys:
                    deleted += self.client.delete(*keys)
                
                if cursor == 0:
                    break
            
            logger.info(f"Cleared {deleted} cache entries")
            return True
        except redis.RedisError as e:
            logger.error(f"Redis clear error: {e}")
            return False
    
    def flush_all(self) -> bool:
        """Flush entire Redis database (USE WITH CAUTION).
        
        Returns:
            True if successful
        """
        try:
            self.client.flushdb()
            logger.warning("Flushed entire Redis database")
            return True
        except redis.RedisError as e:
            logger.error(f"Redis flush error: {e}")
            return False
    
    def ping(self) -> bool:
        """Test Redis connection.
        
        Returns:
            True if connected
        """
        try:
            return self.client.ping()
        except redis.RedisError:
            return False
    
    def info(self) -> dict:
        """Get Redis server info.
        
        Returns:
            Server info dictionary
        """
        try:
            return self.client.info()
        except redis.RedisError as e:
            logger.error(f"Redis info error: {e}")
            return {}
