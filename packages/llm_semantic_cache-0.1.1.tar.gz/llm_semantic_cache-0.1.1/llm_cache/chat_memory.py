
"""Chat Memory - Semantic history management for LLMs.

This module provides a specialized interface for managing chat history
using the vector cache. It allows:
1. Storing chat messages with metadata (role, timestamp, session_id)
2. Retrieving relevant context for a new query
3. Managing token limits
"""

import logging
import time
import uuid
from typing import List, Dict, Optional, Tuple

import numpy as np

from llm_cache.config import load_config
from llm_cache.embedder import create_embedder
from llm_cache.storage.faiss_adapter import FaissAdapter
from llm_cache.cache.redis_cache import RedisCache

logger = logging.getLogger(__name__)

class ChatMemory:
    """Semantic chat memory manager."""
    
    def __init__(self, config=None, use_mock: bool = False):
        """Initialize chat memory.
        
        Args:
            config: Configuration object
            use_mock: Use mock embedder
        """
        self.config = config or load_config()
        
        # Initialize components
        self.embedder = create_embedder(
            model_name=self.config.embedding.model,
            dimension=self.config.embedding.dimension,
            batch_size=self.config.embedding.batch_size,
            use_mock=use_mock,
        )
        
        self.vector_db = FaissAdapter(
            dimension=self.config.embedding.dimension,
            index_type="Flat", # Use Flat for accuracy, or IVF for speed
        )
        
        self.redis = RedisCache(
            host=self.config.redis.host,
            port=self.config.redis.port,
            db=self.config.redis.db,
        )
        
        logger.info("Initialized ChatMemory")

    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict] = None
    ) -> str:
        """Add a message to memory.
        
        Args:
            session_id: Chat session identifier
            role: Message role (user, assistant, system)
            content: Message content
            metadata: Additional metadata
            
        Returns:
            Message ID
        """
        msg_id = str(uuid.uuid4())
        timestamp = time.time()
        
        # Embed content
        embeddings = await self.embedder.embed([content])
        vector = embeddings[0]
        
        # Prepare metadata
        full_metadata = {
            "text": content,
            "role": role,
            "session_id": session_id,
            "timestamp": timestamp,
        }
        if metadata:
            full_metadata.update(metadata)
            
        # Store in Vector DB
        # We use a composite ID or just UUID
        self.vector_db.bulk_upsert([(msg_id, vector, full_metadata)])
        
        # Store full metadata in Redis (Vector DB might truncate)
        self.redis.set_meta(msg_id, full_metadata)
        
        logger.debug(f"Added message {msg_id} to session {session_id}")
        return msg_id

    async def get_context(
        self,
        session_id: str,
        query: str,
        max_tokens: int = 2000,
        top_k: int = 10,
    ) -> List[Dict]:
        """Retrieve relevant context for a query.
        
        Args:
            session_id: Chat session identifier
            query: Current user query
            max_tokens: Maximum estimated tokens for context
            top_k: Number of messages to retrieve
            
        Returns:
            List of message dictionaries, sorted by timestamp
        """
        # Embed query
        embeddings = await self.embedder.embed([query])
        query_vector = embeddings[0]
        
        # Search Vector DB
        # Note: Faiss doesn't support filtering by session_id natively in all index types
        # So we fetch top_k * factor and filter in memory
        fetch_k = top_k * 5
        results = self.vector_db.search(query_vector, top_k=fetch_k)
        
        # Fetch metadata
        doc_ids = [r[0] for r in results]
        meta_map = self.redis.batch_get_meta(doc_ids)
        
        # Filter by session_id and collect messages
        relevant_messages = []
        for doc_id, score in results:
            meta = meta_map.get(doc_id)
            if not meta:
                continue
                
            if meta.get("session_id") == session_id:
                relevant_messages.append({
                    "id": doc_id,
                    "role": meta.get("role"),
                    "content": meta.get("text"),
                    "timestamp": meta.get("timestamp"),
                    "score": score
                })
                
        # Sort by relevance (score) first to pick top ones?
        # Or just take the filtered list (already sorted by score)
        
        # We want the MOST RELEVANT messages that fit in token limit
        # But usually we want them sorted by time in the context window
        
        selected_messages = relevant_messages[:top_k]
        
        # Sort by timestamp for coherent context
        selected_messages.sort(key=lambda x: x.get("timestamp", 0))
        
        # Token limiting (approximate: 4 chars = 1 token)
        final_messages = []
        current_tokens = 0
        
        # We add from latest to oldest? Or oldest to latest?
        # Usually we want the most relevant ones.
        # If we have sorted by timestamp, we iterate and check limit.
        
        for msg in selected_messages:
            content = msg["content"] or ""
            est_tokens = len(content) / 4
            
            if current_tokens + est_tokens <= max_tokens:
                final_messages.append(msg)
                current_tokens += est_tokens
            else:
                break # Stop if full
                
        return final_messages

    def clear_session(self, session_id: str):
        """Clear messages for a session.
        
        Note: This is inefficient with Faiss as it doesn't support delete by query.
        We would need to track IDs per session in Redis.
        """
        # TODO: Implement session tracking in Redis to enable efficient deletion
        pass
