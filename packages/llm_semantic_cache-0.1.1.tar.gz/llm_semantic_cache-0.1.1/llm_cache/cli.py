"""Command-line interface for LLM Cache.

Usage:
    llm-cache --help
    llm-cache query "What is machine learning?"
    llm-cache ingest --file data.jsonl
    llm-cache demo
    llm-cache config --show
"""

import argparse
import asyncio
import logging
import sys
from typing import Optional

from llm_cache import __version__


def setup_logging(verbose: bool = False) -> None:
    """Configure logging based on verbosity."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def cmd_query(args: argparse.Namespace) -> int:
    """Execute a query."""
    from llm_cache import QueryService
    
    async def run():
        service = QueryService(use_mock=args.mock)
        results = await service.query(
            args.query,
            top_k=args.top_k,
            verbose=not args.quiet,
        )
        
        if not args.quiet:
            print(f"\n{'='*60}")
            print(f"Query: {args.query}")
            print(f"Results: {len(results)}")
            print(f"{'='*60}\n")
            
            for i, r in enumerate(results, 1):
                print(f"{i}. Score: {r.get('score', 'N/A'):.4f}")
                print(f"   Text: {r.get('text', 'N/A')[:100]}...")
                print()
        
        return 0
    
    return asyncio.run(run())


def cmd_demo(args: argparse.Namespace) -> int:
    """Run the demo."""
    from llm_cache.demo import main as demo_main
    return demo_main()


def cmd_config(args: argparse.Namespace) -> int:
    """Show or validate configuration."""
    from llm_cache import load_config
    import yaml
    
    try:
        config = load_config(args.config)
        
        if args.show:
            # Convert to dict for display
            config_dict = {
                "embedding": {
                    "model": config.embedding.model,
                    "dimension": config.embedding.dimension,
                },
                "hnsw": {
                    "M": config.hnsw.M,
                    "ef_construction": config.hnsw.ef_construction,
                    "hot_cache_size": config.hnsw.hot_cache_size,
                },
                "redis": {
                    "host": config.redis.host,
                    "port": config.redis.port,
                    "ttl_seconds": config.redis.ttl_seconds,
                },
            }
            print(yaml.dump(config_dict, default_flow_style=False))
        else:
            print("✓ Configuration is valid")
        
        return 0
        
    except Exception as e:
        print(f"✗ Configuration error: {e}", file=sys.stderr)
        return 1


def cmd_version(args: argparse.Namespace) -> int:
    """Show version information."""
    print(f"llm-cache version {__version__}")
    return 0


def main(argv: Optional[list[str]] = None) -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="llm-cache",
        description="Multi-tier caching platform for LLM embeddings and semantic search",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  llm-cache query "What is machine learning?"
  llm-cache query "Explain neural networks" --top-k 10
  llm-cache demo
  llm-cache config --show
  llm-cache --version
        """,
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Query command
    query_parser = subparsers.add_parser("query", help="Execute a semantic query")
    query_parser.add_argument("query", help="Query text")
    query_parser.add_argument("-k", "--top-k", type=int, default=5, help="Number of results")
    query_parser.add_argument("-q", "--quiet", action="store_true", help="Minimal output")
    query_parser.add_argument("--mock", action="store_true", help="Use mock embedder")
    query_parser.set_defaults(func=cmd_query)
    
    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run interactive demo")
    demo_parser.set_defaults(func=cmd_demo)
    
    # Config command
    config_parser = subparsers.add_parser("config", help="Configuration management")
    config_parser.add_argument("-c", "--config", help="Path to config file")
    config_parser.add_argument("--show", action="store_true", help="Display current config")
    config_parser.set_defaults(func=cmd_config)
    
    # Version command
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)
    
    args = parser.parse_args(argv)
    
    if args.version:
        return cmd_version(args)
    
    setup_logging(args.verbose)
    
    if args.command is None:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
