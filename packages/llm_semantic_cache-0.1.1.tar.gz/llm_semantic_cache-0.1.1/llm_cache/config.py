"""Configuration management for LLM Cache Platform.

This module provides dataclass-based configuration with support for:
- Environment variable overrides
- YAML configuration files
- Sensible defaults for all parameters
- Type-safe settings with validation
"""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Optional

import yaml


@dataclass
class HNSWConfig:
    """Configuration for HNSW index (local hot cache).
    
    Attributes:
        M: Number of bi-directional links per node (higher = better recall, more memory)
        ef_construction: Size of dynamic candidate list during construction (higher = better quality)
        ef_search: Size of dynamic candidate list during search (higher = better recall)
        hot_cache_size: Maximum number of vectors in local HNSW index
        space: Distance metric ('l2', 'cosine', 'ip')
    """
    M: int = 16
    ef_construction: int = 200
    ef_search: int = 50
    hot_cache_size: int = 10_000
    space: Literal["l2", "cosine", "ip"] = "l2"


@dataclass
class RedisConfig:
    """Configuration for Redis cache layer.
    
    Attributes:
        host: Redis server hostname
        port: Redis server port
        db: Redis database number
        password: Redis password (optional)
        ttl_seconds: Default TTL for cached query results
        max_connections: Connection pool size
        socket_timeout: Socket timeout in seconds
        socket_connect_timeout: Connection timeout in seconds
    """
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: Optional[str] = None
    ttl_seconds: int = 3600
    max_connections: int = 10
    socket_timeout: int = 5
    socket_connect_timeout: int = 5


@dataclass
class FaissConfig:
    """Configuration for Faiss vector database.
    
    Attributes:
        index_type: Type of index ('Flat', 'IVF', 'IVFPQ', 'HNSW')
        index_path: Path to persist Faiss index
        nlist: Number of clusters for IVF (ignored for Flat)
        nprobe: Number of clusters to search (ignored for Flat)
        pq_enabled: Enable Product Quantization compression
        pq_m: Number of subquantizers (must divide dimension evenly)
        pq_nbits: Bits per subquantizer code (8 is typical)
        metric: Distance metric ('L2' or 'IP' for inner product)
    """
    index_type: Literal["Flat", "IVF", "IVFPQ", "HNSW"] = "Flat"
    index_path: str = "./faiss_index.bin"
    nlist: int = 1024
    nprobe: int = 8
    pq_enabled: bool = False
    pq_m: int = 64
    pq_nbits: int = 8
    metric: Literal["L2", "IP"] = "L2"


@dataclass
class QdrantConfig:
    """Configuration for Qdrant vector database.
    
    Attributes:
        host: Qdrant server hostname
        port: Qdrant server port (gRPC)
        grpc_port: Alternative gRPC port
        collection_name: Name of the collection to use
        api_key: API key for authentication (optional)
        timeout: Request timeout in seconds
        prefer_grpc: Use gRPC over REST
    """
    host: str = "localhost"
    port: int = 6333
    grpc_port: int = 6334
    collection_name: str = "llm_cache"
    api_key: Optional[str] = None
    timeout: int = 30
    prefer_grpc: bool = True


@dataclass
class EmbeddingConfig:
    """Configuration for embedding generation.
    
    Attributes:
        model: Model name for sentence-transformers
        dimension: Embedding vector dimension
        batch_size: Batch size for embedding generation
        normalize: Normalize embeddings to unit length
        device: Device for model ('cpu', 'cuda', 'mps')
    """
    model: str = "all-MiniLM-L6-v2"
    dimension: int = 384
    batch_size: int = 32
    normalize: bool = True
    device: str = "cpu"


@dataclass
class ChunkingConfig:
    """Configuration for text chunking.
    
    Attributes:
        chunk_size: Maximum characters per chunk
        chunk_overlap: Overlap between consecutive chunks
        min_chunk_size: Minimum characters for a valid chunk
        separator: Primary separator for chunking
    """
    chunk_size: int = 512
    chunk_overlap: int = 50
    min_chunk_size: int = 100
    separator: str = "\n\n"


@dataclass
class WarmingConfig:
    """Configuration for cache warming.
    
    Attributes:
        enabled: Enable automatic cache warming
        top_n: Number of top queries to warm
        interval_seconds: Warming interval in seconds
        min_query_count: Minimum query count to consider warming
        popularity_decay: Decay factor for popularity tracking (0-1)
    """
    enabled: bool = True
    top_n: int = 100
    interval_seconds: int = 300
    min_query_count: int = 3
    popularity_decay: float = 0.95


@dataclass
class CacheConfig:
    """Main configuration for LLM Cache Platform.
    
    This is the top-level configuration that aggregates all sub-configurations.
    Can be loaded from environment variables or YAML files.
    """
    # Vector DB backend selection
    vector_db_backend: Literal["faiss", "qdrant"] = "faiss"
    
    # Sub-configurations
    hnsw: HNSWConfig = field(default_factory=HNSWConfig)
    redis: RedisConfig = field(default_factory=RedisConfig)
    faiss: FaissConfig = field(default_factory=FaissConfig)
    qdrant: QdrantConfig = field(default_factory=QdrantConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    warming: WarmingConfig = field(default_factory=WarmingConfig)
    
    # Global settings
    log_level: str = "INFO"
    debug: bool = False
    
    @classmethod
    def from_yaml(cls, path: Path | str) -> "CacheConfig":
        """Load configuration from YAML file.
        
        Args:
            path: Path to YAML configuration file
            
        Returns:
            Loaded CacheConfig instance
            
        Example:
            >>> config = CacheConfig.from_yaml("config.yaml")
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path) as f:
            data = yaml.safe_load(f)
        
        return cls.from_dict(data)
    
    @classmethod
    def from_dict(cls, data: dict) -> "CacheConfig":
        """Create configuration from dictionary.
        
        Args:
            data: Dictionary with configuration values
            
        Returns:
            CacheConfig instance
        """
        # Extract sub-configurations
        config_kwargs = {}
        
        if "vector_db_backend" in data:
            config_kwargs["vector_db_backend"] = data["vector_db_backend"]
        
        if "hnsw" in data:
            config_kwargs["hnsw"] = HNSWConfig(**data["hnsw"])
        
        if "redis" in data:
            config_kwargs["redis"] = RedisConfig(**data["redis"])
        
        if "faiss" in data:
            config_kwargs["faiss"] = FaissConfig(**data["faiss"])
        
        if "qdrant" in data:
            config_kwargs["qdrant"] = QdrantConfig(**data["qdrant"])
        
        if "embedding" in data:
            config_kwargs["embedding"] = EmbeddingConfig(**data["embedding"])
        
        if "chunking" in data:
            config_kwargs["chunking"] = ChunkingConfig(**data["chunking"])
        
        if "warming" in data:
            config_kwargs["warming"] = WarmingConfig(**data["warming"])
        
        if "log_level" in data:
            config_kwargs["log_level"] = data["log_level"]
        
        if "debug" in data:
            config_kwargs["debug"] = data["debug"]
        
        return cls(**config_kwargs)
    
    @classmethod
    def from_env(cls) -> "CacheConfig":
        """Load configuration from environment variables.
        
        Environment variables follow the pattern: {SECTION}_{SETTING}
        Example: HNSW_M=32, REDIS_HOST=localhost, VECTOR_DB_BACKEND=faiss
        
        Returns:
            CacheConfig instance with values from environment
        """
        def get_env(key: str, default: any, type_converter: type = str) -> any:
            value = os.getenv(key)
            if value is None:
                return default
            try:
                return type_converter(value)
            except (ValueError, TypeError):
                return default
        
        return cls(
            vector_db_backend=get_env("VECTOR_DB_BACKEND", "faiss", str),
            
            hnsw=HNSWConfig(
                M=get_env("HNSW_M", 16, int),
                ef_construction=get_env("HNSW_EF_CONSTRUCTION", 200, int),
                ef_search=get_env("HNSW_EF_SEARCH", 50, int),
                hot_cache_size=get_env("HOT_CACHE_SIZE", 10_000, int),
                space=get_env("HNSW_SPACE", "l2", str),
            ),
            
            redis=RedisConfig(
                host=get_env("REDIS_HOST", "localhost", str),
                port=get_env("REDIS_PORT", 6379, int),
                db=get_env("REDIS_DB", 0, int),
                password=get_env("REDIS_PASSWORD", None, str),
                ttl_seconds=get_env("REDIS_TTL_SECONDS", 3600, int),
                max_connections=get_env("REDIS_MAX_CONNECTIONS", 10, int),
            ),
            
            faiss=FaissConfig(
                index_type=get_env("FAISS_INDEX_TYPE", "Flat", str),
                index_path=get_env("FAISS_INDEX_PATH", "./faiss_index.bin", str),
                nlist=get_env("FAISS_NLIST", 1024, int),
                nprobe=get_env("FAISS_NPROBE", 8, int),
                pq_enabled=get_env("PQ_ENABLED", False, lambda x: x.lower() == "true"),
                pq_m=get_env("PQ_M", 64, int),
                pq_nbits=get_env("PQ_NBITS", 8, int),
            ),
            
            qdrant=QdrantConfig(
                host=get_env("QDRANT_HOST", "localhost", str),
                port=get_env("QDRANT_PORT", 6333, int),
                collection_name=get_env("QDRANT_COLLECTION", "llm_cache", str),
                api_key=get_env("QDRANT_API_KEY", None, str),
            ),
            
            embedding=EmbeddingConfig(
                model=get_env("EMBEDDING_MODEL", "all-MiniLM-L6-v2", str),
                dimension=get_env("EMBEDDING_DIM", 384, int),
                batch_size=get_env("EMBEDDING_BATCH_SIZE", 32, int),
                device=get_env("EMBEDDING_DEVICE", "cpu", str),
            ),
            
            chunking=ChunkingConfig(
                chunk_size=get_env("CHUNK_SIZE", 512, int),
                chunk_overlap=get_env("CHUNK_OVERLAP", 50, int),
                min_chunk_size=get_env("MIN_CHUNK_SIZE", 100, int),
            ),
            
            warming=WarmingConfig(
                enabled=get_env("WARMING_ENABLED", True, lambda x: x.lower() == "true"),
                top_n=get_env("WARMING_TOP_N", 100, int),
                interval_seconds=get_env("WARMING_INTERVAL", 300, int),
            ),
            
            log_level=get_env("LOG_LEVEL", "INFO", str),
            debug=get_env("DEBUG", False, lambda x: x.lower() == "true"),
        )
    
    def to_dict(self) -> dict:
        """Convert configuration to dictionary.
        
        Returns:
            Dictionary representation of configuration
        """
        return {
            "vector_db_backend": self.vector_db_backend,
            "hnsw": {
                "M": self.hnsw.M,
                "ef_construction": self.hnsw.ef_construction,
                "ef_search": self.hnsw.ef_search,
                "hot_cache_size": self.hnsw.hot_cache_size,
                "space": self.hnsw.space,
            },
            "redis": {
                "host": self.redis.host,
                "port": self.redis.port,
                "db": self.redis.db,
                "ttl_seconds": self.redis.ttl_seconds,
            },
            "faiss": {
                "index_type": self.faiss.index_type,
                "pq_enabled": self.faiss.pq_enabled,
                "pq_m": self.faiss.pq_m,
            },
            "embedding": {
                "model": self.embedding.model,
                "dimension": self.embedding.dimension,
                "batch_size": self.embedding.batch_size,
            },
        }


def load_config(config_path: Optional[str] = None) -> CacheConfig:
    """Load configuration with fallback chain: file -> env -> defaults.
    
    Args:
        config_path: Optional path to YAML config file
        
    Returns:
        CacheConfig instance
        
    Example:
        >>> config = load_config("config.yaml")  # Load from file
        >>> config = load_config()  # Load from env or defaults
    """
    # Try loading from file if provided
    if config_path:
        path = Path(config_path)
        if path.exists():
            return CacheConfig.from_yaml(path)
        else:
            print(f"Warning: Config file {config_path} not found, using environment/defaults")
    
    # Fall back to environment variables
    return CacheConfig.from_env()
