"""
End-to-end demo of the LLM Cache Platform.

This module demonstrates the complete caching workflow:
1. Document ingestion
2. Cache warming
3. Query execution with cache hits at different tiers
4. Statistics and performance metrics
"""

import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np

from llm_cache.config import load_config, CacheConfig
from llm_cache.embedder import create_embedder
from llm_cache.storage.faiss_adapter import FaissAdapter
from llm_cache.cache.local_hnsw import LocalHNSWCache
from llm_cache.cache.redis_cache import RedisCache
from llm_cache.keys import query_key, content_fingerprint, doc_id_from_fingerprint

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class CacheDemo:
    """Demo orchestrator for the LLM Cache Platform."""
    
    def __init__(self, config: Optional[CacheConfig] = None):
        """Initialize demo with configuration.
        
        Args:
            config: CacheConfig instance (uses defaults if None)
        """
        self.config = config or load_config()
        
        # Initialize components
        self.embedder = create_embedder(
            model_name=self.config.embedding.model,
            dimension=self.config.embedding.dimension,
            batch_size=self.config.embedding.batch_size,
            device=self.config.embedding.device,
            use_mock=True,  # Use mock for demo (no model download)
        )
        
        # Vector DB (Faiss)
        self.vector_db = FaissAdapter(
            dimension=self.config.embedding.dimension,
            index_type="Flat",  # Simple flat index for demo
            metric="L2",
        )
        
        # Redis cache
        try:
            self.redis = RedisCache(
                host=self.config.redis.host,
                port=self.config.redis.port,
                db=self.config.redis.db,
                ttl_seconds=self.config.redis.ttl_seconds,
            )
            logger.info("✓ Connected to Redis")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            logger.error("Please start Redis: docker run -d -p 6379:6379 redis:7-alpine")
            sys.exit(1)
        
        # Local HNSW cache
        self.local_cache = LocalHNSWCache(
            dimension=self.config.embedding.dimension,
            max_elements=self.config.hnsw.hot_cache_size,
            M=self.config.hnsw.M,
            ef_construction=self.config.hnsw.ef_construction,
            ef_search=self.config.hnsw.ef_search,
        )
        
        # Stats
        self.stats = {
            "queries": 0,
            "local_hits": 0,
            "redis_hits": 0,
            "db_hits": 0,
            "total_latency_ms": 0,
        }
        
        logger.info("✓ Initialized all components")
    
    async def create_sample_documents(self) -> None:
        """Create sample documents for demo if no directory exists."""
        logger.info("Creating sample documents...")
        
        sample_docs = [
            "Machine learning is a subset of artificial intelligence that enables computers to learn from data without being explicitly programmed. It uses algorithms to identify patterns and make predictions.",
            "Python is a high-level, interpreted programming language known for its simplicity and readability. It is widely used in web development, data science, artificial intelligence, and automation.",
            "Neural networks are computing systems inspired by biological neural networks. They consist of layers of interconnected nodes that process information and learn to recognize patterns through training.",
            "Deep learning is a subset of machine learning that uses neural networks with multiple layers. It excels at tasks like image recognition, natural language processing, and speech recognition.",
            "Vector databases are specialized storage systems optimized for high-dimensional vector embeddings. They enable efficient similarity search and are commonly used in AI applications.",
            "Caching is a technique to store frequently accessed data in fast-access storage layers. Multi-tier caching strategies can dramatically reduce latency and improve application performance.",
            "Redis is an open-source, in-memory data structure store used as a database, cache, and message broker. It supports various data structures and provides high performance for read and write operations.",
            "HNSW (Hierarchical Navigable Small World) is an approximate nearest neighbor search algorithm. It builds a multi-layer graph structure that enables fast similarity searches in high-dimensional spaces.",
            "Faiss is a library developed by Facebook AI for efficient similarity search and clustering of dense vectors. It contains algorithms for large-scale vector search at various speed-accuracy tradeoffs.",
            "Natural language processing (NLP) is a branch of AI that focuses on enabling computers to understand, interpret, and generate human language. It powers applications like chatbots, translation, and sentiment analysis.",
        ]
        
        all_docs = []
        for i, content in enumerate(sample_docs):
            fp = content_fingerprint(content)
            doc_id = doc_id_from_fingerprint(fp, 0)
            all_docs.append({
                "id": doc_id,
                "text": content,
                "source": f"sample_doc_{i}.txt",
                "chunk_index": 0,
            })
        
        logger.info(f"Created {len(all_docs)} sample documents")
        
        # Embed all documents
        texts = [doc["text"] for doc in all_docs]
        embeddings = await self.embedder.embed(texts)
        
        # Prepare for bulk upsert
        docs_with_embeddings = [
            (
                doc["id"],
                embeddings[i],
                {
                    "text": doc["text"][:200],
                    "source": doc["source"],
                    "chunk_index": doc["chunk_index"],
                }
            )
            for i, doc in enumerate(all_docs)
        ]
        
        # Bulk upsert to vector DB
        self.vector_db.bulk_upsert(docs_with_embeddings)
        
        # Store metadata in Redis
        meta_dict = {
            doc["id"]: {
                "text": doc["text"],
                "source": doc["source"],
                "chunk_index": doc["chunk_index"],
            }
            for doc in all_docs
        }
        self.redis.batch_set_meta(meta_dict)
        
        logger.info(f"✓ Ingested {len(all_docs)} documents")
        logger.info(f"  Vector DB count: {self.vector_db.count()}")
    
    async def ingest_documents(self, input_dir: str) -> None:
        """Ingest documents from directory.
        
        Args:
            input_dir: Directory containing text files
        """
        logger.info(f"Ingesting documents from: {input_dir}")
        
        input_path = Path(input_dir)
        if not input_path.exists():
            logger.warning(f"Directory not found: {input_dir}, using sample documents instead")
            await self.create_sample_documents()
            return
        
        # Read all text files
        text_files = list(input_path.glob("*.txt"))
        if not text_files:
            logger.warning(f"No .txt files found in {input_dir}, using sample documents instead")
            await self.create_sample_documents()
            return
        
        logger.info(f"Found {len(text_files)} text files")
        
        all_docs = []
        
        for file_path in text_files:
            logger.info(f"  Processing: {file_path.name}")
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Simple chunking (split by paragraphs)
            chunks = [c.strip() for c in content.split('\n\n') if c.strip()]
            
            # Generate fingerprints and IDs
            fp = content_fingerprint(content)
            
            for i, chunk in enumerate(chunks):
                doc_id = doc_id_from_fingerprint(fp, i)
                all_docs.append({
                    "id": doc_id,
                    "text": chunk,
                    "source": file_path.name,
                    "chunk_index": i,
                })
        
        if not all_docs:
            logger.warning("No content to ingest")
            return
        
        logger.info(f"Total chunks to embed: {len(all_docs)}")
        
        # Embed in batches
        texts = [doc["text"] for doc in all_docs]
        embeddings = await self.embedder.embed(texts)
        
        # Prepare for bulk upsert
        docs_with_embeddings = [
            (doc["id"], embeddings[i], {
                "text": doc["text"][:200],  # Store truncated text
                "source": doc["source"],
                "chunk_index": doc["chunk_index"],
            })
            for i, doc in enumerate(all_docs)
        ]
        
        # Bulk upsert to vector DB
        self.vector_db.bulk_upsert(docs_with_embeddings)
        
        # Store metadata in Redis
        meta_dict = {
            doc["id"]: {
                "text": doc["text"],
                "source": doc["source"],
                "chunk_index": doc["chunk_index"],
            }
            for doc in all_docs
        }
        self.redis.batch_set_meta(meta_dict)
        
        logger.info(f"✓ Ingested {len(all_docs)} chunks")
        logger.info(f"  Vector DB count: {self.vector_db.count()}")
    
    async def warm_caches(self) -> None:
        """Warm caches with popular queries."""
        logger.info("Warming caches with sample queries...")
        
        # Sample queries to warm
        warm_queries = [
            "What is machine learning?",
            "Explain neural networks",
            "What is Python?",
            "Tell me about deep learning",
            "What is AI?",
        ]
        
        for query_text in warm_queries:
            logger.info(f"  Warming: {query_text}")
            await self.query(query_text, warm_mode=True)
        
        logger.info(f"✓ Warmed {len(warm_queries)} queries")
    
    async def query(
        self,
        query_text: str,
        top_k: int = 3,
        warm_mode: bool = False,
    ) -> list[dict]:
        """Execute query with multi-tier cache lookup.
        
        Args:
            query_text: Query string
            top_k: Number of results
            warm_mode: If True, skip stats tracking
            
        Returns:
            List of result dictionaries
        """
        start_time = time.time()
        
        # Generate query key
        q_key = query_key(
            query_text,
            top_k=top_k,
            embed_model=self.config.embedding.model,
        )
        
        cache_tier = None
        results = []
        
        # Tier A: Local HNSW
        if self.local_cache.count() > 0:
            # Embed query for local search
            query_embedding = await self.embedder.embed([query_text])
            local_results = self.local_cache.knn_query(query_embedding[0], k=top_k)
            
            if local_results:
                cache_tier = "LOCAL_HNSW"
                # Fetch metadata from Redis
                doc_ids = [r[0] for r in local_results]
                meta_map = self.redis.batch_get_meta(doc_ids)
                
                for doc_id, score in local_results:
                    meta = meta_map.get(doc_id, {})
                    results.append({
                        "id": doc_id,
                        "score": score,
                        "text": meta.get("text", ""),
                        "source": meta.get("source", ""),
                    })
        
        # Tier B: Redis
        if not results:
            cached = self.redis.get_query_cache(q_key)
            if cached:
                cache_tier = "REDIS"
                results = cached
        
        # Tier C: Vector DB
        if not results:
            # Check if vector DB has any data
            if self.vector_db.count() == 0:
                logger.warning("Vector DB is empty. Please ingest documents first.")
                return []
            
            cache_tier = "VECTOR_DB"
            
            # Embed query
            query_embedding = await self.embedder.embed([query_text])
            
            # Search vector DB
            db_results = self.vector_db.search(
                query_embedding[0],
                top_k=top_k,
            )
            
            # Fetch metadata
            doc_ids = [r[0] for r in db_results]
            meta_map = self.redis.batch_get_meta(doc_ids)
            
            for doc_id, score in db_results:
                meta = meta_map.get(doc_id, {})
                results.append({
                    "id": doc_id,
                    "score": score,
                    "text": meta.get("text", ""),
                    "source": meta.get("source", ""),
                })
            
            # Cache in Redis
            self.redis.set_query_cache(q_key, results)
            
            # Add top results to local HNSW for future queries
            # We need to re-embed the documents since Faiss doesn't return vectors
            if results and len(doc_ids) > 0:
                top_doc_ids = doc_ids[:min(3, len(doc_ids))]
                top_texts = [meta_map.get(did, {}).get("text", "") for did in top_doc_ids]
                if any(top_texts):
                    top_vectors = await self.embedder.embed(top_texts)
                    self.local_cache.add_items(top_doc_ids, top_vectors)
        
        latency_ms = (time.time() - start_time) * 1000
        
        # Track stats
        if not warm_mode:
            self.stats["queries"] += 1
            self.stats["total_latency_ms"] += latency_ms
            
            if cache_tier == "LOCAL_HNSW":
                self.stats["local_hits"] += 1
            elif cache_tier == "REDIS":
                self.stats["redis_hits"] += 1
            elif cache_tier == "VECTOR_DB":
                self.stats["db_hits"] += 1
            
            # Print results
            print(f"\n{'='*70}")
            print(f"Query: {query_text}")
            print(f"Cache Tier: {cache_tier} | Latency: {latency_ms:.2f}ms")
            print(f"{'-'*70}")
            
            for i, result in enumerate(results, 1):
                print(f"{i}. [{result['source']}] Score: {result['score']:.4f}")
                print(f"   {result['text'][:150]}...")
                print()
        
        return results
    
    def print_stats(self) -> None:
        """Print cache statistics."""
        print(f"\n{'='*70}")
        print("CACHE STATISTICS")
        print(f"{'='*70}")
        
        total = self.stats["queries"]
        if total == 0:
            print("No queries executed yet")
            return
        
        local_pct = (self.stats["local_hits"] / total) * 100
        redis_pct = (self.stats["redis_hits"] / total) * 100
        db_pct = (self.stats["db_hits"] / total) * 100
        avg_latency = self.stats["total_latency_ms"] / total
        
        print(f"Total Queries:       {total}")
        print(f"Average Latency:     {avg_latency:.2f}ms")
        print()
        print(f"Cache Hit Rates:")
        print(f"  Local HNSW:        {self.stats['local_hits']:3d} ({local_pct:5.1f}%)")
        print(f"  Redis:             {self.stats['redis_hits']:3d} ({redis_pct:5.1f}%)")
        print(f"  Vector DB (miss):  {self.stats['db_hits']:3d} ({db_pct:5.1f}%)")
        print()
        print(f"Storage:")
        print(f"  Vector DB:         {self.vector_db.count()} vectors")
        print(f"  Local HNSW:        {self.local_cache.count()} vectors")
        print(f"{'='*70}\n")


async def main_async():
    """Async main function."""
    parser = argparse.ArgumentParser(description="LLM Cache Platform Demo")
    parser.add_argument("--mode", choices=["ingest", "warm", "query", "stats", "full"],
                       default="full", help="Demo mode")
    parser.add_argument("--input-dir", default="./data/documents",
                       help="Input directory for ingestion")
    parser.add_argument("--query", type=str, help="Query text for single query mode")
    
    args = parser.parse_args()
    
    # Initialize demo
    demo = CacheDemo()
    
    if args.mode == "ingest":
        await demo.ingest_documents(args.input_dir)
    
    elif args.mode == "warm":
        await demo.warm_caches()
    
    elif args.mode == "query":
        if not args.query:
            print("Error: --query required for query mode")
            sys.exit(1)
        await demo.query(args.query)
    
    elif args.mode == "stats":
        demo.print_stats()
    
    elif args.mode == "full":
        # Full demo
        print("\n" + "="*70)
        print("LLM CACHE PLATFORM - FULL DEMO")
        print("="*70 + "\n")
        
        # Step 1: Ingest
        print("Step 1: Ingesting documents...")
        await demo.ingest_documents(args.input_dir)
        
        # Step 2: Warm caches
        print("\nStep 2: Warming caches...")
        await demo.warm_caches()
        
        # Step 3: Run queries
        print("\nStep 3: Running demo queries...")
        queries = [
            "What is machine learning?",  # Should hit Redis or local
            "Explain neural networks",     # Should hit Redis or local
            "What is Python used for?",    # May hit Redis or local
            "What is machine learning?",   # Definitely hit cache
            "Tell me about AI",            # May miss and hit DB
        ]
        
        for q in queries:
            await demo.query(q)
            await asyncio.sleep(0.5)  # Small delay for readability
        
        # Step 4: Stats
        print("\nStep 4: Final statistics")
        demo.print_stats()
        
        print("Demo complete! ✓")


def main():
    """Main entry point."""
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
