"""Embedder interface and implementations for text embedding.

This module defines:
- Protocol interface for embedders (duck typing)
- SentenceTransformerEmbedder (production implementation)
- MockEmbedder (for testing and development)

All embedders must implement async embed() method returning numpy arrays.
"""

import hashlib
import logging
from typing import Protocol

import numpy as np

logger = logging.getLogger(__name__)


class Embedder(Protocol):
    """Protocol defining the embedder interface.
    
    Any class implementing this protocol must provide an async embed method
    that converts text strings to embedding vectors.
    """
    
    async def embed(self, texts: list[str]) -> np.ndarray:
        """Embed a batch of texts into vectors.
        
        Args:
            texts: List of text strings to embed
            
        Returns:
            numpy array of shape (len(texts), embedding_dim)
            
        Raises:
            ValueError: If texts is empty or contains invalid data
        """
        ...


class SentenceTransformerEmbedder:
    """Production embedder using sentence-transformers library.
    
    Loads a pre-trained model and generates embeddings for texts.
    Supports batching, normalization, and device selection (CPU/GPU/MPS).
    
    Attributes:
        model_name: Name of the sentence-transformers model
        dimension: Expected embedding dimension
        batch_size: Batch size for encoding
        normalize: Whether to L2-normalize embeddings
        device: Device to run model on ('cpu', 'cuda', 'mps')
    """
    
    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        dimension: int = 384,
        batch_size: int = 32,
        normalize: bool = True,
        device: str = "cpu",
    ):
        """Initialize sentence-transformer embedder.
        
        Args:
            model_name: HuggingFace model name or path
            dimension: Expected embedding dimension (for validation)
            batch_size: Batch size for encoding
            normalize: L2-normalize embeddings to unit length
            device: Device to use ('cpu', 'cuda', 'mps')
        """
        self.model_name = model_name
        self.dimension = dimension
        self.batch_size = batch_size
        self.normalize = normalize
        self.device = device
        self._model = None
        
        logger.info(
            f"Initializing SentenceTransformerEmbedder: "
            f"model={model_name}, dim={dimension}, device={device}"
        )
    
    def _load_model(self) -> None:
        """Lazy load the sentence-transformer model."""
        if self._model is not None:
            return
        
        try:
            from sentence_transformers import SentenceTransformer
            
            logger.info(f"Loading model: {self.model_name}")
            self._model = SentenceTransformer(self.model_name, device=self.device)
            
            # Validate dimension
            test_embedding = self._model.encode(["test"], convert_to_numpy=True)
            actual_dim = test_embedding.shape[1]
            
            if actual_dim != self.dimension:
                logger.warning(
                    f"Model dimension mismatch: expected {self.dimension}, "
                    f"got {actual_dim}. Updating dimension."
                )
                self.dimension = actual_dim
            
            logger.info(f"Model loaded successfully: {self.model_name} (dim={self.dimension})")
            
        except ImportError as e:
            logger.error("sentence-transformers not installed. Install with: pip install sentence-transformers")
            raise ImportError(
                "sentence-transformers required for SentenceTransformerEmbedder. "
                "Install with: pip install sentence-transformers"
            ) from e
    
    async def embed(self, texts: list[str]) -> np.ndarray:
        """Embed texts using sentence-transformers model.
        
        Args:
            texts: List of text strings to embed
            
        Returns:
            numpy array of shape (len(texts), dimension)
            
        Raises:
            ValueError: If texts is empty
            ImportError: If sentence-transformers not installed
        """
        if not texts:
            raise ValueError("Cannot embed empty text list")
        
        # Lazy load model
        self._load_model()
        
        logger.debug(f"Embedding {len(texts)} texts")
        
        # Encode in batches
        embeddings = self._model.encode(
            texts,
            batch_size=self.batch_size,
            show_progress_bar=len(texts) > 100,
            convert_to_numpy=True,
            normalize_embeddings=self.normalize,
        )
        
        # Ensure correct shape
        embeddings = np.array(embeddings, dtype=np.float32)
        
        if embeddings.shape[1] != self.dimension:
            logger.error(
                f"Embedding dimension mismatch: expected {self.dimension}, "
                f"got {embeddings.shape[1]}"
            )
            raise ValueError(f"Dimension mismatch: {embeddings.shape[1]} != {self.dimension}")
        
        logger.debug(f"Generated embeddings: shape={embeddings.shape}")
        return embeddings


class MockEmbedder:
    """Mock embedder for testing and development.
    
    Generates deterministic embeddings based on text hash.
    Useful for testing cache logic without loading real models.
    
    Two modes:
    - deterministic: Hash text to generate reproducible embeddings
    - random: Generate random embeddings (with optional seed)
    
    Attributes:
        dimension: Embedding dimension
        deterministic: Use deterministic hashing vs random
        seed: Random seed (if not deterministic)
    """
    
    def __init__(
        self,
        dimension: int = 384,
        deterministic: bool = True,
        seed: int = 42,
    ):
        """Initialize mock embedder.
        
        Args:
            dimension: Embedding dimension
            deterministic: Use text hash for embeddings (True) or random (False)
            seed: Random seed for non-deterministic mode
        """
        self.dimension = dimension
        self.deterministic = deterministic
        self.seed = seed
        
        if not deterministic:
            np.random.seed(seed)
        
        logger.info(
            f"Initialized MockEmbedder: dim={dimension}, "
            f"deterministic={deterministic}"
        )
    
    def _hash_to_vector(self, text: str) -> np.ndarray:
        """Convert text to deterministic vector via hashing.
        
        Args:
            text: Input text
            
        Returns:
            Normalized embedding vector
        """
        # Hash text to get deterministic seed
        text_hash = hashlib.sha256(text.encode("utf-8")).digest()
        seed = int.from_bytes(text_hash[:4], byteorder="big")
        
        # Generate vector from seed
        rng = np.random.RandomState(seed)
        vector = rng.randn(self.dimension).astype(np.float32)
        
        # Normalize to unit length
        norm = np.linalg.norm(vector)
        if norm > 0:
            vector = vector / norm
        
        return vector
    
    async def embed(self, texts: list[str]) -> np.ndarray:
        """Generate mock embeddings for texts.
        
        Args:
            texts: List of text strings
            
        Returns:
            numpy array of shape (len(texts), dimension)
            
        Raises:
            ValueError: If texts is empty
        """
        if not texts:
            raise ValueError("Cannot embed empty text list")
        
        logger.debug(f"Generating mock embeddings for {len(texts)} texts")
        
        if self.deterministic:
            # Hash-based deterministic embeddings
            embeddings = np.array([self._hash_to_vector(text) for text in texts])
        else:
            # Random embeddings
            embeddings = np.random.randn(len(texts), self.dimension).astype(np.float32)
            # Normalize
            norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
            embeddings = embeddings / np.maximum(norms, 1e-8)
        
        logger.debug(f"Generated mock embeddings: shape={embeddings.shape}")
        return embeddings


def create_embedder(
    model_name: str,
    dimension: int,
    batch_size: int = 32,
    device: str = "cpu",
    use_mock: bool = False,
) -> Embedder:
    """Factory function to create embedder instances.
    
    Args:
        model_name: Model name (for SentenceTransformer)
        dimension: Embedding dimension
        batch_size: Batch size for encoding
        device: Device to use
        use_mock: Use MockEmbedder instead of real model
        
    Returns:
        Embedder instance (SentenceTransformerEmbedder or MockEmbedder)
        
    Example:
        >>> # Create real embedder
        >>> embedder = create_embedder("all-MiniLM-L6-v2", 384)
        
        >>> # Create mock for testing
        >>> mock = create_embedder("any-model", 384, use_mock=True)
    """
    if use_mock:
        logger.info("Creating MockEmbedder")
        return MockEmbedder(dimension=dimension, deterministic=True)
    else:
        logger.info(f"Creating SentenceTransformerEmbedder: {model_name}")
        return SentenceTransformerEmbedder(
            model_name=model_name,
            dimension=dimension,
            batch_size=batch_size,
            device=device,
        )


# Example usage
if __name__ == "__main__":
    import asyncio
    
    logging.basicConfig(level=logging.INFO)
    
    async def demo():
        print("🤖 Embedder Demo\n")
        
        # Sample texts
        texts = [
            "What is machine learning?",
            "Explain neural networks",
            "What is deep learning?",
        ]
        
        # Demo 1: Mock embedder (deterministic)
        print("Demo 1: Mock Embedder (Deterministic)")
        print("-" * 60)
        mock = MockEmbedder(dimension=384, deterministic=True)
        embeddings1 = await mock.embed(texts)
        print(f"Generated embeddings: {embeddings1.shape}")
        print(f"First embedding (first 5 dims): {embeddings1[0][:5]}")
        
        # Verify determinism
        embeddings2 = await mock.embed(texts)
        print(f"Deterministic check: {np.allclose(embeddings1, embeddings2)}")
        print()
        
        # Demo 2: Mock embedder (random)
        print("Demo 2: Mock Embedder (Random)")
        print("-" * 60)
        mock_random = MockEmbedder(dimension=384, deterministic=False, seed=42)
        embeddings3 = await mock_random.embed(texts)
        print(f"Generated embeddings: {embeddings3.shape}")
        print(f"Different from deterministic: {not np.allclose(embeddings1, embeddings3)}")
        print()
        
        # Demo 3: Real embedder (commented out to avoid downloading model)
        print("Demo 3: Sentence-Transformer Embedder")
        print("-" * 60)
        print("(Skipped to avoid model download in demo)")
        print("Uncomment to test with real model:")
        print("  embedder = SentenceTransformerEmbedder('all-MiniLM-L6-v2', 384)")
        print("  embeddings = await embedder.embed(texts)")
        
        # Uncomment to test real embedder:
        # try:
        #     embedder = SentenceTransformerEmbedder("all-MiniLM-L6-v2", 384)
        #     real_embeddings = await embedder.embed(texts)
        #     print(f"Real embeddings: {real_embeddings.shape}")
        # except ImportError:
        #     print("sentence-transformers not installed")
    
    asyncio.run(demo())
