"""Document ingestion pipeline.

This module implements the ingestion workflow:
1. Read files from disk
2. Chunk text with configurable size/overlap
3. Deduplicate by content fingerprint
4. Generate embeddings in batches
5. Bulk insert to vector DB
6. Store metadata in Redis
"""

import argparse
import asyncio
import logging
from pathlib import Path
from typing import List

from llm_cache.config import load_config
from llm_cache.embedder import create_embedder
from llm_cache.storage.faiss_adapter import FaissAdapter
from llm_cache.cache.redis_cache import RedisCache
from llm_cache.keys import content_fingerprint, doc_id_from_fingerprint

logger = logging.getLogger(__name__)


def chunk_text(text: str, chunk_size: int = 512, chunk_overlap: int = 50) -> List[str]:
    """Chunk text with overlap.
    
    Args:
        text: Input text
        chunk_size: Maximum chunk size
        chunk_overlap: Overlap between chunks
        
    Returns:
        List of text chunks
    """
    if len(text) <= chunk_size:
        return [text]
    
    chunks = []
    start = 0
    
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk.strip())
        start = end - chunk_overlap
    
    return [c for c in chunks if len(c) >= 100]  # Filter short chunks


async def ingest_file(
    file_path: Path,
    embedder,
    vector_db,
    redis_cache,
    chunk_size: int = 512,
    chunk_overlap: int = 50,
) -> int:
    """Ingest single file.
    
    Args:
        file_path: Path to text file
        embedder: Embedder instance
        vector_db: Vector DB adapter
        redis_cache: Redis cache
        chunk_size: Chunk size
        chunk_overlap: Chunk overlap
        
    Returns:
        Number of chunks ingested
    """
    logger.info(f"Processing: {file_path.name}")
    
    # Read file
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Chunk
    chunks = chunk_text(content, chunk_size, chunk_overlap)
    
    if not chunks:
        logger.warning(f"No chunks generated for {file_path.name}")
        return 0
    
    # Generate fingerprint
    fp = content_fingerprint(content)
    
    # Create documents
    docs = []
    for i, chunk in enumerate(chunks):
        doc_id = doc_id_from_fingerprint(fp, i)
        docs.append({
            "id": doc_id,
            "text": chunk,
            "source": file_path.name,
            "chunk_index": i,
        })
    
    # Embed
    texts = [doc["text"] for doc in docs]
    embeddings = await embedder.embed(texts)
    
    # Bulk upsert
    docs_with_embeddings = [
        (doc["id"], embeddings[i], {
            "text": doc["text"][:500],
            "source": doc["source"],
            "chunk_index": doc["chunk_index"],
        })
        for i, doc in enumerate(docs)
    ]
    
    vector_db.bulk_upsert(docs_with_embeddings)
    
    # Store metadata
    meta_dict = {
        doc["id"]: {
            "text": doc["text"],
            "source": doc["source"],
            "chunk_index": doc["chunk_index"],
        }
        for doc in docs
    }
    redis_cache.batch_set_meta(meta_dict)
    
    logger.info(f"  ✓ Ingested {len(docs)} chunks")
    return len(docs)


async def main_async():
    """Async main function."""
    parser = argparse.ArgumentParser(description="LLM Cache Ingestion Pipeline")
    parser.add_argument("--input-dir", type=str, help="Input directory")
    parser.add_argument("--input-file", type=str, help="Single input file")
    parser.add_argument("--chunk-size", type=int, default=512)
    parser.add_argument("--chunk-overlap", type=int, default=50)
    parser.add_argument("--use-mock", action="store_true",
                       help="Use mock embedder (no model download)")
    
    args = parser.parse_args()
    
    if not args.input_dir and not args.input_file:
        parser.error("Either --input-dir or --input-file required")
    
    # Load config
    config = load_config()
    
    # Initialize components
    embedder = create_embedder(
        model_name=config.embedding.model,
        dimension=config.embedding.dimension,
        batch_size=config.embedding.batch_size,
        use_mock=args.use_mock,
    )
    
    vector_db = FaissAdapter(
        dimension=config.embedding.dimension,
        index_type="Flat",
    )
    
    redis_cache = RedisCache(
        host=config.redis.host,
        port=config.redis.port,
        db=config.redis.db,
    )
    
    logger.info("Initialized components")
    
    # Get files
    files = []
    if args.input_dir:
        input_path = Path(args.input_dir)
        files = list(input_path.glob("*.txt"))
    elif args.input_file:
        files = [Path(args.input_file)]
    
    if not files:
        logger.error("No files to process")
        return
    
    logger.info(f"Processing {len(files)} files...")
    
    # Ingest files
    total_chunks = 0
    for file_path in files:
        chunks = await ingest_file(
            file_path,
            embedder,
            vector_db,
            redis_cache,
            args.chunk_size,
            args.chunk_overlap,
        )
        total_chunks += chunks
    
    logger.info(f"\n✓ Ingestion complete: {total_chunks} total chunks")
    logger.info(f"  Vector DB count: {vector_db.count()}")


def main():
    """Main entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
