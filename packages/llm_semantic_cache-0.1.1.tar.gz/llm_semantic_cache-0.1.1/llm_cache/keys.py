"""Deterministic key generation for cache lookups.

This module provides functions for generating deterministic cache keys from:
- Query prompts (normalized and hashed)
- Content chunks (fingerprinted)
- Configuration parameters

Keys are SHA-256 hashes represented as hex strings for consistent lookups.
"""

import hashlib
import re
from typing import Optional


def normalize_text(text: str) -> str:
    """Normalize text for consistent hashing.
    
    Normalization steps:
    1. Strip leading/trailing whitespace
    2. Convert to lowercase
    3. Collapse multiple spaces/newlines to single space
    4. Remove non-alphanumeric characters (except spaces)
    
    Args:
        text: Input text to normalize
        
    Returns:
        Normalized text string
        
    Examples:
        >>> normalize_text("  Hello   World!  ")
        'hello world'
        >>> normalize_text("What is\\n\\nMachine Learning?")
        'what is machine learning'
        >>> normalize_text("A  B    C")
        'a b c'
    """
    # Strip and lowercase
    text = text.strip().lower()
    
    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Remove special characters, keep alphanumeric and spaces
    text = re.sub(r'[^a-z0-9\s]', '', text)
    
    return text.strip()


def query_key(
    prompt: str,
    top_k: int,
    embed_model: str,
    chunking_hash: Optional[str] = None,
) -> str:
    """Generate deterministic cache key for a query.
    
    The key uniquely identifies a query configuration, ensuring that
    identical semantic queries hit the same cache entry.
    
    Key components:
    - Normalized prompt text
    - top_k parameter (affects result set)
    - Embedding model name (different models = different embeddings)
    - Chunking configuration hash (optional, for ingestion settings)
    
    Args:
        prompt: User query/prompt text
        top_k: Number of results requested
        embed_model: Name of embedding model
        chunking_hash: Optional hash of chunking configuration
        
    Returns:
        64-character hex SHA-256 hash
        
    Examples:
        >>> key1 = query_key("What is AI?", 5, "all-MiniLM-L6-v2")
        >>> key2 = query_key("what is ai", 5, "all-MiniLM-L6-v2")
        >>> key1 == key2  # Normalization makes queries match
        True
        
        >>> key3 = query_key("What is AI?", 10, "all-MiniLM-L6-v2")
        >>> key1 == key3  # Different top_k = different key
        False
        
        >>> key4 = query_key("What is AI?", 5, "different-model")
        >>> key1 == key4  # Different model = different key
        False
    """
    # Normalize prompt for consistency
    normalized_prompt = normalize_text(prompt)
    
    # Build key components
    key_components = [
        normalized_prompt,
        str(top_k),
        embed_model.lower().strip(),
    ]
    
    if chunking_hash:
        key_components.append(chunking_hash)
    
    # Join and hash
    key_string = "|".join(key_components)
    hash_obj = hashlib.sha256(key_string.encode("utf-8"))
    
    return hash_obj.hexdigest()


def content_fingerprint(text: str) -> str:
    """Generate content fingerprint for deduplication.
    
    Creates a deterministic hash of text content for detecting duplicates
    during ingestion. Uses SHA-256 for cryptographic uniqueness.
    
    Args:
        text: Text content to fingerprint
        
    Returns:
        64-character hex SHA-256 hash
        
    Examples:
        >>> fp1 = content_fingerprint("This is a document.")
        >>> fp2 = content_fingerprint("This is a document.")
        >>> fp1 == fp2
        True
        
        >>> fp3 = content_fingerprint("This is different.")
        >>> fp1 == fp3
        False
        
        >>> len(content_fingerprint("test"))
        64
    """
    # Hash raw content (preserve exact text including whitespace/case)
    hash_obj = hashlib.sha256(text.encode("utf-8"))
    return hash_obj.hexdigest()


def chunking_config_hash(
    chunk_size: int,
    chunk_overlap: int,
    separator: str = "\n\n",
) -> str:
    """Generate hash of chunking configuration.
    
    This hash is used as part of query keys to ensure queries with
    different chunking settings use different cache entries.
    
    Args:
        chunk_size: Maximum characters per chunk
        chunk_overlap: Overlap between chunks
        separator: Chunking separator
        
    Returns:
        16-character hex hash (truncated SHA-256)
        
    Examples:
        >>> hash1 = chunking_config_hash(512, 50)
        >>> hash2 = chunking_config_hash(512, 50)
        >>> hash1 == hash2
        True
        
        >>> hash3 = chunking_config_hash(1024, 50)
        >>> hash1 == hash3
        False
        
        >>> len(chunking_config_hash(512, 50))
        16
    """
    config_string = f"{chunk_size}|{chunk_overlap}|{separator}"
    hash_obj = hashlib.sha256(config_string.encode("utf-8"))
    # Return first 16 chars for brevity
    return hash_obj.hexdigest()[:16]


def doc_id_from_fingerprint(
    fingerprint: str,
    chunk_index: int,
) -> str:
    """Generate document ID from content fingerprint and chunk index.
    
    Creates a unique document ID for storage in vector DB and metadata store.
    Format: {fingerprint_prefix}_{chunk_index}
    
    Args:
        fingerprint: Content fingerprint (SHA-256 hash)
        chunk_index: Index of chunk within document (0-based)
        
    Returns:
        Document ID string
        
    Examples:
        >>> fp = content_fingerprint("Sample text")
        >>> doc_id = doc_id_from_fingerprint(fp, 0)
        >>> doc_id.endswith("_0")
        True
        >>> "_" in doc_id
        True
        
        >>> doc_id_2 = doc_id_from_fingerprint(fp, 5)
        >>> doc_id_2.endswith("_5")
        True
    """
    # Use first 12 chars of fingerprint for readability
    prefix = fingerprint[:12]
    return f"{prefix}_{chunk_index}"


def validate_query_key(key: str) -> bool:
    """Validate that a string is a valid query key format.
    
    Args:
        key: Potential query key string
        
    Returns:
        True if valid (64-char hex), False otherwise
        
    Examples:
        >>> valid_key = query_key("test", 5, "model")
        >>> validate_query_key(valid_key)
        True
        
        >>> validate_query_key("invalid")
        False
        
        >>> validate_query_key("a" * 64)
        True
        
        >>> validate_query_key("z" * 64)  # Invalid hex
        False
    """
    if len(key) != 64:
        return False
    
    try:
        # Check if valid hex
        int(key, 16)
        return True
    except ValueError:
        return False


def batch_fingerprint(texts: list[str]) -> list[str]:
    """Generate fingerprints for multiple texts efficiently.
    
    Args:
        texts: List of text strings to fingerprint
        
    Returns:
        List of fingerprints in same order
        
    Examples:
        >>> texts = ["doc1", "doc2", "doc1"]
        >>> fps = batch_fingerprint(texts)
        >>> len(fps)
        3
        >>> fps[0] == fps[2]  # Same content = same fingerprint
        True
    """
    return [content_fingerprint(text) for text in texts]


# Example usage and testing
if __name__ == "__main__":
    print("🔑 LLM Cache Platform - Key Generation Examples\n")
    
    # Example 1: Query keys with normalization
    print("Example 1: Query Key Generation")
    print("-" * 60)
    
    queries = [
        "What is machine learning?",
        "what is machine learning",
        "  WHAT IS   MACHINE   LEARNING?  ",
    ]
    
    for q in queries:
        key = query_key(q, top_k=5, embed_model="all-MiniLM-L6-v2")
        print(f"Query: {q!r}")
        print(f"Key:   {key}")
        print()
    
    print("All three queries generate the same key (normalization works!)\n")
    
    # Example 2: Different parameters = different keys
    print("Example 2: Parameter Sensitivity")
    print("-" * 60)
    
    base_query = "What is AI?"
    
    configs = [
        (5, "all-MiniLM-L6-v2"),
        (10, "all-MiniLM-L6-v2"),  # Different top_k
        (5, "different-model"),     # Different model
    ]
    
    for top_k, model in configs:
        key = query_key(base_query, top_k, model)
        print(f"top_k={top_k}, model={model}")
        print(f"Key: {key[:32]}...")
        print()
    
    # Example 3: Content fingerprinting
    print("Example 3: Content Fingerprinting")
    print("-" * 60)
    
    doc1 = "This is a sample document."
    doc2 = "This is a sample document."
    doc3 = "This is different content."
    
    fp1 = content_fingerprint(doc1)
    fp2 = content_fingerprint(doc2)
    fp3 = content_fingerprint(doc3)
    
    print(f"Document 1 fingerprint: {fp1}")
    print(f"Document 2 fingerprint: {fp2}")
    print(f"Match: {fp1 == fp2}\n")
    
    print(f"Document 3 fingerprint: {fp3}")
    print(f"Different from 1: {fp1 != fp3}\n")
    
    # Example 4: Document IDs
    print("Example 4: Document ID Generation")
    print("-" * 60)
    
    doc_text = "Sample document for chunking"
    fp = content_fingerprint(doc_text)
    
    for i in range(3):
        doc_id = doc_id_from_fingerprint(fp, i)
        print(f"Chunk {i} -> Document ID: {doc_id}")
