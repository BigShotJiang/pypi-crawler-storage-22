"""Capacity planning and storage estimation utilities.

This module provides mathematical functions for calculating storage requirements
for vector databases with various compression techniques:

- Raw embeddings storage (float32)
- Product Quantization (PQ) compression
- HNSW index overhead
- Combined storage estimates

All functions include detailed docstrings with examples for N=10M vectors, d=1536 dimensions.
"""

from typing import Tuple


def bytes_to_human_readable(num_bytes: int) -> str:
    """Convert bytes to human-readable format.
    
    Args:
        num_bytes: Number of bytes
        
    Returns:
        Human-readable string (e.g., "1.5 GB", "500 MB")
        
    Examples:
        >>> bytes_to_human_readable(1024)
        '1.0 KB'
        >>> bytes_to_human_readable(1024**3)
        '1.0 GB'
    """
    for unit in ["B", "KB", "MB", "GB", "TB", "PB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


def raw_embeddings_bytes(N: int, d: int, dtype_bytes: int = 4) -> Tuple[int, str]:
    """Calculate storage for raw embeddings without compression.
    
    Formula: N * d * sizeof(float32)
    
    Args:
        N: Number of vectors
        d: Dimension of each vector
        dtype_bytes: Bytes per element (4 for float32, 2 for float16)
        
    Returns:
        Tuple of (bytes, human_readable_string)
        
    Examples:
        >>> # 10M vectors, 1536 dimensions, float32
        >>> raw_bytes, human = raw_embeddings_bytes(10_000_000, 1536, 4)
        >>> raw_bytes
        61440000000
        >>> human
        '57.2 GB'
        
        >>> # Same with float16
        >>> raw_bytes, human = raw_embeddings_bytes(10_000_000, 1536, 2)
        >>> human
        '28.6 GB'
    
    Notes:
        For N=10M, d=1536 (OpenAI ada-002):
        - float32: ~61.4 GB
        - float16: ~30.7 GB
    """
    total_bytes = N * d * dtype_bytes
    return total_bytes, bytes_to_human_readable(total_bytes)


def pq_bytes(
    N: int,
    m: int,
    bytes_per_subvector: int = 1,
    include_codebooks: bool = True,
    codebook_size: int = 256,
    subvector_dim: int = 8,
) -> Tuple[int, str]:
    """Calculate storage for Product Quantization compressed embeddings.
    
    Product Quantization splits each d-dimensional vector into m subvectors,
    then quantizes each subvector to a code (typically 8-bit = 1 byte).
    
    Formula: 
        Compressed vectors: N * m * bytes_per_subvector
        Codebooks: m * codebook_size * subvector_dim * 4 (if included)
    
    Args:
        N: Number of vectors
        m: Number of subquantizers (splits d into m parts)
        bytes_per_subvector: Bytes per quantized code (1 for 8-bit)
        include_codebooks: Include codebook storage in calculation
        codebook_size: Size of each codebook (2^nbits, typically 256 for 8-bit)
        subvector_dim: Dimension of each subvector (d / m)
        
    Returns:
        Tuple of (bytes, human_readable_string)
        
    Examples:
        >>> # 10M vectors, 64 subquantizers, 8-bit codes
        >>> pq_compressed, human = pq_bytes(10_000_000, 64, 1)
        >>> pq_compressed >= 640_000_000  # At least N * m bytes
        True
        >>> # Storage is dramatically reduced vs raw
        
        >>> # Calculate compression ratio
        >>> raw, _ = raw_embeddings_bytes(10_000_000, 1536)
        >>> pq, _ = pq_bytes(10_000_000, 64, 1)
        >>> compression_ratio = raw / pq
        >>> compression_ratio > 90  # ~96x compression
        True
    
    Notes:
        For N=10M, d=1536, m=64, 8-bit codes:
        - Compressed vectors: ~610 MB
        - Codebooks: ~2 MB (negligible)
        - Total: ~612 MB
        - Compression: 96x vs raw float32
    """
    # Storage for compressed vectors
    compressed_vectors_bytes = N * m * bytes_per_subvector
    
    # Storage for codebooks (usually negligible)
    codebooks_bytes = 0
    if include_codebooks:
        codebooks_bytes = m * codebook_size * subvector_dim * 4  # float32
    
    total_bytes = compressed_vectors_bytes + codebooks_bytes
    return total_bytes, bytes_to_human_readable(total_bytes)


def hnsw_overhead_bytes(
    N: int,
    M: int,
    pointer_size: int = 8,
    avg_level: float = 1.5,
) -> Tuple[int, str]:
    """Calculate HNSW index graph overhead.
    
    HNSW stores a hierarchical graph with M bi-directional links per node.
    Each link is a pointer (8 bytes on 64-bit systems).
    
    Formula (approximate):
        N * M * 2 * pointer_size * avg_level
    
    Args:
        N: Number of vectors
        M: Number of bi-directional links per node
        pointer_size: Bytes per pointer (8 for 64-bit systems)
        avg_level: Average number of levels per node (1.5 typical)
        
    Returns:
        Tuple of (bytes, human_readable_string)
        
    Examples:
        >>> # 10M vectors, M=16
        >>> overhead, human = hnsw_overhead_bytes(10_000_000, 16)
        >>> overhead
        3840000000
        >>> human
        '3.6 GB'
        
        >>> # Higher M = more memory but better recall
        >>> overhead_m32, _ = hnsw_overhead_bytes(10_000_000, 32)
        >>> overhead_m16, _ = hnsw_overhead_bytes(10_000_000, 16)
        >>> overhead_m32 / overhead_m16
        2.0
    
    Notes:
        For N=10M, M=16:
        - Graph overhead: ~3.8 GB
        - This is in addition to vector storage
    """
    # Each node has M*2 links (bi-directional), times avg levels
    total_bytes = int(N * M * 2 * pointer_size * avg_level)
    return total_bytes, bytes_to_human_readable(total_bytes)


def combined_storage_estimate(
    N: int,
    d: int,
    M: int = 16,
    use_pq: bool = True,
    pq_m: int = 64,
) -> dict:
    """Calculate combined storage for HNSW + vectors with optional PQ.
    
    Args:
        N: Number of vectors
        d: Vector dimension
        M: HNSW M parameter
        use_pq: Use Product Quantization compression
        pq_m: Number of PQ subquantizers
        
    Returns:
        Dictionary with breakdown of storage components
        
    Example:
        >>> # 10M vectors, 1536 dimensions, with PQ compression
        >>> estimate = combined_storage_estimate(10_000_000, 1536, M=16, use_pq=True, pq_m=64)
        >>> estimate['total_bytes'] < 5_000_000_000  # Less than 5 GB
        True
        >>> estimate['compression_ratio'] > 10  # Significant compression
        True
        
        >>> # Without PQ compression
        >>> estimate_raw = combined_storage_estimate(10_000_000, 1536, M=16, use_pq=False)
        >>> estimate_raw['total_bytes'] > estimate['total_bytes']
        True
    """
    # Calculate raw storage
    raw_bytes, raw_human = raw_embeddings_bytes(N, d)
    
    # Calculate vector storage (PQ or raw)
    if use_pq:
        vector_bytes, vector_human = pq_bytes(N, pq_m)
        compression_ratio = raw_bytes / vector_bytes if vector_bytes > 0 else 1.0
    else:
        vector_bytes, vector_human = raw_bytes, raw_human
        compression_ratio = 1.0
    
    # Calculate HNSW overhead
    hnsw_bytes, hnsw_human = hnsw_overhead_bytes(N, M)
    
    # Total
    total_bytes = vector_bytes + hnsw_bytes
    total_human = bytes_to_human_readable(total_bytes)
    
    return {
        "N": N,
        "d": d,
        "M": M,
        "use_pq": use_pq,
        "pq_m": pq_m if use_pq else None,
        "raw_bytes": raw_bytes,
        "raw_human": raw_human,
        "vector_bytes": vector_bytes,
        "vector_human": vector_human,
        "hnsw_bytes": hnsw_bytes,
        "hnsw_human": hnsw_human,
        "total_bytes": total_bytes,
        "total_human": total_human,
        "compression_ratio": compression_ratio,
    }


def print_storage_breakdown(
    N: int,
    d: int,
    M: int = 16,
    use_pq: bool = True,
    pq_m: int = 64,
) -> None:
    """Pretty-print storage breakdown with all components.
    
    Args:
        N: Number of vectors
        d: Vector dimension
        M: HNSW M parameter
        use_pq: Use Product Quantization
        pq_m: Number of PQ subquantizers
        
    Example:
        >>> print_storage_breakdown(10_000_000, 1536, M=16, use_pq=True, pq_m=64)
        ============================================================
        Storage Estimate for 10,000,000 vectors (d=1536)
        ============================================================
        Raw embeddings (float32):      57.2 GB
        <BLANKLINE>
        With Product Quantization (m=64):
          Compressed vectors:           610.4 MB
          Compression ratio:            96.0x
        <BLANKLINE>
        HNSW index overhead (M=16):     3.6 GB
        <BLANKLINE>
        ============================================================
        TOTAL (PQ + HNSW):              4.2 GB
        ============================================================
    """
    estimate = combined_storage_estimate(N, d, M, use_pq, pq_m)
    
    print("=" * 60)
    print(f"Storage Estimate for {N:,} vectors (d={d})")
    print("=" * 60)
    print(f"Raw embeddings (float32):      {estimate['raw_human']:>10}")
    print()
    
    if use_pq:
        print(f"With Product Quantization (m={pq_m}):")
        print(f"  Compressed vectors:           {estimate['vector_human']:>10}")
        print(f"  Compression ratio:            {estimate['compression_ratio']:.1f}x")
    else:
        print("No compression (using raw embeddings)")
    
    print()
    print(f"HNSW index overhead (M={M}):     {estimate['hnsw_human']:>10}")
    print()
    print("=" * 60)
    
    if use_pq:
        print(f"TOTAL (PQ + HNSW):              {estimate['total_human']:>10}")
    else:
        print(f"TOTAL (Raw + HNSW):             {estimate['total_human']:>10}")
    
    print("=" * 60)


# Example calculations for documentation
if __name__ == "__main__":
    print("\n🔢 LLM Cache Platform - Storage Calculator\n")
    
    # Standard OpenAI ada-002 dimensions
    N = 10_000_000
    d = 1536
    
    print("Example 1: 10M vectors, 1536 dimensions (OpenAI ada-002 size)")
    print_storage_breakdown(N, d, M=16, use_pq=True, pq_m=64)
    
    print("\n" + "=" * 60 + "\n")
    
    print("Example 2: Same dataset without compression")
    print_storage_breakdown(N, d, M=16, use_pq=False)
    
    print("\n" + "=" * 60 + "\n")
    
    # Smaller dimension example (sentence-transformers)
    N_small = 1_000_000
    d_small = 384
    
    print("Example 3: 1M vectors, 384 dimensions (all-MiniLM-L6-v2)")
    print_storage_breakdown(N_small, d_small, M=16, use_pq=False)
