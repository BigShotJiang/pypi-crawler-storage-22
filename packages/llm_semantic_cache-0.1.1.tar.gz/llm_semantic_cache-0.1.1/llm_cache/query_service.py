"""Query service - Multi-tier query execution engine.

This module implements the complete query flow:
1. Check local HNSW cache
2. Check Redis cache
3. Query vector DB
4. Populate caches on miss
5. Track metrics and latencies
"""

import argparse
import asyncio
import logging
import time
from typing import Optional

import numpy as np

from llm_cache.config import load_config
from llm_cache.embedder import create_embedder
from llm_cache.storage.faiss_adapter import FaissAdapter
from llm_cache.cache.local_hnsw import LocalHNSWCache
from llm_cache.cache.redis_cache import RedisCache
from llm_cache.keys import query_key

logger = logging.getLogger(__name__)


class QueryService:
    """Query execution service with multi-tier caching."""
    
    def __init__(self, config=None, use_mock: bool = False):
        """Initialize query service.
        
        Args:
            config: Configuration object
            use_mock: Use mock embedder
        """
        self.config = config or load_config()
        
        # Initialize embedder
        self.embedder = create_embedder(
            model_name=self.config.embedding.model,
            dimension=self.config.embedding.dimension,
            batch_size=self.config.embedding.batch_size,
            use_mock=use_mock,
        )
        
        # Vector DB
        self.vector_db = FaissAdapter(
            dimension=self.config.embedding.dimension,
            index_type="Flat",
        )
        
        # Redis
        self.redis = RedisCache(
            host=self.config.redis.host,
            port=self.config.redis.port,
            db=self.config.redis.db,
        )
        
        # Local HNSW
        self.local_cache = LocalHNSWCache(
            dimension=self.config.embedding.dimension,
            max_elements=self.config.hnsw.hot_cache_size,
            M=self.config.hnsw.M,
            ef_construction=self.config.hnsw.ef_construction,
            ef_search=self.config.hnsw.ef_search,
        )
        
        logger.info("Initialized QueryService")
    
    async def query(
        self,
        query_text: str,
        top_k: int = 5,
        verbose: bool = True,
    ) -> list[dict]:
        """Execute query with cache lookup.
        
        Args:
            query_text: Query string
            top_k: Number of results
            verbose: Print detailed output
            
        Returns:
            List of result dictionaries
        """
        start_time = time.time()
        
        # Generate query key
        q_key = query_key(
            query_text,
            top_k=top_k,
            embed_model=self.config.embedding.model,
        )
        
        cache_tier = "MISS"
        results = []
        
        # Tier A: Local HNSW
        if self.local_cache.count() > 0:
            query_embedding = await self.embedder.embed([query_text])
            local_results = self.local_cache.knn_query(query_embedding[0], k=top_k)
            
            if local_results:
                cache_tier = "LOCAL_HNSW"
                doc_ids = [r[0] for r in local_results]
                meta_map = self.redis.batch_get_meta(doc_ids)
                
                for doc_id, score in local_results:
                    meta = meta_map.get(doc_id, {})
                    results.append({
                        "id": doc_id,
                        "score": score,
                        "text": meta.get("text", ""),
                        "source": meta.get("source", ""),
                    })
        
        # Tier B: Redis
        if not results:
            cached = self.redis.get_query_cache(q_key)
            if cached:
                cache_tier = "REDIS"
                results = cached
                self.redis.increment_hit_count(q_key)
        
        # Tier C: Vector DB
        if not results:
            cache_tier = "VECTOR_DB"
            
            query_embedding = await self.embedder.embed([query_text])
            db_results = self.vector_db.search(query_embedding[0], top_k=top_k)
            
            doc_ids = [r[0] for r in db_results]
            meta_map = self.redis.batch_get_meta(doc_ids)
            
            for doc_id, score in db_results:
                meta = meta_map.get(doc_id, {})
                results.append({
                    "id": doc_id,
                    "score": score,
                    "text": meta.get("text", ""),
                    "source": meta.get("source", ""),
                })
            
            # Cache results
            self.redis.set_query_cache(q_key, results)
            
            # Add to local cache
            if results:
                doc_ids = [r["id"] for r in results]
                # Get vectors from DB to populate local cache
                vectors = self.vector_db.get_vectors(doc_ids)
                
                # Filter out None vectors (if DB doesn't support reconstruction)
                valid_ids = []
                valid_vectors = []
                for doc_id, vector in zip(doc_ids, vectors):
                    if vector is not None:
                        valid_ids.append(doc_id)
                        valid_vectors.append(vector)
                
                if valid_ids:
                    self.local_cache.add_items(valid_ids, np.array(valid_vectors))
        
        latency_ms = (time.time() - start_time) * 1000
        
        if verbose:
            print(f"\n{'='*70}")
            print(f"Query: {query_text}")
            print(f"Cache Tier: {cache_tier} | Latency: {latency_ms:.2f}ms")
            print(f"{'-'*70}")
            
            for i, result in enumerate(results, 1):
                print(f"{i}. [{result.get('source', 'unknown')}] "
                      f"Score: {result['score']:.4f}")
                print(f"   {result.get('text', '')[:150]}...")
                print()
        
        return results


async def main_async():
    """Async main function."""
    parser = argparse.ArgumentParser(description="LLM Cache Query Service")
    parser.add_argument("--query", type=str, help="Query text")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--use-mock", action="store_true")
    parser.add_argument("--interactive", action="store_true",
                       help="Interactive mode")
    
    args = parser.parse_args()
    
    # Initialize service
    service = QueryService(use_mock=args.use_mock)
    
    if args.interactive:
        print("Interactive Query Mode (Ctrl+C to exit)")
        print("=" * 70)
        
        while True:
            try:
                query = input("\nEnter query: ").strip()
                if not query:
                    continue
                
                await service.query(query, top_k=args.top_k)
            
            except KeyboardInterrupt:
                print("\n\nExiting...")
                break
    
    elif args.query:
        await service.query(args.query, top_k=args.top_k)
    
    else:
        parser.error("Either --query or --interactive required")


def main():
    """Main entry point."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
