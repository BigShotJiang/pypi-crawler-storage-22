"""Storage adapters for vector databases.

This subpackage provides:
- VectorDBAdapter: Abstract interface for vector stores
- FaissAdapter: Facebook AI Similarity Search adapter
- QdrantAdapter: Qdrant vector database adapter (optional)
"""

from llm_cache.storage.vector_db_interface import VectorDBAdapter
from llm_cache.storage.faiss_adapter import FaissAdapter

__all__ = ["VectorDBAdapter", "FaissAdapter"]

# Optional: Qdrant support
try:
    from llm_cache.storage.qdrant_adapter import QdrantAdapter
    __all__.append("QdrantAdapter")
except ImportError:
    pass  # qdrant-client not installed
