"""Faiss vector database adapter.

This module provides a production-ready adapter for Facebook's Faiss library,
supporting:
- Multiple index types (Flat, IVF, IVFPQ, HNSW)
- Product Quantization compression
- Persistent index snapshots
- Batch operations

Faiss is optimized for billion-scale similarity search with compression.
"""

import logging
import pickle
from pathlib import Path
from typing import Optional

import numpy as np

from llm_cache.storage.vector_db_interface import VectorDBAdapterBase

logger = logging.getLogger(__name__)


class FaissAdapter(VectorDBAdapterBase):
    """Faiss vector database adapter with support for various index types.
    
    Supports:
    - IndexFlatL2: Exact search (no compression)
    - IndexIVFFlat: Inverted file index (faster search)
    - IndexIVFPQ: IVF + Product Quantization (compressed)
    - IndexHNSWFlat: HNSW graph index (fast approximate)
    
    Attributes:
        dimension: Vector dimension
        index_type: Type of index ('Flat', 'IVF', 'IVFPQ', 'HNSW')
        metric: Distance metric ('L2' or 'IP' for inner product)
        index: Faiss index object
        id_map: Mapping from internal index to doc_id
    """
    
    def __init__(
        self,
        dimension: int,
        index_type: str = "Flat",
        metric: str = "L2",
        nlist: int = 1024,
        nprobe: int = 8,
        pq_m: Optional[int] = None,
        pq_nbits: int = 8,
        hnsw_m: int = 32,
    ):
        """Initialize Faiss adapter.
        
        Args:
            dimension: Vector dimension
            index_type: 'Flat', 'IVF', 'IVFPQ', or 'HNSW'
            metric: 'L2' or 'IP' (inner product)
            nlist: Number of clusters for IVF (ignored for Flat/HNSW)
            nprobe: Number of clusters to search (ignored for Flat/HNSW)
            pq_m: Number of PQ subquantizers (for IVFPQ)
            pq_nbits: Bits per PQ code (typically 8)
            hnsw_m: Number of connections per node for HNSW
        """
        super().__init__(dimension)
        
        self.index_type = index_type
        self.metric = metric
        self.nlist = nlist
        self.nprobe = nprobe
        self.pq_m = pq_m or dimension // 8  # Default: split into 8-dim subvectors
        self.pq_nbits = pq_nbits
        self.hnsw_m = hnsw_m
        
        # Document ID mapping (Faiss uses integer IDs internally)
        self.id_map: dict[int, str] = {}
        self.reverse_id_map: dict[str, int] = {}
        self.next_id = 0
        
        # Metadata storage (Faiss doesn't store metadata)
        self.metadata: dict[str, dict] = {}
        
        # Initialize index
        self.index = self._create_index()
        
        logger.info(
            f"Initialized FaissAdapter: type={index_type}, dim={dimension}, "
            f"metric={metric}"
        )
    
    def _create_index(self) -> "faiss.Index":  # type: ignore
        """Create Faiss index based on configuration.
        
        Returns:
            Faiss index object
        """
        try:
            import faiss
        except ImportError:
            raise ImportError(
                "faiss-cpu or faiss-gpu required. Install with: pip install faiss-cpu"
            )
        
        if self.index_type == "Flat":
            # Exact search, no compression
            if self.metric == "L2":
                index = faiss.IndexFlatL2(self.dimension)
            else:  # IP
                index = faiss.IndexFlatIP(self.dimension)
            
            logger.info("Created IndexFlat (exact search)")
        
        elif self.index_type == "IVF":
            # Inverted file index (faster search, exact vectors)
            if self.metric == "L2":
                quantizer = faiss.IndexFlatL2(self.dimension)
                index = faiss.IndexIVFFlat(quantizer, self.dimension, self.nlist)
            else:
                quantizer = faiss.IndexFlatIP(self.dimension)
                index = faiss.IndexIVFFlat(quantizer, self.dimension, self.nlist)
            
            index.nprobe = self.nprobe
            logger.info(f"Created IndexIVFFlat (nlist={self.nlist}, nprobe={self.nprobe})")
        
        elif self.index_type == "IVFPQ":
            # IVF + Product Quantization (compressed)
            if self.metric == "L2":
                quantizer = faiss.IndexFlatL2(self.dimension)
            else:
                quantizer = faiss.IndexFlatIP(self.dimension)
            
            index = faiss.IndexIVFPQ(
                quantizer,
                self.dimension,
                self.nlist,
                self.pq_m,
                self.pq_nbits,
            )
            index.nprobe = self.nprobe
            
            logger.info(
                f"Created IndexIVFPQ (nlist={self.nlist}, m={self.pq_m}, "
                f"nbits={self.pq_nbits})"
            )
        
        elif self.index_type == "HNSW":
            # HNSW graph index (fast approximate search)
            if self.metric == "L2":
                index = faiss.IndexHNSWFlat(self.dimension, self.hnsw_m)
            else:
                index = faiss.IndexHNSWFlat(self.dimension, self.hnsw_m, faiss.METRIC_INNER_PRODUCT)
            
            logger.info(f"Created IndexHNSWFlat (M={self.hnsw_m})")
        
        else:
            raise ValueError(f"Unsupported index type: {self.index_type}")
        
        return index
    
    def _train_if_needed(self, vectors: np.ndarray) -> None:
        """Train index if required (IVF/IVFPQ need training).
        
        Args:
            vectors: Training vectors
        """
        if self.index_type in ["IVF", "IVFPQ"] and not self.index.is_trained:
            logger.info(f"Training index on {len(vectors)} vectors...")
            self.index.train(vectors)
            logger.info("Index training complete")
    
    def bulk_upsert(
        self,
        docs: list[tuple[str, np.ndarray, dict]],
    ) -> None:
        """Insert documents into Faiss index.
        
        Args:
            docs: List of (doc_id, vector, metadata) tuples
        """
        self.validate_docs(docs)
        
        # Extract components
        doc_ids = [doc[0] for doc in docs]
        vectors = np.array([doc[1] for doc in docs], dtype=np.float32)
        metadatas = [doc[2] for doc in docs]
        
        # Ensure 2D shape
        if vectors.ndim == 1:
            vectors = vectors.reshape(1, -1)
        
        # Train if needed
        self._train_if_needed(vectors)
        
        # Assign internal IDs and store mappings
        internal_ids = []
        for doc_id, metadata in zip(doc_ids, metadatas):
            if doc_id in self.reverse_id_map:
                # Update existing
                internal_id = self.reverse_id_map[doc_id]
                logger.debug(f"Updating existing document: {doc_id}")
            else:
                # Add new
                internal_id = self.next_id
                self.id_map[internal_id] = doc_id
                self.reverse_id_map[doc_id] = internal_id
                self.next_id += 1
            
            internal_ids.append(internal_id)
            self.metadata[doc_id] = metadata
        
        # Add to index
        self.index.add(vectors)
        
        logger.info(f"Added {len(docs)} documents to Faiss index")
    
    def search(
        self,
        vector: np.ndarray,
        top_k: int,
        filters: Optional[dict] = None,
    ) -> list[tuple[str, float]]:
        """Search for similar vectors.
        
        Args:
            vector: Query vector
            top_k: Number of results
            filters: Not supported in Faiss (metadata filtering)
            
        Returns:
            List of (doc_id, score) tuples
        """
        self.validate_vector(vector)
        
        if top_k <= 0:
            raise ValueError(f"top_k must be positive, got {top_k}")
        
        # Ensure 2D shape
        if vector.ndim == 1:
            vector = vector.reshape(1, -1)
        
        vector = vector.astype(np.float32)

        # Check for empty index
        if self.count() == 0:
            return []
        
        # Search
        scores, indices = self.index.search(vector, min(top_k, self.count()))
        
        # Convert to doc_ids
        results = []
        for idx, score in zip(indices[0], scores[0]):
            if idx >= 0 and idx in self.id_map:  # Valid result
                doc_id = self.id_map[idx]
                results.append((doc_id, float(score)))
        
        # Apply filters if provided (post-filtering)
        if filters:
            logger.warning("Faiss does not support native filtering, using post-filter")
            filtered_results = []
            for doc_id, score in results:
                if self._matches_filters(doc_id, filters):
                    filtered_results.append((doc_id, score))
            results = filtered_results
        
        logger.debug(f"Search returned {len(results)} results")
        return results
    
    def _matches_filters(self, doc_id: str, filters: dict) -> bool:
        """Check if document matches metadata filters.
        
        Args:
            doc_id: Document ID
            filters: Filter dictionary
            
        Returns:
            True if matches
        """
        if doc_id not in self.metadata:
            return False
        
        metadata = self.metadata[doc_id]
        for key, value in filters.items():
            if key not in metadata or metadata[key] != value:
                return False
        
        return True
    
    def delete(self, doc_id: str) -> None:
        """Delete document.
        
        Note: Faiss does not support efficient deletion.
        This marks the document as deleted but doesn't remove from index.
        Consider rebuilding index periodically.
        
        Args:
            doc_id: Document ID to delete
        """
        if doc_id not in self.reverse_id_map:
            logger.warning(f"Document not found: {doc_id}")
            return
        
        # Remove from mappings
        internal_id = self.reverse_id_map[doc_id]
        del self.id_map[internal_id]
        del self.reverse_id_map[doc_id]
        del self.metadata[doc_id]
        
        logger.info(
            f"Deleted document {doc_id} from mappings "
            "(Faiss index not modified - rebuild recommended)"
        )
    
    def count(self) -> int:
        """Get number of vectors in index.
        
        Returns:
            Vector count
        """
        return self.index.ntotal  # type: ignore
    
    def save(self, path: str) -> None:
        """Save index and mappings to disk.
        
        Args:
            path: Path to save (will create .index and .meta files)
        """
        try:
            import faiss
        except ImportError:
            raise ImportError("faiss-cpu required for save")
        
        path_obj = Path(path)
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        
        # Save index
        index_path = str(path_obj.with_suffix(".index"))
        faiss.write_index(self.index, index_path)
        
        # Save mappings and metadata
        meta_path = str(path_obj.with_suffix(".meta"))
        with open(meta_path, "wb") as f:
            pickle.dump({
                "id_map": self.id_map,
                "reverse_id_map": self.reverse_id_map,
                "metadata": self.metadata,
                "next_id": self.next_id,
                "config": {
                    "dimension": self.dimension,
                    "index_type": self.index_type,
                    "metric": self.metric,
                    "nlist": self.nlist,
                    "nprobe": self.nprobe,
                }
            }, f)
        
        logger.info(f"Saved Faiss index to {index_path} and {meta_path}")
    
    def load(self, path: str) -> None:
        """Load index and mappings from disk.
        
        Args:
            path: Path to load from
        """
        try:
            import faiss
        except ImportError:
            raise ImportError("faiss-cpu required for load")
        
        path_obj = Path(path)
        
        # Load index
        index_path = str(path_obj.with_suffix(".index"))
        self.index = faiss.read_index(index_path)
        
        # Load mappings
        meta_path = str(path_obj.with_suffix(".meta"))
        with open(meta_path, "rb") as f:
            data = pickle.load(f)
        
        self.id_map = data["id_map"]
        self.reverse_id_map = data["reverse_id_map"]
        self.metadata = data["metadata"]
        self.next_id = data["next_id"]
        
        # Update config
        config = data.get("config", {})
        self.dimension = config.get("dimension", self.dimension)
        
        logger.info(f"Loaded Faiss index from {index_path} ({self.count()} vectors)")
    
    def get_vectors(self, doc_ids: list[str]) -> list[Optional[np.ndarray]]:
        """Get vectors for specific document IDs.
        
        Args:
            doc_ids: List of document IDs
            
        Returns:
            List of vectors (or None if not found/supported)
        """
        vectors: list[Optional[np.ndarray]] = []
        for doc_id in doc_ids:
            if doc_id not in self.reverse_id_map:
                vectors.append(None)
                continue
            
            internal_id = self.reverse_id_map[doc_id]
            try:
                # Try to reconstruct vector from index
                # Note: This works for Flat indexes and IVF if make_direct_map() was called
                vector = self.index.reconstruct(internal_id)
                vectors.append(vector)
            except RuntimeError:
                # Index doesn't support reconstruction (e.g. PQ without direct map)
                vectors.append(None)
        
        return vectors
