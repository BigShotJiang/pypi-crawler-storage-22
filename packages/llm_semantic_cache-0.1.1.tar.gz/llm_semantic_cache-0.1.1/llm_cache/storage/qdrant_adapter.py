"""Qdrant vector database adapter.

This module provides an adapter for Qdrant, a high-performance vector database
with native filtering, cloud deployment, and horizontal scaling support.

Features:
- Automatic collection management
- Native metadata filtering
- gRPC and REST support
- Cloud-ready with authentication
"""

import logging
from typing import TYPE_CHECKING, Optional
from uuid import uuid4

import numpy as np

from llm_cache.storage.vector_db_interface import VectorDBAdapterBase

if TYPE_CHECKING:
    from qdrant_client.models import Filter, FieldCondition, MatchValue

logger = logging.getLogger(__name__)


class QdrantAdapter(VectorDBAdapterBase):
    """Qdrant vector database adapter.
    
    Provides a production-ready interface to Qdrant with automatic
    collection management and native filtering support.
    
    Attributes:
        dimension: Vector dimension
        collection_name: Name of Qdrant collection
        client: Qdrant client instance
    """
    
    def __init__(
        self,
        dimension: int,
        collection_name: str = "llm_cache",
        host: str = "localhost",
        port: int = 6333,
        grpc_port: int = 6334,
        api_key: Optional[str] = None,
        prefer_grpc: bool = True,
        timeout: int = 30,
        batch_size: int = 100,
    ):
        """Initialize Qdrant adapter.
        
        Args:
            dimension: Vector dimension
            collection_name: Name of collection to use/create
            host: Qdrant server host
            port: REST API port
            grpc_port: gRPC port
            api_key: API key for authentication (optional)
            prefer_grpc: Use gRPC instead of REST
            timeout: Request timeout in seconds
            batch_size: Batch size for bulk operations
        """
        super().__init__(dimension)
        
        self.collection_name = collection_name
        self.host = host
        self.port = port
        self.grpc_port = grpc_port
        self.api_key = api_key
        self.prefer_grpc = prefer_grpc
        self.timeout = timeout
        self.batch_size = batch_size
        
        # Initialize client
        self.client = self._create_client()
        
        # Ensure collection exists
        self._ensure_collection()
        
        logger.info(
            f"Initialized QdrantAdapter: collection={collection_name}, "
            f"host={host}, port={port}"
        )
    
    def _create_client(self):
        """Create Qdrant client.
        
        Returns:
            QdrantClient instance
        """
        try:
            from qdrant_client import QdrantClient
        except ImportError:
            raise ImportError(
                "qdrant-client required. Install with: pip install qdrant-client"
            )
        
        if self.prefer_grpc:
            client = QdrantClient(
                host=self.host,
                port=self.port,
                grpc_port=self.grpc_port,
                api_key=self.api_key,
                timeout=self.timeout,
                prefer_grpc=True,
            )
            logger.info(f"Created Qdrant client (gRPC): {self.host}:{self.grpc_port}")
        else:
            client = QdrantClient(
                host=self.host,
                port=self.port,
                api_key=self.api_key,
                timeout=self.timeout,
                prefer_grpc=False,
            )
            logger.info(f"Created Qdrant client (REST): {self.host}:{self.port}")
        
        return client
    
    def _ensure_collection(self) -> None:
        """Ensure collection exists, create if not."""
        try:
            from qdrant_client.models import Distance, VectorParams
        except ImportError:
            raise ImportError("qdrant-client required")
        
        # Check if collection exists
        collections = self.client.get_collections().collections
        collection_names = [c.name for c in collections]
        
        if self.collection_name in collection_names:
            logger.info(f"Collection '{self.collection_name}' already exists")
            return
        
        # Create collection
        self.client.create_collection(
            collection_name=self.collection_name,
            vectors_config=VectorParams(
                size=self.dimension,
                distance=Distance.COSINE,  # Can also be Distance.EUCLID, Distance.DOT
            ),
        )
        
        logger.info(f"Created collection: {self.collection_name}")
    
    def bulk_upsert(
        self,
        docs: list[tuple[str, np.ndarray, dict]],
    ) -> None:
        """Insert or update documents in Qdrant.
        
        Args:
            docs: List of (doc_id, vector, metadata) tuples
        """
        self.validate_docs(docs)
        
        try:
            from qdrant_client.models import PointStruct
        except ImportError:
            raise ImportError("qdrant-client required")
        
        # Convert to Qdrant points
        points = []
        for doc_id, vector, metadata in docs:
            # Ensure vector is 1D list
            if vector.ndim > 1:
                vector = vector.flatten()
            
            point = PointStruct(
                id=doc_id,  # Qdrant supports string IDs
                vector=vector.tolist(),
                payload=metadata,  # Metadata stored as payload
            )
            points.append(point)
        
        # Upsert in batches
        for i in range(0, len(points), self.batch_size):
            batch = points[i:i + self.batch_size]
            self.client.upsert(
                collection_name=self.collection_name,
                points=batch,
            )
        
        logger.info(f"Upserted {len(docs)} documents to Qdrant")
    
    def search(
        self,
        vector: np.ndarray,
        top_k: int,
        filters: Optional[dict] = None,
    ) -> list[tuple[str, float]]:
        """Search for similar vectors in Qdrant.
        
        Args:
            vector: Query vector
            top_k: Number of results
            filters: Metadata filters (Qdrant native filtering)
            
        Returns:
            List of (doc_id, score) tuples
        """
        self.validate_vector(vector)
        
        if top_k <= 0:
            raise ValueError(f"top_k must be positive, got {top_k}")
        
        # Ensure 1D
        if vector.ndim > 1:
            vector = vector.flatten()
        
        # Convert filters to Qdrant format
        query_filter = None
        if filters:
            query_filter = self._build_filter(filters)
        
        # Search
        results = self.client.search(
            collection_name=self.collection_name,
            query_vector=vector.tolist(),
            limit=top_k,
            query_filter=query_filter,
        )
        
        # Convert to (doc_id, score) tuples
        output = [(str(hit.id), hit.score) for hit in results]
        
        logger.debug(f"Qdrant search returned {len(output)} results")
        return output
    
    def _build_filter(self, filters: dict):
        """Build Qdrant filter from simple dict.
        
        Args:
            filters: Dictionary of field -> value
            
        Returns:
            Qdrant Filter object
        """
        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
        except ImportError:
            raise ImportError("qdrant-client required")
        
        conditions = []
        for key, value in filters.items():
            conditions.append(
                FieldCondition(
                    key=key,
                    match=MatchValue(value=value),
                )
            )
        
        return Filter(must=conditions) if conditions else None
    
    def delete(self, doc_id: str) -> None:
        """Delete document from Qdrant.
        
        Args:
            doc_id: Document ID to delete
        """
        try:
            from qdrant_client.models import PointIdsList
        except ImportError:
            raise ImportError("qdrant-client required")
        
        self.client.delete(
            collection_name=self.collection_name,
            points_selector=PointIdsList(points=[doc_id]),
        )
        
        logger.info(f"Deleted document: {doc_id}")
    
    def count(self) -> int:
        """Get number of vectors in collection.
        
        Returns:
            Vector count
        """
        info = self.client.get_collection(self.collection_name)
        return info.points_count
    
    def save(self, path: str) -> None:
        """Save is not needed for Qdrant (server-side persistence).
        
        Args:
            path: Ignored
        """
        logger.info("Qdrant uses server-side persistence, save() is a no-op")
    
    def load(self, path: str) -> None:
        """Load is not needed for Qdrant (server-side persistence).
        
        Args:
            path: Ignored
        """
        logger.info("Qdrant uses server-side persistence, load() is a no-op")

    def get_vectors(self, doc_ids: list[str]) -> list[Optional[np.ndarray]]:
        """Get vectors for specific document IDs.
        
        Args:
            doc_ids: List of document IDs
            
        Returns:
            List of vectors (or None if not found)
        """
        if not doc_ids:
            return []
            
        points = self.client.retrieve(
            collection_name=self.collection_name,
            ids=doc_ids,
            with_vectors=True,
        )
        
        # Map results by ID
        # Qdrant IDs can be int or str, normalize to str for lookup
        vectors_map = {
            str(point.id): point.vector 
            for point in points 
            if point.vector is not None
        }
        
        output = []
        for doc_id in doc_ids:
            vec = vectors_map.get(doc_id)
            if vec is not None:
                output.append(np.array(vec, dtype=np.float32))
            else:
                output.append(None)
                
        return output


# Fallback stub if qdrant-client not installed
class QdrantAdapterStub(VectorDBAdapterBase):
    """Stub adapter when Qdrant client is not installed.
    
    Raises ImportError on any operation.
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(dimension=384)
        self._raise_import_error()
    
    def _raise_import_error(self):
        raise ImportError(
            "qdrant-client not installed. Install with: pip install qdrant-client"
        )
    
    def bulk_upsert(self, docs):
        self._raise_import_error()
    
    def search(self, vector, top_k, filters=None):
        self._raise_import_error()
    
    def delete(self, doc_id):
        self._raise_import_error()
    
    def count(self):
        self._raise_import_error()
    
    def save(self, path):
        self._raise_import_error()
    
    def load(self, path):
        self._raise_import_error()

    def get_vectors(self, doc_ids):
        self._raise_import_error()


def create_qdrant_adapter(*args, **kwargs):
    """Factory function that returns QdrantAdapter or stub.
    
    Returns:
        QdrantAdapter if qdrant-client installed, else QdrantAdapterStub
    """
    try:
        import qdrant_client
        return QdrantAdapter(*args, **kwargs)
    except ImportError:
        logger.warning("qdrant-client not installed, using stub")
        return QdrantAdapterStub(*args, **kwargs)
