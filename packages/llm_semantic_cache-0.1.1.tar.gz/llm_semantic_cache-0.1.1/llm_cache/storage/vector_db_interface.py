"""Abstract interface for vector database adapters.

This module defines the protocol that all vector DB adapters must implement,
enabling pluggable backends (Faiss, Qdrant, etc.) with consistent interface.
"""

from typing import Protocol, Optional

import numpy as np


class VectorDBAdapter(Protocol):
    """Protocol defining the vector database adapter interface.
    
    All vector DB implementations must provide these methods to enable
    pluggable backends. This allows swapping between Faiss, Qdrant, etc.
    with configuration changes only.
    """
    
    def bulk_upsert(
        self,
        docs: list[tuple[str, np.ndarray, dict]],
    ) -> None:
        """Insert or update multiple documents in the vector database.
        
        Args:
            docs: List of tuples (doc_id, vector, metadata)
                  - doc_id: Unique document identifier
                  - vector: Embedding vector (numpy array)
                  - metadata: Dictionary of metadata (text, source, etc.)
                  
        Raises:
            ValueError: If docs is empty or contains invalid data
            RuntimeError: If database operation fails
            
        Example:
            >>> docs = [
            ...     ("doc1", np.random.randn(384), {"text": "Sample"}),
            ...     ("doc2", np.random.randn(384), {"text": "Another"}),
            ... ]
            >>> adapter.bulk_upsert(docs)
        """
        ...
    
    def search(
        self,
        vector: np.ndarray,
        top_k: int,
        filters: Optional[dict] = None,
    ) -> list[tuple[str, float]]:
        """Search for similar vectors in the database.
        
        Args:
            vector: Query vector (numpy array)
            top_k: Number of results to return
            filters: Optional metadata filters (implementation-specific)
            
        Returns:
            List of (doc_id, score) tuples, ordered by similarity
            Scores are distances (lower is better for L2) or similarity (higher is better)
            
        Raises:
            ValueError: If vector is invalid or top_k <= 0
            RuntimeError: If search fails
            
        Example:
            >>> query_vector = np.random.randn(384)
            >>> results = adapter.search(query_vector, top_k=5)
            >>> for doc_id, score in results:
            ...     print(f"{doc_id}: {score:.4f}")
        """
        ...
    
    def delete(self, doc_id: str) -> None:
        """Delete a document from the vector database.
        
        Args:
            doc_id: Document identifier to delete
            
        Raises:
            ValueError: If doc_id is invalid
            RuntimeError: If deletion fails
            
        Example:
            >>> adapter.delete("doc1")
        """
        ...
    
    def count(self) -> int:
        """Get total number of vectors in the database.
        
        Returns:
            Number of vectors stored
            
        Example:
            >>> total = adapter.count()
            >>> print(f"Database contains {total} vectors")
        """
        ...
    
    def save(self, path: str) -> None:
        """Persist the index to disk (if supported).
        
        Args:
            path: Path to save index
            
        Example:
            >>> adapter.save("./index_backup.bin")
        """
        ...
    
    def load(self, path: str) -> None:
        """Load the index from disk (if supported).
        
        Args:
            path: Path to load index from
            
        Example:
            >>> adapter.load("./index_backup.bin")
        """
        ...
    
    def get_vectors(self, doc_ids: list[str]) -> list[Optional[np.ndarray]]:
        """Get vectors for specific document IDs.
        
        Args:
            doc_ids: List of document IDs
            
        Returns:
            List of vectors (or None if not found/supported)
        """
        ...


class VectorDBAdapterBase:
    """Base class providing common functionality for adapters.
    
    Concrete adapters can inherit from this class to get utility methods
    and validation logic.
    """
    
    def __init__(self, dimension: int):
        """Initialize base adapter.
        
        Args:
            dimension: Expected vector dimension
        """
        self.dimension = dimension
    
    def validate_vector(self, vector: np.ndarray) -> None:
        """Validate vector shape and type.
        
        Args:
            vector: Vector to validate
            
        Raises:
            ValueError: If vector is invalid
        """
        if not isinstance(vector, np.ndarray):
            raise ValueError(f"Expected numpy array, got {type(vector)}")
        
        if vector.ndim == 1:
            if vector.shape[0] != self.dimension:
                raise ValueError(
                    f"Vector dimension mismatch: expected {self.dimension}, "
                    f"got {vector.shape[0]}"
                )
        elif vector.ndim == 2:
            if vector.shape[1] != self.dimension:
                raise ValueError(
                    f"Vector dimension mismatch: expected {self.dimension}, "
                    f"got {vector.shape[1]}"
                )
        else:
            raise ValueError(f"Invalid vector shape: {vector.shape}")
    
    def validate_docs(self, docs: list[tuple[str, np.ndarray, dict]]) -> None:
        """Validate document list format.
        
        Args:
            docs: List of (doc_id, vector, metadata) tuples
            
        Raises:
            ValueError: If docs is invalid
        """
        if not docs:
            raise ValueError("Document list cannot be empty")
        
        for i, doc in enumerate(docs):
            if not isinstance(doc, tuple) or len(doc) != 3:
                raise ValueError(
                    f"Document {i} must be tuple (doc_id, vector, metadata)"
                )
            
            doc_id, vector, metadata = doc
            
            if not isinstance(doc_id, str) or not doc_id:
                raise ValueError(f"Document {i} has invalid doc_id: {doc_id}")
            
            self.validate_vector(vector)
            
            if not isinstance(metadata, dict):
                raise ValueError(f"Document {i} has invalid metadata: {type(metadata)}")
