"""Integration test for cache flow with mock components."""

import asyncio
import pytest
import numpy as np

from llm_cache.embedder import MockEmbedder
from llm_cache.keys import query_key
from llm_cache.config import CacheConfig


class MockRedis:
    """Mock Redis client for testing without real Redis."""
    
    def __init__(self):
        self.store = {}
    
    def get(self, key):
        return self.store.get(key)
    
    def setex(self, key, ttl, value):
        self.store[key] = value
        return True
    
    def delete(self, key):
        if key in self.store:
            del self.store[key]
            return 1
        return 0
    
    def ping(self):
        return True


class MockVectorDB:
    """Mock vector database for testing."""
    
    def __init__(self, dimension=384):
        self.dimension = dimension
        self.docs = {}
    
    def bulk_upsert(self, docs):
        for doc_id, vector, metadata in docs:
            self.docs[doc_id] = (vector, metadata)
    
    def search(self, vector, top_k, filters=None):
        # Simple mock: return first top_k docs
        results = []
        for doc_id, (vec, meta) in list(self.docs.items())[:top_k]:
            score = float(np.random.rand())
            results.append((doc_id, score))
        return results
    
    def count(self):
        return len(self.docs)


@pytest.mark.asyncio
async def test_embedder_mock():
    """Test mock embedder produces consistent results."""
    embedder = MockEmbedder(dimension=384, deterministic=True)
    
    texts = ["What is ML?", "Explain AI"]
    embeddings1 = await embedder.embed(texts)
    embeddings2 = await embedder.embed(texts)
    
    # Check shape
    assert embeddings1.shape == (2, 384)
    
    # Check determinism
    assert np.allclose(embeddings1, embeddings2)
    
    # Check normalization
    norms = np.linalg.norm(embeddings1, axis=1)
    assert np.allclose(norms, 1.0)


@pytest.mark.asyncio
async def test_embedder_different_texts():
    """Test different texts produce different embeddings."""
    embedder = MockEmbedder(dimension=384, deterministic=True)
    
    emb1 = await embedder.embed(["text1"])
    emb2 = await embedder.embed(["text2"])
    
    # Should be different
    assert not np.allclose(emb1, emb2)


def test_query_key_caching():
    """Test query key generation for cache lookups."""
    prompt = "What is machine learning?"
    
    # Same query should produce same key
    key1 = query_key(prompt, top_k=5, embed_model="all-MiniLM-L6-v2")
    key2 = query_key(prompt, top_k=5, embed_model="all-MiniLM-L6-v2")
    
    assert key1 == key2
    
    # Different top_k should produce different key
    key3 = query_key(prompt, top_k=10, embed_model="all-MiniLM-L6-v2")
    assert key1 != key3


def test_mock_vector_db():
    """Test mock vector DB operations."""
    db = MockVectorDB(dimension=384)
    
    # Add documents
    docs = [
        ("doc1", np.random.randn(384), {"text": "Sample 1"}),
        ("doc2", np.random.randn(384), {"text": "Sample 2"}),
    ]
    db.bulk_upsert(docs)
    
    assert db.count() == 2
    
    # Search
    query_vector = np.random.randn(384)
    results = db.search(query_vector, top_k=2)
    
    assert len(results) == 2
    assert all(isinstance(r[0], str) for r in results)
    assert all(isinstance(r[1], float) for r in results)


def test_mock_redis():
    """Test mock Redis operations."""
    redis = MockRedis()
    
    # Test set/get
    redis.setex("key1", 60, "value1")
    assert redis.get("key1") == "value1"
    
    # Test delete
    redis.delete("key1")
    assert redis.get("key1") is None
    
    # Test ping
    assert redis.ping()


@pytest.mark.asyncio
async def test_cache_miss_flow():
    """Test complete cache miss flow."""
    # Setup components
    embedder = MockEmbedder(dimension=384, deterministic=True)
    vector_db = MockVectorDB(dimension=384)
    redis_cache = MockRedis()
    
    # Ingest some documents
    docs = [
        ("doc1", np.random.randn(384).astype(np.float32), {
            "text": "Machine learning is a subset of AI",
            "source": "doc1.txt"
        }),
        ("doc2", np.random.randn(384).astype(np.float32), {
            "text": "Neural networks are inspired by the brain",
            "source": "doc2.txt"
        }),
    ]
    vector_db.bulk_upsert(docs)
    
    # Query (cache miss)
    query_text = "What is machine learning?"
    q_key = query_key(query_text, top_k=2, embed_model="mock")
    
    # Check Redis (should be empty)
    cached = redis_cache.get(f"cache:query:{q_key}")
    assert cached is None
    
    # Embed query
    query_embedding = await embedder.embed([query_text])
    
    # Search vector DB
    results = vector_db.search(query_embedding[0], top_k=2)
    
    assert len(results) == 2
    
    # Cache results
    import json
    result_list = [{"id": r[0], "score": r[1]} for r in results]
    redis_cache.setex(f"cache:query:{q_key}", 3600, json.dumps(result_list))
    
    # Verify cached
    cached = redis_cache.get(f"cache:query:{q_key}")
    assert cached is not None


@pytest.mark.asyncio
async def test_cache_hit_flow():
    """Test cache hit flow."""
    embedder = MockEmbedder(dimension=384, deterministic=True)
    redis_cache = MockRedis()
    
    # Pre-populate cache
    query_text = "What is AI?"
    q_key = query_key(query_text, top_k=5, embed_model="mock")
    
    import json
    cached_results = [
        {"id": "doc1", "score": 0.95},
        {"id": "doc2", "score": 0.89},
    ]
    redis_cache.setex(f"cache:query:{q_key}", 3600, json.dumps(cached_results))
    
    # Query (cache hit)
    cached = redis_cache.get(f"cache:query:{q_key}")
    assert cached is not None
    
    # Parse and return
    results = json.loads(cached)
    assert len(results) == 2
    assert results[0]["id"] == "doc1"


def test_config_loading():
    """Test configuration loading."""
    config = CacheConfig()
    
    # Check defaults
    assert config.embedding.dimension == 384
    assert config.hnsw.M == 16
    assert config.redis.ttl_seconds == 3600
    assert config.vector_db_backend == "faiss"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
