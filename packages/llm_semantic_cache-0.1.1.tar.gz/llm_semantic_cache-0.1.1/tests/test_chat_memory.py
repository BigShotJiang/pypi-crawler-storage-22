
import pytest
import asyncio
import numpy as np
from unittest.mock import MagicMock, patch
from llm_cache.chat_memory import ChatMemory

class TestChatMemory:
    @pytest.mark.asyncio
    async def test_add_message(self):
        """Test adding a message to memory."""
        with patch("llm_cache.chat_memory.FaissAdapter") as MockVectorDB, \
             patch("llm_cache.chat_memory.RedisCache") as MockRedis, \
             patch("llm_cache.chat_memory.create_embedder") as mock_create_embedder:
            
            # Setup mocks
            mock_embedder = MagicMock()
            future = asyncio.Future()
            future.set_result(np.random.randn(1, 384))
            mock_embedder.embed.return_value = future
            mock_create_embedder.return_value = mock_embedder
            
            memory = ChatMemory(use_mock=True)
            
            msg_id = await memory.add_message("session_1", "user", "Hello")
            
            assert msg_id is not None
            # Verify DB upsert
            memory.vector_db.bulk_upsert.assert_called_once()
            # Verify Redis set
            memory.redis.set_meta.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_context_filtering(self):
        """Test context retrieval filters by session ID."""
        with patch("llm_cache.chat_memory.FaissAdapter") as MockVectorDB, \
             patch("llm_cache.chat_memory.RedisCache") as MockRedis, \
             patch("llm_cache.chat_memory.create_embedder") as mock_create_embedder:
             
            # Setup mocks
            mock_embedder = MagicMock()
            future = asyncio.Future()
            future.set_result(np.random.randn(1, 384))
            mock_embedder.embed.return_value = future
            mock_create_embedder.return_value = mock_embedder
            
            # Mock DB search results (doc_id, score)
            mock_db = MockVectorDB.return_value
            mock_db.search.return_value = [
                ("doc_1", 0.1), # Session 1
                ("doc_2", 0.2), # Session 2 (should be filtered)
                ("doc_3", 0.3), # Session 1
            ]
            
            # Mock Redis metadata
            mock_redis = MockRedis.return_value
            mock_redis.batch_get_meta.return_value = {
                "doc_1": {"session_id": "session_1", "text": "Hi", "role": "user", "timestamp": 100},
                "doc_2": {"session_id": "session_2", "text": "Bye", "role": "user", "timestamp": 110},
                "doc_3": {"session_id": "session_1", "text": "Hello", "role": "assistant", "timestamp": 120},
            }
            
            memory = ChatMemory(use_mock=True)
            
            context = await memory.get_context("session_1", "query", max_tokens=1000)
            
            assert len(context) == 2
            assert context[0]["id"] == "doc_1"
            assert context[1]["id"] == "doc_3"
            
            # Verify doc_2 was filtered out
            ids = [c["id"] for c in context]
            assert "doc_2" not in ids

    @pytest.mark.asyncio
    async def test_get_context_token_limit(self):
        """Test context retrieval respects token limit."""
        with patch("llm_cache.chat_memory.FaissAdapter") as MockVectorDB, \
             patch("llm_cache.chat_memory.RedisCache") as MockRedis, \
             patch("llm_cache.chat_memory.create_embedder") as mock_create_embedder:
             
            # Setup mocks
            mock_embedder = MagicMock()
            future = asyncio.Future()
            future.set_result(np.random.randn(1, 384))
            mock_embedder.embed.return_value = future
            mock_create_embedder.return_value = mock_embedder
            
            mock_db = MockVectorDB.return_value
            mock_db.search.return_value = [("doc_1", 0.1), ("doc_2", 0.2)]
            
            # Long messages
            # 100 chars / 4 = 25 tokens
            long_text = "a" * 100 
            
            mock_redis = MockRedis.return_value
            mock_redis.batch_get_meta.return_value = {
                "doc_1": {"session_id": "s1", "text": long_text, "role": "u", "timestamp": 1},
                "doc_2": {"session_id": "s1", "text": long_text, "role": "a", "timestamp": 2},
            }
            
            memory = ChatMemory(use_mock=True)
            
            # Limit to ~30 tokens (should only fit one message)
            context = await memory.get_context("s1", "q", max_tokens=30)
            
            assert len(context) == 1
            assert context[0]["id"] == "doc_1" # Sorted by timestamp, first one fits
