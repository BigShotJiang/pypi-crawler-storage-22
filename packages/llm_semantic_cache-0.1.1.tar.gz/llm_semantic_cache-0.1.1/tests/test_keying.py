"""Unit tests for key generation functions."""

import pytest
from llm_cache.keys import (
    normalize_text,
    query_key,
    content_fingerprint,
    chunking_config_hash,
    doc_id_from_fingerprint,
    validate_query_key,
    batch_fingerprint,
)


class TestNormalization:
    """Test text normalization."""
    
    def test_normalize_basic(self):
        """Test basic normalization."""
        assert normalize_text("Hello World") == "hello world"
        assert normalize_text("  HELLO  ") == "hello"
    
    def test_normalize_whitespace(self):
        """Test whitespace collapsing."""
        assert normalize_text("a  b    c") == "a b c"
        assert normalize_text("a\n\nb\tc") == "a b c"
    
    def test_normalize_special_chars(self):
        """Test special character removal."""
        assert normalize_text("What is AI?") == "what is ai"
        assert normalize_text("Hello, World!") == "hello world"
    
    def test_normalize_preserves_alphanumeric(self):
        """Test that alphanumeric characters are preserved."""
        assert normalize_text("Test 123") == "test 123"
        assert normalize_text("GPT-4") == "gpt4"


class TestQueryKey:
    """Test query key generation."""
    
    def test_query_key_deterministic(self):
        """Test that same inputs produce same key."""
        key1 = query_key("What is ML?", 5, "model-v1")
        key2 = query_key("What is ML?", 5, "model-v1")
        assert key1 == key2
    
    def test_query_key_normalization(self):
        """Test that normalization makes keys match."""
        key1 = query_key("What is ML?", 5, "model-v1")
        key2 = query_key("what is ml", 5, "model-v1")
        key3 = query_key("  WHAT IS   ML?  ", 5, "model-v1")
        
        assert key1 == key2 == key3
    
    def test_query_key_top_k_sensitivity(self):
        """Test that different top_k produces different keys."""
        key1 = query_key("What is ML?", 5, "model-v1")
        key2 = query_key("What is ML?", 10, "model-v1")
        
        assert key1 != key2
    
    def test_query_key_model_sensitivity(self):
        """Test that different models produce different keys."""
        key1 = query_key("What is ML?", 5, "model-v1")
        key2 = query_key("What is ML?", 5, "model-v2")
        
        assert key1 != key2
    
    def test_query_key_chunking_hash(self):
        """Test that chunking hash is incorporated."""
        key1 = query_key("What is ML?", 5, "model", chunking_hash=None)
        key2 = query_key("What is ML?", 5, "model", chunking_hash="abc123")
        
        assert key1 != key2
    
    def test_query_key_length(self):
        """Test that key is 64 characters (SHA-256 hex)."""
        key = query_key("test", 5, "model")
        assert len(key) == 64
    
    def test_query_key_hex_format(self):
        """Test that key is valid hex."""
        key = query_key("test", 5, "model")
        try:
            int(key, 16)
            valid = True
        except ValueError:
            valid = False
        assert valid


class TestContentFingerprint:
    """Test content fingerprinting."""
    
    def test_fingerprint_deterministic(self):
        """Test deterministic fingerprinting."""
        fp1 = content_fingerprint("Sample text")
        fp2 = content_fingerprint("Sample text")
        assert fp1 == fp2
    
    def test_fingerprint_different_content(self):
        """Test different content produces different fingerprints."""
        fp1 = content_fingerprint("Text 1")
        fp2 = content_fingerprint("Text 2")
        assert fp1 != fp2
    
    def test_fingerprint_case_sensitive(self):
        """Test that fingerprinting is case-sensitive."""
        fp1 = content_fingerprint("Hello")
        fp2 = content_fingerprint("hello")
        assert fp1 != fp2
    
    def test_fingerprint_whitespace_sensitive(self):
        """Test that fingerprinting preserves whitespace."""
        fp1 = content_fingerprint("Hello World")
        fp2 = content_fingerprint("HelloWorld")
        assert fp1 != fp2
    
    def test_fingerprint_length(self):
        """Test fingerprint is 64 characters."""
        fp = content_fingerprint("test")
        assert len(fp) == 64


class TestChunkingConfigHash:
    """Test chunking configuration hashing."""
    
    def test_chunking_hash_deterministic(self):
        """Test deterministic hashing."""
        hash1 = chunking_config_hash(512, 50)
        hash2 = chunking_config_hash(512, 50)
        assert hash1 == hash2
    
    def test_chunking_hash_sensitivity(self):
        """Test that different configs produce different hashes."""
        hash1 = chunking_config_hash(512, 50)
        hash2 = chunking_config_hash(1024, 50)
        hash3 = chunking_config_hash(512, 100)
        
        assert hash1 != hash2
        assert hash1 != hash3
        assert hash2 != hash3
    
    def test_chunking_hash_length(self):
        """Test hash is 16 characters (truncated)."""
        hash_val = chunking_config_hash(512, 50)
        assert len(hash_val) == 16


class TestDocIDGeneration:
    """Test document ID generation."""
    
    def test_doc_id_format(self):
        """Test doc ID format."""
        fp = content_fingerprint("test")
        doc_id = doc_id_from_fingerprint(fp, 0)
        
        assert "_" in doc_id
        assert doc_id.endswith("_0")
    
    def test_doc_id_chunk_index(self):
        """Test different chunk indices."""
        fp = content_fingerprint("test")
        
        doc_id_0 = doc_id_from_fingerprint(fp, 0)
        doc_id_1 = doc_id_from_fingerprint(fp, 1)
        doc_id_5 = doc_id_from_fingerprint(fp, 5)
        
        assert doc_id_0.endswith("_0")
        assert doc_id_1.endswith("_1")
        assert doc_id_5.endswith("_5")
    
    def test_doc_id_same_prefix(self):
        """Test same fingerprint produces same prefix."""
        fp = content_fingerprint("test")
        
        doc_id_0 = doc_id_from_fingerprint(fp, 0)
        doc_id_1 = doc_id_from_fingerprint(fp, 1)
        
        prefix_0 = doc_id_0.rsplit("_", 1)[0]
        prefix_1 = doc_id_1.rsplit("_", 1)[0]
        
        assert prefix_0 == prefix_1


class TestValidation:
    """Test validation functions."""
    
    def test_validate_query_key_valid(self):
        """Test validation of valid keys."""
        key = query_key("test", 5, "model")
        assert validate_query_key(key)
    
    def test_validate_query_key_invalid_length(self):
        """Test rejection of invalid length."""
        assert not validate_query_key("abc123")
        assert not validate_query_key("a" * 63)
        assert not validate_query_key("a" * 65)
    
    def test_validate_query_key_invalid_hex(self):
        """Test rejection of non-hex characters."""
        invalid_key = "z" * 64  # 'z' is not valid hex
        assert not validate_query_key(invalid_key)
    
    def test_validate_query_key_valid_hex(self):
        """Test acceptance of valid hex."""
        valid_key = "a" * 64
        assert validate_query_key(valid_key)


class TestBatchFingerprint:
    """Test batch fingerprinting."""
    
    def test_batch_fingerprint_basic(self):
        """Test batch fingerprinting."""
        texts = ["doc1", "doc2", "doc3"]
        fps = batch_fingerprint(texts)
        
        assert len(fps) == 3
        assert all(len(fp) == 64 for fp in fps)
    
    def test_batch_fingerprint_duplicates(self):
        """Test that duplicate texts get same fingerprint."""
        texts = ["doc1", "doc2", "doc1"]
        fps = batch_fingerprint(texts)
        
        assert fps[0] == fps[2]
        assert fps[0] != fps[1]
    
    def test_batch_fingerprint_empty(self):
        """Test empty list."""
        fps = batch_fingerprint([])
        assert fps == []
    
    def test_batch_fingerprint_consistency(self):
        """Test consistency with single fingerprinting."""
        texts = ["test1", "test2"]
        batch_fps = batch_fingerprint(texts)
        
        single_fp1 = content_fingerprint("test1")
        single_fp2 = content_fingerprint("test2")
        
        assert batch_fps[0] == single_fp1
        assert batch_fps[1] == single_fp2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
