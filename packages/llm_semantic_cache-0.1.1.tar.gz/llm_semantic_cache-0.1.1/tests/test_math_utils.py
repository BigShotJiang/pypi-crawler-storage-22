"""Unit tests for math_utils capacity planning functions."""

import pytest
from llm_cache.math_utils import (
    bytes_to_human_readable,
    raw_embeddings_bytes,
    pq_bytes,
    hnsw_overhead_bytes,
    combined_storage_estimate,
)


class TestBytesConversion:
    """Test human-readable byte conversion."""
    
    def test_bytes_to_human_readable(self):
        """Test byte size formatting."""
        assert bytes_to_human_readable(1024) == "1.0 KB"
        assert bytes_to_human_readable(1024 ** 2) == "1.0 MB"
        assert bytes_to_human_readable(1024 ** 3) == "1.0 GB"
        assert bytes_to_human_readable(1024 ** 4) == "1.0 TB"
    
    def test_bytes_to_human_readable_fractional(self):
        """Test fractional values."""
        assert bytes_to_human_readable(1536) == "1.5 KB"
        assert bytes_to_human_readable(int(1.5 * 1024 ** 2)) == "1.5 MB"


class TestRawEmbeddings:
    """Test raw embeddings storage calculations."""
    
    def test_raw_embeddings_10m_1536d(self):
        """Test 10M vectors, 1536 dimensions (OpenAI ada-002 scale)."""
        N = 10_000_000
        d = 1536
        
        total_bytes, human = raw_embeddings_bytes(N, d, dtype_bytes=4)
        
        # Expected: 10M * 1536 * 4 = 61,440,000,000 bytes ≈ 57.2 GB
        assert total_bytes == 61_440_000_000
        assert "GB" in human
        assert float(human.split()[0]) > 50  # At least 50 GB
    
    def test_raw_embeddings_float16(self):
        """Test with float16 (half precision)."""
        N = 10_000_000
        d = 1536
        
        total_bytes_fp32, _ = raw_embeddings_bytes(N, d, dtype_bytes=4)
        total_bytes_fp16, _ = raw_embeddings_bytes(N, d, dtype_bytes=2)
        
        # Float16 should be exactly half
        assert total_bytes_fp16 == total_bytes_fp32 / 2
    
    def test_raw_embeddings_small(self):
        """Test smaller embedding dimensions."""
        N = 1_000_000
        d = 384  # sentence-transformers dimension
        
        total_bytes, human = raw_embeddings_bytes(N, d, dtype_bytes=4)
        
        # Expected: 1M * 384 * 4 = 1,536,000,000 bytes ≈ 1.4 GB
        expected = 1_536_000_000
        assert total_bytes == expected
        assert "GB" in human or "MB" in human


class TestProductQuantization:
    """Test PQ compression calculations."""
    
    def test_pq_10m_64m(self):
        """Test 10M vectors with 64 subquantizers."""
        N = 10_000_000
        m = 64
        
        total_bytes, human = pq_bytes(N, m, bytes_per_subvector=1)
        
        # Expected: 10M * 64 * 1 = 640,000,000 bytes ≈ 610 MB
        # (slightly higher with codebooks)
        assert total_bytes >= 640_000_000
        assert total_bytes < 650_000_000  # Codebooks add ~2MB
        assert "MB" in human
    
    def test_pq_compression_ratio(self):
        """Test compression ratio is significant."""
        N = 10_000_000
        d = 1536
        m = 64
        
        raw_bytes, _ = raw_embeddings_bytes(N, d)
        pq_compressed, _ = pq_bytes(N, m)
        
        compression_ratio = raw_bytes / pq_compressed
        
        # Should achieve ~96x compression
        assert compression_ratio > 90
        assert compression_ratio < 100
    
    def test_pq_without_codebooks(self):
        """Test PQ calculation without codebook overhead."""
        N = 1_000_000
        m = 32
        
        total_bytes, _ = pq_bytes(N, m, include_codebooks=False)
        
        # Expected: exactly N * m bytes
        expected = N * m
        assert total_bytes == expected


class TestHNSWOverhead:
    """Test HNSW index overhead calculations."""
    
    def test_hnsw_10m_m16(self):
        """Test 10M vectors with M=16."""
        N = 10_000_000
        M = 16
        
        total_bytes, human = hnsw_overhead_bytes(N, M)
        
        # Expected: ~3.8 GB for M=16
        # Formula: N * M * 2 * 8 * 1.5 = 10M * 16 * 2 * 8 * 1.5 = 3,840,000,000
        expected = 3_840_000_000
        assert total_bytes == expected
        assert "GB" in human
    
    def test_hnsw_m_scaling(self):
        """Test that overhead scales linearly with M."""
        N = 1_000_000
        
        overhead_m16, _ = hnsw_overhead_bytes(N, M=16)
        overhead_m32, _ = hnsw_overhead_bytes(N, M=32)
        
        # M=32 should be exactly 2x M=16
        assert overhead_m32 == overhead_m16 * 2
    
    def test_hnsw_n_scaling(self):
        """Test that overhead scales linearly with N."""
        M = 16
        
        overhead_1m, _ = hnsw_overhead_bytes(1_000_000, M)
        overhead_10m, _ = hnsw_overhead_bytes(10_000_000, M)
        
        # 10M should be exactly 10x 1M
        assert overhead_10m == overhead_1m * 10


class TestCombinedEstimate:
    """Test combined storage estimates."""
    
    def test_combined_with_pq(self):
        """Test combined estimate with PQ compression."""
        N = 10_000_000
        d = 1536
        M = 16
        
        estimate = combined_storage_estimate(N, d, M=M, use_pq=True, pq_m=64)
        
        # Check all components present
        assert estimate["N"] == N
        assert estimate["d"] == d
        assert estimate["M"] == M
        assert estimate["use_pq"] is True
        
        # Check compression ratio
        assert estimate["compression_ratio"] > 90
        
        # Total should be PQ vectors + HNSW overhead
        # ~610 MB + 3.8 GB ≈ 4.4 GB
        assert estimate["total_bytes"] < 5_000_000_000  # Less than 5 GB
    
    def test_combined_without_pq(self):
        """Test combined estimate without compression."""
        N = 10_000_000
        d = 1536
        M = 16
        
        estimate = combined_storage_estimate(N, d, M=M, use_pq=False)
        
        # Without PQ, compression ratio should be 1.0
        assert estimate["compression_ratio"] == 1.0
        
        # Total should be raw vectors + HNSW overhead
        # ~57.2 GB + 3.8 GB ≈ 61 GB
        assert estimate["total_bytes"] > 60_000_000_000  # More than 60 GB
    
    def test_pq_vs_raw_comparison(self):
        """Test that PQ is significantly smaller than raw."""
        N = 10_000_000
        d = 1536
        M = 16
        
        estimate_pq = combined_storage_estimate(N, d, M=M, use_pq=True, pq_m=64)
        estimate_raw = combined_storage_estimate(N, d, M=M, use_pq=False)
        
        # PQ should be much smaller
        ratio = estimate_raw["total_bytes"] / estimate_pq["total_bytes"]
        assert ratio > 10  # At least 10x smaller


class TestEdgeCases:
    """Test edge cases and validation."""
    
    def test_zero_vectors(self):
        """Test with N=0."""
        total_bytes, human = raw_embeddings_bytes(0, 384)
        assert total_bytes == 0
        assert human == "0.0 B"
    
    def test_small_dimension(self):
        """Test with very small dimension."""
        total_bytes, _ = raw_embeddings_bytes(1000, 1)
        expected = 1000 * 1 * 4  # 4KB
        assert total_bytes == expected
    
    def test_large_m(self):
        """Test HNSW with large M parameter."""
        overhead, _ = hnsw_overhead_bytes(1_000_000, M=64)
        
        # Should scale correctly
        overhead_ref, _ = hnsw_overhead_bytes(1_000_000, M=16)
        assert overhead == overhead_ref * 4  # M=64 is 4x M=16


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
