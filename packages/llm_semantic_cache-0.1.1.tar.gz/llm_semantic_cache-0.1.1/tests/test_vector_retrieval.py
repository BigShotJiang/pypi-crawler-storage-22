
import pytest
import asyncio
import numpy as np
from llm_cache.storage.faiss_adapter import FaissAdapter
from llm_cache.query_service import QueryService
from llm_cache.cache.local_hnsw import LocalHNSWCache
from unittest.mock import MagicMock, patch

class TestVectorRetrieval:
    def test_faiss_get_vectors_flat(self):
        """Test retrieving vectors from Faiss Flat index."""
        dim = 128
        adapter = FaissAdapter(dimension=dim, index_type="Flat")
        
        # Create dummy data
        docs = []
        vectors = []
        for i in range(10):
            vec = np.random.randn(dim).astype(np.float32)
            docs.append((f"doc_{i}", vec, {"text": f"text_{i}"}))
            vectors.append(vec)
            
        adapter.bulk_upsert(docs)
        
        # Retrieve vectors
        retrieved = adapter.get_vectors(["doc_0", "doc_5", "doc_9"])
        
        assert len(retrieved) == 3
        assert np.allclose(retrieved[0], vectors[0])
        assert np.allclose(retrieved[1], vectors[5])
        assert np.allclose(retrieved[2], vectors[9])
        
        # Test missing
        retrieved_missing = adapter.get_vectors(["doc_999"])
        assert retrieved_missing[0] is None

    @pytest.mark.asyncio
    async def test_query_service_populates_local_cache(self):
        """Test that QueryService populates local cache with result vectors."""
        # Mock dependencies
        with patch("llm_cache.query_service.RedisCache") as MockRedis, \
             patch("llm_cache.query_service.FaissAdapter") as MockVectorDB, \
             patch("llm_cache.query_service.LocalHNSWCache") as MockLocalCache, \
             patch("llm_cache.query_service.create_embedder") as mock_create_embedder:
            
            # Setup mocks
            mock_embedder = MagicMock()
            # Make embed return an awaitable
            future = asyncio.Future()
            future.set_result(np.random.randn(1, 384))
            mock_embedder.embed.return_value = future
            mock_create_embedder.return_value = mock_embedder
            
            mock_db_instance = MockVectorDB.return_value
            mock_db_instance.search.return_value = [("doc_1", 0.9)]
            # Mock get_vectors to return a vector
            doc_vector = np.random.randn(384)
            mock_db_instance.get_vectors.return_value = [doc_vector]
            
            mock_local_cache_instance = MockLocalCache.return_value
            mock_local_cache_instance.count.return_value = 0 # Empty cache
            
            mock_redis_instance = MockRedis.return_value
            mock_redis_instance.get_query_cache.return_value = None # Miss
            mock_redis_instance.batch_get_meta.return_value = {"doc_1": {"text": "foo"}}
            
            # Initialize service
            service = QueryService(use_mock=True)
            
            # Run query
            await service.query("test query", top_k=1, verbose=False)
            
            # Verify add_items was called with doc_id and doc_vector
            # NOT query_text and query_vector
            args, kwargs = mock_local_cache_instance.add_items.call_args
            added_ids = args[0]
            added_vectors = args[1]
            
            assert added_ids == ["doc_1"]
            assert np.allclose(added_vectors[0], doc_vector)
