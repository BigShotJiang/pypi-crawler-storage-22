# 🎨 LLM Slate

**Web interface for chatting with 9+ AI providers in one place.**

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Python](https://img.shields.io/badge/python-3.10+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0+-green.svg)

Chat with Claude, GPT-4, Grok, Gemini, and more from a single interface. Generate images with DALL-E or Aurora. Analyze images with Claude Vision or GPT-4 Vision. All with your own API keys, running locally.

## Features

- Chat with 9 AI providers: Anthropic (Claude), OpenAI (GPT), xAI (Grok), Cohere, Mistral, Perplexity, Gemini, HuggingFace, Groq
- Image generation (DALL-E 3, Aurora)
- Image analysis (Claude Vision, GPT-4 Vision)
- Conversation history saved locally
- Password protected
- Clean, minimal interface

## Quick Start

### Installation

```bash
pip install llm-slate
```

### Set Up API Keys

Create a `.env` file with your API keys:

```env
# Add keys for the providers you want to use
ANTHROPIC_API_KEY=your_key_here
OPENAI_API_KEY=your_key_here
XAI_API_KEY=your_key_here
COHERE_API_KEY=your_key_here
MISTRAL_API_KEY=your_key_here
PERPLEXITY_API_KEY=your_key_here
GEMINI_API_KEY=your_key_here
HUGGINGFACE_API_KEY=your_key_here
GROQ_API_KEY=your_key_here

# Flask secret (generate with: python -c "import secrets; print(secrets.token_hex(32))")
FLASK_SECRET_KEY=your_secret_key_here

# Optional: Custom password (default: "friendship")
STUDIO_PASSWORD=your_password_here

# Optional: Custom port (default: 5413)
STUDIO_PORT=5413
```

### Run

```bash
llm-slate
```

Then open http://localhost:5413 in your browser.

## Usage

### Chat

1. Select a provider from the dropdown
2. Choose a model
3. Start chatting

Your conversation history is saved and persists across sessions.

### Image Generation

1. Go to the "Images" tab
2. Select provider (OpenAI or xAI)
3. Enter your prompt
4. Click generate

### Image Analysis

1. Go to the "Vision" tab
2. Upload an image
3. Select provider (Anthropic or OpenAI)
4. Ask questions about the image

## Configuration

### Environment Variables

- `STUDIO_PORT` - Port to run on (default: 5413)
- `STUDIO_PASSWORD` - Login password (default: "friendship")
- `STUDIO_BASE_PATH` - Base path for reverse proxy (e.g., `/studio`)
- `FLASK_SECRET_KEY` - Flask session secret (required)

### Provider API Keys

Only include keys for providers you want to use. Multi-Studio detects which providers are available based on your configured API keys.

## Development

### From Source

```bash
git clone https://github.com/lukeslp/llm-slate.git
cd llm-slate
pip install -e .
```

### Project Structure

```
llm-slate/
├── app.py              # Main Flask application
├── config.py           # Configuration management
├── database.py         # Conversation storage
├── cache_manager.py    # Response caching
├── providers/          # Provider adapters
├── core/               # Core utilities
├── templates/          # HTML templates
├── static/             # CSS/JS assets
└── blueprints/         # Flask blueprints
```

## Security

- All API keys are read from environment variables (never hardcoded)
- Conversations stored locally in SQLite database
- Password required to access interface
- No data sent to external services except your chosen AI providers

## Supported Providers

| Provider | Chat | Images | Vision |
|----------|------|--------|--------|
| Anthropic (Claude) | ✅ | ❌ | ✅ |
| OpenAI (GPT) | ✅ | ✅ (DALL-E) | ✅ |
| xAI (Grok) | ✅ | ✅ (Aurora) | ❌ |
| Cohere | ✅ | ❌ | ❌ |
| Mistral | ✅ | ❌ | ❌ |
| Perplexity | ✅ | ❌ | ❌ |
| Gemini | ✅ | ❌ | ❌ |
| HuggingFace | ✅ | ❌ | ❌ |
| Groq | ✅ | ❌ | ❌ |

## Requirements

- Python 3.10+
- API keys for at least one provider
- Flask 3.0+

## Author

**Luke Steuber**
- Website: [lukesteuber.com](https://lukesteuber.com)
- Bluesky: [@lukesteuber.com](https://bsky.app/profile/lukesteuber.com)
- Email: <luke@lukesteuber.com>
- Support: [Tip Jar](https://usefulai.lemonsqueezy.com/buy/bf6ce1bd-85f5-4a09-ba10-191a670f74af)

## License

MIT License - see [LICENSE](LICENSE) for details.
