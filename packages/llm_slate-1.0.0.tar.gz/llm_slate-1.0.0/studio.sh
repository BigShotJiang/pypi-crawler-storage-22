#!/bin/bash
# Studio Server Management Script

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${STUDIO_PORT:-5413}"
PIDFILE="$SCRIPT_DIR/.studio.pid"

stop_server() {
    echo "🛑 Stopping Studio server on port $PORT..."
    
    # Try pidfile first
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE")
        if kill -0 "$PID" 2>/dev/null; then
            kill -9 "$PID" 2>/dev/null
            echo "   Killed process $PID from pidfile"
        fi
        rm -f "$PIDFILE"
    fi
    
    # Kill any processes on the port
    PIDS=$(lsof -ti :"$PORT" 2>/dev/null)
    if [ -n "$PIDS" ]; then
        echo "   Killing processes: $PIDS"
        kill -9 $PIDS 2>/dev/null
        echo "✓ Server stopped"
    else
        echo "✓ No server running on port $PORT"
    fi
}

start_server() {
    echo "🚀 Starting Studio server on port $PORT..."
    
    # Stop any existing server first
    stop_server
    
    cd "$SCRIPT_DIR"
    
    # Activate venv if it exists
    if [ -d "venv/bin" ]; then
        source venv/bin/activate
    fi
    
    # Start server in background
    export STUDIO_PORT="$PORT"
    nohup python app.py > studio.log 2>&1 &
    echo $! > "$PIDFILE"
    
    sleep 2
    
    if kill -0 $(cat "$PIDFILE") 2>/dev/null; then
        echo "✓ Server started successfully"
        echo "   PID: $(cat "$PIDFILE")"
        echo "   Port: $PORT"
        echo "   Log: $SCRIPT_DIR/studio.log"
        echo "   URL: http://localhost:$PORT"
    else
        echo "✗ Server failed to start. Check studio.log for errors."
        rm -f "$PIDFILE"
        exit 1
    fi
}

status_server() {
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "✓ Server is running (PID: $PID)"
            echo "   Port: $PORT"
            echo "   URL: http://localhost:$PORT"
            return 0
        else
            echo "✗ Server is not running (stale pidfile)"
            rm -f "$PIDFILE"
            return 1
        fi
    else
        PIDS=$(lsof -ti :"$PORT" 2>/dev/null)
        if [ -n "$PIDS" ]; then
            echo "⚠️  Process(es) running on port $PORT: $PIDS"
            echo "   (No pidfile found)"
            return 0
        else
            echo "✗ Server is not running"
            return 1
        fi
    fi
}

case "${1:-start}" in
    start)
        start_server
        ;;
    stop)
        stop_server
        ;;
    restart)
        stop_server
        sleep 1
        start_server
        ;;
    status)
        status_server
        ;;
    logs)
        tail -f "$SCRIPT_DIR/studio.log"
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the Studio server"
        echo "  stop    - Stop the Studio server"
        echo "  restart - Restart the Studio server"
        echo "  status  - Check server status"
        echo "  logs    - Tail the log file"
        echo ""
        echo "Environment:"
        echo "  STUDIO_PORT - Port to run on (default: 5413)"
        exit 1
        ;;
esac
