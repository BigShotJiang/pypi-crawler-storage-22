# LLM Watch SDK

Lightweight SDK to send LLM usage telemetry to the LLM Watch backend.

## Install

```bash
pip install llm-watch-sdk
```

## Quickstart

```python
from llm_watch import LLMWatch

watch = LLMWatch(
    backend_url="http://YOUR_BACKEND",
    project_api_key="YOUR_PROJECT_KEY",
)
```

## Providers

Wrap your provider client with the matching adapter, then call `invoke(...)`.

```python
# OpenAI example
from openai import OpenAI

client = OpenAI(api_key="...")
oa = watch.openai(client, model="gpt-4o-mini")
resp = oa.invoke({"messages": [{"role": "user", "content": "hello"}]})
```

```python
# Gemini example (google.genai)
from google import genai

client = genai.Client(api_key="...")
gm = watch.gemini(client, model="gemini-1.5-pro")
resp = gm.invoke({"contents": "hello"})
```

```python
# Bedrock example
br = watch.bedrock(region="eu-north-1", model_id="arn:aws:bedrock:...")
resp = br.invoke({...})
```
