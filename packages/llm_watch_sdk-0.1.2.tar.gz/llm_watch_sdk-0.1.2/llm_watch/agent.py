import time
from llm_watch.context import start_span, end_span, get_span_id, get_trace_id
from llm_watch.transport import Transport


class AgentStepContext:
    def __init__(self, name: str, framework: str | None, transport: Transport):
        self.name = name
        self.framework = framework
        self.transport = transport

    def __enter__(self):
        self.start = time.perf_counter()

        # parent span may be None (root agent step)
        parent_span_id = get_span_id()

        # create new span correctly linked
        self.span_id = start_span(parent_span_id)
        self.parent_span_id = parent_span_id

        return self.span_id

    def __exit__(self, exc_type, exc, tb):
        latency_ms = (time.perf_counter() - self.start) * 1000

        # send agent step to backend (never break user code)
        try:
            framework_norm = self.framework.lower() if self.framework else None

            self.transport.send_agent_step({
                "trace_id": get_trace_id(),
                "span_id": self.span_id,
                "parent_span_id": self.parent_span_id,
                "step_name": self.name,
                "framework": framework_norm,
                "latency_ms": latency_ms,
            })
        except Exception:
            pass

        # close span
        end_span(self.span_id)
