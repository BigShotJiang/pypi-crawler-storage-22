import time
import json
import boto3
from llm_watch.transport import Transport
from llm_watch.context import get_trace_id, get_span_id
from llm_watch.utils import build_call_metadata, maybe_wrap_streaming_response


class BedrockClient:
    def __init__(self, region: str, model_id: str, transport: Transport):
        self.region = region
        self.model_id = model_id
        self.transport = transport

        self.client = boto3.client(
            "bedrock-runtime",
            region_name=region,
        )

    def invoke(self, payload: dict):
        start = time.perf_counter()

        # Remove streaming flags from body payload (Bedrock streaming uses a separate API)
        body_payload = dict(payload or {})
        body_payload.pop("stream", None)
        body_payload.pop("streaming", None)

        if payload.get("stream") or payload.get("streaming"):
            if hasattr(self.client, "invoke_model_with_response_stream"):
                response = self.client.invoke_model_with_response_stream(
                    modelId=self.model_id,
                    body=json.dumps(body_payload),
                    contentType="application/json",
                    accept="application/json",
                )
                stream = response.get("body", response)
                model_short = _shorten_bedrock_model_id(self.model_id)

                meta_base = build_call_metadata(payload, response)
                req_id = response.get("ResponseMetadata", {}).get("RequestId")
                if req_id:
                    meta_base["request_id"] = req_id

                wrapper = maybe_wrap_streaming_response(
                    stream,
                    payload,
                    lambda acc: self._finalize_streaming(model_short, meta_base, acc, start),
                )
                if wrapper is not None:
                    return wrapper
                return stream

        response = self.client.invoke_model(
            modelId=self.model_id,
            body=json.dumps(body_payload),
            contentType="application/json",
            accept="application/json",
        )

        latency_ms = (time.perf_counter() - start) * 1000

        body = json.loads(response["body"].read())
        usage = body.get("usage", {})

        input_tokens = usage.get("inputTokens", 0)
        output_tokens = usage.get("outputTokens", 0)
        total_tokens = usage.get("totalTokens", input_tokens + output_tokens)

        from llm_watch.utils import normalize_provider

        model_short = _shorten_bedrock_model_id(self.model_id)

        meta = build_call_metadata(payload, body)
        # Bedrock request id
        req_id = None
        try:
            req_id = response.get("ResponseMetadata", {}).get("RequestId")
        except Exception:
            req_id = None
        if req_id:
            meta["request_id"] = req_id

        self.transport.send_llm_call({
            "provider": normalize_provider("aws-bedrock"),
            "model": model_short,
            "provider_model_id": self.model_id,

            "execution_mode": "llm",

            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,

            "latency_ms": latency_ms,

            # 🔑 observability
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta,
        })

        return body

    def _finalize_streaming(self, model_short: str, meta_base: dict, acc, start: float):
        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = acc.last_usage
        meta = dict(meta_base or {})
        if acc.output_chars and "output_chars" not in meta:
            meta["output_chars"] = acc.output_chars

        from llm_watch.utils import normalize_provider

        self.transport.send_llm_call({
            "provider": normalize_provider("aws-bedrock"),
            "model": model_short,
            "provider_model_id": self.model_id,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t or (i + o),
            "latency_ms": latency_ms,
            "streaming": True,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta,
        })


def _shorten_bedrock_model_id(model_id: str | None) -> str:
    if not model_id:
        return "unknown"
    model_id = str(model_id)
    # Handle inference profile / foundation model ARNs
    if "inference-profile/" in model_id:
        candidate = model_id.split("inference-profile/", 1)[-1]
    elif "foundation-model/" in model_id:
        candidate = model_id.split("foundation-model/", 1)[-1]
    else:
        candidate = model_id.split("/")[-1]

    # Strip trailing numeric version suffix (e.g., ":0")
    if ":" in candidate:
        parts = candidate.split(":")
        if parts[-1].isdigit():
            candidate = ":".join(parts[:-1]) or parts[-1]
        else:
            candidate = candidate

    # Strip common deployment/test suffixes
    for sfx in ("-test", "-dev", "-staging", "-prod"):
        if candidate.endswith(sfx):
            candidate = candidate[: -len(sfx)]
            break
    return candidate
