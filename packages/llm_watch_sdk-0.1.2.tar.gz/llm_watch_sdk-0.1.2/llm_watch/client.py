import os
from dotenv import load_dotenv

import time
from llm_watch.transport import Transport
from llm_watch.bedrock import BedrockClient
from llm_watch.openai import OpenAIClient
from llm_watch.anthropic import AnthropicClient
from llm_watch.cohere import CohereClient
from llm_watch.groq_adapter import GroqClient
from llm_watch.gemini import GeminiClient
from llm_watch.trace import Trace, Span
from llm_watch.agent import AgentStepContext

load_dotenv()


from llm_watch.utils import normalize_provider, extract_usage_from_response, compute_prompt_stats


def _normalize_provider(provider: str) -> str:
    # thin wrapper for compatibility; prefer `normalize_provider` from utils
    return normalize_provider(provider)


def _extract_usage_from_response(response) -> tuple:
    """Try to extract (input_tokens, output_tokens, total_tokens) from
    various provider response shapes.

    Supports:
      - OpenAI-like objects with a `.usage` attribute
      - dict responses with a `usage` key
      - dict responses with `body` (e.g., boto3 StreamingBody), where JSON contains `usage`
      - raw objects that implement `.read()` returning JSON
    """
    import json

    if not response:
        return 0, 0, 0

    # 1) OpenAI-like: response.usage
    usage = getattr(response, "usage", None)

    # 2) dict-like: response.get("usage")
    if usage is None and isinstance(response, dict):
        usage = response.get("usage")

    # 3) body-containing response (boto3 style)
    if usage is None and isinstance(response, dict) and "body" in response:
        body = response["body"]
        try:
            raw = body.read()
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            parsed = json.loads(raw)
            usage = parsed.get("usage")
        except Exception:
            usage = None

    # 4) object with read() (not dict)
    if usage is None and hasattr(response, "read"):
        try:
            raw = response.read()
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            parsed = json.loads(raw)
            usage = parsed.get("usage")
        except Exception:
            usage = None

    # Now map different token naming conventions
    def _get_int(u, *keys):
        if not u:
            return 0
        for k in keys:
            val = None
            if isinstance(u, dict):
                val = u.get(k)
            else:
                val = getattr(u, k, None)
            if val is not None:
                try:
                    return int(val)
                except Exception:
                    continue
        return 0

    input_tokens = _get_int(usage, "inputTokens", "prompt_tokens", "promptTokens", "input_tokens")
    output_tokens = _get_int(usage, "outputTokens", "completion_tokens", "completionTokens", "output_tokens")
    total_tokens = _get_int(usage, "totalTokens", "total_tokens", "totalTokens")

    if total_tokens == 0:
        total_tokens = input_tokens + output_tokens

    return input_tokens, output_tokens, total_tokens


class LLMCallRecorder:
    """Context manager that measures latency, optionally starts a span,
    extracts usage from the response, and sends an LLM call to the backend
    automatically on exit.

    Usage:
        with watch.record_llm_call(provider="groq", model="llama3-8b") as r:
            response = client.chat.completions.create(...)
            r.set_response(response)
    """

    def __init__(self, owner, provider: str, model: str, start_span: bool = True):
        self.owner = owner
        self.provider = provider
        self.model = model
        self.start_span = start_span

        self._start = None
        self._response = None
        self._span_ctx = None

        # captured usage values (extracted eagerly in set_response)
        self._input_tokens = None
        self._output_tokens = None
        self._total_tokens = None
        
        # Optional fields for analysis
        self._request_id = None
        self._provider_model_id = None
        self._prompt_fingerprint = None
        self._system_fingerprint = None
        self._streaming = False
        self._is_async = False
        self._input_chars = None
        self._output_chars = None
        self._messages_count = None
        self._tools_count = None
        self._tool_roundtrips = None
        self._error_type = None
        self._http_status = None
        self._retry_count = None

    def __enter__(self):
        self._start = time.perf_counter()
        if self.start_span:
            # start a span and attach span_id to the owner
            self._span_ctx = self.owner.span()
            self._span_ctx.__enter__()
        return self

    def set_response(self, response):
        """Provide the LLM response so usage can be extracted automatically.

        We extract usage eagerly here so that user code can still read/consume
        the response body afterwards without preventing token extraction.
        """
        self._response = response

        try:
            i, o, t = _extract_usage_from_response(response)
            self._input_tokens = i
            self._output_tokens = o
            self._total_tokens = t
        except Exception:
            # best-effort extraction: silence failures and leave values None
            self._input_tokens = None
            self._output_tokens = None
            self._total_tokens = None
    
    def set_request_metadata(
        self,
        request_id: str | None = None,
        provider_model_id: str | None = None,
        prompt_fingerprint: str | None = None,
        system_fingerprint: str | None = None,
        streaming: bool = False,
        is_async: bool = False,
        input_chars: int | None = None,
        output_chars: int | None = None,
        messages_count: int | None = None,
        tools_count: int | None = None,
        tool_roundtrips: int | None = None,
        error_type: str | None = None,
        http_status: int | None = None,
        retry_count: int | None = None,
    ):
        """Set optional metadata fields for analysis.
        
        These fields help with token optimization analysis:
        - prompt_fingerprint: Hash of normalized prompt content (for duplicate detection)
        - streaming: Whether this was a streaming request
        - retry_count: Number of retries (for waste detection)
        - etc.
        """
        if request_id is not None:
            self._request_id = request_id
        if provider_model_id is not None:
            self._provider_model_id = provider_model_id
        if prompt_fingerprint is not None:
            self._prompt_fingerprint = prompt_fingerprint
        if system_fingerprint is not None:
            self._system_fingerprint = system_fingerprint
        self._streaming = streaming
        self._is_async = is_async
        if input_chars is not None:
            self._input_chars = input_chars
        if output_chars is not None:
            self._output_chars = output_chars
        if messages_count is not None:
            self._messages_count = messages_count
        if tools_count is not None:
            self._tools_count = tools_count
        if tool_roundtrips is not None:
            self._tool_roundtrips = tool_roundtrips
        if error_type is not None:
            self._error_type = error_type
        if http_status is not None:
            self._http_status = http_status
        if retry_count is not None:
            self._retry_count = retry_count

    def set_messages(self, messages):
        """Convenience helper to set prompt fingerprint + message count + input chars."""
        try:
            fp, count, chars = compute_prompt_stats(messages)
            if fp:
                self._prompt_fingerprint = fp
            self._messages_count = count
            self._input_chars = chars
        except Exception:
            # best-effort; don't break user code
            return

    def __exit__(self, exc_type, exc, tb):
        end = time.perf_counter()
        latency_ms = (end - self._start) * 1000 if self._start is not None else 0.0

        # prefer eagerly-captured values (extracted at set_response time)
        if self._input_tokens is not None:
            input_tokens = self._input_tokens
            output_tokens = self._output_tokens or 0
            total_tokens = self._total_tokens or (input_tokens + output_tokens)
        else:
            input_tokens, output_tokens, total_tokens = _extract_usage_from_response(self._response)

        payload = {
            "provider": _normalize_provider(self.provider),
            "model": self.model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "latency_ms": latency_ms,
            "execution_mode": "llm",
            "trace_id": getattr(self.owner, "trace_id", None),
            "span_id": getattr(self.owner, "span_id", None),
            "parent_span_id": None,
            "framework": None,
            "step_name": None,
        }
        
        # Add optional fields if set
        if self._request_id is not None:
            payload["request_id"] = self._request_id
        if self._provider_model_id is not None:
            payload["provider_model_id"] = self._provider_model_id
        if self._prompt_fingerprint is not None:
            payload["prompt_fingerprint"] = self._prompt_fingerprint
        if self._system_fingerprint is not None:
            payload["system_fingerprint"] = self._system_fingerprint
        if self._streaming:
            payload["streaming"] = True
        if self._is_async:
            payload["is_async"] = True
        if self._input_chars is not None:
            payload["input_chars"] = self._input_chars
        if self._output_chars is not None:
            payload["output_chars"] = self._output_chars
        if self._messages_count is not None:
            payload["messages_count"] = self._messages_count
        if self._tools_count is not None:
            payload["tools_count"] = self._tools_count
        if self._tool_roundtrips is not None:
            payload["tool_roundtrips"] = self._tool_roundtrips
        if self._error_type is not None:
            payload["error_type"] = self._error_type
        if self._http_status is not None:
            payload["http_status"] = self._http_status
        if self._retry_count is not None:
            payload["retry_count"] = self._retry_count

        # best-effort send; SDK must not raise
        try:
            self.owner._transport.send_llm_call(payload)
        finally:
            if self.start_span and self._span_ctx is not None:
                # restore span context
                self._span_ctx.__exit__(exc_type, exc, tb)


class LLMWatch:
    def __init__(self, backend_url: str, project_api_key: str):
        self.backend_url = backend_url
        self.project_api_key = project_api_key

        self._transport = Transport(
            backend_url=backend_url,
            project_api_key=project_api_key,
        )

    # ---------- tracing ----------

    def trace(self):
        return Trace(owner=self)

    def span(self, name: str | None = None):
        return Span(name, owner=self)

    def record_llm_call(self, provider: str, model: str, start_span: bool = True):
        """Return a context manager that records an LLM call and sends it on exit.

        Example:
            with watch.record_llm_call("groq", "llama3-8b") as r:
                response = client.chat.completions.create(...)
                r.set_response(response)
        """
        return LLMCallRecorder(owner=self, provider=provider, model=model, start_span=start_span)

    # ---------- agent ----------

    def agent_step(self, name: str, framework: str | None = None):
        return AgentStepContext(
            name=name,
            framework=framework,
            transport=self._transport,
        )

    # ---------- llm providers ----------

    def bedrock(self, region: str | None = None, model_id: str | None = None):
        """Create a Bedrock client wrapper.
        
        Args:
            region: AWS region (defaults to AWS_REGION env var)
            model_id: Bedrock model ID (defaults to AWS_INFERENCE_PROFILE_ARN_CLAUDE_4_5 env var)
        """
        region = region or os.getenv("AWS_REGION")
        model_id = model_id or os.getenv("AWS_INFERENCE_PROFILE_ARN_CLAUDE_4_5")

        if not region:
            raise ValueError("AWS region not set")

        if not model_id:
            raise ValueError("Bedrock model_id not set")

        return BedrockClient(
            region=region,
            model_id=model_id,
            transport=self._transport,
        )

    def openai(self, client, model: str):
        """Create an OpenAI client wrapper.
        
        Args:
            client: An instance of openai.OpenAI or similar
            model: Model name (e.g., "gpt-4")
        """
        return OpenAIClient(client=client, model=model, transport=self._transport)

    def groq(self, client, model: str):
        """Create a Groq client wrapper.
        
        Args:
            client: An instance of groq.Groq
            model: Model name (e.g., "llama3-8b")
        """
        return GroqClient(client=client, model=model, transport=self._transport)

    def anthropic(self, client, model: str):
        """Create an Anthropic client wrapper.
        
        Args:
            client: An instance of anthropic.Anthropic
            model: Model name (e.g., "claude-3-opus-20240229")
        """
        return AnthropicClient(client=client, model=model, transport=self._transport)

    def cohere(self, client, model: str):
        """Create a Cohere client wrapper.
        
        Args:
            client: An instance of cohere.Client
            model: Model name (e.g., "command")
        """
        return CohereClient(client=client, model=model, transport=self._transport)

    def gemini(self, client, model: str):
        """Create a Gemini (Google Generative AI) client wrapper.
        
        Args:
            client: An instance of google.generativeai.GenerativeModel or similar
            model: Model name (e.g., "gemini-pro")
        """
        return GeminiClient(client=client, model=model, transport=self._transport)
