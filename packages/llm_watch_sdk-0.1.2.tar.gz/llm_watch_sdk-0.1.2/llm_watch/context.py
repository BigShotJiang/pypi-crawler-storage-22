# llm_watch/context.py
import contextvars
import uuid

_trace_id = contextvars.ContextVar("trace_id", default=None)
_span_id = contextvars.ContextVar("span_id", default=None)

def start_trace():
    tid = str(uuid.uuid4())
    _trace_id.set(tid)
    _span_id.set(None)
    return tid

def get_trace_id():
    return _trace_id.get()

def start_span(parent_span_id=None):
    sid = str(uuid.uuid4())
    _span_id.set(sid)
    return sid

def get_span_id():
    return _span_id.get()

def end_span(prev_span_id):
    _span_id.set(prev_span_id)
