import time
from llm_watch.utils import (
    normalize_provider,
    extract_usage_from_response,
    build_call_metadata,
    maybe_wrap_streaming_response,
    maybe_await,
)
from llm_watch.context import get_trace_id, get_span_id


class GeminiClient:
    def __init__(self, client, model: str, transport):
        """Wrap a Google Generative AI (gemini) client.
        
        Args:
            client: An instance of google.generativeai.GenerativeModel or similar
            model: Model name (e.g., "gemini-pro")
            transport: LLMWatch Transport instance
        """
        self.client = client
        self.model = model
        self.transport = transport

    def _invoke(self, payload: dict):
        # Google Gemini SDKs differ:
        # - google.generativeai: model.generate_content(...)
        # - google.genai: client.models.generate_content(model=..., contents=...)
        resp = None
        last_err = None
        # 1) google.genai style
        models = getattr(self.client, "models", None)
        if models is not None and hasattr(models, "generate_content"):
            try:
                call_payload = dict(payload or {})
                # normalize content key
                if "contents" not in call_payload and "content" in call_payload:
                    call_payload["contents"] = call_payload.pop("content")
                if "contents" not in call_payload and "messages" in call_payload:
                    call_payload["contents"] = call_payload.pop("messages")
                # google.genai streaming uses generate_content_stream
                if call_payload.get("stream") or call_payload.get("streaming"):
                    if hasattr(models, "generate_content_stream"):
                        # remove stream flag for method signature
                        call_payload.pop("stream", None)
                        call_payload.pop("streaming", None)
                        resp = models.generate_content_stream(model=self.model, **call_payload)
                    else:
                        resp = models.generate_content(model=self.model, **call_payload)
                else:
                    resp = models.generate_content(model=self.model, **call_payload)
            except Exception as e:
                last_err = e
                resp = None

        # 2) google.generativeai / model wrapper style
        if resp is None:
            for method_name in ("generate_content", "generate", "chat", "__call__"):
                fn = getattr(self.client, method_name, None)
                if not fn:
                    continue
                try:
                    # Try with provided payload
                    resp = fn(**payload)
                    break
                except TypeError:
                    # Try alternate key names commonly used by SDKs
                    alt_payload = dict(payload or {})
                    if "content" in alt_payload and "contents" not in alt_payload:
                        alt_payload["contents"] = alt_payload.pop("content")
                    elif "contents" in alt_payload and "content" not in alt_payload:
                        alt_payload["content"] = alt_payload.pop("contents")
                    try:
                        resp = fn(**alt_payload)
                        break
                    except Exception as e:
                        last_err = e
                        resp = None
                    # Try positional forms
                    try:
                        if "content" in payload:
                            resp = fn(payload["content"])
                        elif "contents" in payload:
                            resp = fn(payload["contents"])
                        elif "messages" in payload:
                            resp = fn(payload["messages"])
                        else:
                            resp = fn(payload)
                        break
                    except Exception as e:
                        last_err = e
                        continue

        if resp is None:
            if callable(self.client):
                resp = self.client(payload)
            else:
                if last_err is not None:
                    raise RuntimeError(f"Gemini invocation failed: {last_err}") from last_err
                raise RuntimeError("No invocation method found on Gemini client. Expected .generate_content() or similar.")

        return resp

    def invoke(self, payload: dict):
        start = time.perf_counter()
        resp = self._invoke(payload)

        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000

        # Extract usage - Gemini uses usage_metadata in response
        # Handle both object attributes and dict keys
        i, o, t = self._extract_gemini_usage(resp)

        self.transport.send_llm_call({
            "provider": normalize_provider("gemini"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    async def ainvoke(self, payload: dict):
        start = time.perf_counter()
        resp = await maybe_await(self._invoke(payload))
        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = self._extract_gemini_usage(resp)

        self.transport.send_llm_call({
            "provider": normalize_provider("gemini"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    def _finalize_streaming(self, meta_base: dict, acc, start: float):
        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = acc.last_usage
        meta = dict(meta_base or {})
        if acc.output_chars and "output_chars" not in meta:
            meta["output_chars"] = acc.output_chars

        self.transport.send_llm_call({
            "provider": normalize_provider("gemini"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t or (i + o),
            "latency_ms": latency_ms,
            "streaming": True,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta,
        })
    
    def _extract_gemini_usage(self, response):
        """Extract usage from Gemini response which uses usage_metadata.
        
        Gemini responses have:
        - response.usage_metadata.prompt_token_count
        - response.usage_metadata.candidates_token_count
        - response.usage_metadata.total_token_count
        """
        if not response:
            return 0, 0, 0
        
        # Try getting usage_metadata from object
        usage_metadata = getattr(response, "usage_metadata", None)
        
        # Try dict access
        if usage_metadata is None and isinstance(response, dict):
            usage_metadata = response.get("usage_metadata")
        
        if not usage_metadata:
            # Fallback to standard extraction
            return extract_usage_from_response(response)
        
        # Extract Gemini-specific fields
        def _get_token_count(um, *keys):
            if not um:
                return 0
            for k in keys:
                val = None
                if isinstance(um, dict):
                    val = um.get(k)
                else:
                    val = getattr(um, k, None)
                if val is not None:
                    try:
                        return int(val)
                    except Exception:
                        continue
            return 0
        
        input_tokens = _get_token_count(
            usage_metadata,
            "prompt_token_count",
            "prompt_tokens",
            "input_tokens",
            "inputTokenCount"
        )
        output_tokens = _get_token_count(
            usage_metadata,
            "candidates_token_count",
            "completion_tokens",
            "output_tokens",
            "outputTokenCount",
            "candidatesTokenCount"
        )
        total_tokens = _get_token_count(
            usage_metadata,
            "total_token_count",
            "total_tokens",
            "totalTokenCount"
        )
        
        if total_tokens == 0:
            total_tokens = input_tokens + output_tokens
        
        return input_tokens, output_tokens, total_tokens
