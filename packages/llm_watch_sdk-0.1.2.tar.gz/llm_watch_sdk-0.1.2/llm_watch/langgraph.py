import time
from llm_watch.utils import (
    normalize_provider,
    extract_usage_from_response,
    build_call_metadata,
    maybe_wrap_streaming_response,
    maybe_await,
)
from llm_watch.context import get_trace_id, get_span_id


class LangGraphClient:
    def __init__(self, client, model: str, transport):
        self.client = client
        self.model = model
        self.transport = transport

    def invoke(self, payload: dict):
        start = time.perf_counter()
        # LangGraph graphs expose .invoke(...) (and sometimes .stream/.run/.execute)
        fn = (
            getattr(self.client, "invoke", None)
            or getattr(self.client, "run", None)
            or getattr(self.client, "execute", None)
            or getattr(self.client, "stream", None)
        )
        if fn:
            try:
                resp = fn(**payload)
            except TypeError:
                resp = fn(payload)
        elif callable(self.client):
            resp = self.client(payload)
        else:
            raise RuntimeError("No invocation method found on LangGraph client")

        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = extract_usage_from_response(resp)

        self.transport.send_llm_call({
            "provider": normalize_provider("langgraph"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    async def ainvoke(self, payload: dict):
        start = time.perf_counter()
        fn = (
            getattr(self.client, "ainvoke", None)
            or getattr(self.client, "invoke", None)
            or getattr(self.client, "run", None)
            or getattr(self.client, "execute", None)
            or getattr(self.client, "stream", None)
        )
        if fn:
            try:
                resp = await maybe_await(fn(**payload))
            except TypeError:
                resp = await maybe_await(fn(payload))
        elif callable(self.client):
            resp = await maybe_await(self.client(payload))
        else:
            raise RuntimeError("No invocation method found on LangGraph client")

        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = extract_usage_from_response(resp)

        self.transport.send_llm_call({
            "provider": normalize_provider("langgraph"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    def _finalize_streaming(self, meta_base: dict, acc, start: float):
        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = acc.last_usage
        meta = dict(meta_base or {})
        if acc.output_chars and "output_chars" not in meta:
            meta["output_chars"] = acc.output_chars

        self.transport.send_llm_call({
            "provider": normalize_provider("langgraph"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t or (i + o),
            "latency_ms": latency_ms,
            "streaming": True,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta,
        })
