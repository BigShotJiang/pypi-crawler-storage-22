import time
from llm_watch.utils import (
    normalize_provider,
    extract_usage_from_response,
    build_call_metadata,
    maybe_wrap_streaming_response,
    maybe_await,
)
from llm_watch.context import get_trace_id, get_span_id


class OpenAIClient:
    def __init__(self, client, model: str, transport):
        # `client` is expected to have `chat.completions.create` or similar
        self.client = client
        self.model = model
        self.transport = transport

    def _invoke(self, payload: dict):
        # Prefer new Responses API when available
        responses = getattr(self.client, "responses", None)
        if responses is not None and hasattr(responses, "create"):
            try:
                return responses.create(model=self.model, **payload)
            except TypeError:
                alt = dict(payload or {})
                if "input" not in alt:
                    if "messages" in alt:
                        alt["input"] = alt.pop("messages")
                    elif "prompt" in alt:
                        alt["input"] = alt.pop("prompt")
                return responses.create(model=self.model, **alt)

        # Legacy Chat Completions
        chat = getattr(self.client, "chat", None)
        if chat is not None and hasattr(chat, "completions"):
            try:
                return chat.completions.create(model=self.model, **payload)
            except Exception:
                pass

        # Legacy Completions
        completions = getattr(self.client, "completions", None)
        if completions is not None and hasattr(completions, "create"):
            return completions.create(model=self.model, **payload)

        raise RuntimeError("No invocation method found on OpenAI client.")

    def invoke(self, payload: dict):
        start = time.perf_counter()
        resp = self._invoke(payload)
        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(payload, meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = extract_usage_from_response(resp)
        self.transport.send_llm_call({
            "provider": normalize_provider("openai"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    async def ainvoke(self, payload: dict):
        start = time.perf_counter()
        resp = await maybe_await(self._invoke(payload))
        meta_base = build_call_metadata(payload, resp)
        wrapper = maybe_wrap_streaming_response(
            resp,
            payload,
            lambda acc: self._finalize_streaming(payload, meta_base, acc, start),
        )
        if wrapper is not None:
            return wrapper

        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = extract_usage_from_response(resp)
        self.transport.send_llm_call({
            "provider": normalize_provider("openai"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t,
            "latency_ms": latency_ms,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta_base,
        })

        return resp

    def _finalize_streaming(self, payload: dict, meta_base: dict, acc, start: float):
        latency_ms = (time.perf_counter() - start) * 1000
        i, o, t = acc.last_usage
        meta = dict(meta_base or {})
        if acc.output_chars and "output_chars" not in meta:
            meta["output_chars"] = acc.output_chars

        self.transport.send_llm_call({
            "provider": normalize_provider("openai"),
            "model": self.model,
            "provider_model_id": None,
            "execution_mode": "llm",
            "input_tokens": i,
            "output_tokens": o,
            "total_tokens": t or (i + o),
            "latency_ms": latency_ms,
            "streaming": True,
            "trace_id": get_trace_id(),
            "span_id": get_span_id(),
            "parent_span_id": None,
            **meta,
        })
