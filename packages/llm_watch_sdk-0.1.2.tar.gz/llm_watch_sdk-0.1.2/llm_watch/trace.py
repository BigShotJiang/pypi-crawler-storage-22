from llm_watch.context import (
    start_trace,
    start_span,
    end_span,
    get_span_id,
)


class Trace:
    def __init__(self, owner=None):
        self.owner = owner

    def __enter__(self):
        self.trace_id = start_trace()
        # attach to owner if provided
        if self.owner is not None:
            self.owner.trace_id = self.trace_id
            self.owner.span_id = get_span_id()
        return self.trace_id

    def __exit__(self, exc_type, exc, tb):
        # clear owner attributes when exiting
        if self.owner is not None:
            self.owner.trace_id = None
            self.owner.span_id = None


class Span:
    def __init__(self, name: str | None = None, owner=None):
        self.name = name
        self.owner = owner

    def __enter__(self):
        self.parent_span = get_span_id()
        self.span_id = start_span(self.parent_span)
        # attach to owner if provided
        if self.owner is not None:
            self.owner.span_id = self.span_id
        return self.span_id

    def __exit__(self, exc_type, exc, tb):
        end_span(self.parent_span)
        if self.owner is not None:
            # restore parent's span id on the owner
            self.owner.span_id = self.parent_span
