import requests


class Transport:
    def __init__(self, backend_url: str, project_api_key: str):
        self.backend_url = backend_url.rstrip("/")
        self.project_api_key = project_api_key

    def send_llm_call(self, payload: dict):
        try:
            url = f"{self.backend_url}/api/v1/ingest/llm-call"
            print(f"[llm-watch sdk] POST {url} payload keys: {list(payload.keys())}")
            r = requests.post(
                url,
                json=payload,
                headers={
                    "X-API-Key": self.project_api_key,
                    "Content-Type": "application/json",
                },
                timeout=2,
            )
            print(f"[llm-watch sdk] Response status: {r.status_code}")
        except Exception as e:
            print(f"[llm-watch sdk] send_llm_call error: {e}")
            # infra rule: never break user code
            pass

    def send_agent_step(self, payload: dict):
        try:
            url = f"{self.backend_url}/api/v1/ingest/agent-step"
            print(f"[llm-watch sdk] POST {url} payload keys: {list(payload.keys())}")
            r = requests.post(
                url,
                json=payload,
                headers={
                    "X-API-Key": self.project_api_key,
                    "Content-Type": "application/json",
                },
                timeout=2,
            )
            print(f"[llm-watch sdk] Response status: {r.status_code}")
        except Exception as e:
            print(f"[llm-watch sdk] send_agent_step error: {e}")
            pass
