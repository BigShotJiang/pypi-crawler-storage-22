import json
import hashlib
import inspect
from typing import Any


def normalize_provider(provider: str) -> str:
    if not provider:
        return provider

    p = provider.strip().lower()
    if p.startswith("aws-"):
        p = p[len("aws-") :]
    return p


# Reuse the robust extraction logic from client
def extract_usage_from_response(response) -> tuple:
    if not response:
        return 0, 0, 0

    # First, try Gemini-style usage_metadata
    usage_metadata = getattr(response, "usage_metadata", None)
    if usage_metadata is None and isinstance(response, dict):
        usage_metadata = response.get("usage_metadata")
    
    if usage_metadata:
        def _get_token_count(um, *keys):
            if not um:
                return 0
            for k in keys:
                val = None
                if isinstance(um, dict):
                    val = um.get(k)
                else:
                    val = getattr(um, k, None)
                if val is not None:
                    try:
                        return int(val)
                    except Exception:
                        continue
            return 0
        
        input_tokens = _get_token_count(
            usage_metadata,
            "prompt_token_count",
            "prompt_tokens",
            "input_tokens",
            "inputTokenCount"
        )
        output_tokens = _get_token_count(
            usage_metadata,
            "candidates_token_count",
            "completion_tokens",
            "output_tokens",
            "outputTokenCount",
            "candidatesTokenCount"
        )
        total_tokens = _get_token_count(
            usage_metadata,
            "total_token_count",
            "total_tokens",
            "totalTokenCount"
        )
        
        if total_tokens == 0:
            total_tokens = input_tokens + output_tokens
        
        if input_tokens > 0 or output_tokens > 0:
            return input_tokens, output_tokens, total_tokens

    # Fallback to standard OpenAI-style usage
    usage = getattr(response, "usage", None)

    if usage is None and isinstance(response, dict):
        usage = response.get("usage")

    # Cohere / LangChain / other SDKs often store usage under meta/metadata/response_metadata
    def _get(obj, key):
        if obj is None:
            return None
        if isinstance(obj, dict):
            return obj.get(key)
        return getattr(obj, key, None)

    def _get_meta_usage(meta_obj):
        if not meta_obj:
            return None
        # Common nested usage locations
        for k in ("billed_units", "billedUnits", "token_usage", "tokenUsage", "usage", "tokens"):
            val = _get(meta_obj, k)
            if val:
                return val
        return None

    if usage is None:
        meta = _get(response, "meta") or _get(response, "metadata") or _get(response, "response_metadata")
        usage = _get_meta_usage(meta)

    if usage is None and isinstance(response, dict) and "body" in response:
        body = response["body"]
        try:
            raw = body.read()
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            parsed = json.loads(raw)
            usage = parsed.get("usage")
        except Exception:
            usage = None

    # Bedrock streaming chunks: {"chunk": {"bytes": b"...json..."}}
    if usage is None and isinstance(response, dict) and "chunk" in response:
        try:
            chunk = response.get("chunk") or {}
            raw = chunk.get("bytes")
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            parsed = json.loads(raw)
            usage = parsed.get("usage")
        except Exception:
            usage = None

    if usage is None and hasattr(response, "read"):
        try:
            raw = response.read()
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8")
            parsed = json.loads(raw)
            usage = parsed.get("usage")
        except Exception:
            usage = None

    def _get_int(u, *keys):
        if not u:
            return 0
        for k in keys:
            val = None
            if isinstance(u, dict):
                val = u.get(k)
            else:
                val = getattr(u, k, None)
            if val is not None:
                try:
                    return int(val)
                except Exception:
                    continue
        return 0

    input_tokens = _get_int(usage, "inputTokens", "prompt_tokens", "promptTokens", "input_tokens")
    output_tokens = _get_int(usage, "outputTokens", "completion_tokens", "completionTokens", "output_tokens")
    total_tokens = _get_int(usage, "totalTokens", "total_tokens", "totalTokens")

    if total_tokens == 0:
        total_tokens = input_tokens + output_tokens

    return input_tokens, output_tokens, total_tokens


def _is_simple_iterable(obj: Any) -> bool:
    if obj is None:
        return False
    if isinstance(obj, (str, bytes, bytearray, dict, list, tuple)):
        return False
    if inspect.isgenerator(obj):
        return True
    return hasattr(obj, "__next__")


def _is_async_iterable(obj: Any) -> bool:
    if obj is None:
        return False
    return hasattr(obj, "__aiter__")


def is_streaming_payload(payload: Any | None) -> bool:
    if not payload or not isinstance(payload, dict):
        return False
    for key in ("stream", "streaming"):
        if payload.get(key) is True:
            return True
    return False


def is_streaming_response(response: Any) -> bool:
    # Heuristic: async iterator or non-trivial iterable response
    if _is_async_iterable(response):
        return True
    return _is_simple_iterable(response)


def extract_text_from_response(response: Any) -> str:
    if response is None:
        return ""
    if isinstance(response, str):
        return response
    if isinstance(response, bytes):
        try:
            return response.decode("utf-8")
        except Exception:
            return ""
    if isinstance(response, dict):
        # OpenAI/Anthropic/Gemini common shapes
        if isinstance(response.get("text"), str):
            return response["text"]
        if isinstance(response.get("content"), str):
            return response["content"]
        choices = response.get("choices")
        if isinstance(choices, list) and choices:
            for choice in choices:
                if isinstance(choice, dict):
                    delta = choice.get("delta") or choice.get("message") or {}
                    if isinstance(delta, dict) and isinstance(delta.get("content"), str):
                        return delta["content"]
                    if isinstance(choice.get("text"), str):
                        return choice["text"]
        candidates = response.get("candidates")
        if isinstance(candidates, list) and candidates:
            for cand in candidates:
                if isinstance(cand, dict):
                    content = cand.get("content")
                    if isinstance(content, dict):
                        parts = content.get("parts")
                        if isinstance(parts, list) and parts:
                            for part in parts:
                                if isinstance(part, dict) and isinstance(part.get("text"), str):
                                    return part["text"]
        return ""
    # Object attributes
    for attr in ("text", "content"):
        val = getattr(response, attr, None)
        if isinstance(val, str):
            return val
    # OpenAI-style objects with choices
    choices = getattr(response, "choices", None)
    if choices:
        try:
            for choice in choices:
                delta = getattr(choice, "delta", None) or getattr(choice, "message", None)
                if isinstance(delta, dict) and isinstance(delta.get("content"), str):
                    return delta["content"]
                if isinstance(getattr(choice, "text", None), str):
                    return choice.text
        except Exception:
            pass
    return ""


def extract_text_from_chunk(chunk: Any) -> str:
    if chunk is None:
        return ""
    if isinstance(chunk, str):
        return chunk
    if isinstance(chunk, bytes):
        try:
            return chunk.decode("utf-8")
        except Exception:
            return ""
    if isinstance(chunk, dict):
        # Bedrock streaming chunks often contain {"chunk": {"bytes": b"..."}}
        if isinstance(chunk.get("chunk"), dict) and chunk["chunk"].get("bytes") is not None:
            try:
                raw = chunk["chunk"]["bytes"]
                if isinstance(raw, (bytes, bytearray)):
                    raw = raw.decode("utf-8")
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    for key in ("completion", "outputText", "text", "content"):
                        if isinstance(parsed.get(key), str):
                            return parsed[key]
            except Exception:
                pass
        # OpenAI responses stream events
        if isinstance(chunk.get("delta"), str):
            return chunk["delta"]
        if isinstance(chunk.get("text"), str):
            return chunk["text"]
        if isinstance(chunk.get("content"), str):
            return chunk["content"]
        # OpenAI chat-completions streaming chunks
        choices = chunk.get("choices")
        if isinstance(choices, list) and choices:
            for choice in choices:
                if isinstance(choice, dict):
                    delta = choice.get("delta") or choice.get("message") or {}
                    if isinstance(delta, dict) and isinstance(delta.get("content"), str):
                        return delta["content"]
                    if isinstance(choice.get("text"), str):
                        return choice["text"]
        # Anthropic streaming chunks
        if isinstance(chunk.get("delta"), dict) and isinstance(chunk["delta"].get("text"), str):
            return chunk["delta"]["text"]
        return ""
    # Object attributes
    val = getattr(chunk, "text", None)
    if isinstance(val, str):
        return val
    delta = getattr(chunk, "delta", None)
    if isinstance(delta, str):
        return delta
    if isinstance(delta, dict) and isinstance(delta.get("text"), str):
        return delta["text"]
    return ""


class _StreamAccumulator:
    def __init__(self):
        self.output_chars = 0
        self.last_usage = (0, 0, 0)

    def on_chunk(self, chunk: Any) -> None:
        try:
            text = extract_text_from_chunk(chunk)
            if text:
                self.output_chars += len(text)
        except Exception:
            pass
        try:
            i, o, t = extract_usage_from_response(chunk)
            if i or o or t:
                self.last_usage = (i, o, t)
        except Exception:
            pass


class StreamingResponseWrapper:
    def __init__(self, stream, on_complete):
        self._stream = stream
        self._on_complete = on_complete
        self._acc = _StreamAccumulator()
        self._closed = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._acc.on_chunk(chunk)
            return chunk
        except StopIteration:
            self._finish()
            raise

    def close(self):
        try:
            if hasattr(self._stream, "close"):
                self._stream.close()
        finally:
            self._finish()

    def _finish(self):
        if not self._closed:
            self._closed = True
            self._on_complete(self._acc)


class AsyncStreamingResponseWrapper:
    def __init__(self, stream, on_complete):
        self._stream = stream
        self._on_complete = on_complete
        self._acc = _StreamAccumulator()
        self._closed = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._acc.on_chunk(chunk)
            return chunk
        except StopAsyncIteration:
            await self._finish()
            raise

    async def aclose(self):
        try:
            if hasattr(self._stream, "aclose"):
                await self._stream.aclose()
        finally:
            await self._finish()

    async def _finish(self):
        if not self._closed:
            self._closed = True
            result = self._on_complete(self._acc)
            if inspect.isawaitable(result):
                await result


def maybe_wrap_streaming_response(response: Any, payload: Any | None, on_complete):
    if not is_streaming_payload(payload) and not is_streaming_response(response):
        return None
    if _is_async_iterable(response):
        return AsyncStreamingResponseWrapper(response, on_complete)
    if _is_simple_iterable(response):
        return StreamingResponseWrapper(response, on_complete)
    return None


async def maybe_await(result):
    if inspect.isawaitable(result):
        return await result
    return result


def _normalize_message(msg: Any) -> dict:
    if isinstance(msg, dict):
        role = msg.get("role") or msg.get("type") or "user"
        content = msg.get("content")
        if content is None and "text" in msg:
            content = msg.get("text")
        if content is None and "message" in msg:
            content = msg.get("message")
        return {"role": str(role), "content": content}

    if isinstance(msg, (list, tuple)) and len(msg) >= 2:
        return {"role": str(msg[0]), "content": msg[1]}

    return {"role": "user", "content": msg}


def normalize_messages(messages: Any) -> list[dict]:
    if messages is None:
        return []
    if isinstance(messages, str):
        return [{"role": "user", "content": messages}]
    if isinstance(messages, dict):
        return [_normalize_message(messages)]
    if isinstance(messages, (list, tuple)):
        return [_normalize_message(m) for m in messages]
    return [{"role": "user", "content": messages}]


def _content_to_str(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, (int, float, bool)):
        return str(content)
    try:
        return json.dumps(content, sort_keys=True, ensure_ascii=False, default=str)
    except Exception:
        return str(content)


def compute_prompt_fingerprint(messages: Any) -> str:
    normalized = normalize_messages(messages)
    raw = json.dumps(normalized, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def compute_prompt_stats(messages: Any) -> tuple[str, int, int]:
    normalized = normalize_messages(messages)
    fingerprint = compute_prompt_fingerprint(normalized)
    messages_count = len(normalized)
    input_chars = sum(len(_content_to_str(m.get("content"))) for m in normalized)
    return fingerprint, messages_count, input_chars


def extract_messages_from_payload(payload: Any | None) -> Any | None:
    if not payload or not isinstance(payload, dict):
        return None
    for key in (
        "messages",
        "contents",
        "content",
        "prompt",
        "input",
        "text",
        "query",
        "question",
        "instruction",
    ):
        if key in payload and payload[key] is not None:
            return payload[key]
    return None


def compute_prompt_stats_from_payload(payload: Any | None) -> tuple[str, int, int] | None:
    messages = extract_messages_from_payload(payload)
    if messages is None:
        return None
    return compute_prompt_stats(messages)


def extract_tools_count(payload: Any | None) -> int | None:
    if not payload or not isinstance(payload, dict):
        return None
    for key in ("tools", "functions", "tool_calls"):
        val = payload.get(key)
        if isinstance(val, (list, tuple)):
            return len(val)
    return None


def extract_request_id(response: Any, payload: Any | None = None) -> str | None:
    if isinstance(payload, dict):
        for key in ("request_id", "requestId", "id"):
            val = payload.get(key)
            if val:
                return str(val)
    if response is None:
        return None
    if isinstance(response, dict):
        for key in ("id", "request_id", "requestId", "response_id"):
            val = response.get(key)
            if val:
                return str(val)
    for attr in ("id", "request_id", "requestId", "response_id"):
        val = getattr(response, attr, None)
        if val:
            return str(val)
    return None


def build_call_metadata(payload: Any | None, response: Any) -> dict:
    meta: dict[str, Any] = {}
    stats = compute_prompt_stats_from_payload(payload)
    if stats:
        fp, msg_count, input_chars = stats
        meta["prompt_fingerprint"] = fp
        meta["messages_count"] = msg_count
        meta["input_chars"] = input_chars

    tools_count = extract_tools_count(payload)
    if tools_count is not None:
        meta["tools_count"] = tools_count

    req_id = extract_request_id(response, payload=payload)
    if req_id:
        meta["request_id"] = req_id

    try:
        output_text = extract_text_from_response(response)
        if output_text:
            meta["output_chars"] = len(output_text)
    except Exception:
        pass

    return meta
