<p align="center">
  <a href="https://llmcad.org"><img src="https://llmcad.org/img/logo.png" alt="llmcad" width="400"></a>
</p>
<p align="center">
  <em>A minimal, LLM-friendly CAD library in Python.</em>
</p>
<p align="center">
<a href="https://pypi.org/project/llmcad" target="_blank">
    <img src="https://img.shields.io/pypi/v/llmcad?color=blue&label=PyPI" alt="PyPI version">
</a>
<a href="https://pypi.org/project/llmcad" target="_blank">
    <img src="https://img.shields.io/pypi/pyversions/llmcad" alt="Python versions">
</a>
<a href="https://github.com/llmcad/llmcad/blob/main/LICENSE" target="_blank">
    <img src="https://img.shields.io/github/license/llmcad/llmcad" alt="License">
</a>
</p>

---

**Documentation**: <a href="https://llmcad.org" target="_blank">https://llmcad.org</a>

**Source Code**: <a href="https://github.com/llmcad/llmcad" target="_blank">https://github.com/llmcad/llmcad</a>

---

llmcad is a Python CAD library designed from the ground up to be LLM-friendly, by abstracting 3d spatial reasoning (e.g. absolute coordinate positioning), which LLMs typically struggle with. It wraps OpenCASCADE (via OCP) with a minimal, explicit API that makes 3D modeling predictable and debuggable for AI agents.

The key features are:

- **Minimal API**: ~28 core concepts. Shapes, sketches, operations, booleans, assemblies — nothing more.
- **Named faces and edges**: Every face and edge has a semantic name (`top`, `front`, `left_edge`, ...), so LLMs can reference geometry unambiguously.
- **Face-local coordinate systems**: Each face carries its own 2D frame. Positioning on faces uses intuitive local offsets — no global coordinate math.
- **Visual debugging**: Built-in multi-view snapshots, face coloring, and edge visualization for LLM feedback loops.
- **Immutable operations**: Boolean ops return new bodies. No mutation, no surprises.

## Installation

```bash
pip install llmcad
```

## Example

```python
from llmcad import Box, Cylinder, Rect, extrude, fillet, snapshot

# Create a base plate
plate = Box(100, 60, 10, name="plate")

# Add a boss on the top face
boss = extrude(
    Rect(30, 30).place_on(plate.top),
    amount=20,
    name="boss",
)
plate = plate + boss

# Cut a hole through the boss
hole = extrude(
    Rect(10, 10).place_on(plate.faces["boss_end"]),
    through=True,
    name="hole",
)
plate = plate - hole

# Fillet the top edges of the boss
plate = fillet(plate.faces["boss_end"].edges, radius=3)

# Render a multi-view snapshot
snapshot(plate, "plate")
```

## License

This project is licensed under the terms of the MIT license.
