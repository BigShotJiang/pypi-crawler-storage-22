"""llmcad - A minimal, LLM-friendly CAD library in Python."""

__version__ = "0.1.0"
