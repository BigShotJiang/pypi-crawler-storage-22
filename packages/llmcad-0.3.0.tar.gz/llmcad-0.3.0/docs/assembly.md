# Assembly

Assemble multiple parts by positioning them on faces and combining them into assemblies.

## place

```python
place(
    part: Body,
    on: FaceRef,
    at: Position = None,
    name: str = "",
) -> Body
```

Place a part so its center aligns with a position on a face. Returns a new body translated to the target position.

| Parameter | Description |
|-----------|-------------|
| `part` | The body to place |
| `on` | The face to place on |
| `at` | Position on the face (default: face center) |
| `name` | Optional name for the placed part |

```python
from llmcad import Box, Cylinder, place

base = Box(100, 60, 10)

# Place a cylinder boss on the top face
boss = Cylinder(20, height=30)
boss = place(boss, on=base.top, at=base.top.center)
base = base + boss
```

```python
# Place at an offset position
pos = base.top.center.offset(dx=30)
peg = Cylinder(8, height=15)
peg = place(peg, on=base.top, at=pos)
base = base + peg
```

```python
# Place at corners
for corner in base.bottom.corners:
    pos = corner.inset(8, 8)
    foot = Cylinder(6, height=5)
    foot = place(foot, on=base.bottom, at=pos)
    base = base + foot
```

## Assembly

```python
Assembly(name: str = "")
```

A collection of parts and joints forming a mechanical assembly.

**Methods:**

| Method | Description |
|--------|-------------|
| `add(part, name="")` | Add a part to the assembly |
| `add_joint(joint)` | Add a joint between parts |
| `build()` | Combine all parts into a single `Body` |

**Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `part` | `TopoDS_Shape` | Combined compound shape |
| `name` | `str` | Assembly name |

```python
from llmcad import Box, Cylinder, place, Assembly

base = Box(100, 60, 10)
lid = Box(100, 60, 3)
lid = place(lid, on=base.top, at=base.top.center)

peg = Cylinder(8, height=20)
peg = place(peg, on=base.top, at=base.top.center)

asm = Assembly(name="enclosure")
asm.add(base, name="base")
asm.add(lid, name="lid")
asm.add(peg, name="peg")

result = asm.build()
```

## RevoluteJoint

```python
@dataclass
class RevoluteJoint:
    axis: gp_Ax1
    part_a: str = ""
    part_b: str = ""
    range: tuple[float, float] | None = None
```

A revolute (rotational) joint between two parts. Used for defining kinematic relationships in assemblies.

| Field | Description |
|-------|-------------|
| `axis` | Rotation axis (`gp_Ax1`) |
| `part_a` | Name of the first part |
| `part_b` | Name of the second part |
| `range` | `(min_angle, max_angle)` in degrees, or `None` for unlimited rotation |

```python
from OCP.gp import gp_Ax1, gp_Pnt, gp_Dir
from llmcad import Assembly, RevoluteJoint

asm = Assembly("hinge")
asm.add(door, name="door")
asm.add(frame, name="frame")

joint = RevoluteJoint(
    axis=gp_Ax1(gp_Pnt(0, 0, 0), gp_Dir(0, 0, 1)),
    part_a="frame",
    part_b="door",
    range=(0, 120),
)
asm.add_joint(joint)
```
