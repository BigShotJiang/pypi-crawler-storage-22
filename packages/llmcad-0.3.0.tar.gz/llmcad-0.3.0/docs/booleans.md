# Booleans

Boolean operations combine two bodies into one. They use Python operators for a natural syntax.

## Union (`+`)

Merges two bodies into a single solid.

```python
from llmcad import Box, Cylinder

plate = Box(100, 60, 10)
peg = Cylinder(10, 30)

result = plate + peg  # fused together
```

The result carries face names from **both** operands. If both bodies have a face named `top`, the face from the left operand takes priority.

## Cut (`-`)

Subtracts the right body from the left.

```python
from llmcad import Box, Cylinder, extrude, Circle

plate = Box(100, 60, 10)

# Create a through-hole
hole = extrude(Circle(10).place_on(plate.top), through=True)
plate = plate - hole
```

Only face names from the **left** operand are preserved.

## Intersect (`&`)

Keeps only the volume where both bodies overlap.

```python
from llmcad import Box, Sphere

box = Box(30, 30, 30)
ball = Sphere(40)

# Only the part of the sphere inside the box
result = box & ball
```

## Face name transfer

One of llmcad's key features is that face names **survive** boolean operations. After a union or cut, you can still refer to `body.top`, `body.front`, etc.

```python
plate = Box(100, 60, 10, name="plate")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)

# After union, plate's face names are preserved
plate = plate + boss
print(plate.top)    # still works
print(plate.front)  # still works
```

The transfer algorithm uses geometric matching: it finds faces in the new shape that have the same center and normal as the original named faces.

## Chaining operations

Because booleans return new bodies, you can chain them:

```python
plate = Box(100, 60, 10)

# Add multiple bosses
for dx in [-20, 0, 20]:
    pos = plate.top.center.offset(dx=dx)
    boss = extrude(Rect(10, 10).place_on(plate.top, at=pos), amount=15)
    plate = plate + boss

# Cut multiple holes
for dx in [-20, 0, 20]:
    pos = plate.top.center.offset(dx=dx)
    hole = extrude(Circle(5).place_on(plate.top, at=pos), through=True)
    plate = plate - hole
```

## Color inheritance

After a union (`+`) or cut (`-`), the result inherits the **left** operand's color:

```python
plate = Box(100, 60, 10, color="steel")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)

result = plate + boss
# result has color="steel"
```
