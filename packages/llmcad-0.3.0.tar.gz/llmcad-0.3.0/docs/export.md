# Export

llmcad can export bodies to STEP, STL, and GLB (binary glTF) formats.

## export_step

```python
export_step(body, path: str) -> str
```

Export to [STEP](https://en.wikipedia.org/wiki/ISO_10303-21) format (AP214). This is the standard CAD interchange format supported by all major CAD software.

| Parameter | Description |
|-----------|-------------|
| `body` | Body to export |
| `path` | Output file path (e.g. `"part.step"`) |

```python
from llmcad import Box, export_step

plate = Box(100, 60, 10)
export_step(plate, "plate.step")
```

## export_stl

```python
export_stl(body, path: str, deflection: float = 0.05) -> str
```

Export to [STL](https://en.wikipedia.org/wiki/STL_(file_format)) format. Commonly used for 3D printing.

| Parameter | Description |
|-----------|-------------|
| `body` | Body to export |
| `path` | Output file path (e.g. `"part.stl"`) |
| `deflection` | Mesh quality --- smaller = finer mesh (default: 0.05) |

```python
from llmcad import Box, export_stl

plate = Box(100, 60, 10)
export_stl(plate, "plate.stl")

# Higher quality mesh for 3D printing
export_stl(plate, "plate_hq.stl", deflection=0.01)
```

## export_glb

```python
export_glb(body, path: str, deflection: float = 0.05) -> str
```

Export to [GLB](https://www.khronos.org/gltf/) (binary glTF 2.0) format. Ideal for web viewers like [three.js](https://threejs.org/) and [&lt;model-viewer&gt;](https://modelviewer.dev/).

| Parameter | Description |
|-----------|-------------|
| `body` | Body to export |
| `path` | Output file path (e.g. `"part.glb"`) |
| `deflection` | Mesh quality --- smaller = finer mesh (default: 0.05) |

The exported GLB includes:

- Mesh geometry with per-vertex normals
- PBR material with the body's color

```python
from llmcad import Box, export_glb

plate = Box(100, 60, 10, color="steel")
export_glb(plate, "plate.glb")
```

## Format comparison

| Format | Use case | Preserves geometry? | File size |
|--------|----------|-------------------|-----------|
| STEP | CAD interchange, editing in other tools | Yes (exact B-Rep) | Large |
| STL | 3D printing, simulation | No (triangulated) | Medium |
| GLB | Web viewers, AR/VR, visualization | No (triangulated) | Small |

!!! tip "When to use which"
    - **STEP** if you need to import into another CAD tool (Fusion 360, SolidWorks, FreeCAD)
    - **STL** if you're 3D printing
    - **GLB** if you're displaying in a web browser or need a compact file
