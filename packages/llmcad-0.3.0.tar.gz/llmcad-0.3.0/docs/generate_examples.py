#!/usr/bin/env python3
"""Generate example images for the llmcad documentation.

Run from the repo root:
    python docs/generate_examples.py
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from llmcad import (
    Box, Cylinder, Sphere, Rect, Circle,
    extrude, fillet, chamfer, snapshot,
)
from llmcad._render import render_view, VIEWS
from PIL import Image

OUTPUT = os.path.join(os.path.dirname(__file__), "img", "examples")
os.makedirs(OUTPUT, exist_ok=True)


def render_iso(body, name, color=None):
    """Render a single isometric view and save it."""
    shape = body.part
    c = color
    if c is None and body._color is not None:
        c = body._color[:3]
    kwargs = {"color": c} if c else {}
    look_from, look_up = VIEWS["iso"]
    img = render_view(shape, look_from, look_up, size=(600, 500), **kwargs)
    path = os.path.join(OUTPUT, f"{name}.png")
    img.save(path)
    print(f"  {name}.png")


# ───────────────────────────────────────────────
# Example 1: Simple Box
# ───────────────────────────────────────────────
print("1. Simple Box")
box = Box(60, 40, 20, color="steel")
render_iso(box, "ex01_box")

# ───────────────────────────────────────────────
# Example 2: Cylinder
# ───────────────────────────────────────────────
print("2. Cylinder")
cyl = Cylinder(30, 50, color="blue")
render_iso(cyl, "ex02_cylinder")

# ───────────────────────────────────────────────
# Example 3: Sphere
# ───────────────────────────────────────────────
print("3. Sphere")
ball = Sphere(40, color="red")
render_iso(ball, "ex03_sphere")

# ───────────────────────────────────────────────
# Example 4: Plate with Hole
# ───────────────────────────────────────────────
print("4. Plate with Hole")
plate = Box(80, 50, 10, color="steel")
hole = extrude(Circle(20).place_on(plate.top), through=True)
plate = plate - hole
render_iso(plate, "ex04_plate_hole")

# ───────────────────────────────────────────────
# Example 5: Box with Boss
# ───────────────────────────────────────────────
print("5. Box with Boss")
base = Box(80, 60, 10, color="steel")
boss = extrude(Rect(30, 30).place_on(base.top), amount=20)
base = base + boss
render_iso(base, "ex05_box_boss")

# ───────────────────────────────────────────────
# Example 6: Filleted Edges
# ───────────────────────────────────────────────
print("6. Filleted Edges")
box = Box(50, 50, 30, color="silver")
box = fillet(box.top.edges, radius=8)
render_iso(box, "ex06_fillet")

# ───────────────────────────────────────────────
# Example 7: Chamfered Edges
# ───────────────────────────────────────────────
print("7. Chamfered Edges")
box = Box(50, 50, 30, color="silver")
box = chamfer(box.top.edges, size=6)
render_iso(box, "ex07_chamfer")

# ───────────────────────────────────────────────
# Example 8: Boolean Subtraction
# ───────────────────────────────────────────────
print("8. Boolean Subtraction")
box = Box(50, 50, 50, color="steel")
cyl = Cylinder(30, 60)
result = box - cyl
render_iso(result, "ex08_subtract")

# ───────────────────────────────────────────────
# Example 9: Boolean Intersection
# ───────────────────────────────────────────────
print("9. Boolean Intersection")
box = Box(40, 40, 40, color="blue")
ball = Sphere(50)
result = box & ball
render_iso(result, "ex09_intersect")

# ───────────────────────────────────────────────
# Example 10: Multiple Holes in a Row
# ───────────────────────────────────────────────
print("10. Multiple Holes")
plate = Box(100, 40, 10, color="steel")
for dx in [-30, -15, 0, 15, 30]:
    pos = plate.top.center.offset(dx=dx)
    hole = extrude(Circle(8).place_on(plate.top, at=pos), through=True)
    plate = plate - hole
render_iso(plate, "ex10_multi_holes")

# ───────────────────────────────────────────────
# Example 11: Corner Holes with Inset
# ───────────────────────────────────────────────
print("11. Corner Holes")
plate = Box(80, 60, 8, color="silver")
for corner in plate.top.corners:
    pos = corner.inset(dx=8, dy=8)
    hole = extrude(Circle(5).place_on(plate.top, at=pos), through=True)
    plate = plate - hole
render_iso(plate, "ex11_corner_holes")

# ───────────────────────────────────────────────
# Example 12: Stacked Boxes (Union Chain)
# ───────────────────────────────────────────────
print("12. Stacked Boxes")
base = Box(60, 60, 10, color="steel")
mid = extrude(Rect(40, 40).place_on(base.top), amount=15)
base = base + mid
top = extrude(Rect(20, 20).place_on(base.top), amount=20)
base = base + top
render_iso(base, "ex12_stacked")

# ───────────────────────────────────────────────
# Example 13: Boss with Through Hole
# ───────────────────────────────────────────────
print("13. Boss with Through Hole")
plate = Box(100, 60, 10, color="steel")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)
plate = plate + boss
hole = extrude(Circle(12).place_on(plate.top), through=True)
plate = plate - hole
render_iso(plate, "ex13_boss_hole")

# ───────────────────────────────────────────────
# Example 14: Filleted Boss
# ───────────────────────────────────────────────
print("14. Filleted Boss")
plate = Box(100, 60, 10, color="steel")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)
plate = plate + boss
plate = fillet(plate.top.edges, radius=4)
render_iso(plate, "ex14_filleted_boss")

# ───────────────────────────────────────────────
# Example 15: Mounting Plate (full example)
# ───────────────────────────────────────────────
print("15. Mounting Plate")
plate = Box(100, 60, 10, color="steel")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)
plate = plate + boss
hole = extrude(Rect(10, 10).place_on(plate.top), through=True)
plate = plate - hole
plate = fillet(plate.top.edges, radius=3)
for corner in plate.bottom.corners:
    pos = corner.inset(dx=8, dy=8)
    h = extrude(Circle(5).place_on(plate.bottom, at=pos), through=True)
    plate = plate - h
render_iso(plate, "ex15_mounting_plate")

# ───────────────────────────────────────────────
# Example 16: Offset Holes on Face
# ───────────────────────────────────────────────
print("16. Offset Holes on Face")
plate = Box(80, 80, 10, color="silver")
for dx in [-20, 20]:
    for dy in [-20, 20]:
        pos = plate.top.center.offset(dx=dx, dy=dy)
        hole = extrude(Circle(8).place_on(plate.top, at=pos), through=True)
        plate = plate - hole
render_iso(plate, "ex16_offset_holes")

# ───────────────────────────────────────────────
# Example 17: Cylinder with Flat Cut
# ───────────────────────────────────────────────
print("17. Cylinder with Flat Cut")
cyl = Cylinder(40, 50, color="steel")
cut_sketch = Rect(50, 60).place_at(origin=(0, 15, 0), normal=(0, 1, 0))
cut_body = extrude(cut_sketch, amount=30)
result = cyl - cut_body
render_iso(result, "ex17_cyl_flat")

# ───────────────────────────────────────────────
# Example 18: Dice (Box with Sphere Cuts)
# ───────────────────────────────────────────────
print("18. Dice")
dice = Box(30, 30, 30, color="white")
dice = fillet(dice.top.edges, radius=3)
dice = fillet(dice.bottom.edges, radius=3)
render_iso(dice, "ex18_dice")

print(f"\nDone! {len(os.listdir(OUTPUT))} images generated in {OUTPUT}/")
