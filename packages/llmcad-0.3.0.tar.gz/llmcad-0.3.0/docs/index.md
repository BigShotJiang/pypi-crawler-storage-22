<p align="center">
  <a href="https://llmcad.org"><img src="img/logo.png" alt="llmcad" width="400"></a>
</p>
<p align="center">
  <em>A minimal, LLM-friendly CAD library in Python.</em>
</p>
<p align="center">
<a href="https://pypi.org/project/llmcad" target="_blank">
    <img src="https://img.shields.io/pypi/v/llmcad?color=blue&label=PyPI" alt="PyPI version">
</a>
<a href="https://pypi.org/project/llmcad" target="_blank">
    <img src="https://img.shields.io/pypi/pyversions/llmcad" alt="Python versions">
</a>
<a href="https://github.com/llmcad/llmcad/blob/main/LICENSE" target="_blank">
    <img src="https://img.shields.io/github/license/llmcad/llmcad" alt="License">
</a>
</p>

---

**Documentation**: <a href="https://llmcad.org" target="_blank">https://llmcad.org</a>

**Source Code**: <a href="https://github.com/llmcad/llmcad" target="_blank">https://github.com/llmcad/llmcad</a>

---

## What is llmcad?

llmcad is a Python CAD library designed from the ground up to be **LLM-friendly**, by abstracting 3D spatial reasoning (e.g. absolute coordinate positioning), which LLMs typically struggle with.

It wraps [OpenCASCADE](https://dev.opencascade.org/) (via [cadquery-ocp](https://pypi.org/project/cadquery-ocp/)) with a minimal, explicit API that makes 3D modeling predictable and debuggable for AI agents.

### Key features

- **Minimal API** --- ~28 core concepts. Shapes, sketches, operations, booleans, assemblies --- nothing more.
- **Named faces and edges** --- Every face and edge has a semantic name (`top`, `front`, `left_edge`, ...), so LLMs can reference geometry unambiguously.
- **Face-local coordinate systems** --- Each face carries its own 2D frame. Positioning on faces uses intuitive local offsets --- no global coordinate math.
- **Visual debugging** --- Built-in multi-view snapshots, face coloring, and edge visualization for LLM feedback loops.
- **Immutable operations** --- Boolean ops return new bodies. No mutation, no surprises.

## Quick example

```python
from llmcad import Box, Rect, extrude, fillet, snapshot

# Create a base plate
plate = Box(100, 60, 10, name="plate")

# Add a boss on the top face
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20, name="boss")
plate = plate + boss

# Cut a hole through the boss
hole = extrude(Rect(10, 10).place_on(plate.top), through=True)
plate = plate - hole

# Fillet the top edges
plate = fillet(plate.top.edges, radius=3)

# Render a multi-view snapshot
snapshot(plate, "plate")
```

## Why llmcad?

Traditional CAD libraries require absolute 3D coordinates, complex rotation matrices, and deep understanding of spatial relationships. LLMs struggle with these. llmcad solves this by:

1. **Face-relative positioning** --- "place a hole on `plate.top` offset 10mm to the right" instead of computing `(x=10, y=0, z=50)`.
2. **Named geometry** --- Reference faces and edges by name (`top`, `front`, `wall`) instead of by index or coordinate.
3. **Visual feedback** --- `snapshot()` renders multi-view PNGs that LLMs can inspect to verify their work.
4. **Simple mental model** --- Create shapes, combine with booleans (`+`, `-`, `&`), modify with operations. That's it.

## License

This project is licensed under the terms of the MIT license.
