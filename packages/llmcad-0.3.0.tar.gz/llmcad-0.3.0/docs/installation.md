# Installation

## Requirements

- Python 3.10+
- A working C++ compiler is **not** required --- llmcad uses pre-built OpenCASCADE bindings.

## Install with pip

```bash
pip install llmcad
```

This installs llmcad and its dependencies:

| Package | Purpose |
|---------|---------|
| `cadquery-ocp` | OpenCASCADE (OCCT) Python bindings |
| `numpy` | Numeric operations |
| `Pillow` | Image handling for snapshots |
| `vtk` | Offscreen rendering for `snapshot()` |

## Install with conda

If you're using conda/miniconda:

```bash
pip install llmcad
```

!!! note
    Even with conda, `pip install` is the recommended method. The `cadquery-ocp` dependency provides pre-built wheels for all major platforms.

## Verify installation

```python
import llmcad
print(llmcad.__version__)
```

```python
from llmcad import Box, snapshot
box = Box(10, 20, 30)
snapshot(box, "test_box")
# Should create test_box.png in the current directory
```

## Development install

To install from source for development:

```bash
git clone https://github.com/llmcad/llmcad.git
cd llmcad
pip install -e ".[docs]"
```

### Building the docs

```bash
pip install mkdocs-material
mkdocs serve
```

Then open `http://localhost:8000` in your browser.
