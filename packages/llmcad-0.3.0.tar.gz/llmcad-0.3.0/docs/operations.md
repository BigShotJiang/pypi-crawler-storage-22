# Operations

Operations transform sketches into 3D geometry, modify existing bodies, or reshape edges.

## extrude

```python
extrude(
    sketch: PlacedSketch | SketchPrimitive,
    amount: float = None,
    through: bool = False,
    to: FaceRef = None,
    name: str = "",
) -> Body
```

Push a 2D sketch into a 3D solid along the face normal.

| Parameter | Description |
|-----------|-------------|
| `sketch` | A placed sketch (from `.place_on()` or `.place_at()`) |
| `amount` | Extrusion distance in mm. Positive = outward from face, negative = inward |
| `through` | If `True`, extrude far enough to cut through any body (uses 1000mm) |
| `to` | Extrude until reaching this face |
| `name` | Name for the resulting body |

!!! tip "Extrusion direction"
    The extrusion direction is always along the face normal. When placed on `plate.top`, a positive `amount` goes upward (+Z). When placed on `plate.front`, it goes outward (-Y).

### Basic extrusion

```python
from llmcad import Box, Rect, extrude

plate = Box(100, 60, 10)

# Extrude a boss 20mm upward from the top face
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)
plate = plate + boss
```

### Through extrusion

```python
# Cut a hole all the way through
hole = extrude(Circle(10).place_on(plate.top), through=True)
plate = plate - hole
```

### Extrude to a face

```python
# Extrude from bottom up to the top face
boss = extrude(Rect(20, 20).place_on(plate.bottom), to=plate.top)
```

### Named extrusions

When you name an extrusion, the end cap face gets special naming:

```python
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20, name="boss")
plate = plate + boss

# The end cap is accessible:
plate.faces["_end"]
```

### Automatic face naming

After extrusion, faces are automatically named:

- `_start` --- the face at the extrusion origin
- `_end` --- the face at the extrusion end
- `wall` --- cylindrical face (for circular extrusions only)
- Standard faces (`top`, `bottom`, `front`, `back`, `left`, `right`) are assigned based on face normals

## revolve

```python
revolve(
    sketch: PlacedSketch | SketchPrimitive | Sketch,
    axis = None,
    angle: float = 360,
    name: str = "",
) -> Body
```

Revolve a 2D sketch around an axis to create a solid of revolution.

| Parameter | Description |
|-----------|-------------|
| `sketch` | A sketch (placed or primitive) |
| `axis` | Axis of rotation (`gp_Ax1`, or `body.center_axis`). Default: Z axis |
| `angle` | Revolution angle in **degrees** (default 360 for full revolution) |
| `name` | Name for the resulting body |

```python
from llmcad import Rect, revolve

# Create a donut shape by revolving a rectangle around Z axis
profile = Rect(5, 10).place_at(origin=(20, 0, 0), normal=(0, 1, 0))
ring = revolve(profile, angle=360)
```

```python
# Partial revolution (180 degrees)
half = revolve(Rect(10, 20).place_at(origin=(30, 0, 0), normal=(0, 1, 0)), angle=180)
```

---

## loft

```python
loft(
    sketches: list[SketchPrimitive | PlacedSketch | Sketch],
    heights: list[float],
    name: str = "",
) -> Body
```

Loft between multiple sketches at specified Z-heights to create a smooth transition.

| Parameter | Description |
|-----------|-------------|
| `sketches` | List of 2D sketches to loft between |
| `heights` | Z-height for each sketch (must match length of `sketches`) |
| `name` | Name for the resulting body |

```python
from llmcad import Circle, Rect, loft

# Transition from circle at bottom to rectangle at top
body = loft([Circle(40), Rect(30, 30)], heights=[0, 50])
```

Named faces: `top` (highest Z), `bottom` (lowest Z).

---

## sweep

```python
sweep(
    path: Sketch | PlacedSketch,
    cross_section: PlacedSketch | SketchPrimitive | Sketch = None,
    name: str = "",
) -> Body
```

Sweep a cross-section along a path to create a solid.

| Parameter | Description |
|-----------|-------------|
| `path` | A Sketch defining the sweep path (wire) |
| `cross_section` | The profile to sweep along the path |
| `name` | Name for the resulting body |

```python
from llmcad import Sketch, Circle, sweep

# Create a curved pipe
path = Sketch()
path.start(0, 0)
path.line_to(50, 0)
path.arc_to(80, 30, radius=30)
path.line_to(80, 80)

pipe = sweep(path, cross_section=Circle(10))
```

---

## shell

```python
shell(
    body: Body,
    thickness: float,
    open: list[FaceRef] = None,
    name: str = "",
) -> Body
```

Hollow out a solid body, leaving walls of the specified thickness.

| Parameter | Description |
|-----------|-------------|
| `body` | The body to hollow |
| `thickness` | Wall thickness in mm |
| `open` | Faces to remove (leave as openings) |
| `name` | Optional name |

!!! warning "Shell before features"
    Apply `shell()` **before** cutting holes or adding detailed features. Shelling a body that already has holes can produce errors.

```python
from llmcad import Box, shell

box = Box(80, 60, 40)
enc = shell(box, thickness=2, open=[box.top])
# enc is now an open-top box with 2mm walls
```

After shelling, faces gain `.inner` and `.outer` variants:

```python
enc.front.inner   # inner wall of the front face
enc.front.outer   # outer wall (same as enc.front)
```

---

## split

```python
split(
    body: Body,
    plane = None,
    name: str = "",
) -> Body
```

Split a body with a plane, keeping the half on the positive side of the plane normal.

| Parameter | Description |
|-----------|-------------|
| `body` | The body to split |
| `plane` | A `gp_Pln` plane. Default: XZ plane (splits front/back) |
| `name` | Optional name |

```python
from llmcad import Sphere, split

sphere = Sphere(50)
half = split(sphere)  # keeps the positive-Y half
```

---

## mirror

```python
mirror(
    body: Body,
    plane = None,
    name: str = "",
) -> Body
```

Mirror a body about a plane.

| Parameter | Description |
|-----------|-------------|
| `body` | The body to mirror |
| `plane` | Mirror plane (`gp_Ax2`, `gp_Pln`). Default: YZ plane (mirrors across X) |
| `name` | Optional name |

```python
from llmcad import Box, mirror

box = Box(40, 30, 20)
mirrored = mirror(box)  # mirrored across YZ plane
result = box + mirrored  # symmetric shape
```

---

## fillet

```python
fillet(
    edges,
    radius: float,
    name: str = "",
) -> Body
```

Round edges with a circular cross-section.

| Parameter | Description |
|-----------|-------------|
| `edges` | `EdgeRef`, list of `EdgeRef`, or edge collection from `face.edges` |
| `radius` | Fillet radius in mm |
| `name` | Optional name for the resulting body |

```python
from llmcad import Box, fillet

box = Box(50, 50, 50)

# Fillet all edges of the top face
box = fillet(box.top.edges, radius=5)

# Fillet a single edge
box = fillet(box.top.left_edge, radius=3)

# Fillet specific edges
edges = [box.top.left_edge, box.top.right_edge]
box = fillet(edges, radius=2)
```

!!! note "Parent body"
    `fillet()` automatically finds the parent body from the edge references. The edges must belong to the same body.

## chamfer

```python
chamfer(
    edges,
    size: float,
    name: str = "",
) -> Body
```

Bevel edges with a flat cut.

| Parameter | Description |
|-----------|-------------|
| `edges` | `EdgeRef`, list of `EdgeRef`, or edge collection |
| `size` | Chamfer size in mm |
| `name` | Optional name for the resulting body |

```python
from llmcad import Box, chamfer

box = Box(50, 50, 50)

# Chamfer all top edges
box = chamfer(box.top.edges, size=3)
```

## Face name preservation

After `fillet()` and `chamfer()`, face names from the original body are automatically transferred to the new body. This means you can keep chaining operations:

```python
plate = Box(100, 60, 10, name="plate")
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20)
plate = plate + boss
plate = fillet(plate.top.edges, radius=3)
plate = chamfer(plate.bottom.edges, size=2)

# plate.top, plate.bottom, etc. still work
```
