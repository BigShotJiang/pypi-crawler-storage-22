# Shapes

Shapes are the starting point of every model. llmcad provides three solid primitives, all centered at the origin.

## Box

```python
Box(width: float, length: float, height: float,
    name: str = "", color: str | tuple = None) -> Body
```

Creates a rectangular box centered at the origin.

| Parameter | Description |
|-----------|-------------|
| `width` | Extent along X axis |
| `length` | Extent along Y axis |
| `height` | Extent along Z axis |
| `name` | Optional name for the body |
| `color` | Optional color (name or RGB tuple) |

**Named faces:** `top`, `bottom`, `front`, `back`, `left`, `right`

```python
from llmcad import Box

plate = Box(100, 60, 10, name="plate")

print(plate.top)     # FaceRef('top', center=(0.0, 0.0, 5.0))
print(plate.front)   # FaceRef('front', center=(0.0, -30.0, 0.0))
print(plate.right)   # FaceRef('right', center=(50.0, 0.0, 0.0))
```

### Face layout

```
        top (+Z)
        ┌──────────┐
       /          /|
      /  back    / |
     /  (+Y)   /  | right (+X)
    ┌──────────┐   |
    |          |   |
    |  front   |  /
    |  (-Y)    | /
    └──────────┘
      bottom (-Z)
```

The local coordinate axes for each face:

| Face | x_dir | y_dir | Normal |
|------|-------|-------|--------|
| top | +X | +Y | +Z |
| bottom | +X | +Y | -Z |
| front | +X | +Z | -Y |
| back | -X | +Z | +Y |
| right | +Y | +Z | +X |
| left | -Y | +Z | -X |

## Cylinder

```python
Cylinder(diameter: float, height: float,
         name: str = "", color: str | tuple = None) -> Body
```

Creates a cylinder centered at the origin, axis along Z.

| Parameter | Description |
|-----------|-------------|
| `diameter` | Cylinder diameter (**not** radius) |
| `height` | Extent along Z axis |
| `name` | Optional name |
| `color` | Optional color |

!!! warning "Diameter, not radius"
    `Cylinder(10, 20)` creates a cylinder with **diameter 10** (radius 5) and height 20. This matches how engineers typically specify parts.

**Named faces:** `top`, `bottom`, `wall`

```python
from llmcad import Cylinder

cyl = Cylinder(20, 50, name="pin")

print(cyl.top)   # FaceRef('top', center=(0.0, 0.0, 25.0))
print(cyl.wall)  # FaceRef('wall', center=(0.0, 0.0, 0.0))
```

## Sphere

```python
Sphere(diameter: float,
       name: str = "", color: str | tuple = None) -> Body
```

Creates a sphere centered at the origin.

| Parameter | Description |
|-----------|-------------|
| `diameter` | Sphere diameter (**not** radius) |
| `name` | Optional name |
| `color` | Optional color |

**Named faces:** `surface`

```python
from llmcad import Sphere

ball = Sphere(30, name="ball")
print(ball.faces["surface"])
```

## Colors

All shapes accept an optional `color` parameter:

```python
plate = Box(100, 60, 10, color="steel")
pin = Cylinder(8, 20, color=(0.8, 0.2, 0.2))  # RGB tuple, 0-1
```

You can also set color after creation:

```python
plate.color = "red"
```

Available named colors: `red`, `green`, `blue`, `yellow`, `orange`, `white`, `black`, `gray`/`grey`, `steel`, `silver`, `cyan`, `magenta`, `purple`, `pink`, `brown`.
