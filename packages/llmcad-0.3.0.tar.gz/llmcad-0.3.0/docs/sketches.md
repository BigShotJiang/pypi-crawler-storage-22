# Sketches

Sketches are 2D shapes that get extruded into 3D solids. They start on the XY plane and are then placed onto a face.

## Rect

```python
Rect(width: float, height: float) -> SketchPrimitive
```

Creates a rectangular sketch centered at the origin on the XY plane.

| Parameter | Description |
|-----------|-------------|
| `width` | Width along X |
| `height` | Height along Y |

```python
from llmcad import Rect, extrude, Box

plate = Box(100, 60, 10)

# A 30x20mm rectangle on the top face
boss = extrude(Rect(30, 20).place_on(plate.top), amount=15)
```

## Circle

```python
Circle(diameter: float) -> SketchPrimitive
```

Creates a circular sketch centered at the origin on the XY plane.

| Parameter | Description |
|-----------|-------------|
| `diameter` | Circle diameter (**not** radius) |

!!! warning "Diameter, not radius"
    `Circle(10)` creates a circle with **diameter 10** (radius 5).

```python
from llmcad import Circle, extrude, Box

plate = Box(100, 60, 10)

# A 10mm diameter hole through the plate
hole = extrude(Circle(10).place_on(plate.top), through=True)
plate = plate - hole
```

## Placing sketches

Sketches must be placed in 3D space before they can be extruded. There are two ways to do this.

### place_on(face)

The most common method. Places the sketch on a face, centered by default:

```python
sketch.place_on(face_ref)                    # at face center
sketch.place_on(face_ref, at=position)       # at a specific position on the face
```

The sketch is automatically transformed from the XY plane to the face's local coordinate system. The extrusion direction is the face's outward normal.

```python
plate = Box(100, 60, 10)

# Centered on top
Rect(30, 30).place_on(plate.top)

# Offset 15mm to the right
pos = plate.top.center.offset(dx=15)
Circle(8).place_on(plate.top, at=pos)

# At a corner, inset 10mm
pos = plate.top.corners.TR.inset(dx=10, dy=10)
Circle(5).place_on(plate.top, at=pos)
```

### place_at(origin, x_dir, normal)

For placing sketches at arbitrary positions and orientations in 3D space:

```python
sketch.place_at(
    origin=(50, 0, 0),         # 3D position
    x_dir=(0, 1, 0),           # local X direction (optional)
    normal=(1, 0, 0),          # extrusion direction (optional, default +Z)
)
```

```python
# A circle placed on the YZ plane at x=50
placed = Circle(10).place_at(origin=(50, 0, 0), normal=(1, 0, 0))
boss = extrude(placed, amount=20)
```

## Ellipse

```python
Ellipse(width: float, height: float) -> SketchPrimitive
```

Creates an elliptical sketch centered at the origin on the XY plane.

| Parameter | Description |
|-----------|-------------|
| `width` | Full width along X |
| `height` | Full height along Y |

```python
from llmcad import Ellipse, extrude, Box

plate = Box(100, 60, 10)

# An elliptical boss
boss = extrude(Ellipse(30, 20).place_on(plate.top), amount=10)
plate = plate + boss
```

## Polygon

```python
Polygon(points: list[tuple]) -> SketchPrimitive
```

Creates a polygonal sketch from a list of `(x, y)` vertices on the XY plane. The polygon is closed automatically.

| Parameter | Description |
|-----------|-------------|
| `points` | List of `(x, y)` tuples (minimum 3) |

```python
from llmcad import Polygon, extrude

# Triangular plate
tri = Polygon([(0, 0), (40, 0), (20, 30)])
plate = extrude(tri, amount=5)
```

## Text

```python
Text(txt: str, size: float, font: str = "Arial") -> SketchPrimitive
```

Renders text into a sketch shape. Each glyph becomes a face that can be extruded.

| Parameter | Description |
|-----------|-------------|
| `txt` | The text string |
| `size` | Font size in model units |
| `font` | System font name (default `"Arial"`) |

```python
from llmcad import Text, extrude, Box

plate = Box(100, 40, 5)

# Embossed text on top
label = extrude(Text("HELLO", 12).place_on(plate.top), amount=2)
plate = plate + label
```

## Sketch (turtle-style)

```python
Sketch() -> Sketch
```

A turtle-style sketch builder for complex 2D profiles. Build a wire segment by segment, then close it into a face. Named segments become named faces after extrusion (tag inheritance).

**Methods:**

| Method | Description |
|--------|-------------|
| `start(x, y)` | Set the starting point |
| `line_to(x, y, name=None)` | Draw a line to `(x, y)` |
| `arc_to(x, y, radius=None, center=None, name=None)` | Draw an arc to `(x, y)` |
| `close(name=None)` | Close the sketch back to the start |

```python
from llmcad import Sketch, extrude

# L-shaped bracket profile
s = Sketch()
s.start(0, 0)
s.line_to(80, 0, name="bottom")
s.line_to(80, 5, name="right")
s.line_to(5, 5)
s.line_to(5, 60, name="inner")
s.line_to(0, 60)
s.close(name="left")

bracket = extrude(s, amount=20)
```

The Sketch class supports `.place_on()` and `.place_at()` just like other sketch primitives:

```python
s = Sketch()
s.start(-10, -10)
s.line_to(10, -10)
s.arc_to(10, 10, radius=5)
s.close()

# Place on a face and extrude
placed = s.place_on(plate.top, at=plate.top.center)
boss = extrude(placed, amount=15)
```

## Placing sketches

Sketches must be placed in 3D space before they can be extruded. There are two ways to do this.

### place_on(face)

The most common method. Places the sketch on a face, centered by default:

```python
sketch.place_on(face_ref)                    # at face center
sketch.place_on(face_ref, at=position)       # at a specific position on the face
```

The sketch is automatically transformed from the XY plane to the face's local coordinate system. The extrusion direction is the face's outward normal.

```python
plate = Box(100, 60, 10)

# Centered on top
Rect(30, 30).place_on(plate.top)

# Offset 15mm to the right
pos = plate.top.center.offset(dx=15)
Circle(8).place_on(plate.top, at=pos)

# At a corner, inset 10mm
pos = plate.top.corners.TR.inset(dx=10, dy=10)
Circle(5).place_on(plate.top, at=pos)
```

### place_at(origin, x_dir, normal)

For placing sketches at arbitrary positions and orientations in 3D space:

```python
sketch.place_at(
    origin=(50, 0, 0),         # 3D position
    x_dir=(0, 1, 0),           # local X direction (optional)
    normal=(1, 0, 0),          # extrusion direction (optional, default +Z)
)
```

```python
# A circle placed on the YZ plane at x=50
placed = Circle(10).place_at(origin=(50, 0, 0), normal=(1, 0, 0))
boss = extrude(placed, amount=20)
```

## PlacedSketch

After calling `.place_on()` or `.place_at()`, you get a `PlacedSketch` object. This is what `extrude()`, `revolve()`, and other operations accept:

```python
placed = Rect(30, 30).place_on(plate.top)  # PlacedSketch
boss = extrude(placed, amount=20)
```

You can also create a PlacedSketch from a raw sketch (on the default XY plane):

```python
placed = Rect(30, 30).to_placed_sketch()  # on XY plane at origin
boss = extrude(placed, amount=20)          # extrudes in +Z
```
