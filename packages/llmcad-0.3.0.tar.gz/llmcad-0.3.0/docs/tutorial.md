# Tutorial

This tutorial walks through building a mounting plate step by step, introducing each llmcad concept along the way.

## What we'll build

A rectangular mounting plate with:

- A raised boss on top
- A through-hole in the boss
- Filleted edges
- Mounting holes in the corners

## Step 1: Create the base plate

```python
from llmcad import Box, snapshot

plate = Box(100, 60, 10, name="plate")
snapshot(plate, "step1_plate")
```

`Box(width, length, height)` creates a rectangular solid centered at the origin. The body automatically gets six named faces: `top`, `bottom`, `front`, `back`, `left`, `right`.

```python
print(plate.top)     # FaceRef('top', center=(0.0, 0.0, 5.0))
print(plate.bottom)  # FaceRef('bottom', center=(0.0, 0.0, -5.0))
```

## Step 2: Add a boss

```python
from llmcad import Rect, extrude

boss = extrude(
    Rect(30, 30).place_on(plate.top),
    amount=20,
    name="boss",
)
plate = plate + boss
snapshot(plate, "step2_boss")
```

Let's break this down:

1. `Rect(30, 30)` --- creates a 30x30mm square sketch on the XY plane
2. `.place_on(plate.top)` --- transforms the sketch onto the top face, centered
3. `extrude(..., amount=20)` --- pushes the sketch 20mm upward (along the face normal)
4. `plate + boss` --- boolean union, creating a new body with both shapes merged

After the union, face names from both bodies are preserved.

## Step 3: Cut a hole

```python
hole = extrude(
    Rect(10, 10).place_on(plate.top),
    through=True,
)
plate = plate - hole
snapshot(plate, "step3_hole")
```

- `through=True` extrudes far enough to cut through the entire body
- `plate - hole` subtracts the hole from the plate

## Step 4: Fillet the top edges

```python
from llmcad import fillet

plate = fillet(plate.top.edges, radius=3)
snapshot(plate, "step4_fillet")
```

`plate.top.edges` returns all edges of the top face. `fillet()` rounds them with a 3mm radius.

## Step 5: Add mounting holes

Now we'll use **face-local positioning** to place holes at the corners.

```python
from llmcad import Circle

for corner in plate.bottom.corners:
    pos = corner.inset(dx=8, dy=8)
    hole = extrude(
        Circle(5).place_on(plate.bottom, at=pos),
        through=True,
    )
    plate = plate - hole

snapshot(plate, "step5_mounting_holes")
```

Key concepts here:

- `plate.bottom.corners` gives you `TL`, `TR`, `BL`, `BR` corner positions
- `.inset(dx=8, dy=8)` moves 8mm inward from each corner (toward the face center --- the direction is automatic)
- `Circle(5)` is a 5mm **diameter** circle (not radius)
- `.place_on(plate.bottom, at=pos)` places the sketch at a specific position on the face

## Step 6: Set a color

```python
plate.color = "steel"
snapshot(plate, "step6_final")
```

Colors can be names (`"red"`, `"steel"`, `"blue"`, ...) or RGB tuples (`(0.5, 0.5, 0.5)`).

## Complete code

```python
from llmcad import Box, Cylinder, Rect, Circle, extrude, fillet, snapshot

# Base plate
plate = Box(100, 60, 10, name="plate")

# Boss
boss = extrude(Rect(30, 30).place_on(plate.top), amount=20, name="boss")
plate = plate + boss

# Through-hole
hole = extrude(Rect(10, 10).place_on(plate.top), through=True)
plate = plate - hole

# Fillet top edges
plate = fillet(plate.top.edges, radius=3)

# Mounting holes
for corner in plate.bottom.corners:
    pos = corner.inset(dx=8, dy=8)
    hole = extrude(Circle(5).place_on(plate.bottom, at=pos), through=True)
    plate = plate - hole

# Color and render
plate.color = "steel"
snapshot(plate, "mounting_plate")
```

## Next steps

- [Shapes](shapes.md) --- Box, Cylinder, Sphere reference
- [Sketches](sketches.md) --- Rect, Circle, and placement
- [Operations](operations.md) --- extrude, fillet, chamfer
- [Faces & Edges](faces-and-edges.md) --- face naming, edge selection
- [Positioning](positioning.md) --- offsets, corners, inset
