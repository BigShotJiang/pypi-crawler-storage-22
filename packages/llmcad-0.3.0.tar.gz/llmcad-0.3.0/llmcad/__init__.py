"""llmcad - A minimal, LLM-friendly CAD library in Python.

Core API:
- Shapes: Box, Cylinder, Sphere
- Sketches: Rect, Circle, Ellipse, Polygon, Text, Sketch
- Operations: extrude, revolve, loft, sweep, fillet, chamfer, shell, split, mirror
- Assembly: place, Assembly, RevoluteJoint
- Booleans: body + body, body - body, body & body
- Debug: snapshot, show, show_faces, show_edges, measure
- Export: export_step, export_stl, export_glb
"""

__version__ = "0.3.0"

# Shapes
from .shapes import Box, Cylinder, Sphere

# Sketches
from .sketch import Rect, Circle, Ellipse, Polygon, Text, Sketch

# Operations
from .ops import extrude, revolve, loft, sweep, fillet, chamfer, shell, split, mirror

# Assembly
from .assembly import place, Assembly, RevoluteJoint

# Debug
from .debug import snapshot, show, show_faces, show_edges, measure

# Export
from .export import export_step, export_stl, export_glb

# Core types (for type hints / advanced usage)
from .body import Body
from .face import FaceRef
from .edge import EdgeRef
from .position import Position

__all__ = [
    # Shapes
    "Box", "Cylinder", "Sphere",
    # Sketches
    "Rect", "Circle", "Ellipse", "Polygon", "Text", "Sketch",
    # Operations
    "extrude", "revolve", "loft", "sweep", "fillet", "chamfer",
    "shell", "split", "mirror",
    # Assembly
    "place", "Assembly", "RevoluteJoint",
    # Debug
    "snapshot", "show", "show_faces", "show_edges", "measure",
    # Export
    "export_step", "export_stl", "export_glb",
    # Types
    "Body", "FaceRef", "EdgeRef", "Position",
]
