"""Internal face naming heuristics for primitives and after boolean operations."""

from __future__ import annotations

from OCP.TopoDS import TopoDS_Shape
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder, GeomAbs_Sphere

from ._vec import Vec3
from .face import FaceRef, get_standard_axes
from ._ocp_helpers import iter_faces, face_normal, face_center, face_geom_type


def name_box_faces(shape: TopoDS_Shape, body) -> dict[str, FaceRef]:
    """Identify and name the 6 faces of a Box by their normals."""
    result = {}
    for face in iter_faces(shape):
        n = face_normal(face)
        name = _classify_planar_normal(n)
        if name and name not in result:
            axes = get_standard_axes(name)
            result[name] = FaceRef(face, body, name, x_dir=axes[0], y_dir=axes[1])
    return result


def name_cylinder_faces(shape: TopoDS_Shape, body) -> dict[str, FaceRef]:
    """Identify and name Cylinder faces: top, bottom, wall."""
    result = {}
    for face in iter_faces(shape):
        gt = face_geom_type(face)
        if gt == GeomAbs_Plane:
            n = face_normal(face)
            if n.Z > 0.9:
                axes = get_standard_axes("top")
                result["top"] = FaceRef(face, body, "top", x_dir=axes[0], y_dir=axes[1])
            elif n.Z < -0.9:
                axes = get_standard_axes("bottom")
                result["bottom"] = FaceRef(face, body, "bottom", x_dir=axes[0], y_dir=axes[1])
        elif gt == GeomAbs_Cylinder:
            result["wall"] = FaceRef(face, body, "wall")
    return result


def name_sphere_faces(shape: TopoDS_Shape, body) -> dict[str, FaceRef]:
    """Name the single face of a Sphere."""
    result = {}
    for face in iter_faces(shape):
        gt = face_geom_type(face)
        if gt == GeomAbs_Sphere:
            result["surface"] = FaceRef(face, body, "surface")
    return result


def transfer_face_names(
    old_face_map: dict[str, FaceRef],
    new_shape: TopoDS_Shape,
    new_body,
    tol: float = 0.1,
) -> dict[str, FaceRef]:
    """Transfer face names from an old body to a new body after a boolean operation.

    Strategy:
    1. Try exact geometric matching (center + normal, tight tolerance).
    2. For standard faces (top/bottom/left/right/front/back) that fail exact match,
       use normal-based matching — pick the face with the correct normal that is
       most extreme in the expected direction.
    3. For non-standard faces, try relaxed tolerance.
    """
    new_faces = iter_faces(new_shape)
    used: set[int] = set()
    result: dict[str, FaceRef] = {}

    _STANDARD_FACE_EXTREMES = {
        "top":    (Vec3(0, 0, 1),  "Z", 1),
        "bottom": (Vec3(0, 0, -1), "Z", -1),
        "front":  (Vec3(0, -1, 0), "Y", -1),
        "back":   (Vec3(0, 1, 0),  "Y", 1),
        "right":  (Vec3(1, 0, 0),  "X", 1),
        "left":   (Vec3(-1, 0, 0), "X", -1),
    }

    # Pass 1: tight geometric matching (center + normal)
    for name, old_ref in old_face_map.items():
        old_c = face_center(old_ref._face)
        old_n = face_normal(old_ref._face)

        best_face = None
        best_dist = float("inf")

        for i, new_face in enumerate(new_faces):
            if i in used:
                continue
            new_c = face_center(new_face)
            new_n = face_normal(new_face)

            if old_n.dot(new_n) < 0.95:
                continue

            dist = (old_c - new_c).length
            if dist < best_dist:
                best_dist = dist
                best_face = (i, new_face)

        if best_face is not None and best_dist < tol:
            idx, face = best_face
            used.add(idx)
            result[name] = FaceRef(
                face, new_body, name,
                x_dir=old_ref._x_dir,
                y_dir=old_ref._y_dir,
            )
            result[name]._inner = old_ref._inner
            result[name]._outer = old_ref._outer

    # Pass 2: for standard faces that weren't matched, use normal + extremity
    for name, old_ref in old_face_map.items():
        if name in result:
            continue
        if name not in _STANDARD_FACE_EXTREMES:
            continue

        expected_normal, axis_name, sign = _STANDARD_FACE_EXTREMES[name]
        candidates = []

        for i, new_face in enumerate(new_faces):
            if i in used:
                continue
            new_n = face_normal(new_face)
            if new_n.dot(expected_normal) < 0.9:
                continue
            center = face_center(new_face)
            axis_val = getattr(center, axis_name)
            candidates.append((i, new_face, axis_val))

        if candidates:
            if sign > 0:
                best = max(candidates, key=lambda x: x[2])
            else:
                best = min(candidates, key=lambda x: x[2])
            idx, face, _ = best
            used.add(idx)
            result[name] = FaceRef(
                face, new_body, name,
                x_dir=old_ref._x_dir,
                y_dir=old_ref._y_dir,
            )
            result[name]._inner = old_ref._inner
            result[name]._outer = old_ref._outer

    # Pass 3: for non-standard faces that weren't matched, try relaxed tolerance
    for name, old_ref in old_face_map.items():
        if name in result:
            continue
        if name in _STANDARD_FACE_EXTREMES:
            continue

        old_c = face_center(old_ref._face)
        old_n = face_normal(old_ref._face)

        best_face = None
        best_dist = float("inf")
        relaxed_tol = max(tol * 100, 50.0)

        for i, new_face in enumerate(new_faces):
            if i in used:
                continue
            new_n = face_normal(new_face)
            if old_n.dot(new_n) < 0.9:
                continue
            dist = (old_c - face_center(new_face)).length
            if dist < best_dist:
                best_dist = dist
                best_face = (i, new_face)

        if best_face is not None and best_dist < relaxed_tol:
            idx, face = best_face
            used.add(idx)
            result[name] = FaceRef(
                face, new_body, name,
                x_dir=old_ref._x_dir,
                y_dir=old_ref._y_dir,
            )
            result[name]._inner = old_ref._inner
            result[name]._outer = old_ref._outer

    return result


def _classify_planar_normal(n: Vec3) -> str | None:
    """Classify a face normal to a standard name."""
    threshold = 0.9
    if n.Z > threshold:
        return "top"
    elif n.Z < -threshold:
        return "bottom"
    elif n.Y > threshold:
        return "back"
    elif n.Y < -threshold:
        return "front"
    elif n.X > threshold:
        return "right"
    elif n.X < -threshold:
        return "left"
    return None
