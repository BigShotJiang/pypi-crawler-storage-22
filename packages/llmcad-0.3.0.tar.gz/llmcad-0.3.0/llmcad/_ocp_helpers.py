"""Central OCP import hub and thin helper functions."""

from __future__ import annotations

from OCP.gp import (
    gp_Pnt, gp_Vec, gp_Dir, gp_Ax1, gp_Ax2, gp_Trsf, gp_Pln, gp_Circ, gp_Elips,
)
from OCP.TopoDS import (
    TopoDS, TopoDS_Shape, TopoDS_Face, TopoDS_Edge, TopoDS_Wire,
    TopoDS_Vertex, TopoDS_Solid, TopoDS_Compound, TopoDS_Iterator,
)
from OCP.TopAbs import TopAbs_FACE, TopAbs_EDGE, TopAbs_VERTEX, TopAbs_WIRE, TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer
from OCP.BRep import BRep_Tool, BRep_Builder
from OCP.BRepPrimAPI import (
    BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeSphere,
    BRepPrimAPI_MakePrism, BRepPrimAPI_MakeRevol,
)
from OCP.BRepAlgoAPI import (
    BRepAlgoAPI_Fuse, BRepAlgoAPI_Cut, BRepAlgoAPI_Common,
    BRepAlgoAPI_Splitter,
)
from OCP.BRepOffsetAPI import (
    BRepOffsetAPI_MakeThickSolid, BRepOffsetAPI_ThruSections,
    BRepOffsetAPI_MakePipeShell,
)
from OCP.TopTools import TopTools_ListOfShape
from OCP.BRepBuilderAPI import (
    BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire,
    BRepBuilderAPI_MakeFace, BRepBuilderAPI_Transform,
)
from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet, BRepFilletAPI_MakeChamfer
from OCP.BRepGProp import BRepGProp
from OCP.BRepAdaptor import BRepAdaptor_Surface, BRepAdaptor_Curve
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepBndLib import BRepBndLib
from OCP.GProp import GProp_GProps
from OCP.GeomAbs import (
    GeomAbs_Plane, GeomAbs_Cylinder, GeomAbs_Sphere,
    GeomAbs_Circle, GeomAbs_Line, GeomAbs_BSplineCurve,
)
from OCP.GeomLProp import GeomLProp_SLProps
from OCP.Bnd import Bnd_Box
from OCP.TopLoc import TopLoc_Location
from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
from OCP.TopExp import TopExp
from OCP.gp import gp_Ax3
from OCP.GeomAbs import GeomAbs_JoinType

from ._vec import Vec3


# --- Topology iteration ---

def iter_faces(shape: TopoDS_Shape) -> list[TopoDS_Face]:
    """Iterate all faces of a shape."""
    faces = []
    explorer = TopExp_Explorer(shape, TopAbs_FACE)
    while explorer.More():
        faces.append(TopoDS.Face_s(explorer.Current()))
        explorer.Next()
    return faces


def iter_edges(shape: TopoDS_Shape) -> list[TopoDS_Edge]:
    """Iterate all unique edges of a shape."""
    from OCP.TopTools import TopTools_IndexedMapOfShape
    edge_map = TopTools_IndexedMapOfShape()
    explorer = TopExp_Explorer(shape, TopAbs_EDGE)
    while explorer.More():
        edge_map.Add(explorer.Current())
        explorer.Next()
    return [TopoDS.Edge_s(edge_map.FindKey(i)) for i in range(1, edge_map.Extent() + 1)]


def iter_vertices(shape: TopoDS_Shape) -> list[TopoDS_Vertex]:
    """Iterate all unique vertices of a shape."""
    from OCP.TopTools import TopTools_IndexedMapOfShape
    vert_map = TopTools_IndexedMapOfShape()
    explorer = TopExp_Explorer(shape, TopAbs_VERTEX)
    while explorer.More():
        vert_map.Add(explorer.Current())
        explorer.Next()
    return [TopoDS.Vertex_s(vert_map.FindKey(i)) for i in range(1, vert_map.Extent() + 1)]


def iter_solids(shape: TopoDS_Shape) -> list[TopoDS_Solid]:
    """Iterate all solids in a shape (for compounds)."""
    solids = []
    explorer = TopExp_Explorer(shape, TopAbs_SOLID)
    while explorer.More():
        solids.append(TopoDS.Solid_s(explorer.Current()))
        explorer.Next()
    return solids


# --- Face properties ---

def face_center(face: TopoDS_Face) -> Vec3:
    """Compute the center of mass of a face."""
    props = GProp_GProps()
    BRepGProp.SurfaceProperties_s(face, props)
    pnt = props.CentreOfMass()
    return Vec3(pnt.X(), pnt.Y(), pnt.Z())


def face_normal(face: TopoDS_Face) -> Vec3:
    """Compute the outward normal of a face at its UV midpoint."""
    surf = BRepAdaptor_Surface(face)
    u_min, u_max, v_min, v_max = BRepTools.UVBounds_s(face)
    u_mid = (u_min + u_max) / 2
    v_mid = (v_min + v_max) / 2

    # Use the Surface() handle from BRepAdaptor to get Geom_Surface
    geom_surf = surf.Surface().Surface()
    sl_props = GeomLProp_SLProps(geom_surf, u_mid, v_mid, 1, 1e-6)
    if sl_props.IsNormalDefined():
        n = sl_props.Normal()
        # Check face orientation
        if face.Orientation() == 1:  # TopAbs_REVERSED
            n.Reverse()
        return Vec3(n.X(), n.Y(), n.Z())
    # Fallback: return Z
    return Vec3(0, 0, 1)


def face_area(face: TopoDS_Face) -> float:
    """Compute the surface area of a face."""
    props = GProp_GProps()
    BRepGProp.SurfaceProperties_s(face, props)
    return props.Mass()


def face_geom_type(face: TopoDS_Face):
    """Get the geometric type of a face (GeomAbs_Plane, GeomAbs_Cylinder, etc.)."""
    surf = BRepAdaptor_Surface(face)
    return surf.GetType()


# --- Edge properties ---

def edge_center(edge: TopoDS_Edge) -> Vec3:
    """Compute the center of mass of an edge."""
    props = GProp_GProps()
    BRepGProp.LinearProperties_s(edge, props)
    pnt = props.CentreOfMass()
    return Vec3(pnt.X(), pnt.Y(), pnt.Z())


def edge_length(edge: TopoDS_Edge) -> float:
    """Compute the length of an edge."""
    props = GProp_GProps()
    BRepGProp.LinearProperties_s(edge, props)
    return props.Mass()


def edge_at_parameter(edge: TopoDS_Edge, t: float) -> Vec3:
    """Evaluate a point on an edge at normalized parameter t in [0, 1]."""
    curve = BRepAdaptor_Curve(edge)
    first = curve.FirstParameter()
    last = curve.LastParameter()
    u = first + t * (last - first)
    pnt = curve.Value(u)
    return Vec3(pnt.X(), pnt.Y(), pnt.Z())


def edge_geom_type(edge: TopoDS_Edge):
    """Get the geometric type of an edge."""
    curve = BRepAdaptor_Curve(edge)
    return curve.GetType()


# --- Vertex properties ---

def vertex_point(vertex: TopoDS_Vertex) -> Vec3:
    """Get the 3D point of a vertex."""
    pnt = BRep_Tool.Pnt_s(vertex)
    return Vec3(pnt.X(), pnt.Y(), pnt.Z())


# --- Bounding box ---

def bounding_box(shape: TopoDS_Shape) -> tuple[Vec3, Vec3]:
    """Compute the bounding box of a shape. Returns (min_corner, max_corner)."""
    box = Bnd_Box()
    BRepBndLib.Add_s(shape, box)
    xmin, ymin, zmin, xmax, ymax, zmax = box.Get()
    return Vec3(xmin, ymin, zmin), Vec3(xmax, ymax, zmax)


# --- Transform ---

def move_shape(shape: TopoDS_Shape, trsf: gp_Trsf) -> TopoDS_Shape:
    """Apply a transformation to a shape, returning a new shape."""
    transformer = BRepBuilderAPI_Transform(shape, trsf, True)
    return transformer.Shape()


def make_compound(shapes: list[TopoDS_Shape]) -> TopoDS_Compound:
    """Build a compound from a list of shapes."""
    builder = BRep_Builder()
    compound = TopoDS_Compound()
    builder.MakeCompound(compound)
    for s in shapes:
        builder.Add(compound, s)
    return compound


# --- Tessellation ---

def tessellate_shape(shape: TopoDS_Shape, deflection: float = 0.1):
    """Mesh a shape and return per-face tessellation data.

    Returns list of (face, points, triangles, normals) tuples.
    Points are Vec3, triangles are 0-indexed (i, j, k) tuples.
    """
    BRepMesh_IncrementalMesh(shape, deflection)
    result = []

    for face in iter_faces(shape):
        loc = TopLoc_Location()
        tri = BRep_Tool.Triangulation_s(face, loc)
        if tri is None:
            continue

        trsf = loc.Transformation()
        reversed_face = face.Orientation() == 1  # TopAbs_REVERSED

        # Extract nodes
        points = []
        for i in range(1, tri.NbNodes() + 1):
            p = tri.Node(i)
            p.Transform(trsf)
            points.append(Vec3(p.X(), p.Y(), p.Z()))

        # Extract normals (if available)
        normals = []
        if tri.HasNormals():
            for i in range(1, tri.NbNodes() + 1):
                n = tri.Normal(i)
                n = n.Transformed(trsf)
                if reversed_face:
                    normals.append(Vec3(-n.X(), -n.Y(), -n.Z()))
                else:
                    normals.append(Vec3(n.X(), n.Y(), n.Z()))

        # Extract triangles (convert to 0-indexed)
        triangles = []
        for i in range(1, tri.NbTriangles() + 1):
            t = tri.Triangle(i)
            n1, n2, n3 = t.Get()
            if reversed_face:
                triangles.append((n1 - 1, n3 - 1, n2 - 1))  # flip winding
            else:
                triangles.append((n1 - 1, n2 - 1, n3 - 1))

        result.append((face, points, triangles, normals))

    return result


# --- Edge sampling (for rendering) ---

def sample_edge(edge: TopoDS_Edge, n_points: int = 40) -> list[Vec3]:
    """Sample points along an edge for rendering."""
    curve = BRepAdaptor_Curve(edge)
    first = curve.FirstParameter()
    last = curve.LastParameter()
    points = []
    for i in range(n_points):
        t = first + (last - first) * i / (n_points - 1)
        p = curve.Value(t)
        points.append(Vec3(p.X(), p.Y(), p.Z()))
    return points
