"""Internal: multi-view rendering using VTK offscreen.

Uses VTK for high-quality Phong-shaded rendering with real CAD topology edges.
"""

from __future__ import annotations
import numpy as np
import vtk
from PIL import Image

from ._vec import Vec3
from ._ocp_helpers import (
    iter_faces, iter_edges, face_normal, tessellate_shape,
    sample_edge, bounding_box,
)


# View definitions: name -> (look_from_direction, up_vector)
VIEWS = {
    "front":  ((0, -1, 0),    (0, 0, 1)),
    "back":   ((0, 1, 0),     (0, 0, 1)),
    "right":  ((1, 0, 0),     (0, 0, 1)),
    "left":   ((-1, 0, 0),    (0, 0, 1)),
    "top":    ((0, 0, 1),     (0, 1, 0)),
    "bottom": ((0, 0, -1),    (0, 1, 0)),
    "iso":    ((1, -1, 0.8),  (0, 0, 1)),
}

DEFAULT_COLOR = (0.55, 0.70, 0.85)
EDGE_COLOR = (0.13, 0.13, 0.13)
EDGE_WIDTH = 1.5
EDGE_SAMPLES = 40
BG_BOTTOM = (0.82, 0.82, 0.82)
BG_TOP = (0.95, 0.95, 0.95)


def _color_to_rgb(c) -> tuple[float, float, float]:
    """Extract (r, g, b) from a color tuple."""
    if c is None:
        return DEFAULT_COLOR
    if isinstance(c, tuple):
        return c[:3]
    return DEFAULT_COLOR


def _shape_to_vtk(shape, color: tuple = DEFAULT_COLOR) -> vtk.vtkPolyData:
    """Convert OCP shape to VTK polydata with per-vertex normals and colors."""
    points = vtk.vtkPoints()
    polys = vtk.vtkCellArray()
    normals_arr = vtk.vtkFloatArray()
    normals_arr.SetNumberOfComponents(3)
    normals_arr.SetName("Normals")
    colors_arr = vtk.vtkUnsignedCharArray()
    colors_arr.SetNumberOfComponents(3)
    colors_arr.SetName("Colors")

    r, g, b = int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)
    vertex_offset = 0

    tess_data = tessellate_shape(shape, deflection=0.05)

    for face, face_points, triangles, face_normals in tess_data:
        # Use face-level normal as fallback
        fn = face_normal(face)

        for i, p in enumerate(face_points):
            points.InsertNextPoint(p.X, p.Y, p.Z)
            if face_normals and i < len(face_normals):
                n = face_normals[i]
                normals_arr.InsertNextTuple3(n.X, n.Y, n.Z)
            else:
                normals_arr.InsertNextTuple3(fn.X, fn.Y, fn.Z)
            colors_arr.InsertNextTuple3(r, g, b)

        for tri in triangles:
            triangle = vtk.vtkTriangle()
            for j in range(3):
                triangle.GetPointIds().SetId(j, vertex_offset + tri[j])
            polys.InsertNextCell(triangle)

        vertex_offset += len(face_points)

    pd = vtk.vtkPolyData()
    pd.SetPoints(points)
    pd.SetPolys(polys)
    pd.GetPointData().SetNormals(normals_arr)
    pd.GetPointData().SetScalars(colors_arr)
    return pd


def _edges_to_vtk(shape) -> vtk.vtkPolyData:
    """Convert OCP CAD topology edges to VTK polydata."""
    points = vtk.vtkPoints()
    lines = vtk.vtkCellArray()
    pt_idx = 0

    for edge in iter_edges(shape):
        pts = sample_edge(edge, EDGE_SAMPLES + 1)
        if len(pts) >= 2:
            start_idx = pt_idx
            for p in pts:
                points.InsertNextPoint(p.X, p.Y, p.Z)
                pt_idx += 1
            for i in range(len(pts) - 1):
                line = vtk.vtkLine()
                line.GetPointIds().SetId(0, start_idx + i)
                line.GetPointIds().SetId(1, start_idx + i + 1)
                lines.InsertNextCell(line)

    pd = vtk.vtkPolyData()
    pd.SetPoints(points)
    pd.SetLines(lines)
    return pd


def _setup_renderer(size: tuple = (400, 400)):
    """Create VTK renderer + render window with gradient background and fixed lights."""
    ren = vtk.vtkRenderer()
    ren.SetBackground(*BG_BOTTOM)
    ren.SetBackground2(*BG_TOP)
    ren.GradientBackgroundOn()

    rw = vtk.vtkRenderWindow()
    rw.SetOffScreenRendering(1)
    rw.AddRenderer(ren)
    rw.SetSize(*size)
    rw.SetMultiSamples(8)

    ren.RemoveAllLights()

    key = vtk.vtkLight()
    key.SetPosition(1, -1, 1)
    key.SetFocalPoint(0, 0, 0)
    key.SetIntensity(0.8)
    key.SetPositional(False)
    ren.AddLight(key)

    fill = vtk.vtkLight()
    fill.SetPosition(-1, 1, 0.5)
    fill.SetFocalPoint(0, 0, 0)
    fill.SetIntensity(0.4)
    fill.SetPositional(False)
    ren.AddLight(fill)

    rim = vtk.vtkLight()
    rim.SetPosition(0, 0, -1)
    rim.SetFocalPoint(0, 0, 0)
    rim.SetIntensity(0.2)
    rim.SetPositional(False)
    ren.AddLight(rim)

    return ren, rw


def _setup_camera(renderer, shape, look_from: tuple, look_up: tuple, zoom: float = 0.85):
    """Configure camera for a specific view."""
    d = Vec3(*look_from).normalized()
    bb_min, bb_max = bounding_box(shape)
    cx = (bb_min.X + bb_max.X) / 2
    cy = (bb_min.Y + bb_max.Y) / 2
    cz = (bb_min.Z + bb_max.Z) / 2
    extent = max(bb_max.X - bb_min.X, bb_max.Y - bb_min.Y, bb_max.Z - bb_min.Z)

    cam = renderer.GetActiveCamera()
    cam.SetPosition(cx + d.X * extent * 5, cy + d.Y * extent * 5, cz + d.Z * extent * 5)
    cam.SetFocalPoint(cx, cy, cz)
    cam.SetViewUp(*look_up)
    cam.ParallelProjectionOn()
    renderer.ResetCamera()
    cam.Zoom(zoom)


def _capture_image(rw) -> Image.Image:
    """Capture VTK render window to PIL Image."""
    w2i = vtk.vtkWindowToImageFilter()
    w2i.SetInput(rw)
    w2i.SetInputBufferTypeToRGB()
    w2i.Update()

    img_data = w2i.GetOutput()
    w, h, _ = img_data.GetDimensions()
    vtk_arr = img_data.GetPointData().GetScalars()
    np_arr = np.frombuffer(vtk_arr, dtype=np.uint8).reshape(h, w, 3)
    np_arr = np.flipud(np_arr)
    return Image.fromarray(np_arr)


def render_view(shape, look_from: tuple, look_up: tuple,
                size: tuple = (400, 400), title: str = "",
                color: tuple = DEFAULT_COLOR) -> Image.Image:
    """Render a single view of a shape using VTK offscreen rendering."""
    ren, rw = _setup_renderer(size)

    pd = _shape_to_vtk(shape, color)
    epd = _edges_to_vtk(shape)

    mapper = vtk.vtkPolyDataMapper()
    mapper.SetInputData(pd)
    actor = vtk.vtkActor()
    actor.SetMapper(mapper)
    actor.GetProperty().SetInterpolationToPhong()
    actor.GetProperty().SetSpecular(0.3)
    actor.GetProperty().SetSpecularPower(20)
    actor.GetProperty().SetAmbient(0.15)
    actor.GetProperty().SetDiffuse(0.85)

    edge_mapper = vtk.vtkPolyDataMapper()
    edge_mapper.SetInputData(epd)
    edge_mapper.ScalarVisibilityOff()
    edge_actor = vtk.vtkActor()
    edge_actor.SetMapper(edge_mapper)
    edge_actor.GetProperty().SetColor(*EDGE_COLOR)
    edge_actor.GetProperty().SetLineWidth(EDGE_WIDTH)

    ren.AddActor(actor)
    ren.AddActor(edge_actor)

    _setup_camera(ren, shape, look_from, look_up)

    if title:
        txt = vtk.vtkTextActor()
        txt.SetInput(title)
        txt.GetTextProperty().SetFontSize(16)
        txt.GetTextProperty().SetColor(0.3, 0.3, 0.3)
        txt.GetPositionCoordinate().SetCoordinateSystemToNormalizedViewport()
        txt.SetPosition(0.02, 0.92)
        ren.AddActor2D(txt)

    rw.Render()
    return _capture_image(rw)


def render_multi_view(shape, views: list[str] = None,
                      size: tuple = (800, 800),
                      color: tuple = DEFAULT_COLOR) -> Image.Image:
    """Render a 2x2 grid of views."""
    if views is None:
        views = ["iso", "front", "top", "right"]

    while len(views) < 4:
        views.append("iso")
    views = views[:4]

    view_size = (size[0] // 2, size[1] // 2)
    images = []

    for view_name in views:
        look_from, look_up = VIEWS.get(view_name, VIEWS["iso"])
        img = render_view(shape, look_from, look_up, view_size, title=view_name,
                          color=color)
        images.append(img)

    grid = Image.new("RGB", size, "white")
    grid.paste(images[0], (0, 0))
    grid.paste(images[1], (view_size[0], 0))
    grid.paste(images[2], (0, view_size[1]))
    grid.paste(images[3], (view_size[0], view_size[1]))

    return grid
