"""Vec3: lightweight immutable 3D vector replacing build123d Vector."""

from __future__ import annotations
import math


class Vec3:
    """Immutable 3D vector for coordinate math."""

    __slots__ = ("_x", "_y", "_z")

    def __init__(self, x: float = 0, y: float = 0, z: float = 0):
        object.__setattr__(self, "_x", float(x))
        object.__setattr__(self, "_y", float(y))
        object.__setattr__(self, "_z", float(z))

    @property
    def X(self) -> float:
        return self._x

    @property
    def Y(self) -> float:
        return self._y

    @property
    def Z(self) -> float:
        return self._z

    # --- Arithmetic ---

    def __add__(self, other: Vec3) -> Vec3:
        if isinstance(other, Vec3):
            return Vec3(self._x + other._x, self._y + other._y, self._z + other._z)
        return NotImplemented

    def __sub__(self, other: Vec3) -> Vec3:
        if isinstance(other, Vec3):
            return Vec3(self._x - other._x, self._y - other._y, self._z - other._z)
        return NotImplemented

    def __mul__(self, scalar: float) -> Vec3:
        return Vec3(self._x * scalar, self._y * scalar, self._z * scalar)

    def __rmul__(self, scalar: float) -> Vec3:
        return self.__mul__(scalar)

    def __neg__(self) -> Vec3:
        return Vec3(-self._x, -self._y, -self._z)

    def __truediv__(self, scalar: float) -> Vec3:
        return Vec3(self._x / scalar, self._y / scalar, self._z / scalar)

    # --- Vector operations ---

    def dot(self, other: Vec3) -> float:
        return self._x * other._x + self._y * other._y + self._z * other._z

    def cross(self, other: Vec3) -> Vec3:
        return Vec3(
            self._y * other._z - self._z * other._y,
            self._z * other._x - self._x * other._z,
            self._x * other._y - self._y * other._x,
        )

    @property
    def length(self) -> float:
        return math.sqrt(self._x ** 2 + self._y ** 2 + self._z ** 2)

    def normalized(self) -> Vec3:
        ln = self.length
        if ln < 1e-12:
            return Vec3(0, 0, 0)
        return Vec3(self._x / ln, self._y / ln, self._z / ln)

    # --- OCP conversions ---

    def to_pnt(self):
        from OCP.gp import gp_Pnt
        return gp_Pnt(self._x, self._y, self._z)

    def to_vec(self):
        from OCP.gp import gp_Vec
        return gp_Vec(self._x, self._y, self._z)

    def to_dir(self):
        from OCP.gp import gp_Dir
        n = self.normalized()
        return gp_Dir(n._x, n._y, n._z)

    @staticmethod
    def from_pnt(p) -> Vec3:
        return Vec3(p.X(), p.Y(), p.Z())

    @staticmethod
    def from_vec(v) -> Vec3:
        return Vec3(v.X(), v.Y(), v.Z())

    @staticmethod
    def from_dir(d) -> Vec3:
        return Vec3(d.X(), d.Y(), d.Z())

    # --- Representation ---

    def __repr__(self) -> str:
        return f"Vec3({self._x:.4f}, {self._y:.4f}, {self._z:.4f})"

    def __eq__(self, other) -> bool:
        if isinstance(other, Vec3):
            return (abs(self._x - other._x) < 1e-10 and
                    abs(self._y - other._y) < 1e-10 and
                    abs(self._z - other._z) < 1e-10)
        return NotImplemented

    def __hash__(self) -> int:
        return hash((round(self._x, 8), round(self._y, 8), round(self._z, 8)))
