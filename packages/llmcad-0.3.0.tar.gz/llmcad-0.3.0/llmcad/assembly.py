"""Assembly: place parts, create assemblies with joints."""

from __future__ import annotations
from dataclasses import dataclass

from OCP.gp import gp_Trsf, gp_Vec, gp_Ax1, gp_Pnt, gp_Dir

from ._vec import Vec3
from .body import Body
from .face import FaceRef
from .position import Position
from ._ocp_helpers import move_shape, make_compound, face_center, face_normal, bounding_box


def place(part: Body, on: FaceRef, at: Position = None, name: str = "") -> Body:
    """Place a part so its center aligns with a position on a face.

    Args:
        part: the body to place
        on: face to place on
        at: position on the face (defaults to face center)
        name: optional name for the placed part
    """
    if at is None:
        at = on.center

    # Compute where the part currently is
    bb_min, bb_max = bounding_box(part.part)
    part_center = (bb_min + bb_max) * 0.5

    # Target position
    target = at.vec

    # Translation
    dx = target.X - part_center.X
    dy = target.Y - part_center.Y
    dz = target.Z - part_center.Z

    trsf = gp_Trsf()
    trsf.SetTranslation(gp_Vec(dx, dy, dz))
    new_shape = move_shape(part.part, trsf)

    new_body = Body(new_shape, name=name or part.name)
    if part._color is not None:
        new_body.color = part._color
    return new_body


class Assembly:
    """A collection of parts and joints forming a mechanical assembly.

    Usage:
        asm = Assembly()
        asm.add(base, name="base")
        asm.add(lid, name="lid")
        body = asm.build()  # returns combined Body
    """

    def __init__(self, name: str = ""):
        self.name = name
        self._parts: list[tuple[Body, str]] = []
        self._joints: list[RevoluteJoint] = []

    def add(self, part: Body, name: str = "") -> Assembly:
        """Add a part to the assembly."""
        self._parts.append((part, name or part.name))
        return self

    def add_joint(self, joint: RevoluteJoint) -> Assembly:
        """Add a joint to the assembly."""
        self._joints.append(joint)
        return self

    @property
    def part(self):
        """Combined shape (compound of all parts)."""
        shapes = [p.part for p, _ in self._parts]
        return make_compound(shapes)

    def build(self) -> Body:
        """Build the assembly into a single Body (compound)."""
        compound = self.part
        return Body(compound, name=self.name)

    def __repr__(self) -> str:
        names = [n for _, n in self._parts]
        return f"Assembly('{self.name}', parts={names})"


@dataclass
class RevoluteJoint:
    """A revolute (rotational) joint between two parts.

    Args:
        axis: rotation axis (gp_Ax1)
        part_a: first part name
        part_b: second part name
        range: (min_angle, max_angle) in degrees, or None for unlimited
    """
    axis: gp_Ax1
    part_a: str = ""
    part_b: str = ""
    range: tuple[float, float] | None = None
