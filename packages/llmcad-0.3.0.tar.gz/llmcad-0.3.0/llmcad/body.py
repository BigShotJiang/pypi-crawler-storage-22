"""Body: the core class wrapping an OCP TopoDS_Shape with named faces and edges."""

from __future__ import annotations

from OCP.TopoDS import TopoDS_Shape
from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse, BRepAlgoAPI_Cut, BRepAlgoAPI_Common

from ._vec import Vec3
from .face import FaceRef
from .edge import EdgeRef
from .position import Position
from ._naming import transfer_face_names
from ._ocp_helpers import (
    iter_edges, iter_faces, edge_center, edge_length,
    bounding_box, face_center, face_normal,
)


# Simple named color table (r, g, b, a) floats 0-1
_NAMED_COLORS = {
    "red": (1.0, 0.0, 0.0, 1.0),
    "green": (0.0, 0.5, 0.0, 1.0),
    "blue": (0.0, 0.0, 1.0, 1.0),
    "yellow": (1.0, 1.0, 0.0, 1.0),
    "orange": (1.0, 0.65, 0.0, 1.0),
    "white": (1.0, 1.0, 1.0, 1.0),
    "black": (0.0, 0.0, 0.0, 1.0),
    "gray": (0.5, 0.5, 0.5, 1.0),
    "grey": (0.5, 0.5, 0.5, 1.0),
    "steel": (0.56, 0.59, 0.63, 1.0),
    "silver": (0.75, 0.75, 0.75, 1.0),
    "cyan": (0.0, 1.0, 1.0, 1.0),
    "magenta": (1.0, 0.0, 1.0, 1.0),
    "purple": (0.5, 0.0, 0.5, 1.0),
    "pink": (1.0, 0.75, 0.8, 1.0),
    "brown": (0.65, 0.16, 0.16, 1.0),
}


class FaceCollection:
    """Dict-like access to named faces: body.faces["tag"], body.faces.start, body.faces.end."""

    def __init__(self, body: Body):
        self._body = body

    def __getitem__(self, key: str) -> FaceRef:
        if key in self._body._face_map:
            return self._body._face_map[key]
        raise KeyError(f"No face named '{key}' on body '{self._body.name}'. "
                       f"Available: {list(self._body._face_map.keys())}")

    def __contains__(self, key: str) -> bool:
        return key in self._body._face_map

    @property
    def start(self) -> FaceRef | None:
        return self._body._face_map.get("_start")

    @property
    def end(self) -> FaceRef | None:
        return self._body._face_map.get("_end")

    def filter(self, normal: str = None, axis: str = None) -> list[FaceRef]:
        """Filter faces by normal direction."""
        results = []
        axis_map = {"X": Vec3(1, 0, 0), "Y": Vec3(0, 1, 0), "Z": Vec3(0, 0, 1)}

        for name, face_ref in self._body._face_map.items():
            if normal and normal in axis_map:
                if abs(face_ref.normal.dot(axis_map[normal])) > 0.9:
                    results.append(face_ref)
        return results


class EdgeCollection:
    """Access to edges with filtering."""

    def __init__(self, body: Body):
        self._body = body

    def all(self) -> list[EdgeRef]:
        return [EdgeRef(e, body=self._body) for e in iter_edges(self._body.part)]

    def filter(self, axis: str = None) -> list[EdgeRef]:
        if axis:
            axis_dirs = {"X": Vec3(1, 0, 0), "Y": Vec3(0, 1, 0), "Z": Vec3(0, 0, 1)}
            if axis in axis_dirs:
                target = axis_dirs[axis]
                result = []
                for e in iter_edges(self._body.part):
                    from ._ocp_helpers import edge_at_parameter
                    p0 = edge_at_parameter(e, 0.0)
                    p1 = edge_at_parameter(e, 1.0)
                    direction = (p1 - p0)
                    if direction.length > 1e-9:
                        direction = direction.normalized()
                        if abs(direction.dot(target)) > 0.9:
                            result.append(EdgeRef(e, body=self._body))
                return result
        return self.all()

    def __iter__(self):
        return iter(self.all())

    def __add__(self, other):
        if isinstance(other, list):
            return list(self) + other
        if isinstance(other, EdgeCollection):
            return list(self) + list(other)
        return NotImplemented


class Body:
    """A 3D body with named faces, edges, and boolean operations.

    Bodies are immutable — boolean ops return new Body instances.
    """

    def __init__(self, part: TopoDS_Shape, name: str = "",
                 face_map: dict[str, FaceRef] | None = None,
                 color: str | tuple | None = None):
        self.part = part
        self.name = name
        self._face_map: dict[str, FaceRef] = face_map or {}
        self._color: tuple | None = None
        if color is not None:
            self.color = color
        # Back-reference body on all face refs
        for fr in self._face_map.values():
            fr._body = self

    # --- Named face shortcuts ---

    @property
    def top(self) -> FaceRef:
        return self._face_map["top"]

    @property
    def bottom(self) -> FaceRef:
        return self._face_map["bottom"]

    @property
    def front(self) -> FaceRef:
        return self._face_map["front"]

    @property
    def back(self) -> FaceRef:
        return self._face_map["back"]

    @property
    def left(self) -> FaceRef:
        return self._face_map["left"]

    @property
    def right(self) -> FaceRef:
        return self._face_map["right"]

    @property
    def wall(self) -> FaceRef:
        return self._face_map.get("wall")

    # --- Color ---

    @property
    def color(self) -> tuple | None:
        return self._color

    @color.setter
    def color(self, value: str | tuple | None):
        """Set body color. Accepts name string or (r,g,b[,a]) tuple (0-1 floats)."""
        if value is None:
            self._color = None
        elif isinstance(value, str):
            self._color = _NAMED_COLORS.get(value.lower(), (0.7, 0.7, 0.7, 1.0))
        elif isinstance(value, tuple):
            if len(value) == 3:
                self._color = (*value, 1.0)
            else:
                self._color = value
        else:
            self._color = (0.7, 0.7, 0.7, 1.0)

    # --- Collections ---

    @property
    def faces(self) -> FaceCollection:
        return FaceCollection(self)

    @property
    def edges(self) -> EdgeCollection:
        return EdgeCollection(self)

    @property
    def exterior_edges(self) -> list[EdgeRef]:
        return [EdgeRef(e, body=self) for e in iter_edges(self.part)]

    @property
    def position(self) -> Position:
        """The center of the body's bounding box."""
        bb_min, bb_max = bounding_box(self.part)
        center = (bb_min + bb_max) * 0.5
        return Position(center)

    @property
    def center_axis(self):
        """Central axis of the body (useful for revolve operations)."""
        from OCP.gp import gp_Ax1, gp_Pnt, gp_Dir
        bb_min, bb_max = bounding_box(self.part)
        center = (bb_min + bb_max) * 0.5
        return gp_Ax1(center.to_pnt(), gp_Dir(0, 0, 1))

    # --- Edge queries ---

    def edge_between(self, face_a: FaceRef, face_b: FaceRef) -> EdgeRef | None:
        """Find the edge shared between two faces."""
        edges_a = set()
        for e in iter_edges(face_a._face):
            edges_a.add(id(e))  # Use Python id for quick set lookup
            # Also store by hash for IsSame check
        for ea in iter_edges(face_a._face):
            for eb in iter_edges(face_b._face):
                if ea.IsSame(eb):
                    return EdgeRef(ea, body=self)
        return self._find_shared_edge_geometric(face_a, face_b)

    def edges_between(self, other: Body) -> list[EdgeRef]:
        """Find edges where this body meets another (after union)."""
        result = []
        bb_min, bb_max = bounding_box(other.part)
        for e in iter_edges(self.part):
            ec = edge_center(e)
            if (bb_min.X - 1 <= ec.X <= bb_max.X + 1 and
                bb_min.Y - 1 <= ec.Y <= bb_max.Y + 1 and
                bb_min.Z - 1 <= ec.Z <= bb_max.Z + 1):
                result.append(EdgeRef(e, body=self))
        return result

    def _find_shared_edge_geometric(self, face_a: FaceRef, face_b: FaceRef) -> EdgeRef | None:
        """Find shared edge by geometric proximity."""
        for ea in iter_edges(face_a._face):
            ca = edge_center(ea)
            for eb in iter_edges(face_b._face):
                cb = edge_center(eb)
                if (ca - cb).length < 0.01:
                    return EdgeRef(ea, body=self)
        return None

    # --- Boolean operations (return new Body) ---

    def __add__(self, other: Body) -> Body:
        if not isinstance(other, Body):
            return NotImplemented
        new_shape = BRepAlgoAPI_Fuse(self.part, other.part).Shape()
        new_body = Body(new_shape, name=self.name)
        combined = {}
        combined.update(transfer_face_names(self._face_map, new_shape, new_body))
        combined.update(transfer_face_names(other._face_map, new_shape, new_body))
        new_body._face_map = combined
        if self._color is not None:
            new_body.color = self._color
        return new_body

    def __sub__(self, other: Body) -> Body:
        if not isinstance(other, Body):
            return NotImplemented
        new_shape = BRepAlgoAPI_Cut(self.part, other.part).Shape()
        new_body = Body(new_shape, name=self.name)
        new_body._face_map = transfer_face_names(self._face_map, new_shape, new_body)
        if self._color is not None:
            new_body.color = self._color
        return new_body

    def __and__(self, other: Body) -> Body:
        if not isinstance(other, Body):
            return NotImplemented
        new_shape = BRepAlgoAPI_Common(self.part, other.part).Shape()
        new_body = Body(new_shape, name=self.name)
        new_body._face_map = transfer_face_names(self._face_map, new_shape, new_body)
        return new_body

    def __repr__(self) -> str:
        face_names = list(self._face_map.keys())
        return f"Body('{self.name}', faces={face_names})"
