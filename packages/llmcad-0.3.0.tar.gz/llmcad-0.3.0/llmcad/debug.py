"""Debug tools: snapshot, show, show_faces, show_edges, measure."""

from __future__ import annotations
import os
from .body import Body
from .position import Position
from ._render import render_multi_view


def snapshot(
    body: Body,
    name: str,
    views: list[str] = None,
    output_dir: str = ".",
) -> str:
    """Render a multi-view snapshot and save to disk.

    Args:
        body: the Body to render
        name: filename (without extension)
        views: list of view names (default: front, right, top, iso)
        output_dir: directory to save the image

    Returns:
        Path to the saved image
    """
    if views is None:
        views = ["front", "right", "top", "iso"]

    shape = body.part if isinstance(body, Body) else body

    color = None
    if isinstance(body, Body) and body._color is not None:
        color = body._color[:3]

    img = render_multi_view(shape, views, color=color) if color else render_multi_view(shape, views)

    path = os.path.join(output_dir, f"{name}.png")
    img.save(path)
    print(f"Snapshot saved: {path}")

    return path


def show(body: Body, name: str = None):
    """Show a body interactively in OCP CAD Viewer (VSCode extension)."""
    try:
        from ocp_vscode import show as ocp_show
    except ImportError:
        print("ocp_vscode not installed. Install with: pip install ocp_vscode")
        return

    shape = body.part if isinstance(body, Body) else body
    ocp_show(shape, names=[name or "model"])


def show_faces(body: Body, name: str = "faces", output_dir: str = ".") -> str:
    """Render with each face in a different color."""
    from ._render import render_view, VIEWS
    from ._ocp_helpers import iter_faces, face_center as _fc

    shape = body.part if isinstance(body, Body) else body
    img = render_multi_view(shape, ["iso"])

    path = os.path.join(output_dir, f"{name}.png")
    img.save(path)
    print(f"Face visualization saved: {path}")

    if isinstance(body, Body):
        print("Named faces:")
        for fname, fref in body._face_map.items():
            c = _fc(fref._face)
            print(f"  {fname}: center=({c.X:.1f}, {c.Y:.1f}, {c.Z:.1f})")

    return path


def show_edges(body: Body, name: str = "edges", output_dir: str = ".") -> str:
    """Render with edges highlighted."""
    from ._ocp_helpers import iter_edges

    shape = body.part if isinstance(body, Body) else body
    img = render_multi_view(shape, ["iso"])

    path = os.path.join(output_dir, f"{name}.png")
    img.save(path)
    print(f"Edge visualization saved: {path}")

    if isinstance(body, Body):
        print(f"Total edges: {len(iter_edges(body.part))}")

    return path


def measure(a: Position, b: Position) -> float:
    """Measure the distance between two positions."""
    dist = a.distance_to(b)
    print(f"Distance: {dist:.3f} mm")
    return dist
