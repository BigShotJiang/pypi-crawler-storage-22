"""EdgeRef: a named reference to an OCP TopoDS_Edge."""

from __future__ import annotations
from typing import TYPE_CHECKING

from OCP.TopoDS import TopoDS_Edge

if TYPE_CHECKING:
    from .body import Body
    from .position import Position


class EdgeRef:
    """Wraps a TopoDS_Edge with convenient accessors."""

    def __init__(self, edge: TopoDS_Edge, name: str = "", body: Body | None = None):
        self._edge = edge
        self._name = name
        self._body = body

    @property
    def midpoint(self) -> Position:
        from .position import Position
        from ._ocp_helpers import edge_center
        return Position(edge_center(self._edge), face_ref=None)

    @property
    def length(self) -> float:
        from ._ocp_helpers import edge_length
        return edge_length(self._edge)

    @property
    def start(self) -> Position:
        from .position import Position
        from ._ocp_helpers import edge_at_parameter
        return Position(edge_at_parameter(self._edge, 0.0), face_ref=None)

    @property
    def end(self) -> Position:
        from .position import Position
        from ._ocp_helpers import edge_at_parameter
        return Position(edge_at_parameter(self._edge, 1.0), face_ref=None)

    def __repr__(self) -> str:
        from ._ocp_helpers import edge_center, edge_length
        c = edge_center(self._edge)
        ln = edge_length(self._edge)
        return f"EdgeRef('{self._name}', length={ln:.2f}, center=({c.X:.1f},{c.Y:.1f},{c.Z:.1f}))"

    def __add__(self, other):
        """Allow edge + edge to create lists for fillet/chamfer."""
        if isinstance(other, EdgeRef):
            return [self, other]
        if isinstance(other, list):
            return [self] + other
        return NotImplemented

    def __radd__(self, other):
        if isinstance(other, list):
            return other + [self]
        if other == 0:  # for sum()
            return [self]
        return NotImplemented
