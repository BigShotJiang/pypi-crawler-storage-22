"""Export: save bodies to STEP, STL, and GLB (glTF) files."""

from __future__ import annotations

import struct
import json
import numpy as np

from OCP.TopoDS import TopoDS_Shape
from OCP.STEPControl import STEPControl_Writer, STEPControl_AsIs
from OCP.StlAPI import StlAPI_Writer
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.Interface import Interface_Static


def export_step(body, path: str) -> str:
    """Export a body to STEP format.

    Args:
        body: Body or TopoDS_Shape to export
        path: output file path (e.g. "part.step")

    Returns:
        Path to the saved file
    """
    shape = _resolve_shape(body)
    writer = STEPControl_Writer()
    Interface_Static.SetCVal_s("write.step.schema", "AP214")
    writer.Transfer(shape, STEPControl_AsIs)
    writer.Write(path)
    return path


def export_stl(body, path: str, deflection: float = 0.05) -> str:
    """Export a body to STL format.

    Args:
        body: Body or TopoDS_Shape to export
        path: output file path (e.g. "part.stl")
        deflection: mesh quality (smaller = finer, default 0.05)

    Returns:
        Path to the saved file
    """
    shape = _resolve_shape(body)
    BRepMesh_IncrementalMesh(shape, deflection)
    writer = StlAPI_Writer()
    writer.Write(shape, path)
    return path


def export_glb(body, path: str, deflection: float = 0.05) -> str:
    """Export a body to GLB (binary glTF) format.

    Uses the tessellation from OCP and writes a minimal glTF 2.0 binary file.

    Args:
        body: Body or TopoDS_Shape to export
        path: output file path (e.g. "part.glb")
        deflection: mesh quality (smaller = finer, default 0.05)

    Returns:
        Path to the saved file
    """
    from ._ocp_helpers import tessellate_shape

    shape = _resolve_shape(body)

    # Get color
    color = [0.55, 0.70, 0.85, 1.0]
    from .body import Body
    if isinstance(body, Body) and body._color is not None:
        color = list(body._color[:4])
        if len(color) == 3:
            color.append(1.0)

    # Tessellate
    tess = tessellate_shape(shape, deflection)

    all_positions = []
    all_normals = []
    all_indices = []
    offset = 0

    for face, points, triangles, normals in tess:
        for i, p in enumerate(points):
            all_positions.append([p.X, p.Y, p.Z])
            if normals and i < len(normals):
                n = normals[i]
                all_normals.append([n.X, n.Y, n.Z])
            else:
                all_normals.append([0.0, 0.0, 1.0])

        for tri in triangles:
            all_indices.extend([offset + tri[0], offset + tri[1], offset + tri[2]])

        offset += len(points)

    if not all_positions:
        # Empty shape, write minimal valid GLB
        with open(path, "wb") as f:
            f.write(b"")
        return path

    positions = np.array(all_positions, dtype=np.float32)
    normals_arr = np.array(all_normals, dtype=np.float32)
    indices = np.array(all_indices, dtype=np.uint32)

    # Build binary buffer
    pos_bytes = positions.tobytes()
    norm_bytes = normals_arr.tobytes()
    idx_bytes = indices.tobytes()

    # Pad each to 4-byte alignment
    def pad4(data):
        r = len(data) % 4
        return data + b"\x00" * (4 - r) if r else data

    pos_bytes = pad4(pos_bytes)
    norm_bytes = pad4(norm_bytes)
    idx_bytes = pad4(idx_bytes)

    buffer_data = idx_bytes + pos_bytes + norm_bytes
    buffer_length = len(buffer_data)

    idx_offset = 0
    idx_length = len(idx_bytes)
    pos_offset = idx_length
    pos_length = len(pos_bytes)
    norm_offset = pos_offset + pos_length
    norm_length = len(norm_bytes)

    pos_min = positions.min(axis=0).tolist()
    pos_max = positions.max(axis=0).tolist()

    gltf = {
        "asset": {"version": "2.0", "generator": "llmcad"},
        "scene": 0,
        "scenes": [{"nodes": [0]}],
        "nodes": [{"mesh": 0}],
        "meshes": [{
            "primitives": [{
                "attributes": {"POSITION": 1, "NORMAL": 2},
                "indices": 0,
                "material": 0,
            }]
        }],
        "materials": [{
            "pbrMetallicRoughness": {
                "baseColorFactor": color,
                "metallicFactor": 0.1,
                "roughnessFactor": 0.6,
            }
        }],
        "accessors": [
            {  # 0: indices
                "bufferView": 0,
                "componentType": 5125,  # UNSIGNED_INT
                "count": len(all_indices),
                "type": "SCALAR",
            },
            {  # 1: positions
                "bufferView": 1,
                "componentType": 5126,  # FLOAT
                "count": len(all_positions),
                "type": "VEC3",
                "min": pos_min,
                "max": pos_max,
            },
            {  # 2: normals
                "bufferView": 2,
                "componentType": 5126,  # FLOAT
                "count": len(all_normals),
                "type": "VEC3",
            },
        ],
        "bufferViews": [
            {"buffer": 0, "byteOffset": idx_offset, "byteLength": idx_length, "target": 34963},
            {"buffer": 0, "byteOffset": pos_offset, "byteLength": pos_length, "target": 34962},
            {"buffer": 0, "byteOffset": norm_offset, "byteLength": norm_length, "target": 34962},
        ],
        "buffers": [{"byteLength": buffer_length}],
    }

    # Encode JSON chunk
    json_str = json.dumps(gltf, separators=(",", ":"))
    json_bytes = json_str.encode("utf-8")
    # Pad to 4-byte alignment with spaces
    r = len(json_bytes) % 4
    if r:
        json_bytes += b" " * (4 - r)

    # Write GLB
    # Header: magic(4) + version(4) + length(4)
    # JSON chunk: length(4) + type(4) + data
    # BIN chunk: length(4) + type(4) + data
    total_length = 12 + 8 + len(json_bytes) + 8 + len(buffer_data)

    with open(path, "wb") as f:
        # GLB header
        f.write(struct.pack("<I", 0x46546C67))  # magic: glTF
        f.write(struct.pack("<I", 2))             # version
        f.write(struct.pack("<I", total_length))   # total length

        # JSON chunk
        f.write(struct.pack("<I", len(json_bytes)))
        f.write(struct.pack("<I", 0x4E4F534A))  # JSON
        f.write(json_bytes)

        # BIN chunk
        f.write(struct.pack("<I", len(buffer_data)))
        f.write(struct.pack("<I", 0x004E4942))  # BIN
        f.write(buffer_data)

    return path


def _resolve_shape(body) -> TopoDS_Shape:
    """Extract TopoDS_Shape from a body or pass through."""
    from .body import Body
    if isinstance(body, Body):
        return body.part
    return body
