"""FaceRef: a named face with local coordinate system, edges, and corners."""

from __future__ import annotations
from typing import TYPE_CHECKING

from OCP.TopoDS import TopoDS_Face

from ._vec import Vec3
from .position import Position
from .edge import EdgeRef

if TYPE_CHECKING:
    from .body import Body


class CornerSet:
    """Named corners of a rectangular face: TL, TR, BL, BR."""

    def __init__(self, corners: dict[str, Position]):
        self._corners = corners

    @property
    def TL(self) -> Position:
        return self._corners["TL"]

    @property
    def TR(self) -> Position:
        return self._corners["TR"]

    @property
    def BL(self) -> Position:
        return self._corners["BL"]

    @property
    def BR(self) -> Position:
        return self._corners["BR"]

    def __iter__(self):
        for name, pos in self._corners.items():
            pos._corner_name = name
            yield pos

    def __repr__(self) -> str:
        return "CornerSet(TL, TR, BL, BR)"


class FaceRef:
    """A named reference to an OCP TopoDS_Face with face-local coordinate system.

    The face has a local 2D coordinate system:
    - x_dir: "rightward" on the face
    - y_dir: "upward" on the face
    - normal: outward normal (z_dir)

    Positions on this face use these local axes for offset(dx, dy).
    """

    def __init__(
        self,
        face: TopoDS_Face,
        body: Body | None = None,
        name: str = "",
        x_dir: Vec3 | None = None,
        y_dir: Vec3 | None = None,
    ):
        self._face = face
        self._body = body
        self._name = name

        from ._ocp_helpers import face_normal
        self._normal = face_normal(face)

        if x_dir is not None and y_dir is not None:
            self._x_dir = x_dir
            self._y_dir = y_dir
        else:
            self._x_dir, self._y_dir = _derive_local_axes(face, self._normal)

        # Inner/outer for shelled faces
        self._inner: FaceRef | None = None
        self._outer: FaceRef | None = None

    @property
    def name(self) -> str:
        return self._name

    @property
    def normal(self) -> Vec3:
        return self._normal

    @property
    def center(self) -> Position:
        from ._ocp_helpers import face_center
        return Position(face_center(self._face), face_ref=self)

    @property
    def width(self) -> float:
        """Width of the face (extent along local x_dir)."""
        return _face_extent(self._face, self._x_dir)

    @property
    def height(self) -> float:
        """Height of the face (extent along local y_dir)."""
        return _face_extent(self._face, self._y_dir)

    @property
    def area(self) -> float:
        from ._ocp_helpers import face_area
        return face_area(self._face)

    @property
    def inner(self) -> FaceRef | None:
        return self._inner

    @property
    def outer(self) -> FaceRef | None:
        return self._outer

    # --- Edge access ---

    @property
    def edges(self) -> list[EdgeRef]:
        from ._ocp_helpers import iter_edges
        return [EdgeRef(e, body=self._body) for e in iter_edges(self._face)]

    @property
    def perimeter_edges(self) -> list[EdgeRef]:
        return self.edges

    @property
    def left_edge(self) -> EdgeRef:
        return self._edge_in_direction(-self._x_dir)

    @property
    def right_edge(self) -> EdgeRef:
        return self._edge_in_direction(self._x_dir)

    @property
    def top_edge(self) -> EdgeRef:
        return self._edge_in_direction(self._y_dir)

    @property
    def bottom_edge(self) -> EdgeRef:
        return self._edge_in_direction(-self._y_dir)

    @property
    def long_edges(self) -> list[EdgeRef]:
        """The longest edges of this face."""
        from ._ocp_helpers import iter_edges, edge_length
        face_edges = iter_edges(self._face)
        if not face_edges:
            return []
        lengths = [edge_length(e) for e in face_edges]
        max_len = max(lengths)
        threshold = max_len * 0.9
        return [EdgeRef(e, body=self._body) for e, ln in zip(face_edges, lengths)
                if ln >= threshold]

    def _edge_in_direction(self, direction: Vec3) -> EdgeRef | None:
        """Find the edge whose center is farthest in the given direction from face center."""
        from ._ocp_helpers import iter_edges, edge_center, face_center as _face_center
        fc = _face_center(self._face)
        best_edge = None
        best_score = -float("inf")
        for edge in iter_edges(self._face):
            ec = edge_center(edge)
            diff = ec - fc
            score = diff.dot(direction)
            if score > best_score:
                best_score = score
                best_edge = edge
        return EdgeRef(best_edge, body=self._body) if best_edge else None

    # --- Corners ---

    @property
    def corners(self) -> CornerSet:
        """Named corners of a rectangular face.

        Uses bounding-box extremes in face-local coordinates so that corners
        remain correct even after boolean operations add extra vertices.
        """
        from ._ocp_helpers import iter_vertices, vertex_point, face_center as _face_center
        verts = iter_vertices(self._face)
        if len(verts) < 4:
            return CornerSet({})

        fc = _face_center(self._face)
        x_dir, y_dir = self._x_dir, self._y_dir

        # Project all vertices into face-local 2D
        local = []
        for v in verts:
            p = vertex_point(v)
            lx = (p - fc).dot(x_dir)
            ly = (p - fc).dot(y_dir)
            local.append((lx, ly, p))

        min_x = min(lx for lx, _, _ in local)
        max_x = max(lx for lx, _, _ in local)
        min_y = min(ly for _, ly, _ in local)
        max_y = max(ly for _, ly, _ in local)

        corners = {
            "TL": Position(fc + x_dir * min_x + y_dir * max_y, face_ref=self),
            "TR": Position(fc + x_dir * max_x + y_dir * max_y, face_ref=self),
            "BL": Position(fc + x_dir * min_x + y_dir * min_y, face_ref=self),
            "BR": Position(fc + x_dir * max_x + y_dir * min_y, face_ref=self),
        }

        return CornerSet(corners)

    def __repr__(self) -> str:
        from ._ocp_helpers import face_center
        c = face_center(self._face)
        return f"FaceRef('{self._name}', center=({c.X:.1f},{c.Y:.1f},{c.Z:.1f}))"


# --- Local axis derivation ---

_FACE_AXES = {
    "top": (Vec3(1, 0, 0), Vec3(0, 1, 0)),
    "bottom": (Vec3(1, 0, 0), Vec3(0, 1, 0)),
    "front": (Vec3(1, 0, 0), Vec3(0, 0, 1)),
    "back": (Vec3(-1, 0, 0), Vec3(0, 0, 1)),
    "right": (Vec3(0, 1, 0), Vec3(0, 0, 1)),
    "left": (Vec3(0, -1, 0), Vec3(0, 0, 1)),
}


def get_standard_axes(face_name: str) -> tuple[Vec3, Vec3] | None:
    """Get standard local axes for a named face (Box convention)."""
    return _FACE_AXES.get(face_name)


def _derive_local_axes(face: TopoDS_Face, normal: Vec3) -> tuple[Vec3, Vec3]:
    """Derive local x/y axes from a face when no standard mapping exists."""
    abs_n = Vec3(abs(normal.X), abs(normal.Y), abs(normal.Z))

    if abs_n.Z >= abs_n.X and abs_n.Z >= abs_n.Y:
        up_hint = Vec3(0, 1, 0)
    elif abs_n.Y >= abs_n.X:
        up_hint = Vec3(0, 0, 1)
    else:
        up_hint = Vec3(0, 0, 1)

    x_dir = up_hint.cross(normal).normalized()
    y_dir = normal.cross(x_dir).normalized()
    return x_dir, y_dir


def _face_extent(face: TopoDS_Face, direction: Vec3) -> float:
    """Measure the extent of a face along a direction."""
    from ._ocp_helpers import bounding_box
    bb_min, bb_max = bounding_box(face)
    corners = [
        Vec3(bb_min.X, bb_min.Y, bb_min.Z),
        Vec3(bb_max.X, bb_min.Y, bb_min.Z),
        Vec3(bb_min.X, bb_max.Y, bb_min.Z),
        Vec3(bb_max.X, bb_max.Y, bb_min.Z),
        Vec3(bb_min.X, bb_min.Y, bb_max.Z),
        Vec3(bb_max.X, bb_min.Y, bb_max.Z),
        Vec3(bb_min.X, bb_max.Y, bb_max.Z),
        Vec3(bb_max.X, bb_max.Y, bb_max.Z),
    ]
    projections = [c.dot(direction) for c in corners]
    return max(projections) - min(projections)
