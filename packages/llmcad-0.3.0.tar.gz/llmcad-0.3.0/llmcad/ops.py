"""CAD operations: extrude, revolve, loft, sweep, fillet, chamfer, shell, split, mirror."""

from __future__ import annotations
from math import radians

from OCP.gp import gp_Vec, gp_Ax1, gp_Ax2, gp_Pnt, gp_Dir, gp_Trsf, gp_Pln
from OCP.TopoDS import TopoDS, TopoDS_Face, TopoDS_Shape, TopoDS_Wire
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism, BRepPrimAPI_MakeRevol
from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet, BRepFilletAPI_MakeChamfer
from OCP.BRepOffsetAPI import (
    BRepOffsetAPI_MakeThickSolid, BRepOffsetAPI_ThruSections,
    BRepOffsetAPI_MakePipeShell,
)
from OCP.BRepAlgoAPI import BRepAlgoAPI_Splitter
from OCP.BRepBuilderAPI import (
    BRepBuilderAPI_MakeFace, BRepBuilderAPI_Transform, BRepBuilderAPI_MakeWire,
)
from OCP.TopTools import TopTools_ListOfShape
from OCP.GeomAbs import GeomAbs_Plane, GeomAbs_Cylinder, GeomAbs_Circle, GeomAbs_JoinType

from ._vec import Vec3
from .body import Body
from .face import FaceRef, get_standard_axes
from .edge import EdgeRef
from .position import Position
from .sketch import PlacedSketch, SketchPrimitive, Sketch
from ._naming import transfer_face_names
from ._ocp_helpers import (
    iter_faces, iter_edges, face_center, face_normal, face_geom_type,
    edge_center, edge_at_parameter, edge_geom_type,
    bounding_box, move_shape, iter_solids,
)


def extrude(
    sketch: PlacedSketch | SketchPrimitive | Sketch,
    amount: float = None,
    through: bool = False,
    to: FaceRef = None,
    name: str = "",
) -> Body:
    """Extrude a 2D sketch into a 3D body.

    Args:
        sketch: a PlacedSketch (on a face), SketchPrimitive, or Sketch (turtle-style)
        amount: extrusion distance (positive=outward from face, negative=inward)
        through: if True, extrude through the entire body
        to: extrude until reaching this face
        name: name for the resulting body
    """
    if isinstance(sketch, Sketch):
        placed = sketch.to_placed_sketch()
    elif isinstance(sketch, SketchPrimitive):
        placed = PlacedSketch(sketch._face, None, sketch._edge_names)
    else:
        placed = sketch

    face = placed._face
    normal_dir = placed.normal

    if through:
        amt = 1000  # large enough for most models
    elif to is not None:
        fc = face_center(face)
        tc = face_center(to._face)
        amt = (tc - fc).dot(normal_dir)
    else:
        amt = amount

    # Extrude: direction = normal * amount
    direction = gp_Vec(normal_dir.X * amt, normal_dir.Y * amt, normal_dir.Z * amt)
    prism = BRepPrimAPI_MakePrism(face, direction)
    prism.Build()
    result = prism.Shape()

    body = Body(result, name=name)

    # Name cap faces (start and end)
    _name_cap_faces(body, face, amt, normal_dir)

    # Name features for circular extrusions
    _name_extrusion_features(body, face, name)

    # Assign standard faces by normals
    _assign_standard_faces(body)

    return body


def fillet(edges, radius: float, name: str = "") -> Body | None:
    """Fillet edges of a body.

    Args:
        edges: EdgeRef, list of EdgeRef, or EdgeCollection
        radius: fillet radius
    """
    edge_list, parent_body = _resolve_edges(edges)
    if not edge_list or parent_body is None:
        return None

    fillet_maker = BRepFilletAPI_MakeFillet(parent_body.part)
    for e in edge_list:
        fillet_maker.Add(radius, e)
    fillet_maker.Build()
    new_shape = fillet_maker.Shape()

    new_body = Body(new_shape, name=name or parent_body.name)
    new_body._face_map = transfer_face_names(parent_body._face_map, new_shape, new_body)
    if parent_body._color is not None:
        new_body.color = parent_body._color
    return new_body


def chamfer(edges, size: float, name: str = "") -> Body | None:
    """Chamfer edges of a body.

    Args:
        edges: EdgeRef, list of EdgeRef, or EdgeCollection
        size: chamfer size
    """
    edge_list, parent_body = _resolve_edges(edges)
    if not edge_list or parent_body is None:
        return None

    chamfer_maker = BRepFilletAPI_MakeChamfer(parent_body.part)
    for e in edge_list:
        chamfer_maker.Add(size, e)
    chamfer_maker.Build()
    new_shape = chamfer_maker.Shape()

    new_body = Body(new_shape, name=name or parent_body.name)
    new_body._face_map = transfer_face_names(parent_body._face_map, new_shape, new_body)
    if parent_body._color is not None:
        new_body.color = parent_body._color
    return new_body


def revolve(
    sketch: PlacedSketch | SketchPrimitive | Sketch,
    axis: object = None,
    angle: float = 360,
    name: str = "",
) -> Body:
    """Revolve a 2D sketch around an axis.

    Args:
        sketch: sketch to revolve
        axis: axis of rotation (gp_Ax1, or None for Z axis)
        angle: revolution angle in degrees (default 360 for full revolution)
        name: name for the resulting body
    """
    if isinstance(sketch, Sketch):
        face = sketch.to_face()
    elif isinstance(sketch, SketchPrimitive):
        face = sketch._face
    elif isinstance(sketch, PlacedSketch):
        face = sketch._face
    else:
        face = sketch

    # Resolve axis
    if axis is None:
        rev_axis = gp_Ax1(gp_Pnt(0, 0, 0), gp_Dir(0, 0, 1))
    elif isinstance(axis, gp_Ax1):
        rev_axis = axis
    elif hasattr(axis, 'center_axis'):
        rev_axis = axis.center_axis
    else:
        rev_axis = axis

    # Build revolution (OCP uses radians)
    revol = BRepPrimAPI_MakeRevol(face, rev_axis, radians(angle), True)
    revol.Build()
    result = revol.Shape()

    body = Body(result, name=name)
    _assign_standard_faces(body)
    return body


def loft(
    sketches: list[SketchPrimitive | PlacedSketch | Sketch],
    heights: list[float],
    name: str = "",
) -> Body:
    """Loft between sketches at specified heights.

    Args:
        sketches: list of 2D sketches to loft between
        heights: Z-height for each sketch
        name: name for the resulting body
    """
    loft_builder = BRepOffsetAPI_ThruSections(True, False)  # solid, not ruled

    for sketch, h in zip(sketches, heights):
        if isinstance(sketch, Sketch):
            face = sketch.to_face()
        elif isinstance(sketch, SketchPrimitive):
            face = sketch._face
        elif isinstance(sketch, PlacedSketch):
            face = sketch._face
        else:
            face = sketch

        # Get the outer wire of the face
        from OCP.BRepTools import BRepTools
        outer_wire = BRepTools.OuterWire_s(face)

        # Move wire to the specified height
        trsf = gp_Trsf()
        trsf.SetTranslation(gp_Vec(0, 0, h))
        moved_wire = BRepBuilderAPI_Transform(outer_wire, trsf, True).Shape()
        loft_builder.AddWire(TopoDS.Wire_s(moved_wire))

    loft_builder.Build()
    result = loft_builder.Shape()

    # Extract the solid from the result
    solids = iter_solids(result)
    if solids:
        result = solids[0]

    body = Body(result, name=name)

    # Name top and bottom faces by Z position
    all_faces = iter_faces(result)
    if all_faces:
        z_sorted = sorted(all_faces, key=lambda f: face_center(f).Z)
        axes = get_standard_axes("bottom")
        body._face_map["bottom"] = FaceRef(z_sorted[0], body, "bottom", x_dir=axes[0], y_dir=axes[1])
        axes = get_standard_axes("top")
        body._face_map["top"] = FaceRef(z_sorted[-1], body, "top", x_dir=axes[0], y_dir=axes[1])

    return body


def sweep(
    path: Sketch | PlacedSketch,
    cross_section: PlacedSketch | SketchPrimitive | Sketch = None,
    name: str = "",
) -> Body:
    """Sweep a cross-section along a path.

    Args:
        path: a Sketch defining the sweep path (wire)
        cross_section: the profile to sweep along the path
        name: name for the resulting body
    """
    # Build the path wire
    if isinstance(path, Sketch):
        wire_builder = BRepBuilderAPI_MakeWire()
        for edge in path._edges:
            wire_builder.Add(edge)
        path_wire = wire_builder.Wire()
    elif isinstance(path, PlacedSketch):
        from OCP.BRepTools import BRepTools
        path_wire = BRepTools.OuterWire_s(path._face)
    else:
        path_wire = path

    # Get cross-section face
    if isinstance(cross_section, Sketch):
        section_face = cross_section.to_face()
    elif isinstance(cross_section, SketchPrimitive):
        section_face = cross_section._face
    elif isinstance(cross_section, PlacedSketch):
        section_face = cross_section._face
    else:
        section_face = cross_section

    # Get outer wire of section
    from OCP.BRepTools import BRepTools
    section_wire = BRepTools.OuterWire_s(section_face)

    # Build pipe shell sweep
    builder = BRepOffsetAPI_MakePipeShell(path_wire)
    builder.SetMode(False)  # not Frenet
    builder.Add(section_wire, False, False)
    builder.Build()
    builder.MakeSolid()
    result = builder.Shape()

    body = Body(result, name=name)
    _assign_standard_faces(body)
    return body


def shell(body: Body, thickness: float, open: list[FaceRef] = None, name: str = "") -> Body:
    """Hollow out a body.

    Args:
        body: the body to shell
        thickness: wall thickness (positive shells outward, negative inward)
        open: list of faces to remove (leave open)
        name: optional name
    """
    occ_faces_list = TopTools_ListOfShape()
    if open:
        for fr in open:
            occ_faces_list.Append(fr._face)

    shell_builder = BRepOffsetAPI_MakeThickSolid()
    shell_builder.MakeThickSolidByJoin(
        body.part,
        occ_faces_list,
        -thickness,  # negative = inward (convention: user gives positive thickness)
        1e-4,
        Intersection=True,
        Join=GeomAbs_JoinType.GeomAbs_Arc,
    )
    shell_builder.Build()
    result = shell_builder.Shape()

    new_body = Body(result, name=name or body.name)
    new_body._face_map = transfer_face_names(body._face_map, result, new_body, tol=thickness + 0.5)

    # Detect inner/outer face pairs
    _detect_inner_outer(body, new_body, thickness)

    if body._color is not None:
        new_body.color = body._color
    return new_body


def split(body: Body, plane=None, name: str = "") -> Body:
    """Split a body with a plane, keeping the positive half.

    Args:
        body: the body to split
        plane: a gp_Pln, or None for XZ plane (splits left/right)
        name: optional name
    """
    if plane is None:
        plane = gp_Pln(gp_Pnt(0, 0, 0), gp_Dir(0, 1, 0))  # XZ plane
    elif not isinstance(plane, gp_Pln):
        plane = plane  # assume compatible

    # Create a face from the plane for the splitter tool
    plane_face = BRepBuilderAPI_MakeFace(plane, -1000, 1000, -1000, 1000).Face()

    shape_list = TopTools_ListOfShape()
    shape_list.Append(body.part)

    tool_list = TopTools_ListOfShape()
    tool_list.Append(plane_face)

    splitter = BRepAlgoAPI_Splitter()
    splitter.SetArguments(shape_list)
    splitter.SetTools(tool_list)
    splitter.Build()

    split_result = splitter.Shape()

    # Keep the solid(s) on the positive side of the plane normal
    plane_normal = Vec3(plane.Axis().Direction().X(),
                        plane.Axis().Direction().Y(),
                        plane.Axis().Direction().Z())
    plane_origin = Vec3(plane.Location().X(),
                        plane.Location().Y(),
                        plane.Location().Z())

    solids = iter_solids(split_result)
    if not solids:
        # Fallback: return whole result
        new_body = Body(split_result, name=name or body.name)
    else:
        # Pick the solid on the positive side
        best = None
        best_score = -float("inf")
        for s in solids:
            bb_min, bb_max = bounding_box(s)
            center = (bb_min + bb_max) * 0.5
            score = (center - plane_origin).dot(plane_normal)
            if score > best_score:
                best_score = score
                best = s
        new_body = Body(best, name=name or body.name)

    new_body._face_map = transfer_face_names(body._face_map, new_body.part, new_body)
    if body._color is not None:
        new_body.color = body._color
    return new_body


def mirror(body: Body, plane=None, name: str = "") -> Body:
    """Mirror a body about a plane.

    Args:
        body: the body to mirror
        plane: mirror plane as gp_Ax2, or None for YZ plane
        name: optional name
    """
    trsf = gp_Trsf()
    if plane is None:
        # Default: mirror about YZ plane (X=0)
        trsf.SetMirror(gp_Ax2(gp_Pnt(0, 0, 0), gp_Dir(1, 0, 0)))
    elif isinstance(plane, gp_Ax2):
        trsf.SetMirror(plane)
    elif isinstance(plane, gp_Pln):
        ax2 = gp_Ax2(plane.Location(), plane.Axis().Direction())
        trsf.SetMirror(ax2)
    else:
        trsf.SetMirror(plane)

    result = move_shape(body.part, trsf)
    new_body = Body(result, name=name or body.name)
    if body._color is not None:
        new_body.color = body._color
    return new_body


# --- Internal helpers ---

def _resolve_edges(edges) -> tuple[list, Body | None]:
    """Convert various edge representations to a list of TopoDS_Edge objects and parent body."""
    parent_body = None

    if isinstance(edges, EdgeRef):
        parent_body = edges._body
        return [edges._edge], parent_body

    if isinstance(edges, list):
        result = []
        for e in edges:
            if isinstance(e, EdgeRef):
                result.append(e._edge)
                if parent_body is None:
                    parent_body = e._body
        return result, parent_body

    # EdgeCollection
    if hasattr(edges, '_body'):
        parent_body = edges._body
        return [e._edge for e in edges], parent_body

    return [], None


def _name_cap_faces(body: Body, original_face: TopoDS_Face, amount: float, normal: Vec3):
    """Name the start and end cap faces of an extrusion."""
    fc = face_center(original_face)
    end_c = fc + normal * amount

    for f in iter_faces(body.part):
        c = face_center(f)
        n = face_normal(f)

        # Start cap: near the original face position, normal opposite to extrusion
        if (c - fc).length < 0.1 and n.dot(normal) < -0.9:
            body._face_map["_start"] = FaceRef(f, body, "_start")

        # End cap: at the far end, normal aligned with extrusion
        if (c - end_c).length < 0.1 and n.dot(normal) > 0.9:
            body._face_map["_end"] = FaceRef(f, body, "_end")


def _name_extrusion_features(body: Body, original_face: TopoDS_Face, name: str):
    """Name hole-specific features (wall) for circular extrusions."""
    # Check if the original sketch face's edges form a circle
    face_edges = iter_edges(original_face)
    if len(face_edges) == 1:
        gt = edge_geom_type(face_edges[0])
        if gt == GeomAbs_Circle:
            for f in iter_faces(body.part):
                if face_geom_type(f) == GeomAbs_Cylinder:
                    body._face_map["wall"] = FaceRef(f, body, "wall")
                    break


def _assign_standard_faces(body: Body):
    """Assign standard face names (top/bottom/front/back/left/right) by normals.

    Only assigns names that are not already taken.
    """
    _STANDARD = {
        "top":    (Vec3(0, 0, 1),  "Z", 1),
        "bottom": (Vec3(0, 0, -1), "Z", -1),
        "front":  (Vec3(0, -1, 0), "Y", -1),
        "back":   (Vec3(0, 1, 0),  "Y", 1),
        "right":  (Vec3(1, 0, 0),  "X", 1),
        "left":   (Vec3(-1, 0, 0), "X", -1),
    }

    for fname, (expected_normal, axis_name, sign) in _STANDARD.items():
        if fname in body._face_map:
            continue

        candidates = []
        for f in iter_faces(body.part):
            n = face_normal(f)
            if n.dot(expected_normal) > 0.9:
                c = face_center(f)
                val = getattr(c, axis_name)
                candidates.append((f, val))

        if candidates:
            if sign > 0:
                best = max(candidates, key=lambda x: x[1])
            else:
                best = min(candidates, key=lambda x: x[1])
            axes = get_standard_axes(fname)
            body._face_map[fname] = FaceRef(best[0], body, fname, x_dir=axes[0], y_dir=axes[1])


def _detect_inner_outer(old_body: Body, new_body: Body, thickness: float):
    """Detect inner/outer face pairs after shelling."""
    for name, old_ref in list(old_body._face_map.items()):
        if name not in new_body._face_map:
            continue

        outer_ref = new_body._face_map[name]
        old_center = face_center(old_ref._face)
        old_normal = face_normal(old_ref._face)

        # Look for the inner face: same-ish orientation but offset inward
        inner_center = old_center - old_normal * thickness

        for f in iter_faces(new_body.part):
            fc = face_center(f)
            if (fc - inner_center).length < thickness * 0.6:
                if not fc == face_center(outer_ref._face):
                    inner_ref = FaceRef(f, new_body, f"{name}_inner",
                                        x_dir=old_ref._x_dir, y_dir=old_ref._y_dir)
                    outer_ref._inner = inner_ref
                    outer_ref._outer = outer_ref
                    inner_ref._inner = inner_ref
                    inner_ref._outer = outer_ref
                    break
