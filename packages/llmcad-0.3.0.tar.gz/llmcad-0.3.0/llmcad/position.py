"""Position: a 3D point with face-local offset capabilities."""

from __future__ import annotations
from typing import TYPE_CHECKING

from ._vec import Vec3

if TYPE_CHECKING:
    from .face import FaceRef


class Position:
    """A 3D point that knows which face it belongs to, enabling face-local offsets.

    When a Position is associated with a FaceRef, offset(dx, dy) moves in the
    face's local coordinate system (dx = rightward, dy = upward on that face).
    """

    def __init__(self, point: Vec3, face_ref: FaceRef | None = None):
        self._point = point
        self._face_ref = face_ref

    @property
    def x(self) -> float:
        return self._point.X

    @property
    def y(self) -> float:
        return self._point.Y

    @property
    def z(self) -> float:
        return self._point.Z

    @property
    def vec(self) -> Vec3:
        return self._point

    def offset(self, dx: float = 0, dy: float = 0, dz: float = 0) -> Position:
        """Offset in face-local coords (dx=right, dy=up, dz=normal) or global if no face."""
        if self._face_ref is not None and (dx != 0 or dy != 0 or dz != 0):
            x_dir = self._face_ref._x_dir
            y_dir = self._face_ref._y_dir
            z_dir = self._face_ref.normal
            world_offset = x_dir * dx + y_dir * dy + z_dir * dz
            return Position(self._point + world_offset, self._face_ref)
        else:
            return Position(self._point + Vec3(dx, dy, dz), self._face_ref)

    def inset(self, dx: float, dy: float) -> Position:
        """Inset from a corner position toward the face center.

        The sign is automatic: moves toward the center regardless of which corner.
        """
        if self._face_ref is None:
            return self.offset(dx=dx, dy=dy)

        from ._ocp_helpers import face_center
        center = face_center(self._face_ref._face)
        x_dir = self._face_ref._x_dir
        y_dir = self._face_ref._y_dir

        to_center = center - self._point
        sign_x = 1.0 if to_center.dot(x_dir) > 0 else -1.0
        sign_y = 1.0 if to_center.dot(y_dir) > 0 else -1.0

        world_offset = x_dir * (dx * sign_x) + y_dir * (dy * sign_y)
        return Position(self._point + world_offset, self._face_ref)

    def projected_onto(self, face_ref: FaceRef) -> Position:
        """Project this 3D point onto another face's plane."""
        from ._ocp_helpers import face_center as _face_center
        normal = face_ref.normal
        fc = _face_center(face_ref._face)
        diff = self._point - fc
        dist = diff.dot(normal)
        projected = self._point - normal * dist
        return Position(projected, face_ref)

    def distance_to(self, other: Position) -> float:
        """Euclidean distance to another position."""
        return (self._point - other._point).length

    def __repr__(self) -> str:
        p = self._point
        face_name = self._face_ref._name if self._face_ref else "global"
        return f"Position({p.X:.2f}, {p.Y:.2f}, {p.Z:.2f}, face={face_name})"
