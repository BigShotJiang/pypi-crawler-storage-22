"""Shape primitives: Box, Cylinder, Sphere."""

from __future__ import annotations

from OCP.gp import gp_Pnt, gp_Dir, gp_Ax2
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox, BRepPrimAPI_MakeCylinder, BRepPrimAPI_MakeSphere

from .body import Body
from ._naming import name_box_faces, name_cylinder_faces, name_sphere_faces


def Box(width: float, length: float, height: float, name: str = "",
        color: str | tuple | None = None) -> Body:
    """Create a rectangular box centered at origin.

    Args:
        width: extent along X axis
        length: extent along Y axis
        height: extent along Z axis
        name: optional name for the body
        color: optional color (name like "red", or (r,g,b) tuple 0-1)

    Faces: top, bottom, front, back, left, right
    """
    # Center the box: place corner at (-w/2, -l/2, -h/2)
    ax2 = gp_Ax2(gp_Pnt(-width / 2, -length / 2, -height / 2), gp_Dir(0, 0, 1))
    shape = BRepPrimAPI_MakeBox(ax2, width, length, height).Shape()
    body = Body(shape, name=name or "box")
    body._face_map = name_box_faces(shape, body)
    if color is not None:
        body.color = color
    return body


def Cylinder(diameter: float, height: float, name: str = "",
             color: str | tuple | None = None) -> Body:
    """Create a cylinder centered at origin, axis along Z.

    Args:
        diameter: cylinder diameter (NOT radius)
        height: extent along Z axis
        name: optional name for the body
        color: optional color

    Faces: top, bottom, wall
    """
    radius = diameter / 2
    # Center the cylinder: place base at z = -h/2
    ax2 = gp_Ax2(gp_Pnt(0, 0, -height / 2), gp_Dir(0, 0, 1))
    shape = BRepPrimAPI_MakeCylinder(ax2, radius, height).Shape()
    body = Body(shape, name=name or "cylinder")
    body._face_map = name_cylinder_faces(shape, body)
    if color is not None:
        body.color = color
    return body


def Sphere(diameter: float, name: str = "",
           color: str | tuple | None = None) -> Body:
    """Create a sphere centered at origin.

    Args:
        diameter: sphere diameter (NOT radius)
        name: optional name for the body
        color: optional color

    Faces: surface
    """
    radius = diameter / 2
    shape = BRepPrimAPI_MakeSphere(radius).Shape()
    body = Body(shape, name=name or "sphere")
    body._face_map = name_sphere_faces(shape, body)
    if color is not None:
        body.color = color
    return body
