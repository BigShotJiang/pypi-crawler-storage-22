"""2D sketch primitives and placement."""

from __future__ import annotations
from typing import TYPE_CHECKING

from math import pi, cos, sin, atan2

from OCP.gp import gp_Pnt, gp_Dir, gp_Ax2, gp_Ax3, gp_Circ, gp_Elips, gp_Trsf, gp_Vec
from OCP.TopoDS import TopoDS, TopoDS_Face, TopoDS_Wire, TopoDS_Compound
from OCP.BRepBuilderAPI import (
    BRepBuilderAPI_MakeEdge, BRepBuilderAPI_MakeWire,
    BRepBuilderAPI_MakeFace, BRepBuilderAPI_Transform,
)
from OCP.GCE2d import GCE2d_MakeArcOfCircle
from OCP.BRep import BRep_Builder

from ._vec import Vec3
from .position import Position

if TYPE_CHECKING:
    from .face import FaceRef


class PlacedSketch:
    """A 2D sketch that has been positioned on a 3D face.

    Ready to be passed to extrude(), revolve(), etc.
    """

    def __init__(self, face: TopoDS_Face, host_face: FaceRef | None,
                 edge_names: dict | None = None):
        self._face = face
        self._host_face = host_face
        self._edge_names = edge_names or {}

    @property
    def normal(self) -> Vec3:
        """Normal direction (extrusion direction)."""
        if self._host_face:
            return self._host_face.normal
        return Vec3(0, 0, 1)


class SketchPrimitive:
    """Base class for simple sketch shapes (Rect, Circle, etc.)."""

    def __init__(self):
        self._face: TopoDS_Face = None
        self._edge_names: dict = {}

    def place_on(self, face_ref: FaceRef, at: Position = None) -> PlacedSketch:
        """Place this sketch on a face at a position.

        If `at` is None, places at the face center.
        """
        if at is None:
            at = face_ref.center

        target = at.vec
        normal = face_ref.normal
        x_dir = face_ref._x_dir

        # Build transform from XY plane to face's local frame
        trsf = _make_placement_transform(target, x_dir, normal)
        placed_face = BRepBuilderAPI_Transform(self._face, trsf, True).Shape()
        from OCP.TopoDS import TopoDS
        placed_face = TopoDS.Face_s(placed_face)

        return PlacedSketch(placed_face, face_ref, self._edge_names)

    def place_at(self, origin: tuple | Position, x_dir: tuple = None,
                 normal: tuple = None) -> PlacedSketch:
        """Place this sketch at a specific position and orientation in 3D space."""
        if isinstance(origin, Position):
            org = origin.vec
        else:
            org = Vec3(*origin)

        if normal is None:
            normal = (0, 0, 1)
        z = Vec3(*normal)
        if x_dir is None:
            if abs(z.Z) > 0.9:
                x = Vec3(1, 0, 0)
            else:
                x = Vec3(0, 0, 1).cross(z).normalized()
        else:
            x = Vec3(*x_dir)

        trsf = _make_placement_transform(org, x, z)
        placed_face = BRepBuilderAPI_Transform(self._face, trsf, True).Shape()
        from OCP.TopoDS import TopoDS
        placed_face = TopoDS.Face_s(placed_face)

        return PlacedSketch(placed_face, None, self._edge_names)

    def to_placed_sketch(self) -> PlacedSketch:
        """Convert to PlacedSketch on XY plane (for direct extrusion)."""
        return PlacedSketch(self._face, None, self._edge_names)


def Rect(width: float, height: float) -> SketchPrimitive:
    """Create a rectangular sketch centered at origin on XY plane."""
    sk = SketchPrimitive()
    hw, hh = width / 2, height / 2
    pts = [
        gp_Pnt(-hw, -hh, 0), gp_Pnt(hw, -hh, 0),
        gp_Pnt(hw, hh, 0), gp_Pnt(-hw, hh, 0),
    ]
    wire_builder = BRepBuilderAPI_MakeWire()
    for i in range(4):
        edge = BRepBuilderAPI_MakeEdge(pts[i], pts[(i + 1) % 4]).Edge()
        wire_builder.Add(edge)
    wire = wire_builder.Wire()
    sk._face = BRepBuilderAPI_MakeFace(wire).Face()
    return sk


def Circle(diameter: float) -> SketchPrimitive:
    """Create a circular sketch centered at origin on XY plane.

    Args:
        diameter: circle diameter (NOT radius)
    """
    sk = SketchPrimitive()
    circ = gp_Circ(gp_Ax2(), diameter / 2)
    edge = BRepBuilderAPI_MakeEdge(circ).Edge()
    wire = BRepBuilderAPI_MakeWire(edge).Wire()
    sk._face = BRepBuilderAPI_MakeFace(wire).Face()
    return sk


def Ellipse(width: float, height: float) -> SketchPrimitive:
    """Create an elliptical sketch centered at origin on XY plane.

    Args:
        width: full width (major or minor axis diameter)
        height: full height (major or minor axis diameter)
    """
    sk = SketchPrimitive()
    # gp_Elips requires major >= minor
    a, b = width / 2, height / 2
    if a >= b:
        elips = gp_Elips(gp_Ax2(), a, b)
    else:
        # Swap axes: rotate 90 degrees so major axis is along Y
        ax = gp_Ax2(gp_Pnt(0, 0, 0), gp_Dir(0, 0, 1), gp_Dir(0, 1, 0))
        elips = gp_Elips(ax, b, a)
    edge = BRepBuilderAPI_MakeEdge(elips).Edge()
    wire = BRepBuilderAPI_MakeWire(edge).Wire()
    sk._face = BRepBuilderAPI_MakeFace(wire).Face()
    return sk


def Polygon(points: list[tuple]) -> SketchPrimitive:
    """Create a polygonal sketch from a list of (x, y) points on XY plane.

    Args:
        points: list of (x, y) tuples defining polygon vertices (closed automatically)
    """
    sk = SketchPrimitive()
    n = len(points)
    if n < 3:
        raise ValueError("Polygon requires at least 3 points")
    pts = [gp_Pnt(p[0], p[1], 0) for p in points]
    wire_builder = BRepBuilderAPI_MakeWire()
    for i in range(n):
        edge = BRepBuilderAPI_MakeEdge(pts[i], pts[(i + 1) % n]).Edge()
        wire_builder.Add(edge)
    wire = wire_builder.Wire()
    sk._face = BRepBuilderAPI_MakeFace(wire).Face()
    return sk


def Text(txt: str, size: float, font: str = "Arial") -> SketchPrimitive:
    """Create text as a sketch shape on XY plane.

    Args:
        txt: text string to render
        size: font size in model units
        font: font name (system font). Defaults to "Arial"
    """
    from OCP.Font import Font_FontMgr, Font_FA_Regular
    from OCP.TCollection import TCollection_AsciiString
    from OCP.StdPrs import StdPrs_BRepTextBuilder, StdPrs_BRepFont
    from OCP.NCollection import NCollection_Utf8String
    from OCP.Graphic3d import Graphic3d_HTA_CENTER, Graphic3d_VTA_CENTER

    sk = SketchPrimitive()

    manager = Font_FontMgr.GetInstance_s()
    system_font = manager.FindFont(
        TCollection_AsciiString(font), Font_FA_Regular
    )

    builder = StdPrs_BRepTextBuilder()
    brep_font = StdPrs_BRepFont(
        NCollection_Utf8String(system_font.FontName().ToCString()),
        Font_FA_Regular,
        float(size),
    )

    text_compound = builder.Perform(
        brep_font,
        NCollection_Utf8String(txt),
        gp_Ax3(),
        Graphic3d_HTA_CENTER,
        Graphic3d_VTA_CENTER,
    )

    # The result is a compound of faces (one per glyph)
    compound = TopoDS.Compound(text_compound)
    sk._face = compound  # Store as compound; extrude handles both
    return sk


class Sketch:
    """Turtle-style sketch builder.

    Build a 2D wire segment by segment, then close it into a face.
    Named segments become named faces after extrusion.

    Usage:
        s = Sketch()
        s.start(0, 0)
        s.line_to(10, 0, name="bottom")
        s.line_to(10, 5)
        s.arc_to(0, 5, radius=3)
        s.close(name="top")
        body = extrude(s, amount=2)
    """

    def __init__(self):
        self._edges = []
        self._edge_names: dict[str, object] = {}
        self._cursor = None

    def start(self, x: float, y: float) -> Sketch:
        """Set the starting point."""
        self._cursor = gp_Pnt(x, y, 0)
        self._start = gp_Pnt(x, y, 0)
        return self

    def line_to(self, x: float, y: float, name: str = None) -> Sketch:
        """Draw a line from current position to (x, y)."""
        target = gp_Pnt(x, y, 0)
        edge = BRepBuilderAPI_MakeEdge(self._cursor, target).Edge()
        self._edges.append(edge)
        if name:
            self._edge_names[name] = edge
        self._cursor = target
        return self

    def arc_to(self, x: float, y: float, radius: float = None,
               center: tuple = None, name: str = None) -> Sketch:
        """Draw an arc from current position to (x, y).

        Specify either radius (auto-compute center) or center point explicitly.
        """
        target = gp_Pnt(x, y, 0)

        if center is not None:
            # Arc through center point
            cp = gp_Pnt(center[0], center[1], 0)
            from OCP.GC import GC_MakeArcOfCircle
            arc = GC_MakeArcOfCircle(self._cursor, cp, target).Value()
            edge = BRepBuilderAPI_MakeEdge(arc).Edge()
        elif radius is not None:
            # Compute arc with given radius
            from OCP.GC import GC_MakeArcOfCircle
            # Use a midpoint approach: create arc through a midpoint
            mx = (self._cursor.X() + x) / 2
            my = (self._cursor.Y() + y) / 2
            dx = x - self._cursor.X()
            dy = y - self._cursor.Y()
            chord = (dx * dx + dy * dy) ** 0.5
            if abs(radius) < chord / 2:
                radius = chord / 2  # minimum radius
            h = (radius * radius - (chord / 2) ** 2) ** 0.5
            # Normal to chord
            nx, ny = -dy / chord, dx / chord
            if radius < 0:
                h = -h
            mid_pt = gp_Pnt(mx + nx * h, my + ny * h, 0)
            arc = GC_MakeArcOfCircle(self._cursor, mid_pt, target).Value()
            edge = BRepBuilderAPI_MakeEdge(arc).Edge()
        else:
            # Fallback: straight line
            edge = BRepBuilderAPI_MakeEdge(self._cursor, target).Edge()

        self._edges.append(edge)
        if name:
            self._edge_names[name] = edge
        self._cursor = target
        return self

    def close(self, name: str = None) -> Sketch:
        """Close the sketch by connecting back to the start point."""
        if self._cursor and self._start:
            # Check if already closed
            dist = ((self._cursor.X() - self._start.X()) ** 2 +
                    (self._cursor.Y() - self._start.Y()) ** 2) ** 0.5
            if dist > 1e-6:
                edge = BRepBuilderAPI_MakeEdge(self._cursor, self._start).Edge()
                self._edges.append(edge)
                if name:
                    self._edge_names[name] = edge
        return self

    def to_face(self) -> TopoDS_Face:
        """Build a face from the collected edges."""
        wire_builder = BRepBuilderAPI_MakeWire()
        for edge in self._edges:
            wire_builder.Add(edge)
        wire = wire_builder.Wire()
        return BRepBuilderAPI_MakeFace(wire).Face()

    def to_placed_sketch(self) -> PlacedSketch:
        """Convert to PlacedSketch on XY plane (for extrusion)."""
        return PlacedSketch(self.to_face(), None, self._edge_names)

    # Allow direct use in extrude() etc.
    @property
    def _face(self):
        return self.to_face()

    def place_on(self, face_ref, at=None) -> PlacedSketch:
        """Place this sketch on a face."""
        if at is None:
            at = face_ref.center
        target = at.vec
        normal = face_ref.normal
        x_dir = face_ref._x_dir
        trsf = _make_placement_transform(target, x_dir, normal)
        placed_face = BRepBuilderAPI_Transform(self.to_face(), trsf, True).Shape()
        placed_face = TopoDS.Face_s(placed_face)
        return PlacedSketch(placed_face, face_ref, self._edge_names)

    def place_at(self, origin, x_dir=None, normal=None) -> PlacedSketch:
        """Place this sketch at a position and orientation in 3D space."""
        if isinstance(origin, Position):
            org = origin.vec
        else:
            org = Vec3(*origin)
        if normal is None:
            normal = (0, 0, 1)
        z = Vec3(*normal)
        if x_dir is None:
            if abs(z.Z) > 0.9:
                x = Vec3(1, 0, 0)
            else:
                x = Vec3(0, 0, 1).cross(z).normalized()
        else:
            x = Vec3(*x_dir)
        trsf = _make_placement_transform(org, x, z)
        placed_face = BRepBuilderAPI_Transform(self.to_face(), trsf, True).Shape()
        placed_face = TopoDS.Face_s(placed_face)
        return PlacedSketch(placed_face, None, self._edge_names)


def _make_placement_transform(origin: Vec3, x_dir: Vec3, normal: Vec3) -> gp_Trsf:
    """Build a gp_Trsf that maps XY plane at origin (0,0,0) to
    a plane at `origin` with local X=x_dir, Z=normal."""
    # Y axis = normal cross x_dir
    y_dir = normal.cross(x_dir).normalized()
    # Ensure orthogonal
    x_dir = y_dir.cross(normal).normalized()

    trsf = gp_Trsf()
    # Set as a general transformation (rotation + translation)
    # The 3x3 rotation matrix columns are x_dir, y_dir, normal
    # gp_Trsf.SetValues(a11, a12, a13, a14, a21, a22, a23, a24, a31, a32, a33, a34)
    trsf.SetValues(
        x_dir.X, y_dir.X, normal.X, origin.X,
        x_dir.Y, y_dir.Y, normal.Y, origin.Y,
        x_dir.Z, y_dir.Z, normal.Z, origin.Z,
    )
    return trsf
