# %%
from llmcomp import Question, Config

MODELS = {
    "gpt-4.1-mini": ["gpt-4.1-mini-2025-04-14"],
    "gpt-4o-mini": ["gpt-4o-mini-2024-07-18"],
}

# %%
x = Config.client_for_model("gpt-4.1-mini-2025-04-14")
print(x.base_url)