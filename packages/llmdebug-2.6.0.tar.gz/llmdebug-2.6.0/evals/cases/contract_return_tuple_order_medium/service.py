def fetch_status_payload() -> tuple[str, dict[str, int]]:
    return ("ok", {"count": 2})
