def get_timeout_ms() -> int:
    return 250
