import mathh


def square_root(value: float) -> float:
    return mathh.sqrt(value)
