def last_item(values: list[int]) -> int:
    return values[len(values)]
