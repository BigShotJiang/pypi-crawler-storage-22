def read_port(config: dict[str, int]) -> int:
    return config["prt"]
