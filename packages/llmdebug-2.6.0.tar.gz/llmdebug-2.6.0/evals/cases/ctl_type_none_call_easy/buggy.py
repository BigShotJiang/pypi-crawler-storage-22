def invoke(callback=None) -> str:
    return callback()
