def test_syntax():
    import buggy  # noqa: F401
