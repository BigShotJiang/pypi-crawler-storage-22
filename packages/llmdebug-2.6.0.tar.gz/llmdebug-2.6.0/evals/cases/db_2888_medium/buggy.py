class Solution:
    def lexicalOrder(self, n: int) -> list[int]:
        lst = [str(i) for i in range(1, n)]
        lst.sort()
        return [int(i) for i in lst]
