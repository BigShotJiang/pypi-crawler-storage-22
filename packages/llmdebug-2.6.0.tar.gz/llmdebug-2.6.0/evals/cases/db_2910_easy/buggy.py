class Solution:
    def minimumDifference(self, nums: list[int], k: int) -> int:
        # sliding window
        nums.sort()
        l, r = 0, k - 1
        res = float("inf")
        while r < len(nums):
            res = Math.min(res, nums[r] - nums[l])
            r += 1
            l += 1
        return res
