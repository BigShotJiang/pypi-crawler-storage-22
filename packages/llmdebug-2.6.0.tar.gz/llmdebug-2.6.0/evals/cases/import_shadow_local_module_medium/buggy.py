import statistics


def median_value(values: list[int]) -> float:
    return float(statistics.median(values))
