def append_event(value: str, events: list[str] = []) -> list[str]:
    events.append(value)
    return events
