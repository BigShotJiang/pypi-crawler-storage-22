def parse_amount(raw: str) -> float:
    return float(raw)
