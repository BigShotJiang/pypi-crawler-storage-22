def compute_average(values: list[int]) -> float:
    total = sum(values)
    count = len(values)
    return total // count
