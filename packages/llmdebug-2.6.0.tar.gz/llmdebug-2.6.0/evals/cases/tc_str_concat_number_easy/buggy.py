def format_receipt_line(item: str, price: float) -> str:
    return item + ": $" + price
