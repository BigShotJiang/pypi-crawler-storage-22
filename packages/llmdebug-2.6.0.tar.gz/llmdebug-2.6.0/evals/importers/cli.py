"""CLI entry point for all dataset importers.

Usage:
    python -m evals.importers.cli debugbench --max-cases 40 --validate
    python -m evals.importers.cli humanevalpack --max-cases 20 --validate
    python -m evals.importers.cli condefects --repo-path /path/to/ConDefects --max-cases 15
    python -m evals.importers.cli mutmut --target src/llmdebug --max-cases 30
    python -m evals.importers.cli debugbench --max-cases 5 --dry-run
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Import external dataset cases into the llmdebug framework."
    )
    sub = parser.add_subparsers(dest="source", help="Dataset source to import from.")

    # DebugBench
    db = sub.add_parser("debugbench", help="Import from DebugBench (HuggingFace).")
    db.add_argument("--max-cases", type=int, default=0, help="Max cases to import (0 = unlimited).")
    db.add_argument("--output-dir", default="evals/cases")
    db.add_argument("--validate", action="store_true")
    db.add_argument("--dry-run", action="store_true")

    # HumanEvalPack
    hep = sub.add_parser("humanevalpack", help="Import from HumanEvalPack (HuggingFace).")
    hep.add_argument("--max-cases", type=int, default=20)
    hep.add_argument("--output-dir", default="evals/cases")
    hep.add_argument("--validate", action="store_true")
    hep.add_argument("--dry-run", action="store_true")

    # ConDefects
    cd = sub.add_parser("condefects", help="Import from ConDefects (local clone).")
    cd.add_argument("--repo-path", required=True, help="Path to cloned ConDefects repo.")
    cd.add_argument("--max-cases", type=int, default=0, help="Max cases to import (0 = unlimited).")
    cd.add_argument("--output-dir", default="evals/cases")
    cd.add_argument("--validate", action="store_true")
    cd.add_argument("--dry-run", action="store_true")

    # mutmut
    mm = sub.add_parser("mutmut", help="Generate cases from mutmut mutations.")
    mm.add_argument("--target", required=True, help="Python module/package to mutate.")
    mm.add_argument("--max-cases", type=int, default=30)
    mm.add_argument("--output-dir", default="evals/cases")
    mm.add_argument("--validate", action="store_true")
    mm.add_argument("--dry-run", action="store_true")

    args = parser.parse_args(argv)

    if not args.source:
        parser.print_help()
        return 2

    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = Path.cwd() / output_dir

    if args.source == "debugbench":
        from evals.importers.debugbench_importer import import_debugbench

        results = import_debugbench(
            output_dir,
            max_cases=args.max_cases,
            validate=args.validate,
            dry_run=args.dry_run,
        )

    elif args.source == "humanevalpack":
        from evals.importers.humanevalpack_importer import import_humanevalpack

        results = import_humanevalpack(
            output_dir,
            max_cases=args.max_cases,
            validate=args.validate,
            dry_run=args.dry_run,
        )

    elif args.source == "condefects":
        from evals.importers.condefects_importer import import_condefects

        results = import_condefects(
            output_dir,
            repo_path=Path(args.repo_path),
            max_cases=args.max_cases,
            validate=args.validate,
            dry_run=args.dry_run,
        )

    elif args.source == "mutmut":
        from evals.importers.mutmut_generator import import_mutmut

        results = import_mutmut(
            output_dir,
            target=args.target,
            max_cases=args.max_cases,
            validate=args.validate,
            dry_run=args.dry_run,
        )

    else:
        print(f"Unknown source: {args.source}")
        return 2

    mode = "previewed" if args.dry_run else "imported"
    print(f"\n{len(results)} case(s) {mode} from {args.source}.")

    if args.dry_run and results:
        print("\nPreview:")
        for r in results[:5]:
            print(f"  {r['case_id']}: {json.dumps(r.get('metadata', {}), indent=None)[:120]}...")
        if len(results) > 5:
            print(f"  ... and {len(results) - 5} more")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
