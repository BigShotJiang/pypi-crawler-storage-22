"""Patcher interface for eval harness.

A patcher receives a prompt (plus a context directory path) and returns a single
unified diff that can be applied with `git apply`.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class PatchResult:
    diff: str | None
    meta: dict[str, object] | None = None


class Patcher:
    name: str

    def propose_patch(self, *, prompt: str, context_dir: Path, cwd: Path) -> PatchResult:
        raise NotImplementedError
