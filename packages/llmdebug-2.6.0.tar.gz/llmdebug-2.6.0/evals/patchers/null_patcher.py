from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .base import Patcher, PatchResult


@dataclass(frozen=True)
class NullPatcher(Patcher):
    name: str = "null"

    def propose_patch(self, *, prompt: str, context_dir: Path, cwd: Path) -> PatchResult:
        return PatchResult(diff=None, meta={"reason": "null_patcher"})
