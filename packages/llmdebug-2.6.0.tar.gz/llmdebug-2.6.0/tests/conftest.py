"""Shared test fixtures and helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from llmdebug.output import get_latest_snapshot


def read_latest_snapshot(out_dir: Path) -> dict[str, Any]:
    """Read the latest snapshot, auto-expanding compact keys.

    Raises AssertionError if no snapshot exists in the directory.
    """
    snapshot = get_latest_snapshot(str(out_dir))
    assert snapshot is not None, f"No snapshot in {out_dir}"
    return snapshot
