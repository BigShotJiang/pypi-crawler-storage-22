"""Tests for evals.importers.mutmut_generator — mutmut case generation.

Mocks mutmut subprocess output to test filtering and category assignment.
"""

from __future__ import annotations

from evals.importers.mutmut_generator import (
    _infer_operator_type,
    _parse_mutmut_results,
)

# ---------------------------------------------------------------------------
# Operator type inference
# ---------------------------------------------------------------------------


class TestInferOperatorType:
    def test_arithmetic_operator(self) -> None:
        diff = "-    result = a + b\n+    result = a - b\n"
        assert _infer_operator_type(diff) in ("arithmetic", "comparison", "keyword")

    def test_comparison_operator(self) -> None:
        diff = "-    if x == 0:\n+    if x != 0:\n"
        assert _infer_operator_type(diff) == "comparison"

    def test_boolean_operator(self) -> None:
        diff = "-    return True\n+    return False\n"
        assert _infer_operator_type(diff) == "boolean"

    def test_return_change(self) -> None:
        diff = "-    return result\n+    return None\n"
        assert _infer_operator_type(diff) == "changed_return"

    def test_removed_call(self) -> None:
        diff = "-    process(data)\n+    pass\n"
        assert _infer_operator_type(diff) == "removed_call"

    def test_empty_diff(self) -> None:
        assert _infer_operator_type("") == "keyword"

    def test_unknown_pattern(self) -> None:
        diff = "-    x = 'hello'\n+    x = 'world'\n"
        # String mutations or generic keyword
        result = _infer_operator_type(diff)
        assert result in ("keyword", "boolean", "comparison", "arithmetic", "string")


# ---------------------------------------------------------------------------
# Results parsing
# ---------------------------------------------------------------------------


class TestParseMutmutResults:
    def test_parse_basic_output(self) -> None:
        output = "1  survived\n2  killed\n3  suspicious\n"
        result = _parse_mutmut_results(output)
        assert len(result) == 3
        assert result[0]["id"] == "1"
        assert result[0]["status"] == "survived"
        assert result[1]["status"] == "killed"

    def test_empty_output(self) -> None:
        assert _parse_mutmut_results("") == []

    def test_skip_non_matching_lines(self) -> None:
        output = "Running mutmut...\n1  survived\nDone.\n"
        result = _parse_mutmut_results(output)
        assert len(result) == 1
        assert result[0]["id"] == "1"


# ---------------------------------------------------------------------------
# Dry run
# ---------------------------------------------------------------------------


class TestMutmutDryRun:
    def test_dry_run_returns_preview(self) -> None:
        import tempfile
        from pathlib import Path

        from evals.importers.mutmut_generator import import_mutmut

        with tempfile.TemporaryDirectory() as tmp:
            result = import_mutmut(
                Path(tmp),
                target="src/llmdebug/capture.py",
                max_cases=5,
                dry_run=True,
            )
        assert len(result) == 1
        assert result[0]["metadata"]["bug_source"] == "mutmut"
        assert result[0]["metadata"]["contamination_risk"] == "none"
