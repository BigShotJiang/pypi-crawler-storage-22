"""Tests for RCA verification gate behavior."""

from __future__ import annotations

from llmdebug.gates import evaluate_gate


def test_soft_mode_warns_but_allows_missing_requirements() -> None:
    feedback = evaluate_gate(
        mode="soft",
        current_state="captured",
        action="plan",
        payload={
            "evidence_refs": [],
            "hypothesis": "",
            "experiment_plan": "",
        },
    )
    assert feedback.allowed is True
    assert feedback.severity == "warning"
    assert "evidence_required" in feedback.triggered_checks
    assert "hypothesis_required" in feedback.triggered_checks


def test_strict_mode_blocks_missing_requirements() -> None:
    feedback = evaluate_gate(
        mode="strict",
        current_state="captured",
        action="change",
        payload={
            "evidence_refs": [],
            "hypothesis": "",
            "experiment_plan": "",
        },
    )
    assert feedback.allowed is False
    assert feedback.severity == "error"
    assert "evidence_required" in feedback.triggered_checks
    assert "hypothesis_required" in feedback.triggered_checks


def test_strict_mode_exploratory_override_allows() -> None:
    feedback = evaluate_gate(
        mode="strict",
        current_state="captured",
        action="change",
        payload={
            "evidence_refs": [],
            "hypothesis": "",
            "experiment_plan": "",
            "exploratory": True,
            "override_reason": "Need a probe to inspect runtime branch.",
        },
    )
    assert feedback.allowed is True
    assert feedback.severity == "warning"
    assert any("override accepted" in warning.lower() for warning in feedback.warnings)


def test_loop_protection_warning_after_repeats() -> None:
    feedback = evaluate_gate(
        mode="soft",
        current_state="changed",
        action="change",
        payload={
            "evidence_refs": ["crash_frame:app.py:42:parse_input"],
            "hypothesis": "Input parsing fails on non-digit value.",
            "experiment_plan": "Guard int conversion with try/except.",
            "hypothesis_advanced": False,
        },
        repeated_signature_count=4,
        exploration_budget=2,
    )
    assert feedback.allowed is True
    assert "loop_protection" in feedback.triggered_checks
    assert any("repeated" in warning.lower() for warning in feedback.warnings)
