import re
import warnings
import os
from LLMFunctionObjects.Configuration import Configuration
from LLMFunctionObjects.Evaluator import Evaluator
from LLMFunctionObjects.EvaluatorChat import EvaluatorChat
from LLMFunctionObjects.EvaluatorChatGPT import EvaluatorChatGPT
from LLMFunctionObjects.EvaluatorChatGemini import EvaluatorChatGemini
from LLMFunctionObjects.EvaluatorGemini import EvaluatorGemini
from LLMFunctionObjects.EvaluatorChatOllama import EvaluatorChatOllama
from LLMFunctionObjects.EvaluatorOllama import EvaluatorOllama
from LLMFunctionObjects.Functor import Functor
from LLMFunctionObjects.Chat import Chat
import openai
import google.generativeai as genai


# ===========================================================
# Configuration creation
# ===========================================================
def llm_configuration(spec, **kwargs):
    if spec is None:
        return llm_configuration('chatgpt', **kwargs)
    elif isinstance(spec, Configuration):
        return spec.combine(kwargs)
    elif isinstance(spec, Evaluator):
        return llm_configuration(spec.conf, **kwargs)
    elif isinstance(spec, str) and spec.lower() == 'OpenAI'.lower():
        confOpenAI = Configuration(
            name="openai",
            api_key=None,
            api_user_id='user',
            module='openai',
            model='gpt-3.5-turbo-instruct',  # was 'text-davinci-003'
            function=openai.completions.create,  # was openai.Completion.create
            temperature=0.2,
            max_tokens=300,
            total_probability_cutoff=0.03,
            prompts=None,
            prompt_delimiter=' ',
            stop_tokens=None,
            argument_renames={"stop_tokens": "stop"},
            fmt='values',
            known_params=["model", "prompt", "suffix", "max_tokens", "temperature", "top_p", "n", "stream",
                          "logprobs", "stop", "presence_penalty", "frequency_penalty", "best_of", "logit_bias",
                          "user"],
            response_value_keys=["choices", 0, "text"],
            llm_evaluator=None)
        if len(kwargs) > 0:
            confOpenAI = confOpenAI.combine(kwargs)
        return confOpenAI
    elif isinstance(spec, str) and spec.lower() == 'ChatGPT'.lower():

        # Client and key
        apiKey = os.environ.get("OPENAI_API_KEY")
        apiKey = kwargs.get("api_key", apiKey)
        client = openai.OpenAI(api_key=apiKey)

        default_chat_model = os.environ.get("OPENAI_CHAT_MODEL", os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"))

        confChatGPT = llm_configuration("openai",
                                        name="chatgpt",
                                        module='openai',
                                        model=default_chat_model,
                                        function=client.chat.completions.create,  # was openai.ChatCompletion.create,
                                        argument_renames={"max_tokens": "max_completion_tokens"},
                                        known_params=["model", "messages", "functions", "function_call",
                                                      "tools", "tool_choice", "response_format",
                                                      "temperature", "top_p", "n", "seed",
                                                      "stream", "logprobs", "stop",
                                                      "presence_penalty", "frequency_penalty", "logit_bias",
                                                      "max_completion_tokens",
                                                      "max_tokens",
                                                      "user"],
                                        response_value_keys=[])

        if len(kwargs) > 0:
            confChatGPT = confChatGPT.combine(kwargs)

        # Evaluator class
        confChatGPT.llm_evaluator = None

        return confChatGPT
    elif isinstance(spec, str) and spec.lower() == 'Gemini'.lower():

        # Set key
        apiKey = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY"))
        apiKey = kwargs.get("api_key", apiKey)
        genai.configure(api_key=apiKey)

        default_gemini_model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

        confGemini = Configuration(
            name="gemini",
            api_key=None,
            api_user_id="user",
            module="google.generativeai",
            model=default_gemini_model,
            function=None,
            temperature=0.2,
            max_tokens=300,
            total_probability_cutoff=0.03,
            prompts=None,
            prompt_delimiter=" ",
            stop_tokens=None,
            argument_renames={},
            fmt="values",
            known_params=[
                "model", "generation_config", "safety_settings", "tools", "tool_config",
                "stream", "request_options", "system_instruction"
            ],
            response_object_attribute=None,
            response_value_keys=[],
            llm_evaluator=None)

        if len(kwargs) > 0:
            confGemini = confGemini.combine(kwargs)
        return confGemini

    elif isinstance(spec, str) and spec.lower() == 'ChatGemini'.lower():

        confChatGemini = llm_configuration("Gemini")
        confChatGemini.name = "chatgemini"

        if len(kwargs) > 0:
            confChatGemini = confChatGemini.combine(kwargs)

        return confChatGemini

    elif isinstance(spec, str) and spec.lower() == 'PaLM'.lower():
        warnings.warn("PaLM is deprecated; using Gemini instead.", DeprecationWarning)
        return llm_configuration('Gemini', **kwargs)

    elif isinstance(spec, str) and spec.lower() == 'ChatPaLM'.lower():
        warnings.warn("ChatPaLM is deprecated; using ChatGemini instead.", DeprecationWarning)
        return llm_configuration('ChatGemini', **kwargs)

    elif isinstance(spec, str) and spec.lower() == 'Ollama'.lower():
        default_ollama_model = os.environ.get("OLLAMA_MODEL", "llama3.2")

        confOllama = Configuration(
            name="ollama",
            api_key=None,
            api_user_id="user",
            module="ollama",
            model=default_ollama_model,
            function=None,
            temperature=0.2,
            max_tokens=300,
            total_probability_cutoff=0.03,
            prompts=None,
            prompt_delimiter=" ",
            stop_tokens=None,
            argument_renames={},
            fmt="values",
            known_params=[
                "model", "prompt", "system", "template", "context", "stream",
                "raw", "format", "options", "keep_alive"
            ],
            response_object_attribute=None,
            response_value_keys=[],
            llm_evaluator=None)

        if len(kwargs) > 0:
            confOllama = confOllama.combine(kwargs)
        return confOllama

    elif isinstance(spec, str) and spec.lower() == 'ChatOllama'.lower():
        confChatOllama = llm_configuration("Ollama")
        confChatOllama.name = "chatollama"
        confChatOllama.known_params = [
            "model", "messages", "tools", "stream", "format", "options", "keep_alive"
        ]
        if len(kwargs) > 0:
            confChatOllama = confChatOllama.combine(kwargs)
        return confChatOllama
    else:
        warnings.warn(f"Do not know what to do with given configuration spec: {spec}. Continuing with \"OpenAI\".")
        return llm_configuration('OpenAI', **kwargs)
    pass


# ===========================================================
# Evaluator creation
# ===========================================================
def llm_evaluator(spec, **args):
    # Default evaluator class
    evaluator_class = args.get('llm_evaluator_class', None)
    if evaluator_class is None:
        if isinstance(spec, Configuration):
            if spec.name.lower() == "ChatGPT".lower():
                evaluator_class = EvaluatorChatGPT
            elif spec.name.lower() == "OpenAI".lower():
                evaluator_class = Evaluator
            elif spec.name.lower() in ["Gemini".lower(), "PaLM".lower()]:
                evaluator_class = EvaluatorGemini
            elif spec.name.lower() in ["ChatGemini".lower(), "ChatPaLM".lower()]:
                evaluator_class = EvaluatorChatGemini
            elif spec.name.lower() == "Ollama".lower():
                evaluator_class = EvaluatorOllama
            elif spec.name.lower() == "ChatOllama".lower():
                evaluator_class = EvaluatorChatOllama
            else:
                raise ValueError(
                    'Cannot automatically deduce llm_evaluator_class from the given configuration object.')
        else:
            evaluator_class = EvaluatorChatGPT

    if not (evaluator_class is Evaluator or issubclass(evaluator_class, Evaluator)):
        raise ValueError(
            'The value of llm_evaluator_class is expected to be None or of type LLMFunctionObjects.Evaluator.')

    # Separate configuration from evaluator options
    attr_conf = list(llm_configuration('openai').to_dict().keys())
    args_conf = {k: v for k, v in args.items() if k in attr_conf}
    args_evlr = {k: v for k, v in args.items() if k not in args_conf and k not in ['llm_evaluator_class', 'form']}

    fd = {"formatron": args.get("formatron", args.get("form", None))}
    args_evlr = {**args_evlr, **fd}

    if spec is None:
        return evaluator_class(conf=llm_configuration(None, **args_conf), **args_evlr)
    elif isinstance(spec, str):
        return llm_evaluator(llm_configuration(spec), **args_evlr,
                             llm_evaluator_class=args.get('llm_evaluator_class', None))
    elif isinstance(spec, Configuration):
        conf = spec.copy()
        if spec.llm_evaluator is None:
            return evaluator_class(conf=spec, **args_evlr)
        else:
            if not isinstance(conf.llm_evaluator, Evaluator):
                raise TypeError(
                    'The configuration attribute evaluator is expected' +
                    ' to be of type LLMFunctionObjects.Evaluator or None.')
            conf.llm_evaluator.conf = conf
            return conf.llm_evaluator
    elif isinstance(spec, Evaluator):
        res = spec.copy()
        conf = spec.conf.copy()

        if 'conf' in args_evlr:
            conf = llm_configuration(conf, **args_evlr['conf'])

        if args_conf:
            conf = llm_configuration(conf, **args_conf)

        res.conf = conf

        # We are not overriding object's formatron in the specified formatron is None
        if 'formatron' in args_evlr and args_evlr['formatron'] is not None:
            res.formatron = args_evlr['formatron']

        return res

    else:
        warnings.warn(
            "The first argument is expected to be None, or one of the types str," +
            " LLMFunctionObjects.Evaluator, or LLMFunctionObjects.Configuration.")
        return llm_evaluator(None, **args_evlr)


# ===========================================================
# Function creation
# ===========================================================
def llm_function(prompt='', **kwargs):
    llm_evaluator_spec = kwargs.get("llm_evaluator", kwargs.get("e", None))
    formatron_spec = kwargs.get("formatron", kwargs.get("form", kwargs.get("f", None)))
    llmEvaluator = llm_evaluator(spec=llm_evaluator_spec, formatron=formatron_spec)
    return Functor(llmEvaluator, prompt)


# ===========================================================
# Example function creation
# ===========================================================

def llm_example_function(rules, hint=None, **kwargs):
    hintLocal = hint
    if hintLocal is None:
        hintLocal = ""

    if isinstance(rules, dict):
        pre = ""
        for (k, v) in rules.items():
            pre = f"Input: {k}\nOutput: {v}\n\n"

        if isinstance(hintLocal, str) and len(hintLocal) > 0:
            hint = hint if re.search(r'.*{Punct}$', hint) else hint + '.'
            pre = f"{hint}\n\n{pre}"
        prompt = lambda x: pre + f"\nInput {x}\nOutput:"

        return llm_function(prompt, **kwargs)

    elif isinstance(rules, tuple) and len(rules) == 2:
        return llm_example_function({rules[0]: rules[1]}, **kwargs)

    elif isinstance(rules, list) and all(isinstance(x, tuple) and len(x) == 2 for x in rules):
        return llm_example_function({x[0]: x[1] for x in rules}, **kwargs)

    else:
        TypeError("The first argument is expected to be a tuple, a list of tuples, or a dictionary.")


# ===========================================================
# LLM Synthesise
# ===========================================================

def llm_synthesize(prompts, prop=None, **kwargs):
    # Get evaluator spec
    evlrSpec = kwargs.get("llm_evaluator", kwargs.get("e", None))

    # Prompts processing
    promptsLocal = prompts
    if isinstance(promptsLocal, str):
        promptsLocal = [promptsLocal, ]

    if not isinstance(promptsLocal, list):
        TypeError("The first argument is expected to be a string or list of string.")

    # Process properties
    expected_props = ['FullText', 'CompletionText', 'PromptText']

    if prop is None:
        prop = 'CompletionText'
    if not (isinstance(prop, str) and prop in expected_props):
        raise ValueError(
            f"The value of the second argument is expected to be Whatever or one of: {', '.join(expected_props)}.")

    # Get evaluator
    kwargs2 = {k:v for k,v in kwargs.items() if k not in ["e", "llm_evaluator"]}
    evalObj = llm_evaluator(evlrSpec, **kwargs2)

    # Add configuration prompts
    promptsLocal = evalObj.conf.prompts + promptsLocal
    evalObj.conf.prompts = []

    # Reduce prompts
    processed = []
    for p in promptsLocal:
        if isinstance(p, str):
            processed.append(p)
        elif callable(p):
            try:
                pres = p()
            except Exception:
                pres = None

            if not pres is not None or not isinstance(pres, str):
                args = [''] * p.__code__.co_argcount  # Get the arity of the function
                pres = p(*args)

            processed.append(pres)
        else:
            processed.append(str(p))

    # Find the separator from the configuration
    sep = evalObj.conf.prompt_delimiter
    prompt_text = sep.join(processed)

    # Post process
    if prop == 'FullText':
        res = llm_function('', e=evalObj)(prompt_text)
        return processed + [res]
    elif prop == 'PromptText':
        return prompt_text
    else:
        return llm_function('', e=evalObj)(prompt_text)


# ===========================================================
# Chat object creation
# ===========================================================

_mustPassConfKeys = ["name", "model", "prompts", "examples", "temperature", "max_tokens",
                     "stop_tokens", "api_key", "api_user_id"]


def llm_chat(prompt: str = '', **kwargs):
    # Get evaluator spec
    spec = kwargs.get('llm_evaluator', kwargs.get('llm_configuration', kwargs.get('conf', None)))

    # Default evaluator class
    evaluator_class = kwargs.get('llm_evaluator_class', None)

    # Filter conf args
    conf_args = {k: v for k, v in kwargs.items() if k in list(llm_configuration(None).to_dict().keys())}

    if evaluator_class is not None and not isinstance(evaluator_class, EvaluatorChat):
        raise ValueError('The value of llm_evaluator_class is expected to be None or of the type EvaluatorChat.')

    # Make evaluator object
    if spec is None:
        # Make Configuration object
        conf = llm_configuration('ChatGPT', prompts=prompt, **conf_args)

        # Make Evaluator object
        llm_eval_obj = EvaluatorChatGPT(conf=conf, formatron=kwargs.get('form', kwargs.get('formatron')))

    elif isinstance(spec, Configuration) or isinstance(spec, Evaluator) or isinstance(spec, str):
        # Make Configuration object
        conf = llm_configuration(spec, prompts=prompt, **conf_args)

        # Obtain Evaluator class
        if evaluator_class is None:
            if 'gemini' in conf.name.lower() or 'palm' in conf.name.lower():
                conf = llm_configuration('ChatGemini',
                                         **{k: v for k, v in conf.to_dict().items() if k in _mustPassConfKeys})
                evaluator_class = EvaluatorChatGemini
            elif 'ollama' in conf.name.lower():
                conf = llm_configuration('ChatOllama',
                                         **{k: v for k, v in conf.to_dict().items() if k in _mustPassConfKeys})
                evaluator_class = EvaluatorChatOllama
            else:
                evaluator_class = EvaluatorChatGPT

        # Make Evaluator object
        llm_eval_obj = evaluator_class(conf=conf, formatron=kwargs.get('form', kwargs.get('formatron')))
    else:
        raise ValueError("Cannot obtain or make a LLM evaluator object with the given specs.")

    # Result
    args2 = {k: v for k, v in kwargs.items() if
             k not in ['llm_evaluator', 'llm_configuration', 'conf', 'prompt', 'form', 'formatron']}
    return Chat(llm_evaluator=llm_eval_obj, **args2)
