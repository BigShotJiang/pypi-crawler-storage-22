"""
Bedrock Auto-Instrumentation - Automatically capture model_id, prompts, and responses
Uses wrapt to patch botocore at the lowest level for automatic tracking
"""
import json
import io
import logging
import wrapt
from typing import Optional, Dict, Any
from contextvars import ContextVar
from botocore.response import StreamingBody

logger = logging.getLogger(__name__)

# Context variable to store captured model data for the current call
_bedrock_call_context: ContextVar[Optional[Dict[str, Any]]] = ContextVar('bedrock_call_context', default=None)

# Global flag to track if instrumentation is enabled
_instrumentation_enabled = False


def _serialize_bedrock_body(body: Any) -> Optional[Dict[str, Any]]:
    """
    Serialize Bedrock request body to JSON-safe dict format.
    Handles dict, string (JSON), and bytes formats.
    
    Args:
        body: Request body in any format (dict, string, bytes)
    
    Returns:
        Parsed dict or None if conversion fails
    """
    if body is None:
        return None
    
    if isinstance(body, dict):
        # Already a dict, return as-is
        return body
    
    if isinstance(body, str):
        # JSON string, parse it
        try:
            return json.loads(body)
        except Exception as e:
            logger.debug(f"Failed to parse request body string: {e}")
            return None
    
    if isinstance(body, bytes):
        # Bytes, decode and parse
        try:
            decoded = body.decode('utf-8')
            return json.loads(decoded)
        except Exception as e:
            logger.debug(f"Failed to decode/parse request body bytes: {e}")
            return None
    
    return None


def get_captured_model_data() -> Optional[Dict[str, Any]]:
    """
    Get the auto-captured model data from the current context.
    
    Returns:
        Dict with 'model_id', 'request_body', 'response_body' or None
    """
    return _bedrock_call_context.get()


def clear_captured_model_data():
    """Clear the captured model data from context."""
    _bedrock_call_context.set(None)


def _instrument_bedrock_call(wrapped, instance, args, kwargs):
    """
    Wrapper function that intercepts botocore._make_api_call
    Automatically captures model_id, request body, and response body
    """
    # Only process if instrumentation is enabled
    if not _instrumentation_enabled:
        return wrapped(*args, **kwargs)
    
    operation_name = args[0] if args else None
    
    # Only intercept Bedrock Runtime operations
    if instance.meta.service_model.service_name != 'bedrock-runtime':
        return wrapped(*args, **kwargs)
    
    # Only track InvokeModel operations (not streaming for now)
    if operation_name not in ['InvokeModel', 'Converse']:
        return wrapped(*args, **kwargs)
    
    try:
        # Extract request parameters
        params = kwargs.get('api_params', args[1] if len(args) > 1 else {})
        model_id = params.get('modelId')
        
        # Capture and serialize request body
        request_body = params.get('body')
        request_payload = _serialize_bedrock_body(request_body)
        
        # Capture inference parameters for modelParameters
        inference_config = params.get('inferenceConfig') or params.get('inference_config')
        additional_model_request_fields = params.get('additionalModelRequestFields') or params.get('additional_model_request_fields')
        if isinstance(request_payload, dict):
            if inference_config is None:
                inference_config = request_payload.get('inferenceConfig') or request_payload.get('inference_config')
            if additional_model_request_fields is None:
                additional_model_request_fields = request_payload.get('additionalModelRequestFields') or request_payload.get('additional_model_request_fields')
        
        # Capture messages for Converse API
        messages = params.get('messages')
        system_prompts = params.get('system')
        
        logger.debug(f"[Bedrock Instrumentation] Captured modelId: {model_id}")
        
        # Execute the actual API call
        response = wrapped(*args, **kwargs)
        
        # Extract response metadata (HTTP headers, status, latency, token counts)
        response_metadata = {}
        if isinstance(response, dict) and 'ResponseMetadata' in response:
            resp_meta = response['ResponseMetadata']
            
            # HTTP Status Code
            if 'HTTPStatusCode' in resp_meta:
                response_metadata['status_code'] = resp_meta['HTTPStatusCode']
            
            # Extract HTTP headers
            if 'HTTPHeaders' in resp_meta:
                headers = resp_meta['HTTPHeaders']
                
                # Bedrock-specific metrics
                if 'x-amzn-bedrock-invocation-latency' in headers:
                    try:
                        response_metadata['invocation_latency_ms'] = int(headers['x-amzn-bedrock-invocation-latency'])
                    except (ValueError, TypeError):
                        response_metadata['invocation_latency_ms'] = headers['x-amzn-bedrock-invocation-latency']
                
                if 'x-amzn-bedrock-input-token-count' in headers:
                    try:
                        response_metadata['input_tokens'] = int(headers['x-amzn-bedrock-input-token-count'])
                    except (ValueError, TypeError):
                        response_metadata['input_tokens'] = headers['x-amzn-bedrock-input-token-count']
                
                if 'x-amzn-bedrock-output-token-count' in headers:
                    try:
                        response_metadata['output_tokens'] = int(headers['x-amzn-bedrock-output-token-count'])
                    except (ValueError, TypeError):
                        response_metadata['output_tokens'] = headers['x-amzn-bedrock-output-token-count']
                
                # AWS Request ID
                if 'x-amzn-requestid' in headers:
                    response_metadata['request_id'] = headers['x-amzn-requestid']
                
                # Standard HTTP headers
                if 'content-type' in headers:
                    response_metadata['content_type'] = headers['content-type']
                
                if 'content-length' in headers:
                    response_metadata['content_length'] = headers['content-length']
                
                if 'date' in headers:
                    response_metadata['date'] = headers['date']
        
        # Extract usage metrics if present
        if isinstance(response, dict) and 'usage' in response:
            usage = response['usage']
            if 'inputTokens' in usage:
                response_metadata['usage_input_tokens'] = usage['inputTokens']
            if 'outputTokens' in usage:
                response_metadata['usage_output_tokens'] = usage['outputTokens']
        
        # Extract latency metrics if present
        if isinstance(response, dict) and 'metrics' in response:
            metrics = response['metrics']
            if 'latencyMs' in metrics:
                response_metadata['latency_ms'] = metrics['latencyMs']
        
        # Capture response body
        response_payload = None
        
        if operation_name == 'InvokeModel' and 'body' in response:
            # Read the StreamingBody
            original_body_stream = response['body']
            response_content = original_body_stream.read()
            
            try:
                response_payload = json.loads(response_content)
            except Exception as e:
                logger.debug(f"Failed to parse response body: {e}")
            
            # Restore the body stream so downstream code can read it
            response['body'] = StreamingBody(
                raw_stream=io.BytesIO(response_content),
                content_length=len(response_content)
            )
        elif operation_name == 'Converse':
            # Converse API returns dict directly
            response_payload = response.copy() if isinstance(response, dict) else None
        
        # Build enriched metadata for better observability
        bedrock_request_metadata = {
            'modelId': model_id,
            'operation': operation_name,
            'body': request_payload,  # Clean JSON serialized body
            'inferenceConfig': inference_config,
            'additionalModelRequestFields': additional_model_request_fields,
        }
        
        # Add operation-specific params
        if operation_name == 'Converse':
            bedrock_request_metadata['messages_count'] = len(messages) if messages else 0
            bedrock_request_metadata['has_system_prompt'] = bool(system_prompts)
        elif operation_name == 'InvokeModel':
            # Add accept/contentType for InvokeModel
            if 'accept' in params:
                bedrock_request_metadata['accept'] = params['accept']
            if 'contentType' in params:
                bedrock_request_metadata['contentType'] = params['contentType']
        
        def _extract_stop_reason(payload: Any) -> Optional[str]:
            if not isinstance(payload, dict):
                return None
            for key in ("stop_reason", "stopReason"):
                if key in payload and payload[key] is not None:
                    return payload[key]
            output = payload.get("output")
            if isinstance(output, dict):
                for key in ("stop_reason", "stopReason"):
                    if key in output and output[key] is not None:
                        return output[key]
            return None

        def _extract_is_continue_invoke(payload: Any) -> Optional[bool]:
            if not isinstance(payload, dict):
                return None
            for key in ("is_continue_invoke", "isContinueInvoke", "isContinue"):
                if key in payload:
                    return payload[key]
            output = payload.get("output")
            if isinstance(output, dict):
                for key in ("is_continue_invoke", "isContinueInvoke", "isContinue"):
                    if key in output:
                        return output[key]
            return None
        
        # Build enriched metadata for bedrock_response (includes response_metadata, stop_reason, is_continue_invoke)
        bedrock_response = {
            "response_metadata": response_metadata or {},
            "is_continue_invoke": _extract_is_continue_invoke(response_payload),
            "stop_reason": _extract_stop_reason(response_payload),
        }

        # Store captured data in context variable with enriched metadata
        captured_data = {
            'model_id': model_id,
            'operation': operation_name,
            'request_body': request_payload,
            'response_body': response_payload,
            'messages': messages,
            'system': system_prompts,
            'inference_config': inference_config,
            'additional_model_request_fields': additional_model_request_fields,
            'bedrock_request': bedrock_request_metadata,  # Enriched metadata for spans
            'bedrock_response': bedrock_response,  # Response metadata (full ResponseMetadata + stop info)
        }
        
        _bedrock_call_context.set(captured_data)
        logger.debug(f"[Bedrock Instrumentation] Stored captured data in context")
        
        return response
        
    except Exception as e:
        logger.error(f"[Bedrock Instrumentation] Error during interception: {e}", exc_info=True)
        # If anything fails, just execute the original call
        return wrapped(*args, **kwargs)


def enable_bedrock_instrumentation():
    """
    Enable automatic Bedrock instrumentation.
    Must be called before making any Bedrock API calls.
    """
    global _instrumentation_enabled
    
    if _instrumentation_enabled:
        logger.info("[Bedrock Instrumentation] Already enabled")
        return
    
    try:
        import botocore.client
        
        logger.info("[Bedrock Instrumentation] Enabling automatic model_id capture...")
        
        wrapt.wrap_function_wrapper(
            'botocore.client',
            'BaseClient._make_api_call',
            _instrument_bedrock_call
        )
        
        _instrumentation_enabled = True
        logger.info("[Bedrock Instrumentation] ✓ Enabled successfully")
        
    except Exception as e:
        logger.error(f"[Bedrock Instrumentation] Failed to enable: {e}", exc_info=True)
        raise


def disable_bedrock_instrumentation():
    """
    Disable automatic Bedrock instrumentation.
    Note: Once wrapt patches are applied, they cannot be easily removed.
    This just sets the flag to stop processing in the wrapper.
    """
    global _instrumentation_enabled
    _instrumentation_enabled = False
    logger.info("[Bedrock Instrumentation] Disabled")


def is_instrumentation_enabled() -> bool:
    """Check if Bedrock instrumentation is enabled."""
    return _instrumentation_enabled
