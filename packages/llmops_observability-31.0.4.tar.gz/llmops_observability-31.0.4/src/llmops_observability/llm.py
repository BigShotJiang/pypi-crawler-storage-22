"""
LLM tracking decorator for LLMOps Observability
Simplified version that collects data into SDKTraceData
"""
from __future__ import annotations
import functools
import inspect
import sys
import time
import uuid
import json
import logging
from typing import Optional, Dict, Any, List, Union, Callable

from .trace_manager import TraceManager, serialize_value, SpanData, safe_locals, ensure_json_object
from .config import MAX_SPAN_IO_SIZE

logger = logging.getLogger(__name__)

# Import bedrock instrumentation for auto-capture
try:
    from .bedrock_instrumentation import (
        get_captured_model_data, 
        clear_captured_model_data,
        enable_bedrock_instrumentation,
        is_instrumentation_enabled
    )
    BEDROCK_INSTRUMENTATION_AVAILABLE = True
except ImportError:
    BEDROCK_INSTRUMENTATION_AVAILABLE = False
    get_captured_model_data = None
    clear_captured_model_data = None
    enable_bedrock_instrumentation = None
    is_instrumentation_enabled = None


def _ensure_instrumentation_enabled():
    """Auto-enable Bedrock instrumentation on first use."""
    if BEDROCK_INSTRUMENTATION_AVAILABLE and enable_bedrock_instrumentation and is_instrumentation_enabled:
        if not is_instrumentation_enabled():
            try:
                enable_bedrock_instrumentation()
                logger.debug("Bedrock instrumentation auto-enabled")
            except Exception as e:
                logger.debug(f"Failed to auto-enable Bedrock instrumentation: {e}")


def extract_text(resp: Any) -> str:
    """Extract text from various LLM response formats."""
    if isinstance(resp, str):
        return resp

    if not isinstance(resp, dict):
        return str(resp)

    # Bedrock Converse API
    try:
        return resp["output"]["message"]["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Anthropic Messages API
    try:
        return resp["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Amazon Titan
    try:
        return resp["results"][0]["outputText"]
    except (KeyError, IndexError, TypeError):
        pass

    # Cohere
    try:
        return resp["generation"]
    except (KeyError, TypeError):
        pass

    # AI21
    try:
        return resp["outputs"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Generic text field
    try:
        return resp["text"]
    except (KeyError, TypeError):
        pass

    # OpenAI format
    try:
        return resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        pass

    return str(resp)


def _estimate_tokens(text: Optional[str]) -> int:
    """Approximate tokens when provider doesn't return usage."""
    if not text:
        return 0
    try:
        return max(0, int(len(str(text)) / 4))
    except Exception:
        return 0


def _build_function_params_input(func: Callable, args: tuple, kwargs: Dict[str, Any]) -> Any:
    """
    Build input from function parameters.
    
    If function has single parameter: return just the parameter value
    If function has multiple parameters: return dict with parameter names as keys
    """
    try:
        sig = inspect.signature(func)
        params = sig.parameters
        
        # Skip 'self' for methods
        param_names = [name for name in params.keys() if name != 'self']
        
        # Build mapping of param_name -> value
        param_values = {}
        
        # Map positional args to parameter names
        for i, arg in enumerate(args):
            # Skip 'self' in counting
            param_idx = i if 'self' not in params else i + 1
            if param_idx < len(param_names):
                param_values[param_names[param_idx]] = arg
        
        # Add kwargs
        param_values.update(kwargs)
        
        # Always return as dict with parameter names as keys (don't unwrap single params)
        # This ensures inputs appear as objects in Langfuse, not unwrapped strings
        if len(param_values) >= 1:
            return serialize_value(param_values)
        
        # Empty case
        return None
    except Exception as e:
        logger.debug(f"Error building function params input: {e}")
        return None


def _build_input_data(
    args: tuple,
    kwargs: Dict[str, Any],
    local_vars: Optional[Dict[str, Any]] = None,
    capture_locals_spec: Union[bool, List[str]] = False,
    capture_self_flag: bool = False,
) -> Dict[str, Any]:
    """Build input_data dict with optional capture of locals and self"""
    input_data = {
        "args": serialize_value(args),
        "kwargs": serialize_value(kwargs),
    }
    
    # Capture self if requested
    if capture_self_flag and args and hasattr(args[0], '__dict__'):
        try:
            input_data["self"] = serialize_value(args[0])
        except Exception:
            pass
    
    # Capture local variables if requested
    if capture_locals_spec and local_vars:
        if isinstance(capture_locals_spec, bool) and capture_locals_spec:
            # Capture all locals (except private ones)
            input_data["locals"] = safe_locals(local_vars)
        elif isinstance(capture_locals_spec, list):
            # Capture only specified locals
            input_data["locals"] = {
                k: serialize_value(v) 
                for k, v in local_vars.items() 
                if k in capture_locals_spec
            }
    
    return input_data


def _extract_prompt_from_captured(captured: Optional[Dict[str, Any]]) -> Optional[str]:
    """Extract prompt from Bedrock captured payloads."""
    if not captured:
        return None

    messages = captured.get("messages")
    if messages:
        return str(messages)

    request_body = captured.get("request_body")
    if isinstance(request_body, dict):
        for key in ("prompt", "inputText", "input", "text"):
            if key in request_body and request_body[key] is not None:
                return str(request_body[key])
        if "messages" in request_body and request_body["messages"] is not None:
            return str(request_body["messages"])

    return None


def _extract_prompt_from_locals(args: tuple, kwargs: dict, local_vars: Optional[dict]) -> Optional[str]:
    """Fallback: Extract prompt from function args/kwargs/locals."""
    # Check common parameter names in kwargs
    for key in ("prompt", "user_query", "input", "query", "question", "text", "message"):
        if key in kwargs and kwargs[key] is not None:
            val = kwargs[key]
            if isinstance(val, str) and len(val.strip()) > 0:
                return val
    
    # Check first positional arg (often the prompt)
    if args and len(args) > 0 and isinstance(args[0], str) and len(args[0].strip()) > 0:
        return args[0]
    
    # Check locals as last resort
    if local_vars:
        for key in ("prompt", "user_query", "input", "query", "question", "text", "message"):
            if key in local_vars and local_vars[key] is not None:
                val = local_vars[key]
                if isinstance(val, str) and len(val.strip()) > 0:
                    return val
    
    return None


def _resolve_custom_value(value: Union[str, Callable], args: tuple, kwargs: dict, result: Any = None, local_vars: Optional[dict] = None) -> Optional[str]:
    """Resolve custom input/output value - can be string, variable name, or callable."""
    if value is None:
        return None
    
    # If it's a callable, call it with context
    if callable(value):
        try:
            return str(value(args, kwargs, result))
        except Exception as e:
            logger.debug(f"Error calling custom value resolver: {e}")
            return None
    
    # If it's a string, check if it's a variable name in local_vars first
    if isinstance(value, str):
        # Try to find it as a variable name in locals
        if local_vars and value in local_vars:
            return str(local_vars[value])
        # Otherwise, treat it as a literal string
        return value
    
    return None


def extract_usage(result: Any, kwargs: Dict[str, Any], *, prompt: Optional[str] = None, response_text: Optional[str] = None) -> Optional[Dict[str, int]]:
    """Extract token usage from LLM response with fallback estimation."""
    usage = {}

    # Check auto-captured Bedrock response data first (includes token counts from response headers)
    if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
        captured = get_captured_model_data()
        if captured:
            # Check response_body first (from Converse API)
            if isinstance(captured.get("response_body"), dict):
                resp = captured["response_body"]
                if "usage" in resp and isinstance(resp["usage"], dict):
                    usage_data = resp["usage"]
                    if "inputTokens" in usage_data:
                        usage["input_tokens"] = usage_data["inputTokens"]
                    if "outputTokens" in usage_data:
                        usage["output_tokens"] = usage_data["outputTokens"]
                    if "totalTokens" in usage_data:
                        usage["total_tokens"] = usage_data["totalTokens"]
            
            # Check response_metadata for Bedrock header tokens (from InvokeModel)
            if not usage and isinstance(captured.get("response_metadata"), dict):
                resp_meta = captured["response_metadata"]
                has_input = "input_tokens" in resp_meta
                has_output = "output_tokens" in resp_meta
                if has_input or has_output:
                    if has_input:
                        usage["input_tokens"] = resp_meta["input_tokens"]
                    if has_output:
                        usage["output_tokens"] = resp_meta["output_tokens"]
                    if has_input and has_output:
                        usage["total_tokens"] = resp_meta["input_tokens"] + resp_meta["output_tokens"]
            
            if usage:
                return usage
    
    # Check if result has usage attribute (OpenAI, Anthropic)
    if hasattr(result, 'usage'):
        usage_obj = result.usage
        if hasattr(usage_obj, 'prompt_tokens'):
            usage['input_tokens'] = usage_obj.prompt_tokens
        if hasattr(usage_obj, 'completion_tokens'):
            usage['output_tokens'] = usage_obj.completion_tokens
        if hasattr(usage_obj, 'total_tokens'):
            usage['total_tokens'] = usage_obj.total_tokens
        return usage if usage else None
    
    # Check Bedrock response format
    if isinstance(result, dict):
        # Bedrock Converse API
        if 'usage' in result:
            usage_data = result['usage']
            if 'inputTokens' in usage_data:
                usage['input_tokens'] = usage_data['inputTokens']
            if 'outputTokens' in usage_data:
                usage['output_tokens'] = usage_data['outputTokens']
            if 'totalTokens' in usage_data:
                usage['total_tokens'] = usage_data['totalTokens']
            return usage if usage else None
    
    # Fallback: estimate tokens from prompt/response text
    inp = _estimate_tokens(prompt)
    out = _estimate_tokens(response_text)
    if inp > 0 or out > 0:
        return {"input_tokens": inp, "output_tokens": out, "total_tokens": inp + out}
    
    return None


def extract_model_id(result: Any, kwargs: Dict[str, Any]) -> Optional[str]:
    """
    Extract model ID from LLM response or kwargs.
    
    Priority order:
    1. Auto-captured from Bedrock instrumentation (if enabled)
    2. Function kwargs (model, modelId, model_id)
    3. Result dict or attributes
    """
    # 1. Try auto-captured data from Bedrock instrumentation
    if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
        captured = get_captured_model_data()
        if captured and captured.get('model_id'):
            return captured['model_id']
    
    # 2. Check kwargs
    if 'model' in kwargs:
        return kwargs['model']
    if 'modelId' in kwargs:
        return kwargs['modelId']
    if 'model_id' in kwargs:
        return kwargs['model_id']
    
    # 3. Check result
    if isinstance(result, dict):
        if 'model' in result:
            return str(result['model'])
        if 'modelId' in result:
            return str(result['modelId'])
    
    if hasattr(result, 'model'):
        return str(getattr(result, 'model', None))
    
    return None


def track_llm_call(
    name: Optional[str] = None,
    *,
    model: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    capture_self: bool = False,
    input: Optional[Union[str, Callable]] = None,
    output: Optional[Union[str, Callable]] = None,
):
    """
    Decorator to track LLM calls.
    
    Usage:
        @track_llm_call()
        def call_llm(prompt):
            return response
            
        @track_llm_call(name="summarize", model="claude-3-sonnet", metadata={"version": "1.0"})
        async def summarize(text):
            return summary
        
        @track_llm_call(capture_locals=True)
        def track_with_locals(prompt, max_tokens):
            # capture_locals=True captures all local variables
            return response
        
        @track_llm_call(input="custom input text", output="custom output text")
        def my_function(prompt):
            return response
        
        @track_llm_call(input=lambda args, kwargs: args[0], output=lambda result: result.get("text"))
        def my_function(prompt):
            return response
    
    Args:
        name: Optional custom name
        model: Optional model ID (will be prioritized over auto-detection)
        metadata: Optional metadata
        capture_locals: Capture function local variables (bool or list of var names)
        capture_self: Capture 'self' parameter (for methods)
        input: Optional custom span input (string or callable that extracts from args/kwargs)
        output: Optional custom span output (string or callable that extracts from result)
    """
    def decorator(func):
        # Auto-enable instrumentation on first use
        _ensure_instrumentation_enabled()
        
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    # No trace - just execute function
                    return await func(*args, **kwargs)

                pending_added = TraceManager._increment_pending_if_active()
                
                span_id = uuid.uuid4().hex
                parent_span_id = TraceManager.get_current_parent_span_id()
                start_time = time.time()
                
                # Push span context for nesting
                TraceManager.push_span_context(span_id)
                
                error = None
                result = None
                captured_locals = {}
                
                # Always capture locals for input/output resolution
                old_trace = sys.gettrace()
                
                def trace_hook(frame, event, arg):
                    # Capture locals on any event for our target function
                    if frame.f_code == func.__code__:
                        if event in ('line', 'return', 'exception'):
                            captured_locals.update(frame.f_locals.copy())
                    # Chain to existing trace function (e.g., debugger)
                    if old_trace:
                        return old_trace(frame, event, arg)
                    return trace_hook
                
                trace_was_set = False
                try:
                    if input or output or capture_locals:  # Use trace to capture locals if needed
                        sys.settrace(trace_hook)
                        trace_was_set = True
                    result = await func(*args, **kwargs)
                    return result
                    
                except Exception as e:
                    error = e
                    raise
                    
                finally:
                    # Restore trace if we set it
                    if trace_was_set:
                        sys.settrace(old_trace)
                    end_time = time.time()
                    duration_ms = int((end_time - start_time) * 1000)
                    
                    # Pop span context
                    TraceManager.pop_span_context()
                    
                    # Use captured locals for input/output resolution
                    local_vars_for_prompt = captured_locals if captured_locals else None
                    
                    # Resolve custom input
                    custom_input = None
                    if input:
                        if callable(input):
                            # Check callable signature to support both 2-arg and 3-arg lambdas
                            try:
                                sig = inspect.signature(input)
                                if len(sig.parameters) >= 3:
                                    custom_input = input(args, kwargs, result)
                                else:
                                    custom_input = input(args, kwargs)
                            except Exception:
                                # Fallback to 3-arg call
                                custom_input = input(args, kwargs, result)
                        else:
                            # Resolve string input as variable name (locals/kwargs) or literal
                            custom_input = _resolve_custom_value(input, args, kwargs, result, local_vars_for_prompt)
                    
                    # Resolve custom output
                    custom_output = None
                    if output:
                        custom_output = _resolve_custom_value(output, args, kwargs, result, local_vars_for_prompt)
                    
                    # Extract LLM-specific data
                    prompt = None
                    response = None
                    usage = None
                    model_id_final = None
                    
                    if not error and result:
                        try:
                            response = extract_text(result)

                            # Try Bedrock instrumentation first, fallback to locals
                            prompt = None
                            if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
                                prompt = _extract_prompt_from_captured(get_captured_model_data())
                            if not prompt:
                                prompt = _extract_prompt_from_locals(args, kwargs, local_vars_for_prompt)
                            
                            usage = extract_usage(result, kwargs, prompt=prompt, response_text=response)
                            # Prioritize: explicit model param > metadata['model'] > auto-extract
                            model_id_final = model or (metadata.get('model') if metadata and 'model' in metadata else None) or extract_model_id(result, kwargs)
                        except Exception:
                            pass
                    
                    # Create span data
                    # Capture local variables if needed
                    local_vars = {}
                    if capture_locals or capture_self:
                        try:
                            frame = inspect.currentframe()
                            if frame and frame.f_back:
                                local_vars = frame.f_back.f_locals.copy()
                        except Exception:
                            pass
                    
                    # Build input from function parameters (not bedrock API call)
                    params_input = _build_function_params_input(func, args, kwargs)
                    input_payload = ensure_json_object(
                        custom_input or params_input,
                        MAX_SPAN_IO_SIZE,
                        key="input",
                    )
                    
                    output_payload = ensure_json_object(
                        custom_output if custom_output is not None else (response if (not error and response is not None) else (result if not error else None)),
                        MAX_SPAN_IO_SIZE,
                        key="output",
                    )

                    # Add local variables to metadata if capture_locals is True
                    # Use captured_locals from trace hook (has actual function locals)
                    final_metadata = dict(metadata or {})
                    if capture_locals and local_vars_for_prompt:
                        # Filter out non-serializable items (functions, modules, etc)
                        filtered_locals = {}
                        
                        # If capture_locals is a list, only capture those specific variables
                        if isinstance(capture_locals, list):
                            for var_name in capture_locals:
                                if var_name in local_vars_for_prompt:
                                    try:
                                        filtered_locals[var_name] = serialize_value(local_vars_for_prompt[var_name])
                                    except Exception:
                                        filtered_locals[var_name] = str(type(local_vars_for_prompt[var_name]).__name__)
                        else:
                            # capture_locals is True - capture all (except private vars)
                            for k, v in local_vars_for_prompt.items():
                                if not k.startswith('_'):  # Skip private vars
                                    try:
                                        filtered_locals[k] = serialize_value(v)
                                    except Exception:
                                        filtered_locals[k] = str(type(v).__name__)
                        
                        if filtered_locals:
                            final_metadata["local_variables"] = filtered_locals
                    
                    # Extract ResponseMetadata directly from result if it's a dict (for Bedrock responses)
                    # This ensures it's a top-level metadata key, not nested in local_variables
                    if not error and isinstance(result, dict) and 'ResponseMetadata' in result:
                        final_metadata['ResponseMetadata'] = result['ResponseMetadata']
                        # Also extract stop_reason if present
                        if 'stopReason' in result:
                            final_metadata['stop_reason'] = result['stopReason']
                    
                    # Add Bedrock request/response metadata if available (enriched from instrumentation)
                    if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
                        bedrock_data = get_captured_model_data() or {}
                        if bedrock_data and 'bedrock_request' in bedrock_data:
                            final_metadata['bedrock_request'] = bedrock_data['bedrock_request']
                            logger.info(f"[LLM Wrapper] Added bedrock_request to metadata")
                        
                        # Add Bedrock response metadata as ResponseMetadata (full structure)
                        if bedrock_data and 'bedrock_response' in bedrock_data:
                            bedrock_response = bedrock_data['bedrock_response']
                            # Extract response_metadata and add as top-level ResponseMetadata
                            if isinstance(bedrock_response, dict) and 'response_metadata' in bedrock_response:
                                final_metadata['ResponseMetadata'] = bedrock_response['response_metadata']
                            # Also keep stop_reason and is_continue_invoke for backward compatibility
                            if isinstance(bedrock_response, dict):
                                if bedrock_response.get('stop_reason') is not None:
                                    final_metadata['stop_reason'] = bedrock_response['stop_reason']
                                if bedrock_response.get('is_continue_invoke') is not None:
                                    final_metadata['is_continue_invoke'] = bedrock_response['is_continue_invoke']
                        
                        # Add model parameters from Bedrock inferenceConfig if available
                        model_parameters = {}
                        inference_config = bedrock_data.get('inference_config') or (bedrock_data.get('bedrock_request', {}) or {}).get('inferenceConfig')
                        additional_fields = bedrock_data.get('additional_model_request_fields') or (bedrock_data.get('bedrock_request', {}) or {}).get('additionalModelRequestFields')
                        if isinstance(inference_config, dict):
                            model_parameters.update(inference_config)
                        if isinstance(additional_fields, dict):
                            model_parameters.update(additional_fields)
                        if model_parameters:
                            final_metadata['model_parameters'] = serialize_value(model_parameters)
                            logger.info(f"[LLM Wrapper] Added ResponseMetadata to metadata")
                        
                        # Add model parameters from Bedrock inferenceConfig if available
                        model_parameters = {}
                        inference_config = bedrock_data.get('inference_config') or (bedrock_data.get('bedrock_request', {}) or {}).get('inferenceConfig')
                        additional_fields = bedrock_data.get('additional_model_request_fields') or (bedrock_data.get('bedrock_request', {}) or {}).get('additionalModelRequestFields')
                        if isinstance(inference_config, dict):
                            model_parameters.update(inference_config)
                        if isinstance(additional_fields, dict):
                            model_parameters.update(additional_fields)
                        if model_parameters:
                            final_metadata['model_parameters'] = serialize_value(model_parameters)

                    span_data = SpanData(
                        span_id=span_id,
                        span_name=span_name,
                        span_type="generation",  # LLM calls are generations
                        parent_span_id=parent_span_id,
                        start_time=start_time,
                        end_time=end_time,
                        duration_ms=duration_ms,
                        input_data=input_payload,
                        output_data=output_payload,
                        error=str(error) if error else None,
                        model_id=model_id_final,
                        metadata=final_metadata,
                        usage=usage,
                        prompt=prompt,
                        response=response,
                        status="error" if error else "success",
                        status_message=str(error) if error else None,
                    )
                    
                    # Add to trace
                    TraceManager.add_span(span_data)

                    if pending_added:
                        TraceManager._decrement_pending()
                    
                    # Clear auto-captured data after use
                    if BEDROCK_INSTRUMENTATION_AVAILABLE and clear_captured_model_data:
                        clear_captured_model_data()
            
            return async_wrapper
        
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    # No trace - just execute function
                    return func(*args, **kwargs)

                pending_added = TraceManager._increment_pending_if_active()
                
                span_id = uuid.uuid4().hex
                parent_span_id = TraceManager.get_current_parent_span_id()
                start_time = time.time()
                
                # Push span context for nesting
                TraceManager.push_span_context(span_id)
                
                error = None
                result = None
                captured_locals = {}
                
                # Always capture locals for input/output resolution
                old_trace = sys.gettrace()
                
                def trace_hook(frame, event, arg):
                    # Capture locals on any event for our target function
                    if frame.f_code == func.__code__:
                        if event in ('line', 'return', 'exception'):
                            captured_locals.update(frame.f_locals.copy())
                    # Chain to existing trace function (e.g., debugger)
                    if old_trace:
                        return old_trace(frame, event, arg)
                    return trace_hook
                
                trace_was_set = False
                try:
                    if input or output or capture_locals:  # Use trace to capture locals if needed
                        sys.settrace(trace_hook)
                        trace_was_set = True
                    result = func(*args, **kwargs)
                    return result
                    
                except Exception as e:
                    error = e
                    raise
                    
                finally:
                    # Restore trace if we set it
                    if trace_was_set:
                        sys.settrace(old_trace)
                    end_time = time.time()
                    duration_ms = int((end_time - start_time) * 1000)
                    
                    # Pop span context
                    TraceManager.pop_span_context()
                    
                    # Use captured locals for input/output resolution
                    local_vars_for_prompt = captured_locals if captured_locals else None
                    
                    
                    # Resolve custom input
                    custom_input = None
                    if input:
                        if callable(input):
                            # Check callable signature to support both 2-arg and 3-arg lambdas
                            try:
                                sig = inspect.signature(input)
                                if len(sig.parameters) >= 3:
                                    custom_input = input(args, kwargs, result)
                                else:
                                    custom_input = input(args, kwargs)
                            except Exception:
                                # Fallback to 3-arg call
                                custom_input = input(args, kwargs, result)
                        else:
                            # Resolve string input as variable name (locals/kwargs) or literal
                            custom_input = _resolve_custom_value(input, args, kwargs, result, local_vars_for_prompt)
                    
                    # Resolve custom output
                    custom_output = None
                    if output:
                        custom_output = _resolve_custom_value(output, args, kwargs, result, local_vars_for_prompt)
                    
                    # Extract LLM-specific data
                    prompt = None
                    response = None
                    usage = None
                    model_id_final = None
                    
                    if not error and result:
                        try:
                            response = extract_text(result)

                            # Try Bedrock instrumentation first, fallback to locals
                            prompt = None
                            if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
                                prompt = _extract_prompt_from_captured(get_captured_model_data())
                            if not prompt:
                                prompt = _extract_prompt_from_locals(args, kwargs, local_vars_for_prompt)
                            
                            usage = extract_usage(result, kwargs, prompt=prompt, response_text=response)
                            model_id_final = model or (metadata.get('model') if metadata and 'model' in metadata else None) or extract_model_id(result, kwargs)
                        except Exception:
                            pass
                    
                    # Create span data
                    # Capture local variables if needed
                    local_vars = {}
                    if capture_locals or capture_self:
                        try:
                            frame = inspect.currentframe()
                            if frame and frame.f_back:
                                local_vars = frame.f_back.f_locals.copy()
                        except Exception:
                            pass
                    
                    # Build input from function parameters (not bedrock API call)
                    params_input = _build_function_params_input(func, args, kwargs)
                    input_payload = ensure_json_object(
                        custom_input or params_input,
                        MAX_SPAN_IO_SIZE,
                        key="input",
                    )
                    
                    output_payload = ensure_json_object(
                        custom_output if custom_output is not None else (response if (not error and response is not None) else (serialize_value(result) if not error else None)),
                        MAX_SPAN_IO_SIZE,
                        key="output",
                    )

                    # Add local variables to metadata if capture_locals is True
                    # Use captured_locals from trace hook (has actual function locals)
                    final_metadata = dict(metadata or {})
                    if capture_locals and local_vars_for_prompt:
                        # Filter out non-serializable items (functions, modules, etc)
                        filtered_locals = {}
                        
                        # If capture_locals is a list, only capture those specific variables
                        if isinstance(capture_locals, list):
                            for var_name in capture_locals:
                                if var_name in local_vars_for_prompt:
                                    try:
                                        filtered_locals[var_name] = serialize_value(local_vars_for_prompt[var_name])
                                    except Exception:
                                        filtered_locals[var_name] = str(type(local_vars_for_prompt[var_name]).__name__)
                        else:
                            # capture_locals is True - capture all (except private vars)
                            for k, v in local_vars_for_prompt.items():
                                if not k.startswith('_'):  # Skip private vars
                                    try:
                                        filtered_locals[k] = serialize_value(v)
                                    except Exception:
                                        filtered_locals[k] = str(type(v).__name__)
                        
                        if filtered_locals:
                            final_metadata["local_variables"] = filtered_locals
                    
                    # Extract ResponseMetadata directly from result if it's a dict (for Bedrock responses)
                    # This ensures it's a top-level metadata key, not nested in local_variables
                    if not error and isinstance(result, dict) and 'ResponseMetadata' in result:
                        final_metadata['ResponseMetadata'] = result['ResponseMetadata']
                        # Also extract stop_reason if present
                        if 'stopReason' in result:
                            final_metadata['stop_reason'] = result['stopReason']
                    
                    # Add Bedrock request/response metadata if available (enriched from instrumentation)
                    if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
                        bedrock_data = get_captured_model_data() or {}
                        if bedrock_data and 'bedrock_request' in bedrock_data:
                            final_metadata['bedrock_request'] = bedrock_data['bedrock_request']
                        
                        # Add Bedrock response metadata as ResponseMetadata (full structure)
                        if bedrock_data and 'bedrock_response' in bedrock_data:
                            bedrock_response = bedrock_data['bedrock_response']
                            # Extract response_metadata and add as top-level ResponseMetadata
                            if isinstance(bedrock_response, dict) and 'response_metadata' in bedrock_response:
                                final_metadata['ResponseMetadata'] = bedrock_response['response_metadata']
                            # Also keep stop_reason and is_continue_invoke for backward compatibility
                            if isinstance(bedrock_response, dict):
                                if bedrock_response.get('stop_reason') is not None:
                                    final_metadata['stop_reason'] = bedrock_response['stop_reason']
                                if bedrock_response.get('is_continue_invoke') is not None:
                                    final_metadata['is_continue_invoke'] = bedrock_response['is_continue_invoke']

                    span_data = SpanData(
                        span_id=span_id,
                        span_name=span_name,
                        span_type="generation",  # LLM calls are generations
                        parent_span_id=parent_span_id,
                        start_time=start_time,
                        end_time=end_time,
                        duration_ms=duration_ms,
                        input_data=input_payload,
                        output_data=output_payload,
                        error=str(error) if error else None,
                        model_id=model_id_final,
                        metadata=final_metadata,
                        usage=usage,
                        prompt=prompt,
                        response=response,
                        status="error" if error else "success",
                        status_message=str(error) if error else None,
                    )
                    
                    # Add to trace
                    TraceManager.add_span(span_data)

                    if pending_added:
                        TraceManager._decrement_pending()
                    
                    # Clear auto-captured data after use
                    if BEDROCK_INSTRUMENTATION_AVAILABLE and clear_captured_model_data:
                        clear_captured_model_data()
            
            return sync_wrapper
    
    return decorator
