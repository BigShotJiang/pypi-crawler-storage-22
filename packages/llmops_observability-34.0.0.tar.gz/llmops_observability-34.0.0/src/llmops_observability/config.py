"""
Configuration management for LLMOps Observability SDK
- Environment loading
- SQS configuration
- Default model resolution
- Size and performance limits
"""
import os
import logging
import tempfile
from typing import Dict, Any
from dotenv import load_dotenv

# Configure logger
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[llmops_observability] %(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# Try to load .env if it exists, but don't require it
# This allows users to set env vars before or after importing the SDK
try:
    load_dotenv()
except Exception:
    pass  # Silently continue if no .env file


# ============================================================
# SIZE LIMITS & CONSTRAINTS
# ============================================================
# Serialization  Limits
# MAX_OUTPUT_SIZE (200 KB)
# Maximum size for an individual span's output/response field before truncation.

# MAX_SPAN_IO_SIZE (150 KB)
# Maximum combined size of input + output data for a single span. When the span's content exceeds this, fields get truncated.

# MAX_TRACE_IO_SIZE (50 KB)
# Maximum total size of all serialized trace data (all spans combined) before truncation kicks in across the entire trace.

# MAX_SQS_SIZE (200 KB)
# Hard limit for the compressed SQS message payload. AWS SQS allows up to 256 KB, but we use 200 KB as a safety buffer to account for compression overhead and JSON metadata.

# Truncation Thresholds
# TRUNCATION_PREVIEW_SIZE (1000 bytes)
# When a field is truncated, this many characters are shown in the preview before the [...truncated...] marker. Helps with debugging by showing the beginning of the data.

# PROMPT_RESPONSE_MAX_SIZE (150 KB)
# Specific limit for prompt and response fields. These are often large, so they're individually capped to prevent them from consuming the entire trace budget.
# How They Work Together
# The adaptive truncation in prepare_for_sqs() uses these limits progressively:

# Try with MAX_SPAN_IO_SIZE and MAX_TRACE_IO_SIZE at full values
# If compressed payload > MAX_SQS_SIZE, reduce limits and retry
# Progressively smaller limits until payload fits
# Never drops spans — only truncates content within them


# Serialization limits (override with env vars if needed)
MAX_OUTPUT_SIZE = int(os.getenv("LLMOPS_MAX_OUTPUT_SIZE", 200 * 1024))  # 200 KB
MAX_SPAN_IO_SIZE = int(os.getenv("LLMOPS_MAX_SPAN_IO_SIZE", 150_000))   # 150 KB
MAX_TRACE_IO_SIZE = int(os.getenv("LLMOPS_MAX_TRACE_IO_SIZE", 50_000))  # 50 KB
MAX_SQS_SIZE = int(os.getenv("LLMOPS_MAX_SQS_SIZE", 240_000))           # 240 KB

# S3 Extended Client Configuration
# When payload exceeds this threshold, automatically store in S3 instead of SQS
# NOTE: Developers don't need to configure these - sensible defaults are provided
# These can still be overridden via environment variables if needed
S3_STORAGE_THRESHOLD = int(os.getenv("LLMOPS_S3_THRESHOLD", 240_000))    # 240 KB - default SQS limit
S3_BUCKET = os.getenv("LLMOPS_S3_BUCKET", "sqsdumpstorage")              # Default S3 bucket (override via env)
S3_REGION = os.getenv("LLMOPS_S3_REGION", "us-east-1")                   # Default region
S3_PREFIX = os.getenv("LLMOPS_S3_PREFIX", "llmops_traces")                # Default S3 key prefix

# Truncation thresholds
TRUNCATION_PREVIEW_SIZE = int(os.getenv("LLMOPS_TRUNCATION_PREVIEW_SIZE", 1000))
PROMPT_RESPONSE_MAX_SIZE = int(os.getenv("LLMOPS_PROMPT_RESPONSE_MAX_SIZE", 500_000))  # 500 KB - prompts need room


# ============================================================
# SQS CONFIGURATION & BATCHING
# ============================================================

# Spillover file for failed SQS sends
SPILLOVER_FILE = os.path.join(
    tempfile.gettempdir(), 
    "llmops_observability_spillover_queue.jsonl"
)

# Worker configuration
SQS_WORKER_COUNT = 4        # Number of background worker threads
SQS_BATCH_SIZE = 10         # Flush batch when reaching this count
SQS_BATCH_TIMEOUT = 0.2     # Timeout for queue.get() in seconds
SQS_FLUSH_TIME_THRESHOLD = 0.15  # Time-based flush threshold (every ~1s)
SQS_SHUTDOWN_TIMEOUT = 1.0  # Timeout for worker shutdown


def get_sqs_config() -> Dict[str, Any]:
    """
    Get SQS configuration from environment variables.
    
    Environment variables:
        - AWS_SQS_URL: SQS queue URL (required to enable SQS)
        - AWS_PROFILE: AWS profile name (default: "default")
        - AWS_REGION: AWS region (default: "us-east-1")
    
    Returns:
        Dict with SQS configuration
    """
    return {
        "aws_sqs_url": os.getenv("AWS_SQS_URL"),
        "aws_profile": os.getenv("AWS_PROFILE", "default"),
        "aws_region": os.getenv("AWS_REGION", "us-east-1"),
    }


# ============================================================
# PROJECT & ENVIRONMENT CONFIGURATION
# ============================================================

def get_project_id() -> str:
    """
    Get project ID from environment variables.
    Auto-injected into every span's metadata.
    
    Environment variables:
        - PROJECT_ID: Project identifier (default: "unknown_project")
    
    Returns:
        str: Project ID
    """
    return os.getenv("PROJECT_ID", "unknown_project").strip()


def get_environment() -> str:
    """
    Get environment from environment variables.
    Auto-injected into every span's metadata.
    
    Environment variables:
        - ENV: Environment (e.g., "development", "staging", "uat", "production")
        - Default: "development"
    
    Returns:
        str: Environment name
    """
    return os.getenv("ENV", "development").strip()


def get_trace_context() -> Dict[str, str]:
    """
    Get trace context (project_id and environment) from environment.
    This is injected into all spans automatically.
    
    Returns:
        Dict with project_id and environment
    """
    return {
        "project_id": get_project_id(),
        "environment": get_environment(),
    }


# ============================================================
# MODEL CONFIGURATION
# ============================================================

def get_default_model() -> str:
    """
    Get default model ID for cost calculation.
    
    Resolution order:
        1. MODEL_ID environment variable (if set)
        2. Default: anthropic.claude-3-5-sonnet-20241022-v2:0 (Claude 3.5 Sonnet - most common, cost-effective)
    
    Environment variables:
        - MODEL_ID: Default model ID for cost calculation (e.g., "anthropic.claude-3-sonnet-20240229-v1:0")
    
    Returns:
        str: Default model ID for cost calculation
    """
    # Most popular and cost-effective model as fallback
    DEFAULT_FALLBACK = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    
    model_id = os.getenv("MODEL_ID", DEFAULT_FALLBACK).strip()
    
    if not model_id:
        model_id = DEFAULT_FALLBACK
    
    logger.debug(f"Default model for cost calculation: {model_id}")
    return model_id
