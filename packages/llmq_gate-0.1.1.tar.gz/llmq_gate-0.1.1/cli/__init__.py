"""Backward-compatible CLI namespace."""
