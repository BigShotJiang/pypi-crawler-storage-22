"""Google Gemini-specific: patch targets, response parsing, stream wrapping."""

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────
# google-genai SDK (used by langchain-google-genai v4+)
# LangChain calls: client.models.generate_content() / client.aio.models.generate_content()

SYNC_TARGET = ("google.genai.models", "Models", "generate_content")
ASYNC_TARGET = ("google.genai.models", "AsyncModels", "generate_content")


# ── Response parsing ──────────────────────────────────────────────────────────

def parse_response(result):
    """Extract provider/model/tokens from a Google GenerateContentResponse."""
    usage = getattr(result, "usage_metadata", None)

    model = "unknown"
    # The response object may have model_version or model
    for attr in ("model_version", "model"):
        val = getattr(result, attr, None)
        if val:
            model = str(val)
            break

    input_tokens = 0
    output_tokens = 0
    if usage:
        input_tokens = getattr(usage, "prompt_token_count", 0) or 0
        output_tokens = getattr(usage, "candidates_token_count", 0) or 0

    return {
        "provider": "google",
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "status": "success",
    }


# ── Sync stream wrapper ──────────────────────────────────────────────────────

class _WrappedStream:
    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        input_tokens = 0
        output_tokens = 0
        model = self._kwargs.get("model", "unknown")

        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage_metadata", None)
            if usage:
                input_tokens = getattr(usage, "prompt_token_count", 0) or 0
                output_tokens = getattr(usage, "candidates_token_count", 0) or 0
                break

        response_data = {
            "provider": "google",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*exc)
        return False


def wrap_stream(result, context, elapsed_ms, kwargs):
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────

class _WrappedAsyncStream:
    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._elapsed_ms = start_elapsed_ms
        self._kwargs = kwargs
        self._chunks = []

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            try:
                self._record()
            except Exception:
                pass
            raise

    def _record(self):
        input_tokens = 0
        output_tokens = 0
        model = self._kwargs.get("model", "unknown")

        for chunk in reversed(self._chunks):
            usage = getattr(chunk, "usage_metadata", None)
            if usage:
                input_tokens = getattr(usage, "prompt_token_count", 0) or 0
                output_tokens = getattr(usage, "candidates_token_count", 0) or 0
                break

        response_data = {
            "provider": "google",
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "status": "success",
        }
        _build_and_enqueue(self._context, response_data, self._elapsed_ms)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*exc)
        return False


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)
