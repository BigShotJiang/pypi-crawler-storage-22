"""Comprehensive tests for llmtracer v2.0 SDK.

All LLM API calls are mocked — no real API calls.
"""

import asyncio
import sys
import types
import uuid
from io import StringIO
from unittest import mock

import pytest

# ═══════════════════════════════════════════════════════════════════════════════
# Helpers: fake OpenAI / Anthropic modules for patching tests
# ═══════════════════════════════════════════════════════════════════════════════


class _FakeUsage:
    """Mimics openai.types.completion_usage.CompletionUsage."""

    def __init__(self, prompt_tokens=100, completion_tokens=50):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class _FakeOpenAIResponse:
    """Mimics openai ChatCompletion response."""

    def __init__(self, model="gpt-4o"):
        self.model = model
        self.usage = _FakeUsage(prompt_tokens=100, completion_tokens=50)
        self.choices = [types.SimpleNamespace(message=types.SimpleNamespace(content="hello"))]


class _FakeAnthropicUsage:
    def __init__(self, input_tokens=200, output_tokens=80):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _FakeAnthropicResponse:
    """Mimics anthropic Message response."""

    def __init__(self, model="claude-sonnet-4-5-20250929"):
        self.model = model
        self.usage = _FakeAnthropicUsage()
        self.stop_reason = "end_turn"
        self.content = [types.SimpleNamespace(text="hello")]


def _install_fake_openai():
    """Install a fake openai module into sys.modules for testing."""
    # Build module hierarchy: openai.resources.chat.completions
    openai_mod = types.ModuleType("openai")
    openai_mod.__version__ = "1.51.0"

    resources_mod = types.ModuleType("openai.resources")
    chat_mod = types.ModuleType("openai.resources.chat")
    completions_mod = types.ModuleType("openai.resources.chat.completions")

    class Completions:
        @staticmethod
        def create(*args, **kwargs):
            return _FakeOpenAIResponse(model=kwargs.get("model", "gpt-4o"))

    class AsyncCompletions:
        @staticmethod
        async def create(*args, **kwargs):
            return _FakeOpenAIResponse(model=kwargs.get("model", "gpt-4o"))

    completions_mod.Completions = Completions
    completions_mod.AsyncCompletions = AsyncCompletions

    chat_mod.completions = completions_mod
    resources_mod.chat = chat_mod
    openai_mod.resources = resources_mod

    sys.modules["openai"] = openai_mod
    sys.modules["openai.resources"] = resources_mod
    sys.modules["openai.resources.chat"] = chat_mod
    sys.modules["openai.resources.chat.completions"] = completions_mod

    return openai_mod, Completions, AsyncCompletions


def _install_fake_anthropic():
    """Install a fake anthropic module into sys.modules for testing."""
    anthropic_mod = types.ModuleType("anthropic")
    anthropic_mod.__version__ = "0.39.0"

    resources_mod = types.ModuleType("anthropic.resources")
    messages_mod = types.ModuleType("anthropic.resources.messages")

    class Messages:
        @staticmethod
        def create(*args, **kwargs):
            return _FakeAnthropicResponse(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

    class AsyncMessages:
        @staticmethod
        async def create(*args, **kwargs):
            return _FakeAnthropicResponse(model=kwargs.get("model", "claude-sonnet-4-5-20250929"))

    messages_mod.Messages = Messages
    messages_mod.AsyncMessages = AsyncMessages

    resources_mod.messages = messages_mod
    anthropic_mod.resources = resources_mod

    sys.modules["anthropic"] = anthropic_mod
    sys.modules["anthropic.resources"] = resources_mod
    sys.modules["anthropic.resources.messages"] = messages_mod

    return anthropic_mod, Messages, AsyncMessages


def _cleanup_fake_modules():
    """Remove fake modules from sys.modules."""
    for key in list(sys.modules):
        if key.startswith("openai") or key.startswith("anthropic"):
            del sys.modules[key]


# ═══════════════════════════════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════════════════════════════


@pytest.fixture(autouse=True)
def _reset_state():
    """Reset all global state between tests."""
    import llmtracer
    from llmtracer import _config, _patcher, _transport, _context

    # Reset config
    _config.api_key = ""
    _config.debug = False
    _config.enabled = False
    _config.endpoint = "https://us-central1-llmtracer-alt.cloudfunctions.net/v1Events"

    # Reset transport and save original enqueue
    _transport._reset()
    from llmtracer._transport import enqueue as _original_enqueue
    _transport.enqueue = _original_enqueue

    # Unpatch anything
    _patcher.unpatch_all()

    # Clean fake modules
    _cleanup_fake_modules()

    yield

    # Teardown
    _config.enabled = False
    _transport._reset()
    _transport.enqueue = _original_enqueue
    _patcher.unpatch_all()
    _cleanup_fake_modules()


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Crash-proof tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestCrashProof:
    """SDK NEVER impacts the customer's app."""

    def test_init_no_providers_installed(self):
        """init() with no providers doesn't throw."""
        import llmtracer

        # No openai or anthropic in sys.modules
        llmtracer.init(api_key="lt_test123")
        # Should not raise

    def test_init_no_api_key(self):
        """init() without API key disables tracing silently."""
        import llmtracer
        from llmtracer import _config

        llmtracer.init()
        assert not _config.enabled

    def test_init_no_api_key_debug(self, capsys):
        """init(debug=True) without API key prints message."""
        import llmtracer

        llmtracer.init(debug=True)
        captured = capsys.readouterr()
        assert "No API key found" in captured.out

    def test_wrapper_with_broken_context_still_calls_original(self):
        """Even if context capture fails, original function runs."""
        import llmtracer
        from llmtracer import _config, _wrapper

        _config.enabled = True
        _config.api_key = "lt_test"

        call_log = []

        def original_fn(*args, **kwargs):
            call_log.append("called")
            return "result"

        def bad_parse(result):
            raise RuntimeError("parse failed")

        wrapped = _wrapper.make_sync_wrapper(original_fn, "test", bad_parse, lambda *a: None)

        result = wrapped(model="test")
        assert result == "result"
        assert len(call_log) == 1

    def test_stream_wrapping_failure_returns_raw_stream(self):
        """If stream wrapping fails, raw stream is returned."""
        import llmtracer
        from llmtracer import _config, _wrapper

        _config.enabled = True
        _config.api_key = "lt_test"

        raw_stream = iter([1, 2, 3])

        def original_fn(*args, **kwargs):
            return raw_stream

        def bad_wrap(*args):
            raise RuntimeError("wrap failed")

        wrapped = _wrapper.make_sync_wrapper(original_fn, "test", lambda r: {}, bad_wrap)

        result = wrapped(stream=True)
        assert result is raw_stream

    def test_flush_never_throws(self):
        """flush() swallows all errors."""
        import llmtracer

        llmtracer.flush()  # no init, no transport — should not throw

    def test_trace_exception_returns_function(self):
        """If trace setup fails, original function is returned."""
        import llmtracer
        from llmtracer import _context

        # Temporarily break push
        original_push = _context.push
        _context.push = mock.Mock(side_effect=RuntimeError("broken"))

        try:
            @llmtracer.trace
            def my_func():
                return 42

            # Should still work even though trace broke
            # (trace() catches the exception and returns fn unmodified)
            assert callable(my_func)
        finally:
            _context.push = original_push


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Patching tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestPatching:
    """After init(), provider methods are wrapped."""

    def test_openai_patched(self):
        """OpenAI completions.create is wrapped after init."""
        _openai_mod, Completions, AsyncCompletions = _install_fake_openai()

        import llmtracer

        original_create = Completions.create
        llmtracer.init(api_key="lt_test123")

        # create should now be wrapped
        assert Completions.create is not original_create

    def test_anthropic_patched(self):
        """Anthropic messages.create is wrapped after init."""
        _anth_mod, Messages, AsyncMessages = _install_fake_anthropic()

        import llmtracer

        original_create = Messages.create
        llmtracer.init(api_key="lt_test123")

        assert Messages.create is not original_create

    def test_openai_event_enqueued(self):
        """After a call, an event is enqueued with correct fields."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        # Patch transport to capture events
        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[{"role": "user", "content": "hi"}])

            assert len(events) == 1
            event = events[0]
            assert event["provider"] == "openai"
            assert event["model"] == "gpt-4o"
            assert event["input_tokens"] == 100
            assert event["output_tokens"] == 50
            assert event["status"] == "success"
            assert "event_id" in event
            assert "timestamp" in event
            assert "latency_ms" in event
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_event_enqueued(self):
        """Anthropic call enqueues event with correct fields."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import Messages
            Messages.create(model="claude-sonnet-4-5-20250929", messages=[{"role": "user", "content": "hi"}])

            assert len(events) == 1
            event = events[0]
            assert event["provider"] == "anthropic"
            assert event["model"] == "claude-sonnet-4-5-20250929"
            assert event["input_tokens"] == 200
            assert event["output_tokens"] == 80
        finally:
            _transport.enqueue = original_enqueue

    def test_unpatch_restores_original(self):
        """unpatch_all() restores original methods."""
        _openai_mod, Completions, _ = _install_fake_openai()

        import llmtracer
        from llmtracer import _patcher

        original_create = Completions.create
        llmtracer.init(api_key="lt_test123")
        assert Completions.create is not original_create

        _patcher.unpatch_all()
        assert Completions.create is original_create

    def test_no_double_patch(self):
        """Calling init() twice doesn't double-wrap."""
        _install_fake_openai()

        import llmtracer

        llmtracer.init(api_key="lt_test123")
        from openai.resources.chat.completions import Completions
        first_wrapped = Completions.create

        # Re-init
        llmtracer.init(api_key="lt_test123")
        assert Completions.create is first_wrapped

    def test_disabled_skips_wrapper(self):
        """When disabled, wrapper passes through to original."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _config, _transport

        llmtracer.init(api_key="lt_test123")
        _config.enabled = False

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            result = Completions.create(model="gpt-4o", messages=[])

            assert result.model == "gpt-4o"
            assert len(events) == 0  # nothing enqueued when disabled
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Caller capture tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestCallerCapture:
    """caller_file points to the calling code, not wrapper internals."""

    def test_caller_file_points_to_test(self):
        """caller_file should be THIS file, not _wrapper.py or _caller.py."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            caller_file = events[0].get("caller_file", "")
            # Should point to this test file, not internals
            assert "test_sdk.py" in caller_file or caller_file == "", \
                f"caller_file should be test_sdk.py, got: {caller_file}"
            # Should NOT point to wrapper internals
            assert "_wrapper.py" not in caller_file
            assert "_caller.py" not in caller_file
        finally:
            _transport.enqueue = original_enqueue

    def test_caller_info_graceful_fallback(self):
        """get_caller_info returns empty dict on failure."""
        from llmtracer._caller import get_caller_info

        # Very deep depth should fail gracefully
        result = get_caller_info(depth=9999)
        assert result == {}


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Context propagation tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestContextPropagation:
    """Events inside trace() inherit context tags."""

    def test_trace_context_manager_tags(self):
        """Events inside trace(conversation_id='x') have that tag."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            with llmtracer.trace(conversation_id="conv_abc", user_id="tim"):
                Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["conversation_id"] == "conv_abc"
            assert events[0]["tags"]["user_id"] == "tim"
            assert "trace_id" in events[0]
            assert "span_id" in events[0]
        finally:
            _transport.enqueue = original_enqueue

    def test_nested_traces_merge_tags(self):
        """Nested trace() calls merge parent + child tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            with llmtracer.trace(user_id="tim"):
                with llmtracer.trace(phase="planning"):
                    Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["user_id"] == "tim"
            assert events[0]["tags"]["phase"] == "planning"
            assert events[0].get("parent_span_id") is not None
        finally:
            _transport.enqueue = original_enqueue

    def test_trace_context_cleanup(self):
        """Context is properly cleaned up after trace exits."""
        import llmtracer
        from llmtracer import _context

        assert _context.get_current() is None

        with llmtracer.trace(test="value"):
            ctx = _context.get_current()
            assert ctx is not None
            assert ctx.tags["test"] == "value"

        assert _context.get_current() is None

    def test_no_trace_no_context(self):
        """Without trace(), events have no trace_id/tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions
            Completions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert "trace_id" not in events[0]
            assert "tags" not in events[0]
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Streaming tests
# ═══════════════════════════════════════════════════════════════════════════════


class _FakeStreamChunk:
    """Mimics an OpenAI stream chunk."""

    def __init__(self, model="gpt-4o", usage=None):
        self.model = model
        self.choices = [types.SimpleNamespace(delta=types.SimpleNamespace(content="hi"))]
        self.usage = usage


class TestStreaming:
    """Wrapped streams yield same chunks and record events."""

    def test_openai_sync_stream_passthrough(self):
        """Wrapped stream yields identical chunks to original."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        # Replace the create to return a stream
        chunks = [
            _FakeStreamChunk(),
            _FakeStreamChunk(),
            _FakeStreamChunk(usage=_FakeUsage(prompt_tokens=100, completion_tokens=25)),
        ]

        from openai.resources.chat.completions import Completions
        original_wrapped = Completions.create

        # We need a create that returns an iterator when stream=True
        def stream_create(*args, **kwargs):
            if kwargs.get("stream"):
                return iter(chunks)
            return _FakeOpenAIResponse()

        # Patch at the *original* level (before our wrapper)
        from llmtracer import _patcher
        key = "openai.resources.chat.completions.Completions.create"
        if key in _patcher._originals:
            cls, method_name, _ = _patcher._originals[key]
            _patcher._originals[key] = (cls, method_name, stream_create)
            # Re-wrap with the new original
            from llmtracer._providers import _openai
            from llmtracer._wrapper import make_sync_wrapper
            new_wrapped = make_sync_wrapper(stream_create, "openai", _openai.parse_response, _openai.wrap_stream)
            setattr(cls, method_name, new_wrapped)

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            result = Completions.create(model="gpt-4o", messages=[], stream=True)
            received = list(result)
            assert len(received) == 3
            # Each chunk should be the same object
            for i, chunk in enumerate(received):
                assert chunk is chunks[i]
            # Event recorded after stream completion
            assert len(events) == 1
            assert events[0]["input_tokens"] == 100
            assert events[0]["output_tokens"] == 25
        finally:
            _transport.enqueue = original_enqueue

    def test_anthropic_sync_stream_passthrough(self):
        """Anthropic stream wrapper extracts tokens from events."""
        from llmtracer._providers._anthropic import _WrappedStream

        msg_start = types.SimpleNamespace(
            type="message_start",
            message=types.SimpleNamespace(
                model="claude-sonnet-4-5-20250929",
                usage=types.SimpleNamespace(input_tokens=150),
            ),
        )
        content = types.SimpleNamespace(type="content_block_delta")
        msg_delta = types.SimpleNamespace(
            type="message_delta",
            usage=types.SimpleNamespace(output_tokens=60),
        )

        raw_stream = iter([msg_start, content, msg_delta])

        from llmtracer import _config, _transport

        _config.enabled = True
        _config.api_key = "lt_test"

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            context = {"context": {}, "caller": {}}
            wrapped = _WrappedStream(raw_stream, context, 500, {"model": "claude-sonnet-4-5-20250929"})

            received = list(wrapped)
            assert len(received) == 3
            assert received[0] is msg_start

            assert len(events) == 1
            assert events[0]["input_tokens"] == 150
            assert events[0]["output_tokens"] == 60
            assert events[0]["model"] == "claude-sonnet-4-5-20250929"
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Async tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestAsync:
    """Async wrapper works correctly."""

    @pytest.mark.asyncio
    async def test_async_openai_call(self):
        """Async wrapper captures events."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions
            result = await AsyncCompletions.create(model="gpt-4o", messages=[])

            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["provider"] == "openai"
            assert events[0]["model"] == "gpt-4o"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_anthropic_call(self):
        """Async Anthropic wrapper captures events."""
        _install_fake_anthropic()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from anthropic.resources.messages import AsyncMessages
            result = await AsyncMessages.create(model="claude-sonnet-4-5-20250929", messages=[])

            assert result.model == "claude-sonnet-4-5-20250929"
            assert len(events) == 1
            assert events[0]["provider"] == "anthropic"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_context_propagation(self):
        """Context propagates correctly in async code."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions

            with llmtracer.trace(user_id="async_user"):
                await AsyncCompletions.create(model="gpt-4o", messages=[])

            assert len(events) == 1
            assert events[0]["tags"]["user_id"] == "async_user"
        finally:
            _transport.enqueue = original_enqueue

    @pytest.mark.asyncio
    async def test_async_trace_decorator(self):
        """@llmtracer.trace works on async functions."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import AsyncCompletions

            @llmtracer.trace(phase="async_phase")
            async def do_async_work():
                return await AsyncCompletions.create(model="gpt-4o", messages=[])

            result = await do_async_work()
            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["tags"]["phase"] == "async_phase"
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 7. Bare decorator tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestBareDecorator:
    """@llmtracer.trace (no parens) works."""

    def test_bare_decorator_sync(self):
        """@llmtracer.trace without parens wraps sync function."""
        import llmtracer

        @llmtracer.trace
        def my_func(x):
            return x * 2

        assert my_func(5) == 10
        assert my_func.__name__ == "my_func"

    @pytest.mark.asyncio
    async def test_bare_decorator_async(self):
        """@llmtracer.trace without parens wraps async function."""
        import llmtracer

        @llmtracer.trace
        async def my_async_func(x):
            return x * 3

        result = await my_async_func(5)
        assert result == 15
        assert my_async_func.__name__ == "my_async_func"

    def test_decorator_with_kwargs(self):
        """@llmtracer.trace(phase='x') wraps function with tags."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            @llmtracer.trace(phase="planning")
            def plan():
                return Completions.create(model="gpt-4o", messages=[])

            result = plan()
            assert result.model == "gpt-4o"
            assert len(events) == 1
            assert events[0]["tags"]["phase"] == "planning"
        finally:
            _transport.enqueue = original_enqueue

    def test_bare_decorator_creates_trace_context(self):
        """@llmtracer.trace creates a trace context (trace_id/span_id)."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _transport

        llmtracer.init(api_key="lt_test123")

        events = []
        original_enqueue = _transport.enqueue
        _transport.enqueue = lambda e: events.append(e)

        try:
            from openai.resources.chat.completions import Completions

            @llmtracer.trace
            def plan():
                return Completions.create(model="gpt-4o", messages=[])

            plan()
            assert len(events) == 1
            assert "trace_id" in events[0]
            assert "span_id" in events[0]
        finally:
            _transport.enqueue = original_enqueue


# ═══════════════════════════════════════════════════════════════════════════════
# 8. Debug mode tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestDebugMode:
    """init(debug=True) prints expected output."""

    def test_debug_init_prints_patched(self, capsys):
        """Debug mode prints patch confirmations."""
        _install_fake_openai()
        _install_fake_anthropic()

        import llmtracer

        llmtracer.init(api_key="lt_test123", debug=True)
        captured = capsys.readouterr()

        assert "Patched openai" in captured.out
        assert "Patched anthropic" in captured.out
        assert "Ready" in captured.out

    def test_debug_prints_capture(self, capsys):
        """Debug mode prints per-call capture line."""
        _install_fake_openai()

        import llmtracer
        from llmtracer import _config

        llmtracer.init(api_key="lt_test123", debug=True)

        # Suppress transport HTTP calls
        from llmtracer import _transport
        _transport.enqueue = lambda e: None

        capsys.readouterr()  # clear init output

        from openai.resources.chat.completions import Completions
        Completions.create(model="gpt-4o", messages=[])

        captured = capsys.readouterr()
        assert "openai/gpt-4o" in captured.out
        assert "100" in captured.out  # input tokens
        assert "50" in captured.out  # output tokens


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Transport tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestTransport:
    """Transport batching and HTTP delivery."""

    def test_enqueue_and_flush(self):
        """Events can be enqueued and flushed."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"
        _config.enabled = True

        _transport.enqueue({"test": "event1"})
        _transport.enqueue({"test": "event2"})

        # Mock urlopen to capture the request
        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            mock_resp = mock.MagicMock()
            mock_resp.status = 200
            mock_resp.__enter__ = mock.Mock(return_value=mock_resp)
            mock_resp.__exit__ = mock.Mock(return_value=False)
            mock_urlopen.return_value = mock_resp

            _transport.flush()

            assert mock_urlopen.called
            call_args = mock_urlopen.call_args
            req = call_args[0][0]
            assert req.method == "POST"
            assert req.get_header("Content-type") == "application/json"
            assert req.get_header("Authorization") == "Bearer lt_test"

            import json
            payload = json.loads(req.data)
            assert len(payload["events"]) == 2

    def test_flush_empty_queue_noop(self):
        """Flushing empty queue makes no HTTP calls."""
        from llmtracer import _transport

        with mock.patch("urllib.request.urlopen") as mock_urlopen:
            _transport.flush()
            assert not mock_urlopen.called

    def test_flush_failure_requeues(self):
        """Failed flush re-queues events."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"

        _transport.enqueue({"test": "event"})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("network error")):
            _transport.flush()

        # Event should be re-queued
        assert not _transport._event_queue.empty()

    def test_requeue_limit(self):
        """Re-queue is limited to prevent memory leaks."""
        from llmtracer import _transport, _config

        _config.api_key = "lt_test"

        # Enqueue more than _MAX_REQUEUE
        for i in range(150):
            _transport.enqueue({"i": i})

        with mock.patch("urllib.request.urlopen", side_effect=Exception("fail")):
            _transport.flush()

        # Should have at most _MAX_REQUEUE items
        count = 0
        while not _transport._event_queue.empty():
            _transport._event_queue.get_nowait()
            count += 1
        assert count <= _transport._MAX_REQUEUE


# ═══════════════════════════════════════════════════════════════════════════════
# 10. Schema tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestSchema:
    """Event schema correctness."""

    def test_event_has_required_fields(self):
        """Built events have all required fields."""
        from llmtracer._schema import build_event

        event = build_event(
            context_data={"trace_id": "t1", "span_id": "s1", "tags": {"k": "v"}},
            response_data={"provider": "openai", "model": "gpt-4o", "input_tokens": 100, "output_tokens": 50, "status": "success"},
            latency_ms=1200,
            caller_info={"caller_file": "app.py", "caller_function": "main", "caller_line": 10},
        )

        assert event["event_id"]  # non-empty uuid
        assert event["timestamp"]
        assert event["provider"] == "openai"
        assert event["model"] == "gpt-4o"
        assert event["input_tokens"] == 100
        assert event["output_tokens"] == 50
        assert event["latency_ms"] == 1200
        assert event["status"] == "success"
        assert event["caller_file"] == "app.py"
        assert event["caller_function"] == "main"
        assert event["caller_line"] == 10
        assert event["trace_id"] == "t1"
        assert event["span_id"] == "s1"
        assert event["tags"] == {"k": "v"}
        assert event["sdk_version"] == "2.0.0"
        assert event["sdk_language"] == "python"

    def test_event_without_context(self):
        """Events without trace context omit trace fields."""
        from llmtracer._schema import build_event

        event = build_event(
            context_data=None,
            response_data={"provider": "openai", "model": "gpt-4o", "input_tokens": 0, "output_tokens": 0, "status": "success"},
            latency_ms=500,
            caller_info={},
        )

        assert "trace_id" not in event
        assert "tags" not in event
        assert event["provider"] == "openai"


# ═══════════════════════════════════════════════════════════════════════════════
# 11. Public API surface tests
# ═══════════════════════════════════════════════════════════════════════════════


class TestPublicAPI:
    """Only init, trace, flush, __version__ are public."""

    def test_public_exports(self):
        import llmtracer

        assert llmtracer.__all__ == ["init", "trace", "flush", "__version__"]

    def test_version(self):
        import llmtracer

        assert llmtracer.__version__ == "2.0.0"

    def test_no_langchain_exports(self):
        """No LangChain-related names in the public API."""
        import llmtracer

        assert not hasattr(llmtracer, "LLMTracerCallbackHandler")
        assert not hasattr(llmtracer, "LLMTracer")

    def test_init_reads_env_var(self):
        """init() reads LLMTRACER_API_KEY from env."""
        import llmtracer
        from llmtracer import _config

        with mock.patch.dict("os.environ", {"LLMTRACER_API_KEY": "lt_from_env"}):
            llmtracer.init()

        assert _config.api_key == "lt_from_env"
        assert _config.enabled is True
