""" "Equivariant vector prodictors"""

from .lgatr import LGATrVectors
from .mlp import MLPVectors
from .pelican import PELICANVectors
