# Description: DataSource tools for LogicMonitor MCP server.
# Description: Provides get_datasources, get_datasource for querying LogicModule definitions.

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.types import TextContent

from lm_mcp.tools import (
    WILDCARD_STRIP_NOTE,
    format_response,
    handle_error,
    quote_filter_value,
    sanitize_filter_value,
)

if TYPE_CHECKING:
    from lm_mcp.client import LogicMonitorClient


async def get_datasources(
    client: "LogicMonitorClient",
    name_filter: str | None = None,
    applies_to_filter: str | None = None,
    filter: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[TextContent]:
    """List DataSources (LogicModules) from LogicMonitor.

    Args:
        client: LogicMonitor API client.
        name_filter: Filter by DataSource name (supports wildcards).
        applies_to_filter: Filter by appliesTo expression.
        filter: Raw filter expression for advanced queries (overrides other filters).
            Supports LogicMonitor filter syntax with operators:
            : (equal), !: (not equal), > < >: <: (comparisons),
            ~ (contains), !~ (not contains).
            Examples: "name~CPU,group:Core"
        limit: Maximum number of DataSources to return.
        offset: Number of results to skip for pagination.

    Returns:
        List of TextContent with DataSource data or error.
    """
    try:
        params: dict = {"size": limit, "offset": offset}
        wildcards_stripped = False

        # If raw filter is provided, use it directly (power user mode)
        if filter:
            params["filter"] = filter
        else:
            # Build filter from named parameters
            filters = []
            if name_filter:
                clean_name, was_modified = sanitize_filter_value(name_filter)
                wildcards_stripped = wildcards_stripped or was_modified
                filters.append(f'name~{quote_filter_value(clean_name)}')
            if applies_to_filter:
                clean_val, was_modified = sanitize_filter_value(applies_to_filter)
                wildcards_stripped = wildcards_stripped or was_modified
                filters.append(f'appliesTo~{quote_filter_value(clean_val)}')

            if filters:
                params["filter"] = ",".join(filters)

        result = await client.get("/setting/datasources", params=params)

        datasources = []
        for item in result.get("items", []):
            datasources.append(
                {
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "display_name": item.get("displayName"),
                    "description": item.get("description"),
                    "applies_to": item.get("appliesTo"),
                    "group": item.get("group"),
                    "collect_method": item.get("collectMethod"),
                    "has_multi_instances": item.get("hasMultiInstances"),
                }
            )

        total = result.get("total", 0)
        has_more = (offset + len(datasources)) < total

        response = {
            "total": total,
            "count": len(datasources),
            "offset": offset,
            "has_more": has_more,
            "datasources": datasources,
        }
        if wildcards_stripped:
            response["note"] = WILDCARD_STRIP_NOTE
        return format_response(response)
    except Exception as e:
        return handle_error(e)


async def get_datasource(
    client: "LogicMonitorClient",
    datasource_id: int,
) -> list[TextContent]:
    """Get detailed information about a specific DataSource.

    Args:
        client: LogicMonitor API client.
        datasource_id: DataSource ID.

    Returns:
        List of TextContent with DataSource details or error.
    """
    try:
        result = await client.get(f"/setting/datasources/{datasource_id}")

        # Extract key details for a cleaner response
        datasource = {
            "id": result.get("id"),
            "name": result.get("name"),
            "display_name": result.get("displayName"),
            "description": result.get("description"),
            "applies_to": result.get("appliesTo"),
            "group": result.get("group"),
            "collect_method": result.get("collectMethod"),
            "collect_interval": result.get("collectInterval"),
            "has_multi_instances": result.get("hasMultiInstances"),
            "datapoints": [
                {
                    "id": dp.get("id"),
                    "name": dp.get("name"),
                    "description": dp.get("description"),
                    "type": dp.get("type"),
                    "alert_expr": dp.get("alertExpr"),
                }
                for dp in result.get("dataPoints", [])
            ],
            "graphs": [
                {
                    "id": g.get("id"),
                    "name": g.get("name"),
                    "title": g.get("title"),
                }
                for g in result.get("graphs", [])
            ],
        }

        return format_response(datasource)
    except Exception as e:
        return handle_error(e)
