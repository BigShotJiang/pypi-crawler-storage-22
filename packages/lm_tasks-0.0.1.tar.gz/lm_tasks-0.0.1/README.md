# lm-tasks

Task definitions and runners for language model evaluation.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install lm-tasks
```

## Status

This package is in early planning. Watch this space.
