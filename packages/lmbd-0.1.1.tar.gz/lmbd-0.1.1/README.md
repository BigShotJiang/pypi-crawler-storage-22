# lmbd

A lightweight library for creating lambda expressions in Python using a symbolic syntax.

## Installation

```bash
pip install lmbd
```

## Quick Start

```python
from lmbd import _, F

# Create a lambda that adds 1
add_one = F(_ + 1)
print(add_one(5)) # 6

# Use multiple arguments
add = F(_ + _)
print(add(1, 2)) # 3

# Positional arguments with P
from lmbd import P
custom_add = F(P[0] + P[1] * 2)
print(custom_add(10, 5)) # 20

# Keyword arguments
greet = F("Hello, " + P["name"])
print(greet(name="Alice")) # Hello, Alice
```

`F` prevents ambiguity. It ensures `__call__` triggers a functional call within the expression instead of executing the placeholder prematurely.

```python
from lmbd import _
assert F(_.upper())('test') == 'TEST'

from lmbd.auto import _
print((_ + 1)(5)) # 6
print((_.upper())('test')) # ❌ This raises error since `_.upper` is treated as a placeholder, and `()` immediately invokes it with no arguments.
```

## Under the Hood

Placeholder expressions maintain an AST and are compiled into a callable objects only when invoked. This design balances a flexible DSL with Python's native execution efficiency.
