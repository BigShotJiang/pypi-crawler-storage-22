import ast

from . import Expr, _compile


class AutoExpr(Expr):
    def __init__(self, value):
        super().__init__(value)
        self._compiled = None

    def __call__(self, *args, **kwargs):
        compiled = object.__getattribute__(self, "_compiled")
        if compiled is None:
            compiled = _compile(self)
            self._compiled = compiled
        return compiled(*args, **kwargs)


_ = AutoExpr(ast.Name(id="$", ctx=ast.Load()))
