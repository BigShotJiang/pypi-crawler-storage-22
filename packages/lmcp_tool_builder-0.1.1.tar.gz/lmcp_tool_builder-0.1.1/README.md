# LMCP Tool Builder

A Python library for discovering, building and loading tools from LMCP (Language Model Context Protocol) servers.

## Features

- **Tool Discovery**: Automatically discover tools from LMCP servers
- **Local Caching**: Cache tools locally for offline use
- **Auto Update**: Configurable auto-update behavior
- **Tool Testing**: Built-in testing functionality for discovered tools
- **Easy Integration**: Simple API for integrating with your applications

## Installation

```bash
pip install lmcp-tool-builder
```

## Quick Start

```python
from lmcp_tool_builder import LMCPToolBuilder
import os

# Create a tool builder instance
builder = LMCPToolBuilder(
    server_url="http://your-lmcp-server:8000",
    api_key=os.getenv("LMCP_API_KEY"),
    local_tools_file="bot_tools.py",
    debug=True,
    auto_update=True
)

# Build and load tools
tools = builder.build_and_load_tools()

# Use the tools
for tool in tools:
    print(f"Tool: {tool.__name__}")
```

## Configuration

### Environment Variables

Create a `.env` file in your project:

```env
LMCP_API_KEY=your_api_key_here
LMCP_LOCAL_TOOLS_FILE=bot_tools.py
```

### LMCPToolBuilder Parameters

- `server_url`: URL of the LMCP server (default: "http://localhost:8000")
- `api_key`: API key for authentication (default: "")
- `local_tools_file`: Path to local tools cache file (default: "bot_tools.py")
- `debug`: Enable debug output (default: False)
- `auto_update`: Auto-update tools from server (default: False)

## API Reference

### LMCPToolBuilder Class

#### Methods

- `discover_tools()`: Discover tools from LMCP server or local cache
- `build_tools_module(server_tools)`: Build a Python module from server tools
- `save_tools_module(module_code)`: Save module to local file
- `load_tools_from_module()`: Load tools from local module
- `build_and_load_tools()`: Main method to build and load tools
- `test_tools(tools)`: Test loaded tools with sample inputs

## Example Usage

```python
import os
from dotenv import load_dotenv
from lmcp_tool_builder import LMCPToolBuilder

# Load environment variables
load_dotenv()

# Initialize builder
builder = LMCPToolBuilder(
    server_url="http://aicity.wang:8000",
    api_key=os.getenv("LMCP_API_KEY"),
    local_tools_file=os.getenv("LMCP_LOCAL_TOOLS_FILE", "bot_tools.py"),
    debug=True,
    auto_update=True
)

# Build and load tools
tools = builder.build_and_load_tools()

# Test tools
builder.test_tools(tools)
```

## Development

### Setup Development Environment

```bash
# Clone the repository
git clone https://github.com/example/lmcp-tool-builder.git
cd lmcp-tool-builder

# Install in development mode
pip install -e .
```

### Running Tests

```bash
python -m pytest tests/
```

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
