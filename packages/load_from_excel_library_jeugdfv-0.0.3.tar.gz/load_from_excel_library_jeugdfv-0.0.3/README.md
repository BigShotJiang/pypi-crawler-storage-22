# Readme

A wrapper library that contains wrapper functions to grab excel table objects, figures and import them to Pandas Dataframes or save them as .png.

Relying on the work of other libraries:
- openpyxl (for accessing Excel files and the objects within them) 
- PIL (Pillow:fork) (grabbing the copy-paste buffer in excel and exporting figures)
- win32com (for accessing Excel files and the objects within them)