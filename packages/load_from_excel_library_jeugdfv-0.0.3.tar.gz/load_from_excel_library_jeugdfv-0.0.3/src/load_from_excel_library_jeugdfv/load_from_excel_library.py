#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import openpyxl
from openpyxl.utils import range_boundaries

def named_range_to_dataframe(wb, range_name, has_header=True):
    """Convert a named range to a pandas DataFrame. Uses the openpyxl WB object: (openpyxl.load_workbook())
         
         :param wb: openpyxl.Workbook Object.
    Returns:
    - pandas DataFrame with the PivotTable data
        """
    named_range = wb.defined_names[range_name]
    range_reference = named_range.attr_text
    
    # Parse reference
    sheet_name, cell_range = range_reference.split('!')
    cell_range = cell_range.replace('$', '')
    
    # Get data
    ws = wb[sheet_name]
    min_col, min_row, max_col, max_row = range_boundaries(cell_range)
    
    data = list(ws.iter_rows(min_row=min_row, max_row=max_row,
                            min_col=min_col, max_col=max_col,
                            values_only=True))
    
    if has_header and len(data) > 1:
        return pd.DataFrame(data[1:], columns=data[0])
    else:
        return pd.DataFrame(data)
    

def extract_pivottable_to_dataframe(excel_file, pivot_name="pivot"):
    """
    Extract data from a named PivotTable in Excel to a pandas DataFrame.
    
    Parameters:
    - excel_file: path to the Excel file
    - pivot_name: name of the PivotTable to extract
    
    Returns:
    - pandas DataFrame with the PivotTable data
    """
    # Load the workbook
    wb = openpyxl.load_workbook(excel_file, data_only=True)
    
    # Find the sheet containing the pivot table
    pivot_sheet = None
    pivot_location = None
    
    for sheet in wb.worksheets:
        if hasattr(sheet, '_pivots'):
            for pivot in sheet._pivots:
                if pivot.name == pivot_name:
                    pivot_sheet = sheet
                    pivot_location = pivot.location
                    break
        if pivot_sheet:
            break
    
    if not pivot_sheet:
        raise ValueError(f"PivotTable '{pivot_name}' not found in workbook")
    
    # Get all data from the pivot table range
    data = []
    for row in pivot_sheet[pivot_location.ref]:
        row_data = [cell.value for cell in row]
        data.append(row_data)
    
    # Create DataFrame
    # First row is typically headers
    # added: skip first row (empty), row-indices: header=1, data=2:;
    if data:
        df = pd.DataFrame(data[2:], columns=data[1])
    else:
        df = pd.DataFrame()  # Return empty DataFrame if no data found

    wb.close()
    
    return df
