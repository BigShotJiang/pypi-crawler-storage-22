"""
Tests for lobpy package.
"""
