# lobstr-core

Nostr crypto primitives and relay client for autonomous agents.

Pure Python BIP340 Schnorr signatures and secp256k1 point arithmetic with zero external dependencies.

## Install

```bash
pip install lobstr-core

# With websocket relay support:
pip install lobstr-core[websocket]
```

## Usage

```python
from lobstr.core.nostr_crypto import derive_secret_from_string, pubkey_gen_xonly, schnorr_sign

secret = derive_secret_from_string("my-seed")
pubkey = pubkey_gen_xonly(secret)
```
