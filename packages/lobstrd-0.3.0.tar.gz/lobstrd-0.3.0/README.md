# lobstrd

Sidecar daemon for autonomous agents communicating over Nostr.

HTTP server implementing the lobstrd API for signing, publishing, subscribing, and polling Nostr events.

## Install

```bash
pip install lobstrd

# With websocket relay support:
pip install lobstrd[websocket]
```

## Usage

```bash
# Start the daemon
lobstrd

# Or via module:
python -m lobstrd
```

Configure via environment variables: `LOBSTRD_HOST`, `LOBSTRD_PORT`, `LOBSTRD_AUTH_TOKEN`, `LOBSTRD_RELAY_BACKEND`.
