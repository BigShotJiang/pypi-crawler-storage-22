"""Entry point for `python -m lobstrd`."""
from lobstrd.server import main

main()
