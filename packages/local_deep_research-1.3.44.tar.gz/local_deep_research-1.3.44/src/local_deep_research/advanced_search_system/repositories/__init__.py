"""
Repositories package for advanced search system.
"""

from ..findings.repository import FindingsRepository

__all__ = ["FindingsRepository"]
