"""Server configuration management for web app startup.

This module handles server configuration that needs to be available before
Flask app context is established. It provides a bridge between environment
variables and database settings.
"""

import json
import os
from pathlib import Path
from typing import Dict, Any

from loguru import logger

from ..config.paths import get_data_dir
from ..settings.manager import get_typed_setting_value


def get_server_config_path() -> Path:
    """Get the path to the server configuration file."""
    return Path(get_data_dir()) / "server_config.json"


def load_server_config() -> Dict[str, Any]:
    """Load server configuration from file or environment variables.

    Returns:
        dict: Server configuration with keys: host, port, debug, use_https
    """
    config_path = get_server_config_path()

    # Try to load from config file first
    saved_config = {}
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                saved_config = json.load(f)
                logger.debug(f"Loaded server config from {config_path}")
        except Exception as e:
            logger.warning(f"Failed to load server config: {e}")

    # Ensure correct typing and check environment variables.
    config = {
        "host": get_typed_setting_value(
            "web.host", saved_config.get("host"), "text", default="0.0.0.0"
        ),
        "port": get_typed_setting_value(
            "web.port", saved_config.get("port"), "number", default=5000
        ),
        "debug": get_typed_setting_value(
            "app.debug", saved_config.get("debug"), "checkbox", default=False
        ),
        "use_https": get_typed_setting_value(
            "web.use_https",
            saved_config.get("use_https"),
            "checkbox",
            default=True,
        ),
        "allow_registrations": get_typed_setting_value(
            "app.allow_registrations",
            saved_config.get("allow_registrations"),
            "checkbox",
            default=True,
        ),
    }

    # Security: if LDR_APP_ALLOW_REGISTRATIONS is set to an unrecognized
    # value (e.g. "disabled", "nein", typos like "flase"), default to False
    # (registrations disabled) rather than True.  This "fail closed" approach
    # prevents accidental open registration when an admin clearly intended to
    # restrict it but used a non-standard boolean string.
    _RECOGNIZED_BOOL_VALUES = {
        "true",
        "false",
        "1",
        "0",
        "yes",
        "no",
        "on",
        "off",
    }
    raw_reg_env = os.getenv("LDR_APP_ALLOW_REGISTRATIONS")
    if raw_reg_env is not None:
        normalized = raw_reg_env.lower().strip()
        if normalized not in _RECOGNIZED_BOOL_VALUES:
            logger.warning(
                f"LDR_APP_ALLOW_REGISTRATIONS='{raw_reg_env}' is not a "
                f"recognized boolean value. Defaulting to FALSE "
                f"(registrations disabled) for security. Use "
                f"'true'/'false', '1'/'0', 'yes'/'no', or 'on'/'off'."
            )
            config["allow_registrations"] = False

    config.update(
        {
            # Rate limiting settings
            "rate_limit_default": get_typed_setting_value(
                "security.rate_limit_default",
                saved_config.get("rate_limit_default"),
                "text",
                default="5000 per hour;50000 per day",
            ),
            "rate_limit_login": get_typed_setting_value(
                "security.rate_limit_login",
                saved_config.get("rate_limit_login"),
                "text",
                default="5 per 15 minutes",
            ),
            "rate_limit_registration": get_typed_setting_value(
                "security.rate_limit_registration",
                saved_config.get("rate_limit_registration"),
                "text",
                default="3 per hour",
            ),
        }
    )

    return config


def save_server_config(config: Dict[str, Any]) -> None:
    """Save server configuration to file.

    This should be called when web.host or web.port settings are updated
    through the UI.

    Args:
        config: Server configuration dict
    """
    config_path = get_server_config_path()

    try:
        # Ensure directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)

        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        logger.info(f"Saved server config to {config_path}")
    except Exception:
        logger.exception("Failed to save server config")


def sync_from_settings(settings_snapshot: Dict[str, Any]) -> None:
    """Sync server config from settings snapshot.

    This should be called when settings are updated through the UI.

    Args:
        settings_snapshot: Settings snapshot containing web.host and web.port
    """
    config = load_server_config()

    # Update from settings if available
    if "web.host" in settings_snapshot:
        config["host"] = settings_snapshot["web.host"]
    if "web.port" in settings_snapshot:
        config["port"] = settings_snapshot["web.port"]
    if "app.debug" in settings_snapshot:
        config["debug"] = settings_snapshot["app.debug"]
    if "web.use_https" in settings_snapshot:
        config["use_https"] = settings_snapshot["web.use_https"]
    if "app.allow_registrations" in settings_snapshot:
        config["allow_registrations"] = settings_snapshot[
            "app.allow_registrations"
        ]
    if "security.rate_limit_default" in settings_snapshot:
        config["rate_limit_default"] = settings_snapshot[
            "security.rate_limit_default"
        ]
    if "security.rate_limit_login" in settings_snapshot:
        config["rate_limit_login"] = settings_snapshot[
            "security.rate_limit_login"
        ]
    if "security.rate_limit_registration" in settings_snapshot:
        config["rate_limit_registration"] = settings_snapshot[
            "security.rate_limit_registration"
        ]

    save_server_config(config)
