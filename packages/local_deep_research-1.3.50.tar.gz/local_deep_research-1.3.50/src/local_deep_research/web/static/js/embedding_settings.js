/**
 * Embedding Settings JavaScript
 * Handles the embedding configuration UI and API calls
 */

// Available providers and models loaded from API
let providerOptions = [];
let availableModels = {};
let currentSettings = null;

// safeFetch is now provided by utils/safe-fetch.js loaded in base.html

/**
 * Initialize the page
 */
document.addEventListener('DOMContentLoaded', function() {
    // Load available models first, then settings
    loadAvailableModels().then(() => {
        // After models are loaded, load current settings
        loadCurrentSettings();
    });

    // Setup provider change handler
    document.getElementById('embedding-provider').addEventListener('change', function() {
        updateModelOptions();
        toggleOllamaUrlField();
    });

    // Setup model change handler
    document.getElementById('embedding-model').addEventListener('change', updateModelDescription);

    // Setup Ollama URL change handler
    document.getElementById('ollama-url').addEventListener('input', function() {
        // Mark as changed if needed
    });

    // Setup config form submission
    document.getElementById('rag-config-form').addEventListener('submit', handleConfigSubmit);
});

/**
 * Load available embedding providers and models
 */
async function loadAvailableModels() {
    try {
        const response = await safeFetch('/library/api/rag/models');
        const data = await response.json();

        if (data.success) {
            providerOptions = data.provider_options || [];
            availableModels = data.providers || {};

            // Populate provider dropdown
            populateProviders();

            // Update models for current provider (don't select yet, wait for settings)
            updateModelOptions();

            // Update provider information
            updateProviderInfo();
        } else {
            showError('Failed to load available models: ' + data.error);
        }
    } catch (error) {
        SafeLogger.error('Error loading models:', error);
        showError('Failed to load available models');
    }
}

/**
 * Load current RAG settings from database
 */
async function loadCurrentSettings() {
    try {
        const response = await safeFetch('/library/api/rag/settings');
        const data = await response.json();

        if (data.success && data.settings) {
            currentSettings = data.settings;
            const settings = data.settings;

            // Set provider
            const providerSelect = document.getElementById('embedding-provider');
            if (settings.embedding_provider) {
                providerSelect.value = settings.embedding_provider;
            }

            // Update models for this provider
            updateModelOptions();

            // Set model
            const modelSelect = document.getElementById('embedding-model');
            if (settings.embedding_model) {
                modelSelect.value = settings.embedding_model;
                updateModelDescription();
            }

            // Set chunk size and overlap
            if (settings.chunk_size) {
                document.getElementById('chunk-size').value = settings.chunk_size;
            }
            if (settings.chunk_overlap) {
                document.getElementById('chunk-overlap').value = settings.chunk_overlap;
            }

            // Set new advanced settings
            if (settings.splitter_type) {
                document.getElementById('splitter-type').value = settings.splitter_type;
            }
            if (settings.distance_metric) {
                document.getElementById('distance-metric').value = settings.distance_metric;
            }
            if (settings.index_type) {
                document.getElementById('index-type').value = settings.index_type;
            }
            if (settings.normalize_vectors !== undefined) {
                document.getElementById('normalize-vectors').checked = settings.normalize_vectors;
            }
            if (settings.text_separators) {
                // Convert array to JSON string for display
                document.getElementById('text-separators').value = JSON.stringify(settings.text_separators);
            }

            // Load Ollama URL from global settings
            loadOllamaUrl();

            // Show/hide Ollama URL field based on provider
            toggleOllamaUrlField();

            // Update the saved defaults display
            renderSavedDefaults(settings);
        }
    } catch (error) {
        SafeLogger.error('Error loading current settings:', error);
        // Don't show error to user - just use defaults
    }
}

/**
 * Render the saved default settings display
 */
function renderSavedDefaults(settings) {
    const container = document.getElementById('saved-default-settings');
    if (!container) return;

    // Get provider display name
    const providerLabels = {
        'sentence_transformers': 'Sentence Transformers (Local)',
        'ollama': 'Ollama (Local)',
        'openai': 'OpenAI API'
    };
    const providerLabel = providerLabels[settings.embedding_provider] || settings.embedding_provider;

    // bearer:disable javascript_lang_dangerous_insert_html
    container.innerHTML = `
        <div class="ldr-info-item">
            <span class="ldr-info-label">Provider:</span>
            <span class="ldr-info-value">${escapeHtml(providerLabel)}</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Embedding Model:</span>
            <span class="ldr-info-value">${escapeHtml(settings.embedding_model || '')}</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Chunk Size:</span>
            <span class="ldr-info-value">${escapeHtml(String(settings.chunk_size ?? 1000))} characters</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Chunk Overlap:</span>
            <span class="ldr-info-value">${escapeHtml(String(settings.chunk_overlap ?? 200))} characters</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Splitter Type:</span>
            <span class="ldr-info-value">${escapeHtml(settings.splitter_type || 'recursive')}</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Distance Metric:</span>
            <span class="ldr-info-value">${escapeHtml(settings.distance_metric || 'cosine')}</span>
        </div>
        <div class="ldr-info-item">
            <span class="ldr-info-label">Index Type:</span>
            <span class="ldr-info-value">${escapeHtml(settings.index_type || 'flat')}</span>
        </div>
    `;
}

/**
 * Populate provider dropdown
 */
function populateProviders() {
    const providerSelect = document.getElementById('embedding-provider');
    const currentValue = providerSelect.value;

    // Clear existing options
    providerSelect.innerHTML = '';

    // Add provider options
    providerOptions.forEach(provider => {
        const option = document.createElement('option');
        option.value = provider.value;
        option.textContent = provider.available === false
            ? provider.label + ' (unavailable)'
            : provider.label;
        providerSelect.appendChild(option);
    });

    // Restore previous value if it exists
    if (currentValue && Array.from(providerSelect.options).some(opt => opt.value === currentValue)) {
        providerSelect.value = currentValue;
    } else if (providerSelect.options.length > 0) {
        providerSelect.value = providerSelect.options[0].value;
    }
}

/**
 * Update model dropdown based on selected provider
 */
function updateModelOptions() {
    const provider = document.getElementById('embedding-provider').value;
    const modelSelect = document.getElementById('embedding-model');
    const descriptionSpan = document.getElementById('model-description');

    // Remove any previous provider warning
    var oldWarning = document.getElementById('provider-unavailable-warning');
    if (oldWarning) oldWarning.remove();

    // Check if selected provider is unavailable
    var providerInfo = providerOptions.find(function(p) { return p.value === provider; });
    if (providerInfo && providerInfo.available === false) {
        var warning = document.createElement('div');
        warning.id = 'provider-unavailable-warning';
        warning.className = 'ldr-alert ldr-alert-danger';
        warning.style.marginTop = '8px';
        // bearer:disable javascript_lang_dangerous_insert_html
        warning.innerHTML = '<i class="fas fa-exclamation-triangle"></i> ' +
            escapeHtml(providerInfo.label) +
            ' is not reachable. Check the URL or service and try again.';
        var providerSelect = document.getElementById('embedding-provider');
        providerSelect.parentNode.insertBefore(warning, providerSelect.nextSibling);
    }

    // Clear existing options
    modelSelect.innerHTML = '';

    // Add models for selected provider
    const models = availableModels[provider] || [];
    models.forEach(modelData => {
        const option = document.createElement('option');
        option.value = modelData.value;

        // Mark embedding compatibility when the provider supplies it
        if (modelData.is_embedding === true) {
            option.textContent = modelData.label + ' (Embedding)';
            option.style.color = 'var(--ldr-success, #28a745)';
        } else if (modelData.is_embedding === false) {
            option.textContent = modelData.label + ' (LLM — may not support embeddings)';
            option.style.color = 'var(--ldr-warning, #ffc107)';
        } else {
            option.textContent = modelData.label;
        }

        modelSelect.appendChild(option);
    });

    if (models.length === 0) {
        const placeholder = document.createElement('option');
        placeholder.value = '';
        placeholder.textContent = 'No models available';
        placeholder.disabled = true;
        modelSelect.appendChild(placeholder);
    }

    // Update description and model hint
    updateModelDescription();
    updateModelHint();

    // Add change handler for model selection (remove old handler first)
    modelSelect.removeEventListener('change', onModelChange);
    modelSelect.addEventListener('change', onModelChange);
}

/**
 * Combined handler for model dropdown changes.
 */
function onModelChange() {
    updateModelDescription();
    updateModelHint();
}

/**
 * Show a contextual hint below the model dropdown based on the
 * selected model's embedding compatibility.
 */
function updateModelHint() {
    // Remove previous hint
    var oldHint = document.getElementById('model-embedding-hint');
    if (oldHint) oldHint.remove();

    const provider = document.getElementById('embedding-provider').value;
    const modelSelect = document.getElementById('embedding-model');
    const models = availableModels[provider] || [];
    const selected = models.find(function(m) { return m.value === modelSelect.value; });

    if (!selected || selected.is_embedding === undefined) return;

    var hint = document.createElement('small');
    hint.id = 'model-embedding-hint';
    hint.className = 'ldr-form-text';
    hint.style.display = 'block';
    hint.style.marginTop = '4px';

    if (selected.is_embedding === true) {
        hint.style.color = 'var(--ldr-success, #28a745)';
        // bearer:disable javascript_lang_dangerous_insert_html
        hint.innerHTML = '<i class="fas fa-check-circle"></i> Dedicated embedding model &mdash; recommended for search and RAG.';
    } else {
        hint.style.color = 'var(--ldr-warning, #ffc107)';
        // bearer:disable javascript_lang_dangerous_insert_html
        hint.innerHTML = '<i class="fas fa-exclamation-circle"></i> This is an LLM, not a dedicated embedding model. ' +
            'Some LLMs can still produce embeddings but results vary. Use <strong>Test Embedding Model</strong> to verify.';
    }

    modelSelect.parentNode.appendChild(hint);
}

/**
 * Update model description text
 */
function updateModelDescription() {
    const provider = document.getElementById('embedding-provider').value;
    const modelSelect = document.getElementById('embedding-model');
    const descriptionSpan = document.getElementById('model-description');

    // Get selected model's label which contains the description
    const selectedOption = modelSelect.options[modelSelect.selectedIndex];
    if (selectedOption) {
        // Extract description from label (after the dash)
        const label = selectedOption.textContent;
        const parts = label.split(' - ');
        if (parts.length > 1) {
            descriptionSpan.textContent = parts.slice(1).join(' - ');
        } else {
            descriptionSpan.textContent = '';
        }
    } else {
        descriptionSpan.textContent = '';
    }
}

/**
 * Update provider information display
 */
function updateProviderInfo() {
    const providerInfo = document.getElementById('provider-info');

    let infoHTML = '';

    providerOptions.forEach(provider => {
        const providerKey = provider.value;
        const models = availableModels[providerKey] || [];

        // Add provider-specific notes
        let providerNote = '';
        if (providerKey === 'ollama') {
            const embeddingCount = models.filter(function(m) { return m.is_embedding === true; }).length;
            providerNote = `
                <div class="ldr-alert ldr-alert-info" style="margin-top: 10px; padding: 8px 12px; font-size: 0.85em;">
                    <i class="fas fa-info-circle"></i>
                    <strong>${embeddingCount} embedding model${embeddingCount !== 1 ? 's' : ''}</strong> detected
                    out of ${models.length} total.
                    <br><br>
                    <strong>Dedicated embedding models</strong> (e.g. nomic-embed-text, mxbai-embed-large)
                    are optimized for search and produce compact, high-quality vectors.
                    <br><br>
                    <strong>Some LLMs can also generate embeddings</strong> via Ollama's embed API,
                    but not all do &mdash; for example deepseek-r1 and nemotron work,
                    while qwen3 does not. LLM embeddings tend to have much higher dimensions
                    and are not optimized for similarity search.
                    <br><br>
                    Use the <strong>Test Embedding Model</strong> button above to verify
                    your selection works before saving.
                </div>
            `;
        }

        var statusIcon, statusText, statusClass;
        if (provider.available === false) {
            statusIcon = 'fa-exclamation-triangle';
            statusText = 'Not reachable';
            statusClass = 'ldr-provider-status-unavailable';
        } else {
            statusIcon = 'fa-check-circle';
            statusText = 'Ready';
            statusClass = '';
        }

        const embCount = models.filter(function(m) { return m.is_embedding === true; }).length;
        const modelCountLabel = embCount > 0
            ? `${embCount} embedding / ${models.length} total`
            : `${models.length}`;

        infoHTML += `
            <div class="ldr-stat-card">
                <h4>${escapeHtml(provider.label)}</h4>
                <p><strong>Models Available:</strong> ${modelCountLabel}</p>
                <div class="provider-status ${statusClass}">
                    <i class="fas ${statusIcon}"></i> ${statusText}
                </div>
                ${providerNote}
            </div>
        `;
    });

    // bearer:disable javascript_lang_dangerous_insert_html
    providerInfo.innerHTML = infoHTML;
}

/**
 * Handle configuration form submission
 */
async function handleConfigSubmit(event) {
    event.preventDefault();
    SafeLogger.log('🚀 Configuration form submitted!');

    const provider = document.getElementById('embedding-provider').value;

    // Save Ollama URL first if provider is ollama
    if (provider === 'ollama') {
        const ollamaUrlSaved = await saveOllamaUrl();
        if (!ollamaUrlSaved) {
            showError('Failed to save Ollama URL');
            return;
        }
    }

    // Get text separators and parse JSON
    let textSeparators;
    const textSeparatorsValue = document.getElementById('text-separators').value.trim();
    if (textSeparatorsValue) {
        try {
            textSeparators = JSON.parse(textSeparatorsValue);
            if (!Array.isArray(textSeparators)) {
                showError('Text separators must be a JSON array');
                return;
            }
        } catch (e) {
            showError('Invalid JSON format for text separators');
            return;
        }
    } else {
        // Use default if empty
        textSeparators = ["\n\n", "\n", ". ", " ", ""];
    }

    const formData = {
        embedding_provider: provider,
        embedding_model: document.getElementById('embedding-model').value,
        chunk_size: parseInt(document.getElementById('chunk-size').value),
        chunk_overlap: parseInt(document.getElementById('chunk-overlap').value),
        splitter_type: document.getElementById('splitter-type').value,
        distance_metric: document.getElementById('distance-metric').value,
        index_type: document.getElementById('index-type').value,
        normalize_vectors: document.getElementById('normalize-vectors').checked,
        text_separators: textSeparators
    };

    SafeLogger.log('📋 Form data:', formData);

    // Validation
    if (!formData.embedding_provider) {
        SafeLogger.error('❌ No provider selected');
        showError('Please select an embedding provider');
        return;
    }

    if (!formData.embedding_model) {
        SafeLogger.error('❌ No model selected');
        showError('Please select an embedding model');
        return;
    }

    if (formData.chunk_size < 100 || formData.chunk_size > 5000) {
        SafeLogger.error('❌ Invalid chunk size:', formData.chunk_size);
        showError('Chunk size must be between 100 and 5000 characters');
        return;
    }

    if (formData.chunk_overlap < 0 || formData.chunk_overlap > 1000) {
        SafeLogger.error('❌ Invalid chunk overlap:', formData.chunk_overlap);
        showError('Chunk overlap must be between 0 and 1000 characters');
        return;
    }

    SafeLogger.log('✅ Form validation passed');

    try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
        SafeLogger.log('🔐 CSRF Token:', csrfToken ? 'Found' : 'Not found');

        const response = await safeFetch('/library/api/rag/configure', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify(formData)
        });

        SafeLogger.log('📡 Response status:', response.status);
        const responseText = await response.text();
        SafeLogger.log('📄 Response text:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            SafeLogger.error('❌ Failed to parse JSON:', parseError);
            SafeLogger.error('❌ Response was:', responseText);
            showError('Server returned invalid response. Check console for details.');
            return;
        }

        if (data.success) {
            SafeLogger.log('✅ Default settings saved successfully!');
            showSuccess('Default embedding settings saved successfully! New collections will use these settings.');
            currentSettings = formData;
            // Update the saved defaults display
            renderSavedDefaults(formData);
            // Re-check provider availability (e.g. Ollama URL may have changed)
            await loadAvailableModels();
        } else {
            SafeLogger.error('❌ Server returned error:', data.error);
            showError('Failed to save default settings: ' + data.error);
        }
    } catch (error) {
        SafeLogger.error('❌ Error updating configuration:', error);
        showError('Failed to save configuration: ' + error.message);
    }
}

/**
 * Test configuration by sending a real embedding request
 */
async function testConfiguration() {
    const provider = document.getElementById('embedding-provider').value;
    const model = document.getElementById('embedding-model').value;
    const testBtn = document.getElementById('test-config-btn');
    const testResult = document.getElementById('test-result');

    if (!provider || !model) {
        showError('Please select a provider and model first');
        return;
    }

    // Disable button during test
    testBtn.disabled = true;
    testBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testing...';

    testResult.style.display = 'block';
    testResult.innerHTML = '<div class="ldr-alert ldr-alert-info"><i class="fas fa-spinner fa-spin"></i> Testing embedding model... For local providers this may take a moment while the model is loaded into memory.</div>';

    try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

        // Send test embedding request with selected configuration
        const response = await safeFetch('/library/api/rag/test-embedding', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify({
                provider: provider,
                model: model,
                test_text: 'This is a test sentence to verify the embedding model is working correctly.'
            })
        });

        const data = await response.json();

        if (data.success) {
            const responseTime = parseInt(data.response_time_ms);
            const slowHint = responseTime > 3000
                ? '<br><i class="fas fa-info-circle"></i> <em>Slow response time may be due to initial model loading. Test again for a more accurate measurement.</em>'
                : '';
            // bearer:disable javascript_lang_dangerous_insert_html
            testResult.innerHTML = `
                <div class="ldr-alert ldr-alert-success">
                    <i class="fas fa-check-circle"></i> <strong>Test Passed!</strong><br>
                    Model: ${window.XSSProtection.escapeHtml(model)}<br>
                    Provider: ${window.XSSProtection.escapeHtml(provider)}<br>
                    Embedding dimension: ${window.XSSProtection.escapeHtml(String(data.dimension))}<br>
                    Response time: ${window.XSSProtection.escapeHtml(String(data.response_time_ms))}ms
                    ${slowHint}
                </div>
            `;
            showSuccess('Embedding test passed!');
        } else {
            // bearer:disable javascript_lang_dangerous_insert_html
            testResult.innerHTML = `
                <div class="ldr-alert ldr-alert-danger">
                    <i class="fas fa-times-circle"></i> <strong>Test Failed!</strong><br>
                    Error: ${window.XSSProtection.escapeHtml(data.error || 'Unknown error')}
                </div>
            `;
            // Safe: showError escapes internally
            showError('Embedding test failed: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        // bearer:disable javascript_lang_dangerous_insert_html
        testResult.innerHTML = `
            <div class="ldr-alert ldr-alert-danger">
                <i class="fas fa-times-circle"></i> <strong>Test Failed!</strong><br>
                Error: ${window.XSSProtection.escapeHtml(error.message)}
            </div>
        `;
        // Safe: showError escapes internally
        showError('Test failed: ' + error.message);
    } finally {
        // Re-enable button
        testBtn.disabled = false;
        testBtn.innerHTML = '<i class="fas fa-play"></i> Test Embedding Model';
    }
}

/**
 * Show success message.
 * @param {string} message - Raw, unescaped text. HTML-escaping is handled internally.
 */
function showSuccess(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'ldr-alert ldr-alert-success';
    // Escape message before including in HTML template
    // bearer:disable javascript_lang_dangerous_insert_html
    alertDiv.innerHTML = `<i class="fas fa-check-circle"></i>${escapeHtml(message)}`;

    // Insert at the top of the container
    const container = document.querySelector('.ldr-library-container');
    container.insertBefore(alertDiv, container.firstChild);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 5000);
}

/**
 * Show info message.
 * @param {string} message - Raw, unescaped text. HTML-escaping is handled internally.
 */
function showInfo(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'ldr-alert ldr-alert-info';
    // Escape message before including in HTML template
    // bearer:disable javascript_lang_dangerous_insert_html
    alertDiv.innerHTML = `<i class="fas fa-info-circle"></i>${escapeHtml(message)}`;

    // Insert at the top of the container
    const container = document.querySelector('.ldr-library-container');
    container.insertBefore(alertDiv, container.firstChild);

    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 3000);
}

/**
 * Show error message.
 * @param {string} message - Raw, unescaped text. HTML-escaping is handled internally.
 */
function showError(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'ldr-alert ldr-alert-danger';
    // Escape message before including in HTML template
    // bearer:disable javascript_lang_dangerous_insert_html
    alertDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i>${escapeHtml(message)}`;

    // Insert at the top of the container
    const container = document.querySelector('.ldr-library-container');
    container.insertBefore(alertDiv, container.firstChild);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 5000);
}

// Prefer the full escapeHtml from xss-protection.js; inline fallback if it hasn't loaded yet
// bearer:disable javascript_lang_manual_html_sanitization
var escapeHtml = window.escapeHtml || function(str) {
    return String(str).replace(/[&<>"']/g, function(m) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
    });
};


/**
 * Toggle Ollama URL field visibility based on selected provider
 */
function toggleOllamaUrlField() {
    const provider = document.getElementById('embedding-provider').value;
    const ollamaUrlGroup = document.getElementById('ollama-url-group');

    if (provider === 'ollama') {
        ollamaUrlGroup.style.display = 'block';
    } else {
        ollamaUrlGroup.style.display = 'none';
    }
}

/**
 * Load Ollama URL from settings
 */
async function loadOllamaUrl() {
    try {
        const response = await safeFetch('/settings/api/embeddings.ollama.url');
        const data = await response.json();

        if (data && data.value) {
            document.getElementById('ollama-url').value = data.value;
        }
    } catch (error) {
        SafeLogger.error('Error loading Ollama URL:', error);
    }
}

/**
 * Save Ollama URL to settings
 */
async function saveOllamaUrl() {
    const ollamaUrl = document.getElementById('ollama-url').value.trim();

    try {
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

        const response = await safeFetch('/settings/api/embeddings.ollama.url', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify({
                value: ollamaUrl
            })
        });

        const data = await response.json();
        if (data.error) {
            SafeLogger.error('Failed to save Ollama URL:', data.error);
            return false;
        }
        return true;
    } catch (error) {
        SafeLogger.error('Error saving Ollama URL:', error);
        return false;
    }
}
