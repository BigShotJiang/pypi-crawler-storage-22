# SPDX-License-Identifier: Apache-2.0
"""Allow running as python -m local_openai2anthropic"""

from local_openai2anthropic.main import main

if __name__ == "__main__":
    main()
