"""CLI interface for Local Terminal MCP Server."""

import asyncio
import logging
import sys

import click

from .config import Config
from .server import LocalTerminalMCPServer
from .tools import execute_command

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)


@click.group()
def cli():
    """Local Terminal MCP Server - Connect your local terminal to Agent Builder."""
    pass


@cli.command()
@click.option("--url", help="Agent Builder WebSocket URL")
@click.option("--token", help="JWT token (skips browser auth; for CI/headless)")
@click.option("--team", help="Team ID to connect to (from URL: /teams/<team_id>)")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def connect(url: str | None, token: str | None, team: str | None, debug: bool):
    """
    Connect to Agent Builder.

    Authenticates via browser (OAuth PKCE) on first run.
    Subsequent runs use cached token for instant connect.
    Use --token flag for CI/headless environments.
    Use --team flag if you belong to multiple teams.
    """
    if debug:
        logging.getLogger().setLevel(logging.DEBUG)

    click.echo("🔌 Local Terminal MCP Server")
    click.echo("=" * 50)

    try:
        config = Config()

        if url:
            config.agent_builder_url = url

        if team:
            config.team_id = team

        # ── Resolve auth token ──────────────────────────────
        if token:
            # Explicit token from CLI flag (CI/headless)
            click.echo("\n✅ Using token from --token flag")
            config.auth_token = token

        elif config.auth_token:
            # Token from .env file
            click.echo("\n✅ Using token from .env")

        else:
            # OAuth PKCE flow: cached token or browser auth
            config.auth_token = _resolve_token_via_oauth(config, debug)

        # ── Show configuration ──────────────────────────────
        click.echo(f"\n   URL: {config.agent_builder_url}")
        if config.team_id:
            click.echo(f"   Team: {config.team_id}")
        click.echo(f"   Security: {'Whitelist mode' if config.whitelist_only else 'Blacklist mode'}")
        click.echo(f"   Max timeout: {config.max_command_timeout}s")
        click.echo()

        # ── Build token refresher for auto-reconnect ─────────
        def _make_token_refresher():
            """Create a token refresher callback for reconnection."""
            if token:
                # Explicit --token flag: can't refresh
                return None
            if config.auth_token and not hasattr(config, '_from_oauth'):
                # Token from .env: can't refresh
                return None

            # OAuth flow: use refresh token
            from . import token_store
            from .oauth import OAuthPKCEFlow

            def refresher() -> str:
                cached = token_store.load_tokens()
                if cached and not token_store.is_access_expired(cached):
                    return cached["access_token"]
                if cached and token_store.has_refresh_token(cached):
                    oauth = OAuthPKCEFlow(
                        keycloak_url=config.keycloak_url,
                        client_id=config.keycloak_client_id,
                    )
                    new_tokens = asyncio.run(
                        oauth.refresh_access_token(cached["refresh_token"])
                    )
                    token_store.save_tokens(new_tokens)
                    return new_tokens["access_token"]
                return ""

            return refresher

        # ── Connect via WebSocket ───────────────────────────
        from .websocket_client import MCPWebSocketClient

        client = MCPWebSocketClient(config, token_refresher=_make_token_refresher())

        try:
            asyncio.run(client.connect())
        except KeyboardInterrupt:
            click.echo("\n👋 Disconnected by user")
        except Exception as e:
            click.echo(f"\n❌ Connection failed: {e}")
            if debug:
                import traceback
                traceback.print_exc()
            sys.exit(1)

    except RuntimeError as e:
        # Actionable errors (port busy, config issues)
        click.echo(f"\n❌ {e}")
        sys.exit(1)

    except Exception as e:
        click.echo(f"❌ Error: {e}")
        if debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def _resolve_token_via_oauth(config: Config, debug: bool) -> str:
    """
    Get JWT token via OAuth PKCE flow.

    Priority:
    1. Cached token (not expired) → use directly
    2. Cached token expired + refresh token → refresh
    3. No cached token → full browser auth flow
    """
    from . import token_store
    from .oauth import OAuthPKCEFlow

    # Try cached token
    cached = token_store.load_tokens()

    if cached and not token_store.is_access_expired(cached):
        info = token_store.get_token_info(cached)
        click.echo(f"\n✅ Using cached token ({info})")
        return cached["access_token"]

    # Try refresh
    if cached and token_store.has_refresh_token(cached):
        click.echo("\n🔄 Token expired, refreshing...")
        oauth = OAuthPKCEFlow(
            keycloak_url=config.keycloak_url,
            client_id=config.keycloak_client_id,
        )
        try:
            new_tokens = asyncio.run(
                oauth.refresh_access_token(cached["refresh_token"])
            )
            token_store.save_tokens(new_tokens)
            click.echo("✅ Token refreshed")
            return new_tokens["access_token"]
        except Exception as e:
            click.echo(f"⚠️  Refresh failed ({e}), starting browser auth...")

    # Full browser auth
    click.echo("\n🔐 No cached token found. Starting authentication...")
    oauth = OAuthPKCEFlow(
        keycloak_url=config.keycloak_url,
        client_id=config.keycloak_client_id,
    )

    auth_url_shown = False

    def _show_manual_url():
        """Show URL for manual opening if browser doesn't work."""
        nonlocal auth_url_shown
        if not auth_url_shown:
            click.echo("   If browser doesn't open, visit the URL above.")
            auth_url_shown = True

    try:
        token_data = asyncio.run(oauth.authenticate())
        token_store.save_tokens(token_data)
        click.echo(f"✅ Authenticated! Token cached in {token_store.TOKEN_FILE}")
        return token_data["access_token"]
    except TimeoutError:
        click.echo("❌ Authentication timed out (120s). Try again or use --token flag.")
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Authentication failed: {e}")
        if debug:
            import traceback
            traceback.print_exc()
        click.echo("\n💡 Alternatives:")
        click.echo("   local-terminal-mcp connect --token \"YOUR_JWT_TOKEN\"")
        click.echo("   LT_MCP_AUTH_TOKEN=... local-terminal-mcp connect")
        sys.exit(1)


@cli.command()
def logout():
    """Clear cached authentication tokens."""
    from . import token_store

    token_store.clear_tokens()
    click.echo("✅ Logged out. Cached tokens cleared.")


@cli.command()
def status():
    """Show authentication and configuration status."""
    from . import token_store

    click.echo("📋 Local Terminal MCP Status")
    click.echo("=" * 50)

    # Config
    try:
        config = Config()
        click.echo(f"\n   URL: {config.agent_builder_url}")
        click.echo(f"   Keycloak: {config.keycloak_url}")
        click.echo(f"   Client ID: {config.keycloak_client_id}")
    except Exception:
        click.echo("\n   Config: using defaults (no .env)")

    # Token
    cached = token_store.load_tokens()
    if cached:
        info = token_store.get_token_info(cached)
        click.echo(f"   Token: {info}")
        click.echo(f"   Token file: {token_store.TOKEN_FILE}")
    else:
        click.echo("   Token: not cached (will auth on next connect)")


@cli.command("config-wizard")
@click.option("--url", help="Agent Builder WebSocket URL")
@click.option("--token", help="Authentication JWT token")
def config_wizard(url: str | None, token: str | None):
    """
    [Legacy] Configure connection via .env file.

    Prefer using `local-terminal-mcp connect` which authenticates
    automatically via browser (OAuth PKCE).
    """
    click.echo("🧙 Local Terminal MCP Configuration Wizard")
    click.echo("=" * 50)
    click.echo()
    click.echo("💡 Note: `local-terminal-mcp connect` now authenticates")
    click.echo("   automatically via browser. This wizard is for manual setup.")
    click.echo()

    # URL
    default_url = "wss://agent-builder-stage-api.dc02.gsd1.io"
    if not url:
        url = click.prompt("Agent Builder URL", type=str, default=default_url)

    # Token: from arg, stdin pipe, or prompt
    if not token:
        if not sys.stdin.isatty():
            token = sys.stdin.read().strip()
            if token:
                click.echo("✅ Token read from stdin")
        else:
            click.echo("\n💡 Tip: Use --token flag for long tokens")
            token = click.prompt("Auth Token", type=str, hide_input=True)

    if not token:
        click.echo("❌ Error: Token is required")
        sys.exit(1)

    env_content = f"""# Local Terminal MCP Server Configuration
LT_MCP_AGENT_BUILDER_URL={url}
LT_MCP_AUTH_TOKEN={token}
LT_MCP_WHITELIST_ONLY=false
LT_MCP_BLOCKED_PATHS=["/etc","/sys","/proc","/root","/boot"]
LT_MCP_MAX_COMMAND_TIMEOUT=300
LT_MCP_LOG_LEVEL=INFO
"""

    with open(".env", "w") as f:
        f.write(env_content)

    click.echo()
    click.echo("✅ Configuration saved to .env")
    click.echo(f"   URL: {url}")
    click.echo(f"   Token: {token[:20]}...{token[-10:]}")
    click.echo()
    click.echo("Next: local-terminal-mcp connect")


@cli.command()
@click.option("--debug", is_flag=True, help="Enable debug logging")
def test(debug: bool):
    """Test local tools without connecting to Agent Builder."""
    if debug:
        logging.getLogger().setLevel(logging.DEBUG)

    click.echo("🧪 Testing Local Terminal MCP Server")
    click.echo("=" * 50)

    try:
        config = Config()
        server = LocalTerminalMCPServer(config)

        click.echo(f"\n✅ Server initialized")
        click.echo(server.get_tools_summary())

        # Test execute_command
        click.echo("\n🔧 Testing execute_command tool...")
        result = asyncio.run(
            execute_command(
                "echo 'Hello from Local Terminal MCP!'",
                security_config=config.get_security_config(),
            )
        )
        click.echo(f"   Result: {result.strip()}")

        # Test MCP protocol
        click.echo("\n🔧 Testing MCP protocol...")

        init_result = asyncio.run(server.handle_initialize({}))
        click.echo(f"   ✅ Initialize: {init_result['serverInfo']['name']}")

        tools_result = asyncio.run(server.handle_list_tools())
        tools = tools_result["tools"]
        click.echo(f"   ✅ List tools: {len(tools)} tools available")

        call_result = asyncio.run(
            server.handle_call_tool("execute_command", {"command": "pwd"})
        )
        click.echo(f"   ✅ Call tool: {call_result['content'][0]['text'].strip()}")

        click.echo("\n✅ All tests passed!")
        click.echo("\nReady to connect:")
        click.echo("  local-terminal-mcp connect")

    except Exception as e:
        click.echo(f"\n❌ Error: {e}")
        if debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


@cli.command()
def version():
    """Show version information."""
    from . import __version__
    click.echo(f"Local Terminal MCP Server v{__version__}")


if __name__ == "__main__":
    cli()
