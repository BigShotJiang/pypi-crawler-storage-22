"""Configuration for Local Terminal MCP Server."""

import json
from typing import List
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    """Configuration for Local Terminal MCP Server."""

    model_config = SettingsConfigDict(
        env_prefix="LT_MCP_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore extra fields from .env
    )

    agent_builder_url: str = Field(
        default="wss://agent-builder-stage-api.dc02.gsd1.io",
        description="Agent Builder WebSocket URL",
    )

    auth_token: str = Field(
        default="",
        description="Authentication token (auto-filled via OAuth or --token flag)",
    )

    team_id: str = Field(
        default="",
        description="Team ID to connect to (for users in multiple teams)",
    )

    # Keycloak OAuth settings
    keycloak_url: str = Field(
        default="https://auth.galileosky.com/realms/GS",
        description="Keycloak realm URL for OAuth PKCE authentication",
    )

    keycloak_client_id: str = Field(
        default="local-terminal-mcp",
        description="Keycloak OAuth client ID",
    )

    # Security settings
    whitelist_only: bool = Field(
        default=False,
        description="Enable whitelist-only mode (only whitelisted commands allowed)",
    )

    allowed_paths: List[str] = Field(
        default_factory=list,
        description="List of allowed file paths (empty = all non-blocked paths allowed)",
    )

    blocked_paths: List[str] = Field(
        default_factory=lambda: ["/etc", "/sys", "/proc", "/root", "/boot"],
        description="List of blocked file paths",
    )

    max_command_timeout: int = Field(
        default=300,
        ge=1,
        le=3600,
        description="Maximum command timeout in seconds (1-3600)",
    )

    # Logging
    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR)",
    )

    log_file: str | None = Field(
        default=None,
        description="Log file path (None = log to stdout only)",
    )

    @field_validator("allowed_paths", "blocked_paths", mode="before")
    @classmethod
    def parse_json_list(cls, v):
        """Parse JSON string to list if needed."""
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return []
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level."""
        valid_levels = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        v_upper = v.upper()
        if v_upper not in valid_levels:
            raise ValueError(f"Invalid log level: {v}. Must be one of {valid_levels}")
        return v_upper

    def get_security_config(self) -> dict:
        """Get security configuration dict for SecurityValidator."""
        return {
            "whitelist_only": self.whitelist_only,
            "allowed_paths": self.allowed_paths,
            "blocked_paths": self.blocked_paths,
        }
