"""OAuth 2.0 Authorization Code Flow with PKCE for CLI authentication."""

import asyncio
import base64
import hashlib
import logging
import secrets
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

logger = logging.getLogger(__name__)

# Defaults (overridable via Config)
DEFAULT_KEYCLOAK_URL = "https://auth.galileosky.com/realms/GS"
DEFAULT_CLIENT_ID = "local-terminal-mcp"
CALLBACK_PORT = 29170  # Fixed port — must match Keycloak redirect URI
CALLBACK_TIMEOUT = 120  # seconds to wait for browser callback


class OAuthPKCEFlow:
    """
    OAuth 2.0 Authorization Code Flow with PKCE.

    Opens the user's browser for Keycloak login, receives the auth code
    via a localhost callback, and exchanges it for JWT tokens.
    Works like `gh auth login` / `gcloud auth login`.
    """

    def __init__(self, keycloak_url: str = DEFAULT_KEYCLOAK_URL, client_id: str = DEFAULT_CLIENT_ID):
        self.keycloak_url = keycloak_url.rstrip("/")
        self.client_id = client_id
        self._oidc_config: dict | None = None

    # ── OIDC Discovery ──────────────────────────────────────────

    async def discover_endpoints(self) -> dict:
        """Fetch OIDC endpoints from Keycloak well-known configuration."""
        if self._oidc_config:
            return self._oidc_config

        well_known_url = f"{self.keycloak_url}/.well-known/openid-configuration"
        logger.debug(f"Fetching OIDC config from {well_known_url}")

        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(well_known_url)
            resp.raise_for_status()
            self._oidc_config = resp.json()

        # Keycloak may return internal hostnames in endpoints (e.g. keycloak-gs.boquar.tech)
        # that are unreachable from external networks. Replace them with the public
        # keycloak_url host so all HTTP calls go through the public domain.
        self._oidc_config = self._rewrite_endpoints_to_public(self._oidc_config)

        logger.debug(f"OIDC endpoints discovered: auth={self._oidc_config.get('authorization_endpoint')}")
        return self._oidc_config

    def _rewrite_endpoints_to_public(self, oidc_config: dict) -> dict:
        """Replace internal Keycloak hostnames with the public keycloak_url host."""
        public_parsed = urlparse(self.keycloak_url)
        public_origin = f"{public_parsed.scheme}://{public_parsed.netloc}"

        endpoint_keys = [
            "authorization_endpoint", "token_endpoint", "userinfo_endpoint",
            "end_session_endpoint", "jwks_uri", "introspection_endpoint",
        ]
        for key in endpoint_keys:
            url = oidc_config.get(key)
            if url:
                parsed = urlparse(url)
                if parsed.netloc != public_parsed.netloc:
                    rewritten = f"{public_origin}{parsed.path}"
                    logger.debug(f"Rewriting {key}: {parsed.netloc} -> {public_parsed.netloc}")
                    oidc_config[key] = rewritten
        return oidc_config

    async def _get_auth_endpoint(self) -> str:
        config = await self.discover_endpoints()
        return config["authorization_endpoint"]

    async def _get_token_endpoint(self) -> str:
        config = await self.discover_endpoints()
        return config["token_endpoint"]

    # ── PKCE ────────────────────────────────────────────────────

    @staticmethod
    def generate_pkce_pair() -> tuple[str, str]:
        """
        Generate PKCE code_verifier and code_challenge (S256).

        Returns:
            (code_verifier, code_challenge)
        """
        verifier = secrets.token_urlsafe(43)  # 43 bytes → ~57 chars
        digest = hashlib.sha256(verifier.encode("ascii")).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        return verifier, challenge

    # ── Auth URL ────────────────────────────────────────────────

    async def build_auth_url(self, code_challenge: str, redirect_uri: str, state: str) -> str:
        """Build Keycloak authorization URL with PKCE parameters."""
        auth_endpoint = await self._get_auth_endpoint()
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "scope": "openid profile email",
            "state": state,
        }
        return f"{auth_endpoint}?{urlencode(params)}"

    # ── Localhost Callback Server ───────────────────────────────

    def start_callback_server(self, expected_state: str) -> tuple[int, "asyncio.Future[str]"]:
        """
        Start a temporary localhost HTTP server to receive the OAuth callback.

        Returns:
            (port, future) — port the server is listening on,
            future that resolves with the authorization code.
        """
        loop = asyncio.get_event_loop()
        code_future: asyncio.Future[str] = loop.create_future()
        keycloak_url = self.keycloak_url
        client_id = self.client_id

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                params = parse_qs(parsed.query)

                # Check for errors
                if "error" in params:
                    error = params["error"][0]
                    error_desc = params.get("error_description", ["Unknown error"])[0]
                    self._send_response(
                        "Authentication Failed",
                        f"Error: {error} — {error_desc}",
                        success=False,
                    )
                    if not code_future.done():
                        loop.call_soon_threadsafe(
                            code_future.set_exception,
                            Exception(f"OAuth error: {error} — {error_desc}"),
                        )
                    return

                # Validate state
                received_state = params.get("state", [""])[0]
                if received_state != expected_state:
                    self._send_response(
                        "Authentication Failed",
                        "Invalid state parameter (possible CSRF attack).",
                        success=False,
                    )
                    if not code_future.done():
                        loop.call_soon_threadsafe(
                            code_future.set_exception,
                            Exception("OAuth state mismatch"),
                        )
                    return

                # Extract code
                code = params.get("code", [None])[0]
                if code:
                    self._send_response(
                        "Authentication Successful!",
                        "You can close this tab and return to your terminal.",
                        success=True,
                    )
                    if not code_future.done():
                        loop.call_soon_threadsafe(code_future.set_result, code)
                else:
                    self._send_response(
                        "Authentication Failed",
                        "No authorization code received.",
                        success=False,
                    )
                    if not code_future.done():
                        loop.call_soon_threadsafe(
                            code_future.set_exception,
                            Exception("No authorization code in callback"),
                        )

            def _send_response(self, title: str, message: str, success: bool):
                color = "#10b981" if success else "#ef4444"
                icon = "&#x2705;" if success else "&#x274C;"
                logout_url = (
                    f"{keycloak_url}/protocol/openid-connect/logout"
                    f"?client_id={client_id}"
                    f"&post_logout_redirect_uri=http://localhost:{CALLBACK_PORT}/callback"
                )
                switch_btn = ""
                if success:
                    switch_btn = f"""
<div style="margin-top:30px;">
  <a href="{logout_url}"
     style="display:inline-block;padding:12px 24px;background:#334155;color:#94a3b8;
     border-radius:8px;text-decoration:none;font-size:14px;transition:background 0.2s;">
     Sign out and use a different account
  </a>
</div>"""
                html = f"""<!DOCTYPE html>
<html><head><title>{title}</title></head>
<body style="font-family:system-ui;display:flex;justify-content:center;align-items:center;
height:100vh;margin:0;background:#0f0f1a;color:white;">
<div style="text-align:center;">
<div style="font-size:64px;margin-bottom:20px;">{icon}</div>
<h1 style="color:{color};">{title}</h1>
<p style="color:#94a3b8;">{message}</p>
{switch_btn}
</div></body></html>"""
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode())

            def log_message(self, format, *args):
                """Suppress default HTTP server logging."""
                logger.debug(f"Callback server: {format % args}")

        # Bind to fixed port (must match Keycloak redirect URI config)
        try:
            server = HTTPServer(("127.0.0.1", CALLBACK_PORT), CallbackHandler)
        except OSError as e:
            if e.errno == 48 or "address already in use" in str(e).lower():
                raise RuntimeError(
                    f"Port {CALLBACK_PORT} is already in use. "
                    f"Close the other process or wait a moment and try again.\n"
                    f"  Check: lsof -i :{CALLBACK_PORT}"
                ) from e
            raise
        port = server.server_address[1]

        # Run in background thread (handles exactly 1 request)
        def serve_once():
            server.handle_request()
            server.server_close()

        thread = Thread(target=serve_once, daemon=True)
        thread.start()

        logger.debug(f"Callback server listening on port {port}")
        return port, code_future

    # ── Token Exchange ──────────────────────────────────────────

    async def exchange_code(self, code: str, code_verifier: str, redirect_uri: str) -> dict:
        """
        Exchange authorization code for access + refresh tokens.

        Returns:
            Token response dict with access_token, refresh_token, expires_in, etc.
        """
        token_endpoint = await self._get_token_endpoint()

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(token_endpoint, data={
                "grant_type": "authorization_code",
                "client_id": self.client_id,
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": code_verifier,
            })
            resp.raise_for_status()
            return resp.json()

    async def refresh_access_token(self, refresh_token: str) -> dict:
        """
        Get new access token using refresh token.

        Returns:
            Token response dict with new access_token, refresh_token, etc.
        """
        token_endpoint = await self._get_token_endpoint()

        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(token_endpoint, data={
                "grant_type": "refresh_token",
                "client_id": self.client_id,
                "refresh_token": refresh_token,
            })
            resp.raise_for_status()
            return resp.json()

    # ── Full Flow ───────────────────────────────────────────────

    async def authenticate(self) -> dict:
        """
        Run the complete OAuth PKCE flow:
        1. Generate PKCE pair
        2. Start localhost callback server
        3. Open browser for Keycloak login
        4. Wait for callback with auth code
        5. Exchange code for tokens

        Returns:
            Token response dict with access_token, refresh_token, expires_in, etc.

        Raises:
            TimeoutError: If user doesn't complete auth within CALLBACK_TIMEOUT seconds.
            Exception: On OAuth errors.
        """
        # Step 1: PKCE
        verifier, challenge = self.generate_pkce_pair()
        state = secrets.token_urlsafe(16)

        # Step 2: Callback server
        port, code_future = self.start_callback_server(expected_state=state)
        redirect_uri = f"http://localhost:{port}/callback"

        # Step 3: Auth URL + open browser
        auth_url = await self.build_auth_url(challenge, redirect_uri, state)
        logger.info(f"Opening browser for authentication...")
        logger.debug(f"Auth URL: {auth_url[:100]}...")

        opened = webbrowser.open(auth_url)
        if not opened:
            logger.warning("Could not open browser automatically")
            # URL will be printed by the CLI for manual opening

        # Step 4: Wait for callback
        try:
            code = await asyncio.wait_for(code_future, timeout=CALLBACK_TIMEOUT)
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"Authentication timed out after {CALLBACK_TIMEOUT}s. "
                "Please try again."
            )

        # Step 5: Exchange code for tokens
        logger.info("Exchanging authorization code for tokens...")
        token_data = await self.exchange_code(code, verifier, redirect_uri)

        logger.info("Authentication successful!")
        return token_data
