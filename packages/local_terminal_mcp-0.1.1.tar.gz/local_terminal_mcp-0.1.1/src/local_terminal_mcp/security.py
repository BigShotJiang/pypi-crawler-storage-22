"""Security validation for commands and file paths."""

import re
from pathlib import Path
from typing import List, Dict, Any


class SecurityValidator:
    """Security layer for command and file access validation."""

    # Dangerous commands (blacklist)
    BLOCKED_COMMANDS = [
        r"rm\s+-rf\s+/",  # Recursive delete root
        r"mkfs",  # Format disk
        r"dd\s+if=",  # Direct disk write
        r":\(\)\{\s*:\|:&\s*\};:",  # Fork bomb
        r"shutdown",
        r"reboot",
        r"halt",
        r"poweroff",
        r"init\s+0",
        r"init\s+6",
        r">\s*/dev/sd",  # Direct write to disk
        r"mkswap",
        r"swapon",
        r"swapoff",
    ]

    # Allowed command patterns (whitelist) - used only if whitelist_only=True
    ALLOWED_COMMANDS = [
        r"^ls\s+",
        r"^ls$",
        r"^cd\s+",
        r"^cd$",
        r"^pwd$",
        r"^cat\s+",
        r"^echo\s+",
        r"^git\s+",
        r"^npm\s+",
        r"^yarn\s+",
        r"^pnpm\s+",
        r"^pytest\s+",
        r"^python\s+",
        r"^python3\s+",
        r"^pip\s+",
        r"^pip3\s+",
        r"^docker\s+",
        r"^kubectl\s+",
        r"^make\s+",
        r"^cargo\s+",
        r"^go\s+",
        r"^node\s+",
        r"^which\s+",
        r"^type\s+",
        r"^file\s+",
        r"^grep\s+",
        r"^find\s+",
        r"^tree\s+",
        r"^wc\s+",
        r"^head\s+",
        r"^tail\s+",
        r"^diff\s+",
        r"^sort\s+",
        r"^uniq\s+",
    ]

    def __init__(self, config: Dict[str, Any] | None = None):
        """
        Initialize security validator.

        Args:
            config: Configuration dict with keys:
                - whitelist_only: bool - Enable whitelist-only mode
                - allowed_paths: List[str] - Allowed file paths
                - blocked_paths: List[str] - Blocked file paths
        """
        self.config = config or {}
        self.allowed_paths = self.config.get("allowed_paths", [])
        self.blocked_paths = self.config.get(
            "blocked_paths", ["/etc", "/sys", "/proc", "/root", "/boot"]
        )
        self.whitelist_only = self.config.get("whitelist_only", False)

    def is_command_allowed(self, command: str) -> bool:
        """
        Check if command is allowed to execute.

        Args:
            command: Shell command to validate

        Returns:
            True if command is safe to execute
        """
        if not command or not command.strip():
            return False

        # Check blacklist first (always applies)
        for pattern in self.BLOCKED_COMMANDS:
            if re.search(pattern, command, re.IGNORECASE):
                return False

        # If whitelist mode enabled, check against whitelist
        if self.whitelist_only:
            for pattern in self.ALLOWED_COMMANDS:
                if re.match(pattern, command):
                    return True
            return False

        # Default: allow if not in blacklist
        return True

    def is_path_allowed(self, path: str) -> bool:
        """
        Check if file path is allowed to access.

        Args:
            path: File path to validate

        Returns:
            True if path is safe to access
        """
        try:
            # Resolve to absolute path
            path_obj = Path(path).resolve()
            path_str = str(path_obj)

            # Check blocked paths first
            for blocked in self.blocked_paths:
                blocked_resolved = str(Path(blocked).resolve())
                if path_str.startswith(blocked_resolved):
                    return False

            # If allowed_paths specified, must match one
            if self.allowed_paths:
                for allowed in self.allowed_paths:
                    allowed_resolved = str(Path(allowed).resolve())
                    if path_str.startswith(allowed_resolved):
                        return True
                return False

            # Default: allow if not in blocked paths
            return True

        except Exception:
            # If path resolution fails, deny access
            return False

    def validate_command(self, command: str) -> tuple[bool, str | None]:
        """
        Validate command and return result with optional error message.

        Args:
            command: Command to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not self.is_command_allowed(command):
            if self.whitelist_only:
                return False, f"Command not in whitelist: {command}"
            else:
                return False, f"Command blocked for security: {command}"

        return True, None

    def validate_path(self, path: str) -> tuple[bool, str | None]:
        """
        Validate file path and return result with optional error message.

        Args:
            path: Path to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not self.is_path_allowed(path):
            return False, f"Path not allowed: {path}"

        return True, None
