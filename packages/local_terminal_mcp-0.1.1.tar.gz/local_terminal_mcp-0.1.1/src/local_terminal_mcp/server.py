"""Main MCP Server implementation."""

import json
import logging
from typing import Dict, Any

from .config import Config
from .tools import ALL_TOOLS

logger = logging.getLogger(__name__)


class LocalTerminalMCPServer:
    """
    MCP Server for local terminal access.

    This server exposes local terminal tools (execute_command, read_file, etc.)
    via the MCP protocol.
    """

    def __init__(self, config: Config):
        """
        Initialize the MCP server.

        Args:
            config: Configuration instance
        """
        self.config = config
        self.tools = ALL_TOOLS
        self.server_info = {
            "name": "local-terminal",
            "version": "0.1.0",
        }

        logger.info(f"Initialized MCP server with {len(self.tools)} tools")

    async def handle_initialize(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle MCP initialize request.

        Args:
            params: Initialize parameters from client

        Returns:
            Server capabilities and info
        """
        logger.info("Handling initialize request")

        return {
            "protocolVersion": "1.0",
            "serverInfo": self.server_info,
            "capabilities": {
                "tools": True,
            },
        }

    async def handle_list_tools(self) -> Dict[str, Any]:
        """
        Handle tools/list request.

        Returns:
            MCP tools/list result: {"tools": [...]}
        """
        logger.info("Handling list_tools request")

        tools_list = [
            {
                "name": tool["name"],
                "description": tool["description"],
                "inputSchema": tool["inputSchema"],
            }
            for tool in self.tools
        ]

        return {"tools": tools_list}

    async def handle_call_tool(
        self, tool_name: str, arguments: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handle tools/call request.

        Args:
            tool_name: Name of tool to call
            arguments: Tool arguments

        Returns:
            Tool execution result
        """
        logger.info(f"Handling call_tool: {tool_name}")

        # Find tool
        tool = None
        for t in self.tools:
            if t["name"] == tool_name:
                tool = t
                break

        if not tool:
            error_msg = f"Tool not found: {tool_name}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Add security config to arguments
        arguments["security_config"] = self.config.get_security_config()

        # Execute tool
        try:
            handler = tool["handler"]
            result = await handler(**arguments)

            return {
                "content": [
                    {
                        "type": "text",
                        "text": result,
                    }
                ]
            }

        except Exception as e:
            error_msg = f"Error executing tool {tool_name}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise

    async def handle_message(self, message: str) -> str:
        """
        Handle incoming MCP protocol message.

        Args:
            message: JSON-RPC 2.0 message

        Returns:
            JSON-RPC 2.0 response
        """
        try:
            request = json.loads(message)
            method = request.get("method")
            params = request.get("params", {})
            request_id = request.get("id")

            logger.debug(f"Received request: method={method}, id={request_id}")

            # Handle different methods
            if method == "initialize":
                result = await self.handle_initialize(params)
            elif method == "tools/list":
                result = await self.handle_list_tools()
            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                result = await self.handle_call_tool(tool_name, arguments)
            else:
                raise ValueError(f"Unknown method: {method}")

            # Build success response
            response = {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result,
            }

            logger.debug(f"Sending response: id={request_id}")
            return json.dumps(response)

        except Exception as e:
            # Build error response
            logger.error(f"Error handling message: {e}", exc_info=True)

            # Try to get request id if available
            request_id = None
            try:
                if 'request' in locals() and isinstance(request, dict):
                    request_id = request.get("id")
            except:
                pass

            error_response = {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32603,
                    "message": str(e),
                },
            }

            return json.dumps(error_response)

    def get_tools_summary(self) -> str:
        """
        Get a summary of available tools.

        Returns:
            Human-readable tools summary
        """
        summary = f"Available tools ({len(self.tools)}):\n"
        for tool in self.tools:
            summary += f"  • {tool['name']}: {tool['description']}\n"
        return summary
