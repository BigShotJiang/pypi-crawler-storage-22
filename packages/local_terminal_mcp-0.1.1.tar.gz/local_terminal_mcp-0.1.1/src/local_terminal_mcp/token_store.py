"""Persistent token storage for CLI authentication."""

import json
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)

TOKEN_DIR = Path.home() / ".lt-mcp"
TOKEN_FILE = TOKEN_DIR / "token.json"

# Margin before expiry to trigger refresh (seconds)
EXPIRY_MARGIN = 60


def save_tokens(token_response: dict) -> None:
    """
    Save OAuth token response to ~/.lt-mcp/token.json.

    Adds `expires_at` timestamp for easy expiry checks.
    File permissions set to 600 (owner read/write only).
    """
    TOKEN_DIR.mkdir(parents=True, exist_ok=True)

    # Add absolute expiry timestamp
    data = {
        "access_token": token_response["access_token"],
        "refresh_token": token_response.get("refresh_token"),
        "expires_in": token_response.get("expires_in", 1800),
        "expires_at": time.time() + token_response.get("expires_in", 1800),
        "token_type": token_response.get("token_type", "Bearer"),
    }

    TOKEN_FILE.write_text(json.dumps(data, indent=2))
    TOKEN_FILE.chmod(0o600)

    logger.debug(f"Tokens saved to {TOKEN_FILE}")


def load_tokens() -> dict | None:
    """
    Load cached tokens from disk.

    Returns:
        Token dict or None if not found / corrupted.
    """
    if not TOKEN_FILE.exists():
        return None

    try:
        data = json.loads(TOKEN_FILE.read_text())
        if "access_token" not in data:
            logger.warning("Token file exists but missing access_token")
            return None
        return data
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load token file: {e}")
        return None


def is_access_expired(token_data: dict) -> bool:
    """Check if the access token is expired (with margin)."""
    expires_at = token_data.get("expires_at", 0)
    return time.time() > (expires_at - EXPIRY_MARGIN)


def has_refresh_token(token_data: dict) -> bool:
    """Check if a refresh token is available."""
    return bool(token_data.get("refresh_token"))


def clear_tokens() -> None:
    """Delete cached tokens (logout)."""
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        logger.info(f"Tokens cleared from {TOKEN_FILE}")
    else:
        logger.info("No cached tokens to clear")


def get_token_info(token_data: dict) -> str:
    """Get human-readable token status for display."""
    if is_access_expired(token_data):
        if has_refresh_token(token_data):
            return "expired (refresh available)"
        return "expired"

    expires_at = token_data.get("expires_at", 0)
    remaining = int(expires_at - time.time())
    if remaining > 3600:
        return f"valid ({remaining // 3600}h {(remaining % 3600) // 60}m remaining)"
    if remaining > 60:
        return f"valid ({remaining // 60}m remaining)"
    return f"valid ({remaining}s remaining)"
