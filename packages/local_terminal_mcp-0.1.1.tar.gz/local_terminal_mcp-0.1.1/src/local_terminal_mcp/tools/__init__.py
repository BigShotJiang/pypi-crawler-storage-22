"""Tools for local terminal operations."""

from .execute_command import (
    execute_command,
    TOOL_NAME as EXECUTE_COMMAND_NAME,
    TOOL_DESCRIPTION as EXECUTE_COMMAND_DESC,
    TOOL_INPUT_SCHEMA as EXECUTE_COMMAND_SCHEMA,
)
from .read_file import (
    read_file,
    TOOL_NAME as READ_FILE_NAME,
    TOOL_DESCRIPTION as READ_FILE_DESC,
    TOOL_INPUT_SCHEMA as READ_FILE_SCHEMA,
)
from .write_file import (
    write_file,
    TOOL_NAME as WRITE_FILE_NAME,
    TOOL_DESCRIPTION as WRITE_FILE_DESC,
    TOOL_INPUT_SCHEMA as WRITE_FILE_SCHEMA,
)
from .list_directory import (
    list_directory,
    TOOL_NAME as LIST_DIRECTORY_NAME,
    TOOL_DESCRIPTION as LIST_DIRECTORY_DESC,
    TOOL_INPUT_SCHEMA as LIST_DIRECTORY_SCHEMA,
)

__all__ = [
    # Functions
    "execute_command",
    "read_file",
    "write_file",
    "list_directory",
    # Metadata
    "EXECUTE_COMMAND_NAME",
    "EXECUTE_COMMAND_DESC",
    "EXECUTE_COMMAND_SCHEMA",
    "READ_FILE_NAME",
    "READ_FILE_DESC",
    "READ_FILE_SCHEMA",
    "WRITE_FILE_NAME",
    "WRITE_FILE_DESC",
    "WRITE_FILE_SCHEMA",
    "LIST_DIRECTORY_NAME",
    "LIST_DIRECTORY_DESC",
    "LIST_DIRECTORY_SCHEMA",
]

# Tool registry for easy iteration
ALL_TOOLS = [
    {
        "name": EXECUTE_COMMAND_NAME,
        "description": EXECUTE_COMMAND_DESC,
        "inputSchema": EXECUTE_COMMAND_SCHEMA,
        "handler": execute_command,
    },
    {
        "name": READ_FILE_NAME,
        "description": READ_FILE_DESC,
        "inputSchema": READ_FILE_SCHEMA,
        "handler": read_file,
    },
    {
        "name": WRITE_FILE_NAME,
        "description": WRITE_FILE_DESC,
        "inputSchema": WRITE_FILE_SCHEMA,
        "handler": write_file,
    },
    {
        "name": LIST_DIRECTORY_NAME,
        "description": LIST_DIRECTORY_DESC,
        "inputSchema": LIST_DIRECTORY_SCHEMA,
        "handler": list_directory,
    },
]
