"""Execute command tool for local terminal."""

import os
import subprocess
import logging
from typing import Dict, Any

from ..security import SecurityValidator

logger = logging.getLogger(__name__)


async def execute_command(
    command: str,
    cwd: str | None = None,
    timeout: int = 30,
    security_config: Dict[str, Any] | None = None,
) -> str:
    """
    Execute a shell command and return output.

    Args:
        command: Shell command to execute
        cwd: Working directory (None = current directory)
        timeout: Timeout in seconds
        security_config: Security configuration for validator

    Returns:
        Command output (stdout + stderr)

    Raises:
        ValueError: If command is not allowed by security validator
    """
    # Security validation
    validator = SecurityValidator(config=security_config)
    is_valid, error_msg = validator.validate_command(command)

    if not is_valid:
        logger.warning(f"Blocked command: {command} - {error_msg}")
        raise ValueError(error_msg)

    # Resolve working directory: default to $HOME (not CLI process CWD)
    if not cwd or cwd == ".":
        cwd = os.path.expanduser("~")

    logger.info(f"Executing command: {command} (cwd={cwd}, timeout={timeout}s)")

    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        # Combine stdout and stderr
        output = result.stdout
        if result.stderr:
            output += f"\n[STDERR]\n{result.stderr}"

        # Add exit code if non-zero
        if result.returncode != 0:
            output += f"\n[EXIT CODE: {result.returncode}]"

        logger.info(f"Command completed with exit code {result.returncode}")
        return output

    except subprocess.TimeoutExpired:
        error_msg = f"Command timed out after {timeout}s"
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except Exception as e:
        error_msg = f"Error executing command: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


# Tool metadata for MCP
TOOL_NAME = "execute_command"
TOOL_DESCRIPTION = "Execute a shell command on the local machine"
TOOL_INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "command": {
            "type": "string",
            "description": "Shell command to execute (e.g., 'ls -la', 'git status')",
        },
        "cwd": {
            "type": "string",
            "description": "Working directory path. Defaults to user's home directory. Use absolute paths like /Users/alexk/project.",
        },
        "timeout": {
            "type": "integer",
            "description": "Command timeout in seconds (default: 30)",
            "default": 30,
            "minimum": 1,
            "maximum": 600,
        },
    },
    "required": ["command"],
}
