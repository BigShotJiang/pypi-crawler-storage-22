"""List directory tool for local terminal."""

import logging
import os
from pathlib import Path
from typing import Dict, Any

from ..security import SecurityValidator

logger = logging.getLogger(__name__)


async def list_directory(
    path: str,
    include_hidden: bool = False,
    security_config: Dict[str, Any] | None = None,
) -> str:
    """
    List contents of a directory on local machine.

    Args:
        path: Path to directory
        include_hidden: Include hidden files (starting with .)
        security_config: Security configuration for validator

    Returns:
        Directory listing or error message

    Raises:
        ValueError: If path is not allowed by security validator
    """
    # Security validation
    validator = SecurityValidator(config=security_config)
    is_valid, error_msg = validator.validate_path(path)

    if not is_valid:
        logger.warning(f"Blocked path access: {path} - {error_msg}")
        raise ValueError(error_msg)

    # Resolve path: default to $HOME (not CLI process CWD)
    if path == ".":
        path = os.path.expanduser("~")

    logger.info(f"Listing directory: {path} (include_hidden={include_hidden})")

    try:
        dir_path = Path(path)

        if not dir_path.exists():
            error_msg = f"Directory not found: {path}"
            logger.error(error_msg)
            return f"❌ {error_msg}"

        if not dir_path.is_dir():
            error_msg = f"Not a directory: {path}"
            logger.error(error_msg)
            return f"❌ {error_msg}"

        # Collect items
        items = []
        for item in sorted(dir_path.iterdir(), key=lambda x: (not x.is_dir(), x.name)):
            # Skip hidden files if not requested
            if not include_hidden and item.name.startswith("."):
                continue

            # Determine item type
            if item.is_dir():
                item_type = "DIR "
            elif item.is_symlink():
                item_type = "LINK"
            else:
                item_type = "FILE"

            # Format: TYPE  NAME
            items.append(f"{item_type}\t{item.name}")

        if not items:
            return "Empty directory" if not include_hidden else "Empty directory (including hidden files)"

        result = "\n".join(items)
        logger.info(f"Listed {len(items)} items from: {path}")
        return result

    except PermissionError:
        error_msg = f"Permission denied: {path}"
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except Exception as e:
        error_msg = f"Error listing directory: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


# Tool metadata for MCP
TOOL_NAME = "list_directory"
TOOL_DESCRIPTION = "List contents of a directory on the local machine"
TOOL_INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "Path to the directory to list. Use '.' for user's home directory, or absolute paths like /Users/alexk/project.",
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden files (starting with .)",
            "default": False,
        },
    },
    "required": ["path"],
}
