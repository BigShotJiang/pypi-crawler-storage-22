"""Read file tool for local terminal."""

import logging
from pathlib import Path
from typing import Dict, Any

from ..security import SecurityValidator

logger = logging.getLogger(__name__)


async def read_file(
    path: str,
    encoding: str = "utf-8",
    security_config: Dict[str, Any] | None = None,
) -> str:
    """
    Read contents of a file on local machine.

    Args:
        path: Absolute or relative path to file
        encoding: File encoding (default: utf-8)
        security_config: Security configuration for validator

    Returns:
        File contents as string

    Raises:
        ValueError: If path is not allowed by security validator
    """
    # Security validation
    validator = SecurityValidator(config=security_config)
    is_valid, error_msg = validator.validate_path(path)

    if not is_valid:
        logger.warning(f"Blocked path access: {path} - {error_msg}")
        raise ValueError(error_msg)

    # Read file
    logger.info(f"Reading file: {path} (encoding={encoding})")

    try:
        file_path = Path(path)

        if not file_path.exists():
            error_msg = f"File not found: {path}"
            logger.error(error_msg)
            return f"❌ {error_msg}"

        if not file_path.is_file():
            error_msg = f"Not a file: {path}"
            logger.error(error_msg)
            return f"❌ {error_msg}"

        content = file_path.read_text(encoding=encoding)
        logger.info(f"Successfully read file: {path} ({len(content)} characters)")
        return content

    except UnicodeDecodeError as e:
        error_msg = f"Unicode decode error (try different encoding): {str(e)}"
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except PermissionError:
        error_msg = f"Permission denied: {path}"
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except Exception as e:
        error_msg = f"Error reading file: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


# Tool metadata for MCP
TOOL_NAME = "read_file"
TOOL_DESCRIPTION = "Read contents of a file on the local machine"
TOOL_INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "Path to the file to read",
        },
        "encoding": {
            "type": "string",
            "description": "File encoding (default: utf-8)",
            "default": "utf-8",
        },
    },
    "required": ["path"],
}
