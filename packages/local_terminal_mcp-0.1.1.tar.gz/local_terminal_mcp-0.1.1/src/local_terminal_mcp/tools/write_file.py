"""Write file tool for local terminal."""

import logging
from pathlib import Path
from typing import Dict, Any

from ..security import SecurityValidator

logger = logging.getLogger(__name__)


async def write_file(
    path: str,
    content: str,
    encoding: str = "utf-8",
    create_dirs: bool = False,
    security_config: Dict[str, Any] | None = None,
) -> str:
    """
    Write content to a file on local machine.

    Args:
        path: Path to the file to write
        content: Content to write
        encoding: File encoding (default: utf-8)
        create_dirs: Create parent directories if they don't exist
        security_config: Security configuration for validator

    Returns:
        Success message or error

    Raises:
        ValueError: If path is not allowed by security validator
    """
    # Security validation
    validator = SecurityValidator(config=security_config)
    is_valid, error_msg = validator.validate_path(path)

    if not is_valid:
        logger.warning(f"Blocked path access: {path} - {error_msg}")
        raise ValueError(error_msg)

    # Write file
    logger.info(f"Writing file: {path} (encoding={encoding}, create_dirs={create_dirs})")

    try:
        file_path = Path(path)

        # Create parent directories if requested
        if create_dirs and not file_path.parent.exists():
            file_path.parent.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created parent directories for: {path}")

        # Write content
        file_path.write_text(content, encoding=encoding)

        success_msg = f"✅ File written successfully: {path} ({len(content)} characters)"
        logger.info(success_msg)
        return success_msg

    except FileNotFoundError:
        error_msg = f"Parent directory does not exist: {file_path.parent}. Use create_dirs=true to create it."
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except PermissionError:
        error_msg = f"Permission denied: {path}"
        logger.error(error_msg)
        return f"❌ {error_msg}"

    except Exception as e:
        error_msg = f"Error writing file: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"❌ {error_msg}"


# Tool metadata for MCP
TOOL_NAME = "write_file"
TOOL_DESCRIPTION = "Write content to a file on the local machine"
TOOL_INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "description": "Path to the file to write",
        },
        "content": {
            "type": "string",
            "description": "Content to write to the file",
        },
        "encoding": {
            "type": "string",
            "description": "File encoding (default: utf-8)",
            "default": "utf-8",
        },
        "create_dirs": {
            "type": "boolean",
            "description": "Create parent directories if they don't exist",
            "default": False,
        },
    },
    "required": ["path", "content"],
}
