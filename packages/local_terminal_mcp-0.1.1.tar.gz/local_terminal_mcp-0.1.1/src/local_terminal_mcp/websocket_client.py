"""WebSocket client for connecting to Agent Builder."""

import asyncio
import json
import logging
from typing import Callable, Optional

import websockets
from websockets.client import WebSocketClientProtocol

from .config import Config
from .server import LocalTerminalMCPServer

logger = logging.getLogger(__name__)

# Reconnect constants
RECONNECT_BASE_DELAY = 2.0
RECONNECT_MAX_DELAY = 30.0
RECONNECT_MAX_EXPONENT = 4  # 2^4 = 16s, capped at 30s


class MCPWebSocketClient:
    """
    WebSocket client for Local Terminal MCP Server.

    Connects to Agent Builder backend and handles bidirectional MCP protocol.
    Supports auto-reconnect with exponential backoff when connection drops.
    """

    def __init__(
        self,
        config: Config,
        token_refresher: Optional[Callable[[], str]] = None,
    ):
        """
        Initialize WebSocket client.

        Args:
            config: Configuration instance
            token_refresher: Optional callback to refresh auth token before reconnect.
                             Should return a new JWT token string.
        """
        self.config = config
        self.server = LocalTerminalMCPServer(config)
        self.websocket: Optional[WebSocketClientProtocol] = None
        self.running = False
        self._token_refresher = token_refresher

    def _build_url(self) -> str:
        """Build WebSocket URL with token and team params."""
        url = self.config.agent_builder_url
        if not url.startswith("ws://") and not url.startswith("wss://"):
            url = f"wss://{url}"

        url = f"{url}/ws/v2/mcp/local?token={self.config.auth_token}"

        if self.config.team_id:
            url = f"{url}&team={self.config.team_id}"

        return url

    async def connect(self) -> None:
        """
        Connect to Agent Builder with auto-reconnect.

        On connection drop (pod restart, network issue), waits with
        exponential backoff and reconnects automatically.
        Auth errors (4001) are fatal and stop reconnection.
        Ctrl+C (KeyboardInterrupt) stops reconnection.
        """
        retry_count = 0

        while True:
            try:
                await self._connect_once()
                # Clean return = server closed connection, reconnect
                retry_count += 1
                delay = self._backoff_delay(retry_count)
                logger.info(f"🔄 Connection lost. Reconnecting in {delay:.0f}s... (attempt {retry_count})")
                self._refresh_token_if_needed()
                await asyncio.sleep(delay)

            except websockets.exceptions.InvalidStatusCode as e:
                # Backend returns HTTP 403 for expired/invalid JWT
                # (WebSocket close code 4001 is never seen — rejected at HTTP level)
                retry_count += 1
                if e.status_code in (401, 403, 4001):
                    logger.warning(f"🔑 Auth failed (HTTP {e.status_code}). Refreshing token...")
                    self._refresh_token_if_needed()
                    delay = self._backoff_delay(retry_count)
                    logger.info(f"🔄 Retrying with refreshed token in {delay:.0f}s...")
                    await asyncio.sleep(delay)
                else:
                    delay = self._backoff_delay(retry_count)
                    logger.info(f"🔄 Connection error (status {e.status_code}). Reconnecting in {delay:.0f}s...")
                    await asyncio.sleep(delay)

            except (
                ConnectionRefusedError,
                ConnectionResetError,
                OSError,
                websockets.exceptions.WebSocketException,
            ):
                retry_count += 1
                delay = self._backoff_delay(retry_count)
                logger.info(f"🔄 Connection failed. Reconnecting in {delay:.0f}s... (attempt {retry_count})")
                self._refresh_token_if_needed()
                await asyncio.sleep(delay)

            except KeyboardInterrupt:
                raise

            except Exception as e:
                retry_count += 1
                delay = self._backoff_delay(retry_count)
                logger.warning(f"🔄 Unexpected error: {e}. Reconnecting in {delay:.0f}s...")
                await asyncio.sleep(delay)

    async def _connect_once(self) -> None:
        """
        Single connection attempt. Returns on clean disconnect, raises on error.
        """
        url = self._build_url()
        logger.info(f"🔌 Connecting to {url.split('?')[0]}...")

        try:
            async with websockets.connect(url) as websocket:
                self.websocket = websocket
                self.running = True

                logger.info("✅ Connected to Agent Builder")
                logger.info(f"📡 Server info: {self.server.server_info['name']} v{self.server.server_info['version']}")
                logger.info(f"🔧 Tools available: {len(self.server.tools)}")
                logger.info("")
                logger.info("Listening for MCP protocol messages...")
                logger.info("Press Ctrl+C to disconnect")
                logger.info("")

                try:
                    async for message in websocket:
                        await self._handle_message(message)
                except websockets.exceptions.ConnectionClosed as e:
                    if e.code == 4003:
                        # Team not found — fatal, don't reconnect
                        logger.error(f"❌ {e.reason or 'Team not found'}")
                        raise SystemExit(1)
                    logger.info("👋 Connection closed by server")

        finally:
            self.running = False
            self.websocket = None

    def _refresh_token_if_needed(self) -> None:
        """Refresh auth token via callback if available."""
        if self._token_refresher:
            try:
                new_token = self._token_refresher()
                if new_token:
                    self.config.auth_token = new_token
                    logger.info("🔑 Token refreshed for reconnect")
            except Exception as e:
                logger.warning(f"⚠️ Token refresh failed: {e}")

    @staticmethod
    def _backoff_delay(retry_count: int) -> float:
        """Exponential backoff: 2s, 4s, 8s, 16s, 30s, 30s, ..."""
        exp = min(retry_count - 1, RECONNECT_MAX_EXPONENT)
        return min(RECONNECT_BASE_DELAY * (2 ** exp), RECONNECT_MAX_DELAY)

    async def _handle_message(self, message: str) -> None:
        """
        Handle incoming MCP protocol message from backend.

        Args:
            message: JSON-RPC 2.0 message
        """
        try:
            logger.debug(f"📨 Received: {message[:100]}...")

            # Process message through MCP server
            response = await self.server.handle_message(message)

            # Send response back
            if self.websocket:
                await self.websocket.send(response)
                logger.debug(f"📤 Sent: {response[:100]}...")

                # Log tool calls for visibility
                try:
                    request = json.loads(message)
                    if request.get("method") == "tools/call":
                        tool_name = request.get("params", {}).get("name")
                        logger.info(f"🔧 Executed tool: {tool_name}")
                except:
                    pass

        except Exception as e:
            logger.error(f"❌ Error handling message: {e}", exc_info=True)

            # Send error response
            try:
                request = json.loads(message)
                error_response = {
                    "jsonrpc": "2.0",
                    "id": request.get("id"),
                    "error": {
                        "code": -32603,
                        "message": str(e),
                    },
                }
                if self.websocket:
                    await self.websocket.send(json.dumps(error_response))
            except:
                pass

    async def disconnect(self) -> None:
        """Disconnect from Agent Builder."""
        if self.websocket:
            await self.websocket.close()
            self.websocket = None
        self.running = False
