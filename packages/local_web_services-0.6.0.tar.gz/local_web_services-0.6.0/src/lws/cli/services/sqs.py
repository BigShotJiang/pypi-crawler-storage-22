"""``lws sqs`` sub-commands."""

from __future__ import annotations

import asyncio

import typer

from lws.cli.services.client import LwsClient, exit_with_error, output_json, xml_to_dict

app = typer.Typer(help="SQS commands")

_SERVICE = "sqs"


def _client(port: int) -> LwsClient:
    return LwsClient(port=port)


@app.command("send-message")
def send_message(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    message_body: str = typer.Option(..., "--message-body", help="Message body"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Send a message to a queue."""
    asyncio.run(_send_message(queue_name, message_body, port))


async def _send_message(queue_name: str, message_body: str, port: int) -> None:
    client = _client(port)
    try:
        resource = await client.resolve_resource(_SERVICE, queue_name)
        queue_url = resource.get("queue_url", "")
    except Exception:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
    xml = await client.form_request(
        _SERVICE,
        {"Action": "SendMessage", "QueueUrl": queue_url, "MessageBody": message_body},
    )
    output_json(xml_to_dict(xml))


@app.command("receive-message")
def receive_message(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    max_messages: int = typer.Option(1, "--max-number-of-messages", help="Max messages"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Receive messages from a queue."""
    asyncio.run(_receive_message(queue_name, max_messages, port))


async def _receive_message(queue_name: str, max_messages: int, port: int) -> None:
    client = _client(port)
    try:
        resource = await client.resolve_resource(_SERVICE, queue_name)
        queue_url = resource.get("queue_url", "")
    except Exception:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
    xml = await client.form_request(
        _SERVICE,
        {
            "Action": "ReceiveMessage",
            "QueueUrl": queue_url,
            "MaxNumberOfMessages": str(max_messages),
        },
    )
    output_json(xml_to_dict(xml))


@app.command("delete-message")
def delete_message(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    receipt_handle: str = typer.Option(..., "--receipt-handle", help="Receipt handle"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Delete a message from a queue."""
    asyncio.run(_delete_message(queue_name, receipt_handle, port))


async def _delete_message(queue_name: str, receipt_handle: str, port: int) -> None:
    client = _client(port)
    try:
        resource = await client.resolve_resource(_SERVICE, queue_name)
        queue_url = resource.get("queue_url", "")
    except Exception:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
    xml = await client.form_request(
        _SERVICE,
        {
            "Action": "DeleteMessage",
            "QueueUrl": queue_url,
            "ReceiptHandle": receipt_handle,
        },
    )
    output_json(xml_to_dict(xml))


@app.command("get-queue-attributes")
def get_queue_attributes(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Get queue attributes."""
    asyncio.run(_get_queue_attributes(queue_name, port))


async def _get_queue_attributes(queue_name: str, port: int) -> None:
    client = _client(port)
    try:
        resource = await client.resolve_resource(_SERVICE, queue_name)
        queue_url = resource.get("queue_url", "")
    except Exception:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
    xml = await client.form_request(
        _SERVICE,
        {"Action": "GetQueueAttributes", "QueueUrl": queue_url},
    )
    output_json(xml_to_dict(xml))


@app.command("create-queue")
def create_queue(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Create a queue."""
    asyncio.run(_create_queue(queue_name, port))


async def _create_queue(queue_name: str, port: int) -> None:
    client = _client(port)
    try:
        xml = await client.form_request(
            _SERVICE,
            {"Action": "CreateQueue", "QueueName": queue_name},
        )
    except Exception as exc:
        exit_with_error(str(exc))
    output_json(xml_to_dict(xml))


@app.command("delete-queue")
def delete_queue(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Delete a queue."""
    asyncio.run(_delete_queue(queue_name, port))


async def _delete_queue(queue_name: str, port: int) -> None:
    client = _client(port)
    try:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
        xml = await client.form_request(
            _SERVICE,
            {"Action": "DeleteQueue", "QueueUrl": queue_url},
        )
    except Exception as exc:
        exit_with_error(str(exc))
    output_json(xml_to_dict(xml))


@app.command("list-queues")
def list_queues(
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """List all queues."""
    asyncio.run(_list_queues(port))


async def _list_queues(port: int) -> None:
    client = _client(port)
    try:
        xml = await client.form_request(
            _SERVICE,
            {"Action": "ListQueues"},
        )
    except Exception as exc:
        exit_with_error(str(exc))
    output_json(xml_to_dict(xml))


@app.command("purge-queue")
def purge_queue(
    queue_name: str = typer.Option(..., "--queue-name", help="Queue name"),
    port: int = typer.Option(3000, "--port", "-p", help="LDK port"),
) -> None:
    """Purge all messages from a queue."""
    asyncio.run(_purge_queue(queue_name, port))


async def _purge_queue(queue_name: str, port: int) -> None:
    client = _client(port)
    try:
        svc_port = await client.service_port(_SERVICE)
        queue_url = f"http://localhost:{svc_port}/000000000000/{queue_name}"
        xml = await client.form_request(
            _SERVICE,
            {"Action": "PurgeQueue", "QueueUrl": queue_url},
        )
    except Exception as exc:
        exit_with_error(str(exc))
    output_json(xml_to_dict(xml))
