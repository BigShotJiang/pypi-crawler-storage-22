"""Secrets Manager provider package."""
