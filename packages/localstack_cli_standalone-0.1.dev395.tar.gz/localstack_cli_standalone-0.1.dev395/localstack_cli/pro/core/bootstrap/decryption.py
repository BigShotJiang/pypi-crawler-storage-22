import inspect
import os.path
import sys
import tempfile
import tokenize
import traceback
from importlib.abc import MetaPathFinder, SourceLoader
from importlib.util import spec_from_file_location

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from localstack_cli.utils.files import load_file
from localstack_cli.utils.patch import patch
from localstack_cli.utils.strings import to_str


class DecryptionHandler:
    decryption_key: bytes

    def __init__(self, decryption_key: bytes):
        self.decryption_key = decryption_key

    def decrypt(self, content) -> bytes:
        iv = b"\0" * 16
        cipher = Cipher(algorithms.AES(self.decryption_key), modes.CBC(iv))
        decryptor = cipher.decryptor()

        decrypted = decryptor.update(content) + decryptor.finalize()
        # Remove padding bytes
        decrypted = decrypted.partition(b"\0")[0]
        return decrypted


class EncryptedFileFinder(MetaPathFinder):
    decryption_handler: DecryptionHandler

    def __init__(self, decryption_handler: DecryptionHandler):
        self.decryption_handler = decryption_handler

    def find_spec(self, fullname, path, target=None):
        # convert to list - "path" may be an instance of _NamespacePath (which doesn't support indexing)
        if path and not isinstance(path, list):
            path = list(getattr(path, "_path", []))

        if not path:
            return None

        name = fullname.split(".")[-1]

        file_path = os.path.join(path[0], name + ".py")
        enc = file_path + ".enc"

        if not os.path.isfile(enc):
            return None

        if os.path.isfile(file_path):
            # file already exists in decrypted state, let next import handler handle it
            return None

        return spec_from_file_location(
            fullname, enc, loader=DecryptingLoader(enc, self.decryption_handler)
        )


class DecryptingLoader(SourceLoader):
    decryption_handler: DecryptionHandler

    def __init__(self, encrypted_file, decryption_handler: DecryptionHandler):
        self.encrypted_file = encrypted_file
        self.decryption_handler = decryption_handler

    def get_filename(self, fullname):
        return self.encrypted_file

    def get_data(self, filename):
        with open(filename, "rb") as f:
            data = f.read()
        data = self.decryption_handler.decrypt(data)
        return data


def init_source_decryption(decryption_handler: DecryptionHandler):
    # insert custom file loader into meta_path
    sys.meta_path.insert(0, EncryptedFileFinder(decryption_handler))
    # patch traceback/inspect to gracefully handle encrypted source files
    patch_traceback_lines()
    patch_inspect_findsource()
    patch_tokenize_open(decryption_handler)


def patch_traceback_lines():
    """Patch traceback to gracefully handle encrypted source files. This is required to avoid
    UnicodeDecodeError errors when traceback attempts to access the binary file content."""

    # make sure we apply the patch only once
    if getattr(traceback.FrameSummary, "_ls_patch_applied", None):
        return

    @property
    def line(self):
        try:
            return line_orig.fget(self)
        except Exception:
            self._line = ""
            return self._line

    line_orig = traceback.FrameSummary.line
    traceback.FrameSummary.line = line
    traceback.FrameSummary._ls_patch_applied = True


def patch_inspect_findsource():
    """Patch inspect to gracefully handle encrypted source files. This is required to avoid
    "SyntaxError: invalid or missing encoding declaration" when attempting to access the binary file content.
    """

    # TODO: this patch is likely no longer required, should be handled by patch_tokenize_open(..) below

    # make sure we apply the patch only once
    if getattr(inspect, "_ls_patch_applied", None):
        return

    def findsource(*args, **kwargs):
        try:
            return findsource_orig(*args, **kwargs)
        except Exception:
            return [], 0

    findsource_orig = inspect.findsource
    inspect.findsource = findsource
    inspect._ls_patch_applied = True


def patch_tokenize_open(decryption_handler: DecryptionHandler):
    """
    Patch to gracefully handle encrypted source files. This is required to properly retrieve the source
    code of encrypted Python files when requested. In particular, it enables the use of code inspection utilities
    in the `inspect` module, for example inspect.getsource(..) which returns the source code of a given module.

    Note: this patch still leaves the in-memory file decryption of the `DecryptingLoader(..)` above intact,
    and hence has no negative impact on the runtime performance of decrypting the source files on startup.
    """

    @patch(tokenize.open)
    def tokenize_open(fn, filename, *args, **kwargs):
        try:
            return fn(filename, *args, **kwargs)
        except Exception as e:
            # Special handling for loading encrypted python files. In case we run inspect.getsource(..) on
            # an encrypted module, we'd receive the following error message:
            #  SyntaxError: invalid or missing encoding declaration for '/.../my_module.py.enc'
            if "missing encoding declaration" in str(e) and filename.endswith(".py.enc"):
                # below we load the content of the encrypted file, decrypt it via `decryption_handler`,
                # then store it to a temporary file, and call tokenize.open(..) on the now plaintext file
                content = load_file(filename, mode="rb")
                content_decrypted = to_str(decryption_handler.decrypt(content))
                with tempfile.NamedTemporaryFile("w+t") as fp:
                    fp.write(content_decrypted)
                    fp.seek(0)
                    return fn(fp.name, *args, **kwargs)
            raise
