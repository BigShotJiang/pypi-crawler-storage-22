from datetime import datetime

from localstack_cli import config

try:
    from localstack_cli.runtime import hooks
except ImportError:
    hooks = None

from localstack_cli.utils.analytics import get_session_id
from localstack_cli.utils.analytics.events import Event, EventMetadata
from localstack_cli.utils.analytics.publisher import AnalyticsClientPublisher

from .registry import MetricRegistry


def publish_metrics() -> None:
    """
    Collects all the registered metrics and immediately sends them to the analytics service.
    Skips execution if event tracking is disabled (`config.DISABLE_EVENTS`).

    This function is automatically triggered on infrastructure shutdown.
    """
    if config.DISABLE_EVENTS:
        return

    collected_metrics = MetricRegistry().collect()
    if not collected_metrics.payload:  # Skip publishing if no metrics remain after filtering
        return

    metadata = EventMetadata(
        session_id=get_session_id(),
        client_time=str(datetime.now()),
    )

    if collected_metrics:
        publisher = AnalyticsClientPublisher()
        publisher.publish(
            [Event(name="ls_metrics", metadata=metadata, payload=collected_metrics.as_dict())]
        )


# Register the hook if runtime is available
if hooks is not None:
    publish_metrics = hooks.on_infra_shutdown()(publish_metrics)
