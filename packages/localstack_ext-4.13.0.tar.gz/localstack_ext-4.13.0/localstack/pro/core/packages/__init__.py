from .core import OSPackageInstaller

__all__ = [
    "OSPackageInstaller",
]
