__all__=['__version__','__version_tuple__','version','version_tuple','__commit_id__','commit_id']
TYPE_CHECKING=False
if TYPE_CHECKING:from typing import Tuple,Union;VERSION_TUPLE=Tuple[Union[int,str],...];COMMIT_ID=Union[str,None]
else:VERSION_TUPLE=object;COMMIT_ID=object
version:str
__version__:str
__version_tuple__:VERSION_TUPLE
version_tuple:VERSION_TUPLE
commit_id:COMMIT_ID
__commit_id__:COMMIT_ID
__version__=version='4.13.0'
__version_tuple__=version_tuple=4,13,0
__commit_id__=commit_id='g0d5749a35'