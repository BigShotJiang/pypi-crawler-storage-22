# Location Main Local Python Package

## TODOs

TODO location can include multiple polygons

## General

To run the tests in full, please access the OpenCage API:

1. Visit the following website: https://opencagedata.com/
2. Sign up for the service.
3. You can retrieve the access token OPENCAGE_KEY in quick_start

Package Description: insert to get_country_name function,n city name, state id, or country code, and it will return you the
country name

TODO: We should ensure we have an inheritance of geocoding (Google Maps, HERE Technologies, OpenCage Geocoding ...)<be>

TODO Geo Class (city_id, multiple cities, city-group, or geo-region) in location-local repo. Both in Python and TypeScript.<br>

https://sourceforge.net/software/compare/Google-Maps-vs-HERE-Technologies-vs-OpenCage-Geocoding-API/<br>

We should allow multiple location_ids in the same coordinates, i.e, different floors
 
