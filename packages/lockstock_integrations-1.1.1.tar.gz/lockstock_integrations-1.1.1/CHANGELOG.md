# Changelog

All notable changes to lockstock-integrations will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.1] - 2026-02-05

### Fixed
- **CRITICAL**: Added missing `lockstock_core` package to wheel build
  - v1.1.0 was published WITHOUT `lockstock_core` module due to missing entry in pyproject.toml
  - All framework imports failed with `ModuleNotFoundError: No module named 'lockstock_core'`
  - Added `lockstock_core` to `[tool.hatch.build.targets.wheel] packages` list
  - All imports now work correctly: `from lockstock_openai import LockStockGuardrail` ✓

### Note
v1.1.0 should have been yanked immediately but was functionally broken on install.
Use v1.1.1 instead.

## [1.1.0] - 2026-02-05 [BROKEN - Use v1.1.1]

**DO NOT USE**: This version is missing `lockstock_core` and cannot import.

### Changed
- **BREAKING**: Converted to chain-based authentication (NO SECRETS)
  - `LockStockGuardrail.from_liberty()` now uses Chain Authority Mode
  - Guard daemon tracks chain state (hash, matrix, sequence), not secrets
  - Guard uses `current_hash` as HMAC key for signing
  - Genesis token is BURNED to create initial chain state
  - NO persistent secrets exist after genesis
- Removed secret retrieval from `from_liberty()` method
- Added chain state tracking (`current_hash`, `current_sequence`, `current_matrix`)
- Added `_ensure_chain_initialized()` method to sync chain state from Guard
- Added `_verify_with_server()` method for server communication
- Updated `validate()` to use Guard's `sign_and_advance()` instead of legacy `verify()`

### Security
- Implements correct security model: secrets NEVER leave Guard daemon
- Guard performs all HMAC signing internally using chain state
- Application only receives signatures, never secrets
- Aligns with TECHNICAL_SPECIFICATION.md line 1: "YOU DO NOT NEED AGENT SECRETS FOR ANYTHING"

### Migration Guide
If upgrading from v1.0.1:
1. No code changes required - `from_liberty()` API is unchanged
2. Ensure Guard daemon supports `sign_and_advance()` method
3. Ensure Guard daemon has chain state synced from server

## [1.0.1] - 2026-02-05 [YANKED]

**YANKED**: This version implements WRONG security model (secret-based instead of chain-based)

### Why Yanked
- Uses legacy `guard.get(agent_id)` to retrieve secrets
- Violates "secrets NEVER leave daemon" security model
- Genesis token should be BURNED, not converted to persistent secret
- Chain state (hash) should be HMAC key, not a separate secret

### What Was Added (WRONG)
- Implemented `LockStockGuardrail.from_liberty()` using secret retrieval (INCORRECT)
- Retrieved hardware-bound secrets from Guard daemon (WRONG APPROACH)

### Fix
Upgrade to v1.1.0 which implements correct chain-based authentication

## [1.0.0] - 2026-02-05

### Fixed
- **CRITICAL**: Fixed SHELL generator mismatch with server (was Matrix(1,1,0,1), now Matrix(1,4,0,1))
  - This resolves "Topology violation: matrix multiplication check failed" errors when using Shell capability
  - Server was updated to v1.0.8+ with distinct SHELL generator but Python SDK was not synchronized
  - Discovered during production verification testing on RunPod before PyPI publish
  - All 7/7 production tests now pass including Shell capability

### Breaking Changes
- SHELL generator matrix changed from Matrix(1, 1, 0, 1) to Matrix(1, 4, 0, 1) to match server v1.0.8+
- Agents using SDK versions prior to 1.0.0 will fail Shell capability verification with topology violations
- Upgrade required for all deployed agents using Shell capability

## [0.1.0] - 2026-01-XX

### Added
- Initial release
- Core LockStockClient with matrix state management
- Integration modules for OpenAI, LangGraph, and Claude
- Support for all capability types: Deploy, Restart, Backup, Rollback, Heartbeat, Checkpoint, Teleport, FileRead, FileWrite, Network, Shell, Database, Handoff, Delegate
- GL(2, F_65537) matrix group for topological state transitions
- HMAC-SHA256 signature generation
- Audit trail support
