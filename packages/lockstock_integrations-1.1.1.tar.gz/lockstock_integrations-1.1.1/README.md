# LockStock Integrations

Universal compliance runtime for AI Agent SDKs. LockStock provides cryptographic identity, capability authorization, and audit trails for agents running on any framework.

## Supported Frameworks

| Integration | Framework | Status |
|-------------|-----------|--------|
| `lockstock_claude` | Claude Agent SDK | Alpha |
| `lockstock_openai` | OpenAI Agents SDK | Alpha |
| `lockstock_langgraph` | LangGraph | Alpha |
| `lockstock_a2a` | A2A Protocol | Alpha |
| `lockstock_adk` | Google ADK | Planned |
| `lockstock_crewai` | CrewAI | Planned |

## Installation

```bash
# Install with specific framework support
pip install lockstock-integrations[claude]
pip install lockstock-integrations[openai]
pip install lockstock-integrations[langgraph]

# Install with all frameworks
pip install lockstock-integrations[all]
```

## Quick Start

### Claude Agent SDK

```python
from lockstock_claude import LockStockHook

# Create hook with your agent credentials
hook = LockStockHook(
    agent_id="agent_abc123",
    api_key="lsk_admin_...",
    endpoint="https://lockstock-api-i9kp.onrender.com"
)

# Use as pre-tool-execution hook
# The hook will verify capabilities before each tool call
```

### OpenAI Agents SDK

```python
from lockstock_openai import LockStockGuardrail

guardrail = LockStockGuardrail(agent_id="agent_abc123")

# Add to your agent's guardrails
agent = Agent(
    name="my-agent",
    guardrails=[guardrail]
)
```

### LangGraph

```python
from lockstock_langgraph import lockstock_middleware

# Wrap your graph with LockStock middleware
app = lockstock_middleware(
    graph=your_graph,
    agent_id="agent_abc123"
)
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     YOUR AGENT RUNTIME                          │
│  (Claude Agent SDK / OpenAI / LangGraph / CrewAI / ADK)        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   LOCKSTOCK INTEGRATION                         │
│                                                                  │
│  • Pre-tool-execution hooks                                     │
│  • Capability verification                                       │
│  • Audit trail logging                                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     LOCKSTOCK CORE API                          │
│                                                                  │
│  • /verify - Capability authorization                           │
│  • /bootstrap - Agent identity initialization                   │
│  • Hash chain - Cryptographic audit trail                       │
└─────────────────────────────────────────────────────────────────┘
```

## License

MIT License - See LICENSE file for details.
