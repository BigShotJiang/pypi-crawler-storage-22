"""
LockStock Claude Agent SDK Skills
----------------------------------
Custom skills for Claude Agent SDK that expose LockStock functionality.

These skills can be placed in .claude/skills/ to make LockStock
capabilities available to Claude Code.
"""

from typing import Dict, Any, Optional
from lockstock_core import LockStockClient


class LockStockSkill:
    """
    LockStock skill for Claude Agent SDK.

    Provides identity management, verification, and audit capabilities
    as Claude Code skills.
    """

    def __init__(
        self,
        agent_id: str,
        secret: Optional[str] = None,
        api_key: Optional[str] = None,
        endpoint: str = "https://lockstock-api-i9kp.onrender.com"
    ):
        self.client = LockStockClient(
            agent_id=agent_id,
            secret=secret,
            api_key=api_key,
            endpoint=endpoint
        )
        self.agent_id = agent_id

    async def get_identity(self) -> Dict[str, Any]:
        """
        Get the current agent's identity information.

        Returns:
            Dictionary with agent identity details
        """
        card = await self.client.get_agent_card()

        if card:
            return {
                "agent_id": card.agent_id,
                "display_name": card.display_name,
                "capabilities": card.capabilities,
                "status": card.status,
                "fingerprint": card.fingerprint
            }

        return {
            "agent_id": self.agent_id,
            "error": "Agent card not found"
        }

    async def verify_capability(self, capability: str) -> Dict[str, Any]:
        """
        Check if the agent has a specific capability.

        Args:
            capability: The capability to check (e.g., "DEPLOY", "RESTART")

        Returns:
            Dictionary with verification result
        """
        result = await self.client.verify(task=capability)

        return {
            "capability": capability,
            "authorized": result.authorized,
            "status": result.status.value,
            "reason": result.reason,
            "state_hash": result.state_hash
        }

    async def export_passport(self) -> Dict[str, Any]:
        """
        Export the agent's portable passport for teleportation.

        Returns:
            Dictionary with passport data
        """
        # This would call the export endpoint
        return {
            "agent_id": self.agent_id,
            "message": "Use lockstock-guard export command for full passport export"
        }

    async def get_audit_trail(self, limit: int = 10) -> Dict[str, Any]:
        """
        Get recent entries from the agent's audit trail.

        Args:
            limit: Maximum number of entries to return

        Returns:
            Dictionary with audit entries
        """
        # This would call an audit endpoint
        return {
            "agent_id": self.agent_id,
            "message": "Audit trail retrieval not yet implemented"
        }

    def generate_skill_file(self) -> str:
        """
        Generate the SKILL.md content for this skill.

        Returns:
            Markdown content for .claude/skills/lockstock/SKILL.md
        """
        return f'''# LockStock Identity Skill

This skill provides LockStock identity and authorization capabilities.

## Agent Configuration

- **Agent ID**: {self.agent_id}
- **Endpoint**: {self.client.endpoint}

## Available Actions

### Get Identity
Retrieve your agent identity and capabilities.

### Verify Capability
Check if you're authorized for a specific action before attempting it.

### Export Passport
Export your identity for migration to another machine.

## Usage Notes

- Always verify capabilities before performing sensitive operations
- Your actions are logged to an immutable hash chain for audit
- Capabilities are enforced at the LockStock API level
'''

    async def close(self):
        """Close the underlying client."""
        await self.client.close()
