"""
LockStock Core Client
---------------------
HTTP client for LockStock API interactions.
"""

import hashlib
import hmac
import time
from typing import Optional, Dict, Any, List
import httpx

from .types import VerifyResult, VerifyStatus, AuditEntry, AgentCard, map_tool_to_capability, Matrix, get_generator, normalize_task_for_signature


class LockStockClient:
    """
    Client for interacting with the LockStock API.

    Provides capability verification, audit logging, and identity management.
    """

    DEFAULT_ENDPOINT = "https://lockstock-api-i9kp.onrender.com"

    def __init__(
        self,
        agent_id: str,
        secret: Optional[str] = None,
        api_key: Optional[str] = None,
        endpoint: str = DEFAULT_ENDPOINT,
        timeout: float = 30.0
    ):
        """
        Initialize LockStock client.

        Args:
            agent_id: The agent's unique identifier
            secret: The agent's HMAC secret (for signing requests)
            api_key: Admin API key (for provisioning/management)
            endpoint: LockStock API endpoint
            timeout: Request timeout in seconds
        """
        self.agent_id = agent_id
        self.secret = secret
        self.api_key = api_key
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout

        # State tracking
        self._current_hash = "0" * 64  # Genesis hash
        self._sequence = 0
        self._state_matrix = Matrix.identity()

        # HTTP client
        self._client = httpx.AsyncClient(timeout=timeout)

    async def verify(
        self,
        task: str,
        tool_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> VerifyResult:
        """
        Verify that the agent is authorized to perform a task.

        Args:
            task: The capability/task to verify (e.g., "DEPLOY", "RESTART")
            tool_name: Optional tool name (will be mapped to capability)
            metadata: Optional metadata to include in audit

        Returns:
            VerifyResult with authorization status
        """
        # Map tool name to capability if provided
        if tool_name and task == "UNKNOWN":
            task = map_tool_to_capability(tool_name)

        # Prepare request
        self._sequence += 1
        timestamp = int(time.time())

        # Apply generator matrix for this task (topological state transition)
        generator = get_generator(task)
        new_matrix = self._state_matrix.multiply(generator)

        # Create signature with the NEW matrix (uses timestamp, not sequence)
        signature = self._sign_request(task, self._current_hash, timestamp, new_matrix)

        payload = {
            "client_id": self.agent_id,
            "task": task.lower(),
            "parent_hash": self._current_hash,
            "state_matrix": new_matrix.to_dict(),
            "signature": signature,
            "timestamp": timestamp,
            "sequence": self._sequence
        }

        try:
            response = await self._client.post(
                f"{self.endpoint}/verify",
                json=payload,
                headers=self._headers()
            )

            data = response.json()

            status = VerifyStatus(data.get("status", "rejected"))

            if status == VerifyStatus.ACCEPTED:
                # Update state from server response
                self._current_hash = data.get("state_hash", self._current_hash)
                if "state_matrix" in data:
                    self._state_matrix = Matrix.from_dict(data["state_matrix"])

            return VerifyResult(
                status=status,
                reason=data.get("reason"),
                state_hash=data.get("state_hash"),
                server_timestamp=data.get("server_timestamp")
            )

        except httpx.HTTPError as e:
            return VerifyResult(
                status=VerifyStatus.REJECTED,
                reason=f"HTTP error: {str(e)}"
            )
        except Exception as e:
            return VerifyResult(
                status=VerifyStatus.REJECTED,
                reason=f"Client error: {str(e)}"
            )

    async def verify_tool(self, tool_name: str, tool_input: Optional[Dict] = None) -> VerifyResult:
        """
        Verify authorization for a specific tool call.

        Args:
            tool_name: Name of the tool being called
            tool_input: The tool's input parameters

        Returns:
            VerifyResult with authorization status
        """
        capability = map_tool_to_capability(tool_name)
        return await self.verify(task=capability, tool_name=tool_name)

    async def bootstrap(self) -> Dict[str, Any]:
        """
        Initialize the agent's identity with the server.

        Returns:
            Bootstrap response with root hash and matrix
        """
        try:
            response = await self._client.post(
                f"{self.endpoint}/bootstrap",
                json={"client_id": self.agent_id},
                headers=self._headers()
            )

            data = response.json()

            if "root_hash" in data:
                self._current_hash = data["root_hash"]
                if "root_matrix" in data:
                    self._state_matrix = Matrix.from_dict(data["root_matrix"])
                self._sequence = 0

            return data

        except Exception as e:
            return {"error": str(e)}

    async def get_agent_card(self) -> Optional[AgentCard]:
        """
        Retrieve the agent's card from the server.

        Returns:
            AgentCard if found, None otherwise
        """
        try:
            response = await self._client.get(
                f"{self.endpoint}/api/guard/agents/{self.agent_id}",
                headers=self._headers()
            )

            if response.status_code == 200:
                data = response.json()
                return AgentCard(
                    agent_id=data.get("agent_id", self.agent_id),
                    display_name=data.get("display_name", ""),
                    capabilities=data.get("capabilities", []),
                    status=data.get("status", "unknown"),
                    fingerprint=data.get("fingerprint"),
                    owner_id=data.get("owner_id"),
                    created_at=data.get("created_at")
                )
            return None

        except Exception:
            return None

    async def log_audit(
        self,
        action: str,
        status: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Log an action to the audit trail.

        Args:
            action: The action that was performed
            status: Status of the action (e.g., "APPROVED", "DENIED")
            metadata: Additional metadata to log

        Returns:
            True if logged successfully
        """
        # Audit is automatically logged via verify() calls
        # This method is for explicit logging of non-verified actions
        entry = AuditEntry(
            sequence=self._sequence,
            action=action,
            timestamp=int(time.time()),
            state_hash=self._current_hash,
            signature=self._sign_request(action, self._current_hash, self._sequence),
            metadata=metadata or {}
        )

        # In production, this would POST to an audit endpoint
        # For now, we just track locally
        return True

    def _sign_request(self, task: str, parent_hash: str, timestamp: int, matrix: Matrix = None) -> str:
        """Create HMAC signature for a request.

        The signature format matches the Rust server:
        {client_id}|{Task}|{parent_hash}|{a11},{a12},{a21},{a22}|{timestamp}

        IMPORTANT: The task name must match Rust's Debug format (e.g., "Heartbeat", "FileRead")
        because the server uses {:?} formatting for the Task enum in signature generation.
        """
        if not self.secret:
            return "unsigned"

        # Use provided matrix or current state
        m = matrix if matrix else self._state_matrix
        matrix_str = f"{m.a11},{m.a12},{m.a21},{m.a22}"

        # Normalize task to Rust Debug format (e.g., "HEARTBEAT" -> "Heartbeat")
        rust_task = normalize_task_for_signature(task)

        # Build message in server's expected format
        message = f"{self.agent_id}|{rust_task}|{parent_hash}|{matrix_str}|{timestamp}"

        signature = hmac.new(
            self.secret.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()

        return signature

    def _headers(self) -> Dict[str, str]:
        """Build request headers."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["x-admin-key"] = self.api_key
        return headers

    async def close(self):
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
