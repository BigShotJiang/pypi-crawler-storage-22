# FastAPI Middleware Performance Fix - Implementation Analysis

**Date:** 2026-02-08
**Issue:** Server sync inside chain lock creates throughput bottleneck
**Question:** Can we apply the daemon's background sync pattern to the middleware?
**Answer:** ✅ YES - Implementation is straightforward

---

## The Problem (Current State)

### Current Implementation:
```python
async with _chain_lock:  # Lock acquired
    # Get chain state from daemon
    chain_state = await self._get_chain_state(...)

    # Sign and advance locally
    sign_result = await self._sign_and_advance(...)

    # Sync to server (INSIDE LOCK) ❌
    if self.server_sync:
        verify_result = await self._verify_with_server(...)
# Lock released here
```

### Performance Issue:
- **Render cold start**: 30 second HTTP response time
- **Lock hold time**: 30 seconds per request during cold start
- **Impact**: All concurrent requests queue behind the cold start
- **Throughput**: Serialized (one request at a time during sync)

### Example Scenario:
```
Request 1: Acquires lock → signs (fast) → server sync (30s cold start) → releases lock
Request 2: WAITING 30 seconds for lock...
Request 3: WAITING 30+ seconds for lock...
Request 4: WAITING 30+ seconds for lock...
```

**Result:** Cascade of timeouts and angry users.

---

## The Solution (Daemon Pattern)

### What the Daemon Does (Already Implemented):
```python
# daemon.py - sign_and_advance()
with self._chain_lock:  # Lock acquired
    # Validate chain state
    # Compute new matrix
    # Compute chain hash
    # Update state
    # Persist to disk
# Lock released here

# Fire-and-forget server sync (OUTSIDE LOCK) ✅
threading.Thread(
    target=self._sync_chain_to_server,
    args=(agent_id, sequence, chain_hash, ...),
    daemon=True,
    name=f"chain-sync-{agent_id}-{sequence}"
).start()
```

### Key Properties:
1. **Lock released immediately** after local state update
2. **Network I/O happens in background** (daemon thread)
3. **Failures logged but don't block** caller
4. **Non-blocking**: Sign operation returns microseconds after lock release

---

## Proposed Fix for Middleware

### Pattern Translation:
| Daemon (sync) | Middleware (async) |
|---------------|-------------------|
| `threading.Thread(daemon=True)` | `asyncio.create_task()` |
| `threading.Thread(...).start()` | Fire-and-forget task |
| Exception caught in thread | Exception caught in task |

### Implementation:

```python
async def dispatch(self, request: Request, call_next):
    sign_result = None

    try:
        async with _chain_lock:  # Lock acquired
            # Get chain state
            chain_state = await asyncio.wait_for(
                run_in_threadpool(self._get_chain_state, self.agent_id),
                timeout=self.timeout,
            )
            parent_hash = chain_state.get("current_hash")

            # Sign and advance
            sign_result = await asyncio.wait_for(
                run_in_threadpool(
                    self._sign_and_advance,
                    self.agent_id,
                    self.task,
                    parent_hash,
                ),
                timeout=self.timeout,
            )

            logger.debug(
                f"Chain advanced: seq={sign_result['new_sequence']} "
                f"hash={sign_result['new_hash'][:16]}... task={self.task}"
            )
        # Lock released here ✅

        # Fire-and-forget server sync (OUTSIDE LOCK) ✅
        if self.server_sync and sign_result:
            asyncio.create_task(
                self._verify_with_server_background(
                    task=self.task,
                    signature=sign_result["signature"],
                    parent_hash=parent_hash,
                    state_matrix=sign_result["new_matrix"],
                    timestamp=sign_result["timestamp"],
                    sequence=sign_result["new_sequence"]
                )
            )

    except asyncio.TimeoutError:
        # ... existing error handling
        pass

    # Call downstream handler (inference) - CONCURRENT
    response = await call_next(request)

    # Add headers
    if sign_result:
        response.headers["X-LockStock-Agent-Id"] = self.agent_id
        response.headers["X-LockStock-Seq"] = str(sign_result["new_sequence"])
        # ...

    return response


async def _verify_with_server_background(
    self,
    task: str,
    signature: str,
    parent_hash: str,
    state_matrix: Dict[str, int],
    timestamp: int,
    sequence: int
) -> None:
    """
    Background task wrapper for server sync with error handling.

    This runs outside the chain lock to prevent blocking concurrent requests.
    Failures are logged but don't affect the calling request.
    """
    try:
        verify_result = await self._verify_with_server(
            task=task,
            signature=signature,
            parent_hash=parent_hash,
            state_matrix=state_matrix,
            timestamp=timestamp,
            sequence=sequence
        )
        logger.debug(
            f"Server sync complete: seq={sequence} "
            f"authorized={verify_result.get('authorized')}"
        )
    except Exception as e:
        logger.warning(
            f"Server sync failed for seq={sequence}: {e}",
            exc_info=True
        )
        # Don't raise - this is a background task


# Keep existing _verify_with_server() unchanged
async def _verify_with_server(self, task: str, ...) -> Dict[str, Any]:
    # ... existing implementation
```

---

## Safety Analysis

### Data Capture ✅
All required data is captured BEFORE the lock is released:
- `sign_result` contains all fields needed for server sync
- `parent_hash` captured before lock release
- No race conditions possible

### Error Handling ✅
- Exceptions caught in `_verify_with_server_background()`
- Logged with context (sequence number)
- Doesn't crash the main request flow
- Background task failure doesn't affect caller

### Concurrency ✅
- Multiple background tasks can run concurrently
- Each has unique sequence number
- Server handles out-of-order arrivals (sequence monotonicity check)
- No shared mutable state

### Resource Management ⚠️
**Potential Issue:** Unbounded task creation under high load

**Mitigation Options:**
1. **Task tracking**: Keep weak references to tasks
2. **Bounded semaphore**: Limit concurrent syncs
3. **Queue with worker**: Single background worker (overkill for now)

**Current Assessment:** Low priority - server sync is fast (milliseconds) except during cold start, and cold starts are rare.

---

## Performance Impact

### Before Fix:
```
Lock hold time = daemon_sign_time + server_sync_time
               = 50ms + 30000ms (cold start)
               = 30050ms

Throughput during cold start: 1 request / 30 seconds
```

### After Fix:
```
Lock hold time = daemon_sign_time
               = 50ms

Throughput: ~20 requests/second (limited by inference, not auth)
Server sync happens in background (doesn't block new requests)
```

### Improvement:
- **600x reduction in lock hold time** (30s → 50ms)
- **No more cascading timeouts**
- **Concurrent request handling** during server sync

---

## Edge Cases

### 1. Server Sync Slower Than Request Rate
**Scenario:** 100 requests/sec, server sync takes 5 seconds each

**Behavior:**
- 500 background tasks accumulating
- Memory usage increases
- Eventually stabilizes when sync rate matches request rate

**Mitigation:**
- Monitor task count (add metrics)
- Reduce httpx timeout to fail fast (5s instead of 30s)
- Future: Bounded queue with backpressure

### 2. Server Completely Down
**Behavior:**
- All background syncs fail after timeout
- Requests continue successfully (offline-first)
- Audit trail resumes when server recovers

**No degradation of inference throughput** ✅

### 3. Out-of-Order Sync Arrival
**Scenario:** Request 2's sync completes before Request 1's

**Behavior:**
- Server has sequence validation
- Both syncs accepted (monotonicity per sequence, not timestamp)
- Audit log reflects actual order

**No correctness issue** ✅

---

## Testing Plan

### Unit Tests:
```python
@pytest.mark.asyncio
async def test_server_sync_outside_lock():
    """Verify lock is released before server sync completes"""
    middleware = LockStockMiddleware(...)

    # Mock server with 5-second delay
    with patch_http_delay(5.0):
        # Send request
        response = await middleware.dispatch(request, call_next)

        # Verify lock released immediately (not held for 5 seconds)
        assert lock_hold_time < 0.1  # 100ms
        assert response.status_code == 200

@pytest.mark.asyncio
async def test_concurrent_requests_during_sync():
    """Verify concurrent requests don't queue during server sync"""
    middleware = LockStockMiddleware(...)

    # Mock server with 10-second delay
    with patch_http_delay(10.0):
        # Send 3 requests concurrently
        results = await asyncio.gather(
            middleware.dispatch(req1, call_next),
            middleware.dispatch(req2, call_next),
            middleware.dispatch(req3, call_next)
        )

        # All should complete in ~10 seconds (concurrent)
        # NOT 30 seconds (serial)
        assert total_time < 15.0  # Allow overhead
        assert all(r.status_code == 200 for r in results)
```

### Integration Test:
```bash
# Deploy middleware with fix
# Send 10 concurrent requests to Trinity
ab -n 10 -c 10 http://localhost:8002/v1/chat/completions

# Verify:
# 1. All requests complete successfully
# 2. Total time < 2 seconds (not 30 seconds)
# 3. Server receives all 10 syncs
# 4. Dashboard shows all 10 entries
```

---

## Rollout Plan

### Phase 1: Local Testing
1. Apply fix to middleware.py
2. Run unit tests
3. Test with Trinity locally
4. Verify lock metrics

### Phase 2: RunPod Deployment
1. Copy fixed middleware to RunPod
2. Restart Trinity adapter
3. Monitor logs for background sync warnings
4. Load test with 10 concurrent requests

### Phase 3: Production Validation
1. Deploy to production
2. Monitor dashboard for sync delays
3. Check for background task accumulation
4. Verify no increase in 401 errors

### Phase 4: PyPI Release (v1.1.3)
1. Update version in pyproject.toml
2. Update CHANGELOG.md
3. Build and publish
4. Update documentation

---

## Alternative Approaches Considered

### Option A: Reduce Timeout (Quick Fix)
```python
self._http = httpx.AsyncClient(timeout=5.0)  # Was: 30.0
```
**Pros:** One-line change
**Cons:** May fail on legitimate cold starts
**Verdict:** Bandaid, not solution

### Option B: Keep Sync Inside Lock (Status Quo)
**Pros:** Simple, no concurrency complexity
**Cons:** Terrible performance, cascading failures
**Verdict:** Unacceptable for production

### Option C: Background Queue with Worker
```python
# Single worker thread consumes sync queue
sync_queue = asyncio.Queue()
asyncio.create_task(sync_worker(sync_queue))

# Middleware adds to queue (non-blocking)
await sync_queue.put((agent_id, sequence, ...))
```
**Pros:** Bounded concurrency, rate limiting
**Cons:** Added complexity, single point of failure
**Verdict:** Overkill for current scale

### Option D: Fire-and-Forget (Proposed)
```python
asyncio.create_task(self._verify_with_server_background(...))
```
**Pros:** Simple, non-blocking, scales well
**Cons:** Unbounded tasks under extreme load
**Verdict:** ✅ Best balance for current needs

---

## Compatibility

### Backward Compatibility: ✅
- No API changes
- No config changes
- Existing deployments work unchanged
- Just faster

### Forward Compatibility: ✅
- Can add task tracking later
- Can add bounded queue later
- Can add metrics later
- Architecture supports evolution

---

## Decision Matrix

| Criteria | Inside Lock (Current) | Outside Lock (Proposed) |
|----------|----------------------|------------------------|
| Lock hold time | 30s (cold start) | 50ms |
| Throughput | 1 req/30s | 20 req/s |
| Cascading failures | Yes ❌ | No ✅ |
| Implementation complexity | Simple | Simple + |
| Memory usage | Low | Medium |
| Production ready | No ❌ | Yes ✅ |

---

## Recommendation

✅ **IMPLEMENT** the fire-and-forget pattern (Option D)

**Rationale:**
1. **Critical performance issue** - 30s lock hold is unacceptable
2. **Simple implementation** - ~20 lines of code
3. **Proven pattern** - Already works in daemon
4. **Low risk** - Failure mode is logged warnings (offline-first preserved)
5. **High impact** - 600x performance improvement

**Timeline:**
- Implementation: 30 minutes
- Testing: 1 hour
- Deployment: 30 minutes
- **Total: 2 hours to production**

---

## Implementation Checklist

- [ ] Add `_verify_with_server_background()` method
- [ ] Move `asyncio.create_task()` call outside lock
- [ ] Update docstrings to explain background behavior
- [ ] Add unit tests for concurrent behavior
- [ ] Test locally with Trinity
- [ ] Deploy to RunPod
- [ ] Load test with 10 concurrent requests
- [ ] Verify dashboard updates
- [ ] Monitor for 24 hours
- [ ] Publish to PyPI as v1.1.3
- [ ] Update documentation

---

## Conclusion

**Can this be implemented?** ✅ **YES**

**Should this be implemented?** ✅ **ABSOLUTELY**

**When?** ⏰ **Next session - high priority**

The pattern is proven (daemon already uses it), the implementation is straightforward, and the performance impact is dramatic. This is a textbook case of "move slow network I/O outside the critical section."

The fix transforms the middleware from "development toy" to "production ready."

---

**Status:** ✅ Ready for implementation
**Risk Level:** Low
**Impact:** High
**Priority:** 🔴 Critical (P0)

**Next Action:** Implement the fix and test with Trinity
