"""
LockStock A2A Protocol Adapter
-------------------------------
Adapts LockStock Agent Cards to the A2A (Agent-to-Agent) Protocol.

The A2A protocol, developed by Google and now under the Linux Foundation,
provides a standard for agent interoperability. This adapter ensures
LockStock agents can participate in A2A ecosystems.

See: https://a2a-protocol.org/
"""

from .adapter import A2AAdapter
from .agent_card import A2AAgentCard, A2ACapability, A2ASecurity
from .task_handler import A2ATaskHandler

__all__ = [
    "A2AAdapter",
    "A2AAgentCard",
    "A2ACapability",
    "A2ASecurity",
    "A2ATaskHandler"
]
