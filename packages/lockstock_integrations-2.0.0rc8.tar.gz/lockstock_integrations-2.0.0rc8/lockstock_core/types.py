"""
LockStock Core Types
--------------------
Shared types for all SDK integrations.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum


class VerifyStatus(str, Enum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    BUFFERED = "buffered"


@dataclass
class VerifyResult:
    """Result of a capability verification request."""
    status: VerifyStatus
    reason: Optional[str] = None
    state_hash: Optional[str] = None
    sequence: Optional[int] = None
    server_timestamp: Optional[int] = None

    @property
    def authorized(self) -> bool:
        return self.status == VerifyStatus.ACCEPTED


@dataclass
class AuditEntry:
    """An entry in the agent's audit trail."""
    sequence: int
    action: str
    timestamp: int
    state_hash: str
    signature: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AgentCard:
    """Agent identity and capabilities."""
    agent_id: str
    display_name: str
    capabilities: List[str]
    status: str = "active"
    fingerprint: Optional[str] = None
    owner_id: Optional[str] = None
    created_at: Optional[str] = None

    def has_capability(self, capability: str) -> bool:
        """Check if agent has a specific capability."""
        return capability.upper() in [c.upper() for c in self.capabilities]


# Mapping from common tool names to LockStock capabilities
# These map to the Task enum variants in Rust (case-insensitive)
TOOL_CAPABILITY_MAP = {
    # File operations -> FileRead, FileWrite
    "read": "FILEREAD",
    "read_file": "FILEREAD",
    "Read": "FILEREAD",
    "Glob": "FILEREAD",
    "glob": "FILEREAD",
    "Grep": "FILEREAD",
    "grep": "FILEREAD",
    "write": "FILEWRITE",
    "write_file": "FILEWRITE",
    "Write": "FILEWRITE",
    "edit": "FILEWRITE",
    "Edit": "FILEWRITE",
    "NotebookEdit": "FILEWRITE",

    # Shell/execution -> Shell (alias for Deploy)
    "bash": "SHELL",
    "Bash": "SHELL",
    "shell": "SHELL",
    "execute": "SHELL",
    "run_command": "SHELL",
    "KillShell": "SHELL",

    # Network operations -> Network
    "web_fetch": "NETWORK",
    "WebFetch": "NETWORK",
    "web_search": "NETWORK",
    "WebSearch": "NETWORK",
    "http_request": "NETWORK",
    "fetch": "NETWORK",

    # Database operations -> Database
    "sql": "DATABASE",
    "query": "DATABASE",
    "db_read": "DATABASE",
    "db_write": "DATABASE",
    "LSP": "DATABASE",  # Language Server Protocol reads code

    # Agent operations -> Teleport, Handoff
    "task": "TELEPORT",
    "Task": "TELEPORT",
    "spawn_agent": "TELEPORT",
    "TaskOutput": "TELEPORT",
    "handoff": "HANDOFF",
    "delegate": "DELEGATE",

    # State operations -> Checkpoint, Teleport
    "checkpoint": "CHECKPOINT",
    "save_state": "CHECKPOINT",
    "export_passport": "TELEPORT",
    "import_passport": "TELEPORT",

    # Monitoring -> Heartbeat
    "heartbeat": "HEARTBEAT",
    "health_check": "HEARTBEAT",

    # Operations -> Deploy, Restart, Backup, Rollback
    "deploy": "DEPLOY",
    "restart": "RESTART",
    "backup": "BACKUP",
    "rollback": "ROLLBACK",

    # Task management tools
    "TaskCreate": "FILEWRITE",
    "TaskUpdate": "FILEWRITE",
    "TaskList": "FILEREAD",
    "TaskGet": "FILEREAD",

    # Skills
    "Skill": "SHELL",
    "AskUserQuestion": "HEARTBEAT",  # Interactive, low privilege
    "EnterPlanMode": "HEARTBEAT",
    "ExitPlanMode": "HEARTBEAT",
}


def map_tool_to_capability(tool_name: str) -> str:
    """Map a tool name to a LockStock capability."""
    return TOOL_CAPABILITY_MAP.get(tool_name, "UNKNOWN")
