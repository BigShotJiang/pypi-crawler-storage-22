"""
LockStock FastAPI Integration
------------------------------
Production-ready middleware for FastAPI inference servers.

Uses the thin client pattern - no daemon required, no local crypto.
Calls /v1/stamp API, server handles everything.
Supports SSE streaming (pure ASGI, no buffering).

Usage:
    from fastapi import FastAPI
    from lockstock_fastapi import LockStockMiddleware

    app = FastAPI()
    app.add_middleware(
        LockStockMiddleware,
        agent_id="agent_xxx_name",
        api_key="lsk_admin_...",
        path_tasks={"/v1/chat/completions": "chatcompletion"},
    )
"""

from .thin import LockStockThinMiddleware, StampResult

# Alias for convenience - LockStockMiddleware is now the thin middleware
LockStockMiddleware = LockStockThinMiddleware

__all__ = ["LockStockMiddleware", "LockStockThinMiddleware", "StampResult"]
