"""
LockStock OpenAI Agents SDK Integration
----------------------------------------
Provides tracing for OpenAI Agents SDK using the thin client pattern.
"""

from .tracing import LockStockTracer

__all__ = ["LockStockTracer"]
