# locraft

AI-powered localization pipeline. Translate, validate, and ship your app in 70+ languages.

Coming soon. Built by Fabrica Studio, Barcelona.
