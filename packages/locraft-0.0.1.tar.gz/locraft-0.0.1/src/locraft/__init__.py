"""locraft – AI-powered localization pipeline."""

__version__ = "0.0.1"
