"""Version information for log2fast-fastapi."""

__version__ = "0.1.0"
__author__ = "Angel Daniel Sanchez Castillo"
__license__ = "MIT"
