# Log Similarity SDK - Project Overview

## Project Structure

```
log-similarity-sdk/
├── log_similarity/              # Main package directory
│   ├── __init__.py             # Package initialization and exports
│   ├── similarity_clusterer.py # Core clustering algorithm
│   ├── preprocessor.py         # Log preprocessing and normalization
│   └── logram.py               # Log parsing and template extraction
├── examples/                    # Usage examples
│   ├── basic_usage.py          # Basic usage demonstration
│   └── advanced_usage.py       # Advanced features demonstration
├── README.md                    # Main documentation (PyPI page)
├── PUBLISH.md                   # Publishing guide
├── LICENSE                      # MIT License
├── setup.py                     # Package setup configuration
├── pyproject.toml              # Modern Python packaging config
├── MANIFEST.in                 # File inclusion rules
├── .gitignore                  # Git ignore rules
└── test_sdk.py                 # Test suite
```

## Core Components

### 1. SimilarityClusterer (`similarity_clusterer.py`)

Main class for log clustering and analysis.

**Key Features:**
- Similarity-driven clustering algorithm
- Efficient length-based indexing
- Support for finding unmatched logs
- Batch processing capabilities

**New Methods Added:**
- `predict_batch()`: Batch prediction for multiple logs
- `find_unmatched_logs()`: Returns logs that don't match any cluster

**Key Changes from Original:**
- Removed `__main__` test code
- Enhanced `predict()` to include 'original' field
- Changed match_type from 'similar'/'new' to 'matched'/'unmatched'
- Added comprehensive batch processing support

### 2. LogPreprocessor (`preprocessor.py`)

Multi-layer pattern matching for log normalization.

**Features:**
- Complex structure detection (JSON, XML, URLs, SQL)
- Key-value pair preservation
- Dynamic field normalization (IPs, timestamps, UUIDs)
- Domain-specific patterns (Java, databases)

**Changes:**
- Removed `__main__` test code
- No functional changes - ready for production use

### 3. LogramParser (`logram.py`)

Token extraction and template generation.

**Features:**
- Tokenization with delimiter preservation
- Template extraction
- Variable part identification

**Changes:**
- Removed `__main__` test code
- No functional changes

## SDK API

### Main Class: SimilarityClusterer

```python
from log_similarity import SimilarityClusterer

# Initialize
clusterer = SimilarityClusterer(
    similarity_threshold=0.90,    # Matching threshold
    merge_threshold=0.95,         # Merge threshold
    length_tolerance=0.3          # Length tolerance
)

# Build clusters from base logs
clusterer.fit(base_logs, verbose=True)

# Find unmatched logs
unmatched = clusterer.find_unmatched_logs(new_logs, verbose=True)

# Predict single log
result = clusterer.predict(single_log)

# Get all clusters
clusters = clusterer.get_all_clusters()
```

## Use Cases

1. **Error Log Monitoring**: Build clusters from known error patterns, detect new anomalies
2. **Log Deduplication**: Group similar logs to reduce noise
3. **Anomaly Detection**: Identify unusual patterns in production logs
4. **Log Analysis**: Understand log distribution and common patterns

## Installation

### From PyPI (after publishing):
```bash
pip install log-similarity
```

### From source:
```bash
cd log-similarity-sdk
pip install -e .
```

## Testing

Run the test suite:
```bash
python test_sdk.py
```

Run examples:
```bash
PYTHONPATH=. python examples/basic_usage.py
PYTHONPATH=. python examples/advanced_usage.py
```

## Publishing to PyPI

See `PUBLISH.md` for detailed instructions.

**Quick steps:**

1. Install build tools:
```bash
pip install --upgrade build twine
```

2. Build distribution:
```bash
python -m build
```

3. Upload to PyPI:
```bash
python -m twine upload dist/*
```

## Key Features

### 1. Base Log Clustering
Train the clusterer on known error patterns:
```python
base_logs = ["Error A", "Error B", ...]
clusterer.fit(base_logs)
```

### 2. Unmatched Log Detection
Find logs that don't match any existing cluster:
```python
new_logs = ["Error X", "Error Y", ...]
unmatched = clusterer.find_unmatched_logs(new_logs)
```

Each unmatched log includes:
- `original`: Original log message
- `preprocessed`: Preprocessed version
- `template`: Extracted template
- `similarity`: Best similarity score

## Configuration

### Similarity Threshold
Controls how strict the matching is:
- **0.95+**: Very strict - only nearly identical logs match
- **0.85-0.95**: Balanced - good for most use cases
- **0.75-0.85**: Lenient - groups more logs together
- **< 0.75**: Very lenient - may over-cluster

### Length Tolerance
Controls length-based filtering (default: 0.3):
- Only compares logs with similar token counts
- Higher value = compare more diverse lengths
- Lower value = faster but may miss some matches

## Dependencies

**None!** Pure Python implementation with no external dependencies.

Requires: Python >= 3.7

## Performance

- **Memory**: O(n) where n = number of clusters
- **Training**: O(n*m) where n = logs, m = clusters
- **Prediction**: O(m) where m = clusters (with length indexing)

Efficient for:
- Thousands of clusters
- Millions of logs
- Real-time prediction

## License

MIT License - See LICENSE file

## Next Steps

1. **Customize Configuration**: Adjust thresholds for your use case
2. **Test on Real Data**: Try with your actual log files
3. **Integrate**: Add to your monitoring/logging pipeline
4. **Publish**: Share on PyPI for others to use

## Support

- GitHub Issues: Report bugs and request features
- Examples: See `examples/` directory
- Documentation: See README.md

## Contributing

Contributions welcome! Areas for improvement:
- Additional preprocessing patterns
- Performance optimizations
- More examples and use cases
- Better documentation
