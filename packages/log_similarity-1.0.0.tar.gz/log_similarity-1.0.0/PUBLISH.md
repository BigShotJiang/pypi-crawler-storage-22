# Publishing to PyPI

This guide explains how to publish the Log Similarity SDK to PyPI.

## Prerequisites

1. Install build tools:
```bash
pip install --upgrade pip setuptools wheel twine build
```

2. Create PyPI account:
   - Go to https://pypi.org/account/register/
   - Verify your email address

3. Create API token:
   - Go to https://pypi.org/manage/account/token/
   - Create a token with "Entire account" scope
   - Save the token securely

## Build the Package

1. Clean previous builds:
```bash
rm -rf build/ dist/ *.egg-info
```

2. Build the distribution packages:
```bash
python -m build
```

This will create:
- `dist/log-similarity-0.1.0.tar.gz` (source distribution)
- `dist/log_similarity-0.1.0-py3-none-any.whl` (wheel distribution)

## Test the Package Locally

Before publishing, test the package locally:

```bash
# Install in editable mode
pip install -e .

# Test import
python -c "from log_similarity import SimilarityClusterer; print('Import successful!')"

# Run examples
python examples/basic_usage.py
```

## Publish to Test PyPI (Recommended First)

1. Create Test PyPI account at https://test.pypi.org/account/register/

2. Upload to Test PyPI:
```bash
python -m twine upload --repository testpypi dist/*
```

3. Test installation from Test PyPI:
```bash
pip install --index-url https://test.pypi.org/simple/ log-similarity
```

## Publish to Production PyPI

When you're confident the package works correctly:

```bash
python -m twine upload dist/*
```

You'll be prompted for:
- Username: `__token__`
- Password: Your PyPI API token (starting with `pypi-`)

## After Publishing

1. Verify the package page: https://pypi.org/project/log-similarity/

2. Test installation:
```bash
pip install log-similarity
```

3. Tag the release on GitHub:
```bash
git tag v0.1.0
git push origin v0.1.0
```

## Updating the Package

For future updates:

1. Update version in:
   - `log_similarity/__init__.py`
   - `setup.py`
   - `pyproject.toml`

2. Update CHANGELOG (create if doesn't exist)

3. Rebuild and republish:
```bash
rm -rf build/ dist/ *.egg-info
python -m build
python -m twine upload dist/*
```

## Troubleshooting

### Error: Package already exists

If you get a "File already exists" error, you need to increment the version number.

### Import errors after installation

Make sure the package structure is correct:
```
log-similarity-sdk/
├── log_similarity/
│   ├── __init__.py
│   ├── similarity_clusterer.py
│   ├── preprocessor.py
│   └── logram.py
├── setup.py
└── pyproject.toml
```

### Authentication issues

- Make sure you're using `__token__` as username
- Your token should start with `pypi-`
- Don't share your API token publicly

## Best Practices

1. Always test on Test PyPI first
2. Use semantic versioning (MAJOR.MINOR.PATCH)
3. Keep README.md up to date
4. Add a CHANGELOG.md for version history
5. Test installation in a fresh virtual environment
6. Create GitHub releases for each version

## Resources

- PyPI Help: https://pypi.org/help/
- Packaging Tutorial: https://packaging.python.org/tutorials/packaging-projects/
- Twine Documentation: https://twine.readthedocs.io/
