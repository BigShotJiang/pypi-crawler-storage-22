# Quick Start Guide

## SDK 已完成！

Log Similarity SDK 已成功封装，包含以下核心功能：

### ✅ 核心功能

1. **基于 base 错误日志构建聚类**
   ```python
   from log_similarity import SimilarityClusterer

   clusterer = SimilarityClusterer(similarity_threshold=0.85)
   clusterer.fit(base_error_logs, verbose=True)
   ```

2. **返回未命中聚类的错误日志**
   ```python
   unmatched = clusterer.find_unmatched_logs(new_logs, verbose=True)
   # 返回所有没有匹配到任何聚类的日志
   ```

### 📦 项目结构

```
log-similarity-sdk/
├── log_similarity/          # 核心 SDK 代码
│   ├── __init__.py
│   ├── similarity_clusterer.py  # 主聚类算法
│   ├── preprocessor.py          # 日志预处理
│   └── logram.py                # 日志解析
├── examples/                # 使用示例
│   ├── basic_usage.py       # 基础用法
│   └── advanced_usage.py    # 高级用法
├── README.md                # 官方文档
├── setup.py                 # PyPI 发布配置
├── pyproject.toml          # 现代 Python 打包配置
└── test_sdk.py             # 测试套件
```

### 🚀 立即测试

```bash
cd /Users/10005612/Projects/lrtht/log-similarity-sdk

# 运行测试
python test_sdk.py

# 运行示例
PYTHONPATH=. python examples/basic_usage.py
```

### 📝 使用示例

#### 场景 1: 检测新错误模式

```python
from log_similarity import SimilarityClusterer

# 1. 用已知错误日志训练
base_logs = [
    "User 12345 logged in from 192.168.1.100",
    "Database connection timeout after 30 seconds",
    "GET /api/users returned 404",
]

clusterer = SimilarityClusterer(similarity_threshold=0.85)
clusterer.fit(base_logs, verbose=True)
# 输出: Created 3 clusters

# 2. 检查新日志，找出未匹配的（新错误模式）
new_logs = [
    "User 99999 logged in from 10.0.0.1",      # 匹配 cluster 1
    "Critical: Out of memory error",           # 新模式！
    "Fatal: Disk space exhausted",             # 新模式！
]

unmatched = clusterer.find_unmatched_logs(new_logs, verbose=True)
# 输出: Found 2 unmatched logs

# 3. 处理新错误
for log in unmatched:
    print(f"New error pattern: {log['original']}")
    # 发送告警、记录到数据库等
```

#### 场景 2: 单个日志分类

```python
result = clusterer.predict("User 88888 logged in from 172.16.0.1")

if result['match_type'] == 'matched':
    print(f"Known error, cluster: {result['cluster_id']}")
else:
    print(f"New error pattern detected!")
```

### 📤 发布到 PyPI

#### 1. 更新配置（必需）

编辑以下文件，替换占位符：

**setup.py**:
```python
author_email="your.email@example.com",
url="https://github.com/suiwenfeng/log-similarity-sdk",
```

**pyproject.toml**:
```toml
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]
```

#### 2. 构建和发布

```bash
# 安装构建工具
pip install --upgrade build twine

# 构建包
python -m build

# 先发布到 Test PyPI（推荐）
python -m twine upload --repository testpypi dist/*

# 测试安装
pip install --index-url https://test.pypi.org/simple/ log-similarity

# 确认无误后，发布到正式 PyPI
python -m twine upload dist/*
```

#### 3. 验证

```bash
pip install log-similarity
python -c "from log_similarity import SimilarityClusterer; print('Success!')"
```

### 📚 详细文档

- **README.md**: 完整的 API 文档和使用说明
- **PUBLISH.md**: PyPI 发布详细指南
- **PROJECT_OVERVIEW.md**: 项目结构和设计说明
- **CHECKLIST.md**: 发布前检查清单

### 🎯 核心优势

1. **零依赖**: 纯 Python 实现，无需外部依赖
2. **高性能**: 基于长度索引的高效查找
3. **灵活配置**: 可调整相似度阈值
4. **完整文档**: API 文档 + 使用示例
5. **生产就绪**: 经过测试，可直接使用

### 💡 实际应用场景

1. **日志监控**: 从历史日志构建基线，监控新错误
2. **异常检测**: 识别生产环境中的异常模式
3. **日志去重**: 合并相似日志，减少噪音
4. **模板提取**: 自动提取日志模板

### ⚙️ 配置建议

**相似度阈值**:
- `0.95`: 非常严格，只匹配几乎相同的日志
- `0.85`: 推荐值，平衡准确性和召回率
- `0.75`: 宽松，会将更多日志归为一类

**使用场景**:
- 错误监控: 使用较高阈值 (0.90-0.95)
- 日志分类: 使用中等阈值 (0.80-0.90)
- 模板提取: 使用较低阈值 (0.75-0.85)

### 📞 支持

- 问题反馈: GitHub Issues
- 功能请求: GitHub Issues
- 贡献代码: Pull Requests

---

**现在就开始使用吧！** 🎉
