# Log Similarity SDK

一个强大的 Python SDK，用于基于相似度的日志聚类和错误日志分析。自动将相似的日志消息分组到聚类中，并识别不匹配现有模式的异常日志。

## 核心功能

- **智能日志聚类**: 基于语义相似度自动分组相似日志
- **多层预处理**: 通用日志格式的高级模式规范化
- **未匹配日志检测**: 识别不符合任何现有聚类的错误日志
- **高性能**: 高效的基于长度的索引和相似度计算
- **灵活配置**: 可自定义的相似度阈值和预处理规则

## 安装

```bash
pip install log-similarity
```

或从源码安装:

```bash
git clone https://github.com/suiwenfeng/log-similarity-sdk.git
cd log-similarity-sdk
pip install -e .
```

## 快速开始

### 1. 从基础错误日志构建聚类

```python
from log_similarity import SimilarityClusterer

# 基础错误日志样本
base_logs = [
    "User 12345 logged in from 192.168.1.100",
    "User 67890 logged in from 10.0.0.1",
    "Database connection timeout after 30 seconds",
    "Database connection timeout after 45 seconds",
    "GET /api/users returned 404",
    "GET /api/posts returned 500",
]

# 创建并训练聚类器
clusterer = SimilarityClusterer(similarity_threshold=0.85)
clusterer.fit(base_logs, verbose=True)

# 查看聚类摘要
clusterer.print_summary()
```

### 2. 查找未匹配的错误日志

```python
# 要检查的新错误日志
new_logs = [
    "User 11111 logged in from 172.16.0.1",  # 与聚类 1 相似
    "GET /api/products returned 404",         # 与聚类 3 相似
    "Critical: Out of memory error",          # 新的 - 不匹配任何聚类
    "Fatal: Disk space exhausted",            # 新的 - 不匹配任何聚类
]

# 查找不匹配任何现有聚类的日志
unmatched = clusterer.find_unmatched_logs(new_logs, verbose=True)

# 处理未匹配的日志
for log in unmatched:
    print(f"未匹配: {log['original']}")
    print(f"模板:  {log['template']}")
    print(f"相似度: {log['similarity']:.2f}\n")
```

## 主要方法

### `fit(log_messages, verbose=True)`
从训练日志构建聚类。

### `find_unmatched_logs(log_messages, verbose=False)`
查找不匹配任何现有聚类的日志。

### `predict(log_message)`
预测单个日志属于哪个聚类。

### `predict_batch(log_messages, verbose=False)`
批量预测多个日志的聚类。

### `get_all_clusters()`
获取所有聚类及其详细信息。

## 实际应用场景

1. **错误日志监控**: 从已知错误模式构建聚类，检测新异常
2. **日志去重**: 将相似日志分组以减少噪音
3. **异常检测**: 识别生产日志中的异常模式
4. **日志模板提取**: 自动提取日志模板
5. **日志分析**: 理解日志分布和模式

## 配置建议

### 相似度阈值
- **0.95+**: 非常严格 - 只有几乎相同的日志才匹配
- **0.85-0.95**: 平衡 - 适用于大多数用例
- **0.75-0.85**: 宽松 - 将更多日志分组在一起
- **< 0.75**: 非常宽松 - 可能过度聚类

## 算法原理

SDK 使用基于相似度驱动的聚类算法：

1. **多层预处理**: 规范化动态部分（IP、时间戳、UUID 等）
2. **模板提取**: 使用 Logram 解析器识别静态和动态部分
3. **相似度计算**: 结合 Jaccard 相似度、前缀匹配和长度比率
4. **高效索引**: 基于长度的索引用于快速聚类查找

## 依赖要求

- Python >= 3.7
- 无外部依赖（纯 Python）

## 许可证

MIT License

## 贡献

欢迎贡献！请随时提交 Pull Request。

## 支持

如有问题和疑问，请在 GitHub 上提交 issue。
