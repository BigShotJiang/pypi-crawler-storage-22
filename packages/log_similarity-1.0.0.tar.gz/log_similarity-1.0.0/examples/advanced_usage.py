"""
Advanced Usage Example
Demonstrates batch processing and custom configuration
"""

from log_similarity import SimilarityClusterer, PreprocessorConfig


def batch_processing_example():
    """Example: Processing large log files"""
    print("\n" + "=" * 70)
    print("Example 1: Batch Processing Large Log Files")
    print("=" * 70)

    # Simulate reading from a large log file
    # In practice, you would read from an actual file
    all_logs = [
        f"User {i:05d} logged in from 192.168.{i%256}.{i%256}"
        for i in range(1000)
    ]

    # Add some anomalous logs
    all_logs.extend([
        "Critical: Memory corruption detected at 0x7fff5fbfe000",
        "Fatal: System call failed with errno 28",
        "Panic: Unable to mount root filesystem",
    ])

    print(f"Total logs: {len(all_logs)}")

    # Build clusters from first 90% of logs
    split_point = int(len(all_logs) * 0.9)
    training_logs = all_logs[:split_point]
    testing_logs = all_logs[split_point:]

    print(f"Training set: {len(training_logs)} logs")
    print(f"Testing set: {len(testing_logs)} logs")

    # Train
    clusterer = SimilarityClusterer(similarity_threshold=0.90)
    clusterer.fit(training_logs, verbose=False)
    print(f"Clusters created: {clusterer.get_cluster_count()}")

    # Find unmatched in testing set
    unmatched = clusterer.find_unmatched_logs(testing_logs, verbose=True)

    print(f"\nUnmatched logs in testing set:")
    for log in unmatched:
        print(f"  - {log['original'][:80]}...")


def custom_threshold_example():
    """Example: Different similarity thresholds"""
    print("\n" + "=" * 70)
    print("Example 2: Comparing Different Similarity Thresholds")
    print("=" * 70)

    base_logs = [
        "Connection timeout to database server",
        "Connection timeout to cache server",
        "Request timeout from API endpoint",
        "User authentication failed",
        "User authorization denied",
    ]

    test_logs = [
        "Connection timeout to mail server",
        "User session expired",
    ]

    thresholds = [0.95, 0.85, 0.75]

    for threshold in thresholds:
        print(f"\n--- Threshold: {threshold} ---")
        clusterer = SimilarityClusterer(similarity_threshold=threshold)
        clusterer.fit(base_logs, verbose=False)

        print(f"Clusters: {clusterer.get_cluster_count()}")

        unmatched = clusterer.find_unmatched_logs(test_logs, verbose=False)
        print(f"Unmatched: {len(unmatched)}/{len(test_logs)}")

        for log in unmatched:
            print(f"  - {log['original']} (similarity: {log['similarity']:.2f})")


def cluster_analysis_example():
    """Example: Analyzing clusters"""
    print("\n" + "=" * 70)
    print("Example 3: Cluster Analysis")
    print("=" * 70)

    logs = [
        "GET /api/users/123 returned 200",
        "GET /api/users/456 returned 200",
        "GET /api/users/789 returned 200",
        "POST /api/users returned 400",
        "POST /api/users returned 400",
        "Database query executed in 150ms",
        "Database query executed in 200ms",
        "Database query executed in 175ms",
        "Database query executed in 225ms",
    ]

    clusterer = SimilarityClusterer(similarity_threshold=0.85)
    clusterer.fit(logs, verbose=False)

    # Get all clusters
    clusters = clusterer.get_all_clusters()

    print(f"\nTotal clusters: {len(clusters)}")
    print("\nCluster details:")

    for i, cluster in enumerate(clusters, 1):
        print(f"\n[Cluster {i}] ID: {cluster['cluster_id']}")
        print(f"  Template: {cluster['template']}")
        print(f"  Count: {cluster['count']}")
        print(f"  Sample logs:")
        for sample in cluster['sample_logs'][:3]:
            print(f"    - {sample}")


def save_and_analyze_example():
    """Example: Save results for further analysis"""
    print("\n" + "=" * 70)
    print("Example 4: Save Results")
    print("=" * 70)

    logs = [
        "Error: Connection refused to host 10.0.0.1 port 8080",
        "Error: Connection refused to host 10.0.0.2 port 8080",
        "Warning: Slow query detected, duration 5.2s",
        "Warning: Slow query detected, duration 6.8s",
    ]

    clusterer = SimilarityClusterer(similarity_threshold=0.85)
    clusterer.fit(logs, verbose=False)

    # Save clusterer state
    output_file = "/tmp/log_clusters.json"
    clusterer.save(output_file)
    print(f"Saved cluster state to: {output_file}")


def main():
    print("Log Similarity SDK - Advanced Usage Examples")

    # Run all examples
    batch_processing_example()
    custom_threshold_example()
    cluster_analysis_example()
    save_and_analyze_example()

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70)


if __name__ == "__main__":
    main()
