"""
Basic Usage Example
Shows how to use log-similarity SDK for error log clustering
"""

from log_similarity import SimilarityClusterer


def main():
    print("=" * 70)
    print("Log Similarity SDK - Basic Usage Example")
    print("=" * 70)

    # Step 1: Prepare base error logs (training data)
    print("\n[Step 1] Preparing base error logs...")
    base_error_logs = [
        "User 12345 logged in from 192.168.1.100",
        "User 67890 logged in from 10.0.0.1",
        "User 99999 logged in from 172.16.0.5",
        "Database connection timeout after 30 seconds",
        "Database connection timeout after 45 seconds",
        "Database connection timeout after 60 seconds",
        "GET /api/users returned 404",
        "GET /api/posts returned 404",
        "POST /api/login returned 500",
        "POST /api/register returned 500",
        "Cache miss for key user_profile_123",
        "Cache miss for key user_profile_456",
    ]

    print(f"Total base logs: {len(base_error_logs)}")

    # Step 2: Build clusters from base logs
    print("\n[Step 2] Building clusters from base logs...")
    clusterer = SimilarityClusterer(similarity_threshold=0.85)
    clusterer.fit(base_error_logs, verbose=True)

    # Step 3: View cluster summary
    print("\n[Step 3] Cluster summary:")
    clusterer.print_summary()

    # Step 4: Check new error logs
    print("\n[Step 4] Checking new error logs...")
    new_error_logs = [
        # These should match existing clusters
        "User 11111 logged in from 10.0.0.50",
        "Database connection timeout after 25 seconds",
        "GET /api/products returned 404",
        "Cache miss for key user_profile_789",

        # These are new patterns (should be unmatched)
        "Critical: Out of memory error at 0x7fff5fbfe000",
        "Fatal: Disk space exhausted on /dev/sda1",
        "Segmentation fault in process 12345",
        "NullPointerException at com.example.UserService.findUser",
    ]

    print(f"Total new logs to check: {len(new_error_logs)}")

    # Step 5: Find unmatched logs
    print("\n[Step 5] Finding unmatched logs...")
    unmatched_logs = clusterer.find_unmatched_logs(new_error_logs, verbose=True)

    # Step 6: Display unmatched logs (new error patterns)
    print("\n[Step 6] New error patterns detected:")
    print("-" * 70)
    if unmatched_logs:
        for i, log in enumerate(unmatched_logs, 1):
            print(f"\n[{i}] Original: {log['original']}")
            print(f"    Template: {log['template']}")
            print(f"    Best similarity: {log['similarity']:.2f}")
    else:
        print("No new error patterns found. All logs matched existing clusters.")

    # Step 7: Predict individual logs
    print("\n[Step 7] Predicting individual logs...")
    test_logs = [
        "User 88888 logged in from 192.168.5.100",
        "Kernel panic: Fatal exception in interrupt",
    ]

    for log in test_logs:
        result = clusterer.predict(log)
        print(f"\nLog: {log}")
        print(f"Match type: {result['match_type']}")
        if result['match_type'] == 'matched':
            print(f"Cluster ID: {result['cluster_id']}")
            print(f"Similarity: {result['similarity']:.2f}")
        else:
            print(f"No match found (best similarity: {result['similarity']:.2f})")

    print("\n" + "=" * 70)
    print("Example completed!")
    print("=" * 70)


if __name__ == "__main__":
    main()
