"""
Logram Parser - Token extraction and normalization
Simplified implementation based on Logram paper principles
"""
import re
from typing import List, Tuple


class LogramParser:
    """
    Logram-style parser that extracts tokens and identifies variable positions
    """
    
    def __init__(self):
        # Token delimiters (whitespace, special chars)
        self.delimiters = r'[\s:,;=\[\](){}]+'
        
    def tokenize(self, message: str) -> List[str]:
        """
        Tokenize log message into words/tokens
        
        Args:
            message: Preprocessed log message
            
        Returns:
            List of tokens
        """
        # Split by delimiters but keep delimiters
        tokens = re.split(f'({self.delimiters})', message)
        # Filter out empty strings
        tokens = [t for t in tokens if t and t.strip()]
        return tokens
    
    def extract_template(self, message: str) -> Tuple[str, List[str]]:
        """
        Extract template from message by identifying variable parts
        
        Args:
            message: Preprocessed log message (after preprocessor)
            
        Returns:
            Tuple of (template_string, list_of_tokens)
        """
        tokens = self.tokenize(message)
        
        # After preprocessing, dynamic parts are already marked as <*>
        # We just need to create a normalized template
        template_tokens = []
        for token in tokens:
            # Check if token looks like a preprocessor placeholder
            if re.match(r'<[A-Z_]+>', token):
                template_tokens.append('<*>')
            elif self._is_likely_variable(token):
                template_tokens.append('<*>')
            else:
                template_tokens.append(token)
        
        template = ' '.join(template_tokens)
        return template, tokens
    
    def _is_likely_variable(self, token: str) -> bool:
        """
        Heuristic to identify if a token is likely a variable
        (catches things the preprocessor might have missed)
        """
        # Pure numbers (longer ones)
        if re.match(r'^\d{4,}$', token):
            return True
        
        # Hex strings
        if re.match(r'^0x[0-9a-fA-F]+$', token):
            return True
        
        # Very long alphanumeric strings (likely IDs)
        if len(token) > 32 and re.match(r'^[a-zA-Z0-9]+$', token):
            return True
        
        return False
    
    def get_token_count(self, message: str) -> int:
        """Get number of tokens in message"""
        return len(self.tokenize(message))
