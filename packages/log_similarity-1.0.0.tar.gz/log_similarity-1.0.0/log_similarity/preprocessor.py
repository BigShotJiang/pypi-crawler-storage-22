"""
Intelligent Log Preprocessor
Multi-layer pattern matching for universal log normalization
"""
import re
from typing import List, Tuple, Dict
from enum import Enum


class TokenType(Enum):
    """Token types for pattern identification"""
    STATIC = "STATIC"
    DYNAMIC = "DYNAMIC"


class PreprocessorConfig:
    """Configuration for preprocessing rules"""
    def __init__(self):
        # Layer 1: Complex structures (process first to avoid fragmentation)
        self.complex_patterns = [
            # Connection IDs (MUST BE BEFORE JSON to avoid being matched as {JSON})
            (r'\{conn-\d+\}', '<CONN_ID>'),

            # Java/Python stack traces (multi-line)
            (r'\n\s*at\s+[\w.$]+\.[\w.<>]+\([^)]*\)(?:\n\s*at\s+[\w.$]+\.[\w.<>]+\([^)]*\))*', '<STACKTRACE>'),
            (r'\n\s*File\s+"[^"]+",\s+line\s+\d+(?:,\s+in\s+\w+)?', '<STACKTRACE>'),

            # JSON objects - match various formats
            (r'\{["\w\s:,\-\.0-9]+\}', '<JSON>'),
            # JSON arrays with objects
            (r'\[\s*\{[^}]*\}(?:\s*,\s*\{[^}]*\})*\s*\]', '<JSON_ARRAY>'),

            # XML removed - rarely appears in logs and causes false matches

            # Complete URLs with query parameters
            (r'https?://[^\s\]]+(?:\?[^\s\]]+)?', '<URL>'),

            # SQL queries (basic detection)
            (r'(?i)\b(?:SELECT|INSERT|UPDATE|DELETE)\s+.{10,200}?\b(?:FROM|INTO|SET|WHERE)\b', '<SQL>'),
        ]
        
        # Layer 2: Structured key-value pairs
        self.kv_patterns = [
            # key=value or key:value (preserve the key name)
            (r'(\w+)=[\w\-\.]+', r'\1=<VAL>'),
            (r'(\w+):\s*["\']?[\w\-\.]+["\']?(?=\s|,|$)', r'\1:<VAL>'),
        ]
        
        # Layer 3: Common dynamic fields
        self.dynamic_patterns = [
            # UUIDs and GUIDs
            (r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', '<UUID>'),
            (r'\b[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\b', '<UUID>'),

            # IP addresses (IPv4 and IPv6)
            (r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '<IP>'),
            (r'\b(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b', '<IPV6>'),

            # Timestamps (ISO, RFC, Unix, etc.)
            (r'\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?', '<TIMESTAMP>'),
            (r'\d{2}/[A-Za-z]{3}/\d{4}:\d{2}:\d{2}:\d{2}\s[+-]\d{4}', '<TIMESTAMP>'),
            (r'\b\d{10,13}\b', '<UNIX_TS>'),

            # Time durations with units (MUST BE BEFORE generic numbers)
            # Matches various formats:
            # - "58,658 milliseconds" (comma without space)
            # - "58 , 658 milliseconds" (comma with spaces)
            # - "59,929 milliseconds" (multiple digits with comma)
            # - "30 minutes", "2 hours" (no comma)
            (r'\b\d+(?:\s*,\s*\d+)*\s*(?:milliseconds?|ms|seconds?|sec|s|minutes?|min|hours?|hrs?|h)\b', '<TIME_DURATION>'),

            # File paths (Unix and Windows)
            (r'(?:/[\w\-\.]+){2,}', '<PATH>'),
            (r'[A-Z]:\\(?:[\w\-\.]+\\)+[\w\-\.]+', '<PATH>'),

            # Hex values and hashes
            (r'\b0x[0-9a-fA-F]{6,}\b', '<HEX>'),
            (r'\b[0-9a-f]{32,128}\b', '<HASH>'),

            # Email addresses
            (r'\b[\w\.-]+@[\w\.-]+\.\w{2,}\b', '<EMAIL>'),

            # Port numbers (after colons, but not HTTP status codes)
            (r':(\d{4,5})\b', ':<PORT>'),

            # Generic numbers (but preserve small numbers that might be meaningful)
            # Avoid replacing numbers in class names, exception types
            (r'(?<![a-zA-Z_$])\b\d{6,}\b(?![a-zA-Z_$])', '<NUM>'),
            (r'(?<![a-zA-Z_$])\b\d+\.\d+\b(?![a-zA-Z_$])', '<FLOAT>'),
        ]
        
        # Layer 4: Domain-specific patterns (Java, databases, etc.)
        self.domain_patterns = [
            # Java implementation details (MUST BE FIRST to normalize before other processing)
            # File name with line number: AbstractQpsQuery.java:111 → <FILE_LINE>
            (r'\b\w+\.java\s*:\s*\d+\b', '<FILE_LINE>'),

            # Java dynamic proxy classes: $Proxy464 → <PROXY>
            (r'\$Proxy\d+', '<PROXY>'),

            # JDK proxy packages: jdk.proxy3 → jdk.proxy<NUM>
            (r'jdk\.proxy\d+', 'jdk.proxy<NUM>'),

            # Generated method accessors: GeneratedMethodAccessor411 → <ACCESSOR>
            (r'\bGeneratedMethodAccessor\d+\b', '<ACCESSOR>'),

            # Java reflection implementations (preserve invoke but normalize class)
            # NativeMethodAccessorImpl → <REFLECTION>
            # DelegatingMethodAccessorImpl → <REFLECTION>
            (r'\b(?:Native|Delegating)MethodAccessorImpl\b', '<REFLECTION>'),

            # Java class names (preserve structure but replace specific names)
            # Keep exception type names intact
            (r'\b(?:java|javax|com|org)\.[\w.]+\.(\w+(?:Exception|Error))\b', r'<PKG>.\1'),
            (r'\b(?:java|javax|com|org)\.([\w.]{20,})\b', r'<PKG_LONG>'),

            # Database connection strings (preserve driver type)
            (r'jdbc:(mysql|postgresql|oracle|sqlserver)://[\w\.\-:]+/\w+\?[^\s]+', r'jdbc:\1://<DB_CONN>'),

            # Method signatures
            (r'\b[\w.]+#[\w<>]+\([^)]{0,50}\)', '<METHOD_SIG>'),

            # Version numbers (keep major version, abstract minor)
            (r'\b(\d+)\.\d+\.\d+(?:\.\d+)?\b', r'\1.<VERSION>'),
        ]
        
        # Preserve these tokens (case-insensitive matching for keywords)
        self.preserve_keywords = {
            # HTTP status codes
            r'\b(200|201|204|301|302|304|400|401|403|404|500|502|503|504)\b',
            # HTTP methods
            r'\b(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b',
            # Log levels
            r'\b(DEBUG|INFO|WARN|WARNING|ERROR|FATAL|TRACE)\b',
            # Exception keywords
            r'\b(\w*Exception|\w*Error)\b',
            # Common operations
            r'\b(SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|ALTER)\b',
        }


class LogPreprocessor:
    """Intelligent log preprocessor with multi-layer pattern matching"""
    
    def __init__(self, config: PreprocessorConfig = None):
        self.config = config or PreprocessorConfig()
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Compile all regex patterns for efficiency"""
        self.compiled_complex = [(re.compile(p, re.MULTILINE | re.DOTALL), r) for p, r in self.config.complex_patterns]
        self.compiled_kv = [(re.compile(p), r) for p, r in self.config.kv_patterns]
        self.compiled_dynamic = [(re.compile(p), r) for p, r in self.config.dynamic_patterns]
        self.compiled_domain = [(re.compile(p), r) for p, r in self.config.domain_patterns]
        self.compiled_preserve = [re.compile(p, re.IGNORECASE) for p in self.config.preserve_keywords]
    
    def preprocess(self, log_message: str) -> str:
        """
        Apply multi-layer preprocessing to normalize log message
        
        Args:
            log_message: Raw log message
            
        Returns:
            Normalized log message with dynamic parts replaced
        """
        msg = log_message
        
        # Layer 1: Complex structures (prevent fragmentation)
        for pattern, replacement in self.compiled_complex:
            msg = pattern.sub(replacement, msg)
        
        # Layer 2: Key-value pairs (preserve keys)
        for pattern, replacement in self.compiled_kv:
            msg = pattern.sub(replacement, msg)
        
        # Layer 3: Common dynamic fields
        for pattern, replacement in self.compiled_dynamic:
            msg = pattern.sub(replacement, msg)
        
        # Layer 4: Domain-specific patterns
        for pattern, replacement in self.compiled_domain:
            msg = pattern.sub(replacement, msg)
        
        return msg
    
    def preprocess_batch(self, log_messages: List[str]) -> List[str]:
        """Preprocess a batch of log messages"""
        return [self.preprocess(msg) for msg in log_messages]
    
    def analyze_message(self, log_message: str) -> Dict[str, any]:
        """
        Analyze a log message and return detailed token information
        
        Returns:
            Dictionary with original, preprocessed, and token analysis
        """
        preprocessed = self.preprocess(log_message)
        
        # Count dynamic tokens
        dynamic_tokens = len(re.findall(r'<[A-Z_]+>', preprocessed))
        
        # Calculate compression ratio
        orig_len = len(log_message)
        prep_len = len(preprocessed)
        compression_ratio = prep_len / orig_len if orig_len > 0 else 1.0
        
        return {
            'original': log_message,
            'preprocessed': preprocessed,
            'original_length': orig_len,
            'preprocessed_length': prep_len,
            'compression_ratio': compression_ratio,
            'dynamic_token_count': dynamic_tokens,
        }
