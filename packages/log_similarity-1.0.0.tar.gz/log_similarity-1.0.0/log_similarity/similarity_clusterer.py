"""
Similarity-Driven Log Clustering
递归的、基于相似度的日志聚类算法
"""
import json
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict

from .preprocessor import LogPreprocessor, PreprocessorConfig
from .logram import LogramParser


@dataclass
class ClusterNode:
    """聚类树节点"""
    cluster_id: str  # 全局唯一ID，如 "1", "1.1", "1.2.1"
    template: str = ""
    tokens: List[str] = field(default_factory=list)
    log_count: int = 0
    children: List['ClusterNode'] = field(default_factory=list)
    is_leaf: bool = True
    sample_logs: List[str] = field(default_factory=list)  # 保存样本日志
    
    def add_log(self, log: str):
        """添加日志到此cluster"""
        self.log_count += 1
        if len(self.sample_logs) < 10:  # 最多保存10个样本
            self.sample_logs.append(log)


class SimilarityClusterer:
    """
    基于相似度的日志聚类器
    
    核心思想：
    1. 新日志来了，从根节点开始递归查找最相似的cluster
    2. 如果相似度 > threshold，加入该cluster
    3. 否则创建新的cluster
    4. 支持层次结构，可以递归细分
    """
    
    def __init__(self, 
                 similarity_threshold: float = 0.90,
                 merge_threshold: float = 0.95,
                 length_tolerance: float = 0.3,
                 preprocessor_config: Optional[PreprocessorConfig] = None):
        """
        Args:
            similarity_threshold: 相似度阈值（低于此值创建新cluster）
            merge_threshold: 合并阈值（高于此值直接合并，不细分）
            length_tolerance: 长度容忍度（只比较长度相近的日志）
        """
        self.preprocessor = LogPreprocessor(preprocessor_config)
        self.logram = LogramParser()
        
        self.similarity_threshold = similarity_threshold
        self.merge_threshold = merge_threshold
        self.length_tolerance = length_tolerance
        
        # 根节点，包含所有clusters
        self.root = ClusterNode(cluster_id="root")
        self.next_cluster_id = 1
        
        # 辅助索引：length -> [cluster_nodes]，用于加速查找
        self.length_index: Dict[int, List[ClusterNode]] = defaultdict(list)
        
        # 统计
        self.total_logs = 0
        self.stats = {
            'new_clusters': 0,
            'merged_logs': 0,
        }
    
    def fit(self, log_messages: List[str], verbose: bool = True) -> 'SimilarityClusterer':
        """训练聚类器"""
        if verbose:
            print(f"Starting similarity-driven clustering on {len(log_messages)} logs...")
        
        for idx, log_msg in enumerate(log_messages):
            self._process_log(log_msg)
            
            if verbose and (idx + 1) % 1000 == 0:
                print(f"  Processed {idx + 1}/{len(log_messages)} logs, "
                      f"{self.get_cluster_count()} clusters")
        
        self.total_logs = len(log_messages)
        
        if verbose:
            print(f"\nClustering complete!")
            print(f"  Total logs: {self.total_logs}")
            print(f"  Unique clusters: {self.get_cluster_count()}")
            print(f"  New clusters: {self.stats['new_clusters']}")
            print(f"  Merged logs: {self.stats['merged_logs']}")
        
        return self
    
    def predict(self, log_message: str) -> Dict:
        """
        预测新日志的cluster

        Args:
            log_message: 单条日志消息

        Returns:
            包含cluster_id、template、similarity等信息的字典
            - match_type: 'matched' 表示匹配到cluster，'unmatched' 表示未匹配
        """
        # 预处理
        preprocessed = self.preprocessor.preprocess(log_message)
        template, tokens = self.logram.extract_template(preprocessed)

        # 查找最相似的cluster
        best_cluster, best_similarity = self._find_most_similar_cluster(template, tokens)

        if best_cluster and best_similarity >= self.similarity_threshold:
            return {
                'cluster_id': best_cluster.cluster_id,
                'template': best_cluster.template,
                'similarity': best_similarity,
                'match_type': 'matched',
                'preprocessed': preprocessed,
                'original': log_message,
            }
        else:
            return {
                'cluster_id': None,
                'template': template,
                'similarity': best_similarity if best_cluster else 0.0,
                'match_type': 'unmatched',
                'preprocessed': preprocessed,
                'original': log_message,
            }

    def predict_batch(self, log_messages: List[str], verbose: bool = False) -> List[Dict]:
        """
        批量预测日志的cluster

        Args:
            log_messages: 日志消息列表
            verbose: 是否显示进度

        Returns:
            预测结果列表，每个元素包含cluster_id、template、similarity等信息
        """
        results = []
        for idx, log_msg in enumerate(log_messages):
            result = self.predict(log_msg)
            results.append(result)

            if verbose and (idx + 1) % 1000 == 0:
                print(f"  Predicted {idx + 1}/{len(log_messages)} logs")

        return results

    def find_unmatched_logs(self, log_messages: List[str], verbose: bool = False) -> List[Dict]:
        """
        查找没有命中任何聚类的日志

        Args:
            log_messages: 待检查的日志消息列表
            verbose: 是否显示进度和统计信息

        Returns:
            未匹配的日志列表，每个元素包含：
            - original: 原始日志
            - preprocessed: 预处理后的日志
            - template: 提取的模板
            - similarity: 与最相似cluster的相似度
        """
        if verbose:
            print(f"Checking {len(log_messages)} logs against {self.get_cluster_count()} clusters...")

        unmatched_logs = []
        matched_count = 0

        for idx, log_msg in enumerate(log_messages):
            result = self.predict(log_msg)

            if result['match_type'] == 'unmatched':
                unmatched_logs.append({
                    'original': result['original'],
                    'preprocessed': result['preprocessed'],
                    'template': result['template'],
                    'similarity': result['similarity'],
                })
            else:
                matched_count += 1

            if verbose and (idx + 1) % 1000 == 0:
                print(f"  Processed {idx + 1}/{len(log_messages)} logs, "
                      f"unmatched: {len(unmatched_logs)}")

        if verbose:
            print(f"\nResults:")
            print(f"  Total logs: {len(log_messages)}")
            print(f"  Matched: {matched_count} ({matched_count/len(log_messages)*100:.1f}%)")
            print(f"  Unmatched: {len(unmatched_logs)} ({len(unmatched_logs)/len(log_messages)*100:.1f}%)")

        return unmatched_logs
    
    def _process_log(self, log_message: str):
        """处理单条日志"""
        # 预处理
        preprocessed = self.preprocessor.preprocess(log_message)
        template, tokens = self.logram.extract_template(preprocessed)
        length = len(tokens)
        
        # 查找最相似的cluster
        best_cluster, best_similarity = self._find_most_similar_cluster(template, tokens)
        
        if best_cluster and best_similarity >= self.similarity_threshold:
            # 相似度够高，加入现有cluster
            best_cluster.add_log(log_message)
            self.stats['merged_logs'] += 1
        else:
            # 创建新cluster
            new_cluster = ClusterNode(
                cluster_id=str(self.next_cluster_id),
                template=template,
                tokens=tokens,
            )
            new_cluster.add_log(log_message)
            
            self.root.children.append(new_cluster)
            self.root.is_leaf = False
            
            # 加入length索引
            self.length_index[length].append(new_cluster)
            
            self.next_cluster_id += 1
            self.stats['new_clusters'] += 1
    
    def _find_most_similar_cluster(self, template: str, tokens: List[str]) -> Tuple[Optional[ClusterNode], float]:
        """
        查找最相似的cluster
        
        Returns:
            (best_cluster, best_similarity)
        """
        target_length = len(tokens)
        best_cluster = None
        best_similarity = 0.0
        
        # 只在长度相近的clusters中查找（性能优化）
        min_length = int(target_length * (1 - self.length_tolerance))
        max_length = int(target_length * (1 + self.length_tolerance))
        
        candidate_clusters = []
        for length in range(min_length, max_length + 1):
            candidate_clusters.extend(self.length_index.get(length, []))
        
        # 如果没有候选cluster，返回None
        if not candidate_clusters:
            return None, 0.0
        
        # 计算相似度，找最相似的
        for cluster in candidate_clusters:
            sim = self._calculate_similarity(template, tokens, cluster.template, cluster.tokens)
            if sim > best_similarity:
                best_similarity = sim
                best_cluster = cluster
        
        return best_cluster, best_similarity
    
    def _calculate_similarity(self, template1: str, tokens1: List[str], 
                             template2: str, tokens2: List[str]) -> float:
        """
        计算两个模板的相似度
        
        策略：
        1. 长度差异惩罚
        2. Token Jaccard相似度
        3. 前N个token精确匹配奖励
        """
        # 长度差异惩罚
        len1, len2 = len(tokens1), len(tokens2)
        if len1 == 0 or len2 == 0:
            return 0.0
        
        length_ratio = min(len1, len2) / max(len1, len2)
        if length_ratio < 0.7:  # 长度差异太大
            return 0.0
        
        # Token Jaccard相似度
        set1 = set(tokens1)
        set2 = set(tokens2)
        
        # 过滤掉占位符（它们不提供区分信息）
        set1_filtered = {t for t in set1 if not t.startswith('<')}
        set2_filtered = {t for t in set2 if not t.startswith('<')}
        
        if not set1_filtered and not set2_filtered:
            # 都只有占位符，看原始token
            intersection = len(set1 & set2)
            union = len(set1 | set2)
        else:
            intersection = len(set1_filtered & set2_filtered)
            union = len(set1_filtered | set2_filtered)
        
        jaccard = intersection / union if union > 0 else 0.0
        
        # 前N个token精确匹配奖励（开头很重要）
        prefix_length = min(5, len1, len2)
        prefix_match = sum(1 for i in range(prefix_length) if tokens1[i] == tokens2[i])
        prefix_score = prefix_match / prefix_length if prefix_length > 0 else 0.0
        
        # 加权组合
        similarity = (
            jaccard * 0.5 +         # Jaccard权重50%
            prefix_score * 0.4 +    # 前缀匹配权重40%
            length_ratio * 0.1      # 长度相似度权重10%
        )
        
        return similarity
    
    def get_cluster_count(self) -> int:
        """获取cluster总数"""
        return len(self.root.children)
    
    def get_all_clusters(self) -> List[Dict]:
        """获取所有clusters"""
        all_clusters = []
        
        for cluster in self.root.children:
            all_clusters.append({
                'cluster_id': cluster.cluster_id,
                'template': cluster.template,
                'count': cluster.log_count,
                'sample_logs': cluster.sample_logs,
                'tokens': cluster.tokens,
            })
        
        # 按count排序
        all_clusters.sort(key=lambda x: x['count'], reverse=True)
        return all_clusters
    
    def print_summary(self):
        """打印摘要"""
        print("\n" + "="*60)
        print("Similarity-Driven Clustering Summary")
        print("="*60)
        print(f"Total logs processed: {self.total_logs}")
        print(f"Unique clusters: {self.get_cluster_count()}")
        print(f"New clusters created: {self.stats['new_clusters']}")
        print(f"Logs merged into existing: {self.stats['merged_logs']}")
        print(f"Similarity threshold: {self.similarity_threshold}")
        
        print("\nTop 10 Clusters by Frequency:")
        print("-" * 60)
        clusters = self.get_all_clusters()[:10]
        for i, cluster in enumerate(clusters, 1):
            print(f"\n[{i}] Cluster ID: {cluster['cluster_id']} | Count: {cluster['count']}")
            print(f"    Template: {cluster['template'][:100]}...")
    
    def save(self, filepath: str):
        """保存状态"""
        state = {
            'total_logs': self.total_logs,
            'stats': self.stats,
            'clusters': self.get_all_clusters(),
            'config': {
                'similarity_threshold': self.similarity_threshold,
                'merge_threshold': self.merge_threshold,
                'length_tolerance': self.length_tolerance,
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(state, f, indent=2, ensure_ascii=False)
        
        print(f"Saved clusterer state to {filepath}")
