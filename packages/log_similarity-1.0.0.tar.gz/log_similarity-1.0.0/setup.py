from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="log-similarity",
    version="1.0.0",
    author="Log Similarity Team",
    author_email="suiwenfeng@qq.com",
    description="Similarity-driven log clustering for error log analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/suiwenfeng/log-similarity-sdk",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Logging",
        "Topic :: System :: Monitoring",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        # Pure Python, no external dependencies
    ],
    keywords=[
        "log",
        "logging",
        "clustering",
        "similarity",
        "error-detection",
        "log-analysis",
        "anomaly-detection",
        "log-parsing",
    ],
    project_urls={
        "Bug Reports": "https://github.com/suiwenfeng/log-similarity-sdk/issues",
        "Source": "https://github.com/suiwenfeng/log-similarity-sdk",
        "Documentation": "https://github.com/suiwenfeng/log-similarity-sdk#readme",
    },
)
