"""
Quick test script to verify SDK functionality
Run this after installation: python test_sdk.py
"""

import sys


def test_import():
    """Test if package can be imported"""
    print("Testing import...")
    try:
        from log_similarity import SimilarityClusterer
        print("✓ Import successful")
        return True
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False


def test_basic_clustering():
    """Test basic clustering functionality"""
    print("\nTesting basic clustering...")
    try:
        from log_similarity import SimilarityClusterer

        logs = [
            "Error: Connection timeout",
            "Error: Connection failed",
            "Warning: Slow query",
        ]

        clusterer = SimilarityClusterer(similarity_threshold=0.85)
        clusterer.fit(logs, verbose=False)

        cluster_count = clusterer.get_cluster_count()
        print(f"✓ Created {cluster_count} clusters")
        return True
    except Exception as e:
        print(f"✗ Clustering failed: {e}")
        return False


def test_unmatched_detection():
    """Test unmatched log detection"""
    print("\nTesting unmatched log detection...")
    try:
        from log_similarity import SimilarityClusterer

        base_logs = ["Error: Connection timeout", "Error: Connection failed"]
        new_logs = ["Error: Out of memory", "Error: Connection timeout"]

        clusterer = SimilarityClusterer(similarity_threshold=0.85)
        clusterer.fit(base_logs, verbose=False)

        unmatched = clusterer.find_unmatched_logs(new_logs, verbose=False)
        print(f"✓ Found {len(unmatched)} unmatched log(s)")
        return True
    except Exception as e:
        print(f"✗ Unmatched detection failed: {e}")
        return False


def test_predict():
    """Test predict functionality"""
    print("\nTesting predict...")
    try:
        from log_similarity import SimilarityClusterer

        logs = ["Error: Connection timeout"]
        clusterer = SimilarityClusterer(similarity_threshold=0.85)
        clusterer.fit(logs, verbose=False)

        result = clusterer.predict("Error: Connection timeout")
        assert result['match_type'] in ['matched', 'unmatched']
        print(f"✓ Predict works (match_type: {result['match_type']})")
        return True
    except Exception as e:
        print(f"✗ Predict failed: {e}")
        return False


def main():
    print("="*60)
    print("Log Similarity SDK - Test Suite")
    print("="*60)

    tests = [
        test_import,
        test_basic_clustering,
        test_unmatched_detection,
        test_predict,
    ]

    passed = 0
    failed = 0

    for test in tests:
        if test():
            passed += 1
        else:
            failed += 1

    print("\n" + "="*60)
    print(f"Tests: {passed} passed, {failed} failed")
    print("="*60)

    if failed > 0:
        sys.exit(1)
    else:
        print("\n✓ All tests passed! SDK is working correctly.")
        sys.exit(0)


if __name__ == "__main__":
    main()
