
이 패키지는 loguru 기반 공통 로깅 패키지다.
모노레포에서 모든 프로젝트가 같은 로깅을 쓰기 위해 만든 것이다.

⸻

1. 앱 시작점에서 한 번만 설정한다

from logging_hj3415 import setup_logging

setup_logging()

파일로 로그를 남기고 싶으면:

setup_logging(log_file="logs/app.log")


⸻

2. 어디서든 logger를 바로 사용한다

from logging_hj3415 import logger

logger.info("작업 시작")
logger.warning("값 이상: {}", 123)
logger.error("에러 발생")
logger.exception("예외 발생")

* 현재로그레벨 확인
from logging_hj3415 import current_log_level
print(current_log_level())  # "INFO"
* 코드상에서 로그레벨 재설정
from logging_hj3415 import reset_logging
reset_logging("DEBUG")

⸻

3. 환경변수로 로그 설정을 바꿀 수 있다

LOG_LEVEL=DEBUG
LOG_FILE=logs/app.log


⸻

4. 중요한 규칙
	•	setup_logging()은 여러 번 호출해도 한 번만 적용된다.
	•	각 프로젝트에서 따로 loguru 설정을 하지 않는다.
	•	로깅 설정은 이 패키지 하나만 사용한다.

⸻

5. 이 패키지는 단순함을 유지한다
	•	JSON 로그 안 씀
	•	trace id 자동 삽입 안 함
	•	로그 회전 기본 제공 안 함
	•	복잡한 설정 파일 안 씀

⸻

6. 사용 패턴 요약

# 엔트리포인트
setup_logging()

# 모든 모듈
logger.info(...)


⸻

한 문장으로 요약하면:

setup_logging() 한 번, logger는 어디서든.

⸻

이 정도만 README에 써도
사용법 전달에는 충분히 명확하고 깔끔해.