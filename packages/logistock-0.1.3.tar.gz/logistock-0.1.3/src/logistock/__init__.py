from .configuration import Configuration
from .gestionnaire import GestionnairePile
from .moteur_mcts import MCTS_Optimiseur
from .api import optimalSorting
__version__ = "1.0.0"