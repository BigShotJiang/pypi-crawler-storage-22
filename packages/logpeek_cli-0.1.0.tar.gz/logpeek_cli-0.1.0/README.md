# logpeek

View, tail, filter, search, and analyze log files from the command line. Think `tail -f` meets `grep` with stats and JSON output.

## Install

```bash
pip install logpeek-cli
```

## Commands

```bash
logpeek view app.log                    # View with syntax highlighting
logpeek view app.log -n 50              # Last 50 lines
logpeek tail app.log                    # Live tail (like tail -f)
logpeek filter app.log --level error    # Filter by log level
logpeek filter app.log -l warning -v    # Exclude warnings
logpeek search app.log "pattern"        # Regex search
logpeek search app.log "error" -C 3     # With 3 lines context
logpeek search app.log "fail" -c        # Count matches
logpeek stats app.log                   # Log level distribution
logpeek between app.log --from "2026-02-08" --to "2026-02-09"
logpeek extract app.log --field ip      # Extract IP addresses
logpeek extract app.log -f url -u       # Unique URLs
logpeek top app.log --field ip -n 10    # Top 10 IPs
```

## Features

- **Auto-detect log formats**: syslog, nginx, Apache, JSON lines, generic timestamped
- **Log level detection**: ERROR, WARNING, INFO, DEBUG with colorized output
- **Regex search**: with context lines (`-A`, `-B`, `-C`) like grep
- **Time range filtering**: parse timestamps from any common format
- **Statistics**: level distribution, lines per hour, error rate
- **Field extraction**: IPs, URLs, emails, HTTP status codes
- **Top N analysis**: most frequent values for any extractable field
- **JSON output**: `--json` flag on every command
- **Stdin support**: pipe logs from other commands
- **No heavy deps**: just Python + Click

## Stdin / Pipelines

```bash
cat /var/log/syslog | logpeek filter --level error
kubectl logs pod-name | logpeek stats
docker logs container | logpeek search "timeout" -C 2
journalctl -u nginx | logpeek top --field ip -n 20
```

## JSON Output

Every command supports `--json` for machine-readable output:

```bash
logpeek stats app.log --json
logpeek top app.log -f status --json
logpeek search app.log "error" --json
```

## For AI Agents

See [SKILL.md](SKILL.md) for structured command reference and usage patterns.

## License

MIT
