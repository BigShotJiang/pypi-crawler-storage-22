"""logpeek - Log file viewer and analyzer CLI."""
__version__ = "0.1.0"
