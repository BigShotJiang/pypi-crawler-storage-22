"""logpeek CLI - Log file viewer and analyzer."""
import json
import re
import sys
import time
from collections import Counter
from datetime import datetime

import click

from .parser import detect_level, parse_timestamp, extract_fields, detect_format, FIELD_PATTERNS

# Colors for log levels
LEVEL_COLORS = {
    'ERROR': 'red',
    'WARNING': 'yellow',
    'INFO': 'green',
    'DEBUG': 'cyan',
}


def colorize_line(line, level=None):
    """Colorize a log line based on its level."""
    if level is None:
        level = detect_level(line)
    if level and level in LEVEL_COLORS:
        return click.style(line, fg=LEVEL_COLORS[level])
    return line


def read_lines(file, follow=False):
    """Read lines from file or stdin. If follow, tail -f style."""
    if file == '-' or file is None:
        if follow:
            raise click.ClickException("Cannot tail stdin. Provide a file path.")
        for line in sys.stdin:
            yield line.rstrip('\n')
        return

    if follow:
        with open(file, 'r') as f:
            # Seek to end
            f.seek(0, 2)
            while True:
                line = f.readline()
                if line:
                    yield line.rstrip('\n')
                else:
                    time.sleep(0.1)
    else:
        with open(file, 'r') as f:
            for line in f:
                yield line.rstrip('\n')


@click.group()
@click.version_option()
def main():
    """View, tail, filter, search, and analyze log files."""
    pass


@main.command()
@click.argument('file', default='-')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
@click.option('-n', '--lines', default=0, help='Last N lines (0=all)')
@click.option('--no-color', is_flag=True, help='Disable colorization')
def view(file, as_json, lines, no_color):
    """View log file with syntax highlighting."""
    try:
        all_lines = list(read_lines(file))
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    if lines > 0:
        all_lines = all_lines[-lines:]

    if as_json:
        result = []
        for line in all_lines:
            level = detect_level(line)
            ts = parse_timestamp(line)
            result.append({
                'line': line,
                'level': level,
                'timestamp': ts.isoformat() if ts else None,
            })
        click.echo(json.dumps(result, indent=2))
    else:
        for line in all_lines:
            if no_color:
                click.echo(line)
            else:
                click.echo(colorize_line(line))


@main.command()
@click.argument('file')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON lines')
@click.option('--no-color', is_flag=True, help='Disable colorization')
def tail(file, as_json, no_color):
    """Live tail a log file (like tail -f)."""
    try:
        for line in read_lines(file, follow=True):
            if as_json:
                level = detect_level(line)
                ts = parse_timestamp(line)
                click.echo(json.dumps({
                    'line': line,
                    'level': level,
                    'timestamp': ts.isoformat() if ts else None,
                }))
            elif no_color:
                click.echo(line)
            else:
                click.echo(colorize_line(line))
    except KeyboardInterrupt:
        pass


@main.command()
@click.argument('file', default='-')
@click.option('--level', '-l', help='Filter by log level (error, warning, info, debug)')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
@click.option('--no-color', is_flag=True, help='Disable colorization')
@click.option('--invert', '-v', is_flag=True, help='Invert match (exclude level)')
def filter(file, level, as_json, no_color, invert):
    """Filter log lines by level."""
    if not level:
        raise click.ClickException("--level is required")

    target = level.upper()
    # Normalize
    if target in ('ERR',):
        target = 'ERROR'
    if target in ('WARN',):
        target = 'WARNING'

    results = []
    try:
        for line in read_lines(file):
            detected = detect_level(line)
            match = (detected == target)
            if invert:
                match = not match
            if match:
                if as_json:
                    ts = parse_timestamp(line)
                    results.append({
                        'line': line,
                        'level': detected,
                        'timestamp': ts.isoformat() if ts else None,
                    })
                elif no_color:
                    click.echo(line)
                else:
                    click.echo(colorize_line(line, detected))
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    if as_json:
        click.echo(json.dumps(results, indent=2))


@main.command()
@click.argument('file', default='-')
@click.argument('pattern')
@click.option('-A', '--after', 'after_ctx', default=0, help='Lines after match')
@click.option('-B', '--before', 'before_ctx', default=0, help='Lines before match')
@click.option('-C', '--context', default=0, help='Lines before and after match')
@click.option('-i', '--ignore-case', is_flag=True, help='Case insensitive')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
@click.option('--no-color', is_flag=True, help='Disable colorization')
@click.option('-c', '--count', is_flag=True, help='Only show match count')
def search(file, pattern, after_ctx, before_ctx, context, ignore_case, as_json, no_color, count):
    """Search log lines with regex pattern."""
    if context > 0:
        after_ctx = context
        before_ctx = context

    flags = re.IGNORECASE if ignore_case else 0
    try:
        regex = re.compile(pattern, flags)
    except re.error as e:
        raise click.ClickException(f"Invalid regex: {e}")

    try:
        all_lines = list(read_lines(file))
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    matches = []
    match_indices = set()
    for i, line in enumerate(all_lines):
        if regex.search(line):
            match_indices.add(i)
            for j in range(max(0, i - before_ctx), min(len(all_lines), i + after_ctx + 1)):
                match_indices.add(j)
            matches.append({'index': i, 'line': line, 'level': detect_level(line)})

    if count:
        if as_json:
            click.echo(json.dumps({'count': len(matches)}))
        else:
            click.echo(len(matches))
        return

    if as_json:
        click.echo(json.dumps(matches, indent=2))
    else:
        sorted_indices = sorted(match_indices)
        prev = -2
        for i in sorted_indices:
            if i > prev + 1 and prev >= 0:
                click.echo('--')
            line = all_lines[i]
            if no_color:
                click.echo(line)
            elif i in {m['index'] for m in matches}:
                # Highlight the match
                highlighted = regex.sub(lambda m: click.style(m.group(), fg='bright_white', bold=True), line)
                click.echo(colorize_line(highlighted, detect_level(line)) if detect_level(line) else highlighted)
            else:
                click.echo(click.style(line, dim=True))
            prev = i


@main.command()
@click.argument('file', default='-')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
def stats(file, as_json):
    """Show log level distribution and statistics."""
    level_counts = Counter()
    total = 0
    hourly = Counter()
    first_ts = None
    last_ts = None

    try:
        for line in read_lines(file):
            total += 1
            level = detect_level(line)
            if level:
                level_counts[level] += 1
            ts = parse_timestamp(line)
            if ts:
                if first_ts is None:
                    first_ts = ts
                last_ts = ts
                hourly[ts.strftime('%Y-%m-%d %H:00')] += 1
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    error_count = level_counts.get('ERROR', 0)
    error_rate = (error_count / total * 100) if total > 0 else 0

    result = {
        'total_lines': total,
        'levels': dict(level_counts.most_common()),
        'error_rate': round(error_rate, 2),
        'first_timestamp': first_ts.isoformat() if first_ts else None,
        'last_timestamp': last_ts.isoformat() if last_ts else None,
        'lines_per_hour': dict(sorted(hourly.items())),
    }

    if as_json:
        click.echo(json.dumps(result, indent=2))
    else:
        click.echo(f"Total lines: {total}")
        click.echo(f"Error rate:  {error_rate:.1f}%")
        click.echo()
        if first_ts:
            click.echo(f"Time range:  {first_ts} → {last_ts}")
            click.echo()
        click.echo("Level distribution:")
        for level in ['ERROR', 'WARNING', 'INFO', 'DEBUG']:
            count = level_counts.get(level, 0)
            if count > 0:
                pct = count / total * 100
                bar = '█' * int(pct / 2)
                color = LEVEL_COLORS.get(level, 'white')
                click.echo(f"  {click.style(level.ljust(8), fg=color)} {count:>6} ({pct:5.1f}%) {bar}")
        unlabeled = total - sum(level_counts.values())
        if unlabeled > 0:
            pct = unlabeled / total * 100
            click.echo(f"  {'OTHER'.ljust(8)} {unlabeled:>6} ({pct:5.1f}%)")

        if hourly:
            click.echo()
            click.echo("Lines per hour (top 10):")
            for hour, cnt in Counter(hourly).most_common(10):
                click.echo(f"  {hour}  {cnt}")


@main.command()
@click.argument('file', default='-')
@click.option('--from', 'from_time', required=True, help='Start time (ISO or date)')
@click.option('--to', 'to_time', required=True, help='End time (ISO or date)')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
@click.option('--no-color', is_flag=True, help='Disable colorization')
def between(file, from_time, to_time, as_json, no_color):
    """Filter log lines within a time range."""
    try:
        start = _parse_user_time(from_time)
        end = _parse_user_time(to_time, end_of_day=True)
    except ValueError as e:
        raise click.ClickException(f"Cannot parse time: {e}")

    results = []
    try:
        for line in read_lines(file):
            ts = parse_timestamp(line)
            if ts and start <= ts <= end:
                if as_json:
                    results.append({
                        'line': line,
                        'level': detect_level(line),
                        'timestamp': ts.isoformat(),
                    })
                elif no_color:
                    click.echo(line)
                else:
                    click.echo(colorize_line(line))
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    if as_json:
        click.echo(json.dumps(results, indent=2))


def _parse_user_time(s, end_of_day=False):
    """Parse user-provided time string."""
    for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            dt = datetime.strptime(s, fmt)
            if end_of_day and fmt == '%Y-%m-%d':
                dt = dt.replace(hour=23, minute=59, second=59)
            return dt
        except ValueError:
            continue
    raise ValueError(f"Unrecognized time format: {s}")


@main.command()
@click.argument('file', default='-')
@click.option('--field', '-f', required=True, type=click.Choice(['ip', 'url', 'email', 'status']),
              help='Field type to extract')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
@click.option('--unique', '-u', is_flag=True, help='Only unique values')
def extract(file, field, as_json, unique):
    """Extract fields (IPs, URLs, emails, HTTP status codes) from logs."""
    values = []
    seen = set()
    try:
        for line in read_lines(file):
            for val in extract_fields(line, field):
                if unique:
                    if val in seen:
                        continue
                    seen.add(val)
                values.append(val)
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    if as_json:
        click.echo(json.dumps({'field': field, 'count': len(values), 'values': values}, indent=2))
    else:
        for v in values:
            click.echo(v)


@main.command()
@click.argument('file', default='-')
@click.option('--field', '-f', required=True, type=click.Choice(['ip', 'url', 'email', 'status']),
              help='Field type to count')
@click.option('-n', '--number', default=10, help='Top N results')
@click.option('--json', 'as_json', is_flag=True, help='Output as JSON')
def top(file, field, number, as_json):
    """Show top N values for a field."""
    counter = Counter()
    try:
        for line in read_lines(file):
            for val in extract_fields(line, field):
                counter[val] += 1
    except FileNotFoundError:
        raise click.ClickException(f"File not found: {file}")

    top_items = counter.most_common(number)

    if as_json:
        click.echo(json.dumps({
            'field': field,
            'top': [{'value': v, 'count': c} for v, c in top_items],
            'unique_count': len(counter),
        }, indent=2))
    else:
        if not top_items:
            click.echo(f"No {field} values found.")
            return
        max_count = top_items[0][1] if top_items else 1
        for val, cnt in top_items:
            bar = '█' * max(1, int(cnt / max_count * 20))
            click.echo(f"  {cnt:>6}  {val}  {bar}")
        click.echo(f"\n  {len(counter)} unique values")


if __name__ == '__main__':
    main()
