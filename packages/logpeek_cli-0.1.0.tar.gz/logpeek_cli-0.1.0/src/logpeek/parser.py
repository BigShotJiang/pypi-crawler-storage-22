"""Log line parsing and format detection."""
import json
import re
from datetime import datetime

# Log level patterns
LEVEL_PATTERNS = [
    re.compile(r'\b(EMERGENCY|EMERG)\b', re.I),
    re.compile(r'\b(ALERT)\b', re.I),
    re.compile(r'\b(CRITICAL|CRIT|FATAL)\b', re.I),
    re.compile(r'\b(ERROR|ERR)\b', re.I),
    re.compile(r'\b(WARNING|WARN)\b', re.I),
    re.compile(r'\b(NOTICE)\b', re.I),
    re.compile(r'\b(INFO)\b', re.I),
    re.compile(r'\b(DEBUG|TRACE)\b', re.I),
]

LEVEL_NAMES = {
    'EMERGENCY': 'error', 'EMERG': 'error',
    'ALERT': 'error',
    'CRITICAL': 'error', 'CRIT': 'error', 'FATAL': 'error',
    'ERROR': 'error', 'ERR': 'error',
    'WARNING': 'warning', 'WARN': 'warning',
    'NOTICE': 'info',
    'INFO': 'info',
    'DEBUG': 'debug', 'TRACE': 'debug',
}

LEVEL_CANONICAL = {
    'EMERGENCY': 'ERROR', 'EMERG': 'ERROR',
    'ALERT': 'ERROR',
    'CRITICAL': 'ERROR', 'CRIT': 'ERROR', 'FATAL': 'ERROR',
    'ERROR': 'ERROR', 'ERR': 'ERROR',
    'WARNING': 'WARNING', 'WARN': 'WARNING',
    'NOTICE': 'INFO',
    'INFO': 'INFO',
    'DEBUG': 'DEBUG', 'TRACE': 'DEBUG',
}

# Timestamp patterns (order matters - try most specific first)
TIMESTAMP_PATTERNS = [
    # ISO 8601: 2026-02-08T12:34:56.789Z or with offset
    (re.compile(r'(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)'), '%Y-%m-%dT%H:%M:%S'),
    # Common: 2026-02-08 12:34:56
    (re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'), '%Y-%m-%d %H:%M:%S'),
    # Common: 2026/02/08 12:34:56
    (re.compile(r'(\d{4}/\d{2}/\d{2} \d{2}:\d{2}:\d{2})'), '%Y/%m/%d %H:%M:%S'),
    # Syslog: Feb  8 12:34:56
    (re.compile(r'([A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2})'), '%b %d %H:%M:%S'),
    # Apache/nginx: 08/Feb/2026:12:34:56
    (re.compile(r'(\d{2}/[A-Z][a-z]{2}/\d{4}:\d{2}:\d{2}:\d{2})'), '%d/%b/%Y:%H:%M:%S'),
    # Date only: 2026-02-08
    (re.compile(r'(\d{4}-\d{2}-\d{2})'), '%Y-%m-%d'),
]

# Field extraction patterns
FIELD_PATTERNS = {
    'ip': re.compile(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b'),
    'url': re.compile(r'(https?://[^\s"\'<>]+)'),
    'email': re.compile(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'),
    'status': re.compile(r'\b([1-5]\d{2})\b'),
}


def detect_level(line):
    """Detect log level from a line. Returns canonical level or None."""
    for pat in LEVEL_PATTERNS:
        m = pat.search(line)
        if m:
            return LEVEL_CANONICAL.get(m.group(1).upper(), 'INFO')
    return None


def parse_timestamp(line):
    """Try to extract a datetime from a log line. Returns datetime or None."""
    # Try JSON first
    try:
        obj = json.loads(line)
        for key in ('timestamp', 'time', 'ts', '@timestamp', 'date', 'datetime'):
            if key in obj:
                val = obj[key]
                if isinstance(val, (int, float)):
                    return datetime.fromtimestamp(val)
                for pat, fmt in TIMESTAMP_PATTERNS:
                    m = pat.search(str(val))
                    if m:
                        return _parse_ts(m.group(1), fmt)
    except (json.JSONDecodeError, ValueError, TypeError):
        pass

    for pat, fmt in TIMESTAMP_PATTERNS:
        m = pat.search(line)
        if m:
            return _parse_ts(m.group(1), fmt)
    return None


def _parse_ts(s, fmt):
    """Parse a timestamp string, handling timezone suffixes."""
    # Strip Z or timezone offset for simple parsing
    clean = s.rstrip('Z')
    # Remove colon in timezone offset
    if re.search(r'[+-]\d{2}:\d{2}$', clean):
        clean = clean[:-3] + clean[-2:]
    # Remove timezone offset entirely for strptime
    clean = re.sub(r'[+-]\d{4}$', '', clean)
    # Remove fractional seconds
    clean = re.sub(r'\.\d+', '', clean)
    # Normalize T separator
    clean = clean.replace('T', ' ')
    # Pick appropriate format
    if ' ' in clean and ':' in clean:
        parts = clean.split()
        if '/' in parts[0] and ':' in parts[0]:
            fmt = '%d/%b/%Y:%H:%M:%S'
        elif '-' in parts[0]:
            fmt = '%Y-%m-%d %H:%M:%S'
        elif '/' in parts[0]:
            fmt = '%Y/%m/%d %H:%M:%S'
        elif parts[0][0].isalpha():
            fmt = '%b %d %H:%M:%S'
        else:
            fmt = '%Y-%m-%d %H:%M:%S'
    try:
        return datetime.strptime(clean, fmt)
    except ValueError:
        return None


def extract_fields(line, field):
    """Extract field values from a line."""
    pat = FIELD_PATTERNS.get(field)
    if not pat:
        return []
    return pat.findall(line)


def detect_format(lines):
    """Detect log format from sample lines. Returns format name."""
    json_count = 0
    syslog_count = 0
    nginx_count = 0
    apache_count = 0

    for line in lines[:50]:
        line = line.strip()
        if not line:
            continue
        try:
            json.loads(line)
            json_count += 1
            continue
        except (json.JSONDecodeError, ValueError):
            pass
        if re.match(r'[A-Z][a-z]{2}\s+\d{1,2} \d{2}:\d{2}:\d{2} \S+', line):
            syslog_count += 1
        elif re.match(r'\d+\.\d+\.\d+\.\d+ - .+ \[\d{2}/[A-Z][a-z]{2}/\d{4}', line):
            nginx_count += 1
        elif re.match(r'\d+\.\d+\.\d+\.\d+ .+ \[\d{2}/[A-Z][a-z]{2}/\d{4}', line):
            apache_count += 1

    total = max(len(lines[:50]), 1)
    if json_count > total * 0.5:
        return 'jsonl'
    if nginx_count > total * 0.3:
        return 'nginx'
    if apache_count > total * 0.3:
        return 'apache'
    if syslog_count > total * 0.3:
        return 'syslog'
    return 'generic'
