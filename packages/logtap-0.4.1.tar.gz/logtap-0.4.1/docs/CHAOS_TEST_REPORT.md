# Logtap Chaos Testing Report

**Date:** 2026-02-02
**Tester:** Automated chaos testing suite
**Version:** 0.2.2

## Executive Summary

Chaos testing revealed **4 categories of issues**. Three have been **FIXED** in this commit:

| Severity | Count | Status | Category |
|----------|-------|--------|----------|
| **HIGH** | 1 | **FIXED** | ReDoS vulnerability - now using google-re2 |
| **HIGH** | 1 | **FIXED** | Non-UTF-8 file crash |
| **MEDIUM** | 2 | **FIXED** | Crash bugs in JSON parser |
| **LOW** | 1 | N/A | Minor edge case (acceptable behavior) |

**All critical issues have been resolved.**

---

## Fixes Applied

The following issues were **fixed**:

### Fix 1: ReDoS Vulnerability
- **File changed:** `src/logtap/core/search.py`
- **Fix:** Replaced Python `re` with `google-re2` for all regex operations
- **Result:** Regex matching is now immune to catastrophic backtracking

### Fix 2: Non-UTF-8 File Handling
- **Files changed:** `src/logtap/core/reader.py`, `src/logtap/api/routes/logs.py`
- **Fix:** Added `errors="replace"` to all file open operations
- **Result:** Non-UTF-8 files now return content with replacement characters instead of crashing

### Fix 3: JSON Parser Non-Object Handling
- **File changed:** `src/logtap/core/parsers/json_parser.py`
- **Fix:** Added type check for dict before accessing fields
- **Result:** JSON arrays, primitives, and null are now handled gracefully

### Fix 4: Level Detection Type Safety
- **File changed:** `src/logtap/core/parsers/base.py`
- **Fix:** Added type check in `_detect_level_from_content()` for string type
- **Result:** Non-string message fields no longer crash the parser

---

## HIGH Severity Issues

### 1. ReDoS (Regular Expression Denial of Service) Vulnerability - **FIXED**

**Location:** `src/logtap/core/search.py`

**Description:** The regex search feature was vulnerable to catastrophic backtracking with malicious patterns.

**Status:** **FIXED** - Replaced Python's `re` module with `google-re2`, which uses a finite automaton approach that guarantees linear time complexity. This makes the regex engine completely immune to ReDoS attacks.

**Solution implemented:**
```python
import re2  # google-re2 instead of re

def filter_lines(...):
    if regex:
        options = re2.Options()
        options.case_sensitive = case_sensitive
        pattern = re2.compile(regex, options)
        return [line for line in lines if pattern.search(line)]
```

Evil patterns like `(a+)+$` now complete in milliseconds instead of hanging.

---

### 2. Non-UTF-8 File Encoding Crashes Server - **FIXED**

**Location:** `src/logtap/core/reader.py:90, 102`

**Description:** When reading log files with non-UTF-8 encoding (Latin-1, Windows-1252, etc.), the server crashed with `UnicodeDecodeError`.

**Status:** **FIXED** - Added `errors="replace"` to all file reading operations. Non-UTF-8 bytes are now replaced with the Unicode replacement character (`\ufffd`) instead of crashing.

---

## MEDIUM Severity Issues

### 3. JSON Parser Crashes on Non-Object JSON - **FIXED**

**Location:** `src/logtap/core/parsers/json_parser.py`

**Description:** The JSON parser assumed all valid JSON is a dictionary/object. When given arrays, primitives, or null, it crashed.

**Status:** **FIXED** - Added type check for dict before field extraction. Non-object JSON now returns a basic ParsedLogEntry with the raw line as the message.

---

### 4. JSON Parser Crashes on Nested Message Objects - **FIXED**

**Location:** `src/logtap/core/parsers/base.py:139`

**Description:** When a JSON log had a nested object as the message field, level detection crashed.

**Status:** **FIXED** - Added type check in `_detect_level_from_content()` to handle non-string content gracefully.

---

## LOW Severity Issues

### 5. URL-Encoded Path Traversal Returns 404 Instead of 400

**Location:** `src/logtap/core/validation.py:22`

**Description:** While URL-encoded path traversal attempts like `%2e%2e%2fetc%2fpasswd` are correctly NOT exploitable (the file isn't accessed), they return a 404 status code instead of 400 Bad Request.

**Current behavior:**
- Request: `/logs?filename=%2e%2e%2fetc%2fpasswd`
- Response: 404 Not Found (after attempting to access the decoded path)

**Expected behavior:**
- Response: 400 Bad Request (path traversal detected and rejected)

**Impact:** Minor - the security is not compromised, but the response code is misleading. It also means the validation is running after URL decoding happens at the framework level, not at the raw input level.

**Note:** FastAPI/Starlette automatically URL-decode query parameters, so `%2e%2e` becomes `..` before reaching validation. The current validation DOES catch this, but returns 404 because the file path resolution fails first.

---

## Test Coverage Summary

### Tests Passed
- All authentication bypass attempts blocked ✅
- All input injection attacks handled safely ✅
- All path traversal with raw `..` blocked ✅
- All syslog parser edge cases handled ✅
- All nginx parser edge cases handled ✅
- Concurrent request handling ✅
- Large file handling (10MB+) ✅
- Multi-file endpoint edge cases ✅
- Limit parameter validation ✅

### Tests Failed
- ReDoS vulnerability (TIMEOUT - indicates vulnerability) ❌
- Non-UTF-8 file encoding ❌
- JSON parser with non-object input ❌
- JSON parser with nested message objects ❌

---

## Recommendations

### Immediate Actions (Before next release)
1. Add `errors="replace"` to file reading to handle non-UTF-8 files
2. Add type check in JSON parser for non-dict JSON
3. Add type check in `_detect_level_from_content` for non-string content

### Short-term Actions
4. Implement ReDoS protection (recommend `google-re2` or pattern validation)
5. Add comprehensive chaos tests to CI/CD pipeline

### Long-term Considerations
6. Consider adding rate limiting to prevent abuse
7. Add request timeout middleware
8. Consider sandboxing log file access more strictly

---

## Appendix: Chaos Test Files

The chaos test suite is located at:
- `tests/chaos/test_security.py` - Security vulnerability tests
- `tests/chaos/test_robustness.py` - Edge case and robustness tests
- `tests/chaos/test_parsers.py` - Parser resilience tests

Run all chaos tests:
```bash
uv run pytest tests/chaos/ -v
```
