# Production Learnings: GPU Training Monitoring

**Date:** 2026-02-02
**Use Case:** Monitoring LoRA training on RunPod (A100) + Local (RTX 5070)
**Integration:** Studioflow desktop app (Tauri + TypeScript)

## Overview

Used logtap to monitor ML training runs:
- Local Z-Image Flux LoRA training (ai-toolkit)
- Cloud Wan 2.2 video LoRA training (musubi-tuner on RunPod A100)

This doc captures learnings for making logtap more production-ready.

---

## What Worked Well

### 1. Disconnect Resilience
The core value prop delivered. SSH drops during long training runs (4-12 hours) didn't lose log history. `--since` cursor resume worked as expected.

### 2. Simple Pipe Integration
```bash
python train.py 2>&1 | logtap ingest training-run
```
Zero code changes to training scripts. Worked with:
- ai-toolkit (tqdm progress bars)
- musubi-tuner (custom logging)
- PyTorch distributed training

### 3. Tag-Based Multi-Node
```bash
# Node 1
... | logtap ingest run1 --tag node=gpu0
# Node 2
... | logtap ingest run1 --tag node=gpu1
```
Could aggregate or filter by node cleanly.

---

## Integration Pain Points

### 1. Shell-Based Client Integration is Brittle

**Problem:** Our Tauri app shells out to `logtap tail`:
```rust
fn get_logs(run_id: String, lines: u32) -> Result<Vec<String>, String> {
    let output = Command::new("logtap")
        .args(["tail", &run_id, "--lines", &lines.to_string()])
        .output();
    // Parse stdout...
}
```

**Issues:**
- No streaming - must poll (we used 3-second intervals)
- Hard to detect "server down" vs "no logs yet"
- Error messages go to stderr, need separate handling
- Process spawning overhead on every poll

**Suggestion:** Provide a simple HTTP client library or document the REST API better for direct integration. SSE endpoint for streaming would help desktop apps.

### 2. No Built-in Training Metrics Parsing

**Problem:** Training logs have structured info buried in tqdm output:
```
zimage_lora_teo_v1:  94%|#########4| 3773/4000 [45:54<5:58:48, 94.43s/it, lr: 3.0e-04 loss: 3.915e-01]
```

We want:
- Current step: 3773
- Total steps: 4000
- Loss: 0.3915
- ETA: 5:58:48

**Current workaround:** Parse in the UI layer:
```typescript
if (line.includes('%|') || line.includes('steps:')) className += ' progress';
else if (line.includes('loss') || line.includes('Loss')) className += ' loss';
```

**Suggestion:** Optional training-mode parser that extracts:
- Step progress (X/Y or percentage)
- Loss values (various formats)
- Timing/ETA
- Expose as structured metadata on log entries

### 3. Cloud Provider Setup Complexity

**Problem:** RunPod pods have:
- Dynamic IPs that change on restart
- Port mapping (internal 8000 -> random external port)
- No stable hostname

**Our workaround:**
```bash
# Query RunPod API for current SSH endpoint
curl -X POST https://api.runpod.io/graphql -d '...'
# Returns: {"ip":"38.128.233.145","publicPort":17314}
# Then SSH tunnel or direct connect
```

**Suggestion:** Document cloud provider setup patterns:
- RunPod: GraphQL API for pod discovery
- Vast.ai: Their API pattern
- Lambda: Static IPs (easier)

Or provide a discovery helper:
```bash
logtap discover --provider runpod --pod-id abc123
# Outputs connection string
```

### 4. Multi-Source Dashboard View

**Problem:** Monitoring both local and cloud training simultaneously. Each needs different `LOGTAP_SERVER` endpoint.

**Current state:** Must run separate logtap tail commands or switch contexts.

**Suggestion:** Client-side multi-source support:
```bash
logtap tail run1 --server http://localhost:8765 \
                 --server http://runpod-ip:8000
# Interleaves logs from both sources
```

Or a dashboard mode that shows multiple runs side-by-side.

---

## Feature Requests from Production Use

### Priority 1: HTTP/SSE Client Library
```python
from logtap import LogtapClient

client = LogtapClient("http://localhost:8000", api_key="secret")
for line in client.tail("run1", follow=True):
    print(line.text, line.cursor)
```

Would enable:
- Native integration without subprocess
- Proper streaming in desktop apps
- Better error handling

### Priority 2: Training Metrics Extraction
```bash
logtap tail run1 --format metrics
# Outputs:
# {"step": 3773, "total": 4000, "loss": 0.3915, "eta": "5:58:48"}
```

Patterns to detect:
- tqdm: `X/Y [time<eta, speed, key: value]`
- pytorch: `Epoch X Step Y Loss: Z`
- transformers: `{'loss': X, 'learning_rate': Y, ...}`

### Priority 3: Health Endpoint Enhancement
Current `/health` returns basic info. Add:
```json
{
  "status": "healthy",
  "runs": {
    "training-run": {
      "lines": 15000,
      "last_write": "2026-02-02T23:30:00Z",
      "active": true
    }
  }
}
```

Would help detect stale/finished runs without tailing.

### Priority 4: Retention and Cleanup
Training runs accumulate. Need:
```bash
logtap cleanup --older-than 7d
logtap archive run1 --to s3://bucket/logs/
```

---

## Configuration That Worked

### RunPod Setup Script
```bash
#!/bin/bash
# On pod startup
pip install logtap
export LOGTAP_API_KEY=mykey
logtap collect --port 8000 &

# Start training with log capture
python train.py 2>&1 | logtap ingest "$(hostname)-$(date +%Y%m%d)"
```

### Local Training Integration
```bash
# launch_clean.py wraps training to clear env vars
# Pipe output to logtap
uv run python scripts/training/launch_clean.py config.yaml 2>&1 | logtap ingest local-training
```

### Studioflow UI Polling
```typescript
// 3-second polling interval balanced responsiveness vs overhead
const logRefreshInterval = setInterval(loadLogs, 3000);

// Auto-scroll when follow mode enabled
if (logFollowEnabled) {
  output.scrollTop = output.scrollHeight;
}
```

---

## Summary

logtap's core value (disconnect-resilient log streaming) works great for GPU training. Main gaps are:

1. **Integration ergonomics** - HTTP client library would help desktop/web apps
2. **Training-specific parsing** - Extract step/loss/ETA as structured data
3. **Cloud discovery** - Helpers for RunPod/Vast.ai dynamic endpoints
4. **Multi-source views** - Dashboard showing local + cloud together

The shell-based CLI approach works but feels like v1. A v2 with native client libraries and training-aware features would be significantly more useful for the ML training monitoring use case.
