#!/usr/bin/env python3
"""
Production validation script for logtap.
Simulates real-world scenarios to validate before launch.

Run with: uv run python scripts/validate_prod.py
"""

import json
import os
import subprocess
import sys
import time
from pathlib import Path

# Configuration
SERVER = "http://localhost:9123"
API_KEY = "test-secret"
DATA_DIR = Path.home() / ".logtap" / "test-runs"

# Colors
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
DIM = "\033[2m"
RESET = "\033[0m"


def log(msg, color=None):
    if color:
        print(f"{color}{msg}{RESET}", flush=True)
    else:
        print(msg, flush=True)


def run_cmd(cmd, capture=False, timeout=30):
    """Run a command and return result."""
    # Use UV_PROJECT_ENVIRONMENT to ensure we use the right venv
    env = {
        **os.environ,
        "LOGTAP_SERVER": SERVER,
        "LOGTAP_API_KEY": API_KEY,
        "UV_PROJECT_ENVIRONMENT": os.environ.get("UV_PROJECT_ENVIRONMENT", ".venv2"),
    }
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=capture,
            text=True,
            timeout=timeout,
            env=env,
        )
        return result
    except subprocess.TimeoutExpired:
        return None


def start_collector():
    """Start collector in background."""
    log("\n[1/5] Starting collector...", YELLOW)

    # Clean up old data
    if DATA_DIR.exists():
        import shutil

        shutil.rmtree(DATA_DIR)

    proc = subprocess.Popen(
        f"uv run logtap collect --port 9123 --api-key {API_KEY} --data-dir {DATA_DIR}",
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    time.sleep(2)  # Wait for startup

    # Verify it's running
    result = run_cmd("uv run logtap doctor", capture=True)
    if result and result.returncode == 0:
        log("  [OK] Collector running", GREEN)
        return proc
    else:
        log("  [FAIL] Collector failed to start", RED)
        proc.kill()
        return None


def test_basic_flow():
    """Test basic ingest -> tail flow."""
    log("\n[2/5] Testing basic flow (ingest -> tail)...", YELLOW)

    # Ingest some lines
    ingest_proc = subprocess.Popen(
        f"uv run logtap ingest basic-test --api-key {API_KEY}",
        shell=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "LOGTAP_SERVER": SERVER},
    )

    for i in range(10):
        ingest_proc.stdin.write(f"line {i}: training epoch {i}\n".encode())
        ingest_proc.stdin.flush()
    ingest_proc.stdin.close()
    ingest_proc.wait(timeout=5)

    # Tail and verify
    result = run_cmd("uv run logtap tail basic-test --lines 10 --output plain", capture=True)
    if result and "line 9" in result.stdout:
        log("  [OK] Basic flow works", GREEN)
        return True
    else:
        log("  [FAIL] Basic flow failed", RED)
        log(f"    stdout: {result.stdout if result else 'None'}", DIM)
        return False


def test_reconnect_with_cursor():
    """Test reconnect with --since cursor."""
    log("\n[3/5] Testing reconnect with cursor...", YELLOW)

    # Ingest 100 lines
    ingest_proc = subprocess.Popen(
        f"uv run logtap ingest reconnect-test --api-key {API_KEY}",
        shell=True,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "LOGTAP_SERVER": SERVER},
    )

    for i in range(100):
        ingest_proc.stdin.write(f"epoch {i}: loss=0.{100-i:03d}\n".encode())
        ingest_proc.stdin.flush()
    ingest_proc.stdin.close()
    ingest_proc.wait(timeout=5)

    # Tail first 50 lines
    result1 = run_cmd(
        f"uv run logtap tail reconnect-test --server {SERVER} --lines 50 --output jsonl",
        capture=True,
    )
    if not result1 or result1.returncode != 0:
        log("  [FAIL] First tail failed", RED)
        log(f"    {result1.stderr if result1 else 'timeout'}", DIM)
        return False

    # Get cursor from last line
    lines = [x for x in result1.stdout.strip().split("\n") if x]
    if not lines:
        log("  [FAIL] No lines returned", RED)
        return False

    try:
        last_line = json.loads(lines[-1])
        cursor = last_line.get("cursor", 50)
    except Exception as e:
        log(f"  [FAIL] Could not parse cursor: {e}", RED)
        cursor = 50

    # Reconnect with --since
    result2 = run_cmd(
        f"uv run logtap tail reconnect-test --server {SERVER} --since {cursor} --output plain",
        capture=True,
    )
    if result2 and result2.returncode == 0 and "epoch 99" in result2.stdout:
        log(f"  [OK] Reconnect from cursor {cursor} works", GREEN)
        return True
    else:
        log("  [FAIL] Reconnect failed", RED)
        if result2:
            log(f"    stdout: {result2.stdout[:200] if result2.stdout else 'empty'}", DIM)
        return False


def test_multi_node_tags():
    """Test multi-node with tags."""
    log("\n[4/5] Testing multi-node tagging...", YELLOW)

    # Ingest from "node 1"
    p1 = subprocess.Popen(
        f"uv run logtap ingest multinode-test --tag node=gpu1 --api-key {API_KEY}",
        shell=True,
        stdin=subprocess.PIPE,
        env={**os.environ, "LOGTAP_SERVER": SERVER},
    )

    # Ingest from "node 2"
    p2 = subprocess.Popen(
        f"uv run logtap ingest multinode-test --tag node=gpu2 --api-key {API_KEY}",
        shell=True,
        stdin=subprocess.PIPE,
        env={**os.environ, "LOGTAP_SERVER": SERVER},
    )

    for i in range(20):
        p1.stdin.write(f"gpu1: step {i}\n".encode())
        p1.stdin.flush()
        p2.stdin.write(f"gpu2: step {i}\n".encode())
        p2.stdin.flush()

    p1.stdin.close()
    p2.stdin.close()
    p1.wait(timeout=5)
    p2.wait(timeout=5)

    # Filter by tag
    result1 = run_cmd(
        "uv run logtap tail multinode-test --tag node=gpu1 --output plain", capture=True
    )
    result2 = run_cmd(
        "uv run logtap tail multinode-test --tag node=gpu2 --output plain", capture=True
    )

    gpu1_only = result1 and "gpu1:" in result1.stdout and "gpu2:" not in result1.stdout
    gpu2_only = result2 and "gpu2:" in result2.stdout and "gpu1:" not in result2.stdout

    if gpu1_only and gpu2_only:
        log("  [OK] Tag filtering works", GREEN)
        return True
    else:
        log("  [FAIL] Tag filtering broken", RED)
        log(f"    gpu1 filter: {'pass' if gpu1_only else 'fail'}", DIM)
        log(f"    gpu2 filter: {'pass' if gpu2_only else 'fail'}", DIM)
        return False


def test_pipe_cleanliness():
    """Test that stdout is clean for piping."""
    log("\n[5/5] Testing pipe cleanliness (stdout vs stderr)...", YELLOW)

    # Ingest test data
    ingest_proc = subprocess.Popen(
        f"uv run logtap ingest pipe-test --api-key {API_KEY}",
        shell=True,
        stdin=subprocess.PIPE,
        env={**os.environ, "LOGTAP_SERVER": SERVER},
    )

    for i in range(5):
        ingest_proc.stdin.write(f'{{"epoch": {i}, "loss": 0.{5-i}}}\n'.encode())
        ingest_proc.stdin.flush()
    ingest_proc.stdin.close()
    ingest_proc.wait(timeout=5)

    # Tail with jsonl and pipe to check
    result = run_cmd(f"uv run logtap tail pipe-test --server {SERVER} --output jsonl", capture=True)

    if not result or result.returncode != 0:
        log("  [FAIL] Tail failed", RED)
        log(f"    {result.stderr if result else 'timeout'}", DIM)
        return False

    # Verify stdout is valid JSON lines
    valid_json = True
    invalid_line = None
    for line in result.stdout.strip().split("\n"):
        if line:
            try:
                json.loads(line)
            except Exception:
                valid_json = False
                invalid_line = line[:100]
                break

    # Check stderr doesn't have data lines
    stderr_clean = "epoch" not in result.stderr if result.stderr else True

    if valid_json and stderr_clean:
        log("  [OK] Pipe output is clean JSON", GREEN)
        return True
    else:
        log("  [FAIL] Pipe output not clean", RED)
        log(f"    valid_json: {valid_json}, stderr_clean: {stderr_clean}", DIM)
        if invalid_line:
            log(f"    invalid line: {invalid_line}", DIM)
        return False


def main():
    log("=" * 60)
    log("logtap Production Validation", YELLOW)
    log("=" * 60)

    collector = start_collector()
    if not collector:
        sys.exit(1)

    results = []
    try:
        results.append(("Basic flow", test_basic_flow()))
        results.append(("Reconnect with cursor", test_reconnect_with_cursor()))
        results.append(("Multi-node tags", test_multi_node_tags()))
        results.append(("Pipe cleanliness", test_pipe_cleanliness()))
    finally:
        # Cleanup
        collector.terminate()
        collector.wait()

    # Summary
    log("\n" + "=" * 60)
    log("RESULTS", YELLOW)
    log("=" * 60)

    passed = 0
    for name, result in results:
        status = f"{GREEN}[OK] PASS{RESET}" if result else f"{RED}[FAIL] FAIL{RESET}"
        print(f"  {name}: {status}")
        if result:
            passed += 1

    log(f"\n{passed}/{len(results)} tests passed")

    if passed == len(results):
        log("\n>> Ready for production!", GREEN)
        return 0
    else:
        log("\n!!  Fix failures before shipping", RED)
        return 1


if __name__ == "__main__":
    sys.exit(main())
