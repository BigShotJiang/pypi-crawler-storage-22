"""FastAPI application factory for logtap."""

import os
import time
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from logtap import __version__
from logtap.api.routes import files, health, logs, parsed, runs
from logtap.core.runs import RunStore


def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application for serve mode.

    Serves static log files from a directory (legacy mode).

    Returns:
        Configured FastAPI application instance.
    """
    app = FastAPI(
        title="logtap",
        description="A CLI-first log access tool for Unix systems.",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # Store mode info
    app.state.mode = "serve"
    app.state.features = ["files"]

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health.router, tags=["health"])
    app.include_router(logs.router, prefix="/logs", tags=["logs"])
    app.include_router(files.router, prefix="/files", tags=["files"])
    app.include_router(parsed.router, prefix="/parsed", tags=["parsed"])

    return app


def create_collector_app() -> FastAPI:
    """
    Create and configure the FastAPI application for collector mode.

    Accepts ingested log streams and serves them for tailing.
    This is the recommended mode for ML training logs.

    Returns:
        Configured FastAPI application instance.
    """
    app = FastAPI(
        title="logtap",
        description="tail -f for GPU clouds. Survives disconnects, aggregates multi-node.",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # Store mode info and start time
    app.state.mode = "collect"
    app.state.features = ["runs"]
    app.state.start_time = time.time()

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Initialize run store from environment
    data_dir = Path(os.environ.get("LOGTAP_DATA_DIR", "~/.logtap/runs")).expanduser()
    buffer_lines = int(os.environ.get("LOGTAP_BUFFER_LINES", "100000"))
    max_disk_mb = int(os.environ.get("LOGTAP_MAX_DISK_MB", "1000"))
    retention_hours = int(os.environ.get("LOGTAP_RETENTION_HOURS", "72"))

    run_store = RunStore(
        data_dir=data_dir,
        buffer_lines=buffer_lines,
        max_disk_mb=max_disk_mb,
        retention_hours=retention_hours,
    )
    runs.set_run_store(run_store)
    app.state.run_store = run_store

    # Include routers
    app.include_router(health.router, tags=["health"])
    app.include_router(runs.router, prefix="/runs", tags=["runs"])

    return app


# Create default app instance for uvicorn (serve mode)
app = create_app()
