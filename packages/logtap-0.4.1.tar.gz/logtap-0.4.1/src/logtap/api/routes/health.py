"""Health check endpoint for logtap."""

import time

from fastapi import APIRouter, Request

from logtap import __version__
from logtap.models.responses import HealthResponse

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health_check(request: Request) -> HealthResponse:
    """
    Check the health of the logtap service.

    Returns:
        Health status, version, mode, and capability information.
    """
    mode = getattr(request.app.state, "mode", "serve")
    features = getattr(request.app.state, "features", ["files"])

    # Get run count if in collect mode
    runs_count = None
    if hasattr(request.app.state, "run_store"):
        runs_count = len(request.app.state.run_store.list_runs())

    # Get uptime if start_time is set
    uptime = None
    if hasattr(request.app.state, "start_time"):
        uptime = int(time.time() - request.app.state.start_time)

    return HealthResponse(
        status="healthy",
        version=__version__,
        mode=mode,
        features=features,
        runs=runs_count,
        uptime_seconds=uptime,
    )
