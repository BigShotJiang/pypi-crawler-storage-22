"""Routes for run management (collector mode)."""

import asyncio
from typing import List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response
from fastapi.responses import StreamingResponse

from logtap.api.dependencies import verify_api_key
from logtap.core.runs import RunStore
from logtap.models.responses import (
    IngestResponse,
    RunInfo,
    RunListResponse,
    StreamLineEvent,
    StreamMetaEvent,
)

router = APIRouter()

# Global run store - will be set by app factory
_run_store: Optional[RunStore] = None


def get_run_store() -> RunStore:
    """Get the run store instance."""
    if _run_store is None:
        raise HTTPException(status_code=500, detail="Run store not initialized")
    return _run_store


def set_run_store(store: RunStore) -> None:
    """Set the global run store instance."""
    global _run_store
    _run_store = store


def parse_tags(tag_headers: Optional[List[str]]) -> dict:
    """Parse X-Logtap-Tag headers into dict."""
    if not tag_headers:
        return {}

    tags = {}
    for tag in tag_headers:
        if "=" in tag:
            key, value = tag.split("=", 1)
            tags[key.strip()] = value.strip()
    return tags


@router.get("", response_model=RunListResponse)
async def list_runs(
    since_hours: Optional[int] = Query(None, description="Filter to runs active within N hours"),
    _: None = Depends(verify_api_key),
    store: RunStore = Depends(get_run_store),
) -> RunListResponse:
    """List all runs."""
    runs = store.list_runs(since_hours=since_hours)

    return RunListResponse(
        runs=[
            RunInfo(
                id=run.id,
                lines=run.metadata.lines_count,
                cursor_earliest=run.cursor_earliest,
                cursor_latest=run.cursor_latest,
                tags=run.metadata.tags,
                created_at=run.metadata.created_at,
                last_activity=run.metadata.last_activity,
                active=run.metadata.active,
                bytes_on_disk=run.metadata.bytes_on_disk,
            )
            for run in runs
        ]
    )


@router.get("/{run_id}", response_model=RunInfo)
async def get_run(
    run_id: str,
    _: None = Depends(verify_api_key),
    store: RunStore = Depends(get_run_store),
) -> RunInfo:
    """Get details for a specific run."""
    run = store.get(run_id)
    if run is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "run_not_found", "message": f"Run '{run_id}' does not exist"},
        )

    return RunInfo(
        id=run.id,
        lines=run.metadata.lines_count,
        cursor_earliest=run.cursor_earliest,
        cursor_latest=run.cursor_latest,
        tags=run.metadata.tags,
        created_at=run.metadata.created_at,
        last_activity=run.metadata.last_activity,
        active=run.metadata.active,
        bytes_on_disk=run.metadata.bytes_on_disk,
    )


@router.post("/{run_id}/ingest", response_model=IngestResponse)
async def ingest(
    run_id: str,
    request: Request,
    response: Response,
    x_logtap_tag: Optional[List[str]] = Header(None),
    _: None = Depends(verify_api_key),
    store: RunStore = Depends(get_run_store),
) -> IngestResponse:
    """
    Ingest log lines for a run.

    Send lines as plain text with newline delimiters.
    Supports chunked transfer encoding for streaming.
    """
    # Check storage
    storage_err = store.check_storage()
    if storage_err:
        raise HTTPException(
            status_code=507,
            detail={"error": "insufficient_storage", "message": "Disk limit exceeded"},
        )

    # Get or create run
    run, created = store.get_or_create(run_id)

    # Handle tags (validate and track in metadata)
    tags = parse_tags(x_logtap_tag)
    if tags:
        err = run.set_tags(tags)
        if err:
            raise HTTPException(
                status_code=400,
                detail={"error": "invalid_tag", "message": err},
            )

    # Read and ingest body
    lines_ingested = 0
    buffer = ""

    async for chunk in request.stream():
        text = chunk.decode("utf-8", errors="replace")
        buffer += text

        # Process complete lines
        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            run.append(line, tags)  # Pass tags to each line
            lines_ingested += 1

    # Flush remaining partial line
    if buffer:
        run.append(buffer, tags)  # Pass tags to each line
        lines_ingested += 1

    # Save metadata
    run._save_metadata()

    # Set status code: 201 for new run, 200 for existing
    response.status_code = 201 if created else 200

    return IngestResponse(
        run_id=run_id,
        lines_ingested=lines_ingested,
        cursor_end=run.cursor_latest,
    )


@router.get("/{run_id}/stream")
async def stream_run(
    run_id: str,
    since: Optional[int] = Query(None, description="Cursor to resume from (exclusive)"),
    tail: int = Query(50, description="Lines to show if since not provided"),
    follow: bool = Query(False, description="Keep connection open for new lines"),
    tag: Optional[List[str]] = Query(None, description="Filter by tag (key=value)"),
    _: None = Depends(verify_api_key),
    store: RunStore = Depends(get_run_store),
) -> StreamingResponse:
    """
    Stream lines from a run using Server-Sent Events.

    Supports resume via `since` parameter or Last-Event-ID header.
    """
    run = store.get(run_id)
    if run is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "run_not_found", "message": f"Run '{run_id}' does not exist"},
        )

    # Parse tag filter for per-line filtering
    tag_filter = parse_tags(tag) if tag else None

    async def generate_sse():
        # Get initial lines and check for gap
        lines, gap = run.get_lines(since=since, tail=tail, tag_filter=tag_filter)

        # Send meta event
        missed = None
        if gap and since is not None:
            missed = run.cursor_earliest - since - 1
            if missed < 0:
                missed = 0

        meta = StreamMetaEvent(
            cursor_earliest=run.cursor_earliest,
            cursor_latest=run.cursor_latest,
            gap=gap,
            missed=missed,
        )
        yield f"event: meta\ndata: {meta.model_dump_json()}\n\n"

        # Send initial lines
        last_cursor = since if since is not None else -1
        for line in lines:
            event = StreamLineEvent(
                cursor=line.cursor,
                line=line.line,
                ts=line.ts,
            )
            yield f"id: {line.cursor}\nevent: line\ndata: {event.model_dump_json()}\n\n"
            last_cursor = line.cursor

        if not follow:
            return

        # Follow mode - stream new lines
        heartbeat_interval = 15  # seconds
        last_heartbeat = asyncio.get_event_loop().time()

        while True:
            # Get new lines since last cursor
            new_lines, _ = run.get_lines(since=last_cursor, limit=100, tag_filter=tag_filter)

            for line in new_lines:
                event = StreamLineEvent(
                    cursor=line.cursor,
                    line=line.line,
                    ts=line.ts,
                )
                yield f"id: {line.cursor}\nevent: line\ndata: {event.model_dump_json()}\n\n"
                last_cursor = line.cursor

            # Send heartbeat if needed
            now = asyncio.get_event_loop().time()
            if now - last_heartbeat >= heartbeat_interval:
                yield ": heartbeat\n\n"
                last_heartbeat = now

            # Small delay before checking again
            await asyncio.sleep(0.1)

    return StreamingResponse(
        generate_sse(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Logtap-Earliest-Cursor": str(run.cursor_earliest),
            "X-Logtap-Latest-Cursor": str(run.cursor_latest),
        },
    )


@router.get("/{run_id}/query")
async def query_run(
    run_id: str,
    from_cursor: Optional[int] = Query(None, alias="from", description="Start cursor (inclusive)"),
    to_cursor: Optional[int] = Query(None, alias="to", description="End cursor (inclusive)"),
    tail: int = Query(50, description="Last N lines (if from/to not provided)"),
    limit: int = Query(1000, le=10000, description="Maximum lines to return"),
    search: Optional[str] = Query(None, description="Substring filter"),
    regex: Optional[str] = Query(None, description="Regex filter"),
    output: str = Query("jsonl", description="Output format: jsonl or plain"),
    _: None = Depends(verify_api_key),
    store: RunStore = Depends(get_run_store),
) -> StreamingResponse:
    """Query lines from a run."""
    # Validate search/regex mutual exclusion
    if search and regex:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_query", "message": "Cannot use both search and regex"},
        )

    run = store.get(run_id)
    if run is None:
        raise HTTPException(
            status_code=404,
            detail={"error": "run_not_found", "message": f"Run '{run_id}' does not exist"},
        )

    # Get lines
    if from_cursor is not None:
        # Range query - get lines from cursor onwards
        lines, _ = run.get_lines(since=from_cursor - 1, limit=limit)
        if to_cursor is not None:
            lines = [ln for ln in lines if ln.cursor <= to_cursor]
    else:
        # Tail query
        lines, _ = run.get_lines(tail=tail, limit=limit)

    # Apply search/regex filter
    if search:
        lines = [ln for ln in lines if search in ln.line]
    elif regex:
        import re2

        try:
            pattern = re2.compile(regex)
            lines = [ln for ln in lines if pattern.search(ln.line)]
        except re2.error:
            raise HTTPException(
                status_code=400,
                detail={"error": "invalid_regex", "message": "Invalid regex pattern"},
            )

    async def generate():
        for line in lines:
            if output == "plain":
                yield line.line + "\n"
            else:
                event = StreamLineEvent(cursor=line.cursor, line=line.line, ts=line.ts)
                yield event.model_dump_json() + "\n"

    content_type = "text/plain" if output == "plain" else "application/x-ndjson"
    return StreamingResponse(generate(), media_type=content_type)
