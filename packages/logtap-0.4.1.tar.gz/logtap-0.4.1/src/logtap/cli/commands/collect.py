"""Collector command for logtap CLI."""

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

console = Console()


def collect(
    port: int = typer.Option(
        8000,
        "--port",
        "-p",
        help="Port to listen on.",
    ),
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        "-H",
        help="Host to bind to.",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key for authentication.",
        envvar="LOGTAP_API_KEY",
    ),
    data_dir: Path = typer.Option(
        Path("~/.logtap/runs").expanduser(),
        "--data-dir",
        "-d",
        help="Directory for run storage.",
    ),
    buffer_lines: int = typer.Option(
        100_000,
        "--buffer-lines",
        help="In-memory cache size per run.",
    ),
    max_disk_mb: int = typer.Option(
        1000,
        "--max-disk-mb",
        help="Maximum disk usage across all runs (MB).",
    ),
    retention_hours: int = typer.Option(
        72,
        "--retention-hours",
        help="Hours to retain runs before cleanup.",
    ),
    reload: bool = typer.Option(
        False,
        "--reload",
        "-r",
        help="Enable auto-reload for development.",
    ),
) -> None:
    """
    Start the logtap collector server.

    Accepts ingested log streams over HTTP and serves them for tailing.
    This is the recommended mode for ML training logs.

    Example:
        logtap collect
        logtap collect --port 9000 --api-key secret
        logtap collect --data-dir /mnt/logs --max-disk-mb 5000
    """
    import os

    import uvicorn

    # Expand data_dir
    data_dir = Path(data_dir).expanduser()

    # Set environment variables for the app
    os.environ["LOGTAP_HOST"] = host
    os.environ["LOGTAP_PORT"] = str(port)
    os.environ["LOGTAP_MODE"] = "collect"
    os.environ["LOGTAP_DATA_DIR"] = str(data_dir)
    os.environ["LOGTAP_BUFFER_LINES"] = str(buffer_lines)
    os.environ["LOGTAP_MAX_DISK_MB"] = str(max_disk_mb)
    os.environ["LOGTAP_RETENTION_HOURS"] = str(retention_hours)
    if api_key:
        os.environ["LOGTAP_API_KEY"] = api_key

    console.print("[bold green]Starting logtap collector[/bold green]")
    console.print(f"  [dim]Host:[/dim] {host}")
    console.print(f"  [dim]Port:[/dim] {port}")
    console.print(f"  [dim]Data directory:[/dim] {data_dir}")
    console.print(f"  [dim]Buffer lines:[/dim] {buffer_lines:,}")
    console.print(f"  [dim]Max disk:[/dim] {max_disk_mb} MB")
    console.print(f"  [dim]Retention:[/dim] {retention_hours} hours")
    console.print(f"  [dim]Auth:[/dim] {'enabled' if api_key else 'disabled'}")
    console.print()
    console.print(f"[dim]API docs available at[/dim] http://{host}:{port}/docs")
    console.print()

    uvicorn.run(
        "logtap.api.app:create_collector_app",
        host=host,
        port=port,
        reload=reload,
        factory=True,
    )
