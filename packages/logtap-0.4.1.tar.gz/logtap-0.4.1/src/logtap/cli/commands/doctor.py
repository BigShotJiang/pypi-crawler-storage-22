"""Doctor command for logtap CLI - diagnose connection issues."""

from typing import Optional

import typer
from rich.console import Console

console = Console()


def doctor(
    server: str = typer.Option(
        "http://localhost:8000",
        "--server",
        "-s",
        help="Server URL to check.",
        envvar="LOGTAP_SERVER",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key for authentication.",
        envvar="LOGTAP_API_KEY",
    ),
) -> None:
    """
    Check server connectivity and diagnose issues.

    Verifies the server is reachable, auth works, and reports capabilities.

    Example:
        logtap doctor
        logtap doctor --server http://gpu-box:8000
    """
    import httpx

    console.print(f"[bold]Checking {server}[/bold]\n")

    # Build headers
    headers = {}
    if api_key:
        headers["X-API-Key"] = api_key

    # Step 1: Check if server is reachable
    console.print("[dim]1. Server reachable?[/dim]", end=" ")
    try:
        with httpx.Client(timeout=10) as client:
            response = client.get(f"{server}/health", headers=headers)
    except httpx.ConnectError:
        console.print("[red]NO[/red]")
        console.print(f"\n[red]Could not connect to {server}[/red]")
        console.print("\n[dim]Possible causes:[/dim]")
        console.print("  - Server not running (start with: logtap collect)")
        console.print("  - Wrong host/port")
        console.print("  - Firewall blocking connection")
        console.print(f"\n[dim]Try:[/dim] curl {server}/health")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        console.print("[red]TIMEOUT[/red]")
        console.print(f"\n[red]Connection timed out to {server}[/red]")
        raise typer.Exit(1)

    console.print("[green]YES[/green]")

    # Step 2: Check auth
    console.print("[dim]2. Auth working?[/dim]", end=" ")
    if response.status_code == 401:
        console.print("[red]NO (401 Unauthorized)[/red]")
        console.print("\n[red]API key required or invalid[/red]")
        if not api_key:
            console.print("\n[dim]Try:[/dim] logtap doctor --api-key YOUR_KEY")
            console.print("[dim]Or:[/dim] export LOGTAP_API_KEY=YOUR_KEY")
        else:
            console.print("\n[dim]Check that your API key matches the server's --api-key[/dim]")
        raise typer.Exit(1)
    elif response.status_code >= 400:
        console.print(f"[red]NO ({response.status_code})[/red]")
        raise typer.Exit(1)

    if api_key:
        console.print("[green]YES (key accepted)[/green]")
    else:
        console.print("[green]YES (no auth required)[/green]")

    # Step 3: Parse health response
    try:
        health = response.json()
    except Exception:
        console.print("\n[yellow]Warning: Could not parse health response[/yellow]")
        health = {}

    # Step 4: Check features
    console.print("[dim]3. Features?[/dim]", end=" ")
    mode = health.get("mode", "unknown")
    features = health.get("features", [])
    version = health.get("version", "unknown")

    if "runs" in features:
        console.print("[green]runs[/green] (collector mode)")
    elif "files" in features:
        console.print("[cyan]files[/cyan] (legacy serve mode)")
    else:
        console.print(f"[yellow]{mode}[/yellow]")

    # Step 5: Show summary
    console.print("\n[bold green]Server OK[/bold green]")
    console.print(f"  Version: {version}")
    console.print(f"  Mode: {mode}")
    console.print(f"  Features: {', '.join(features) if features else 'unknown'}")

    if "runs" in features:
        runs_count = health.get("runs", 0)
        console.print(f"  Active runs: {runs_count}")

    # Show curl command for debugging
    console.print("\n[dim]Debug command:[/dim]")
    if api_key:
        console.print(f'  curl -H "X-API-Key: {api_key}" {server}/health')
    else:
        console.print(f"  curl {server}/health")

    # Show quick start if collector mode
    if "runs" in features:
        console.print("\n[dim]Quick start:[/dim]")
        console.print("  python train.py 2>&1 | logtap ingest run1")
        console.print("  logtap tail run1 --follow")
