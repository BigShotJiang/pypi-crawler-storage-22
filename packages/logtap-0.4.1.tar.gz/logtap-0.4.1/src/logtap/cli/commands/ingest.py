"""Ingest command for logtap CLI."""

import sys
from datetime import datetime
from typing import List, Optional

import typer
from rich.console import Console

console = Console(stderr=True)  # Output status to stderr so it doesn't mix with piped data


def ingest(
    name: Optional[str] = typer.Argument(
        None,
        help="Run name. If omitted, generates: run-YYYYMMDD-HHMMSS",
    ),
    server: str = typer.Option(
        "http://localhost:8000",
        "--server",
        "-s",
        help="Collector server URL.",
        envvar="LOGTAP_SERVER",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key for authentication.",
        envvar="LOGTAP_API_KEY",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-t",
        help="Tags as key=value (repeatable).",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress status messages.",
    ),
) -> None:
    """
    Pipe stdin to collector as a named run.

    Reads from stdin and streams lines to the collector server.
    Designed to be used with pipes for training logs.

    Example:
        python train.py 2>&1 | logtap ingest run1
        python train.py 2>&1 | logtap ingest --tag node=gpu1
        cat training.log | logtap ingest my-run --server http://collector:8000
    """
    import httpx

    # Generate run name if not provided
    if name is None:
        name = datetime.now().strftime("run-%Y%m%d-%H%M%S")

    # Build headers as list of tuples (supports duplicate keys)
    headers: List[tuple] = [("Content-Type", "text/plain")]
    if api_key:
        headers.append(("X-API-Key", api_key))
    if tag:
        for t in tag:
            headers.append(("X-Logtap-Tag", t))

    url = f"{server.rstrip('/')}/runs/{name}/ingest"

    if not quiet:
        console.print(f"[dim]Ingesting to[/dim] {name} [dim]@[/dim] {server}")

    try:
        # Read all stdin
        content = sys.stdin.read()

        if not quiet:
            line_count = content.count("\n") + (1 if content and not content.endswith("\n") else 0)
            console.print(f"[dim]Sending {line_count} lines...[/dim]")

        # Use httpx
        with httpx.Client(timeout=None) as client:
            response = client.post(url, content=content, headers=headers)

            if response.status_code == 401:
                console.print("[red]Error: Unauthorized. Check your API key.[/red]")
                raise typer.Exit(1)
            elif response.status_code == 409:
                try:
                    data = response.json()
                    msg = data.get("detail", {}).get("message", "Tag conflict")
                except Exception:
                    msg = "Tag conflict"
                console.print(f"[red]Error: {msg}[/red]")
                raise typer.Exit(1)
            elif response.status_code == 507:
                console.print("[red]Error: Server storage limit exceeded.[/red]")
                raise typer.Exit(1)
            elif response.status_code >= 400:
                console.print(f"[red]Error: Server returned {response.status_code}[/red]")
                try:
                    console.print(f"[dim]{response.text}[/dim]")
                except Exception:
                    pass
                raise typer.Exit(1)

            data = response.json()
            if not quiet:
                console.print(
                    f"[green]Done.[/green] "
                    f"Ingested {data['lines_ingested']} lines to [bold]{data['run_id']}[/bold] "
                    f"(cursor: {data['cursor_end']})"
                )

    except httpx.ConnectError:
        console.print(f"[red]Error: Could not connect to {server}[/red]")
        console.print("[dim]Is the collector running? Start with: logtap collect[/dim]")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        console.print("[red]Error: Connection timed out[/red]")
        raise typer.Exit(1)
