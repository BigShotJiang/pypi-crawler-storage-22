"""Runs command for logtap CLI."""

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

console = Console()


def runs(
    server: str = typer.Option(
        "http://localhost:8000",
        "--server",
        "-s",
        help="Collector server URL.",
        envvar="LOGTAP_SERVER",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key for authentication.",
        envvar="LOGTAP_API_KEY",
    ),
    since_hours: Optional[int] = typer.Option(
        24,
        "--since-hours",
        help="Show runs active within N hours.",
    ),
) -> None:
    """
    List runs on a collector.

    Shows all active and recent runs with their line counts and tags.

    Example:
        logtap runs
        logtap runs --server http://gpu-box:8000
        logtap runs --since-hours 48
    """
    from datetime import datetime, timezone

    import httpx

    # Build headers
    headers = {}
    if api_key:
        headers["X-API-Key"] = api_key

    url = f"{server.rstrip('/')}/runs"
    params = {}
    if since_hours is not None:
        params["since_hours"] = since_hours

    try:
        with httpx.Client(timeout=30) as client:
            response = client.get(url, headers=headers, params=params)

            if response.status_code == 401:
                console.print("[red]Error: Unauthorized. Check your API key.[/red]")
                raise typer.Exit(1)
            elif response.status_code >= 400:
                console.print(f"[red]Error: Server returned {response.status_code}[/red]")
                raise typer.Exit(1)

            data = response.json()
            runs_list = data.get("runs", [])

            if not runs_list:
                console.print("[dim]No runs found.[/dim]")
                return

            # Create table
            table = Table(show_header=True, header_style="bold")
            table.add_column("RUN", style="cyan")
            table.add_column("LINES", justify="right")
            table.add_column("LAST ACTIVITY", style="dim")
            table.add_column("TAGS")

            now = datetime.now(timezone.utc)

            for run in runs_list:
                # Format last activity as relative time
                last_activity = datetime.fromisoformat(run["last_activity"].replace("Z", "+00:00"))
                delta = now - last_activity
                if delta.total_seconds() < 60:
                    time_str = f"{int(delta.total_seconds())}s ago"
                elif delta.total_seconds() < 3600:
                    time_str = f"{int(delta.total_seconds() / 60)}m ago"
                elif delta.total_seconds() < 86400:
                    time_str = f"{int(delta.total_seconds() / 3600)}h ago"
                else:
                    time_str = f"{int(delta.total_seconds() / 86400)}d ago"

                # Format tags
                tags = run.get("tags", {})
                tags_str = ", ".join(f"{k}={v}" for k, v in tags.items()) if tags else ""

                table.add_row(
                    run["id"],
                    f"{run['lines']:,}",
                    time_str,
                    tags_str,
                )

            console.print(table)

    except httpx.ConnectError:
        console.print(f"[red]Error: Could not connect to {server}[/red]")
        console.print("[dim]Is the collector running? Start with: logtap collect[/dim]")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        console.print("[red]Error: Connection timed out[/red]")
        raise typer.Exit(1)
