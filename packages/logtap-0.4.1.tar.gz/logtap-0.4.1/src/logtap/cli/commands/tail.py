"""Tail command for logtap CLI - real-time log streaming."""

import json
from typing import List, Optional

import typer
from rich.console import Console

console = Console()


def tail(
    target: str = typer.Argument(
        ...,
        help="Run name or file path to tail.",
    ),
    server: Optional[str] = typer.Option(
        None,
        "--server",
        "-s",
        help="URL of the logtap server.",
        envvar="LOGTAP_SERVER",
    ),
    follow: bool = typer.Option(
        False,
        "--follow",
        "-f",
        help="Follow log output (like tail -f).",
    ),
    lines: int = typer.Option(
        50,
        "--lines",
        "-n",
        help="Number of lines to show initially.",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key for authentication.",
        envvar="LOGTAP_API_KEY",
    ),
    mode: str = typer.Option(
        "auto",
        "--mode",
        "-m",
        help="Resolution mode: auto, runs, or files.",
    ),
    since: Optional[int] = typer.Option(
        None,
        "--since",
        help="Resume from cursor (exclusive). For runs mode only.",
    ),
    tag: Optional[List[str]] = typer.Option(
        None,
        "--tag",
        "-t",
        help="Filter by tag (key=value, repeatable). For runs mode only.",
    ),
    output: str = typer.Option(
        "pretty",
        "--output",
        "-o",
        help="Output format: pretty, plain, or jsonl.",
    ),
) -> None:
    """
    Tail a run or file, optionally following new entries.

    For ML training logs (runs mode):
        logtap tail run1 -f
        logtap tail run1 --since 5000 -f
        logtap tail run1 --tag node=gpu1

    For static files (legacy mode):
        logtap tail syslog --server http://mybox:8000
        logtap tail auth.log -f
    """

    # If no server specified and target looks like a path, use local file mode
    if server is None:
        if "/" in target or "\\" in target or target.startswith("."):
            console.print("[red]Error: Local file tailing requires --server[/red]")
            console.print("[dim]For runs: logtap tail run1 --server http://collector:8000[/dim]")
            console.print(
                "[dim]For files: logtap tail syslog --server http://fileserver:8000[/dim]"
            )
            raise typer.Exit(1)
        # Default to localhost
        server = "http://localhost:8000"

    headers = {}
    if api_key:
        headers["X-API-Key"] = api_key

    # Determine mode
    use_runs_mode = False
    if mode == "runs":
        use_runs_mode = True
    elif mode == "files":
        use_runs_mode = False
    else:
        # Auto mode: check server capabilities and run existence
        use_runs_mode = _detect_runs_mode(server, target, headers)

    if use_runs_mode:
        _tail_run(server, target, headers, follow, lines, since, tag, output)
    else:
        _tail_file(server, target, headers, follow, lines, output)


def _detect_runs_mode(server: str, target: str, headers: dict) -> bool:
    """Detect if server supports runs and target exists as a run."""
    import httpx

    try:
        with httpx.Client(timeout=5) as client:
            # Check health endpoint for capabilities
            response = client.get(f"{server}/health", headers=headers)
            if response.status_code == 200:
                data = response.json()
                features = data.get("features", [])
                if "runs" in features:
                    # Check if run exists
                    run_response = client.get(f"{server}/runs/{target}", headers=headers)
                    if run_response.status_code == 200:
                        return True
    except Exception:
        pass

    return False


def _tail_run(
    server: str,
    run_id: str,
    headers: dict,
    follow: bool,
    lines: int,
    since: Optional[int],
    tags: Optional[List[str]],
    output: str,
) -> None:
    """Tail a run using SSE."""
    import httpx

    # Build URL with query params
    params = {"tail": lines, "follow": str(follow).lower()}
    if since is not None:
        params["since"] = since
    if tags:
        params["tag"] = tags

    url = f"{server}/runs/{run_id}/stream"

    try:
        with httpx.Client(timeout=None) as client:
            with client.stream("GET", url, headers=headers, params=params) as response:
                if response.status_code == 401:
                    console.print("[red]Error: Unauthorized. Check your API key.[/red]")
                    raise typer.Exit(1)
                elif response.status_code == 404:
                    console.print(f"[red]Error: Run '{run_id}' not found.[/red]")
                    raise typer.Exit(1)
                elif response.status_code >= 400:
                    console.print(f"[red]Error: Server returned {response.status_code}[/red]")
                    raise typer.Exit(1)

                # Track if this is a reconnect (user provided --since)
                is_reconnect = since is not None

                # Parse SSE stream
                buffer = ""
                for chunk in response.iter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_str, buffer = buffer.split("\n\n", 1)
                        _process_sse_event(event_str, output, is_reconnect)

    except httpx.ConnectError:
        console.print(f"[red]Error: Could not connect to {server}[/red]")
        console.print("[dim]Is the collector running? Start with: logtap collect[/dim]")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped.[/dim]")


def _process_sse_event(event_str: str, output: str, is_reconnect: bool) -> None:
    """Process a single SSE event."""
    event_type = None
    data = None

    for line in event_str.split("\n"):
        if line.startswith(":"):
            # Comment (heartbeat)
            continue
        elif line.startswith("event: "):
            event_type = line[7:]
        elif line.startswith("data: "):
            data = line[6:]
        # Note: id: lines are parsed by SSE but not used for now

    if event_type == "meta" and data:
        try:
            meta = json.loads(data)
            if meta.get("gap") and meta.get("missed"):
                # Gap detected - warn user about missed lines
                console.print(
                    f"[yellow]reconnected (missed {meta['missed']} lines)[/yellow]",
                    stderr=True,
                )
            elif is_reconnect:
                # Clean reconnect - show cursor position
                cursor = meta.get("cursor_earliest", meta.get("cursor_latest", "?"))
                console.print(f"[dim]resumed at cursor {cursor}[/dim]", stderr=True)
        except Exception:
            pass
    elif event_type == "line" and data:
        try:
            line_data = json.loads(data)
            if output == "jsonl":
                console.print(data)
            elif output == "plain":
                console.print(line_data["line"])
            else:
                # Pretty output - just the line
                console.print(line_data["line"])
        except Exception:
            pass


def _tail_file(
    server: str,
    filename: str,
    headers: dict,
    follow: bool,
    lines: int,
    output: str,
) -> None:
    """Tail a static file (legacy mode)."""
    import httpx

    params = {
        "filename": filename,
        "limit": lines,
    }

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(f"{server}/logs", params=params, headers=headers)

        if response.status_code == 401:
            console.print("[red]Error: Unauthorized. Check your API key.[/red]")
            raise typer.Exit(1)
        elif response.status_code != 200:
            try:
                error_detail = response.json().get("detail", response.text)
            except Exception:
                error_detail = response.text
            console.print(f"[red]Error:[/red] {error_detail}")
            raise typer.Exit(1)

        data = response.json()
        log_lines = data.get("lines", [])

        # Print initial lines
        for line in log_lines:
            if output == "jsonl":
                console.print(json.dumps({"line": line}))
            else:
                console.print(line)

        if follow:
            console.print()
            console.print("[dim]Streaming new entries... (Ctrl+C to stop)[/dim]")
            console.print()

            # Stream new entries via WebSocket
            import asyncio

            async def stream_logs():
                import websockets

                ws_url = server.replace("http://", "ws://").replace("https://", "wss://")
                ws_url = f"{ws_url}/logs/stream?filename={filename}"

                extra_headers = {}
                if headers.get("X-API-Key"):
                    extra_headers["X-API-Key"] = headers["X-API-Key"]

                try:
                    async with websockets.connect(ws_url, extra_headers=extra_headers) as ws:
                        async for message in ws:
                            if output == "jsonl":
                                console.print(json.dumps({"line": message}))
                            else:
                                console.print(message)
                except websockets.exceptions.InvalidStatusCode as e:
                    if e.status_code == 404:
                        console.print("[yellow]Streaming not available.[/yellow]")
                        console.print("[dim]Server may need updating.[/dim]")
                    else:
                        console.print(f"[red]WebSocket error: {e}[/red]")
                except Exception as e:
                    console.print(f"[red]Streaming error: {e}[/red]")

            try:
                asyncio.run(stream_logs())
            except KeyboardInterrupt:
                console.print("\n[dim]Stopped.[/dim]")

    except httpx.ConnectError:
        console.print(f"[red]Error:[/red] Could not connect to {server}")
        console.print("[dim]Is the logtap server running? Start it with 'logtap serve'[/dim]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
