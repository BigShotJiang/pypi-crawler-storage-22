"""Main CLI application for logtap."""

import typer

from logtap import __version__
from logtap.cli.commands import collect, doctor, files, ingest, query, runs, serve, tail

app = typer.Typer(
    name="logtap",
    help="tail -f for GPU clouds. Survives disconnects, aggregates multi-node.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        typer.echo(f"logtap {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """
    logtap - tail -f for GPU clouds.

    Start a collector with 'logtap collect', pipe logs with 'logtap ingest',
    and tail from anywhere with 'logtap tail'.
    """
    pass


# Primary commands (new ML workflow)
app.command()(collect.collect)
app.command()(ingest.ingest)
app.command()(runs.runs)
app.command()(doctor.doctor)

# Legacy commands (file-based workflow)
app.command()(serve.serve)
app.command()(query.query)
app.command()(tail.tail)
app.command()(files.files)


if __name__ == "__main__":
    app()
