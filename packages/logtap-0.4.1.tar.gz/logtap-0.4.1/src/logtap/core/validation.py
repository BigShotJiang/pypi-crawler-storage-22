"""
Input validation functions for logtap.

These functions validate user input to prevent security issues
like path traversal attacks and DoS via overly large inputs.

Path Traversal Prevention Model
===============================
1. Input validation: reject NUL bytes, control chars, path separators, ".."
2. Join filename to base directory
3. Resolve to canonical absolute path (follows symlinks)
4. Containment check: commonpath([base, resolved]) == base
5. File type check: must be regular file (not dir, device, etc.)

This prevents:
- Directory traversal (../)
- Absolute path injection (/etc/passwd)
- Symlink escape attacks
- Null byte injection
- Path prefix collisions (/var/log vs /var/logs)
"""

import os
import stat
from typing import Optional, Tuple


def resolve_safe_path(base_dir: str, filename: str, require_exists: bool = False) -> Optional[str]:
    """
    Safely resolve a filename within a base directory.

    Security guarantees:
    - Resolved path is always within base_dir (symlink-safe)
    - No path traversal via "..", separators, or absolute paths
    - No NUL bytes or control characters
    - Containment verified via os.path.commonpath

    Args:
        base_dir: The base directory that files must be within.
        filename: The user-provided filename (single component, no path separators).
        require_exists: If True, also verify the file exists and is a regular file.

    Returns:
        The resolved filepath if safe, None if validation fails.
    """
    # Reject empty filenames
    if not filename:
        return None

    # Reject NUL bytes (can truncate paths in some contexts)
    if "\x00" in filename:
        return None

    # Reject control characters (0x00-0x1F, 0x7F)
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in filename):
        return None

    # Reject special directory entries
    # Note: ".." substring check removed - it over-blocks valid names like "my..log"
    # Traversal requires separators which we reject below; containment check is authoritative
    if filename in {".", ".."}:
        return None

    # Reject path separators - filename must be a single component
    if "/" in filename or "\\" in filename:
        return None

    # Reject absolute paths (Unix and Windows)
    if filename.startswith("/") or filename.startswith("\\"):
        return None
    # Windows drive letters (C:, D:, etc.)
    if len(filename) >= 2 and filename[1] == ":":
        return None

    # Resolve base directory to canonical absolute form
    base_resolved = os.path.realpath(base_dir)

    # Join and resolve to canonical absolute path (follows symlinks)
    filepath = os.path.join(base_resolved, filename)
    filepath_resolved = os.path.realpath(filepath)

    # Containment check using commonpath
    # This is the authoritative check - handles prefix collisions correctly
    # e.g., base=/var/log, candidate=/var/logs/evil will fail
    try:
        common = os.path.commonpath([base_resolved, filepath_resolved])
        if common != base_resolved:
            return None
    except ValueError:
        # Paths on different drives (Windows) or other path issues
        return None

    # Optional: verify file exists and is a regular file
    if require_exists:
        try:
            file_stat = os.stat(filepath_resolved)
            if not stat.S_ISREG(file_stat.st_mode):
                return None
        except OSError:
            return None

    return filepath_resolved


def resolve_safe_path_checked(base_dir: str, filename: str) -> Tuple[Optional[str], str]:
    """
    Resolve a safe path and return detailed error reason if validation fails.

    Returns:
        Tuple of (resolved_path, error_reason). If path is valid, error_reason is empty.
    """
    if not filename:
        return None, "empty filename"
    if "\x00" in filename:
        return None, "filename contains NUL byte"
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in filename):
        return None, "filename contains control character"
    if filename in {".", ".."}:
        return None, "filename is special directory entry"
    if "/" in filename or "\\" in filename:
        return None, "filename contains path separator"
    if filename.startswith("/") or filename.startswith("\\"):
        return None, "filename is absolute path"
    if len(filename) >= 2 and filename[1] == ":":
        return None, "filename contains Windows drive letter"

    base_resolved = os.path.realpath(base_dir)
    filepath = os.path.join(base_resolved, filename)
    filepath_resolved = os.path.realpath(filepath)

    try:
        common = os.path.commonpath([base_resolved, filepath_resolved])
        if common != base_resolved:
            return None, "resolved path escapes base directory"
    except ValueError as e:
        return None, f"path resolution error: {e}"

    return filepath_resolved, ""


def is_filename_valid(filename: str) -> bool:
    """
    Validates a filename for path traversal and absolute paths.

    The filename is considered valid if it does not contain any ".."
    (used for path traversal) and does not start with "/" (indicating an absolute path).

    Args:
        filename: The filename to be checked.

    Returns:
        True if filename is valid, False otherwise.
    """
    return ".." not in filename and not filename.startswith("/")


def is_search_term_valid(search_term: str) -> bool:
    """
    Validates a search term based on its length.

    The search term is considered valid if its length is less than or equal to 100.

    Args:
        search_term: The search term to be checked.

    Returns:
        True if search term is valid, False otherwise.
    """
    return len(search_term) <= 100


def is_limit_valid(limit: int) -> bool:
    """
    Validates a limit for the number of lines to return.

    The limit is considered valid if it's within the range 1 to 1000, inclusive.

    Args:
        limit: The limit to be checked.

    Returns:
        True if limit is valid, False otherwise.
    """
    return 1 <= limit <= 1000
