"""Response models for logtap API."""

from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class LogResponse(BaseModel):
    """Response model for log queries."""

    lines: List[str] = Field(description="Log lines matching the query")
    count: int = Field(description="Number of lines returned")
    filename: str = Field(description="Name of the log file queried")

    model_config = {
        "json_schema_extra": {
            "example": {
                "lines": [
                    "Jan  8 10:23:45 server sshd[1234]: Accepted publickey",
                    "Jan  8 10:23:46 server systemd[1]: Started session",
                ],
                "count": 2,
                "filename": "syslog",
            }
        }
    }


class ErrorResponse(BaseModel):
    """Response model for errors."""

    error: str = Field(description="Error message")
    detail: Optional[str] = Field(default=None, description="Additional error details")

    model_config = {
        "json_schema_extra": {
            "example": {
                "error": "File not found",
                "detail": "/var/log/nonexistent does not exist",
            }
        }
    }


class FileListResponse(BaseModel):
    """Response model for listing available log files."""

    files: List[str] = Field(description="List of available log files")
    directory: str = Field(description="Log directory path")

    model_config = {
        "json_schema_extra": {
            "example": {
                "files": ["syslog", "auth.log", "kern.log", "dpkg.log"],
                "directory": "/var/log",
            }
        }
    }


class HealthResponse(BaseModel):
    """Response model for health check."""

    status: str = Field(default="healthy", description="Service status")
    version: str = Field(description="logtap version")
    mode: Optional[str] = Field(default=None, description="Server mode: serve, collect, or both")
    features: Optional[List[str]] = Field(default=None, description="Available features")
    runs: Optional[int] = Field(default=None, description="Number of active runs (collect mode)")
    uptime_seconds: Optional[int] = Field(default=None, description="Server uptime in seconds")


# Run-related models for collector mode


class RunInfo(BaseModel):
    """Information about a single run."""

    id: str = Field(description="Run identifier")
    lines: int = Field(description="Total lines ingested")
    cursor_earliest: int = Field(description="Earliest available cursor")
    cursor_latest: int = Field(description="Latest cursor")
    tags: Dict[str, str] = Field(default_factory=dict, description="Run tags")
    created_at: datetime = Field(description="When the run was created")
    last_activity: datetime = Field(description="Last activity timestamp")
    active: bool = Field(description="Whether the run is actively receiving data")
    bytes_on_disk: Optional[int] = Field(default=None, description="Disk usage in bytes")


class RunListResponse(BaseModel):
    """Response for listing runs."""

    runs: List[RunInfo] = Field(description="List of runs")


class IngestResponse(BaseModel):
    """Response after ingest completes."""

    run_id: str = Field(description="Run identifier")
    lines_ingested: int = Field(description="Number of lines ingested in this request")
    cursor_end: int = Field(description="Final cursor after ingest")


class StreamMetaEvent(BaseModel):
    """Meta event sent at start of stream."""

    cursor_earliest: int = Field(description="Earliest available cursor")
    cursor_latest: int = Field(description="Latest cursor")
    gap: bool = Field(default=False, description="Whether a gap was detected")
    missed: Optional[int] = Field(default=None, description="Number of missed lines if gap")


class StreamLineEvent(BaseModel):
    """Line event in stream."""

    cursor: int = Field(description="Line cursor")
    line: str = Field(description="Log line content")
    ts: datetime = Field(description="Timestamp when line was ingested")
