"""Tests for logtap."""
