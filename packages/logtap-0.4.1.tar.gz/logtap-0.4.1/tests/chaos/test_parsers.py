"""Parser chaos tests for logtap.

These tests attempt to break the log parsers with malformed input:
- Malformed syslog
- Invalid JSON
- Broken nginx/apache logs
- Mixed formats
- Edge cases in parsing
"""

from http import HTTPStatus

import pytest


class TestSyslogParserChaos:
    """Chaos tests for syslog parser."""

    @pytest.mark.parametrize(
        "malformed_line",
        [
            # Missing components
            "Jan  8 hostname process: message",  # Missing time
            "Jan  8 10:23:45 process: message",  # Missing hostname
            "Jan  8 10:23:45 hostname message",  # Missing process separator
            "10:23:45 hostname process: message",  # Missing date
            # Invalid dates
            "Xxx  8 10:23:45 hostname process: message",  # Invalid month
            "Jan 99 10:23:45 hostname process: message",  # Invalid day
            "Jan  8 99:99:99 hostname process: message",  # Invalid time
            "Jan  8 10:23:45:99 hostname process: message",  # Extra time component
            # Edge case dates
            "Jan  1 00:00:00 hostname process: message",  # Midnight
            "Dec 31 23:59:59 hostname process: message",  # End of year
            "Feb 29 12:00:00 hostname process: message",  # Leap day (may not exist)
            "Feb 30 12:00:00 hostname process: message",  # Invalid day
            # Weird spacing
            "Jan   8 10:23:45 hostname process: message",  # Extra space
            "Jan  8  10:23:45 hostname process: message",  # Double space before time
            "Jan\t8 10:23:45 hostname process: message",  # Tab instead of space
            # Special characters in components
            "Jan  8 10:23:45 host-name.domain process[123]: message",  # Complex hostname
            "Jan  8 10:23:45 hostname pro<cess[123]: message",  # Special in process
            "Jan  8 10:23:45 hostname process[abc]: message",  # Non-numeric PID
            # Very long components
            "Jan  8 10:23:45 " + "a" * 1000 + " process: message",  # Long hostname
            "Jan  8 10:23:45 hostname " + "b" * 1000 + ": message",  # Long process
            # Empty message
            "Jan  8 10:23:45 hostname process: ",
            "Jan  8 10:23:45 hostname process:",
            # Message with syslog-like content
            "Jan  8 10:23:45 hostname process: Jan  8 10:23:45 nested: data",
            # Unicode in various parts
            "Jan  8 10:23:45 호스트 process: message",  # Korean hostname
            "Jan  8 10:23:45 hostname プロセス: message",  # Japanese process
        ],
    )
    def test_malformed_syslog_handled(self, malformed_line):
        """Malformed syslog should not crash parser."""
        from logtap.core.parsers.syslog import SyslogParser

        parser = SyslogParser()
        # Should not raise exception
        result = parser.parse(malformed_line)
        assert result is not None
        assert result.raw == malformed_line


class TestJsonParserChaos:
    """Chaos tests for JSON log parser."""

    @pytest.mark.parametrize(
        "malformed_json",
        [
            # Not JSON at all
            "not json",
            "random text",
            "",
            # Broken JSON syntax
            "{",
            "}",
            "{{}",
            '{"key": }',
            '{"key": value}',  # Unquoted value
            "{'key': 'value'}",  # Single quotes
            '{"key": "value",}',  # Trailing comma
            # Valid JSON but not object
            "[]",
            "[1, 2, 3]",
            '"just a string"',
            "123",
            "null",
            "true",
            "false",
            # Nested/complex JSON
            '{"a": {"b": {"c": {"d": {"e": "deep"}}}}}',
            '{"arr": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}',
            '{"mixed": [1, "two", {"three": 3}, [4, 5]]}',
            # Unusual but valid JSON
            '{"": "empty key"}',
            '{"key": ""}',  # Empty value
            '{"key": null}',
            '{"key": true}',
            '{"key": 123.456}',
            '{"key": -999}',
            '{"key": 1e10}',
            '{"key": "line\\nwith\\nnewlines"}',
            # Very long values
            '{"message": "' + "x" * 10000 + '"}',
            # Unicode in JSON
            '{"message": "日本語メッセージ"}',
            '{"message": "emoji 🎉🔥💻"}',
            '{"日本語キー": "value"}',
            # Escape sequences
            '{"message": "tab\\there\\nand\\rmore"}',
            '{"message": "quote\\"inside"}',
            '{"message": "backslash\\\\here"}',
            '{"message": "unicode\\u0041\\u0042\\u0043"}',
            # Numbers as keys
            '{"123": "numeric key"}',
            # Duplicate keys
            '{"key": "first", "key": "second"}',
            # Extremely nested
            '{"a":' * 100 + "1" + "}" * 100,
        ],
    )
    def test_malformed_json_handled(self, malformed_json):
        """Malformed JSON should not crash parser."""
        from logtap.core.parsers.json_parser import JsonLogParser

        parser = JsonLogParser()
        # Should not raise exception
        result = parser.parse(malformed_json)
        assert result is not None
        assert result.raw == malformed_json

    def test_deeply_nested_json(self):
        """Very deeply nested JSON should be handled."""
        from logtap.core.parsers.json_parser import JsonLogParser

        # Create deeply nested JSON
        depth = 100
        json_str = '{"message": ' + '{"nested": ' * depth + '"deep"' + "}" * depth + "}"

        parser = JsonLogParser()
        result = parser.parse(json_str)
        assert result is not None


class TestNginxParserChaos:
    """Chaos tests for nginx log parser."""

    @pytest.mark.parametrize(
        "malformed_line",
        [
            # Missing fields
            '192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "GET /path HTTP/1.1"',
            '192.168.1.1 - - "GET /path HTTP/1.1" 200 1234',
            '- - [08/Jan/2024:10:23:45 +0000] "GET /path HTTP/1.1" 200 1234',
            # Invalid IP
            (
                "999.999.999.999 - - [08/Jan/2024:10:23:45 +0000] "
                '"GET /path HTTP/1.1" 200 1234 "-" "-"'
            ),
            ("not.an.ip - - [08/Jan/2024:10:23:45 +0000] " '"GET /path HTTP/1.1" 200 1234 "-" "-"'),
            # Invalid dates
            (
                "192.168.1.1 - - [99/Xxx/2024:10:23:45 +0000] "
                '"GET /path HTTP/1.1" 200 1234 "-" "-"'
            ),
            (
                "192.168.1.1 - - [08/Jan/9999:99:99:99 +0000] "
                '"GET /path HTTP/1.1" 200 1234 "-" "-"'
            ),
            # Invalid HTTP methods
            (
                "192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "
                '"INVALID /path HTTP/1.1" 200 1234 "-" "-"'
            ),
            ("192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] " '"" 200 1234 "-" "-"'),
            # Invalid status codes
            (
                "192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "
                '"GET /path HTTP/1.1" 999 1234 "-" "-"'
            ),
            (
                "192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "
                '"GET /path HTTP/1.1" abc 1234 "-" "-"'
            ),
            # Very long URLs
            (
                '192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "GET /'
                + "a" * 10000
                + ' HTTP/1.1" 200 1234 "-" "-"'
            ),
            # Special characters in URL
            (
                "192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "
                '"GET /path?q=<script>alert(1)</script> HTTP/1.1" 200 1234 "-" "-"'
            ),
            (
                "192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "
                '"GET /path?q=日本語 HTTP/1.1" 200 1234 "-" "-"'
            ),
            # Malicious user agents
            '192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "GET /path HTTP/1.1" 200 1234 "-" "'
            + "a" * 10000
            + '"',
        ],
    )
    def test_malformed_nginx_handled(self, malformed_line):
        """Malformed nginx logs should not crash parser."""
        from logtap.core.parsers.nginx import NginxParser

        parser = NginxParser()
        result = parser.parse(malformed_line)
        assert result is not None


class TestAutoParserChaos:
    """Chaos tests for auto-detection parser."""

    def test_mixed_formats_same_file(self):
        """File with multiple log formats mixed together."""
        from logtap.core.parsers.auto import AutoParser

        lines = [
            "Jan  8 10:23:45 hostname process: syslog message",
            '{"message": "json log", "level": "info"}',
            '192.168.1.1 - - [08/Jan/2024:10:23:45 +0000] "GET /path HTTP/1.1" 200 1234 "-" "-"',
            "Just plain text",
            "",
            "Jan  8 10:23:46 hostname process: another syslog",
        ]

        parser = AutoParser()
        results = parser.parse_many(lines)

        assert len(results) == len(lines)
        for result in results:
            assert result is not None

    def test_format_switching(self):
        """Parser should handle format switching mid-file."""
        from logtap.core.parsers.auto import AutoParser

        # Start with JSON, switch to syslog
        lines = [
            '{"message": "json1"}',
            '{"message": "json2"}',
            '{"message": "json3"}',
            "Jan  8 10:23:45 hostname process: syslog suddenly",
            "Jan  8 10:23:46 hostname process: more syslog",
        ]

        parser = AutoParser()
        results = parser.parse_many(lines)
        assert len(results) == len(lines)

    def test_all_garbage(self):
        """File with no recognizable format."""
        from logtap.core.parsers.auto import AutoParser

        lines = [
            "random garbage",
            "12345",
            "!@#$%^&*()",
            "",
            "   ",
            "more random text",
        ]

        parser = AutoParser()
        results = parser.parse_many(lines)

        assert len(results) == len(lines)
        for result in results:
            assert result is not None
            # Should fall back to unparsed

    def test_empty_input(self):
        """Empty list of lines."""
        from logtap.core.parsers.auto import AutoParser

        parser = AutoParser()
        results = parser.parse_many([])
        assert results == []


class TestParsedEndpointChaos:
    """Chaos tests for /parsed endpoint."""

    def test_parsed_with_malformed_content(self, client, log_file):
        """Parsed endpoint should handle malformed content."""
        lines = [
            "completely invalid",
            '{"broken": json',
            "Jan 99 99:99:99 bad syslog",
            "",
            "normal text",
        ]
        filename = log_file(lines)

        response = client.get("/parsed", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert "entries" in data

    def test_parsed_level_filter(self, client, log_file):
        """Level filtering should work correctly."""
        lines = [
            '{"message": "error log", "level": "error"}',
            '{"message": "info log", "level": "info"}',
            '{"message": "debug log", "level": "debug"}',
        ]
        filename = log_file(lines)

        response = client.get("/parsed", params={"filename": filename, "level": "error"})
        assert response.status_code == HTTPStatus.OK

    def test_parsed_invalid_level(self, client, log_file):
        """Invalid level should be handled gracefully."""
        filename = log_file(['{"message": "test"}'])

        response = client.get("/parsed", params={"filename": filename, "level": "invalid_level"})
        # Should either return empty or error gracefully
        assert response.status_code in (
            HTTPStatus.OK,
            HTTPStatus.BAD_REQUEST,
            HTTPStatus.UNPROCESSABLE_ENTITY,
        )


class TestTimestampParsingChaos:
    """Chaos tests for timestamp parsing."""

    @pytest.mark.parametrize(
        "timestamp_value",
        [
            # Valid Unix timestamps
            0,
            1,
            1704700000,
            1704700000.123456,
            # Edge cases
            -1,  # Before epoch
            2147483647,  # Max 32-bit
            2147483648,  # Over 32-bit
            9999999999,  # Far future
            99999999999,  # Very far future (milliseconds?)
            # String formats
            "2024-01-08T10:23:45Z",
            "2024-01-08T10:23:45.123Z",
            "2024-01-08T10:23:45",
            "2024-01-08 10:23:45",
            "2024-01-08",
            # Invalid formats
            "not a date",
            "2024-99-99",
            "",
            "null",
        ],
    )
    def test_timestamp_parsing(self, timestamp_value):
        """Various timestamp formats should be handled."""
        import json

        from logtap.core.parsers.json_parser import JsonLogParser

        parser = JsonLogParser()
        log_line = json.dumps({"message": "test", "timestamp": timestamp_value})
        result = parser.parse(log_line)
        assert result is not None
        # Timestamp might be None if parsing failed, but shouldn't crash


class TestLogLevelDetectionChaos:
    """Chaos tests for log level detection from content."""

    @pytest.mark.parametrize(
        "content,expected_detected",
        [
            # Clear levels
            ("ERROR: something failed", True),
            ("WARNING: be careful", True),
            ("INFO: all good", True),
            ("DEBUG: detailed info", True),
            # Case variations
            ("error something", True),
            ("Error something", True),
            ("ERROR something", True),
            ("ErRoR something", True),
            # Embedded in text
            ("the error was critical", True),  # Contains 'error'
            ("this is an information message", False),  # 'information' != 'info'
            # False positives to watch for
            ("Terror attack", True),  # Contains 'error'
            ("warning: sign ahead", True),
            # No level
            ("just a plain message", False),
            ("", False),
            ("12345", False),
        ],
    )
    def test_level_detection(self, content, expected_detected):
        """Level detection should handle various content."""
        from logtap.core.parsers.base import LogParser, ParsedLogEntry

        # Use a concrete parser to access the method
        class TestParser(LogParser):
            @property
            def name(self):
                return "test"

            def can_parse(self, line):
                return True

            def parse(self, line):
                return ParsedLogEntry(raw=line, message=line)

        parser = TestParser()
        level = parser._detect_level_from_content(content)

        if expected_detected:
            assert level is not None
        # Note: we can't always assert level is None for False cases
        # because the detection might pick up partial matches
