"""Robustness chaos tests for logtap.

These tests attempt to break logtap with edge cases:
- Unusual file contents
- Encoding issues
- Large/empty files
- Concurrent access
- Resource exhaustion
"""

from http import HTTPStatus

import pytest


class TestFileContentEdgeCases:
    """Test handling of unusual file contents."""

    def test_empty_file(self, client, log_file):
        """Empty file should return empty results."""
        filename = log_file([])
        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert data["lines"] == [] or data["lines"] == [""]

    def test_single_empty_line(self, client, log_file):
        """File with single empty line."""
        filename = log_file([""])
        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK

    def test_only_newlines(self, client, test_log_dir):
        """File containing only newlines."""
        filename = "only_newlines.log"
        filepath = test_log_dir / filename
        with open(filepath, "w") as f:
            f.write("\n" * 100)

        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK

    def test_no_trailing_newline(self, client, test_log_dir):
        """File without trailing newline."""
        filename = "no_trailing.log"
        filepath = test_log_dir / filename
        with open(filepath, "w") as f:
            f.write("line1\nline2\nline3")  # No final newline

        response = client.get("/logs", params={"filename": filename, "limit": 5})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert "line3" in data["lines"]

    def test_very_long_lines(self, client, test_log_dir):
        """File with extremely long lines."""
        filename = "long_lines.log"
        filepath = test_log_dir / filename
        long_line = "x" * 100000  # 100KB line
        with open(filepath, "w") as f:
            f.write(f"{long_line}\nshort\n{long_line}")

        response = client.get("/logs", params={"filename": filename, "limit": 3})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert len(data["lines"]) <= 3

    def test_binary_content(self, client, test_log_dir):
        """File with binary content mixed with text."""
        filename = "binary_mixed.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write(b"normal line\n")
            f.write(b"\x00\x01\x02\x03\x04\x05\n")  # Binary bytes
            f.write(b"another normal line\n")

        response = client.get("/logs", params={"filename": filename})
        # Should handle gracefully (might error or return partial)
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.INTERNAL_SERVER_ERROR)

    def test_null_bytes_in_content(self, client, test_log_dir):
        """File with null bytes in content."""
        filename = "null_bytes.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write(b"before\x00after\n")
            f.write(b"normal line\n")

        response = client.get("/logs", params={"filename": filename})
        # Should handle gracefully
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.INTERNAL_SERVER_ERROR)

    def test_control_characters(self, client, log_file):
        """File with various control characters."""
        lines = [
            "normal line",
            "line\twith\ttabs",
            "line\rwith\rcarriage\rreturns",
            "line\x1b[31mwith\x1b[0m ansi codes",
            "line with bell \x07",
            "line with backspace \x08",
        ]
        filename = log_file(lines)

        response = client.get("/logs", params={"filename": filename, "limit": 10})
        assert response.status_code == HTTPStatus.OK

    def test_unicode_bom(self, client, test_log_dir):
        """File with UTF-8 BOM."""
        filename = "bom.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write(b"\xef\xbb\xbf")  # UTF-8 BOM
            f.write("line after BOM\n".encode("utf-8"))

        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK


class TestEncodingEdgeCases:
    """Test handling of various encodings."""

    def test_utf8_valid(self, client, log_file):
        """Valid UTF-8 content."""
        lines = [
            "English text",
            "日本語テキスト",
            "العربية",
            "Emoji: 🎉🔥💻",
            "Mixed: Hello 世界 مرحبا",
        ]
        filename = log_file(lines)

        response = client.get("/logs", params={"filename": filename, "limit": 10})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert any("日本語" in line for line in data["lines"])

    def test_latin1_file(self, client, test_log_dir):
        """File encoded in Latin-1 (will fail UTF-8 decode)."""
        filename = "latin1.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write("café résumé naïve\n".encode("latin-1"))

        response = client.get("/logs", params={"filename": filename})
        # Should handle gracefully - either decode error or replacement chars
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.INTERNAL_SERVER_ERROR)

    def test_mixed_encoding(self, client, test_log_dir):
        """File with mixed encodings (broken scenario)."""
        filename = "mixed_encoding.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write("UTF-8: 日本語\n".encode("utf-8"))
            f.write(b"Latin-1: caf\xe9\n")  # Latin-1 é as bytes
            f.write("More UTF-8: 你好\n".encode("utf-8"))

        response = client.get("/logs", params={"filename": filename})
        # Should handle gracefully
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.INTERNAL_SERVER_ERROR)

    def test_invalid_utf8_sequences(self, client, test_log_dir):
        """File with invalid UTF-8 byte sequences."""
        filename = "bad_utf8.log"
        filepath = test_log_dir / filename
        with open(filepath, "wb") as f:
            f.write(b"valid line\n")
            f.write(b"\x80\x81\x82\n")  # Invalid UTF-8 continuation bytes
            f.write(b"\xfe\xff\n")  # Invalid UTF-8 bytes
            f.write(b"another valid line\n")

        response = client.get("/logs", params={"filename": filename})
        # Should handle gracefully
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.INTERNAL_SERVER_ERROR)


class TestFileSizeEdgeCases:
    """Test handling of various file sizes."""

    def test_exactly_block_size(self, client, test_log_dir):
        """File exactly 1024 bytes (default block size)."""
        filename = "exact_block.log"
        filepath = test_log_dir / filename

        # Create file of exactly 1024 bytes
        with open(filepath, "w") as f:
            content = "x" * 1020 + "\n" * 4  # 1024 bytes
            f.write(content)

        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK

    def test_one_byte_file(self, client, test_log_dir):
        """File with exactly one byte."""
        filename = "one_byte.log"
        filepath = test_log_dir / filename
        with open(filepath, "w") as f:
            f.write("x")

        response = client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.OK

    def test_multimegabyte_file(self, client, test_log_dir):
        """Large multi-megabyte file."""
        filename = "large.log"
        filepath = test_log_dir / filename

        # Create 10MB file
        line = "x" * 99 + "\n"  # 100 bytes per line
        with open(filepath, "w") as f:
            for _ in range(100000):  # 10MB
                f.write(line)

        response = client.get("/logs", params={"filename": filename, "limit": 10})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert len(data["lines"]) == 10


class TestConcurrencyAndRace:
    """Test concurrent access and race conditions."""

    def test_file_deleted_during_request(self, client, test_log_dir, monkeypatch):
        """Handle file being deleted during read."""
        # This is hard to test deterministically, but we can test the error path
        response = client.get("/logs", params={"filename": "nonexistent.log"})
        assert response.status_code == HTTPStatus.NOT_FOUND

    def test_multiple_concurrent_requests(self, client, log_file):
        """Multiple concurrent requests to same file."""
        import concurrent.futures

        lines = [f"line {i}" for i in range(100)]
        filename = log_file(lines)

        def make_request():
            return client.get("/logs", params={"filename": filename, "limit": 10})

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(make_request) for _ in range(20)]
            results = [f.result() for f in futures]

        # All requests should succeed
        assert all(r.status_code == HTTPStatus.OK for r in results)

    def test_concurrent_different_files(self, client, log_file):
        """Concurrent requests to different files."""
        import concurrent.futures

        files = []
        for i in range(5):
            filename = log_file([f"file {i} line {j}" for j in range(10)], filename=f"file{i}.log")
            files.append(filename)

        def make_request(fname):
            return client.get("/logs", params={"filename": fname, "limit": 5})

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(make_request, f) for f in files]
            results = [f.result() for f in futures]

        assert all(r.status_code == HTTPStatus.OK for r in results)


class TestMultiFileEndpoint:
    """Test the /logs/multi endpoint edge cases."""

    def test_empty_filenames(self, client):
        """Empty filenames parameter."""
        response = client.get("/logs/multi", params={"filenames": ""})
        assert response.status_code == HTTPStatus.BAD_REQUEST

    def test_only_commas(self, client):
        """Filenames with only commas."""
        response = client.get("/logs/multi", params={"filenames": ",,,"})
        assert response.status_code == HTTPStatus.BAD_REQUEST

    def test_too_many_files(self, client):
        """More than 10 files."""
        filenames = ",".join([f"file{i}.log" for i in range(15)])
        response = client.get("/logs/multi", params={"filenames": filenames})
        assert response.status_code == HTTPStatus.BAD_REQUEST

    def test_exactly_10_files(self, client, log_file):
        """Exactly 10 files (at limit)."""
        files = []
        for i in range(10):
            filename = log_file([f"content {i}"], filename=f"multi{i}.log")
            files.append(filename)

        response = client.get("/logs/multi", params={"filenames": ",".join(files)})
        assert response.status_code == HTTPStatus.OK

    def test_duplicate_filenames(self, client, log_file):
        """Same filename repeated multiple times."""
        filename = log_file(["test content"])
        filenames = ",".join([filename] * 5)
        response = client.get("/logs/multi", params={"filenames": filenames})
        assert response.status_code == HTTPStatus.OK

    def test_mix_valid_invalid(self, client, log_file):
        """Mix of valid and invalid filenames."""
        valid = log_file(["valid content"])
        filenames = f"{valid},../etc/passwd,nonexistent.log"
        response = client.get("/logs/multi", params={"filenames": filenames})
        # Should return results with errors for invalid ones
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert "results" in data


class TestLimitEdgeCases:
    """Test limit parameter edge cases."""

    @pytest.mark.parametrize("limit", [1, 2, 10, 100, 500, 999, 1000])
    def test_valid_limits(self, client, log_file, limit):
        """Test various valid limit values."""
        lines = [f"line {i}" for i in range(limit + 10)]
        filename = log_file(lines)

        response = client.get("/logs", params={"filename": filename, "limit": limit})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert len(data["lines"]) == limit

    @pytest.mark.parametrize("limit", [0, -1, -100, 1001, 10000, 999999])
    def test_invalid_limits(self, client, log_file, limit):
        """Test invalid limit values."""
        filename = log_file(["test"])
        response = client.get("/logs", params={"filename": filename, "limit": limit})
        assert response.status_code in (HTTPStatus.BAD_REQUEST, HTTPStatus.UNPROCESSABLE_ENTITY)

    def test_limit_larger_than_file(self, client, log_file):
        """Request more lines than file contains."""
        lines = ["line 1", "line 2", "line 3"]
        filename = log_file(lines)

        response = client.get("/logs", params={"filename": filename, "limit": 1000})
        assert response.status_code == HTTPStatus.OK
        data = response.json()
        assert len(data["lines"]) == 3

    def test_float_limit(self, client, log_file):
        """Float value for limit."""
        filename = log_file(["test"])
        response = client.get("/logs", params={"filename": filename, "limit": 10.5})
        # FastAPI should reject or truncate
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.UNPROCESSABLE_ENTITY)

    def test_string_limit(self, client, log_file):
        """String value for limit."""
        filename = log_file(["test"])
        response = client.get("/logs", params={"filename": filename, "limit": "abc"})
        assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
