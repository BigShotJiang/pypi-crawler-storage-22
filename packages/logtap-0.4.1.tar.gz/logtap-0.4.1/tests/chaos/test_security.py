"""Security chaos tests for logtap.

These tests attempt to break logtap's security measures:
- Path traversal bypasses
- Authentication bypasses
- Regex DoS attacks
- Input injection
"""

from http import HTTPStatus

import pytest


class TestPathTraversalAttacks:
    """Attempt to bypass path traversal protections."""

    @pytest.mark.parametrize(
        "malicious_filename",
        [
            # Basic traversal
            "../etc/passwd",
            "..\\etc\\passwd",
            "../../etc/passwd",
            "....//....//etc/passwd",
            # Unicode dots with separator - these contain actual "/" characters
            "\u002e\u002e/etc/passwd",  # Unicode dots (U+002E is period)
            # Note: URL-encoded patterns like "..%2fetc%2fpasswd" are NOT included here
            # because the test client double-encodes them (% -> %25), so they become
            # literal strings without separators and return 404 instead of 400.
            # Null byte injection (could bypass extension checks)
            "../etc/passwd%00",
            "../etc/passwd\x00",
            "../etc/passwd%00.log",
            # Mixed slashes
            "..\\..\\etc\\passwd",
            "../..\\etc/passwd",
            "..\\../etc\\passwd",
            # Absolute paths (Unix)
            "/etc/passwd",
            "//etc/passwd",
            "///etc/passwd",
            # Absolute paths (Windows)
            "C:\\Windows\\System32\\config\\SAM",
            "C:/Windows/System32/config/SAM",
            "\\\\server\\share\\file",
            # Path with valid prefix but traversal
            "logs/../../../etc/passwd",
            "./logs/../../../etc/passwd",
            "valid.log/../../../etc/passwd",
            # Trailing traversal
            "passwd/../../..",
            # Just dots - only "." and ".." are special entries
            "..",
            # Control characters
            ".\x00./etc/passwd",
            "..\t/etc/passwd",
            "..\n./etc/passwd",
            # With query-like suffixes (in case of poor parsing)
            "../etc/passwd?foo=bar",
            "../etc/passwd#fragment",
        ],
    )
    def test_path_traversal_blocked(self, client, malicious_filename):
        """Ensure all path traversal attempts are blocked."""
        response = client.get("/logs", params={"filename": malicious_filename})
        # Should be 400 (bad request) not 404 (not found) - we want to reject, not attempt access
        assert response.status_code in (
            HTTPStatus.BAD_REQUEST,
            HTTPStatus.UNPROCESSABLE_ENTITY,
        ), f"Path traversal not blocked for: {malicious_filename!r}"


class TestAuthenticationAttacks:
    """Attempt to bypass authentication."""

    @pytest.fixture
    def protected_app(self, test_log_dir, monkeypatch):
        """Create an app with API key authentication enabled."""
        monkeypatch.setenv("LOGTAP_LOG_DIRECTORY", str(test_log_dir))
        monkeypatch.setenv("LOGTAP_TESTING", "true")
        monkeypatch.setenv("LOGTAP_API_KEY", "super-secret-key-12345")

        from logtap.api.dependencies import get_settings

        get_settings.cache_clear()

        from logtap.api.app import create_app

        return create_app()

    @pytest.fixture
    def protected_client(self, protected_app):
        """Create a client for the protected app."""
        from fastapi.testclient import TestClient

        return TestClient(protected_app)

    def test_no_key_rejected(self, protected_client, log_file):
        """Request without API key should be rejected."""
        filename = log_file(["test log"])
        response = protected_client.get("/logs", params={"filename": filename})
        assert response.status_code == HTTPStatus.UNAUTHORIZED

    def test_wrong_key_rejected(self, protected_client, log_file):
        """Request with wrong API key should be rejected."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs", params={"filename": filename}, headers={"X-API-Key": "wrong-key"}
        )
        assert response.status_code == HTTPStatus.UNAUTHORIZED

    def test_empty_key_rejected(self, protected_client, log_file):
        """Request with empty API key should be rejected."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs", params={"filename": filename}, headers={"X-API-Key": ""}
        )
        assert response.status_code == HTTPStatus.UNAUTHORIZED

    def test_partial_key_rejected(self, protected_client, log_file):
        """Request with partial API key should be rejected."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs",
            params={"filename": filename},
            headers={"X-API-Key": "super-secret"},  # Partial match
        )
        assert response.status_code == HTTPStatus.UNAUTHORIZED

    def test_key_with_extra_chars_rejected(self, protected_client, log_file):
        """Request with extra characters in API key should be rejected."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs",
            params={"filename": filename},
            headers={"X-API-Key": "super-secret-key-12345-extra"},
        )
        assert response.status_code == HTTPStatus.UNAUTHORIZED

    def test_correct_key_accepted(self, protected_client, log_file):
        """Request with correct API key should be accepted."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs", params={"filename": filename}, headers={"X-API-Key": "super-secret-key-12345"}
        )
        assert response.status_code == HTTPStatus.OK

    @pytest.mark.parametrize(
        "header_name",
        [
            "x-api-key",  # lowercase
            "X-Api-Key",  # mixed case
            "X-API-KEY",  # all caps
            "x-API-key",  # random case
        ],
    )
    def test_header_case_sensitivity(self, protected_client, log_file, header_name):
        """HTTP headers should be case-insensitive."""
        filename = log_file(["test log"])
        response = protected_client.get(
            "/logs", params={"filename": filename}, headers={header_name: "super-secret-key-12345"}
        )
        # HTTP headers are case-insensitive per spec
        assert response.status_code == HTTPStatus.OK


class TestRegexDoS:
    """Test for ReDoS (Regular Expression Denial of Service) vulnerabilities."""

    @pytest.mark.parametrize(
        "evil_pattern",
        [
            # Classic ReDoS patterns - exponential backtracking
            "(a+)+$",
            "([a-zA-Z]+)*$",
            "(a|aa)+$",
            "(a|a?)+$",
            "(.*a){10}",
            "^(a+)+b$",
            # Nested quantifiers
            "((a+)+)+",
            "(([a-z])+.)+",
            # Alternation with overlap
            "(a|ab|abc)+",
            # Long patterns
            "a" * 100,
        ],
    )
    def test_regex_patterns_dont_hang(self, client, log_file, evil_pattern):
        """Ensure regex patterns don't cause excessive CPU usage."""
        import time

        # Create a file with content designed to trigger backtracking
        lines = ["a" * 50 + "x" for _ in range(10)]
        filename = log_file(lines)

        start = time.time()
        response = client.get(
            "/logs", params={"filename": filename, "regex": evil_pattern, "limit": 10}
        )
        elapsed = time.time() - start

        # Should complete in reasonable time (< 5 seconds)
        # A vulnerable regex could take minutes or hours
        assert elapsed < 5.0, f"Regex took too long: {elapsed}s for pattern: {evil_pattern}"

        # Should either succeed or fail gracefully (invalid regex)
        assert response.status_code in (HTTPStatus.OK, HTTPStatus.BAD_REQUEST)

    def test_invalid_regex_handled_gracefully(self, client, log_file):
        """Invalid regex patterns should not crash the server."""
        filename = log_file(["test log"])

        invalid_patterns = [
            "[",  # Unclosed bracket
            "(",  # Unclosed group
            "*",  # Nothing to repeat
            "?",  # Nothing to repeat
            "+",  # Nothing to repeat
            "\\",  # Trailing backslash
            "[z-a]",  # Bad range
            "(?P<>)",  # Empty group name
        ]

        for pattern in invalid_patterns:
            response = client.get("/logs", params={"filename": filename, "regex": pattern})
            # Should not crash - either return empty results or error
            assert response.status_code in (
                HTTPStatus.OK,
                HTTPStatus.BAD_REQUEST,
            ), f"Crash on invalid regex: {pattern!r}"


class TestInputInjection:
    """Test for various injection attacks."""

    @pytest.mark.parametrize(
        "malicious_term",
        [
            # Shell injection attempts
            "; rm -rf /",
            "| cat /etc/passwd",
            "$(whoami)",
            "`id`",
            "&& cat /etc/passwd",
            "|| true",
            # SQL injection attempts (shouldn't apply but test anyway)
            "' OR '1'='1",
            "'; DROP TABLE logs; --",
            "1; SELECT * FROM users",
            # LDAP injection
            "*)(uid=*))(|(uid=*",
            # XPath injection
            "' or '1'='1",
            # Null bytes
            "test\x00evil",
            # Format string attacks
            "%s%s%s%s%s%s%s%s%s%s",
            "%n%n%n%n%n%n%n%n%n%n",
            "{0}{1}{2}",
            # Very long input (up to limit)
            "a" * 100,
        ],
    )
    def test_search_term_injection_safe(self, client, log_file, malicious_term):
        """Search terms should be treated as literal text, not executed."""
        lines = [malicious_term, "normal log line"]
        filename = log_file(lines)

        response = client.get("/logs", params={"filename": filename, "term": malicious_term})

        # Should either work (treating it as literal) or be rejected as too long
        if len(malicious_term) <= 100:
            assert response.status_code == HTTPStatus.OK
            data = response.json()
            # If the term is in the file, it should be found
            assert malicious_term in data["lines"] or data["lines"] == []
        else:
            assert response.status_code == HTTPStatus.BAD_REQUEST
