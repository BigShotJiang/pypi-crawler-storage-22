"""Test fixtures for logtap."""
