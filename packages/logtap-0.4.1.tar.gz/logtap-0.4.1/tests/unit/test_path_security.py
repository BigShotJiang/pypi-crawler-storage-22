"""
Security tests for path traversal prevention.

These tests prove that resolve_safe_path correctly rejects all known
path traversal attack vectors under real filesystem conditions.
"""

import os
from pathlib import Path

import pytest
from logtap.core.validation import resolve_safe_path, resolve_safe_path_checked


class TestPathTraversalPrevention:
    """Tests for directory traversal attack prevention."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        """Create a base directory with a test file."""
        log_file = tmp_path / "test.log"
        log_file.write_text("test content")
        return str(tmp_path)

    def test_valid_filename(self, base_dir):
        """Valid filename should be accepted."""
        # Create the file first
        Path(base_dir, "valid.log").write_text("content")
        result = resolve_safe_path(base_dir, "valid.log", require_exists=True)
        assert result is not None
        assert result.endswith("valid.log")

    def test_traversal_dotdot(self, base_dir):
        """../ traversal should be rejected (due to separator, not "..")."""
        assert resolve_safe_path(base_dir, "../etc/passwd") is None
        assert resolve_safe_path(base_dir, "../../etc/passwd") is None
        assert resolve_safe_path(base_dir, "foo/../../../etc/passwd") is None

    def test_dotdot_in_filename_allowed(self, base_dir):
        """Filenames containing '..' (not as path component) should be allowed."""
        # Create files with ".." in name
        Path(base_dir, "my..log").write_text("content")
        Path(base_dir, "v1..bak").write_text("content")
        # These should be allowed since they don't contain path separators
        assert resolve_safe_path(base_dir, "my..log") is not None
        assert resolve_safe_path(base_dir, "v1..bak") is not None

    def test_traversal_dotdot_windows(self, base_dir):
        r"""..\ traversal (Windows style) should be rejected."""
        assert resolve_safe_path(base_dir, "..\\etc\\passwd") is None
        assert resolve_safe_path(base_dir, "..\\..\\etc\\passwd") is None

    def test_traversal_mixed_separators(self, base_dir):
        """Mixed path separators should be rejected."""
        assert resolve_safe_path(base_dir, "../..\\etc/passwd") is None
        assert resolve_safe_path(base_dir, "..\\../etc\\passwd") is None

    def test_absolute_path_unix(self, base_dir):
        """Absolute Unix paths should be rejected."""
        assert resolve_safe_path(base_dir, "/etc/passwd") is None
        assert resolve_safe_path(base_dir, "/tmp/evil") is None

    def test_absolute_path_windows(self, base_dir):
        """Absolute Windows paths should be rejected."""
        assert resolve_safe_path(base_dir, "C:\\Windows\\System32") is None
        assert resolve_safe_path(base_dir, "D:\\evil") is None
        assert resolve_safe_path(base_dir, "\\\\server\\share") is None

    def test_path_separator_forward_slash(self, base_dir):
        """Forward slash in filename should be rejected."""
        assert resolve_safe_path(base_dir, "foo/bar") is None
        assert resolve_safe_path(base_dir, "subdir/file.log") is None

    def test_path_separator_backslash(self, base_dir):
        """Backslash in filename should be rejected."""
        assert resolve_safe_path(base_dir, "foo\\bar") is None
        assert resolve_safe_path(base_dir, "subdir\\file.log") is None


class TestNullByteInjection:
    """Tests for null byte injection attacks."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        return str(tmp_path)

    def test_null_byte_in_filename(self, base_dir):
        """NUL byte in filename should be rejected."""
        assert resolve_safe_path(base_dir, "file.log\x00../../etc/passwd") is None
        assert resolve_safe_path(base_dir, "file\x00.log") is None
        assert resolve_safe_path(base_dir, "\x00file.log") is None


class TestControlCharacters:
    """Tests for control character injection."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        return str(tmp_path)

    def test_control_char_start(self, base_dir):
        """Control characters (0x00-0x1F) should be rejected."""
        for i in range(0x20):
            filename = f"file{chr(i)}.log"
            assert resolve_safe_path(base_dir, filename) is None, f"Failed for char 0x{i:02x}"

    def test_control_char_del(self, base_dir):
        """DEL character (0x7F) should be rejected."""
        assert resolve_safe_path(base_dir, "file\x7f.log") is None


class TestSymlinkEscape:
    """Tests for symlink escape attacks."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        """Create base directory with a valid file."""
        log_file = tmp_path / "valid.log"
        log_file.write_text("valid content")
        return str(tmp_path)

    @pytest.mark.skipif(os.name == "nt", reason="Symlinks require admin on Windows")
    def test_symlink_to_outside_dir(self, tmp_path):
        """Symlink pointing outside base should be rejected."""
        # Create separate base and outside directories
        base_dir = tmp_path / "base"
        base_dir.mkdir()
        outside_dir = tmp_path / "outside"
        outside_dir.mkdir()
        secret_file = outside_dir / "secret.txt"
        secret_file.write_text("secret content")

        # Create symlink inside base_dir pointing to outside_dir
        symlink_path = base_dir / "escape"
        symlink_path.symlink_to(outside_dir)

        # Attempting to access via symlink should fail
        # The symlink resolves to outside_dir, which is outside base_dir
        result = resolve_safe_path(str(base_dir), "escape")
        # commonpath check should reject this - result must be None
        assert result is None, f"Symlink escape not caught: {result}"

    @pytest.mark.skipif(os.name == "nt", reason="Symlinks require admin on Windows")
    def test_symlink_to_etc(self, tmp_path):
        """Symlink to /etc should be rejected."""
        if not os.path.exists("/etc"):
            pytest.skip("No /etc directory")

        base_dir = tmp_path / "base"
        base_dir.mkdir()

        symlink_path = base_dir / "etc_link"
        try:
            symlink_path.symlink_to("/etc")
        except OSError:
            pytest.skip("Cannot create symlink")

        # Symlink resolves to /etc which is outside base_dir
        # commonpath check should reject this
        result = resolve_safe_path(str(base_dir), "etc_link")
        assert result is None, f"Symlink to /etc not caught: {result}"


class TestPrefixCollision:
    """Tests for path prefix collision attacks."""

    def test_prefix_collision_basic(self, tmp_path):
        """Base /var/log should not match /var/logs/evil."""
        # Create two directories: log and logs
        log_dir = tmp_path / "log"
        logs_dir = tmp_path / "logs"
        log_dir.mkdir()
        logs_dir.mkdir()

        # Create evil file in logs (not log)
        evil_file = logs_dir / "evil.txt"
        evil_file.write_text("evil content")

        # Even if somehow the path resolved to logs_dir, commonpath should catch it
        # But our validation rejects separators, so "s/evil.txt" is rejected anyway
        result = resolve_safe_path(str(log_dir), "s/evil.txt")
        assert result is None  # Rejected due to separator

    def test_prefix_collision_commonpath(self, tmp_path):
        """Verify commonpath behavior with similar prefixes."""
        log_dir = tmp_path / "log"
        logs_dir = tmp_path / "logs"
        log_dir.mkdir()
        logs_dir.mkdir()

        # Verify commonpath correctly identifies these as different
        common = os.path.commonpath([str(log_dir), str(logs_dir)])
        assert common == str(tmp_path)  # Common ancestor is parent, not log_dir


class TestEmptyAndEdgeCases:
    """Tests for empty strings and edge cases."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        return str(tmp_path)

    def test_empty_filename(self, base_dir):
        """Empty filename should be rejected."""
        assert resolve_safe_path(base_dir, "") is None

    def test_whitespace_only(self, base_dir):
        """Whitespace-only filename should be allowed (if valid on filesystem)."""
        # This depends on OS - some allow spaces in filenames
        # But control chars (like tab, newline) should be rejected
        assert resolve_safe_path(base_dir, "\t") is None
        assert resolve_safe_path(base_dir, "\n") is None

    def test_dot_filename(self, base_dir):
        """Single dot should be rejected (special directory entry)."""
        assert resolve_safe_path(base_dir, ".") is None

    def test_double_dot_alone(self, base_dir):
        """Double dot alone should be rejected (special directory entry)."""
        assert resolve_safe_path(base_dir, "..") is None


class TestResolvedPathChecked:
    """Tests for the detailed error reporting function."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        return str(tmp_path)

    def test_error_reason_empty(self, base_dir):
        """Empty filename should return specific error."""
        path, error = resolve_safe_path_checked(base_dir, "")
        assert path is None
        assert "empty" in error.lower()

    def test_error_reason_nul(self, base_dir):
        """NUL byte should return specific error."""
        path, error = resolve_safe_path_checked(base_dir, "file\x00.log")
        assert path is None
        assert "nul" in error.lower()

    def test_error_reason_separator_dotdot(self, base_dir):
        """Path with separator (../) should return separator error."""
        path, error = resolve_safe_path_checked(base_dir, "../etc")
        assert path is None
        assert "separator" in error.lower()

    def test_error_reason_special_entry(self, base_dir):
        """Special directory entry should return specific error."""
        path, error = resolve_safe_path_checked(base_dir, "..")
        assert path is None
        assert "special" in error.lower() or "directory" in error.lower()

    def test_error_reason_separator_subpath(self, base_dir):
        """Path with separator (subpath) should return separator error."""
        path, error = resolve_safe_path_checked(base_dir, "foo/bar")
        assert path is None
        assert "separator" in error.lower()

    def test_success_no_error(self, base_dir):
        """Valid path should return empty error string."""
        Path(base_dir, "valid.log").write_text("content")
        path, error = resolve_safe_path_checked(base_dir, "valid.log")
        assert path is not None
        assert error == ""


class TestRequireExists:
    """Tests for the require_exists parameter."""

    @pytest.fixture
    def base_dir(self, tmp_path):
        log_file = tmp_path / "exists.log"
        log_file.write_text("content")
        return str(tmp_path)

    def test_existing_file(self, base_dir):
        """Existing regular file should pass with require_exists=True."""
        result = resolve_safe_path(base_dir, "exists.log", require_exists=True)
        assert result is not None

    def test_nonexistent_file(self, base_dir):
        """Non-existent file should fail with require_exists=True."""
        result = resolve_safe_path(base_dir, "nonexistent.log", require_exists=True)
        assert result is None

    def test_nonexistent_file_without_flag(self, base_dir):
        """Non-existent file should pass without require_exists flag."""
        result = resolve_safe_path(base_dir, "nonexistent.log", require_exists=False)
        assert result is not None

    def test_directory_rejected(self, base_dir, tmp_path):
        """Directory should be rejected with require_exists=True."""
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        result = resolve_safe_path(base_dir, "subdir", require_exists=True)
        assert result is None


class TestURLEncodedInputs:
    """Tests for URL-encoded attack strings.

    Note: URL decoding happens at the web framework level before reaching
    resolve_safe_path. These tests verify that decoded strings are still caught.
    """

    @pytest.fixture
    def base_dir(self, tmp_path):
        return str(tmp_path)

    def test_decoded_dotdot(self, base_dir):
        """Decoded %2e%2e%2f (../) should be rejected."""
        # FastAPI/Starlette decode this before it reaches our code
        assert resolve_safe_path(base_dir, "../etc/passwd") is None

    def test_decoded_separator(self, base_dir):
        """Decoded %2f (/) should be rejected."""
        assert resolve_safe_path(base_dir, "foo/bar") is None
