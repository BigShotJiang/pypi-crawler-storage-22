"""Tests for run store."""

from pathlib import Path

from logtap.core.runs import Run, RunStore


class TestRun:
    """Tests for single Run."""

    def test_create_run(self, tmp_path: Path):
        """Test creating a new run."""
        run = Run("test-run", tmp_path)
        assert run.id == "test-run"
        assert run.metadata.lines_count == 0
        assert run.cursor_latest == -1
        assert (tmp_path / "test-run" / "meta.json").exists()

    def test_append_line(self, tmp_path: Path):
        """Test appending lines."""
        run = Run("test-run", tmp_path)

        line1 = run.append("first line")
        assert line1.cursor == 0
        assert line1.line == "first line"

        line2 = run.append("second line")
        assert line2.cursor == 1

        assert run.cursor_latest == 1
        assert run.metadata.lines_count == 2

    def test_get_lines_tail(self, tmp_path: Path):
        """Test getting last N lines."""
        run = Run("test-run", tmp_path)
        for i in range(100):
            run.append(f"line {i}")

        lines, gap = run.get_lines(tail=10)
        assert len(lines) == 10
        assert gap is False
        assert lines[0].line == "line 90"
        assert lines[-1].line == "line 99"

    def test_get_lines_since(self, tmp_path: Path):
        """Test getting lines since cursor."""
        run = Run("test-run", tmp_path)
        for i in range(10):
            run.append(f"line {i}")

        lines, gap = run.get_lines(since=5)
        assert len(lines) == 4  # cursors 6, 7, 8, 9
        assert gap is False
        assert lines[0].cursor == 6

    def test_gap_detection(self, tmp_path: Path):
        """Test gap detection when cursor too old."""
        run = Run("test-run", tmp_path, buffer_lines=5)
        for i in range(20):
            run.append(f"line {i}")

        # Cache only holds last 5 lines (cursors 15-19)
        lines, gap = run.get_lines(since=5)
        assert gap is True
        # Should start from earliest available
        assert lines[0].cursor >= 15

    def test_tags(self, tmp_path: Path):
        """Test setting tags."""
        run = Run("test-run", tmp_path)

        # Set initial tags
        err = run.set_tags({"node": "gpu1", "rank": "0"})
        assert err is None
        assert run.metadata.tags == {"node": "gpu1", "rank": "0"}

        # Merge new tags
        err = run.set_tags({"experiment": "test"})
        assert err is None
        assert run.metadata.tags["experiment"] == "test"
        assert run.metadata.tags["node"] == "gpu1"

    def test_tag_update(self, tmp_path: Path):
        """Test that tags can be updated (no conflict for multi-node support)."""
        run = Run("test-run", tmp_path)

        run.set_tags({"node": "gpu1"})
        err = run.set_tags({"node": "gpu2"})
        # Tags should not conflict - per-line tags support multi-node
        assert err is None
        # Metadata tracks last value for discoverability
        assert run.metadata.tags["node"] == "gpu2"

    def test_invalid_tag_key(self, tmp_path: Path):
        """Test invalid tag key rejection."""
        run = Run("test-run", tmp_path)

        err = run.set_tags({"invalid key": "value"})
        assert err is not None

    def test_persistence(self, tmp_path: Path):
        """Test run persists and reloads."""
        run = Run("test-run", tmp_path)
        run.append("line 1")
        run.append("line 2")
        run.set_tags({"node": "gpu1"})
        run._save_metadata()

        # Reload
        run2 = Run("test-run", tmp_path)
        assert run2.metadata.lines_count == 2
        assert run2.metadata.tags == {"node": "gpu1"}

        # Cache should be populated
        lines, _ = run2.get_lines(tail=10)
        assert len(lines) == 2


class TestRunStore:
    """Tests for RunStore."""

    def test_create_store(self, tmp_path: Path):
        """Test creating store."""
        store = RunStore(tmp_path)
        assert store.data_dir == tmp_path

    def test_get_or_create(self, tmp_path: Path):
        """Test get_or_create run."""
        store = RunStore(tmp_path)

        run, created = store.get_or_create("run1")
        assert created is True
        assert run.id == "run1"

        run2, created2 = store.get_or_create("run1")
        assert created2 is False
        assert run2 is run

    def test_list_runs(self, tmp_path: Path):
        """Test listing runs."""
        store = RunStore(tmp_path)
        store.get_or_create("run1")
        store.get_or_create("run2")

        runs = store.list_runs()
        assert len(runs) == 2

    def test_persistence(self, tmp_path: Path):
        """Test store persists and reloads runs."""
        store = RunStore(tmp_path)
        run, _ = store.get_or_create("run1")
        run.append("test line")
        run._save_metadata()

        # Create new store instance
        store2 = RunStore(tmp_path)
        run2 = store2.get("run1")
        assert run2 is not None
        assert run2.metadata.lines_count == 1

    def test_disk_limit(self, tmp_path: Path):
        """Test disk limit enforcement."""
        # 1KB limit
        store = RunStore(tmp_path, max_disk_mb=0.001)

        run1, _ = store.get_or_create("run1")
        for i in range(100):
            run1.append("x" * 100)  # ~10KB

        run1._save_metadata()

        # Should enforce limit
        store.enforce_disk_limit()
        # run1 should be deleted
        assert store.get("run1") is None
