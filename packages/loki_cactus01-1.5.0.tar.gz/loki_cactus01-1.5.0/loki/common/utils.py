from typing import LiteralString


def load_cookies(cookie_path: LiteralString | str | bytes):
    """
    读取 cookie 文本文件并解析为字典
    :param cookie_path: cookie 文件路径
    :return: cookie 键值对
    """
    with open(cookie_path, "r", encoding="utf-8") as f:
        cookie_txt = f.read()
    cookies = {}
    for line in cookie_txt.split(";"):
        if "=" in line:
            key, value = line.strip().split("=", 1)
            cookies[key] = value
    return cookies