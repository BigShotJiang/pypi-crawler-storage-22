import os

import pytest

from loki.scrapers.javdb import JavDB


@pytest.mark.skipif(
    os.environ.get("LOKI_JAVDB_INTEGRATION") != "1",
    reason="integration test (requires network/playwright browser)",
)
def test_search_integration():
    jdb = JavDB()
    try:
        res = jdb.search("PRED-427")
        assert isinstance(res, dict)
    finally:
        jdb.close()
