# Lola MCP Server

This MCP server allows MCP-compatible clients (Claude, OpenAI, Cursor, etc.)
to access Lola and HubSpot tools via MCP.

## Installation

pip install lola-mcp-server

## MCP Configuration

Add to your MCP config:

{
  "mcpServers": {
    "lola-suite": {
      "command": "lola-mcp-server",
      "env": {
        "LOLA_BASE_URL": "https://extraneous-blaine-seclusive.ngrok-free.dev",
        "LOLA_API_KEY": "SUPER_SECRET_KEY_123"
      }
    }
  }
}
