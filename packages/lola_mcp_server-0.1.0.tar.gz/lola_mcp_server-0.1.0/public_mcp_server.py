from mcp.server.fastmcp import FastMCP
import httpx
import os
import asyncio

mcp = FastMCP("Lola Suite MCP Bridge")

# Change only via ENV later (no code edits needed)
BASE_URL = os.getenv(
    "LOLA_BASE_URL",
    "https://extraneous-blaine-seclusive.ngrok-free.dev"
)

API_KEY = os.getenv("LOLA_API_KEY", "SUPER_SECRET_KEY_123")


def headers():
    return {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }


# ---------------- HEALTH CHECK ----------------

async def health_check():
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.get(f"{BASE_URL}/tools_lola", headers=headers())
            r.raise_for_status()
            print(" Connected to backend:", BASE_URL)
        except Exception as e:
            raise RuntimeError(
                f"Cannot reach backend at {BASE_URL}. "
                "Make sure FastAPI and ngrok are running."
            ) from e


# ---------------- HUBSPOT ----------------

@mcp.tool()
async def hubspot_list_tools():
    """List all HubSpot tools"""
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.get(f"{BASE_URL}/tools_hubspot", headers=headers())
        r.raise_for_status()
        return r.json()


@mcp.tool()
async def hubspot_call_tool(name: str, arguments: dict):
    """Call a HubSpot tool"""
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.post(
            f"{BASE_URL}/call_hubspot",
            json={"name": name, "arguments": arguments},
            headers=headers(),
        )
        r.raise_for_status()
        return r.json()


# ---------------- LOLA ----------------

@mcp.tool()
async def lola_list_tools():
    """List all Lola tools"""
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.get(f"{BASE_URL}/tools_lola", headers=headers())
        r.raise_for_status()
        return r.json()


@mcp.tool()
async def lola_call_tool(name: str, arguments: dict):
    """Call a Lola tool"""
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.post(
            f"{BASE_URL}/call_lola",
            json={"name": name, "arguments": arguments},
            headers=headers(),
        )
        r.raise_for_status()
        return r.json()


# ---------------- MAIN ----------------

def main():
    asyncio.run(health_check())
    mcp.run()


if __name__ == "__main__":
    main()
