# Lola MCP Server

This MCP server allows MCP-compatible clients (Claude, OpenAI, Cursor, etc.)
to access Lola and HubSpot tools via MCP.

## Installation

pip install lola-mcp-server

## MCP Configuration

Add to your MCP config:

{
  "mcpServers": {
    "lola-suite": {
      "command": "pipx",
      "args": ["run", "--no-cache", "lola-mcp-server"],
      "env": {
        "LOLA_API_BASE_URL": "https://extraneous-blaine-seclusive.ngrok-free.dev",
        "LOLA_ACCESS_TOKEN": "eyJwYXNzd29yZF9oYXNoIjogImQ3OTk4NzA1MWEyNTUyYWMxODk1ZTA2Yjk3ZDEyZDhjZmU1OTI0ODcyZjYxZGJhNTljMTU1NTJiY2M4MzJmOWUiLCAic2VsZWN0aW9ucyI6IHsibG9sYV9zZXJ2ZXIiOiBbImNyZWF0ZV9hcHBvaW50bWVudF90b29sIiwgImNhbGVuZGFyX3Rvb2wiXX0sICJ0aW1lc3RhbXAiOiAiMjAyNi0wMi0wM1QxODoxMzoyOS45NjU5MjciLCAidXNlcm5hbWUiOiAibmFnZW5kcmFiYWJ1azI5QGdtYWlsLmNvbSJ9.c43443c876af084ef8fec2a732583adb095eecac4f678998856f4daacf025f8c",
        "LOLA_AUTH_TOKEN": "lola-super-secret-bridge-key"
      }
    }
  }
}


eyJwYXNzd29yZF9oYXNoIjogImQ3OTk4NzA1MWEyNTUyYWMxODk1ZTA2Yjk3ZDEyZDhjZmU1OTI0ODcyZjYxZGJhNTljMTU1NTJiY2M4MzJmOWUiLCAic2VsZWN0aW9ucyI6IHsibG9sYV9zZXJ2ZXIiOiBbImNyZWF0ZV9hcHBvaW50bWVudF90b29sIiwgImNhbGVuZGFyX3Rvb2wiXX0sICJ0aW1lc3RhbXAiOiAiMjAyNi0wMi0wM1QxODoxMzoyOS45NjU5MjciLCAidXNlcm5hbWUiOiAibmFnZW5kcmFiYWJ1azI5QGdtYWlsLmNvbSJ9.c43443c876af084ef8fec2a732583adb095eecac4f678998856f4daacf025f8c
