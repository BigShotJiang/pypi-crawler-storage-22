from argparse import ArgumentParser

from mesalocal.mesalocal_types import MESALocalArguments
from mesalocal.mesalocal import MESALocal


def parse_args() -> MESALocalArguments:
    parser: ArgumentParser = ArgumentParser()
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Whether to print debug output",
    )
    return MESALocalArguments(**vars(parser.parse_args()))


def run() -> None:
    args: MESALocalArguments = parse_args()
    mesa_local: MESALocal = MESALocal(args.verbose)
    if mesa_local.unpack():
        mesa_local.serve()
