# long-horizon

Long-horizon planning and execution for autonomous agents.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install long-horizon
```

## Status

This package is in early planning. Watch this space.
