"""Long-horizon planning and execution for autonomous agents."""

__version__ = "0.0.1"
