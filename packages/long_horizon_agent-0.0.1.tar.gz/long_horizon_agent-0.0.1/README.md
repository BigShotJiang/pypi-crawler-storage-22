# long-horizon-agent

Long-horizon autonomous agent framework.

> This package is under active development by [Synth Laboratories](https://usesynth.ai).

## Installation

```bash
pip install long-horizon-agent
```

## Status

This package is in early planning. Watch this space.
