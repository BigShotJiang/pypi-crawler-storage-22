"""Long-horizon autonomous agent framework."""

__version__ = "0.0.1"
