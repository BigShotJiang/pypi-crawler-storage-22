-- Drop triggers

DROP TRIGGER IF EXISTS trg_workflows_updated;
DROP TRIGGER IF EXISTS trg_tasks_updated;