-- Drop events table

DROP TABLE IF EXISTS events;