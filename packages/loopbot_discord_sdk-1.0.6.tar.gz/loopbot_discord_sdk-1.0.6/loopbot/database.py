"""
Database class for persistent storage
Makes HTTP calls to the Loop API to store/retrieve data
"""

from typing import Any, Dict, Optional
import aiohttp


class Database:
    """Database for persistent storage via Loop API"""

    def __init__(self, client: Any):
        self._client = client

    async def get(self, key: str) -> Optional[Any]:
        """Get a value by key"""
        try:
            response = await self._client.request(
                "GET",
                f"/sdk/db/{key}",
            )
            return response.get("value")
        except Exception:
            return None

    async def set(self, key: str, value: Any) -> bool:
        """Set a value for a key"""
        try:
            response = await self._client.request(
                "POST",
                f"/sdk/db/{key}",
                {"value": value},
            )
            return response.get("success", False)
        except Exception:
            return False

    async def delete(self, key: str) -> bool:
        """Delete a key"""
        try:
            response = await self._client.request(
                "DELETE",
                f"/sdk/db/{key}",
            )
            return response.get("success", False)
        except Exception:
            return False

    async def get_all(self) -> Dict[str, Any]:
        """Get all data"""
        try:
            response = await self._client.request(
                "GET",
                "/sdk/db",
            )
            return response.get("data", {})
        except Exception:
            return {}

    async def clear(self) -> bool:
        """Clear all data"""
        try:
            response = await self._client.request(
                "DELETE",
                "/sdk/db",
            )
            return response.get("success", False)
        except Exception:
            return False
