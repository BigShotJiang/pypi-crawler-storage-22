"""
Base Context for all interaction types
"""

import time
from typing import Any, Dict, List, Optional, Union
import warnings

from ..types import Interaction, InteractionResponseType, DiscordUser, DiscordMember
from ..database import Database
from ..builders.embed import EmbedBuilder
from ..builders.action_row import ActionRowBuilder
from ..builders.modal import ModalBuilder
from ..permissions import has_permission as check_permission

# ANSI color codes for warnings
YELLOW = '\033[93m'
RESET = '\033[0m'


class BaseContext:
    """Base context for handling Discord interactions"""

    def __init__(
        self,
        interaction: Dict[str, Any],
        client: Any,
        application_id: str,
    ):
        self._interaction = interaction
        self._client = client
        self._application_id = application_id
        self._response: Optional[Dict[str, Any]] = None
        self._deferred = False
        self._has_responded = False
        self.db = Database(client)

    def _check_duplicate_response(self, method_name: str) -> bool:
        """Check if already responded and warn if so"""
        if self._has_responded:
            print(
                f"{YELLOW}[Loop SDK] ⚠️  Você já respondeu a esta interação! "
                f"Chamada duplicada de {method_name}() será ignorada.{RESET}"
            )
            return True
        self._has_responded = True
        return False

    @property
    def interaction_id(self) -> str:
        return self._interaction.get("id", "")

    @property
    def token(self) -> str:
        return self._interaction.get("token", "")

    @property
    def guild_id(self) -> Optional[str]:
        return self._interaction.get("guild_id")

    @property
    def channel_id(self) -> Optional[str]:
        return self._interaction.get("channel_id")

    @property
    def user(self) -> Optional[Dict[str, Any]]:
        """Get the user who triggered the interaction"""
        member = self._interaction.get("member")
        if member:
            return member.get("user")
        return self._interaction.get("user")

    @property
    def user_id(self) -> Optional[str]:
        user = self.user
        return user.get("id") if user else None

    @property
    def username(self) -> Optional[str]:
        user = self.user
        return user.get("username") if user else None

    @property
    def member(self) -> Optional[Dict[str, Any]]:
        return self._interaction.get("member")

    @property
    def locale(self) -> Optional[str]:
        return self._interaction.get("locale")

    @property
    def response(self) -> Optional[Dict[str, Any]]:
        return self._response

    @property
    def is_deferred(self) -> bool:
        return self._deferred

    # ==================== UTILITY METHODS ====================

    def has_permission(self, permission: str) -> bool:
        """
        Check if the member has a specific permission
        
        Args:
            permission: Permission to check (e.g., 'ADMINISTRATOR', 'MANAGE_MESSAGES')
        
        Returns:
            True if the member has the permission
        """
        member = self.member
        if not member:
            return False
        permissions = member.get("permissions")
        if not permissions:
            return False
        return check_permission(permissions, permission)

    async def cooldown(self, key: str, seconds: int) -> bool:
        """
        Check if the user is in cooldown. If not, applies the cooldown.
        
        Args:
            key: Unique key for this cooldown (e.g., command name)
            seconds: Cooldown duration in seconds
        
        Returns:
            True if user is in cooldown (should block), False if ok to proceed
        """
        cooldown_key = f"cooldown:{key}:{self.user_id}"
        now = int(time.time() * 1000)
        
        last_use = await self.db.get(cooldown_key)
        
        if last_use:
            elapsed = (now - last_use) / 1000
            if elapsed < seconds:
                return True  # Still in cooldown
        
        # Set new cooldown
        await self.db.set(cooldown_key, now)
        return False  # Not in cooldown

    async def get_cooldown_remaining(self, key: str, seconds: int) -> int:
        """
        Get remaining cooldown time in seconds
        
        Args:
            key: Unique key for this cooldown
            seconds: Original cooldown duration
        
        Returns:
            Remaining seconds, or 0 if not in cooldown
        """
        cooldown_key = f"cooldown:{key}:{self.user_id}"
        now = int(time.time() * 1000)
        
        last_use = await self.db.get(cooldown_key)
        
        if last_use:
            elapsed = (now - last_use) / 1000
            remaining = seconds - elapsed
            return int(remaining) if remaining > 0 else 0
        
        return 0

    def reply(
        self,
        content: Optional[str] = None,
        embeds: Optional[List[Union[Dict[str, Any], EmbedBuilder]]] = None,
        components: Optional[List[Union[Dict[str, Any], ActionRowBuilder]]] = None,
        ephemeral: bool = False,
    ) -> None:
        """Reply to the interaction"""
        if self._check_duplicate_response("reply"):
            return

        # Check if any component is a Container (type 17) and warn
        if components:
            for c in components:
                comp_dict = c.to_dict() if hasattr(c, "to_dict") else c
                if comp_dict.get("type") == 17:
                    print(
                        f"{YELLOW}[Loop SDK] ⚠️  Você está usando reply() com um Container. "
                        f"Use reply_with_components() para que Components V2 funcionem corretamente!{RESET}"
                    )
                    break

        data: Dict[str, Any] = {}
        
        if content:
            data["content"] = content
        
        if embeds:
            data["embeds"] = [
                e.to_dict() if isinstance(e, EmbedBuilder) else e
                for e in embeds
            ]
        
        if components:
            data["components"] = [
                c.to_dict() if isinstance(c, ActionRowBuilder) else c
                for c in components
            ]
        
        if ephemeral:
            data["flags"] = 64

        self._response = {
            "type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
            "data": data,
        }

    def reply_text(self, content: str, ephemeral: bool = False) -> None:
        """Reply with simple text"""
        self.reply(content=content, ephemeral=ephemeral)

    def reply_with_components(
        self,
        components: List[Any],
        ephemeral: bool = False,
    ) -> None:
        """Reply with Components V2 (Container, MediaGallery, etc.)"""
        if self._check_duplicate_response("reply_with_components"):
            return

        data: Dict[str, Any] = {
            "components": [
                c.to_dict() if hasattr(c, "to_dict") else c
                for c in components
            ],
            "flags": 32768,  # IS_COMPONENTS_V2
        }
        
        if ephemeral:
            data["flags"] |= 64

        self._response = {
            "type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
            "data": data,
        }

    def update(
        self,
        content: Optional[str] = None,
        embeds: Optional[List[Union[Dict[str, Any], EmbedBuilder]]] = None,
        components: Optional[List[Union[Dict[str, Any], ActionRowBuilder]]] = None,
    ) -> None:
        """Update the original message"""
        if self._check_duplicate_response("update"):
            return

        data: Dict[str, Any] = {}
        
        if content is not None:
            data["content"] = content
        
        if embeds:
            data["embeds"] = [
                e.to_dict() if isinstance(e, EmbedBuilder) else e
                for e in embeds
            ]
        
        if components:
            data["components"] = [
                c.to_dict() if isinstance(c, ActionRowBuilder) else c
                for c in components
            ]

        self._response = {
            "type": InteractionResponseType.UPDATE_MESSAGE,
            "data": data,
        }

    def update_with_components(self, components: List[Any]) -> None:
        """Update the original message with Components V2"""
        if self._check_duplicate_response("update_with_components"):
            return

        self._response = {
            "type": InteractionResponseType.UPDATE_MESSAGE,
            "data": {
                "components": [
                    c.to_dict() if hasattr(c, "to_dict") else c
                    for c in components
                ],
                "flags": 32768,  # IS_COMPONENTS_V2
            },
        }

    def defer(self, ephemeral: bool = False) -> None:
        """Defer the response (show 'thinking...')"""
        if self._check_duplicate_response("defer"):
            return

        self._deferred = True
        self._response = {
            "type": InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE,
            "data": {"flags": 64 if ephemeral else 0},
        }

    def defer_update(self) -> None:
        """Defer the update (acknowledge without visible loading)"""
        if self._check_duplicate_response("defer_update"):
            return

        self._deferred = True
        self._response = {
            "type": InteractionResponseType.DEFERRED_UPDATE_MESSAGE,
        }

    def show_modal(self, modal: ModalBuilder) -> None:
        """Show a modal to the user"""
        if self._check_duplicate_response("show_modal"):
            return

        self._response = {
            "type": InteractionResponseType.MODAL,
            "data": modal.to_dict(),
        }

    async def follow_up(
        self,
        content: Optional[str] = None,
        embeds: Optional[List[Union[Dict[str, Any], EmbedBuilder]]] = None,
        components: Optional[List[Union[Dict[str, Any], ActionRowBuilder]]] = None,
        ephemeral: bool = False,
    ) -> Dict[str, Any]:
        """Send a follow-up message"""
        data: Dict[str, Any] = {}
        
        if content:
            data["content"] = content
        
        if embeds:
            data["embeds"] = [
                e.to_dict() if isinstance(e, EmbedBuilder) else e
                for e in embeds
            ]
        
        if components:
            data["components"] = [
                c.to_dict() if isinstance(c, ActionRowBuilder) else c
                for c in components
            ]
        
        if ephemeral:
            data["flags"] = 64

        return await self._client.follow_up(
            self._application_id,
            self.token,
            data,
        )

    async def edit_reply(
        self,
        content: Optional[str] = None,
        embeds: Optional[List[Union[Dict[str, Any], EmbedBuilder]]] = None,
        components: Optional[List[Union[Dict[str, Any], ActionRowBuilder]]] = None,
    ) -> None:
        """Edit the original response"""
        data: Dict[str, Any] = {}
        
        if content is not None:
            data["content"] = content
        
        if embeds:
            data["embeds"] = [
                e.to_dict() if isinstance(e, EmbedBuilder) else e
                for e in embeds
            ]
        
        if components:
            data["components"] = [
                c.to_dict() if isinstance(c, ActionRowBuilder) else c
                for c in components
            ]

        await self._client.edit_original(
            self._application_id,
            self.token,
            data,
        )
