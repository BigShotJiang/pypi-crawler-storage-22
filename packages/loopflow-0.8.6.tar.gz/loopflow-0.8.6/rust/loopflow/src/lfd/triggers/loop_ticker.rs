use std::time::Duration;

use tokio::task::JoinHandle;
use tokio_util::sync::CancellationToken;

use super::common::{create_wave_run_with_id, spawn_run_task_with_slot};
use crate::lfd::events::EventHub;
use crate::lfd::executor::WaveExecutor;
use crate::lfd::id::LfdId;
use crate::lfd::scheduler::Scheduler;
use crate::lfd::store::SharedStore;
use crate::lfd::types::{StimulusKind, WaveStatus};

pub fn spawn_loop_ticker(
    scheduler: std::sync::Arc<Scheduler>,
    store: SharedStore,
    executor: WaveExecutor,
    event_hub: EventHub,
    cancel: CancellationToken,
) -> JoinHandle<()> {
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(Duration::from_secs(5));
        loop {
            tokio::select! {
                _ = cancel.cancelled() => {
                    tracing::info!("loop_ticker shutting down");
                    break;
                }
                _ = interval.tick() => {
                    tick_loop_waves(&scheduler, &store, &executor, &event_hub).await;
                }
            }
        }
    })
}

async fn tick_loop_waves(
    scheduler: &std::sync::Arc<Scheduler>,
    store: &SharedStore,
    executor: &WaveExecutor,
    event_hub: &EventHub,
) {
    let stimuli = match store.list_stimuli_by_kind(StimulusKind::Loop.as_i32()) {
        Ok(stimuli) => stimuli,
        Err(err) => {
            tracing::error!(error = %err, "failed to list loop stimuli");
            return;
        }
    };

    for stimulus in stimuli {
        if !stimulus.enabled {
            continue;
        }

        let wave = match store.get_wave(&stimulus.wave_id) {
            Ok(Some(wave)) => wave,
            Ok(None) => continue,
            Err(err) => {
                tracing::error!(wave_id = %stimulus.wave_id, error = %err, "failed to load wave");
                continue;
            }
        };

        if wave.status == WaveStatus::Paused {
            continue;
        }

        if scheduler.has_active_session(wave.id.as_str()) {
            continue;
        }

        if let Ok(Some(_)) = store.get_active_wave_run(&stimulus.wave_id) {
            continue;
        }

        let run_id = LfdId::new();
        let (acquired, _) = scheduler.acquire(run_id.as_str()).await;
        if !acquired {
            continue;
        }

        let run = match create_wave_run_with_id(store, &wave, &run_id) {
            Ok(run) => run,
            Err(err) => {
                scheduler.release(run_id.as_str());
                tracing::error!(wave_id = %wave.id, error = %err, "failed to create wave run");
                continue;
            }
        };

        spawn_run_task_with_slot(
            store.clone(),
            executor.clone(),
            scheduler.clone(),
            event_hub.clone(),
            run,
        );
    }
}
