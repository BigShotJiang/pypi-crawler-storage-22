// Loopflow Concerto app entry point.
// macOS 15+ native app for managing waves and launching LLM coding sessions.

import SwiftUI
import CoreText
import LoopflowCore

@main
struct ConcertoApp: App {
    @State private var recentsService = RecentsService()
    @Environment(\.openWindow) private var openWindow
    @Environment(\.colorScheme) private var systemScheme
    @State private var snapshotError: String?
    @State private var showSnapshotError = false
    @AppStorage("appearanceMode") private var appearanceMode = AppearanceMode.system.rawValue

    init() {
        Self.registerBundledFonts()
        Task {
            try? await NotificationService.shared.requestAuthorization()
        }
    }

    private static var fontBundle: Bundle {
        // SPM executable targets use Bundle.module for copied resources.
        // Xcode app targets use Bundle.main (Fonts copied into app bundle).
        #if SWIFT_PACKAGE
        return Bundle.module
        #else
        return Bundle.main
        #endif
    }

    private static func registerBundledFonts() {
        let fontFiles = [
            "CormorantGaramond-Regular.otf",
            "CormorantGaramond-Medium.otf",
            "CormorantGaramond-SemiBold.otf",
            "Lato-Regular.ttf",
            "Lato-Bold.ttf",
            "JetBrainsMono-Regular.ttf",
        ]
        for file in fontFiles {
            guard let url = fontBundle.url(forResource: file, withExtension: nil, subdirectory: "Fonts") else {
                continue
            }
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
    }

    private var resolvedPalette: LoopflowPalette {
        switch AppearanceMode(rawValue: appearanceMode) {
        case .light: return .light
        case .dark: return .dark
        case .system, .none: return systemScheme == .dark ? .dark : .light
        }
    }

    var body: some Scene {
        let preferredScheme = AppearanceMode(rawValue: appearanceMode)?.colorScheme
        let uiTestMode = RepoState.uiTestMode()
        let screenshotMode = RepoState.ScreenshotMode.fromArgs()

        // Welcome/main window - shown on launch
        WindowGroup {
            Group {
                if let screenshot = screenshotMode {
                    ScreenshotWindow(mode: screenshot, recentsService: recentsService)
                } else if uiTestMode != nil {
                    RepoWindow(
                        repoURL: URL(fileURLWithPath: "/tmp/loopflow-ui-tests"),
                        recentsService: recentsService
                    )
                } else {
                    WelcomeWindow(recentsService: recentsService)
                }
            }
            .tint(.loopflowBurgundy)
            .preferredColorScheme(preferredScheme)
            .environment(\.palette, resolvedPalette)
        }
        .windowStyle(.automatic)
        .defaultSize(width: 500, height: 400)

        // Repo windows - opened explicitly for each repository
        WindowGroup(id: "repo", for: URL.self) { $repoURL in
            RepoWindow(repoURL: repoURL, recentsService: recentsService)
                .tint(.loopflowBurgundy)
                .preferredColorScheme(preferredScheme)
                .environment(\.palette, resolvedPalette)
        }
        .windowStyle(.automatic)
        .defaultSize(width: 900, height: 700)

        // Terminal test window - for testing embedded Ghostty
        Window("Terminal Test", id: "terminal-test") {
            TerminalTestWindow()
                .preferredColorScheme(preferredScheme)
                .environment(\.palette, resolvedPalette)
        }
        .defaultSize(width: 800, height: 600)

        .commands {
            // Beta features menu
            CommandGroup(after: .appSettings) {
                Toggle("Beta Features", isOn: Binding(
                    get: { Flags.beta },
                    set: { Flags.setBeta($0) }
                ))
                Divider()
                Picker("Appearance", selection: Binding(
                    get: { appearanceMode },
                    set: { appearanceMode = $0 }
                )) {
                    ForEach(AppearanceMode.allCases, id: \.rawValue) { mode in
                        Text(mode.menuTitle).tag(mode.rawValue)
                    }
                }
                .pickerStyle(.radioGroup)
            }

            CommandGroup(after: .saveItem) {
                Button("Snapshot for Review") {
                    snapshotCurrentWindow()
                }
                .keyboardShortcut("4", modifiers: [.command])
            }

            // View menu - command palette and navigation
            CommandGroup(after: .sidebar) {
                Button("Command Palette") {
                    NotificationCenter.default.post(name: .toggleCommandPalette, object: nil)
                }
                .keyboardShortcut("k", modifiers: .command)

                Divider()

                Button("Terminal Test") {
                    openWindow(id: "terminal-test")
                }
                .keyboardShortcut("t", modifiers: [.command, .shift])
            }
        }
    }

    @MainActor
    private func snapshotCurrentWindow() {
        let snapshotService = SnapshotService()

        do {
            let outputURL = try snapshotService.snapshotKeyWindow()
            NSSound.beep()
            NSWorkspace.shared.activateFileViewerSelecting([outputURL])
        } catch {
            snapshotError = error.localizedDescription
            showSnapshotError = true
        }
    }
}
