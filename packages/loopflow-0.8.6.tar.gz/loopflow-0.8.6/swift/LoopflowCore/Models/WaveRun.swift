// WaveRun - a single execution of a Wave.

import Foundation
import SwiftUI

public enum WaveRunStatus: String, Sendable, Codable {
    case pending
    case running
    case waiting
    case completed
    case failed
    case cancelled

    public var color: Color {
        switch self {
        case .running: return .statusSuccess
        case .waiting: return .statusWarning
        case .pending: return .statusInfo
        case .completed: return .statusNeutral
        case .failed: return .statusError
        case .cancelled: return .statusWarning
        }
    }
}

public struct WaveRun: Sendable, Identifiable, Hashable {
    public let id: String
    public let waveId: String?

    public let flow: String
    public let area: String
    public let repo: String
    public let direction: [String]

    public var status: WaveRunStatus
    public var iteration: Int
    public var stepIndex: Int

    public var worktree: String?
    public var branch: String?
    public var currentStep: String?
    public var error: String?
    public var pr: PullRequest?

    public var startedAt: Date?
    public var endedAt: Date?
    public var createdAt: Date

    public init(
        id: String,
        waveId: String?,
        flow: String,
        area: String,
        repo: String,
        direction: [String] = [],
        status: WaveRunStatus = .pending,
        iteration: Int = 0,
        stepIndex: Int = 0,
        worktree: String? = nil,
        branch: String? = nil,
        currentStep: String? = nil,
        error: String? = nil,
        pr: PullRequest? = nil,
        startedAt: Date? = nil,
        endedAt: Date? = nil,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.waveId = waveId
        self.flow = flow
        self.area = area
        self.repo = repo
        self.direction = direction
        self.status = status
        self.iteration = iteration
        self.stepIndex = stepIndex
        self.worktree = worktree
        self.branch = branch
        self.currentStep = currentStep
        self.error = error
        self.pr = pr
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.createdAt = createdAt
    }

}

public extension WaveRun {
    var duration: String? {
        guard let startedAt, let endedAt else { return nil }
        let interval = max(0, endedAt.timeIntervalSince(startedAt))
        let minutes = Int(interval) / 60
        let seconds = Int(interval) % 60
        return "\(minutes)m\(String(format: "%02d", seconds))s"
    }

    var relativeTime: String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        let reference = endedAt ?? startedAt ?? createdAt
        return formatter.localizedString(for: reference, relativeTo: Date())
    }
}
