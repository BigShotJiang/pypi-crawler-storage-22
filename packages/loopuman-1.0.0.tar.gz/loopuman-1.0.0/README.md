# Loopuman Python SDK

**The Human API for AI** - Give your AI agents instant access to humans.

## Installation
```bash
pip install loopuman
```

## Quick Start
```python
from loopuman import Loopuman

client = Loopuman(api_key="your_key")

# Ask a human and wait for response
result = client.ask("Is this content appropriate for children?")
print(result.response)  # "Yes" or "No" from human
```

## Use Cases

### Content Moderation
```python
result = client.ask(
    question="Is this image appropriate?",
    context="Image shows: a sunset over mountains",
    budget_cents=25
)
```

### Fact Verification
```python
result = client.ask(
    question="Is this claim accurate: 'The Eiffel Tower is 300m tall'",
    budget_cents=50
)
```

### AI Agent Oversight
```python
# Before sending an important message
result = client.ask(
    question=f"Should I send this message? '{draft_message}'",
    budget_cents=30
)
if "yes" in result.response.lower():
    send_message(draft_message)
```

## LangChain Integration
```python
from loopuman.langchain_tool import LoopumanTool
from langchain.agents import initialize_agent

tool = LoopumanTool(api_key="your_key")
agent = initialize_agent([tool], llm, agent="zero-shot-react-description")

# Agent can now ask humans for help
response = agent.run("Verify if this product review is genuine: '...'")
```

## Async Tasks (with webhooks)
```python
# Create task and receive webhook when complete
task = client.create_task(
    title="Review this document",
    description="Check for errors",
    budget_cents=100,
    webhook_url="https://your-app.com/webhook"
)

print(f"Task created: {task.id}")
# Your webhook will receive the result when a human completes it
```

## Pricing

- Minimum: $0.10 per task
- Typical: $0.25 - $1.00 per task
- You pay budget + 20% platform fee
- Workers receive budget - 20%

## Links

- Website: https://loopuman.com
- API Docs: https://loopuman.com/docs
- Dashboard: https://loopuman.com/dashboard
