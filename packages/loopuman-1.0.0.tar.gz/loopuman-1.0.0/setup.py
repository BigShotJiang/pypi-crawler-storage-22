from setuptools import setup, find_packages

setup(
    name="loopuman",
    version="1.0.0",
    description="The Human API for AI - Give your AI agents instant access to humans",
    author="Loopuman",
    author_email="hello@loopuman.com",
    url="https://github.com/loopuman/loopuman-python",
    packages=find_packages(),
    install_requires=["requests>=2.25.0"],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai human-in-the-loop microtasks langchain agents",
)
