# Credential Management for LOOVE AI Agents

This module provides credential management and GitHub App authentication for all AI assistants in the LOOVE ecosystem (Devin, Manus, Claude Code, etc.).

## Quick Start

The easiest way to get started is with the `AgentCredentialProvider`:

```python
from integration_validation.credential import get_agent_provider

# Initialize for your agent
provider = get_agent_provider("manus")  # or "devin", "claude", etc.

# Get GitHub credentials
github_token = provider.get_github_token()
github_headers = provider.get_github_headers()

# Get other service credentials
slack_token = provider.get_slack_token()
asana_token = provider.get_asana_token()

# Or any credential by name
api_key = provider.get_credential("MY_API_KEY")
```

## CLI Tool

A command-line interface is available for setup and verification:

```bash
# Check current credential configuration status
python -m integration_validation.credential status

# Interactive setup guide
python -m integration_validation.credential setup
python -m integration_validation.credential setup --interactive

# Verify GitHub App authentication
python -m integration_validation.credential verify

# Test GitHub API access
python -m integration_validation.credential test-github
python -m integration_validation.credential test-github --verbose

# Export configuration as JSON
python -m integration_validation.credential export
```

## Components

### AgentCredentialProvider

The recommended way for AI agents to access credentials. Provides a unified interface for all credential types.

```python
from integration_validation.credential import get_agent_provider, get_manus_provider

# Generic provider for any agent
provider = get_agent_provider("my_agent")

# Pre-configured providers for common agents
manus = get_manus_provider()
devin = get_devin_provider()
claude = get_claude_provider()

# Get status of all credentials
status = provider.get_status()
print(status)
```

### EnvCredentialManager

Environment-aware credential management that automatically detects the runtime environment and retrieves credentials from the appropriate source.

**Environments supported:**
- **GitHub Actions**: Uses environment variables from GitHub Secrets
- **CI**: Uses environment variables
- **Development**: Uses a central `.env` file (configurable via `LOOVE_CREDENTIAL_STORE_PATH` env var, default: `~/repos/Devin_integrations/.env`)

**Usage:**
```python
from integration_validation.credential import EnvCredentialManager

cred_manager = EnvCredentialManager("my_service")
token = cred_manager.get_credential("API_TOKEN", required=True)
```

### GitHubAppAuth

GitHub App authentication with automatic token rotation. Provides secure, scalable access to GitHub APIs for any AI assistant.

**Benefits over Personal Access Tokens:**
- Automatic token rotation (installation tokens expire in 1 hour)
- Fine-grained permissions per repository
- Better audit trail
- Scalable for multiple AI assistants

**Usage:**
```python
from integration_validation.credential import get_github_app_auth

# Get auth instance for your agent
auth = get_github_app_auth("devin")  # or "manus", "claude", etc.

# Get headers for API requests
headers = auth.get_auth_headers()

# Or get the token directly
token = auth.get_installation_token()
```

## GitHub App Setup

### Step 1: Create a GitHub App

1. Go to your GitHub organization settings
2. Navigate to **Developer settings** > **GitHub Apps** > **New GitHub App**
3. Configure the app:
   - **Name**: `LOOVE AI Agent Access` (or similar)
   - **Homepage URL**: Your organization's URL
   - **Webhook**: Uncheck "Active" (not needed for API access)
   - **Permissions**: Set based on your needs:
     - **Repository permissions**:
       - Actions: Read and write
       - Contents: Read and write
       - Metadata: Read-only
       - Secrets: Read and write (if managing secrets)
     - **Organization permissions**:
       - Members: Read-only (optional)
4. Click **Create GitHub App**

### Step 2: Generate a Private Key

1. On the app's settings page, scroll to **Private keys**
2. Click **Generate a private key**
3. Save the downloaded `.pem` file securely

### Step 3: Install the App

1. On the app's settings page, click **Install App**
2. Select your organization
3. Choose which repositories the app can access
4. Click **Install**
5. Note the **Installation ID** from the URL (e.g., `https://github.com/settings/installations/12345678`)

### Step 4: Configure Credentials

Add the following to your environment:

**For GitHub Actions (recommended for CI/CD):**

Add these as repository or organization secrets:
- `GITHUB_APP_ID`: The App ID from the app's settings page
- `GITHUB_APP_PRIVATE_KEY`: The contents of the `.pem` file
- `GITHUB_APP_INSTALLATION_ID`: The installation ID from Step 3

**For local development:**

Add to your credential store (default: `~/repos/Devin_integrations/.env`, or set `LOOVE_CREDENTIAL_STORE_PATH` to customize):
```bash
GITHUB_APP_ID=123456
GITHUB_APP_PRIVATE_KEY_PATH=/path/to/private-key.pem
GITHUB_APP_INSTALLATION_ID=12345678
```

Or inline the key (replace newlines with `\n`):
```bash
GITHUB_APP_ID=123456
GITHUB_APP_PRIVATE_KEY="-----BEGIN RSA PRIVATE KEY-----\nMIIE...\n-----END RSA PRIVATE KEY-----"
GITHUB_APP_INSTALLATION_ID=12345678
```

## Dependencies

The GitHub App authentication requires:
- `PyJWT`: For JWT generation (`pip install PyJWT`)
- `requests`: For API calls (`pip install requests`)
- `cryptography`: For RSA key handling (`pip install cryptography`)

Install all dependencies:
```bash
pip install PyJWT requests cryptography
```

## Verification

Verify your setup is working:

```python
from integration_validation.credential import get_github_app_auth

auth = get_github_app_auth("test")
status = auth.verify_installation()
print(status)
```

Expected output for a properly configured setup:
```python
{
    'configured': True,
    'agent_name': 'test',
    'app_id': '123456',
    'installation_id': '12345678',
    'jwt_available': True,
    'token_available': True,
    'environment': 'development',
    'error': None
}
```

## Fallback Behavior

If GitHub App authentication is not configured, the system will fall back to using `GITHUB_TOKEN` (a Personal Access Token) if available. This ensures backward compatibility with existing workflows.

## Security Considerations

- Never commit private keys to version control
- Use GitHub Secrets for CI/CD environments
- Rotate private keys periodically
- Use the minimum required permissions for your use case
- Monitor the app's audit log for unusual activity
