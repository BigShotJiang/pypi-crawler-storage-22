"""
Supabase-based credential provider for LOOVE AI Agent Infrastructure.

This module provides direct access to credentials stored in Supabase,
enabling AI assistants without GitHub CLI access to retrieve credentials
using only the LOOVE_KEYS_BOOTSTRAP_KEY environment variable.

Usage:
    from loove_credentials import bootstrap_supabase, get_asana_token
    
    # Bootstrap from Supabase (requires LOOVE_KEYS_BOOTSTRAP_KEY env var)
    bootstrap_supabase()
    
    # Then use tokens as normal
    token = get_asana_token()

Environment Variables:
    LOOVE_KEYS_BOOTSTRAP_KEY: Supabase service role key (required)
"""

import os
import urllib.request
import json
from typing import Optional, Dict, Any
from functools import lru_cache

__all__ = [
    'SupabaseCredentialProvider',
    'bootstrap_supabase',
    'get_supabase_credential',
    'get_supabase_credentials',
    'is_supabase_available',
]

# Supabase configuration
SUPABASE_URL = "https://ewlygzvnvqyvszdpwbww.supabase.co"
BOOTSTRAP_KEY_ENV = "LOOVE_KEYS_BOOTSTRAP_KEY"

# Mapping from loove-keys service/credential to environment variable names
CREDENTIAL_ENV_MAPPING = {
    ("asana", "pat"): "ASANA_ACCESS_TOKEN",
    ("shopify", "client_id"): "SHOPIFY_CLIENT_ID",
    ("shopify", "api_secret"): "SHOPIFY_API_SECRET",
    ("shopify", "access_token"): "SHOPIFY_ACCESS_TOKEN",
    ("shopify", "store_domain"): "SHOPIFY_STORE_URL",
    ("coda", "expense_projections_doc"): "CODA_EXPENSE_PROJECTIONS_TOKEN",
    ("coda", "financial_modeling_doc"): "CODA_FINANCIAL_MODELING_TOKEN",
    ("coda", "studio_booking_doc"): "CODA_STUDIO_BOOKING_TOKEN",
    ("coda", "loove_brain_doc"): "CODA_LOOVE_BRAIN_TOKEN",
    ("coda", "trombonistry_doc"): "CODA_JOSH_TROMBONISTRY_TOKEN",
    ("anthropic", "api_key"): "ANTHROPIC_API_KEY",
    ("quickbooks", "client_id"): "QUICKBOOKS_CLIENT_ID",
    ("quickbooks", "client_secret"): "QUICKBOOKS_CLIENT_SECRET",
    ("github", "pat"): "GITHUB_TOKEN",
    ("pypi", "token"): "PYPI_TOKEN",
}


class SupabaseCredentialError(Exception):
    """Raised when Supabase credential access fails."""
    pass


def is_supabase_available() -> bool:
    """
    Check if Supabase bootstrap is available.
    
    Returns:
        True if LOOVE_KEYS_BOOTSTRAP_KEY is set
    """
    return bool(os.environ.get(BOOTSTRAP_KEY_ENV))


def _get_bootstrap_key() -> str:
    """
    Get the bootstrap key from environment variable.
    
    Raises:
        SupabaseCredentialError: If the bootstrap key is not set
    """
    key = os.environ.get(BOOTSTRAP_KEY_ENV)
    if not key:
        raise SupabaseCredentialError(
            f"Bootstrap key not found. Set the {BOOTSTRAP_KEY_ENV} environment variable.\n"
            "This should be the Supabase service role key."
        )
    return key


def _supabase_request(endpoint: str, params: str = "") -> Optional[Any]:
    """
    Make an authenticated request to Supabase REST API.
    
    Args:
        endpoint: The table/endpoint to query
        params: Query parameters string
    
    Returns:
        JSON response data or None on error
    """
    bootstrap_key = _get_bootstrap_key()
    url = f"{SUPABASE_URL}/rest/v1/{endpoint}"
    if params:
        url = f"{url}?{params}"
    
    req = urllib.request.Request(url, headers={
        "apikey": bootstrap_key,
        "Authorization": f"Bearer {bootstrap_key}",
        "Content-Type": "application/json"
    })
    
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        raise SupabaseCredentialError(f"Supabase request failed: {e.code} - {e.read().decode()}")


@lru_cache(maxsize=64)
def get_supabase_credential(service_key: str, credential_key: str) -> Optional[str]:
    """
    Fetch a single credential from Supabase.
    
    Args:
        service_key: The service identifier (e.g., 'asana', 'shopify')
        credential_key: The specific credential (e.g., 'pat', 'access_token')
    
    Returns:
        The credential value, or None if not found
    """
    params = f"service_key=eq.{service_key}&credential_key=eq.{credential_key}&is_active=eq.true"
    data = _supabase_request("loove_credentials", params)
    
    if data and len(data) > 0:
        return data[0].get("credential_value")
    return None


def get_supabase_credentials(service_key: str) -> Dict[str, str]:
    """
    Fetch all credentials for a service from Supabase.
    
    Args:
        service_key: The service identifier (e.g., 'asana', 'shopify')
    
    Returns:
        Dictionary mapping credential_key to credential_value
    """
    params = f"service_key=eq.{service_key}&is_active=eq.true"
    data = _supabase_request("loove_credentials", params)
    
    if data:
        return {row["credential_key"]: row["credential_value"] for row in data}
    return {}


class SupabaseCredentialProvider:
    """
    Credential provider that fetches credentials directly from Supabase.
    
    This provider is designed for AI assistants that don't have GitHub CLI
    access but have the LOOVE_KEYS_BOOTSTRAP_KEY environment variable set.
    """
    
    def __init__(self):
        """Initialize the Supabase credential provider."""
        if not is_supabase_available():
            raise SupabaseCredentialError(
                f"{BOOTSTRAP_KEY_ENV} not set. Cannot use Supabase provider."
            )
    
    def get_credential(self, service_key: str, credential_key: str) -> Optional[str]:
        """Get a specific credential."""
        return get_supabase_credential(service_key, credential_key)
    
    def get_credentials(self, service_key: str) -> Dict[str, str]:
        """Get all credentials for a service."""
        return get_supabase_credentials(service_key)
    
    def get_asana_token(self) -> str:
        """Get Asana PAT."""
        token = self.get_credential("asana", "pat")
        if not token:
            raise SupabaseCredentialError("Asana PAT not found in Supabase")
        return token
    
    def get_shopify_credentials(self) -> Dict[str, str]:
        """Get all Shopify credentials."""
        return self.get_credentials("shopify")
    
    def get_anthropic_key(self) -> str:
        """Get Anthropic API key."""
        key = self.get_credential("anthropic", "api_key")
        if not key:
            raise SupabaseCredentialError("Anthropic API key not found in Supabase")
        return key
    
    def get_github_token(self) -> str:
        """Get GitHub PAT."""
        token = self.get_credential("github", "pat")
        if not token:
            raise SupabaseCredentialError("GitHub PAT not found in Supabase")
        return token


def bootstrap_supabase() -> bool:
    """
    Bootstrap credentials from Supabase into environment variables.
    
    This function fetches all credentials from Supabase and sets them
    as environment variables, matching the format expected by the
    existing loove-credentials API.
    
    Returns:
        True if successful
    
    Raises:
        SupabaseCredentialError: If bootstrap fails
    """
    if not is_supabase_available():
        raise SupabaseCredentialError(
            f"{BOOTSTRAP_KEY_ENV} not set. Cannot bootstrap from Supabase."
        )
    
    # Fetch all active credentials
    params = "is_active=eq.true"
    data = _supabase_request("loove_credentials", params)
    
    if not data:
        raise SupabaseCredentialError("No credentials found in Supabase")
    
    # Map credentials to environment variables
    credentials_set = 0
    for row in data:
        service_key = row.get("service_key")
        credential_key = row.get("credential_key")
        credential_value = row.get("credential_value")
        
        if not all([service_key, credential_key, credential_value]):
            continue
        
        # Check if we have a mapping for this credential
        env_var = CREDENTIAL_ENV_MAPPING.get((service_key, credential_key))
        if env_var:
            os.environ[env_var] = credential_value
            credentials_set += 1
        
        # Also set a generic format: SERVICE_CREDENTIALKEY
        generic_env = f"{service_key.upper()}_{credential_key.upper()}"
        os.environ[generic_env] = credential_value
    
    # Set CODA_API_KEY to financial modeling token (default)
    if "CODA_FINANCIAL_MODELING_TOKEN" in os.environ:
        os.environ["CODA_API_KEY"] = os.environ["CODA_FINANCIAL_MODELING_TOKEN"]
    
    # Set CLAUDE_API_KEY as alias for ANTHROPIC_API_KEY
    if "ANTHROPIC_API_KEY" in os.environ:
        os.environ["CLAUDE_API_KEY"] = os.environ["ANTHROPIC_API_KEY"]
    
    return True


def get_supabase_provider() -> SupabaseCredentialProvider:
    """
    Get a configured Supabase credential provider.
    
    Returns:
        SupabaseCredentialProvider instance
    """
    return SupabaseCredentialProvider()
