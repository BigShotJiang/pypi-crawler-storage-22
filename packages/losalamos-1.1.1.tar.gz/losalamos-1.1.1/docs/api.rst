.. _api:

API
############################################

.. develop a small description for the API [CHANGE THIS]:

Welcome to the API documentation for this project.
This reference, automatically generated using Sphinx, provides a complete overview of all relevant modules,
classes, functions, and constants in the repository. It is intended to help developers quickly understand
and navigate the available components and their usage, serving as a reliable
guide for integrating and extending the functionality of the project.


.. remove this note after enter maintenance mode [CHANGE THIS]:

.. warning::

    This API documentation is under active development


.. list down here all modules that must be in the API [CHANGE THIS]:


.. autosummary::
   :toctree: generated

   losalamos


.. autosummary::
   :toctree: generated

   losalamos.root


.. autosummary::
   :toctree: generated

   losalamos.project


.. autosummary::
   :toctree: generated

   losalamos.notes

.. autosummary::
   :toctree: generated

   losalamos.figures
