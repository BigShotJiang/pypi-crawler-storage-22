# Importing modules
import sys

# Creating meta classes
class _StringMeta(type):
    def __instancecheck__(cls, other):
        return isinstance(other, (str, bytes, bytearray))
class _NumberMeta(type):
    def __instancecheck__(cls, other):
        return isinstance(other, (int, float))
class _AnyMeta(type):
    def __instancecheck__(cls, other):
        return True
class _MassiveMeta(type):
    def __instancecheck__(cls, other):
        return isinstance(other, (list, tuple, dict))

# Creating classes
class Number(metaclass=_NumberMeta):
    """Any number (int, float)."""
class Any(metaclass=_AnyMeta):
    """Just anything."""
class String(metaclass=_StringMeta):
    """Any string/text (str, bytes, bytearray)."""
class Massive(metaclass=_MassiveMeta):
    """Any massive/list (list, tuple, dict)."""

# Creating non classes
class NonCallable:
    """Raises TypeError('Object MyNonCall is not callable.') on MyNonCall()."""
    def __init__(self):
        pass
    def __call__(self, *args, **kw):
        raise TypeError(f"Object {self.__class__.__name__} is not callable.")
class NonInitable:
    """Raises TypeError('Object MyNonInit is not initable.') on MyNonInit = NonInitable()."""
    def __init__(self):
        raise TypeError(f"Object {self.__class__.__name__} is not initable.")
class NonIterable:
    """Raises TypeError('Object MyNonIter is not iterable.') on for _ in MyNonIter."""
    def __init__(self):
        pass
    def __iter__(self):
        raise TypeError(f"Object {self.__class__.__name__} is not iterable.")

# Creating construct funcs / classes
def _a(): return True
class _A:
    def method(self): return True
    @property
    def prop(self): return 1
    @staticmethod
    def sm(): pass
    @classmethod
    def cm(cls): pass
class _M(type): pass
async def _as(): return True

# Creating types
NoneType            = type(None)
LambdaType          = type(lambda: True)
FunctionType        = type(_a)
BuiltinFunctionType = type(print)
ModuleType          = type(sys)
GeneratorType       = type(i for i in range(3))
MethodType          = type(_A().method)
ClassType           = type(_A)
MetaClassType       = type(_M)
AsyncFunctionType   = type(_as)
IteratorType        = type(iter([]))
CoroutineType       = type(_as())
CodeType            = type(_a.__code__)
EllipsisType        = type(...)
BytesType           = type(b'')
ByteArrayType       = type(bytearray(b''))
MemoryViewType      = type(memoryview(b''))
StrType             = type('')
IntType             = type(0)
FloatType           = type(0.0)
BoolType            = type(True)
DictType            = type({})
TupleType           = type(())
ListType            = type([])
SetType             = type(set())
FrozenSetType       = type(frozenset())
PropertyType        = type(_A.prop)
StaticMethodType    = type(_A.__dict__['sm'])
ClassMethodType     = type(_A.__dict__['cm'])

try:
    UnionType = type(str | int)
except:
    UnionType = None

try:
    raise Exception()
except Exception as e:
    TracebackType = type(e.__traceback__)

try:
    _as().close()
except:
    pass

# Deleting construct classes / funcs
del _A, _a, _M, _as

# Deleting meta classes
del _AnyMeta, _NumberMeta, _StringMeta, _MassiveMeta

# Deleting modules
del sys
