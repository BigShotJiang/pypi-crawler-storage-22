from setuptools import setup, find_packages
import os

version = "1.0.2"
desc = "A lot more types!"
long_description = f"""# Lottypes {version}

# {desc}
# Installation:
## Main:
```bash
pip install lottypes=={version}
```
## Or:
```bash
pip3 install lottypes=={version}
```

# Examples:
```python
from lottypes import *

mystr = 'String'
mybytes = b'Bytes'
myint = 13
myfloat = 13.13
fruits = {{'Banana': 15.5, 'Apple': 14.3}}
fruitsName = ['Banana', 'Apple']
user = ('Bob', 32, 'bobgmail@gmail.com')

isinstance(mystr, String) # True
isinstance(mybytes, String) # True
isinstance(myint, String) # False
isinstance(mystr, Number) # False
isinstance(myint, Number) # True
isinstance(myfloat, Number) # True
isinstance(fruits, Massive) # True
isinstance(fruitsName, Massive) # True
isinstance(user, Massive) # True
```

# Changelog
## [{version}]
- **Fixed bugs with docs and homepage.**

# Github
## [My github account](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

# Enjoy it!

![PyPI - Version](https://img.shields.io/pypi/v/lottypes)
![PyPI - Downloads](https://img.shields.io/pypi/dm/lottypes)
![PyPI - License](https://img.shields.io/pypi/l/lottypes)
![PyPi - Badge](https://img.shields.io/pypi/v/lottypes?color=blue&style=for-the-badge&logo=python)
![PyPi - Status](https://img.shields.io/pypi/status/lottypes)
![PyPi - Format](https://img.shields.io/pypi/format/lottypes)
![PyPi - PyVersions](https://img.shields.io/pypi/pyversions/lottypes)
"""

setup(
    name="lottypes",
    version=version,
    author="kanderusss",
    author_email="kanderusss.dev@gmail.com",
    description=desc,

    long_description=long_description,
    long_description_content_type="text/markdown",

    url="https://pypi.org/project/lottypes/",
    project_urls={
        "Documentation": "https://pypi.org/project/lottypes/",
    },

    packages=find_packages(),

    install_requires=[],


    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],

    python_requires=">=3.6",
)
