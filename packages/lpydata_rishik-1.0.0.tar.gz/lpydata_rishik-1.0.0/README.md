# LPYData

LPYData is a lightweight Python student database system.

## Features

- Add student
- Search student
- Update student
- Delete student
- JSON-based storage

## Installation

pip install lpydata-rishik

## Example Usage

```python
from lpydata import StudentManager

manager = StudentManager()
manager.add_student("S001", "Rishik", 9)
print(manager.get_student("S001"))
