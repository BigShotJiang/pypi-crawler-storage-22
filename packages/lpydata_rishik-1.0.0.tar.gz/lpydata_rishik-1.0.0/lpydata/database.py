"""
LPYData - Core Database Engine
Author: Rishik Ravada
License: MIT
"""

import json
import os
from typing import Any, Dict


class LPYDatabase:
    """
    A lightweight JSON-based database system.
    Handles saving, reading, updating, deleting, and searching data.
    """

    def __init__(self, filename: str):
        """
        Initialize the database with a file name.
        If file does not exist, create an empty JSON file.
        """
        self.filename = filename
        self._ensure_file_exists()

    def _ensure_file_exists(self) -> None:
        """
        Creates the JSON file if it does not already exist.
        """
        if not os.path.exists(self.filename):
            with open(self.filename, "w", encoding="utf-8") as file:
                json.dump({}, file, indent=4)

    def load_data(self) -> Dict[str, Any]:
        """
        Loads and returns all data from the JSON file.
        """
        with open(self.filename, "r", encoding="utf-8") as file:
            return json.load(file)

    def save_data(self, data: Dict[str, Any]) -> None:
        """
        Saves the provided dictionary into the JSON file.
        """
        with open(self.filename, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4)

    def add_record(self, key: str, value: Any) -> None:
        """
        Adds a new record to the database.
        """
        data = self.load_data()
        data[key] = value
        self.save_data(data)

    def get_record(self, key: str) -> Any:
        """
        Retrieves a record by key.
        Returns None if not found.
        """
        data = self.load_data()
        return data.get(key)

    def update_record(self, key: str, value: Any) -> None:
        """
        Updates an existing record.
        """
        data = self.load_data()
        if key in data:
            data[key] = value
            self.save_data(data)

    def delete_record(self, key: str) -> None:
        """
        Deletes a record from the database.
        """
        data = self.load_data()
        if key in data:
            del data[key]
            self.save_data(data)

    def search(self, field: str, value: Any) -> Dict[str, Any]:
        """
        Searches all records where field matches the given value.
        """
        data = self.load_data()
        results = {}

        for key, record in data.items():
            if isinstance(record, dict) and record.get(field) == value:
                results[key] = record

        return results
