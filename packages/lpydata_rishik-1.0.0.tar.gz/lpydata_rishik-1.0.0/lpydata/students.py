"""
LPYData - Student Management Module
Author: Rishik Ravada
License: MIT
"""

from typing import Dict, Any
from .database import LPYDatabase


class StudentManager:
    """
    Handles student-related operations using LPYDatabase.
    """

    def __init__(self):
        """
        Initializes student database file.
        """
        self.database = LPYDatabase("students.json")

    def add_student(self, student_id: str, name: str, grade: int) -> None:
        """
        Adds a new student.
        """
        if not isinstance(student_id, str):
            raise ValueError("Student ID must be a string.")

        if not isinstance(name, str):
            raise ValueError("Name must be a string.")

        if not isinstance(grade, int):
            raise ValueError("Grade must be an integer.")

        student_data = {
            "name": name,
            "grade": grade
        }

        self.database.add_record(student_id, student_data)

    def get_student(self, student_id: str) -> Dict[str, Any]:
        """
        Retrieves a student by ID.
        """
        return self.database.get_record(student_id)

    def update_student(self, student_id: str, name: str, grade: int) -> None:
        """
        Updates existing student data.
        """
        student_data = {
            "name": name,
            "grade": grade
        }

        self.database.update_record(student_id, student_data)

    def remove_student(self, student_id: str) -> None:
        """
        Removes a student from database.
        """
        self.database.delete_record(student_id)

    def search_by_grade(self, grade: int) -> Dict[str, Any]:
        """
        Searches students by grade.
        """
        return self.database.search("grade", grade)

    def export_all_students(self) -> Dict[str, Any]:
        """
        Returns all student records.
        """
        return self.database.load_data()
