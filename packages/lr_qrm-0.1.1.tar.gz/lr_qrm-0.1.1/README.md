# lr-qrm

CLI tooling for LumenRadio engineers to interrogate and validate data stored in the Qestit QRM platform. The application is implemented with Typer, Rich, Pydantic, and Requests, and is packaged as a standard Python project targeting Python 3.9+.

## Features
- Consistent CLI entry point exposed as `qrm`.
- Ready-to-extend Rich console output pipeline.
- Secure login workflow that writes bearer tokens to `~/.config/qrm/login.json`.
- Comprehensive pytest test suite with coverage and HTML/JUnit reports suitable for CI.

## Quickstart
1. Ensure Python 3.9+ is available.
2. Create the virtual environment and install dependencies:
	```sh
	make dev
	```
3. Authenticate (stores token in `~/.config/qrm/login.json`):
	```sh
	.venv/bin/qrm login --username <user>
	```
4. Inspect help/placeholder commands:
	```sh
	.venv/bin/qrm --help
	.venv/bin/qrm status
	```

## Development Workflow
- Format code: `make black` (CI passes `BLACK_ARGS=--check`).
- Run tests with coverage: `make test`.
- Build distribution artifacts: `make dist`.
- Validate with Twine: `make check`.
- Publish to PyPI (requires `PYPI_TOKEN`): `make publish`.

## Testing & Reports
`make test` configures pytest to emit:
- Cobertura XML: `build/reports/coverage.xml`.
- HTML coverage dashboard: `build/reports/html/index.html`.
- JUnit XML: `build/reports/junit.xml`.

## License
Released under the MIT License. See LICENSE.

