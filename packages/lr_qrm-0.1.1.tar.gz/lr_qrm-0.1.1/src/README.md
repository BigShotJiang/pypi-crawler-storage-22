# QRM

CLI + Python client for interacting with the Qestit QRM.

## Install

```bash
pip install lr-qrm
```

## Quick start

### Login

Interactive login (prompts for username/password):

```bash
qrm login
```

Non-interactive (for CI/CD):

```bash
export QRM_USERNAME="<insert username>"
export QRM_PASSWORD="<insert password>"
qrm login --ci
```

By default, this stores session details at:

```
~/.config/qrm/login.json
```

### Commands

#### Check API health

```bash
qrm status
```

#### Inspect UUT history

```bash
qrm uut status 326115020010F2F1 --start "2026-02-01 00:00:00" --stop "2026-02-06 23:59:00"
```

By default the command queries the last 24 hours ending now. Pass `--base-url` and `--insecure` to override the stored settings when needed.

#### JSON output

Most commands support a JSON output mode.

```bash
qrm uut status 326115020010F2F1 --output json
```

## Programmatic use

```python
from qrm.config import load_login_state
from qrm.client import QrmClient

state = load_login_state()
client = QrmClient(base_url=str(state.base_url), verify_tls=state.verify_tls)
uut_runs = client.uut_status(
  token=state.token,
  serial_number="326115020010F2F1",
  start_datetime="2026-02-01 00:00:00",
  stop_datetime="2026-02-06 23:59:00",
  max_results=1000,
)
```


## FAQ

- **Where is the config kept?**
  `~/.config/qrm/login.json` (override with `QRM_CONFIG`)

- **How do I run non-interactively?**
  Make sure to give all required arguments. Also pass `--ci` to stop output of sensitive information such as username or passwords.