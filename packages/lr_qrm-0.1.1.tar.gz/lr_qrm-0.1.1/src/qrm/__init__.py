"""Top-level package for the lr-qrm CLI."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path

from .client import LoginState, QrmClient, QrmClientError


def _load_version() -> str:
    try:
        return package_version("lr-qrm")
    except PackageNotFoundError:
        return _version_from_pyproject()


def _version_from_pyproject() -> str:
    pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
    if not pyproject.exists():  # pragma: no cover - defensive guard
        raise RuntimeError("pyproject.toml not found; unable to determine version")

    for raw_line in pyproject.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line.startswith("version ="):
            return line.split("=", 1)[1].strip().strip('"').strip("'")

    raise RuntimeError("Version not declared in pyproject.toml")


__version__ = _load_version()

__all__ = [
    "__version__",
    "LoginState",
    "QrmClient",
    "QrmClientError",
]
