"""Helpers for loading persisted QRM CLI configuration."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .client import LoginState


def load_login_state(path: Path) -> LoginState:
    """Load a previously stored :class:`LoginState` from ``path``."""

    raw = path.read_text(encoding="utf-8")
    data: Any
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:  # pragma: no cover - defensive guard
        raise ValueError(f"Invalid JSON in {path}") from exc

    return LoginState.model_validate(data)


__all__ = ["load_login_state"]

