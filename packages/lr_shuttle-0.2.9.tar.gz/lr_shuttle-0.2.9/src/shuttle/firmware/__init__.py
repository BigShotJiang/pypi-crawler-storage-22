"""Embedded firmware artifacts bundled with the Shuttle CLI."""

DEFAULT_BOARD = "esp32c5"

__all__ = ["DEFAULT_BOARD"]
