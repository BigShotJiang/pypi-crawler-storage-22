"""ESP32-C5 devboard firmware bundle."""
