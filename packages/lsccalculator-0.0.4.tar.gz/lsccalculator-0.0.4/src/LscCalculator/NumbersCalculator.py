from decimal import *


class NumbersCalculator:
    def __init__(self):
        self.returned_type = Decimal
    
    def addition(self, *addends):
        sum_ = Decimal("0")

        if type(addends[0]) is list:
            addends = addends[0]
        for addend in addends:
            sum_ += Decimal(f"{addend}")

        return self.returned_type(sum_)
    
    def subtraction(self, minuend, *subtrahends):
        difference = Decimal(f"{minuend}")

        if type(subtrahends[0]) is list:
            subtrahends = subtrahends[0]
        for subtrahend in subtrahends:
            difference -= Decimal(f"{subtrahend}")

        return self.returned_type(difference)
    
    def multiplication(self, *multipliers):
        product = Decimal("1")

        if type(multipliers[0]) is list:
            multipliers = multipliers[0]
        for multiplier in multipliers:
            product *= Decimal(f"{multiplier}")

        return self.returned_type(product)
    
    def division(self, dividend, *divisors):
        quotient = Decimal(f"{dividend}")

        if type(divisors[0]) is list:
            divisors = divisors[0]

        for divisor in divisors:
            try:
                quotient = quotient / Decimal(f"{divisor}")
            except DivisionByZero:
                raise ZeroDivisionError(f"除数不能为零！")

        return self.returned_type(quotient)
    
    def recursive_range_sum(self, start, end):
        if (end := Decimal(f"{end}")) <= (start := Decimal(f"{start}")):
            return self.returned_type(start)
        else:
            return self.returned_type(self.recursive_range_sum(start, end - 1) + end)
    
    def loop_range_sum(self, start, end):
        sum_ = Decimal("0")

        for addend in range(start, end + 1):
            sum_ += Decimal(f"{addend}")

        return self.returned_type(sum_)
    
    def power(self, n, p, modulo=None):
        product = Decimal(f"{pow(n, p, modulo)}")
        return product
    
    def sqrt(self, n, pow_num=2):
        n = Decimal(f"{n}")
        pow_num = Decimal(f"{pow_num}")
        return self.returned_type(pow(n, 1 / pow_num))
    
    def factorial(self, n):
        if (n := Decimal(f"{n}")) <= 1:
            return self.returned_type(1)
        else:
            return self.returned_type(n * self.factorial(n - 1))


NC = nc = NumbersCalculator

if __name__ == '__main__':
    print(nc.addition(1, 2, 3, 435, 23, 65, 3423458, 324, 12, 434, 542345))
