# This file is part of dax_apdb
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (https://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

__all__ = ["create_sql"]

import warnings
from typing import Any

from ..sql import ApdbSql


def create_sql(output_config: str, ra_dec_columns: str | None, **kwargs: Any) -> None:
    """Create new APDB instance in SQL database.

    Parameters
    ----------
    output_config : `str`
        Name of the file to write APDB configuration.
    ra_dec_columns : `str` or `None`
        Comma-separated list of names for ra/dec columns in DiaObject table.
    **kwargs
        Keyword arguments passed to `ApdbSql.init_database` method.
    """
    ra_dec_tuple: tuple[str, str] | None = None
    if ra_dec_columns:
        ra_dec_list = ra_dec_columns.split(",")
        if len(ra_dec_list) != 2:
            raise ValueError(f"--ra-dec-columns must specify exactly two columns: {ra_dec_columns}")
        ra_dec_tuple = (ra_dec_list[0], ra_dec_list[1])
    config = ApdbSql.init_database(ra_dec_columns=ra_dec_tuple, **kwargs)
    config.save(output_config)
    if output_config.endswith(".py"):
        warnings.warn(
            "APDB configuration is now saved in YAML format, "
            "output file should use .yaml extension instead of .py."
        )
