# This file is part of sdm_schemas.
#
# Developed for the LSST Data Management System.
# This product includes software developed by the LSST Project
# (https://www.lsst.org).
# See the COPYRIGHT file at the top-level directory of this distribution
# for details of code ownership.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import unittest
import importlib.resources
import yaml

from felis.datamodel import Schema


class SchemaResourceTestCase(unittest.TestCase):
    """Test reading of schema data from a resource."""

    def test_read_resource(self) -> None:
        """Test that schema data can be read from a resource."""
        resource = importlib.resources.files("lsst.sdm.schemas").joinpath(
            "dp02_dc2.yaml"
        )
        raw_data = resource.read_text()
        data = yaml.safe_load(raw_data)
        Schema.model_validate(data)


if __name__ == "__main__":
    unittest.main()
