# Authors

lswifi was created by Josh Schmelzle.

## Maintainers

- Josh Schmelzle (@joshschmelzle)

## Contributors

- Colin Vallance (@crvallance)

## Credits

Thanks to many other makers contributions to open source which inspired ideas for this project. Python, nmap, horst, tcpdump, airport CLI utility (now deprecated on macOS Sonoma replaced by wdutil), etc.

Special thanks to Helge Magnus Keck (@HelgeKeck). This project would not be where it is without his initial guidance.
