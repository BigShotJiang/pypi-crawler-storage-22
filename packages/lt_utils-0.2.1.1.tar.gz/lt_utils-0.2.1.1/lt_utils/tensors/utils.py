import math
import torch
import numpy as np
from torch import nn, Tensor
from torch.nn import functional as F
from ..common import Number, Literal, Optional, List, Tuple, Union, Any, Sequence, Dict, Callable
from ..types import check_string_on_list

DEFAULT_DEVICE = torch.zeros(1).device


def get_device(module: nn.Module):
    for param in module.parameters():
        return param.device
    return DEFAULT_DEVICE


def sp_to_linear(base: Tensor, lin_fb: Tensor, eps: float = 1e-8) -> Tensor:
    """Approximate inversion of 'base' to 'lin_fb' using pseudo-inverse."""
    mel_fb_inv = torch.pinverse(lin_fb)
    return torch.matmul(mel_fb_inv, base + eps)


def stretch_tensor(x: Tensor, rate: float, mode: str = "linear") -> Tensor:
    """Time-stretch tensor using interpolation."""
    B = 1 if x.ndim < 2 else x.shape[0]
    C = 1 if x.ndim < 3 else x.shape[-2]
    T = x.shape[-1]
    new_t = int(T * rate)
    stretched = F.interpolate(x.view(B * C, T), size=new_t, mode=mode)
    return stretched.view(B, C, new_t)


def stft_phase_ola(
    stft: Tensor, n_fft: int, hop_length: int, win_length: int = None, window=None
):
    """
    Reconstruct phase (OLA style) from complex STFT.
    Args:
        stft: [B, F, T] complex tensor
        n_fft: FFT size
        hop_length: hop size
        win_length: window length
        window: torch window (optional)
    Returns:
        phase: [B, F, T] tensor of angles (radians)
    """
    # Inverse STFT (reconstruct waveform by overlap-add)
    if not torch.is_complex(stft):
        stft = view_as_complex(stft)

    wav = torch.istft(
        stft, n_fft=n_fft, hop_length=hop_length, win_length=win_length, window=window
    )
    # Forward STFT again to enforce consistency
    stft_re = torch.stft(
        wav,
        n_fft=n_fft,
        hop_length=hop_length,
        win_length=win_length,
        window=window,
        return_complex=True,
    )

    return torch.angle(stft_re)


def view_as_complex(tensor: Tensor):
    if not torch.is_complex(tensor):
        if tensor.size(-1) == 2 and torch.ndim > 2:  # maybe real+imag as last dim
            try:
                return torch.view_as_complex(tensor)
            except:
                pass

        # treat as real and multiply by 1j
        return tensor * (1j)
    return tensor


def ensure_2d(x: Tensor):
    if x.ndim == 2:
        return x
    B = 1 if x.ndim < 2 else x.size(0)
    return x.view(B, -1)


def ensure_3d(x: Tensor, t_centered: bool = False):
    if x.ndim != 3:
        B = 1 if x.ndim < 2 else x.size(0)
        T = 1 if not x.ndim else x.size(-1)  # scalar
        x = x.view(B, -1, T)
        if t_centered:
            x = x.transpose(-1, -2)
    return x


def ensure_4d(x: Tensor, t_centered: bool = False):
    if x.ndim != 4:
        B = 1 if x.ndim < 2 else x.size(0)
        T = 1 if not x.ndim else x.size(-1)
        x = x.view(B, 1, -1, T)
        if t_centered:
            x = x.transpose(-2, -3)
    return x


def compact_embeddings(
    x: Tensor,
    factor: int = 2,
    normalize: bool = True,
) -> Tensor:
    """
    Compact embeddings along the feature dimension by averaging groups of size `factor`.
    Args:
        x: [B, D] or [B, T, D] tensor
        factor: reduction factor
        normalize: whether to L2-normalize after compaction
    Returns:
        compacted tensor with reduced feature dimension
    """
    if x.shape[-1] % factor != 0:
        raise ValueError(f"Feature dim {x.shape[-1]} not divisible by factor={factor}")

    new_dim = x.shape[-1] // factor
    shape = list(x.shape[:-1]) + [new_dim, factor]
    x = x.reshape(shape).mean(dim=-1)

    if normalize:
        norm = torch.norm(x, p=2, dim=-1, keepdim=True).clamp(min=1e-6)
        x = x / norm
    return x


def log_magnitude(stft_complex: Tensor, eps: float = 1e-6) -> Tensor:
    """
    Compute magnitude from STFT tensor.
    Args:
        stft: [B, F, T] tensor (complex or real)
    Returns:
        magnitude: [B, F, T] real tensor
    """
    if not torch.is_complex(stft):
        stft = view_as_complex(stft)
    magnitude = torch.abs(stft_complex)
    return torch.log(magnitude + eps)


def sub_outer(tensor: Tensor, other: Tensor):
    return tensor.reshape(-1, 1) - other


def normalize_minmax(
    x: Tensor,
    min_val: float = -1.0,
    max_val: float = 1.0,
    dim: Union[Sequence[int], int] = (),
    eps: float = 1e-6,
) -> Tensor:
    """Scales tensor to [min_val, max_val] range."""
    x_min, x_max = x.amin(dim=dim), x.amax(dim=dim)
    return (x - x_min) / (x_max - x_min + eps) * (max_val - min_val) + min_val


def normalize_zscore(
    x: Tensor, dim: int = -1, keep_dims: bool = True, eps: float = 1e-6
):
    mean = x.mean(dim=dim, keepdim=keep_dims)
    std = x.std(dim=dim, keepdim=keep_dims)
    return (x - mean) / (std + eps)


def spectral_norm(x: Tensor, c: int = 1, eps: float = 1e-6) -> Tensor:
    return torch.log(torch.clamp(x, min=eps) * c)


def spectral_de_norm(x: Tensor, c: int = 1) -> Tensor:
    return torch.exp(x) / c


def channel_randomizer(
    x: Tensor,
    combinations: int = 1,
    dim: int = 1,
) -> Tensor:
    """
    Randomizes channels along a dimension, with optional grouping.
    Args:
        x: Tensor [B, C, T] or [C, T]
        combinations: Number of groups/combinations to split channels into.
                groups=1 -> shuffle all channels freely
                groups=C -> no shuffle
        dim: channel dimension (1 for [B, C, T], 0 for [C, T])
    Returns:
        shuffled tensor
    """
    C = x.shape[dim]
    if C % combinations != 0:
        raise ValueError(
            f"Number of channels {C} not divisible by groups={combinations}"
        )

    # reshape into groups
    group_size = C // combinations
    shape = list(x.shape)
    shape[dim] = combinations
    shape.insert(dim + 1, group_size)
    xg = x.reshape(shape)

    # permutation of groups
    perm = torch.randperm(combinations, device=x.device)
    xg = xg.index_select(dim, perm)

    # flatten back
    x = xg.reshape(list(x.shape))
    return x


def channel_randomizer2(
    x: Tensor,
    groups: int = 1,
    dim: int = 1,
    shuffle_within: bool = False,
) -> Tensor:
    """
    Randomizes/shuffles channels in groups, optionally shuffling inside groups as well.
    Args:
        x: [B, C, T] or [C, T] tensor
        groups: number of groups to split channels into
        dim: channel dimension (default=1 for batched)
        shuffle_within: if True, shuffle channels inside each group,
                        if False, only shuffle group order
    Returns:
        shuffled tensor (detached, no graph)
    """
    import numpy as np

    C = x.shape[dim]
    if C % groups != 0:
        raise ValueError(f"Channels ({C}) must be divisible by groups={groups}")
    group_size = C // groups

    # Reshape into groups
    shape = list(x.shape)
    shape[dim] = groups
    shape.insert(dim + 1, group_size)
    xg = x.detach().reshape(shape)

    if shuffle_within:
        # Shuffle inside each group independently
        idx = np.arange(group_size)
        perms = [np.random.permutation(idx) for _ in range(groups)]
        perms = np.stack(perms)
        perms = torch.from_numpy(perms).to(x.device)

        arange_groups = torch.arange(groups, device=x.device)[:, None].expand(
            -1, group_size
        )
        xg = xg[(*[slice(None)] * dim, arange_groups, perms)]
    else:
        # Shuffle groups only
        perm = torch.randperm(groups, device=x.device)
        xg = xg.index_select(dim, perm)

    return xg.reshape(list(x.shape))


def non_zero(value: Union[float, Tensor]):
    if not (value == 0).any().item():
        return value + torch.finfo(value.dtype).tiny
    return value


def log_norm(
    self, entry: Tensor, std: Number = 4, mean: Number = -4, eps: float = 1e-6
) -> Tensor:
    return (torch.log(eps + entry.unsqueeze(0)) - mean) / max(
        std + torch.finfo(entry.dtype).tiny
    )


def clip_gradients(model: nn.Module, max_norm: float = 1.0):
    """Applies gradient clipping."""
    return nn.utils.clip_grad_norm_(model.parameters(), max_norm)


def detach(entry: Union[Tensor, Tuple[Tensor, ...]]):
    """Detaches tensors (for RNNs)."""
    if isinstance(entry, Tensor):
        return entry.detach()
    return tuple(detach(h) for h in entry)


def move_list_to_device(
    entries: Union[List[Union[Any, Tensor]], Tuple[Union[Any, Tensor], ...]],
    device: Union[str, torch.device],
    max_depth: int = 3,
    *,
    _depth: int = 0,
):
    was_tuple = isinstance(entries, tuple)
    if was_tuple:
        entries_list = [x for x in entries]
        entries = entries_list

    for i in range(len(entries)):
        if isinstance(entries[i], Tensor):
            entries[i] = entries[i].to(device=device)
        elif _depth >= max_depth:
            continue
        elif isinstance(entries[i], dict):
            entries[i] = move_dict_to_device(
                entries[i], device=device, _depth=_depth + 1
            )
        elif isinstance(entries[i], (tuple, list)):
            entries[i] = move_list_to_device(
                entries[i], device=device, _depth=_depth + 1
            )
    if was_tuple:
        return tuple(entries)
    return entries


def move_dict_to_device(
    entries: Dict[str, Union[Any, Tensor]],
    device: Union[str, torch.device],
    max_depth: int = 3,
    *,
    _depth: int = 0,
):
    keys = list(entries.keys())
    for k in keys:
        if isinstance(entries[k], Tensor):
            entries[k] = entries[k].to(device)
        elif _depth >= max_depth:
            continue
        elif isinstance(entries[k], dict):
            entries[k] = move_dict_to_device(
                entries[k], device=device, _depth=_depth + 1
            )
        elif isinstance(entries[k], (list, tuple)):
            entries[k] = move_list_to_device(
                entries[k], device=device, _depth=_depth + 1
            )
    return entries


def safe_divide(a: Tensor, b: Tensor, eps: float = 1e-6):
    """Safe division for tensors (prevents divide-by-zero)."""
    b = torch.as_tensor(b, device=a.device, dtype=a.dtype)
    if b.is_nonzero():
        return a / b
    return a / eps


def normalize_unit_norm(x: Tensor, eps: float = 1e-6):
    norm = torch.norm(x, dim=-1, keepdim=True)
    return x / (norm + eps)


def time_weighted_avg(data: np.ndarray, alpha: float = 0.9) -> np.ndarray:
    """
    Compute time-weighted moving average for smoothing.
    Args:
        data: [T] or [N, T] tensor / array (time series)
        alpha: smoothing factor (0 < alpha < 1), higher = smoother
    Returns:
        smoothed array of same shape
    """
    data = np.asanyarray(data).squeeze()
    if data.ndim == 1:
        out = np.zeros_like(data)
        out[0] = data[0]
        for t in range(1, len(data)):
            out[t] = alpha * out[t - 1] + (1 - alpha) * data[t]
        return out
    elif data.ndim == 2:
        out = np.zeros_like(data)
        out[:, 0] = data[:, 0]
        for t in range(1, data.shape[1]):
            out[:, t] = alpha * out[:, t - 1] + (1 - alpha) * data[:, t]
        return out
    else:
        raise ValueError("Data must be 1D or 2D time series")


def time_weighted_ema(
    x: Tensor,
    time_weights: Optional[Tensor] = None,
    alpha: float = 0.9,
    normalize: bool = False,
    eps: float = 1e-8,
    ret_type: Literal["pytorch", "list", "numpy"] = "pytorch",
):
    """
    Compute a time-weighted exponential moving average (EMA) for a 1D or 2D tensor.

    Args:
        x (torch.Tensor): Input tensor of shape (T,) or (B, T)
        time_weights (torch.Tensor, optional): Relative weights per time step.
            Must be broadcastable to x.shape. If None, uses uniform spacing.
        alpha (float): Smoothing factor in [0,1]. Higher means slower decay.
        normalize (bool): If True, normalize EMA output to zero mean/unit variance.
        eps (float): Small constant to prevent division by zero.

    Returns:
        torch.Tensor: Time-weighted EMA of same shape as input.
    """
    check_string_on_list(ret_type, valid_entries=["pytorch", "list", "numpy"])

    x = torch.as_tensor(x)

    if x.ndim != 2:
        x = x.view(1, -1)

    T = x.size(-1)

    if time_weights is None:
        time_weights = torch.ones(T, device=x.device)
    else:
        time_weights = torch.as_tensor(time_weights, device=x.device)

    # Normalize time weights to ensure stability
    time_weights = time_weights / (time_weights.max() + eps)

    ema = torch.zeros_like(x)
    ema[:, 0] = x[:, 0]

    for t in range(1, T):
        # Adjust decay using time weighting
        decay = alpha ** time_weights[t]
        ema[:, t] = decay * ema[:, t - 1] + (1 - decay) * x[:, t]

    if normalize:
        mean = ema.mean(dim=-1, keepdim=True)
        std = ema.std(dim=-1, keepdim=True) + eps
        ema = (ema - mean) / std

    ema = ema.squeeze()
    if ret_type == "pytorch":
        return ema
    cl_ema = ema.clone().detach().cpu()

    if ret_type == "list":
        return cl_ema.tolist()
    return cl_ema.numpy(force=True)






def alpha_bar_laplace(t: Number, mu: Number = 0, b: Number = 1):
    snr = mu - b * math.copysign(1, 0.5 - t) * math.log(1 - 2 * abs(t - 0.5) * 0.98)
    return 1 - 1 / (math.exp(snr) + 1.02)


def alpha_bar_cauchy(t: Number, gamma: Number = 1, mu: Number = 3):
    snr = mu + gamma * math.tan(math.pi * (0.5 - t) * 0.9)
    return 1 - 1 / (math.exp(snr) + 1.1)


def alpha_bar_exp(t: Number):
    return math.exp(t * -12.0)


def alpha_bar_cosine(t: Number):
    return math.cos((t + 0.008) / 1.008 * math.pi / 2) ** 2


def betas_for_alpha_bars(num_time_steps: int, alpha_bar_fn: Callable[[Number], Number]):
    betas = []
    for i in range(num_time_steps):
        t1 = i / num_time_steps
        t2 = (i + 1) / num_time_steps
        betas.append(min(1 - alpha_bar_fn(t2) / alpha_bar_fn(t1), num_time_steps))
    return torch.tensor(betas, dtype=torch.float32)


def rescale_zero_terminal_snr(betas: Tensor):
    """

    Rescales betas to have zero terminal SNR Based on https://arxiv.org/pdf/2305.08891.pdf (Algorithm 1)


    Args:
        betas (`Tensor`):
            the betas that the scheduler is being initialized with.

    Returns:
        `Tensor`: rescaled betas with zero terminal SNR

    Note:
        Modified from diffusers.schedulers.scheduling_ddim.rescale_zero_terminal_snr
    """
    # Convert betas to alphas_bar_sqrt
    alphas_bar_sqrt = (1.0 - betas).cumprod(dim=0).sqrt()

    # Store old values.
    alphas_bar_sqrt_0 = alphas_bar_sqrt[0].clone()
    alphas_bar_sqrt_T = alphas_bar_sqrt[-1].clone()

    # Shift so the last timestep is zero.
    alphas_bar_sqrt -= alphas_bar_sqrt_T

    # Scale so the first timestep is back to the old value.
    alphas_bar_sqrt *= alphas_bar_sqrt_0 / (alphas_bar_sqrt_0 - alphas_bar_sqrt_T)

    # Convert alphas_bar_sqrt to betas
    alphas_bar = alphas_bar_sqrt**2  # Revert sqrt
    alphas = alphas_bar[1:] / alphas_bar[:-1]  # Revert cumprod
    alphas = torch.cat([alphas_bar[0:1], alphas])
    betas = 1.0 - alphas

    return betas


def add_gaussian_noise(x: Tensor, noise_level: float = 0.025) -> Tensor:
    noise = torch.randn_like(x) * noise_level
    return x + noise


def add_uniform_noise(x: Tensor, noise_level: float = 0.025) -> Tensor:
    noise = (torch.rand_like(x) - 0.5) * 2 * noise_level
    return x + noise


def add_linear_noise(x, noise_level=0.05) -> Tensor:
    T = x.shape[-1]
    ramp = torch.linspace(0, noise_level, T, device=x.device)
    for _ in range(x.dim() - 1):
        ramp = ramp.unsqueeze(0)
    return x + ramp.expand_as(x)


def add_impulse_noise(x: Tensor, noise_level: float = 0.025) -> Tensor:
    probs = torch.rand_like(x)
    x_clone = x.detach().clone()
    x_clone[probs < (noise_level / 2)] = 0.0  # s
    x_clone[probs > (1 - noise_level / 2)] = 1.0  # p
    return x_clone


class NoiseScheduler(nn.Module):
    """
    Diffusion-style noise scheduler for e-prediction training.

    Returns (x_t, eps, t) for training, where
        x_t = sqrt(alpha_bar_t) * x0 + sqrt(1 - alpha_bar_t) * eps
    """

    def __init__(
        self,
        max_steps: int = 50,
        beta_start: float = 1e-4,
        beta_end: float = 0.05,
    ):
        super().__init__()
        self.scheduler_steps = max_steps

        # beta/alpha schedules
        betas = torch.linspace(beta_start, beta_end, max_steps)
        alphas = 1.0 - betas
        alpha_bars = torch.cumprod(alphas, dim=0)

        self.register_buffer("betas", betas)
        self.register_buffer("alphas", alphas)
        self.register_buffer("alpha_bars", alpha_bars)

    def _sample_timesteps(self, batch: int) -> Tensor:
        """Uniform random timestep per sample, shape (B,)"""
        return torch.randint(
            0,
            self.scheduler_steps,
            (batch,),
            device=self.betas.device,
            dtype=torch.long,
        )

    def q_sample(self, x0: Tensor, t: Tensor = None) -> tuple[Tensor, Tensor, Tensor]:
        """
        Forward diffusion: sample x_t and return (x_t, noise, t).
        x0 : clean waveform, shape (B, C, L)
        t  : optional LongTensor of shape (B,)
        """
        B = x0.size(0)
        if t is None:
            t = self._sample_timesteps(B)
        else:
            t = torch.as_tensor(t, dtype=torch.long, device=self.betas.device)

        eps = torch.randn_like(x0)
        a_bar = self.alpha_bars[t].view(B, 1, 1)  # (B,1,1)
        x_t = a_bar.sqrt() * x0 + torch.sqrt(1.0 - a_bar) * eps
        return x_t, eps, t

    def loss(self, model: nn.Module, x0: Tensor, cond: Tensor = None) -> Tensor:
        """
        DDPM ε-prediction loss.
        Samples x_t ~ q(x_t|x0) and computes MSE between
        predicted and true noise.
        """
        x_t, eps, t = self.q_sample(x0)  # x_t, ε, t
        eps_pred = model.train_step(x_t, t, cond)  # your net outputs ε̂
        return F.l1_loss(eps_pred, eps)

    @torch.no_grad()
    def p_sample(
        self, model: nn.Module, x: Tensor, t: int, cond: Tensor = None
    ) -> Tensor:
        """
        Single reverse step: x_{t-1} from x_t using predicted ε.
        """

        beta_t = self.betas[t]
        a_t = self.alphas[t]
        a_bar_t = self.alpha_bars[t]
        t = torch.as_tensor(t, dtype=torch.long, device=x.device).view(1, -1)

        eps_pred = model(x, t, cond.to(x.device))

        coef1 = 1.0 / torch.sqrt(a_t)
        coef2 = beta_t / torch.sqrt(1.0 - a_bar_t)
        mean = coef1 * (x - coef2 * eps_pred)
        if t > 0:
            noise = torch.randn_like(x)
            sigma = torch.sqrt(beta_t)
            return mean + (sigma * noise)
        return mean

    def sample(
        self,
        model: nn.Module,
        cond: Optional[Tensor] = None,
        latent: Optional[Tensor] = None,
        hop_length: int = 256,
        steps: Optional[int] = None,
    ) -> Tensor:
        """
        Iteratively sample x_0 from pure noise.
        shape: (B, C, L)
        """
        assert (
            cond is not None or latent is not None
        ), "Either a condition should be given or a latent should be given."
        if steps is None:
            steps = self.scheduler_steps
        else:
            steps = int(min(self.scheduler_steps, steps))
        device = get_device(model)

        if latent is not None:
            x = latent.clone().to(device=device)
        else:
            x = torch.randn(1, 1, hop_length * cond.size(-1), device=device)

        for t in reversed(range(steps)):
            x = self.p_sample(model, x, t, cond)
        return x
