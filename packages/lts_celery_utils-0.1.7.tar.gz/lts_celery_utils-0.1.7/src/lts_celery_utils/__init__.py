from os import environ
import logging

__version__ = "0.1.7"


def configure_logger():  # pragma: no cover
    log_level = environ.get("APP_LOG_LEVEL", "WARNING")
    formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - ' +
                '[%(filename)s:%(funcName)s:%(lineno)d] - %(message)s')

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger = logging.getLogger('lts_celery_utils')
    if not logger.handlers:  # Check if handlers already exist
        logger.addHandler(console_handler)
    logger.setLevel(log_level)

    return logger


logger = configure_logger()
