import celery as celeryapp
import time
from kombu.exceptions import OperationalError
from lts_celery_utils import logger


def reliable_send_task(task_name, args, kwargs, queue, max_retries=3):
    """
    Reliably send a task with automatic retry logic and message persistence.

    Args:
        task_name: Full task name (e.g., "tasks.tasks.do_task")
        args: Task arguments
        kwargs: Task keyword arguments
        queue: Target queue name
        max_retries: Number of retry attempts
    """
    for attempt in range(max_retries):
        try:
            celeryapp.execute.send_task(
                task_name,
                args=args,
                kwargs=kwargs,
                queue=queue,
                options={"delivery_mode": 2}  # 2 = persistent message
            )
            logger.info(f"Task {task_name} sent successfully to queue {queue}")
            return True
        except OperationalError as e:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # exponential backoff
                logger.warning(
                    f"Retrying to send task {task_name} "
                    f"(attempt {attempt + 1}) due to error: {e}"
                )
            else:
                logger.error(
                    f"reliable_send_task failed to send task {task_name} " +
                    f"after {max_retries} attempts"
                )
                return False
