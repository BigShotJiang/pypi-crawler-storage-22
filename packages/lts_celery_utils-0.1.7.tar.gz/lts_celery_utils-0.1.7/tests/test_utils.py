import pytest
from unittest.mock import patch
from kombu.exceptions import OperationalError

from lts_celery_utils.utils import reliable_send_task


class TestReliableSendTask:
    """Tests for reliable_send_task function."""

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_successful_send_on_first_attempt(self, mock_logger, mock_send):
        """Test that task is sent successfully on first attempt."""
        result = reliable_send_task(
            task_name="my.task",
            args=(1, 2),
            kwargs={"key": "value"},
            queue="default",
        )

        assert result is True
        mock_send.assert_called_once_with(
            "my.task",
            args=(1, 2),
            kwargs={"key": "value"},
            queue="default",
            options={"delivery_mode": 2},
        )
        mock_logger.warning.assert_not_called()

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.time.sleep")
    @patch("lts_celery_utils.utils.logger")
    def test_retries_on_failure_then_succeeds(
        self, mock_logger, mock_sleep, mock_send
    ):
        """Test that task is retried and eventually succeeds."""
        # Fail twice, succeed on third attempt
        mock_send.side_effect = [
            OperationalError("Connection error"),
            OperationalError("Connection error"),
            None,
        ]

        result = reliable_send_task(
            task_name="my.task",
            args=(1,),
            kwargs={},
            queue="default",
            max_retries=3,
        )

        assert result is True
        assert mock_send.call_count == 3
        # Verify exponential backoff: sleep(1) then sleep(2)
        mock_sleep.assert_any_call(1)
        mock_sleep.assert_any_call(2)
        assert mock_logger.warning.call_count == 2

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.time.sleep")
    @patch("lts_celery_utils.utils.logger")
    def test_raises_exception_after_max_retries(
        self, mock_logger, mock_sleep, mock_send
    ):
        """Test that function returns False after max retries are exhausted."""
        mock_send.side_effect = OperationalError("Connection error")

        result = reliable_send_task(
            task_name="my.task",
            args=(1,),
            kwargs={},
            queue="default",
            max_retries=3,
        )

        assert result is False
        assert mock_send.call_count == 3
        mock_logger.error.assert_called_once()

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_single_retry_failure(self, mock_logger, mock_send):
        """Test with max_retries=1 (no retries, just one attempt)."""
        mock_send.side_effect = OperationalError("Connection error")

        result = reliable_send_task(
            task_name="my.task",
            args=(1,),
            kwargs={},
            queue="default",
            max_retries=1,
        )

        assert result is False
        assert mock_send.call_count == 1

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_no_retry_on_first_success(self, mock_logger, mock_send):
        """Test that no retries occur when first attempt succeeds."""
        result = reliable_send_task(
            task_name="my.task",
            args=(),
            kwargs={},
            queue="default",
            max_retries=5,
        )

        assert result is True
        assert mock_send.call_count == 1

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.time.sleep")
    @patch("lts_celery_utils.utils.logger")
    def test_exponential_backoff(self, mock_logger, mock_sleep, mock_send):
        """Test exponential backoff timing between retries."""
        mock_send.side_effect = [
            OperationalError("Error"),
            OperationalError("Error"),
            OperationalError("Error"),
            None,
        ]

        result = reliable_send_task(
            task_name="my.task",
            args=(1,),
            kwargs={},
            queue="default",
            max_retries=4,
        )

        assert result is True
        # Exponential backoff: 2^0=1, 2^1=2, 2^2=4
        mock_sleep.assert_any_call(1)
        mock_sleep.assert_any_call(2)
        mock_sleep.assert_any_call(4)
        assert mock_sleep.call_count == 3

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_only_catches_operational_error(self, mock_logger, mock_send):
        """Test that only OperationalError is caught, others are raised."""
        mock_send.side_effect = ValueError("Invalid argument")

        with pytest.raises(ValueError, match="Invalid argument"):
            reliable_send_task(
                task_name="my.task",
                args=(1,),
                kwargs={},
                queue="default",
                max_retries=3,
            )

        # Should fail immediately without retries
        assert mock_send.call_count == 1

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_logger_warning_on_retry(self, mock_logger, mock_send):
        """Test that warning is logged on retry."""
        mock_send.side_effect = [
            OperationalError("Connection timeout"),
            None,
        ]

        result = reliable_send_task(
            task_name="test.task",
            args=(1, 2),
            kwargs={"key": "value"},
            queue="test_queue",
            max_retries=2,
        )

        assert result is True
        mock_logger.warning.assert_called_once()
        # Check that the warning message mentions the task name
        warning_call_args = mock_logger.warning.call_args[0][0]
        assert "test.task" in warning_call_args

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_logger_error_on_final_failure(self, mock_logger, mock_send):
        """Test that error is logged on final failure."""
        mock_send.side_effect = OperationalError("Connection failed")

        result = reliable_send_task(
            task_name="my.task",
            args=(1,),
            kwargs={},
            queue="default",
            max_retries=2,
        )

        assert result is False
        mock_logger.error.assert_called_once()
        error_call_args = mock_logger.error.call_args[0][0]
        assert "my.task" in error_call_args

    @patch("lts_celery_utils.utils.celeryapp.execute.send_task")
    @patch("lts_celery_utils.utils.logger")
    def test_persistent_message_delivery_mode(self, mock_logger, mock_send):
        """Test that persistent delivery mode (2) is used."""
        result = reliable_send_task(
            task_name="my.task",
            args=(1, 2),
            kwargs={"a": "b"},
            queue="default",
        )

        assert result is True
        # Verify delivery_mode is set to 2 (persistent)
        call_args = mock_send.call_args
        assert call_args[1]["options"]["delivery_mode"] == 2
