### Rules

At any cost avoid using Any type.
Do not mute lint checks. Do not exclude tests.



### Tests

**Running Unin and Integration Tests:**

```bash
# Load environment variables from .env.test
uv run --env-file .env.test pytest tests/unit/ tests/integration/
```


**Running E2E Tests:**

```bash
# Load environment variables from .env.test
uv run --env-file .env.test pytest tests/e2e/
```

