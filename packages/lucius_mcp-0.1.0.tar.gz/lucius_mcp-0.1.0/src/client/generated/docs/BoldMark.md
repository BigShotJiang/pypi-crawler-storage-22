# BoldMark


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from src.client.generated.models.bold_mark import BoldMark

# TODO update the JSON string below
json = "{}"
# create an instance of BoldMark from a JSON string
bold_mark_instance = BoldMark.from_json(json)
# print the JSON string representation of the object
print(BoldMark.to_json())

# convert the object into a dict
bold_mark_dict = bold_mark_instance.to_dict()
# create an instance of BoldMark from a dict
bold_mark_from_dict = BoldMark.from_dict(bold_mark_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


