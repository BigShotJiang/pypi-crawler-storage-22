# CleanerSchemaTargetDto


## Enum

* `ATTACHMENT` (value: `'attachment'`)

* `SCENARIO` (value: `'scenario'`)

* `FIXTURE` (value: `'fixture'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


