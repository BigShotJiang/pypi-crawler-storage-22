# CodeMark


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from src.client.generated.models.code_mark import CodeMark

# TODO update the JSON string below
json = "{}"
# create an instance of CodeMark from a JSON string
code_mark_instance = CodeMark.from_json(json)
# print the JSON string representation of the object
print(CodeMark.to_json())

# convert the object into a dict
code_mark_dict = code_mark_instance.to_dict()
# create an instance of CodeMark from a dict
code_mark_from_dict = CodeMark.from_dict(code_mark_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


