# ExportType


## Enum

* `LAUNCH_PDF` (value: `'LAUNCH_PDF'`)

* `TEST_CASE_CSV` (value: `'TEST_CASE_CSV'`)

* `TEST_RESULT_CSV` (value: `'TEST_RESULT_CSV'`)

* `TEST_CASE_PDF` (value: `'TEST_CASE_PDF'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


