# FilterTypeDto


## Enum

* `TEST_CASE` (value: `'TEST_CASE'`)

* `LAUNCH` (value: `'LAUNCH'`)

* `TEST_RESULT` (value: `'TEST_RESULT'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


