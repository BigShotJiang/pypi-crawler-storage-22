# IntegrationRoutineTypeDto


## Enum

* `ENDPOINT` (value: `'endpoint'`)

* `ISSUE_URL` (value: `'issue_url'`)

* `TEST_KEY_URL` (value: `'test_key_url'`)

* `WEBHOOK` (value: `'webhook'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


