# ItalicMark


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from src.client.generated.models.italic_mark import ItalicMark

# TODO update the JSON string below
json = "{}"
# create an instance of ItalicMark from a JSON string
italic_mark_instance = ItalicMark.from_json(json)
# print the JSON string representation of the object
print(ItalicMark.to_json())

# convert the object into a dict
italic_mark_dict = italic_mark_instance.to_dict()
# create an instance of ItalicMark from a dict
italic_mark_from_dict = ItalicMark.from_dict(italic_mark_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


