# JobRunStageDto


## Enum

* `RUN_FAILURE` (value: `'run_failure'`)

* `SCHEDULED` (value: `'scheduled'`)

* `IN_PROGRESS` (value: `'in_progress'`)

* `FINISHED` (value: `'finished'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


