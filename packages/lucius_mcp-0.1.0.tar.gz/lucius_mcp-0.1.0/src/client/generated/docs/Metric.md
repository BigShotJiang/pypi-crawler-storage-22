# Metric


## Enum

* `DURATION` (value: `'duration'`)

* `SUCCESS_RATE` (value: `'success_rate'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


