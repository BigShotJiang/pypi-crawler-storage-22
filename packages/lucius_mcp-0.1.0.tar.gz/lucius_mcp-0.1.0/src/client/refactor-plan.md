# Refactor Plan for `src/client/client.py`

This plan targets the repetition hotspots documented in `src/client/refactor-hotspots.md` and keeps behavior unchanged.

## Goals
- Reduce repeated guards, token refresh checks, and exception handling boilerplate.
- Centralize controller access and error messaging.
- Deduplicate scenario step creation and attachment upload flows.
- Keep API behavior and error semantics identical.

## Non-goals
- No functional changes to API behavior or response handling.
- No changes to external interfaces beyond internal helper use.
- No changes to configuration, logging, or test behavior.

## Step-by-step plan

1. **Introduce a shared “entered” guard helper**
   - **Why:** Replaces repeated `if not self._is_entered ...` checks across methods (e.g., `src/client/client.py:397`, `:462`, `:510`, `:551`, `:634`, `:846`).
   - **Action:** Add a private method (e.g., `_require_entered(self) -> None`) and use it at the top of public API methods.
   - **Behavioral constraint:** Same exception type/message as today.

2. **Add a controller access helper that includes token refresh**
   - **Why:** Many methods do `await self._ensure_valid_token()` and then check a controller attribute (e.g., `:400-404`, `:465-468`, `:513-515`, `:554-556`, `:637-639`).
   - **Action:** Add a helper such as:
     - `_get_api(self, attr_name: str) -> ControllerType`
     - It should call `_require_entered()`, await `_ensure_valid_token()`, and return the controller or raise the same “Internal error: X_api not initialized” message.
   - **Behavioral constraint:** Preserve error text formatting exactly.

3. **Centralize `ApiException` mapping**
   - **Why:** Many methods have identical `try/except ApiException` blocks calling `_handle_api_exception` (e.g., `:408-416`, `:479-489`, `:517-525`, `:611-618`, `:705-714`).
   - **Action:** Create a helper wrapper such as `_call_api(self, coro: Awaitable[T]) -> T` that awaits the call, catches `ApiException`, routes to `_handle_api_exception`, then re-raises.
   - **Behavioral constraint:** Preserve the same exception mapping and logging.

4. **Extract common scenario step creation logic**
   - **Why:** `create_scenario_step` and `create_shared_step_scenario_step` are nearly identical (see `src/client/client.py:527-593` and `:933-976`).
   - **Action:** Add a private helper like `_create_scenario_step_via_api(...)` that:
     - Calls the `*_without_preload_content` endpoint
     - Validates HTTP status
     - Parses JSON
     - Returns `ScenarioStepCreatedResponseDto.model_construct(...)`
   - **Behavioral constraint:** Keep the same status validation and response parsing.

5. **Extract common attachment upload logic**
   - **Why:** `upload_attachment` and `upload_shared_step_attachment` repeat the same flow (`src/client/client.py:491-525`, `:978-1007`).
   - **Action:** Create a helper to accept controller + target ID + file data, and invoke the corresponding `createXX` method.
   - **Behavioral constraint:** Same exception handling and timeout usage.

6. **Consolidate scenario controller attributes**
   - **Why:** Both `_scenario_api` and `_test_case_scenario_api` are `TestCaseScenarioControllerApi` (see `:173-175`, initialization in `:309-310`).
   - **Action:** Keep a single attribute (prefer `_scenario_api`) and update usages to that single field.
   - **Behavioral constraint:** No change in which endpoints are called.

7. **Centralize “internal error” message formatting**
   - **Why:** Repeated strings with only controller name changed (e.g., `:402`, `:467`, `:515`, `:556`, `:609`, `:639`, `:703`, `:734`, `:918`, `:950`, `:997`, `:1020`, `:1047`, `:1076`).
   - **Action:** Add a helper that formats and raises the same `AllureAPIError` message.
   - **Behavioral constraint:** Preserve exact wording.

8. **Clean up duplicate entries in `__all__`**
   - **Why:** `ScenarioStepCreateDto` and `ScenarioStepCreatedResponseDto` appear twice (`src/client/client.py:97-100`).
   - **Action:** Remove duplicates to keep `__all__` concise and accurate.

9. **Validation & regression checks**
   - **Action:** After refactor, review call sites to ensure all exceptions, timeouts, and API calls are unchanged.
   - **Optional:** Run unit/integration tests if desired (per project test instructions).

## Helper signatures (non-binding)
- `_require_entered(self) -> None`
- `_get_api(self, attr_name: str) -> ControllerType`
- `_call_api(self, coro: Awaitable[T]) -> T`
- `_raise_missing_api(self, api_name: str) -> None`
- `_create_scenario_step_via_api(...) -> ScenarioStepCreatedResponseDto`
- `_upload_attachment_via_api(...) -> list[AttachmentRowType]`

## Notes
- Keep new helpers type-annotated without introducing `Any`.
- Maintain all existing exception classes and messages.
- Avoid changing public method signatures.
