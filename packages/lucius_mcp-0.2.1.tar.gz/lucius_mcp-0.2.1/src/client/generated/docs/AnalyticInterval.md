# AnalyticInterval


## Enum

* `HOUR` (value: `'hour'`)

* `DAY` (value: `'day'`)

* `WEEK` (value: `'week'`)

* `MONTH` (value: `'month'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


