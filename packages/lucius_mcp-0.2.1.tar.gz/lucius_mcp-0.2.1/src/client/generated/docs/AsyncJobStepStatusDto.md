# AsyncJobStepStatusDto


## Enum

* `IN_PROGRESS` (value: `'IN_PROGRESS'`)

* `FAILED` (value: `'FAILED'`)

* `COMPLETED` (value: `'COMPLETED'`)

* `STOPPED` (value: `'STOPPED'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


