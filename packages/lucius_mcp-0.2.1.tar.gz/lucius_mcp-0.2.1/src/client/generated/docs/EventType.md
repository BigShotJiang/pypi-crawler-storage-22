# EventType


## Enum

* `STARTED` (value: `'started'`)

* `CREATED` (value: `'created'`)

* `CLOSED` (value: `'closed'`)

* `DELETED` (value: `'deleted'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


