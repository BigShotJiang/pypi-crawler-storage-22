# IntegrationOperationTypeDto


## Enum

* `ISSUE_CREATE` (value: `'issue_create'`)

* `ISSUE_EXPORT_LAUNCH` (value: `'issue_export_launch'`)

* `ISSUE_SUGGEST` (value: `'issue_suggest'`)

* `ISSUE_SYNC` (value: `'issue_sync'`)

* `JOB_RUN` (value: `'job_run'`)

* `JOB_SUGGEST` (value: `'job_suggest'`)

* `JOB_SYNC` (value: `'job_sync'`)

* `TMS_SYNC` (value: `'tms_sync'`)

* `TEST_KEY_SUGGEST` (value: `'test_key_suggest'`)

* `TEST_KEY_SYNC` (value: `'test_key_sync'`)

* `AI_CHAT` (value: `'ai_chat'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


