# IntegrationTypeDto


## Enum

* `ALLURE_TESTOPS` (value: `'allure_testops'`)

* `AZURE` (value: `'azure'`)

* `BAMBOO` (value: `'bamboo'`)

* `BITBUCKET` (value: `'bitbucket'`)

* `CIRCLECI` (value: `'circleci'`)

* `GITHUB` (value: `'github'`)

* `GITLAB` (value: `'gitlab'`)

* `JENKINS` (value: `'jenkins'`)

* `JIRA` (value: `'jira'`)

* `JIRA_CLOUD` (value: `'jira_cloud'`)

* `REDMINE` (value: `'redmine'`)

* `TARGET_PROCESS` (value: `'target_process'`)

* `TEAMCITY` (value: `'teamcity'`)

* `TEKTON` (value: `'tekton'`)

* `TESTRAIL` (value: `'testrail'`)

* `XRAY` (value: `'xray'`)

* `XRAY_CLOUD` (value: `'xray_cloud'`)

* `YOUTRACK` (value: `'youtrack'`)

* `ZEPHYR_SCALE` (value: `'zephyr_scale'`)

* `ZEPHYR_SCALE_CLOUD` (value: `'zephyr_scale_cloud'`)

* `YANDEX_TRACKER` (value: `'yandex_tracker'`)

* `CUSTOM` (value: `'custom'`)

* `AWS` (value: `'aws'`)

* `WRIKE` (value: `'wrike'`)

* `KAITEN` (value: `'kaiten'`)

* `CHAT_GPT` (value: `'chat_gpt'`)

* `DEEP_SEEK` (value: `'deep_seek'`)

* `MISTRAL_AI` (value: `'mistral_ai'`)

* `OLLAMA` (value: `'ollama'`)

* `YANDEX_GPT` (value: `'yandex_gpt'`)

* `GIGA_CHAT` (value: `'giga_chat'`)

* `BITRIX24` (value: `'bitrix24'`)

* `CLICKUP` (value: `'clickup'`)

* `EVA_PROJECT` (value: `'eva_project'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


