# LaunchPdfPart


## Enum

* `HEADER` (value: `'header'`)

* `TITLE` (value: `'title'`)

* `STATISTIC` (value: `'statistic'`)

* `SUMMARY` (value: `'summary'`)

* `TRBYSTATUSES` (value: `'trByStatuses'`)

* `DETAILS` (value: `'details'`)

* `TCDETAILS` (value: `'tcDetails'`)

* `FOOTER` (value: `'footer'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


