"""
gRPC generated stubs for LuckyEngine.

This module contains the generated protobuf stubs. The client implementation
is in luckyrobots/client.py.
"""
