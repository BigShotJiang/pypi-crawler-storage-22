"""Run a callable or agent across every record in a dataset.

This module provides ``run_experiment`` and ``arun_experiment`` — the local
execution counterpart of server-side Experiments.  The callable can be a plain
function, an async function, or a LangChain/LangGraph Runnable.

Examples:
    Run a simple function across all records:
        >>> from lumenova_beacon.experiments import run_experiment
        >>> from lumenova_beacon.datasets import Dataset
        >>> dataset = Dataset.get("dataset-id")
        >>> result = run_experiment(dataset, lambda x: x.upper(), input_column="Input", output_column="Output")
        >>> print(f"Processed {result.succeeded}/{result.total} records")

    Run a LangGraph agent with tracing:
        >>> result = run_experiment(
        ...     dataset, agent,
        ...     input_column="Input", output_column="Output",
        ...     trace_calls=True,
        ... )
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from lumenova_beacon.datasets.models import Dataset, DatasetRecord
from lumenova_beacon.exceptions import DatasetError, DatasetValidationError

logger = logging.getLogger(__name__)


@dataclass
class RecordError:
    """Details about a failed record execution."""

    record_id: str
    error: Exception
    error_message: str


@dataclass
class RunAllResult:
    """Summary of a run_experiment execution."""

    total: int
    succeeded: int
    failed: int
    errors: list[RecordError] = field(default_factory=list)


async def _fetch_all_records(dataset: Dataset) -> list[DatasetRecord]:
    """Fetch all records from a dataset, handling pagination."""
    all_records: list[DatasetRecord] = []
    page = 1
    page_size = 100

    while True:
        records, pagination = await dataset.alist_records(
            page=page, page_size=page_size
        )
        all_records.extend(records)
        if page >= pagination.total_pages:
            break
        page += 1

    return all_records


async def _ensure_output_column(dataset: Dataset, output_column: str) -> None:
    """Add output_column to dataset schema if it doesn't exist."""
    schema = dataset.column_schema or []
    existing_names = {col["name"] for col in schema}

    if output_column not in existing_names:
        max_order = max((col.get("order", 0) for col in schema), default=-1)
        schema.append({"name": output_column, "order": max_order + 1})
        await dataset.aupdate(column_schema=schema)
        logger.debug("Added column '%s' to dataset schema", output_column)


def _is_langchain_runnable(fn: Any) -> bool:
    """Check if fn is a LangChain Runnable (lazy import)."""
    try:
        from langchain_core.runnables import Runnable

        return isinstance(fn, Runnable)
    except ImportError:
        return False


def _extract_output(raw_output: Any) -> Any:
    """Extract a serializable output value from callable result.

    Handles strings, dicts, lists, primitives as-is.
    Extracts .content from LangChain AIMessage.
    Falls back to str() for unknown types.
    """
    try:
        from langchain_core.messages import AIMessage

        if isinstance(raw_output, AIMessage):
            return raw_output.content
    except ImportError:
        pass

    if isinstance(raw_output, (str, dict, list, int, float, bool)):
        return raw_output

    return str(raw_output)


def _wrap_input_for_runnable(input_value: Any) -> Any:
    """Wrap a plain string/primitive as a LangGraph messages dict.

    LangGraph agents expect ``{"messages": [...]}``.  If the caller already
    provides a dict (i.e. they mapped it themselves), pass it through as-is.
    """
    if isinstance(input_value, dict):
        return input_value

    # Lazy-import HumanMessage so langchain_core stays optional
    try:
        from langchain_core.messages import HumanMessage

        return {"messages": [HumanMessage(content=str(input_value))]}
    except ImportError:
        # langchain_core not installed – best-effort plain dict
        return {"messages": [{"role": "user", "content": str(input_value)}]}


def _extract_runnable_output(raw_output: Any) -> Any:
    """Pull the final assistant message content out of a LangGraph state dict."""
    if isinstance(raw_output, dict) and "messages" in raw_output:
        messages = raw_output["messages"]
        if messages:
            last = messages[-1]
            # LangChain message objects have .content
            if hasattr(last, "content"):
                return last.content
            # Plain dict messages
            if isinstance(last, dict) and "content" in last:
                return last["content"]
    return _extract_output(raw_output)


async def _invoke_runnable(
    fn: Any,
    input_value: Any,
    trace_calls: bool,
    dataset_id: str,
    record_id: str,
) -> Any:
    """Invoke a LangChain Runnable with optional BeaconCallbackHandler."""
    config: dict[str, Any] = {
        # Always provide thread_id — required by LangGraph agents with
        # checkpointers, harmless when there is no checkpointer.
        "configurable": {"thread_id": f"run_experiment:{record_id}"},
    }

    if trace_calls:
        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconCallbackHandler,
        )

        handler = BeaconCallbackHandler(
            metadata={
                "dataset_id": dataset_id,
                "dataset_record_id": record_id,
                "source": "run_experiment",
            },
        )
        config["callbacks"] = [handler]

    # Auto-wrap string inputs as LangGraph messages dict
    wrapped_input = _wrap_input_for_runnable(input_value)

    return await fn.ainvoke(wrapped_input, config=config)


async def _invoke_callable(
    fn: Any,
    mapped_input: Any,
    trace_calls: bool,
    dataset_id: str,
    record_id: str,
) -> Any:
    """Invoke a plain callable with optional trace span."""
    is_async = inspect.iscoroutinefunction(fn)

    if trace_calls:
        from lumenova_beacon.core.client import get_client
        from lumenova_beacon.types import SpanType

        client = get_client()

        async with client.trace(
            f"run_experiment:record-{record_id}", span_type=SpanType.TASK
        ) as span:
            span.set_metadata("dataset_id", dataset_id)
            span.set_metadata("dataset_record_id", record_id)
            span.set_metadata("source", "run_experiment")
            span.set_input(mapped_input)

            if is_async:
                result = await fn(mapped_input)
            else:
                result = await asyncio.to_thread(fn, mapped_input)

            span.set_output(result)
            return result
    else:
        if is_async:
            return await fn(mapped_input)
        else:
            return await asyncio.to_thread(fn, mapped_input)


async def _process_record(
    record: DatasetRecord,
    fn: Any,
    input_column: str,
    output_column: str,
    trace_calls: bool,
    is_runnable: bool,
    semaphore: asyncio.Semaphore,
    dataset_id: str,
    input_mapper: Callable[[Any], Any] | None,
    output_mapper: Callable[[Any], Any] | None,
) -> RecordError | None:
    """Process a single record: invoke fn, write output.

    Returns None on success, RecordError on failure.
    """
    async with semaphore:
        try:
            input_value = record.data.get(input_column)
            if input_value is None:
                raise DatasetValidationError(
                    f"Record {record.id} has no value for column '{input_column}'"
                )

            # Transform input for the callable (e.g. string -> LangGraph state dict)
            mapped_input = input_mapper(input_value) if input_mapper else input_value

            record_id = record.id or "unknown"
            if is_runnable:
                raw_output = await _invoke_runnable(
                    fn, mapped_input, trace_calls, dataset_id, record_id
                )
            else:
                raw_output = await _invoke_callable(
                    fn, mapped_input, trace_calls, dataset_id, record_id
                )

            # Transform output for storage (e.g. LangGraph state dict -> string)
            if output_mapper:
                output_value = output_mapper(raw_output)
            elif is_runnable:
                output_value = _extract_runnable_output(raw_output)
            else:
                output_value = _extract_output(raw_output)

            # Merge output into existing data to preserve other columns
            updated_data = {**record.data, output_column: output_value}
            await record.aupdate(data=updated_data)

            return None

        except Exception as e:
            logger.warning("Error processing record %s: %s", record.id, e)
            return RecordError(
                record_id=record.id,
                error=e,
                error_message=str(e),
            )


async def arun_experiment(
    dataset: Dataset,
    fn: Any,
    *,
    input_column: str,
    output_column: str,
    name: str | None = None,
    input_mapper: Callable[[Any], Any] | None = None,
    output_mapper: Callable[[Any], Any] | None = None,
    trace_calls: bool = True,
    max_concurrency: int = 5,
    on_error: str = "continue",
) -> RunAllResult:
    """Run a callable against every record in a dataset.

    Fetches all records via pagination, invokes fn(input) for each,
    and writes the output back to the record's data[output_column].

    If fn is a LangChain Runnable, a BeaconCallbackHandler is injected
    per-record for deep tracing.  Otherwise, the call is wrapped in a
    client.trace() context manager when trace_calls=True.

    Args:
        dataset: The Dataset to run against (must have an id).
        fn: Callable accepting a single input argument and returning output.
            Can be a plain function, async function, or LangChain Runnable.
        input_column: Column name in record.data to use as input.
        output_column: Column name to write the output to (added to schema if missing).
        name: Optional experiment name.  When provided, creates a server-side
            Experiment record for tracking in the UI.  (Not yet implemented —
            reserved for a future backend endpoint.)
        input_mapper: Transform the column value before passing to fn.
        output_mapper: Transform fn's return value before writing to the record.
            When None, uses built-in extraction (AIMessage.content, str fallback).
        trace_calls: Create tracing spans for each invocation.
        max_concurrency: Maximum concurrent record invocations.
        on_error: "continue" to skip failures, or "raise" to stop on first error.

    Returns:
        RunAllResult with total/succeeded/failed counts and error details.
    """
    if dataset.id is None:
        raise DatasetError(
            "Dataset must be saved before running. Call dataset.save() first."
        )

    if on_error not in ("continue", "raise"):
        raise DatasetValidationError(
            f"on_error must be 'continue' or 'raise', got '{on_error}'"
        )

    if name is not None:
        logger.warning(
            "Server-side experiment tracking (name='%s') is not yet implemented. "
            "The experiment will run locally without creating a server record.",
            name,
        )

    is_runnable = _is_langchain_runnable(fn)

    await _ensure_output_column(dataset, output_column)

    records = await _fetch_all_records(dataset)

    if not records:
        return RunAllResult(total=0, succeeded=0, failed=0)

    semaphore = asyncio.Semaphore(max_concurrency)

    tasks = [
        _process_record(
            record=record,
            fn=fn,
            input_column=input_column,
            output_column=output_column,
            trace_calls=trace_calls,
            is_runnable=is_runnable,
            semaphore=semaphore,
            dataset_id=dataset.id,
            input_mapper=input_mapper,
            output_mapper=output_mapper,
        )
        for record in records
    ]

    results = await asyncio.gather(*tasks)

    errors: list[RecordError] = []
    succeeded = 0
    for result in results:
        if result is None:
            succeeded += 1
        else:
            errors.append(result)
            if on_error == "raise":
                raise result.error

    return RunAllResult(
        total=len(records),
        succeeded=succeeded,
        failed=len(errors),
        errors=errors,
    )


def run_experiment(
    dataset: Dataset,
    fn: Any,
    *,
    input_column: str,
    output_column: str,
    name: str | None = None,
    input_mapper: Callable[[Any], Any] | None = None,
    output_mapper: Callable[[Any], Any] | None = None,
    trace_calls: bool = True,
    max_concurrency: int = 5,
    on_error: str = "continue",
) -> RunAllResult:
    """Run a callable against every record in a dataset (sync).

    Sync wrapper around arun_experiment().
    See arun_experiment() for full documentation.
    """
    return asyncio.run(
        arun_experiment(
            dataset=dataset,
            fn=fn,
            input_column=input_column,
            output_column=output_column,
            name=name,
            input_mapper=input_mapper,
            output_mapper=output_mapper,
            trace_calls=trace_calls,
            max_concurrency=max_concurrency,
            on_error=on_error,
        )
    )
