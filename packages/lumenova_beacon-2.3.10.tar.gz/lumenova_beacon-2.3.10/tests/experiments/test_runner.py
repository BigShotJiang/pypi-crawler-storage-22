"""Tests for the experiment runner (run_experiment / arun_experiment)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from lumenova_beacon.datasets.models import Dataset, DatasetRecord
from lumenova_beacon.datasets.types import PaginatedResponse
from lumenova_beacon.exceptions import DatasetError, DatasetValidationError
from lumenova_beacon.experiments.runner import (
    RecordError,
    RunAllResult,
    _extract_output,
    _fetch_all_records,
    _is_langchain_runnable,
    arun_experiment,
    run_experiment,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_dataset():
    """A Dataset with pre-set id and schema."""
    ds = Dataset(
        id="dataset-123",
        name="test-dataset",
        column_schema=[
            {"name": "Input", "order": 0},
            {"name": "Output", "order": 1},
        ],
        record_count=3,
    )
    return ds


@pytest.fixture
def mock_records():
    """Three sample DatasetRecords."""
    return [
        DatasetRecord(
            id="rec-1",
            dataset_id="dataset-123",
            data={"Input": "hello"},
        ),
        DatasetRecord(
            id="rec-2",
            dataset_id="dataset-123",
            data={"Input": "world"},
        ),
        DatasetRecord(
            id="rec-3",
            dataset_id="dataset-123",
            data={"Input": "test"},
        ),
    ]


def _pagination(total: int, page: int = 1, page_size: int = 100) -> PaginatedResponse:
    """Helper to build a PaginatedResponse."""
    total_pages = max(1, (total + page_size - 1) // page_size)
    return PaginatedResponse(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


# ---------------------------------------------------------------------------
# TestRunExperimentBasic
# ---------------------------------------------------------------------------


class TestRunExperimentBasic:
    """Basic run_experiment / arun_experiment behaviour with plain callables."""

    @pytest.mark.asyncio
    async def test_arun_experiment_with_sync_callable(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        result = await arun_experiment(
            mock_dataset,
            lambda x: x.upper(),
            input_column="Input",
            output_column="Output",
            trace_calls=False,
        )

        assert result.total == 3
        assert result.succeeded == 3
        assert result.failed == 0
        assert result.errors == []

        # Verify each record was updated with correct output
        for rec in mock_records:
            rec.aupdate.assert_called_once()
            call_data = rec.aupdate.call_args[1]["data"]
            assert call_data["Output"] == rec.data["Input"].upper()
            # Original data preserved
            assert "Input" in call_data

    @pytest.mark.asyncio
    async def test_arun_experiment_with_async_callable(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        async def async_upper(x: str) -> str:
            return x.upper()

        result = await arun_experiment(
            mock_dataset,
            async_upper,
            input_column="Input",
            output_column="Output",
            trace_calls=False,
        )

        assert result.total == 3
        assert result.succeeded == 3

    @pytest.mark.asyncio
    async def test_arun_experiment_empty_dataset(self, mock_dataset):
        mock_dataset.alist_records = AsyncMock(
            return_value=([], _pagination(0))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        result = await arun_experiment(
            mock_dataset,
            lambda x: x,
            input_column="Input",
            output_column="Output",
            trace_calls=False,
        )

        assert result.total == 0
        assert result.succeeded == 0
        assert result.failed == 0

    @pytest.mark.asyncio
    async def test_arun_experiment_unsaved_dataset_raises(self):
        ds = Dataset(name="unsaved")

        with pytest.raises(DatasetError, match="must be saved"):
            await arun_experiment(
                ds,
                lambda x: x,
                input_column="Input",
                output_column="Output",
            )

    @pytest.mark.asyncio
    async def test_arun_experiment_invalid_on_error(self, mock_dataset):
        with pytest.raises(DatasetValidationError, match="on_error"):
            await arun_experiment(
                mock_dataset,
                lambda x: x,
                input_column="Input",
                output_column="Output",
                on_error="invalid",
            )

    def test_run_experiment_sync_wrapper(self, mock_dataset, mock_records):
        """Sync run_experiment delegates to arun_experiment."""
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        result = run_experiment(
            mock_dataset,
            lambda x: x.upper(),
            input_column="Input",
            output_column="Output",
            trace_calls=False,
        )

        assert result.total == 3
        assert result.succeeded == 3


# ---------------------------------------------------------------------------
# TestRunExperimentOutputColumn
# ---------------------------------------------------------------------------


class TestRunExperimentOutputColumn:
    """Output column schema management."""

    @pytest.mark.asyncio
    async def test_adds_output_column_to_schema(self, mock_records):
        """When output_column not in schema, it gets added."""
        ds = Dataset(
            id="ds-1",
            name="test",
            column_schema=[{"name": "Input", "order": 0}],
        )
        ds.alist_records = AsyncMock(return_value=(mock_records, _pagination(3)))
        ds.aupdate = AsyncMock(return_value=ds)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        await arun_experiment(
            ds,
            lambda x: x,
            input_column="Input",
            output_column="NewOutput",
            trace_calls=False,
        )

        # aupdate called with expanded schema
        ds.aupdate.assert_called()
        schema_arg = ds.aupdate.call_args[1]["column_schema"]
        col_names = {c["name"] for c in schema_arg}
        assert "NewOutput" in col_names

    @pytest.mark.asyncio
    async def test_preserves_existing_output_column(self, mock_dataset, mock_records):
        """When output_column already in schema, no schema update."""
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        await arun_experiment(
            mock_dataset,
            lambda x: x,
            input_column="Input",
            output_column="Output",  # already in schema
            trace_calls=False,
        )

        # aupdate should NOT be called for schema (Output already exists)
        mock_dataset.aupdate.assert_not_called()

    @pytest.mark.asyncio
    async def test_preserves_other_record_data(self, mock_dataset):
        """Record update merges output without losing existing columns."""
        record = DatasetRecord(
            id="rec-1",
            dataset_id="dataset-123",
            data={"Input": "hello", "Extra": "keep-me"},
        )
        record.aupdate = AsyncMock(return_value=record)
        mock_dataset.alist_records = AsyncMock(
            return_value=([record], _pagination(1))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        await arun_experiment(
            mock_dataset,
            lambda x: x.upper(),
            input_column="Input",
            output_column="Output",
            trace_calls=False,
        )

        call_data = record.aupdate.call_args[1]["data"]
        assert call_data["Input"] == "hello"
        assert call_data["Extra"] == "keep-me"
        assert call_data["Output"] == "HELLO"


# ---------------------------------------------------------------------------
# TestRunExperimentErrorHandling
# ---------------------------------------------------------------------------


class TestRunExperimentErrorHandling:
    """Error handling: continue vs raise, missing input."""

    @pytest.mark.asyncio
    async def test_on_error_continue(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        call_count = 0

        def failing_fn(x):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise ValueError("boom")
            return x.upper()

        result = await arun_experiment(
            mock_dataset,
            failing_fn,
            input_column="Input",
            output_column="Output",
            trace_calls=False,
            on_error="continue",
            max_concurrency=1,  # sequential to control order
        )

        assert result.total == 3
        assert result.succeeded == 2
        assert result.failed == 1
        assert len(result.errors) == 1
        assert "boom" in result.errors[0].error_message

    @pytest.mark.asyncio
    async def test_on_error_raise(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        def always_fail(x):
            raise RuntimeError("fail")

        with pytest.raises(RuntimeError, match="fail"):
            await arun_experiment(
                mock_dataset,
                always_fail,
                input_column="Input",
                output_column="Output",
                trace_calls=False,
                on_error="raise",
            )

    @pytest.mark.asyncio
    async def test_missing_input_column(self, mock_dataset):
        record = DatasetRecord(
            id="rec-no-input",
            dataset_id="dataset-123",
            data={"Other": "value"},
        )
        record.aupdate = AsyncMock(return_value=record)
        mock_dataset.alist_records = AsyncMock(
            return_value=([record], _pagination(1))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        result = await arun_experiment(
            mock_dataset,
            lambda x: x,
            input_column="Input",
            output_column="Output",
            trace_calls=False,
            on_error="continue",
        )

        assert result.failed == 1
        assert "no value for column" in result.errors[0].error_message


# ---------------------------------------------------------------------------
# TestRunExperimentConcurrency
# ---------------------------------------------------------------------------


class TestRunExperimentConcurrency:
    """Concurrency control via max_concurrency."""

    @pytest.mark.asyncio
    async def test_max_concurrency_respected(self, mock_dataset, mock_records):
        """With max_concurrency=1, records process sequentially."""
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        execution_order: list[str] = []

        async def tracking_fn(x):
            execution_order.append(f"start-{x}")
            await asyncio.sleep(0.01)
            execution_order.append(f"end-{x}")
            return x

        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        await arun_experiment(
            mock_dataset,
            tracking_fn,
            input_column="Input",
            output_column="Output",
            trace_calls=False,
            max_concurrency=1,
        )

        # With max_concurrency=1, each start should be followed by its end
        # before the next start
        for i in range(0, len(execution_order) - 1, 2):
            start_val = execution_order[i].replace("start-", "")
            end_val = execution_order[i + 1].replace("end-", "")
            assert start_val == end_val


# ---------------------------------------------------------------------------
# TestRunExperimentTracing
# ---------------------------------------------------------------------------


class TestRunExperimentTracing:
    """Tracing integration for plain callables."""

    @pytest.mark.asyncio
    async def test_trace_calls_creates_spans(self, mock_dataset):
        record = DatasetRecord(
            id="rec-1",
            dataset_id="dataset-123",
            data={"Input": "hello"},
        )
        record.aupdate = AsyncMock(return_value=record)
        mock_dataset.alist_records = AsyncMock(
            return_value=([record], _pagination(1))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        mock_span = MagicMock()
        mock_trace_ctx = MagicMock()
        mock_trace_ctx.__aenter__ = AsyncMock(return_value=mock_span)
        mock_trace_ctx.__aexit__ = AsyncMock(return_value=None)

        mock_client = MagicMock()
        mock_client.trace.return_value = mock_trace_ctx

        with patch(
            "lumenova_beacon.experiments.runner.get_client", return_value=mock_client
        ):
            await arun_experiment(
                mock_dataset,
                lambda x: x.upper(),
                input_column="Input",
                output_column="Output",
                trace_calls=True,
            )

        mock_client.trace.assert_called_once()
        mock_span.set_metadata.assert_any_call("dataset_id", "dataset-123")
        mock_span.set_metadata.assert_any_call("dataset_record_id", "rec-1")
        mock_span.set_input.assert_called_once_with("hello")
        mock_span.set_output.assert_called_once_with("HELLO")

    @pytest.mark.asyncio
    async def test_trace_calls_false_no_spans(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        with patch(
            "lumenova_beacon.experiments.runner.get_client"
        ) as mock_get_client:
            await arun_experiment(
                mock_dataset,
                lambda x: x.upper(),
                input_column="Input",
                output_column="Output",
                trace_calls=False,
            )

            mock_get_client.assert_not_called()


# ---------------------------------------------------------------------------
# TestRunExperimentLangChain
# ---------------------------------------------------------------------------


class TestRunExperimentLangChain:
    """LangChain Runnable detection and callback handler injection."""

    @pytest.mark.asyncio
    async def test_detects_langchain_runnable(self, mock_dataset):
        record = DatasetRecord(
            id="rec-1",
            dataset_id="dataset-123",
            data={"Input": "hello"},
        )
        record.aupdate = AsyncMock(return_value=record)
        mock_dataset.alist_records = AsyncMock(
            return_value=([record], _pagination(1))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)

        # Create a mock Runnable
        mock_runnable = MagicMock()
        mock_runnable.ainvoke = AsyncMock(return_value="HELLO")

        mock_handler_cls = MagicMock()
        mock_handler_instance = MagicMock()
        mock_handler_cls.return_value = mock_handler_instance

        with (
            patch(
                "lumenova_beacon.experiments.runner._is_langchain_runnable",
                return_value=True,
            ),
            patch(
                "lumenova_beacon.tracing.integrations.langchain.BeaconCallbackHandler",
                mock_handler_cls,
            ),
        ):
            await arun_experiment(
                mock_dataset,
                mock_runnable,
                input_column="Input",
                output_column="Output",
                trace_calls=True,
            )

        # ainvoke called with input and config containing callbacks + thread_id
        mock_runnable.ainvoke.assert_called_once()
        call_args = mock_runnable.ainvoke.call_args
        assert call_args[0][0] == "hello"
        config = call_args[1]["config"]
        assert "callbacks" in config
        assert config["configurable"]["thread_id"] == "run_experiment:rec-1"

    @pytest.mark.asyncio
    async def test_plain_callable_not_detected(self, mock_dataset, mock_records):
        """Plain functions are not treated as LangChain Runnables."""
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )
        mock_dataset.aupdate = AsyncMock(return_value=mock_dataset)
        for rec in mock_records:
            rec.aupdate = AsyncMock(return_value=rec)

        assert not _is_langchain_runnable(lambda x: x)
        assert not _is_langchain_runnable(str.upper)

    def test_langchain_not_installed(self):
        """When langchain_core is not importable, returns False."""
        with patch.dict("sys.modules", {"langchain_core": None, "langchain_core.runnables": None}):
            assert not _is_langchain_runnable(MagicMock())


# ---------------------------------------------------------------------------
# TestOutputExtraction
# ---------------------------------------------------------------------------


class TestOutputExtraction:
    """Output type normalization."""

    def test_extract_string(self):
        assert _extract_output("hello") == "hello"

    def test_extract_dict(self):
        assert _extract_output({"key": "val"}) == {"key": "val"}

    def test_extract_list(self):
        assert _extract_output([1, 2, 3]) == [1, 2, 3]

    def test_extract_int(self):
        assert _extract_output(42) == 42

    def test_extract_bool(self):
        assert _extract_output(True) is True

    def test_extract_unknown_type_falls_back_to_str(self):
        @dataclass
        class Custom:
            value: str

        obj = Custom(value="test")
        result = _extract_output(obj)
        assert isinstance(result, str)
        assert "test" in result

    def test_extract_ai_message(self):
        """When langchain_core is available, AIMessage.content is extracted."""
        try:
            from langchain_core.messages import AIMessage

            msg = MagicMock(spec=AIMessage)
            msg.content = "AI response"
            result = _extract_output(msg)
            assert result == "AI response"
        except ImportError:
            pytest.skip("langchain_core not installed")


# ---------------------------------------------------------------------------
# TestFetchAllRecords
# ---------------------------------------------------------------------------


class TestFetchAllRecords:
    """Pagination handling in _fetch_all_records."""

    @pytest.mark.asyncio
    async def test_fetches_single_page(self, mock_dataset, mock_records):
        mock_dataset.alist_records = AsyncMock(
            return_value=(mock_records, _pagination(3))
        )

        records = await _fetch_all_records(mock_dataset)
        assert len(records) == 3
        mock_dataset.alist_records.assert_called_once_with(page=1, page_size=100)

    @pytest.mark.asyncio
    async def test_fetches_multiple_pages(self, mock_dataset):
        page1_records = [
            DatasetRecord(id=f"rec-{i}", dataset_id="dataset-123", data={"Input": f"val-{i}"})
            for i in range(100)
        ]
        page2_records = [
            DatasetRecord(id=f"rec-{i}", dataset_id="dataset-123", data={"Input": f"val-{i}"})
            for i in range(100, 150)
        ]

        mock_dataset.alist_records = AsyncMock(
            side_effect=[
                (page1_records, _pagination(150, page=1, page_size=100)),
                (page2_records, _pagination(150, page=2, page_size=100)),
            ]
        )

        records = await _fetch_all_records(mock_dataset)
        assert len(records) == 150
        assert mock_dataset.alist_records.call_count == 2
