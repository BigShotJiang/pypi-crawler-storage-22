"""
Document text extraction via OpenAI Responses API.

Supports images and PDFs.

Example:
    >>> from lumera import documents
    >>> text = documents.extract_text("invoice.pdf")

    # Or from bytes (no file needed):
    >>> text = documents.extract_text_from_bytes(pdf_bytes, "application/pdf")
"""

from __future__ import annotations

import base64
import mimetypes
from pathlib import Path

__all__ = ["extract_text", "extract_text_from_bytes"]

_DEFAULT_MODEL = "gpt-5-mini"
_DEFAULT_PROMPT = "Extract all text from this document. Return only the extracted text."


def _get_mime_type(file_path: str) -> str:
    """Get MIME type for a file."""
    mime, _ = mimetypes.guess_type(file_path)
    if mime:
        return mime
    ext = Path(file_path).suffix.lower()
    return {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".pdf": "application/pdf",
    }.get(ext, "application/octet-stream")


def extract_text_from_bytes(
    data: bytes,
    mime_type: str,
    *,
    filename: str = "document",
    prompt: str = _DEFAULT_PROMPT,
    model: str = _DEFAULT_MODEL,
) -> str:
    """Extract text from document bytes using OpenAI.

    Args:
        data: Raw file bytes
        mime_type: MIME type (e.g., "application/pdf", "image/png")
        filename: Optional filename for context
        prompt: What to ask the LLM
        model: Model to use (default: gpt-5-mini)

    Returns:
        Extracted text

    Example:
        >>> import requests
        >>> resp = requests.get(presigned_url)
        >>> text = documents.extract_text_from_bytes(
        ...     resp.content,
        ...     "application/pdf",
        ...     filename="invoice.pdf"
        ... )
    """
    from . import llm

    b64 = base64.b64encode(data).decode("utf-8")
    data_url = f"data:{mime_type};base64,{b64}"
    client = llm.get_provider().client

    response = client.responses.create(
        model=model,
        input=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "input_file",
                        "filename": filename,
                        "file_data": data_url,
                    },
                    {
                        "type": "input_text",
                        "text": prompt,
                    },
                ],
            },
        ],
    )
    return response.output_text or ""


def extract_text(
    file_path: str,
    *,
    prompt: str = _DEFAULT_PROMPT,
    model: str = _DEFAULT_MODEL,
) -> str:
    """Extract text from a document file using OpenAI.

    Args:
        file_path: Path to image or PDF
        prompt: What to ask the LLM
        model: Model to use (default: gpt-5-mini)

    Returns:
        Extracted text
    """
    with open(file_path, "rb") as f:
        data = f.read()

    mime = _get_mime_type(file_path)
    filename = Path(file_path).name

    return extract_text_from_bytes(
        data,
        mime,
        filename=filename,
        prompt=prompt,
        model=model,
    )
