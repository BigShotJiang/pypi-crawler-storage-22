"""
Email sending for Lumera automations.

Send transactional emails through the Lumera platform using AWS SES infrastructure.
Emails are logged to the lm_email_logs collection for auditing and debugging.

Functions:
    send()  - Send an email with HTML/text content

Example:
    >>> from lumera import email
    >>>
    >>> # Send a simple email
    >>> result = email.send(
    ...     to="user@example.com",
    ...     subject="Welcome to Lumera!",
    ...     body_html="<h1>Hello!</h1><p>Welcome aboard.</p>"
    ... )
    >>> print(result.message_id)
    >>>
    >>> # Send to multiple recipients with plain text fallback
    >>> result = email.send(
    ...     to=["alice@example.com", "bob@example.com"],
    ...     subject="Team Update",
    ...     body_html="<h1>Update</h1><p>See details below.</p>",
    ...     body_text="Update\\n\\nSee details below.",
    ...     tags={"type": "notification", "team": "engineering"}
    ... )
"""

from __future__ import annotations

from typing import Any

from ._utils import _api_request, LumeraAPIError

__all__ = [
    "send",
    "SendResult",
]


class SendResult:
    """Result of sending an email.

    Attributes:
        message_id: The unique identifier from AWS SES for the sent email.
        log_id: The PocketBase record ID in lm_email_logs for auditing.
    """

    def __init__(self, data: dict[str, Any]):
        self.message_id: str = data.get("message_id", "")
        self.log_id: str = data.get("log_id", "")
        self._raw = data

    def __repr__(self) -> str:
        return f"SendResult(message_id={self.message_id!r}, log_id={self.log_id!r})"


def send(
    to: list[str] | str,
    subject: str,
    *,
    body_html: str | None = None,
    body_text: str | None = None,
    cc: list[str] | str | None = None,
    bcc: list[str] | str | None = None,
    from_address: str | None = None,
    from_name: str | None = None,
    reply_to: str | None = None,
    tags: dict[str, str] | None = None,
) -> SendResult:
    """Send an email.

    At least one of body_html or body_text must be provided. If only body_html
    is provided, a plain text version will be auto-generated.

    Args:
        to: Recipient email address(es). Can be a single string or list.
        subject: Email subject line.
        body_html: HTML body content (optional if body_text provided).
        body_text: Plain text body content (optional, auto-generated from HTML).
        cc: CC recipient(s) (optional).
        bcc: BCC recipient(s) (optional).
        from_address: Sender email address (optional, uses platform default).
        from_name: Sender display name (optional, uses platform default).
        reply_to: Reply-to address (optional).
        tags: Custom key-value pairs for tracking/filtering in logs (optional).

    Returns:
        SendResult with message_id and log_id.

    Raises:
        ValueError: If required fields are missing or invalid.
        LumeraAPIError: If the API request fails.

    Example:
        >>> # Simple email
        >>> result = email.send(
        ...     to="user@example.com",
        ...     subject="Password Reset",
        ...     body_html="<p>Click <a href='...'>here</a> to reset.</p>"
        ... )
        >>>
        >>> # Email with all options
        >>> result = email.send(
        ...     to=["alice@example.com", "bob@example.com"],
        ...     subject="Monthly Report",
        ...     body_html="<h1>Report</h1><p>See attached.</p>",
        ...     body_text="Report\\n\\nSee attached.",
        ...     cc="manager@example.com",
        ...     reply_to="reports@example.com",
        ...     tags={"report_type": "monthly", "department": "sales"}
        ... )
    """
    # Normalize to lists
    to_list = [to] if isinstance(to, str) else list(to) if to else []
    cc_list = [cc] if isinstance(cc, str) else (list(cc) if cc else None)
    bcc_list = [bcc] if isinstance(bcc, str) else (list(bcc) if bcc else None)

    # Validate
    if not to_list:
        raise ValueError("at least one recipient is required")
    if not subject or not subject.strip():
        raise ValueError("subject is required")
    if not body_html and not body_text:
        raise ValueError("at least one of body_html or body_text is required")

    # Build payload
    payload: dict[str, Any] = {
        "to": to_list,
        "subject": subject.strip(),
    }

    if body_html:
        payload["body_html"] = body_html
    if body_text:
        payload["body_text"] = body_text
    if cc_list:
        payload["cc"] = cc_list
    if bcc_list:
        payload["bcc"] = bcc_list
    if from_address:
        payload["from"] = from_address.strip()
    if from_name:
        payload["from_name"] = from_name.strip()
    if reply_to:
        payload["reply_to"] = reply_to.strip()
    if tags:
        payload["tags"] = tags

    result = _api_request("POST", "email/send", json_body=payload)
    if not isinstance(result, dict):
        raise RuntimeError("unexpected response from email/send")

    return SendResult(result)
