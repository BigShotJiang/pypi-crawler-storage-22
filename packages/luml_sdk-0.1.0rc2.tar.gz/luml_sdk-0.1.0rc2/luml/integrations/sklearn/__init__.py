from luml.integrations.sklearn.packaging import save_sklearn

__all__ = ["save_sklearn"]
