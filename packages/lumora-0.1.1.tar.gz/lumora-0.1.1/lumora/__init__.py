"""Lumora — composable image generation and document rendering."""

__version__ = "0.1.1"
