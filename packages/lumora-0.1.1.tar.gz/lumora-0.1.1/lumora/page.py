from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Tuple

from .layout import Widget
from .exceptions import MissingExtraError, EmptyDocumentError
from PIL import Image
from io import BytesIO
from datetime import datetime

try:
    import pikepdf  # noqa: F401

    _HAS_PIKEPDF = True
except ImportError:
    _HAS_PIKEPDF = False


def _require_pikepdf() -> None:
    """Raise :class:`~lumora.exceptions.MissingExtraError` if pikepdf is not installed."""
    if not _HAS_PIKEPDF:
        raise MissingExtraError("pikepdf")


@dataclass
class DocumentMetadata:
    """PDF document metadata.

    Requires the ``pikepdf`` extra::

        pip install lumora[pikepdf]

    Raises:
        MissingExtraError: If ``pikepdf`` is not installed when
            :meth:`Document.save` is called with metadata.
    """

    title: str = ""
    author: str = ""
    subject: str = ""
    keywords: str = ""
    creator: str = ""
    producer: str = ""


class Page(ABC):
    """Base class for report pages.

    Subclasses only need to implement ``build()`` which returns a widget tree.
    Sizing, rendering, and scaling are handled automatically.

    Class attributes:
        design_width: Virtual design width (pixels). Default 2520.
        design_height: Virtual design height (pixels). Default 1780.

    All dimensions (font_size, padding, spacing, etc.) are defined relative
    to the design resolution. When rendered to a different resolution, the
    entire page is proportionally scaled using LANCZOS — no pixelation.

    Example::

        class MyPage(Page):
            design_width = 2520
            design_height = 1780

            def build(self) -> Widget:
                return Container(
                    width=self.design_width,
                    height=self.design_height,
                    background=RGBColor(0, 0, 0),
                    child=TextWidget("Hello", style=HEADER_STYLE),
                )

        page = MyPage()
        img = page.render()                     # 2520×1780 (design size)
        img = page.render(scale=2.0)            # 5040×3560 (2x)
        img = page.render(width=1260)           # 1260×890  (0.5x, aspect ratio preserved)
        img = page.render(width=1920, height=1080)  # 1920×1080 (custom)
    """

    design_width: int = 2520
    design_height: int = 1780

    @abstractmethod
    def build(self) -> Widget:
        """Build the widget tree for this page.

        Use ``self.design_width`` and ``self.design_height`` as the
        root Container size so it scales proportionally.
        """
        ...

    @property
    def design_size(self) -> Tuple[int, int]:
        """(width, height) design resolution."""
        return (self.design_width, self.design_height)

    @property
    def aspect_ratio(self) -> float:
        """Aspect ratio (width / height)."""
        return self.design_width / self.design_height

    def render(
        self,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> Image.Image:
        """Render the page to an Image.

        Always renders the widget tree at design resolution first,
        then scales the final result to the target resolution.

        Args:
            width: Target width (pixels). If only width is given, height
                   is calculated from the aspect ratio.
            height: Target height (pixels). If only height is given, width
                    is calculated from the aspect ratio.
            scale: Scale factor (default 1.0). Ignored if width/height
                   are explicitly set.

        Returns:
            PIL RGBA Image at the target resolution.
        """
        # 1. Build & render at design resolution
        widget = self.build()
        design_img = widget.render(self.design_width, self.design_height)

        # 2. Calculate target size
        target_w, target_h = self._resolve_target_size(width, height, scale)

        # 3. Scale if needed
        if (target_w, target_h) != design_img.size:
            return design_img.resize((target_w, target_h), Image.Resampling.LANCZOS)
        return design_img

    def _resolve_target_size(
        self,
        width: int | None,
        height: int | None,
        scale: float,
    ) -> Tuple[int, int]:
        """Calculate target (width, height) from parameters."""
        if width is not None and height is not None:
            return (max(1, width), max(1, height))
        if width is not None:
            # Height from aspect ratio
            h = max(1, int(width / self.aspect_ratio))
            return (max(1, width), h)
        if height is not None:
            # Width from aspect ratio
            w = max(1, int(height * self.aspect_ratio))
            return (w, max(1, height))
        # Scale from design resolution
        return (
            max(1, int(self.design_width * scale)),
            max(1, int(self.design_height * scale)),
        )

    def save(
        self,
        out: str | BytesIO,
        format: str = "PNG",
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> None:
        """Render & save the page to a file or buffer.

        Args are the same as ``render()``.
        """
        self.render(width=width, height=height, scale=scale).save(out, format=format)


class Document:
    """Multi-page document — renders to PDF or image sequence.

    Example::

        doc = Document()
        doc.add_page(cover_page)
        doc.add_page(content_page)
        doc.save("report.pdf", metadata)
        doc.save("report.pdf", metadata, scale=0.5)     # 50% size
        doc.save("report.pdf", metadata, width=1920)     # fit width
    """

    def __init__(self) -> None:
        self.pages: list[Page] = []

    def add_page(self, page: Page) -> None:
        self.pages.append(page)

    def render_all(
        self,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> list[Image.Image]:
        """Render all pages to a list of Images."""
        return [
            page.render(width=width, height=height, scale=scale) for page in self.pages
        ]

    def save(
        self,
        out: str | BytesIO,
        metadata: DocumentMetadata | None = None,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> None:
        """Render all pages & save as a PDF.

        When *metadata* is provided, ``pikepdf`` is used to inject document
        metadata into the PDF.  If ``pikepdf`` is not installed, a
        :class:`~lumora.exceptions.MissingExtraError` is raised.

        When *metadata* is ``None``, the PDF is saved directly via Pillow
        without requiring ``pikepdf``.

        Args:
            out: File path or BytesIO buffer.
            metadata: Document metadata (title, author, etc.).  Requires
                the ``pikepdf`` extra.
            width: Target width per page (pixels).
            height: Target height per page (pixels).
            scale: Scale factor (default 1.0).

        Raises:
            EmptyDocumentError: If the document has no pages.
            MissingExtraError: If *metadata* is provided but ``pikepdf``
                is not installed.
        """
        if not self.pages:
            raise EmptyDocumentError()

        images = self.render_all(width=width, height=height, scale=scale)

        if metadata is not None:
            _require_pikepdf()
            import pikepdf

            buffer = BytesIO()
            images[0].save(
                buffer,
                format="PDF",
                save_all=True,
                append_images=images[1:],
                resolution=100.0,
                quality=95,
            )

            with pikepdf.open(buffer) as pdf:
                pdf.docinfo["/Title"] = metadata.title
                pdf.docinfo["/Author"] = metadata.author
                pdf.docinfo["/Subject"] = metadata.subject
                pdf.docinfo["/Keywords"] = metadata.keywords
                pdf.docinfo["/Creator"] = metadata.creator
                pdf.docinfo["/Producer"] = metadata.producer

                now = datetime.now().strftime("D:%Y%m%d%H%M%S")
                pdf.docinfo["/CreationDate"] = now
                pdf.docinfo["/ModDate"] = now
                pdf.save(out)
        else:
            # Save as plain PDF without metadata (no pikepdf needed)
            images[0].save(
                out,
                format="PDF",
                save_all=True,
                append_images=images[1:],
                resolution=100.0,
                quality=95,
            )
