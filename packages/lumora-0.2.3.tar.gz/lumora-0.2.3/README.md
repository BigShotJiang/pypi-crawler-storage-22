<p align="center">
  <strong>Lumora</strong>
</p>

<p align="center">
  A composable image generation and document rendering library for Python, powered by Pillow.
</p>

<p align="center">
  <a href="https://www.python.org/downloads/"><img src="https://img.shields.io/badge/python-3.12+-blue.svg" alt="Python 3.12+"></a>
  <a href="https://github.com/krypton-byte/lumora/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-MIT-green.svg" alt="MIT License"></a>
</p>

---

## Overview

**Lumora** lets you build complex, pixel-perfect images, multi-page PDF documents, and PPTX presentations entirely in Python — no browser, no template engine, no external rendering service.

Inspired by modern declarative UI toolkits (Jetpack Compose, Flutter), Lumora provides a composable widget tree where every element — containers, columns, rows, text, images — is sized, laid out, clipped, and rendered automatically.

### Key features

- **Composable layouts** — `Container`, `Column`, `Row`, `Stack`, `Expanded`, `Spacer`, `SizedBox`, `Padding`
- **Rich text** — `TextWidget`, `RichTextWidget` (inline HTML-like markup), `JustifiedTextWidget`, `HighlightTextWidget`
- **Advanced styling** — gradients (linear & radial), rounded corners, circles, strokes, shadows, text transforms
- **Visual effects** — blur, stroke outlines, glassmorphism corners, alpha gradients, custom effects
- **Design-resolution scaling** — define once at a virtual size, render to any resolution with LANCZOS resampling
- **PDF export** — multi-page documents with optional metadata via pikepdf
- **PPTX export** — PowerPoint presentations with auto-fitted slide dimensions via python-pptx
- **Pure Python** — only depends on Pillow; pikepdf and python-pptx are optional extras

---

## Installation

```bash
pip install lumora
```

For PDF metadata support (title, author, etc.):

```bash
pip install lumora[pikepdf]
```

For PPTX (PowerPoint) export:

```bash
pip install python-pptx
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv add lumora            # core only
uv add lumora[pikepdf]   # with PDF metadata
uv add python-pptx       # with PPTX export
```

### Requirements

- Python 3.12+
- Pillow ≥ 12.1
- pikepdf ≥ 10.3 *(optional — for PDF metadata)*
- python-pptx ≥ 1.0 *(optional — for PPTX export)*

---

## Quick start

```python
from lumora.page import Page
from lumora.layout import Container, Column, TextWidget
from lumora.config import RGBColor, Alignment, Margin
from lumora.font import TextStyle, FontWeight

title_style = TextStyle(
    font_size=72,
    font_family="Inter",
    font_weight=FontWeight.BOLD,
    color=RGBColor(255, 255, 255),
)

body_style = TextStyle(
    font_size=32,
    font_family="Inter",
    color=RGBColor(200, 200, 200),
)


class HelloPage(Page):
    design_width = 1920
    design_height = 1080

    def build(self):
        return Container(
            width=self.design_width,
            height=self.design_height,
            background=RGBColor(25, 25, 35),
            alignment=Alignment.CENTER,
            padding=Margin(60, 60, 60, 60),
            child=Column(
                spacing=20,
                children=[
                    TextWidget("Hello, Lumora!", style=title_style),
                    TextWidget(
                        "Composable image generation in pure Python.",
                        style=body_style,
                    ),
                ],
            ),
        )


page = HelloPage()
page.save("hello.png", width=1920)
```

---

## Widget catalog

| Widget | Description |
|-|-|
| `Container` | Box with background, padding, alignment, clipping, effects |
| `Column` | Vertical layout with spacing and axis alignment |
| `Row` | Horizontal layout with spacing and axis alignment |
| `Stack` | Overlay children on top of each other |
| `Expanded` | Fill remaining space in a `Column` or `Row` |
| `Spacer` | Fixed-size empty space |
| `SizedBox` | Force explicit width/height on a child |
| `Padding` | Add insets around a child |
| `TextWidget` | Single-style text block |
| `RichTextWidget` | Inline markup: `<b>`, `<i>`, `<color>`, `<size>`, etc. |
| `JustifiedTextWidget` | Fully justified paragraph text |
| `HighlightTextWidget` | Text with highlighted background spans |
| `ImageWidget` | Render an image from file or PIL Image |
| `LineWidget` | Horizontal line / divider |
| `GlassContainer` | Frosted-glass effect container |

---

## Multi-page PDF

```python
from lumora.page import Document, DocumentMetadata, Format

doc = Document()
doc.add_page(CoverPage())
doc.add_page(ChartPage())
doc.add_page(SummaryPage())

# Without metadata — no pikepdf needed
doc.save("report.pdf", width=1920)

# With metadata — requires: pip install lumora[pikepdf]
doc.save(
    "report.pdf",
    Format.PDF,
    DocumentMetadata(title="Q4 Report", author="Analytics"),
    width=1920,
)
```

---

## PPTX (PowerPoint) export

Slide dimensions automatically match the image aspect ratio — no stretching.

```python
# Requires: pip install python-pptx
doc.save("slides.pptx", Format.PPTX)

# With metadata
doc.save(
    "slides.pptx",
    Format.PPTX,
    DocumentMetadata(title="Q4 Report", author="Analytics"),
    width=1920,
)

# At half resolution
doc.save("slides.pptx", Format.PPTX, scale=0.5)
```

---

## Documentation

Full documentation is available at the project docs site (built with MkDocs Material):

```bash
# Serve locally
uv sync --group docs
uv run mkdocs serve
```

---

## License

MIT — see [LICENSE](LICENSE) for details.
