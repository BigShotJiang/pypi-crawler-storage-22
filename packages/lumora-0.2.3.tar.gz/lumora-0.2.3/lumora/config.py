from abc import ABC, abstractmethod
from enum import Enum
from typing import Union
from PIL import Image
from dataclasses import dataclass


@dataclass
class Margin:
    top: int
    right: int
    bottom: int
    left: int


@dataclass
class MarginAxis:
    horizontal: int
    vertical: int


@dataclass
class Coordinate:
    x: int
    y: int


@dataclass
class Size:
    width: int
    height: int


@dataclass
class RGBColor:
    r: int
    g: int
    b: int

    def mode(self):
        return "RGB"

    def to_tuple(self):
        return (self.r, self.g, self.b)


class VerticalAlignment:
    TOP = "top"
    CENTER = "center"
    BOTTOM = "bottom"


class HorizontalAlignment:
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"


class Color(ABC):
    pass


@dataclass
class RGBAColor:
    r: int
    g: int
    b: int
    a: int

    def mode(self):
        return "RGBA"

    def to_tuple(self):
        return (self.r, self.g, self.b, self.a)


@dataclass
class GradientColor:
    start_color: RGBColor
    end_color: RGBColor


class Shape(ABC):
    @abstractmethod
    def clip(self, data: Image.Image) -> Image.Image:
        raise NotImplementedError("Subclasses should implement this method.")


@dataclass
class RoundedCorner(Shape):
    radius: int = 20
    stroke_width: int = 0
    stroke_color: "StrokeColor | None" = None

    def clip(self, data: Image.Image) -> Image.Image:
        from .ops import border_radius, draw_rounded_rect_stroke

        result = border_radius(data, self.radius)
        if self.stroke_width > 0 and self.stroke_color is not None:
            result = draw_rounded_rect_stroke(
                result, self.radius, self.stroke_width, self.stroke_color
            )
        return result


@dataclass
class Circle(Shape):
    """Clips the image into a circle (diameter = shortest side)."""

    stroke_width: int = 0
    stroke_color: "StrokeColor | None" = None

    def clip(self, data: Image.Image) -> Image.Image:
        from .ops import circle_clip, draw_circle_stroke

        result = circle_clip(data)
        if self.stroke_width > 0 and self.stroke_color is not None:
            result = draw_circle_stroke(result, self.stroke_width, self.stroke_color)
        return result


class Alignment(Enum):
    """Alignment for positioning a child within a container or stack."""

    TOP_START = "top_start"
    TOP_CENTER = "top_center"
    TOP_END = "top_end"
    CENTER_START = "center_start"
    CENTER = "center"
    CENTER_END = "center_end"
    BOTTOM_START = "bottom_start"
    BOTTOM_CENTER = "bottom_center"
    BOTTOM_END = "bottom_end"


class MainAxisAlignment(Enum):
    """Controls the positioning of children along the main axis (layout direction).

    Column: main axis = vertical.
    Row: main axis = horizontal.
    """

    START = "start"
    CENTER = "center"
    END = "end"
    SPACE_BETWEEN = "space_between"
    SPACE_AROUND = "space_around"
    SPACE_EVENLY = "space_evenly"


class CrossAxisAlignment(Enum):
    """Controls the positioning of children along the cross axis (perpendicular to layout direction).

    Column: cross axis = horizontal.
    Row: cross axis = vertical.
    """

    START = "start"
    CENTER = "center"
    END = "end"
    STRETCH = "stretch"


@dataclass
class LinearGradient:
    """Linear gradient with arbitrary angle.

    angle: 0 = top-to-bottom, 90 = left-to-right, 180 = bottom-to-top, 270 = right-to-left.
    """

    start_color: RGBColor | RGBAColor
    end_color: RGBColor | RGBAColor
    angle: float = 0


@dataclass
class RadialGradient:
    """Radial (circular) gradient from center to edge."""

    inner_color: RGBColor | RGBAColor
    outer_color: RGBColor | RGBAColor


# Type alias for all background types
Background = Union[RGBColor, RGBAColor, GradientColor, LinearGradient, RadialGradient]

# Type alias for stroke color (solid or gradient)
StrokeColor = Union[RGBColor, RGBAColor, LinearGradient, RadialGradient]


class BackgroundFit(Enum):
    """Fit mode for background images within a Container.

    COVER: Resize preserving aspect ratio, center-crop to fill (no empty areas).
    CONTAIN: Resize preserving aspect ratio, entire image visible (may have empty areas).
    STRETCH: Resize ignoring aspect ratio to fill the entire area.
    REPEAT: Tile the original image without resizing.
    FIT_WIDTH: Resize to match width, height proportional (crop top/bottom if needed).
    FIT_HEIGHT: Resize to match height, width proportional (crop left/right if needed).
    """

    COVER = "cover"
    CONTAIN = "contain"
    STRETCH = "stretch"
    REPEAT = "repeat"
    FIT_WIDTH = "fit_width"
    FIT_HEIGHT = "fit_height"
