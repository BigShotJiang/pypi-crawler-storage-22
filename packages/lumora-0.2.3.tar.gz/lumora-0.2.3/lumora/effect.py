from abc import ABC, abstractmethod
from PIL import Image, ImageFilter, ImageDraw, ImageChops
from .config import Margin, MarginAxis, RGBAColor
from .ops import border_radius


class Effect(ABC):
    @abstractmethod
    def apply(self, data: Image.Image) -> Image.Image:
        raise NotImplementedError("Subclasses should implement this method.")

    # def border_radius(self, data: Image.Image, radius: int = 20) -> Image.Image:
    #     return border_radius(data, radius)


class BlurEffect(Effect):
    def __init__(
        self,
        margin: Margin | MarginAxis,
        color: RGBAColor = RGBAColor(255, 255, 255, int(0.7 * 255)),
        radius: int = 10,
        border_radius: int = 20,
    ):
        self.margin = margin
        self.radius = radius
        self.color = color
        self.border_radius = border_radius

    def apply(self, data: Image.Image) -> Image.Image:
        data = data.convert("RGBA")
        w, h = data.size

        left = (
            self.margin.left
            if isinstance(self.margin, Margin)
            else self.margin.horizontal
        )
        right = (
            self.margin.right
            if isinstance(self.margin, Margin)
            else self.margin.horizontal
        )
        top = (
            self.margin.top if isinstance(self.margin, Margin) else self.margin.vertical
        )
        bottom = (
            self.margin.bottom
            if isinstance(self.margin, Margin)
            else self.margin.vertical
        )

        x1, y1 = left, top
        x2, y2 = w - right, h - bottom

        # 1. Blur the full image
        blurred = data.filter(ImageFilter.GaussianBlur(self.radius))

        # 2. Create glass area mask
        mask = Image.new("L", (w, h), 0)
        draw = ImageDraw.Draw(mask)
        draw.rectangle([x1, y1, x2, y2], fill=255)

        # 3. Composite: blur only within the masked area
        result = Image.composite(blurred, data, mask)

        # 4. Add white overlay (glass tint)
        overlay = Image.new(
            "RGBA",
            (x2 - x1, y2 - y1),
            (self.color.r, self.color.g, self.color.b, self.color.a),
        )
        result.paste(overlay, (x1, y1), overlay)

        return result


class RoundedCornerEffect(Effect):
    def __init__(self, radius: int = 20):
        self.radius = radius

    def apply(self, data: Image.Image) -> Image.Image:
        # Placeholder for rounded corner effect
        return border_radius(data, self.radius)


class StrokeEffect(Effect):
    """Adds a stroke (outline) around the non-transparent area of an image."""

    def __init__(
        self,
        width: int = 4,
        color: RGBAColor = RGBAColor(255, 255, 255, 255),
    ):
        self.width = width
        self.color = color

    def apply(self, data: Image.Image) -> Image.Image:
        data = data.convert("RGBA")
        w, h = data.size
        pad = self.width

        # Pad image so the stroke has room to grow outward
        padded = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
        padded.paste(data, (pad, pad))

        alpha = padded.getchannel("A")

        # Expand alpha outward using MaxFilter to create the outline
        expanded = alpha
        for _ in range(self.width):
            expanded = expanded.filter(ImageFilter.MaxFilter(3))

        # Create stroke mask: expanded area minus the original area
        stroke_mask = ImageChops.subtract(expanded, alpha)

        # Create stroke layer with the desired color
        stroke_layer = Image.new(
            "RGBA",
            padded.size,
            (self.color.r, self.color.g, self.color.b, self.color.a),
        )

        # Apply stroke mask to the stroke layer
        stroke_layer.putalpha(
            ImageChops.multiply(stroke_mask, stroke_layer.getchannel("A"))
        )

        # Composite: stroke underneath, then image on top
        result = Image.alpha_composite(stroke_layer, padded)
        return result


class VerticalAlphaGradient(Effect):
    def apply(self, data: Image.Image) -> Image.Image:
        data = data.convert("RGBA")
        existing_alpha = data.getchannel("A")
        mask = Image.new("L", (data.width, data.height))
        pixels = mask.load()
        if pixels is None:
            raise ValueError("Failed to load pixel data from the image.")
        for y in range(data.height):
            t = y / (data.height - 1)

            # V shape (255 → 0 → 255)
            alpha = int(abs(t - 0.5) * 2 * 255)

            for x in range(data.width):
                pixels[x, y] = alpha
        # Multiply with original alpha so transparent areas remain transparent
        combined = ImageChops.multiply(existing_alpha, mask)
        data.putalpha(combined)
        return data


class GlassCornerEffect(Effect):
    """Glassmorphism effect on corner areas — frosted glass with blur + tint overlay.

    Corners receive a frosted glass effect (blurred + semi-transparent tint),
    while the center area remains untouched.

    Args:
        radius: Size of the corner area (in pixels from each corner).
        blur_radius: Gaussian blur intensity.
        tint_color: Glass overlay color (default: semi-transparent white).
        corner_radius: Border radius for rounded corners on the mask (0 = square).
    """

    def __init__(
        self,
        radius: int = 120,
        blur_radius: int = 15,
        tint_color: RGBAColor = RGBAColor(255, 255, 255, int(0.15 * 255)),
        corner_radius: int = 40,
    ):
        self.radius = radius
        self.blur_radius = blur_radius
        self.tint_color = tint_color
        self.corner_radius = corner_radius

    def _build_corner_mask(self, w: int, h: int) -> Image.Image:
        """Build a mask that covers only the four corner areas."""
        mask = Image.new("L", (w, h), 0)
        draw = ImageDraw.Draw(mask)
        r = self.radius
        cr = self.corner_radius

        # Top-left corner
        draw.rounded_rectangle([0, 0, r, r], radius=cr, fill=255)
        # Top-right corner
        draw.rounded_rectangle([w - r, 0, w, r], radius=cr, fill=255)
        # Bottom-left corner
        draw.rounded_rectangle([0, h - r, r, h], radius=cr, fill=255)
        # Bottom-right corner
        draw.rounded_rectangle([w - r, h - r, w, h], radius=cr, fill=255)

        return mask

    def apply(self, data: Image.Image) -> Image.Image:
        data = data.convert("RGBA")
        w, h = data.size

        # 1. Blur the entire image
        blurred = data.filter(ImageFilter.GaussianBlur(self.blur_radius))

        # 2. Create mask only for corner areas
        corner_mask = self._build_corner_mask(w, h)

        # Multiply mask with original alpha so transparent areas stay transparent
        existing_alpha = data.getchannel("A")
        effective_mask = ImageChops.multiply(corner_mask, existing_alpha)

        # 3. Composite: blur only in corner areas, rest remains original
        result = Image.composite(blurred, data, effective_mask)

        # 4. Add tint overlay (glass tint) in corner areas
        tint = Image.new(
            "RGBA",
            (w, h),
            (
                self.tint_color.r,
                self.tint_color.g,
                self.tint_color.b,
                self.tint_color.a,
            ),
        )
        # Apply corner mask to tint so it only affects corners
        tint_alpha = ImageChops.multiply(effective_mask, tint.getchannel("A"))
        tint.putalpha(tint_alpha)
        result = Image.alpha_composite(result, tint)

        # 5. Add highlight/shine in corners for a glass reflection effect
        highlight = self._build_highlight(w, h, effective_mask)
        result = Image.alpha_composite(result, highlight)

        return result

    def _build_highlight(self, w: int, h: int, corner_mask: Image.Image) -> Image.Image:
        """Build a subtle diagonal gradient highlight in each corner for a glass reflection effect."""
        highlight = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        r = self.radius

        for cx, cy, dx, dy in [
            (0, 0, 1, 1),  # top-left: gradient from corner inward
            (w - r, 0, -1, 1),  # top-right
            (0, h - r, 1, -1),  # bottom-left
            (w - r, h - r, -1, -1),  # bottom-right
        ]:
            grad = Image.new("L", (r, r), 0)
            pixels = grad.load()
            if pixels is None:
                continue
            for y in range(r):
                for x in range(r):
                    # Diagonal gradient: brighter at outer corner, fading inward
                    dist = (
                        (x if dx > 0 else r - 1 - x) + (y if dy > 0 else r - 1 - y)
                    ) / (2 * r)
                    val = int(
                        max(0, (1.0 - dist * 2)) * 40
                    )  # max alpha 40 → very subtle
                    pixels[x, y] = val
            # Create highlight RGBA at corner position
            corner_hl = Image.new("RGBA", (r, r), (255, 255, 255, 0))
            corner_hl.putalpha(grad)
            highlight.paste(corner_hl, (cx, cy), corner_hl)

        # Mask highlight so it only applies to visible corner areas
        hl_alpha = ImageChops.multiply(highlight.getchannel("A"), corner_mask)
        highlight.putalpha(hl_alpha)

        return highlight
