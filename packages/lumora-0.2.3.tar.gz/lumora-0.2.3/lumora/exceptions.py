"""Custom exceptions for Lumora."""


class LumoraError(Exception):
    """Base exception for all Lumora errors."""


class MissingExtraError(LumoraError):
    """Raised when an optional dependency (extra) is not installed.

    Example::

        # This is raised automatically when you try to save a Document
        # with metadata but pikepdf is not installed.
        raise MissingExtraError("pikepdf")
    """

    def __init__(self, extra: str) -> None:
        self.extra = extra
        super().__init__(
            f"The '{extra}' package is required for this operation but is not installed. "
            f"Install it with:  pip install lumora[{extra}]"
        )


class EmptyDocumentError(LumoraError):
    """Raised when attempting to save or render a Document with no pages."""

    def __init__(self) -> None:
        super().__init__("Document has no pages. Add at least one page before saving.")
