"""Font & TextStyle module — CSS/Flutter-like text styling.

Example usage::

    style = TextStyle(
        font_family="inter",
        font_size=80,
        font_weight=FontWeight.BOLD,
        font_style=FontStyle.ITALIC,
        paint=LinearGradient(RGBColor(30, 4, 206), RGBColor(209, 6, 235), angle=90),
        letter_spacing=2,
        line_height=1.5,
        text_transform=TextTransform.UPPER,
        decoration=TextDecoration.UNDERLINE,
        decoration_color=RGBColor(255, 0, 0),
        shadow=Shadow(offset=(4, 4), blur_radius=6, color=RGBAColor(0, 0, 0, 128)),
    )

    # Get PIL font:
    pil_font = style.to_pil_font()

    # Render styled text (returns an RGBA image):
    img = style.render("Hello World", max_width=800)

Rich text (inline markup)::

    from lumora.font.rich_text import render_rich_text, TextSpan

    img = render_rich_text(
        "Hello <b>World</b>, <color=#FF0000>red</color> text",
        style,
        max_width=800,
    )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Tuple, Union

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

from ..config import (
    LinearGradient,
    RadialGradient,
    RGBAColor,
    RGBColor,
)

# ─── Fonts directory ────────────────────────────────────────────────────────

_FONTS_DIR = Path(__file__).parent / "fonts"

# Mapping font_family name → folder name (case-insensitive lookup)
_FAMILY_DIRS = {d.name.lower(): d for d in _FONTS_DIR.iterdir() if d.is_dir()}

# ─── Enums ──────────────────────────────────────────────────────────────────


class FontWeight(Enum):
    """Font weight — follows CSS/Flutter conventions."""

    THIN = "Thin"  # 100
    EXTRA_LIGHT = "ExtraLight"  # 200
    LIGHT = "Light"  # 300
    REGULAR = "Regular"  # 400
    MEDIUM = "Medium"  # 500
    SEMI_BOLD = "SemiBold"  # 600
    BOLD = "Bold"  # 700
    EXTRA_BOLD = "ExtraBold"  # 800
    BLACK = "Black"  # 900

    # Aliases
    NORMAL = "Regular"
    W100 = "Thin"
    W200 = "ExtraLight"
    W300 = "Light"
    W400 = "Regular"
    W500 = "Medium"
    W600 = "SemiBold"
    W700 = "Bold"
    W800 = "ExtraBold"
    W900 = "Black"


class FontStyle(Enum):
    """Font style."""

    NORMAL = "normal"
    ITALIC = "Italic"


class TextTransform(Enum):
    """Text transformation applied before rendering."""

    NONE = "none"
    UPPER = "upper"  # ALL UPPERCASE
    LOWER = "lower"  # all lowercase
    CAPITALIZE = "capitalize"  # Title Case


class TextAlign(Enum):
    """Horizontal text alignment."""

    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"


class TextDecoration(Enum):
    """Text decoration."""

    NONE = "none"
    UNDERLINE = "underline"
    OVERLINE = "overline"
    LINE_THROUGH = "line_through"


# ─── Paint type ─────────────────────────────────────────────────────────────

Paint = Union[RGBColor, RGBAColor, LinearGradient, RadialGradient]

# ─── Shadow ─────────────────────────────────────────────────────────────────


@dataclass
class Shadow:
    """Text shadow — similar to CSS text-shadow.

    Args:
        offset: (dx, dy) shadow offset in pixels.
        blur_radius: Gaussian blur radius for the shadow.
        color: Shadow color.
    """

    offset: Tuple[int, int] = (2, 2)
    blur_radius: int = 4
    color: RGBColor | RGBAColor = field(default_factory=lambda: RGBAColor(0, 0, 0, 128))


# ─── TextStyle ──────────────────────────────────────────────────────────────


@dataclass
class TextStyle:
    """Comprehensive text styling — CSS/Flutter-like.

    Args:
        font_family: Font family name (folder in fonts/, e.g. "inter", "montserrat").
                     None = uses default PIL font.
        font_path: Direct path to a .ttf/.otf file (highest priority).
                   If set, font_family/font_weight/font_style are ignored.
        font_size: Font size in pixels.
        font_weight: Font weight (THIN..BLACK).
        font_style: Font style (NORMAL/ITALIC).
        paint: Text color or gradient. Solid colors are drawn directly; gradients are masked.
        line_height: Line height as a multiplier (1.0 = normal, 1.5 = 1.5x).
        letter_spacing: Spacing between characters (pixels). 0 = normal.
        text_align: Horizontal text alignment.
        text_transform: Text transformation (UPPER/LOWER/CAPITALIZE).
        decoration: Text decoration (UNDERLINE/OVERLINE/LINE_THROUGH).
        decoration_color: Decoration color. None = follows paint color.
        decoration_thickness: Decoration thickness (pixels).
        background: Background highlight behind the text.
        shadow: Text shadow.
        baseline_shift: Vertical baseline offset (pixels). Positive = upward.
    """

    font_family: str | None = None
    font_path: str | Path | None = None
    font_size: int = 40
    font_weight: FontWeight = FontWeight.REGULAR
    font_style: FontStyle = FontStyle.NORMAL
    paint: Paint = field(default_factory=lambda: RGBColor(255, 255, 255))
    line_height: float = 1.2
    letter_spacing: int = 0
    text_align: TextAlign = TextAlign.LEFT
    text_transform: TextTransform = TextTransform.NONE
    decoration: TextDecoration = TextDecoration.NONE
    decoration_color: RGBColor | RGBAColor | None = None
    decoration_thickness: int = 2
    background: RGBColor | RGBAColor | None = None
    shadow: Shadow | None = None
    baseline_shift: float = 0

    # ── Font resolution ──────────────────────────────────────────────────

    def _resolve_font_path(self) -> Path | None:
        """Locate the font file based on family + weight + style."""
        if self.font_family is None:
            return None

        family_key = self.font_family.lower()
        family_dir = _FAMILY_DIRS.get(family_key)
        if family_dir is None:
            return None

        weight_name = self.font_weight.value  # e.g. "Bold"
        style_name = self.font_style.value  # "normal" or "Italic"

        # Build expected filename patterns
        family_stem = family_dir.name  # e.g. "inter" or "Montserrat"

        # Search for matching file
        # Pattern: FamilyName-WeightStyle.ext
        # e.g. Inter-BoldItalic.otf, Montserrat-Regular.ttf
        candidates: list[str] = []
        if style_name == "Italic":
            if weight_name == "Regular":
                candidates.append(f"-Italic")
            else:
                candidates.append(f"-{weight_name}Italic")
        else:
            candidates.append(f"-{weight_name}")

        for suffix in candidates:
            for ext in (".otf", ".ttf"):
                # Try exact case
                path = family_dir / f"{family_stem}{suffix}{ext}"
                if path.exists():
                    return path
                # Try case-insensitive scan
                target = f"{family_stem}{suffix}{ext}".lower()
                for f in family_dir.iterdir():
                    if f.name.lower() == target:
                        return f

        return None

    def to_pil_font(self) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
        """Resolve this TextStyle to a PIL font object."""
        # Priority 1: direct font_path
        if self.font_path is not None:
            return ImageFont.truetype(str(self.font_path), size=self.font_size)
        # Priority 2: font_family + weight + style
        font_path = self._resolve_font_path()
        if font_path is not None:
            return ImageFont.truetype(str(font_path), size=self.font_size)
        return ImageFont.load_default(size=self.font_size)

    # ── Text transform ───────────────────────────────────────────────────

    def transform_text(self, text: str) -> str:
        """Apply text_transform to the string."""
        if self.text_transform == TextTransform.UPPER:
            return text.upper()
        elif self.text_transform == TextTransform.LOWER:
            return text.lower()
        elif self.text_transform == TextTransform.CAPITALIZE:
            return text.title()
        return text

    # ── Measurement helpers ──────────────────────────────────────────────

    def _measure_line(
        self,
        text: str,
        font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
        draw: ImageDraw.ImageDraw,
    ) -> Tuple[int, int]:
        """Measure a single line of text, accounting for letter_spacing.

        Returns:
            (width, height)
        """
        if self.letter_spacing == 0:
            bbox = draw.textbbox((0, 0), text, font=font)
            return int(bbox[2] - bbox[0]), int(bbox[3] - bbox[1])

        # With letter_spacing: calculate manually
        total_w = 0
        max_h = 0
        for _i, ch in enumerate(text):
            bbox = draw.textbbox((0, 0), ch, font=font)
            ch_w = int(bbox[2] - bbox[0])
            ch_h = int(bbox[3] - bbox[1])
            total_w += ch_w
            if _i < len(text) - 1:
                total_w += self.letter_spacing
            max_h = max(max_h, ch_h)

        return total_w, max_h

    def _draw_line(
        self,
        draw: ImageDraw.ImageDraw,
        text: str,
        x: int,
        y: int,
        font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
        fill: int | Tuple[int, ...] = (255, 255, 255),
    ) -> int:
        """Draw a single line of text; returns the drawn width.

        With letter_spacing > 0, draws character by character.
        """
        if self.letter_spacing == 0:
            bbox = draw.textbbox((0, 0), text, font=font)
            draw.text((x - bbox[0], y - bbox[1]), text, font=font, fill=fill)
            return int(bbox[2] - bbox[0])

        cx = x
        for i, ch in enumerate(text):
            bbox = draw.textbbox((0, 0), ch, font=font)
            draw.text((cx - bbox[0], y - bbox[1]), ch, font=font, fill=fill)
            ch_w = int(bbox[2] - bbox[0])
            cx += ch_w + self.letter_spacing

        return cx - x - (self.letter_spacing if text else 0)

    # ── Gradient mask rendering ──────────────────────────────────────────

    def _render_paint(self, mask: Image.Image) -> Image.Image:
        """Apply paint (solid color or gradient) to the text mask.

        mask: Grayscale image where white = text area.
        Returns: RGBA image with the color/gradient applied.
        """
        w, h = mask.size

        if isinstance(self.paint, (RGBColor, RGBAColor)):
            # Solid color — return directly
            color = self.paint.to_tuple()
            if len(color) == 3:
                color = (*color, 255)
            result = Image.new("RGBA", (w, h), color)
            result.putalpha(mask)
            return result

        # Gradient — render gradient image then mask
        from ..ops import render_linear_gradient, render_radial_gradient

        if isinstance(self.paint, LinearGradient):
            gradient_img = render_linear_gradient(w, h, self.paint)
        elif isinstance(self.paint, RadialGradient):
            gradient_img = render_radial_gradient(w, h, self.paint)
        else:
            gradient_img = Image.new("RGBA", (w, h), (255, 255, 255, 255))

        # Mask gradient with text shape
        gradient_alpha = gradient_img.getchannel("A")
        combined_alpha = ImageChops.multiply(gradient_alpha, mask)
        gradient_img.putalpha(combined_alpha)
        return gradient_img

    # ── Main render ──────────────────────────────────────────────────────

    def render(self, text: str, max_width: int = 0) -> Image.Image:
        """Render text with full styling → RGBA image.

        Args:
            text: The text to render.
            max_width: Maximum width (0 = no limit, wraps content).

        Returns:
            PIL RGBA Image.
        """
        font = self.to_pil_font()
        text = self.transform_text(text)

        dummy = Image.new("RGBA", (1, 1))
        dummy_draw = ImageDraw.Draw(dummy)

        # Split lines & measure
        raw_lines = text.split("\n")
        line_h_ref = self._measure_line("Ay", font, dummy_draw)[1]
        actual_line_h = max(1, int(line_h_ref * self.line_height))

        # Measure each line
        line_widths: list[int] = []
        for line in raw_lines:
            if line:
                lw, _ = self._measure_line(line, font, dummy_draw)
            else:
                lw = 0
            line_widths.append(lw)

        canvas_w = max(1, max(line_widths)) if line_widths else 1
        if max_width > 0:
            canvas_w = max(canvas_w, max_width)

        total_h = actual_line_h * len(raw_lines)

        # Account for shadow expanding canvas
        shadow_pad_x = 0
        shadow_pad_y = 0
        if self.shadow:
            sx = abs(self.shadow.offset[0]) + self.shadow.blur_radius * 2
            sy = abs(self.shadow.offset[1]) + self.shadow.blur_radius * 2
            shadow_pad_x = sx
            shadow_pad_y = sy

        # Account for baseline shift
        shift_y = int(self.baseline_shift)

        final_w = canvas_w + shadow_pad_x
        final_h = total_h + shadow_pad_y + abs(shift_y)

        # Offset for shadow (if shadow goes left/up)
        origin_x = (
            max(0, -(self.shadow.offset[0]) + self.shadow.blur_radius * 2)
            if self.shadow
            else 0
        )
        origin_y = (
            max(0, -(self.shadow.offset[1]) + self.shadow.blur_radius * 2)
            if self.shadow
            else 0
        )
        origin_y += max(0, shift_y)  # baseline shift up → move origin down

        # ── Step 1: Render text mask (white on black, grayscale) ─────────
        mask_img = Image.new("L", (final_w, final_h), 0)
        mask_draw = ImageDraw.Draw(mask_img)

        y = origin_y - shift_y
        for i, line in enumerate(raw_lines):
            if not line:
                y += actual_line_h
                continue

            # Text align
            lw = line_widths[i]
            if self.text_align == TextAlign.CENTER:
                x = origin_x + (canvas_w - lw) // 2
            elif self.text_align == TextAlign.RIGHT:
                x = origin_x + canvas_w - lw
            else:
                x = origin_x

            self._draw_line(mask_draw, line, x, y, font, fill=255)
            y += actual_line_h

        # ── Step 2: Shadow layer ─────────────────────────────────────────
        canvas = Image.new("RGBA", (final_w, final_h), (0, 0, 0, 0))

        if self.shadow:
            s = self.shadow
            s_color = (
                s.color.to_tuple() if hasattr(s.color, "to_tuple") else (0, 0, 0, 128)
            )
            if len(s_color) == 3:
                s_color = (*s_color, 128)

            # Offset mask for shadow position
            shadow_mask = Image.new("L", (final_w, final_h), 0)
            shadow_mask.paste(mask_img, (s.offset[0], s.offset[1]))

            if s.blur_radius > 0:
                shadow_mask = shadow_mask.filter(
                    ImageFilter.GaussianBlur(s.blur_radius)
                )

            shadow_layer = Image.new("RGBA", (final_w, final_h), s_color[:3] + (255,))
            # Multiply shadow alpha with mask alpha
            shadow_alpha = shadow_mask.point(
                lambda a: min(255, int(a * s_color[3] / 255))
            )  # type: ignore[arg-type]
            shadow_layer.putalpha(shadow_alpha)
            canvas = Image.alpha_composite(canvas, shadow_layer)

        # ── Step 3: Background highlight ─────────────────────────────────
        if self.background:
            bg_color = self.background.to_tuple()
            if len(bg_color) == 3:
                bg_color = (*bg_color, 255)

            y = origin_y - shift_y
            for i, line in enumerate(raw_lines):
                lw = line_widths[i]
                if not line or lw == 0:
                    y += actual_line_h
                    continue

                if self.text_align == TextAlign.CENTER:
                    bx = origin_x + (canvas_w - lw) // 2
                elif self.text_align == TextAlign.RIGHT:
                    bx = origin_x + canvas_w - lw
                else:
                    bx = origin_x

                bg_rect = Image.new("RGBA", (lw, actual_line_h), bg_color)
                canvas.paste(bg_rect, (bx, y), bg_rect)
                y += actual_line_h

        # ── Step 4: Paint (color/gradient) teks ──────────────────────────
        text_layer = self._render_paint(mask_img)
        canvas = Image.alpha_composite(canvas, text_layer)

        # ── Step 5: Decoration ───────────────────────────────────────────
        if self.decoration != TextDecoration.NONE:
            deco_draw = ImageDraw.Draw(canvas)
            deco_color = (
                self.decoration_color.to_tuple()
                if self.decoration_color
                else self._solid_paint_color()
            )
            if len(deco_color) == 3:
                deco_color = (*deco_color, 255)

            thickness = self.decoration_thickness

            y = origin_y - shift_y
            for i, line in enumerate(raw_lines):
                lw = line_widths[i]
                if not line or lw == 0:
                    y += actual_line_h
                    continue

                if self.text_align == TextAlign.CENTER:
                    dx = origin_x + (canvas_w - lw) // 2
                elif self.text_align == TextAlign.RIGHT:
                    dx = origin_x + canvas_w - lw
                else:
                    dx = origin_x

                if self.decoration == TextDecoration.UNDERLINE:
                    dy = y + line_h_ref + 2
                elif self.decoration == TextDecoration.OVERLINE:
                    dy = y - 2
                elif self.decoration == TextDecoration.LINE_THROUGH:
                    dy = y + line_h_ref // 2
                else:
                    dy = y + line_h_ref

                for t in range(thickness):
                    deco_draw.line(
                        [(dx, dy + t), (dx + lw, dy + t)],
                        fill=deco_color,
                    )

                y += actual_line_h

        return canvas

    def _solid_paint_color(self) -> Tuple[int, ...]:
        """Extract solid color from paint (falls back to white for gradients)."""
        if isinstance(self.paint, (RGBColor, RGBAColor)):
            return self.paint.to_tuple()
        return (255, 255, 255, 255)

    # ── Shortcut methods ─────────────────────────────────────────────────

    def copy_with(self, **kwargs: Any) -> TextStyle:
        """Create a copy of this TextStyle with specific parameter overrides.

        Example::

            bold_style = style.copy_with(font_weight=FontWeight.BOLD)
        """
        import dataclasses as _dc

        current = {f.name: getattr(self, f.name) for f in _dc.fields(self)}
        current.update(kwargs)
        return TextStyle(**current)

    def measure(self, text: str) -> Tuple[int, int]:
        """Measure (width, height) of text without rendering."""
        font = self.to_pil_font()
        text = self.transform_text(text)
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)

        lines = text.split("\n")
        line_h_ref = self._measure_line("Ay", font, draw)[1]
        actual_line_h = max(1, int(line_h_ref * self.line_height))

        widths: list[int] = []
        for line in lines:
            if line:
                lw, _ = self._measure_line(line, font, draw)
            else:
                lw = 0
            widths.append(lw)

        total_w = max(widths) if widths else 0
        total_h = actual_line_h * len(lines)
        return (total_w, total_h)
