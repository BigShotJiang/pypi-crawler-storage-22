"""Rich text rendering with inline markup support.

Supports HTML-like tags for inline styling within text:

    <b>bold</b>
    <i>italic</i>
    <u>underline</u>
    <s>strikethrough</s>
    <color=#RRGGBB>colored text</color>  (or <c=#RRGGBB>)
    <size=N>sized text</size>
    <bg=#RRGGBB>highlighted</bg>
    <upper>UPPERCASE</upper>
    <lower>lowercase</lower>

Tags can be nested: <b><color=#FF0000>bold red</color></b>

Example:

    from lumora.font.rich_text import render_rich_text
    from lumora.font import TextStyle

    style = TextStyle(font_path="path/to/font.ttf", font_size=50)
    img = render_rich_text(
        "Hello <b>World</b>, this is <color=#FF0000>red</color>!",
        style,
        max_width=800,
    )
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

from PIL import Image, ImageDraw, ImageFont

from ..config import RGBAColor, RGBColor
from . import (
    FontStyle,
    FontWeight,
    TextAlign,
    TextDecoration,
    TextStyle,
    TextTransform,
)

# ─── Data types ─────────────────────────────────────────────────────────────


@dataclass
class TextSpan:
    """A contiguous piece of text with a single style."""

    text: str
    style: TextStyle


@dataclass
class _Token:
    """A measured token (word, space, or newline) for layout."""

    text: str
    style: TextStyle
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont
    width: int
    ascent: int
    descent: int
    is_space: bool = False
    is_newline: bool = False


@dataclass
class _Line:
    """A laid-out line of tokens."""

    tokens: list[_Token]
    width: int
    ascent: int
    descent: int
    is_paragraph_end: bool = False

    @property
    def height(self) -> int:
        return self.ascent + self.descent


# ─── Colour parsing ────────────────────────────────────────────────────────


def _parse_hex_color(s: str) -> RGBColor | RGBAColor:
    """Parse hex colour string (#RGB, #RRGGBB, #RRGGBBAA)."""
    s = s.lstrip("#")
    if len(s) == 3:
        r = int(s[0] * 2, 16)
        g = int(s[1] * 2, 16)
        b = int(s[2] * 2, 16)
        return RGBColor(r, g, b)
    elif len(s) == 6:
        return RGBColor(int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    elif len(s) == 8:
        return RGBAColor(
            int(s[0:2], 16),
            int(s[2:4], 16),
            int(s[4:6], 16),
            int(s[6:8], 16),
        )
    return RGBColor(255, 255, 255)


# ─── Font variant derivation ──────────────────────────────────────────────

_WEIGHT_KEYWORDS = [
    "thin",
    "extralight",
    "light",
    "regular",
    "medium",
    "semibold",
    "bold",
    "extrabold",
    "black",
]


def _derive_font_variant(
    base_path: str | Path | None,
    target_weight: FontWeight | None = None,
    target_style: FontStyle | None = None,
) -> Path | None:
    """Try to derive a font variant path from a base font path.

    Replaces weight/style keywords in the filename.
    E.g. ``karu-regular.ttf`` + BOLD → ``karu-bold.ttf``
    """
    if base_path is None:
        return None

    path = Path(base_path)
    if not path.exists():
        return None

    stem_lower = path.stem.lower()
    parent = path.parent
    suffix = path.suffix

    # Find current weight keyword in filename
    current_weight: str | None = None
    for wk in _WEIGHT_KEYWORDS:
        if wk in stem_lower:
            current_weight = wk
            break

    if current_weight is None:
        return None

    weight_str = target_weight.value.lower() if target_weight else current_weight
    wants_italic = target_style == FontStyle.ITALIC

    # Build candidate stems
    candidates: list[str] = []
    if wants_italic:
        if weight_str == "regular":
            candidates.append(stem_lower.replace(current_weight, "italic"))
            candidates.append(stem_lower.replace(current_weight, "regularitalic"))
        else:
            candidates.append(stem_lower.replace(current_weight, f"{weight_str}italic"))
            candidates.append(
                stem_lower.replace(current_weight, f"{weight_str}-italic")
            )
    else:
        candidates.append(stem_lower.replace(current_weight, weight_str))

    # Search case-insensitively
    for candidate in candidates:
        for f in parent.iterdir():
            if f.is_file() and f.suffix.lower() == suffix.lower():
                if f.stem.lower() == candidate:
                    return f

    return None


# ─── Markup parsing ────────────────────────────────────────────────────────

_TAG_RE = re.compile(r"<(/?)(\w+)(?:=([^>]*))?>")


def _apply_tag_to_style(
    style: TextStyle,
    tag: str,
    value: str | None,
) -> TextStyle:
    """Return a new TextStyle with the tag's modification applied."""
    tag_l = tag.lower()
    overrides: dict = {}

    if tag_l in ("b", "bold"):
        overrides["font_weight"] = FontWeight.BOLD
        derived = _derive_font_variant(
            style.font_path, FontWeight.BOLD, style.font_style
        )
        if derived:
            overrides["font_path"] = derived

    elif tag_l in ("i", "italic"):
        overrides["font_style"] = FontStyle.ITALIC
        derived = _derive_font_variant(
            style.font_path, style.font_weight, FontStyle.ITALIC
        )
        if derived:
            overrides["font_path"] = derived

    elif tag_l in ("u", "underline"):
        overrides["decoration"] = TextDecoration.UNDERLINE

    elif tag_l in ("s", "strike"):
        overrides["decoration"] = TextDecoration.LINE_THROUGH

    elif tag_l in ("color", "c") and value:
        overrides["paint"] = _parse_hex_color(value)

    elif tag_l == "size" and value:
        try:
            overrides["font_size"] = int(value)
        except ValueError:
            pass

    elif tag_l == "bg" and value:
        overrides["background"] = _parse_hex_color(value)

    elif tag_l == "upper":
        overrides["text_transform"] = TextTransform.UPPER

    elif tag_l == "lower":
        overrides["text_transform"] = TextTransform.LOWER

    if not overrides:
        return style
    return style.copy_with(**overrides)


def parse_rich_text(markup: str, base_style: TextStyle) -> list[TextSpan]:
    """Parse HTML-like markup into a list of :class:`TextSpan`.

    Supported tags (can be nested)::

        <b>, <i>, <u>, <s>,
        <color=#RRGGBB>, <c=#RRGGBB>,
        <size=N>, <bg=#RRGGBB>,
        <upper>, <lower>
    """
    spans: list[TextSpan] = []
    style_stack: list[TextStyle] = [base_style]

    pos = 0
    for match in _TAG_RE.finditer(markup):
        start = match.start()
        if start > pos:
            text = markup[pos:start]
            if text:
                spans.append(TextSpan(text=text, style=style_stack[-1]))

        is_closing = match.group(1) == "/"
        tag_name = match.group(2)
        tag_value = match.group(3)

        if is_closing:
            if len(style_stack) > 1:
                style_stack.pop()
        else:
            new_style = _apply_tag_to_style(style_stack[-1], tag_name, tag_value)
            style_stack.append(new_style)

        pos = match.end()

    # Remaining text after the last tag
    if pos < len(markup):
        remaining = markup[pos:]
        if remaining:
            spans.append(TextSpan(text=remaining, style=style_stack[-1]))

    return spans


# ─── Font metrics helpers ──────────────────────────────────────────────────


def _get_font_metrics(
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
) -> Tuple[int, int]:
    """Return ``(ascent, descent)`` for *font*."""
    if hasattr(font, "getmetrics"):
        return font.getmetrics()  # type: ignore[return-value]
    # Fallback for bitmap fonts
    dummy = Image.new("RGBA", (1, 1))
    d = ImageDraw.Draw(dummy)
    bbox = d.textbbox((0, 0), "Ayg|", font=font)
    return (int(bbox[3] - bbox[1]), 4)


def _measure_text_width(
    text: str,
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
    draw: ImageDraw.ImageDraw,
    letter_spacing: int = 0,
) -> int:
    """Measure the pixel width of *text* rendered in *font*."""
    if not text:
        return 0
    if letter_spacing > 0 and len(text) > 1:
        total = 0
        for i, ch in enumerate(text):
            bbox = draw.textbbox((0, 0), ch, font=font)
            total += int(bbox[2] - bbox[0])
            if i < len(text) - 1:
                total += letter_spacing
        return total
    bbox = draw.textbbox((0, 0), text, font=font)
    return int(bbox[2] - bbox[0])


# ─── Tokeniser ─────────────────────────────────────────────────────────────

_SPLIT_RE = re.compile(r"( |\n)")


def _tokenise_spans(
    spans: list[TextSpan],
    draw: ImageDraw.ImageDraw,
) -> list[_Token]:
    """Convert *spans* into measurable :class:`_Token` objects."""
    tokens: list[_Token] = []

    for span in spans:
        style = span.style
        text = style.transform_text(span.text)
        font = style.to_pil_font()
        ascent, descent = _get_font_metrics(font)

        parts = _SPLIT_RE.split(text)
        for part in parts:
            if not part:
                continue
            if part == "\n":
                tokens.append(
                    _Token(
                        text="",
                        style=style,
                        font=font,
                        width=0,
                        ascent=ascent,
                        descent=descent,
                        is_newline=True,
                    )
                )
            elif part == " ":
                w = _measure_text_width(" ", font, draw, style.letter_spacing)
                tokens.append(
                    _Token(
                        text=" ",
                        style=style,
                        font=font,
                        width=w,
                        ascent=ascent,
                        descent=descent,
                        is_space=True,
                    )
                )
            else:
                w = _measure_text_width(part, font, draw, style.letter_spacing)
                tokens.append(
                    _Token(
                        text=part,
                        style=style,
                        font=font,
                        width=w,
                        ascent=ascent,
                        descent=descent,
                    )
                )

    return tokens


# ─── Line layout ───────────────────────────────────────────────────────────


def _make_line(
    toks: list[_Token],
    width: int,
    default_ascent: int,
    default_descent: int,
    is_para_end: bool = False,
) -> _Line:
    """Build a :class:`_Line`, stripping trailing spaces."""
    # Strip trailing spaces
    while toks and toks[-1].is_space:
        width -= toks[-1].width
        toks = toks[:-1]

    if toks:
        max_asc = max(t.ascent for t in toks)
        max_desc = max(t.descent for t in toks)
    else:
        max_asc = default_ascent
        max_desc = default_descent

    return _Line(
        tokens=list(toks),
        width=width,
        ascent=max_asc,
        descent=max_desc,
        is_paragraph_end=is_para_end,
    )


def _layout_lines(
    tokens: list[_Token],
    max_width: int,
    default_ascent: int,
    default_descent: int,
) -> list[_Line]:
    """Arrange *tokens* into wrapped lines."""
    lines: list[_Line] = []
    cur: list[_Token] = []
    cur_w = 0

    for token in tokens:
        if token.is_newline:
            lines.append(
                _make_line(
                    cur, cur_w, default_ascent, default_descent, is_para_end=True
                )
            )
            cur = []
            cur_w = 0
            continue

        if token.is_space:
            if max_width > 0 and cur_w + token.width > max_width and cur:
                lines.append(_make_line(cur, cur_w, default_ascent, default_descent))
                cur = []
                cur_w = 0
                continue
            cur.append(token)
            cur_w += token.width
            continue

        # A real word
        if max_width > 0 and cur_w + token.width > max_width and cur:
            lines.append(_make_line(cur, cur_w, default_ascent, default_descent))
            cur = [token]
            cur_w = token.width
        else:
            cur.append(token)
            cur_w += token.width

    if cur:
        lines.append(
            _make_line(cur, cur_w, default_ascent, default_descent, is_para_end=True)
        )

    return lines


# ─── Renderer ──────────────────────────────────────────────────────────────


def _paint_to_fill(style: TextStyle) -> Tuple[int, ...]:
    """Extract a solid RGBA fill colour from *style.paint*.

    Falls back to white for gradient paints.
    """
    paint = style.paint
    if isinstance(paint, (RGBColor, RGBAColor)):
        c = paint.to_tuple()
        if len(c) == 3:
            return (*c, 255)
        return c
    return (255, 255, 255, 255)


def render_rich_text(
    markup: str,
    base_style: TextStyle,
    max_width: int = 0,
) -> Image.Image:
    """Render rich-text *markup* to an RGBA image.

    Args:
        markup: Text with HTML-like inline tags.
        base_style: Default :class:`TextStyle` (font, size, colour, …).
        max_width: Maximum width for word wrapping (``0`` = no wrap).

    Returns:
        RGBA :class:`PIL.Image.Image`.
    """

    # 1 ── Parse ──────────────────────────────────────────────────────────
    spans = parse_rich_text(markup, base_style)
    if not spans:
        return Image.new("RGBA", (1, 1), (0, 0, 0, 0))

    # 2 ── Tokenise ───────────────────────────────────────────────────────
    dummy = Image.new("RGBA", (1, 1))
    draw = ImageDraw.Draw(dummy)

    tokens = _tokenise_spans(spans, draw)
    if not tokens:
        return Image.new("RGBA", (1, 1), (0, 0, 0, 0))

    # Default metrics from base font
    base_font = base_style.to_pil_font()
    base_ascent, base_descent = _get_font_metrics(base_font)

    # 3 ── Layout ─────────────────────────────────────────────────────────
    lines = _layout_lines(tokens, max_width, base_ascent, base_descent)
    if not lines:
        return Image.new("RGBA", (1, 1), (0, 0, 0, 0))

    # 4 ── Canvas size ────────────────────────────────────────────────────
    lh_factor = base_style.line_height

    canvas_w = max(line.width for line in lines)
    if max_width > 0:
        canvas_w = max(canvas_w, max_width)
    canvas_w = max(1, canvas_w)

    line_heights: list[int] = []
    total_h = 0
    for line in lines:
        lh = max(1, int(line.height * lh_factor))
        line_heights.append(lh)
        total_h += lh
    total_h = max(1, total_h)

    # 5 ── Text alignment ─────────────────────────────────────────────────
    text_align = base_style.text_align

    # 6 ── Render ─────────────────────────────────────────────────────────
    canvas = Image.new("RGBA", (canvas_w, total_h), (0, 0, 0, 0))
    canvas_draw = ImageDraw.Draw(canvas)

    y = 0
    for line_idx, line in enumerate(lines):
        lh = line_heights[line_idx]

        if not line.tokens:
            y += lh
            continue

        # Alignment x offset
        if text_align == TextAlign.CENTER:
            x_start = (canvas_w - line.width) // 2
        elif text_align == TextAlign.RIGHT:
            x_start = canvas_w - line.width
        else:
            x_start = 0

        # Justify: compute extra gap per space
        extra_space = 0.0
        if (
            text_align == TextAlign.JUSTIFY
            and not line.is_paragraph_end
            and max_width > 0
        ):
            space_count = sum(1 for t in line.tokens if t.is_space)
            if space_count > 0:
                needed = max_width - line.width
                if needed > 0:
                    extra_space = needed / space_count

        max_ascent = line.ascent

        # ── Pass 1: backgrounds ──────────────────────────────────────────
        x = float(x_start)
        for token in line.tokens:
            token_w = token.width + (extra_space if token.is_space else 0)
            if token.style.background:
                bg_c = token.style.background.to_tuple()
                if len(bg_c) == 3:
                    bg_c = (*bg_c, 255)
                bg_img = Image.new("RGBA", (max(1, int(token_w)), lh), bg_c)
                canvas.paste(bg_img, (int(x), y), bg_img)
            x += token_w
        # Recreate draw object after pastes
        canvas_draw = ImageDraw.Draw(canvas)

        # ── Pass 2: text ─────────────────────────────────────────────────
        x = float(x_start)
        for token in line.tokens:
            token_w = token.width + (extra_space if token.is_space else 0)

            if token.text and not token.is_newline:
                baseline_y = y + max_ascent
                fill = _paint_to_fill(token.style)

                try:
                    if token.style.letter_spacing > 0:
                        cx = x
                        for ch in token.text:
                            canvas_draw.text(
                                (cx, baseline_y),
                                ch,
                                font=token.font,
                                fill=fill,
                                anchor="ls",
                            )
                            bbox = canvas_draw.textbbox((0, 0), ch, font=token.font)
                            ch_w = int(bbox[2] - bbox[0])
                            cx += ch_w + token.style.letter_spacing
                    else:
                        canvas_draw.text(
                            (x, baseline_y),
                            token.text,
                            font=token.font,
                            fill=fill,
                            anchor="ls",
                        )
                except TypeError:
                    # Fallback for older Pillow without anchor support
                    dy = max_ascent - token.ascent
                    canvas_draw.text(
                        (int(x), y + dy),
                        token.text,
                        font=token.font,
                        fill=fill,
                    )

            x += token_w

        # ── Pass 3: decorations ──────────────────────────────────────────
        x = float(x_start)
        for token in line.tokens:
            token_w = token.width + (extra_space if token.is_space else 0)

            if (
                token.text
                and not token.is_space
                and token.style.decoration != TextDecoration.NONE
            ):
                if token.style.decoration_color:
                    deco_fill = token.style.decoration_color.to_tuple()
                else:
                    deco_fill = _paint_to_fill(token.style)
                if len(deco_fill) == 3:
                    deco_fill = (*deco_fill, 255)

                thickness = token.style.decoration_thickness
                baseline_y = y + max_ascent

                if token.style.decoration == TextDecoration.UNDERLINE:
                    dy = int(baseline_y + 4)
                elif token.style.decoration == TextDecoration.OVERLINE:
                    dy = int(y + (max_ascent - token.ascent))
                elif token.style.decoration == TextDecoration.LINE_THROUGH:
                    dy = int(baseline_y - token.ascent // 3)
                else:
                    dy = int(baseline_y)

                for t in range(thickness):
                    canvas_draw.line(
                        [(int(x), dy + t), (int(x) + int(token_w), dy + t)],
                        fill=deco_fill,
                    )

            x += token_w

        y += lh

    return canvas
