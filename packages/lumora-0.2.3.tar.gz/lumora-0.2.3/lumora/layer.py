from __future__ import annotations
from typing import List
from PIL import Image, ImageDraw, ImageFont
from abc import ABC, abstractmethod
from typing import Callable, Tuple
from pathlib import Path
from .effect import Effect
from .ops import rectangle_gradient, draw_justified_text

from .config import (
    Coordinate,
    GradientColor,
    Margin,
    MarginAxis,
    RGBColor,
    RGBAColor,
    Shape,
    Size,
)


class BaseLayer(ABC):
    image: Image.Image
    preprocess: List[Callable[[Image.Image], Image.Image]] = []

    # def __init__(self):
    @abstractmethod
    def setup(self) -> Image.Image:
        raise NotImplementedError("Subclasses should implement this method.")

    def render(self) -> Image.Image:
        im = self.setup()
        for process in self.preprocess:
            im = process(im)
        return im

    def add_effect(self, effect: Effect) -> BaseLayer:
        self.image = effect.apply(self.setup())
        return self

    def add_card(self, card: BaseCard) -> BaseLayer:
        self.image = card.apply(self.image)
        return self

    def clip(self, shape: Shape) -> BaseLayer:
        self.image = shape.clip(self.image)
        return self


class BaseCard(ABC):
    position: Coordinate

    def __init__(self):
        self.preprocess: List[Callable[[Image.Image], Image.Image]] = []

    @abstractmethod
    def render(self, data: Image.Image) -> Image.Image:
        raise NotImplementedError("Subclasses should implement this method.")

    def apply(self, data: Image.Image) -> Image.Image:
        im = self.render(data)
        orig_size = im.size
        for process in self.preprocess:
            im = process(im)
        # Adjust position if image size changed (e.g. due to stroke padding)
        dx = (im.width - orig_size[0]) // 2
        dy = (im.height - orig_size[1]) // 2
        data.paste(im, (self.position.x - dx, self.position.y - dy), im)
        return data

    def clip(self, shape: Shape) -> BaseCard:
        self.preprocess.append(shape.clip)
        return self

    def apply_effect(self, effect: Effect) -> BaseCard:
        self.preprocess.append(effect.apply)
        return self


class DarkTransclucentCard(BaseCard):
    def __init__(
        self,
        color: RGBAColor = RGBAColor(0, 0, 0, int(0.5 * 255)),
        size: Size | Margin | MarginAxis = Size(500, 300),
        position: Coordinate = Coordinate(0, 0),
    ):
        super().__init__()
        self.size = size
        self.position = position
        self.color = color

    def render(self, data: Image.Image) -> Image.Image:
        if isinstance(self.size, Margin):
            w, h = data.size
            width = w - self.size.left - self.size.right
            height = h - self.size.top - self.size.bottom
            self.position.x = self.size.left
            self.position.y = self.size.top
            self.size = Size(width, height)
        elif isinstance(self.size, MarginAxis):
            w, h = data.size
            width = w - 2 * self.size.horizontal
            height = h - 2 * self.size.vertical
            self.position.x = self.size.horizontal
            self.position.y = self.size.vertical
            self.size = Size(width, height)
        return Image.new(
            "RGBA",
            (self.size.width, self.size.height),
            (self.color.r, self.color.g, self.color.b, self.color.a),
        )
        # return Image.new("RGBA", (self.size.width, self.size.height), (self.color.r, self.color.g, self.color.b, self.color.a))


class BackgroundLayer(BaseLayer):
    def __init__(self, image_path: Path):
        self.image = Image.open(image_path).convert("RGBA")

    def setup(self) -> Image.Image:
        return self.image


class ImagePILLayer(BaseLayer):
    def __init__(self, image: Image.Image):
        self.image = image.convert("RGBA")


class BackgroundColorLayer(BaseLayer):
    def __init__(
        self, color: RGBColor | RGBAColor, size: Tuple[int, int] = (2520, 1780)
    ):
        self.image = Image.new(color.mode(), size, color.to_tuple())
        if isinstance(color, RGBColor):
            self.image = self.image.convert("RGBA")

    def setup(self) -> Image.Image:
        # Create a solid color image
        return self.image

    def copy(self) -> BackgroundColorLayer:
        new_layer = BackgroundColorLayer(RGBColor(0, 0, 0), self.image.size)
        new_layer.image = self.image.copy()
        return new_layer

    def clip(self, shape: Shape) -> BackgroundColorLayer:
        self.image = shape.clip(self.image)
        return self


class RectangleLayer(BaseLayer):
    def __init__(
        self,
        size: Size,
        color: RGBColor | RGBAColor | GradientColor,
        position: Coordinate = Coordinate(0, 0),
    ):
        self.size = size
        self.position = position
        if isinstance(color, GradientColor):
            self.image = rectangle_gradient(Size(size.width, size.height), color)
        else:
            self.image = Image.new(
                color.mode(), (size.width, size.height), color.to_tuple()
            )
            if isinstance(color, RGBColor):
                self.image = self.image.convert("RGBA")

    def setup(self) -> Image.Image:
        return self.image


class HighlightTextLayer(BaseLayer):
    def __init__(
        self,
        text: str,
        font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
        color: RGBColor | RGBAColor | GradientColor,
        text_color: RGBColor | RGBAColor = RGBColor(255, 255, 255),
        position: Coordinate = Coordinate(0, 0),
        is_vertical_gradient: bool = False,
        padding: Margin | MarginAxis | int = 0,
    ):
        self.text = text
        self.font = font
        self.position = position
        self.color = color
        self.text_color = text_color
        self.is_vertical_gradient = is_vertical_gradient
        if isinstance(padding, int):
            self.padding = Margin(padding, padding, padding, padding)
        elif isinstance(padding, MarginAxis):
            self.padding = Margin(
                padding.vertical,
                padding.horizontal,
                padding.vertical,
                padding.horizontal,
            )
        else:
            self.padding = padding

    def clip(self, shape: Shape) -> HighlightTextLayer:
        self.preprocess.append(shape.clip)
        return self

    def setup(self) -> Image.Image:
        # Calculate text size to create a properly sized image
        dummy_img = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy_img)
        text_bbox = draw.textbbox((0, 0), self.text, font=self.font)
        # bbox offset: text_bbox[0]=x_offset, text_bbox[1]=y_offset (top gap from font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]

        # Rectangle size = text + padding
        rect_width = int(text_width + self.padding.left + self.padding.right)
        rect_height = int(text_height + self.padding.top + self.padding.bottom)

        if isinstance(self.color, GradientColor):
            self.image = rectangle_gradient(
                Size(rect_width, rect_height),
                self.color,
                is_vertical=self.is_vertical_gradient,
            )
        else:
            self.image = Image.new(
                self.color.mode(), (rect_width, rect_height), self.color.to_tuple()
            )
            if isinstance(self.color, RGBColor):
                self.image = self.image.convert("RGBA")

        # Draw text centered in the rectangle, compensating for bbox offset
        draw = ImageDraw.Draw(self.image)
        text_x = self.padding.left - text_bbox[0]
        text_y = self.padding.top - text_bbox[1]
        draw.text(
            (text_x, text_y),
            self.text,
            font=self.font,
            fill=self.text_color.to_tuple(),
        )
        return self.image


class JustifiedTextLayer(BaseLayer):
    """Justified (left-right aligned) text layer with automatic word wrapping.

    Text is automatically wrapped to new lines when exceeding max_width,
    and inter-word spacing is adjusted for full justification.

    Args:
        text: Text content to draw.
        font: Font to use.
        max_width: Maximum width of the text area (pixels).
        text_color: Text color.
        line_spacing: Space between lines (pixels).
        padding: Padding around the text.
    """

    def __init__(
        self,
        text: str,
        font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
        max_width: int,
        text_color: RGBColor | RGBAColor = RGBColor(255, 255, 255),
        line_spacing: int = 10,
        padding: Margin | MarginAxis | int = 0,
    ):
        self.text = text
        self.font = font
        self.max_width = max_width
        self.text_color = text_color
        self.line_spacing = line_spacing
        if isinstance(padding, int):
            self.padding = Margin(padding, padding, padding, padding)
        elif isinstance(padding, MarginAxis):
            self.padding = Margin(
                padding.vertical,
                padding.horizontal,
                padding.vertical,
                padding.horizontal,
            )
        else:
            self.padding = padding

    def setup(self) -> Image.Image:
        content_width = self.max_width - self.padding.left - self.padding.right

        # Pre-render to a large temporary image to measure height
        temp_img = Image.new("RGBA", (self.max_width, 10000), (0, 0, 0, 0))
        temp_draw = ImageDraw.Draw(temp_img)
        total_height = draw_justified_text(
            draw=temp_draw,
            text=self.text,
            font=self.font,
            max_width=content_width,
            position=(self.padding.left, self.padding.top),
            fill=self.text_color.to_tuple(),
            line_spacing=self.line_spacing,
        )

        # Create final image with exact dimensions
        final_height = total_height + self.padding.top + self.padding.bottom
        self.image = Image.new("RGBA", (self.max_width, final_height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(self.image)
        draw_justified_text(
            draw=draw,
            text=self.text,
            font=self.font,
            max_width=content_width,
            position=(self.padding.left, self.padding.top),
            fill=self.text_color.to_tuple(),
            line_spacing=self.line_spacing,
        )
        return self.image


class ImageLayer(BaseLayer):
    """Image placeholder layer — supports automatic resize & crop.

    If size is not set (None), the image is displayed at its original size.
    If size is set, the image is cover-resized (preserving aspect ratio)
    then center-cropped to fit the target dimensions.

    Args:
        image: PIL Image or path to an image file.
        size: Target size (optional). None = original size.
    """

    def __init__(
        self,
        image: Image.Image | Path,
        size: Size | None = None,
    ):
        if isinstance(image, Path):
            self._source = Image.open(image).convert("RGBA")
        else:
            self._source = image.convert("RGBA")
        self.size = size

    def setup(self) -> Image.Image:
        if self.size is None:
            self.image = self._source.copy()
            return self.image

        target_w, target_h = self.size.width, self.size.height
        src_w, src_h = self._source.size

        # Cover resize: scale so the smallest side fits, other side overflows
        scale = max(target_w / src_w, target_h / src_h)
        new_w = int(src_w * scale)
        new_h = int(src_h * scale)
        resized = self._source.resize((new_w, new_h), Image.LANCZOS)

        # Center crop
        left = (new_w - target_w) // 2
        top = (new_h - target_h) // 2
        self.image = resized.crop((left, top, left + target_w, top + target_h))
        return self.image
