"""Composable layout system inspired by Jetpack Compose / JSX.

Widgets compose automatically with built-in layout management:
- Container: box with background, padding, clipping, and alignment
- Column: vertical layout (top to bottom)
- Row: horizontal layout (left to right)
- Stack: overlapping children (overlay)
- Expanded: fills remaining space in Column/Row
- Spacer: empty space
- SizedBox: box with fixed dimensions
- Padding: padding wrapper
- TextWidget: text
- JustifiedTextWidget: fully justified text with automatic word wrapping
- HighlightTextWidget: text with a highlight background
- ImageWidget: image with automatic resize & crop

Example usage::

    Container(
        width=2520, height=1780,
        background=RGBColor(0, 0, 0),
        padding=80,
        child=Container(
            fill_width=True, fill_height=True,
            background=RGBAColor(255, 255, 255, 76),
            clip=RoundedCorner(40),
            padding=60,
            child=Column(
                spacing=20,
                children=[
                    TextWidget("Header", font=big_font),
                    HighlightTextWidget("Title", font=med_font, background=...),
                    JustifiedTextWidget("Content...", font=small_font),
                    Expanded(ImageWidget(Path("photo.png"))),
                ]
            )
        )
    ).render(2520, 1780)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Tuple

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .config import (
    Alignment,
    Background,
    BackgroundFit,
    CrossAxisAlignment,
    MainAxisAlignment,
    Margin,
    MarginAxis,
    RGBColor,
    RGBAColor,
    RoundedCorner,
    Shape,
    StrokeColor,
)
from .effect import Effect
from .font import TextStyle
from .font.rich_text import render_rich_text
from .ops import draw_justified_text, fit_background_image, render_background, wrap_text


# ─── Helpers ────────────────────────────────────────────────────────────────


def _normalize_padding(padding: Margin | MarginAxis | int) -> Margin:
    """Normalize padding to a Margin instance."""
    if isinstance(padding, int):
        return Margin(padding, padding, padding, padding)
    elif isinstance(padding, MarginAxis):
        return Margin(
            padding.vertical,
            padding.horizontal,
            padding.vertical,
            padding.horizontal,
        )
    return padding


def _calculate_alignment(
    child_w: int,
    child_h: int,
    avail_w: int,
    avail_h: int,
    alignment: Alignment,
) -> Tuple[int, int]:
    """Calculate (x, y) position based on alignment."""
    # Horizontal
    if alignment in (
        Alignment.TOP_START,
        Alignment.CENTER_START,
        Alignment.BOTTOM_START,
    ):
        x = 0
    elif alignment in (
        Alignment.TOP_CENTER,
        Alignment.CENTER,
        Alignment.BOTTOM_CENTER,
    ):
        x = (avail_w - child_w) // 2
    else:
        x = avail_w - child_w

    # Vertical
    if alignment in (
        Alignment.TOP_START,
        Alignment.TOP_CENTER,
        Alignment.TOP_END,
    ):
        y = 0
    elif alignment in (
        Alignment.CENTER_START,
        Alignment.CENTER,
        Alignment.CENTER_END,
    ):
        y = (avail_h - child_h) // 2
    else:
        y = avail_h - child_h

    return max(0, x), max(0, y)


# ─── Base Widget ────────────────────────────────────────────────────────────


class Widget(ABC):
    """Base class for all UI widgets — composable like Jetpack Compose."""

    def __init__(self) -> None:
        self._effects: List[Effect] = []
        self._clip: Shape | None = None
        self._last_image: Image.Image | None = None

    @abstractmethod
    def _render(self, max_width: int, max_height: int) -> Image.Image:
        """Internal render. Subclasses must implement this method."""
        pass

    def render(self, max_width: int = 0, max_height: int = 0) -> Image.Image:
        """Render the widget, then apply clipping and effects."""
        im = self._render(max_width, max_height)
        if self._clip:
            im = self._clip.clip(im)
        for effect in self._effects:
            im = effect.apply(im)
        self._last_image = im
        return im

    @property
    def rendered_width(self) -> int:
        """Width of the last render result. Returns 0 if not yet rendered."""
        return self._last_image.width if self._last_image else 0

    @property
    def rendered_height(self) -> int:
        """Height of the last render result. Returns 0 if not yet rendered."""
        return self._last_image.height if self._last_image else 0

    @property
    def rendered_size(self) -> Tuple[int, int]:
        """(width, height) of the last render result. Returns (0, 0) if not yet rendered."""
        return (self.rendered_width, self.rendered_height)

    def clip(self, shape: Shape) -> Widget:
        """Clip the widget with a shape (RoundedCorner, Circle, etc.)."""
        self._clip = shape
        return self

    def add_effect(self, effect: Effect) -> Widget:
        """Add an effect to the widget (Stroke, Blur, etc.)."""
        self._effects.append(effect)
        return self


# ─── Container ──────────────────────────────────────────────────────────────


class Container(Widget):
    """Container — similar to Box/Surface in Compose.

    Sizing behavior:
    - width/height set → fixed size.
    - Not set + has child + fill=False → wraps child + padding.
    - Not set + fill=True or no child → fills parent space.

    Args:
        child: Child widget (optional).
        width: Fixed width (None = automatic).
        height: Fixed height (None = automatic).
        fill_width: Fill parent width when width=None.
        fill_height: Fill parent height when height=None.
        padding: Padding around the child.
        background: Background color or gradient.
        background_image: Image for the background (Path or PIL Image).
        background_fit: Fit mode for background_image (COVER, CONTAIN, STRETCH, REPEAT, etc.).
        clip: Shape for clipping (RoundedCorner, Circle).
        effects: List of Effects applied to the entire container (background + child).
        background_effects: List of Effects applied only to the background (child unaffected).
        alignment: Child alignment within the container.
    """

    def __init__(
        self,
        child: Widget | None = None,
        width: int | None = None,
        height: int | None = None,
        fill_width: bool = False,
        fill_height: bool = False,
        padding: Margin | MarginAxis | int = 0,
        background: Background | None = None,
        background_image: Image.Image | Path | None = None,
        background_fit: BackgroundFit = BackgroundFit.COVER,
        clip: Shape | None = None,
        effects: List[Effect] | None = None,
        background_effects: List[Effect] | None = None,
        alignment: Alignment = Alignment.TOP_START,
    ):
        super().__init__()
        self.child = child
        self.width = width
        self.height = height
        self.fill_width = fill_width
        self.fill_height = fill_height
        self.padding = _normalize_padding(padding)
        self.background = background
        self.background_fit = background_fit
        self.background_effects = background_effects or []
        self.alignment = alignment

        # Load background image
        if isinstance(background_image, Path):
            self._bg_image = Image.open(background_image).convert("RGBA")
        elif isinstance(background_image, Image.Image):
            self._bg_image = background_image.convert("RGBA")
        else:
            self._bg_image = None

        if clip:
            self._clip = clip
        if effects:
            self._effects.extend(effects)

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        pad = self.padding

        # Pre-calculate content area
        pre_w = self.width if self.width is not None else max_width
        pre_h = self.height if self.height is not None else max_height
        content_w = max(0, pre_w - pad.left - pad.right)
        content_h = max(0, pre_h - pad.top - pad.bottom)

        # Render child
        child_img = None
        if self.child:
            child_img = self.child.render(content_w, content_h)

        # Determine final size
        if self.width is not None:
            w = self.width
        elif child_img is not None and not self.fill_width:
            w = child_img.width + pad.left + pad.right
        else:
            w = max_width

        if self.height is not None:
            h = self.height
        elif child_img is not None and not self.fill_height:
            h = child_img.height + pad.top + pad.bottom
        else:
            h = max_height

        w = max(1, w)
        h = max(1, h)

        # Render background
        if self.background:
            canvas = render_background(w, h, self.background)
        else:
            canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))

        # Render background image (on top of background color/gradient)
        if self._bg_image is not None:
            bg_img = fit_background_image(self._bg_image, w, h, self.background_fit)
            canvas = Image.alpha_composite(canvas, bg_img)

        # Apply background-only effects (before child is pasted)
        for effect in self.background_effects:
            canvas = effect.apply(canvas)

        # Paste child with alignment
        if child_img:
            avail_w = w - pad.left - pad.right
            avail_h = h - pad.top - pad.bottom
            ax, ay = _calculate_alignment(
                child_img.width, child_img.height, avail_w, avail_h, self.alignment
            )
            canvas.paste(child_img, (pad.left + ax, pad.top + ay), child_img)

        return canvas


# ─── Column ─────────────────────────────────────────────────────────────────


class Column(Widget):
    """Vertical layout — arranges children from top to bottom (like Column in Compose).

    Args:
        children: List of child widgets.
        spacing: Space between children (pixels). Ignored for SPACE_* alignments.
        main_axis_alignment: Alignment along the main axis (vertical).
        cross_axis_alignment: Alignment along the cross axis (horizontal).
    """

    def __init__(
        self,
        children: List[Widget],
        spacing: int = 0,
        main_axis_alignment: MainAxisAlignment = MainAxisAlignment.START,
        cross_axis_alignment: CrossAxisAlignment = CrossAxisAlignment.START,
    ):
        super().__init__()
        self.children = children
        self.spacing = spacing
        self.main_axis_alignment = main_axis_alignment
        self.cross_axis_alignment = cross_axis_alignment

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        if not self.children:
            return Image.new(
                "RGBA", (max(1, max_width), max(1, max_height)), (0, 0, 0, 0)
            )

        # Phase 1: render non-Expanded children
        child_images: List[Image.Image | None] = []
        expanded_indices: List[int] = []
        total_flex = 0
        non_expanded_height = 0

        for i, child in enumerate(self.children):
            if isinstance(child, Expanded):
                child_images.append(None)
                expanded_indices.append(i)
                total_flex += child.flex
            else:
                img = child.render(max_width, max_height)
                child_images.append(img)
                non_expanded_height += img.height

        total_spacing = self.spacing * max(0, len(self.children) - 1)

        # Phase 2: render Expanded children
        remaining = max(0, max_height - non_expanded_height - total_spacing)
        for idx in expanded_indices:
            expanded_widget = self.children[idx]
            assert isinstance(expanded_widget, Expanded)
            flex_h = (
                int(remaining * expanded_widget.flex / total_flex)
                if total_flex > 0
                else 0
            )
            img = expanded_widget.child.render(max_width, flex_h)
            child_images[idx] = img

        rendered = [img for img in child_images if img is not None]
        if not rendered:
            return Image.new(
                "RGBA", (max(1, max_width), max(1, max_height)), (0, 0, 0, 0)
            )

        # Canvas size
        canvas_w = (
            max(1, max_width) if max_width > 0 else max(img.width for img in rendered)
        )

        has_expanded = len(expanded_indices) > 0
        has_layout_alignment = self.main_axis_alignment != MainAxisAlignment.START
        content_h = sum(img.height for img in rendered) + total_spacing
        if has_expanded or has_layout_alignment:
            canvas_h = max(1, max_height)
        else:
            canvas_h = max(1, content_h)

        canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))

        # Calculate Y positions
        y_positions = self._main_axis_positions(rendered, canvas_h)

        # Paste children
        for i, img in enumerate(rendered):
            x = self._cross_axis_x(img.width, canvas_w)
            canvas.paste(img, (x, y_positions[i]), img)

        return canvas

    def _main_axis_positions(
        self, images: List[Image.Image], canvas_h: int
    ) -> List[int]:
        n = len(images)
        heights = [img.height for img in images]
        total_children_h = sum(heights)
        content_h = total_children_h + self.spacing * max(0, n - 1)

        positions: List[int] = []

        if self.main_axis_alignment == MainAxisAlignment.START:
            y = 0
            for h in heights:
                positions.append(y)
                y += h + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.CENTER:
            y = (canvas_h - content_h) // 2
            for h in heights:
                positions.append(y)
                y += h + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.END:
            y = canvas_h - content_h
            for h in heights:
                positions.append(y)
                y += h + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_BETWEEN:
            if n <= 1:
                positions.append(0)
            else:
                gap = (canvas_h - total_children_h) / (n - 1)
                y = 0.0
                for h in heights:
                    positions.append(int(y))
                    y += h + gap

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_AROUND:
            gap = (canvas_h - total_children_h) / n if n > 0 else 0
            y = gap / 2
            for h in heights:
                positions.append(int(y))
                y += h + gap

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_EVENLY:
            gap = (canvas_h - total_children_h) / (n + 1) if n > 0 else 0
            y = gap
            for h in heights:
                positions.append(int(y))
                y += h + gap

        return positions

    def _cross_axis_x(self, child_w: int, canvas_w: int) -> int:
        if self.cross_axis_alignment == CrossAxisAlignment.CENTER:
            return max(0, (canvas_w - child_w) // 2)
        elif self.cross_axis_alignment == CrossAxisAlignment.END:
            return max(0, canvas_w - child_w)
        return 0  # START and STRETCH


# ─── Row ────────────────────────────────────────────────────────────────────


class Row(Widget):
    """Horizontal layout — arranges children from left to right (like Row in Compose).

    Args:
        children: List of child widgets.
        spacing: Space between children (pixels). Ignored for SPACE_* alignments.
        main_axis_alignment: Alignment along the main axis (horizontal).
        cross_axis_alignment: Alignment along the cross axis (vertical).
    """

    def __init__(
        self,
        children: List[Widget],
        spacing: int = 0,
        main_axis_alignment: MainAxisAlignment = MainAxisAlignment.START,
        cross_axis_alignment: CrossAxisAlignment = CrossAxisAlignment.START,
    ):
        super().__init__()
        self.children = children
        self.spacing = spacing
        self.main_axis_alignment = main_axis_alignment
        self.cross_axis_alignment = cross_axis_alignment

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        if not self.children:
            return Image.new(
                "RGBA", (max(1, max_width), max(1, max_height)), (0, 0, 0, 0)
            )

        # Phase 1: render non-Expanded children
        child_images: List[Image.Image | None] = []
        expanded_indices: List[int] = []
        total_flex = 0
        non_expanded_width = 0

        for i, child in enumerate(self.children):
            if isinstance(child, Expanded):
                child_images.append(None)
                expanded_indices.append(i)
                total_flex += child.flex
            else:
                img = child.render(max_width, max_height)
                child_images.append(img)
                non_expanded_width += img.width

        total_spacing = self.spacing * max(0, len(self.children) - 1)

        # Phase 2: render Expanded children
        remaining = max(0, max_width - non_expanded_width - total_spacing)
        for idx in expanded_indices:
            expanded_widget = self.children[idx]
            assert isinstance(expanded_widget, Expanded)
            flex_w = (
                int(remaining * expanded_widget.flex / total_flex)
                if total_flex > 0
                else 0
            )
            img = expanded_widget.child.render(flex_w, max_height)
            child_images[idx] = img

        rendered = [img for img in child_images if img is not None]
        if not rendered:
            return Image.new(
                "RGBA", (max(1, max_width), max(1, max_height)), (0, 0, 0, 0)
            )

        # Canvas size
        canvas_h = (
            max(1, max_height)
            if max_height > 0
            else max(img.height for img in rendered)
        )

        has_expanded = len(expanded_indices) > 0
        has_layout_alignment = self.main_axis_alignment != MainAxisAlignment.START
        content_w = sum(img.width for img in rendered) + total_spacing
        if has_expanded or has_layout_alignment:
            canvas_w = max(1, max_width)
        else:
            canvas_w = max(1, content_w)

        canvas = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))

        # Calculate X positions
        x_positions = self._main_axis_positions(rendered, canvas_w)

        # Paste children
        for i, img in enumerate(rendered):
            y = self._cross_axis_y(img.height, canvas_h)
            canvas.paste(img, (x_positions[i], y), img)

        return canvas

    def _main_axis_positions(
        self, images: List[Image.Image], canvas_w: int
    ) -> List[int]:
        n = len(images)
        widths = [img.width for img in images]
        total_children_w = sum(widths)
        content_w = total_children_w + self.spacing * max(0, n - 1)

        positions: List[int] = []

        if self.main_axis_alignment == MainAxisAlignment.START:
            x = 0
            for w in widths:
                positions.append(x)
                x += w + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.CENTER:
            x = (canvas_w - content_w) // 2
            for w in widths:
                positions.append(x)
                x += w + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.END:
            x = canvas_w - content_w
            for w in widths:
                positions.append(x)
                x += w + self.spacing

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_BETWEEN:
            if n <= 1:
                positions.append(0)
            else:
                gap = (canvas_w - total_children_w) / (n - 1)
                x = 0.0
                for w in widths:
                    positions.append(int(x))
                    x += w + gap

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_AROUND:
            gap = (canvas_w - total_children_w) / n if n > 0 else 0
            x = gap / 2
            for w in widths:
                positions.append(int(x))
                x += w + gap

        elif self.main_axis_alignment == MainAxisAlignment.SPACE_EVENLY:
            gap = (canvas_w - total_children_w) / (n + 1) if n > 0 else 0
            x = gap
            for w in widths:
                positions.append(int(x))
                x += w + gap

        return positions

    def _cross_axis_y(self, child_h: int, canvas_h: int) -> int:
        if self.cross_axis_alignment == CrossAxisAlignment.CENTER:
            return max(0, (canvas_h - child_h) // 2)
        elif self.cross_axis_alignment == CrossAxisAlignment.END:
            return max(0, canvas_h - child_h)
        return 0  # START and STRETCH


# ─── Stack ──────────────────────────────────────────────────────────────────


class Stack(Widget):
    """Stack layout — overlays children on top of each other.

    Args:
        children: List of child widgets (order = z-order; first = bottommost).
        alignment: Default alignment for all children.
    """

    def __init__(
        self,
        children: List[Widget],
        alignment: Alignment = Alignment.TOP_START,
    ):
        super().__init__()
        self.children = children
        self.alignment = alignment

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        canvas = Image.new(
            "RGBA", (max(1, max_width), max(1, max_height)), (0, 0, 0, 0)
        )
        for child in self.children:
            img = child.render(max_width, max_height)
            x, y = _calculate_alignment(
                img.width, img.height, max_width, max_height, self.alignment
            )
            canvas.paste(img, (x, y), img)
        return canvas


# ─── Expanded ───────────────────────────────────────────────────────────────


class Expanded(Widget):
    """Wrapper to make a child fill the remaining space in a Column/Row.

    Use inside Column/Row. Remaining space after non-Expanded children
    is distributed based on flex ratios.

    Args:
        child: The widget to expand.
        flex: Flex ratio (default 1). A child with flex=2 gets 2x the space of flex=1.
    """

    def __init__(self, child: Widget, flex: int = 1):
        super().__init__()
        self.child = child
        self.flex = flex

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        # Fallback when called directly (not by Column/Row)
        return self.child.render(max_width, max_height)


# ─── Spacer & SizedBox ─────────────────────────────────────────────────────


class Spacer(Widget):
    """Transparent empty space. Inside Column/Row, wrap with Expanded
    to fill remaining space.

    Args:
        width: Width (optional, default 0 = use parent constraint).
        height: Height (optional, default 0 = use parent constraint).
    """

    def __init__(self, width: int = 0, height: int = 0):
        super().__init__()
        self._width = width
        self._height = height

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        w = self._width or max_width
        h = self._height or max_height
        return Image.new("RGBA", (max(1, w), max(1, h)), (0, 0, 0, 0))


class SizedBox(Widget):
    """Empty box with fixed dimensions.

    Args:
        width: Width (pixels).
        height: Height (pixels).
    """

    def __init__(self, width: int = 1, height: int = 1):
        super().__init__()
        self._width = width
        self._height = height

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        return Image.new("RGBA", (self._width, self._height), (0, 0, 0, 0))


# ─── Padding ────────────────────────────────────────────────────────────────


class Padding(Widget):
    """Padding wrapper — adds padding around a child widget.

    Args:
        child: Child widget.
        padding: Padding value (int, MarginAxis, or Margin).
    """

    def __init__(self, child: Widget, padding: Margin | MarginAxis | int = 0):
        super().__init__()
        self.child = child
        self.pad = _normalize_padding(padding)

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        avail_w = max(0, max_width - self.pad.left - self.pad.right)
        avail_h = max(0, max_height - self.pad.top - self.pad.bottom)
        child_img = self.child.render(avail_w, avail_h)
        w = child_img.width + self.pad.left + self.pad.right
        h = child_img.height + self.pad.top + self.pad.bottom
        canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        canvas.paste(child_img, (self.pad.left, self.pad.top), child_img)
        return canvas


# ─── TextWidget ─────────────────────────────────────────────────────────────


class TextWidget(Widget):
    """Simple text widget (wraps content).

    Supports newlines (\\n) for multi-line text.
    Accepts either a TextStyle or legacy font+color parameters.

    With TextStyle, automatically supports:
    - font_family, font_weight, font_style
    - gradient paint (masking)
    - letter_spacing, line_height
    - text_transform (UPPER/LOWER/CAPITALIZE)
    - decoration (UNDERLINE/OVERLINE/LINE_THROUGH)
    - shadow, background, baseline_shift

    Args:
        text: The text to display.
        style: TextStyle object (takes priority).
        font: PIL font (legacy — ignored if style is provided).
        color: Text color (legacy — ignored if style is provided).
        line_spacing: Space between lines in pixels (legacy — ignored if style is provided).
    """

    def __init__(
        self,
        text: str,
        style: TextStyle | None = None,
        font: ImageFont.ImageFont | ImageFont.FreeTypeFont | None = None,
        color: RGBColor | RGBAColor = RGBColor(255, 255, 255),
        line_spacing: int = 5,
    ):
        super().__init__()
        self.text = text
        self.style = style
        self.color = color
        self._line_spacing = line_spacing

        # Resolve font: style takes priority
        if style is not None:
            self.font = style.to_pil_font()
        elif font is not None:
            self.font = font
        else:
            self.font = ImageFont.load_default(size=40)

    @property
    def text_width(self) -> int:
        """Text width (pixels) — no rendering required."""
        if self.style:
            return self.style.measure(self.text)[0]
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)
        lines = self.text.split("\n")
        return max(
            int(
                draw.textbbox((0, 0), line or " ", font=self.font)[2]
                - draw.textbbox((0, 0), line or " ", font=self.font)[0]
            )
            for line in lines
        )

    @property
    def text_height(self) -> int:
        """Text height (pixels) — no rendering required."""
        if self.style:
            return self.style.measure(self.text)[1]
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)
        lines = self.text.split("\n")
        line_h = int(
            draw.textbbox((0, 0), "Ay", font=self.font)[3]
            - draw.textbbox((0, 0), "Ay", font=self.font)[1]
        )
        return line_h * len(lines) + self._line_spacing * max(0, len(lines) - 1)

    @property
    def text_size(self) -> Tuple[int, int]:
        """(width, height) of the text (pixels) — no rendering required."""
        return (self.text_width, self.text_height)

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        # ── TextStyle path: full styled render ──
        if self.style:
            return self.style.render(self.text, max_width=0)

        # ── Legacy path: font + color ──
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)
        lines = self.text.split("\n")

        # Measure each line
        line_bboxes = [
            draw.textbbox((0, 0), line or " ", font=self.font) for line in lines
        ]
        line_h = max(int(bb[3] - bb[1]) for bb in line_bboxes)
        w = max(int(bb[2] - bb[0]) for bb in line_bboxes)
        total_h = line_h * len(lines) + self._line_spacing * max(0, len(lines) - 1)

        img = Image.new("RGBA", (max(1, w), max(1, total_h)), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        y = 0
        for line in lines:
            bbox = draw.textbbox((0, 0), line or " ", font=self.font)
            draw.text(
                (-bbox[0], y - bbox[1]),
                line,
                font=self.font,
                fill=self.color.to_tuple(),
            )
            y += line_h + self._line_spacing

        return img


# ─── RichTextWidget ────────────────────────────────────────────────────────


class RichTextWidget(Widget):
    """Rich text widget with HTML-like inline markup.

    Supports inline styling tags within text:
    - ``<b>bold</b>`` — bold text
    - ``<i>italic</i>`` — italic text
    - ``<u>underline</u>`` — underlined text
    - ``<s>strikethrough</s>`` — strikethrough text
    - ``<color=#RRGGBB>colored</color>`` (or ``<c=#RRGGBB>``) — text color
    - ``<size=N>sized</size>`` — font size
    - ``<bg=#RRGGBB>highlight</bg>`` — background highlight
    - ``<upper>UPPERCASE</upper>`` — uppercase
    - ``<lower>lowercase</lower>`` — lowercase

    Tags can be nested: ``<b><color=#FF0000>bold red</color></b>``

    For ``<b>`` and ``<i>`` tags, the engine automatically searches for font variants
    based on the filename (e.g. ``karu-regular.ttf`` → ``karu-bold.ttf``).

    Args:
        text: Text with inline markup.
        style: Base TextStyle providing default font/color/size.
    """

    def __init__(self, text: str, style: TextStyle):
        super().__init__()
        self.text = text
        self.style = style

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        return render_rich_text(self.text, self.style, max_width=max_width)


# ─── JustifiedTextWidget ───────────────────────────────────────────────────


class JustifiedTextWidget(Widget):
    """Fully justified text widget with automatic word wrapping.

    Text is automatically wrapped to new lines and inter-word spacing is adjusted
    to align both the left and right edges. Width uses max_width from the parent.

    Args:
        text: Text content.
        font: PIL font.
        color: Text color.
        line_spacing: Space between lines (pixels).
    """

    def __init__(
        self,
        text: str,
        font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
        color: RGBColor | RGBAColor = RGBColor(255, 255, 255),
        line_spacing: int = 10,
    ):
        super().__init__()
        self.text = text
        self.font = font
        self.color = color
        self.line_spacing = line_spacing

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        if max_width <= 0:
            max_width = 1

        # Pre-render to measure height
        temp = Image.new("RGBA", (max_width, 10000), (0, 0, 0, 0))
        temp_draw = ImageDraw.Draw(temp)
        total_h = draw_justified_text(
            draw=temp_draw,
            text=self.text,
            font=self.font,
            max_width=max_width,
            position=(0, 0),
            fill=self.color.to_tuple(),
            line_spacing=self.line_spacing,
        )

        # Render final
        img = Image.new("RGBA", (max_width, max(1, total_h)), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw_justified_text(
            draw=draw,
            text=self.text,
            font=self.font,
            max_width=max_width,
            position=(0, 0),
            fill=self.color.to_tuple(),
            line_spacing=self.line_spacing,
        )
        return img


# ─── HighlightTextWidget ───────────────────────────────────────────────────


class HighlightTextWidget(Widget):
    """Text widget with a highlight background (like a tag/badge).

    Supports auto-wrap: if the text exceeds the parent’s max_width,
    it wraps to new lines. Each line has its own highlight background
    (inline-style). Line spacing is controlled via the line_spacing parameter.

    Args:
        text: The text to display.
        font: PIL font.
        background: Highlight background (color or gradient).
        text_color: Text color.
        padding: Padding between text and highlight edges.
        line_spacing: Space between wrapped lines (pixels).
    """

    def __init__(
        self,
        text: str,
        font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
        background: Background,
        text_color: RGBColor | RGBAColor = RGBColor(255, 255, 255),
        padding: Margin | MarginAxis | int = 0,
        line_spacing: int = 8,
    ):
        super().__init__()
        self.text = text
        self.font = font
        self.background = background
        self.text_color = text_color
        self.padding = _normalize_padding(padding)
        self.line_spacing = line_spacing

    def _render_line(self, line_text: str) -> Image.Image:
        """Render a single line of text with highlight background."""
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)
        bbox = draw.textbbox((0, 0), line_text, font=self.font)
        text_w = int(bbox[2] - bbox[0])
        text_h = int(bbox[3] - bbox[1])

        pad = self.padding
        rect_w = text_w + pad.left + pad.right
        rect_h = text_h + pad.top + pad.bottom

        img = render_background(max(1, rect_w), max(1, rect_h), self.background)

        draw = ImageDraw.Draw(img)
        draw.text(
            (pad.left - bbox[0], pad.top - bbox[1]),
            line_text,
            font=self.font,
            fill=self.text_color.to_tuple(),
        )
        return img

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        pad = self.padding
        # Text area width = max_width minus left/right padding
        text_max_w = max(1, max_width - pad.left - pad.right) if max_width > 0 else 0

        # Check if the text fits in a single line
        dummy = Image.new("RGBA", (1, 1))
        draw = ImageDraw.Draw(dummy)
        full_bbox = draw.textbbox((0, 0), self.text, font=self.font)
        full_text_w = int(full_bbox[2] - full_bbox[0])

        if text_max_w <= 0 or full_text_w <= text_max_w:
            # Fits in a single line — render directly
            return self._render_line(self.text)

        # Auto-wrap teks
        wrapped = wrap_text(self.text, self.font, text_max_w)
        line_images: List[Image.Image] = []
        for words in wrapped:
            line_text = " ".join(words)
            line_images.append(self._render_line(line_text))

        if not line_images:
            return self._render_line(self.text)

        # Calculate total canvas size
        total_w = max(img.width for img in line_images)
        total_h = sum(img.height for img in line_images) + self.line_spacing * max(
            0, len(line_images) - 1
        )

        canvas = Image.new("RGBA", (max(1, total_w), max(1, total_h)), (0, 0, 0, 0))
        y = 0
        for img in line_images:
            canvas.paste(img, (0, y), img)
            y += img.height + self.line_spacing

        return canvas


# ─── GlassContainer ─────────────────────────────────────────────────────────


class GlassContainer(Widget):
    """Glassmorphism container — frosted glass effect.

    Features:
    - Frosted glass background (blurred backdrop)
    - Semi-transparent tint overlay
    - Rounded corners
    - Subtle border (default: semi-transparent white)
    - Thin highlight on top and left edges (light reflection)

    For proper backdrop blur, provide the ``backdrop`` parameter with
    the image behind this container. Without a backdrop, the container
    only shows tint + highlight + border.

    Args:
        child: Child widget (optional).
        width: Fixed width (None = automatic).
        height: Fixed height (None = automatic).
        fill_width: Fill parent width when width=None.
        fill_height: Fill parent height when height=None.
        padding: Padding around the child.
        corner_radius: Rounded corner radius.
        tint_color: Semi-transparent tint color (glass tint).
        blur_radius: Gaussian blur intensity for the backdrop.
        border_width: Border stroke width.
        border_color: Border color (solid/gradient). Default: semi-transparent white.
        highlight_alpha: Maximum alpha for edge highlights (0 = no highlight).
        highlight_width: Width of the highlight area on edges (pixels).
        backdrop: Background image to blur (optional).
        background_image: Background image rendered below the glass layer (optional).
        background_fit: Fit mode for background_image (COVER, CONTAIN, STRETCH, REPEAT, etc.).
        alignment: Child alignment within the container.
        effects: Additional Effect list.
        background_effects: Effects applied only to the glass background.
    """

    def __init__(
        self,
        child: Widget | None = None,
        width: int | None = None,
        height: int | None = None,
        fill_width: bool = False,
        fill_height: bool = False,
        padding: Margin | MarginAxis | int = 0,
        corner_radius: int = 30,
        tint_color: RGBAColor = RGBAColor(255, 255, 255, 40),
        blur_radius: int = 20,
        border_width: int = 2,
        border_color: StrokeColor | None = None,
        highlight_alpha: int = 30,
        highlight_width: int = 60,
        backdrop: Image.Image | Path | None = None,
        background_image: Image.Image | Path | None = None,
        background_fit: BackgroundFit = BackgroundFit.COVER,
        alignment: Alignment = Alignment.TOP_START,
        effects: List[Effect] | None = None,
        background_effects: List[Effect] | None = None,
    ):
        super().__init__()
        self.child = child
        self.width = width
        self.height = height
        self.fill_width = fill_width
        self.fill_height = fill_height
        self.padding = _normalize_padding(padding)
        self.tint_color = tint_color
        self.blur_radius = blur_radius
        self.highlight_alpha = highlight_alpha
        self.highlight_width = highlight_width
        self.alignment = alignment
        self.background_effects = background_effects or []
        self.background_fit = background_fit

        # Load backdrop
        if isinstance(backdrop, Path):
            self._backdrop = Image.open(backdrop).convert("RGBA")
        elif isinstance(backdrop, Image.Image):
            self._backdrop = backdrop.convert("RGBA")
        else:
            self._backdrop = None

        # Load background image
        if isinstance(background_image, Path):
            self._bg_image = Image.open(background_image).convert("RGBA")
        elif isinstance(background_image, Image.Image):
            self._bg_image = background_image.convert("RGBA")
        else:
            self._bg_image = None

        # Default border: semi-transparent white
        if border_color is None:
            border_color = RGBAColor(255, 255, 255, 80)

        # Set clip: rounded corner + stroke border
        self._clip = RoundedCorner(
            radius=corner_radius,
            stroke_width=border_width,
            stroke_color=border_color,
        )

        if effects:
            self._effects.extend(effects)

    def _prepare_backdrop(self, w: int, h: int) -> Image.Image:
        """Cover-resize, center-crop, then blur the backdrop."""
        assert self._backdrop is not None
        src = self._backdrop
        src_w, src_h = src.size

        # Cover resize
        scale = max(w / src_w, h / src_h)
        new_w = max(1, int(src_w * scale))
        new_h = max(1, int(src_h * scale))
        resized = src.resize((new_w, new_h), Image.Resampling.LANCZOS)

        # Center crop
        left = (new_w - w) // 2
        top = (new_h - h) // 2
        cropped = resized.crop((left, top, left + w, top + h))

        # Blur
        return cropped.filter(ImageFilter.GaussianBlur(self.blur_radius))

    def _build_highlight(self, w: int, h: int) -> Image.Image:
        """Build a thin gradient highlight on the top and left edges (glass light reflection)."""
        # Top edge highlight
        edge_h = min(h // 4, self.highlight_width)
        top_hl = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        if edge_h > 0:
            draw_t = ImageDraw.Draw(top_hl)
            for y in range(edge_h):
                alpha = int(self.highlight_alpha * (1 - y / edge_h))
                draw_t.line([(0, y), (w - 1, y)], fill=(255, 255, 255, alpha))

        # Left edge highlight
        edge_w = min(w // 4, self.highlight_width)
        left_hl = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        if edge_w > 0:
            draw_l = ImageDraw.Draw(left_hl)
            for x in range(edge_w):
                alpha = int(self.highlight_alpha * (1 - x / edge_w))
                draw_l.line([(x, 0), (x, h - 1)], fill=(255, 255, 255, alpha))

        # Composite both highlights (alpha_composite for smooth overlap)
        return Image.alpha_composite(top_hl, left_hl)

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        pad = self.padding

        # Pre-calculate content area
        pre_w = self.width if self.width is not None else max_width
        pre_h = self.height if self.height is not None else max_height
        content_w = max(0, pre_w - pad.left - pad.right)
        content_h = max(0, pre_h - pad.top - pad.bottom)

        # Render child
        child_img = None
        if self.child:
            child_img = self.child.render(content_w, content_h)

        # Determine final size
        if self.width is not None:
            w = self.width
        elif child_img is not None and not self.fill_width:
            w = child_img.width + pad.left + pad.right
        else:
            w = max_width

        if self.height is not None:
            h = self.height
        elif child_img is not None and not self.fill_height:
            h = child_img.height + pad.top + pad.bottom
        else:
            h = max_height

        w = max(1, w)
        h = max(1, h)

        # === Build glass background ===

        # Layer 0: Background image (below glass layers, if present)
        if self._bg_image is not None:
            canvas = fit_background_image(self._bg_image, w, h, self.background_fit)
        else:
            canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))

        # Layer 1: Backdrop blur (if available, on top of background image)
        if self._backdrop is not None:
            backdrop_img = self._prepare_backdrop(w, h)
            canvas = Image.alpha_composite(canvas, backdrop_img)
        else:
            canvas = Image.new("RGBA", (w, h), (0, 0, 0, 0))

        # Layer 2: Tint overlay
        tint = Image.new("RGBA", (w, h), self.tint_color.to_tuple())
        canvas = Image.alpha_composite(canvas, tint)

        # Layer 3: Edge highlight (light reflection)
        if self.highlight_alpha > 0:
            highlight = self._build_highlight(w, h)
            canvas = Image.alpha_composite(canvas, highlight)

        # Apply background-only effects
        for effect in self.background_effects:
            canvas = effect.apply(canvas)

        # Paste child with alignment
        if child_img:
            avail_w = w - pad.left - pad.right
            avail_h = h - pad.top - pad.bottom
            ax, ay = _calculate_alignment(
                child_img.width, child_img.height, avail_w, avail_h, self.alignment
            )
            canvas.paste(child_img, (pad.left + ax, pad.top + ay), child_img)

        return canvas


# ─── ImageWidget ────────────────────────────────────────────────────────────


class ImageWidget(Widget):
    """Image widget — automatically resizes & crops to the available size.

    Sizing:
    - width/height set → fixed size.
    - Not set → uses parent constraints (max_width/max_height).

    Args:
        image: PIL Image or Path to a file.
        width: Fixed width (None = use parent constraint).
        height: Fixed height (None = use parent constraint).
        fit: Image fit mode (default COVER).
             COVER: preserves aspect ratio, center-crops (no empty areas).
             CONTAIN: preserves aspect ratio, entire image visible (may have empty areas).
             STRETCH: fills the entire area ignoring aspect ratio.
             REPEAT: tiles the original image.
             FIT_WIDTH: resizes to match width, proportional height.
             FIT_HEIGHT: resizes to match height, proportional width.
    """

    def __init__(
        self,
        image: Image.Image | Path,
        width: int | None = None,
        height: int | None = None,
        fit: BackgroundFit = BackgroundFit.COVER,
    ):
        super().__init__()
        if isinstance(image, Path):
            self._source = Image.open(image).convert("RGBA")
        else:
            self._source = image.convert("RGBA")
        self._width = width
        self._height = height
        self._fit = fit

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        target_w = self._width or max_width or self._source.width
        target_h = self._height or max_height or self._source.height

        target_w = max(1, target_w)
        target_h = max(1, target_h)

        return fit_background_image(self._source, target_w, target_h, self._fit)


# ─── LineWidget ─────────────────────────────────────────────────────────────


class LineWidget(Widget):
    """Line widget (horizontal/vertical/diagonal) — separators, decorations, etc.

    Supports solid colors, gradients, dash patterns, and cap styles.

    Args:
        length: Line length (pixels). None = fills parent space (max_width/max_height).
        thickness: Line thickness (pixels).
        color: Line color (solid or gradient). Default: white.
        direction: Line direction — "horizontal" or "vertical".
        dash: Dash pattern (dash_length, gap_length). None = solid line.
        cap: Cap style at line ends — "butt" (flat) or "round" (rounded).
        margin: Margin around the line (int, MarginAxis, or Margin).
    """

    def __init__(
        self,
        length: int | None = None,
        thickness: int = 2,
        color: RGBColor | RGBAColor | Background = RGBColor(255, 255, 255),
        direction: str = "horizontal",
        dash: tuple[int, int] | None = None,
        cap: str = "butt",
        margin: Margin | MarginAxis | int = 0,
    ):
        super().__init__()
        self.length = length
        self.thickness = thickness
        self.color = color
        self.direction = direction
        self.dash = dash
        self.cap = cap
        self.margin = _normalize_padding(margin)

    def _render(self, max_width: int, max_height: int) -> Image.Image:
        m = self.margin
        is_horizontal = self.direction == "horizontal"

        # Determine line length
        if self.length is not None:
            line_len = self.length
        elif is_horizontal:
            line_len = max(1, max_width - m.left - m.right)
        else:
            line_len = max(1, max_height - m.top - m.bottom)

        t = max(1, self.thickness)

        # Canvas size (including margin)
        if is_horizontal:
            canvas_w = line_len + m.left + m.right
            canvas_h = t + m.top + m.bottom
        else:
            canvas_w = t + m.left + m.right
            canvas_h = line_len + m.top + m.bottom

        canvas = Image.new("RGBA", (max(1, canvas_w), max(1, canvas_h)), (0, 0, 0, 0))

        # Render line color/gradient ke area garis
        if is_horizontal:
            line_w, line_h = line_len, t
        else:
            line_w, line_h = t, line_len

        line_img = render_background(max(1, line_w), max(1, line_h), self.color)

        # Apply dash pattern (cut gap areas to transparent)
        if self.dash is not None:
            dash_len, gap_len = self.dash
            cycle = dash_len + gap_len
            if cycle > 0:
                mask = Image.new("L", (line_w, line_h), 0)
                draw_m = ImageDraw.Draw(mask)
                pos = 0
                while pos < (line_len if is_horizontal else line_len):
                    end = min(pos + dash_len, line_len)
                    if is_horizontal:
                        draw_m.rectangle([pos, 0, end - 1, line_h - 1], fill=255)
                    else:
                        draw_m.rectangle([0, pos, line_w - 1, end - 1], fill=255)
                    pos += cycle
                # Multiply mask with alpha
                existing_alpha = line_img.getchannel("A")
                from PIL import ImageChops

                combined = ImageChops.multiply(existing_alpha, mask)
                line_img.putalpha(combined)

        # Apply round cap
        if self.cap == "round" and t > 1:
            cap_mask = Image.new("L", (line_w, line_h), 255)
            draw_cap = ImageDraw.Draw(cap_mask)
            r = t // 2
            if is_horizontal:
                # Left cap
                draw_cap.rectangle([0, 0, r - 1, line_h - 1], fill=0)
                draw_cap.ellipse([0, 0, t - 1, t - 1], fill=255)
                # Right cap
                draw_cap.rectangle([line_w - r, 0, line_w - 1, line_h - 1], fill=0)
                draw_cap.ellipse([line_w - t, 0, line_w - 1, t - 1], fill=255)
            else:
                # Top cap
                draw_cap.rectangle([0, 0, line_w - 1, r - 1], fill=0)
                draw_cap.ellipse([0, 0, t - 1, t - 1], fill=255)
                # Bottom cap
                draw_cap.rectangle([0, line_h - r, line_w - 1, line_h - 1], fill=0)
                draw_cap.ellipse([0, line_h - t, t - 1, line_h - 1], fill=255)
            from PIL import ImageChops

            existing_alpha = line_img.getchannel("A")
            combined = ImageChops.multiply(existing_alpha, cap_mask)
            line_img.putalpha(combined)

        canvas.paste(line_img, (m.left, m.top), line_img)
        return canvas
