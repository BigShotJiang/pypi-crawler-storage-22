from __future__ import annotations

import math
from typing import TypeVar, List, Tuple
from PIL import Image, ImageDraw, ImageChops, ImageFont
from .config import (
    BackgroundFit,
    GradientColor,
    LinearGradient,
    RadialGradient,
    RGBAColor,
    RGBColor,
    Size,
    StrokeColor,
)


def boost_alpha(
    image: Image.Image,
    factor: float = 3.0,
    threshold: int = 0,
) -> Image.Image:
    """Boost the alpha channel of an RGBA image.

    Multiplies alpha values by *factor* (clamped to 255) for pixels whose
    alpha is above *threshold*.  Useful for making semi-transparent chart
    images more visible on dark backgrounds without losing fully
    transparent regions.

    Args:
        image: Source image (will be converted to RGBA).
        factor: Multiplier applied to each alpha value (default ``3.0``).
        threshold: Only boost pixels whose alpha exceeds this value
            (default ``0`` — every non-fully-transparent pixel).

    Returns:
        A new RGBA image with the boosted alpha channel.
    """
    img = image.convert("RGBA")
    alpha = img.getchannel("A")
    alpha = alpha.point(lambda a: min(255, int(a * factor)) if a > threshold else 0)
    img.putalpha(alpha)
    return img


def _stroke_color_to_image(w: int, h: int, color: StrokeColor) -> Image.Image:
    """Render a StrokeColor (solid or gradient) to an RGBA image."""
    if isinstance(color, RGBAColor):
        return Image.new("RGBA", (w, h), color.to_tuple())
    elif isinstance(color, RGBColor):
        return Image.new("RGBA", (w, h), (*color.to_tuple(), 255))
    elif isinstance(color, LinearGradient):
        return render_linear_gradient(w, h, color)
    elif isinstance(color, RadialGradient):
        return render_radial_gradient(w, h, color)
    return Image.new("RGBA", (w, h), (255, 255, 255, 255))


def fit_background_image(
    source: Image.Image,
    target_w: int,
    target_h: int,
    fit: BackgroundFit = BackgroundFit.COVER,
) -> Image.Image:
    """Resize/fit an image to the target size according to the specified mode.

    Args:
        source: Source image.
        target_w: Target width.
        target_h: Target height.
        fit: Fit mode (COVER, CONTAIN, STRETCH, REPEAT, FIT_WIDTH, FIT_HEIGHT).

    Returns:
        RGBA image with dimensions (target_w, target_h).
    """
    src = source.convert("RGBA")
    src_w, src_h = src.size
    canvas = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 0))

    if fit == BackgroundFit.COVER:
        scale = max(target_w / src_w, target_h / src_h)
        new_w = max(1, int(src_w * scale))
        new_h = max(1, int(src_h * scale))
        resized = src.resize((new_w, new_h), Image.Resampling.LANCZOS)
        left = (new_w - target_w) // 2
        top = (new_h - target_h) // 2
        cropped = resized.crop((left, top, left + target_w, top + target_h))
        canvas.paste(cropped, (0, 0), cropped)

    elif fit == BackgroundFit.CONTAIN:
        scale = min(target_w / src_w, target_h / src_h)
        new_w = max(1, int(src_w * scale))
        new_h = max(1, int(src_h * scale))
        resized = src.resize((new_w, new_h), Image.Resampling.LANCZOS)
        x = (target_w - new_w) // 2
        y = (target_h - new_h) // 2
        canvas.paste(resized, (x, y), resized)

    elif fit == BackgroundFit.STRETCH:
        resized = src.resize((target_w, target_h), Image.Resampling.LANCZOS)
        canvas.paste(resized, (0, 0), resized)

    elif fit == BackgroundFit.REPEAT:
        for y in range(0, target_h, src_h):
            for x in range(0, target_w, src_w):
                canvas.paste(src, (x, y), src)

    elif fit == BackgroundFit.FIT_WIDTH:
        scale = target_w / src_w
        new_w = target_w
        new_h = max(1, int(src_h * scale))
        resized = src.resize((new_w, new_h), Image.Resampling.LANCZOS)
        if new_h >= target_h:
            top = (new_h - target_h) // 2
            cropped = resized.crop((0, top, target_w, top + target_h))
            canvas.paste(cropped, (0, 0), cropped)
        else:
            y = (target_h - new_h) // 2
            canvas.paste(resized, (0, y), resized)

    elif fit == BackgroundFit.FIT_HEIGHT:
        scale = target_h / src_h
        new_w = max(1, int(src_w * scale))
        new_h = target_h
        resized = src.resize((new_w, new_h), Image.Resampling.LANCZOS)
        if new_w >= target_w:
            left = (new_w - target_w) // 2
            cropped = resized.crop((left, 0, left + target_w, target_h))
            canvas.paste(cropped, (0, 0), cropped)
        else:
            x = (target_w - new_w) // 2
            canvas.paste(resized, (x, 0), resized)

    return canvas


def draw_rounded_rect_stroke(
    image: Image.Image,
    radius: int,
    stroke_width: int,
    stroke_color: StrokeColor,
) -> Image.Image:
    """Draw a stroke along the edge of a rounded rectangle on top of the image.

    The stroke is drawn on the inside (inset) of the clip shape.
    Supports solid colors (RGBColor/RGBAColor) and gradients (LinearGradient/RadialGradient).
    """
    im = image.convert("RGBA")
    w, h = im.size

    # Outer mask: full rounded rect
    outer = Image.new("L", (w, h), 0)
    draw_o = ImageDraw.Draw(outer)
    draw_o.rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255)

    # Inner mask: inset by stroke_width
    inner = Image.new("L", (w, h), 0)
    draw_i = ImageDraw.Draw(inner)
    sw = stroke_width
    inner_radius = max(0, radius - sw)
    draw_i.rounded_rectangle(
        [sw, sw, w - 1 - sw, h - 1 - sw], radius=inner_radius, fill=255
    )

    # Stroke mask = outer - inner
    stroke_mask = ImageChops.subtract(outer, inner)

    # Render color/gradient
    color_layer = _stroke_color_to_image(w, h, stroke_color)

    # Apply stroke mask to color layer
    color_alpha = color_layer.getchannel("A")
    combined = ImageChops.multiply(color_alpha, stroke_mask)
    color_layer.putalpha(combined)

    return Image.alpha_composite(im, color_layer)


def draw_circle_stroke(
    image: Image.Image,
    stroke_width: int,
    stroke_color: StrokeColor,
) -> Image.Image:
    """Draw a stroke along the edge of a circle on top of the image.

    The stroke is drawn on the inside (inset) of the clip shape.
    Supports solid colors (RGBColor/RGBAColor) and gradients (LinearGradient/RadialGradient).
    """
    im = image.convert("RGBA")
    w, h = im.size
    diameter = min(w, h)
    cx, cy = w // 2, h // 2
    r = diameter // 2

    # Outer mask: full circle
    outer = Image.new("L", (w, h), 0)
    draw_o = ImageDraw.Draw(outer)
    draw_o.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)

    # Inner mask: inset by stroke_width
    inner = Image.new("L", (w, h), 0)
    draw_i = ImageDraw.Draw(inner)
    ri = r - stroke_width
    if ri > 0:
        draw_i.ellipse((cx - ri, cy - ri, cx + ri, cy + ri), fill=255)

    # Stroke mask = outer - inner
    stroke_mask = ImageChops.subtract(outer, inner)

    # Render color/gradient
    color_layer = _stroke_color_to_image(w, h, stroke_color)

    # Apply stroke mask to color layer
    color_alpha = color_layer.getchannel("A")
    combined = ImageChops.multiply(color_alpha, stroke_mask)
    color_layer.putalpha(combined)

    return Image.alpha_composite(im, color_layer)


def _lerp_color(
    start: RGBColor | RGBAColor, end: RGBColor | RGBAColor, t: float
) -> tuple[int, int, int, int]:
    """Linearly interpolate between two colors."""
    sr, sg, sb = start.r, start.g, start.b
    sa = start.a if isinstance(start, RGBAColor) else 255
    er, eg, eb = end.r, end.g, end.b
    ea = end.a if isinstance(end, RGBAColor) else 255
    return (
        int(sr + (er - sr) * t),
        int(sg + (eg - sg) * t),
        int(sb + (eb - sb) * t),
        int(sa + (ea - sa) * t),
    )


def circle_clip(image: Image.Image) -> Image.Image:
    """Clip an image into a circle (diameter = shortest side)."""
    im = image.convert("RGBA")
    w, h = im.size
    diameter = min(w, h)
    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    cx, cy = w // 2, h // 2
    r = diameter // 2
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
    existing_alpha = im.getchannel("A")
    combined = ImageChops.multiply(existing_alpha, mask)
    im.putalpha(combined)
    return im


def render_linear_gradient(w: int, h: int, gradient: LinearGradient) -> Image.Image:
    """Render a linear gradient with an arbitrary angle."""
    img = Image.new("RGBA", (w, h))
    draw = ImageDraw.Draw(img)
    start = gradient.start_color
    end = gradient.end_color
    angle = gradient.angle % 360

    # Fast path for common angles (line-by-line)
    if angle == 0:  # top to bottom
        for y in range(h):
            t = y / max(h - 1, 1)
            draw.line([(0, y), (w, y)], fill=_lerp_color(start, end, t))
    elif angle == 90:  # left to right
        for x in range(w):
            t = x / max(w - 1, 1)
            draw.line([(x, 0), (x, h)], fill=_lerp_color(start, end, t))
    elif angle == 180:  # bottom to top
        for y in range(h):
            t = 1 - y / max(h - 1, 1)
            draw.line([(0, y), (w, y)], fill=_lerp_color(start, end, t))
    elif angle == 270:  # right to left
        for x in range(w):
            t = 1 - x / max(w - 1, 1)
            draw.line([(x, 0), (x, h)], fill=_lerp_color(start, end, t))
    else:
        # General case: projection onto gradient direction
        angle_rad = math.radians(angle)
        dx = math.sin(angle_rad)
        dy = math.cos(angle_rad)
        corners = [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]
        projections = [cx * dx + cy * dy for cx, cy in corners]
        min_p = min(projections)
        max_p = max(projections)
        p_range = max_p - min_p if max_p > min_p else 1
        pixels = img.load()
        if pixels is not None:
            for y in range(h):
                for x in range(w):
                    proj = x * dx + y * dy
                    t = max(0.0, min(1.0, (proj - min_p) / p_range))
                    pixels[x, y] = _lerp_color(start, end, t)
    return img


def render_radial_gradient(w: int, h: int, gradient: RadialGradient) -> Image.Image:
    """Render a radial (circular) gradient from center to edge."""
    img = Image.new("RGBA", (w, h))
    pixels = img.load()
    if pixels is None:
        return img
    cx, cy = w / 2, h / 2
    max_dist = math.sqrt(cx * cx + cy * cy)
    inner = gradient.inner_color
    outer = gradient.outer_color
    for y in range(h):
        for x in range(w):
            dist = math.sqrt((x - cx) ** 2 + (y - cy) ** 2)
            t = min(1.0, dist / max_dist) if max_dist > 0 else 0
            pixels[x, y] = _lerp_color(inner, outer, t)
    return img


def render_background(w: int, h: int, bg: object) -> Image.Image:
    """Render a background from various color/gradient types."""
    if isinstance(bg, RGBAColor):
        return Image.new("RGBA", (w, h), bg.to_tuple())
    elif isinstance(bg, RGBColor):
        return Image.new("RGBA", (w, h), (*bg.to_tuple(), 255))
    elif isinstance(bg, GradientColor):
        return rectangle_gradient(Size(w, h), bg)
    elif isinstance(bg, LinearGradient):
        return render_linear_gradient(w, h, bg)
    elif isinstance(bg, RadialGradient):
        return render_radial_gradient(w, h, bg)
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))


def border_radius(image: Image.Image, radius: int = 20) -> Image.Image:
    im = image.convert("RGBA")
    circle = Image.new("L", (radius * 2, radius * 2), 0)
    draw = ImageDraw.Draw(circle)
    draw.ellipse((0, 0, radius * 2, radius * 2), fill=255)
    mask = Image.new("L", im.size, 255)
    w, h = im.size
    mask.paste(circle.crop((0, 0, radius, radius)), (0, 0))
    mask.paste(circle.crop((0, radius, radius, radius * 2)), (0, h - radius))
    mask.paste(circle.crop((radius, 0, radius * 2, radius)), (w - radius, 0))
    mask.paste(
        circle.crop((radius, radius, radius * 2, radius * 2)), (w - radius, h - radius)
    )
    # Multiply mask with original alpha channel to preserve transparency
    existing_alpha = im.getchannel("A")
    combined_alpha = ImageChops.multiply(existing_alpha, mask)
    im.putalpha(combined_alpha)
    return im


# def paste_with_align_or_coordinate()

TColor = TypeVar("TColor", bound=RGBAColor | RGBColor)


def rectangle_gradient(
    size: Size,
    color: GradientColor,
    is_vertical: bool = True,
) -> Image.Image:
    width, height = size.width, size.height
    gradient = Image.new("RGB", (width, height), color=0)
    draw = ImageDraw.Draw(gradient)

    if is_vertical:
        for y in range(height):
            ratio = y / height
            r = int(color.start_color.r * (1 - ratio) + color.end_color.r * ratio)
            g = int(color.start_color.g * (1 - ratio) + color.end_color.g * ratio)
            b = int(color.start_color.b * (1 - ratio) + color.end_color.b * ratio)
            draw.line([(0, y), (width, y)], fill=(r, g, b))
    else:
        for x in range(width):
            ratio = x / width
            r = int(color.start_color.r * (1 - ratio) + color.end_color.r * ratio)
            g = int(color.start_color.g * (1 - ratio) + color.end_color.g * ratio)
            b = int(color.start_color.b * (1 - ratio) + color.end_color.b * ratio)
            draw.line([(x, 0), (x, height)], fill=(r, g, b))

    return gradient.convert("RGBA")


def wrap_text(
    text: str,
    font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
    max_width: int,
) -> List[List[str]]:
    """Wrap text into lines based on max_width.

    Supports newlines (\\n) as paragraph separators.
    The last word before a newline is tagged with a '\\x00' marker so that
    ``draw_justified_text`` knows that line is a paragraph end
    (left-aligned, not justified).

    Returns:
        List of lines, where each line is a list of words.
    """
    paragraphs = text.split("\n")
    lines: List[List[str]] = []
    dummy = Image.new("RGBA", (1, 1))
    draw = ImageDraw.Draw(dummy)

    for p_idx, paragraph in enumerate(paragraphs):
        words = paragraph.split()
        if not words:
            # Empty line: store as an empty line
            lines.append([])
            continue

        current_line: List[str] = []
        for word in words:
            test_line = " ".join(current_line + [word])
            bbox = draw.textbbox((0, 0), test_line, font=font)
            line_width = bbox[2] - bbox[0]
            if line_width <= max_width or not current_line:
                current_line.append(word)
            else:
                lines.append(current_line)
                current_line = [word]

        if current_line:
            # Tag the last word of the paragraph with \x00 marker
            # so draw_justified_text knows this is a paragraph end (left-aligned)
            current_line[-1] = current_line[-1] + "\x00"
            lines.append(current_line)

    return lines


def draw_justified_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.ImageFont | ImageFont.FreeTypeFont,
    max_width: int,
    position: Tuple[int, int] = (0, 0),
    fill: Tuple[int, ...] = (255, 255, 255),
    line_spacing: int = 10,
) -> int:
    """Draw fully justified (left-right aligned) text with automatic word wrapping.

    Args:
        draw: ImageDraw instance.
        text: The text to draw.
        font: Font to use.
        max_width: Maximum width of the text area.
        position: Starting (x, y) position.
        fill: Text color.
        line_spacing: Spacing between lines (pixels).

    Returns:
        Total height of the drawn text.
    """
    lines = wrap_text(text, font, max_width)
    x_start, y = position
    dummy = Image.new("RGBA", (1, 1))
    dummy_draw = ImageDraw.Draw(dummy)

    # Calculate standard line height from reference characters (not spaces,
    # since textbbox(" ") can return height=0)
    _ref_bbox = dummy_draw.textbbox((0, 0), "Ay", font=font)
    _ref_line_height = _ref_bbox[3] - _ref_bbox[1]

    total_height = 0

    for i, words in enumerate(lines):
        is_last_line = i == len(lines) - 1

        if not words:
            # Empty line (from \n\n): add one full line height
            y += _ref_line_height + line_spacing
            total_height += _ref_line_height + line_spacing
            continue

        # Check if this line is a paragraph end (has \x00 marker)
        is_paragraph_end = words[-1].endswith("\x00")
        if is_paragraph_end:
            words = words[:]
            words[-1] = words[-1][:-1]  # Remove marker

        if is_last_line or is_paragraph_end or len(words) == 1:
            # Last line or single word: left-align only
            line_text = " ".join(words)
            draw.text((x_start, y), line_text, font=font, fill=fill)
            bbox = dummy_draw.textbbox((0, 0), line_text, font=font)
            line_height = bbox[3] - bbox[1]
        else:
            # Calculate total word width without spaces
            word_widths: List[int] = []
            for word in words:
                bbox = dummy_draw.textbbox((0, 0), word, font=font)
                word_widths.append(bbox[2] - bbox[0])

            total_words_width = sum(word_widths)
            total_space = max_width - total_words_width
            gap_count = len(words) - 1
            base_gap = total_space / gap_count if gap_count > 0 else 0

            # Draw each word with evenly distributed spacing
            cx: float = x_start
            line_height = 0
            for j, word in enumerate(words):
                draw.text((cx, y), word, font=font, fill=fill)
                bbox = dummy_draw.textbbox((0, 0), word, font=font)
                w_height = bbox[3] - bbox[1]
                if w_height > line_height:
                    line_height = w_height
                cx += word_widths[j] + base_gap

        y += line_height + line_spacing
        total_height += line_height + line_spacing

    return int(total_height)
