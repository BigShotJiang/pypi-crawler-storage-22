from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Tuple, Type
from .layout import Widget
from .exceptions import MissingExtraError, EmptyDocumentError
from PIL import Image
from io import BytesIO
from datetime import datetime

try:
    import pikepdf  # noqa: F401

    _HAS_PIKEPDF = True
except ImportError:
    _HAS_PIKEPDF = False

try:
    import pptx  # noqa: F401

    _HAS_PPTX = True
except ImportError:
    _HAS_PPTX = False


def preview(cls: Type[Page]) -> Type[Page]:
    """Class decorator to mark a Page as a preview (not included in final output)."""
    cls.preview = True
    return cls



def _require_pikepdf() -> None:
    """Raise :class:`~lumora.exceptions.MissingExtraError` if pikepdf is not installed."""
    if not _HAS_PIKEPDF:
        raise MissingExtraError("pikepdf")

def _require_pptx() -> None:
    """Raise :class:`~lumora.exceptions.MissingExtraError` if python-pptx is not installed."""
    if not _HAS_PPTX:
        raise MissingExtraError("python-pptx")

@dataclass
class DocumentMetadata:
    """Document metadata — used for both PDF and PPTX.

    For **PDF**: requires the ``pikepdf`` extra::

        pip install lumora[pikepdf]

    For **PPTX**: metadata is written to the PPTX core properties
    automatically (no extra dependencies beyond ``python-pptx``).

    Raises:
        MissingExtraError: If the required extra is not installed when
            :meth:`Document.save` is called with metadata.
    """

    title: str = ""
    author: str = ""
    subject: str = ""
    keywords: str = ""
    creator: str = ""
    producer: str = ""


class Page(ABC):
    """Base class for report pages.

    Subclasses only need to implement ``build()`` which returns a widget tree.
    Sizing, rendering, and scaling are handled automatically.

    Class attributes:
        design_width: Virtual design width (pixels). Default 2520.
        design_height: Virtual design height (pixels). Default 1780.

    All dimensions (font_size, padding, spacing, etc.) are defined relative
    to the design resolution. When rendered to a different resolution, the
    entire page is proportionally scaled using LANCZOS — no pixelation.

    Example::

        class MyPage(Page):
            design_width = 2520
            design_height = 1780

            def build(self) -> Widget:
                return Container(
                    width=self.design_width,
                    height=self.design_height,
                    background=RGBColor(0, 0, 0),
                    child=TextWidget("Hello", style=HEADER_STYLE),
                )

        page = MyPage()
        img = page.render()                     # 2520×1780 (design size)
        img = page.render(scale=2.0)            # 5040×3560 (2x)
        img = page.render(width=1260)           # 1260×890  (0.5x, aspect ratio preserved)
        img = page.render(width=1920, height=1080)  # 1920×1080 (custom)
    """
    preview: bool = False  # If True, this page is a preview and should not be included in final output.
    design_width: int = 2520
    design_height: int = 1780

    @abstractmethod
    def build(self) -> Widget:
        """Build the widget tree for this page.

        Use ``self.design_width`` and ``self.design_height`` as the
        root Container size so it scales proportionally.
        """
        ...

    @property
    def design_size(self) -> Tuple[int, int]:
        """(width, height) design resolution."""
        return (self.design_width, self.design_height)

    @property
    def aspect_ratio(self) -> float:
        """Aspect ratio (width / height)."""
        return self.design_width / self.design_height

    def render(
        self,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> Image.Image:
        """Render the page to an Image.

        Always renders the widget tree at design resolution first,
        then scales the final result to the target resolution.

        Args:
            width: Target width (pixels). If only width is given, height
                   is calculated from the aspect ratio.
            height: Target height (pixels). If only height is given, width
                    is calculated from the aspect ratio.
            scale: Scale factor (default 1.0). Ignored if width/height
                   are explicitly set.

        Returns:
            PIL RGBA Image at the target resolution.
        """
        # 1. Build & render at design resolution
        widget = self.build()
        design_img = widget.render(self.design_width, self.design_height)

        # 2. Calculate target size
        target_w, target_h = self._resolve_target_size(width, height, scale)

        # 3. Scale if needed
        if (target_w, target_h) != design_img.size:
            return design_img.resize((target_w, target_h), Image.Resampling.LANCZOS)
        return design_img

    def _resolve_target_size(
        self,
        width: int | None,
        height: int | None,
        scale: float,
    ) -> Tuple[int, int]:
        """Calculate target (width, height) from parameters."""
        if width is not None and height is not None:
            return (max(1, width), max(1, height))
        if width is not None:
            # Height from aspect ratio
            h = max(1, int(width / self.aspect_ratio))
            return (max(1, width), h)
        if height is not None:
            # Width from aspect ratio
            w = max(1, int(height * self.aspect_ratio))
            return (w, max(1, height))
        # Scale from design resolution
        return (
            max(1, int(self.design_width * scale)),
            max(1, int(self.design_height * scale)),
        )

    def save(
        self,
        out: str | BytesIO,
        format: str = "PNG",
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> None:
        """Render & save the page to a file or buffer.

        Args are the same as ``render()``.
        """
        self.render(width=width, height=height, scale=scale).save(out, format=format)


class Format(Enum):
    """Document output format."""

    PDF = "pdf"
    PPTX = "pptx"


class Document:
    """Multi-page document — renders to PDF or PPTX.

    Supports two output formats via the :class:`Format` enum:

    - ``Format.PDF``  — multi-page PDF (default). Metadata via ``pikepdf``.
    - ``Format.PPTX`` — PowerPoint. Requires ``python-pptx``.
      Slide dimensions automatically match the image aspect ratio.

    Example::

        doc = Document()
        doc.add_page(cover_page)
        doc.add_page(content_page)

        # PDF
        doc.save("report.pdf")
        doc.save("report.pdf", Format.PDF, metadata, scale=0.5)

        # PPTX
        doc.save("slides.pptx", Format.PPTX)
        doc.save("slides.pptx", Format.PPTX, metadata, width=1920)
    """

    def __init__(self) -> None:
        self.pages: list[Page] = []

    def add_page(self, page: Page) -> None:
        self.pages.append(page)

    def render_all(
        self,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> list[Image.Image]:
        """Render all pages to a list of Images."""
        return [
            page.render(width=width, height=height, scale=scale) for page in self.pages
        ]
    def save(
        self,
        out: str | BytesIO,
        format: Format = Format.PDF,
        metadata: DocumentMetadata | None = None,
        *,
        width: int | None = None,
        height: int | None = None,
        scale: float = 1.0,
    ) -> None:
        """Render all pages and save as PDF or PPTX.

        **PDF** (``Format.PDF``, default):

        - Without *metadata*: saved directly via Pillow (no extras).
        - With *metadata*: ``pikepdf`` is used to inject document metadata.
          Requires ``pip install lumora[pikepdf]``.

        **PPTX** (``Format.PPTX``):

        - Requires ``pip install python-pptx``.
        - Slide dimensions are automatically set to match the rendered
          image aspect ratio — images are never stretched or cropped.
        - If *metadata* is provided, it is written to the PPTX core
          properties (title, author, subject, keywords, …).

        Args:
            out: File path or BytesIO buffer.
            format: Output format — ``Format.PDF`` or ``Format.PPTX``.
            metadata: Document metadata (title, author, etc.).
            width: Target width per page (pixels).
            height: Target height per page (pixels).
            scale: Scale factor (default 1.0).

        Raises:
            EmptyDocumentError: If the document has no pages.
            MissingExtraError: If a required extra (``pikepdf`` or
                ``python-pptx``) is not installed.

        Example::

            doc = Document()
            doc.add_page(my_page)

            # Plain PDF
            doc.save("report.pdf")

            # PDF with metadata
            doc.save("report.pdf", Format.PDF, metadata)

            # PPTX
            doc.save("slides.pptx", Format.PPTX)

            # PPTX at 50 % resolution with metadata
            doc.save("slides.pptx", Format.PPTX, metadata, scale=0.5)
        """
        if not self.pages:
            raise EmptyDocumentError()

        images = self.render_all(width=width, height=height, scale=scale)

        if format == Format.PDF and metadata is not None:
            _require_pikepdf()
            import pikepdf
            image_rgb = [img.convert("RGB") for img in images]
            buffer = BytesIO()
            image_rgb[0].save(
                buffer,
                format="PDF",
                save_all=True,
                append_images=image_rgb[1:],
                resolution=100.0,
                quality=95,
            )

            with pikepdf.open(buffer) as pdf:
                pdf.docinfo["/Title"] = metadata.title
                pdf.docinfo["/Author"] = metadata.author
                pdf.docinfo["/Subject"] = metadata.subject
                pdf.docinfo["/Keywords"] = metadata.keywords
                pdf.docinfo["/Creator"] = metadata.creator
                pdf.docinfo["/Producer"] = metadata.producer

                now = datetime.now().strftime("D:%Y%m%d%H%M%S")
                pdf.docinfo["/CreationDate"] = now
                pdf.docinfo["/ModDate"] = now
                pdf.save(out)
        elif format == Format.PPTX:
            _require_pptx()
            from pptx import Presentation
            from pptx.util import Emu
            prs = Presentation()
            blank_slide_layout = prs.slide_layouts[6]  # Blank layout

            # Set slide dimensions to match the first image's aspect ratio.
            # We use a base height of 7.5 inches (6858000 EMU) and derive
            # the width from the image aspect ratio so nothing is stretched
            # or cropped.
            first_img = images[0]
            img_aspect = first_img.width / first_img.height
            slide_h = Emu(6858000)  # 7.5 inches in EMU
            slide_w = Emu(int(6858000 * img_aspect))
            prs.slide_width = slide_w
            prs.slide_height = slide_h

            for img in images:
                slide = prs.slides.add_slide(blank_slide_layout)
                image = BytesIO()
                img.save(image, format="PNG")
                image.seek(0)
                slide.shapes.add_picture(image, Emu(0), Emu(0), width=slide_w, height=slide_h)
            properties = prs.core_properties
            if metadata:
                properties.title = metadata.title
                properties.author = metadata.author
                properties.subject = metadata.subject
                properties.keywords = metadata.keywords
                properties.last_modified_by = metadata.producer
                properties.created = datetime.now()
                properties.modified = datetime.now()
                properties.category = "Generated with Lumora"
                properties.comments = "Created using Lumora and python-pptx"
                properties.revision = 1
                properties.version = "1.0"
            if isinstance(out, BytesIO):
                prs.save(out)
            else:
                prs.save(out)
        else:
            # Save as plain PDF without metadata (no pikepdf needed)
            images[0].save(
                out,
                format="PDF",
                save_all=True,
                append_images=images[1:],
                resolution=100.0,
                quality=95,
            )

