# Lumyn SDK for Python

Official Python SDK for Lumyn Labs ConnectorX devices.

## Installation

### Recommended: Install with uv

[uv](https://docs.astral.sh/uv/) is a fast Python package installer and virtual environment manager. This is the recommended installation method, especially on ARM platforms like Raspberry Pi.

#### Linux/macOS

```bash
# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install Python 3.11+
uv python install 3.11

# Create virtual environment
uv venv --python 3.11 ~/venvs/lumyn311
source ~/venvs/lumyn311/bin/activate

# Install pip and the SDK
python -m ensurepip --upgrade
python -m pip install -U pip
python -m pip install --only-binary=:all: lumyn-sdk
```

#### Windows

```powershell
# Install uv
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# Install Python 3.11+
uv python install 3.11

# Create virtual environment and install the SDK
uv venv --python 3.11 $env:USERPROFILE/venvs/lumyn311
& "$env:USERPROFILE/venvs/lumyn311/Scripts/Activate.ps1"
uv pip install lumyn-sdk
```

> **Note:** Pre-built wheels are available for Python 3.10, 3.11, and 3.12 on Windows x86-64. If you see "No matching distribution found", ensure you're using a supported Python version (`python --version`) and that you're on a 64-bit system.

## Quick Start

```python
from lumyn_sdk import ConnectorX

# Connect to device
cx = ConnectorX()
cx.connect_usb("COM3")  # Windows
# cx.connect_usb("/dev/ttyACM0")  # Linux/Mac

# Control LEDs
cx.leds.set_color("zone1", (255, 0, 0))  # Red
cx.leds.set_animation("zone1", "Breathe", (0, 255, 0), 30)  # Green breathing
```

## Documentation

For complete documentation, tutorials, API reference, and examples, visit:

[**https://docs.lumynlabs.com**](https://docs.lumynlabs.com)

## Support

- **Documentation**: <https://docs.lumynlabs.com>
- **Examples**: <https://github.com/Lumyn-Labs/Examples>
- **Issues & Questions**: Contact Lumyn Labs support

## License

Copyright © 2026 Lumyn Labs. All rights reserved.
