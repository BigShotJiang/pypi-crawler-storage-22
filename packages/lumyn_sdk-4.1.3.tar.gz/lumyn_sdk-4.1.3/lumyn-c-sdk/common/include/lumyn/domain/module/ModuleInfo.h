#pragma once

#include <stdint.h>

#include "lumyn/types/config.h"

namespace lumyn::internal::ModuleInfo {

enum class ModuleConnectionType : int
{
  I2C = LUMYN_MODULE_CONNECTION_I2C,
  SPI = LUMYN_MODULE_CONNECTION_SPI,
  UART = LUMYN_MODULE_CONNECTION_UART,
  DIO = LUMYN_MODULE_CONNECTION_DIO,
  AIO = LUMYN_MODULE_CONNECTION_AIO,
};

inline constexpr lumyn_module_connection_type_t ConvertToC(ModuleConnectionType type)
{
  return static_cast<lumyn_module_connection_type_t>(type);
}

inline constexpr ModuleConnectionType ConvertFromC(lumyn_module_connection_type_t type)
{
  return static_cast<ModuleConnectionType>(type);
}

}  // namespace lumyn::internal::ModuleInfo
