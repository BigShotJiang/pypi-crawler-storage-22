#pragma once

#include <map>
#include <string_view>

#include "lumyn/types/animation.h"

namespace lumyn::led
{
  // Animation enum class is defined in lumyn/types/animation.h
  // Provides Animation::Chase style syntax for C++ users
  
  // String lookup map for animation names
  const std::map<Animation, std::string_view> kAnimationMap =
      {
          {Animation::Fill, "Fill"},
          {Animation::Blink, "Blink"},
          {Animation::Breathe, "Breathe"},
          {Animation::RainbowRoll, "RainbowRoll"},
          {Animation::SineRoll, "SineRoll"},
          {Animation::Chase, "Chase"},
          {Animation::FadeIn, "FadeIn"},
          {Animation::FadeOut, "FadeOut"},
          {Animation::RainbowCycle, "RainbowCycle"},
          {Animation::AlternateBreathe, "AlternateBreathe"},
          {Animation::GrowingBreathe, "GrowingBreathe"},
          {Animation::Comet, "Comet"},
          {Animation::Sparkle, "Sparkle"},
          {Animation::Fire, "Fire"},
          {Animation::Scanner, "Scanner"},
          {Animation::TheaterChase, "TheaterChase"},
          {Animation::Twinkle, "Twinkle"},
          {Animation::Meteor, "Meteor"},
          {Animation::Wave, "Wave"},
          {Animation::Pulse, "Pulse"},
          {Animation::Larson, "Larson"},
          {Animation::Ripple, "Ripple"},
          {Animation::Confetti, "Confetti"},
          {Animation::Lava, "Lava"},
          {Animation::Plasma, "Plasma"},
          {Animation::Heartbeat, "Heartbeat"},
  };
} // namespace lumyn::led
