/**
 * @file animation.h
 * @brief C-compatible animation type definitions
 * 
 * This header defines animation types that work in both C and C++.
 * C++ code can use the lumyn::led namespace aliases for convenience.
 */
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Animation types for LED strips and matrices
 */
typedef enum lumyn_animation {
  LUMYN_ANIMATION_NONE = 0,
  LUMYN_ANIMATION_FILL = 1,
  LUMYN_ANIMATION_BLINK = 2,
  LUMYN_ANIMATION_BREATHE = 3,
  LUMYN_ANIMATION_RAINBOW_ROLL = 4,
  LUMYN_ANIMATION_SINE_ROLL = 5,
  LUMYN_ANIMATION_CHASE = 6,
  LUMYN_ANIMATION_FADE_IN = 7,
  LUMYN_ANIMATION_FADE_OUT = 8,
  LUMYN_ANIMATION_RAINBOW_CYCLE = 9,
  LUMYN_ANIMATION_ALTERNATE_BREATHE = 10,
  LUMYN_ANIMATION_GROWING_BREATHE = 11,
  LUMYN_ANIMATION_COMET = 12,
  LUMYN_ANIMATION_SPARKLE = 13,
  LUMYN_ANIMATION_FIRE = 14,
  LUMYN_ANIMATION_SCANNER = 15,
  LUMYN_ANIMATION_THEATER_CHASE = 16,
  LUMYN_ANIMATION_TWINKLE = 17,
  LUMYN_ANIMATION_METEOR = 18,
  LUMYN_ANIMATION_WAVE = 19,
  LUMYN_ANIMATION_PULSE = 20,
  LUMYN_ANIMATION_LARSON = 21,
  LUMYN_ANIMATION_RIPPLE = 22,
  LUMYN_ANIMATION_CONFETTI = 23,
  LUMYN_ANIMATION_LAVA = 24,
  LUMYN_ANIMATION_PLASMA = 25,
  LUMYN_ANIMATION_HEARTBEAT = 26,
} lumyn_animation_t;

#ifdef __cplusplus
} // extern "C"

// C++ scoped enum with C interoperability
namespace lumyn::led {

/**
 * @brief C++ enum class for animations
 * 
 * Provides type-safe Animation::Chase syntax for C++ code.
 * Use to_c_animation() when calling C API functions.
 */
enum class Animation : uint16_t {
  None = LUMYN_ANIMATION_NONE,
  Fill = LUMYN_ANIMATION_FILL,
  Blink = LUMYN_ANIMATION_BLINK,
  Breathe = LUMYN_ANIMATION_BREATHE,
  RainbowRoll = LUMYN_ANIMATION_RAINBOW_ROLL,
  SineRoll = LUMYN_ANIMATION_SINE_ROLL,
  Chase = LUMYN_ANIMATION_CHASE,
  FadeIn = LUMYN_ANIMATION_FADE_IN,
  FadeOut = LUMYN_ANIMATION_FADE_OUT,
  RainbowCycle = LUMYN_ANIMATION_RAINBOW_CYCLE,
  AlternateBreathe = LUMYN_ANIMATION_ALTERNATE_BREATHE,
  GrowingBreathe = LUMYN_ANIMATION_GROWING_BREATHE,
  Comet = LUMYN_ANIMATION_COMET,
  Sparkle = LUMYN_ANIMATION_SPARKLE,
  Fire = LUMYN_ANIMATION_FIRE,
  Scanner = LUMYN_ANIMATION_SCANNER,
  TheaterChase = LUMYN_ANIMATION_THEATER_CHASE,
  Twinkle = LUMYN_ANIMATION_TWINKLE,
  Meteor = LUMYN_ANIMATION_METEOR,
  Wave = LUMYN_ANIMATION_WAVE,
  Pulse = LUMYN_ANIMATION_PULSE,
  Larson = LUMYN_ANIMATION_LARSON,
  Ripple = LUMYN_ANIMATION_RIPPLE,
  Confetti = LUMYN_ANIMATION_CONFETTI,
  Lava = LUMYN_ANIMATION_LAVA,
  Plasma = LUMYN_ANIMATION_PLASMA,
  Heartbeat = LUMYN_ANIMATION_HEARTBEAT,
};

// Helper to convert Animation enum class to C lumyn_animation_t
inline constexpr lumyn_animation_t to_c_animation(Animation a) {
  return static_cast<lumyn_animation_t>(static_cast<uint16_t>(a));
}

} // namespace lumyn::led

#endif // __cplusplus

