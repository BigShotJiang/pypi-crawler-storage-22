/**
 * @file connectorx_animate.c
 * @brief ConnectorX Animate - Advanced Multi-Channel Control - C Example
 *
 * Demonstrates multi-channel control with zones, groups, and sequences.
 * Uses the configurations from examples/configs/connectorx_animate/basic.json
 * or advanced.json
 */

#include <lumyn/c/lumyn_sdk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#define sleep_ms(ms) Sleep(ms)
#else
#include <unistd.h>
#define sleep_ms(ms) usleep((ms) * 1000)
#endif

static void demo_zone_control(cx_base_t *cx)
{
  printf("\n=== Zone Control ===\n");

  lumyn_color_t red = {255, 0, 0};
  lumyn_color_t blue = {0, 0, 255};
  lumyn_color_t green = {0, 255, 0};
  lumyn_color_t yellow = {255, 255, 0};

  printf("Setting 'MyMatrix' zone to RED...\n");
  lumyn_SetColor(cx, "MyMatrix", red);
  sleep_ms(2000);

  printf("Setting 'MyStrip' zone to BLUE...\n");
  lumyn_SetColor(cx, "MyStrip", blue);
  sleep_ms(2000);

  printf("Setting 'MyOtherStrip' zone to GREEN (if using advanced.json)...\n");
  lumyn_SetColor(cx, "MyOtherStrip", green);
  sleep_ms(2000);

  printf("Running rainbow animation on 'MyMatrix'...\n");
  lumyn_color_t black = {0, 0, 0};
  lumyn_SetAnimation(cx, "MyMatrix", LUMYN_ANIMATION_RAINBOW_CYCLE, black, 40, false, false);
  sleep_ms(4000);
}

static void demo_group_control(cx_base_t *cx)
{
  printf("\n=== Group Control (advanced.json only) ===\n");

  lumyn_color_t purple = {128, 0, 255};
  
  printf("Setting 'MyGroup' to PURPLE...\n");
  lumyn_SetGroupColor(cx, "MyGroup", purple);
  sleep_ms(2000);
}

static void demo_sequences(cx_base_t *cx)
{
  printf("\n=== Animation Sequences ===\n");

  printf("Running sequence '1' (Blink)...\n");
  lumyn_SetAnimationSequence(cx, "MyMatrix", "1");
  sleep_ms(3000);

  printf("Running sequence 'cool' (RainbowRoll, AlternateBreathe, GrowingBreathe)...\n");
  lumyn_SetAnimationSequence(cx, "MyStrip", "cool");
  sleep_ms(6000);

  printf("Running sequence 'fadebreathe' on MyOtherStrip (advanced.json only)...\n");
  lumyn_SetAnimationSequence(cx, "MyOtherStrip", "fadebreathe");
  sleep_ms(5000);
}

int main(int argc, char *argv[])
{
  const char *port = NULL;

  for (int i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "--port") == 0 && i + 1 < argc)
    {
      port = argv[++i];
    }
  }

  if (!port)
  {
    fprintf(stderr, "Error: --port is required\n");
    return 1;
  }

  cx_animate_t cx = {0};
  lumyn_error_t err;

  err = lumyn_CreateConnectorXAnimate(&cx);
  if (err != LUMYN_OK)
  {
    fprintf(stderr, "Failed: %s\n", Lumyn_ErrorString(err));
    return 1;
  }

  printf("Connecting to %s...\n", port);
  err = lumyn_Connect(&cx.base, port);
  if (err != LUMYN_OK)
  {
    fprintf(stderr, "Failed to connect: %s\n", Lumyn_ErrorString(err));
    lumyn_DestroyConnectorXAnimate(&cx);
    return 1;
  }

  printf("Connected!\n");

  demo_zone_control(&cx.base);
  demo_group_control(&cx.base);
  demo_sequences(&cx.base);

  printf("\n=== All demos complete! ===\n");

  lumyn_Disconnect(&cx.base);
  lumyn_DestroyConnectorXAnimate(&cx);

  return 0;
}
