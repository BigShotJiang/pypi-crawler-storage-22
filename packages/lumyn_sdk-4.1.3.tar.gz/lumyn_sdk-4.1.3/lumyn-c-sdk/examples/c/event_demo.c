/**
 * @file event_demo.c
 * @brief ConnectorX Event Demo - C Example
 *
 * Connects to a device, prints current status, and polls events.
 *
 * Usage:
 *     ./event_demo_c --port /dev/ttyACM0 --duration 10 --poll-ms 100
 */

#include <lumyn/c/lumyn_device.h>
#include <lumyn/c/lumyn_events.h>
#include <lumyn/c/lumyn_sdk.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef _WIN32
#include <windows.h>
#define sleep_ms(ms) Sleep(ms)
#else
#include <unistd.h>
#define sleep_ms(ms) usleep((ms) * 1000)
#endif

static void print_event(const lumyn_event_t *evt)
{
  if (!evt)
    return;
  char buf[256];
  lumyn_snprintf_event(buf, sizeof(buf), evt);
  printf("%s\n", buf);
}

int main(int argc, char *argv[])
{
  const char *port = NULL;
  int duration_sec = 10;
  int poll_ms = 100;

  for (int i = 1; i < argc; i++)
  {
    if (strcmp(argv[i], "--port") == 0 && i + 1 < argc)
    {
      port = argv[++i];
    }
    else if (strcmp(argv[i], "--duration") == 0 && i + 1 < argc)
    {
      duration_sec = atoi(argv[++i]);
    }
    else if (strcmp(argv[i], "--poll-ms") == 0 && i + 1 < argc)
    {
      poll_ms = atoi(argv[++i]);
    }
  }

  if (!port)
  {
    printf("Error: --port is required\n");
    return 1;
  }

  cx_t cx = {0};
  lumyn_error_t err = lumyn_CreateConnectorX(&cx);
  if (err != LUMYN_OK)
  {
    fprintf(stderr, "Failed to create instance: %s\n", Lumyn_ErrorString(err));
    return 1;
  }

  printf("Connecting to %s...\n", port);
  err = lumyn_Connect(&cx.base, port);
  if (err != LUMYN_OK)
  {
    fprintf(stderr, "Failed to connect: %s\n", Lumyn_ErrorString(err));
    lumyn_DestroyConnectorX(&cx);
    return 1;
  }
  printf("Connected to ConnectorX!\n");

  lumyn_connection_status_t status = lumyn_GetCurrentStatus(&cx.base);
  lumyn_status_t health = lumyn_GetDeviceHealth(&cx.base);
  printf("Current status: connected=%d enabled=%d health=%s\n",
         status.connected ? 1 : 0, status.enabled ? 1 : 0, lumyn_StatusToString(health));

#define MAX_EVENTS 16
  lumyn_event_t events[MAX_EVENTS];
  int out_count = 0;

  time_t start = time(NULL);
  while ((int)(time(NULL) - start) < duration_sec)
  {
    out_count = 0;
    if (lumyn_GetEvents(&cx.base, events, MAX_EVENTS, &out_count) == LUMYN_OK)
    {
      for (int i = 0; i < out_count; ++i)
      {
        print_event(&events[i]);
      }
    }
    sleep_ms(poll_ms);
  }

  lumyn_Disconnect(&cx.base);
  lumyn_DestroyConnectorX(&cx);
  printf("Done!\n");
  return 0;
}
