#include <lumyn/Constants.h>  // Required for BuiltInAnimations.h (included via SDK headers)
/**
 * @file connectorx_animate.cpp
 * @brief ConnectorX Animate - Advanced Multi-Channel Control - C++ Example
 *
 * Demonstrates multi-channel control with zones, groups, and sequences.
 * Uses the configurations from examples/configs/connectorx_animate/basic.json
 * or advanced.json
 */

#include <lumyn/cpp/connectorXVariant/ConnectorXAnimate.hpp>
#include <lumyn/c/lumyn_sdk.h>
#include <iostream>
#include <thread>
#include <chrono>
#include <string>

using namespace lumyn::device;

static void demo_zone_control(ConnectorXAnimate& cx) {
    std::cout << "\n=== Zone Control ===\n";
    
    lumyn_color_t red{255, 0, 0};
    lumyn_color_t blue{0, 0, 255};
    lumyn_color_t green{0, 255, 0};
    lumyn_color_t yellow{255, 255, 0};
    
    std::cout << "Setting 'MyMatrix' zone to RED...\n";
    cx.SetColor("MyMatrix", red);
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    
    std::cout << "Setting 'MyStrip' zone to BLUE...\n";
    cx.SetColor("MyStrip", blue);
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    
    std::cout << "Setting 'MyOtherStrip' zone to GREEN (if using advanced.json)...\n";
    cx.SetColor("MyOtherStrip", green);
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    
    std::cout << "Running rainbow animation on 'MyMatrix'...\n";
    lumyn_color_t black{0, 0, 0};
    cx.SetAnimation(lumyn::led::Animation::RainbowCycle).ForZone("MyMatrix").WithColor(black).WithDelay(40).execute();
    std::this_thread::sleep_for(std::chrono::milliseconds(4000));
}

static void demo_group_control(ConnectorXAnimate& cx) {
    std::cout << "\n=== Group Control (advanced.json only) ===\n";
    
    lumyn_color_t purple{128, 0, 255};
    
    std::cout << "Setting 'MyGroup' to PURPLE...\n";
    cx.SetGroupColor("MyGroup", purple);
    std::this_thread::sleep_for(std::chrono::milliseconds(2000));
}

static void demo_sequences(ConnectorXAnimate& cx) {
    std::cout << "\n=== Animation Sequences ===\n";
    
    std::cout << "Running sequence '1' (Blink)...\n";
    cx.SetImageSequence("1").ForZone("MyMatrix").execute();
    std::this_thread::sleep_for(std::chrono::milliseconds(3000));
    
    std::cout << "Running sequence 'cool' (RainbowRoll, AlternateBreathe, GrowingBreathe)...\n";
    cx.SetImageSequence("cool").ForZone("MyStrip").execute();
    std::this_thread::sleep_for(std::chrono::milliseconds(6000));
    
    std::cout << "Running sequence 'fadebreathe' on MyOtherStrip (advanced.json only)...\n";
    cx.SetImageSequence("fadebreathe").ForZone("MyOtherStrip").execute();
    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
}

int main(int argc, char* argv[]) {
    std::string port;
    
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " --port <port>\n";
        return 1;
    }
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--port" && i + 1 < argc) {
            port = argv[++i];
        }
    }
    
    if (port.empty()) {
        std::cerr << "Error: --port is required\n";
        return 1;
    }
    
    try {
        ConnectorXAnimate cx;
        
        std::cout << "Connecting to " << port << "...\n";
        auto err = cx.Connect(port);
        if (err != LUMYN_OK) {
            std::cerr << "Failed to connect: " << Lumyn_ErrorString(err) << "\n";
            return 1;
        }
        
        std::cout << "Connected!\n";
        
        demo_zone_control(cx);
        demo_group_control(cx);
        demo_sequences(cx);
        
        std::cout << "\n=== All demos complete! ===\n";
        
        cx.Disconnect();
        
    } catch (const std::exception& e) {
        std::cerr << "Exception: " << e.what() << "\n";
        return 1;
    }
    
    return 0;
}
