#include <lumyn/Constants.h>  // Required for BuiltInAnimations.h (included via SDK headers)
/**
 * @file event_demo.cpp
 * @brief ConnectorX Event Demo - C++ Example
 *
 * Connects to a device, prints current status, and polls events.
 *
 * Usage:
 *     ./event_demo_cpp --port /dev/ttyACM0 --duration 10 --poll-ms 100
 */

#include <lumyn/c/lumyn_device.h>
#include <lumyn/c/lumyn_events.h>
#include <lumyn/c/lumyn_sdk.h>
#include <lumyn/cpp/EventUtils.hpp>

#include <chrono>
#include <cstring>
#include <iostream>
#include <thread>

static void print_event(const lumyn_event_t& evt) {
  std::cout << lumyn::FormatEvent(evt) << "\n";
}

int main(int argc, char* argv[]) {
  std::string port;
  int duration_sec = 10;
  int poll_ms = 100;

  for (int i = 1; i < argc; i++) {
    if (std::strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
      port = argv[++i];
    } else if (std::strcmp(argv[i], "--duration") == 0 && i + 1 < argc) {
      duration_sec = std::atoi(argv[++i]);
    } else if (std::strcmp(argv[i], "--poll-ms") == 0 && i + 1 < argc) {
      poll_ms = std::atoi(argv[++i]);
    }
  }

  if (port.empty()) {
    std::cerr << "Error: --port is required\n";
    return 1;
  }

  cx_t cx{};
  if (lumyn_CreateConnectorX(&cx) != LUMYN_OK) {
    std::cerr << "Failed to create instance\n";
    return 1;
  }
  std::cout << "Connecting to " << port << "...\n";
  auto err = lumyn_Connect(&cx.base, port.c_str());
  if (err != LUMYN_OK) {
    std::cerr << "Failed to connect: " << Lumyn_ErrorString(err) << "\n";
    lumyn_DestroyConnectorX(&cx);
    return 1;
  }
  std::cout << "Connected to ConnectorX!\n";

  lumyn_connection_status_t status = lumyn_GetCurrentStatus(&cx.base);
  lumyn_status_t health = lumyn_GetDeviceHealth(&cx.base);
  std::cout << "Current status: connected=" << (status.connected ? 1 : 0)
            << " enabled=" << (status.enabled ? 1 : 0)
            << " health=" << lumyn::StatusToString(health) << "\n";

  auto start = std::chrono::steady_clock::now();
  while (std::chrono::duration_cast<std::chrono::seconds>(
             std::chrono::steady_clock::now() - start)
             .count() < duration_sec) {
    const int kMaxEvents = 16;
    lumyn_event_t events[kMaxEvents];
    int out_count = 0;
    if (lumyn_GetEvents(&cx.base, events, kMaxEvents, &out_count) == LUMYN_OK) {
      for (int i = 0; i < out_count; ++i) {
        print_event(events[i]);
      }
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(poll_ms));
  }

  lumyn_Disconnect(&cx.base);
  lumyn_DestroyConnectorX(&cx);
  std::cout << "Done!\n";
  return 0;
}
