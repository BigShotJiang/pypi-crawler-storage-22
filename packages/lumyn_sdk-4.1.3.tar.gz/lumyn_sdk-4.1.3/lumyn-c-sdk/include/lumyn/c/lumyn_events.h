/**
 * @file lumyn_events.h
 * @brief Event handling and callbacks
 *
 * This header contains functions for registering event handlers and
 * retrieving events from Lumyn devices.
 */
#pragma once

#include "lumyn_common.h"

#ifdef __cplusplus
extern "C"
{
#endif

  // =============================================================================
  // Event Handler Registration
  // =============================================================================

  /**
   * @brief Register a callback for events.
   * @param inst Device instance
   * @param cb Callback function
   * @param user User-provided context pointer
   * @return LUMYN_OK on success
   * @note extra_message is only valid for the duration of the callback.
   */
  LUMYN_SDK_API lumyn_error_t lumyn_AddEventHandler(cx_base_t *inst, lumyn_event_callback_t cb, void *user);

  // =============================================================================
  // Event Retrieval
  // =============================================================================

  /**
   * @brief Get latest event (if any).
   * @param inst Device instance
   * @param evt Output event structure
   * @return LUMYN_OK if an event is available
   * @note extra_message is valid until the next call to lumyn_GetLatestEvent()/lumyn_GetEvents()
   *       on the same thread.
   */
  LUMYN_SDK_API lumyn_error_t lumyn_GetLatestEvent(cx_base_t *inst, lumyn_event_t *evt);

  /**
   * @brief Get buffered events (if any).
   * @param inst Device instance
   * @param arr Array to receive events
   * @param max_count Maximum number of events to retrieve
   * @param out_count Output pointer to receive actual count
   * @return LUMYN_OK on success
   * @note extra_message is valid until the next call to lumyn_GetLatestEvent()/lumyn_GetEvents()
   *       on the same thread.
   */
  LUMYN_SDK_API lumyn_error_t lumyn_GetEvents(cx_base_t *inst, lumyn_event_t *arr, int max_count, int *out_count);

  /**
   * @brief Enable or disable automatic event polling.
   * @param inst Device instance
   * @param enabled Whether automatic polling should be enabled
   */
  LUMYN_SDK_API void lumyn_SetAutoPollEvents(cx_base_t *inst, bool enabled);

  // =============================================================================
  // Enum-to-String Conversion Functions
  // =============================================================================

  /**
   * @brief Convert event type to string.
   * @param type Event type
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_EventTypeToString(lumyn_event_type_t type);

  /**
   * @brief Convert device status to string.
   * @param status Device status
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_StatusToString(lumyn_status_t status);

  /**
   * @brief Convert disabled cause to string.
   * @param cause Disabled cause
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_DisabledCauseToString(lumyn_disabled_cause_t cause);

  /**
   * @brief Convert connection type to string.
   * @param type Connection type
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_ConnectionTypeToString(lumyn_connection_type_t type);

  /**
   * @brief Convert error type to string.
   * @param type Error type
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_ErrorTypeToString(lumyn_error_type_t type);

  /**
   * @brief Convert fatal error type to string.
   * @param type Fatal error type
   * @return Static string representation
   */
  LUMYN_SDK_API const char *lumyn_FatalErrorTypeToString(lumyn_fatal_error_type_t type);

  // =============================================================================
  // Event Formatting Functions
  // =============================================================================

  /**
   * @brief Format an event to a string buffer (snprintf-style).
   * @param buf Output buffer
   * @param size Buffer size
   * @param evt Event to format
   * @return Number of characters written (excluding null terminator), or negative on error
   */
  LUMYN_SDK_API int lumyn_snprintf_event(char *buf, size_t size, const lumyn_event_t *evt);

#ifdef __cplusplus
} // extern "C"
#endif
