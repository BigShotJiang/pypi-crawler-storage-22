/**
 * @file ConfigUtils.hpp
 * @brief C++ configuration formatting utilities
 *
 * This header provides idiomatic C++ wrappers around the C configuration
 * formatting functions. All functions delegate to their C counterparts.
 */
#pragma once

#include <lumyn/c/lumyn_config.h>
#include <lumyn/cpp/types.hpp>

namespace lumyn {

// =============================================================================
// Enum-to-String Functions (inline wrappers around C functions)
// =============================================================================

/**
 * @brief Convert module connection type to string.
 * @param type Module connection type
 * @return Static string representation
 */
inline const char* ModuleConnectionTypeToString(ModuleConnectionType type) {
  return lumyn_ModuleConnectionTypeToString(type);
}

} // namespace lumyn
