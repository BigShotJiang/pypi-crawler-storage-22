/**
 * @file EventUtils.hpp
 * @brief C++ event formatting utilities
 *
 * This header provides idiomatic C++ wrappers around the C event formatting
 * functions. All functions delegate to their C counterparts.
 */
#pragma once

#include <lumyn/c/lumyn_events.h>
#include <lumyn/cpp/types.hpp>
#include <string>

namespace lumyn {

// =============================================================================
// Enum-to-String Functions (inline wrappers around C functions)
// =============================================================================

/**
 * @brief Convert event type to string.
 * @param type Event type
 * @return Static string representation
 */
inline const char* EventTypeToString(EventType type) {
  return lumyn_EventTypeToString(type);
}

/**
 * @brief Convert device status to string.
 * @param status Device status
 * @return Static string representation
 */
inline const char* StatusToString(Status status) {
  return lumyn_StatusToString(status);
}

/**
 * @brief Convert disabled cause to string.
 * @param cause Disabled cause
 * @return Static string representation
 */
inline const char* DisabledCauseToString(DisabledCause cause) {
  return lumyn_DisabledCauseToString(cause);
}

/**
 * @brief Convert connection type to string.
 * @param type Connection type
 * @return Static string representation
 */
inline const char* ConnectionTypeToString(ConnectionType type) {
  return lumyn_ConnectionTypeToString(type);
}

/**
 * @brief Convert error type to string.
 * @param type Error type
 * @return Static string representation
 */
inline const char* ErrorTypeToString(ErrorType type) {
  return lumyn_ErrorTypeToString(type);
}

/**
 * @brief Convert fatal error type to string.
 * @param type Fatal error type
 * @return Static string representation
 */
inline const char* FatalErrorTypeToString(FatalErrorType type) {
  return lumyn_FatalErrorTypeToString(type);
}

// =============================================================================
// Event Formatting Functions
// =============================================================================

/**
 * @brief Format an event to a std::string.
 * @param evt Event to format
 * @return Formatted string representation
 */
inline std::string FormatEvent(const lumyn_event_t& evt) {
  char buf[256];
  int len = lumyn_snprintf_event(buf, sizeof(buf), &evt);
  if (len < 0) {
    return "";
  }
  return std::string(buf, static_cast<size_t>(len < static_cast<int>(sizeof(buf)) ? len : sizeof(buf) - 1));
}

/**
 * @brief Format an Event wrapper to a std::string.
 * @param evt Event wrapper to format
 * @return Formatted string representation
 */
inline std::string FormatEvent(const Event& evt) {
  // Reconstruct a C event for formatting
  lumyn_event_t c_evt{};
  c_evt.type = evt.getType();
  c_evt.data = evt.getData();
  c_evt.extra_message = const_cast<char*>(evt.getExtraMessage());
  return FormatEvent(c_evt);
}

} // namespace lumyn
