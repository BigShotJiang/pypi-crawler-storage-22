#pragma once

#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "lumyn/cpp/export.hpp"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"

namespace lumyn::modules
{
  class ModuleDataDispatcher;
}

namespace lumyn::device {

/**
 * @brief ConnectorX device with full LED and module support
 *
 * Thin C++ wrapper around the C SDK. All device logic is in the C SDK layer.
 * This class provides C++ conveniences and module data management.
 *
 * Architecture: common -> C SDK -> C++ SDK (this) -> Driver -> WPILib API
 */
class LUMYN_SDK_CPP_API ConnectorX : public BaseConnectorXVariant {
public:
  ConnectorX();
  ~ConnectorX() override;

  ConnectorX(const ConnectorX&) = delete;
  ConnectorX& operator=(const ConnectorX&) = delete;
  ConnectorX(ConnectorX&&) = delete;
  ConnectorX& operator=(ConnectorX&&) = delete;

  // Event polling control
  ConnectorX& SetAutoPollEvents(bool enabled);

  // RestartDevice - ConnectorX-specific
  void RestartDevice(uint32_t delay_ms = 0);

  // Module data - delegates to C API
  lumyn_error_t GetLatestModuleData(std::string_view module_id, std::vector<uint8_t> &out);
  void RegisterModule(std::string_view module_id, std::function<void(const std::vector<uint8_t> &)> callback);
  void SetModulePollingEnabled(bool enabled);
  void PollModules();
  
  // Module dispatcher accessor
  ::lumyn::modules::ModuleDataDispatcher& GetModuleDispatcher();

  // Connection state callback
  void SetConnectionStateCallback(std::function<void(bool)> callback);

  // Hook from BaseConnectorXVariant for disconnect cleanup
  void OnDisconnect() override;

private:
  void EnsureModuleRegistered(std::string_view module_id);
  void ClearModuleCache();
  bool PopModuleData(std::string_view module_id, std::vector<uint8_t> &out);
  static void HandleModuleData(const char *module_id, const uint8_t *data, size_t len, void *user);

  cx_t *c_handle_{nullptr};
  bool owns_c_handle_{false};
  std::unique_ptr<std::function<void(bool)>> connection_callback_;
  std::unique_ptr<::lumyn::modules::ModuleDataDispatcher> module_dispatcher_;
  std::mutex module_cache_mutex_;
  std::unordered_map<std::string, std::deque<std::vector<uint8_t>>> module_cache_;
  std::unordered_set<std::string> registered_modules_;
  std::unordered_map<std::string, std::function<void(const std::vector<uint8_t> &)>> module_callbacks_;
  bool module_polling_enabled_{false};
};

} // namespace lumyn::device
