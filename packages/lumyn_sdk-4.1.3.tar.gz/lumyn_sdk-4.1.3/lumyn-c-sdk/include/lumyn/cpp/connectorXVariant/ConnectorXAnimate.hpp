#pragma once

#include "lumyn/cpp/export.hpp"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"

namespace lumyn::device {

/**
 * @brief ConnectorXAnimate device with LED support (no modules)
 *
 * Thin C++ wrapper around the C SDK. This variant does not support modules.
 *
 * Architecture: common -> C SDK -> C++ SDK (this) -> Driver -> WPILib API
 */
class LUMYN_SDK_CPP_API ConnectorXAnimate : public BaseConnectorXVariant {
public:
  ConnectorXAnimate();
  ~ConnectorXAnimate() override;

  ConnectorXAnimate(const ConnectorXAnimate&) = delete;
  ConnectorXAnimate& operator=(const ConnectorXAnimate&) = delete;
  ConnectorXAnimate(ConnectorXAnimate&&) = delete;
  ConnectorXAnimate& operator=(ConnectorXAnimate&&) = delete;

  // SetAutoPollEvents - return *this for chaining
  ConnectorXAnimate& SetAutoPollEvents(bool enabled);

private:
  cx_animate_t *c_handle_{nullptr};
  bool owns_c_handle_{false};
};

} // namespace lumyn::device
