#pragma once

#include "lumyn/cpp/device/BaseLEDDevice.hpp"
#include "lumyn/cpp/device/BaseLumynDevice.hpp"
#include "lumyn/cpp/device/BaseModuleDevice.hpp"
#include "lumyn/cpp/device/DirectLED.hpp"
#include "lumyn/cpp/types.hpp"
#include "lumyn/c/lumyn_sdk.h"
#include "lumyn/c/serial_io.h"
#include "lumyn/types/status.h"

#include <atomic>
#include <functional>
#include <optional>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

namespace lumyn::internal
{
  class BaseConnectorXCore
      : public BaseLEDDevice,
        public BaseLumynDevice
  {
  public:
    BaseConnectorXCore();
    ~BaseConnectorXCore() override;

    BaseConnectorXCore(const BaseConnectorXCore &) = delete;
    BaseConnectorXCore &operator=(const BaseConnectorXCore &) = delete;
    BaseConnectorXCore(BaseConnectorXCore &&) = delete;
    BaseConnectorXCore &operator=(BaseConnectorXCore &&) = delete;

    using BaseLumynDevice::Connect;
    ::lumyn_error_t Connect(const ::lumyn_serial_io_t &io);
    ::lumyn_error_t Connect(const std::string &port, std::optional<int> baud = std::nullopt);
    void Disconnect();
    bool IsConnected() const;
    ::lumyn::ConnectionStatus GetCurrentStatus() const;
    ::lumyn::Status GetDeviceHealth() const;

    ::lumyn_error_t AddEventHandler(std::function<void(const ::lumyn::Event &)> handler);
    ::lumyn_error_t GetLatestEvent(::lumyn_event_t &out_event);
    std::optional<::lumyn::Event> GetLatestEvent();
    std::vector<::lumyn::Event> GetEvents();
    void SetAutoPollEvents(bool enabled);
    void PollEvents();

    ::lumyn_error_t RequestConfig(std::string &out_json, uint32_t timeout_ms = 1000);
    bool ApplyConfigurationJson(const std::string &json);
    bool LoadConfigurationFromFile(const std::string &path);

    void SetColor(std::string_view zone_id, ::lumyn_color_t color) const;
    void SetGroupColor(std::string_view group_id, ::lumyn_color_t color) const;
    void SetAnimationSequence(std::string_view zone_id, std::string_view sequence_id);
    void SetGroupAnimationSequence(std::string_view group_id, std::string_view sequence_id);

    ::lumyn_error_t SendDirectBuffer(std::string_view zone_id, const uint8_t *data, size_t length, bool delta);
    ::lumyn_error_t SendDirectBuffer(uint16_t zone_hash, const uint8_t *data, size_t length, bool delta);
    ::lumyn::device::DirectLED CreateDirectLED(std::string_view zone_id, size_t num_leds, int full_refresh_interval_ms = 100);

    void SendRawCommand(const uint8_t *data, size_t length);
    void SendLEDCommand(const void *data, uint32_t length) override;

  protected:
    void StartEventPolling();
    void StopEventPolling();
    virtual void OnDisconnect() {}

    bool auto_poll_events_{true};
    std::atomic<bool> poll_events_{false};
    std::thread event_thread_;
  };

  class ConnectorXCore : public BaseConnectorXCore, public BaseModuleDevice
  {
  public:
    ConnectorXCore();
    ~ConnectorXCore() override;

    ConnectorXCore(const ConnectorXCore &) = delete;
    ConnectorXCore &operator=(const ConnectorXCore &) = delete;
    ConnectorXCore(ConnectorXCore &&) = delete;
    ConnectorXCore &operator=(ConnectorXCore &&) = delete;

    BaseLumynDevice *GetModuleBasePtr() override;
    const BaseLumynDevice *GetModuleBasePtr() const override;

    ConnectorXCore &SetAutoPollEvents(bool enabled);
    void RestartDevice(uint32_t delay_ms = 0);

    void OnEvent(const Eventing::Event &evt) override;
    void *GetBasePtr() override;
    const void *GetBasePtr() const override;

  protected:
    void OnDisconnect() override;
  };

  class ConnectorXAnimateCore : public BaseConnectorXCore
  {
  public:
    ConnectorXAnimateCore();
    ~ConnectorXAnimateCore() override;

    ConnectorXAnimateCore(const ConnectorXAnimateCore &) = delete;
    ConnectorXAnimateCore &operator=(const ConnectorXAnimateCore &) = delete;
    ConnectorXAnimateCore(ConnectorXAnimateCore &&) = delete;
    ConnectorXAnimateCore &operator=(ConnectorXAnimateCore &&) = delete;

    ConnectorXAnimateCore &SetAutoPollEvents(bool enabled);

    void OnEvent(const Eventing::Event &evt) override;
    void *GetBasePtr() override;
    const void *GetBasePtr() const override;
  };
}
