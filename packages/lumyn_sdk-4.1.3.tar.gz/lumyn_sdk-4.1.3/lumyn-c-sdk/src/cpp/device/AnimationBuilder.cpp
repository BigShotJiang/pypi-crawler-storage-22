#include "lumyn/Constants.h"  // Required for BuiltInAnimations.h (included via AnimationBuilder.hpp)
#include "lumyn/cpp/device/builder/AnimationBuilder.hpp"

#include "lumyn/c/lumyn_led.h"
#include "lumyn/c/lumyn_sdk.h"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"
#include "lumyn/led/BuiltInAnimations.h"

namespace lumyn {
namespace device {

void AnimationBuilder::execute()
{
  if (this->isExecuted()) {
    return;
  }

  this->validateTarget();

  if (!_device || !_device->GetCBasePtr()) {
    this->markExecuted();
    return;
  }

  if (this->hasZone()) {
    lumyn_SetAnimation(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                       std::string(this->getZoneId().value()).c_str(),
                       lumyn::led::to_c_animation(_animation), _color,
                       static_cast<uint32_t>(_delay.count()),
                       _reversed, _oneShot);
  } else {
    lumyn_SetGroupAnimation(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                            std::string(this->getGroupId().value()).c_str(),
                            lumyn::led::to_c_animation(_animation), _color,
                            static_cast<uint32_t>(_delay.count()),
                            _reversed, _oneShot);
  }

  this->markExecuted();
}

lumyn_color_t AnimationBuilder::defaultColor(lumyn::led::Animation animation)
{
  const auto* instance = lumyn::led::GetAnimationInstance(animation);
  if (instance) {
    return {instance->defaultColor.r, instance->defaultColor.g, instance->defaultColor.b};
  }
  // Fallback to default color (blue: {0, 0, 240}) - hardcoded to avoid private Constants.h dependency
  return {0, 0, 240};
}

} // namespace device
} // namespace lumyn
