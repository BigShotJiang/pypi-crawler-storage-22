#include "lumyn/cpp/device/builder/ImageSequenceBuilder.hpp"
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"
#include "lumyn/c/lumyn_led.h"

namespace lumyn {
namespace device {

void ImageSequenceBuilder::execute()
{
  if (this->isExecuted()) return;

  this->validateTarget();

  if (!_device || !_device->GetCBasePtr()) {
    this->markExecuted();
    return;
  }

  if (this->hasZone()) {
    lumyn_SetImageSequence(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                           std::string(this->getZoneId().value()).c_str(),
                           _sequenceId.c_str(),
                           _color,
                           _setColor,
                           _oneShot);
  } else {
    lumyn_SetGroupImageSequence(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                                std::string(this->getGroupId().value()).c_str(),
                                _sequenceId.c_str(),
                                _color,
                                _setColor,
                                _oneShot);
  }

  this->markExecuted();
}

} // namespace device
} // namespace lumyn
