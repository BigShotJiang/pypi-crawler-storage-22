#include "lumyn/cpp/device/builder/MatrixTextBuilder.hpp"

#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"
#include "lumyn/c/lumyn_led.h"

namespace lumyn {
namespace device {

void MatrixTextBuilder::execute()
{
  if (this->isExecuted()) return;

  this->validateTarget();

  if (!_device || !_device->GetCBasePtr()) {
    this->markExecuted();
    return;
  }

  const auto direction = static_cast<lumyn_matrix_text_scroll_direction_t>(_direction);
  const auto font = static_cast<lumyn_matrix_text_font_t>(_font);
  const auto align = static_cast<lumyn_matrix_text_align_t>(_align);
  if (this->hasZone()) {
    lumyn_SetTextAdvanced(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                          std::string(this->getZoneId().value()).c_str(),
                          _text.c_str(),
                          _color,
                          direction,
                          static_cast<uint32_t>(_delay.count()),
                          _oneShot,
                          _bgColor,
                          font,
                          align,
                          _flags,
                          _yOffset);
  } else {
    lumyn_SetGroupTextAdvanced(const_cast<cx_base_t*>(_device->GetCBasePtr()),
                               std::string(this->getGroupId().value()).c_str(),
                               _text.c_str(),
                               _color,
                               direction,
                               static_cast<uint32_t>(_delay.count()),
                               _oneShot,
                               _bgColor,
                               font,
                               align,
                               _flags,
                               _yOffset);
  }

  this->markExecuted();
}

} // namespace device
} // namespace lumyn
