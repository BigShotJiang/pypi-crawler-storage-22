#include "lumyn/Constants.h"  // Required for BuiltInAnimations.h (included via ConnectorXAnimate.hpp -> BaseConnectorXVariant.hpp -> AnimationBuilder.hpp)
#include "lumyn/cpp/connectorXVariant/ConnectorXAnimate.hpp"

#include <stdexcept>

namespace lumyn::device
{

  ConnectorXAnimate::ConnectorXAnimate()
      : BaseConnectorXVariant()
  {
    cx_animate_t *handle = nullptr;
    const auto err = lumyn_CreateConnectorXAnimateAlloc(&handle);
    if (err != LUMYN_OK)
    {
      throw std::runtime_error(Lumyn_ErrorString(err));
    }
    c_handle_ = handle;
    owns_c_handle_ = true;
    SetCBasePtr(&handle->base);
  }

  ConnectorXAnimate::~ConnectorXAnimate()
  {
    if (owns_c_handle_ && c_handle_)
    {
      lumyn_DestroyConnectorXAnimateAlloc(c_handle_);
    }
    c_handle_ = nullptr;
    SetCBasePtr(nullptr);
  }

  ConnectorXAnimate& ConnectorXAnimate::SetAutoPollEvents(bool enabled)
  {
    BaseConnectorXVariant::SetAutoPollEvents(enabled);
    return *this;
  }

} // namespace lumyn::device
