#include "lumyn/Constants.h" // Required for BuiltInAnimations.h (included via BaseConnectorXVariant.hpp -> AnimationBuilder.hpp)
#include "lumyn/cpp/connectorXVariant/BaseConnectorXVariant.hpp"
#include "../c_abi/internal/ConnectorXCore.hpp"

// Internal headers
#include "lumyn/cpp/util/SerialIOAdapter.hpp"
#include "lumyn/cpp/util/EventConversion.hpp"
#include <lumyn/domain/command/Command.h>
#include <lumyn/util/hashing/IDCreator.h>
#include <lumyn/util/serial/ISerialIO.h>
#include <lumyn/domain/Color.h>
#include <lumyn/domain/command/led/LEDCommand.h>
#include <lumyn/domain/event/EventType.h>
#include <lumyn/led/Animation.h>
#include <lumyn/domain/event/Event.h>
#include <lumyn/cpp/EventManager.h>
#include <lumyn/cpp/ConfigManager.h>

#include <stdexcept>
#include <cstring>
#include <chrono>
#include <thread>
#include <vector>
#include <climits>
#include <fstream>
#include <iterator>
#include <memory>

namespace
{
  /**
   * @brief Convert an internal::Eventing::Event to a lumyn_event_t C struct
   *
   * This allows events from the pure C++ BaseLumynDevice::DrainEvents() to be
   * converted to the C API format used by lumyn::Event.
   */
  lumyn_event_t convert_internal_event_to_c(const lumyn::internal::Eventing::Event &evt)
  {
    lumyn_event_t c_evt{};
    c_evt.type = static_cast<lumyn_event_type_t>(evt.header.type);

    // Convert data union based on event type
    using lumyn::internal::Eventing::EventType;
    switch (evt.header.type)
    {
    case EventType::Disabled:
      c_evt.data.disabled.cause = static_cast<lumyn_disabled_cause_t>(evt.header.data.disabled.cause);
      break;
    case EventType::Connected:
      c_evt.data.connected.type = static_cast<lumyn_connection_type_t>(evt.header.data.connected.type);
      break;
    case EventType::Disconnected:
      c_evt.data.disconnected.type = static_cast<lumyn_connection_type_t>(evt.header.data.disconnected.type);
      break;
    case EventType::Error:
      c_evt.data.error.type = static_cast<lumyn_error_type_t>(evt.header.data.error.type);
      std::strncpy(c_evt.data.error.message, evt.header.data.error.message,
                   sizeof(c_evt.data.error.message) - 1);
      c_evt.data.error.message[sizeof(c_evt.data.error.message) - 1] = '\0';
      break;
    case EventType::FatalError:
      c_evt.data.fatal_error.type = static_cast<lumyn_fatal_error_type_t>(evt.header.data.fatalError.type);
      std::strncpy(c_evt.data.fatal_error.message, evt.header.data.fatalError.message,
                   sizeof(c_evt.data.fatal_error.message) - 1);
      c_evt.data.fatal_error.message[sizeof(c_evt.data.fatal_error.message) - 1] = '\0';
      break;
    case EventType::RegisteredEntity:
      c_evt.data.registered_entity.id = static_cast<int32_t>(evt.header.data.registeredEntity.id);
      break;
    case EventType::Custom:
      c_evt.data.custom.type = evt.header.data.custom.type;
      c_evt.data.custom.length = evt.header.data.custom.length;
      std::memcpy(c_evt.data.custom.data, evt.header.data.custom.data,
                  sizeof(c_evt.data.custom.data));
      break;
    case EventType::PinInterrupt:
      c_evt.data.pin_interrupt.pin = evt.header.data.pinInterrupt.pin;
      break;
    case EventType::HeartBeat:
      c_evt.data.heartbeat.status = static_cast<lumyn_status_t>(evt.header.data.heartBeat.status);
      c_evt.data.heartbeat.enabled = evt.header.data.heartBeat.enabled;
      c_evt.data.heartbeat.connected_usb = evt.header.data.heartBeat.connectedUSB;
      c_evt.data.heartbeat.can_ok = evt.header.data.heartBeat.canOK;
      break;
    default:
      // BeginInitialization, FinishInitialization, Enabled, OTA, Module - no data
      break;
    }

    // Handle extra message (lumyn::Event will make a copy)
    c_evt.extra_message = nullptr;
    if (evt.hasExtraMessage())
    {
      // Note: lumyn::Event constructor will copy this, so we can use the pointer directly
      // But lumyn_event_t expects caller to free, so we need to duplicate
      const char *msg = evt.getExtraMessageStr();
      if (msg)
      {
        size_t len = std::strlen(msg) + 1;
        c_evt.extra_message = static_cast<char *>(std::malloc(len));
        if (c_evt.extra_message)
        {
          std::memcpy(c_evt.extra_message, msg, len);
        }
      }
    }

    return c_evt;
  }
} // anonymous namespace

namespace lumyn::internal
{

  BaseConnectorXCore::BaseConnectorXCore()
      : BaseLEDDevice(),
        BaseLumynDevice()
  {
    // Initialize LED commanders for BaseLEDDevice
    InitializeLEDCommanders([this](Command::LED::LEDCommand &cmd)
                            { SendLEDCommand(&cmd, sizeof(cmd)); });
  }

  BaseConnectorXCore::~BaseConnectorXCore()
  {
    poll_events_ = false;
    if (event_thread_.joinable())
      event_thread_.join();
  }

  lumyn_error_t BaseConnectorXCore::Connect(const lumyn_serial_io_t &io)
  {
    auto adapter = std::make_unique<SerialIOAdapter>(io);
    if (BaseLumynDevice::Connect(adapter.release()))
    {
      StartEventPolling();
      return LUMYN_OK;
    }
    return LUMYN_ERR_IO;
  }

  lumyn_error_t BaseConnectorXCore::Connect(const std::string &port, std::optional<int> baud)
  {
    lumyn_serial_io_cfg_t cfg = LUMYN_SERIAL_CFG_DEFAULT;
    cfg.path = port.c_str();
    cfg.baud = baud.value_or(115200);

    lumyn_serial_io_t io{};
    auto err = lumyn_serial_open(&cfg, &io);
    if (err != LUMYN_OK)
      return err;
    err = Connect(io);
    if (err != LUMYN_OK)
    {
      lumyn_serial_io_close(&io);
    }
    return err;
  }

  void BaseConnectorXCore::Disconnect()
  {
    BaseLumynDevice::Disconnect();
    StopEventPolling();
    OnDisconnect();
  }

  bool BaseConnectorXCore::IsConnected() const
  {
    return BaseLumynDevice::IsConnected();
  }

  lumyn::ConnectionStatus BaseConnectorXCore::GetCurrentStatus() const
  {
    return lumyn::ConnectionStatus{IsConnected(), IsConnected()};
  }

  lumyn::Status BaseConnectorXCore::GetDeviceHealth() const
  {
    return static_cast<lumyn::Status>(LUMYN_STATUS_UNKNOWN);
  }

  lumyn_error_t BaseConnectorXCore::AddEventHandler(std::function<void(const lumyn::Event &)> handler)
  {
    (void)handler;
    return LUMYN_ERR_NOT_SUPPORTED;
  }

  lumyn_error_t BaseConnectorXCore::GetLatestEvent(lumyn_event_t &out_event)
  {
    const auto *evt = BaseLumynDevice::GetLatestEvent();
    if (!evt)
      return LUMYN_ERR_TIMEOUT;
    out_event = convert_internal_event_to_c(*evt);
    return LUMYN_OK;
  }

  std::optional<lumyn::Event> BaseConnectorXCore::GetLatestEvent()
  {
    const auto *evt = BaseLumynDevice::GetLatestEvent();
    if (!evt)
      return std::nullopt;
    lumyn_event_t c_evt = convert_internal_event_to_c(*evt);
    lumyn::Event wrapped(c_evt);
    if (c_evt.extra_message)
    {
      std::free(c_evt.extra_message);
    }
    return wrapped;
  }

  std::vector<lumyn::Event> BaseConnectorXCore::GetEvents()
  {
    auto raw_events = BaseLumynDevice::DrainEvents();
    std::vector<lumyn::Event> events;
    events.reserve(raw_events.size());
    for (const auto &evt : raw_events)
    {
      lumyn_event_t c_evt = convert_internal_event_to_c(evt);
      events.emplace_back(c_evt);
      if (c_evt.extra_message)
      {
        std::free(c_evt.extra_message);
      }
    }
    return events;
  }

  void BaseConnectorXCore::SetAutoPollEvents(bool enabled)
  {
    auto_poll_events_ = enabled;
    if (!enabled)
    {
      StopEventPolling();
    }
    else if (!poll_events_ && IsConnected())
    {
      StartEventPolling();
    }
  }

  void BaseConnectorXCore::PollEvents()
  {
    (void)GetEvents();
  }

  lumyn_error_t BaseConnectorXCore::RequestConfig(std::string &out_json, uint32_t timeout_ms)
  {
    bool ok = BaseLumynDevice::RequestConfig(out_json, static_cast<int>(timeout_ms));
    return ok ? LUMYN_OK : LUMYN_ERR_TIMEOUT;
  }

  bool BaseConnectorXCore::ApplyConfigurationJson(const std::string &json)
  {
    if (json.empty())
      return false;
    if (!IsConnected())
      return false;
    BaseLumynDevice::SendConfiguration(reinterpret_cast<const uint8_t *>(json.data()),
                                       static_cast<uint32_t>(json.size()));
    return true;
  }

  bool BaseConnectorXCore::LoadConfigurationFromFile(const std::string &path)
  {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open())
      return false;
    std::string contents((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    return ApplyConfigurationJson(contents);
  }

  void BaseConnectorXCore::SetColor(std::string_view zone_id, lumyn_color_t color) const
  {
    Command::LED::AnimationColor animColor{color.r, color.g, color.b};
    GetLEDCommander().SetColor(zone_id, animColor);
  }

  void BaseConnectorXCore::SetGroupColor(std::string_view group_id, lumyn_color_t color) const
  {
    Command::LED::AnimationColor animColor{color.r, color.g, color.b};
    GetLEDCommander().SetGroupColor(group_id, animColor);
  }

  void BaseConnectorXCore::SetAnimationSequence(std::string_view zone_id, std::string_view sequence_id)
  {
    GetLEDCommander().SetAnimationSequence(zone_id, sequence_id);
  }

  void BaseConnectorXCore::SetGroupAnimationSequence(std::string_view group_id, std::string_view sequence_id)
  {
    GetLEDCommander().SetGroupAnimationSequence(group_id, sequence_id);
  }

  lumyn_error_t BaseConnectorXCore::SendDirectBuffer(std::string_view zone_id, const uint8_t *data, size_t length, bool delta)
  {
    auto zone_hash = IDCreator::createId(zone_id);
    return SendDirectBuffer(zone_hash, data, length, delta);
  }

  lumyn_error_t BaseConnectorXCore::SendDirectBuffer(uint16_t zone_hash, const uint8_t *data, size_t length, bool delta)
  {
    if (!data || length == 0 || length > UINT16_MAX)
      return LUMYN_ERR_INVALID_ARGUMENT;
    Command::CommandHeader header{};
    header.type = Command::CommandType::LED;
    header.ledType = Command::LED::LEDCommandType::SetDirectBuffer;

    Command::LED::SetDirectBufferData meta{};
    meta.zoneId = zone_hash;
    meta.bufferLength = static_cast<uint16_t>(length);
    meta.flags.delta = delta ? 1 : 0;
    meta.flags.reserved = 0;

    std::vector<uint8_t> payload(sizeof(meta) + length);
    std::memcpy(payload.data(), &meta, sizeof(meta));
    std::memcpy(payload.data() + sizeof(meta), data, length);

    SendCommand(header, payload.data(), payload.size());
    return LUMYN_OK;
  }

  lumyn::device::DirectLED BaseConnectorXCore::CreateDirectLED(std::string_view zone_id, size_t num_leds, int full_refresh_interval_ms)
  {
    return lumyn::device::DirectLED(
        [this](uint16_t zone_hash, const uint8_t *data, size_t length, bool delta)
        {
          return this->SendDirectBuffer(zone_hash, data, length, delta);
        },
        zone_id, num_leds, full_refresh_interval_ms);
  }

  void BaseConnectorXCore::SendRawCommand(const uint8_t *data, size_t length)
  {
    BaseLumynDevice::SendRawCommand(data, length);
  }

  void BaseConnectorXCore::SendLEDCommand(const void *data, uint32_t length)
  {
    if (!data || length == 0)
      return;
    const auto *led = static_cast<const Command::LED::LEDCommand *>(data);
    Command::CommandHeader header{};
    header.type = Command::CommandType::LED;
    header.ledType = led->type;

    const void *payload = nullptr;
    uint32_t payload_len = 0;
    using Command::LED::LEDCommandType;
    switch (led->type)
    {
    case LEDCommandType::SetAnimation:
      payload = &led->data.setAnimation;
      payload_len = sizeof(led->data.setAnimation);
      break;
    case LEDCommandType::SetAnimationGroup:
      payload = &led->data.setAnimationGroup;
      payload_len = sizeof(led->data.setAnimationGroup);
      break;
    case LEDCommandType::SetColor:
      payload = &led->data.setColor;
      payload_len = sizeof(led->data.setColor);
      break;
    case LEDCommandType::SetColorGroup:
      payload = &led->data.setColorGroup;
      payload_len = sizeof(led->data.setColorGroup);
      break;
    case LEDCommandType::SetAnimationSequence:
      payload = &led->data.setAnimationSequence;
      payload_len = sizeof(led->data.setAnimationSequence);
      break;
    case LEDCommandType::SetAnimationSequenceGroup:
      payload = &led->data.setAnimationSequenceGroup;
      payload_len = sizeof(led->data.setAnimationSequenceGroup);
      break;
    case LEDCommandType::SetBitmap:
      payload = &led->data.setBitmap;
      payload_len = sizeof(led->data.setBitmap);
      break;
    case LEDCommandType::SetBitmapGroup:
      payload = &led->data.setBitmapGroup;
      payload_len = sizeof(led->data.setBitmapGroup);
      break;
    case LEDCommandType::SetMatrixText:
      payload = &led->data.setMatrixText;
      payload_len = sizeof(led->data.setMatrixText);
      break;
    case LEDCommandType::SetMatrixTextGroup:
      payload = &led->data.setMatrixTextGroup;
      payload_len = sizeof(led->data.setMatrixTextGroup);
      break;
    case LEDCommandType::SetDirectBuffer:
      payload = &led->data.setDirectBuffer;
      payload_len = sizeof(led->data.setDirectBuffer);
      break;
    default:
      payload = data;
      payload_len = length;
      break;
    }

    SendCommand(header, payload, payload_len);
  }

  void BaseConnectorXCore::StartEventPolling()
  {
    if (auto_poll_events_ && !poll_events_)
    {
      poll_events_ = true;
      event_thread_ = std::thread([this]()
                                  {
        while (poll_events_) {
          try {
            GetEvents();
            std::this_thread::sleep_for(std::chrono::milliseconds(22));
          } catch (...) {
          }
        } });
    }
  }

  void BaseConnectorXCore::StopEventPolling()
  {
    poll_events_ = false;
    if (event_thread_.joinable())
      event_thread_.join();
  }

  ConnectorXCore::ConnectorXCore()
      : BaseConnectorXCore(),
        BaseModuleDevice()
  {
  }

  ConnectorXCore::~ConnectorXCore() = default;

  BaseLumynDevice *ConnectorXCore::GetModuleBasePtr()
  {
    return this;
  }

  const BaseLumynDevice *ConnectorXCore::GetModuleBasePtr() const
  {
    return this;
  }

  ConnectorXCore &ConnectorXCore::SetAutoPollEvents(bool enabled)
  {
    BaseConnectorXCore::SetAutoPollEvents(enabled);
    return *this;
  }

  void ConnectorXCore::RestartDevice(uint32_t delay_ms)
  {
    BaseLumynDevice::Restart(delay_ms);
  }

  void ConnectorXCore::OnEvent(const Eventing::Event &evt)
  {
    (void)evt;
  }

  void *ConnectorXCore::GetBasePtr()
  {
    return this;
  }

  const void *ConnectorXCore::GetBasePtr() const
  {
    return this;
  }

  void ConnectorXCore::OnDisconnect()
  {
  }

  ConnectorXAnimateCore::ConnectorXAnimateCore()
      : BaseConnectorXCore()
  {
  }

  ConnectorXAnimateCore::~ConnectorXAnimateCore() = default;

  ConnectorXAnimateCore &ConnectorXAnimateCore::SetAutoPollEvents(bool enabled)
  {
    BaseConnectorXCore::SetAutoPollEvents(enabled);
    return *this;
  }

  void ConnectorXAnimateCore::OnEvent(const Eventing::Event &evt)
  {
    (void)evt;
  }

  void *ConnectorXAnimateCore::GetBasePtr()
  {
    return this;
  }

  const void *ConnectorXAnimateCore::GetBasePtr() const
  {
    return this;
  }
}

// =============================================================================
// BaseConnectorXVariant - Thin C++ wrapper around C API
// =============================================================================

namespace lumyn::device
{

  BaseConnectorXVariant::BaseConnectorXVariant()
      : c_base_ptr_(nullptr)
  {
  }

  BaseConnectorXVariant::~BaseConnectorXVariant() = default;

  lumyn_error_t BaseConnectorXVariant::Connect(const lumyn_serial_io_t &io)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    return lumyn_ConnectIO_internal(c_base_ptr_, &io);
  }

  lumyn_error_t BaseConnectorXVariant::Connect(const std::string &port, std::optional<int> baud)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    return baud.has_value()
               ? lumyn_ConnectWithBaud(c_base_ptr_, port.c_str(), baud.value())
               : lumyn_Connect(c_base_ptr_, port.c_str());
  }

  void BaseConnectorXVariant::Disconnect()
  {
    if (c_base_ptr_)
      lumyn_Disconnect(c_base_ptr_);
    OnDisconnect();
  }

  bool BaseConnectorXVariant::IsConnected() const
  {
    if (!c_base_ptr_)
      return false;
    return lumyn_IsConnected(c_base_ptr_);
  }

  lumyn::ConnectionStatus BaseConnectorXVariant::GetCurrentStatus() const
  {
    if (!c_base_ptr_)
      return lumyn::ConnectionStatus{false, false};
    auto c_status = lumyn_GetCurrentStatus(const_cast<cx_base_t *>(c_base_ptr_));
    return lumyn::ConnectionStatus{c_status.connected, c_status.enabled};
  }

  lumyn::Status BaseConnectorXVariant::GetDeviceHealth() const
  {
    if (!c_base_ptr_)
      return static_cast<lumyn::Status>(LUMYN_STATUS_UNKNOWN);
    return static_cast<lumyn::Status>(lumyn_GetDeviceHealth(const_cast<cx_base_t *>(c_base_ptr_)));
  }

  lumyn_error_t BaseConnectorXVariant::AddEventHandler(std::function<void(const lumyn::Event &)> handler)
  {
    if (!handler)
      return LUMYN_ERR_INVALID_ARGUMENT;
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    // Store handler and register C callback
    // Note: This is a simplified implementation - proper implementation would need handler storage
    return LUMYN_ERR_NOT_SUPPORTED; // TODO: Implement via lumyn_AddEventHandler
  }

  lumyn_error_t BaseConnectorXVariant::GetLatestEvent(lumyn_event_t &out_event)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    return lumyn_GetLatestEvent(c_base_ptr_, &out_event);
  }

  std::optional<lumyn::Event> BaseConnectorXVariant::GetLatestEvent()
  {
    if (!c_base_ptr_)
      return std::nullopt;
    lumyn_event_t c_evt{};
    if (lumyn_GetLatestEvent(c_base_ptr_, &c_evt) != LUMYN_OK)
      return std::nullopt;
    return internal::from_c_event(c_evt);
  }

  std::vector<lumyn::Event> BaseConnectorXVariant::GetEvents()
  {
    if (!c_base_ptr_)
      return {};
    // Get events via C API
    std::array<lumyn_event_t, 32> c_events{};
    int count = 0;
    if (lumyn_GetEvents(c_base_ptr_, c_events.data(), static_cast<int>(c_events.size()), &count) != LUMYN_OK)
      return {};
    std::vector<lumyn::Event> events;
    events.reserve(static_cast<size_t>(count));
    for (int i = 0; i < count; ++i)
    {
      events.push_back(internal::from_c_event(c_events[static_cast<size_t>(i)]));
    }
    return events;
  }

  void BaseConnectorXVariant::SetAutoPollEvents(bool enabled)
  {
    if (!c_base_ptr_)
      return;
    lumyn_SetAutoPollEvents(c_base_ptr_, enabled);
  }

  void BaseConnectorXVariant::PollEvents()
  {
    (void)GetEvents();
  }

  lumyn_error_t BaseConnectorXVariant::RequestConfig(std::string &out_json, uint32_t timeout_ms)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    char *json = nullptr;
    auto err = lumyn_RequestConfigAlloc(c_base_ptr_, &json, timeout_ms);
    if (err == LUMYN_OK && json)
    {
      out_json = json;
      LUMYN_SDK_FREE(json);
    }
    return err;
  }

  bool BaseConnectorXVariant::ApplyConfigurationJson(const std::string &json)
  {
    if (json.empty() || !c_base_ptr_)
      return false;
    return lumyn_ApplyConfig(c_base_ptr_, json.data(), json.size()) == LUMYN_OK;
  }

  bool BaseConnectorXVariant::LoadConfigurationFromFile(const std::string &path)
  {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open())
      return false;
    std::string contents((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    return ApplyConfigurationJson(contents);
  }

  void BaseConnectorXVariant::SetColor(std::string_view zone_id, ::lumyn_color_t color) const
  {
    if (!c_base_ptr_)
      return;
    lumyn_SetColor(const_cast<cx_base_t *>(c_base_ptr_), std::string(zone_id).c_str(), color);
  }

  void BaseConnectorXVariant::SetGroupColor(std::string_view group_id, ::lumyn_color_t color) const
  {
    if (!c_base_ptr_)
      return;
    lumyn_SetGroupColor(const_cast<cx_base_t *>(c_base_ptr_), std::string(group_id).c_str(), color);
  }

  AnimationBuilder BaseConnectorXVariant::SetAnimation(lumyn::led::Animation animation)
  {
    return AnimationBuilder(*this, animation);
  }

  ImageSequenceBuilder BaseConnectorXVariant::SetImageSequence(std::string_view sequence_id)
  {
    return ImageSequenceBuilder(*this, sequence_id);
  }

  void BaseConnectorXVariant::SetAnimationSequence(std::string_view zone_id, std::string_view sequence_id)
  {
    if (!c_base_ptr_)
      return;
    lumyn_SetAnimationSequence(c_base_ptr_, std::string(zone_id).c_str(), std::string(sequence_id).c_str());
  }

  void BaseConnectorXVariant::SetGroupAnimationSequence(std::string_view group_id, std::string_view sequence_id)
  {
    if (!c_base_ptr_)
      return;
    lumyn_SetGroupAnimationSequence(c_base_ptr_, std::string(group_id).c_str(), std::string(sequence_id).c_str());
  }

  MatrixTextBuilder BaseConnectorXVariant::SetText(std::string_view text)
  {
    return MatrixTextBuilder(*this, text);
  }

  lumyn_error_t BaseConnectorXVariant::SendDirectBuffer(std::string_view zone_id, const uint8_t *data, size_t length, bool delta)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    return lumyn_UpdateDirectBuffer(c_base_ptr_, std::string(zone_id).c_str(), data, length, delta);
  }

  lumyn_error_t BaseConnectorXVariant::SendDirectBuffer(uint16_t zone_hash, const uint8_t *data, size_t length, bool delta)
  {
    if (!c_base_ptr_)
      return LUMYN_ERR_INVALID_HANDLE;
    return lumyn_UpdateDirectBufferByHash(c_base_ptr_, zone_hash, data, length, delta);
  }

  DirectLED BaseConnectorXVariant::CreateDirectLED(std::string_view zone_id, size_t num_leds, int full_refresh_interval_ms)
  {
    return DirectLED(c_base_ptr_, zone_id, num_leds, full_refresh_interval_ms);
  }

  void BaseConnectorXVariant::SendRawCommand(const uint8_t *data, size_t length)
  {
    if (!c_base_ptr_)
      return;
    lumyn_SendRawCommand(c_base_ptr_, data, length);
  }

  void BaseConnectorXVariant::SendLEDCommand(const void *data, uint32_t length)
  {
    // This is now a no-op - builders use C API directly
    // Kept for API compatibility
    (void)data;
    (void)length;
  }

} // namespace lumyn::device
