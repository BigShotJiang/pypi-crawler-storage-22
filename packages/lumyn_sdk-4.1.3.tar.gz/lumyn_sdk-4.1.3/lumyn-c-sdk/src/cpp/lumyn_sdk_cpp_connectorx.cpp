#include "lumyn/Constants.h"  // Required for BuiltInAnimations.h (included via ConnectorX.hpp -> BaseConnectorXVariant.hpp -> AnimationBuilder.hpp)
#include "lumyn/cpp/connectorXVariant/ConnectorX.hpp"
#include "lumyn/cpp/modules/ModuleDataDispatcher.hpp"
#include "lumyn/c/lumyn_device.h"

#include <stdexcept>

namespace lumyn::device
{

  ConnectorX::ConnectorX()
      : BaseConnectorXVariant()
  {
    cx_t *handle = nullptr;
    const auto err = lumyn_CreateConnectorXAlloc(&handle);
    if (err != LUMYN_OK)
    {
      throw std::runtime_error(Lumyn_ErrorString(err));
    }
    c_handle_ = handle;
    owns_c_handle_ = true;
    SetCBasePtr(&handle->base);
  }

  ConnectorX::~ConnectorX()
  {
    if (module_dispatcher_)
    {
      module_dispatcher_->Stop();
    }
    ClearModuleCache();
    if (owns_c_handle_ && c_handle_)
    {
      lumyn_DestroyConnectorXAlloc(c_handle_);
    }
    c_handle_ = nullptr;
    SetCBasePtr(nullptr);
    connection_callback_.reset();
  }

  void ConnectorX::OnDisconnect()
  {
    if (module_dispatcher_)
    {
      module_dispatcher_->Stop();
    }
    ClearModuleCache();
  }

  ConnectorX &ConnectorX::SetAutoPollEvents(bool enabled)
  {
    BaseConnectorXVariant::SetAutoPollEvents(enabled);
    return *this;
  }

  void ConnectorX::RestartDevice(uint32_t delay_ms)
  {
    if (!GetCBasePtr())
      return;
    lumyn_RestartDevice(GetCBasePtr(), delay_ms);
  }

  lumyn::modules::ModuleDataDispatcher &ConnectorX::GetModuleDispatcher()
  {
    if (!module_dispatcher_)
    {
      module_dispatcher_ = std::make_unique<lumyn::modules::ModuleDataDispatcher>(*this, GetCBasePtr());
    }
    return *module_dispatcher_;
  }

  void ConnectorX::SetConnectionStateCallback(std::function<void(bool)> callback)
  {
    connection_callback_ = std::make_unique<std::function<void(bool)>>(std::move(callback));
    auto* c_ptr = GetCBasePtr();
    if (c_ptr)
    {
      lumyn_SetConnectionStateCallback(c_ptr, [](bool connected, void *user)
                                       {
      auto* fn = static_cast<std::function<void(bool)>*>(user);
      if (fn) (*fn)(connected); }, connection_callback_.get());
    }
  }

  lumyn_error_t ConnectorX::GetLatestModuleData(std::string_view module_id, std::vector<uint8_t> &out)
  {
    if (module_id.empty())
    {
      return LUMYN_ERR_INVALID_ARGUMENT;
    }
    if (!GetCBasePtr())
    {
      return LUMYN_ERR_INVALID_HANDLE;
    }

    EnsureModuleRegistered(module_id);
    if (PopModuleData(module_id, out))
    {
      return LUMYN_OK;
    }
    return LUMYN_ERR_TIMEOUT;
  }

  void ConnectorX::RegisterModule(std::string_view module_id, std::function<void(const std::vector<uint8_t> &)> callback)
  {
    EnsureModuleRegistered(module_id);
    if (callback)
    {
      std::lock_guard<std::mutex> lock(module_cache_mutex_);
      module_callbacks_[std::string(module_id)] = std::move(callback);
    }
  }

  void ConnectorX::SetModulePollingEnabled(bool enabled)
  {
    if (GetCBasePtr())
    {
      lumyn_SetModulePollingEnabled(GetCBasePtr(), enabled);
    }
  }

  void ConnectorX::PollModules()
  {
    if (GetCBasePtr())
    {
      lumyn_PollModules(GetCBasePtr());
    }
  }

  void ConnectorX::EnsureModuleRegistered(std::string_view module_id)
  {
    if (!GetCBasePtr() || module_id.empty())
    {
      return;
    }

    std::string key(module_id);
    {
      std::lock_guard<std::mutex> lock(module_cache_mutex_);
      if (registered_modules_.find(key) != registered_modules_.end())
      {
        return;
      }
    }

    if (lumyn_RegisterModule(GetCBasePtr(), key.c_str(), &ConnectorX::HandleModuleData, this) != LUMYN_OK)
    {
      return;
    }

    std::lock_guard<std::mutex> lock(module_cache_mutex_);
    registered_modules_.insert(std::move(key));
  }

  void ConnectorX::ClearModuleCache()
  {
    std::vector<std::string> registered;
    {
      std::lock_guard<std::mutex> lock(module_cache_mutex_);
      registered.assign(registered_modules_.begin(), registered_modules_.end());
      registered_modules_.clear();
      module_cache_.clear();
    }

    if (GetCBasePtr())
    {
      for (const auto &entry : registered)
      {
        lumyn_UnregisterModule(GetCBasePtr(), entry.c_str());
      }
    }
  }

  bool ConnectorX::PopModuleData(std::string_view module_id, std::vector<uint8_t> &out)
  {
    std::lock_guard<std::mutex> lock(module_cache_mutex_);
    auto it = module_cache_.find(std::string(module_id));
    if (it == module_cache_.end() || it->second.empty())
    {
      return false;
    }
    out = std::move(it->second.front());
    it->second.pop_front();
    if (it->second.empty())
    {
      module_cache_.erase(it);
    }
    return true;
  }

  void ConnectorX::HandleModuleData(const char *module_id, const uint8_t *data, size_t len, void *user)
  {
    if (!user || !module_id || !data || len == 0)
    {
      return;
    }

    auto *self = static_cast<ConnectorX *>(user);
    std::string id(module_id);
    std::vector<uint8_t> data_copy(data, data + len);
    
    std::function<void(const std::vector<uint8_t> &)> callback;
    {
      std::lock_guard<std::mutex> lock(self->module_cache_mutex_);
      // Store in cache for pull-based retrieval
      auto &queue = self->module_cache_[id];
      queue.emplace_back(data_copy);
      
      // Look up callback for this module
      auto cb_it = self->module_callbacks_.find(id);
      if (cb_it != self->module_callbacks_.end())
      {
        callback = cb_it->second;
      }
    }
    
    // Invoke callback outside of lock to avoid deadlocks
    if (callback)
    {
      callback(data_copy);
    }
  }

} // namespace lumyn::device
