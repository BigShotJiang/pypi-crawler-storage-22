"""
Comprehensive tests for configuration parsing from JSON fixture.

These tests verify that all configuration values are correctly parsed and
decoded from the JSON, especially bit-packed fields like matrix orientation.

The fixture file exercises all possible configuration combinations to ensure
the parsing layer doesn't return hardcoded defaults.
"""

import json
import pytest
from pathlib import Path
from lumyn_sdk import (
    ParseConfig,
    NetworkType,
    ZoneType,
    BitmapType,
)


@pytest.fixture
def comprehensive_config_json():
    """Load the comprehensive config JSON fixture."""
    fixture_path = Path(__file__).parent / "fixtures" / "comprehensive_config.json"
    with open(fixture_path, "r") as f:
        return f.read()


@pytest.fixture
def comprehensive_config_data():
    """Load the comprehensive config as a Python dict for comparison."""
    fixture_path = Path(__file__).parent / "fixtures" / "comprehensive_config.json"
    with open(fixture_path, "r") as f:
        return json.load(f)


@pytest.fixture
def parsed_config(comprehensive_config_json):
    """Parse the comprehensive config JSON."""
    config = ParseConfig(comprehensive_config_json)
    assert config is not None, "Failed to parse config JSON"
    return config


class TestComprehensiveConfigParsing:
    """Test parsing of all configuration fields from JSON fixture."""

    def test_team_number(self, parsed_config, comprehensive_config_data):
        """Test team number parsing."""
        assert parsed_config.teamNumber == comprehensive_config_data["team"]

    def test_network_mode_usb(self, parsed_config, comprehensive_config_data):
        """Test USB network mode parsing."""
        assert parsed_config.network.type == NetworkType.USB
        expected_mode = comprehensive_config_data["network"]["mode"]
        assert expected_mode == "USB"

    def test_channel_count(self, parsed_config, comprehensive_config_data):
        """Test channel count."""
        expected_count = len(comprehensive_config_data["channels"])
        assert len(parsed_config.channels) == expected_count

    def test_channel_properties(self, parsed_config, comprehensive_config_data):
        """Test channel properties."""
        channel = parsed_config.channels[0]
        expected = comprehensive_config_data["channels"]["0"]
        
        assert channel.id == expected["id"]
        assert channel.length == expected["length"]
        assert channel.brightness == expected["brightness"]
        assert len(channel.zones) == len(expected["zones"])


class TestStripZoneParsing:
    """Test strip zone parsing from JSON fixture."""

    def test_strip_forward(self, parsed_config, comprehensive_config_data):
        """Test forward strip zone parsing."""
        zones = parsed_config.channels[0].zones
        strip_forward = next(z for z in zones if z.id == "strip_forward")
        expected = next(z for z in comprehensive_config_data["channels"]["0"]["zones"] 
                       if z["id"] == "strip_forward")
        
        assert strip_forward.type == ZoneType.STRIP
        assert strip_forward.length == expected["length"]
        assert strip_forward.reversed == expected["reversed"]
        assert strip_forward.brightness == expected["brightness"]

    def test_strip_reversed(self, parsed_config, comprehensive_config_data):
        """Test reversed strip zone parsing."""
        zones = parsed_config.channels[0].zones
        strip_reversed = next(z for z in zones if z.id == "strip_reversed")
        expected = next(z for z in comprehensive_config_data["channels"]["0"]["zones"] 
                       if z["id"] == "strip_reversed")
        
        assert strip_reversed.type == ZoneType.STRIP
        assert strip_reversed.length == expected["length"]
        assert strip_reversed.reversed == expected["reversed"]
        assert strip_reversed.brightness == expected["brightness"]


class TestMatrixOrientationParsing:
    """
    Test matrix orientation parsing from JSON fixture.
    
    This is the critical test class that validates the orientation byte is
    correctly decoded, NOT returning hardcoded defaults.
    
    Orientation bit layout:
    - Bit 0: cornerTopBottom (0=top, 1=bottom)
    - Bit 1: cornerLeftRight (0=left, 1=right)
    - Bit 2: axisLayout (0=rows, 1=cols)
    - Bit 3: sequenceLayout (0=progressive, 1=zigzag)
    """

    def _get_zone_by_id(self, parsed_config, zone_id):
        """Helper to get a zone by ID."""
        for zone in parsed_config.channels[0].zones:
            if zone.id == zone_id:
                return zone
        raise ValueError(f"Zone {zone_id} not found")

    def _get_expected_zone(self, config_data, zone_id):
        """Helper to get expected zone data by ID."""
        for zone in config_data["channels"]["0"]["zones"]:
            if zone["id"] == zone_id:
                return zone
        raise ValueError(f"Zone {zone_id} not found in expected data")

    def test_matrix_top_left_rows_progressive(self, parsed_config, comprehensive_config_data):
        """Test top-left, rows, progressive matrix orientation."""
        zone_id = "matrix_tl_rows_prog"
        zone = self._get_zone_by_id(parsed_config, zone_id)
        expected = self._get_expected_zone(comprehensive_config_data, zone_id)
        
        assert zone.type == ZoneType.MATRIX
        assert zone.matrix_rows == expected["rows"]
        assert zone.matrix_cols == expected["cols"]
        assert zone.brightness == expected["brightness"]
        
        orientation = zone.matrix_orientation
        expected_orient = expected["orientation"]
        
        assert orientation["cornerTopBottom"] == expected_orient["cornerTopBottom"]
        assert orientation["cornerLeftRight"] == expected_orient["cornerLeftRight"]
        assert orientation["axisLayout"] == expected_orient["axisLayout"]
        assert orientation["sequenceLayout"] == expected_orient["sequenceLayout"]

    def test_matrix_top_left_rows_zigzag(self, parsed_config, comprehensive_config_data):
        """Test top-left, rows, zigzag matrix orientation."""
        zone_id = "matrix_tl_rows_zigzag"
        zone = self._get_zone_by_id(parsed_config, zone_id)
        expected = self._get_expected_zone(comprehensive_config_data, zone_id)
        
        assert zone.type == ZoneType.MATRIX
        assert zone.matrix_rows == expected["rows"]
        assert zone.matrix_cols == expected["cols"]
        
        orientation = zone.matrix_orientation
        expected_orient = expected["orientation"]
        
        assert orientation["cornerTopBottom"] == expected_orient["cornerTopBottom"]
        assert orientation["cornerLeftRight"] == expected_orient["cornerLeftRight"]
        assert orientation["axisLayout"] == expected_orient["axisLayout"]
        assert orientation["sequenceLayout"] == expected_orient["sequenceLayout"]

    def test_matrix_top_right_cols_progressive(self, parsed_config, comprehensive_config_data):
        """Test top-right, cols, progressive matrix orientation."""
        zone_id = "matrix_tr_cols_prog"
        zone = self._get_zone_by_id(parsed_config, zone_id)
        expected = self._get_expected_zone(comprehensive_config_data, zone_id)
        
        assert zone.type == ZoneType.MATRIX
        assert zone.matrix_rows == expected["rows"]
        assert zone.matrix_cols == expected["cols"]
        
        orientation = zone.matrix_orientation
        expected_orient = expected["orientation"]
        
        assert orientation["cornerTopBottom"] == expected_orient["cornerTopBottom"]
        assert orientation["cornerLeftRight"] == expected_orient["cornerLeftRight"]
        assert orientation["axisLayout"] == expected_orient["axisLayout"]
        assert orientation["sequenceLayout"] == expected_orient["sequenceLayout"]

    def test_matrix_bottom_left_rows_zigzag(self, parsed_config, comprehensive_config_data):
        """Test bottom-left, rows, zigzag matrix orientation."""
        zone_id = "matrix_bl_rows_zigzag"
        zone = self._get_zone_by_id(parsed_config, zone_id)
        expected = self._get_expected_zone(comprehensive_config_data, zone_id)
        
        assert zone.type == ZoneType.MATRIX
        assert zone.matrix_rows == expected["rows"]
        assert zone.matrix_cols == expected["cols"]
        
        orientation = zone.matrix_orientation
        expected_orient = expected["orientation"]
        
        assert orientation["cornerTopBottom"] == expected_orient["cornerTopBottom"]
        assert orientation["cornerLeftRight"] == expected_orient["cornerLeftRight"]
        assert orientation["axisLayout"] == expected_orient["axisLayout"]
        assert orientation["sequenceLayout"] == expected_orient["sequenceLayout"]

    def test_matrix_bottom_right_cols_zigzag(self, parsed_config, comprehensive_config_data):
        """Test bottom-right, cols, zigzag matrix orientation (all bits set)."""
        zone_id = "matrix_br_cols_zigzag"
        zone = self._get_zone_by_id(parsed_config, zone_id)
        expected = self._get_expected_zone(comprehensive_config_data, zone_id)
        
        assert zone.type == ZoneType.MATRIX
        assert zone.matrix_rows == expected["rows"]
        assert zone.matrix_cols == expected["cols"]
        
        orientation = zone.matrix_orientation
        expected_orient = expected["orientation"]
        
        # This orientation has ALL bits set (0x0F)
        # If the parsing returns defaults (top, left, rows, progressive),
        # this test will fail because the expected values are:
        # bottom, right, cols, zigzag
        assert orientation["cornerTopBottom"] == expected_orient["cornerTopBottom"]
        assert orientation["cornerLeftRight"] == expected_orient["cornerLeftRight"]
        assert orientation["axisLayout"] == expected_orient["axisLayout"]
        assert orientation["sequenceLayout"] == expected_orient["sequenceLayout"]


class TestSequenceParsing:
    """Test sequence parsing from JSON fixture."""

    def test_sequence_count(self, parsed_config, comprehensive_config_data):
        """Test sequence count."""
        expected_count = len(comprehensive_config_data["sequences"])
        assert len(parsed_config.sequences) == expected_count

    def test_startup_sequence(self, parsed_config, comprehensive_config_data):
        """Test startup sequence parsing."""
        seq = next(s for s in parsed_config.sequences if s.id == "startup_sequence")
        expected = next(s for s in comprehensive_config_data["sequences"] 
                       if s["id"] == "startup_sequence")
        
        assert len(seq.steps) == len(expected["steps"])

    def test_sequence_step_with_color(self, parsed_config, comprehensive_config_data):
        """Test sequence step with color parsing."""
        seq = next(s for s in parsed_config.sequences if s.id == "startup_sequence")
        expected_seq = next(s for s in comprehensive_config_data["sequences"] 
                          if s["id"] == "startup_sequence")
        
        step = seq.steps[0]
        expected = expected_seq["steps"][0]
        
        assert step.id == expected["animationId"]
        assert step.delay == expected["delay"]
        assert step.reversed == expected["reversed"]
        
        # Check color
        assert step.color is not None
        assert step.color.r == expected["color"]["r"]
        assert step.color.g == expected["color"]["g"]
        assert step.color.b == expected["color"]["b"]

    def test_sequence_step_reversed(self, parsed_config, comprehensive_config_data):
        """Test reversed sequence step parsing."""
        seq = next(s for s in parsed_config.sequences if s.id == "startup_sequence")
        expected_seq = next(s for s in comprehensive_config_data["sequences"] 
                          if s["id"] == "startup_sequence")
        
        # Second step has reversed=true
        step = seq.steps[1]
        expected = expected_seq["steps"][1]
        
        assert step.id == expected["animationId"]
        assert step.reversed == expected["reversed"]
        assert step.repeatCount == expected["repeat"]


class TestBitmapParsing:
    """Test bitmap parsing from JSON fixture."""

    def test_bitmap_count(self, parsed_config, comprehensive_config_data):
        """Test bitmap count."""
        expected_count = len(comprehensive_config_data["bitmaps"])
        assert len(parsed_config.bitmaps) == expected_count

    def test_static_bitmap(self, parsed_config, comprehensive_config_data):
        """Test static bitmap parsing."""
        bmp = next(b for b in parsed_config.bitmaps if b.id == "logo_static")
        expected = next(b for b in comprehensive_config_data["bitmaps"] 
                       if b["id"] == "logo_static")
        
        assert bmp.type == BitmapType.STATIC
        assert bmp.path == expected["path"]

    def test_animated_bitmap(self, parsed_config, comprehensive_config_data):
        """Test animated bitmap parsing."""
        bmp = next(b for b in parsed_config.bitmaps if b.id == "animation_frames")
        expected = next(b for b in comprehensive_config_data["bitmaps"] 
                       if b["id"] == "animation_frames")
        
        assert bmp.type == BitmapType.ANIMATED
        assert bmp.folder == expected["folder"]
        assert bmp.frameDelay == expected["delay"]


class TestModuleParsing:
    """Test module/sensor parsing from JSON fixture."""

    def test_module_count(self, parsed_config, comprehensive_config_data):
        """Test module count."""
        expected_count = len(comprehensive_config_data["sensors"])
        assert len(parsed_config.sensors) == expected_count

    def test_distance_sensor(self, parsed_config, comprehensive_config_data):
        """Test distance sensor module parsing."""
        module = next(m for m in parsed_config.sensors if m.id == "distance_sensor")
        expected = next(m for m in comprehensive_config_data["sensors"] 
                       if m["id"] == "distance_sensor")
        
        assert module.type == expected["type"]
        assert module.pollingRateMs == expected["pollingRateMs"]
        # connection_type returns string representation
        assert module.connection_type == expected["connection"]


class TestGroupParsing:
    """Test group parsing from JSON fixture."""

    def test_group_count(self, parsed_config, comprehensive_config_data):
        """Test group count."""
        expected_count = len(comprehensive_config_data["groups"])
        assert len(parsed_config.groups) == expected_count

    def test_all_strips_group(self, parsed_config, comprehensive_config_data):
        """Test all_strips group parsing."""
        group = next(g for g in parsed_config.groups if g.id == "all_strips")
        expected = next(g for g in comprehensive_config_data["groups"] 
                       if g["id"] == "all_strips")
        
        assert list(group.zoneIds) == expected["zoneIds"]

    def test_all_matrices_group(self, parsed_config, comprehensive_config_data):
        """Test all_matrices group parsing."""
        group = next(g for g in parsed_config.groups if g.id == "all_matrices")
        expected = next(g for g in comprehensive_config_data["groups"] 
                       if g["id"] == "all_matrices")
        
        assert list(group.zoneIds) == expected["zoneIds"]

    def test_all_zones_group(self, parsed_config, comprehensive_config_data):
        """Test all_zones group parsing."""
        group = next(g for g in parsed_config.groups if g.id == "all_zones")
        expected = next(g for g in comprehensive_config_data["groups"] 
                       if g["id"] == "all_zones")
        
        assert list(group.zoneIds) == expected["zoneIds"]
