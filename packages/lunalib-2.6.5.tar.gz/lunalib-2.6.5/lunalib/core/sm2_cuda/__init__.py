"""SM2 GPU acceleration package (CUDA)."""
