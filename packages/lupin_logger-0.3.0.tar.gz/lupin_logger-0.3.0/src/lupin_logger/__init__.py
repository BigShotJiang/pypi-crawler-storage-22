from .logger import CustomLogger, get_logger
from .logging_sync import get_synchronized_logger

__author__ = """LupinDental"""
__email__ = "contact@lupindental.com"
__all__ = ["CustomLogger", "get_logger", "get_synchronized_logger"]
