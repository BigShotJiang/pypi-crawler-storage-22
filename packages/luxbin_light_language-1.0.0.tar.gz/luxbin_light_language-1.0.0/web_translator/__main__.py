"""Allow running as: python -m web_translator"""
from .cli import main
main()
