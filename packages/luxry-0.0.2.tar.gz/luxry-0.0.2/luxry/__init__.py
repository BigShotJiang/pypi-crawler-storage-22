﻿print('Luxry package reserved for Xiaorui Lu.')
