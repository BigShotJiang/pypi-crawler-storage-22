﻿from setuptools import setup, find_packages
setup(
    name='luxry',
    version='0.0.2',
    description='Reserved by Xiaorui Lu (Lux/Rain).',
    author='Xiaorui Lu',
    author_email='rainrain2007@gmail.com',
    packages=find_packages(),
)
