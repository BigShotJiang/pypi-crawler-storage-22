"""Quick profiling script for test inversion performance."""
import time
import numpy as np
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from lwdid.inference.wild_bootstrap import (
    wild_cluster_bootstrap_test_inversion,
    _compute_bootstrap_pvalue_at_null_fast,
    _precompute_bootstrap_matrices,
    _estimate_ols_for_bootstrap,
)

def generate_data(N=500, G=30, seed=42):
    rng = np.random.default_rng(seed)
    cluster_sizes = [N // G] * G
    for i in range(N % G):
        cluster_sizes[i] += 1
    cluster_ids = np.repeat(np.arange(G), cluster_sizes)
    cluster_effects = rng.normal(0, 0.5, G)
    d = rng.binomial(1, 0.4, N).astype(float)
    y = 1.0 + 2.0 * d + cluster_effects[cluster_ids] + rng.normal(0, 1, N)
    return pd.DataFrame({'y_transformed': y, 'd': d, 'cluster': cluster_ids})

data = generate_data(N=500, G=30)

# Time a single _compute_bootstrap_pvalue_at_null_fast call
precomp = _precompute_bootstrap_matrices(data, 'y_transformed', 'd', 'cluster')
d_values = data['d'].values.astype(np.float64)
orig = _estimate_ols_for_bootstrap(data, 'y_transformed', 'd', 'cluster')

start = time.perf_counter()
pval = _compute_bootstrap_pvalue_at_null_fast(
    null_value=0.0, precomp=precomp, d_values=d_values,
    att_original=orig['att'], se_original=orig['se'],
    n_bootstrap=999, weight_type='rademacher', seed=42,
)
single_call = time.perf_counter() - start
print(f"Single _compute_bootstrap_pvalue_at_null_fast: {single_call:.3f}s")
print(f"Estimated for 35 calls: {single_call * 35:.1f}s")
print(f"N={precomp['N']}, G={precomp['G']}, k={precomp['k']}, B=999")
