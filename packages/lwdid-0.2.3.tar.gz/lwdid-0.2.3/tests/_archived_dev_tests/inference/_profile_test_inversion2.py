"""Profile the full test inversion to count function calls."""
import time
import numpy as np
import pandas as pd
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from lwdid.inference.wild_bootstrap import (
    wild_cluster_bootstrap_test_inversion,
)

def generate_data(N=500, G=30, seed=42):
    rng = np.random.default_rng(seed)
    cluster_sizes = [N // G] * G
    for i in range(N % G):
        cluster_sizes[i] += 1
    cluster_ids = np.repeat(np.arange(G), cluster_sizes)
    cluster_effects = rng.normal(0, 0.5, G)
    d = rng.binomial(1, 0.4, N).astype(float)
    y = 1.0 + 2.0 * d + cluster_effects[cluster_ids] + rng.normal(0, 1, N)
    return pd.DataFrame({'y_transformed': y, 'd': d, 'cluster': cluster_ids})

data = generate_data(N=500, G=30)

# Monkey-patch to count calls
import lwdid.inference.wild_bootstrap as wb_mod
original_fast = wb_mod._compute_bootstrap_pvalue_at_null_fast
call_count = [0]
call_times = []

def counting_wrapper(*args, **kwargs):
    call_count[0] += 1
    t0 = time.perf_counter()
    result = original_fast(*args, **kwargs)
    call_times.append(time.perf_counter() - t0)
    return result

wb_mod._compute_bootstrap_pvalue_at_null_fast = counting_wrapper

start = time.perf_counter()
result = wild_cluster_bootstrap_test_inversion(
    data=data,
    y_transformed='y_transformed',
    d='d',
    cluster_var='cluster',
    n_bootstrap=999,
    weight_type='rademacher',
    seed=42,
    grid_points=25,
    ci_tol=0.01,
)
total = time.perf_counter() - start

wb_mod._compute_bootstrap_pvalue_at_null_fast = original_fast

print(f"Total time: {total:.1f}s")
print(f"Fast function calls: {call_count[0]}")
print(f"Avg per call: {np.mean(call_times):.4f}s")
print(f"Sum of call times: {sum(call_times):.1f}s")
print(f"Overhead: {total - sum(call_times):.1f}s")
