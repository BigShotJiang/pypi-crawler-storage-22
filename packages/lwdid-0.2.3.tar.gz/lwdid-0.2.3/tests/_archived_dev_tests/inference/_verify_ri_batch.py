"""
快速验证 Task 7: 批量向量化路径 vs 循环路径的等价性。

验证点:
1. permutation 模式: batch atts == loop atts (逐元素)
2. bootstrap 模式: batch atts == loop atts (逐元素, 含 NaN 位置)
3. p-value 一致
4. 性能对比

使用方法:
    cd lwdid-py_v0.1.0
    python tests/inference/_verify_ri_batch.py
"""

import sys
import os
import time
import warnings

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from lwdid.randomization import randomization_inference


def generate_test_data(N=50, seed=42):
    """生成测试数据。"""
    rng = np.random.default_rng(seed)
    d = rng.binomial(1, 0.4, N).astype(int)
    if d.sum() < 2:
        d[:2] = 1
    if (N - d.sum()) < 2:
        d[-2:] = 0
    tau = 1.5
    y = 0.5 + tau * d + rng.normal(0, 1, N)
    return pd.DataFrame({
        'ydot_postavg': y,
        'd_': d,
        'ivar': np.arange(N),
    })


def verify_batch_vs_loop():
    """验证批量路径与循环路径的等价性。"""
    data = generate_test_data(N=50, seed=42)
    print(f"数据: N={len(data)}, N1={int(data['d_'].sum())}")

    for method in ['permutation', 'bootstrap']:
        print(f"\n{'='*50}")
        print(f"方法: {method}")
        print(f"{'='*50}")

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")

            # 批量路径（默认）
            t0 = time.perf_counter()
            result_batch = randomization_inference(
                firstpost_df=data,
                y_col='ydot_postavg', d_col='d_', ivar='ivar',
                rireps=1000, ri_method=method, seed=42,
                controls=None, _return_atts=True,
                _force_loop=False,
            )
            t_batch = time.perf_counter() - t0

            # 循环路径
            t0 = time.perf_counter()
            result_loop = randomization_inference(
                firstpost_df=data,
                y_col='ydot_postavg', d_col='d_', ivar='ivar',
                rireps=1000, ri_method=method, seed=42,
                controls=None, _return_atts=True,
                _force_loop=True,
            )
            t_loop = time.perf_counter() - t0

        atts_batch = result_batch['atts']
        atts_loop = result_loop['atts']

        # 检查 NaN 位置一致
        nan_batch = np.isnan(atts_batch)
        nan_loop = np.isnan(atts_loop)
        nan_match = np.array_equal(nan_batch, nan_loop)
        print(f"  NaN 位置一致: {nan_match}")
        if not nan_match:
            print(f"    batch NaN 数: {nan_batch.sum()}, loop NaN 数: {nan_loop.sum()}")

        # 检查有效值一致
        valid = ~nan_batch & ~nan_loop
        if valid.any():
            max_diff = np.max(np.abs(atts_batch[valid] - atts_loop[valid]))
            print(f"  有效值最大差异: {max_diff:.2e}")
            print(f"  有效值完全一致: {max_diff == 0.0}")
        else:
            print(f"  无有效值可比较")

        # p-value
        print(f"  p-value batch: {result_batch['p_value']}")
        print(f"  p-value loop:  {result_loop['p_value']}")
        print(f"  p-value 一致:  {result_batch['p_value'] == result_loop['p_value']}")

        # ri_valid / ri_failed
        print(f"  ri_valid batch: {result_batch['ri_valid']}, loop: {result_loop['ri_valid']}")
        print(f"  ri_failed batch: {result_batch['ri_failed']}, loop: {result_loop['ri_failed']}")

        # 性能
        print(f"  时间 batch: {t_batch:.4f}s, loop: {t_loop:.4f}s")
        if t_batch > 0:
            speedup = t_loop / t_batch
            print(f"  加速比: {speedup:.1f}x")


if __name__ == '__main__':
    verify_batch_vs_loop()
