"""
快速验证 Task 8: 有控制变量 RI 的性能提升。

对比 np.linalg.lstsq 路径 vs 旧的 sm.OLS 路径（通过参考数据验证正确性）。

使用方法:
    cd lwdid-py_v0.1.0
    python tests/inference/_verify_ri_controls_perf.py
"""

import sys
import os
import time
import warnings

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from lwdid.randomization import randomization_inference


def generate_test_data(N=50, seed=42):
    """生成有控制变量的测试数据。"""
    rng = np.random.default_rng(seed)
    d = rng.binomial(1, 0.4, N).astype(int)
    if d.sum() < 2:
        d[:2] = 1
    if (N - d.sum()) < 2:
        d[-2:] = 0
    tau = 1.5
    y = 0.5 + tau * d + rng.normal(0, 1, N)
    x1 = rng.normal(0, 1, N)
    x2 = rng.normal(0, 1, N)
    y_with_ctrl = y + 0.3 * x1 - 0.2 * x2
    return pd.DataFrame({
        'ydot_postavg': y_with_ctrl,
        'd_': d,
        'ivar': np.arange(N),
        'x1': x1,
        'x2': x2,
    })


def main():
    data = generate_test_data(N=50, seed=42)
    print(f"数据: N={len(data)}, N1={int(data['d_'].sum())}, K=2")

    for method in ['permutation', 'bootstrap']:
        print(f"\n方法: {method}")

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")

            # 有控制变量
            start = time.perf_counter()
            result = randomization_inference(
                firstpost_df=data,
                y_col='ydot_postavg', d_col='d_', ivar='ivar',
                rireps=1000, ri_method=method, seed=42,
                controls=['x1', 'x2'], _return_atts=True,
            )
            elapsed = time.perf_counter() - start

        print(f"  时间: {elapsed:.3f}s")
        print(f"  p_value: {result['p_value']}")
        print(f"  ri_valid: {result['ri_valid']}, ri_failed: {result['ri_failed']}")

        atts = result['atts']
        valid = atts[~np.isnan(atts)]
        print(f"  ATT 范围: [{valid.min():.6f}, {valid.max():.6f}]")


if __name__ == '__main__':
    main()
