"""验证 RI 快速路径（无控制变量直接计算）与参考数据完全一致。"""
import json
import os
import sys
import warnings

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'src'))

from lwdid.randomization import randomization_inference


def generate_ri_test_data(N=50, seed=42, with_controls=False):
    """与参考数据生成脚本完全相同的数据生成逻辑。"""
    rng = np.random.default_rng(seed)
    d = rng.binomial(1, 0.4, N).astype(int)
    if d.sum() < 2:
        d[:2] = 1
    if (N - d.sum()) < 2:
        d[-2:] = 0
    tau = 1.5
    y = 0.5 + tau * d + rng.normal(0, 1, N)
    data = pd.DataFrame({
        'ydot_postavg': y,
        'd_': d,
        'ivar': np.arange(N),
    })
    if with_controls:
        x1 = rng.normal(0, 1, N)
        x2 = rng.normal(0, 1, N)
        data['ydot_postavg'] = y + 0.3 * x1 - 0.2 * x2
        data['x1'] = x1
        data['x2'] = x2
    return data


def main():
    ref_path = os.path.join(os.path.dirname(__file__), 'reference_data', 'ri_reference.json')
    with open(ref_path) as f:
        ref = json.load(f)

    data_no_ctrl = generate_ri_test_data(N=50, seed=42, with_controls=False)

    # 场景 1: permutation, 无控制变量
    print("验证场景 1: permutation, 无控制变量...")
    result = randomization_inference(
        firstpost_df=data_no_ctrl,
        y_col='ydot_postavg', d_col='d_', ivar='ivar',
        rireps=1000, ri_method='permutation', seed=42,
        controls=None, _return_atts=True,
    )
    ref_atts = np.array(ref['permutation_no_controls']['atts'])
    new_atts = result['atts']
    max_diff = np.max(np.abs(ref_atts - new_atts))
    print(f"  atts max_diff = {max_diff:.2e}")
    print(f"  p_value: ref={ref['permutation_no_controls']['p_value']}, new={result['p_value']}")
    assert max_diff < 1e-12, f"permutation_no_controls atts 不一致: max_diff={max_diff}"
    assert result['p_value'] == ref['permutation_no_controls']['p_value']
    print("  ✓ 通过")

    # 场景 2: bootstrap, 无控制变量
    print("验证场景 2: bootstrap, 无控制变量...")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = randomization_inference(
            firstpost_df=data_no_ctrl,
            y_col='ydot_postavg', d_col='d_', ivar='ivar',
            rireps=1000, ri_method='bootstrap', seed=42,
            controls=None, _return_atts=True,
        )
    ref_atts = np.array(ref['bootstrap_no_controls']['atts'])
    new_atts = result['atts']
    # bootstrap 可能有 NaN，只比较有效值
    valid_mask = ~np.isnan(ref_atts) & ~np.isnan(new_atts)
    max_diff = np.max(np.abs(ref_atts[valid_mask] - new_atts[valid_mask]))
    print(f"  atts max_diff = {max_diff:.2e} (有效 {valid_mask.sum()} 个)")
    print(f"  p_value: ref={ref['bootstrap_no_controls']['p_value']}, new={result['p_value']}")
    assert max_diff < 1e-12, f"bootstrap_no_controls atts 不一致: max_diff={max_diff}"
    assert result['p_value'] == ref['bootstrap_no_controls']['p_value']
    print("  ✓ 通过")

    # 场景 3: permutation, 有控制变量（应走 OLS 路径，不受快速路径影响）
    print("验证场景 3: permutation, 有控制变量...")
    data_ctrl = generate_ri_test_data(N=50, seed=42, with_controls=True)
    result = randomization_inference(
        firstpost_df=data_ctrl,
        y_col='ydot_postavg', d_col='d_', ivar='ivar',
        rireps=1000, ri_method='permutation', seed=42,
        controls=['x1', 'x2'], _return_atts=True,
    )
    ref_atts = np.array(ref['permutation_with_controls']['atts'])
    new_atts = result['atts']
    max_diff = np.max(np.abs(ref_atts - new_atts))
    print(f"  atts max_diff = {max_diff:.2e}")
    assert max_diff < 1e-10, f"permutation_with_controls atts 不一致: max_diff={max_diff}"
    assert result['p_value'] == ref['permutation_with_controls']['p_value']
    print("  ✓ 通过")

    # 场景 4: bootstrap, 有控制变量
    print("验证场景 4: bootstrap, 有控制变量...")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = randomization_inference(
            firstpost_df=data_ctrl,
            y_col='ydot_postavg', d_col='d_', ivar='ivar',
            rireps=1000, ri_method='bootstrap', seed=42,
            controls=['x1', 'x2'], _return_atts=True,
        )
    ref_atts = np.array(ref['bootstrap_with_controls']['atts'])
    new_atts = result['atts']
    valid_mask = ~np.isnan(ref_atts) & ~np.isnan(new_atts)
    max_diff = np.max(np.abs(ref_atts[valid_mask] - new_atts[valid_mask]))
    print(f"  atts max_diff = {max_diff:.2e} (有效 {valid_mask.sum()} 个)")
    assert max_diff < 1e-10, f"bootstrap_with_controls atts 不一致: max_diff={max_diff}"
    assert result['p_value'] == ref['bootstrap_with_controls']['p_value']
    print("  ✓ 通过")

    print("\n全部 4 个场景验证通过!")


if __name__ == '__main__':
    main()
