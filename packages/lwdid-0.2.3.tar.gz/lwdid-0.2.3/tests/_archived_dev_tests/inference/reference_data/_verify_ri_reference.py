"""
Verify RI reference data reproducibility.

Loads the saved reference data and re-generates it from scratch,
then compares element-wise to confirm deterministic reproducibility.
"""

import json
import os
import sys
import warnings

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

from generate_ri_reference import generate_ri_test_data
from lwdid.randomization import randomization_inference


def verify():
    """Verify that saved reference data is reproducible."""
    ref_path = os.path.join(os.path.dirname(__file__), 'ri_reference.json')
    with open(ref_path, 'r') as f:
        saved = json.load(f)

    scenarios = [
        ('permutation_no_controls', 'permutation', False),
        ('bootstrap_no_controls', 'bootstrap', False),
        ('permutation_with_controls', 'permutation', True),
        ('bootstrap_with_controls', 'bootstrap', True),
    ]

    all_pass = True
    for key, method, with_ctrl in scenarios:
        print(f"\nVerifying: {key}")
        ref = saved[key]

        data = generate_ri_test_data(N=50, seed=42, with_controls=with_ctrl)
        controls = ['x1', 'x2'] if with_ctrl else None

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = randomization_inference(
                firstpost_df=data,
                y_col='ydot_postavg',
                d_col='d_',
                ivar='ivar',
                rireps=1000,
                ri_method=method,
                seed=42,
                controls=controls,
                _return_atts=True,
            )

        # Compare p_value
        if result['p_value'] != ref['p_value']:
            print(f"  FAIL: p_value mismatch: {result['p_value']} vs {ref['p_value']}")
            all_pass = False
        else:
            print(f"  OK: p_value = {ref['p_value']}")

        # Compare ri_valid / ri_failed
        if result['ri_valid'] != ref['ri_valid']:
            print(f"  FAIL: ri_valid mismatch: {result['ri_valid']} vs {ref['ri_valid']}")
            all_pass = False
        else:
            print(f"  OK: ri_valid = {ref['ri_valid']}")

        if result['ri_failed'] != ref['ri_failed']:
            print(f"  FAIL: ri_failed mismatch: {result['ri_failed']} vs {ref['ri_failed']}")
            all_pass = False
        else:
            print(f"  OK: ri_failed = {ref['ri_failed']}")

        # Compare atts array element-wise
        # Use rtol=1e-10 to accommodate machine-epsilon floating-point
        # differences that arise from JSON serialization round-trips
        atts_saved = np.array(ref['atts'])
        atts_new = result['atts']
        try:
            np.testing.assert_allclose(atts_new, atts_saved, rtol=1e-10)
            print(f"  OK: atts array matches (1000 elements, rtol=1e-10)")
        except AssertionError as e:
            print(f"  FAIL: atts mismatch: {e}")
            all_pass = False

    if all_pass:
        print("\n✓ All 4 scenarios verified: reference data is reproducible.")
    else:
        print("\n✗ Some scenarios failed verification!")
    return all_pass


if __name__ == '__main__':
    ok = verify()
    sys.exit(0 if ok else 1)
