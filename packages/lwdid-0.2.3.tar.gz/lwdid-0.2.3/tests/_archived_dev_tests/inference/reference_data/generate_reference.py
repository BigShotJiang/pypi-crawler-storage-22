"""
生成 Wild Bootstrap 和 Test Inversion CI 优化前参考结果。

在进行任何性能优化之前运行此脚本，保存完整的数值结果作为回归测试基准。
这是确保"数值不变"约束的关键步骤。

使用方法:
    cd lwdid-py_v0.1.0
    python tests/inference/reference_data/generate_reference.py
"""

import json
import os
import sys
import numpy as np
import pandas as pd

# 确保可以导入 lwdid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

from lwdid.inference.wild_bootstrap import (
    wild_cluster_bootstrap,
    wild_cluster_bootstrap_test_inversion,
)


def generate_test_data(N=200, G=10, seed=42):
    """
    生成用于 Wild Bootstrap 测试的合成数据。
    
    模拟已经过 rolling 变换的横截面数据，
    包含 y_transformed, d, cluster 列。
    
    Parameters
    ----------
    N : int
        总观测数
    G : int
        聚类数
    seed : int
        随机种子
    
    Returns
    -------
    pd.DataFrame
        包含 y_transformed, d, cluster 列的数据框
    """
    rng = np.random.default_rng(seed)
    
    # 聚类分配（均匀分配）
    cluster_sizes = [N // G] * G
    for i in range(N % G):
        cluster_sizes[i] += 1
    cluster_ids = np.repeat(np.arange(G), cluster_sizes)
    
    # 聚类效应
    cluster_effects = rng.normal(0, 0.5, G)
    
    # 处理变量（约 40% 被处理）
    d = rng.binomial(1, 0.4, N).astype(float)
    
    # 结果变量（含处理效应 tau=2.0）
    tau = 2.0
    y = 1.0 + tau * d + cluster_effects[cluster_ids] + rng.normal(0, 1, N)
    
    data = pd.DataFrame({
        'y_transformed': y,
        'd': d,
        'cluster': cluster_ids,
    })
    
    return data


def generate_wild_bootstrap_reference():
    """
    生成 Wild Bootstrap 优化前参考结果。
    
    覆盖 6 个场景:
    1. impose_null=True, rademacher
    2. impose_null=True, mammen
    3. impose_null=True, webb
    4. impose_null=False, rademacher
    5. impose_null=False, mammen
    6. impose_null=False, webb
    """
    print("=" * 60)
    print("生成 Wild Bootstrap 参考数据")
    print("=" * 60)
    
    data = generate_test_data(N=200, G=10, seed=42)
    print(f"测试数据: N={len(data)}, G={data['cluster'].nunique()}")
    print(f"处理组: {int(data['d'].sum())}, 控制组: {int((1 - data['d']).sum())}")
    
    scenarios = [
        {'impose_null': True,  'weight_type': 'rademacher', 'name': 'impose_null_true_rademacher'},
        {'impose_null': True,  'weight_type': 'mammen',     'name': 'impose_null_true_mammen'},
        {'impose_null': True,  'weight_type': 'webb',       'name': 'impose_null_true_webb'},
        {'impose_null': False, 'weight_type': 'rademacher', 'name': 'impose_null_false_rademacher'},
        {'impose_null': False, 'weight_type': 'mammen',     'name': 'impose_null_false_mammen'},
        {'impose_null': False, 'weight_type': 'webb',       'name': 'impose_null_false_webb'},
    ]
    
    all_references = {}
    
    for scenario in scenarios:
        print(f"\n场景: {scenario['name']}")
        print(f"  impose_null={scenario['impose_null']}, weight_type={scenario['weight_type']}")
        
        result = wild_cluster_bootstrap(
            data=data,
            y_transformed='y_transformed',
            d='d',
            cluster_var='cluster',
            controls=None,
            n_bootstrap=999,
            weight_type=scenario['weight_type'],
            impose_null=scenario['impose_null'],
            alpha=0.05,
            seed=42,
            full_enumeration=False,  # 强制使用随机抽样（非完全枚举）
        )
        
        ref = {
            'att': float(result.att),
            'se_bootstrap': float(result.se_bootstrap),
            'pvalue': float(result.pvalue),
            'ci_lower': float(result.ci_lower),
            'ci_upper': float(result.ci_upper),
            't_stat_original': float(result.t_stat_original),
            'n_clusters': int(result.n_clusters),
            'n_bootstrap': int(result.n_bootstrap),
            'weight_type': result.weight_type,
            # 完整的 t_stats_bootstrap 数组（用于逐元素比较）
            't_stats_bootstrap': result.t_stats_bootstrap.tolist(),
        }
        
        all_references[scenario['name']] = ref
        
        print(f"  ATT = {ref['att']:.6f}")
        print(f"  SE  = {ref['se_bootstrap']:.6f}")
        print(f"  p   = {ref['pvalue']:.4f}")
        print(f"  CI  = [{ref['ci_lower']:.6f}, {ref['ci_upper']:.6f}]")
        print(f"  t_orig = {ref['t_stat_original']:.6f}")
        print(f"  t_stats 长度 = {len(ref['t_stats_bootstrap'])}")
        
        # 验证 t_stats 数组非空且无全 NaN
        t_arr = np.array(ref['t_stats_bootstrap'])
        n_valid = int(np.sum(~np.isnan(t_arr)))
        print(f"  有效 t_stats = {n_valid}/{len(t_arr)}")
    
    # 添加测试数据生成参数（用于重现）
    all_references['_metadata'] = {
        'data_params': {'N': 200, 'G': 10, 'seed': 42},
        'bootstrap_params': {'n_bootstrap': 999, 'alpha': 0.05, 'seed': 42},
        'description': 'Wild Bootstrap 优化前参考结果，用于数值回归测试',
    }
    
    return all_references


def generate_test_inversion_reference():
    """
    生成 Test Inversion CI 优化前参考结果。
    
    Test Inversion CI 计算量大（~35 次完整 bootstrap），
    使用较小的数据集和较少的 bootstrap 次数。
    """
    print("\n" + "=" * 60)
    print("生成 Test Inversion CI 参考数据")
    print("=" * 60)
    
    # 使用较小数据集以控制运行时间
    data = generate_test_data(N=100, G=8, seed=42)
    print(f"测试数据: N={len(data)}, G={data['cluster'].nunique()}")
    print(f"处理组: {int(data['d'].sum())}, 控制组: {int((1 - data['d']).sum())}")
    
    print("\n运行 Test Inversion CI（这可能需要几分钟）...")
    
    result = wild_cluster_bootstrap_test_inversion(
        data=data,
        y_transformed='y_transformed',
        d='d',
        cluster_var='cluster',
        controls=None,
        n_bootstrap=499,  # 较少的 bootstrap 次数以控制时间
        weight_type='rademacher',
        alpha=0.05,
        seed=42,
        grid_points=15,  # 较少的网格点以控制时间
        ci_tol=0.01,
    )
    
    reference = {
        'att': float(result.att),
        'ci_lower': float(result.ci_lower),
        'ci_upper': float(result.ci_upper),
        'pvalue': float(result.pvalue),
        'se_bootstrap': float(result.se_bootstrap),
        't_stat_original': float(result.t_stat_original),
        'n_clusters': int(result.n_clusters),
        'ci_method': result.ci_method,
        '_metadata': {
            'data_params': {'N': 100, 'G': 8, 'seed': 42},
            'bootstrap_params': {
                'n_bootstrap': 499,
                'weight_type': 'rademacher',
                'alpha': 0.05,
                'seed': 42,
                'grid_points': 15,
                'ci_tol': 0.01,
            },
            'description': 'Test Inversion CI 优化前参考结果',
        },
    }
    
    print(f"  ATT      = {reference['att']:.6f}")
    print(f"  CI       = [{reference['ci_lower']:.6f}, {reference['ci_upper']:.6f}]")
    print(f"  p-value  = {reference['pvalue']:.4f}")
    print(f"  SE       = {reference['se_bootstrap']:.6f}")
    print(f"  t_orig   = {reference['t_stat_original']:.6f}")
    print(f"  CI方法   = {reference['ci_method']}")
    
    return reference


def main():
    """主函数：生成所有参考数据并保存。"""
    # 确保输出目录存在
    output_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. 生成 Wild Bootstrap 参考数据
    wb_reference = generate_wild_bootstrap_reference()
    
    wb_path = os.path.join(output_dir, 'wild_bootstrap_reference.json')
    with open(wb_path, 'w', encoding='utf-8') as f:
        json.dump(wb_reference, f, indent=2, ensure_ascii=False)
    print(f"\n✓ Wild Bootstrap 参考数据已保存到: {wb_path}")
    
    # 2. 生成 Test Inversion CI 参考数据
    ti_reference = generate_test_inversion_reference()
    
    ti_path = os.path.join(output_dir, 'test_inversion_reference.json')
    with open(ti_path, 'w', encoding='utf-8') as f:
        json.dump(ti_reference, f, indent=2, ensure_ascii=False)
    print(f"\n✓ Test Inversion CI 参考数据已保存到: {ti_path}")
    
    # 汇总
    print("\n" + "=" * 60)
    print("参考数据生成完成")
    print("=" * 60)
    print(f"Wild Bootstrap: {len(wb_reference) - 1} 个场景")  # -1 排除 _metadata
    print(f"Test Inversion: 1 个场景")
    print(f"输出目录: {output_dir}")


if __name__ == '__main__':
    main()
