"""
生成 Randomization Inference 优化前参考结果。

在进行任何 RI 性能优化之前运行此脚本，保存完整的数值结果作为回归测试基准。
覆盖 4 个场景:
  1. permutation, 无控制变量
  2. bootstrap, 无控制变量
  3. permutation, 有控制变量
  4. bootstrap, 有控制变量

使用方法:
    cd lwdid-py_v0.1.0
    python tests/inference/reference_data/generate_ri_reference.py
"""

import json
import os
import sys
import warnings

import numpy as np
import pandas as pd

# 确保可以导入 lwdid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

from lwdid.randomization import randomization_inference
from lwdid.estimation import prepare_controls


def generate_ri_test_data(N=50, seed=42, with_controls=False):
    """
    生成用于 RI 测试的合成横截面数据。

    模拟已经过 rolling 变换的 firstpost 横截面数据，
    包含 ydot_postavg, d_, ivar 列。

    Parameters
    ----------
    N : int
        总观测数（单位数）
    seed : int
        随机种子
    with_controls : bool
        是否生成控制变量 x1, x2

    Returns
    -------
    pd.DataFrame
        包含 ydot_postavg, d_, ivar 列（及可选的 x1, x2）的数据框
    """
    rng = np.random.default_rng(seed)

    # 处理变量（约 40% 被处理）
    d = rng.binomial(1, 0.4, N).astype(int)

    # 确保至少有 2 个处理和 2 个控制
    if d.sum() < 2:
        d[:2] = 1
    if (N - d.sum()) < 2:
        d[-2:] = 0

    # 结果变量（含处理效应 tau=1.5）
    tau = 1.5
    y = 0.5 + tau * d + rng.normal(0, 1, N)

    data = pd.DataFrame({
        'ydot_postavg': y,
        'd_': d,
        'ivar': np.arange(N),
    })

    if with_controls:
        # 生成两个控制变量
        x1 = rng.normal(0, 1, N)
        x2 = rng.normal(0, 1, N)
        # 让控制变量与结果有一定相关性
        data['ydot_postavg'] = y + 0.3 * x1 - 0.2 * x2
        data['x1'] = x1
        data['x2'] = x2

    return data


def generate_ri_reference():
    """生成 RI 优化前参考结果（4 个场景）。"""
    print("=" * 60)
    print("生成 Randomization Inference 参考数据")
    print("=" * 60)

    all_references = {}

    # =========================================================================
    # 场景 1: permutation, 无控制变量
    # =========================================================================
    print("\n场景 1: permutation, 无控制变量")
    data_no_ctrl = generate_ri_test_data(N=50, seed=42, with_controls=False)
    print(f"  数据: N={len(data_no_ctrl)}, "
          f"N1={int(data_no_ctrl['d_'].sum())}, "
          f"N0={int((1 - data_no_ctrl['d_']).sum())}")

    result_perm = randomization_inference(
        firstpost_df=data_no_ctrl,
        y_col='ydot_postavg',
        d_col='d_',
        ivar='ivar',
        rireps=1000,
        ri_method='permutation',
        seed=42,
        controls=None,
        _return_atts=True,
    )

    ref_perm = {
        'p_value': float(result_perm['p_value']),
        'ri_valid': int(result_perm['ri_valid']),
        'ri_failed': int(result_perm['ri_failed']),
        'ri_failure_rate': float(result_perm['ri_failure_rate']),
        'atts': result_perm['atts'].tolist(),
    }
    all_references['permutation_no_controls'] = ref_perm
    print(f"  p_value = {ref_perm['p_value']:.4f}")
    print(f"  ri_valid = {ref_perm['ri_valid']}, ri_failed = {ref_perm['ri_failed']}")
    atts_arr = np.array(ref_perm['atts'])
    n_valid = int(np.sum(~np.isnan(atts_arr)))
    print(f"  atts: {len(ref_perm['atts'])} 个, 有效 {n_valid} 个")
    print(f"  atts 范围: [{np.nanmin(atts_arr):.6f}, {np.nanmax(atts_arr):.6f}]")

    # =========================================================================
    # 场景 2: bootstrap, 无控制变量
    # =========================================================================
    print("\n场景 2: bootstrap, 无控制变量")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_boot = randomization_inference(
            firstpost_df=data_no_ctrl,
            y_col='ydot_postavg',
            d_col='d_',
            ivar='ivar',
            rireps=1000,
            ri_method='bootstrap',
            seed=42,
            controls=None,
            _return_atts=True,
        )

    ref_boot = {
        'p_value': float(result_boot['p_value']),
        'ri_valid': int(result_boot['ri_valid']),
        'ri_failed': int(result_boot['ri_failed']),
        'ri_failure_rate': float(result_boot['ri_failure_rate']),
        'atts': result_boot['atts'].tolist(),
    }
    all_references['bootstrap_no_controls'] = ref_boot
    print(f"  p_value = {ref_boot['p_value']:.4f}")
    print(f"  ri_valid = {ref_boot['ri_valid']}, ri_failed = {ref_boot['ri_failed']}")
    atts_arr = np.array(ref_boot['atts'])
    n_valid = int(np.sum(~np.isnan(atts_arr)))
    print(f"  atts: {len(ref_boot['atts'])} 个, 有效 {n_valid} 个")

    # =========================================================================
    # 场景 3: permutation, 有控制变量
    # =========================================================================
    print("\n场景 3: permutation, 有控制变量")
    data_ctrl = generate_ri_test_data(N=50, seed=42, with_controls=True)
    print(f"  数据: N={len(data_ctrl)}, "
          f"N1={int(data_ctrl['d_'].sum())}, "
          f"N0={int((1 - data_ctrl['d_']).sum())}")

    result_perm_ctrl = randomization_inference(
        firstpost_df=data_ctrl,
        y_col='ydot_postavg',
        d_col='d_',
        ivar='ivar',
        rireps=1000,
        ri_method='permutation',
        seed=42,
        controls=['x1', 'x2'],
        _return_atts=True,
    )

    ref_perm_ctrl = {
        'p_value': float(result_perm_ctrl['p_value']),
        'ri_valid': int(result_perm_ctrl['ri_valid']),
        'ri_failed': int(result_perm_ctrl['ri_failed']),
        'ri_failure_rate': float(result_perm_ctrl['ri_failure_rate']),
        'atts': result_perm_ctrl['atts'].tolist(),
    }
    all_references['permutation_with_controls'] = ref_perm_ctrl
    print(f"  p_value = {ref_perm_ctrl['p_value']:.4f}")
    print(f"  ri_valid = {ref_perm_ctrl['ri_valid']}, ri_failed = {ref_perm_ctrl['ri_failed']}")
    atts_arr = np.array(ref_perm_ctrl['atts'])
    n_valid = int(np.sum(~np.isnan(atts_arr)))
    print(f"  atts: {len(ref_perm_ctrl['atts'])} 个, 有效 {n_valid} 个")

    # =========================================================================
    # 场景 4: bootstrap, 有控制变量
    # =========================================================================
    print("\n场景 4: bootstrap, 有控制变量")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_boot_ctrl = randomization_inference(
            firstpost_df=data_ctrl,
            y_col='ydot_postavg',
            d_col='d_',
            ivar='ivar',
            rireps=1000,
            ri_method='bootstrap',
            seed=42,
            controls=['x1', 'x2'],
            _return_atts=True,
        )

    ref_boot_ctrl = {
        'p_value': float(result_boot_ctrl['p_value']),
        'ri_valid': int(result_boot_ctrl['ri_valid']),
        'ri_failed': int(result_boot_ctrl['ri_failed']),
        'ri_failure_rate': float(result_boot_ctrl['ri_failure_rate']),
        'atts': result_boot_ctrl['atts'].tolist(),
    }
    all_references['bootstrap_with_controls'] = ref_boot_ctrl
    print(f"  p_value = {ref_boot_ctrl['p_value']:.4f}")
    print(f"  ri_valid = {ref_boot_ctrl['ri_valid']}, ri_failed = {ref_boot_ctrl['ri_failed']}")
    atts_arr = np.array(ref_boot_ctrl['atts'])
    n_valid = int(np.sum(~np.isnan(atts_arr)))
    print(f"  atts: {len(ref_boot_ctrl['atts'])} 个, 有效 {n_valid} 个")

    # =========================================================================
    # 元数据
    # =========================================================================
    all_references['_metadata'] = {
        'data_params_no_controls': {'N': 50, 'seed': 42, 'with_controls': False},
        'data_params_with_controls': {'N': 50, 'seed': 42, 'with_controls': True},
        'ri_params': {'rireps': 1000, 'seed': 42},
        'description': 'RI 优化前参考结果，用于数值回归测试',
    }

    return all_references


def main():
    """主函数：生成 RI 参考数据并保存。"""
    output_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(output_dir, exist_ok=True)

    ri_reference = generate_ri_reference()

    ri_path = os.path.join(output_dir, 'ri_reference.json')
    with open(ri_path, 'w', encoding='utf-8') as f:
        json.dump(ri_reference, f, indent=2, ensure_ascii=False)
    print(f"\n✓ RI 参考数据已保存到: {ri_path}")

    # 汇总
    print("\n" + "=" * 60)
    print("RI 参考数据生成完成")
    print("=" * 60)
    n_scenarios = len(ri_reference) - 1  # 排除 _metadata
    print(f"场景数: {n_scenarios}")
    print(f"输出文件: {ri_path}")


if __name__ == '__main__':
    main()
