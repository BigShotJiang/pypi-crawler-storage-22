"""
Property-Based Tests for Wild Cluster Bootstrap optimization.

Uses the hypothesis library to verify that the optimized fast OLS + cluster SE
implementation produces results numerically equivalent to statsmodels OLS with
cluster-robust standard errors across a wide range of randomly generated inputs.

**Validates: Requirements AC-1.1, AC-1.2**
"""

import numpy as np
import pytest
import statsmodels.api as sm
from hypothesis import given, settings, strategies as st, assume

from lwdid.inference.wild_bootstrap import (
    _precompute_bootstrap_matrices,
    _fast_ols_cluster_se,
)


def _build_precomp_from_arrays(
    X: np.ndarray,
    cluster_ids: np.ndarray,
) -> dict:
    """
    Build a precompute dict directly from numpy arrays (X already includes intercept).

    This helper mirrors the structure of _precompute_bootstrap_matrices() but
    accepts raw arrays instead of a DataFrame, enabling property-based testing
    without pandas overhead.

    Parameters
    ----------
    X : ndarray, shape (N, k)
        Design matrix with intercept in column 0.
    cluster_ids : ndarray, shape (N,)
        Integer cluster assignments.

    Returns
    -------
    dict
        Precompute dictionary compatible with _fast_ols_cluster_se().
    """
    N, k = X.shape

    XtX = X.T @ X
    XtX_inv = np.linalg.inv(XtX)
    P = XtX_inv @ X.T

    unique_clusters = np.unique(cluster_ids)
    G = len(unique_clusters)

    cluster_to_idx = {c: i for i, c in enumerate(unique_clusters)}
    obs_cluster_idx = np.array([cluster_to_idx[c] for c in cluster_ids])

    cluster_masks = []
    cluster_X = []
    for g in range(G):
        mask = obs_cluster_idx == g
        cluster_masks.append(mask)
        cluster_X.append(X[mask])

    correction = (G / (G - 1)) * ((N - 1) / (N - k))

    return {
        'y': None,  # Not needed for _fast_ols_cluster_se
        'X': X, 'P': P, 'XtX_inv': XtX_inv,
        'cluster_ids': cluster_ids,
        'unique_clusters': unique_clusters,
        'obs_cluster_idx': obs_cluster_idx,
        'cluster_masks': cluster_masks,
        'cluster_X': cluster_X,
        'G': G, 'N': N, 'k': k,
        'correction': correction,
    }


@given(
    n=st.integers(min_value=20, max_value=100),
    k=st.integers(min_value=1, max_value=4),
    n_clusters_frac=st.floats(min_value=0.1, max_value=0.5),
    seed=st.integers(min_value=0, max_value=10000),
)
@settings(max_examples=50, deadline=None)
def test_fast_ols_coefficients_match_statsmodels(n, k, n_clusters_frac, seed):
    """
    Property: _fast_ols_cluster_se() coefficients match statsmodels OLS.

    **Validates: Requirements AC-1.1, AC-1.2**

    For any randomly generated (n, k, seed) with valid cluster structure,
    the treatment effect coefficient from _fast_ols_cluster_se() must match
    the statsmodels OLS coefficient within machine precision.
    """
    rng = np.random.default_rng(seed)

    # Determine number of clusters (at least 2, at most n//2)
    G = max(2, int(n * n_clusters_frac))
    G = min(G, n // 2)

    # Generate cluster assignments ensuring each cluster has >= 1 observation
    cluster_ids = np.zeros(n, dtype=int)
    # First assign one observation to each cluster
    cluster_ids[:G] = np.arange(G)
    # Then randomly assign the rest
    cluster_ids[G:] = rng.integers(0, G, size=n - G)
    # Shuffle to avoid ordering artifacts
    rng.shuffle(cluster_ids)

    # Generate design matrix: [intercept, treatment, covariates...]
    X_raw = rng.normal(size=(n, k))
    X = np.column_stack([np.ones(n), X_raw])

    # Generate outcome
    y = rng.normal(size=n)

    # Ensure X'X is invertible
    cond = np.linalg.cond(X.T @ X)
    assume(cond < 1e10)

    # Fast OLS path
    precomp = _build_precomp_from_arrays(X, cluster_ids)
    att_fast, se_fast = _fast_ols_cluster_se(y, precomp)

    # statsmodels OLS path
    model = sm.OLS(y, X)
    results = model.fit(cov_type='cluster', cov_kwds={'groups': cluster_ids})
    att_sm = results.params[1]
    se_sm = results.bse[1]

    # Coefficient must match within machine precision
    np.testing.assert_allclose(
        att_fast, att_sm, rtol=1e-10,
        err_msg=f"Coefficient mismatch: fast={att_fast}, sm={att_sm}"
    )

    # Cluster-robust SE must match (slightly looser tolerance due to
    # different matrix computation paths)
    np.testing.assert_allclose(
        se_fast, se_sm, rtol=1e-8,
        err_msg=f"SE mismatch: fast={se_fast}, sm={se_sm}"
    )


@given(
    n=st.integers(min_value=20, max_value=80),
    seed=st.integers(min_value=0, max_value=10000),
)
@settings(max_examples=30, deadline=None)
def test_fast_ols_residuals_orthogonal_to_X(n, seed):
    """
    Property: OLS residuals are orthogonal to the design matrix.

    **Validates: Requirements AC-1.1, AC-1.2**

    For any valid input, the residuals e = y - X @ beta must satisfy X' @ e ≈ 0.
    This is a fundamental OLS property that must hold regardless of implementation.
    """
    rng = np.random.default_rng(seed)

    G = max(2, n // 5)
    cluster_ids = np.zeros(n, dtype=int)
    cluster_ids[:G] = np.arange(G)
    cluster_ids[G:] = rng.integers(0, G, size=n - G)
    rng.shuffle(cluster_ids)

    X = np.column_stack([np.ones(n), rng.normal(size=(n, 1))])
    y = rng.normal(size=n)

    cond = np.linalg.cond(X.T @ X)
    assume(cond < 1e10)

    precomp = _build_precomp_from_arrays(X, cluster_ids)

    # Compute beta via projection matrix
    beta = precomp['P'] @ y
    residuals = y - X @ beta

    # X' @ e should be zero (within floating-point precision)
    Xte = X.T @ residuals
    np.testing.assert_allclose(
        Xte, 0.0, atol=1e-10,
        err_msg=f"Residuals not orthogonal to X: X'e = {Xte}"
    )


@given(
    n=st.integers(min_value=20, max_value=80),
    seed=st.integers(min_value=0, max_value=10000),
)
@settings(max_examples=30, deadline=None)
def test_fast_ols_se_positive_definite(n, seed):
    """
    Property: Cluster-robust variance matrix is positive semi-definite.

    **Validates: Requirements AC-1.1, AC-1.2**

    The cluster-robust SE must be a real positive number for any valid input
    with non-degenerate cluster structure.
    """
    rng = np.random.default_rng(seed)

    G = max(2, n // 5)
    cluster_ids = np.zeros(n, dtype=int)
    cluster_ids[:G] = np.arange(G)
    cluster_ids[G:] = rng.integers(0, G, size=n - G)
    rng.shuffle(cluster_ids)

    # Treatment indicator (ensure both 0 and 1 present)
    d = np.zeros(n)
    d[:n // 2] = 1.0
    rng.shuffle(d)

    X = np.column_stack([np.ones(n), d])
    y = rng.normal(size=n) + 2.0 * d

    precomp = _build_precomp_from_arrays(X, cluster_ids)
    att, se = _fast_ols_cluster_se(y, precomp)

    assert np.isfinite(att), f"ATT is not finite: {att}"
    assert np.isfinite(se), f"SE is not finite: {se}"
    assert se > 0, f"SE must be positive, got {se}"
