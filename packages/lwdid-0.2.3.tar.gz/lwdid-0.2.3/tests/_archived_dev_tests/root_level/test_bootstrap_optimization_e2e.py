"""
End-to-end integration tests for bootstrap performance optimization.

Validates correctness of all optimized modules through top-level API calls
and direct function invocations, covering Wild Bootstrap, Randomization
Inference, and Staggered RI.
"""

import os
import time
import warnings

import numpy as np
import pandas as pd
import pytest


# ===========================================================================
# Data Generation Utilities
# ===========================================================================

def generate_benchmark_data(
    N: int = 500,
    G: int = 30,
    K: int = 0,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate benchmark data for bootstrap and RI tests.

    Parameters
    ----------
    N : int
        Total number of observations.
    G : int
        Number of clusters (for wild cluster bootstrap).
    K : int
        Number of control variables.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        DataFrame containing y, d, cluster, and x1..xK columns.
    """
    rng = np.random.default_rng(seed)

    # Cluster assignment
    cluster_sizes = [N // G] * G
    for i in range(N % G):
        cluster_sizes[i] += 1
    cluster_ids = np.repeat(np.arange(G), cluster_sizes)

    # Cluster-level random effects
    cluster_effects = rng.normal(0, 0.5, G)

    # Treatment indicator
    d = rng.binomial(1, 0.5, N)

    # Control variables
    X = rng.normal(0, 1, (N, max(K, 0)))

    # Outcome variable
    y = 1.0 + 2.0 * d + cluster_effects[cluster_ids] + rng.normal(0, 1, N)
    if K > 0:
        beta_x = rng.normal(0, 0.5, K)
        y += X @ beta_x

    data = pd.DataFrame({
        'y': y, 'd': d, 'cluster': cluster_ids,
    })

    for k in range(K):
        data[f'x{k + 1}'] = X[:, k]

    return data


def generate_minimal_data(N: int = 6, G: int = 2, seed: int = 42) -> pd.DataFrame:
    """Generate a minimal viable dataset for edge-case testing."""
    rng = np.random.default_rng(seed)

    cluster_ids = np.repeat(np.arange(G), N // G)
    if len(cluster_ids) < N:
        cluster_ids = np.append(cluster_ids, [G - 1] * (N - len(cluster_ids)))

    d = np.zeros(N, dtype=int)
    d[:N // 2] = 1

    y = rng.normal(0, 1, N) + 2.0 * d

    return pd.DataFrame({'y': y, 'd': d, 'cluster': cluster_ids})


def generate_common_timing_panel(
    n_units: int = 20,
    n_periods: int = 10,
    treat_period: int = 6,
    tau: float = 2.0,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate a common-timing panel dataset."""
    rng = np.random.default_rng(seed)

    n_treated = n_units // 2
    rows = []
    for i in range(n_units):
        unit_fe = rng.normal(0, 0.5)
        is_treated = i < n_treated
        for t in range(1, n_periods + 1):
            time_fe = 0.1 * t
            post = 1 if t >= treat_period else 0
            d = 1 if (is_treated and post) else 0
            treat_effect = tau * d
            y = unit_fe + time_fe + treat_effect + rng.normal(0, 0.3)
            rows.append({
                'id': i, 'time': t, 'y': y,
                'd': 1 if is_treated else 0,
                'post': post,
            })

    return pd.DataFrame(rows)


def generate_staggered_panel(
    n_units: int = 30,
    n_periods: int = 10,
    tau: float = 1.0,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate a staggered adoption panel dataset."""
    rng = np.random.default_rng(seed)
    cohort_values = [0, 4, 6, 8]
    cohort_probs = [0.25, 0.25, 0.25, 0.25]
    unit_cohorts = rng.choice(cohort_values, size=n_units, p=cohort_probs)

    # Ensure each cohort has at least 2 units
    for g in cohort_values:
        count = np.sum(unit_cohorts == g)
        if count < 2:
            largest = max(cohort_values, key=lambda x: np.sum(unit_cohorts == x))
            idx = np.where(unit_cohorts == largest)[0]
            needed = 2 - count
            for j in range(min(needed, len(idx))):
                unit_cohorts[idx[j]] = g

    rows = []
    for i in range(n_units):
        g = unit_cohorts[i]
        unit_fe = rng.normal(0, 0.5)
        for t in range(1, n_periods + 1):
            time_fe = 0.1 * t
            treat_effect = tau if (g > 0 and t >= g) else 0.0
            y = unit_fe + time_fe + treat_effect + rng.normal(0, 0.5)
            rows.append({'id': i, 'time': t, 'gvar': g, 'y': y})

    return pd.DataFrame(rows)


# ===========================================================================
# Wild Bootstrap End-to-End Tests
# ===========================================================================

class TestWildBootstrapE2E:
    """End-to-end tests for the optimized wild cluster bootstrap."""

    @pytest.fixture
    def wb_data(self):
        """Generate wild bootstrap test data."""
        return generate_benchmark_data(N=200, G=15, seed=42)

    def test_wild_bootstrap_basic(self, wb_data):
        """Basic wild bootstrap produces valid results."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=199,
            weight_type='rademacher',
            impose_null=True,
            seed=42,
        )

        assert result.att is not None
        assert not np.isnan(result.att)
        assert result.se_bootstrap > 0
        assert 0 <= result.pvalue <= 1
        assert result.ci_lower < result.ci_upper
        assert result.n_clusters == 15
        assert len(result.t_stats_bootstrap) == 199

    def test_wild_bootstrap_impose_null_false(self, wb_data):
        """impose_null=False mode produces valid results."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=99,
            impose_null=False,
            seed=42,
        )

        assert result.att is not None
        assert result.se_bootstrap > 0
        assert 0 <= result.pvalue <= 1

    def test_wild_bootstrap_mammen_weights(self, wb_data):
        """Mammen weight distribution produces valid results."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=99,
            weight_type='mammen',
            seed=42,
        )

        assert result.att is not None
        assert 0 <= result.pvalue <= 1

    def test_wild_bootstrap_webb_weights(self, wb_data):
        """Webb six-point weight distribution produces valid results."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=99,
            weight_type='webb',
            seed=42,
        )

        assert result.att is not None
        assert 0 <= result.pvalue <= 1

    def test_wild_bootstrap_with_controls(self, wb_data):
        """Wild bootstrap with control variables."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        # Add a control variable
        rng = np.random.default_rng(123)
        wb_data = wb_data.copy()
        wb_data['x1'] = rng.normal(0, 1, len(wb_data))

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            controls=['x1'],
            n_bootstrap=99,
            seed=42,
        )

        assert result.att is not None
        assert result.se_bootstrap > 0

    def test_wild_bootstrap_detects_treatment_effect(self, wb_data):
        """Wild bootstrap detects a true treatment effect (tau=2.0)."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        result = wild_cluster_bootstrap(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=499,
            seed=42,
        )

        # tau=2.0 should be detected
        assert result.pvalue < 0.05, (
            f"p_value={result.pvalue:.4f}, treatment effect tau=2.0 should be detected"
        )
        assert abs(result.att - 2.0) < 1.0, (
            f"ATT={result.att:.4f}, expected close to 2.0"
        )

    def test_wild_bootstrap_deterministic(self, wb_data):
        """Identical seeds produce identical results."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        r1 = wild_cluster_bootstrap(
            data=wb_data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=99, seed=42,
        )
        r2 = wild_cluster_bootstrap(
            data=wb_data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=99, seed=42,
        )

        np.testing.assert_array_equal(
            r1.t_stats_bootstrap, r2.t_stats_bootstrap
        )
        assert r1.pvalue == r2.pvalue

    def test_test_inversion_ci(self, wb_data):
        """Test inversion confidence interval produces valid bounds."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap_test_inversion

        result = wild_cluster_bootstrap_test_inversion(
            data=wb_data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=99,
            seed=42,
            grid_points=10,
        )

        assert result.att is not None
        assert result.ci_lower < result.ci_upper
        assert 0 <= result.pvalue <= 1
        assert result.ci_lower < 2.5 and result.ci_upper > 1.0, (
            f"CI=[{result.ci_lower:.2f}, {result.ci_upper:.2f}], "
            f"expected to contain the neighborhood of tau=2.0"
        )


# ===========================================================================
# Randomization Inference End-to-End Tests
# ===========================================================================

class TestRIE2E:
    """End-to-end tests for randomization inference."""

    @pytest.fixture
    def common_timing_data(self):
        """Common-timing panel data fixture."""
        return generate_common_timing_panel(
            n_units=20, n_periods=10, treat_period=6, tau=2.0, seed=42
        )

    def test_lwdid_ri_permutation(self, common_timing_data):
        """RI permutation mode via the lwdid() top-level API."""
        from lwdid import lwdid

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = lwdid(
                data=common_timing_data,
                y='y', d='d', post='post',
                ivar='id', tvar='time',
                rolling='demean',
                ri=True, rireps=200, seed=42,
                ri_method='permutation',
            )

        assert result.ri_pvalue is not None
        assert 0 <= result.ri_pvalue <= 1
        assert result.ri_valid > 0

    def test_lwdid_ri_bootstrap(self, common_timing_data):
        """RI bootstrap mode via the lwdid() top-level API."""
        from lwdid import lwdid

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = lwdid(
                data=common_timing_data,
                y='y', d='d', post='post',
                ivar='id', tvar='time',
                rolling='demean',
                ri=True, rireps=200, seed=42,
                ri_method='bootstrap',
            )

        assert result.ri_pvalue is not None
        assert 0 <= result.ri_pvalue <= 1

    def test_lwdid_ri_detects_effect(self, common_timing_data):
        """RI detects a true treatment effect (tau=2.0)."""
        from lwdid import lwdid

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = lwdid(
                data=common_timing_data,
                y='y', d='d', post='post',
                ivar='id', tvar='time',
                rolling='demean',
                ri=True, rireps=500, seed=42,
                ri_method='permutation',
            )

        assert result.ri_pvalue < 0.10, (
            f"ri_pvalue={result.ri_pvalue:.4f}, treatment effect tau=2.0 should be detected"
        )

    def test_ri_direct_no_controls(self):
        """Direct call to randomization_inference without controls."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 50
        d = np.array([1] * 25 + [0] * 25)
        y = rng.normal(0, 1, N) + 2.0 * d

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        result = randomization_inference(
            firstpost_df=df,
            y_col='ydot_postavg',
            d_col='d_',
            ivar='ivar',
            rireps=500,
            seed=42,
            ri_method='permutation',
        )

        assert result['p_value'] < 0.05
        assert result['ri_valid'] == 500
        assert result['ri_failed'] == 0

    def test_ri_direct_with_controls(self):
        """Direct call to randomization_inference with controls."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 50
        d = np.array([1] * 25 + [0] * 25)
        x1 = rng.normal(0, 1, N)
        y = rng.normal(0, 1, N) + 2.0 * d + 0.5 * x1

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
            'x1': x1,
        })

        result = randomization_inference(
            firstpost_df=df,
            y_col='ydot_postavg',
            d_col='d_',
            ivar='ivar',
            rireps=500,
            seed=42,
            ri_method='permutation',
            controls=['x1'],
        )

        assert result['p_value'] < 0.05
        assert result['ri_valid'] == 500

    def test_ri_deterministic(self):
        """RI produces identical results with the same seed."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 30
        d = np.array([1] * 15 + [0] * 15)
        y = rng.normal(0, 1, N) + 1.5 * d

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        r1 = randomization_inference(
            firstpost_df=df, rireps=200, seed=42,
            ri_method='permutation', _return_atts=True,
        )
        r2 = randomization_inference(
            firstpost_df=df, rireps=200, seed=42,
            ri_method='permutation', _return_atts=True,
        )

        np.testing.assert_array_equal(r1['atts'], r2['atts'])
        assert r1['p_value'] == r2['p_value']


# ===========================================================================
# Staggered RI End-to-End Tests
# ===========================================================================

class TestStaggeredRIE2E:
    """End-to-end tests for staggered randomization inference."""

    @pytest.fixture
    def staggered_data(self):
        """Staggered adoption panel data fixture."""
        return generate_staggered_panel(
            n_units=30, n_periods=10, tau=1.0, seed=42
        )

    def test_staggered_ri_overall(self, staggered_data):
        """Staggered RI overall target produces valid results."""
        from lwdid.staggered.randomization import ri_overall_effect
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_overall

        data_t = transform_staggered_demean(
            staggered_data, 'y', 'id', 'time', 'gvar'
        )
        overall = aggregate_to_overall(
            data_t, 'gvar', 'id', 'time', transform_type='demean',
        )

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = ri_overall_effect(
                data=staggered_data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att,
                rolling='demean',
                rireps=100, seed=42,
                n_jobs=1,
            )

        assert result.p_value is not None
        assert 0 <= result.p_value <= 1
        assert result.ri_valid > 0
        assert result.ri_method == 'permutation'

    def test_staggered_ri_cohort(self, staggered_data):
        """Staggered RI cohort target produces valid results."""
        from lwdid.staggered.randomization import ri_cohort_effect
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_cohort

        data_t = transform_staggered_demean(
            staggered_data, 'y', 'id', 'time', 'gvar'
        )
        T_max = int(staggered_data['time'].max())
        cohort_results = aggregate_to_cohort(
            data_t, 'gvar', 'id', 'time',
            cohorts=[6], T_max=T_max,
            transform_type='demean',
        )
        observed_att = cohort_results[0].att

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = ri_cohort_effect(
                data=staggered_data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                target_cohort=6,
                observed_att=observed_att,
                rolling='demean',
                rireps=100, seed=42,
                n_jobs=1,
            )

        assert result.p_value is not None
        assert 0 <= result.p_value <= 1
        assert result.ri_valid > 0

    def test_staggered_ri_parallel(self, staggered_data):
        """Staggered RI parallel execution produces valid results."""
        from lwdid.staggered.randomization import ri_overall_effect
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_overall

        data_t = transform_staggered_demean(
            staggered_data, 'y', 'id', 'time', 'gvar'
        )
        overall = aggregate_to_overall(
            data_t, 'gvar', 'id', 'time', transform_type='demean',
        )

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = ri_overall_effect(
                data=staggered_data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att,
                rolling='demean',
                rireps=100, seed=42,
                n_jobs=2,
            )

        assert result.p_value is not None
        assert result.ri_valid > 0

    def test_staggered_ri_bootstrap_method(self, staggered_data):
        """Staggered RI bootstrap resampling method produces valid results."""
        from lwdid.staggered.randomization import randomization_inference_staggered
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_overall
        from lwdid.validation import is_never_treated

        data_t = transform_staggered_demean(
            staggered_data, 'y', 'id', 'time', 'gvar'
        )
        overall = aggregate_to_overall(
            data_t, 'gvar', 'id', 'time', transform_type='demean',
        )

        unit_gvar = staggered_data.groupby('id')['gvar'].first()
        n_nt = int(unit_gvar.apply(is_never_treated).sum())

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = randomization_inference_staggered(
                data=staggered_data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att,
                target='overall',
                ri_method='bootstrap',
                rireps=100, seed=42,
                rolling='demean',
                n_never_treated=n_nt,
                n_jobs=1,
            )

        assert result.ri_method == 'bootstrap'
        assert result.ri_valid > 0
        assert 0 <= result.p_value <= 1

    def test_staggered_ri_detects_effect(self, staggered_data):
        """Staggered RI detects a true treatment effect (tau=1.0)."""
        from lwdid.staggered.randomization import ri_overall_effect
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_overall

        data_t = transform_staggered_demean(
            staggered_data, 'y', 'id', 'time', 'gvar'
        )
        overall = aggregate_to_overall(
            data_t, 'gvar', 'id', 'time', transform_type='demean',
        )

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            result = ri_overall_effect(
                data=staggered_data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att,
                rolling='demean',
                rireps=200, seed=42,
                n_jobs=1,
            )

        assert result.p_value < 0.05, (
            f"p_value={result.p_value:.4f}, treatment effect tau=1.0 should be detected"
        )


# ===========================================================================
# Edge Case Tests
# ===========================================================================

class TestEdgeCases:
    """Boundary condition and edge case tests."""

    def test_minimal_data_wild_bootstrap(self):
        """Wild bootstrap with minimal data (N=6, G=2)."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        data = generate_minimal_data(N=6, G=2)

        result = wild_cluster_bootstrap(
            data=data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=10,
            seed=42,
        )

        assert not np.isnan(result.pvalue)
        assert result.att is not None

    def test_single_bootstrap(self):
        """Single bootstrap replication (B=1) with full enumeration disabled."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        data = generate_benchmark_data(N=50, G=5)

        result = wild_cluster_bootstrap(
            data=data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=1,
            seed=42,
            full_enumeration=False,
        )

        assert len(result.t_stats_bootstrap) == 1

    def test_full_enumeration_small_g(self):
        """Full enumeration mode with G=8 clusters (2^8=256 replications)."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        data = generate_benchmark_data(N=40, G=8)

        result = wild_cluster_bootstrap(
            data=data,
            y_transformed='y',
            d='d',
            cluster_var='cluster',
            n_bootstrap=999,
            seed=42,
            full_enumeration=True,
        )

        assert len(result.t_stats_bootstrap) == 256

    def test_controls_empty_list_wild_bootstrap(self):
        """controls=[] is equivalent to controls=None."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        data = generate_benchmark_data(N=50, G=5)

        r1 = wild_cluster_bootstrap(
            data=data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=99, seed=42,
            controls=None,
        )
        r2 = wild_cluster_bootstrap(
            data=data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=99, seed=42,
            controls=[],
        )

        np.testing.assert_array_equal(
            r1.t_stats_bootstrap, r2.t_stats_bootstrap
        )

    def test_ri_permutation_all_valid(self):
        """All RI permutation iterations produce valid statistics."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 30
        d = np.array([1] * 15 + [0] * 15)
        y = rng.normal(0, 1, N)

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        result = randomization_inference(
            firstpost_df=df, rireps=100, seed=42,
            ri_method='permutation',
        )

        assert result['ri_valid'] == 100
        assert result['ri_failed'] == 0

    def test_ri_small_sample(self):
        """RI with a very small sample (N=4)."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 4
        d = np.array([1, 1, 0, 0])
        y = rng.normal(0, 1, N) + 3.0 * d

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        result = randomization_inference(
            firstpost_df=df, rireps=100, seed=42,
            ri_method='permutation',
        )

        assert result['ri_valid'] > 0
        assert 0 <= result['p_value'] <= 1

    def test_staggered_ri_error_no_never_treated(self):
        """Staggered RI overall target raises error without never-treated units."""
        from lwdid.staggered.randomization import randomization_inference_staggered
        from lwdid.exceptions import RandomizationError

        # All units are treated
        data = generate_staggered_panel(n_units=20, n_periods=10, seed=42)
        data = data[data['gvar'] > 0].copy()  # Remove never-treated

        with pytest.raises(RandomizationError, match="never treated"):
            randomization_inference_staggered(
                data=data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=1.0,
                target='overall',
                rireps=10, seed=42,
                rolling='demean',
                n_never_treated=0,
            )

    def test_staggered_ri_error_too_few_units(self):
        """Staggered RI raises error with too few units."""
        from lwdid.staggered.randomization import randomization_inference_staggered
        from lwdid.exceptions import RandomizationError

        # Only 3 units
        data = pd.DataFrame({
            'id': [0, 0, 1, 1, 2, 2],
            'time': [1, 2, 1, 2, 1, 2],
            'gvar': [0, 0, 2, 2, 2, 2],
            'y': [1.0, 1.1, 2.0, 2.1, 2.5, 2.6],
        })

        with pytest.raises(RandomizationError, match="Too few units"):
            randomization_inference_staggered(
                data=data,
                gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=1.0,
                target='overall',
                rireps=10, seed=42,
                rolling='demean',
                n_never_treated=1,
            )

    def test_wild_bootstrap_numerical_reasonableness(self):
        """Numerical reasonableness: null data yields large p-value."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        # Data with no treatment effect
        rng = np.random.default_rng(42)
        N = 100
        G = 10
        cluster_ids = np.repeat(np.arange(G), N // G)
        d = rng.binomial(1, 0.5, N)
        y = rng.normal(0, 1, N)  # No treatment effect

        data = pd.DataFrame({'y': y, 'd': d, 'cluster': cluster_ids})

        result = wild_cluster_bootstrap(
            data=data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=499, seed=42,
        )

        # Under no treatment effect, p-value should be large
        assert result.pvalue > 0.01, (
            f"p_value={result.pvalue:.4f}, expected large p-value under null"
        )
        # ATT should be close to zero
        assert abs(result.att) < 1.0, (
            f"ATT={result.att:.4f}, expected close to 0 under null"
        )

    def test_ri_numerical_reasonableness_no_effect(self):
        """Numerical reasonableness: RI yields large p-value under no effect."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 40
        d = np.array([1] * 20 + [0] * 20)
        y = rng.normal(0, 1, N)  # No treatment effect

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        result = randomization_inference(
            firstpost_df=df, rireps=500, seed=42,
            ri_method='permutation',
        )

        # Under no treatment effect, p-value should be > 0.05 (with high probability).
        # Use a lenient threshold to avoid spurious test failures.
        assert result['p_value'] > 0.01, (
            f"p_value={result['p_value']:.4f}, expected large p-value under null"
        )

    def test_ri_degenerate_treatment_all_treated(self):
        """RI with degenerate treatment assignment: all units treated.

        When all units are treated (d=1), permutation still shuffles labels
        so some replications will have a control group. The observed ATT
        is undefined (no control group), but the function should handle
        this gracefully.
        """
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 20
        d = np.ones(N, dtype=int)  # All treated
        y = rng.normal(0, 1, N)

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        # Permutation mode: shuffling all-ones still yields all-ones,
        # so the observed ATT is mean(y) - NaN. The function should
        # either raise an error or produce a valid result depending on
        # implementation. We verify it does not crash unexpectedly.
        try:
            result = randomization_inference(
                firstpost_df=df, rireps=100, seed=42,
                ri_method='permutation',
            )
            # If it succeeds, the result should have valid structure
            assert 'p_value' in result
            assert 'ri_valid' in result
        except Exception:
            # Acceptable: the function may raise an error for degenerate input
            pass

    def test_ri_controls_empty_list_equivalent_to_none(self):
        """RI: controls=[] produces identical results to controls=None."""
        from lwdid.randomization import randomization_inference

        rng = np.random.default_rng(42)
        N = 30
        d = np.array([1] * 15 + [0] * 15)
        y = rng.normal(0, 1, N) + 1.5 * d

        df = pd.DataFrame({
            'ydot_postavg': y, 'd_': d, 'ivar': np.arange(N),
        })

        r1 = randomization_inference(
            firstpost_df=df, rireps=200, seed=42,
            ri_method='permutation', controls=None,
            _return_atts=True,
        )
        r2 = randomization_inference(
            firstpost_df=df, rireps=200, seed=42,
            ri_method='permutation', controls=[],
            _return_atts=True,
        )

        np.testing.assert_array_equal(r1['atts'], r2['atts'])
        assert r1['p_value'] == r2['p_value']
        assert r1['ri_valid'] == r2['ri_valid']

    def test_wild_bootstrap_full_enumeration_deterministic(self):
        """Full enumeration is deterministic regardless of seed."""
        from lwdid.inference.wild_bootstrap import wild_cluster_bootstrap

        data = generate_benchmark_data(N=30, G=6)

        r1 = wild_cluster_bootstrap(
            data=data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=999, seed=42,
            full_enumeration=True,
        )
        r2 = wild_cluster_bootstrap(
            data=data, y_transformed='y', d='d',
            cluster_var='cluster', n_bootstrap=999, seed=99,
            full_enumeration=True,
        )

        # Full enumeration uses all 2^G weight combinations, so the seed
        # should not affect the set of t-statistics (only ordering may differ).
        np.testing.assert_array_equal(
            np.sort(r1.t_stats_bootstrap),
            np.sort(r2.t_stats_bootstrap),
        )

    def test_staggered_ri_parallel_serial_consistency(self):
        """Staggered RI: parallel and serial produce consistent p-values."""
        from lwdid.staggered.randomization import ri_overall_effect
        from lwdid.staggered.transformations import transform_staggered_demean
        from lwdid.staggered.aggregation import aggregate_to_overall

        data = generate_staggered_panel(n_units=30, n_periods=10, tau=1.0, seed=42)
        data_t = transform_staggered_demean(data, 'y', 'id', 'time', 'gvar')
        overall = aggregate_to_overall(
            data_t, 'gvar', 'id', 'time', transform_type='demean',
        )

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            r_serial = ri_overall_effect(
                data=data, gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att, rolling='demean',
                rireps=50, seed=42, n_jobs=1,
            )
            r_parallel = ri_overall_effect(
                data=data, gvar='gvar', ivar='id', tvar='time', y='y',
                observed_att=overall.att, rolling='demean',
                rireps=50, seed=42, n_jobs=2,
            )

        # Sorted permutation statistics should match (parallel uses same
        # SeedSequence-derived child seeds, execution order may differ).
        np.testing.assert_allclose(
            np.sort(r_serial.permutation_stats),
            np.sort(r_parallel.permutation_stats),
            rtol=1e-10,
        )
        assert r_serial.p_value == r_parallel.p_value
