"""
检查点脚本：验证警告系统基础设施（Task 1 & Task 2）工作正常。

覆盖内容：
- 警告类别导入和继承关系
- WarningRegistry 收集、flush、diagnostics
- verbose 参数验证
- 空 flush 和幂等 flush
"""

import warnings

# ── 1. 导入验证 ──────────────────────────────────────────────────────
from lwdid.warnings_categories import (
    LWDIDWarning,
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
)
from lwdid.warning_registry import WarningRegistry, WarningRecord

ALL_CATEGORIES = [
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
]

# ── 2. 继承关系验证 ──────────────────────────────────────────────────
def test_inheritance():
    for cat in ALL_CATEGORIES:
        assert issubclass(cat, LWDIDWarning), f"{cat.__name__} 不是 LWDIDWarning 子类"
        assert issubclass(cat, UserWarning), f"{cat.__name__} 不是 UserWarning 子类"
    assert issubclass(LWDIDWarning, UserWarning), "LWDIDWarning 不是 UserWarning 子类"
    print("✓ 继承关系验证通过")

# ── 3. WarningRegistry 基本流程 ─────────────────────────────────────
def test_registry_basic_flow():
    reg = WarningRegistry(verbose='default')

    # 收集几条警告
    reg.collect(SmallSampleWarning, "小样本 n=3", cohort=2004, period=2006,
                context={'n_treated': 3})
    reg.collect(SmallSampleWarning, "小样本 n=4", cohort=2004, period=2007,
                context={'n_treated': 4})
    reg.collect(OverlapWarning, "极端权重", cohort=2005, period=2008,
                context={'max_weight': 15.2})

    # flush 前不应有 warnings.warn 输出
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        # 此处不调用 flush，不应有输出
        pass
    assert len(caught) == 0, "flush 前不应有警告输出"

    # flush
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush(total_pairs=56)

    # default 模式：每种类别一条聚合输出 → 2 条
    assert len(caught) == 2, f"期望 2 条聚合警告，实际 {len(caught)}"

    # 验证 diagnostics
    diag = reg.get_diagnostics()
    assert len(diag) == 2, f"期望 2 个诊断条目，实际 {len(diag)}"

    small_diag = [d for d in diag if d['category'] == 'SmallSampleWarning'][0]
    assert small_diag['count'] == 2
    assert len(small_diag['affected_pairs']) == 2
    assert small_diag['context_summary']['n_treated_min'] == 3
    assert small_diag['context_summary']['n_treated_max'] == 4

    print("✓ WarningRegistry 基本流程验证通过")

# ── 4. verbose 参数非法值 ───────────────────────────────────────────
def test_invalid_verbose():
    try:
        WarningRegistry(verbose='invalid')
        assert False, "应抛出 ValueError"
    except ValueError:
        pass

    try:
        WarningRegistry(verbose=123)
        assert False, "应抛出 ValueError 或 AttributeError"
    except (ValueError, AttributeError):
        pass

    print("✓ verbose 参数验证通过")

# ── 5. 空 flush ─────────────────────────────────────────────────────
def test_empty_flush():
    reg = WarningRegistry(verbose='default')
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush()
    assert len(caught) == 0, "空注册表 flush 不应产生输出"
    print("✓ 空 flush 验证通过")

# ── 6. 幂等 flush ───────────────────────────────────────────────────
def test_idempotent_flush():
    reg = WarningRegistry(verbose='default')
    reg.collect(DataWarning, "数据问题", cohort=2004, period=2006)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush(total_pairs=10)
    first_count = len(caught)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush(total_pairs=10)
    assert len(caught) == 0, "重复 flush 不应产生输出"

    print("✓ 幂等 flush 验证通过")

# ── 7. collect 接受 None cohort/period ──────────────────────────────
def test_collect_none_cohort_period():
    reg = WarningRegistry(verbose='verbose')
    reg.collect(NumericalWarning, "数值不稳定", cohort=None, period=None)
    diag = reg.get_diagnostics()
    assert len(diag) == 1
    assert diag[0]['affected_pairs'] == []
    print("✓ collect(None cohort/period) 验证通过")

# ── 8. quiet 模式仅输出严重警告 ─────────────────────────────────────
def test_quiet_mode():
    reg = WarningRegistry(verbose='quiet')
    reg.collect(SmallSampleWarning, "小样本", cohort=2004, period=2006)
    reg.collect(ConvergenceWarning, "未收敛", cohort=2004, period=2007)
    reg.collect(NumericalWarning, "数值问题", cohort=2005, period=2008)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush(total_pairs=20)

    # quiet 模式：仅 ConvergenceWarning 和 NumericalWarning（严重类别）
    categories_emitted = [w.category for w in caught]
    assert SmallSampleWarning not in categories_emitted, "quiet 模式不应输出 SmallSampleWarning"
    assert ConvergenceWarning in categories_emitted, "quiet 模式应输出 ConvergenceWarning"
    assert NumericalWarning in categories_emitted, "quiet 模式应输出 NumericalWarning"
    print("✓ quiet 模式验证通过")

# ── 9. verbose 模式输出所有个体警告 ─────────────────────────────────
def test_verbose_mode():
    reg = WarningRegistry(verbose='verbose')
    for i in range(5):
        reg.collect(SmallSampleWarning, f"警告 {i}", cohort=2004, period=2006 + i)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        reg.flush()

    assert len(caught) == 5, f"verbose 模式期望 5 条输出，实际 {len(caught)}"
    print("✓ verbose 模式验证通过")


# ── 运行所有测试 ────────────────────────────────────────────────────
if __name__ == '__main__':
    test_inheritance()
    test_registry_basic_flow()
    test_invalid_verbose()
    test_empty_flush()
    test_idempotent_flush()
    test_collect_none_cohort_period()
    test_quiet_mode()
    test_verbose_mode()
    print("\n🎉 所有检查点测试通过！基础设施就绪。")
