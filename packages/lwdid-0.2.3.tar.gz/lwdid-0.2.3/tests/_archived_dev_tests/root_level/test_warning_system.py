"""
Unit tests for the warning system.

Tests warning category hierarchy, backward compatibility with standard
``UserWarning`` filters, ``WarningRegistry`` behavior, verbose parameter
validation, and end-to-end warning integration across all three modes.
"""

import warnings

import pytest

from lwdid.warnings_categories import (
    LWDIDWarning,
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
)


# All LWDIDWarning subclasses for parametrized tests
ALL_WARNING_SUBCLASSES = [
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
]


# ── Inheritance hierarchy tests ────────────────────────────────────────────────────


class TestWarningCategoryHierarchy:
    """Verify the inheritance structure of warning categories."""

    def test_lwdid_warning_inherits_from_user_warning(self):
        """LWDIDWarning must inherit from UserWarning."""
        assert issubclass(LWDIDWarning, UserWarning)

    @pytest.mark.parametrize("cls", ALL_WARNING_SUBCLASSES, ids=lambda c: c.__name__)
    def test_subclass_inherits_from_lwdid_warning(self, cls):
        """Each subclass must inherit from LWDIDWarning."""
        assert issubclass(cls, LWDIDWarning)

    @pytest.mark.parametrize("cls", ALL_WARNING_SUBCLASSES, ids=lambda c: c.__name__)
    def test_subclass_inherits_from_user_warning(self, cls):
        """Each subclass must also inherit from UserWarning (transitivity)."""
        assert issubclass(cls, UserWarning)

    def test_all_five_subclasses_exist(self):
        """Exactly 5 warning subclasses must be defined."""
        assert len(ALL_WARNING_SUBCLASSES) == 5

    @pytest.mark.parametrize("cls", ALL_WARNING_SUBCLASSES, ids=lambda c: c.__name__)
    def test_subclass_is_instantiable(self, cls):
        """Each warning subclass must be instantiable."""
        instance = cls("test message")
        assert isinstance(instance, cls)
        assert isinstance(instance, LWDIDWarning)
        assert isinstance(instance, UserWarning)


# ── Backward compatibility tests ─────────────────────────────────────


class TestBackwardCompatibility:
    """Verify that standard UserWarning filters still catch custom categories."""

    @pytest.mark.parametrize("cls", ALL_WARNING_SUBCLASSES, ids=lambda c: c.__name__)
    def test_user_warning_filter_catches_subclass(self, cls):
        """filterwarnings(category=UserWarning) must catch all custom subclasses."""
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always", category=UserWarning)
            warnings.warn("test message", cls)

        assert len(caught) == 1
        assert issubclass(caught[0].category, UserWarning)
        assert caught[0].category is cls

    def test_user_warning_ignore_suppresses_all_subclasses(self):
        """filterwarnings('ignore', category=UserWarning) must suppress all custom subclasses."""
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            warnings.filterwarnings("ignore", category=UserWarning)

            for cls in ALL_WARNING_SUBCLASSES:
                warnings.warn(f"{cls.__name__} test", cls)

        # All UserWarning subclasses should be suppressed
        assert len(caught) == 0

    def test_lwdid_warning_filter_catches_all_subclasses(self):
        """filterwarnings(category=LWDIDWarning) must catch all subclasses."""
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always", category=LWDIDWarning)

            for cls in ALL_WARNING_SUBCLASSES:
                warnings.warn(f"{cls.__name__} test", cls)

        assert len(caught) == len(ALL_WARNING_SUBCLASSES)
        for w in caught:
            assert issubclass(w.category, LWDIDWarning)

    def test_lwdid_warning_ignore_does_not_suppress_unrelated(self):
        """filterwarnings('ignore', category=LWDIDWarning) must not suppress unrelated UserWarning."""
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            warnings.filterwarnings("ignore", category=LWDIDWarning)

            # Emit one plain UserWarning and one LWDIDWarning subclass
            warnings.warn("plain warning", UserWarning)
            warnings.warn("lwdid warning", SmallSampleWarning)

        # Only the plain UserWarning should be caught
        categories = [w.category for w in caught]
        assert UserWarning in categories
        assert SmallSampleWarning not in categories


# ── WarningRegistry unit tests ───────────────────────────────────────

from lwdid.warning_registry import WarningRegistry, WarningRecord


class TestWarningRegistryEmptyFlush:
    """Verify empty registry flush behavior."""

    def test_empty_flush_produces_no_warnings(self):
        """Flushing an empty registry must not produce any warnings."""
        registry = WarningRegistry(verbose='default')
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=10)
        assert len(caught) == 0

    def test_empty_flush_no_exception(self):
        """Flushing an empty registry must not raise an exception."""
        registry = WarningRegistry(verbose='default')
        registry.flush()  # omitting total_pairs must not error

    @pytest.mark.parametrize("level", ["quiet", "default", "verbose"])
    def test_empty_flush_no_output_all_levels(self, level):
        """Empty flush must produce no output at any verbose level."""
        registry = WarningRegistry(verbose=level)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=5)
        assert len(caught) == 0

    def test_empty_diagnostics_returns_empty_list(self):
        """get_diagnostics() on an empty registry must return an empty list."""
        registry = WarningRegistry()
        assert registry.get_diagnostics() == []


class TestWarningRegistryFlushIdempotency:
    """Verify that repeated flush() calls are idempotent."""

    def test_double_flush_no_duplicate_output(self):
        """Calling flush() twice must not produce duplicate output."""
        registry = WarningRegistry(verbose='default')
        registry.collect(SmallSampleWarning, "small sample", cohort=2004, period=2006)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=10)
            registry.flush(total_pairs=10)  # second call

        # Only the first flush should produce output
        assert len(caught) == 1

    def test_triple_flush_still_idempotent(self):
        """Calling flush() three times must still produce output only once."""
        registry = WarningRegistry(verbose='verbose')
        registry.collect(OverlapWarning, "overlap issue", cohort=2005, period=2007)
        registry.collect(DataWarning, "data issue", cohort=2005, period=2008)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush()
            registry.flush()
            registry.flush()

        # In verbose mode 2 records => 2 outputs, but only on the first flush
        assert len(caught) == 2

    def test_flush_sets_flushed_flag(self):
        """Internal _flushed flag must be True after flush()."""
        registry = WarningRegistry()
        assert registry._flushed is False
        registry.flush()
        assert registry._flushed is True


class TestWarningRegistryVerboseValidation:
    """Verify handling of invalid verbose parameter values."""

    def test_invalid_verbose_raises_value_error(self):
        """Invalid verbose value must raise ValueError."""
        with pytest.raises(ValueError, match="Invalid verbose level"):
            WarningRegistry(verbose='debug')

    def test_invalid_verbose_numeric_raises_value_error(self):
        """Numeric verbose value must raise ValueError."""
        with pytest.raises(ValueError):
            WarningRegistry(verbose=1)

    def test_invalid_verbose_none_raises(self):
        """None as verbose must raise an exception."""
        with pytest.raises((ValueError, AttributeError)):
            WarningRegistry(verbose=None)

    def test_valid_verbose_case_insensitive(self):
        """verbose parameter must be case-insensitive."""
        for level in ['Quiet', 'DEFAULT', 'Verbose', 'QUIET', 'Default']:
            registry = WarningRegistry(verbose=level)
            assert registry._verbose == level.lower()

    @pytest.mark.parametrize("level", ["quiet", "default", "verbose"])
    def test_valid_verbose_accepted(self, level):
        """All three valid verbose values must create an instance."""
        registry = WarningRegistry(verbose=level)
        assert registry._verbose == level


class TestWarningRegistryCollectNone:
    """Verify that collect() accepts None cohort/period values."""

    def test_collect_none_cohort_and_period(self):
        """collect() must accept cohort=None and period=None (non-loop context)."""
        registry = WarningRegistry()
        registry.collect(DataWarning, "data quality issue", cohort=None, period=None)
        assert len(registry._records) == 1
        assert registry._records[0].cohort is None
        assert registry._records[0].period is None

    def test_collect_none_cohort_only(self):
        """collect() must accept cohort=None with a valid period."""
        registry = WarningRegistry()
        registry.collect(SmallSampleWarning, "small sample", cohort=None, period=2006)
        assert registry._records[0].cohort is None
        assert registry._records[0].period == 2006

    def test_collect_none_period_only(self):
        """collect() must accept period=None with a valid cohort."""
        registry = WarningRegistry()
        registry.collect(NumericalWarning, "numerical issue", cohort=2004, period=None)
        assert registry._records[0].cohort == 2004
        assert registry._records[0].period is None

    def test_collect_default_params_are_none(self):
        """collect() 不传 cohort/period 时默认为 None。"""
        registry = WarningRegistry()
        registry.collect(ConvergenceWarning, "收敛失败")
        rec = registry._records[0]
        assert rec.cohort is None
        assert rec.period is None
        assert rec.context == {}

    def test_collect_none_excluded_from_affected_pairs(self):
        """cohort/period 均为 None 的记录不应出现在 affected_pairs 中。"""
        registry = WarningRegistry()
        registry.collect(DataWarning, "问题1", cohort=None, period=None)
        registry.collect(DataWarning, "问题2", cohort=2004, period=2006)

        diag = registry.get_diagnostics()
        assert len(diag) == 1  # 同类别聚合为一条
        # 只有第二条记录有 (cohort, period)
        assert diag[0]['affected_pairs'] == [(2004, 2006)]
        assert diag[0]['count'] == 2


# ── core.py and results.py warning system integration tests ─────────
# Requirements: 3.1, 3.5, 4.1

import inspect

from lwdid.core import lwdid
from lwdid.results import LWDIDResults


class TestCoreLwdidVerboseParameter:
    """Verify that lwdid() accepts the verbose parameter with correct default.

    Requirements: 3.1, 3.5
    """

    def test_lwdid_signature_includes_verbose(self):
        """The lwdid() function signature must include a 'verbose' parameter."""
        sig = inspect.signature(lwdid)
        assert 'verbose' in sig.parameters, (
            "lwdid() is missing the 'verbose' parameter"
        )

    def test_lwdid_verbose_default_is_default(self):
        """The verbose parameter must default to 'default'."""
        sig = inspect.signature(lwdid)
        param = sig.parameters['verbose']
        assert param.default == 'default', (
            f"Expected verbose default='default', got {param.default!r}"
        )

    def test_lwdid_verbose_is_keyword_argument(self):
        """The verbose parameter should be a keyword-only or keyword argument."""
        sig = inspect.signature(lwdid)
        param = sig.parameters['verbose']
        assert param.kind in (
            inspect.Parameter.KEYWORD_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ), f"verbose parameter has unexpected kind: {param.kind}"


class TestLWDIDResultsDiagnosticsProperty:
    """Verify that LWDIDResults has a diagnostics property with correct type.

    Requirements: 4.1
    """

    @staticmethod
    def _make_minimal_results() -> LWDIDResults:
        """Create a minimal LWDIDResults instance for testing."""
        results_dict = {
            'att': 0.0,
            'se_att': 0.1,
            't_stat': 0.0,
            'pvalue': 1.0,
            'ci_lower': -0.2,
            'ci_upper': 0.2,
            'nobs': 10,
            'df_resid': 8,
            'vce_type': 'ols',
            'params': None,
            'bse': None,
            'vcov': None,
            'resid': None,
        }
        metadata = {
            'K': 2,
            'tpost1': 3,
            'depvar': 'y',
            'N_treated': 5,
            'N_control': 5,
        }
        return LWDIDResults(results_dict, metadata)

    def test_diagnostics_property_exists(self):
        """LWDIDResults must have a 'diagnostics' property."""
        assert hasattr(LWDIDResults, 'diagnostics'), (
            "LWDIDResults is missing the 'diagnostics' attribute"
        )
        assert isinstance(
            inspect.getattr_static(LWDIDResults, 'diagnostics'), property
        ), "LWDIDResults.diagnostics should be a property, not a plain attribute"

    def test_diagnostics_returns_list(self):
        """LWDIDResults.diagnostics must return a list."""
        result = self._make_minimal_results()
        diag = result.diagnostics
        assert isinstance(diag, list), (
            f"Expected diagnostics to be a list, got {type(diag).__name__}"
        )

    def test_fresh_results_has_empty_diagnostics(self):
        """A freshly created LWDIDResults must have an empty diagnostics list."""
        result = self._make_minimal_results()
        assert result.diagnostics == [], (
            f"Expected empty diagnostics, got {result.diagnostics}"
        )

    def test_diagnostics_populated_externally(self):
        """Diagnostics can be populated via the internal _diagnostics attribute."""
        result = self._make_minimal_results()
        sample_diag = [
            {
                'category': 'SmallSampleWarning',
                'message': 'Small treated sample',
                'count': 3,
                'affected_pairs': [(2004, 2006), (2004, 2007)],
                'context_summary': {},
            }
        ]
        result._diagnostics = sample_diag
        assert result.diagnostics == sample_diag
        assert len(result.diagnostics) == 1

    def test_diagnostics_independent_of_staggered_flag(self):
        """Diagnostics property should work for both staggered and non-staggered results."""
        result = self._make_minimal_results()
        assert result.is_staggered is False
        assert isinstance(result.diagnostics, list)


# ── pandas PerformanceWarning suppression tests ─────────────────────
# Requirements: 5.1, 5.2

import numpy as np
import pandas as pd

from lwdid.staggered.transformations import (
    transform_staggered_demean,
    transform_staggered_detrend,
)
from lwdid.transformations import apply_rolling_transform


def _make_staggered_panel() -> pd.DataFrame:
    """Create a minimal staggered panel dataset for transformation tests.

    Returns a balanced panel with 4 units over 6 periods (t=1..6).
    Units 1-2 are treated at g=4, units 3-4 are never-treated (gvar=0).
    """
    records = []
    np.random.seed(42)
    for unit_id in range(1, 5):
        gvar_val = 4 if unit_id <= 2 else 0
        for t in range(1, 7):
            records.append({
                'unit': unit_id,
                'time': t,
                'y': float(unit_id * 10 + t + np.random.normal(0, 0.5)),
                'gvar': gvar_val,
            })
    return pd.DataFrame(records)


def _make_common_timing_panel() -> pd.DataFrame:
    """Create a minimal common-timing panel dataset for transformation tests.

    Returns a balanced panel with 4 units over 6 periods (t=1..6).
    Treatment occurs at t=4 for units 1-2 (d=1), units 3-4 are control (d=0).
    """
    records = []
    np.random.seed(42)
    for unit_id in range(1, 5):
        d_val = 1 if unit_id <= 2 else 0
        for t in range(1, 7):
            post_val = 1 if t >= 4 else 0
            records.append({
                'unit': unit_id,
                'time': t,
                'tindex': t,
                'y': float(unit_id * 10 + t + np.random.normal(0, 0.5)),
                'd': d_val,
                'post': post_val,
            })
    return pd.DataFrame(records)


class TestStaggeredPerformanceWarningSuppression:
    """Verify staggered transformation functions do not emit PerformanceWarning.

    Requirements: 5.1
    """

    def test_staggered_demean_no_performance_warning(self):
        """transform_staggered_demean should not emit PerformanceWarning."""
        df = _make_staggered_panel()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            transform_staggered_demean(
                df, y='y', ivar='unit', tvar='time', gvar='gvar'
            )

        perf_warnings = [
            w for w in caught
            if issubclass(w.category, pd.errors.PerformanceWarning)
        ]
        assert len(perf_warnings) == 0, (
            f"Expected no PerformanceWarning, but got {len(perf_warnings)}: "
            f"{[str(w.message) for w in perf_warnings]}"
        )

    def test_staggered_detrend_no_performance_warning(self):
        """transform_staggered_detrend should not emit PerformanceWarning."""
        df = _make_staggered_panel()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            transform_staggered_detrend(
                df, y='y', ivar='unit', tvar='time', gvar='gvar'
            )

        perf_warnings = [
            w for w in caught
            if issubclass(w.category, pd.errors.PerformanceWarning)
        ]
        assert len(perf_warnings) == 0, (
            f"Expected no PerformanceWarning, but got {len(perf_warnings)}: "
            f"{[str(w.message) for w in perf_warnings]}"
        )


class TestCommonTimingPerformanceWarningSuppression:
    """Verify common-timing transformation functions do not emit PerformanceWarning.

    Requirements: 5.1
    """

    def test_demean_no_performance_warning(self):
        """apply_rolling_transform with rolling='demean' should not emit PerformanceWarning."""
        df = _make_common_timing_panel()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            apply_rolling_transform(
                df, y='y', ivar='unit', tindex='tindex',
                post='post', rolling='demean', tpost1=4,
            )

        perf_warnings = [
            w for w in caught
            if issubclass(w.category, pd.errors.PerformanceWarning)
        ]
        assert len(perf_warnings) == 0, (
            f"Expected no PerformanceWarning, but got {len(perf_warnings)}: "
            f"{[str(w.message) for w in perf_warnings]}"
        )

    def test_detrend_no_performance_warning(self):
        """apply_rolling_transform with rolling='detrend' should not emit PerformanceWarning."""
        df = _make_common_timing_panel()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            apply_rolling_transform(
                df, y='y', ivar='unit', tindex='tindex',
                post='post', rolling='detrend', tpost1=4,
            )

        perf_warnings = [
            w for w in caught
            if issubclass(w.category, pd.errors.PerformanceWarning)
        ]
        assert len(perf_warnings) == 0, (
            f"Expected no PerformanceWarning, but got {len(perf_warnings)}: "
            f"{[str(w.message) for w in perf_warnings]}"
        )


class TestPerformanceWarningSuppressionScope:
    """Verify that PerformanceWarning suppression is scoped and does not leak.

    The suppression must only apply within transformation code blocks.
    User-level pandas warning settings must be preserved after transformations.

    Requirements: 5.2
    """

    def test_user_warning_settings_preserved_after_staggered_demean(self):
        """User-level pandas warning filters must remain intact after staggered demean."""
        # Set a custom user-level filter for PerformanceWarning before transformation.
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")

            # Record the filter state before transformation.
            filters_before = warnings.filters[:]

            df = _make_staggered_panel()
            transform_staggered_demean(
                df, y='y', ivar='unit', tvar='time', gvar='gvar'
            )

            # Filter state after transformation should be identical.
            filters_after = warnings.filters[:]
            assert filters_before == filters_after, (
                "Warning filters were modified by staggered demean transformation"
            )

    def test_user_warning_settings_preserved_after_staggered_detrend(self):
        """User-level pandas warning filters must remain intact after staggered detrend."""
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")

            filters_before = warnings.filters[:]

            df = _make_staggered_panel()
            transform_staggered_detrend(
                df, y='y', ivar='unit', tvar='time', gvar='gvar'
            )

            filters_after = warnings.filters[:]
            assert filters_before == filters_after, (
                "Warning filters were modified by staggered detrend transformation"
            )

    def test_user_warning_settings_preserved_after_common_timing(self):
        """User-level pandas warning filters must remain intact after common-timing transform."""
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")

            filters_before = warnings.filters[:]

            df = _make_common_timing_panel()
            apply_rolling_transform(
                df, y='y', ivar='unit', tindex='tindex',
                post='post', rolling='demean', tpost1=4,
            )

            filters_after = warnings.filters[:]
            assert filters_before == filters_after, (
                "Warning filters were modified by common-timing transformation"
            )

    def test_user_can_still_receive_performance_warning_after_transform(self):
        """After transformation completes, user code should still be able to
        receive PerformanceWarning from their own pandas operations."""
        df = _make_staggered_panel()
        transform_staggered_demean(
            df, y='y', ivar='unit', tvar='time', gvar='gvar'
        )

        # Manually emit a PerformanceWarning to verify it is not suppressed.
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            warnings.warn(
                "User-triggered PerformanceWarning",
                pd.errors.PerformanceWarning,
            )

        perf_warnings = [
            w for w in caught
            if issubclass(w.category, pd.errors.PerformanceWarning)
        ]
        assert len(perf_warnings) == 1, (
            "User-level PerformanceWarning was suppressed after transformation; "
            "the suppression scope has leaked."
        )

# ══════════════════════════════════════════════════════════════════════════════
# End-to-End Integration Tests for the Warning System
#
# These tests run the full lwdid() pipeline with a synthetic staggered panel
# dataset and IPWRA estimation, verifying that the warning registry correctly
# collects, aggregates, and outputs warnings under all three verbose modes.
#
# Requirements: 2.1, 2.4, 3.2, 3.3, 3.4, 4.2, 7.2
# ══════════════════════════════════════════════════════════════════════════════

import numpy as np
import pandas as pd

from lwdid.core import lwdid
from lwdid.warnings_categories import (
    LWDIDWarning,
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
)


def _make_e2e_staggered_panel() -> pd.DataFrame:
    """Create a synthetic staggered panel designed to trigger warnings.

    The dataset has 30 units over 8 time periods (t=1..8) with three
    treatment cohorts and a never-treated group:

    - Cohort g=4: 3 treated units  (small sample → SmallSampleWarning)
    - Cohort g=6: 4 treated units  (small sample → SmallSampleWarning)
    - Never-treated (gvar=0): 23 control units

    A time-invariant covariate ``x1`` is included for IPWRA estimation.
    The covariate distribution differs between treated and control groups
    to create non-trivial propensity scores.

    Returns
    -------
    pd.DataFrame
        Balanced panel in long format with columns:
        unit, time, y, gvar, x1
    """
    np.random.seed(2024)
    records = []

    # Cohort g=4: units 1-3 (small treated group)
    for uid in range(1, 4):
        gvar_val = 4
        x1_val = np.random.normal(2.0, 0.5)
        for t in range(1, 9):
            treatment_effect = 3.0 if t >= gvar_val else 0.0
            y_val = 10.0 + uid + 0.5 * t + treatment_effect + x1_val * 0.3 + np.random.normal(0, 1.0)
            records.append({
                'unit': uid, 'time': t, 'y': y_val,
                'gvar': gvar_val, 'x1': x1_val,
            })

    # Cohort g=6: units 4-7 (small treated group)
    for uid in range(4, 8):
        gvar_val = 6
        x1_val = np.random.normal(1.5, 0.5)
        for t in range(1, 9):
            treatment_effect = 2.0 if t >= gvar_val else 0.0
            y_val = 10.0 + uid + 0.5 * t + treatment_effect + x1_val * 0.3 + np.random.normal(0, 1.0)
            records.append({
                'unit': uid, 'time': t, 'y': y_val,
                'gvar': gvar_val, 'x1': x1_val,
            })

    # Never-treated: units 8-30
    for uid in range(8, 31):
        gvar_val = 0
        x1_val = np.random.normal(0.0, 0.5)
        for t in range(1, 9):
            y_val = 10.0 + uid * 0.5 + 0.5 * t + x1_val * 0.3 + np.random.normal(0, 1.0)
            records.append({
                'unit': uid, 'time': t, 'y': y_val,
                'gvar': gvar_val, 'x1': x1_val,
            })

    return pd.DataFrame(records)


class TestEndToEndDefaultMode:
    """End-to-end tests for verbose='default' mode.

    Verifies that the default mode emits aggregated warning summaries
    instead of per-(g,r) duplicates, and that diagnostics are populated.

    Requirements: 2.1, 2.4, 3.3, 7.2
    """

    def test_default_mode_no_duplicate_warnings(self):
        """Default mode must not emit duplicate warnings of the same category.

        Each warning category should appear at most once in the output,
        as an aggregated summary containing M/T ratio information.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # Collect only LWDIDWarning subclass warnings (ignore unrelated warnings).
        lwdid_warnings = [w for w in caught if issubclass(w.category, LWDIDWarning)]

        # Count occurrences of each warning category.
        category_counts = {}
        for w in lwdid_warnings:
            cat = w.category
            category_counts[cat] = category_counts.get(cat, 0) + 1

        # Each category must appear at most once (aggregated, not duplicated).
        for cat, count in category_counts.items():
            assert count == 1, (
                f"Warning category {cat.__name__} appeared {count} times in "
                f"default mode; expected exactly 1 aggregated summary."
            )

    def test_default_mode_warnings_contain_ratio_info(self):
        """Aggregated warning summaries must contain M/T ratio information.

        The summary message should include the count of affected (g,r) pairs
        and the total number of pairs, e.g. '3/7 (cohort, period) pairs'.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        lwdid_warnings = [w for w in caught if issubclass(w.category, LWDIDWarning)]

        # At least one warning should be emitted (small sample is expected).
        if len(lwdid_warnings) > 0:
            for w in lwdid_warnings:
                msg = str(w.message)
                # Aggregated summaries should contain ratio info like "X/Y" or
                # "N (cohort, period) pairs" or "N occurrences".
                has_ratio = (
                    '(cohort, period)' in msg
                    or 'occurrences' in msg
                    or '/' in msg
                )
                assert has_ratio, (
                    f"Warning message does not contain ratio/count info: {msg}"
                )

    def test_default_mode_returns_valid_results(self):
        """lwdid() must return a valid LWDIDResults object in default mode."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # Basic sanity checks on the results object.
        assert results is not None
        assert hasattr(results, 'att')
        assert hasattr(results, 'diagnostics')


class TestEndToEndQuietMode:
    """End-to-end tests for verbose='quiet' mode.

    Verifies that quiet mode suppresses informational warnings and only
    emits critical warnings (ConvergenceWarning, NumericalWarning).

    Requirements: 3.2, 4.2
    """

    def test_quiet_mode_suppresses_informational_warnings(self):
        """Quiet mode must suppress non-critical warnings like SmallSampleWarning.

        Only critical categories (ConvergenceWarning, NumericalWarning) should
        be emitted. SmallSampleWarning, OverlapWarning, DataWarning are
        informational and must be suppressed.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='quiet',
            )

        lwdid_warnings = [w for w in caught if issubclass(w.category, LWDIDWarning)]

        # Non-critical categories must not appear.
        non_critical_categories = {SmallSampleWarning, OverlapWarning, DataWarning}
        for w in lwdid_warnings:
            assert w.category not in non_critical_categories, (
                f"Quiet mode emitted non-critical warning: {w.category.__name__}: "
                f"{w.message}"
            )

    def test_quiet_mode_diagnostics_still_complete(self):
        """Diagnostics must be fully populated even in quiet mode.

        The verbose setting only controls console output; the diagnostics
        attribute must always contain the complete warning record set.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results_quiet = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='quiet',
            )

        # Diagnostics should be a list (possibly non-empty if warnings were collected).
        assert isinstance(results_quiet.diagnostics, list)

        # Run the same estimation in default mode for comparison.
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results_default = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # Both modes must produce the same diagnostic categories.
        quiet_cats = {d['category'] for d in results_quiet.diagnostics}
        default_cats = {d['category'] for d in results_default.diagnostics}
        assert quiet_cats == default_cats, (
            f"Diagnostics differ between quiet and default modes: "
            f"quiet={quiet_cats}, default={default_cats}"
        )


class TestEndToEndVerboseMode:
    """End-to-end tests for verbose='verbose' mode.

    Verifies that verbose mode emits individual warnings for each (g,r)
    pair that has issues, without aggregation.

    Requirements: 3.4, 4.2
    """

    def test_verbose_mode_emits_individual_warnings(self):
        """Verbose mode must emit more warnings than default mode.

        In verbose mode, each (g,r) pair with an issue produces its own
        warning. In default mode, these are aggregated into one per category.
        Therefore verbose mode should emit >= as many warnings as default.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught_verbose:
            warnings.simplefilter("always")
            results_verbose = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='verbose',
            )

        with warnings.catch_warnings(record=True) as caught_default:
            warnings.simplefilter("always")
            results_default = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        verbose_lwdid = [w for w in caught_verbose if issubclass(w.category, LWDIDWarning)]
        default_lwdid = [w for w in caught_default if issubclass(w.category, LWDIDWarning)]

        # Verbose mode should emit at least as many warnings as default mode.
        assert len(verbose_lwdid) >= len(default_lwdid), (
            f"Verbose mode emitted {len(verbose_lwdid)} warnings, but default "
            f"mode emitted {len(default_lwdid)}. Verbose should emit >= default."
        )

    def test_verbose_mode_diagnostics_match_default(self):
        """Diagnostics must be identical regardless of verbose mode."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results_verbose = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='verbose',
            )

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results_default = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # Same number of diagnostic entries.
        assert len(results_verbose.diagnostics) == len(results_default.diagnostics), (
            f"Diagnostic count differs: verbose={len(results_verbose.diagnostics)}, "
            f"default={len(results_default.diagnostics)}"
        )

        # Same categories present.
        verbose_cats = sorted(d['category'] for d in results_verbose.diagnostics)
        default_cats = sorted(d['category'] for d in results_default.diagnostics)
        assert verbose_cats == default_cats, (
            f"Diagnostic categories differ: verbose={verbose_cats}, default={default_cats}"
        )


class TestEndToEndDiagnosticsStructure:
    """End-to-end tests for the diagnostics attribute structure.

    Verifies that results.diagnostics contains well-formed records with
    the expected keys and value types.

    Requirements: 4.2, 7.2
    """

    def test_diagnostics_is_list(self):
        """results.diagnostics must always be a list."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        assert isinstance(results.diagnostics, list)

    def test_diagnostics_entries_have_required_keys(self):
        """Each diagnostic entry must contain category, message, count,
        affected_pairs, and context_summary keys."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        required_keys = {'category', 'message', 'count', 'affected_pairs', 'context_summary'}

        for entry in results.diagnostics:
            missing = required_keys - set(entry.keys())
            assert not missing, (
                f"Diagnostic entry missing keys: {missing}. Entry: {entry}"
            )

    def test_diagnostics_entry_types(self):
        """Diagnostic entry values must have correct types."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        for entry in results.diagnostics:
            assert isinstance(entry['category'], str), (
                f"category should be str, got {type(entry['category'])}"
            )
            assert isinstance(entry['message'], str), (
                f"message should be str, got {type(entry['message'])}"
            )
            assert isinstance(entry['count'], int), (
                f"count should be int, got {type(entry['count'])}"
            )
            assert isinstance(entry['affected_pairs'], list), (
                f"affected_pairs should be list, got {type(entry['affected_pairs'])}"
            )
            assert isinstance(entry['context_summary'], dict), (
                f"context_summary should be dict, got {type(entry['context_summary'])}"
            )

    def test_diagnostics_category_names_are_valid(self):
        """Diagnostic category names must correspond to known warning classes."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        valid_category_names = {
            'SmallSampleWarning', 'OverlapWarning', 'NumericalWarning',
            'DataWarning', 'ConvergenceWarning', 'LWDIDWarning',
        }

        for entry in results.diagnostics:
            assert entry['category'] in valid_category_names, (
                f"Unknown diagnostic category: {entry['category']}. "
                f"Expected one of {valid_category_names}"
            )

    def test_diagnostics_affected_pairs_are_tuples(self):
        """Each affected_pairs entry must be a (cohort, period) tuple."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        for entry in results.diagnostics:
            for pair in entry['affected_pairs']:
                assert isinstance(pair, (tuple, list)) and len(pair) == 2, (
                    f"affected_pairs entry should be a 2-element tuple, got {pair}"
                )

    def test_diagnostics_count_matches_affected_pairs(self):
        """The count field must be >= len(affected_pairs).

        Count reflects total occurrences; affected_pairs only includes
        entries with non-None cohort/period values.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            results = lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        for entry in results.diagnostics:
            assert entry['count'] >= len(entry['affected_pairs']), (
                f"count ({entry['count']}) < len(affected_pairs) "
                f"({len(entry['affected_pairs'])}) for {entry['category']}"
            )


class TestEndToEndDiagnosticsIndependence:
    """Verify that diagnostics are independent of verbose setting.

    The diagnostics attribute must contain the same information regardless
    of whether verbose is 'quiet', 'default', or 'verbose'.

    Requirements: 4.2
    """

    def test_all_three_modes_produce_same_diagnostics(self):
        """Diagnostics must be identical across quiet, default, and verbose modes."""
        df = _make_e2e_staggered_panel()

        diagnostics_by_mode = {}
        for mode in ('quiet', 'default', 'verbose'):
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                results = lwdid(
                    df, y='y', ivar='unit', tvar='time', gvar='gvar',
                    rolling='demean', estimator='ipwra', controls=['x1'],
                    aggregate='none', verbose=mode,
                )
            diagnostics_by_mode[mode] = results.diagnostics

        # Compare category sets across all modes.
        quiet_cats = sorted(d['category'] for d in diagnostics_by_mode['quiet'])
        default_cats = sorted(d['category'] for d in diagnostics_by_mode['default'])
        verbose_cats = sorted(d['category'] for d in diagnostics_by_mode['verbose'])

        assert quiet_cats == default_cats == verbose_cats, (
            f"Diagnostic categories differ across modes: "
            f"quiet={quiet_cats}, default={default_cats}, verbose={verbose_cats}"
        )

        # Compare counts for each category.
        for mode_a, mode_b in [('quiet', 'default'), ('default', 'verbose')]:
            diag_a = {d['category']: d['count'] for d in diagnostics_by_mode[mode_a]}
            diag_b = {d['category']: d['count'] for d in diagnostics_by_mode[mode_b]}
            assert diag_a == diag_b, (
                f"Diagnostic counts differ between {mode_a} and {mode_b}: "
                f"{mode_a}={diag_a}, {mode_b}={diag_b}"
            )


# ── stacklevel 一致性验证测试 ──────────────────────────────────────
#
# 验证各调用路径中 warnings.warn() 的 stacklevel 设置正确，
# 使得警告的 filename 指向用户代码（测试文件）而非包内部模块。
#
# Requirements: 6.1, 6.2


class TestStacklevelLwdidDirectWarnings:
    """Verify stacklevel for warnings emitted directly by lwdid().

    When lwdid() itself calls warnings.warn() (not via registry flush),
    the warning's filename must point to the caller (this test file),
    not to core.py or any internal module.

    Requirements: 6.1, 6.2
    """

    def test_unknown_kwargs_warning_points_to_caller(self):
        """Unknown kwargs warning should report caller's filename."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            # Pass an unknown kwarg to trigger DataWarning from lwdid()
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ra', aggregate='none',
                verbose='quiet',
                bogus_param=42,
            )

        unknown_kwarg_warnings = [
            w for w in caught
            if issubclass(w.category, DataWarning)
            and 'Unknown keyword argument' in str(w.message)
        ]
        assert len(unknown_kwarg_warnings) >= 1, (
            f"Expected at least 1 unknown-kwargs DataWarning, got {len(unknown_kwarg_warnings)}. "
            f"All warnings: {[(w.category.__name__, str(w.message)[:60]) for w in caught]}"
        )

        for w in unknown_kwarg_warnings:
            assert 'test_warning_system' in w.filename, (
                f"Unknown-kwargs warning filename should reference test file, "
                f"got '{w.filename}'"
            )
            # Must NOT point to core.py internals
            assert 'src/lwdid/core.py' not in w.filename, (
                f"Warning filename should not point to package internal core.py, "
                f"got '{w.filename}'"
            )

    def test_gvar_with_d_post_warning_points_to_caller(self):
        """Warning for gvar + d/post conflict should report caller's filename."""
        df = _make_e2e_staggered_panel()
        # Add d and post columns to trigger the conflict warning
        df['d'] = (df['gvar'] > 0).astype(int)
        df['post'] = (df['time'] >= 4).astype(int)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                d='d', post='post',
                rolling='demean', estimator='ra', aggregate='none',
                verbose='quiet',
            )

        conflict_warnings = [
            w for w in caught
            if issubclass(w.category, DataWarning)
            and 'Staggered mode takes precedence' in str(w.message)
        ]
        assert len(conflict_warnings) >= 1, (
            f"Expected gvar/d-post conflict warning, got none. "
            f"All warnings: {[(w.category.__name__, str(w.message)[:60]) for w in caught]}"
        )

        for w in conflict_warnings:
            assert 'test_warning_system' in w.filename, (
                f"gvar/d-post conflict warning filename should reference test file, "
                f"got '{w.filename}'"
            )


class TestStacklevelRegistryFlushWarnings:
    """Verify stacklevel for warnings emitted via WarningRegistry.flush().

    In staggered mode, warnings collected during (g,r) iteration are
    emitted by registry.flush(). The flush is called from within
    estimate_cohort_time_effects() → lwdid(). The emitted warnings'
    filename should point to the internal flush call site (this is
    acceptable since flush happens inside the package). The key
    requirement is that flush warnings use the correct category and
    contain aggregated information.

    Requirements: 6.1, 6.2
    """

    def test_registry_flush_warnings_use_correct_categories(self):
        """Registry-flushed warnings must use custom categories, not UserWarning."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # All warnings should use LWDIDWarning subclasses
        lwdid_warnings = [
            w for w in caught
            if issubclass(w.category, LWDIDWarning)
        ]
        raw_user_warnings = [
            w for w in caught
            if w.category is UserWarning  # exact match, not subclass
        ]

        assert len(raw_user_warnings) == 0, (
            f"Found {len(raw_user_warnings)} raw UserWarning(s) that should use "
            f"custom categories: "
            f"{[(str(w.message)[:80]) for w in raw_user_warnings]}"
        )
        # Staggered IPWRA with small samples should produce at least some warnings
        assert len(lwdid_warnings) >= 1, (
            "Expected at least 1 LWDIDWarning from staggered IPWRA estimation"
        )

    def test_registry_flush_default_mode_emits_aggregated_summaries(self):
        """Default mode flush should emit aggregated summaries with ratio info."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='none', verbose='default',
            )

        # In default mode, aggregated warnings should contain "(cohort, period) pairs"
        aggregated = [
            w for w in caught
            if issubclass(w.category, LWDIDWarning)
            and '(cohort, period) pairs' in str(w.message)
        ]
        # With small sample data and IPWRA, we expect aggregated warnings
        # (SmallSampleWarning at minimum)
        if len([w for w in caught if issubclass(w.category, LWDIDWarning)]) > 0:
            assert len(aggregated) >= 1, (
                f"Default mode should emit aggregated summaries with ratio info. "
                f"LWDIDWarnings found: "
                f"{[(w.category.__name__, str(w.message)[:80]) for w in caught if issubclass(w.category, LWDIDWarning)]}"
            )


class TestStacklevelCommonTimingWarnings:
    """Verify stacklevel for warnings in common timing (non-staggered) path.

    When lwdid() is called without gvar (common timing mode), warnings
    about ignored staggered parameters should point to the caller.

    Requirements: 6.1, 6.2
    """

    def test_ignored_params_warning_points_to_caller(self):
        """Warning about ignored staggered params should report caller's filename."""
        # Build a common-timing panel without reserved column names
        np.random.seed(42)
        records = []
        for unit_id in range(1, 5):
            d_val = 1 if unit_id <= 2 else 0
            for t in range(1, 7):
                post_val = 1 if t >= 4 else 0
                records.append({
                    'unit': unit_id,
                    'time': t,
                    'y': float(unit_id * 10 + t + np.random.normal(0, 0.5)),
                    'd': d_val,
                    'post': post_val,
                })
        df = pd.DataFrame(records)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', d='d', ivar='unit', tvar='time', post='post',
                rolling='demean',
                # These staggered-only params should trigger a warning
                control_group='never_treated',
                aggregate='overall',
            )

        ignored_warnings = [
            w for w in caught
            if issubclass(w.category, DataWarning)
            and 'ignored' in str(w.message).lower()
        ]
        assert len(ignored_warnings) >= 1, (
            f"Expected warning about ignored staggered params, got none. "
            f"All warnings: {[(w.category.__name__, str(w.message)[:60]) for w in caught]}"
        )

        for w in ignored_warnings:
            assert 'test_warning_system' in w.filename, (
                f"Ignored-params warning filename should reference test file, "
                f"got '{w.filename}'"
            )
            assert 'src/lwdid/core.py' not in w.filename, (
                f"Warning filename should not point to package internal core.py, "
                f"got '{w.filename}'"
            )


class TestStacklevelStaggeredInternalWarnings:
    """Verify stacklevel for warnings inside _lwdid_staggered().

    Warnings emitted by _lwdid_staggered() (e.g., graph=True not supported,
    validation warnings) have higher stacklevel values because they are
    called from lwdid() → _lwdid_staggered(). We verify these warnings
    still point to user code or at least use the correct category.

    Requirements: 6.1, 6.2
    """

    def test_graph_true_warning_does_not_point_to_internal_module(self):
        """graph=True warning in staggered mode should not report internal module filename.

        The warning is emitted from _lwdid_staggered() which is 2 frames
        below lwdid(). With stacklevel=4, the filename should point outside
        the package (to user code or test runner), not to core.py internals.
        In pytest, the exact filename may be the test runner rather than the
        test file itself, so we verify it does NOT point to package internals.
        """
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ra', aggregate='none',
                verbose='quiet',
                graph=True,
            )

        graph_warnings = [
            w for w in caught
            if issubclass(w.category, DataWarning)
            and 'graph' in str(w.message).lower()
        ]
        assert len(graph_warnings) >= 1, (
            f"Expected graph=True warning, got none. "
            f"All warnings: {[(w.category.__name__, str(w.message)[:60]) for w in caught]}"
        )

        for w in graph_warnings:
            # Must NOT point to package internal modules
            assert 'src/lwdid/' not in w.filename, (
                f"graph=True warning filename should not point to package internals, "
                f"got '{w.filename}'"
            )

    def test_all_staggered_warnings_use_custom_categories(self):
        """All warnings from staggered path must use LWDIDWarning subclasses."""
        df = _make_e2e_staggered_panel()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            lwdid(
                df, y='y', ivar='unit', tvar='time', gvar='gvar',
                rolling='demean', estimator='ipwra', controls=['x1'],
                aggregate='cohort', verbose='verbose',
            )

        # Filter to only warnings that originate from lwdid package
        package_warnings = [
            w for w in caught
            if 'lwdid' in str(w.filename).lower()
            or 'test_warning_system' in w.filename
        ]

        for w in package_warnings:
            # Every warning should be a LWDIDWarning subclass or a known
            # third-party warning (e.g., pandas, numpy, statsmodels)
            is_lwdid = issubclass(w.category, LWDIDWarning)
            is_third_party = any(
                lib in w.filename
                for lib in ('pandas', 'numpy', 'statsmodels', 'scipy', 'sklearn')
            )
            assert is_lwdid or is_third_party, (
                f"Warning from lwdid code uses non-custom category "
                f"{w.category.__name__}: '{str(w.message)[:80]}' "
                f"(file: {w.filename})"
            )
