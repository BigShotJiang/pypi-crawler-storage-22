"""
验证 legacy_seed=True 模式能精确复现优化前的参考数据。

使用方法:
    cd lwdid-py_v0.1.0
    python tests/staggered/reference_data/_verify_legacy_seed.py
"""

import json
import os
import sys
import warnings

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))
# 同目录导入
sys.path.insert(0, os.path.dirname(__file__))

from generate_staggered_ri_reference import (
    generate_staggered_test_data,
    compute_observed_att,
)
from lwdid.staggered.randomization import randomization_inference_staggered


def main():
    print("=" * 60)
    print("验证 legacy_seed 模式精确复现参考数据")
    print("=" * 60)

    # 加载参考数据
    ref_path = os.path.join(os.path.dirname(__file__), 'staggered_ri_reference.json')
    with open(ref_path, 'r') as f:
        reference = json.load(f)

    # 生成相同的测试数据
    data = generate_staggered_test_data(n_units=30, n_periods=10, seed=42)
    unit_gvar = data.groupby('id')['gvar'].first()
    n_nt = int((unit_gvar == 0).sum())

    # =========================================================================
    # 场景 1: overall, legacy_seed=True
    # =========================================================================
    print("\n场景 1: overall, legacy_seed=True")
    ref = reference['overall_permutation']
    observed_att = ref['observed_att']

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = randomization_inference_staggered(
            data=data, gvar='gvar', ivar='id', tvar='time', y='y',
            observed_att=observed_att, target='overall',
            ri_method='permutation', rireps=200, seed=42,
            rolling='demean', n_never_treated=n_nt,
            legacy_seed=True, n_jobs=1,
        )

    ref_stats = np.array(ref['permutation_stats'])
    actual_stats = result.permutation_stats

    print(f"  参考 p_value = {ref['p_value']:.4f}")
    print(f"  实际 p_value = {result.p_value:.4f}")
    print(f"  参考 ri_valid = {ref['ri_valid']}")
    print(f"  实际 ri_valid = {result.ri_valid}")
    print(f"  参考 stats 长度 = {len(ref_stats)}")
    print(f"  实际 stats 长度 = {len(actual_stats)}")

    if len(ref_stats) == len(actual_stats):
        max_diff = np.max(np.abs(ref_stats - actual_stats))
        print(f"  最大差异 = {max_diff:.2e}")
        if max_diff < 1e-10:
            print("  ✓ legacy_seed 模式精确复现参考数据")
        else:
            print("  ✗ 存在差异")
    else:
        print("  ✗ 长度不匹配")

    # =========================================================================
    # 场景 2: cohort, legacy_seed=True
    # =========================================================================
    print("\n场景 2: cohort (g=6), legacy_seed=True")
    ref = reference['cohort_permutation']
    observed_att = ref['observed_att']

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = randomization_inference_staggered(
            data=data, gvar='gvar', ivar='id', tvar='time', y='y',
            observed_att=observed_att, target='cohort',
            target_cohort=6,
            ri_method='permutation', rireps=200, seed=42,
            rolling='demean', n_never_treated=n_nt,
            legacy_seed=True, n_jobs=1,
        )

    ref_stats = np.array(ref['permutation_stats'])
    actual_stats = result.permutation_stats

    print(f"  参考 p_value = {ref['p_value']:.4f}")
    print(f"  实际 p_value = {result.p_value:.4f}")
    print(f"  参考 ri_valid = {ref['ri_valid']}")
    print(f"  实际 ri_valid = {result.ri_valid}")

    if len(ref_stats) == len(actual_stats):
        max_diff = np.max(np.abs(ref_stats - actual_stats))
        print(f"  最大差异 = {max_diff:.2e}")
        if max_diff < 1e-10:
            print("  ✓ legacy_seed 模式精确复现参考数据")
        else:
            print("  ✗ 存在差异")
    else:
        print(f"  ✗ 长度不匹配: ref={len(ref_stats)}, actual={len(actual_stats)}")

    # =========================================================================
    # 场景 3: SeedSequence 模式（新默认）- 验证统计性质
    # =========================================================================
    print("\n场景 3: SeedSequence 模式（新默认）- 统计性质验证")
    ref = reference['overall_permutation']
    observed_att = ref['observed_att']

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_new = randomization_inference_staggered(
            data=data, gvar='gvar', ivar='id', tvar='time', y='y',
            observed_att=observed_att, target='overall',
            ri_method='permutation', rireps=200, seed=42,
            rolling='demean', n_never_treated=n_nt,
            legacy_seed=False, n_jobs=1,
        )

    print(f"  新模式 p_value = {result_new.p_value:.4f}")
    print(f"  新模式 ri_valid = {result_new.ri_valid}")
    print(f"  新模式 stats 均值 = {np.mean(result_new.permutation_stats):.6f}")
    print(f"  新模式 stats 标准差 = {np.std(result_new.permutation_stats):.6f}")

    # 新模式的 perm_stats 不需要与参考完全一致（种子派生方式不同），
    # 但统计性质应该合理
    if result_new.p_value <= 0.05:
        print("  ✓ p_value 合理（处理效应 tau=1.0 应被检测到）")
    else:
        print(f"  ⚠ p_value = {result_new.p_value:.4f}，可能偏高")

    # =========================================================================
    # 场景 4: SeedSequence 确定性验证
    # =========================================================================
    print("\n场景 4: SeedSequence 确定性验证（两次运行应完全一致）")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_a = randomization_inference_staggered(
            data=data, gvar='gvar', ivar='id', tvar='time', y='y',
            observed_att=observed_att, target='overall',
            ri_method='permutation', rireps=200, seed=42,
            rolling='demean', n_never_treated=n_nt,
            legacy_seed=False, n_jobs=1,
        )
        result_b = randomization_inference_staggered(
            data=data, gvar='gvar', ivar='id', tvar='time', y='y',
            observed_att=observed_att, target='overall',
            ri_method='permutation', rireps=200, seed=42,
            rolling='demean', n_never_treated=n_nt,
            legacy_seed=False, n_jobs=1,
        )

    if np.array_equal(result_a.permutation_stats, result_b.permutation_stats):
        print("  ✓ SeedSequence 模式确定性验证通过")
    else:
        max_diff = np.max(np.abs(result_a.permutation_stats - result_b.permutation_stats))
        print(f"  ✗ 两次运行不一致，最大差异 = {max_diff:.2e}")


if __name__ == '__main__':
    main()
