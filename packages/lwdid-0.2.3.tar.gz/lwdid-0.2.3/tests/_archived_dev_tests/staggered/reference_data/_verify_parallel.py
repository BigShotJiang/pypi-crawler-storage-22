"""
验证 Staggered RI 并行模式的正确性和确定性。

使用方法:
    cd lwdid-py_v0.1.0
    python tests/staggered/reference_data/_verify_parallel.py
"""

import os
import sys
import time
import warnings

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))
sys.path.insert(0, os.path.dirname(__file__))

from generate_staggered_ri_reference import generate_staggered_test_data, compute_observed_att
from lwdid.staggered.randomization import randomization_inference_staggered


def main():
    print("=" * 60)
    print("验证 Staggered RI 并行模式")
    print("=" * 60)

    data = generate_staggered_test_data(n_units=30, n_periods=10, seed=42)
    unit_gvar = data.groupby('id')['gvar'].first()
    n_nt = int((unit_gvar == 0).sum())
    observed_att = compute_observed_att(data, 'y', 'id', 'time', 'gvar', 'overall')

    common_kwargs = dict(
        data=data, gvar='gvar', ivar='id', tvar='time', y='y',
        observed_att=observed_att, target='overall',
        ri_method='permutation', rireps=100, seed=42,
        rolling='demean', n_never_treated=n_nt,
        legacy_seed=False,
    )

    # =========================================================================
    # 测试 1: 串行 vs 并行（排序后应一致）
    # =========================================================================
    print("\n测试 1: 串行 vs 并行（排序后应一致）")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_serial = randomization_inference_staggered(**common_kwargs, n_jobs=1)
        result_parallel = randomization_inference_staggered(**common_kwargs, n_jobs=2)

    serial_sorted = np.sort(result_serial.permutation_stats)
    parallel_sorted = np.sort(result_parallel.permutation_stats)

    print(f"  串行 ri_valid = {result_serial.ri_valid}")
    print(f"  并行 ri_valid = {result_parallel.ri_valid}")

    if len(serial_sorted) == len(parallel_sorted):
        max_diff = np.max(np.abs(serial_sorted - parallel_sorted))
        print(f"  排序后最大差异 = {max_diff:.2e}")
        if max_diff < 1e-10:
            print("  ✓ 串行与并行结果一致")
        else:
            print("  ✗ 存在差异")
    else:
        print(f"  ✗ 长度不匹配: serial={len(serial_sorted)}, parallel={len(parallel_sorted)}")

    # p-value 应一致
    if result_serial.p_value == result_parallel.p_value:
        print(f"  ✓ p_value 一致: {result_serial.p_value:.4f}")
    else:
        print(f"  ✗ p_value 不一致: serial={result_serial.p_value:.4f}, "
              f"parallel={result_parallel.p_value:.4f}")

    # =========================================================================
    # 测试 2: 并行确定性（多次运行应一致）
    # =========================================================================
    print("\n测试 2: 并行确定性（3 次运行应完全一致）")
    results = []
    for i in range(3):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            r = randomization_inference_staggered(**common_kwargs, n_jobs=2)
        results.append(r.permutation_stats)

    all_equal = True
    for i in range(1, len(results)):
        if not np.array_equal(results[0], results[i]):
            all_equal = False
            break

    if all_equal:
        print("  ✓ 3 次并行运行结果完全一致")
    else:
        print("  ✗ 并行运行结果不一致")

    # =========================================================================
    # 测试 3: n_jobs=-1（使用所有核心）
    # =========================================================================
    print("\n测试 3: n_jobs=-1（使用所有核心）")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_all = randomization_inference_staggered(**common_kwargs, n_jobs=-1)

    all_sorted = np.sort(result_all.permutation_stats)
    if len(serial_sorted) == len(all_sorted):
        max_diff = np.max(np.abs(serial_sorted - all_sorted))
        print(f"  排序后最大差异 = {max_diff:.2e}")
        if max_diff < 1e-10:
            print("  ✓ n_jobs=-1 与串行结果一致")
        else:
            print("  ✗ 存在差异")
    else:
        print(f"  ✗ 长度不匹配")

    # =========================================================================
    # 测试 4: 性能比较
    # =========================================================================
    print("\n测试 4: 性能比较 (rireps=100)")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        t0 = time.perf_counter()
        randomization_inference_staggered(**common_kwargs, n_jobs=1)
        t_serial = time.perf_counter() - t0

        t0 = time.perf_counter()
        randomization_inference_staggered(**common_kwargs, n_jobs=-1)
        t_parallel = time.perf_counter() - t0

    speedup = t_serial / t_parallel if t_parallel > 0 else float('inf')
    print(f"  串行: {t_serial:.2f}s")
    print(f"  并行: {t_parallel:.2f}s")
    print(f"  加速比: {speedup:.1f}x")

    print("\n" + "=" * 60)
    print("验证完成")
    print("=" * 60)


if __name__ == '__main__':
    main()
