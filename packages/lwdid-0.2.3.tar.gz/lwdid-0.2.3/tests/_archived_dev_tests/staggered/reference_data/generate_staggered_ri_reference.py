"""
生成 Staggered Randomization Inference 优化前参考结果。

在进行任何 Staggered RI 性能优化之前运行此脚本，保存完整的数值结果作为回归测试基准。
覆盖 2 个场景:
  1. overall target, permutation
  2. cohort target, permutation

注意: 由于 Staggered RI 的种子派生方式将改变（SeedSequence），
此参考数据主要用于验证统计性质（p-value 合理性、perm_stats 分布）
而非逐元素一致性。

使用方法:
    cd lwdid-py_v0.1.0
    python tests/staggered/reference_data/generate_staggered_ri_reference.py
"""

import json
import os
import sys
import warnings

import numpy as np
import pandas as pd

# 确保可以导入 lwdid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

from lwdid.staggered.randomization import (
    randomization_inference_staggered,
)
from lwdid.staggered.transformations import transform_staggered_demean
from lwdid.staggered.aggregation import aggregate_to_overall, aggregate_to_cohort


def generate_staggered_test_data(
    n_units=30, n_periods=10, seed=42
):
    """
    生成用于 Staggered RI 测试的合成面板数据。

    创建一个简单的 staggered adoption 面板:
    - n_units 个单位，n_periods 个时期
    - 3 个 cohort: g=4, g=6, g=8
    - 约 1/4 的单位是 never-treated (gvar=0)
    - 处理效应 tau=1.0

    Parameters
    ----------
    n_units : int
        单位数
    n_periods : int
        时期数 (1 到 n_periods)
    seed : int
        随机种子

    Returns
    -------
    pd.DataFrame
        面板数据，包含 id, time, gvar, y 列
    """
    rng = np.random.default_rng(seed)

    # 分配 cohort
    # 约 25% never-treated, 其余均匀分配到 3 个 cohort
    cohort_values = [0, 4, 6, 8]
    cohort_probs = [0.25, 0.25, 0.25, 0.25]
    unit_cohorts = rng.choice(cohort_values, size=n_units, p=cohort_probs)

    # 确保每个 cohort 至少有 2 个单位
    for g in cohort_values:
        count = np.sum(unit_cohorts == g)
        if count < 2:
            # 从最大 cohort 借用
            largest = max(cohort_values, key=lambda x: np.sum(unit_cohorts == x))
            idx = np.where(unit_cohorts == largest)[0]
            needed = 2 - count
            for i in range(min(needed, len(idx))):
                unit_cohorts[idx[i]] = g

    rows = []
    for i in range(n_units):
        g = unit_cohorts[i]
        unit_fe = rng.normal(0, 0.5)  # 单位固定效应
        for t in range(1, n_periods + 1):
            time_fe = 0.1 * t  # 时间趋势
            # 处理效应: 如果 g > 0 且 t >= g
            treat_effect = 1.0 if (g > 0 and t >= g) else 0.0
            y = unit_fe + time_fe + treat_effect + rng.normal(0, 0.5)
            rows.append({
                'id': i,
                'time': t,
                'gvar': g,
                'y': y,
            })

    return pd.DataFrame(rows)



def compute_observed_att(data, y, ivar, tvar, gvar, target, rolling='demean',
                         target_cohort=None, target_period=None):
    """
    计算观测到的 ATT 统计量。

    先做 staggered demean 变换，再根据 target 类型聚合。

    Parameters
    ----------
    data : pd.DataFrame
        面板数据
    y, ivar, tvar, gvar : str
        列名
    target : str
        'overall' 或 'cohort'
    rolling : str
        变换类型
    target_cohort : int, optional
        目标 cohort（target='cohort' 时需要）
    target_period : int, optional
        目标时期（target='cohort_time' 时需要）

    Returns
    -------
    float
        观测到的 ATT
    """
    data_transformed = transform_staggered_demean(data, y, ivar, tvar, gvar)

    if target == 'overall':
        result = aggregate_to_overall(
            data_transformed, gvar, ivar, tvar,
            transform_type='demean',
        )
        return result.att
    elif target == 'cohort':
        T_max = int(data[tvar].max())
        results = aggregate_to_cohort(
            data_transformed, gvar, ivar, tvar,
            cohorts=[target_cohort], T_max=T_max,
            transform_type='demean',
        )
        if results:
            return results[0].att
        raise ValueError(f"无法估计 cohort {target_cohort} 的效应")
    else:
        raise ValueError(f"不支持的 target: {target}")


def generate_staggered_ri_reference():
    """生成 Staggered RI 优化前参考结果（2 个场景）。"""
    print("=" * 60)
    print("生成 Staggered Randomization Inference 参考数据")
    print("=" * 60)

    all_references = {}

    # 生成合成数据
    data = generate_staggered_test_data(n_units=30, n_periods=10, seed=42)
    print(f"\n合成数据: {len(data)} 行, {data['id'].nunique()} 个单位, "
          f"{data['time'].nunique()} 个时期")

    # 统计 cohort 分布
    unit_gvar = data.groupby('id')['gvar'].first()
    for g in sorted(unit_gvar.unique()):
        n = int((unit_gvar == g).sum())
        label = "never-treated" if g == 0 else f"cohort {g}"
        print(f"  {label}: {n} 个单位")

    # =========================================================================
    # 场景 1: overall target, permutation
    # =========================================================================
    print("\n场景 1: overall target, permutation")

    # 计算观测 ATT
    observed_att_overall = compute_observed_att(
        data, 'y', 'id', 'time', 'gvar', target='overall'
    )
    print(f"  观测 ATT (overall) = {observed_att_overall:.6f}")

    # 计算 never-treated 单位数
    n_nt = int((unit_gvar == 0).sum())
    print(f"  never-treated 单位数 = {n_nt}")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_overall = randomization_inference_staggered(
            data=data,
            gvar='gvar',
            ivar='id',
            tvar='time',
            y='y',
            observed_att=observed_att_overall,
            target='overall',
            ri_method='permutation',
            rireps=200,
            seed=42,
            rolling='demean',
            n_never_treated=n_nt,
        )

    ref_overall = {
        'observed_att': float(observed_att_overall),
        'p_value': float(result_overall.p_value),
        'ri_method': result_overall.ri_method,
        'ri_reps': int(result_overall.ri_reps),
        'ri_valid': int(result_overall.ri_valid),
        'ri_failed': int(result_overall.ri_failed),
        'permutation_stats': result_overall.permutation_stats.tolist(),
    }
    all_references['overall_permutation'] = ref_overall
    print(f"  p_value = {ref_overall['p_value']:.4f}")
    print(f"  ri_valid = {ref_overall['ri_valid']}, "
          f"ri_failed = {ref_overall['ri_failed']}")
    stats = result_overall.permutation_stats
    print(f"  perm_stats: {len(stats)} 个, "
          f"范围 [{np.min(stats):.6f}, {np.max(stats):.6f}]")
    print(f"  perm_stats 均值 = {np.mean(stats):.6f}, "
          f"标准差 = {np.std(stats):.6f}")

    # =========================================================================
    # 场景 2: cohort target, permutation (选择 cohort=6)
    # =========================================================================
    print("\n场景 2: cohort target (g=6), permutation")

    target_cohort = 6
    observed_att_cohort = compute_observed_att(
        data, 'y', 'id', 'time', 'gvar', target='cohort',
        target_cohort=target_cohort,
    )
    print(f"  观测 ATT (cohort={target_cohort}) = {observed_att_cohort:.6f}")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result_cohort = randomization_inference_staggered(
            data=data,
            gvar='gvar',
            ivar='id',
            tvar='time',
            y='y',
            observed_att=observed_att_cohort,
            target='cohort',
            target_cohort=target_cohort,
            ri_method='permutation',
            rireps=200,
            seed=42,
            rolling='demean',
            n_never_treated=n_nt,
        )

    ref_cohort = {
        'observed_att': float(observed_att_cohort),
        'target_cohort': target_cohort,
        'p_value': float(result_cohort.p_value),
        'ri_method': result_cohort.ri_method,
        'ri_reps': int(result_cohort.ri_reps),
        'ri_valid': int(result_cohort.ri_valid),
        'ri_failed': int(result_cohort.ri_failed),
        'permutation_stats': result_cohort.permutation_stats.tolist(),
    }
    all_references['cohort_permutation'] = ref_cohort
    print(f"  p_value = {ref_cohort['p_value']:.4f}")
    print(f"  ri_valid = {ref_cohort['ri_valid']}, "
          f"ri_failed = {ref_cohort['ri_failed']}")
    stats = result_cohort.permutation_stats
    print(f"  perm_stats: {len(stats)} 个, "
          f"范围 [{np.min(stats):.6f}, {np.max(stats):.6f}]")

    # =========================================================================
    # 元数据
    # =========================================================================
    all_references['_metadata'] = {
        'data_params': {
            'n_units': 30,
            'n_periods': 10,
            'seed': 42,
            'cohorts': [0, 4, 6, 8],
            'treatment_effect': 1.0,
        },
        'ri_params': {
            'rireps': 200,
            'seed': 42,
            'ri_method': 'permutation',
            'rolling': 'demean',
        },
        'description': (
            'Staggered RI 优化前参考结果。'
            '由于种子派生方式将改变（SeedSequence），'
            '此数据主要用于验证统计性质而非逐元素一致性。'
        ),
    }

    return all_references


def main():
    """主函数：生成 Staggered RI 参考数据并保存。"""
    output_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(output_dir, exist_ok=True)

    reference = generate_staggered_ri_reference()

    output_path = os.path.join(output_dir, 'staggered_ri_reference.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(reference, f, indent=2, ensure_ascii=False)
    print(f"\n✓ 参考数据已保存到: {output_path}")

    # 汇总
    print("\n" + "=" * 60)
    print("Staggered RI 参考数据生成完成")
    print("=" * 60)
    n_scenarios = len(reference) - 1  # 排除 _metadata
    print(f"场景数: {n_scenarios}")
    print(f"输出文件: {output_path}")


if __name__ == '__main__':
    main()
