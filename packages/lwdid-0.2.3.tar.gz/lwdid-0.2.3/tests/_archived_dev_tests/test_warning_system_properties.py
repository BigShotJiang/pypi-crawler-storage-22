"""
属性测试：警告系统重构

使用 hypothesis 库对警告系统的正确性属性进行 property-based testing。
每个属性测试至少运行 100 次迭代。
"""

import warnings

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st

from lwdid.warnings_categories import (
    LWDIDWarning,
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
)

# ── 生成器策略 ──────────────────────────────────────────────────────

# 所有 LWDIDWarning 子类列表
_WARNING_SUBCLASSES = [
    SmallSampleWarning,
    OverlapWarning,
    NumericalWarning,
    DataWarning,
    ConvergenceWarning,
]

# 从子类列表中随机选择一个警告类别
warning_category_st = st.sampled_from(_WARNING_SUBCLASSES)

# 生成两个不同的警告类别对
distinct_category_pair_st = st.tuples(
    warning_category_st, warning_category_st
).filter(lambda pair: pair[0] is not pair[1])


# ── Property 7: 警告类别过滤隔离性 ─────────────────────────────────


class TestProperty7WarningCategoryFilterIsolation:
    """Property 7: 警告类别过滤隔离性

    Feature: warning-system-overhaul, Property 7: 警告类别过滤隔离性

    **Validates: Requirements 1.4**
    """

    @given(data=distinct_category_pair_st, msg=st.text(min_size=1, max_size=50))
    @settings(max_examples=100)
    def test_filtering_c1_suppresses_only_c1(self, data, msg):
        """Feature: warning-system-overhaul, Property 7: 警告类别过滤隔离性

        对于任意两个不同的警告类别 C1 和 C2，
        使用 filterwarnings('ignore', category=C1) 过滤后，
        C1 类别的警告应被抑制，而 C2 类别的警告应正常输出。

        **Validates: Requirements 1.4**
        """
        c1, c2 = data

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            # 仅过滤 C1 类别
            warnings.filterwarnings("ignore", category=c1)

            # 发出 C1 和 C2 两种警告
            warnings.warn(f"c1: {msg}", c1)
            warnings.warn(f"c2: {msg}", c2)

        # C1 应被抑制，C2 应被捕获
        categories_caught = [w.category for w in caught]
        assert c1 not in categories_caught, (
            f"C1={c1.__name__} 应被抑制但仍出现在捕获列表中"
        )
        assert c2 in categories_caught, (
            f"C2={c2.__name__} 应正常输出但未出现在捕获列表中"
        )

    @given(data=distinct_category_pair_st, msg=st.text(min_size=1, max_size=50))
    @settings(max_examples=100)
    def test_filtering_c1_does_not_affect_c2_message(self, data, msg):
        """Feature: warning-system-overhaul, Property 7: 警告类别过滤隔离性

        对于任意两个不同的警告类别 C1 和 C2，
        过滤 C1 后，C2 的警告消息内容应完整保留。

        **Validates: Requirements 1.4**
        """
        c1, c2 = data
        expected_msg = f"c2: {msg}"

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            warnings.filterwarnings("ignore", category=c1)

            warnings.warn(f"c1: {msg}", c1)
            warnings.warn(expected_msg, c2)

        # 验证 C2 的消息内容完整
        c2_warnings = [w for w in caught if w.category is c2]
        assert len(c2_warnings) == 1, (
            f"应恰好捕获 1 条 C2={c2.__name__} 警告，实际捕获 {len(c2_warnings)} 条"
        )
        assert str(c2_warnings[0].message) == expected_msg, (
            f"C2 警告消息不匹配: 期望 {expected_msg!r}, 实际 {str(c2_warnings[0].message)!r}"
        )

    @given(category=warning_category_st, msg=st.text(min_size=1, max_size=50))
    @settings(max_examples=100)
    def test_filtering_category_suppresses_itself(self, category, msg):
        """Feature: warning-system-overhaul, Property 7: 警告类别过滤隔离性

        对于任意警告类别 C，过滤 C 后，C 类别的警告应被完全抑制。

        **Validates: Requirements 1.4**
        """
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            warnings.filterwarnings("ignore", category=category)

            warnings.warn(msg, category)

        categories_caught = [w.category for w in caught]
        assert category not in categories_caught, (
            f"{category.__name__} 应被抑制但仍出现在捕获列表中"
        )

from lwdid.warning_registry import WarningRegistry

# ── 额外生成器策略（用于 WarningRegistry 属性测试）──────────────────

# (g, r) 对生成器：cohort 为正整数，period >= cohort
gr_pair_st = st.tuples(
    st.integers(min_value=1, max_value=2100),  # cohort
    st.integers(min_value=1, max_value=2100),  # period
).filter(lambda pair: pair[1] >= pair[0])

# 警告记录生成器：(category, message, cohort, period, context)
warning_record_st = st.tuples(
    warning_category_st,
    st.text(min_size=1, max_size=80),
    gr_pair_st,
    st.fixed_dictionaries({}, optional={
        'n_treated': st.integers(min_value=1, max_value=1000),
        'weights_cv': st.floats(min_value=0.0, max_value=10.0, allow_nan=False),
    }),
)

# 警告记录列表生成器（至少 1 条，最多 50 条）
warning_records_list_st = st.lists(warning_record_st, min_size=1, max_size=50)


# ── Property 1: 收集模式不泄漏警告 ─────────────────────────────────


class TestProperty1CollectDoesNotLeakWarnings:
    """Property 1: 收集模式不泄漏警告

    Feature: warning-system-overhaul, Property 1: 收集模式不泄漏警告

    **Validates: Requirements 2.1**
    """

    @given(
        records=warning_records_list_st,
        verbose=st.sampled_from(['quiet', 'default', 'verbose']),
    )
    @settings(max_examples=100)
    def test_collect_does_not_emit_warnings_before_flush(self, records, verbose):
        """Feature: warning-system-overhaul, Property 1: 收集模式不泄漏警告

        对于任意序列的 collect() 调用（无论数量和类别），
        在 flush() 被调用之前，WarningRegistry 不应触发任何
        Python warnings.warn() 输出。

        **Validates: Requirements 2.1**
        """
        registry = WarningRegistry(verbose=verbose)

        # 在 catch_warnings 中记录所有警告
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")

            # 执行一系列 collect() 调用
            for category, message, (cohort, period), context in records:
                registry.collect(
                    category=category,
                    message=message,
                    cohort=cohort,
                    period=period,
                    context=context,
                )

        # flush() 尚未调用，不应有任何警告被触发
        assert len(caught) == 0, (
            f"在 flush() 调用之前不应有警告输出，"
            f"但捕获到 {len(caught)} 条警告: "
            f"{[(w.category.__name__, str(w.message)) for w in caught]}"
        )

    @given(
        records=warning_records_list_st,
        verbose=st.sampled_from(['quiet', 'default', 'verbose']),
    )
    @settings(max_examples=100)
    def test_warnings_only_emitted_after_flush(self, records, verbose):
        """Feature: warning-system-overhaul, Property 1: 收集模式不泄漏警告

        验证警告仅在 flush() 调用后才被触发，
        collect() 阶段严格不产生任何输出。

        **Validates: Requirements 2.1**
        """
        registry = WarningRegistry(verbose=verbose)

        # 阶段 1：collect 阶段 — 不应有警告
        with warnings.catch_warnings(record=True) as caught_during_collect:
            warnings.simplefilter("always")

            for category, message, (cohort, period), context in records:
                registry.collect(
                    category=category,
                    message=message,
                    cohort=cohort,
                    period=period,
                    context=context,
                )

        assert len(caught_during_collect) == 0, (
            f"collect() 阶段不应产生警告，"
            f"但捕获到 {len(caught_during_collect)} 条"
        )

        # 阶段 2：flush 阶段 — 可能产生警告（取决于 verbose 级别和内容）
        with warnings.catch_warnings(record=True) as caught_during_flush:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        # 不对 flush 阶段的警告数量做断言（那是其他属性的职责），
        # 只确认 collect 阶段确实没有泄漏
        # （上面的 assert 已经验证了这一点）

    @given(verbose=st.sampled_from(['quiet', 'default', 'verbose']))
    @settings(max_examples=100)
    def test_empty_registry_collect_no_warnings(self, verbose):
        """Feature: warning-system-overhaul, Property 1: 收集模式不泄漏警告

        空的 WarningRegistry（没有任何 collect 调用）
        在 flush 之前也不应产生任何警告。

        **Validates: Requirements 2.1**
        """
        registry = WarningRegistry(verbose=verbose)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            # 不调用 collect，也不调用 flush
            pass

        assert len(caught) == 0, (
            f"空注册表不应产生任何警告，但捕获到 {len(caught)} 条"
        )


# ── Property 2: 按类别聚合输出 ─────────────────────────────────────


class TestProperty2AggregateOutputByCategory:
    """Property 2: 按类别聚合输出

    Feature: warning-system-overhaul, Property 2: 按类别聚合输出

    **Validates: Requirements 2.2, 2.4, 2.5, 3.3**
    """

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_flush_default_emits_exactly_k_warnings(self, records):
        """Feature: warning-system-overhaul, Property 2: 按类别聚合输出

        对于任意包含 K 种不同警告类别的 N 条警告记录（N ≥ 1, K ≥ 1），
        在 default 模式下调用 flush() 应恰好产生 K 条聚合输出（每种类别一条）。

        **Validates: Requirements 2.2, 2.4, 2.5, 3.3**
        """
        registry = WarningRegistry(verbose='default')

        # 收集所有警告记录
        distinct_categories = set()
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            distinct_categories.add(category)

        k = len(distinct_categories)

        # flush 并捕获输出的警告
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        # 应恰好产生 K 条聚合输出
        assert len(caught) == k, (
            f"期望 {k} 条聚合警告（对应 {k} 种类别），"
            f"实际捕获 {len(caught)} 条。"
            f"类别集合: {[c.__name__ for c in distinct_categories]}，"
            f"捕获的类别: {[w.category.__name__ for w in caught]}"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_flush_default_each_category_appears_once(self, records):
        """Feature: warning-system-overhaul, Property 2: 按类别聚合输出

        在 default 模式下，flush() 输出的每种警告类别应恰好出现一次，
        即使该类别在收集阶段出现了多次。

        **Validates: Requirements 2.2, 2.4, 2.5, 3.3**
        """
        registry = WarningRegistry(verbose='default')

        distinct_categories = set()
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            distinct_categories.add(category)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        # 捕获到的警告类别集合应与输入的不同类别集合完全一致
        caught_categories = {w.category for w in caught}
        assert caught_categories == distinct_categories, (
            f"输出的类别集合与输入不匹配。"
            f"期望: {sorted(c.__name__ for c in distinct_categories)}，"
            f"实际: {sorted(c.__name__ for c in caught_categories)}"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_flush_default_no_duplicate_categories(self, records):
        """Feature: warning-system-overhaul, Property 2: 按类别聚合输出

        在 default 模式下，flush() 输出中不应有重复的警告类别，
        验证同一类型警告出现超过 1 次时仅输出 1 条聚合摘要。

        **Validates: Requirements 2.2, 2.4, 2.5, 3.3**
        """
        registry = WarningRegistry(verbose='default')

        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        # 检查输出中没有重复类别
        caught_categories = [w.category for w in caught]
        assert len(caught_categories) == len(set(caught_categories)), (
            f"输出中存在重复类别。"
            f"捕获的类别列表: {[c.__name__ for c in caught_categories]}"
        )


# ── Property 3: 聚合摘要包含正确的统计信息 ─────────────────────────


# 生成同一类别的多条警告记录（每条关联不同的 (g,r) 对）
def _same_category_records_st():
    """生成同一类别的 M 条警告记录，每条关联唯一的 (g,r) 对。"""
    return (
        st.tuples(
            warning_category_st,
            # 生成 1~30 个不同的 (g,r) 对
            st.lists(
                gr_pair_st,
                min_size=1,
                max_size=30,
                unique=True,
            ),
            st.text(min_size=1, max_size=60),
        )
    )


same_category_records_st = _same_category_records_st()


class TestProperty3AggregateSummaryStatistics:
    """Property 3: 聚合摘要包含正确的统计信息

    Feature: warning-system-overhaul, Property 3: 聚合摘要包含正确的统计信息

    **Validates: Requirements 2.3**
    """

    @given(
        data=same_category_records_st,
        # total_pairs >= M，确保 T 合理
        extra_pairs=st.integers(min_value=0, max_value=200),
    )
    @settings(max_examples=100)
    def test_summary_contains_m_and_t_values(self, data, extra_pairs):
        """Feature: warning-system-overhaul, Property 3: 聚合摘要包含正确的统计信息

        对于任意包含 M 条同类别警告的集合（关联到不同的 (g,r) 对），
        且总对数为 T，聚合摘要消息应包含 M 和 T 的数值。

        **Validates: Requirements 2.3**
        """
        category, gr_pairs, message = data
        m = len(gr_pairs)
        t = m + extra_pairs  # T >= M

        registry = WarningRegistry(verbose='default')
        for cohort, period in gr_pairs:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
            )

        # flush 并捕获输出
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=t)

        assert len(caught) == 1, (
            f"单一类别应产生恰好 1 条聚合摘要，实际 {len(caught)} 条"
        )

        summary_msg = str(caught[0].message)

        # 摘要消息应包含 M/T 格式的比例信息
        ratio_str = f"{m}/{t}"
        assert ratio_str in summary_msg, (
            f"聚合摘要应包含 '{ratio_str}'（M={m}, T={t}），"
            f"但实际消息为: {summary_msg!r}"
        )

    @given(
        data=same_category_records_st,
        extra_pairs=st.integers(min_value=0, max_value=200),
    )
    @settings(max_examples=100)
    def test_summary_contains_cohort_period_label(self, data, extra_pairs):
        """Feature: warning-system-overhaul, Property 3: 聚合摘要包含正确的统计信息

        聚合摘要消息应包含 "(cohort, period) pairs" 标签，
        明确说明 M/T 比例的含义。

        **Validates: Requirements 2.3**
        """
        category, gr_pairs, message = data
        m = len(gr_pairs)
        t = m + extra_pairs

        registry = WarningRegistry(verbose='default')
        for cohort, period in gr_pairs:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=t)

        assert len(caught) == 1
        summary_msg = str(caught[0].message)

        # 消息应包含 "(cohort, period) pairs" 标签
        assert "(cohort, period) pairs" in summary_msg, (
            f"聚合摘要应包含 '(cohort, period) pairs' 标签，"
            f"但实际消息为: {summary_msg!r}"
        )

    @given(
        data=same_category_records_st,
        extra_pairs=st.integers(min_value=0, max_value=200),
    )
    @settings(max_examples=100)
    def test_summary_m_equals_affected_pairs_count(self, data, extra_pairs):
        """Feature: warning-system-overhaul, Property 3: 聚合摘要包含正确的统计信息

        摘要中的 M 值应等于该类别关联的不同 (g,r) 对数量，
        即 collect() 时传入了 cohort 和 period 的记录数。

        **Validates: Requirements 2.3**
        """
        category, gr_pairs, message = data
        m = len(gr_pairs)
        t = m + extra_pairs

        registry = WarningRegistry(verbose='default')
        for cohort, period in gr_pairs:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=t)

        assert len(caught) == 1
        summary_msg = str(caught[0].message)

        # 从消息中提取 M/T 格式，验证 M 值正确
        import re
        match = re.search(r'(\d+)/(\d+)', summary_msg)
        assert match is not None, (
            f"聚合摘要应包含 M/T 格式的比例，"
            f"但实际消息为: {summary_msg!r}"
        )
        extracted_m = int(match.group(1))
        extracted_t = int(match.group(2))

        assert extracted_m == m, (
            f"摘要中的 M 值应为 {m}（受影响对数），"
            f"但提取到 {extracted_m}。消息: {summary_msg!r}"
        )
        assert extracted_t == t, (
            f"摘要中的 T 值应为 {t}（总对数），"
            f"但提取到 {extracted_t}。消息: {summary_msg!r}"
        )


from lwdid.warning_registry import _CRITICAL_CATEGORIES

# ── 额外生成器策略（用于 Property 4）──────────────────────────────

# 严重（critical）警告类别
_CRITICAL_SUBCLASSES = [c for c in _WARNING_SUBCLASSES if c in _CRITICAL_CATEGORIES]
# 信息性（非 critical）警告类别
_INFORMATIONAL_SUBCLASSES = [c for c in _WARNING_SUBCLASSES if c not in _CRITICAL_CATEGORIES]

critical_category_st = st.sampled_from(_CRITICAL_SUBCLASSES)
informational_category_st = st.sampled_from(_INFORMATIONAL_SUBCLASSES)

# 生成混合严重级别的警告记录列表：至少包含 1 条 critical 和 1 条 informational
_critical_record_st = st.tuples(
    critical_category_st,
    st.text(min_size=1, max_size=80),
    gr_pair_st,
    st.fixed_dictionaries({}, optional={
        'n_treated': st.integers(min_value=1, max_value=1000),
    }),
)

_informational_record_st = st.tuples(
    informational_category_st,
    st.text(min_size=1, max_size=80),
    gr_pair_st,
    st.fixed_dictionaries({}, optional={
        'n_treated': st.integers(min_value=1, max_value=1000),
    }),
)

# 混合列表：至少 1 条 critical + 至少 1 条 informational
mixed_severity_records_st = st.tuples(
    st.lists(_critical_record_st, min_size=1, max_size=25),
    st.lists(_informational_record_st, min_size=1, max_size=25),
).map(lambda pair: pair[0] + pair[1])


# ── Property 4: quiet 模式仅输出严重警告 ───────────────────────────


class TestProperty4QuietModeOnlyCriticalWarnings:
    """Property 4: quiet 模式仅输出严重警告

    Feature: warning-system-overhaul, Property 4: quiet 模式仅输出严重警告

    **Validates: Requirements 3.2**
    """

    @given(records=mixed_severity_records_st)
    @settings(max_examples=100)
    def test_quiet_flush_emits_only_critical_categories(self, records):
        """Feature: warning-system-overhaul, Property 4: quiet 模式仅输出严重警告

        对于任意混合了不同严重级别的警告集合，在 quiet 模式下调用 flush()
        应仅输出被标记为严重（critical）的警告类别，抑制所有信息性警告。

        **Validates: Requirements 3.2**
        """
        registry = WarningRegistry(verbose='quiet')

        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        # 所有输出的警告类别都应属于 _CRITICAL_CATEGORIES
        for w in caught:
            assert w.category in _CRITICAL_CATEGORIES, (
                f"quiet 模式下不应输出非严重类别 {w.category.__name__}，"
                f"仅允许 {[c.__name__ for c in _CRITICAL_CATEGORIES]}"
            )

    @given(records=mixed_severity_records_st)
    @settings(max_examples=100)
    def test_quiet_flush_suppresses_all_informational(self, records):
        """Feature: warning-system-overhaul, Property 4: quiet 模式仅输出严重警告

        在 quiet 模式下，所有信息性（非 critical）类别的警告应被完全抑制，
        不出现在 flush() 的输出中。

        **Validates: Requirements 3.2**
        """
        registry = WarningRegistry(verbose='quiet')

        informational_categories_in_input = set()
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            if category not in _CRITICAL_CATEGORIES:
                informational_categories_in_input.add(category)

        # 确保输入中确实包含信息性类别
        assume(len(informational_categories_in_input) > 0)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        caught_categories = {w.category for w in caught}
        # 信息性类别不应出现在输出中
        leaked = informational_categories_in_input & caught_categories
        assert len(leaked) == 0, (
            f"quiet 模式下信息性类别应被抑制，但以下类别仍被输出: "
            f"{[c.__name__ for c in leaked]}"
        )

    @given(records=mixed_severity_records_st)
    @settings(max_examples=100)
    def test_quiet_flush_emits_all_present_critical_categories(self, records):
        """Feature: warning-system-overhaul, Property 4: quiet 模式仅输出严重警告

        在 quiet 模式下，输入中存在的每种严重类别都应在 flush() 输出中
        恰好出现一次（聚合形式），不遗漏任何严重警告。

        **Validates: Requirements 3.2**
        """
        registry = WarningRegistry(verbose='quiet')

        critical_categories_in_input = set()
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            if category in _CRITICAL_CATEGORIES:
                critical_categories_in_input.add(category)

        # 确保输入中确实包含严重类别
        assume(len(critical_categories_in_input) > 0)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        caught_categories = {w.category for w in caught}
        # 所有输入中的严重类别都应出现在输出中
        missing = critical_categories_in_input - caught_categories
        assert len(missing) == 0, (
            f"quiet 模式下以下严重类别应被输出但缺失: "
            f"{[c.__name__ for c in missing]}"
        )

        # 每种严重类别恰好出现一次（聚合）
        caught_list = [w.category for w in caught]
        assert len(caught_list) == len(set(caught_list)), (
            f"quiet 模式下严重类别应各输出恰好 1 条聚合摘要，"
            f"但存在重复: {[c.__name__ for c in caught_list]}"
        )

    @given(
        informational_records=st.lists(
            _informational_record_st, min_size=1, max_size=30
        ),
    )
    @settings(max_examples=100)
    def test_quiet_flush_emits_nothing_when_only_informational(
        self, informational_records
    ):
        """Feature: warning-system-overhaul, Property 4: quiet 模式仅输出严重警告

        当输入中仅包含信息性警告（无严重类别）时，
        quiet 模式下 flush() 应不产生任何输出。

        **Validates: Requirements 3.2**
        """
        registry = WarningRegistry(verbose='quiet')

        for category, message, (cohort, period), context in informational_records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(informational_records))

        assert len(caught) == 0, (
            f"仅包含信息性警告时，quiet 模式不应产生任何输出，"
            f"但捕获到 {len(caught)} 条: "
            f"{[(w.category.__name__, str(w.message)) for w in caught]}"
        )


# ── Property 5: verbose 模式输出所有个体警告 ───────────────────────


class TestProperty5VerboseModeEmitsAllIndividualWarnings:
    """Property 5: verbose 模式输出所有个体警告

    Feature: warning-system-overhaul, Property 5: verbose 模式输出所有个体警告

    **Validates: Requirements 3.4**
    """

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_verbose_flush_emits_exactly_n_warnings(self, records):
        """Feature: warning-system-overhaul, Property 5: verbose 模式输出所有个体警告

        对于任意包含 N 条警告记录的集合，在 verbose 模式下调用 flush()
        应产生恰好 N 条独立输出（每条警告一个）。

        **Validates: Requirements 3.4**
        """
        n = len(records)
        registry = WarningRegistry(verbose='verbose')

        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=n)

        assert len(caught) == n, (
            f"verbose 模式下应产生 {n} 条独立输出，"
            f"实际捕获 {len(caught)} 条"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_verbose_flush_preserves_each_message(self, records):
        """Feature: warning-system-overhaul, Property 5: verbose 模式输出所有个体警告

        在 verbose 模式下，flush() 输出的每条警告消息应与
        collect() 时传入的原始消息一一对应（保持顺序）。

        **Validates: Requirements 3.4**
        """
        registry = WarningRegistry(verbose='verbose')

        expected_messages = []
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            expected_messages.append(message)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        actual_messages = [str(w.message) for w in caught]
        assert actual_messages == expected_messages, (
            f"verbose 模式下输出的消息应与输入一一对应。"
            f"期望 {len(expected_messages)} 条，实际 {len(actual_messages)} 条。"
            f"首条不匹配: "
            f"期望={expected_messages[0]!r}, 实际={actual_messages[0]!r}"
            if actual_messages else
            f"verbose 模式下输出的消息应与输入一一对应，但未捕获到任何输出"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_verbose_flush_preserves_each_category(self, records):
        """Feature: warning-system-overhaul, Property 5: verbose 模式输出所有个体警告

        在 verbose 模式下，flush() 输出的每条警告类别应与
        collect() 时传入的原始类别一一对应（保持顺序）。

        **Validates: Requirements 3.4**
        """
        registry = WarningRegistry(verbose='verbose')

        expected_categories = []
        for category, message, (cohort, period), context in records:
            registry.collect(
                category=category,
                message=message,
                cohort=cohort,
                period=period,
                context=context,
            )
            expected_categories.append(category)

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            registry.flush(total_pairs=len(records))

        actual_categories = [w.category for w in caught]
        assert actual_categories == expected_categories, (
            f"verbose 模式下输出的类别应与输入一一对应。"
            f"期望: {[c.__name__ for c in expected_categories]}，"
            f"实际: {[c.__name__ for c in actual_categories]}"
        )

# ── Property 6: diagnostics 完整性不受 verbose 影响 ────────────────


class TestProperty6DiagnosticsIndependentOfVerbose:
    """Property 6: diagnostics 完整性不受 verbose 影响

    Feature: warning-system-overhaul, Property 6: diagnostics 完整性不受 verbose 影响

    **Validates: Requirements 4.2, 4.4**
    """

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_diagnostics_identical_across_all_verbose_levels(self, records):
        """Feature: warning-system-overhaul, Property 6: diagnostics 完整性不受 verbose 影响

        对于任意相同的警告集合，在 quiet、default、verbose 三种模式下，
        get_diagnostics() 返回的记录集合应完全相同。

        **Validates: Requirements 4.2, 4.4**
        """
        # 为三种 verbose 级别分别创建 registry 并收集相同的警告
        diagnostics_by_level = {}
        for level in ('quiet', 'default', 'verbose'):
            registry = WarningRegistry(verbose=level)
            for category, message, (cohort, period), context in records:
                registry.collect(
                    category=category,
                    message=message,
                    cohort=cohort,
                    period=period,
                    context=context,
                )
            diagnostics_by_level[level] = registry.get_diagnostics()

        # 三种模式的 diagnostics 应完全相同
        assert diagnostics_by_level['quiet'] == diagnostics_by_level['default'], (
            "quiet 和 default 模式的 diagnostics 应完全相同"
        )
        assert diagnostics_by_level['default'] == diagnostics_by_level['verbose'], (
            "default 和 verbose 模式的 diagnostics 应完全相同"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_diagnostics_identical_after_flush(self, records):
        """Feature: warning-system-overhaul, Property 6: diagnostics 完整性不受 verbose 影响

        对于任意相同的警告集合，在三种模式下调用 flush() 之后，
        get_diagnostics() 返回的记录集合仍应完全相同。

        **Validates: Requirements 4.2, 4.4**
        """
        total_pairs = len(records) + 5  # 模拟总对数大于实际警告数

        diagnostics_by_level = {}
        for level in ('quiet', 'default', 'verbose'):
            registry = WarningRegistry(verbose=level)
            for category, message, (cohort, period), context in records:
                registry.collect(
                    category=category,
                    message=message,
                    cohort=cohort,
                    period=period,
                    context=context,
                )
            # 在 catch_warnings 中 flush，避免干扰测试输出
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                registry.flush(total_pairs=total_pairs)
            diagnostics_by_level[level] = registry.get_diagnostics()

        assert diagnostics_by_level['quiet'] == diagnostics_by_level['default'], (
            "flush 后 quiet 和 default 模式的 diagnostics 应完全相同"
        )
        assert diagnostics_by_level['default'] == diagnostics_by_level['verbose'], (
            "flush 后 default 和 verbose 模式的 diagnostics 应完全相同"
        )

    @given(records=warning_records_list_st)
    @settings(max_examples=100)
    def test_diagnostics_contains_all_categories(self, records):
        """Feature: warning-system-overhaul, Property 6: diagnostics 完整性不受 verbose 影响

        对于任意警告集合，三种模式下 get_diagnostics() 返回的类别集合
        应包含所有输入中出现过的类别。

        **Validates: Requirements 4.2, 4.4**
        """
        # 收集输入中所有出现过的类别
        expected_categories = set()
        for category, message, (cohort, period), context in records:
            expected_categories.add(category.__name__)

        for level in ('quiet', 'default', 'verbose'):
            registry = WarningRegistry(verbose=level)
            for category, message, (cohort, period), context in records:
                registry.collect(
                    category=category,
                    message=message,
                    cohort=cohort,
                    period=period,
                    context=context,
                )
            diag = registry.get_diagnostics()
            actual_categories = {d['category'] for d in diag}
            assert actual_categories == expected_categories, (
                f"在 {level} 模式下，diagnostics 应包含所有输入类别。"
                f"期望: {expected_categories}，实际: {actual_categories}"
            )
