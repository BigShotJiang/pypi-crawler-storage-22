# Inference module tests
