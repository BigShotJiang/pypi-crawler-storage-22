"""Staggered DiD module tests."""
