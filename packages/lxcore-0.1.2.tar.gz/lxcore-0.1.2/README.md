# LXcore - Production-Ready Storage Engine

LXcore is a high-performance, segment-based storage engine with atomic index updates and crash recovery.

## Features

- **Segment-based storage**: Immutable segment files prevent SIGBUS and enable safe mmap reads
- **Atomic index updates**: Append-only binary index with versioning and checksum support
- **Configurable durability**: `fast` (no fsync), `durable` (periodic fsync), `safe` (per-write fsync)
- **Bounded writer queue**: Configurable backpressure to prevent memory exhaustion
- **Automatic index recovery**: Detects and rebuilds corrupted indexes
- **Checksum verification**: CRC32 checksums for data integrity
- **Backward compatibility**: Supports reading old single-file `.lx` format

## Quick Start

```python
import lxcore

# Create a new storage instance
db = lxcore.create("mydata.lx")

# Write data with namespace and tags
db.write(b"Hello, World!", namespace="greetings", tags=["hello", "test"])

# Read all data
for record in db.read_stream():
    print(record["namespace"], record["data"])

# Query by namespace or tag
for record in db.read_stream(namespace="greetings"):
    print(record["data"])

db.close()