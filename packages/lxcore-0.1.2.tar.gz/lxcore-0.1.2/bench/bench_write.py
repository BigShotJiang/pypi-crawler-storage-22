#!/usr/bin/env python3
"""
Benchmark write performance with different configurations.
"""
import os
import time
import statistics
import tempfile
import shutil
import lxcore

def benchmark_writes(config_name, **engine_opts):
    """Benchmark write performance with given configuration."""
    tmpdir = tempfile.mkdtemp()
    db_path = os.path.join(tmpdir, "benchdb")
    
    try:
        # Create engine
        db = lxcore.create(db_path, **engine_opts)
        
        # Warm up
        for i in range(100):
            db.write(b"warmup" * 10)
        
        # Benchmark
        latencies = []
        count = 1000
        
        for i in range(count):
            payload = f"payload_{i}".encode() * 10
            
            start = time.perf_counter_ns()
            db.write(payload)
            end = time.perf_counter_ns()
            
            latencies.append((end - start) / 1e6)  # ms
        
        # Calculate stats
        avg = statistics.mean(latencies)
        p95 = statistics.quantiles(latencies, n=20)[18] if len(latencies) > 1 else 0
        max_lat = max(latencies) if latencies else 0
        
        db.close()
        
        return {
            "config": config_name,
            "avg_ms": avg,
            "p95_ms": p95,
            "max_ms": max_lat,
            "writes_per_sec": 1000 / avg if avg > 0 else 0
        }
        
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

def main():
    print("LXcore Write Performance Benchmark")
    print("=" * 60)
    
    # Test configurations
    configs = [
        ("fast-no-index", {"durability": "fast", "use_index": False}),
        ("fast-with-index", {"durability": "fast", "use_index": True}),
        ("durable-with-index", {"durability": "durable", "use_index": True}),
        ("safe-with-index", {"durability": "safe", "use_index": True}),
    ]
    
    results = []
    
    for config_name, opts in configs:
        print(f"\nRunning: {config_name}...")
        result = benchmark_writes(config_name, **opts)
        results.append(result)
        
        print(f"  Avg latency: {result['avg_ms']:.3f} ms")
        print(f"  P95 latency: {result['p95_ms']:.3f} ms")
        print(f"  Throughput: {result['writes_per_sec']:.0f} writes/sec")
    
    # Print summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("-" * 60)
    print(f"{'Config':20} {'Avg (ms)':>10} {'P95 (ms)':>10} {'Writes/s':>10}")
    print("-" * 60)
    
    for r in results:
        print(f"{r['config']:20} {r['avg_ms']:10.3f} {r['p95_ms']:10.3f} {r['writes_per_sec']:10.0f}")
    
    print("=" * 60)

if __name__ == "__main__":
    main()