from lxcore.core.engine import Engine

__all__ = ["Engine", "create", "open"]
__version__ = "0.1.2"

def create(path, **opts):
    """Create a new LXcore database."""
    return Engine(path, **opts)

def open(path, **opts):
    """Open an existing LXcore database."""
    return Engine(path, **opts)