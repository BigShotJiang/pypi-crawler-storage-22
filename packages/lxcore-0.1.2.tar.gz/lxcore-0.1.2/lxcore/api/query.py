import os
from lxcore.core.engine import Engine

def vacuum(engine, keep_func):
    """
    Rewrite storage keeping only records where keep_func(record) is True
    """
    tmp = engine.path + ".tmp"
    new = Engine(tmp)

    for r in engine.read_stream():
        if keep_func(r):
            new.write(r["data"], r["namespace"], r["tags"])

    new.close()
    engine.close()
    os.replace(tmp, engine.path)

def count(engine, namespace=None):
    total = 0
    for r in engine.read_stream():
        if namespace is None or r["namespace"] == namespace:
            total += 1
    return total


def query(engine, namespace=None, tag=None):
    for r in engine.read_stream():
        if namespace and r["namespace"] != namespace:
            continue
        if tag and tag not in r["tags"]:
            continue
        yield r
