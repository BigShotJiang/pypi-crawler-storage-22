def read_all(engine):
    return engine.read_all()
