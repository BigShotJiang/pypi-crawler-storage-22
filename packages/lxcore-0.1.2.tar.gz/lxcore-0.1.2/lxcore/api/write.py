from lxcore.core.engine import Engine

def write(storage_path, namespace, payload, tags=None):
    """
    Writes payload to the storage engine at storage_path
    with optional namespace and tags.
    """
    if isinstance(payload, str):
        payload = payload.encode()

    eng = Engine(storage_path)
    return eng.write(payload, namespace=namespace, tags=tags)
