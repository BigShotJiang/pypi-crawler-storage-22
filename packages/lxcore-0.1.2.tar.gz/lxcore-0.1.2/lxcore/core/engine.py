import os
import zipfile
import tempfile
import shutil
import weakref
from lxcore.core.writer import Writer
from lxcore.core.reader import Reader
from lxcore.core.monitor import Monitor
from lxcore.core.recovery import Recovery
from lxcore.storage.meta import StorageMeta
from lxcore.core.index import Index

class Engine:
    def __init__(self, path, auto_create=True, **opts):
        self.path = path
        self.is_zip = path.endswith('.lx') and not os.path.isdir(path)
        self.temp_dir = None
        self._closed = False
        
        # If it's a zip file, extract to temp directory
        if self.is_zip:
            self.temp_dir = tempfile.mkdtemp(prefix='lxcore_')
            # If the zip file exists, extract it
            if os.path.exists(path):
                try:
                    with zipfile.ZipFile(path, 'r') as zipf:
                        zipf.extractall(self.temp_dir)
                except zipfile.BadZipFile:
                    # If the zip file is bad, treat as empty
                    pass
            real_path = self.temp_dir
        else:
            real_path = path
        
        self.real_path = real_path
        self.monitor = Monitor()
        
        # Options with defaults
        self.durability = opts.get('durability', 'fast')
        self.use_index = opts.get('use_index', True)
        self.auto_rebuild = opts.get('auto_rebuild', True)
        self.queue_maxsize = opts.get('queue_maxsize', 20000)
        self.backpressure = opts.get('backpressure', True)
        self.segment_max_bytes = opts.get('segment_max_bytes', 64 * 1024 * 1024)
        
        # Create directory if needed
        if auto_create:
            os.makedirs(self.real_path, exist_ok=True)
        
        # Initialize metadata
        self.meta = StorageMeta(self.real_path)
        
        # Initialize components
        self.writer = Writer(
            self.real_path,
            self.monitor,
            durability=self.durability,
            use_index=self.use_index,
            queue_maxsize=self.queue_maxsize,
            backpressure=self.backpressure,
            segment_max_bytes=self.segment_max_bytes
        )
        
        self.reader = Reader(self.real_path, use_index=self.use_index)
        self.recovery = Recovery()
        
        # Update metadata
        self.meta.update(
            engine_initialized=True,
            durability=self.durability,
            use_index=self.use_index
        )
        
        # Setup safe finalizer instead of __del__
        self._finalizer = weakref.finalize(self, self._safe_close)
    
    def write(self, payload: bytes, namespace="default", tags=None):
        return self.writer.write(payload, namespace=namespace, tags=tags)
    
    def read_all(self):
        return list(self.reader.read_stream())
    
    def read_stream(self, namespace=None, tag=None, use_index=None):
        return self.reader.read_stream(namespace=namespace, tag=tag, use_index=use_index)
    
    def flush(self):
        """Flush all pending writes to disk."""
        self.writer.flush()
    
    def close(self):
        """Close the engine and release all resources."""
        if self._closed:
            return
        
        self._closed = True
        try:
            self.writer.stop()
        except Exception:
            pass
        
        if self.is_zip and self.temp_dir:
            try:
                import zipfile
                import shutil
                # Create a zip file at the original path
                with zipfile.ZipFile(self.path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for root, dirs, files in os.walk(self.temp_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, self.temp_dir)
                            zipf.write(file_path, arcname)
                # Remove the temporary directory
                shutil.rmtree(self.temp_dir, ignore_errors=True)
                self.temp_dir = None
            except Exception:
                # Ignore errors during close (might be interpreter shutdown)
                pass
        
        # Cancel the finalizer since we're closing manually
        if hasattr(self, '_finalizer'):
            self._finalizer.detach()
    
    def _safe_close(self):
        """Safe version of close for finalizer (avoids imports)."""
        if self._closed:
            return
        
        self._closed = True
        try:
            # Try to stop writer without heavy imports
            if hasattr(self, 'writer'):
                self.writer.stop()
        except Exception:
            pass
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def stats(self):
        """Get comprehensive statistics."""
        import os
        from pathlib import Path
        
        segments_dir = os.path.join(self.real_path, "segments")
        segment_count = 0
        total_size = 0
        
        if os.path.exists(segments_dir):
            for f in os.listdir(segments_dir):
                if f.startswith("seg_") and f.endswith(".lx"):
                    segment_count += 1
                    fp = os.path.join(segments_dir, f)
                    total_size += os.path.getsize(fp)
        
        return {
            "path": self.path,
            "size": total_size,
            "segment_count": segment_count,
            "writer_stats": self.writer.get_stats(),
            "fs": self.monitor.fs_info(),
            "meta": self.meta.to_dict(),
        }
    
    def scan_recovery(self):
        return self.recovery.scan(self.real_path)
    
    def recover(self):
        return self.recovery.scan(self.real_path)
    
    def delete(self, criteria):
        """Mark records for deletion."""
        for r in self.read_stream():
            if criteria(r):
                self.writer.write(
                    b"", r["namespace"], r["tags"], deleted=True
                )
    
    def rebuild_index(self):
        """Rebuild index from segments."""
        if not self.use_index:
            return False
        
        try:
            # Get the index object from writer
            if hasattr(self.writer, 'index'):
                # Rebuild the index
                self.writer.index.rebuild(
                    self.writer.segment_manager,
                    self.reader
                )
                return True
        except Exception as e:
            print(f"Index rebuild failed: {e}")
            return False
        
        return False
    
    def verify_index(self):
        """Verify index consistency."""
        if not self.use_index:
            return True, []
        
        try:
            if hasattr(self.writer, 'index'):
                return self.writer.index.verify(
                    self.writer.segment_manager,
                    self.reader
                )
        except Exception as e:
            print(f"Index verification failed: {e}")
            return False, [{"error": str(e)}]
        
        return True, []