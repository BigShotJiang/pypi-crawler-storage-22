import os
import threading
import struct
from typing import List, Tuple, Optional
import tempfile

# Index file format constants
MAGIC = b"LXIDX1"
TYPE_NS = 0x01
TYPE_TAG = 0x02

# Index header: magic(6) + version(1) + flags(1) + reserved(6) = 14 bytes
INDEX_HEADER = struct.Struct(">6s B B 6x")

# Entry format: type(1) + str_len(2) + seg_id(4) + offset(8) = 15 bytes
ENTRY_FORMAT = struct.Struct(">B H I Q")

class Index:
    """
    Binary append-only index with segment-aware offsets.
    """
    
    def __init__(self, base_path, enable=True, durability="fast"):
        self.base_path = base_path
        self.lxi_path = os.path.join(base_path, "index.lxi.bin")
        self.enable = enable
        self.durability = durability
        self.lock = threading.Lock()
        
        # In-memory maps: key -> list of (seg_id, offset)
        self.ns_map = {}
        self.tag_map = {}
        
        # File descriptor for appending
        self.fd = None
        
        if enable:
            self._ensure_index_file()
            self._load()
    
    def _ensure_index_file(self):
        """Create index file with proper header if it doesn't exist."""
        if not os.path.exists(self.lxi_path):
            with open(self.lxi_path, 'wb') as f:
                header = INDEX_HEADER.pack(MAGIC, 1, 0)  # version=1, flags=0
                f.write(header)
                if self.durability in ["durable", "safe"]:
                    f.flush()
                    os.fsync(f.fileno())
    
    def _load(self):
        """Load index from file, handling both old and new formats."""
        if not os.path.exists(self.lxi_path):
            return
        
        try:
            with open(self.lxi_path, 'rb') as f:
                # Read and validate header
                header_data = f.read(INDEX_HEADER.size)
                if len(header_data) < INDEX_HEADER.size:
                    raise ValueError("Index file too short")
                
                magic, version, flags = INDEX_HEADER.unpack(header_data)
                if magic != MAGIC:
                    raise ValueError("Invalid index magic")
                
                if version == 1:
                    self._load_v1(f)
                else:
                    raise ValueError(f"Unsupported index version: {version}")
                    
        except Exception as e:
            # Corrupted index, start fresh
            self.ns_map = {}
            self.tag_map = {}
            print(f"Index load failed, will rebuild: {e}")
    
    def _load_v1(self, file_obj):
        """Load version 1 index format."""
        while True:
            entry_header = file_obj.read(ENTRY_FORMAT.size)
            if len(entry_header) < ENTRY_FORMAT.size:
                break
            
            typ, str_len, seg_id, offset = ENTRY_FORMAT.unpack(entry_header)
            key_bytes = file_obj.read(str_len)
            if len(key_bytes) < str_len:
                break
            
            key = key_bytes.decode('utf-8')
            
            if typ == TYPE_NS:
                self.ns_map.setdefault(key, []).append((seg_id, offset))
            elif typ == TYPE_TAG:
                self.tag_map.setdefault(key, []).append((seg_id, offset))
    
    def _open_for_append(self):
        """Open index file for appending."""
        if self.fd is None:
            self.fd = os.open(self.lxi_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        return self.fd
    
    def update(self, namespace, tags, seg_id, offset):
        """
        Update index with new record location.
        
        Args:
            namespace: Record namespace
            tags: List of tags
            seg_id: Segment ID
            offset: Offset within segment
        """
        if not self.enable:
            return
        
        with self.lock:
            # Update in-memory maps
            self.ns_map.setdefault(namespace, []).append((seg_id, offset))
            for tag in tags:
                self.tag_map.setdefault(str(tag), []).append((seg_id, offset))
            
            # Append to binary index
            fd = self._open_for_append()
            
            # Write namespace entry
            ns_bytes = namespace.encode('utf-8')
            entry = ENTRY_FORMAT.pack(TYPE_NS, len(ns_bytes), seg_id, offset)
            os.write(fd, entry)
            os.write(fd, ns_bytes)
            
            # Write tag entries
            for tag in tags:
                tag_str = str(tag)
                tag_bytes = tag_str.encode('utf-8')
                entry = ENTRY_FORMAT.pack(TYPE_TAG, len(tag_bytes), seg_id, offset)
                os.write(fd, entry)
                os.write(fd, tag_bytes)
            
            # Sync if needed
            if self.durability == "safe":
                os.fsync(fd)
    
    def query_namespace(self, ns):
        """Get all (seg_id, offset) for a namespace."""
        with self.lock:
            return self.ns_map.get(ns, []).copy()
    
    def query_tag(self, tag):
        """Get all (seg_id, offset) for a tag."""
        with self.lock:
            return self.tag_map.get(str(tag), []).copy()
    
    def flush(self, fsync=False):
        """Flush index to disk."""
        if self.fd and fsync:
            try:
                os.fsync(self.fd)
            except (OSError, IOError):
                pass
    
    def close(self):
        """Close index file."""
        if self.fd:
            try:
                os.close(self.fd)
            except (OSError, IOError):
                pass
            finally:
                self.fd = None
    
    def rebuild(self, segment_manager, reader):
        """
        Rebuild index from all segments.
        
        Args:
            segment_manager: SegmentManager instance
            reader: Reader instance for scanning
        """
        if not self.enable:
            return False
        
        temp_path = self.lxi_path + ".tmp"
        
        try:
            # Create new index file
            with open(temp_path, 'wb') as f:
                # Write header
                header = INDEX_HEADER.pack(MAGIC, 1, 0)
                f.write(header)
                
                # Scan all segments
                for seg_id in segment_manager.list_segments():
                    fd = segment_manager.open_segment_readonly(seg_id)
                    try:
                        offset = 0
                        file_size = os.fstat(fd).st_size
                        
                        while offset < file_size:
                            # Read record header
                            try:
                                header_data = os.pread(fd, 4, offset)  # Read total_len first
                                if len(header_data) < 4:
                                    break
                                    
                                total_len = struct.unpack(">I", header_data)[0]
                                if total_len < 15:  # Minimum header size
                                    break
                                    
                                # Read full header for V2
                                header_data = os.pread(fd, 29, offset)  # HEADER_V2.size = 29
                                if len(header_data) < 29:
                                    # Try V1
                                    header_data = os.pread(fd, 24, offset)  # HEADER_V1.size = 24
                                    if len(header_data) < 24:
                                        break
                                    
                                    total_len, flags, ts, psize, ns_len, tags_len = \
                                        struct.unpack(">I B Q I H H", header_data)
                                    checksum = None
                                    header_size = 24
                                else:
                                    total_len, flags, ts, psize, ns_len, tags_len, checksum = \
                                        struct.unpack(">I B Q I H H I", header_data)
                                    header_size = 29
                                
                                if flags & 0x01:  # FLAG_DELETED
                                    offset += total_len
                                    continue
                                
                                # Read namespace
                                ns_data = os.pread(fd, ns_len, offset + header_size)
                                if len(ns_data) != ns_len:
                                    offset += total_len
                                    continue
                                namespace = ns_data.decode('utf-8')
                                
                                # Read tags
                                tags_data = os.pread(fd, tags_len, 
                                                    offset + header_size + ns_len)
                                if len(tags_data) != tags_len:
                                    offset += total_len
                                    continue
                                tags_str = tags_data.decode('utf-8')
                                tags = tags_str.split(',') if tags_str else []
                                
                                # Write index entries
                                ns_bytes = namespace.encode('utf-8')
                                entry = ENTRY_FORMAT.pack(TYPE_NS, len(ns_bytes), seg_id, offset)
                                f.write(entry)
                                f.write(ns_bytes)
                                
                                for tag in tags:
                                    tag_bytes = str(tag).encode('utf-8')
                                    entry = ENTRY_FORMAT.pack(TYPE_TAG, len(tag_bytes), seg_id, offset)
                                    f.write(entry)
                                    f.write(tag_bytes)
                                
                                offset += total_len
                            except (struct.error, UnicodeDecodeError):
                                # Skip corrupted record
                                offset += 1
                    finally:
                        os.close(fd)
                
                f.flush()
                if self.durability in ["durable", "safe"]:
                    os.fsync(f.fileno())
            
            # Atomically replace old index
            os.replace(temp_path, self.lxi_path)
            
            # Reload index
            self._load()
            
            return True
            
        except Exception as e:
            print(f"Index rebuild failed: {e}")
            return False
        finally:
            # Clean up temp file if it exists
            if os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except:
                    pass
    
    def verify(self, segment_manager, reader):
        """
        Verify index consistency by comparing with full scan.
        Returns: (is_consistent: bool, discrepancies: list)
        """
        if not self.enable:
            return True, []
        
        discrepancies = []
        
        # Build maps from full scan
        scan_ns_map = {}
        scan_tag_map = {}
        
        for record in reader.read_stream(use_index=False):
            seg_id = record.get("seg_id", 0)
            offset = record.get("offset", 0)
            namespace = record["namespace"]
            tags = record["tags"]
            
            scan_ns_map.setdefault(namespace, []).append((seg_id, offset))
            for tag in tags:
                scan_tag_map.setdefault(tag, []).append((seg_id, offset))
        
        # Compare with index
        with self.lock:
            # Check namespaces
            for ns in set(list(self.ns_map.keys()) + list(scan_ns_map.keys())):
                index_entries = set(self.ns_map.get(ns, []))
                scan_entries = set(scan_ns_map.get(ns, []))
                
                if index_entries != scan_entries:
                    missing = scan_entries - index_entries
                    extra = index_entries - scan_entries
                    discrepancies.append({
                        "type": "namespace",
                        "key": ns,
                        "missing": len(missing),
                        "extra": len(extra)
                    })
            
            # Check tags
            for tag in set(list(self.tag_map.keys()) + list(scan_tag_map.keys())):
                index_entries = set(self.tag_map.get(tag, []))
                scan_entries = set(scan_tag_map.get(tag, []))
                
                if index_entries != scan_entries:
                    missing = scan_entries - index_entries
                    extra = index_entries - scan_entries
                    discrepancies.append({
                        "type": "tag",
                        "key": tag,
                        "missing": len(missing),
                        "extra": len(extra)
                    })
        
        return len(discrepancies) == 0, discrepancies