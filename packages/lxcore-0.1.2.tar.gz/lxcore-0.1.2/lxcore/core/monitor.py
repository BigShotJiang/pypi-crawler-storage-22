import os
import time

class Monitor:
    def fs_info(self):
        stat = os.statvfs(".")
        return {
            "block_size": stat.f_bsize,
            "free_blocks": stat.f_bavail,
        }

    def write_delay_hint(self):
        # placeholder for adaptive throttling
        return 0.0
