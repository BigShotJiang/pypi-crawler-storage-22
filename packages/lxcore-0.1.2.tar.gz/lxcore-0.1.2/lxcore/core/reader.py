import struct
import mmap
import os
from typing import Optional, Iterator, Dict, Any
import zlib

# Header formats
HEADER_V1 = struct.Struct(">I B Q I H H")  # Old format without checksum
HEADER_V2 = struct.Struct(">I B Q I H H I")  # New format with CRC32
FLAG_DELETED = 0x01
FLAG_CHECKSUM = 0x02

class Reader:
    def __init__(self, base_path, use_index=True):
        self.base_path = base_path
        self.use_index = use_index
        self.segments_dir = os.path.join(base_path, "segments")
        
        # Lazy initialization of index
        self._index = None
    
    @property
    def index(self):
        """Lazy load index."""
        if self._index is None and self.use_index:
            from lxcore.core.index import Index
            self._index = Index(self.base_path, enable=True)
        return self._index
    
    def read_stream(self, namespace: Optional[str] = None, 
                   tag: Optional[str] = None,
                   use_index: Optional[bool] = None) -> Iterator[Dict[str, Any]]:
        """
        Read records with optional filtering.
        
        Args:
            namespace: Filter by namespace
            tag: Filter by tag
            use_index: Override instance use_index setting
        
        Yields:
            Record dictionaries
        """
        use_idx = self.use_index if use_index is None else use_index
        
        # Fast path with index
        if use_idx and self.index and (namespace or tag):
            offsets = set()
            
            if namespace:
                offsets.update(self.index.query_namespace(namespace))
            
            if tag:
                offsets.update(self.index.query_tag(tag))
            
            if offsets:
                yield from self._read_from_indexed_offsets(offsets, namespace, tag)
                return
        
        # Fallback: full scan
        yield from self._full_scan(namespace, tag)
    
    def _read_from_indexed_offsets(self, offsets, namespace=None, tag=None):
        """Read records from specific (seg_id, offset) pairs."""
        # Group by segment for efficient reads
        by_segment = {}
        for seg_id, offset in offsets:
            by_segment.setdefault(seg_id, []).append(offset)
        
        for seg_id, seg_offsets in by_segment.items():
            seg_path = os.path.join(self.segments_dir, f"seg_{seg_id:08d}.lx")
            if not os.path.exists(seg_path):
                continue
            
            size = os.path.getsize(seg_path)
            
            # Try to mmap if segment is closed (immutable)
            is_active = self._is_segment_active(seg_id)
            
            if not is_active and size > 0:
                # Use mmap for closed segments
                with open(seg_path, 'rb') as f:
                    with mmap.mmap(f.fileno(), size, access=mmap.ACCESS_READ) as mm:
                        for offset in seg_offsets:
                            record = self._read_record_from_mmap(mm, offset, size, 
                                                                seg_id, namespace, tag)
                            if record:
                                yield record
            else:
                # Use file reads for active segment
                with open(seg_path, 'rb') as f:
                    for offset in seg_offsets:
                        record = self._read_record_from_file(f, offset, size,
                                                           seg_id, namespace, tag)
                        if record:
                            yield record
    
    def _is_segment_active(self, seg_id):
        """Check if segment is currently active."""
        # Simple heuristic: check if it's the highest numbered segment
        if not os.path.exists(self.segments_dir):
            return False
        
        segments = []
        for f in os.listdir(self.segments_dir):
            if f.startswith("seg_") and f.endswith(".lx"):
                try:
                    f_seg_id = int(f.split('_')[1].split('.')[0])
                    segments.append(f_seg_id)
                except (ValueError, IndexError):
                    continue
        
        return seg_id == max(segments) if segments else False
    
    def _read_record_from_mmap(self, mm, offset, file_size, seg_id, namespace, tag):
        """Read a record from mmapped segment."""
        if offset < 0 or offset + HEADER_V2.size > file_size:
            return None
        
        try:
            # Try V2 header first
            header_data = mm[offset:offset + HEADER_V2.size]
            total_len, flags, ts, psize, ns_len, tags_len, checksum = \
                HEADER_V2.unpack(header_data)
        except struct.error:
            # Fall back to V1
            if offset + HEADER_V1.size > file_size:
                return None
            header_data = mm[offset:offset + HEADER_V1.size]
            total_len, flags, ts, psize, ns_len, tags_len = \
                HEADER_V1.unpack(header_data)
            checksum = None
        
        # Validate record fits in file
        if total_len <= HEADER_V1.size or offset + total_len > file_size:
            return None
        
        # Calculate data positions
        header_size = HEADER_V2.size if checksum is not None else HEADER_V1.size
        pos = offset + header_size
        
        # Read namespace
        if pos + ns_len > offset + total_len:
            return None
        ns_bytes = mm[pos:pos + ns_len]
        ns_str = ns_bytes.decode('utf-8')
        pos += ns_len
        
        # Read tags
        if pos + tags_len > offset + total_len:
            return None
        tags_bytes = mm[pos:pos + tags_len]
        tags_str = tags_bytes.decode('utf-8')
        tags_list = tags_str.split(',') if tags_str else []
        pos += tags_len
        
        # Read payload
        if pos + psize > offset + total_len:
            return None
        payload = bytes(mm[pos:pos + psize])
        
        # Verify checksum if present
        if checksum is not None:
            calc_checksum = zlib.crc32(payload) & 0xFFFFFFFF
            if calc_checksum != checksum:
                return None  # Checksum mismatch
        
        # Apply filters
        if flags & FLAG_DELETED:
            return None
        if namespace and ns_str != namespace:
            return None
        if tag and tag not in tags_list:
            return None
        
        return {
            "ts": ts,
            "namespace": ns_str,
            "tags": tags_list,
            "data": payload,
            "offset": offset,
            "seg_id": seg_id,
            "checksum_ok": checksum is not None
        }
    
    def _read_record_from_file(self, f, offset, file_size, seg_id, namespace, tag):
        """Read a record using file reads (safe for active segment)."""
        if offset < 0 or offset + HEADER_V2.size > file_size:
            return None
        
        # Try V2 header
        f.seek(offset)
        header_data = f.read(HEADER_V2.size)
        if len(header_data) < HEADER_V2.size:
            return None
        
        try:
            total_len, flags, ts, psize, ns_len, tags_len, checksum = \
                HEADER_V2.unpack(header_data)
        except struct.error:
            # Try V1
            if len(header_data) < HEADER_V1.size:
                return None
            total_len, flags, ts, psize, ns_len, tags_len = \
                HEADER_V1.unpack(header_data[:HEADER_V1.size])
            checksum = None
            header_size = HEADER_V1.size
        else:
            header_size = HEADER_V2.size
        
        # Validate
        if total_len <= header_size or offset + total_len > file_size:
            return None
        
        # Read namespace
        ns_bytes = f.read(ns_len)
        if len(ns_bytes) != ns_len:
            return None
        ns_str = ns_bytes.decode('utf-8')
        
        # Read tags
        tags_bytes = f.read(tags_len)
        if len(tags_bytes) != tags_len:
            return None
        tags_str = tags_bytes.decode('utf-8')
        tags_list = tags_str.split(',') if tags_str else []
        
        # Read payload
        payload = f.read(psize)
        if len(payload) != psize:
            return None
        
        # Verify checksum
        if checksum is not None:
            calc_checksum = zlib.crc32(payload) & 0xFFFFFFFF
            if calc_checksum != checksum:
                return None
        
        # Apply filters
        if flags & FLAG_DELETED:
            return None
        if namespace and ns_str != namespace:
            return None
        if tag and tag not in tags_list:
            return None
        
        return {
            "ts": ts,
            "namespace": ns_str,
            "tags": tags_list,
            "data": payload,
            "offset": offset,
            "seg_id": seg_id,
            "checksum_ok": checksum is not None
        }
    
    def _full_scan(self, namespace=None, tag=None):
        """Scan all segments sequentially."""
        if not os.path.exists(self.segments_dir):
            return
        
        # Get all segments in order
        segments = []
        for f in os.listdir(self.segments_dir):
            if f.startswith("seg_") and f.endswith(".lx"):
                try:
                    seg_id = int(f.split('_')[1].split('.')[0])
                    segments.append((seg_id, f))
                except (ValueError, IndexError):
                    continue
        
        segments.sort(key=lambda x: x[0])
        
        for seg_id, filename in segments:
            seg_path = os.path.join(self.segments_dir, filename)
            size = os.path.getsize(seg_path)
            
            if size == 0:
                continue
            
            # For full scan, we always use mmap for efficiency
            with open(seg_path, 'rb') as f:
                with mmap.mmap(f.fileno(), size, access=mmap.ACCESS_READ) as mm:
                    offset = 0
                    while offset + HEADER_V1.size <= size:
                        record = self._read_record_from_mmap(
                            mm, offset, size, seg_id, namespace, tag
                        )
                        if record:
                            yield record
                        
                        # Move to next record
                        if offset + HEADER_V1.size > size:
                            break
                        
                        # Peek next record length
                        try:
                            total_len = HEADER_V1.unpack(
                                mm[offset:offset + HEADER_V1.size]
                            )[0]
                        except struct.error:
                            break
                        
                        offset += total_len if total_len > 0 else HEADER_V1.size