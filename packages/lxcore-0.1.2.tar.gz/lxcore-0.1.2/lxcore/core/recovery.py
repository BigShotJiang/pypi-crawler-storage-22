import os
import struct
from typing import Tuple, Optional
import zlib

HEADER_V1 = struct.Struct(">I B Q I H H")
HEADER_V2 = struct.Struct(">I B Q I H H I")
FLAG_DELETED = 0x01
INDEX_MAGIC = b"LXIDX1"

class Recovery:
    def __init__(self):
        self.scan_stats = {}
    
    def scan(self, base_path: str) -> Tuple[bool, Optional[str], int]:
        """
        Scan storage for integrity issues.
        
        Returns:
            (ok: bool, reason: Optional[str], recovered_count: int)
        """
        self.scan_stats = {
            "segments_scanned": 0,
            "records_found": 0,
            "records_corrupt": 0,
            "index_consistent": False,
        }
        
        # Check if it's old single-file format
        if os.path.isfile(base_path) and base_path.endswith('.lx'):
            return self._scan_legacy_file(base_path)
        
        # New segmented format
        segments_dir = os.path.join(base_path, "segments")
        if not os.path.exists(segments_dir):
            return True, "No segments directory (empty storage)", 0
        
        # Scan all segments
        total_records = 0
        for seg_file in sorted(os.listdir(segments_dir)):
            if seg_file.startswith("seg_") and seg_file.endswith(".lx"):
                seg_path = os.path.join(segments_dir, seg_file)
                ok, reason, count = self._scan_segment(seg_path)
                if not ok:
                    return False, f"Segment {seg_file}: {reason}", total_records
                total_records += count
                self.scan_stats["segments_scanned"] += 1
        
        # Check index consistency if exists
        index_path = os.path.join(base_path, "index.lxi.bin")
        if os.path.exists(index_path):
            index_ok, index_reason = self._check_index_consistency(base_path, total_records)
            self.scan_stats["index_consistent"] = index_ok
            if not index_ok:
                return False, f"Index issue: {index_reason}", total_records
        
        return True, None, total_records
    
    def _scan_segment(self, seg_path: str) -> Tuple[bool, Optional[str], int]:
        """Scan a single segment file."""
        size = os.path.getsize(seg_path)
        if size == 0:
            return True, None, 0
        
        record_count = 0
        corrupt_count = 0
        
        with open(seg_path, 'rb') as f:
            offset = 0
            while offset < size:
                # Try to read header
                header_data = f.read(HEADER_V2.size)
                if len(header_data) < HEADER_V2.size:
                    # Try V1
                    if len(header_data) < HEADER_V1.size:
                        break
                    
                    # Parse V1 header
                    total_len, flags, ts, psize, ns_len, tags_len = \
                        HEADER_V1.unpack(header_data[:HEADER_V1.size])
                    checksum = None
                    header_size = HEADER_V1.size
                else:
                    # Parse V2 header
                    total_len, flags, ts, psize, ns_len, tags_len, checksum = \
                        HEADER_V2.unpack(header_data)
                    header_size = HEADER_V2.size
                
                # Basic validation
                if total_len <= header_size:
                    corrupt_count += 1
                    offset += 1  # Skip one byte and try to resync
                    f.seek(offset)
                    continue
                
                if offset + total_len > size:
                    # Partial write at end of file
                    return True, None, record_count
                
                # Read the rest of the record
                remaining = total_len - header_size
                record_data = f.read(remaining)
                if len(record_data) != remaining:
                    # Truncated record
                    corrupt_count += 1
                    offset += total_len
                    continue
                
                # Extract payload for checksum verification
                if checksum is not None and ns_len + tags_len <= len(record_data):
                    payload_start = ns_len + tags_len
                    payload = record_data[payload_start:payload_start + psize]
                    if len(payload) == psize:
                        calc_checksum = zlib.crc32(payload) & 0xFFFFFFFF
                        if calc_checksum != checksum:
                            corrupt_count += 1
                
                if not (flags & FLAG_DELETED):
                    record_count += 1
                
                offset += total_len
        
        self.scan_stats["records_found"] += record_count
        self.scan_stats["records_corrupt"] += corrupt_count
        
        if corrupt_count > 0:
            return False, f"{corrupt_count} corrupt records found", record_count
        
        return True, None, record_count
    
    def _scan_legacy_file(self, filepath: str) -> Tuple[bool, Optional[str], int]:
        """Scan legacy single-file format."""
        size = os.path.getsize(filepath)
        if size == 0:
            return True, "Empty file", 0
        
        record_count = 0
        
        with open(filepath, 'rb') as f:
            offset = 0
            while offset + HEADER_V1.size <= size:
                header_data = f.read(HEADER_V1.size)
                if len(header_data) < HEADER_V1.size:
                    break
                
                total_len, flags, ts, psize, ns_len, tags_len = \
                    HEADER_V1.unpack(header_data)
                
                if total_len <= HEADER_V1.size or offset + total_len > size:
                    # Corrupted or partial write
                    break
                
                # Skip rest of record
                f.seek(total_len - HEADER_V1.size, os.SEEK_CUR)
                
                if not (flags & FLAG_DELETED):
                    record_count += 1
                
                offset += total_len
        
        return True, None, record_count
    
    def _check_index_consistency(self, base_path: str, expected_records: int) -> Tuple[bool, str]:
        """Check index file basic consistency."""
        index_path = os.path.join(base_path, "index.lxi.bin")
        
        try:
            size = os.path.getsize(index_path)
            if size < 14:  # Minimum header size
                return False, "Index file too small"
            
            with open(index_path, 'rb') as f:
                magic = f.read(6)
                if magic != INDEX_MAGIC:
                    return False, "Invalid index magic"
                
                # TODO: More thorough index validation
                # For now, just check file can be opened
                return True, "Index appears valid"
                
        except Exception as e:
            return False, f"Index read error: {e}"
    
    def get_stats(self):
        """Get scan statistics."""
        return self.scan_stats.copy()