import struct
import time
import threading
import os
from queue import Queue, Empty, Full
from lxcore.core.index import Index
from lxcore.storage.segments import SegmentManager
from lxcore.storage.meta import StorageMeta

# Record header with checksum support
RECHDR_V1 = struct.Struct(">I B Q I H H")  # Old format without checksum
RECHDR_V2 = struct.Struct(">I B Q I H H I")  # New format with CRC32 checksum
FLAG_DELETED = 0x01
FLAG_CHECKSUM = 0x02
FLUSH_INTERVAL = 0.5
import zlib

class Writer:
    def __init__(self, base_path, monitor, durability="fast", use_index=True, 
                 queue_maxsize=20000, backpressure=True, segment_max_bytes=64*1024*1024):
        self.base_path = base_path
        self.monitor = monitor
        self.durability = durability
        self.use_index = use_index
        self.backpressure = backpressure
        self.queue_maxsize = queue_maxsize
        
        # Initialize metadata
        self.meta = StorageMeta(base_path)
        self.meta.update(
            durability=durability,
            segment_max_bytes=segment_max_bytes,
            checksum_enabled=True  # Always enable checksum for new writes
        )
        
        # Initialize segment manager
        self.segment_manager = SegmentManager(base_path, segment_max_bytes)
        
        # Threading
        self.lock = threading.Lock()
        self.queue = Queue(maxsize=queue_maxsize)
        self.running = True
        
        # Initialize index
        self.index = Index(base_path, enable=use_index, durability=durability)
        
        # Stats
        self.stats = {
            "writes": 0,
            "queue_size": 0,
            "segments_created": 0,
            "errors": 0,
        }
        
        # Background thread
        self.last_flush = time.time()
        self.thread = threading.Thread(target=self._flush_loop, daemon=True)
        self.thread.start()

    def write(self, payload, namespace="default", tags=None, deleted=False):
        """
        Write a record with optional backpressure.
        
        Returns: timestamp (int) or raises Queue.Full if backpressure=False
        """
        if isinstance(payload, str):
            payload = payload.encode()
        
        if isinstance(namespace, str):
            namespace = namespace.encode()
        
        if tags is None:
            tags = []
        elif isinstance(tags, str):
            tags = [tags]
        elif isinstance(tags, list):
            tags = [str(t) for t in tags]
        
        flags = FLAG_DELETED if deleted else 0
        flags |= FLAG_CHECKSUM  # Always use checksum
        
        record_data = (payload, namespace, tags, flags, time.time_ns())
        
        try:
            if self.backpressure:
                self.queue.put(record_data, block=True, timeout=0.1)
            else:
                try:
                    self.queue.put_nowait(record_data)
                except Full:
                    raise Full("Write queue full")
        except Full:
            with self.lock:
                self.stats["errors"] += 1
            raise
        
        with self.lock:
            self.stats["queue_size"] = self.queue.qsize()
        
        return record_data[4]  # Return timestamp

    def _build_record(self, payload, namespace, tags, flags, timestamp):
        """Build complete record with checksum."""
        ns_len = len(namespace)
        tags_bytes = b",".join([t.encode() if isinstance(t, str) else str(t).encode() for t in tags]) if tags else b""
        tags_len = len(tags_bytes)
        payload_size = len(payload)
        
        # Calculate checksum over payload only (not header/metadata)
        checksum = zlib.crc32(payload) & 0xFFFFFFFF
        
        # Build record with checksum
        total_len = RECHDR_V2.size + ns_len + tags_len + payload_size
        header = RECHDR_V2.pack(
            total_len, flags, timestamp,
            payload_size, ns_len, tags_len,
            checksum
        )
        
        return header + namespace + tags_bytes + payload

    def _flush_loop(self):
        """Background thread that writes records to segments."""
        while self.running or not self.queue.empty():
            try:
                payload, namespace, tags, flags, timestamp = self.queue.get(timeout=0.1)
            except Empty:
                continue
            
            try:
                # Build record
                record = self._build_record(payload, namespace, tags, flags, timestamp)
                
                # Append to active segment
                seg_id, offset = self.segment_manager.append_record(record)
                
                # Update index AFTER successful write
                if self.use_index:
                    self.index.update(
                        namespace.decode() if isinstance(namespace, bytes) else namespace,
                        tags,
                        seg_id,
                        offset
                    )
                
                # Handle durability
                if self.durability == "safe":
                    # Sync both segment and index
                    os.fsync(self.segment_manager.active_fd)
                    self.index.flush(fsync=True)
                elif self.durability == "durable":
                    # Periodic sync
                    if time.time() - self.last_flush >= FLUSH_INTERVAL:
                        os.fsync(self.segment_manager.active_fd)
                        self.index.flush(fsync=True)
                        self.last_flush = time.time()
                
                with self.lock:
                    self.stats["writes"] += 1
                    self.stats["queue_size"] = self.queue.qsize()
                    
            except Exception as e:
                with self.lock:
                    self.stats["errors"] += 1
                # Log error but continue
                import traceback
                print(f"Write error: {e}")

    def flush(self):
        """Explicit flush."""
        if self.durability in ["durable", "safe"]:
            if self.segment_manager.active_fd:
                try:
                    os.fsync(self.segment_manager.active_fd)
                except (OSError, IOError):
                    pass
            self.index.flush(fsync=True)
            self.last_flush = time.time()

    def stop(self):
        """Stop writer gracefully."""
        self.running = False
        
        # Wait for thread to finish
        if self.thread.is_alive():
            self.thread.join(timeout=5.0)
        
        # Final flush
        self.flush()
        
        # Finalize active segment
        if self.segment_manager:
            self.segment_manager.close()
        
        # Update metadata
        self.meta.update(
            last_writer_stop=time.time(),
            total_writes=self.stats["writes"]
        )

    def get_stats(self):
        """Get writer statistics."""
        with self.lock:
            stats = self.stats.copy()
            stats["queue_maxsize"] = self.queue_maxsize
            stats["backpressure"] = self.backpressure
            stats["durability"] = self.durability
            return stats