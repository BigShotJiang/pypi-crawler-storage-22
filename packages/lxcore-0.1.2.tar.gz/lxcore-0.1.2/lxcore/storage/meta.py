"""
Metadata management for LXcore storage.
"""
import json
import os
import threading
from pathlib import Path
from typing import Any, Dict
import tempfile

class StorageMeta:
    """Atomic metadata storage with JSON."""
    
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.meta_path = self.base_path / "meta.json"
        self.lock = threading.Lock()
        self.data = {}
        self._load()
    
    def _load(self):
        """Load metadata from file."""
        if self.meta_path.exists():
            try:
                with open(self.meta_path, 'r') as f:
                    self.data = json.load(f)
            except (json.JSONDecodeError, IOError):
                self.data = {}
        
        # Set defaults if missing
        defaults = {
            "record_abi_version": 1,
            "index_version": 1,
            "segment_max_bytes": 64 * 1024 * 1024,
            "durability": "fast",
            "checksum_enabled": False,
            "created_at": self.data.get("created_at", None),
            "last_modified": self.data.get("last_modified", None),
        }
        
        for key, default in defaults.items():
            if key not in self.data:
                self.data[key] = default
        
        # Initialize timestamps if not present
        if not self.data.get("created_at"):
            import time
            self.data["created_at"] = time.time()
        
        self._save()
    
    def _save(self):
        """Atomically save metadata."""
        import time
        self.data["last_modified"] = time.time()
        
        # Write to temp file then rename atomically
        with tempfile.NamedTemporaryFile(
            mode='w',
            dir=self.base_path,
            delete=False,
            suffix='.tmp'
        ) as tmp:
            json.dump(self.data, tmp, indent=2)
            tmp.flush()
            os.fsync(tmp.fileno())
            tmp_path = tmp.name
        
        os.replace(tmp_path, self.meta_path)
    
    def update(self, **kwargs):
        """Update metadata fields."""
        with self.lock:
            self.data.update(kwargs)
            self._save()
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get metadata value."""
        with self.lock:
            return self.data.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set metadata value."""
        with self.lock:
            self.data[key] = value
            self._save()
    
    def to_dict(self) -> Dict:
        """Return metadata as dictionary."""
        with self.lock:
            return self.data.copy()