"""
Segment-based storage manager for LXcore.
Implements immutable segment files to prevent mmap-SIGBUS issues.
"""
import os
import struct
import threading
from pathlib import Path
from typing import Tuple, List, Iterator, Optional
import tempfile

class SegmentManager:
    """
    Manages segmented storage with immutable completed segments and one active segment.
    """
    
    # Segment header format: magic (8 bytes) + segment_id (4 bytes) + flags (1 byte)
    SEGMENT_HEADER = struct.Struct(">8s I B")
    SEGMENT_MAGIC = b"LXSEGv1"
    
    def __init__(self, base_path: str, max_bytes: int = 64 * 1024 * 1024):
        """
        Args:
            base_path: Base directory for storage
            max_bytes: Maximum size per segment (default 64MB)
        """
        self.base_path = Path(base_path)
        self.max_bytes = max_bytes
        self.segments_dir = self.base_path / "segments"
        self.segments_dir.mkdir(parents=True, exist_ok=True)
        
        self.lock = threading.Lock()
        self.active_segment_id = 0
        self.active_segment_path = None
        self.active_fd = None
        self.active_offset = 0
        self.closed_segments = set()
        
        self._discover_existing_segments()
        
        # Ensure we have an active segment
        if self.active_fd is None:
            self._create_new_segment()
    
    def _discover_existing_segments(self):
        """Discover existing segments and find the latest active one."""
        if not self.segments_dir.exists():
            return
        
        segment_files = []
        for f in self.segments_dir.iterdir():
            if f.name.startswith("seg_") and f.name.endswith(".lx"):
                try:
                    seg_id = int(f.stem.split("_")[1])
                    segment_files.append((seg_id, f))
                except (ValueError, IndexError):
                    continue
        
        if not segment_files:
            return
        
        # Sort by segment ID
        segment_files.sort(key=lambda x: x[0])
        
        # Mark all but the last as closed
        for seg_id, path in segment_files[:-1]:
            self.closed_segments.add(seg_id)
        
        # Last segment might be active
        last_id, last_path = segment_files[-1]
        self.active_segment_id = last_id
        size = last_path.stat().st_size
        
        # Check if last segment has been properly closed (has closing magic)
        if size > 0:
            try:
                with open(last_path, 'rb') as f:
                    f.seek(-8, os.SEEK_END)
                    closing_magic = f.read(8)
                    if closing_magic == b"LXSEGEND":
                        # Segment is closed
                        self.closed_segments.add(last_id)
                        self.active_segment_id += 1
                    else:
                        # Segment is still active
                        self.active_segment_path = last_path
                        self.active_fd = os.open(str(last_path), os.O_RDWR | os.O_CREAT, 0o644)
                        self.active_offset = size
            except (OSError, IOError):
                # Can't read file, treat as closed and create new
                self.closed_segments.add(last_id)
                self.active_segment_id += 1
        else:
            # Empty file, treat as active
            self.active_segment_path = last_path
            self.active_fd = os.open(str(last_path), os.O_RDWR | os.O_CREAT, 0o644)
            self.active_offset = 0
    
    def _create_new_segment(self):
        """Create a new active segment file."""
        seg_id = self.active_segment_id
        seg_path = self.segments_dir / f"seg_{seg_id:08d}.lx"
        
        # Create segment with header
        self.active_fd = os.open(str(seg_path), os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o644)
        header = self.SEGMENT_HEADER.pack(self.SEGMENT_MAGIC, seg_id, 0)
        os.write(self.active_fd, header)
        
        self.active_segment_path = seg_path
        self.active_offset = len(header)
    
    def _ensure_active_segment(self):
        """Ensure we have an active segment file descriptor."""
        if self.active_fd is None:
            self._create_new_segment()
    
    def append_record(self, data: bytes) -> Tuple[int, int]:
        """
        Append a record to active segment.
        Returns: (segment_id, offset_within_segment)
        """
        with self.lock:
            # Ensure we have an active segment
            self._ensure_active_segment()
            
            # Rotate if needed
            if self.active_offset + len(data) > self.max_bytes:
                self._finalize_active_segment()
                self.active_segment_id += 1
                self._create_new_segment()
            
            # Write data
            offset = self.active_offset
            written = os.write(self.active_fd, data)
            if written != len(data):
                raise IOError(f"Failed to write all data: {written}/{len(data)} bytes")
            
            self.active_offset += written
            
            return (self.active_segment_id, offset)
    
    def _finalize_active_segment(self):
        """Finalize the active segment by writing closing magic."""
        if self.active_fd is not None:
            try:
                # Write segment end marker
                os.write(self.active_fd, b"LXSEGEND")
                os.fsync(self.active_fd)
                os.close(self.active_fd)
                self.closed_segments.add(self.active_segment_id)
            except (OSError, IOError):
                # Ignore errors during finalization
                pass
            finally:
                self.active_fd = None
                self.active_segment_path = None
    
    def get_segment_path(self, seg_id: int) -> Path:
        """Get path for a segment by ID."""
        return self.segments_dir / f"seg_{seg_id:08d}.lx"
    
    def list_segments(self) -> List[int]:
        """List all segment IDs in order."""
        with self.lock:
            closed = sorted(self.closed_segments)
            if self.active_fd is not None:
                return closed + [self.active_segment_id]
            return closed
    
    def open_segment_readonly(self, seg_id: int) -> int:
        """
        Open a segment for reading.
        Returns file descriptor.
        """
        path = self.get_segment_path(seg_id)
        if not path.exists():
            raise FileNotFoundError(f"Segment {seg_id} not found")
        
        fd = os.open(str(path), os.O_RDONLY)
        return fd
    
    def close(self):
        """Close the segment manager."""
        with self.lock:
            if self.active_fd is not None:
                self._finalize_active_segment()