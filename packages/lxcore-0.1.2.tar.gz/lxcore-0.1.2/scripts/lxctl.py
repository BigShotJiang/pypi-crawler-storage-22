#!/usr/bin/env python3
"""
LXcore Command Line Interface
"""
import os
import sys
import json
import argparse
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="LXcore Database Management Tool")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # stats command
    stats_parser = subparsers.add_parser("stats", help="Show database statistics")
    stats_parser.add_argument("path", help="Path to database")
    
    # rebuild-index command
    rebuild_parser = subparsers.add_parser("rebuild-index", help="Rebuild database index")
    rebuild_parser.add_argument("path", help="Path to database")
    rebuild_parser.add_argument("--verify", action="store_true", help="Verify after rebuild")
    rebuild_parser.add_argument("--force", action="store_true", help="Force rebuild")
    
    # verify command
    verify_parser = subparsers.add_parser("verify", help="Verify database integrity")
    verify_parser.add_argument("path", help="Path to database")
    
    # dump command
    dump_parser = subparsers.add_parser("dump", help="Dump database records")
    dump_parser.add_argument("path", help="Path to database")
    dump_parser.add_argument("--namespace", help="Filter by namespace")
    dump_parser.add_argument("--tag", help="Filter by tag")
    dump_parser.add_argument("--limit", type=int, default=100, help="Limit records")
    dump_parser.add_argument("--format", choices=["json", "text"], default="text", help="Output format")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Add lxcore to path
    lxcore_path = str(Path(__file__).parent.parent)
    if lxcore_path not in sys.path:
        sys.path.insert(0, lxcore_path)
    
    from lxcore import open as lxopen
    
    if args.command == "stats":
        try:
            db = lxopen(args.path)
            stats = db.stats()
            db.close()
            
            print(f"Database: {stats['path']}")
            print(f"Size: {stats['size']:,} bytes")
            print(f"Segments: {stats['segment_count']}")
            print(f"Writer Stats:")
            for k, v in stats['writer_stats'].items():
                print(f"  {k}: {v}")
            print(f"Metadata:")
            for k, v in stats['meta'].items():
                print(f"  {k}: {v}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)
    
    elif args.command == "rebuild-index":
        from scripts.rebuild_index import main as rebuild_main
        sys.argv = ["rebuild_index.py", args.path]
        if args.verify:
            sys.argv.append("--verify")
        if args.force:
            sys.argv.append("--force")
        rebuild_main()
    
    elif args.command == "verify":
        try:
            db = lxopen(args.path)
            ok, reason, count = db.scan_recovery()
            consistent, discrepancies = db.verify_index()
            db.close()
            
            if ok:
                print(f"✓ Database integrity check passed")
                print(f"  Records: {count}")
            else:
                print(f"✗ Database integrity check failed: {reason}")
            
            if consistent:
                print(f"✓ Index consistency check passed")
            else:
                print(f"✗ Index consistency check failed: {len(discrepancies)} discrepancies")
                for d in discrepancies[:5]:
                    print(f"  - {d}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)
    
    elif args.command == "dump":
        try:
            db = lxopen(args.path)
            count = 0
            records = []
            
            for record in db.read_stream(namespace=args.namespace, tag=args.tag):
                if count >= args.limit:
                    break
                
                if args.format == "json":
                    records.append({
                        "ts": record["ts"],
                        "namespace": record["namespace"],
                        "tags": record["tags"],
                        "data_size": len(record["data"]),
                        "data_preview": record["data"][:50].hex() if record["data"] else "",
                        "offset": record["offset"],
                        "seg_id": record["seg_id"]
                    })
                else:
                    print(f"Record {count}:")
                    print(f"  Timestamp: {record['ts']}")
                    print(f"  Namespace: {record['namespace']}")
                    print(f"  Tags: {record['tags']}")
                    print(f"  Data size: {len(record['data'])} bytes")
                    print(f"  Data preview: {record['data'][:50].hex() if record['data'] else ''}")
                    print(f"  Segment: {record['seg_id']}, Offset: {record['offset']}")
                    print()
                
                count += 1
            
            db.close()
            
            if args.format == "json":
                print(json.dumps({"records": records, "total_returned": count}, indent=2))
            else:
                print(f"Total records: {count}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

if __name__ == "__main__":
    main()