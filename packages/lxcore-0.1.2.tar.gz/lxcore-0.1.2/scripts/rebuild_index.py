#!/usr/bin/env python3
"""
LXcore Index Rebuild Tool
Rebuilds index from segment files.
"""
import os
import sys
import argparse
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Rebuild LXcore index")
    parser.add_argument("path", help="Path to LXcore storage directory or .lx file")
    parser.add_argument("--verify", action="store_true", help="Verify index after rebuild")
    parser.add_argument("--force", action="store_true", help="Force rebuild even if index appears valid")
    
    args = parser.parse_args()
    
    # Add lxcore to path
    lxcore_path = str(Path(__file__).parent.parent)
    if lxcore_path not in sys.path:
        sys.path.insert(0, lxcore_path)
    
    from lxcore import create
    
    if not os.path.exists(args.path):
        print(f"Error: Path '{args.path}' does not exist")
        sys.exit(1)
    
    print(f"Rebuilding index for: {args.path}")
    
    # Create engine with auto_rebuild disabled
    engine = create(args.path, auto_create=False, auto_rebuild=False)
    
    # Check current index status
    if not args.force:
        ok, reason, count = engine.scan_recovery()
        if ok:
            print(f"Storage appears valid ({count} records)")
            
            # Check index specifically
            consistent, discrepancies = engine.verify_index()
            if consistent:
                print("Index appears consistent. Use --force to rebuild anyway.")
                engine.close()
                return
            else:
                print(f"Index has {len(discrepancies)} discrepancies")
    
    # Perform rebuild
    print("Rebuilding index...")
    success = engine.rebuild_index()
    
    if success:
        print("Index rebuild successful")
        
        if args.verify:
            print("Verifying...")
            consistent, discrepancies = engine.verify_index()
            if consistent:
                print("✓ Index verification passed")
            else:
                print(f"✗ Index verification failed: {len(discrepancies)} discrepancies")
                for d in discrepancies[:10]:  # Show first 10
                    print(f"  - {d}")
    else:
        print("✗ Index rebuild failed")
        sys.exit(1)
    
    engine.close()
    print("Done.")

if __name__ == "__main__":
    main()