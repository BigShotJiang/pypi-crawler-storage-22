import lxcore
import time
import os
import statistics
import sys
import shutil

# =====================
# CONFIG
# =====================
DB_PATH = "stress_test.lx"
TEST_DURATION = 3  # Shorter for testing
RAMP_STEPS = 6
PAYLOAD_BASE = b"x" * 64
NAMESPACES = ["agent1", "agent2"]
TAGS = ["tagA", "tagB"]

# =====================
# CLEAN START
# =====================
if os.path.exists(DB_PATH):
    os.remove(DB_PATH)

print("[lxcore] basic test starting")
print(f" duration: {TEST_DURATION}s, ramp steps: {RAMP_STEPS}")
print("-" * 40)

latencies = []
written = 0
start_time = time.time()

# =====================
# WRITE TEST
# =====================
with lxcore.create(DB_PATH, 
                   segment_max_bytes=1024*1024,  # 1MB segments
                   durability="fast") as db:
    
    for step in range(1, RAMP_STEPS + 1):
        step_start = time.time()
        step_duration = TEST_DURATION / RAMP_STEPS
        target_wps = 1000 * step  # Lower target for testing
        sleep_time = 1.0 / target_wps

        print(f"[step {step}] target {target_wps} writes/sec")

        while time.time() - step_start < step_duration:
            ns = NAMESPACES[written % len(NAMESPACES)]
            tag = TAGS[written % len(TAGS)]
            payload = PAYLOAD_BASE + written.to_bytes(4, "big")

            t0 = time.perf_counter_ns()
            db.write(payload, namespace=ns, tags=tag)
            t1 = time.perf_counter_ns()

            latencies.append((t1 - t0) / 1e6)
            written += 1

            if sleep_time > 0:
                time.sleep(sleep_time * 0.85)

    print(f"\n[write complete] {written} records written")

    # =====================
    # READ TEST
    # =====================
    records = list(db.read_stream())
    total_time = time.time() - start_time

    print("\n[lxcore] basic test complete")
    print("-" * 40)
    print(f" total time      : {total_time:.2f}s")
    print(f" records written : {written}")
    print(f" records read    : {len(records)}")

    # Get storage stats
    stats = db.stats()
    print(f" segments        : {stats.get('segment_count', 0)}")
    print(f" total size      : {stats.get('size', 0)/1024:.2f} KB")

    if latencies:
        print(f" avg latency     : {statistics.mean(latencies):.3f} ms")
        print(f" max latency     : {max(latencies):.3f} ms")

    # =====================
    # BASIC INTEGRITY CHECK
    # =====================
    print("\n[integrity check]")
    ok = True

    for r in records:
        if not r["data"].startswith(PAYLOAD_BASE):
            print(" corruption detected")
            ok = False
            break

    print("[integrity]", "OK" if ok else "FAILED")

print("\n[done]")
sys.exit(0 if ok else 1)