import lxcore
import time
import threading
import random
import os
import struct
import statistics
from concurrent.futures import ThreadPoolExecutor

# =====================
# 🔥 CONFIGURATION 🔥
# =====================
DB_PATH = "torture_test.lx"
DURATION = 10                # Seconds to run (shorter for testing)
WRITER_THREADS = 4           # Reduced for stability
READER_THREADS = 2           
TARGET_WPS_PER_THREAD = 200  # Controlled rate

# Payload definitions
PAYLOADS = {
    "tiny": b"x" * 16,
    "med":  b"y" * 1024,
    "huge": b"z" * (1024 * 64), 
}
WEIGHTS = [0.8, 0.15, 0.05]

# =====================
# STATE & METRICS
# =====================
running = True
metrics = {
    "writes": 0,
    "reads": 0,
    "errors": 0,
    "latencies": [],
    "seq_map": {}  # thread_id -> last_written_seq
}
lock = threading.Lock()

def writer_worker(db, thread_id):
    global metrics
    seq = 0
    print(f"  [writer-{thread_id}] 🔨 Starting...")
    
    while running:
        p_type = random.choices(list(PAYLOADS.keys()), weights=WEIGHTS)[0]
        # Embed Thread ID and Seq for integrity check
        data = struct.pack(">I I", thread_id, seq) + PAYLOADS[p_type]
        ns = f"agent_{thread_id}"
        tag = f"tag_{random.randint(0, 5)}"

        t0 = time.perf_counter_ns()
        try:
            db.write(data, namespace=ns, tags=[tag])
            with lock:
                metrics["writes"] += 1
                metrics["seq_map"][thread_id] = seq
                if seq % 100 == 0:
                    metrics["latencies"].append((time.perf_counter_ns() - t0) / 1e6)
            seq += 1
        except Exception as e:
            with lock: 
                metrics["errors"] += 1
            # Brief pause on error
            time.sleep(0.001)
        
        # Rate limiting
        if TARGET_WPS_PER_THREAD > 0:
            time.sleep(1.0 / TARGET_WPS_PER_THREAD)

def reader_worker(db, thread_id):
    global metrics
    print(f"  [reader-{thread_id}] 🔍 Starting...")
    while running:
        try:
            # Alternate between Full Scan and Indexed Lookup
            mode = random.choice(["scan", "index"])
            if mode == "index":
                # Use indexed lookup
                target_tag = f"tag_{random.randint(0, 5)}"
                count = sum(1 for _ in db.read_stream(tag=target_tag))
            else:
                # Standard scan
                count = sum(1 for _ in db.read_stream())
            
            with lock: 
                metrics["reads"] += 1
        except Exception as e:
            # print(f"Reader error: {e}")
            pass
        
        # Don't read too fast
        time.sleep(0.1)

# =====================
# MAIN EXECUTION
# =====================
if __name__ == "__main__":
    # Clean up old test files
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    
    print(f"💀 [INSANE V2] Starting Stress Test...")
    print(f"   Writers: {WRITER_THREADS} | Readers: {READER_THREADS}")
    print(f"   Duration: {DURATION}s | Target: {TARGET_WPS_PER_THREAD} wps/thread")
    print("-" * 55)

    start_time = time.time()
    
    with lxcore.create(
        DB_PATH,
        segment_max_bytes=1024 * 1024,  # 1MB segments
        durability="fast",
        queue_maxsize=5000,
        backpressure=True
    ) as db:
        
        with ThreadPoolExecutor(max_workers=WRITER_THREADS + READER_THREADS) as executor:
            # Start readers
            reader_futures = []
            for i in range(READER_THREADS): 
                reader_futures.append(executor.submit(reader_worker, db, i))
            
            # Start writers
            writer_futures = []
            for i in range(WRITER_THREADS): 
                writer_futures.append(executor.submit(writer_worker, db, i))

            # Run for specified duration
            try:
                while time.time() - start_time < DURATION:
                    elapsed = int(time.time() - start_time)
                    with lock:
                        w = metrics["writes"]
                        r = metrics["reads"]
                        e = metrics["errors"]
                    print(f"   T+{elapsed}s | W: {w:,} | R: {r:,} | E: {e}", end="\r")
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
            
            # Stop all workers
            running = False
            print("\n" + "-" * 55)
            print("⚡ Stopping workers...")

        # Wait for all tasks to complete
        time.sleep(1)
    
    # =====================
    # REOPEN & VERIFY
    # =====================
    print("\n🔍 [VERIFICATION PHASE]")
    with lxcore.create(DB_PATH, auto_rebuild=True) as db:
        all_records = list(db.read_stream())
        found_writes = len(all_records)
        
        # 1. Check Data Integrity
        seq_check = {}  # thread -> list of seqs
        for r in all_records:
            if len(r["data"]) >= 8:
                try:
                    t_id, seq = struct.unpack(">I I", r["data"][:8])
                    seq_check.setdefault(t_id, []).append(seq)
                except:
                    pass

        integrity_ok = True
        for t_id, seqs in seq_check.items():
            # Check for gaps or regressions
            if len(seqs) > 1:
                for i in range(1, len(seqs)):
                    if seqs[i] < seqs[i-1]:
                        print(f"   ❌ Thread {t_id}: Sequence regression at {seqs[i-1]} -> {seqs[i]}")
                        integrity_ok = False
                        break

        # 2. Get stats
        stats = db.stats()
        
        print("\n📊 [RESULTS]")
        print("-" * 55)
        print(f"   Writes Attempted: {metrics['writes']:,}")
        print(f"   Records Found   : {found_writes:,}")
        print(f"   Read Operations : {metrics['reads']:,}")
        print(f"   Write Errors    : {metrics['errors']:,}")
        print(f"   Segments Created: {stats.get('segment_count', 0)}")
        print(f"   Total Size      : {stats.get('size', 0)/1024:.1f} KB")
        
        # 3. Recovery check
        try:
            ok, reason, count = db.scan_recovery()
            print(f"   Recovery Scan   : {'✅ OK' if ok else '❌ FAIL'} ({reason})")
        except:
            print(f"   Recovery Scan   : ⚠️  Error")
        
        # 4. Latency stats
        if metrics["latencies"]:
            print(f"   Avg Write Latency: {statistics.mean(metrics['latencies']):.2f} ms")
            print(f"   P95 Write Latency: {statistics.quantiles(metrics['latencies'], n=20)[18]:.2f} ms" 
                  if len(metrics['latencies']) > 1 else "   P95: N/A")
        
        print(f"   Integrity Check : {'✅ PASS' if integrity_ok else '❌ FAIL'}")
        
        # 5. Test index queries
        print("\n🔎 [INDEX QUERY TEST]")
        try:
            tag_counts = {}
            for i in range(6):
                tag = f"tag_{i}"
                count = sum(1 for _ in db.read_stream(tag=tag))
                tag_counts[tag] = count
                print(f"   {tag}: {count:,} records")
        except Exception as e:
            print(f"   Index query error: {e}")
    
    # Final assessment
    print("\n" + "=" * 55)
    if integrity_ok and metrics["errors"] == 0:
        print("✅ TEST PASSED - No SIGBUS, no data corruption")
    else:
        print("⚠️  TEST HAD ISSUES - Check errors above")
    
    print("[Test Complete]")