#!/usr/bin/env python3
"""
Test LXcore API functionality
"""
import os
import tempfile
import lxcore

def test_open_alias():
    """Test that open() works as an alias for create()."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Test create()
        db1 = lxcore.create(db_path)
        db1.write(b"test1")
        db1.close()
        
        # Test open()
        db2 = lxcore.open(db_path)
        records = list(db2.read_stream())
        db2.close()
        
        assert len(records) == 1
        assert records[0]["data"] == b"test1"
        print("✓ open() alias works")
        
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_flush():
    """Test flush() method."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        with lxcore.create(db_path) as db:
            db.write(b"test flush")
            db.flush()  # Should not raise
            print("✓ flush() works")
            
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_context_manager():
    """Test context manager functionality."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        with lxcore.create(db_path) as db:
            db.write(b"test context")
            # Should automatically close on exit
        
        # Should be able to reopen
        with lxcore.open(db_path) as db:
            records = list(db.read_stream())
            assert len(records) == 1
            print("✓ Context manager works")
            
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_stats():
    """Test stats() method."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        with lxcore.create(db_path) as db:
            for i in range(10):
                db.write(f"data{i}".encode())
            
            stats = db.stats()
            assert "path" in stats
            assert "size" in stats
            assert "segment_count" in stats
            assert "writer_stats" in stats
            print("✓ stats() works")
            
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_index_rebuild():
    """Test index rebuild functionality."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Create DB with data
        with lxcore.create(db_path, use_index=True) as db:
            for i in range(20):
                db.write(f"data{i}".encode(), namespace="test", tags=[f"tag{i%5}"])
        
        # Corrupt index
        import zipfile
        import tempfile as tmp_module
        
        with tmp_module.TemporaryDirectory() as tmpdir:
            with zipfile.ZipFile(db_path, 'r') as zipf:
                zipf.extractall(tmpdir)
            
            index_path = os.path.join(tmpdir, "index.lxi.bin")
            if os.path.exists(index_path):
                with open(index_path, 'wb') as f:
                    f.write(b"CORRUPTED")
            
            with zipfile.ZipFile(db_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(tmpdir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, tmpdir)
                        zipf.write(file_path, arcname)
        
        # Reopen with auto_rebuild
        with lxcore.create(db_path, auto_rebuild=True) as db:
            records = list(db.read_stream())
            assert len(records) == 20
            print("✓ Index auto-rebuild works")
            
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_tag_queries():
    """Test tag-based queries."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        with lxcore.create(db_path, use_index=True) as db:
            # Write with tags
            db.write(b"data1", tags=["important", "test"])
            db.write(b"data2", tags=["test"])
            db.write(b"data3", tags=["important"])
            db.flush()
            
            # Query by tag
            important = list(db.read_stream(tag="important"))
            test = list(db.read_stream(tag="test"))
            
            assert len(important) == 2
            assert len(test) == 2
            print("✓ Tag queries work")
            
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_safe_destructor():
    """Test that destructor doesn't crash during interpreter shutdown."""
    import subprocess
    import sys
    
    test_code = '''
import lxcore
import tempfile
import os

with tempfile.NamedTemporaryFile(suffix=".lx", delete=False) as tmp:
    path = tmp.name

try:
    db = lxcore.create(path)
    db.write(b"test")
    # Don't call close() - let destructor handle it
    del db
    # Force garbage collection
    import gc
    gc.collect()
    print("SUCCESS: No crash during destruction")
except Exception as e:
    print(f"ERROR: {e}")
finally:
    if os.path.exists(path):
        os.remove(path)
'''
    
    result = subprocess.run([sys.executable, "-c", test_code], 
                          capture_output=True, text=True)
    assert "SUCCESS" in result.stdout
    print("✓ Safe destructor works")

if __name__ == "__main__":
    print("Running API tests...")
    
    tests = [
        test_open_alias,
        test_flush,
        test_context_manager,
        test_stats,
        test_index_rebuild,
        test_tag_queries,
        test_safe_destructor,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"✗ {test.__name__} failed: {e}")
            failed += 1
    
    print(f"\nTests: {passed} passed, {failed} failed")
    if failed > 0:
        exit(1)