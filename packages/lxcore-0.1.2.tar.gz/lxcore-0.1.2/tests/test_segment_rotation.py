#!/usr/bin/env python3
"""
Test segment rotation and basic functionality.
"""
import os
import tempfile
import lxcore

def test_small_segments():
    """Test with very small segments to force rotation."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Create DB with tiny segments
        with lxcore.create(db_path, segment_max_bytes=1024) as db:  # 1KB segments
            
            # Write enough data to force rotation
            for i in range(100):
                db.write(f"payload_{i}".encode(), namespace="test", tags=[f"tag{i%5}"])
            
            stats = db.stats()
            print(f"Segments created: {stats['segment_count']}")
            assert stats['segment_count'] > 1, "Should have multiple segments"
            
            # Read back all data
            records = list(db.read_stream())
            assert len(records) == 100, f"Expected 100 records, got {len(records)}"
            
            # Verify index
            consistent, discrepancies = db.verify_index()
            assert consistent, f"Index inconsistent: {discrepancies}"
            
            print("✓ Segment rotation test passed")
            
            return True
        
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_index_rebuild():
    """Test index rebuild after corruption."""
    with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
        db_path = tmp.name
    
    try:
        # Create DB and write data
        with lxcore.create(db_path) as db:
            for i in range(50):
                db.write(f"data_{i}".encode(), namespace="ns1", tags=["common"])
        
        # Corrupt index inside zip - we need to extract, corrupt, and re-zip
        import zipfile
        import tempfile
        
        # Extract zip
        with tempfile.TemporaryDirectory() as tmpdir:
            with zipfile.ZipFile(db_path, 'r') as zipf:
                zipf.extractall(tmpdir)
            
            # Corrupt index
            index_path = os.path.join(tmpdir, "index.lxi.bin")
            if os.path.exists(index_path):
                with open(index_path, 'wb') as f:
                    f.write(b"CORRUPTED")  # Truncate/corrupt index
            
            # Re-zip
            with zipfile.ZipFile(db_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(tmpdir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, tmpdir)
                        zipf.write(file_path, arcname)
        
        # Reopen with auto-rebuild
        with lxcore.create(db_path, auto_rebuild=True) as db:
            
            # Verify data is still accessible
            records = list(db.read_stream())
            assert len(records) == 50, f"Should recover 50 records, got {len(records)}"
            
            # Verify index was rebuilt
            consistent, _ = db.verify_index()
            assert consistent, "Index should be consistent after rebuild"
            
            print("✓ Index rebuild test passed")
            
            return True
        
    finally:
        if os.path.exists(db_path):
            os.remove(db_path)

def test_durability_modes():
    """Test different durability modes."""
    for mode in ["fast", "durable", "safe"]:
        with tempfile.NamedTemporaryFile(suffix='.lx', delete=False) as tmp:
            db_path = tmp.name
        
        try:
            with lxcore.create(db_path, durability=mode) as db:
                
                import time
                start = time.time()
                
                # Write some data
                for i in range(100):
                    db.write(f"test_{mode}_{i}".encode())
                
                elapsed = time.time() - start
                print(f"  {mode}: {elapsed:.3f}s for 100 writes")
            
        finally:
            if os.path.exists(db_path):
                os.remove(db_path)
    
    print("✓ Durability modes test passed")
    return True

if __name__ == "__main__":
    print("Running segment rotation tests...")
    
    all_passed = True
    
    try:
        all_passed &= test_small_segments()
    except Exception as e:
        print(f"✗ test_small_segments failed: {e}")
        all_passed = False
    
    try:
        all_passed &= test_index_rebuild()
    except Exception as e:
        print(f"✗ test_index_rebuild failed: {e}")
        all_passed = False
    
    try:
        all_passed &= test_durability_modes()
    except Exception as e:
        print(f"✗ test_durability_modes failed: {e}")
        all_passed = False
    
    if all_passed:
        print("\n✅ All tests passed!")
    else:
        print("\n❌ Some tests failed")
        exit(1)