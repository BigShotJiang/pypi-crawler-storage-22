"""Inference jobs command"""

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ....shared.config import config
from ....shared.display import format_timestamp, truncate_id

console = Console()

def jobs_cmd(
    stream_job_id: str = typer.Option(None, "--stream", "-s", metavar="JOB_ID", help="Stream status of a job"),
    result_job_id: str = typer.Option(None, "--result", "-r", metavar="JOB_ID", help="Get result of a job"),
    history: bool = typer.Option(False, "--history", "-h", help="List past jobs"),
):
    """
    Retrieve status of inference jobs
    """
    try:
        config.get_client()

        # 1. Stream Job
        if stream_job_id:
             console.print(f"[dim]Streaming job {stream_job_id}...[/dim]")
             # TODO: implement real streaming log retrieval if API supports it
             # For now, get batch status
             response = httpx.get(
                f"{config.base_url}/api/v2/external/batches/{stream_job_id}",
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=30.0
             )
             if response.status_code != 200:
                 console.print(f"[red]Error fetching job: {response.text}[/red]")
                 raise typer.Exit(1)

             data = response.json()
             console.print(f"Job Status: [cyan]{data['status']}[/cyan]")
             return

        # 2. Result Job
        if result_job_id:
             console.print(f"[dim]Getting result for {result_job_id}...[/dim]")
             response = httpx.get(
                f"{config.base_url}/api/v2/external/batches/{result_job_id}",
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=30.0
             )
             if response.status_code != 200:
                 console.print(f"[red]Error: {response.text}[/red]")
                 raise typer.Exit(1)

             data = response.json()
             if data.get('output_file_id'):
                 # Download output
                 file_resp = httpx.get(
                    f"{config.base_url}/api/v2/external/files/{data['output_file_id']}/content",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                    timeout=60.0
                 )
                 if file_resp.status_code == 200:
                     console.print("[green]Result:[/green]")
                     console.print(file_resp.text)
                 else:
                     console.print(f"[red]Error downloading result: {file_resp.text}[/red]")
             else:
                 console.print(f"[yellow]No output file yet. Status: {data['status']}[/yellow]")
             return

        # 3. History (List)
        if history:
             console.print("[dim]Fetching job history...[/dim]")
             response = httpx.get(
                f"{config.base_url}/api/v2/external/batches",
                headers={"Authorization": f"Bearer {config.api_key}"},
                params={"limit": 20},
                timeout=30.0
             )
             if response.status_code != 200:
                 console.print(f"[red]Error: {response.text}[/red]")
                 raise typer.Exit(1)

             data = response.json()
             batches = data.get('data', [])

             if not batches:
                 console.print("[yellow]No jobs found[/yellow]")
                 return

             table = Table(title="Inference Jobs History")
             table.add_column("Job ID", style="cyan", no_wrap=True, max_width=16)
             table.add_column("Status", style="yellow")
             table.add_column("Model/Endpoint", style="green")
             table.add_column("Created", style="dim")

             for batch in batches:
                 short_id = truncate_id(batch['id'], 12)
                 table.add_row(
                     short_id,
                     batch['status'],
                     batch.get('endpoint') or batch.get('model') or 'N/A',
                     format_timestamp(batch.get('created_at'))
                 )
             console.print(table)
             return

        console.print("[yellow]Please use --stream, --result, or --history[/yellow]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
