"""Inference chat command"""

import json
import os
from pathlib import Path

import typer
from rich.console import Console

from ....shared.config import config

console = Console()

def chat_cmd(
    prompt: str = typer.Option(None, "--prompt", "-p", help="The message or path to file (.txt/.yaml/.xml)"),
    no_stream: bool = typer.Option(False, "--no-stream", "-n", help="Disable streaming response"),
    image: str = typer.Option(None, "--image", "-i", help="Image path or base64"),
    image_url: str = typer.Option(None, "--url", help="Image URL"),
    image_dir: str = typer.Option(None, "--dir", help="Directory of images"),
    base64: bool = typer.Option(False, "--base64", help="Treat image input as base64"),
    model: str = typer.Option("gpt-4", "--model", "-m", help="Model to use"),
    max_tokens: int = typer.Option(1000, "--tokens", "-t", help="Max output tokens"),
    output_type: str = typer.Option("text", "--type", help="Output type (e.g. json, markdown)"),
    batch_file: str = typer.Option(None, "--batch", "-b", help="JSONL file for batch processing"),
):
    """
    Perform inference (Chat, Image, or Batch).
    """
    try:
        config.get_client()
        import httpx

        # 1. Batch Processing
        if batch_file:
            console.print(f"[dim]Initiating batch processing from {batch_file}...[/dim]")
            if not os.path.exists(batch_file):
                 console.print(f"[red]File not found: {batch_file}[/red]")
                 raise typer.Exit(1)

            # Upload
            with open(batch_file, 'rb') as f:
                files = {'file': (os.path.basename(batch_file), f, 'application/jsonl')}
                response = httpx.post(
                    f"{config.base_url}/api/v2/external/files",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                    files=files,
                    data={'purpose': 'batch'},
                    timeout=60.0
                )
            if response.status_code != 200:
                console.print(f"[red]Upload failed: {response.text}[/red]")
                raise typer.Exit(1)

            file_id = response.json()['id']

            # Create Batch
            response = httpx.post(
                f"{config.base_url}/api/v2/external/batches",
                headers={"Authorization": f"Bearer {config.api_key}"},
                json={"input_file_id": file_id, "model": model},
                timeout=30.0
            )
            if response.status_code != 200:
                console.print(f"[red]Batch creation failed: {response.text}[/red]")
                raise typer.Exit(1)

            data = response.json()
            console.print(f"[green]Batch Job Created: {data['id']}[/green]")
            return

        # 2. Image Analysis
        if image or image_url or image_dir:
            if image_dir:
                console.print("[yellow]Directory processing not yet implemented[/yellow]")
                return

            console.print(f"[dim]Analyzing image with {model}...[/dim]")

            img_input = image_url if image_url else image
            payload = {
                "model_id": model,
                "input": {
                    "text": prompt or "Describe this image",
                    # Simple heuristic: if it looks like a URL, treat as URL, else file/base64 logic
                    "image_url": img_input
                },
                "max_tokens": max_tokens,
                "stream": not no_stream
            }

            url = f"{config.base_url}/api/v2/external/sync/"
            headers = {"Authorization": f"Bearer {config.api_key}"}

            with httpx.Client() as client:
                response = client.post(url, json=payload, headers=headers, timeout=60.0)
                if response.status_code != 200:
                    console.print(f"[red]Error: {response.text}[/red]")
                    raise typer.Exit(1)

                result = response.json()
                console.print(f"[cyan]{result.get('output', '')}[/cyan]")
            return

        # 3. Text Chat (Prompt)
        if prompt:
            # Check if prompt is a file
            if os.path.exists(prompt):
                 prompt = Path(prompt).read_text()

            console.print(f"[dim]Sending message to {model}...[/dim]")

            payload = {
                "model_id": model,
                "input": {"text": prompt},
                "max_tokens": max_tokens,
                "stream": not no_stream
            }

            url = f"{config.base_url}/api/v2/external/sync/"
            headers = {"Authorization": f"Bearer {config.api_key}"}

            with httpx.Client() as client:
                response = client.post(url, json=payload, headers=headers, timeout=60.0)
                if response.status_code != 200:
                    console.print(f"[red]Error: {response.text}[/red]")
                    raise typer.Exit(1)

                result = response.json()
                console.print(f"[cyan]{result.get('output', '')}[/cyan]")
            return

        console.print("[yellow]Please provide input via --prompt, --image, or --batch[/yellow]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
