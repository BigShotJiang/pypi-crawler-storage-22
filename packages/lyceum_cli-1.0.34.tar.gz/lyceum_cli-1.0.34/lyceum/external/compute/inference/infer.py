"""Inference command group"""
import typer
import os
from rich.console import Console
import httpx
from ....shared.config import config
from .chat import chat_cmd
from .models import models_cmd
from .batch import jobs_cmd

console = Console()

infer_app = typer.Typer(name="infer", help="Inference commands")

# Mount sub-apps / commands
infer_app.command("chat")(chat_cmd)
infer_app.command("models")(models_cmd)
infer_app.command("jobs")(jobs_cmd)

@infer_app.command("deploy")
def deploy_model(
    hf_model_id: str = typer.Argument(..., help="HuggingFace model ID to deploy"),
    vllm_config: str = typer.Option(None, "--config", "-c", help="Name of server-side vLLM config to use"),
    hf_token: str = typer.Option(None, "--hf-token", "-t", help="HuggingFace token to use for deployment"),
):
    """Deploy a model for inference"""
    # Interactive prompt for token if not provided and not in env
    if hf_token is None and not (os.getenv("HF_TOKEN") or os.getenv("HUGGING_FACE_HUB_TOKEN")):
        if typer.confirm("No HF token detected. Do you want to provide one (required for private models)?", default=False):
            hf_token = typer.prompt("HuggingFace Token", hide_input=True)

    try:
        config.get_client()

        url = f"{config.base_url}/api/v2/external/inference/deploy"
        headers = {"Authorization": f"Bearer {config.api_key}"}

        payload = {
            "hf_model_id": hf_model_id
        }
        if vllm_config:
            payload["vllm_config_name"] = vllm_config
        if hf_token:
            payload["hf_token"] = hf_token

        console.print(f"[dim]Deploying model {hf_model_id}...[/dim]")

        with httpx.Client() as client:
            response = client.post(url, json=payload, headers=headers, timeout=30.0)

            if response.status_code != 200:
                console.print(f"[red]Error: HTTP {response.status_code}[/red]")
                console.print(f"[red]{response.text}[/red]")
                raise typer.Exit(1)

            data = response.json()

            console.print(f"[green]Deployment initiated![/green]")
            console.print(f"Model ID: [cyan]{data.get('model_id')}[/cyan]")
            console.print(f"Deployment ID: [cyan]{data.get('deployment_id')}[/cyan]")
            console.print(f"Status: [yellow]{data.get('status')}[/yellow]")
            console.print(f"Instance URL: [blue]{data.get('instance_url')}[/blue]")
            console.print("\n[dim]Use 'lyceum infer models' to check status[/dim]")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

@infer_app.command("spindown")
def spindown_model(
    model_id: str = typer.Argument(..., help="Model ID to spin down"),
):
    """Spin down a deployed model"""
    try:
        config.get_client()

        url = f"{config.base_url}/api/v2/external/inference/spindown"
        headers = {"Authorization": f"Bearer {config.api_key}"}

        payload = {"model_id": model_id}

        console.print(f"[dim]Spinning down model {model_id}...[/dim]")

        with httpx.Client() as client:
            response = client.post(url, json=payload, headers=headers, timeout=30.0)

            if response.status_code != 200:
                console.print(f"[red]Error: HTTP {response.status_code}[/red]")
                console.print(f"[red]{response.text}[/red]")
                raise typer.Exit(1)

            data = response.json()

            console.print(f"[green]Spindown initiated![/green]")
            console.print(f"Model ID: [cyan]{data.get('model_id')}[/cyan]")
            console.print(f"Status: [yellow]{data.get('status')}[/yellow]")
            console.print(f"Message: {data.get('message')}")

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
