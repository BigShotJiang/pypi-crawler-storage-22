"""Model discovery and information commands for AI inference"""

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ....shared.config import config

console = Console()

def models_cmd():
    """Retrieve available models"""
    try:
        config.get_client()

        endpoint = "/api/v2/external/models/"

        url = f"{config.base_url}{endpoint}"
        headers = {
            "Authorization": f"Bearer {config.api_key}",
            "ngrok-skip-browser-warning": "true",
        }

        console.print("[dim]Fetching available models...[/dim]")

        with httpx.Client() as http_client:
            response = http_client.get(url, headers=headers, timeout=10.0)

            if response.status_code != 200:
                console.print(f"[red]Error: HTTP {response.status_code}[/red]")
                try:
                    console.print(f"[red]{response.text}[/red]")
                except:
                    pass
                raise typer.Exit(1)

            models = response.json()

            if not models:
                console.print("[yellow]No models found matching your criteria[/yellow]")
                return

            # Filter to only available models
            models = [m for m in models if m.get('available', False)]

            if not models:
                console.print("[yellow]No available models found.[/yellow]")
                console.print("[dim]Deploy a new model with: lyceum infer deploy <model_id>[/dim]")
                return

            # Create a detailed table
            table = Table(title="Available AI Models", show_header=True, header_style="bold cyan")
            table.add_column("Model ID", style="cyan", no_wrap=True)
            table.add_column("Name", style="white")
            table.add_column("Type", style="magenta")

            # Sort models by type, then by name
            sorted_models = sorted(models, key=lambda m: (
                m.get('type', 'text'),
                m.get('model_id', '')
            ))

            for model in sorted_models:
                table.add_row(
                    model.get('model_id', 'Unknown'),
                    model.get('name', 'Unknown'),
                    model.get('type', 'text').title()
                )

            console.print(table)

    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
