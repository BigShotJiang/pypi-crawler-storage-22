"""GPU selection execution commands"""

import json
import time

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ....shared.config import config
from ....shared.streaming import StatusLine
from .python import (
    inject_script_args,
    load_workspace_config,
    read_code_from_source,
    resolve_import_files,
    resolve_requirements,
)

console = Console()

gpu_selection_app = typer.Typer(name="gpu-selection", help="GPU selection and profiling commands")

POLL_INTERVAL = 2.0
MAX_POLL_TIME = 3600  # 1 hour - A100/H100 initialization can take up to 30 min

# Cache for GPU pricing
_pricing_cache: dict[str, float] | None = None

# Mapping from API profile names to display names
GPU_DISPLAY_NAMES = {
    "gpu": "T4",
    "gpu.t4": "T4",
    "gpu.t4.64gb": "T4",
    "gpu.a100": "A100",
    "gpu.a100.40gb": "A100 (40GB)",
    "gpu.a100.80gb": "A100 (80GB)",
    "gpu.h100": "H100",
    "gpu.h200": "H200",
    "gpu.l40s": "L40S",
    "gpu.b200": "B200",
    "gpu.rtx6000pro": "RTX 6000 Pro",
}


def format_gpu_name(profile: str) -> str:
    """Format GPU profile name for display."""
    if profile in GPU_DISPLAY_NAMES:
        return GPU_DISPLAY_NAMES[profile]
    # Fallback: strip "gpu." prefix and uppercase
    return profile.replace("gpu.", "").upper()


def fetch_gpu_pricing() -> dict[str, float]:
    """Fetch GPU pricing from API. Returns dict of hardware_profile -> price_per_hour."""
    global _pricing_cache
    if _pricing_cache is not None:
        return _pricing_cache

    try:
        response = httpx.get(
            f"{config.base_url}/api/v2/external/machine-types",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=10.0,
        )
        if response.status_code == 200:
            data = response.json()
            _pricing_cache = {
                m["hardware_profile"]: m.get("price_per_hour", 0) or 0
                for m in data.get("machine_types", [])
            }
            return _pricing_cache
    except Exception:
        pass
    return {}


def calculate_cost(execution_time_s: float, hardware_profile: str, pricing: dict[str, float]) -> float | None:
    """Calculate cost based on execution time and GPU pricing."""
    price_per_hour = pricing.get(hardware_profile)
    if price_per_hour is None or price_per_hour == 0:
        return None
    return execution_time_s * (price_per_hour / 3600)


def submit_gpu_selection(payload: dict, status: StatusLine = None) -> str:
    """Submit GPU selection request to API and return the execution_id."""
    if status:
        status.update("Submitting GPU selection job...")

    response = httpx.post(
        f"{config.base_url}/api/v2/external/execution/gpu_selection/start",
        headers={"Authorization": f"Bearer {config.api_key}"},
        json=payload,
        timeout=30.0,
    )

    if response.status_code != 200:
        if status:
            status.stop()
        console.print(f"[red]Error: HTTP {response.status_code}[/red]")
        if response.status_code == 401:
            console.print("[red]Authentication failed. Your session may have expired.[/red]")
            console.print("[yellow]Run 'lyceum auth login' to re-authenticate.[/yellow]")
        elif response.status_code == 402:
            console.print("[red]Insufficient credits. Please purchase more credits to continue.[/red]")
        elif response.status_code == 403:
            console.print("[red]You do not have access to GPU instances.[/red]")
        else:
            console.print(f"[red]{response.content.decode()}[/red]")
        raise typer.Exit(1)

    data = response.json()
    return data["execution_id"]


def format_elapsed_time(seconds: float) -> str:
    """Format elapsed time in human readable format for status messages."""
    if seconds < 60:
        return f"{int(seconds)}s"
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return f"{minutes}m {secs}s"


def format_duration_hms(seconds: float) -> str:
    """Format duration in hh:mm:ss format."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    if hours > 0:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes}:{secs:02d}"


# Status descriptions for better user feedback
STATUS_DESCRIPTIONS = {
    "pending": "Queued, waiting for resources",
    "queued": "Queued, waiting for resources",
    "initializing": "Starting GPU instance",
    "running": "Analyzing your code",
    "extracting": "Extracting memory requirements",
    "profiling": "Running performance benchmarks",
    "processing": "Processing results",
}


def poll_gpu_selection(execution_id: str, status: StatusLine = None) -> dict:
    """Poll GPU selection status until terminal state."""
    elapsed = 0.0
    last_status = None
    phase_start_time = 0.0

    while elapsed < MAX_POLL_TIME:
        try:
            response = httpx.get(
                f"{config.base_url}/api/v2/external/execution/gpu_selection/{execution_id}/status",
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=10.0,
            )

            if response.status_code != 200:
                if status:
                    status.update(f"Connecting... ({format_elapsed_time(elapsed)})")
                time.sleep(POLL_INTERVAL)
                elapsed += POLL_INTERVAL
                continue

            data = response.json()
            current_status = data.get("status", "unknown")

            if current_status in ("completed", "failed", "aborted", "system_failure"):
                return data

            # Track phase changes
            if current_status != last_status:
                last_status = current_status
                phase_start_time = elapsed

            # Build informative status message
            if status:
                description = STATUS_DESCRIPTIONS.get(current_status, current_status.replace("_", " ").title())
                phase_time = elapsed - phase_start_time

                # Show phase time only if we've moved past the first phase
                if phase_start_time > 0 and phase_time > 5:
                    status.update(f"{description} ({format_elapsed_time(phase_time)}) • Total: {format_elapsed_time(elapsed)}")
                else:
                    status.update(f"{description} • {format_elapsed_time(elapsed)}")

        except httpx.RequestError:
            if status:
                status.update(f"Reconnecting... ({format_elapsed_time(elapsed)})")

        time.sleep(POLL_INTERVAL)
        elapsed += POLL_INTERVAL

    if status:
        status.stop()
    console.print("[yellow]Timed out waiting for GPU selection results.[/yellow]")
    console.print(f"[dim]Check later: lyceum gpu-selection status {execution_id}[/dim]")
    raise typer.Exit(1)


ERROR_SUGGESTIONS = {
    "No PyTorch or Hugging Face ecosystem detected": [
        "Add [cyan]import torch[/cyan] and use PyTorch modules",
        "Or use HuggingFace [cyan]transformers[/cyan] library",
    ],
    "GPU requirement cannot be determined or is CPU-only": [
        "Move model to GPU: [cyan]model.to('cuda')[/cyan]",
        "Move tensors to GPU: [cyan]tensor.to('cuda')[/cyan]",
        "Or use [cyan]device = torch.device('cuda')[/cyan]",
    ],
    "No model found": [
        "Define a class that inherits from [cyan]nn.Module[/cyan]",
        "Or use a pretrained model from [cyan]transformers[/cyan]",
    ],
    "No training loop detected": [
        "Add a training loop with [cyan]loss.backward()[/cyan]",
        "And [cyan]optimizer.step()[/cyan]",
    ],
}


def get_suggestions(error: str) -> list[str]:
    """Get suggestions for a given error message."""
    for key, suggestions in ERROR_SUGGESTIONS.items():
        if key.lower() in error.lower():
            return suggestions
    return []


def format_memory_size(gb: float) -> str:
    """Format memory size in GB with appropriate precision."""
    if gb >= 1:
        return f"{gb:.1f} GB"
    elif gb >= 0.001:
        return f"{gb * 1024:.0f} MB"
    else:
        return f"{gb * 1024 * 1024:.0f} KB"


def format_param_count(count: float) -> str:
    """Format parameter count with B/M suffix."""
    if count >= 1:
        return f"{count:.2f}B"
    elif count >= 0.001:
        return f"{count * 1000:.0f}M"
    else:
        return f"{count * 1000000:.0f}K"


def display_results(data: dict, file_path: str | None = None, optimize: str = "cost", execution_id: str | None = None) -> None:
    """Display GPU selection results."""
    if data is None:
        console.print()
        console.print(Panel(
            "[red]✗[/red] No response data received",
            title="[red]GPU Selection Failed[/red]",
            border_style="red",
            padding=(1, 2),
        ))
        return

    status = data.get("status", "unknown")

    # Parse metadata if it's a string
    metadata = data.get("metadata")
    if isinstance(metadata, str):
        try:
            metadata = json.loads(metadata)
        except (json.JSONDecodeError, TypeError):
            metadata = {}
    metadata = metadata or {}

    profiling = metadata.get("profiling_results", [])
    extraction = metadata.get("extraction_result", {})

    # Get memory info for summary
    mem_config = extraction.get("memory_config", {})
    minimal_configs = mem_config.get("minimal_configs", [])
    memory_requirements = mem_config.get("memory_requirements", {})

    # Fetch pricing for cost calculations
    pricing = fetch_gpu_pricing()

    # Calculate costs for profiling results
    if profiling:
        for result in profiling:
            if result.get("cost") is None and result.get("execution_time") is not None:
                result["cost"] = calculate_cost(
                    result["execution_time"],
                    result.get("profile", ""),
                    pricing
                )

    # Find the best GPU based on optimization strategy
    best_gpu = None
    best_profile = None  # The profile name of the best GPU

    completed_profiling = [p for p in profiling if p.get("status") in ("success", "completed")] if profiling else []

    if optimize == "speed" and completed_profiling:
        # Fastest execution time
        fastest = min(completed_profiling, key=lambda x: x.get("execution_time") or 999999)
        best_profile = fastest.get("profile")
    elif optimize == "util" and minimal_configs:
        # Highest utilization
        best_config = max(minimal_configs, key=lambda x: x.get("vram_utilization_percent", 0))
        best_profile = best_config.get("gpu_type")
    elif optimize == "cost" and completed_profiling:
        # Cheapest cost (default)
        cheapest = min(completed_profiling, key=lambda x: x.get("cost") or 999999)
        best_profile = cheapest.get("profile")
    elif minimal_configs:
        # Fallback: smallest VRAM if no profiling results
        sorted_configs = sorted(minimal_configs, key=lambda x: x.get("per_gpu_vram_gb", 999))
        best_profile = sorted_configs[0].get("gpu_type") if sorted_configs else None

    # Find best_gpu from minimal_configs matching best_profile
    if best_profile and minimal_configs:
        for cfg in minimal_configs:
            if cfg.get("gpu_type") == best_profile:
                best_gpu = cfg
                break
        # Fallback if profile not in minimal_configs
        if not best_gpu:
            sorted_configs = sorted(minimal_configs, key=lambda x: x.get("per_gpu_vram_gb", 999))
            best_gpu = sorted_configs[0] if sorted_configs else None

    # Determine state of extraction and profiling
    extraction_status = extraction.get("status")
    extraction_succeeded = extraction_status in ("success", "completed") or bool(minimal_configs)
    profiling_succeeded = profiling and any(p.get("status") in ("success", "completed") for p in profiling)
    all_profiling_failed = profiling and all(p.get("status") == "failed" for p in profiling)

    # Summary panel - show appropriate message based on what succeeded
    console.print()

    if status == "completed" or (extraction_succeeded and profiling_succeeded):
        # Full success
        summary_lines = ["[green]✓[/green] Analysis complete"]
        panel_title = "[green]GPU Selection Results[/green]"
        panel_style = "green"
    elif extraction_succeeded and all_profiling_failed:
        # Partial success: extraction worked, profiling failed
        summary_lines = [
            "[green]✓[/green] Memory extraction succeeded",
            "[red]✗[/red] Runtime prediction failed on all GPUs",
        ]
        panel_title = "[yellow]Partial Results[/yellow]"
        panel_style = "yellow"
    elif extraction_succeeded:
        # Extraction worked, profiling partially succeeded or didn't run
        summary_lines = ["[green]✓[/green] Memory extraction succeeded"]
        if not profiling:
            summary_lines.append("[dim]Profiling not attempted[/dim]")
        panel_title = "[yellow]Partial Results[/yellow]"
        panel_style = "yellow"
    else:
        # Complete failure
        errors = data.get("system_errors") or []
        error_lines = []
        all_suggestions = []

        for err in errors:
            error_lines.append(f"[red]✗[/red] {err}")
            all_suggestions.extend(get_suggestions(err))

        if not error_lines:
            error_lines.append(f"[red]✗[/red] Status: {status}")

        error_content = "\n".join(error_lines)

        if all_suggestions:
            error_content += "\n\n[dim]Suggestions:[/dim]"
            for suggestion in all_suggestions:
                error_content += f"\n  → {suggestion}"

        console.print(Panel(
            error_content,
            title="[red]GPU Selection Failed[/red]",
            border_style="red",
            padding=(1, 2),
        ))
        return

    if best_gpu:
        gpu_name = format_gpu_name(best_gpu.get("gpu_type", "unknown"))
        vram = best_gpu.get("per_gpu_vram_gb", "?")
        count = best_gpu.get("min_gpu_count", 1)
        gpu_str = f"{count}x " if count > 1 else ""

        # Label based on optimization strategy
        optimize_labels = {
            "cost": "Cheapest",
            "speed": "Fastest",
            "util": "Best utilization",
        }
        label = optimize_labels.get(optimize, "Recommended")

        summary_lines.append("")
        summary_lines.append(f"[bold]{label}:[/bold] [cyan]{gpu_str}{gpu_name}[/cyan] ({vram} GB VRAM)")

    # Add runtime info if available
    if profiling:
        completed = [p for p in profiling if p.get("status") in ("success", "completed")]
        if completed:
            fastest = min(completed, key=lambda x: x.get("execution_time", 999))
            time_s = fastest.get("execution_time")
            if time_s is not None:
                summary_lines.append(f"[bold]Est. runtime:[/bold] {format_duration_hms(time_s)}")

            report = fastest.get("runtime_report", {})
            iters = report.get("train_iteration", {}).get("train_iterations_per_second")
            if iters:
                summary_lines.append(f"[bold]Throughput:[/bold] {iters:.0f} iters/sec")

    console.print(Panel(
        "\n".join(summary_lines),
        title=panel_title,
        border_style=panel_style,
        padding=(1, 2),
    ))

    # Memory breakdown table (shown first for understanding model requirements)
    if memory_requirements:
        console.print()
        mem_table = Table(title="Memory Breakdown", show_header=True, header_style="bold")
        mem_table.add_column("Component", style="dim")
        mem_table.add_column("Size", justify="right", style="cyan")

        param_count = memory_requirements.get("parameter_count")
        if param_count is not None:
            mem_table.add_row("Parameters", format_param_count(param_count))

        weights = memory_requirements.get("model_weights")
        if weights is not None:
            mem_table.add_row("Model Weights", format_memory_size(weights))

        gradients = memory_requirements.get("gradients")
        if gradients is not None:
            mem_table.add_row("Gradients", format_memory_size(gradients))

        optimizer = memory_requirements.get("optimizer_states")
        if optimizer is not None:
            mem_table.add_row("Optimizer States", format_memory_size(optimizer))

        activations = memory_requirements.get("activations")
        if activations is not None:
            mem_table.add_row("Activations", format_memory_size(activations))

        # Add total if we have the components
        if all(v is not None for v in [weights, gradients, optimizer, activations]):
            total = weights + gradients + optimizer + activations
            mem_table.add_row("", "")  # Separator row
            mem_table.add_row("[bold]Total[/bold]", f"[bold]{format_memory_size(total)}[/bold]")

        console.print(mem_table)

    # Compatible GPU configurations table
    if minimal_configs:
        console.print()
        gpu_table = Table(title="Compatible GPUs", show_header=True, header_style="bold")
        gpu_table.add_column("GPU", style="cyan")
        # Show sort indicator based on optimization strategy
        vram_header = "VRAM ▲" if optimize != "util" else "VRAM"
        util_header = "Utilization ▼" if optimize == "util" else "Utilization"  # ▼ for descending
        gpu_table.add_column(vram_header, justify="right")
        gpu_table.add_column("GPUs Needed", justify="right")
        gpu_table.add_column(util_header, justify="right")

        # Sort based on optimization strategy
        if optimize == "util":
            # Sort by utilization descending (highest first)
            sorted_configs = sorted(minimal_configs, key=lambda x: x.get("vram_utilization_percent", 0), reverse=True)
        else:
            # Sort by VRAM ascending (smallest first)
            sorted_configs = sorted(minimal_configs, key=lambda x: x.get("per_gpu_vram_gb", 0))

        for cfg in sorted_configs:
            gpu_type_raw = cfg.get("gpu_type", "?")
            gpu_type = format_gpu_name(gpu_type_raw)
            vram = cfg.get("per_gpu_vram_gb", 0)
            count = cfg.get("min_gpu_count", 1)
            util = cfg.get("vram_utilization_percent", 0)

            # Highlight the best option in green
            is_best = gpu_type_raw == best_profile
            if is_best:
                gpu_table.add_row(
                    f"[green]{gpu_type}[/green] ✓",
                    f"[green]{vram} GB[/green]",
                    f"[green]{count}[/green]",
                    f"[green]{util}%[/green]",
                )
            else:
                gpu_table.add_row(
                    gpu_type,
                    f"{vram} GB",
                    str(count),
                    f"{util}%",
                )

        console.print(gpu_table)

    # Profiling results table with cost
    # Always show this table if profiling was attempted, even if all failed
    if profiling:
        console.print()
        prof_table = Table(title="Runtime Prediction", show_header=True, header_style="bold")
        prof_table.add_column("GPU", style="cyan")
        prof_table.add_column("Status")
        # Show sort indicator based on optimization strategy
        time_header = "Time ▲" if optimize == "speed" else "Time"
        cost_header = "Cost ▲" if optimize == "cost" else "Cost"
        prof_table.add_column(time_header, justify="right")
        prof_table.add_column(cost_header, justify="right")

        # Sort based on optimization strategy
        if optimize == "speed":
            sorted_profiling = sorted(profiling, key=lambda x: x.get("execution_time") or 999999)
        elif optimize == "cost":
            sorted_profiling = sorted(profiling, key=lambda x: x.get("cost") or 999999)
        else:
            # Default sort by execution time for other strategies
            sorted_profiling = sorted(profiling, key=lambda x: x.get("execution_time") or 999999)

        for result in sorted_profiling:
            profile = result.get("profile", "?")
            rst = result.get("status", "unknown")
            is_success = rst in ("completed", "success")
            is_best = is_success and profile == best_profile

            time_s = result.get("execution_time")
            cost = result.get("cost")

            # Highlight best in green, failures in red
            time_str = format_duration_hms(time_s) if time_s is not None else "-"
            cost_str = f"${cost:.2f}" if cost is not None else "-"

            if is_best:
                prof_table.add_row(
                    f"[green]{format_gpu_name(profile)}[/green] ✓",
                    "[green]success[/green]",
                    f"[green]{time_str}[/green]",
                    f"[green]{cost_str}[/green]",
                )
            elif is_success:
                prof_table.add_row(
                    format_gpu_name(profile),
                    "[green]success[/green]",
                    time_str,
                    cost_str,
                )
            else:
                prof_table.add_row(
                    format_gpu_name(profile),
                    f"[red]{rst}[/red]",
                    "-",
                    "-",
                )

        console.print(prof_table)

    # Show run command hint with prominent styling if we have a best GPU and file path
    if best_gpu and file_path:
        machine_flag = best_gpu.get("gpu_type", "gpu")
        console.print()
        run_cmd = f"lyceum python run {file_path} -m {machine_flag}"
        console.print(Panel(
            f"[bold green]▶ Run on Lyceum:[/bold green]\n\n  [cyan]{run_cmd}[/cyan]",
            border_style="green",
            padding=(0, 2),
        ))

    # Show feedback link
    if execution_id:
        feedback_url = f"https://dashboard.lyceum.technology/runs/runs-feedback/{execution_id}"
        console.print()
        console.print(f"[dim]Submit feedback for this job: {feedback_url}[/dim]")


@gpu_selection_app.command("run", context_settings={"allow_extra_args": True, "allow_interspersed_args": True})
def run_gpu_selection(
    ctx: typer.Context,
    code_or_file: str = typer.Argument(..., help="Python code to execute or path to Python file"),
    file_name: str | None = typer.Option(None, "--file-name", "-f", help="Name for the execution"),
    timeout: int = typer.Option(60, "--timeout", "-t", help="Timeout per sub-job in seconds (1-600)"),
    requirements: str | None = typer.Option(
        None, "--requirements", "-r", help="Requirements file path or pip requirements string"
    ),
    imports: list[str] | None = typer.Option(
        None, "--import", help="Pre-import modules (can be used multiple times)"
    ),
    use_config: bool = typer.Option(
        True, "--use-config/--no-config",
        help="Use workspace config from .lyceum/config.json if available"
    ),
    optimize: str = typer.Option(
        "cost", "--optimize", "-o",
        help="Optimization strategy: cost (cheapest), speed (fastest), util (highest utilization)"
    ),
    debug: bool = typer.Option(
        False, "--debug", "-d",
        help="Show detailed debug information about config, requirements, and payload"
    ),
):
    """Run code on multiple GPUs and select the optimal hardware.

    Submits the code to run on all GPU profiles available to your account,
    then returns which GPU performed best.

    Script arguments can be passed after the file path:

        lyceum gpu-selection run train.py -- --epochs 10 --lr 0.001
    """
    status = StatusLine()

    try:
        config.get_client()
        status.start()

        script_args = [arg for arg in (ctx.args or []) if arg != "--"]

        code, file_path, detected_file_name = read_code_from_source(code_or_file, status)
        if not file_name:
            file_name = detected_file_name

        code = inject_script_args(code, script_args, file_name)

        workspace_config = None
        if use_config:
            status.update("Loading workspace config...")
            workspace_config = load_workspace_config(file_path)
            if workspace_config and debug:
                status.stop()
                console.print(f"[cyan]DEBUG: Config keys: {list(workspace_config.keys())}[/cyan]")
                status.start()

        requirements_content = resolve_requirements(requirements, workspace_config, debug, status, file_path)
        import_files = resolve_import_files(file_path, workspace_config, debug, status)

        # Build payload matching GPUSelectionRequest schema
        payload = {
            "code": code,
            "nbcode": 0,
            "timeout": timeout,
        }
        if file_name:
            payload["file_name"] = file_name
        if requirements_content:
            payload["requirements_content"] = requirements_content
        if imports:
            payload["prior_imports"] = imports
        if import_files:
            payload["import_files"] = import_files

        if debug:
            status.stop()
            console.print("[cyan]DEBUG: Payload summary:[/cyan]")
            console.print(f"[cyan]  - timeout: {timeout}[/cyan]")
            console.print(f"[cyan]  - code length: {len(code)} chars[/cyan]")
            console.print(f"[cyan]  - requirements_content: {len(requirements_content or '')} chars[/cyan]")
            console.print(f"[cyan]  - import_files: {len(import_files or '')} chars[/cyan]")
            status.start()

        execution_id = submit_gpu_selection(payload, status)
        console.print(f"[dim]Execution ID: {execution_id}[/dim]")

        status.update("Analyzing code and predicting GPU requirements...")
        data = poll_gpu_selection(execution_id, status)
        status.stop()

        display_results(data, file_path=code_or_file, optimize=optimize, execution_id=execution_id)

        if data.get("status") != "completed":
            raise typer.Exit(1)

    except typer.Exit:
        status.stop()
        raise
    except Exception as e:
        status.stop()
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@gpu_selection_app.command("status")
def gpu_selection_status(
    execution_id: str = typer.Argument(..., help="Execution ID to check"),
    optimize: str = typer.Option(
        "cost", "--optimize", "-o",
        help="Optimization strategy: cost (cheapest), speed (fastest), util (highest utilization)"
    ),
):
    """Check the status of a GPU selection execution."""
    try:
        config.get_client()

        response = httpx.get(
            f"{config.base_url}/api/v2/external/execution/gpu_selection/{execution_id}/status",
            headers={"Authorization": f"Bearer {config.api_key}"},
            timeout=10.0,
        )

        if response.status_code == 404:
            console.print("[red]Execution not found.[/red]")
            raise typer.Exit(1)

        if response.status_code != 200:
            console.print(f"[red]Error: HTTP {response.status_code}[/red]")
            console.print(f"[red]{response.content.decode()}[/red]")
            raise typer.Exit(1)

        data = response.json()

        # Parse metadata if it's a string
        if isinstance(data.get("metadata"), str):
            try:
                data["metadata"] = json.loads(data["metadata"])
            except (json.JSONDecodeError, TypeError):
                pass

        current_status = data.get("status", "unknown")
        console.print(f"Status: [bold]{current_status}[/bold]")

        if current_status in ("completed", "failed", "aborted", "system_failure"):
            display_results(data, optimize=optimize, execution_id=execution_id)
        else:
            console.print("[dim]Job is still running. Check again later.[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
