#!/usr/bin/env python3
"""
Lyceum CLI - Command-line interface for Lyceum Cloud Execution API
Refactored to match API directory structure
"""

import typer
from rich.console import Console

# Import all command modules
from .external.auth.login import auth_app
from .external.compute.execution.python import python_app
from .external.compute.execution.docker import docker_app
from .external.compute.execution.docker_compose import compose_app
from .external.compute.execution.workloads import workloads_app
from .external.compute.execution.notebook import notebook_app
from .external.compute.execution.gpu_selection import gpu_selection_app
from .external.compute.inference.infer import infer_app
# from .external.vms.management import vms_app

__version__ = "1.0.38"


def version_callback(value: bool):
    if value:
        print(f"lyceum {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="lyceum",
    help="Lyceum Cloud Execution CLI",
    add_completion=False,
)


@app.callback()
def main(
    version: bool = typer.Option(
        None, "--version", "-v", callback=version_callback, is_eager=True,
        help="Show version and exit"
    ),
):
    """Lyceum Cloud Execution CLI"""
    pass

console = Console()

# Add all command groups
app.add_typer(auth_app, name="auth")
app.add_typer(python_app, name="python")
app.add_typer(docker_app, name="docker")
app.add_typer(compose_app, name="compose")
app.add_typer(workloads_app, name="workloads")
app.add_typer(notebook_app, name="notebook")
app.add_typer(gpu_selection_app, name="gpu-selection")
app.add_typer(infer_app, name="infer")
# app.add_typer(vms_app, name="vms")

















if __name__ == "__main__":
    app()
