# coding=utf-8
from adslproxy.sender import run

if __name__ == '__main__':
    run()