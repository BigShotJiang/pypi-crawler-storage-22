"""M365 Roadmap MCP Server - Query the Microsoft 365 Roadmap via MCP."""

__version__ = "0.1.0"
