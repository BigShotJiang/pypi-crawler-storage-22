"""M365 Roadmap API feed handling."""
