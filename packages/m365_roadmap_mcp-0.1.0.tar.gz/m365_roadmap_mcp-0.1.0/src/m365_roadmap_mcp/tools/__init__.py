"""MCP tools for M365 Roadmap."""
