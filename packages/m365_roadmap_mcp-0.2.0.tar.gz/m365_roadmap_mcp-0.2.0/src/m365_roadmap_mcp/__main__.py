"""Entry point for python -m m365_roadmap_mcp."""

from .server import main

main()
