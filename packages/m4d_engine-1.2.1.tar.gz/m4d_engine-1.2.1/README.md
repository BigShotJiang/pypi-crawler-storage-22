# 🚀 M4D Engine (Material 4 Design)

**M4D Engine**은 Windows 사용자를 위한 프리미엄 GUI 및 웹 개발 통합 프레임워크입니다. 
Win32 네이티브 드로잉부터 최신 Chromium 기반 웹 기술까지, 파이썬 코드 한 줄로 전문가급 UI를 구축할 수 있습니다.

---

## 📦 설치 (Installation)

```bash
pip install m4d-engine
```

---

## 🌟 주요 기능 및 사용법 (Key Features)

### 1. Zero-Init 자동 웹 개발 환경 (`m4d.App`)
터미널 명령어 없이 파이썬 실행만으로 React + Vite + Chromium 개발 환경을 즉시 구축합니다.

```python
import m4d

# 앱 이름만 지정하면 자동으로 프로젝트 생성 및 환경 설정이 완료됩니다.
app = m4d.App("my_premium_project")

# 서버 실행 및 브라우저 오픈까지 한 번에!
app.run()
```

### 2. 파이썬 전용 웹사이트 빌더 (`m4d.WebSite`)
프론트엔드 지식 없이 파이썬 객체만으로 고해상도 다크 테마 웹사이트를 제작합니다.

```python
import m4d

site = m4d.WebSite("M4D 공식 가이드")

# 섹션 추가
site.add_hero(title="M4D Web Engine", subtitle="파이썬으로 만드는 프리미엄 웹")
site.add_features([
    ("⚡", "초고속", "최적화된 렌더링"),
    ("🎨", "디자인", "옵시디언 다크 테마")
])

# 실시간 미리보기 실행
site.run(port=8080)
```

### 3. 네이티브 Win32 GUI 엔진 (`m4d.M4DEngine`)
외부 라이브러리 없이 Windows 시스템 API를 직접 호출하여 가볍고 빠른 데스크톱 앱을 만듭니다.

```python
import m4d

app = m4d.M4DEngine("Native App", 800, 600)
app.widgets.append(m4d.widgets.M4DButton(300, 250, 200, 50, "M4D Button"))
app.run()
```

---

## 🛠️ 고급 활용 (CLI)

자동화 기능 외에 수동으로 프로젝트를 생성하고 싶을 때 사용합니다.
```bash
m4d-init [프로젝트명]
```

---

## 💎 디자인 철학
M4D는 **Liquid Glass**와 **Obsidian Dark** 테마를 지향합니다. 사용자에게 "와우"를 선사하는 고해상도 그래픽과 매끄러운 애니메이션을 기본으로 제공합니다.

---

## 📝 라이선스
MIT License. 자유롭게 수정 및 배포가 가능합니다.

---
**M4D Engine** - *Material for Design, Logic for Performance.*
| [PyPI](https://pypi.org/project/m4d-engine/) | [Github](https://github.com/m4d/m4d-engine) |
