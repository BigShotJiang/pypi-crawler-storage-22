import os
import subprocess
import sys
import time
import webbrowser
import threading
from .cli import create_web_project # 기존 자동화 로직 재사용

class App:
    def __init__(self, name="m4d_project"):
        self.name = name
        self.project_path = os.path.join(os.getcwd(), self.name)
        self.server_process = None

    def _ensure_project(self):
        if not os.path.exists(self.project_path):
            print(f"📦 [M4D] '{self.name}' 프로젝트를 처음 생성합니다. 잠시만 기다려주세요...")
            # cli.py의 로직을 인자값 프로젝트명으로 호출
            sys.argv = [sys.argv[0], self.name]
            create_web_project()
        
        # node_modules 체크
        if not os.path.exists(os.path.join(self.project_path, "node_modules")):
            print(f"🔌 [M4D] 필요한 모듈을 설치 중입니다 (npm install)...")
            subprocess.run("cmd /c npm install", cwd=self.project_path, shell=True)

    def run(self):
        """가장 강력한 명령어: 환경 구축, 설치, 실행, 브라우저 오픈을 한 번에 수행"""
        self._ensure_project()
        
        print(f"🚀 [M4D] 엔진을 시작합니다...")
        
        # Vite 서버 실행
        self.server_process = subprocess.Popen(
            "cmd /c npm run dev", 
            cwd=self.project_path, 
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # 서버가 뜨기를 잠시 대기 후 브라우저 오픈
        time.sleep(3)
        url = "http://localhost:5173"
        print(f"🌐 [M4D] 브라우저에서 대시보드를 엽니다: {url}")
        webbrowser.open(url)

        print("\n✨ M4D 엔진이 활성화되었습니다. 파이썬 파일을 끄지 마세요.")
        try:
            while True:
                line = self.server_process.stdout.readline()
                if not line: break
                if "VITE" in line:
                    print(f"  [Log] {line.strip()}")
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\n🛑 엔진을 중지합니다...")
            self.server_process.terminate()
