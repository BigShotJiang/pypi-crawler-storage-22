import os
import subprocess
import sys
import shutil

APP_TSX = """
import React from 'react';

const Card = ({ title, description, icon }: { title: string, description: string, icon: string }) => (
  <div className="m4d-card">
    <div style={{ fontSize: '32px', marginBottom: '16px' }}>{icon}</div>
    <h3 style={{ marginBottom: '12px', fontSize: '20px' }}>{title}</h3>
    <p style={{ color: 'var(--m4d-text-dim)', lineHeight: '1.5' }}>{description}</p>
  </div>
);

function App() {
  return (
    <div className="m4d-engine-container">
      <nav className="m4d-navbar">
        <div className="m4d-logo">M4D ENGINE</div>
        <div style={{ display: 'flex', gap: '24px' }}>
          <button className="m4d-btn m4d-btn-outline" style={{ padding: '8px 20px' }}>Docs</button>
          <button className="m4d-btn" style={{ padding: '8px 20px' }}>Launch App</button>
        </div>
      </nav>

      <section className="m4d-hero">
        <div className="m4d-badge floating">M4D Engine v2.0 - Chromium Optimized</div>
        <h1 className="text-gradient">Next-Gen Interface for the Open Web.</h1>
        <p className="m4d-subtitle">
          Build stunning websites and high-performance applications using the M4D Framework. 
          Powered by Chromium, designed for professionals.
        </p>
        <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
          <button className="m4d-btn">Get Started</button>
          <button className="m4d-btn m4d-btn-outline">Watch Demo</button>
        </div>
      </section>

      <section className="m4d-grid">
        <Card 
          icon="🚀" 
          title="Speed Optimized" 
          description="Leverages modern Chromium JIT compilation for blistering UI performance." 
        />
        <Card 
          icon="🔋" 
          title="Battery Included" 
          description="Everything you need to build a website: Routing, State, UI, and Backend bridge." 
        />
        <Card 
          icon="🛠️" 
          title="Full Control" 
          description="Customizable CSS control over every pixel of your application." 
        />
      </section>

      <footer style={{ marginTop: '100px', padding: '40px', borderTop: '1px solid var(--m4d-border)', textAlign: 'center' }}>
        <p style={{ color: 'var(--m4d-text-dim)', fontSize: '14px' }}>
          &copy; 2026 M4D Engineering.
        </p>
      </footer>
    </div>
  );
}

export default App;
"""

INDEX_CSS = """
:root {
  --m4d-bg: #0a0a0c;
  --m4d-surface: #141418;
  --m4d-primary: #3b82f6;
  --m4d-primary-glow: rgba(59, 130, 246, 0.4);
  --m4d-text: #f8fafc;
  --m4d-text-dim: #94a3b8;
  --m4d-border: rgba(255, 255, 255, 0.1);
  --m4d-card-bg: rgba(20, 20, 24, 0.8);
  --font-main: 'Inter', system-ui, -apple-system, sans-serif;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  background-color: var(--m4d-bg);
  color: var(--m4d-text);
  font-family: var(--font-main);
  overflow-x: hidden;
  -webkit-font-smoothing: antialiased;
}

.m4d-engine-container {
  min-height: 100vh;
  padding: 40px;
  background: radial-gradient(circle at 50% 0%, #1e293b 0%, #0a0a0c 100%);
}

.m4d-navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 40px;
  background: rgba(10, 10, 12, 0.8);
  backdrop-filter: blur(10px);
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  border-bottom: 1px solid var(--m4d-border);
  z-index: 1000;
}

.m4d-logo {
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -1px;
  background: linear-gradient(135deg, #fff 0%, #3b82f6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.m4d-hero {
  max-width: 1200px;
  margin: 120px auto 60px;
  text-align: center;
}

.m4d-badge {
  display: inline-block;
  padding: 6px 12px;
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid var(--m4d-primary);
  color: var(--m4d-primary);
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 24px;
  text-transform: uppercase;
  letter-spacing: 1px;
}

h1 {
  font-size: clamp(48px, 8vw, 84px);
  margin-bottom: 24px;
  line-height: 1.1;
  font-weight: 800;
}

.text-gradient {
  background: linear-gradient(to bottom, #fff 40%, #64748b 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.m4d-subtitle {
  font-size: 20px;
  color: var(--m4d-text-dim);
  max-width: 600px;
  margin: 0 auto 48px;
  line-height: 1.6;
}

.m4d-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  max-width: 1200px;
  margin: 0 auto;
}

.m4d-card {
  background: var(--m4d-card-bg);
  border: 1px solid var(--m4d-border);
  border-radius: 16px;
  padding: 32px;
  transition: all 0.3s ease;
  text-align: left;
}

.m4d-card:hover {
  border-color: var(--m4d-primary);
  transform: translateY(-8px);
  box-shadow: 0 20px 40px rgba(0,0,0,0.4);
}

.m4d-btn {
  padding: 14px 32px;
  background: var(--m4d-primary);
  color: #fff;
  border-radius: 12px;
  border: none;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 4px 14px var(--m4d-primary-glow);
}

.m4d-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 6px 20px var(--m4d-primary-glow);
}

.m4d-btn-outline {
  background: transparent;
  border: 1px solid var(--m4d-border);
  box-shadow: none;
}

.m4d-btn-outline:hover {
  background: rgba(255, 255, 255, 0.05);
  border-color: #fff;
}

@keyframes float {
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
}

.floating {
  animation: float 4s ease-in-out infinite;
}
"""

def create_web_project():
    project_name = sys.argv[1] if len(sys.argv) > 1 else "my_m4d_app"
    print(f"Initializing M4D Web Project: {project_name}...")
    
    try:
        # Use create-vite with specific flags for non-interactive mode
        # Command varies slightly by version, but this is the most compatible:
        subprocess.run(f"cmd /c npx -y create-vite {project_name} --template react-ts", check=True)
        
        # Inject M4D assets
        src_path = os.path.join(project_name, "src")
        if os.path.exists(src_path):
            with open(os.path.join(src_path, "App.tsx"), "w", encoding="utf-8") as f:
                f.write(APP_TSX)
            with open(os.path.join(src_path, "index.css"), "w", encoding="utf-8") as f:
                f.write(INDEX_CSS)
                
            # Fix index.html root ID
            html_path = os.path.join(project_name, "index.html")
            if os.path.exists(html_path):
                with open(html_path, "r", encoding="utf-8") as f:
                    content = f.read()
                content = content.replace('id="app"', 'id="root"')
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(content)
            
            # Remove default vite styles to avoid conflicts
            for f in ["App.css", "style.css"]:
                p = os.path.join(src_path, f)
                if os.path.exists(p): os.remove(p)

        print(f"\n🚀 [SUCCESS] M4D Engine project '{project_name}' initialized!")
        print(f"---------------------------------------------------")
        print(f"Next steps:")
        print(f"  cd {project_name}")
        print(f"  npm install")
        print(f"  npm run dev")
        print(f"---------------------------------------------------")
    except Exception as e:
        print(f"❌ [ERROR] Failed to create project: {e}")
