import ctypes
from ctypes import wintypes
import time
from .graphics import Graphics, argb

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32
gdiplus = ctypes.windll.gdiplus

# Set argtypes for stability
user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.DefWindowProcW.restype = ctypes.c_longlong
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]

# Constants
CS_HREDRAW = 0x0002
CS_VREDRAW = 0x0001
IDC_ARROW = 32512
WS_OVERLAPPEDWINDOW = 0x00CF0000
SW_SHOWNORMAL = 1
WM_DESTROY = 0x0002
WM_PAINT = 0x000F
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_ERASEBKGND = 0x0014

class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.WINFUNCTYPE(ctypes.c_longlong, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HANDLE),
        ("hCursor", wintypes.HANDLE),
        ("hbrBackground", wintypes.HANDLE),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HANDLE),
    ]

class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [("hdc", wintypes.HDC), ("fErase", wintypes.BOOL), ("rcPaint", wintypes.RECT), ("fRestore", wintypes.BOOL), ("fIncUpdate", wintypes.BOOL), ("rgbReserved", ctypes.c_byte * 32)]

class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [("GdiplusVersion", ctypes.c_uint32), ("DebugEventCallback", ctypes.c_void_p), ("SuppressBackgroundThread", ctypes.c_bool), ("SuppressExternalCodecs", ctypes.c_bool)]

class M4DEngine:
    def __init__(self, title="M4D GUI Engine", width=1024, height=768):
        self.title = title
        self.width = width
        self.height = height
        self.hwnd = None
        self.hinstance = kernel32.GetModuleHandleW(None)
        self.classname = "M4D_Engine_Class"
        self.running = True
        
        # GDI+
        self.token = ctypes.c_ulonglong()
        self.si = GdiplusStartupInput(1, None, False, False)
        gdiplus.GdiplusStartup(ctypes.byref(self.token), ctypes.byref(self.si), None)
        
        self.widgets = []
        self.mouse_pos = (0, 0)
        self.mouse_pressed = False
        self.bg_color1 = argb(255, 15, 15, 25)
        self.bg_color2 = argb(255, 30, 30, 45)

    def _wnd_proc(self, hwnd, msg, wparam, lparam):
        if msg == WM_DESTROY:
            self.running = False
            user32.PostQuitMessage(0)
            return 0
        elif msg == WM_ERASEBKGND:
            return 1
        elif msg == WM_PAINT:
            self._on_paint(hwnd)
            return 0
        elif msg == WM_MOUSEMOVE:
            self.mouse_pos = (lparam & 0xFFFF, (lparam >> 16) & 0xFFFF)
            user32.InvalidateRect(hwnd, None, False)
            return 0
        elif msg == WM_LBUTTONDOWN:
            self.mouse_pressed = True
            user32.InvalidateRect(hwnd, None, False)
            return 0
        elif msg == WM_LBUTTONUP:
            self.mouse_pressed = False
            user32.InvalidateRect(hwnd, None, False)
            return 0
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _on_paint(self, hwnd):
        ps = PAINTSTRUCT()
        hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))
        rect = wintypes.RECT()
        user32.GetClientRect(hwnd, ctypes.byref(rect))
        w, h = rect.right - rect.left, rect.bottom - rect.top
        
        mem_dc = gdi32.CreateCompatibleDC(hdc)
        mem_bm = gdi32.CreateCompatibleBitmap(hdc, w, h)
        gdi32.SelectObject(mem_dc, mem_bm)
        
        g = Graphics(mem_dc)
        
        # Background: Modern Material Gradient
        g.fill_gradient_path(g.create_rounded_rect_path(0, 0, w, h, 0), (0, 0, w, h), self.bg_color1, self.bg_color2, True)
        
        for widget in self.widgets:
            widget.render(g, self.mouse_pos, self.mouse_pressed)
        
        gdi32.BitBlt(hdc, 0, 0, w, h, mem_dc, 0, 0, 0x00CC0020)
        del g
        gdi32.DeleteObject(mem_bm)
        gdi32.DeleteDC(mem_dc)
        user32.EndPaint(hwnd, ctypes.byref(ps))

    def run(self):
        WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        self._proc = WNDPROC(self._wnd_proc)
        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.lpfnWndProc = self._proc
        wc.hInstance = self.hinstance
        wc.hCursor = user32.LoadCursorW(None, IDC_ARROW)
        wc.lpszClassName = self.classname
        user32.RegisterClassExW(ctypes.byref(wc))

        self.hwnd = user32.CreateWindowExW(0, self.classname, self.title, WS_OVERLAPPEDWINDOW, 100, 100, self.width, self.height, None, None, self.hinstance, None)
        user32.ShowWindow(self.hwnd, SW_SHOWNORMAL)
        
        msg = wintypes.MSG()
        while self.running:
            if user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            else:
                time.sleep(0.01)
        gdiplus.GdiplusShutdown(self.token)
