import ctypes
from ctypes import wintypes

gdiplus = ctypes.windll.gdiplus
gdi32 = ctypes.windll.gdi32

# GDI+ Constants
UnitPixel = 2
UnitPoint = 3
FontStyleRegular = 0
StringAlignmentCenter = 1
StringAlignmentNear = 0

def argb(a, r, g, b):
    return (a << 24) | (r << 16) | (g << 8) | b

class Graphics:
    def __init__(self, hdc):
        self.graphics = ctypes.c_void_p()
        gdiplus.GdipCreateFromHDC(hdc, ctypes.byref(self.graphics))
        gdiplus.GdipSetSmoothingMode(self.graphics, 2) # AntiAlias
        gdiplus.GdipSetTextRenderingHint(self.graphics, 4) # ClearType

    def __del__(self):
        if self.graphics:
            gdiplus.GdipDeleteGraphics(self.graphics)

    def clear(self, color_argb):
        gdiplus.GdipGraphicsClear(self.graphics, color_argb)

    def draw_path(self, path, color_argb, thickness=1):
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(color_argb, ctypes.c_float(thickness), UnitPixel, ctypes.byref(pen))
        gdiplus.GdipDrawPath(self.graphics, pen, path)
        gdiplus.GdipDeletePen(pen)

    def fill_path(self, path, color_argb):
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(color_argb, ctypes.byref(brush))
        gdiplus.GdipFillPath(self.graphics, brush, path)
        gdiplus.GdipDeleteBrush(brush)
        
    def fill_gradient_path(self, path, rect, color1, color2, vertical=True):
        rect_f = (ctypes.c_float * 4)(*rect)
        brush = ctypes.c_void_p()
        mode = 1 if vertical else 0
        gdiplus.GdipCreateLineBrushFromRect(
            ctypes.byref(rect_f), color1, color2, mode, 0, ctypes.byref(brush)
        )
        gdiplus.GdipFillPath(self.graphics, brush, path)
        gdiplus.GdipDeleteBrush(brush)

    def create_rounded_rect_path(self, x, y, w, h, r):
        path = ctypes.c_void_p()
        gdiplus.GdipCreatePath(0, ctypes.byref(path))
        if r <= 0:
            gdiplus.GdipAddPathRectangle(path, ctypes.c_float(x), ctypes.c_float(y), ctypes.c_float(w), ctypes.c_float(h))
        else:
            gdiplus.GdipAddPathArc(path, ctypes.c_float(x), ctypes.c_float(y), ctypes.c_float(2*r), ctypes.c_float(2*r), ctypes.c_float(180), ctypes.c_float(90))
            gdiplus.GdipAddPathArc(path, ctypes.c_float(x+w-2*r), ctypes.c_float(y), ctypes.c_float(2*r), ctypes.c_float(2*r), ctypes.c_float(270), ctypes.c_float(90))
            gdiplus.GdipAddPathArc(path, ctypes.c_float(x+w-2*r), ctypes.c_float(y+h-2*r), ctypes.c_float(2*r), ctypes.c_float(2*r), ctypes.c_float(0), ctypes.c_float(90))
            gdiplus.GdipAddPathArc(path, ctypes.c_float(x), ctypes.c_float(y+h-2*r), ctypes.c_float(2*r), ctypes.c_float(2*r), ctypes.c_float(90), ctypes.c_float(90))
            gdiplus.GdipClosePathFigure(path)
        return path

    def draw_text(self, text, x, y, w, h, color_argb, size=12, align="center", font_name="Segoe UI"):
        family = ctypes.c_void_p()
        gdiplus.GdipCreateFontFamilyFromName(font_name, None, ctypes.byref(family))
        font = ctypes.c_void_p()
        gdiplus.GdipCreateFont(family, ctypes.c_float(size), FontStyleRegular, UnitPoint, ctypes.byref(font))
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(color_argb, ctypes.byref(brush))
        rect_f = (ctypes.c_float * 4)(x, y, w, h)
        fmt = ctypes.c_void_p()
        gdiplus.GdipCreateStringFormat(0, 0, ctypes.byref(fmt))
        if align == "center":
            gdiplus.GdipSetStringFormatAlign(fmt, StringAlignmentCenter)
            gdiplus.GdipSetStringFormatLineAlign(fmt, StringAlignmentCenter)
        elif align == "left":
            gdiplus.GdipSetStringFormatAlign(fmt, StringAlignmentNear)
            gdiplus.GdipSetStringFormatLineAlign(fmt, StringAlignmentCenter)
            
        gdiplus.GdipDrawString(self.graphics, str(text), -1, font, ctypes.byref(rect_f), fmt, brush)
        
        gdiplus.GdipDeleteStringFormat(fmt)
        gdiplus.GdipDeleteBrush(brush)
        gdiplus.GdipDeleteFont(font)
        gdiplus.GdipDeleteFontFamily(family)
