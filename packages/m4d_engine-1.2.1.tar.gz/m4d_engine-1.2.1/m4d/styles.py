from .graphics import argb

class Style:
    def __init__(self, **kwargs):
        self.bg_color = kwargs.get('bg_color', argb(100, 255, 255, 255))
        self.border_color = kwargs.get('border_color', argb(50, 255, 255, 255))
        self.border_width = kwargs.get('border_width', 1)
        self.border_radius = kwargs.get('border_radius', 12)
        self.color = kwargs.get('color', argb(255, 255, 255, 255))
        self.font_size = kwargs.get('font_size', 12)
        self.font_name = kwargs.get('font_name', "Segoe UI")
        self.hover_bg = kwargs.get('hover_bg', None)
        self.active_bg = kwargs.get('active_bg', None)
        self.glass_effect = kwargs.get('glass_effect', True)

    @staticmethod
    def from_css(css_str):
        # A very primitive pseudo-CSS parser
        props = {}
        for line in css_str.split(';'):
            if ':' not in line: continue
            k, v = line.split(':')
            k = k.strip().lower()
            v = v.strip()
            
            if k == 'background-color':
                props['bg_color'] = Style._parse_color(v)
            elif k == 'border-radius':
                props['border_radius'] = int(v.replace('px', ''))
            elif k == 'color':
                props['color'] = Style._parse_color(v)
            elif k == 'font-size':
                props['font_size'] = int(v.replace('pt', '').replace('px', ''))
            elif k == 'border-color':
                props['border_color'] = Style._parse_color(v)
        return Style(**props)

    @staticmethod
    def _parse_color(val):
        # Support rgba(r,g,b,a) or #hex or simple colors
        if val.startswith('rgba'):
            parts = val.replace('rgba(', '').replace(')', '').split(',')
            r, g, b, a = [int(float(x.strip())) if '.' not in x else int(float(x.strip())*255) for x in parts]
            return argb(a, r, g, b)
        elif val.startswith('#'):
            h = val.lstrip('#')
            if len(h) == 6:
                r, g, b = struct.unpack('BBB', bytes.fromhex(h))
                return argb(255, r, g, b)
        return argb(255, 100, 100, 100) # Default
