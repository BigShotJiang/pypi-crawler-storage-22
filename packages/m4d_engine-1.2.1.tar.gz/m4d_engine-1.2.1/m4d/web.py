import os
import http.server
import socketserver
import webbrowser
import threading

class WebSite:
    def __init__(self, title="M4D Website"):
        self.title = title
        self.sections = []
        self.theme_color = "#3b82f6"

    def add_hero(self, title, subtitle, badge="M4D Powered"):
        self.sections.append({
            "type": "hero",
            "title": title,
            "subtitle": subtitle,
            "badge": badge
        })

    def add_features(self, features):
        """features is a list of (icon, title, desc) tuples"""
        self.sections.append({
            "type": "features",
            "items": features
        })

    def _generate_html(self):
        sections_html = ""
        for s in self.sections:
            if s["type"] == "hero":
                sections_html += f"""
                <section class="hero">
                    <div class="badge floating">{s['badge']}</div>
                    <h1 class="text-gradient">{s['title']}</h1>
                    <p class="subtitle">{s['subtitle']}</p>
                    <div class="cta-group">
                        <button class="btn">시작하기</button>
                        <button class="btn btn-outline">더 알아보기</button>
                    </div>
                </section>
                """
            elif s["type"] == "features":
                items_html = ""
                for icon, title, desc in s["items"]:
                    items_html += f"""
                    <div class="card">
                        <div class="icon">{icon}</div>
                        <h3>{title}</h3>
                        <p>{desc}</p>
                    </div>
                    """
                sections_html += f'<section class="grid">{items_html}</section>'

        return f"""
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title}</title>
    <style>
        :root {{
            --bg: #0a0a0c; --surface: #141418; --primary: {self.theme_color};
            --text: #f8fafc; --text-dim: #94a3b8; --border: rgba(255,255,255,0.1);
        }}
        body {{ background: var(--bg); color: var(--text); font-family: system-ui; margin: 0; padding: 0; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 40px; text-align: center; }}
        .hero {{ padding: 100px 20px; }}
        .badge {{ display: inline-block; padding: 6px 12px; border: 1px solid var(--primary); color: var(--primary); border-radius: 20px; font-size: 12px; margin-bottom: 20px; }}
        h1 {{ font-size: 64px; margin: 0; font-weight: 800; }}
        .text-gradient {{ background: linear-gradient(to bottom, #fff, #64748b); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }}
        .subtitle {{ font-size: 20px; color: var(--text-dim); margin: 24px auto; max-width: 600px; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px; padding: 40px; }}
        .card {{ background: var(--surface); border: 1px solid var(--border); padding: 32px; border-radius: 16px; text-align: left; transition: 0.3s; }}
        .card:hover {{ border-color: var(--primary); transform: translateY(-5px); }}
        .icon {{ font-size: 32px; margin-bottom: 16px; }}
        .btn {{ padding: 12px 24px; background: var(--primary); border: none; color: white; border-radius: 8px; font-weight: 600; cursor: pointer; }}
        .btn-outline {{ background: transparent; border: 1px solid var(--border); color: var(--text); margin-left:12px; }}
        @keyframes float {{ 0%, 100% {{ transform: translateY(0); }} 50% {{ transform: translateY(-10px); }} }}
        .floating {{ animation: float 3s ease-in-out infinite; }}
    </style>
</head>
<body>
    <div class="container">
        {sections_html}
    </div>
</body>
</html>
"""

    def build(self, output_dir="dist"):
        if not os.path.exists(output_dir): os.makedirs(output_dir)
        with open(os.path.join(output_dir, "index.html"), "w", encoding="utf-8") as f:
            f.write(self._generate_html())
        print(f"✅ Website build complete in '{output_dir}/'")

    def run(self, port=8000):
        self.build(".temp_serve")
        os.chdir(".temp_serve")
        handler = http.server.SimpleHTTPRequestHandler
        with socketserver.TCPServer(("", port), handler) as httpd:
            print(f"🚀 M4D Web Server running at http://localhost:{port}")
            webbrowser.open(f"http://localhost:{port}")
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                httpd.shutdown()
                print("\nStopped server.")
