from .graphics import argb, Graphics
from .styles import Style
import ctypes

gdiplus = ctypes.windll.gdiplus

class Widget:
    def __init__(self, x, y, w, h, style=None):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.style = style or Style()
    
    def is_hovered(self, mouse_pos):
        mx, my = mouse_pos
        return self.x <= mx <= self.x + self.w and self.y <= my <= self.y + self.h

    def render(self, g, mouse_pos, is_pressed):
        pass

class GlassCard(Widget):
    def render(self, g, mouse_pos, is_pressed):
        s = self.style
        path = g.create_rounded_rect_path(self.x, self.y, self.w, self.h, s.border_radius)
        
        # 1. Background Blur / Translucency (Liquid Glass base)
        # We simulate this with a semi-transparent gradient
        g.fill_gradient_path(path, (self.x, self.y, self.w, self.h), 
                             argb(150, 255, 255, 255), # Top-left light
                             argb(60, 200, 200, 255), # Bottom-right slight tint
                             True)
        
        # 2. Inner Highlight (Bevel effect for Glass)
        inner_r = max(0, s.border_radius - 1)
        inner_path = g.create_rounded_rect_path(self.x + 1, self.y + 1, self.w - 2, self.h - 2, inner_r)
        g.draw_path(inner_path, argb(100, 255, 255, 255), 1.5)
        gdiplus.GdipDeletePath(inner_path)
        
        # 3. Main Border
        g.draw_path(path, s.border_color, s.border_width)
        
        # 4. Glossy Highlight (The "Liquid" part)
        # A simple ellipse or path at the top
        gloss_path = ctypes.c_void_p()
        gdiplus.GdipCreatePath(0, ctypes.byref(gloss_path))
        gdiplus.GdipAddPathEllipse(gloss_path, 
                                   ctypes.c_float(self.x + self.w*0.1), 
                                   ctypes.c_float(self.y - self.h*0.2), 
                                   ctypes.c_float(self.w*0.8), 
                                   ctypes.c_float(self.h*0.5))
        # Use clipping to only show it inside the card
        gdiplus.GdipSetClipPath(g.graphics, path, 0)
        g.fill_path(gloss_path, argb(30, 255, 255, 255))
        gdiplus.GdipResetClip(g.graphics)
        
        gdiplus.GdipDeletePath(gloss_path)
        gdiplus.GdipDeletePath(path)

class M4DButton(Widget):
    def __init__(self, x, y, w, h, text, callback=None, style=None):
        super().__init__(x, y, w, h, style)
        self.text = text
        self.callback = callback
        self.was_pressed = False

    def render(self, g, mouse_pos, is_pressed):
        hover = self.is_hovered(mouse_pos)
        s = self.style
        
        # Colors based on state
        curr_bg = s.bg_color
        if hover:
            curr_bg = s.hover_bg or argb(180, 100, 100, 255)
            if is_pressed:
                curr_bg = s.active_bg or argb(220, 80, 80, 230)
                if not self.was_pressed:
                    if self.callback: self.callback()
                    self.was_pressed = True
            else:
                self.was_pressed = False
        else:
            self.was_pressed = False

        path = g.create_rounded_rect_path(self.x, self.y, self.w, self.h, s.border_radius)
        
        # Shadow if hovered
        if hover:
            shadow_path = g.create_rounded_rect_path(self.x-1, self.y-1, self.w+2, self.h+2, s.border_radius+1)
            g.fill_path(shadow_path, argb(40, 0, 0, 0))
            gdiplus.GdipDeletePath(shadow_path)

        # Main Body
        g.fill_path(path, curr_bg)
        
        # Border
        g.draw_path(path, s.border_color, s.border_width)
        
        # Text
        g.draw_text(self.text, self.x, self.y, self.w, self.h, s.color, s.font_size, font_name=s.font_name)
        
        gdiplus.GdipDeletePath(path)

class M4DLabel(Widget):
    def __init__(self, x, y, w, h, text, style=None, align="center"):
        super().__init__(x, y, w, h, style)
        self.text = text
        self.align = align

    def render(self, g, mouse_pos, is_pressed):
        s = self.style
        g.draw_text(self.text, self.x, self.y, self.w, self.h, s.color, s.font_size, align=self.align, font_name=s.font_name)
