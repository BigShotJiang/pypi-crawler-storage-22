import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="m4d-engine",
    version="1.2.1",
    author="M4D Dev Team",
    author_email="m4d@example.com",
    description="A premium Native & Web GUI framework for Windows.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/m4d/m4d-engine",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires='>=3.7',
    entry_points={
        'console_scripts': [
            'm4d-init=m4d.cli:create_web_project',
        ],
    },
    install_requires=[], # No external dependencies for native core
)
