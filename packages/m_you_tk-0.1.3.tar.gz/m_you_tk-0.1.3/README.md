# About

A modern Material You (Material Design 3) UI library for Tkinter with smooth LERP animations.
It was made for black theme, for best look use #1C1B1F background

## Documentation

The full documentation for this library is provided as a **standalone Windows application** for your convenience.

### How to open:
1. Locate `docs.exe` in the root directory.
2. Run it to view the documentation in a dedicated window (no browser needed).

> On linux, use wine (bad idea) or go to docs folder and open index.html

---

## 🛠 Quick Installation

```bash
pip install m-you-tk
```
# Usage
```python
from m_you import (
    MaterialInput, 
    MaterialButton, 
    MaterialDropdown, 
    MaterialSwitch, 
    MaterialToast, 
    MaterialCheckbox,
    MaterialSlider,
    MaterialRadioButton
)
""" or use this:
from m_you import MaterialInput
from m_you import MaterialButton
from m_you import MaterialDropdown
from m_you import MaterialSwitch
from m_you import MaterialToast
from m_you import MaterialSlider
from m_you import MaterialCheckbox
from m_you import MaterialRadioButton
"""
import tkinter as tk

root = tk.Tk()
root.geometry("400x300")
root.configure(bg="#1C1B1F")
btn = MaterialButton(root, text="Click Me!", command=lambda: print("Hello!"))
btn.pack(pady=20)

root.mainloop()
```

## Icons avaible:
edit, settings, home, search, favorite, delete, add, check, close, menu, person, share, sound, wifi, baterry, camera, folder, email, clock

### Changelog:
0.1.0 - first release
0.1.1 - bug fixes
0.1.2 - added README file
0.1.3 - now docs are standalone .exe for windows users