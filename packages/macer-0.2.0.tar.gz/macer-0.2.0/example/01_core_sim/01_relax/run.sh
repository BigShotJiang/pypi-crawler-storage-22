#!/bin/bash
macer relax -p POSCAR --ff emt --fmax 0.1 --output-dir output
