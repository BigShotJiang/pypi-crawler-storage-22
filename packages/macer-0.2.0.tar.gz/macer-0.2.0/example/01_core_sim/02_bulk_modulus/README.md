# Example: Bulk Modulus
Calculate Bulk Modulus by fitting Equation of State (EOS).
## Command
```bash
macer relax -p POSCAR --ff emt --bulk-modulus --strain 0.02 --n-points 5
```
