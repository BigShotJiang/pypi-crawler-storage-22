#!/bin/bash
macer relax -p POSCAR --ff emt --bulk-modulus --strain 0.02 --n-points 5
