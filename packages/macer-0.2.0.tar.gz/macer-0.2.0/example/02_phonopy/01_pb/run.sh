#!/bin/bash
macer phonopy pb -p POSCAR --ff emt --dim 2 2 2 --dos --write-arrow --output-dir output
