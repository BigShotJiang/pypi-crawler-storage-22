# Example: Symmetry Refine
Refine structure symmetry using phonopy.
## Command
```bash
macer phonopy sr -p POSCAR --ff emt --tolerance 0.01 --output-dir output
```
