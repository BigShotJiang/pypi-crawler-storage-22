#!/bin/bash
macer phonopy sr -p POSCAR --ff emt --tolerance 0.01 --output-dir output
