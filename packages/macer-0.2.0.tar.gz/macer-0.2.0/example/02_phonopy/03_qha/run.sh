#!/bin/bash
macer phonopy qha -p POSCAR --ff emt --dim 2 2 2 --num-volumes 4 --tmax 500 --output-dir output
