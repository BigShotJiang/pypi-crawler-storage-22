# Example: SSCHA
Self-consistent phonon calculation (SSCHA).
## Command
```bash
macer phonopy sscha -p POSCAR --ff emt --dim 2 2 2 -T 300 --max-iter 2 --output-dir output
```
