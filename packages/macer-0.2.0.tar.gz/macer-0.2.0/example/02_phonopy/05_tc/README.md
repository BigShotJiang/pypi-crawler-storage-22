# Example: Thermal Conductivity
Calculate thermal conductivity using phono3py.
## Command
```bash
macer phonopy tc -p POSCAR --ff emt --dim 2 2 2 --mesh 3 3 3 --no-save-hdf5 --output-dir output
```
