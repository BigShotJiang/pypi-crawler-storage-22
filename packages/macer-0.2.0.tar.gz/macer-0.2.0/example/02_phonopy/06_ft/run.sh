#!/bin/bash
macer phonopy ft -p POSCAR --ff emt -T 300 --dim 2 2 2 --md-steps 50 --output-dir output
