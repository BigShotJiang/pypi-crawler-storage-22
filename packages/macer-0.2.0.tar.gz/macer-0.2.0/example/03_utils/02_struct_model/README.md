# Example: Struct & Model Utilities
Structure conversion and model management.
## Command
```bash
macer util struct vasp4to5 -i POSCAR -o POSCAR_v5
macer util model list
```
