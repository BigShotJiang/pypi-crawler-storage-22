#!/bin/bash
macer util struct vasp4to5 -i POSCAR -o POSCAR_v5
macer util model list
