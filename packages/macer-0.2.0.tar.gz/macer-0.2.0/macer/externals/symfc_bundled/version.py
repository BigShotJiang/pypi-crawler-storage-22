"""Version number of the package."""

__version__ = "1.6.0"
