
_CHGNET_AVAILABLE = False
try:
    from chgnet.model import CHGNetCalculator
    _CHGNET_AVAILABLE = True
except Exception:
    pass

from macer.defaults import resolve_model_path

def get_chgnet_calculator(model_path=None, device="cpu", **kwargs):
    if not _CHGNET_AVAILABLE:
        raise RuntimeError("CHGNet is not installed. Please install with 'pip install .[chgnet]'")
    
    if model_path:
        resolved = resolve_model_path(model_path)
        if resolved:
            model_path = resolved

    # CHGNetCalculator takes common arguments
    return CHGNetCalculator(use_device=device)
