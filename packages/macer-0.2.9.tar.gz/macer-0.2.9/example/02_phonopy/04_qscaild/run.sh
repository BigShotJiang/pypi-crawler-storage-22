#!/bin/bash
macer phonopy qscaild -p POSCAR --ff emt --dim 2 2 2 -T 300 --nsteps 2 --output-dir output
