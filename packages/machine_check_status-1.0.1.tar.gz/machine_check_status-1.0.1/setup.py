from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="machine-check-status",
    version="1.0.1",
    author="eleven_developer",
    description="machine status and operation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "machine_check_status": [
            "pyarmor_runtime_000000/*",
            "pyarmor_runtime_000000/*/*",
        ],
    },
    python_requires=">=3.7",
    install_requires=[
        "psutil>=5.8.0",
        "colorama>=0.4.4",
        "requests>=2.25.0",
        "rich>=10.0.0",
        "websocket-client>=1.4.0",
    ],
    entry_points={
        "console_scripts": [
            "machine-check-status=machine_check_status.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
