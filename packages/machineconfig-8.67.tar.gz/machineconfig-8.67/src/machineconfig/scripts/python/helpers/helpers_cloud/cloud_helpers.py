
# from machineconfig.utils.io import read_ini,
from machineconfig.utils.accessories import pprint
from machineconfig.utils.source_of_truth import DEFAULTS_PATH
from machineconfig.utils.ve import VE_YAML, CLOUD


from typing import Optional, cast
import os
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

console = Console()

def find_cloud_config(path: Path) -> CLOUD | None:
    display_header(f"Searching for .ve.yaml configuration file @ {path}")
    for _i in range(len(path.parts)):
        if path.joinpath(".ve.yaml").exists():
            import yaml
            res = cast(VE_YAML, yaml.load(path.joinpath(".ve.yaml").read_text(encoding="utf-8"), Loader=yaml.FullLoader))
            cloud_section = "cloud"
            display_success(f"Found cloud config at: {path.joinpath('.ve.yaml')}")
            if cloud_section in res:
                res = res["cloud"]
                pprint(dict(res), "Cloud Config")
                return res
            display_error(f".ve.yaml @ {path}/.ve.yaml has no [cloud] section.")
        path = path.parent
    display_error("No cloud configuration file found")
    return None


def my_abs(path: str) -> Path:
    obj = Path(path).expanduser().absolute()
    if not path.startswith(".") and obj.absolute().exists():
        return obj
    try_absing = Path.cwd().joinpath(path)
    if try_absing.exists():
        return try_absing
    display_warning(f"Path {path} resolved to {obj} could not be resolved to absolute path.")
    display_warning("Trying to resolve symlinks (this may result in unintended paths).")
    return obj.absolute()


def get_secure_share_cloud_config(interactive: bool, cloud: Optional[str]) -> CLOUD:
    console.print(Panel("🔐 Secure Share Cloud Configuration", expand=False))
    if cloud is None:
        if os.environ.get("CLOUD_CONFIG_NAME") is not None:
            default_cloud = os.environ.get("CLOUD_CONFIG_NAME")
            assert default_cloud is not None
            cloud = default_cloud
            console.print(f"☁️  Using cloud from environment: {cloud}")
        else:
            try:
                from machineconfig.utils.io import read_ini
                default_cloud__ = read_ini(DEFAULTS_PATH)["general"]["rclone_config_name"]
            except Exception:
                default_cloud__ = "No default cloud found."
            if default_cloud__ == "No default cloud found." or interactive:
                # assert default_cloud is not None
                cloud = input(f"☁️  Enter cloud name (default {default_cloud__}): ") or default_cloud__
            else:
                cloud = default_cloud__
                console.print(f"☁️  Using default cloud: {cloud}")

    default_password_path = Path.home().joinpath("dotfiles/creds/passwords/quick_password")
    if default_password_path.exists():
        pwd = default_password_path.read_text(encoding="utf-8").strip()
        default_message = "defaults to quick_password"
    else:
        pwd = ""
        default_message = "no default password found"
    pwd = input(f"🔑 Enter encryption password ({default_message}): ") or pwd
    res = CLOUD(cloud=cloud, pwd=pwd, encrypt=True, zip=True, overwrite=True, share=True, rel2home=True, root="myshare", os_specific=False, key=None)
    display_success("Using SecureShare cloud config")
    pprint(dict(res), "SecureShare Config")
    return res


def display_header(title: str):
    console.print(f"\n[bold]{title}[/bold]")

def display_subheader(title: str):
    console.print(f"[bold]{title}[/bold]")

def display_content(content: str):
    console.print(content)

def display_status(status: str):
    console.print(status)

def display_success(message: str):
    console.print(f"[green]✓ {message}[/green]")

def display_warning(message: str):
    console.print(f"[yellow]⚠ {message}[/yellow]")

def display_error(message: str):
    console.print(f"[red]✗ {message}[/red]")
