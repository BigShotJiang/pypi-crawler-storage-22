
import typer
from typing import Annotated, Literal
from machineconfig.utils.ssh_utils.abc import MACHINECONFIG_VERSION
from pathlib import Path

def copy_both_assets():
    import machineconfig.profile.create_helper as create_helper
    create_helper.copy_assets_to_machine(which="scripts")
    create_helper.copy_assets_to_machine(which="settings")


def init(which: Annotated[Literal["init", "ia", "live", "wrap"], typer.Argument(..., help="Comma-separated list of script names to run all initialization scripts.")] = "init",
         run: Annotated[bool, typer.Option("--run/--no-run", "-r/-nr", help="Run the script after displaying it.")] = False,
                        ) -> None:
    import platform
    script = ""
    if platform.system() == "Linux" or platform.system() == "Darwin":
        match which:
            case "init":
                import machineconfig.settings as module
                from pathlib import Path
                if platform.system() == "Darwin":
                    init_path = Path(module.__file__).parent.joinpath("shells", "zsh", "init.sh")
                else: init_path = Path(module.__file__).parent.joinpath("shells", "bash", "init.sh")
                script = init_path.read_text(encoding="utf-8")
            case "ia":
                from machineconfig.setup_linux import INTERACTIVE as script_path
                script = script_path.read_text(encoding="utf-8")
            case "live":
                from machineconfig.setup_linux import LIVE as script_path
                script = script_path.read_text(encoding="utf-8")
            case _:
                typer.echo("Unsupported shell script for Linux.")
                raise typer.Exit(code=1)

    elif platform.system() == "Windows":
        match which:
            case "init":
                import machineconfig.settings as module
                from pathlib import Path
                init_path = Path(module.__file__).parent.joinpath("shells", "powershell", "init.ps1")
                script = init_path.read_text(encoding="utf-8")
            case "ia":
                from machineconfig.setup_windows import INTERACTIVE as script_path
                script = script_path.read_text(encoding="utf-8")
            case "live":
                from machineconfig.setup_windows import LIVE as script_path
                script = script_path.read_text(encoding="utf-8")
            case _:
                typer.echo("Unsupported shell script for Windows.")
                raise typer.Exit(code=1)
                # return
    else:
        # raise NotImplementedError("Unsupported platform")
        typer.echo("Unsupported platform for init scripts.")
        raise typer.Exit(code=1)
    if run:
        from machineconfig.utils.code import exit_then_run_shell_script
        exit_then_run_shell_script(script, strict=True)
    else:
        print(script)


def update(copy_assets: Annotated[bool, typer.Option("--assets-copy/--no-assets-copy", "-a/-na", help="Copy (overwrite) assets to the machine after the update")] = True,
           link_public_configs: Annotated[bool, typer.Option("--link-public-configs/--no-link-public-configs", "-b/-nb", help="Link public configs after update (overwrites your configs!)")] = False,
           ):
    """🔄 UPDATE uv and machineconfig"""
    from pathlib import Path
    if Path.home().joinpath("code", "machineconfig").exists():
        shell_script = """
uv self update
cd ~/code/machineconfig
git pull
uv tool install --no-cache --upgrade --editable $HOME/code/machineconfig
    """
    else:
        shell_script = """
uv self update
uv tool install --no-cache --upgrade machineconfig
    """
    import platform
    if platform.system() == "Windows":
        from machineconfig.utils.code import exit_then_run_shell_script, get_uv_command_executing_python_script
        from machineconfig.utils.meta import lambda_to_python_script
        python_script = lambda_to_python_script(lambda: copy_both_assets(),
                                                in_global=True, import_module=False)
        uv_command, _py_file = get_uv_command_executing_python_script(python_script=python_script, uv_with=["machineconfig"], uv_project_dir=None)
        exit_then_run_shell_script(shell_script + "\n" + uv_command, strict=True)
    else:
        from machineconfig.utils.code import run_shell_script
        run_shell_script(shell_script, display_script=True, clean_env=False)
        if copy_assets:
            copy_both_assets()
        if link_public_configs:
            import machineconfig.profile.create_links_export as create_links_export
            create_links_export.main_from_parser(sensitivity="public", method="copy", on_conflict="overwrite-default-path", which="all")


def install(copy_assets: Annotated[bool, typer.Option("--copy-assets/--no-assets-copy", "-a/-na", help="Copy (overwrite) assets to the machine after the update")] = True,
            dev: Annotated[bool, typer.Option("--dev", "-d", help="Install from local development code instead of PyPI")] = False,
    
            ):
    """📋 CLONE machienconfig locally and incorporate to shell profile for faster execution and nightly updates."""
    from machineconfig.utils.code import run_shell_script, get_uv_command, get_shell_script_running_lambda_function, exit_then_run_shell_script
    from pathlib import Path
    import platform
    mcfg_path = Path.home().joinpath("code/machineconfig")
    _ = run_shell_script
    if dev and not mcfg_path.exists():
        # clone: https://github.com/thisismygitrepo/machineconfig.git
        import git
        mcfg_path.parent.mkdir(parents=True, exist_ok=True)
        git.Repo.clone_from("https://github.com/thisismygitrepo/machineconfig.git", str(mcfg_path))
        # now we need to run `uv sync` to install dependencies

    uv_command = get_uv_command(platform=platform.system())
    if copy_assets:
        def func():
            from machineconfig.profile.create_shell_profile import create_default_shell_profile
            create_default_shell_profile()   # involves copying assets too
        uv_command2, _script_path = get_shell_script_running_lambda_function(lambda: func(),
                                                          uv_with=["machineconfig"], uv_project_dir=None)
    else:
        uv_command2 = ""
    if mcfg_path.exists():
        exit_then_run_shell_script(f"""
cd {str(mcfg_path)}
{uv_command} sync
{uv_command} tool install --upgrade --editable "{str(mcfg_path)}"
{uv_command2}
""")
    else:
        exit_then_run_shell_script(rf"""
{uv_command} tool install --upgrade "{MACHINECONFIG_VERSION}"
{uv_command2}
""")



def interactive():
    """🤖 INTERACTIVE configuration of machine."""
    from machineconfig.scripts.python.helpers.helpers_devops.interactive import main
    main()

def status():
    """📊 STATUS of machine, shell profile, apps, symlinks, dotfiles, etc."""
    import machineconfig.scripts.python.helpers.helpers_devops.devops_status as helper
    helper.main()


def navigate():
    """📚 NAVIGATE command structure with TUI"""
    import machineconfig.scripts.python as navigator
    from pathlib import Path
    path = Path(navigator.__file__).resolve().parent.joinpath("devops_navigator.py")
    from machineconfig.utils.code import exit_then_run_shell_script
    if Path.home().joinpath("code/machineconfig").exists(): executable = f"""--project "{str(Path.home().joinpath("code/machineconfig"))}" --with textual"""
    else: executable = f"""--with "{MACHINECONFIG_VERSION},textual" """
    exit_then_run_shell_script(f"""uv run {executable} {path}""")

def readme():
    from rich.console import Console
    from rich.markdown import Markdown
    import requests

    # URL of the raw README.md file
    url_readme = "https://raw.githubusercontent.com/thisismygitrepo/machineconfig/refs/heads/main/README.md"

    # Fetch the content
    response = requests.get(url_readme, timeout=10)
    response.raise_for_status()  # Raise an error for bad responses

    # Parse markdown
    md = Markdown(response.text)

    # Render in terminal
    console = Console()
    console.print(md)


def buid_docker(
    variant: Annotated[Literal["slim", "ai"], typer.Argument(..., help="Variant to build: 'slim' or 'ai'")] = "slim",
) -> None:
    """🧱 `buid_docker` — wrapper for `jobs/shell/docker_build_and_publish.sh`"""
    from pathlib import Path
    import machineconfig
    script_path = Path(machineconfig.__file__).resolve().parent.parent.parent.joinpath("jobs", "shell", "docker_build_and_publish.sh")
    if not script_path.exists():
        typer.echo(f"❌ Script not found: {str(script_path)}")
        raise typer.Exit(code=1)

    # shell_cmd = f'VARIANT="{variant}" && bash "{str(script_path)}"'\
    from machineconfig.utils.source_of_truth import REPO_ROOT
    shell_cmd = f"""
export VARIANT="{variant}"
cd "{str(REPO_ROOT)}"
bash "{str(script_path)}"
"""
    # Use exit_then_run_shell_script for interactive runs (keeps tty), otherwise run shell script non-interactively
    from machineconfig.utils.code import exit_then_run_shell_script
    exit_then_run_shell_script(shell_cmd, strict=True)




def get_app():
    cli_app = typer.Typer(help="🔄 [s] self operations subcommands", no_args_is_help=True, add_help_option=True, add_completion=False)
    cli_app.command(name= "update",      no_args_is_help=False, help="🔄 [u] UPDATE machineconfig")(update)
    cli_app.command(name= "u",           no_args_is_help=False, hidden=True)(update)
    cli_app.command(name= "interactive", no_args_is_help=False, help="🤖 [ia] INTERACTIVE configuration of machine.")(interactive)
    cli_app.command(name= "ia",           no_args_is_help=False, help="INTERACTIVE configuration of machine.", hidden=True)(interactive)
    cli_app.command(name= "init",         no_args_is_help=False, help="🦐 [t] Define and manage configurations")(init)
    cli_app.command(name= "t",            no_args_is_help=False, hidden=True)(init)
    cli_app.command(name= "status",      no_args_is_help=False, help="📊 [s] STATUS of machine, shell profile, apps, symlinks, dotfiles, etc.")(status)
    cli_app.command(name= "s",           no_args_is_help=False, help="STATUS of machine, shell profile, apps, symlinks, dotfiles, etc.", hidden=True)(status)
    cli_app.command(name= "install",     no_args_is_help=False, help="📋 [i] CLONE machienconfig locally and incorporate to shell profile for faster execution and nightly updates.")(install)
    cli_app.command(name= "i",           no_args_is_help=False, help="CLONE machienconfig locally and incorporate to shell profile for faster execution and nightly updates.", hidden=True)(install)
    cli_app.command(name= "navigate", no_args_is_help=False, help="📚 [n] NAVIGATE command structure with TUI")(navigate)
    cli_app.command(name= "n", no_args_is_help=False, help="NAVIGATE command structure with TUI", hidden=True)(navigate)


    if Path.home().joinpath("code", "machineconfig").exists():
        cli_app.command(name= "buid_docker", no_args_is_help=False, help="🧱 [d] Build docker images (wraps jobs/shell/docker_build_and_publish.sh)")(buid_docker)
        cli_app.command(name= "d", no_args_is_help=False, help="Build docker images (wraps jobs/shell/docker_build_and_publish.sh)", hidden=True)(buid_docker)

    cli_app.command(name= "readme", no_args_is_help=False, help="📚 [r] render readme markdown in terminal.")(readme)
    cli_app.command(name= "r", no_args_is_help=False, hidden=True)(readme)
    return cli_app
