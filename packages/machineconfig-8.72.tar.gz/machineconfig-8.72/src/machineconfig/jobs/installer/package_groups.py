
GUI = [
    "brave",
    "code",
    "zoomit",
    "wezterm",
    "mouse-without-borders",
]

# AI/LLM Tools - AI-powered coding and chat assistants
AGENTS = [
    "aider",
    "aichat",
    "copilot",
    "gemini",
    "crush",
    "opencode-ai",
    "chatgpt",
    "mods",
    "q",
    "qwen-code",
    "cursor-cli",
    "droid",
    "kilocode",
    "cline",
    "auggie",
    # "codex",
    # "gorilla",
    # "ollama",
]


# Terminal Emulators & Shells - Terminal applications, emulators, and shell environments
PACKAGES_TERMINAL_EMULATORS = [
    "alacritty",
    "wezterm",
    "warp",
    "vtm",
    "edex-ui",
    "extraterm",
    "nushell",
]

# Browsers - Web browsers and terminal browsers
PACKAGES_BROWSERS = [
    "brave",
    "bypass-paywalls-chrome",
    "browsh",
    "carbonyl",
]

# Code Editors & IDEs - Code editing tools
# NOTE: Entries must match the corresponding `appName` in installer_data.json for filtering to work.
PACKAGES_CODE_EDITORS = [
    "code",
    "hx",
    # "cursor",
    # "lvim",
]



# Database Tools - Database clients and visualizers
DB_TUIS = [
    "rainfrog",
    "lazysql",
    "dblab",
    "usql",
    "harlequin",
    "sqlit"
]
DB_CLI = [
    "duckdb",
    "postgresql-client",
    "sqlite3",
    "redis-cli",
]
DB_DESKTOP = [
    "dbgate",
    "dbeaver",
    "sqliteBrowser",
]
DB_WEB = [
    "pgadmin",
    "pgweb"
    # https://github.com/chartdb/chartdb
]
PACKAGES_DATABASE: list[str] = DB_TUIS + DB_CLI + DB_DESKTOP + DB_WEB


# Media & Entertainment - Music players and media tools
PACKAGES_MEDIA = [
    "ytui-music",
    "youtube-tui",
    "termusic",
    "kronos",
    "OBS Background removal",
]

# File Sharing & Cloud - File sharing, transfer, backup, sync, and QR tools
PACKAGES_FILE_SHARING = [
    "ngrok",
    "devtunnel",
    "cloudflared",
    "forward-cli",
    "ffsend",
    "portal",
    "qrcp",
    "termscp",
    "filebrowser",
    "qr",
    "qrscan",
    "sharewifi",
    "share-wifi",
    "easy-sharing",
    "ezshare",
    "restic",
    "syncthing",
    "cloudreve",
    "ots",
]


# Development Tools - Various development utilities
PACKAGES_DEV_UTILS = [
    "devcontainer",
    "rust-analyzer",
    "evcxr",
    "geckodriver",
    "git",
    "m365",
]

# Code Analysis, Git & Docs - Code analysis, statistics, documentation, and Git tools
PACKAGES_CODE_ANALYSIS = [
    "nano",
    "lazygit",
    "onefetch",
    "gitcs",
    "lazydocker",
    "hyperfine",
    "kondo",
    "tokei",
    "navi",
    "tealdeer",
    "gitui",
    "delta",
    "gh",
    "watchexec",
    "jq",
]

# Productivity & Utilities - Productivity tools, security, remote access, and terminal enhancements
PACKAGES_PRODUCTIVITY = [
    "espanso",
    "bitwarden",
    "openpomodoro-cli",
    "rustdesk",
    "mermaid-cli",
    "html2markdown",
    "pandoc",
    "patat",
    "marp",
    "presenterm",
    "glow",
    "gum",
]


TERMINAL_EYE_CANDY = [
    "lolcatjs",
    "figlet-cli",
    "boxes",
    "cowsay",
    # "transmission",
    # "bytehound",
    # "xcrawl3r",
    # "obsidian",
    # "istio",
    # "cointop",
# sudo nala install cowsay -y || true
# sudo nala install lolcat -y || true
# sudo nala install boxes -y || true
# sudo nala install figlet -y || true
# sudo nala install fortune -y || true
# sudo nala install toilet -y || true
]


# System & Network Monitoring - System resource monitors, process viewers, network analysis, and system info tools
PACKAGES_SYSTEM_MONITORS = [
    "btop",
    "btm",
    "ntop",
    "procs",
    "cpufetch",
    "fastfetch",
]




# Search & Archive Tools - File and content search utilities, archive management
PACKAGES_FILE = [

    "nerdfont",
    "fd",
    "fzf",
    "tv",
    "broot",
    "rg",
    "rga",
    "ugrep",
    "ouch",
    "pistol",
    "bat",
    "viu",
    # "xplr",
    # "joshuto",
    # "lf",
    # "nnn",
    "yazi",
    "tere",
    # "exa",
    "lsd",
    "zoxide",
    "diskonaut",
    "dua",
    "dust",
    "cpz",
    "rmz",
]

NETWORK = [
    "bandwhich",
    "ipinfo",
    "sniffnet",
    "topgrade",
    "speedtest",
    "rclone",

]

# Terminal & Shell Enhancements - Terminal multiplexers, shell history, and prompts
PACKAGES_TERMINAL_SHELL = [
    "zellij",
    "mprocs",
    "mcfly",
    "atuin",
    "starship",
    "gotty",
    "ttyd",
    "cb"
]



PACKAGE_GROUP2NAMES: dict[str, list[str]] = {
    "sysabc": ["sysabc"],

    "shell": PACKAGES_TERMINAL_SHELL,
    "search": PACKAGES_FILE,
    "sys-monitor": PACKAGES_SYSTEM_MONITORS,
    "code-analysis": PACKAGES_CODE_ANALYSIS,
    "termabc": [*PACKAGES_CODE_ANALYSIS, *PACKAGES_SYSTEM_MONITORS, *PACKAGES_TERMINAL_SHELL, *PACKAGES_FILE,],

    "dev": [*PACKAGES_TERMINAL_EMULATORS,
            *PACKAGES_BROWSERS, *PACKAGES_CODE_EDITORS, *PACKAGES_DATABASE,
            *PACKAGES_MEDIA, *PACKAGES_FILE_SHARING, *PACKAGES_DEV_UTILS,
            *PACKAGES_CODE_ANALYSIS, *PACKAGES_PRODUCTIVITY, *TERMINAL_EYE_CANDY,],
    "dev-utils": PACKAGES_DEV_UTILS,
    "eye": TERMINAL_EYE_CANDY,
    "agents": AGENTS,
    "terminal": PACKAGES_TERMINAL_EMULATORS,
    "browsers": PACKAGES_BROWSERS,
    "editors": PACKAGES_CODE_EDITORS,

    "db-all": PACKAGES_DATABASE,
    "db-cli": DB_CLI,
    "db-desktop": DB_DESKTOP,
    "db-web": DB_WEB,
    "db-tui": DB_TUIS,

    "media": PACKAGES_MEDIA,
    "gui": GUI,
    "nw": NETWORK,
    "file-sharing": PACKAGES_FILE_SHARING,
    "productivity": PACKAGES_PRODUCTIVITY,
}
