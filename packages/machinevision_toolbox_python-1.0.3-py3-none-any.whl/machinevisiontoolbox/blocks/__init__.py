try:
    from .camera import *
except ImportError:
    pass

url = "https://petercorke.github.io/machinevision-toolbox-python/" + __package__
