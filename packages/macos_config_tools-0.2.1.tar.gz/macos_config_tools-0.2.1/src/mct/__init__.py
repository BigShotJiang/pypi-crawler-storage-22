"""macOS Configuration Tools - A CLI for managing macOS settings declaratively."""

__version__ = "0.2.1"
