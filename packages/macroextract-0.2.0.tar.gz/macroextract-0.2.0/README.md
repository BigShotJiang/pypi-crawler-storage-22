# macroextract

Extract and flag causal relation sentences from macroeconomic news articles.

## Installation

```bash
pip install macroextract
python -m spacy download en_core_web_md
```

## Quick Start

```python
import macroextract

article = """
Inflation rose to 3.5% in December, driven by higher energy costs.
The Federal Reserve maintained interest rates at 5.25%.
Consumer spending increased amid holiday shopping.
"""

# Get all sentences with relation flags
results = macroextract.extract(article)

for r in results:
    marker = "✓" if r["relations"] else "✗"
    print(f"{marker} {r['sentence']}")
```

Output:
```
✓ Inflation rose to 3.5% in December, driven by higher energy costs.
✗ The Federal Reserve maintained interest rates at 5.25%.
✗ Consumer spending increased amid holiday shopping.
```

## API

### `extract(article_text)`

Returns all extracted sentences with relation flags.

```python
results = macroextract.extract(article_text)
# [{"sentence": "...", "relations": True}, {"sentence": "...", "relations": False}, ...]
```

### `extract_relations(article_text)`

Returns only sentences containing causal relations.

```python
relations = macroextract.extract_relations(article_text)
# [{"sentence": "...", "relations": True}, ...]
```

## CLI

```bash
# Run extraction on test articles
macro bench extract_all

# Show relation sentences only
macro bench extract_all -v

# Show all sentences with flags (✓/✗)
macro bench extract_all -vv

# Filter by pattern
macro bench extract_all "bbc*"

# Debug sentence structure
macro debug sentence "Inflation rose due to supply constraints."
```

## Causal Markers

The extractor identifies sentences containing:

- **Connectors**: because, due to, after, following, amid
- **Verbs**: cause, trigger, fuel, drive, support, spark, spur, dampen, contribute, push
- **Nouns**: contributor, driver, factor, catalyst, impact

## How It Works

1. **Sentence Extraction**: Identifies economically relevant sentences
2. **Relation Flagging**: Marks sentences containing causal language
3. **Output**: Returns all sentences with boolean `relations` flag

## License

MIT
