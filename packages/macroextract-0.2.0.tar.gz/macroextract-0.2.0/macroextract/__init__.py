"""Extract causal relation sentences from macroeconomic news articles."""

from typing import List, Dict

from macroextract.extract.extract_sentences import SentenceExtractor
from macroextract.extract.extract_relations import RelationExtractor

# Lazy-loaded extractors
_sent_extractor = None
_rel_extractor = None


def _get_extractors():
    global _sent_extractor, _rel_extractor
    if _sent_extractor is None:
        _sent_extractor = SentenceExtractor()
        _rel_extractor = RelationExtractor()
    return _sent_extractor, _rel_extractor


def extract(article_text: str) -> List[Dict[str, any]]:
    """Extract all sentences with relation flags.

    Args:
        article_text: The article text to extract from.

    Returns:
        List of dicts with keys: sentence (str), relations (bool)
    """
    sent_ext, rel_ext = _get_extractors()

    sentences = sent_ext.extract(article_text)
    relations = rel_ext.extract(sentences)

    # Create set of relation sentence texts for fast lookup
    relation_texts = {text for text, _, _ in relations}

    return [
        {
            "sentence": text,
            "relations": text in relation_texts
        }
        for text, _, _ in sentences
    ]


def extract_relations(article_text: str) -> List[Dict[str, any]]:
    """Extract only sentences with causal relations.

    Args:
        article_text: The article text to extract from.

    Returns:
        List of dicts with keys: sentence (str), relations (bool)
        Note: relations will always be True in this function
    """
    sent_ext, rel_ext = _get_extractors()

    sentences = sent_ext.extract(article_text)
    relations = rel_ext.extract(sentences)

    return [
        {
            "sentence": text,
            "relations": True
        }
        for text, _, _ in relations
    ]
