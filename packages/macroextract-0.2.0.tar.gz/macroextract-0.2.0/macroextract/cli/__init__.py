"""CLI for macroextract."""

import click
import spacy
from fnmatch import fnmatch
from pathlib import Path

from macroextract.settings import SPACY_MODEL
from macroextract.extract.extract_sentences import SentenceExtractor
from macroextract.extract.extract_relations import RelationExtractor

# Default articles directory
ARTICLES_DIR = Path(__file__).parent.parent / "test_articles"

# Shared spacy model
_nlp = None


def get_nlp():
    global _nlp
    if _nlp is None:
        _nlp = spacy.load(SPACY_MODEL)
    return _nlp


def print_token_table(doc):
    """Print token analysis table."""
    click.echo(f"{'TEXT':<15} {'LEMMA':<12} {'POS':<6} {'DEP':<10} {'HEAD'}")
    click.echo("-" * 60)
    for token in doc:
        click.echo(f"{token.text:<15} {token.lemma_:<12} {token.pos_:<6} {token.dep_:<10} {token.head.text}")


@click.group()
def cli():
    """Macroextract CLI."""
    pass


@cli.group()
def debug():
    """Debug and analyze sentence structure."""
    pass


@debug.command("file")
@click.argument("pattern")
def debug_file(pattern: str):
    """Debug sentences from files matching PATTERN."""
    nlp = get_nlp()
    all_files = list(ARTICLES_DIR.glob("*.txt"))
    files = [f for f in all_files if fnmatch(f.name, pattern)]

    if not files:
        click.echo("No matching files found.")
        return

    for file in sorted(files):
        click.echo(f"\n=== {file.name} ===\n")
        text = file.read_text()
        doc = nlp(text)

        for sent in doc.sents:
            click.echo(f"\n> {sent.text.strip()}\n")
            print_token_table(sent.as_doc())


@debug.command("sentence")
@click.argument("text")
def debug_sentence(text: str):
    """Debug a single sentence."""
    nlp = get_nlp()
    doc = nlp(text)

    click.echo(f"\n> {text}\n")
    print_token_table(doc)


@cli.group()
def bench():
    """Benchmarking commands."""
    pass


@bench.command("extract_sentence")
@click.option("-v", "--verbose", is_flag=True, help="Show extracted sentences")
@click.argument("pattern", required=False)
def extract_sentence(verbose: bool, pattern: str = None):
    """Run sentence extraction on test articles.

    PATTERN: Optional filename wildcard (e.g., 'bbc*')
    """
    extractor = SentenceExtractor()

    # Get all .txt files
    all_files = list(ARTICLES_DIR.glob("*.txt"))

    # Filter by pattern if provided
    if pattern:
        files = [f for f in all_files if fnmatch(f.name, pattern)]
    else:
        files = all_files

    if not files:
        click.echo("No matching files found.")
        return

    total_sentences = 0

    for file in sorted(files):
        text = file.read_text()
        sentences = extractor.extract(text)
        count = len(sentences)
        total_sentences += count
        click.echo(f"{file.name}: {count} sentences")

        if verbose:
            for text, start, end in sentences:
                click.echo(f"  - {text}")

    click.echo(f"\n--- Summary ---")
    click.echo(f"Files: {len(files)}")
    click.echo(f"Total extractions: {total_sentences}")


@bench.command("extract_relations")
@click.option("-v", "--verbose", count=True, help="Show extracted (-v) or all with filtering (-vv)")
@click.argument("pattern", required=False)
def extract_relations(verbose: int, pattern: str = None):
    """Run relation extraction on test articles.

    Chains: extract_sentences -> extract_relations

    PATTERN: Optional filename wildcard (e.g., 'bbc*')
    """
    sent_extractor = SentenceExtractor()
    rel_extractor = RelationExtractor()

    all_files = list(ARTICLES_DIR.glob("*.txt"))

    if pattern:
        files = [f for f in all_files if fnmatch(f.name, pattern)]
    else:
        files = all_files

    if not files:
        click.echo("No matching files found.")
        return

    total_sentences = 0
    total_relations = 0

    for file in sorted(files):
        text = file.read_text()
        sentences = sent_extractor.extract(text)
        relations = rel_extractor.extract(sentences)
        total_sentences += len(sentences)
        total_relations += len(relations)
        click.echo(f"{file.name}: {len(sentences)} sentences -> {len(relations)} relations")

        if verbose >= 2:
            relation_texts = {r[0] for r in relations}
            for text, start, end in sentences:
                marker = "+" if text in relation_texts else "-"
                click.echo(f"  {marker} {text}")
        elif verbose == 1:
            for text, start, end in relations:
                click.echo(f"  - {text}")

    click.echo(f"\n--- Summary ---")
    click.echo(f"Files: {len(files)}")
    click.echo(f"Sentences: {total_sentences}")
    click.echo(f"Relations: {total_relations}")


@bench.command("extract_all")
@click.option("-v", "--verbose", count=True, help="Show results (-v) or with filtering markers (-vv)")
@click.argument("pattern", required=False)
def extract_all(verbose: int, pattern: str = None):
    """Run full extraction pipeline on test articles.

    Pipeline: sentences -> flag relations
    Output: sentence + relations (bool)

    PATTERN: Optional filename wildcard (e.g., 'bbc*')
    """
    sent_extractor = SentenceExtractor()
    rel_extractor = RelationExtractor()

    all_files = list(ARTICLES_DIR.glob("*.txt"))

    if pattern:
        files = [f for f in all_files if fnmatch(f.name, pattern)]
    else:
        files = all_files

    if not files:
        click.echo("No matching files found.")
        return

    totals = {"sentences": 0, "relations": 0}

    for file in sorted(files):
        text = file.read_text()
        sentences = sent_extractor.extract(text)
        relations = rel_extractor.extract(sentences)

        # Create relation lookup
        relation_texts = {r[0] for r in relations}

        totals["sentences"] += len(sentences)
        totals["relations"] += len(relations)

        click.echo(f"\n{'='*60}")
        click.echo(f"FILE: {file.name}")
        click.echo(f"{'='*60}")
        click.echo(f"  sentences: {len(sentences)} -> relations: {len(relations)}")

        if verbose >= 1:
            if verbose >= 2:
                click.echo(f"\n  [ALL SENTENCES]")
                for text_s, start, end in sentences:
                    is_rel = text_s in relation_texts
                    marker = "✓" if is_rel else "✗"
                    click.echo(f"    {marker} {text_s}")
            else:
                click.echo(f"\n  [RELATION SENTENCES]")
                for text_r, start, end in relations:
                    click.echo(f"    ✓ {text_r}")

    click.echo(f"\n{'='*60}")
    click.echo(f"SUMMARY")
    click.echo(f"{'='*60}")
    click.echo(f"Files: {len(files)}")
    click.echo(f"Sentences: {totals['sentences']}")
    click.echo(f"Relations: {totals['relations']} ({totals['sentences'] - totals['relations']} non-relations)")


def main():
    cli()


if __name__ == "__main__":
    main()
