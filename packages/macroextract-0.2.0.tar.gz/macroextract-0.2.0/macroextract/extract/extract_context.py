"""Extract time and place context for causal sentences."""

import re
import spacy
from dataclasses import dataclass
from typing import List, Optional, Tuple

from macroextract.settings import SPACY_MODEL

# Skip vague date patterns
VAGUE_DATE_PATTERNS = [
    r"^the\s",           # "the year", "the 12 months to..."
    r"^this\s",          # "this year"
    r"^a\s",             # "a year"
]
VAGUE_DATE_WORDS = {
    "annual", "annually", "quarterly", "monthly", "yearly",
    "month", "week", "day", "year",  # single time units are too vague
}


@dataclass
class CausalSentence:
    """A sentence expressing a causal relation."""
    sentence: str
    time: str = ""
    place: str = ""


class ContextExtractor:
    """Extract time and place context for sentences using NER."""

    def __init__(self, lookback: int = 1):
        """Initialize with lookback distance for context search.

        Args:
            lookback: Max sentences to look back for time/place context.
        """
        self.nlp = spacy.load(SPACY_MODEL)
        self.lookback = lookback

    def _is_valid_date(self, text: str) -> bool:
        """Check if DATE entity is specific enough to be useful."""
        lower = text.lower().strip()
        # Skip vague single words
        if lower in VAGUE_DATE_WORDS:
            return False
        # Skip vague patterns
        for pattern in VAGUE_DATE_PATTERNS:
            if re.match(pattern, lower):
                return False
        return True

    def _is_valid_gpe(self, ent, doc) -> bool:
        """Check if GPE entity is a valid location (not part of event phrase)."""
        start_idx = ent.start

        # Skip GPE preceded by "invasion of", "war in", etc. - it's an event reference
        if start_idx >= 2:
            prev_two = doc[start_idx - 2 : start_idx].text.lower()
            if prev_two in ("invasion of", "war in", "conflict in", "crisis in"):
                return False

        # Skip if GPE is followed by "'s" (possessive) - it's describing an event
        end_idx = ent.end
        if end_idx < len(doc):
            next_token = doc[end_idx]
            if next_token.text == "'s":
                return False

        return True

    def _extract_entities(self, text: str) -> Tuple[Optional[str], Optional[str]]:
        """Extract DATE and GPE entities from text.

        Returns (time, place) tuple.
        """
        doc = self.nlp(text)
        time = None
        place = None

        for ent in doc.ents:
            if ent.label_ == "DATE" and not time and self._is_valid_date(ent.text):
                time = ent.text
            elif ent.label_ == "GPE" and not place and self._is_valid_gpe(ent, doc):
                place = ent.text

        return time, place

    def _get_article_sentences(self, article_text: str) -> List[Tuple[str, int, int]]:
        """Get all sentences from article with their positions."""
        doc = self.nlp(article_text)
        return [(sent.text.strip(), sent.start_char, sent.end_char) for sent in doc.sents]

    def _find_sentence_index(
        self, sentence_text: str, sentences: List[Tuple[str, int, int]]
    ) -> int:
        """Find index of sentence in article sentences."""
        for i, (text, _, _) in enumerate(sentences):
            if sentence_text.strip() in text or text in sentence_text.strip():
                return i
        return -1

    def extract_one(
        self, sentence_text: str, article_sentences: List[Tuple[str, int, int]]
    ) -> CausalSentence:
        """Extract context for a single sentence.

        Args:
            sentence_text: The causal sentence text
            article_sentences: All sentences from article for lookback context

        Returns:
            CausalSentence with time/place filled in.
        """
        result = CausalSentence(sentence=sentence_text)

        # Try to extract from the sentence itself first
        time, place = self._extract_entities(sentence_text)
        result.time = time or ""
        result.place = place or ""

        # If missing context, look back in article
        if (not result.time or not result.place) and article_sentences:
            sent_idx = self._find_sentence_index(sentence_text, article_sentences)
            if sent_idx > 0:
                # Look back up to self.lookback sentences
                start_idx = max(0, sent_idx - self.lookback)
                for i in range(sent_idx - 1, start_idx - 1, -1):
                    prev_text = article_sentences[i][0]
                    prev_time, prev_place = self._extract_entities(prev_text)
                    if not result.time and prev_time:
                        result.time = prev_time
                    if not result.place and prev_place:
                        result.place = prev_place
                    if result.time and result.place:
                        break

        return result

    def extract(
        self, article_text: str, sentences: List[Tuple[str, int, int]]
    ) -> List[CausalSentence]:
        """Extract context for multiple sentences.

        Args:
            article_text: Full article text for lookback context
            sentences: List of (sentence_text, start, end) tuples

        Returns:
            List of CausalSentence with time/place filled in.
        """
        article_sentences = self._get_article_sentences(article_text)
        results = []

        for text, start, end in sentences:
            result = self.extract_one(text, article_sentences)
            results.append(result)

        return results
