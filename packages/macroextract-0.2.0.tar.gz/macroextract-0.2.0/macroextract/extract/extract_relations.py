"""Filter sentences to only those expressing causal relations between economic events."""

import spacy
from typing import List, Set, Tuple

from macroextract.settings import SPACY_MODEL

# Causal connectors that signal X affects Y relationships
CAUSAL_MARKERS = {
    "because",   # "X increased because Y"
    "cause",     # "X caused Y" / "causing Y"
    "due",       # "due to"
    "after",     # "X rose after Y"
    "follow",   # "X increased following Y"
    "amid",      # "X fell amid Y"
    "spark",     # "X sparked Y"
    "spur",      # "X spurred Y"
    "trigger",   # "X triggered Y"
    "fuel",      # "X fuelled Y"
    "drive",     # "driven by Y" only
    "dampen",    # "X dampens Y"
    "contribute",  # "X contributed to Y"
    "support",   # "supported by Y" only
    "push",      # "X pushing Y"
}

# Markers that require "by" to be causal (passive voice only)
REQUIRES_BY = {"support", "drive"}

# Noun forms of causal markers (X was a contributor to Y)
CAUSAL_NOUNS = {"contributor", "driver", "factor", "catalyst"}

# Reversed noun markers (X was an impact of Y → Y caused X)
REVERSED_NOUNS = {"impact"}


class RelationExtractor:
    """Filter sentences to only those with causal relations."""

    def __init__(self):
        self.nlp = spacy.load(SPACY_MODEL)

    def has_causal_relation(self, sentence: str) -> bool:
        """Check if sentence contains a causal relation pattern."""
        doc = self.nlp(sentence)

        for token in doc:
            lemma = token.lemma_.lower()
            # Check verb markers
            if lemma in CAUSAL_MARKERS:
                # Some markers require "by" to be causal
                if lemma in REQUIRES_BY:
                    next_token = doc[token.i + 1] if token.i + 1 < len(doc) else None
                    if next_token and next_token.text.lower() == "by":
                        return True
                else:
                    return True
            # Check noun markers (X was a contributor to Y)
            if token.text.lower() in CAUSAL_NOUNS and token.pos_ == "NOUN":
                return True
            # Check reversed noun markers (X was a consequence of Y)
            if token.text.lower() in REVERSED_NOUNS and token.pos_ == "NOUN":
                return True

        return False

    def extract(self, sentences: List[Tuple[str, int, int]]) -> List[Tuple[str, int, int]]:
        """Filter sentences to only those with causal relations.

        Takes and returns list of (sentence_text, start_char, end_char) tuples.
        """
        return [s for s in sentences if self.has_causal_relation(s[0])]
