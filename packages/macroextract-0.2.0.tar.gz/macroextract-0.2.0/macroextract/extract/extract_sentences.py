"""Extract sentences containing economic event markers using spaCy."""

import spacy
from typing import List, Set, Tuple

from macroextract.settings import SPACY_MODEL
from macroextract.extract.extract_relations import CAUSAL_NOUNS, REVERSED_NOUNS

# Core event markers (verb lemmas) - extend as needed
EVENT_MARKERS = {
    # Causal
    "cause", "lead", "drive", "fuel", "stifle", "contribute", "spark", "spur", "dampen",
    # Change
    "rise", "fall", "increase", "decrease", "decline", "drop", "grow", "slow", "ease", "jump", "climb", "contract", "retreat", "lose", "slide", "push", "support",
    # Impact
    "affect", "impact", "trigger",
    # Policy
    "cut", "raise", "lower", "hike", "reduce", "lift",
}


class SentenceExtractor:
    """Extract sentences containing event marker verbs."""

    def __init__(self, markers: Set[str] = None):
        self.nlp = spacy.load(SPACY_MODEL)
        self.markers = markers or EVENT_MARKERS

    def extract(self, text: str) -> List[Tuple[str, int, int]]:
        """Extract sentences containing event marker verbs.

        Returns list of (sentence_text, start_char, end_char) tuples.
        """
        doc = self.nlp(text)
        sentences = []
        seen = set()

        for token in doc:
            sent = token.sent
            sent_text = sent.text.strip()

            if sent_text in seen:
                continue

            # Check verb markers
            if token.pos_ == "VERB" and token.lemma_ in self.markers:
                seen.add(sent_text)
                sentences.append((sent_text, sent.start_char, sent.end_char))
            # Check causal noun markers
            elif token.pos_ == "NOUN" and token.text.lower() in (CAUSAL_NOUNS | REVERSED_NOUNS):
                seen.add(sent_text)
                sentences.append((sent_text, sent.start_char, sent.end_char))

        return sentences
