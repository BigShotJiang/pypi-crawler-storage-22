"""Settings for macroextract."""

SPACY_MODEL = "en_core_web_md"
