import random

jokes = [
    "why can't yu fart in an apple store? coz it has no windows",
    "why UK and New York can't play chess? coz one loose tower and other loose their queen",
    "aaj mere friend ki engagement thi itna zor se earthquake aya ki uski MAGNITUDE gayi",
    "being kissed while you're asleep is the purest form of love, unless you're in prison",
    "if you lose a leg, your bmi goes down but if you lose another leg your bmi goes up",
    "What's the difference between a priest and acne? At least acne waits until you're 14 before it comes on your face",
    "What the difference between a fridge and a woman?A fridge doesn't queef when you pull the meat out.",
    "A woman goes out clubbing and meets a handsome black dude. They go back to her place after a night of partying and drinking.As they're getting undressed, the woman slides up to the black dude and says, Go on stud, show me what makes you black guys famous. So he stabs her and runs off with her purse.",
    "As an airplane is about to crash, a female passenger jumps up frantically and announces, If I'm going to die, I want to die feeling like a woman.She removes all her clothing and asks, Is there someone on this plane who is man enough to make me feel like a woman?A man stands up, removes his shirt, and says, Here, iron this!,"
    "What did the leper say to the hooker? keep the tip :) ",
    "What's 12 inches long and makes women scream all night long? .... Crib death.",
    "What do you do after you rape Helen Keller?You break her fingers so she can't tell anyone.",
    "Why did Helen Keller masturbate with one hand? So she could moan with the other.",
    "A man walks into a bar with a huge grin on his face. The bartender asks why he's so happy. The man says, I just met a beautiful girl down by the train tracks. We just had sex for hours! We did everything I've ever wanted to do in the bedroom but my only regret is that I didn't get a blowjob. The bartender congratulates the man but has to ask, if you managed to do everything you wanted then why didn't you get a blowjob? The man replies, I couldn't find the head.",
    "A priest is teaching a nun to swim. So the nun says:Father, will I really sink if you take your finger out?",
    
    
    ]

def get_jokes():
    return random.choice(jokes)
