# Params
from mageflow.signature.consts import MAGEFLOW_TASK_INITIALS

CHAIN_TASK_ID_NAME = "chain_task_id"

# Task names
ON_CHAIN_ERROR = f"{MAGEFLOW_TASK_INITIALS}on_chain_error"
ON_CHAIN_END = f"{MAGEFLOW_TASK_INITIALS}on_chain_done"
