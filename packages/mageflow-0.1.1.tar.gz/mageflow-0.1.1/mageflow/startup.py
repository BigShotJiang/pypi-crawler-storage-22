import rapyer
from hatchet_sdk import Hatchet
from hatchet_sdk.runnables.workflow import Standalone
from pydantic import BaseModel
from redis.asyncio.client import Redis

from mageflow.task.model import HatchetTaskModel

REGISTERED_TASKS: list[tuple[Standalone, str]] = []


class ConfigModel(BaseModel):
    class Config:
        arbitrary_types_allowed = True


class MageFlowConfigModel(ConfigModel):
    hatchet_client: Hatchet | None = None
    redis_client: Redis | None = None


mageflow_config = MageFlowConfigModel()


async def init_mageflow():
    await rapyer.init_rapyer(mageflow_config.redis_client, prefer_normal_json_dump=True)
    await register_workflows()


async def teardown_mageflow():
    await rapyer.teardown_rapyer()


async def register_workflows():
    for reg_task in REGISTERED_TASKS:
        workflow, mageflow_task_name = reg_task
        hatchet_task = HatchetTaskModel(
            mageflow_task_name=mageflow_task_name,
            task_name=workflow.name,
            input_validator=workflow.input_validator,
            retries=workflow.tasks[0].retries,
        )
        await hatchet_task.asave()


async def lifespan_initialize():
    await init_mageflow()
    # yield makes the function usable as a Hatchet lifespan context manager (can also be used for FastAPI):
    # - code before yield runs at startup (init config, register workers, etc.)
    # - code after yield would run at shutdown
    yield
    await teardown_mageflow()
