
def get_welcome_message(name: str) -> str:
    """A simple function from our custom package."""
    return f"Hello {name}! This message is coming from the custom 'magenta_utils' package."

def calculate_discount(price: float, discount_percent: float) -> float:
    """Calculate price after discount."""
    return price * (1 - (discount_percent / 100))
