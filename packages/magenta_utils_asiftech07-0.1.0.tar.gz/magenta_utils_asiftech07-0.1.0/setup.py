
from setuptools import setup, find_packages

setup(
    name="magenta-utils-asiftech07",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[], 
    author="asiftech07",
    description="A simple utility package for our FastAPI project",
)
