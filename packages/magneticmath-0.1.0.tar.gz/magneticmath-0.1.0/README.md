# SmartMath

A simple Python math utility library.

## Features
- Arithmetic operations

## Usage

```python
from magneticmath import Arithmetic
print(Arithmetic.add(1,2,3))
