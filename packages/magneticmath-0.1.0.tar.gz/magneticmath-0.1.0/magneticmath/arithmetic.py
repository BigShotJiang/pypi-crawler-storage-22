class Arithmetic:
    def __init__(self):
        pass
    def add(self,*args):
        try:
            add=0
            for i in args:
                    add+=i
            return add  
        except TypeError:
            return "Invalid input: All arguments must be numbers."
    def sub(self,*args):
        try:
            sub=args[0]
            for i in args[1:]:
                sub-=i
            return sub
        except TypeError:
            return "Invalid input: All arguments must be numbers."

    def mul(self,*args):
        try:
            mul=1
            for i in args:
                mul*=i
            return mul
        except TypeError:
            return "Invalid input: All arguments must be numbers."
       
    def div(self,*args):
        try:
            div=args[0]
            for i in args[1:]:
                if i==0:
                    return "Error: Division by zero is not allowed."
                div/=i
            return div
        except TypeError:
            return "Invalid input: All arguments must be numbers."
    
