# Implementation Plan Revision Summary

**Date**: 2026-01-23
**Version**: 1.0 → 2.0 (Post-Trifecta Audit)
**Timeline**: 5 weeks → 12 weeks

---

## ✅ Your Decisions Incorporated

### 1. Phase 0: Security Hardening First
- **Decision**: Start with security fixes before any feature work
- **Implementation**: Added Phase 0 (Week 1) - "Security Hardening"
- **Focus**: Fix all 6 critical security issues before proceeding

### 2. Prefect Over Airflow
- **Decision**: Use Prefect instead of Airflow
- **Implementation**:
  - Removed Airflow adapter entirely
  - Added Prefect adapter (Week 7)
  - Created migration guide: Airflow → Prefect
  - Updated all references throughout plan

### 3. 12-Week Timeline
- **Decision**: Accept realistic 12-week timeline
- **Implementation**:
  - Extended from 5 to 12 weeks
  - Added buffer for unexpected issues
  - Realistic estimates for each phase

### 4. Tests After Implementation
- **Decision**: Write tests after implementation (not TDD)
- **Reasoning**: Allow design flexibility midstream
- **Implementation**:
  - Phase 5 dedicated to testing (Week 11)
  - Note added: "Tests written after implementation to allow design flexibility"
  - 90%+ coverage target maintained

---

## 📊 What Changed

### Structural Changes

| Aspect | Old Plan | New Plan |
|--------|----------|----------|
| **Timeline** | 5 weeks | 12 weeks |
| **Phases** | 5 phases | 6 phases (added Phase 0) |
| **Security** | Integrated | Phase 0 (first) |
| **Adapters** | Airflow + CrewAI + LangGraph + Agno | Prefect + LangGraph + Agno (CrewAI deprecated) |
| **Testing** | TDD implied | Tests after implementation |
| **MCP Server** | Assumed functional | Complete rewrite specified |

### New Phase 0: Security Hardening (Week 1)

**Critical Security Issues to Fix**:
- Remove API keys from config.yaml
- Implement JWT authentication for CLI
- Add path traversal validation
- Strengthen auth secret validation (32+ chars, entropy check)
- Add config.yaml to .gitignore
- Create example configuration templates
- Add security scan to CI/CD (bandit, safety)

### Architecture Fixes (Phase 1)

**Async/Sync Mismatch**:
- Old: `def execute()` (sync)
- New: `async def execute()` (async)
- Impact: All adapters must be rewritten

**Concurrency Control**:
- Added: `max_concurrent_workflows` config (default: 10)
- Added: `asyncio.Semaphore` for limiting
- Added: Work queue for pending workflows

**Repository Processing**:
- Old: Sequential (100 repos = 8+ minutes)
- New: Parallel (100 repos = ~50 seconds)

### MCP Server Rewrite (Phase 2)

**Current Status**: NON-FUNCTIONAL

**Complete Rewrite**:
- Old: FastAPI (REST endpoints)
- New: FastMCP (MCP protocol)
- Tools: 6 core tools with full specifications
- Security: Authentication + TLS + rate limiting

### Adapter Implementation (Phase 3)

**Old Plan**: "Implement CrewAI adapter with full functionality" (1 week for all adapters)

**New Plan**:
- Week 5-6: LangGraph (2 weeks)
- Week 7: Prefect (1 week) - **replaces Airflow**
- Week 8: Agno (1 week)
- Total: 4 weeks (realistic)

### Production Features (Phase 4)

**Added** (were missing from old plan):
- Error recovery patterns (retry, circuit breaker, DLQ)
- Observability (OpenTelemetry, metrics, tracing)
- Crackerjack QC integration
- Session-Buddy checkpoint integration

### Testing & Documentation (Phase 5)

**Old Plan**: "Add comprehensive tests" (1 week for tests + docs)

**New Plan**:
- Week 11a: Testing (unit, integration, E2E, property)
- Week 11b: Documentation (guides, API reference, examples)
- Target: 90%+ coverage

### Production Readiness (Phase 6)

**Added** (was missing):
- Security validation (bandit, safety)
- Performance benchmarking (100+ repos, 100+ workflows)
- Quality validation (tests, type checking, linting)
- Dependency management (pinning, licensing, SBOM)
- Production checklist

---

## 🎯 Key Improvements

### 1. Security First
- **Before**: Security scattered across phases
- **After**: All critical security issues fixed in Week 1
- **Benefit**: Secure foundation before any feature work

### 2. Modern Stack
- **Before**: Airflow (legacy, Java-based)
- **After**: Prefect (modern, Python-native)
- **Benefit**: Better integration, more maintainable

### 3. Realistic Timeline
- **Before**: 5 weeks (aggressive, unrealistic)
- **After**: 12 weeks (achievable, battle-tested)
- **Benefit**: Less stress, higher quality

### 4. Design Flexibility
- **Before**: TDD implied (tests before code)
- **After**: Tests after implementation
- **Benefit**: Adapt to design discoveries midstream

### 5. Production Ready
- **Before**: Minimal production planning
- **After**: Comprehensive production readiness phase
- **Benefit**: Smooth deployment, fewer surprises

---

## 📋 Migration Path

### CrewAI → LangGraph
**Status**: CrewAI deprecated (per pyproject.toml)

**Concept Mapping**:
| CrewAI | LangGraph |
|--------|-----------|
| Agent | Node in StateGraph |
| Task | State transition |
| Crew | Compiled StateGraph |
| Process | StateGraph routing |

**Migration guide included in plan**

### Airflow → Prefect
**Status**: Airflow replaced with Prefect

**Concept Mapping**:
| Airflow | Prefect |
|---------|---------|
| DAG | Flow |
| Operator | Task |
| Task Instance | Task Run |
| XCom | Artifact |

**Migration guide included in plan**

---

## 🚀 Next Steps: Phase 0 Execution

### Immediate Actions (This Week)

**1. Security Hardening Checklist**:
```bash
# 1. Remove API keys from config
git rm config.yaml
echo "config.yaml" >> .gitignore

# 2. Create example templates
cp config.yaml config.yaml.example
# Edit config.yaml.example to replace secrets with ${VARIABLE}

# 3. Update .gitignore
# Ensure config.yaml, *.local.yaml, oneiric.yaml are listed

# 4. Create JWT auth module
# Create mahavishnu/core/auth.py

# 5. Add path validation
# Update mahavishnu/core/app.py

# 6. Strengthen auth secret validation
# Update mahavishnu/core/config.py

# 7. Add security scans to CI/CD
# Create .github/workflows/security.yml
```

**2. Development Environment Setup**:
```bash
# Create example configuration files
mkdir -p settings
cat > repos.yaml.example << 'EOF'
repos:
  - path: "/path/to/repo1"
    tags: ["backend", "python"]
    description: "Example repository"
EOF

cat > settings/mahavishnu.yaml.example << 'EOF'
server_name: "Mahavishnu Orchestrator"
adapters:
  langgraph: true
  prefect: true
  agno: false
EOF

cat > settings/local.yaml.example << 'EOF'
# Local development overrides
logging:
  level: DEBUG
EOF
```

**3. Crackerjack Configuration**:
```bash
# Configure Crackerjack for quality control
mkdir -p settings
cat > settings/crackerjack.yaml << 'EOF'
crackerjack:
  enabled: true
  min_score: 80
  checks:
    ruff:
      enabled: true
      args: ["--fix", "--exit-non-zero-on-fix"]
    bandit:
      enabled: true
      args: ["-c", "pyproject.toml"]
    pytest:
      enabled: true
      min_coverage: 80
EOF
```
1. **No Security Planning**: Security was an afterthought
2. **Unrealistic Timeline**: 5 weeks for this scope was impossible
3. **Placeholder Code**: Adapters were stubs, not implementations
4. **MCP Server Broken**: Core feature completely non-functional
5. **Async/Sync Mismatch**: Fundamental architecture flaw

### What We Fixed

1. **Security First**: Phase 0 dedicated to security
2. **Realistic Timeline**: 12 weeks based on actual effort
3. **Implementation Details**: Full code examples for all adapters
4. **MCP Rewrite**: Complete FastMCP implementation specified
5. **Async Architecture**: All adapters async throughout

### Best Practices Applied

1. **Trifecta Audit**: Architecture + Security + Code perspectives
2. **Critical Issues First**: Fix blockers before features
3. **Modern Stack**: Prefect over Airflow
4. **Design Flexibility**: Tests after implementation
5. **Production Ready**: Comprehensive Phase 6 validation

---

## 📚 Related Documents

1. **IMPLEMENTATION_PLAN.md** (Revised - Version 2.0)
2. **IMPLEMENTATION_PLAN_TRIFECTA_AUDIT.md** (Complete audit report)
3. **SECURITY_CHECKLIST.md** (Security guidelines)

---

## ✅ Ready to Execute

**Status**: Plan approved and ready for implementation

**Next Action**: Begin Phase 0 - Security Hardening

**Estimated Completion**: 12 weeks from start date

**Target Release**: Mahavishnu v1.0 (production-ready)

---

**End of Revision Summary**

**3. Crackerjack Configuration**:
\`\`\`bash
# Configure Crackerjack for quality control
mkdir -p settings
cat > settings/crackerjack.yaml << 'EOF'
crackerjack:
  enabled: true
  min_score: 80
  checks:
    ruff:
      enabled: true
      args: ["--fix", "--exit-non-zero-on-fix"]
    bandit:
      enabled: true
      args: ["-c", "pyproject.toml"]
    pytest:
      enabled: true
      min_coverage: 80
