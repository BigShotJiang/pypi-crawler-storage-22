# Trifecta Critical Audit: IMPLEMENTATION_PLAN.md

**Comprehensive multi-agent review combining Architecture Council, Security Auditor, and Code Reviewer perspectives**

**Audit Date**: 2026-01-23
**Auditors**: Architecture Council + Security Auditor + Code Reviewer
**Overall Score**: 6.5/10 ⚠️ **NOT PRODUCTION READY**

______________________________________________________________________

## 🚨 Executive Summary

Three specialized agents conducted a comprehensive audit of the Mahavishnu implementation plan. While the **architectural foundation is solid**, the plan suffers from **critical security vulnerabilities**, **broken core components**, **unrealistic timelines**, and **missing production features**.

### Critical Findings Across All Three Audits

**🔴 CRITICAL (Must Fix Before Any Implementation)**

1. **API keys in configuration file** (Security) - credentials exposed in git
1. **Missing CLI authentication** (Security) - unprotected access to workflows
1. **Async/sync interface mismatch** (Architecture + Code) - fundamental breaking issue
1. **MCP server is non-functional** (Architecture + Code) - core feature completely broken
1. **Path traversal vulnerability** (Security) - can access arbitrary system files
1. **Adapter implementations are placeholders** (Architecture + Code) - no actual logic

**🟡 HIGH (Must Fix Before Production)**
7\. **No concurrency control** (Architecture) - 100 concurrent workflows will crash
8\. **Sequential repo processing** (Architecture) - unacceptable latency at scale
9\. **Missing error recovery** (Code) - no retry, circuit breakers, or dead letter queues
10\. **Missing observability** (Code) - no metrics, tracing, or structured logging
11\. **Insecure MCP configuration** (Security) - no TLS, auth, or rate limiting
12\. **Weak auth secret validation** (Security) - JWT secrets can be brute-forced

**Recommended Timeline**: **10-12 weeks** (not 5 weeks as planned)

______________________________________________________________________

## 🔴 CRITICAL ISSUES (Must Fix Immediately)

### 1. API Keys in Configuration File (Security)

**Severity**: 🔴 CRITICAL
**Found By**: Security Auditor
**Location**: `config.yaml` line 25

**Issue**:

```yaml
# ❌ NEVER COMMIT API KEYS TO GIT
api_key: "sk-ant-api03-..."  # Exposed in version control
```

**Attack Vector**:

- Git history contains plaintext API keys
- Anyone with repo access can steal credentials
- Keys cannot be rotated without breaking existing commits

**Remediation**:

```yaml
# ✅ Use environment variables
api_key: "${MAHAVISHNU_API_KEY}"  # Loaded from env, not git

# Set in shell:
export MAHAVISHNU_API_KEY="sk-ant-api03-..."
```

**Required Actions**:

1. Remove API keys from `config.yaml`
1. Rotate all exposed keys immediately
1. Add `config.yaml` to `.gitignore`
1. Create `config.yaml.example` template
1. Document environment variable setup in README

______________________________________________________________________

### 2. Missing CLI Authentication (Security)

**Severity**: 🔴 CRITICAL
**Found By**: Security Auditor
**Location**: `cli.py` entire file

**Issue**:

```python
# ❌ ANYONE CAN TRIGGER WORKFLOWS
@app.command()
def sweep(tag: str, adapter: str):
    """Trigger workflow sweep - NO AUTH CHECK"""
    result = await maha_app.execute_workflow(task, adapter, repos)
```

**Attack Vector**:

- Unauthorized users can trigger workflows on arbitrary repos
- Can execute code on developer machines
- Can access sensitive repositories
- Can DOS the system with massive workflow sweeps

**Remediation**:

```python
# ✅ Add JWT authentication
from mahavishnu.core.auth import require_auth

@app.command()
@require_auth  # 🔒 Enforce JWT authentication
def sweep(tag: str, adapter: str):
    """Trigger workflow sweep - AUTHORIZED ONLY"""
    result = await maha_app.execute_workflow(task, adapter, repos)
```

**Required Actions**:

1. Implement JWT middleware for all CLI commands
1. Add `--token` parameter or `MAHAVISHNU_AUTH_TOKEN` env var
1. Document authentication setup
1. Add role-based access control (admin vs. user)
1. Add audit logging for all workflow triggers

______________________________________________________________________

### 3. Async/Sync Interface Mismatch (Architecture + Code)

**Severity**: 🔴 CRITICAL
**Found By**: Architecture Council + Code Reviewer
**Location**: `core/adapters/base.py` line 35

**Issue**:

```python
# ❌ Plan shows SYNC interface
class OrchestratorAdapter:
    def execute(self, task: dict, repos: list[str]) -> dict:
        """Synchronous execute - BLOCKS EVENT LOOP"""

# ✅ But implementation expects ASYNC
result = await adapter.execute(task, repos)  # <-- Doesn't work!
```

**Impact**:

- Adapter calls will block the event loop
- Cannot handle concurrent workflows
- Breaks async/await pattern throughout codebase
- Cannot integrate with async engines (LangGraph, Agno)

**Remediation**:

```python
# ✅ Fix base adapter interface
class OrchestratorAdapter:
    async def execute(self, task: dict, repos: list[str]) -> dict:
        """Async execute - NON-BLOCKING"""
        raise NotImplementedError

    async def get_health(self) -> dict:
        """Health check for monitoring"""
        return {"status": "healthy"}
```

**Required Actions**:

1. Change `def execute()` to `async def execute()` in base adapter
1. Update all adapter implementations to be async
1. Update all adapter call sites to use `await`
1. Update type hints to reflect async nature
1. Update ADR documentation to reflect async architecture

______________________________________________________________________

### 4. MCP Server is Non-Functional (Architecture + Code)

**Severity**: 🔴 CRITICAL
**Found By**: Architecture Council + Code Reviewer
**Location**: `mcp/server.py` entire file

**Issue**:

```python
# ❌ This is NOT an MCP server
@app.get("/list_repos")  # <-- REST endpoint, not MCP tool
async def list_repos():
    return {"repos": [...]}

# ✅ Should be using FastMCP
from fastmcp import FastMCP

mcp = FastMCP("Mahavishnu")

@mcp.tool()  # <-- Actual MCP tool
async def list_repos() -> dict:
    """List all repositories"""
    return {"repos": [...]}
```

**Problems**:

- Server implements REST API, not MCP protocol
- No tools are registered with FastMCP
- Cannot communicate with MCP clients (Claude Desktop, etc.)
- Core feature completely broken

**Remediation**:

```python
# ✅ Rewrite using FastMCP
from fastmcp import FastMCP
from mahavishnu.core.app import MahavishnuApp

mcp = FastMCP("Mahavishnu Orchestrator")
app = MahavishnuApp()

@mcp.tool()
async def list_repos(
    tag: str | None = None,
    limit: int = 100
) -> dict:
    """List all repositories.

    Args:
        tag: Optional tag to filter repos
        limit: Maximum repos to return

    Returns:
        Dictionary with repos list and metadata
    """
    repos = app.get_repos(tag=tag, limit=limit)
    return {"repos": repos, "count": len(repos)}

@mcp.tool()
async def trigger_workflow(
    adapter: str,
    task_type: str,
    tag: str | None = None,
    repos: list[str] | None = None,
    timeout: int | None = None
) -> dict:
    """Trigger workflow execution.

    Args:
        adapter: Adapter name (langgraph, prefect, agno)
        task_type: Type of workflow (code_sweep, quality_check)
        tag: Optional tag to filter repos
        repos: Optional explicit repo list (overrides tag)
        timeout: Optional timeout in seconds

    Returns:
        Workflow result with status and output
    """
    result = await app.execute_workflow(
        task={"task_type": task_type},
        adapter_name=adapter,
        repos=repos,
        timeout=timeout
    )
    return result
```

**Required Actions**:

1. Rewrite `mcp/server.py` to use FastMCP
1. Implement all MCP tools from specification (see `docs/MCP_TOOLS_SPECIFICATION.md`)
1. Add proper error handling for each tool
1. Add input validation using Pydantic models
1. Test with real MCP client (Claude Desktop)
1. Write MCP integration tests

**Estimated Effort**: 2 weeks

______________________________________________________________________

### 5. Path Traversal Vulnerability (Security)

**Severity**: 🔴 CRITICAL
**Found By**: Security Auditor
**Location**: `app.py` line 80-89

**Issue**:

```python
# ❌ NO VALIDATION - can access ANY directory
def get_repos(self, tag: str | None = None) -> list[dict]:
    repos_path = Path(self.config.repos_path).expanduser()

    # Can pass "../../../etc/passwd" to read arbitrary files!
    with open(repos_path) as f:
        repos = yaml.safe_load(f)
```

**Attack Vector**:

- Malicious config can point to sensitive system directories
- Can read `/etc/passwd`, SSH keys, etc.
- Can expose secrets from other projects

**Remediation**:

```python
# ✅ Validate path is within allowed bounds
def get_repos(self, tag: str | None = None) -> list[dict]:
    repos_path = Path(self.config.repos_path).expanduser().resolve()

    # Ensure path is within allowed prefixes
    allowed_prefixes = [
        Path.home() / "Projects",
        Path("/etc/mahavishnu/repos")
    ]

    if not any(
        str(repos_path).startswith(str(prefix))
        for prefix in allowed_prefixes
    ):
        raise ConfigurationError(
            f"repos_path must be within allowed prefixes",
            details={"repos_path": str(repos_path), "allowed": allowed_prefixes}
        )

    # Safe to load
    with open(repos_path) as f:
        repos = yaml.safe_load(f)
```

**Required Actions**:

1. Add path validation in `get_repos()`
1. Add path validation in `_load_repos()`
1. Define allowed prefixes in configuration
1. Test path traversal prevention
1. Add security scan for path patterns (bandit)

______________________________________________________________________

### 6. Adapter Implementations Are Placeholders (Architecture + Code)

**Severity**: 🔴 CRITICAL
**Found By**: Architecture Council + Code Reviewer
**Location**: `core/adapters/langgraph.py`, `core/adapters/prefect.py`, etc.

**Issue**:

```python
# ❌ This is a STUB, not implementation
class LangGraphAdapter(OrchestratorAdapter):
    def execute(self, task: dict, repos: list[str]) -> dict:
        """Execute LangGraph workflow"""
        # TODO: Implement actual LangGraph logic
        return {"status": "not_implemented"}
```

**Problems**:

- Zero actual adapter logic implemented
- No LLM provider integration
- No state management
- No error handling
- No retry logic
- No progress tracking

**Remediation** (LangGraph Example):

```python
# ✅ Actual implementation
from langgraph.graph import StateGraph
from langchain_openai import ChatOpenAI
from typing import TypedDict

class WorkflowState(TypedDict):
    repo: str
    task: dict
    messages: list[str]
    result: dict

class LangGraphAdapter(OrchestratorAdapter):
    def __init__(self, config: MahavishnuSettings):
        self.llm = ChatOpenAI(
            model=config.llm_model,
            api_key=config.llm_api_key
        )

    async def execute(
        self,
        task: dict,
        repos: list[str]
    ) -> dict:
        """Execute LangGraph workflow across repos"""

        results = []

        for repo in repos:
            # Build state graph for this repo
            graph = StateGraph(WorkflowState)

            # Add nodes
            graph.add_node("analyze", self._analyze_repo)
            graph.add_node("execute", self._execute_task)
            graph.add_node("verify", self._verify_result)

            # Add edges
            graph.set_entry_point("analyze")
            graph.add_edge("analyze", "execute")
            graph.add_edge("execute", "verify")

            # Compile and run
            compiled = graph.compile()
            result = await compiled.ainvoke({
                "repo": repo,
                "task": task,
                "messages": [],
                "result": {}
            })

            results.append(result)

        return {
            "status": "completed",
            "results": results,
            "repos_processed": len(repos)
        }

    async def _analyze_repo(self, state: WorkflowState) -> dict:
        """Analyze repository structure"""
        # Actual analysis logic
        pass

    async def _execute_task(self, state: WorkflowState) -> dict:
        """Execute task on repo"""
        # Actual execution logic
        pass

    async def _verify_result(self, state: WorkflowState) -> dict:
        """Verify execution result"""
        # Actual verification logic
        pass
```

**Required Actions**:

1. Implement actual LangGraph integration
1. Implement actual Prefect integration
1. Implement actual Agno integration
1. Add LLM provider configuration (OpenAI, Anthropic, etc.)
1. Add error handling and retry logic
1. Add progress tracking
1. Write comprehensive tests for each adapter

**Estimated Effort**: 3-4 weeks per adapter

______________________________________________________________________

## 🟡 HIGH PRIORITY ISSUES (Must Fix Before Production)

### 7. No Concurrency Control (Architecture)

**Severity**: 🟡 HIGH
**Found By**: Architecture Council
**Location**: `app.py` execute_workflow()

**Issue**:

```python
# ❌ No concurrency limits - will crash with 100 concurrent workflows
async def execute_workflow(self, task, adapter_name, repos):
    # Launches unlimited concurrent workflows
    results = await asyncio.gather(*[
        adapter.execute(task, [repo])
        for repo in repos
    ])
```

**Impact**:

- 100 concurrent workflows = 1000+ async tasks
- Will exhaust file descriptors, memory, CPU
- No rate limiting for external APIs
- No queue management

**Remediation**:

```python
# ✅ Add work queue with worker pool
import asyncio
from asyncio import Semaphore

class MahavishnuApp:
    def __init__(self, config: MahavishnuSettings):
        self.max_concurrent = config.max_concurrent_workflows  # e.g., 10
        self.semaphore = Semaphore(self.max_concurrent)
        self.work_queue = asyncio.Queue()

    async def execute_workflow(self, task, adapter_name, repos):
        """Execute workflow with concurrency control"""

        async def process_repo(repo):
            async with self.semaphore:  # 🔒 Limit concurrency
                return await adapter.execute(task, [repo])

        # Process repos with limited concurrency
        results = await asyncio.gather(*[
            process_repo(repo) for repo in repos
        ])

        return results
```

**Required Actions**:

1. Add `max_concurrent_workflows` to configuration (default: 10)
1. Implement `asyncio.Semaphore` for concurrency limiting
1. Add work queue for pending workflows
1. Add metrics for queue depth and wait times
1. Test with 100+ concurrent workflows

______________________________________________________________________

### 8. Sequential Repository Processing (Architecture)

**Severity**: 🟡 HIGH
**Found By**: Architecture Council
**Location**: `app.py` execute_workflow()

**Issue**:

```python
# ❌ Sequential processing = unacceptable latency
for repo in repos:  # 100 repos × 5 seconds = 500 seconds (8+ minutes!)
    result = await adapter.execute(task, [repo])
    results.append(result)
```

**Impact**:

- 100 repos × 5 seconds = 8+ minutes
- 1000 repos = 83+ minutes
- Unacceptable for large-scale operations

**Remediation**:

```python
# ✅ Parallel processing with controlled concurrency
async def execute_workflow(self, task, adapter_name, repos):
    """Execute workflow in parallel with concurrency control"""

    async def process_repo(repo):
        async with self.semaphore:
            return await adapter.execute(task, [repo])

    # Process repos in parallel (with semaphore limiting)
    results = await asyncio.gather(*[
        process_repo(repo) for repo in repos
    ])

    return results

# Performance: 100 repos × 5 seconds = ~50 seconds (with 10 workers)
```

**Required Actions**:

1. Change from sequential to parallel processing
1. Add concurrency limiting (see issue #7)
1. Add progress reporting for long-running workflows
1. Test with 100+ repos

______________________________________________________________________

### 9. Missing Error Recovery Patterns (Code)

**Severity**: 🟡 HIGH
**Found By**: Code Reviewer
**Location**: `core/adapters/` all adapters

**Issue**:

```python
# ❌ No retry logic - single failure causes permanent failure
result = await adapter.execute(task, repos)
# If this fails, workflow fails forever
```

**Impact**:

- Transient failures (network, API rate limits) cause permanent failures
- No retry with exponential backoff
- No circuit breaker for failing services
- No dead letter queue for failed repos

**Remediation**:

```python
# ✅ Add retry logic with tenacity
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)

class LangGraphAdapter(OrchestratorAdapter):
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_exception_type((ConnectionError, TimeoutError))
    )
    async def execute(self, task: dict, repos: list[str]) -> dict:
        """Execute with retry on transient failures"""
        # Actual implementation
        pass

# ✅ Add circuit breaker
class CircuitBreaker:
    def __init__(self, threshold: int = 5):
        self.threshold = threshold
        self.failure_count = 0
        self.state = "closed"  # closed, open, half_open

    def record_failure(self):
        self.failure_count += 1
        if self.failure_count >= self.threshold:
            self.state = "open"

    def allow_request(self) -> bool:
        if self.state == "open":
            return False
        return True
```

**Required Actions**:

1. Add tenacity retry decorators to all adapter methods
1. Implement circuit breaker for external API calls
1. Add dead letter queue for permanently failed repos
1. Add backoff strategy configuration
1. Add timeout enforcement
1. Write tests for retry and circuit breaker logic

______________________________________________________________________

### 10. Missing Observability Implementation (Code)

**Severity**: 🟡 HIGH
**Found By**: Code Reviewer
**Location**: `config.py` + all execution paths

**Issue**:

```python
# ✅ Configuration exists
metrics_enabled: bool = Field(default=True)
tracing_enabled: bool = Field(default=True)
otlp_endpoint: str = Field(default="http://localhost:4317")

# ❌ But no actual implementation
# No spans, metrics, or structured logging
```

**Impact**:

- Production debugging is impossible
- No visibility into system health
- Cannot diagnose performance issues
- No alerting on failures

**Remediation**:

```python
# ✅ Add OpenTelemetry initialization
from opentelemetry import trace, metrics
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import ConsoleSpanExporter
from opentelemetry.sdk.metrics import MeterProvider

def setup_telemetry(config: MahavishnuSettings):
    """Initialize OpenTelemetry"""

    if config.metrics_enabled:
        meter_provider = MeterProvider()
        metrics.set_meter_provider(meter_provider)

    if config.tracing_enabled:
        tracer_provider = TracerProvider()
        trace.set_tracer_provider(tracer_provider)

# ✅ Use in adapters
class LangGraphAdapter(OrchestratorAdapter):
    async def execute(self, task: dict, repos: list[str]) -> dict:
        """Execute with observability"""

        tracer = trace.get_tracer(__name__)
        meter = metrics.get_meter(__name__)

        # Create span
        with tracer.start_as_current_span("langgraph.execute") as span:
            span.set_attribute("task_type", task["task_type"])
            span.set_attribute("repo_count", len(repos))

            # Record metrics
            workflow_counter = meter.create_counter(
                "workflows.executed",
                description="Number of workflows executed"
            )
            workflow_counter.add(1, {"adapter": "langgraph"})

            # Actual execution
            result = await self._execute_internal(task, repos)

            span.set_attribute("status", result["status"])
            return result
```

**Required Actions**:

1. Add OpenTelemetry initialization in app startup
1. Add span creation for all workflow executions
1. Add metric recording (repos processed, failures, latency)
1. Add structured logging with correlation IDs
1. Add OTLP endpoint configuration
1. Write observability tests

______________________________________________________________________

### 11. Insecure MCP Server Configuration (Security)

**Severity**: 🟡 HIGH
**Found By**: Security Auditor
**Location**: `mcp/server.py` + configuration

**Issue**:

```python
# ❌ No TLS, no auth, no rate limiting
mcp_server = FastMCP("Mahavishnu")
mcp_server.run(host="0.0.0.0", port=8675)  # Exposed to world!
```

**Attack Vector**:

- Anyone can connect to MCP server
- No authentication required
- No rate limiting (can DOS the server)
- Plaintext communication (no TLS)

**Remediation**:

```python
# ✅ Add security controls
from fastmcp import FastMCP
import ssl

mcp_server = FastMCP("Mahavishnu")

# Add TLS
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(
    certfile="/etc/mahavishnu/cert.pem",
    keyfile="/etc/mahavishnu/key.pem"
)

# Add authentication
@mcp_server.auth
def authenticate(token: str) -> bool:
    """Validate JWT token"""
    import jwt
    try:
        jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return True
    except jwt.InvalidTokenError:
        return False

# Add rate limiting
from slowapi import Limiter
limiter = Limiter(max_requests=100, window_seconds=60)

@mcp_server.tool()
@limiter.limit("100/minute")
async def trigger_workflow(...) -> dict:
    """Rate-limited tool"""
    pass

# Run with security
mcp_server.run(
    host="127.0.0.1",  # Localhost only
    port=8675,
    ssl_context=ssl_context
)
```

**Required Actions**:

1. Bind to localhost by default (127.0.0.1)
1. Add JWT authentication for all tools
1. Add TLS for production deployments
1. Add rate limiting (100 req/min per client)
1. Add audit logging for all tool calls
1. Document security setup

______________________________________________________________________

### 12. Weak Auth Secret Validation (Security + Code)

**Severity**: 🟡 HIGH
**Found By**: Security Auditor + Code Reviewer
**Location**: `config.py` line 152-161

**Issue**:

```python
# ❌ Only checks presence, not strength
@field_validator("auth_secret")
@classmethod
def validate_auth_secret(cls, v: str | None, info) -> str | None:
    if info.data.get("auth_enabled") and not v:
        raise ValueError("auth_secret required")
    return v  # <-- Accepts "password" as valid!
```

**Risk**:

- Weak secrets can be brute-forced
- No entropy check
- No length requirement
- JWT secrets must be cryptographically strong

**Remediation**:

```python
# ✅ Add strength validation
@field_validator("auth_secret")
@classmethod
def validate_auth_secret(cls, v: str | None, info) -> str | None:
    if info.data.get("auth_enabled"):
        if not v:
            raise ValueError("auth_secret required when auth_enabled")

        # Length requirement
        if len(v) < 32:
            raise ValueError(
                "auth_secret must be at least 32 characters"
            )

        # Entropy check
        if len(set(v)) < 16:
            raise ValueError(
                "auth_secret has insufficient entropy "
                "(use random string, not dictionary word)"
            )

        # Warn on common patterns
        if v.lower() in ["password", "secret", "key"]:
            raise ValueError(
                "auth_secret cannot be a common word"
            )

    return v
```

**Required Actions**:

1. Add minimum length requirement (32 characters)
1. Add entropy check (at least 16 unique characters)
1. Reject common words
1. Document secret generation (use `openssl rand -base64 48`)
1. Add secret strength meter in setup

______________________________________________________________________

## 🟢 MEDIUM PRIORITY ISSUES

### 13. Missing QC Integration Points (Code)

**Severity**: 🟢 MEDIUM
**Found By**: Code Reviewer
**Location**: All adapters

**Issue**: Configuration has Crackerjack settings but no implementation.

**Remediation**:

```python
# After adapter execution
if app.config.qc_enabled:
    from crackerjack import run_qc_checks

    qc_result = run_qc_checks(
        repos=repos,
        min_score=app.config.qc_min_score
    )

    if qc_result["score"] < app.config.qc_min_score:
        raise WorkflowError(
            f"QC failed with score {qc_result['score']}",
            details={"qc_result": qc_result}
        )
```

______________________________________________________________________

### 14. Missing Session-Buddy Integration (Code)

**Severity**: 🟢 MEDIUM
**Found By**: Code Reviewer
**Location**: All workflow execution

**Issue**: Configuration has Session-Buddy settings but no implementation.

**Remediation**:

```python
async def execute_workflow(self, task, adapter_name, repos):
    if self.config.session_enabled:
        from session_buddy import create_checkpoint

        checkpoint_id = await create_checkpoint(
            session_id=task["id"],
            state={"task": task, "repos": repos}
        )

    try:
        result = await adapter.execute(task, repos)
        return result
    except Exception as e:
        if self.config.session_enabled:
            await update_checkpoint(
                checkpoint_id,
                status="failed",
                error=str(e)
            )
        raise
```

______________________________________________________________________

### 15. Missing Configuration Files (Code)

**Severity**: 🟢 MEDIUM
**Found By**: Code Reviewer
**Location**: Root directory

**Issue**: Plan references files that don't exist:

- `repos.yaml`
- `settings/mahavishnu.yaml`
- `settings/local.yaml`
- `oneiric.yaml`

**Remediation**:

```bash
# Create template files
mahavishnu/
├── repos.yaml.example           # Template repos.yaml
├── settings/
│   ├── mahavishnu.yaml.example  # Template config
│   └── local.yaml.example       # Template local overrides
└── oneiric.yaml.example         # Legacy Oneiric config
```

______________________________________________________________________

### Additional Issues Found

See full agent reports for:

- **Security Auditor**: 16 total security issues (2 Critical, 5 High, 6 Medium, 3 Low)
- **Architecture Council**: 7 architectural concerns with detailed recommendations
- **Code Reviewer**: 20+ code quality issues with implementation patterns

______________________________________________________________________

## 📊 COMBINED SCORE BREAKDOWN

| Perspective | Score | Status |
|-------------|-------|--------|
| **Architecture Council** | 7.5/10 | ⚠️ Needs Work |
| **Security Auditor** | 4/10 | 🔴 Critical Issues |
| **Code Reviewer** | 6.5/10 | ⚠️ Incomplete |
| **Combined Overall** | **6.5/10** | **🔴 NOT PRODUCTION READY** |

______________________________________________________________________

## 🎯 PRIORITIZED ACTION PLAN

### Phase 0: Security Hardening (Week 1) - 🔴 CRITICAL

**Must complete before any other work**

- [ ] Remove API keys from `config.yaml` and rotate them
- [ ] Add path traversal validation to all file operations
- [ ] Implement JWT authentication for CLI
- [ ] Add auth secret strength validation
- [ ] Create `config.yaml.example` templates
- [ ] Add security scan to CI/CD (bandit, safety)

**Deliverable**: Security-hardened configuration foundation

______________________________________________________________________

### Phase 1: Fix Core Architecture (Week 2) - 🔴 CRITICAL

**Must complete before implementing features**

- [ ] Fix async/sync mismatch in base adapter
- [ ] Add `get_health()` to base adapter interface
- [ ] Update all adapter implementations to be async
- [ ] Add concurrency control (semaphore, work queue)
- [ ] Change from sequential to parallel repo processing
- [ ] Add repository validation

**Deliverable**: Solid async architecture with concurrency control

______________________________________________________________________

### Phase 2: Rewrite MCP Server (Week 3-4) - 🔴 CRITICAL

**Core feature is completely broken**

- [ ] Rewrite `mcp/server.py` using FastMCP
- [ ] Implement core MCP tools:
  - `list_repos`
  - `trigger_workflow`
  - `get_workflow_status`
  - `cancel_workflow`
  - `list_adapters`
  - `get_health`
- [ ] Add tool error handling
- [ ] Add MCP authentication
- [ ] Add MCP rate limiting
- [ ] Test with Claude Desktop
- [ ] Write MCP integration tests

**Deliverable**: Functional MCP server with all core tools

______________________________________________________________________

### Phase 3: Implement Actual Adapters (Week 5-8) - 🟡 HIGH

**Current implementations are placeholders**

#### Week 5-6: LangGraph Adapter

- [ ] Implement actual LangGraph integration
- [ ] Add LLM provider configuration (OpenAI, Anthropic)
- [ ] Add state management across repos
- [ ] Add error handling and retry logic
- [ ] Add progress tracking
- [ ] Write comprehensive tests

#### Week 7: Prefect Adapter

- [ ] Implement Prefect integration
- [ ] Add flow construction from task specs
- [ ] Add deployment patterns
- [ ] Add error handling
- [ ] Write tests

#### Week 8: Agno Adapter

- [ ] Implement Agno v2.0 integration
- [ ] Add AgentOS runtime integration
- [ ] Add experimental feature flags
- [ ] Write tests

**Deliverable**: Three production-ready adapters

______________________________________________________________________

### Phase 4: Production Features (Week 9-10) - 🟡 HIGH

**Features required for production readiness**

- [ ] Implement error recovery patterns:
  - [ ] Tenacity retry decorators
  - [ ] Circuit breaker implementation
  - [ ] Dead letter queue for failed repos
  - [ ] Backoff strategies
  - [ ] Timeout enforcement
- [ ] Implement observability:
  - [ ] OpenTelemetry initialization
  - [ ] Span creation for workflows
  - [ ] Metric recording
  - [ ] Structured logging with correlation IDs
- [ ] Integrate Crackerjack QC:
  - [ ] Pre-execution quality gates
  - [ ] Post-execution scoring
  - [ ] Failure handling
- [ ] Integrate Session-Buddy:
  - [ ] Pre-execution checkpoint
  - [ ] Post-execution update
  - [ ] Failure recovery

**Deliverable**: Production-ready feature set

______________________________________________________________________

### Phase 5: Testing & Documentation (Week 11) - 🟢 MEDIUM

**Quality assurance**

- [ ] Write comprehensive test suite:
  - [ ] Unit tests (90%+ coverage)
  - [ ] Integration tests (all CLI commands, all adapters)
  - [ ] E2E tests (3-5 critical workflows)
  - [ ] Property-based tests (Hypothesis)
- [ ] Create configuration guides
- [ ] Create migration guides (Airflow/CrewAI → Prefect/LangGraph)
- [ ] Create troubleshooting guide
- [ ] Create API reference
- [ ] Create usage examples

**Deliverable**: Complete test suite and documentation

______________________________________________________________________

### Phase 6: Production Readiness (Week 12) - 🟢 MEDIUM

**Final validation**

- [ ] Security audit (bandit, safety)
- [ ] Performance benchmarking:
  - [ ] Test with 100+ repos
  - [ ] Test with 100+ concurrent workflows
  - [ ] Memory usage profiling
- [ ] Dependency vulnerability scan
- [ ] License compliance check
- [ ] Production readiness checklist
- [ ] PyPI release preparation

**Deliverable**: Production-ready Mahavishnu v1.0

______________________________________________________________________

## 📈 REVISED TIMELINE

**Original Plan**: 5 weeks

**Recommended Timeline**: **10-12 weeks**

**Breakdown**:

- Week 1: Security hardening
- Week 2: Core architecture fixes
- Week 3-4: MCP server rewrite
- Week 5-8: Adapter implementations
- Week 9-10: Production features
- Week 11: Testing & documentation
- Week 12: Production readiness

**Why 10-12 weeks?**

- 6 critical security issues must be fixed first
- MCP server requires complete rewrite (2 weeks)
- Each adapter requires 2-3 weeks (not 1 week)
- Production features (retry, observability) require 2 weeks
- Testing and documentation require 2 weeks
- Buffer for unexpected issues

______________________________________________________________________

## 🎯 KEY SUCCESS METRICS

### Security

- ✅ Zero API keys in git
- ✅ All CLI commands require JWT authentication
- ✅ All path operations validated
- ✅ All secrets meet strength requirements

### Architecture

- ✅ All adapters are async
- ✅ Concurrency control in place
- ✅ MCP server functional with FastMCP
- ✅ All adapters implement actual logic

### Code Quality

- ✅ 90%+ test coverage
- ✅ All tests passing
- ✅ Type checking passes (mypy)
- ✅ Linting passes (ruff)

### Production Readiness

- ✅ Can handle 100+ repos without degradation
- ✅ Can handle 100+ concurrent workflows
- ✅ Retry logic prevents cascading failures
- ✅ Observability provides full visibility

______________________________________________________________________

## 📚 RESOURCES

### Full Agent Reports

- **Architecture Council**: Task aade016
- **Security Auditor**: Task a94ab2e
- **Code Reviewer**: Task a0c9bb8

### Related Documentation

- `IMPLEMENTATION_PLAN.md` - Original plan (audited)
- `docs/MCP_TOOLS_SPECIFICATION.md` - MCP tool specifications
- `CLAUDE.md` - Project instructions
- `SECURITY_CHECKLIST.md` - Security guidelines

______________________________________________________________________

## 🏁 CONCLUSION

The Mahavishnu implementation plan has a **solid architectural foundation** but requires **critical security fixes**, **core architecture corrections**, and **complete implementation of placeholder code** before it can be considered production-ready.

**Immediate Priorities**:

1. Fix all 6 critical security issues
1. Fix async/sync mismatch in adapters
1. Rewrite MCP server with FastMCP
1. Implement actual adapter logic
1. Add concurrency control
1. Add error recovery and observability

**With these fixes, Mahavishnu will be a production-ready, enterprise-grade multi-engine orchestration platform.**

**Recommended Action**: Approve revised 10-12 week timeline and begin with Phase 0 (Security Hardening).

______________________________________________________________________

**Audit Completed**: 2026-01-23
**Next Review**: After Phase 0 completion (Week 1)
