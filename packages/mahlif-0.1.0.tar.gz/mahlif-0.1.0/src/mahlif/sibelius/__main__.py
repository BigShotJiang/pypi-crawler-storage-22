"""Entry point for `python -m mahlif.sibelius` or `uv run -m mahlif.sibelius`."""

# no cover: start
from mahlif.sibelius.cli import main

if __name__ == "__main__":
    main()
# no cover: stop
