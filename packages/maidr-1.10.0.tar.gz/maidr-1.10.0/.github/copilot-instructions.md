Always adhere to PEP 8 coding style guide.
Always add NumPy-style docstring for all functions and classes.
Include example section in the docstring if applicable.
Always add type annotations
Always add understandable comments.
