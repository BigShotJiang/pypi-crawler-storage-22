import base64
import datetime
from pathlib import Path

from mailjet_rest import Client
from mailjet_rest.client import ApiError


def init_mailjet_client(api_key: str, api_secret: str) -> Client:
    return Client(auth=(api_key, api_secret), version="v3.1")


class MailjetSender:
    def __init__(self, api_key: str, api_secret: str, sender_addr: str, sender_name: str) -> None:
        self.api_key = api_key
        self.api_secret = api_secret
        self.sender_addr = sender_addr
        self.sender_name = sender_name
        self.mj_client = Client(auth=(api_key, api_secret), version="v3.1")

    def send_mail(
        self,
        recipient_addr: str,
        subject: str,
        html_body: str,
        attachment_pth: Path | None = None,
        attachment_name: str = "document",
    ) -> dict:
        """Sends the actual mail

        :param recipient_addr: recipient email address
        :param subject: subject of the email
        :param html_body: html body of the email
        :param attachment_path: path to a PDF file
        :param attachment_name: name of the file of the attachment without suffix, '.pdf' is automatically appended
        :return: mailjet message meta of the sent email
        """
        data = {
            "Messages": [
                {
                    "From": {"Email": self.sender_addr, "Name": self.sender_name},
                    "To": [{"Email": f"{recipient_addr}", "Name": recipient_addr.split("@")[0]}],
                    "Subject": subject,
                    "TextPart": "Greetings from Mailjet!",
                    "HTMLPart": html_body,
                }
            ]
        }

        if attachment_pth:
            if attachment_pth.suffix != ".pdf":
                msg = f"Only accepting .pdf files as attachment. Implement MIME type for {attachment_pth.suffix}"
                raise NotImplementedError(msg)
            with attachment_pth.open("rb") as attachment_file:
                encoded_binary_string = base64.b64encode(attachment_file.read())
            encoded_string = encoded_binary_string.decode("ascii")
            data["Messages"][0]["Attachments"] = [
                {
                    "ContentType": "application/pdf",
                    "Filename": attachment_name + ".pdf",
                    "Base64Content": encoded_string,
                }
            ]

        result = self.mj_client.send.create(data=data)
        result.raise_for_status()

        meta = {
            "message_id": result.json()["Messages"][0]["To"][0]["MessageID"],
            "date_sent": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S"),
            "system": "mailjet",
        }
        return meta


def test_connection(api_key: str, api_secret: str) -> None:
    """Tests the connection to mailjet by sending a request to the send endpoint.

    :param api_key: The API key for Mailjet
    :param api_secret: The API secret for Mailjet
    """
    mj = init_mailjet_client(api_key=api_key, api_secret=api_secret)
    try:
        response = mj.send.get()
    except ApiError as e:
        print(f"Failed with exception: {e}")  # noqa T201
        return

    if response.status_code == 405 and response.json()["ErrorMessage"].startswith("Method GET not allowed"):  # noqa PLR2004
        print("Success")  # noqa T201
        return

    print(f"Status Code: {response.status_code}, Response: {response.text}")  # noqa T201
