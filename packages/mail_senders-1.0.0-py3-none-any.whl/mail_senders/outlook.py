import datetime
from pathlib import Path

import win32com.client as win32


class OutlookSender:
    def __init__(self) -> None:
        self.outlook = win32.Dispatch("Outlook.application")

    def send_mail(
        self, recipient_addr: str, subject: str, html_body: str, attachment_path: Path | str | None = None
    ) -> dict:
        """sends the email

        :param recipient_addr: recipient email address
        :param subject: subject of the email
        :param html_body: html body of the email
        :param attachment_path: path to the attachment (optional)
        :return: meta information about the sent email
        """

        mail = self.outlook.CreateItem(0)
        mail.To = recipient_addr
        mail.Subject = subject
        mail.HTMLBody = html_body

        if attachment_path:
            mail.Attachments.Add(str(attachment_path))

        mail.Send()
        meta = {
            "date_sent": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S"),
            "system": "outlook",
        }
        return meta


def send_html_mail_with_outlook(
    outlook, recipient: str, subject: str, html_body: str, attachment: Path | str | None = None
) -> None:
    """Sends a mail via outlook. Outlook object is passed as parameter to avoid multiple
    initialization of reusable object.

    :param outlook: outlook object, e.g. outlook = win32.Dispatch('outlook.application')
    :param recipient: recipient email address
    :param subject: subject of the email
    :param html_body: html body of the email
    :param attachment: path to the attachment (optional)
    """
    mail = outlook.CreateItem(0)
    mail.To = recipient
    mail.Subject = subject
    # mail.Body = 'Message body'
    mail.HTMLBody = html_body

    if attachment:
        mail.Attachments.Add(str(attachment))

    mail.Send()
