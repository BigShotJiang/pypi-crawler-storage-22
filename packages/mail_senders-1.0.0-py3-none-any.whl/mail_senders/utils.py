from pathlib import Path


def get_html_body(path: Path, replacements: list[tuple] | None = None):
    """Reads html or arbitrary text body from file.

    Te idea is to have a template file with placeholders that can be replaced with actual values.

    :param path: path to the file containing the html body
    :param replacements: list of tuples with (to_replace, replace_with)
    """
    with path.open("r", encoding="utf-8") as f:
        html_body = f.read()
        if replacements:
            for replace, replace_with in replacements:
                html_body = html_body.replace(replace, replace_with)
    return html_body
