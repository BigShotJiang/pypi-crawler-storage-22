# MAIL Contributors and Maintainers

## Will Hahn
- **Affiliation**: Charon Labs, LLC
- **GitHub**: [wsfhahn](https://github.com/wsfhahn)
- **Contributions**: Documentation diagrams and swarm endpoint work
- **Status**: occasional

## Ryan Heaton
- **Affiliation**: Charon Labs, LLC
- **GitHub**: [rheaton64](https://github.com/rheaton64)
- **Contributions**: MAIL reference implementation runtime architecture work
- **Status**: occasional

## Jacob Hahn
- **Affiliation**: Charon Labs, LLC
- **GitHub**: [jacobtohahn](https://github.com/jacobtohahn)
- **Contributions**: Help with protocol development
- **Status**: occasional

## Addison Kline
- **Affiliation**: Charon Labs, LLC
- **GitHub**: [addisonkline](https://github.com/addisonkline)
- **Contributions**: The rest
- **Status**: active