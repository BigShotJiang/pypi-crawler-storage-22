from mail.examples.math_dummy.actions import calculate_expression

action_calculate_expression = calculate_expression

__all__ = ["action_calculate_expression"]
