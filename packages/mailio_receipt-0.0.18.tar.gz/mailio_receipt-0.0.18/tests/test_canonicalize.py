"""Tests for RFC8785 canonicalization."""

from __future__ import annotations

from mailio_receipt.canonicalize import canonicalize, compute_digest
from mailio_receipt.models import MailioAuditEvent


class TestCanonicalize:
    """Tests for canonicalize function."""

    def test_deterministic_output(self) -> None:
        """Test that canonicalization produces deterministic output."""
        data = {"b": 2, "a": 1, "c": 3}

        # Multiple calls should produce identical output
        result1 = canonicalize(data)
        result2 = canonicalize(data)

        assert result1 == result2

    def test_returns_bytes(self) -> None:
        """Test that canonicalize returns bytes."""
        data = {"key": "value"}
        result = canonicalize(data)

        assert isinstance(result, bytes)


class TestComputeDigest:
    """Tests for compute_digest function."""

    def test_deterministic_digest(self) -> None:
        """Test that digest computation is deterministic."""
        data = {"b": 2, "a": 1}

        digest1 = compute_digest(data)
        digest2 = compute_digest(data)

        assert digest1 == digest2

    def test_digest_length(self) -> None:
        """Test that digest is 64 hex characters (SHA-256)."""
        data = {"key": "value"}
        digest = compute_digest(data)

        assert len(digest) == 64
        assert all(c in "0123456789abcdef" for c in digest)

    def test_different_data_different_digest(self) -> None:
        """Test that different data produces different digests."""
        data1 = {"key": "value1"}
        data2 = {"key": "value2"}

        digest1 = compute_digest(data1)
        digest2 = compute_digest(data2)

        assert digest1 != digest2

    def test_key_order_independent(self) -> None:
        """Test that key order doesn't affect digest (due to canonicalization)."""
        # These should produce the same digest after canonicalization
        data1 = {"a": 1, "b": 2}
        data2 = {"b": 2, "a": 1}

        digest1 = compute_digest(data1)
        digest2 = compute_digest(data2)

        assert digest1 == digest2

    def test_known_digest(self) -> None:
        """Test against a known digest value."""
        # This ensures the implementation doesn't change unexpectedly
        data = {
    "type": "MailioAuditEvent",
    "v": "v1",
    "id": "84d44d51-d5c4-4ab6-a766-d701fa80a666",
    "flow_id": "243313bb-c4a0-4e81-a88c-a31f3566cdac",
    "ts": "2026-02-11T22:49:20.469Z",
    "actors": {
        "issuer": "igor@mail.io",
        "subject": "did:web:mio.mailiomail.com:0xb3e49d751ba7d6647a720a52060ceebe42524704"
    },
    "intent": {
        "kind": "trigger_watch_condition",
        "action": "price_above",
        "category": "stock_price",
        "scope": {
            "ticker": "MIO",
            "direction": "price_above",
            "threshold": 66
        }
    }
}
        event = MailioAuditEvent.from_dict(data)
        digest = compute_digest(event.to_dict())

        print(digest)

        # Pre-computed expected value
        # canonicalize({"hello": "world"}) = b'{"hello":"world"}'
        # sha256(b'{"hello":"world"}').hexdigest() = expected
        expected = "pS8Th0V15_b6jZT_gqpw0V4C8hJt4Zm4P0mKt6VnemM"
        assert digest == expected
