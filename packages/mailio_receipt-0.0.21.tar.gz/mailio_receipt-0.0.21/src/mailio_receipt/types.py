"""Type aliases for MailioReceipt library."""

from __future__ import annotations

from typing import Literal


# Type aliases
SignerRole = Literal["user", "agent", "authority"]
Algorithm = Literal["ES256", "EdDSA"]
Canonicalization = Literal["RFC8785"]
SignedTarget = Literal["/event"]
