"""MailioReceipt v1 - Cryptographically verifiable event records."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Literal

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePrivateKey

from importlib.metadata import version

from mailio_receipt.canonicalize import canonicalize, compute_digest
from mailio_receipt.client import CreateReceiptResult, MailioClient
from mailio_receipt.errors import (
    BindingMismatchError,
    ChainError,
    ChainIntegrityError,
    ExecutionBlockedError,
    ExpiredApprovalError,
    InvalidSignatureError,
    MailioReceiptError,
    MissingPredecessorError,
    NetworkError,
    RevocationError,
    SaveReceiptError,
    SignatureError,
    SignerNotFoundError,
    ValidationError,
)
from mailio_receipt.execution import (
    BlockingReason,
    ExecutionDecision,
    check_execution,
)
from mailio_receipt.integrations import (
    ReceiptsResponse,
    get_receipt,
    get_receipts_by_flow,
    save_receipt,
)
from mailio_receipt.models import (
    Actors,
    ArtifactBinding,
    Binding,
    Chain,
    Intent,
    IntentKind,
    MailioAuditEvent,
    MailioReceipt,
    MessageBinding,
    Signature,
    SignedMetadata,
    create_event,
)
from mailio_receipt.signing import create_jws_detached
from mailio_receipt.verification import (
    ChainVerificationResult,
    SignerInfo,
    VerificationResult,
    verify_chain,
    verify_receipt,
)

__version__ = version("mailio-receipt")

__all__ = [
    # Version
    "__version__",
    # Creation
    "create_receipt",
    "create_event",
    "compute_chain_digest",
    "chain_from",
    # Models
    "MailioReceipt",
    "MailioAuditEvent",
    "Actors",
    "Intent",
    "IntentKind",
    "Chain",
    "Binding",
    "ArtifactBinding",
    "MessageBinding",
    "Signature",
    "SignedMetadata",
    # Verification
    "verify_receipt",
    "verify_chain",
    "VerificationResult",
    "ChainVerificationResult",
    "SignerInfo",
    # Errors
    "MailioReceiptError",
    "ValidationError",
    "SignatureError",
    "InvalidSignatureError",
    "SignerNotFoundError",
    "ChainError",
    "ChainIntegrityError",
    "MissingPredecessorError",
    "ExecutionBlockedError",
    "RevocationError",
    "ExpiredApprovalError",
    "BindingMismatchError",
    # Execution
    "check_execution",
    "ExecutionDecision",
    "BlockingReason",
    # Integrations
    "save_receipt",
    "get_receipt",
    "get_receipts_by_flow",
    "ReceiptsResponse",
    # Client
    "MailioClient",
    "CreateReceiptResult",
    "NetworkError",
    "SaveReceiptError",
]


def create_receipt(
    *,
    event: MailioAuditEvent,
    private_key: EllipticCurvePrivateKey | Ed25519PrivateKey,
    signer_did: str,
    role: Literal["user", "agent", "authority"] = "agent",
    mio_base_url: str | None = None,
    mio_api_key: str | None = None,
) -> MailioReceipt:
    """
    Create a signed receipt for an event.

    Args:
        event: The event to receipt (must be fully populated)
        private_key: EC P-256 or Ed25519 private key for signing
        signer_did: Identifier of the signer
        role: Role of the signer in this event
        mio_base_url: If provided (with mio_api_key), the receipt is saved
            to the Mailio backend via POST /api/v1/receipts.
        mio_api_key: API key for the Mailio backend.

    Returns:
        MailioReceipt with computed digest and signature

    Raises:
        ValidationError: If event is invalid
        SignatureError: If signing fails
        httpx.HTTPStatusError: If saving to the backend fails
    """
    # Compute event digest
    event_dict = event.to_dict()
    event_digest = compute_digest(event_dict)

    # Create JWS signature over the digest (consistent with WebAuthn challenge)
    try:
        jws = create_jws_detached(event_digest.encode(), private_key, signer_did)
    except Exception as e:
        raise SignatureError(f"Failed to create signature: {e}") from e

    # Build signature metadata
    signed_metadata = SignedMetadata(
        canonicalization="RFC8785",
        digest=event_digest,
        target="/event",
    )

    # Build signature
    alg = "ES256"
    if isinstance(private_key, Ed25519PrivateKey):
        alg = "EdDSA"

    signature = Signature(
        role=role,
        signer=signer_did,
        alg=alg,
        signed=signed_metadata,
        jws=jws,
    )

    # Build receipt
    receipt = MailioReceipt(
        type="MailioReceipt",
        v="v1",
        event=event,
        event_digest=event_digest,
        signatures=(signature,),
    )

    # Optionally save to Mailio backend
    if mio_base_url is not None and mio_api_key is not None:
        receipt = asyncio.run(
            save_receipt(receipt, base_url=mio_base_url, api_key=mio_api_key)
        )

    return receipt


def compute_chain_digest(source: MailioReceipt | MailioAuditEvent) -> str:
    """
    Compute a chain digest from an event or receipt.

    For chaining, we only digest the event content (not signatures).
    """
    if isinstance(source, MailioReceipt):
        if source.event_digest:
            return source.event_digest
        event = source.event
    else:
        event = source
    return compute_digest(event.to_dict())


def chain_from(
    source: MailioReceipt | MailioAuditEvent,
    *,
    prev_receipt_ref: str | None = None,
    reason: str | None = None,
) -> Chain:
    """Create a Chain reference from a prior receipt or event."""
    return Chain(
        prev_receipt_digest=compute_chain_digest(source),
        prev_receipt_ref=prev_receipt_ref,
        reason=reason,
    )
