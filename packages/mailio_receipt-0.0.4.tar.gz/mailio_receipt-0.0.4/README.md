# MailioReceipt v1

Cryptographically verifiable, append-only event records for human-agent and agent-agent workflows.

## Installation

```bash
pip install mailio-receipt
```

## Quick Start

```python
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend

from mailio_receipt import (
    create_receipt,
    create_event,
    Actors,
    Intent,
    IntentKind,
)

# Generate a signing key (P-256 or Ed25519)
private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

# Create an event
event = create_event(
    flow_id="660f9400-f39c-51e5-b827-557766551111",
    actors=Actors(
        issuer="did:web:agent.example.com",
        subject="did:web:user.example.com",
    ),
    intent=Intent(
        kind=IntentKind.ACTION_PLANNED,
        action="invoice.send",
        category="financial",
        scope={"invoiceId": "INV-2026-001"},
    ),
)

# Sign and create receipt
receipt = create_receipt(
    event=event,
    private_key=private_key,
    signer_did="did:web:agent.example.com",
)

print(f"Receipt created: {receipt.digest[:16]}...")
```

## License

MIT
