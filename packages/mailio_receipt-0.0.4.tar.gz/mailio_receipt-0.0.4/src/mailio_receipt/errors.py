"""Custom exception types for MailioReceipt library."""

from __future__ import annotations


class MailioReceiptError(Exception):
    """Base exception for all library errors."""


class ValidationError(MailioReceiptError):
    """Invalid input data."""


class SignatureError(MailioReceiptError):
    """Signature creation or verification failed."""


class InvalidSignatureError(SignatureError):
    """Signature does not match content."""


class SignerNotFoundError(SignatureError):
    """Signer key not found in DID document."""


class ChainError(MailioReceiptError):
    """Chain integrity violation."""


class ChainIntegrityError(ChainError):
    """Chain digest mismatch."""


class MissingPredecessorError(ChainError):
    """Referenced predecessor not found."""


class DIDResolutionError(MailioReceiptError):
    """DID resolution failed."""


class DIDNotFoundError(DIDResolutionError):
    """DID document not found."""


class DIDNetworkError(DIDResolutionError):
    """Network error during resolution (retryable)."""


class ExecutionBlockedError(MailioReceiptError):
    """Execution not allowed."""


class RevocationError(ExecutionBlockedError):
    """Action revoked."""


class ExpiredApprovalError(ExecutionBlockedError):
    """Approval has expired."""


class BindingMismatchError(ExecutionBlockedError):
    """Artifact binding verification failed."""
