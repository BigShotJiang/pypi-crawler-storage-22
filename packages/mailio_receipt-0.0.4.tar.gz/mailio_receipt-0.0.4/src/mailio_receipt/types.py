"""Type aliases and protocols for MailioReceipt library."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, Protocol, runtime_checkable

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric.ec import EllipticCurvePublicKey
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


# Type aliases
SignerRole = Literal["user", "agent", "authority"]
Algorithm = Literal["ES256", "EdDSA"]
Canonicalization = Literal["RFC8785"]
SignedTarget = Literal["/event"]

# DID Document type alias (simplified)
DIDDocument = dict[str, Any]


@runtime_checkable
class DIDResolver(Protocol):
    """Protocol for DID resolution."""

    async def resolve(self, did: str) -> DIDDocument:
        """Resolve a DID to its document."""
        ...

    async def get_verification_key(
        self,
        did: str,
        key_id: str | None = None,
    ) -> EllipticCurvePublicKey | Ed25519PublicKey:
        """Get a verification public key from a DID document."""
        ...
