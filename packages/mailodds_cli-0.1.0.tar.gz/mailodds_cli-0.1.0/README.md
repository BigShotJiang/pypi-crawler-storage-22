# MailOdds CLI

Command-line interface for MailOdds API testing and webhook debugging.

## Installation

```bash
pip install mailodds-cli
```

Or install from source:

```bash
cd sdks/cli
pip install -e .
```

## Authentication

Set your API key as an environment variable:

```bash
export MAILODDS_API_KEY=mo_live_your_api_key
```

Or pass it with each command:

```bash
mailodds --api-key mo_live_xxx webhooks listen ...
```

## Commands

### Webhook Testing

Listen for webhook events and forward to your local server:

```bash
# Forward webhooks to local development server
mailodds webhooks listen --forward localhost:3000/webhook

# Just display events without forwarding
mailodds webhooks listen --no-forward
```

List recent webhook deliveries:

```bash
mailodds webhooks list
mailodds webhooks list --limit 50
```

Replay a historical webhook delivery:

```bash
mailodds webhooks replay 12345
```

### Email Validation

Validate a single email from the command line:

```bash
mailodds validate user@example.com
```

## Test Mode

Use `mo_test_` API keys with special test domains for predictable results without consuming credits:

```bash
export MAILODDS_API_KEY=mo_test_your_test_key

# Always returns valid
mailodds validate john@deliverable.mailodds.com

# Always returns invalid
mailodds validate john@invalid.mailodds.com
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MAILODDS_API_KEY` | Your API key | Required |
| `MAILODDS_API_URL` | API base URL | `https://api.mailodds.com` |

## Development

```bash
# Install in development mode
pip install -e ".[dev]"

# Run CLI
mailodds --help
```
