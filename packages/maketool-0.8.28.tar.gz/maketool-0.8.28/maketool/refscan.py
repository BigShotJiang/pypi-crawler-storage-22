#!/usr/bin/env python3
"""
maketool-refscan

Usage:
  maketool-refscan <entry_file>

Reports (order):
  1) UNUSED functions: top-level Python functions whose names are never referenced anywhere
     - Heuristic: counts Name loads and Attribute loads (e.g., foo(), obj.foo)
  2) UNUSED files: filename/path tokens not found in scanned text sources
     - Grouped by extension, with .py printed last
  3) MISSING imports: imports used by entry (and local-resolved siblings) but not installed
     - Printed in Sublime-clickable form: File "...", line N, <import ...> (missing)
"""

from __future__ import annotations

import ast
import sys
import os
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Set, Tuple

try:
    from importlib.metadata import packages_distributions  # py 3.8+
except Exception:
    packages_distributions = None  # type: ignore


# ----------------------------
# Refscan settings
# ----------------------------

DEFAULT_IGNORE_DIRS = {
    ".git", ".hg", ".svn",
    "__pycache__", ".mypy_cache", ".pytest_cache",
    ".venv", "venv", "env",
    "build", "dist", ".tox",
}

DEFAULT_SCAN_EXTS = {
    ".py", ".ui", ".qrc", ".qss",
    ".bat", ".cmd", ".ps1",
    ".txt", ".md", ".rst",
    ".ini", ".cfg", ".toml",
    ".json", ".yaml", ".yml",
    ".xml", ".html", ".htm", ".css",
}

DEFAULT_SKIP_CONTENT_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg",
    ".ico", ".icns",
    ".pdf", ".zip", ".7z", ".rar",
    ".db", ".sqlite", ".dll", ".exe", ".pyd",
}


@dataclass(frozen=True)
class Candidate:
    path: Path
    rel: str
    tokens: tuple[str, ...]


def usage_exit(msg: str = "") -> None:
    if msg:
        print(msg, file=sys.stderr)
    print("Usage: maketool-refscan <entry_file>", file=sys.stderr)
    raise SystemExit(2)


def iter_files(root: Path, ignore_dirs: set[str]) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        if any(part in ignore_dirs for part in p.parts):
            continue
        yield p


def safe_read_text(p: Path) -> Optional[str]:
    try:
        return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None


def norm(s: str) -> str:
    return s.replace("\\", "/").lower()


def build_candidates(root: Path, files: list[Path]) -> list[Candidate]:
    out: list[Candidate] = []
    for p in files:
        rel = str(p.relative_to(root))
        rel_norm = norm(rel)
        base = p.name.lower()
        stem = p.stem.lower()

        tokens = {
            base,                          # rat.ico
            stem,                          # common
            rel_norm,                      # icons/rat.ico
            rel_norm.replace("/", "\\"),   # icons\rat.ico
        }
        out.append(Candidate(p, rel, tuple(t for t in tokens if t)))
    return out


def is_text_source(p: Path) -> bool:
    ext = p.suffix.lower()
    if ext in DEFAULT_SKIP_CONTENT_EXTS:
        return False
    return ext in DEFAULT_SCAN_EXTS


def print_unused_grouped(unused_rels: list[str]) -> None:
    """
    Print unused files grouped by extension, with .py printed last.
    """
    def sort_key(rel: str):
        ext = Path(rel).suffix.lower()
        is_py = (ext == ".py")
        return (is_py, ext, rel.lower())

    unused_sorted = sorted(unused_rels, key=sort_key)

    print("UNUSED files (no filename/path tokens found)")
    print("--------------------------------------------")

    printed_py_gap = False
    for rel in unused_sorted:
        if Path(rel).suffix.lower() == ".py" and not printed_py_gap:
            printed_py_gap = True
        print(rel)

    print()


# ----------------------------
# Unused-functions report
# ----------------------------

@dataclass(frozen=True)
class FuncDef:
    module: str     # dotted module path
    qualname: str   # function name (top-level only)
    path: Path
    lineno: int


def path_to_module(project_root: Path, path: Path) -> str:
    rel = path.relative_to(project_root)
    s = str(rel).replace(os.sep, ".")
    if s.endswith(".py"):
        s = s[:-3]
    if s.endswith(".__init__"):
        s = s[:-9]
    return s


class FuncAnalyzer(ast.NodeVisitor):
    def __init__(self, module: str):
        self.module = module
        self.defined: List[Tuple[str, int]] = []  # (name, lineno)
        self.refs: Set[str] = set()               # names referenced in this module

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if isinstance(getattr(node, "parent", None), ast.Module):
            self.defined.append((node.name, node.lineno))
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        if isinstance(getattr(node, "parent", None), ast.Module):
            self.defined.append((node.name, node.lineno))
        self.generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            self.refs.add(node.id)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if isinstance(node.ctx, ast.Load):
            self.refs.add(node.attr)
        self.generic_visit(node)


def attach_parents(tree: ast.AST) -> None:
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            setattr(child, "parent", parent)


def analyze_python_tree(project_root: Path, py_files: List[Path]) -> Tuple[List[FuncDef], Set[str]]:
    all_defs: List[FuncDef] = []
    all_refs: Set[str] = set()

    for path in py_files:
        module = path_to_module(project_root, path)
        try:
            src = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(src, filename=str(path))
        except Exception:
            continue

        attach_parents(tree)
        a = FuncAnalyzer(module)
        a.visit(tree)

        for name, lineno in a.defined:
            all_defs.append(FuncDef(module=module, qualname=name, path=path, lineno=lineno))

        all_refs |= a.refs

    return all_defs, all_refs


def find_unused_functions(project_root: Path, py_files: List[Path]) -> List[FuncDef]:
    defs, refs = analyze_python_tree(project_root, py_files)
    unused = [d for d in defs if d.qualname not in refs]
    return sorted(unused, key=lambda x: (str(x.path).lower(), x.lineno, x.qualname.lower()))


def print_unused_functions_report(project_root: Path, py_files: List[Path]) -> None:
    unused = find_unused_functions(project_root, py_files)

    print("UNUSED functions (top-level; name never referenced)")
    print("--------------------------------------------------")

    if not unused:
        print("(none)\n")
        return

    for d in unused:
        print(f'File "{d.path}", line {d.lineno}, {d.module}.{d.qualname} (not referenced)')
    print()


# ----------------------------
# Missing-import report (now Sublime-clickable)
# ----------------------------

@dataclass(frozen=True)
class ImportUse:
    top: str
    path: Path
    lineno: int
    detail: str  # e.g. "import matplotlib" or "from matplotlib import pyplot as plt"


def stdlib_names() -> Set[str]:
    names = set(getattr(sys, "stdlib_module_names", set()) or set())
    if names:
        return names

    return {
        "os", "sys", "re", "math", "time", "json", "pathlib", "typing", "ast",
        "subprocess", "logging", "datetime", "functools", "itertools", "collections",
        "statistics", "threading", "multiprocessing", "asyncio", "http", "urllib",
        "email", "sqlite3", "csv", "gzip", "zipfile", "hashlib", "base64",
        "ctypes", "inspect", "platform", "shutil", "glob", "fnmatch", "traceback",
        "unittest", "doctest", "xml", "html", "socket", "ssl", "queue",
        "codecs", "shlex", "winreg",
    }


def resolve_local_module(module_name: str, base_dir: Path) -> Optional[Path]:
    rel = Path(*module_name.split("."))
    for candidate in (base_dir / f"{rel}.py", base_dir / rel / "__init__.py"):
        if candidate.exists():
            return candidate
    return None


def _importuse_from_import(node: ast.Import, file_path: Path, source_lines: List[str]) -> List[ImportUse]:
    out: List[ImportUse] = []
    for alias in node.names:
        top = alias.name.split(".")[0]
        lineno = getattr(node, "lineno", 1) or 1
        # Prefer a clean synthetic representation over full line text.
        if alias.asname:
            detail = f"import {alias.name} as {alias.asname}"
        else:
            detail = f"import {alias.name}"
        out.append(ImportUse(top=top, path=file_path, lineno=lineno, detail=detail))
    return out


def _importuse_from_importfrom(node: ast.ImportFrom, file_path: Path, source_lines: List[str]) -> List[ImportUse]:
    out: List[ImportUse] = []
    if node.module is None:
        return out
    top = node.module.split(".")[0]
    lineno = getattr(node, "lineno", 1) or 1

    # Build a readable "from X import a, b as c" string
    parts: List[str] = []
    for a in node.names:
        if a.asname:
            parts.append(f"{a.name} as {a.asname}")
        else:
            parts.append(a.name)
    names_s = ", ".join(parts) if parts else "*"
    detail = f"from {node.module} import {names_s}"
    out.append(ImportUse(top=top, path=file_path, lineno=lineno, detail=detail))
    return out


def imported_top_level_packages_with_locations(entry_file: Path) -> Dict[str, List[ImportUse]]:
    visited: Set[Path] = set()
    found: Dict[str, List[ImportUse]] = {}

    def add_use(u: ImportUse) -> None:
        found.setdefault(u.top, []).append(u)

    def analyze_file(file_path: Path) -> None:
        if file_path in visited:
            return
        visited.add(file_path)

        try:
            source = file_path.read_text(encoding="utf-8")
            source_lines = source.splitlines()
            tree = ast.parse(source, filename=str(file_path))
        except Exception:
            return

        base_dir = file_path.parent

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                uses = _importuse_from_import(node, file_path, source_lines)
                for u in uses:
                    add_use(u)
                    local = resolve_local_module(u.top, base_dir)  # only for recursion decision below
                for alias in node.names:
                    local = resolve_local_module(alias.name, base_dir)
                    if local:
                        analyze_file(local)

            elif isinstance(node, ast.ImportFrom):
                uses = _importuse_from_importfrom(node, file_path, source_lines)
                for u in uses:
                    add_use(u)
                if node.module:
                    local = resolve_local_module(node.module, base_dir)
                    if local:
                        analyze_file(local)

    analyze_file(entry_file)
    return found


def _index_local_modules_under(root: Path) -> Set[str]:
    found: Set[str] = set()
    if not root.exists():
        return found

    for init_file in root.glob("*/__init__.py"):
        found.add(init_file.parent.name)

    for py in root.glob("*.py"):
        found.add(py.stem)

    return found


def index_local_modules(project_root: Path) -> Set[str]:
    roots: List[Path] = [project_root]

    for name in ["src", "lib", "app", "python", "package", "packages"]:
        p = project_root / name
        if p.exists() and p.is_dir():
            roots.append(p)

    locals_found: Set[str] = set()
    for r in roots:
        locals_found |= _index_local_modules_under(r)

    return locals_found


def try_importable_as_local(name: str, project_root: Path) -> bool:
    added: List[str] = []
    try:
        sp = str(project_root)
        if sp and sp not in sys.path:
            sys.path.insert(0, sp)
            added.append(sp)
        __import__(name)
        return True
    except Exception:
        return False
    finally:
        for sp in added:
            try:
                sys.path.remove(sp)
            except ValueError:
                pass


def compute_missing_used_imports(
    used_import_names: Set[str],
    std: Set[str],
    local_index: Set[str],
    import_to_dists: Dict[str, List[str]],
    project_root: Path,
) -> Set[str]:
    missing: Set[str] = set()
    for name in used_import_names:
        if not name or name in std:
            continue
        if name in local_index:
            continue
        if import_to_dists.get(name):
            continue
        if try_importable_as_local(name, project_root):
            continue
        try:
            __import__(name)
            continue
        except Exception:
            missing.add(name)
    return missing


def run_missing_imports_report(entry: Path, project_root: Path) -> None:
    print("MISSING (used but not installed):")
    print("------------------------------")

    if packages_distributions is None:
        print('(skipped: Python 3.8+ required for importlib.metadata.packages_distributions())\n')
        return

    std = stdlib_names()
    local_index = index_local_modules(project_root)

    uses_by_top = imported_top_level_packages_with_locations(entry)
    used_import_names = set(uses_by_top.keys())

    import_to_dists: Dict[str, List[str]] = packages_distributions() or {}

    missing = compute_missing_used_imports(
        used_import_names=used_import_names,
        std=std,
        local_index=local_index,
        import_to_dists=import_to_dists,
        project_root=project_root,
    )

    if not missing:
        print("(none)\n")
        return

    # Print first occurrence per missing top-level import in Sublime-clickable format
    for top in sorted(missing):
        uses = uses_by_top.get(top) or []
        if uses:
            u0 = sorted(uses, key=lambda u: (str(u.path).lower(), u.lineno))[0]
            print(f'File "{u0.path}", line {u0.lineno}, {u0.detail} (missing)')
        else:
            print(f'File "<unknown>", line 0, {top} (missing)')
    print()


# ----------------------------
# Main
# ----------------------------

def main() -> int:
    if len(sys.argv) != 2:
        usage_exit()

    entry = Path(sys.argv[1]).expanduser()
    if not entry.exists():
        usage_exit(f"Entry file not found: {entry}")

    entry = entry.resolve()
    root = entry.parent

    ignore_dirs = set(DEFAULT_IGNORE_DIRS)

    files = sorted(iter_files(root, ignore_dirs))
    candidates = build_candidates(root, files)
    text_sources = [p for p in files if is_text_source(p)]
    py_sources = [p for p in files if p.suffix.lower() == ".py"]

    references: Dict[str, List[str]] = {c.rel: [] for c in candidates}

    for src in text_sources:
        src_rel = str(src.relative_to(root))
        text = safe_read_text(src)
        if not text:
            continue
        hay = text.lower()

        for c in candidates:
            if src == c.path:
                continue
            if any(tok in hay for tok in c.tokens):
                references[c.rel].append(src_rel)

    unused_rels = [c.rel for c in candidates if not references[c.rel]]

    # Order requested:
    # 1) UNUSED functions
    # 2) MISSING imports
    # 3) UNUSED files

    print_unused_functions_report(project_root=root, py_files=py_sources)

    if entry.suffix.lower() == ".py":
        run_missing_imports_report(entry=entry, project_root=root)
    else:
        print("MISSING (used but not installed):")
        print("------------------------------")
        print("(skipped: entry is not a .py file)\n")

    print_unused_grouped(unused_rels)


    return 0


if __name__ == "__main__":
    raise SystemExit(main())
