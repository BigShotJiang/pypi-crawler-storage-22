from nexo.schemas.resource import Resource, ResourceIdentifier


USER_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="user", name="User", slug="users")],
    details=None,
)
