from uuid import UUID


IdentifierValueType = int | str | UUID
