from nexo.schemas.resource import Resource, ResourceIdentifier

ANALYSIS_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="analysis", name="Analysis", slug="analyses")],
    details=None,
)
