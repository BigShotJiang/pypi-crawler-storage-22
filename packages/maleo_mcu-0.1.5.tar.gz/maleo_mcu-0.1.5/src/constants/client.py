from nexo.schemas.resource import Resource, ResourceIdentifier

CLIENT_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="client", name="Client", slug="clients")],
    details=None,
)
