from uuid import UUID


IdentifierValueType = int | UUID
ValueType = bool | float | int | str | UUID
OptValueType = ValueType | None
