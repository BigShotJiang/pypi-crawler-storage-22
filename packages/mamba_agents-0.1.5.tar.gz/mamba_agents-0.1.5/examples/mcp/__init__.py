"""MCP integration examples."""
