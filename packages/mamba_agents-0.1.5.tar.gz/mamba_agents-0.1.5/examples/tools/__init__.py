"""Tool-related examples."""
