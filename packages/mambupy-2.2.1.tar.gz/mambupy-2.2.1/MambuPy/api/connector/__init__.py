""" MambuPy's Mambu REST API v2 connectors package.

.. autosummary::
   :toctree: _autosummary

    MambuPy.api.connector.mambuconnector
    MambuPy.api.connector.rest
"""
