"""Utils package.

Funtional Scripts

.. autosummary::
   :toctree: _autosummary

    MambuPy.utils.userdeactivate
"""
