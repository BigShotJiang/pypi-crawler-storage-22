# ruff: noqa: F405

"""
    Django settings for production
"""

from .base import *  # noqa
