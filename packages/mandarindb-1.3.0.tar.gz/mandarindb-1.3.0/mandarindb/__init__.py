import json as _json
import os as _os
import io as _io
import typing as _typing

def mandarinCode(text: str):
    mapping = {
        '0': 'A',
        '1': 'B',
        '2': 'C',
        '3': 'D',
        '4': 'E',
        '5': 'F',
        '6': 'G',
        '7': 'H',
        '8': 'I',
        '9': 'J',
        ' ': '-'
    }
    ordResult = []
    for c in text:
        ordResult.append(str(ord(c)))
    ordResult = ' '.join(ordResult)
    result = ''
    for c in ordResult:
        result += mapping[c]
    return result

def unMandarinCode(mdrCode: str):
    mapping = {
        'A': '0',
        'B': '1',
        'C': '2',
        'D': '3',
        'E': '4',
        'F': '5',
        'G': '6',
        'H': '7',
        'I': '8',
        'J': '9'
    }
    chrs = mdrCode.split("-")
    res = ''
    for c in chrs:
        resultChar = ''
        for i in c:
            resultChar += mapping[i]
        res += chr(int(resultChar))
    return res

class MandarinJson:
    def __init__(self):
        self.filename: str = None
    def load(self, filename: str) -> _typing.NoReturn:
        if self.filename:
            raise MandarinError("File is already loaded.")
        self.filename = filename
    def write(self, data: dict, mode: _typing.Literal['w', 'a'] = 'w') -> _typing.NoReturn:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        textData = mandarinCode(_json.dumps(data))
        tempFile = open(self.filename, mode)
        tempFile.write(textData)
        tempFile.close()
    def close(self) -> _typing.NoReturn:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        self.filename = None
    def read(self) -> dict:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        tempFile = open(self.filename, 'r')
        text = unMandarinCode(tempFile.read())
        tempFile.close()
        return _json.loads(text)
class MandarinData:
    def __init__(self):
        self.filename: str = None
    def load(self, filename: str) -> _typing.NoReturn:
        if self.filename:
            raise MandarinError("File is already loaded.")
        self.filename = filename
    def write(self, data: str, mode: _typing.Literal['w', 'a'] = 'w') -> _typing.NoReturn:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        textData = mandarinCode(data)
        tempFile = open(self.filename, mode)
        tempFile.write(textData)
        tempFile.close()
    def close(self) -> _typing.NoReturn:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        self.filename = None
    def read(self) -> dict:
        if not self.filename:
            raise MandarinError("Please, load a file.")
        tempFile = open(self.filename, 'r')
        text = unMandarinCode(tempFile.read())
        tempFile.close()
        return text

class MandarinError(Exception):
    def __init__(self, msg):
        super().__init__(msg)
