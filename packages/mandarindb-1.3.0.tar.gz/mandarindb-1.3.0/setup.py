from setuptools import setup, find_packages

name = 'mandarindb'

setup(
    name=name,
    version='1.3.0',
    description='Mandarin Databases',
    long_description='# Mandarin databases',
    long_description_content_type='text/markdown',
    install_requires=[],
    author='kanderusss',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.6',
    author_email='kanderusss.dev@gmail.com',
    url=f"https://pypi.org/project/{name}/",
    project_urls={
        "Documentation": f"https://pypi.org/project/{name}/",
    },
    packages=find_packages(),
    license='MIT'
)
