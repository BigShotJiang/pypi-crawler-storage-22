# Tests for maniple
