"""Maniscope Streamlit evaluation application."""
