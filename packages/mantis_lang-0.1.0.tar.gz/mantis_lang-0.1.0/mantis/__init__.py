# mantis/__init__.py

__version__ = "0.1.0"
from .compiler import compile_source
from .loader import run, run_bytes
