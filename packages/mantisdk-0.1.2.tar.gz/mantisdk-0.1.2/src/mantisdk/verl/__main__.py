# Copyright (c) Microsoft. All rights reserved.

from .entrypoint import main

if __name__ == "__main__":
    main()
