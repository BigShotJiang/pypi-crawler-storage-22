# Copyright (c) Microsoft. All rights reserved.

__version__ = "0.1.6"

from .adapter import *
from .algorithm import *
from .client import MantisdkClient, DevTaskLoader  # deprecated  # type: ignore
from .config import *
from .emitter import *
from .env_var import *
from .execution import *
from .litagent import *

# LLMProxy requires litellm[proxy] which has strict dependency pins.
# Make import optional to avoid conflicts for users who don't need this feature.
# Install with: pip install 'mantisdk[proxy]'
try:
    from .llm_proxy import *
except ImportError:
    pass  # LLMProxy not available without litellm[proxy] extras

from .logging import configure_logger  # deprecated  # type: ignore
from .logging import setup as setup_logging  # type: ignore
from .logging import setup_module as setup_module_logging  # type: ignore
from .runner import *
from .server import MantisdkServer  # deprecated  # type: ignore
from .store import *
from .tracer import *

# Trainer requires LLMProxy which requires litellm[proxy]
# Make import optional to avoid conflicts for users who don't need training features.
try:
    from .trainer import *
except ImportError:
    pass  # Trainer not available without litellm[proxy] extras

from .types import *
