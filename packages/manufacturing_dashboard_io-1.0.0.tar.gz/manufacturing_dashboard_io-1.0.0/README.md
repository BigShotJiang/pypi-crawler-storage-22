# Manufacturing Dashboard IO

[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/manufacturing-dashboard-io.svg)](https://badge.fury.io/py/manufacturing-dashboard-io)

A professional manufacturing dashboard with real-time analytics, interactive charts, and comprehensive monitoring capabilities.

## 🏭 Features

- **Real-time Production Monitoring**: Track daily production output in real-time
- **Interactive Charts**: Production trends, quality breakdown, energy consumption analysis
- **Machine Status Tracking**: Monitor operational status of all machines
- **Team Performance Metrics**: View top performers and team statistics
- **Maintenance Scheduling**: Track and schedule maintenance tasks
- **Password Protection**: Secure access with encrypted authentication
- **Dark/Light Mode**: Beautiful UI with theme customization
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Keyboard Shortcuts**: Quick access to common functions
- **Multi-language Support Ready**: Easy to extend for multiple languages

## 📋 System Requirements

- Python 3.7 or higher
- 50MB disk space
- Any modern web browser (Chrome, Firefox, Safari, Edge)

## 🚀 Installation

### Quick Start

```bash
pip install manufacturing-dashboard-io
```

### From Source

```bash
git clone https://github.com/mahdi123-tech/manufacturing-dashboard-io.git
cd manufacturing-dashboard-io
pip install -e .
```

## 🎯 Usage

### Start the Dashboard

```bash
manufacturing start
```

The dashboard will automatically open in your default browser at `http://localhost:8000`

### Command Options

```bash
# Custom port
manufacturing start --port 9000

# Listen on all interfaces
manufacturing start --host 0.0.0.0

# Don't auto-open browser
manufacturing start --no-browser

# Show version
manufacturing --version

# Show help
manufacturing --help
```

## 🔐 Default Credentials

**Password:** `play with mahdi`

> ⚠️ **Important**: Change the password in production by modifying `manufacturing_dashboard/web/js/script.js`

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+K` / `Cmd+K` | Logout |
| `Ctrl+T` / `Cmd+T` | Toggle Dark/Light Mode |
| `Ctrl+E` / `Cmd+E` | Export Data |

## 📊 Dashboard Sections

### 1. Key Metrics
- **Total Units**: Daily production output
- **Efficiency Rate**: Operational efficiency percentage
- **Defect Rate**: Quality control metrics
- **Machine Uptime**: System availability

### 2. Analytics
- **Production Trend**: 7-day production volume with bar charts
- **Quality Breakdown**: Defects distribution with pie charts
- **Energy Consumption**: Hourly energy usage with line charts
- **Shift Distribution**: Workers per shift visualization

### 3. Monitoring
- **Machine Status**: Real-time operational status
- **Team Performance**: Top performers ranking
- **Maintenance Schedule**: Upcoming maintenance tasks
- **Active Alerts**: System notifications and warnings

### 4. Activity
- **Recent Events**: Production and system events timeline
- **Daily Target**: Production goal progress tracker

## 🎨 Customization

### Change the Password

Edit `manufacturing_dashboard/web/js/script.js`:

```javascript
// Find this line (around line 30):
this.correctPasswordHash = this.hashPassword("play with mahdi");

// Change to your desired password:
this.correctPasswordHash = this.hashPassword("your-new-password");
```

### Customize Colors

Edit `manufacturing_dashboard/web/css/styles.css`:

```css
:root {
    --color-primary: #000;        /* Primary color */
    --color-success: #4CAF50;     /* Success (green) */
    --color-warning: #FF9800;     /* Warning (orange) */
    --color-error: #F44336;       /* Error (red) */
    --color-info: #2196F3;        /* Info (blue) */
}
```

### Add Custom Data

Modify the data in `manufacturing_dashboard/web/js/script.js` in the `ChartDrawer` class:

```javascript
static drawProductionChart() {
    const data = [14200, 15100, 16800, 17500, 16200, 18900, 15487];
    // Modify the data array with your actual values
}
```

## 📦 Project Structure

```
manufacturing-dashboard-io/
├── manufacturing_dashboard/
│   ├── __init__.py              # Package initialization
│   ├── server.py                # HTTP server implementation
│   ├── cli.py                   # Command-line interface
│   ├── utils.py                 # Utility functions
│   └── web/                     # Web assets
│       ├── index.html           # Login page
│       ├── dashboard.html       # Main dashboard
│       ├── css/
│       │   └── styles.css       # All styling
│       └── js/
│           └── script.js        # Frontend logic
├── setup.py                     # Package configuration
├── requirements.txt             # Dependencies
├── LICENSE                      # MIT License
├── README.md                    # This file
└── MANIFEST.in                  # Package manifest

```

## 🔧 Development

### Local Development Setup

```bash
# Clone the repository
git clone https://github.com/mahdi123-tech/manufacturing-dashboard-io.git
cd manufacturing-dashboard-io

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e .

# Run the dashboard
manufacturing start
```

### Running Tests

```bash
# Run all tests
python -m pytest

# Run with coverage
python -m pytest --cov=manufacturing_dashboard
```

## 📤 Publishing to PyPI

### Prerequisites

1. Register account at [PyPI.org](https://pypi.org)
2. Install required tools:

```bash
pip install build twine
```

### Build the Package

```bash
cd manufacturing-dashboard-io
python -m build
```

This creates `dist/` directory with:
- `manufacturing-dashboard-io-1.0.0.tar.gz` (source distribution)
- `manufacturing_dashboard_io-1.0.0-py3-none-any.whl` (wheel)

### Upload to PyPI

```bash
# Upload to PyPI (requires credentials)
python -m twine upload dist/*

# Or with specific credentials
python -m twine upload dist/* -u __token__ -p your-pypi-token
```

### Test Upload (TestPyPI)

```bash
# First time setup: register on testpypi.org
# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Install from TestPyPI to verify
pip install --index-url https://test.pypi.org/simple/ manufacturing-dashboard-io
```

## 🐛 Troubleshooting

### Port Already in Use

```bash
# Use a different port
manufacturing start --port 9000

# Or kill existing process
# On Linux/Mac: lsof -i :8000 | grep LISTEN | awk '{print $2}' | xargs kill -9
# On Windows: netstat -ano | findstr :8000
```

### Browser Doesn't Open Automatically

```bash
# Use --no-browser flag and open manually
manufacturing start --no-browser
# Then visit http://localhost:8000
```

### Wrong Password Error

The default password is: `play with mahdi` (case-sensitive)

### Dashboard Not Loading

1. Check console for errors (F12)
2. Verify Python version: `python --version`
3. Verify installation: `pip show manufacturing-dashboard-io`
4. Reinstall: `pip install --upgrade manufacturing-dashboard-io`

## 📚 Additional Resources

- **GitHub**: [https://github.com/mahdi123-tech/manufacturing-dashboard-io](https://github.com/mahdi123-tech/manufacturing-dashboard-io)
- **Issues**: [Report bugs or request features](https://github.com/mahdi123-tech/manufacturing-dashboard-io/issues)
- **Wiki**: [Documentation and guides](https://github.com/mahdi123-tech/manufacturing-dashboard-io/wiki)

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 Changelog

### Version 1.0.0 (2025-02-04)
- Initial release
- Real-time production monitoring
- Interactive charts and analytics
- Password protection
- Dark/Light mode support
- Responsive design

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Manufacturing Systems**
- Email: info@manufacturingdashboard.io
- GitHub: [@mahdi123-tech](https://github.com/mahdi123-tech)

## 🙏 Acknowledgments

- Built with Python 3.7+
- Inspired by modern manufacturing analytics platforms
- Thanks to the open-source community

## ⭐ Support

If you find this project useful, please consider giving it a star on GitHub!

---

**Happy Manufacturing! 🏭**
