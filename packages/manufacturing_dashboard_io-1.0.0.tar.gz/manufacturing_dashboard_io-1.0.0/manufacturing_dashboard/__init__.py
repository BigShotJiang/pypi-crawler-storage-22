"""
Manufacturing Dashboard IO - Professional Manufacturing Analytics Dashboard

A complete manufacturing dashboard with real-time analytics, interactive charts,
password protection, and dark/light mode support.

Features:
    - Real-time production monitoring
    - Interactive charts and analytics
    - Password-protected access
    - Dark/Light mode toggle
    - Responsive design
    - Multi-machine monitoring
    - Team performance tracking
    - Energy consumption analysis

Usage:
    >>> from manufacturing_dashboard import DashboardServer
    >>> server = DashboardServer()
    >>> server.start()

Command Line:
    $ manufacturing start
    $ manufacturing start --port 8000
    $ manufacturing start --host 0.0.0.0
"""

__title__ = "manufacturing-dashboard-io"
__version__ = "1.0.0"
__author__ = "Manufacturing Systems"
__author_email__ = "info@manufacturingdashboard.io"
__license__ = "MIT"
__copyright__ = "Copyright (c) 2025 Manufacturing Systems"
__description__ = "Professional manufacturing dashboard with real-time analytics and monitoring"
__url__ = "https://github.com/mahdi123-tech/manufacturing-dashboard-io"

# Version tuple for version comparison
VERSION = tuple(map(int, __version__.split(".")))

# Import main classes
from .server import DashboardServer
from .utils import open_browser, get_web_root

__all__ = [
    "DashboardServer",
    "open_browser",
    "get_web_root",
    "__version__",
    "__author__",
]
