"""
Command Line Interface for Manufacturing Dashboard IO

This module provides the CLI entry point for the manufacturing dashboard
"""

import sys
import argparse
from . import __version__
from .server import DashboardServer
from .utils import print_help, check_python_version


def main():
    """Main CLI entry point"""
    
    # Check Python version
    check_python_version()
    
    # Create argument parser
    parser = argparse.ArgumentParser(
        prog="manufacturing",
        description="Manufacturing Dashboard IO - Professional Manufacturing Analytics",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  manufacturing start                    # Start dashboard on default port 8000
  manufacturing start --port 9000        # Start on custom port
  manufacturing start --host 0.0.0.0     # Listen on all interfaces
  manufacturing start --no-browser       # Don't auto-open browser
  manufacturing --version                # Show version
  manufacturing --help                   # Show this help message
        """
    )
    
    # Add subparsers for commands
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Start command
    start_parser = subparsers.add_parser(
        "start",
        help="Start the Manufacturing Dashboard server"
    )
    start_parser.add_argument(
        "--port", "-p",
        type=int,
        default=8000,
        help="Port to run the server on (default: 8000)"
    )
    start_parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)"
    )
    start_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Don't automatically open browser"
    )
    
    # Version flag
    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"%(prog)s {__version__}"
    )
    
    # Parse arguments
    args = parser.parse_args()
    
    # Handle commands
    if args.command == "start":
        start_dashboard(args)
    elif args.command is None:
        # If no command, show help
        parser.print_help()
    else:
        parser.print_help()


def start_dashboard(args):
    """Start the dashboard server"""
    
    print("\n" + "="*70)
    print("🏭 Manufacturing Dashboard IO - Starting Server")
    print("="*70)
    
    # Validate port
    if not (1 <= args.port <= 65535):
        print(f"❌ Error: Port must be between 1 and 65535")
        sys.exit(1)
    
    # Create and start server
    server = DashboardServer(
        host=args.host,
        port=args.port,
        auto_open=not args.no_browser
    )
    
    try:
        server.start()
    except KeyboardInterrupt:
        print("\n✓ Server stopped")
        sys.exit(0)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


# Alternative entry point for manufacturing-dashboard command
def main_alt():
    """Alternative entry point"""
    main()


if __name__ == "__main__":
    main()
