"""
Server module for Manufacturing Dashboard IO

Handles the HTTP server setup and management
"""

import os
import sys
import socket
import subprocess
import time
import webbrowser
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler


class DashboardHTTPHandler(SimpleHTTPRequestHandler):
    """Custom HTTP request handler with proper content types"""
    
    def do_GET(self):
        """Override GET to handle routing properly"""
        if self.path == "/" or self.path == "":
            self.path = "/index.html"
        
        return super().do_GET()
    
    def end_headers(self):
        """Add cache control headers"""
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()


class DashboardServer:
    """Manufacturing Dashboard Server Manager"""
    
    def __init__(self, host="127.0.0.1", port=8000, auto_open=True):
        """
        Initialize the Dashboard Server
        
        Args:
            host (str): The host to bind to (default: 127.0.0.1)
            port (int): The port to listen on (default: 8000)
            auto_open (bool): Automatically open browser (default: True)
        """
        self.host = host
        self.port = port
        self.auto_open = auto_open
        self.server = None
        self.web_root = self._get_web_root()
    
    def _get_web_root(self):
        """Get the web root directory"""
        # The web root is in the same package
        return Path(__file__).parent / "web"
    
    def _is_port_available(self):
        """Check if the port is available"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            result = sock.connect_ex((self.host, self.port))
            return result != 0
        finally:
            sock.close()
    
    def _find_available_port(self):
        """Find an available port starting from the default"""
        port = self.port
        while not self._is_port_available() and port < self.port + 100:
            port += 1
        return port
    
    def start(self):
        """Start the Manufacturing Dashboard Server"""
        try:
            # Check if port is available
            if not self._is_port_available():
                print(f"⚠️  Port {self.port} is in use, finding an available port...")
                self.port = self._find_available_port()
            
            # Change to web root directory
            original_dir = os.getcwd()
            os.chdir(self.web_root)
            
            # Create HTTP server
            self.server = HTTPServer((self.host, self.port), DashboardHTTPHandler)
            
            # Print startup message
            self._print_startup_message()
            
            # Auto-open browser if requested
            if self.auto_open:
                self._open_browser()
            
            # Start serving
            try:
                self.server.serve_forever()
            except KeyboardInterrupt:
                print("\n✓ Server stopped gracefully")
            finally:
                self.server.server_close()
                os.chdir(original_dir)
        
        except Exception as e:
            print(f"❌ Error starting server: {e}")
            sys.exit(1)
    
    def _open_browser(self):
        """Open the dashboard in the default browser"""
        url = f"http://{self.host}:{self.port}"
        time.sleep(1)  # Give server a moment to start
        try:
            webbrowser.open(url)
            print(f"✓ Opening browser: {url}")
        except Exception as e:
            print(f"⚠️  Could not open browser automatically: {e}")
            print(f"📍 Please visit: {url}")
    
    def _print_startup_message(self):
        """Print startup information"""
        url = f"http://{self.host}:{self.port}"
        
        print("\n" + "="*60)
        print("🏭 Manufacturing Dashboard IO")
        print("="*60)
        print(f"✓ Server is running on: {url}")
        print(f"✓ Dashboard Location: {self.web_root}")
        print("\n📝 Login Information:")
        print("   Password: play with mahdi")
        print("\n⌨️  Keyboard Shortcuts:")
        print("   Ctrl+K (Cmd+K)  → Logout")
        print("   Ctrl+T (Cmd+T)  → Toggle Dark/Light Mode")
        print("   Ctrl+E (Cmd+E)  → Export Data")
        print("\n📊 Features:")
        print("   ✓ Real-time production monitoring")
        print("   ✓ Interactive charts and analytics")
        print("   ✓ Dark/Light mode support")
        print("   ✓ Responsive design")
        print("   ✓ Machine status tracking")
        print("   ✓ Team performance metrics")
        print("\n💡 Tips:")
        print("   - Press Ctrl+C to stop the server")
        print("   - Use Ctrl+T to switch themes")
        print("   - Check browser console (F12) for debugging")
        print("\n" + "="*60)
        print("Press Ctrl+C to stop the server\n")


def get_web_root():
    """Get the web root directory path"""
    return Path(__file__).parent / "web"


def open_browser(host="127.0.0.1", port=8000):
    """Open the dashboard in the browser"""
    url = f"http://{host}:{port}"
    try:
        webbrowser.open(url)
        return True
    except Exception as e:
        print(f"Error opening browser: {e}")
        return False
