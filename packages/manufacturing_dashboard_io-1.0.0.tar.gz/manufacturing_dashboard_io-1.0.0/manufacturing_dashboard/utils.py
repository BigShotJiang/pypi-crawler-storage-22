"""
Utility functions for Manufacturing Dashboard IO
"""

import os
import sys
import webbrowser
from pathlib import Path


def get_web_root():
    """Get the web root directory"""
    return Path(__file__).parent / "web"


def open_browser(url):
    """
    Open URL in the default browser
    
    Args:
        url (str): The URL to open
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        webbrowser.open(url)
        return True
    except Exception as e:
        print(f"Error opening browser: {e}")
        return False


def check_python_version():
    """Check if Python version is supported"""
    if sys.version_info < (3, 7):
        print("❌ Python 3.7+ is required")
        sys.exit(1)


def print_version():
    """Print package version"""
    from . import __version__
    print(f"manufacturing-dashboard-io version {__version__}")


def print_help():
    """Print help message"""
    help_text = """
Manufacturing Dashboard IO - CLI Help

Usage:
    manufacturing <command> [options]
    manufacturing-dashboard <command> [options]

Commands:
    start          Start the dashboard server
    help           Show this help message
    version        Show version information

Options for 'start':
    --port PORT    Set the port (default: 8000)
    --host HOST    Set the host (default: 127.0.0.1)
    --no-browser   Don't auto-open browser
    -p, --port     Specify custom port
    -h, --host     Specify custom host

Examples:
    manufacturing start
    manufacturing start --port 9000
    manufacturing start --host 0.0.0.0
    manufacturing start --no-browser
    manufacturing help
    manufacturing version

For more information, visit: https://github.com/mahdi123-tech/manufacturing-dashboard-io
"""
    print(help_text)


def format_bytes(bytes_value):
    """Format bytes to human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_value < 1024.0:
            return f"{bytes_value:.1f}{unit}"
        bytes_value /= 1024.0
    return f"{bytes_value:.1f}TB"
