"""
Web module for Manufacturing Dashboard IO

Contains web assets (HTML, CSS, JS)
"""
