// ===========================
// CHART DRAWING FUNCTIONS
// ===========================

class ChartDrawer {
    // Draw Bar Chart for Production
    static drawProductionChart() {
        const canvas = document.getElementById('productionChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const data = [14200, 15100, 16800, 17500, 16200, 18900, 15487];
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const maxValue = 20000;
        const padding = 40;
        const barWidth = (canvas.width - padding * 2 - 70) / data.length;
        
        // Clear canvas
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-bg-dark');
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw axes
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-border');
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(padding, canvas.height - padding);
        ctx.lineTo(canvas.width - 20, canvas.height - padding);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(padding, 20);
        ctx.lineTo(padding, canvas.height - padding);
        ctx.stroke();
        
        // Draw bars
        ctx.fillStyle = '#4CAF50';
        data.forEach((value, index) => {
            const x = padding + 15 + (index * (barWidth + 5));
            const height = (value / maxValue) * (canvas.height - padding * 1.5);
            const y = canvas.height - padding - height;
            ctx.fillRect(x, y, barWidth - 5, height);
            
            // Draw labels
            ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text');
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(labels[index], x + barWidth/2 - 2, canvas.height - padding + 20);
            
            // Draw values on bars
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText(value.toLocaleString(), x + barWidth/2 - 2, y - 5);
        });
    }
    
    // Draw Pie Chart for Quality
    static drawQualityChart() {
        const canvas = document.getElementById('qualityChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const data = [45, 25, 20, 10];
        const labels = ['Assembly', 'Paint', 'Welding', 'Other'];
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A'];
        const centerX = canvas.width / 3;
        const centerY = canvas.height / 2;
        const radius = 50;
        
        // Clear canvas
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-bg-dark');
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        let currentAngle = -Math.PI / 2;
        data.forEach((percentage, index) => {
            const sliceAngle = (percentage / 100) * 2 * Math.PI;
            
            // Draw slice
            ctx.fillStyle = colors[index];
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            ctx.closePath();
            ctx.fill();
            
            // Draw label
            const labelAngle = currentAngle + sliceAngle / 2;
            const labelX = centerX + Math.cos(labelAngle) * (radius + 30);
            const labelY = centerY + Math.sin(labelAngle) * (radius + 30);
            
            ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text');
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(percentage + '%', labelX, labelY);
            
            currentAngle += sliceAngle;
        });
        
        // Draw legend
        let legendY = 20;
        labels.forEach((label, index) => {
            ctx.fillStyle = colors[index];
            ctx.fillRect(canvas.width - 120, legendY, 12, 12);
            
            ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text');
            ctx.font = '11px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(label + ' ' + data[index] + '%', canvas.width - 105, legendY + 10);
            
            legendY += 20;
        });
    }
    
    // Draw Line Chart for Energy
    static drawEnergyChart() {
        const canvas = document.getElementById('energyChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const data = [450, 420, 380, 350, 380, 420, 460, 490];
        const labels = ['0:00', '4:00', '8:00', '12:00', '16:00', '20:00', '23:00', '24:00'];
        const maxValue = 500;
        const padding = 40;
        const pointSpacing = (canvas.width - padding * 2) / (data.length - 1);
        
        // Clear canvas
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-bg-dark');
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw grid
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 4; i++) {
            const y = padding + (i * (canvas.height - padding * 2) / 4);
            ctx.beginPath();
            ctx.moveTo(padding, y);
            ctx.lineTo(canvas.width - 20, y);
            ctx.stroke();
        }
        
        // Draw axes
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-border');
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(padding, canvas.height - padding);
        ctx.lineTo(canvas.width - 20, canvas.height - padding);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(padding, 20);
        ctx.lineTo(padding, canvas.height - padding);
        ctx.stroke();
        
        // Draw line with fill
        ctx.fillStyle = 'rgba(33, 150, 243, 0.2)';
        ctx.beginPath();
        ctx.moveTo(padding, canvas.height - padding);
        
        data.forEach((value, index) => {
            const x = padding + (index * pointSpacing);
            const height = (value / maxValue) * (canvas.height - padding * 1.5);
            const y = canvas.height - padding - height;
            ctx.lineTo(x, y);
        });
        
        ctx.lineTo(canvas.width - 20, canvas.height - padding);
        ctx.closePath();
        ctx.fill();
        
        // Draw line
        ctx.strokeStyle = '#2196F3';
        ctx.lineWidth = 3;
        ctx.beginPath();
        data.forEach((value, index) => {
            const x = padding + (index * pointSpacing);
            const height = (value / maxValue) * (canvas.height - padding * 1.5);
            const y = canvas.height - padding - height;
            if (index === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.stroke();
        
        // Draw points
        ctx.fillStyle = '#2196F3';
        data.forEach((value, index) => {
            const x = padding + (index * pointSpacing);
            const height = (value / maxValue) * (canvas.height - padding * 1.5);
            const y = canvas.height - padding - height;
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
        });
        
        // Draw labels
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text');
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        labels.forEach((label, index) => {
            const x = padding + (index * pointSpacing);
            ctx.fillText(label, x, canvas.height - padding + 18);
        });
    }
    
    // Draw Horizontal Bar Chart for Shifts
    static drawShiftChart() {
        const canvas = document.getElementById('shiftChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const data = [45, 55, 35];
        const labels = ['Shift 1', 'Shift 2', 'Shift 3'];
        const colors = ['#FF9800', '#2196F3', '#9C27B0'];
        const maxValue = 60;
        const barHeight = 30;
        const padding = 40;
        
        // Clear canvas
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-bg-dark');
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw bars
        data.forEach((value, index) => {
            const y = padding + (index * (barHeight + 15));
            const width = (value / maxValue) * (canvas.width - padding * 3);
            
            // Draw bar
            ctx.fillStyle = colors[index];
            ctx.fillRect(padding + 50, y, width, barHeight);
            
            // Draw label
            ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text');
            ctx.font = 'bold 12px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(labels[index], padding + 40, y + barHeight / 2 + 5);
            
            // Draw value
            ctx.fillStyle = '#fff';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(value + ' workers', padding + 55 + width + 5, y + barHeight / 2 + 5);
        });
    }
}

// Function to initialize all charts
function initializeCharts() {
    setTimeout(() => {
        ChartDrawer.drawProductionChart();
        ChartDrawer.drawQualityChart();
        ChartDrawer.drawEnergyChart();
        ChartDrawer.drawShiftChart();
    }, 100);
}

// Redraw charts on theme change
function redrawChartsOnThemeChange() {
    const originalToggleTheme = window.toggleTheme;
    window.toggleTheme = function() {
        originalToggleTheme();
        setTimeout(() => {
            initializeCharts();
        }, 300);
    };
}

// ===========================
// PASSWORD ENCRYPTION & AUTH
// ===========================

class PasswordManager {
    constructor() {
        this.correctPasswordHash = this.hashPassword("play with mahdi");
    }

    hashPassword(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return Math.abs(hash).toString(16);
    }

    verifyPassword(inputPassword) {
        const inputHash = this.hashPassword(inputPassword);
        return inputHash === this.correctPasswordHash;
    }
}

const passwordManager = new PasswordManager();

// ===========================
// LOGIN PAGE FUNCTIONALITY
// ===========================

function initializeLoginPage() {
    const passwordForm = document.getElementById('passwordForm');
    const passwordInput = document.getElementById('passwordInput');
    const errorMessage = document.getElementById('errorMessage');

    if (passwordForm) {
        passwordForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const enteredPassword = passwordInput.value.trim();

            if (passwordManager.verifyPassword(enteredPassword)) {
                errorMessage.textContent = '✓ Access granted! Redirecting...';
                errorMessage.style.color = '#4CAF50';
                
                sessionStorage.setItem('authenticated', 'true');
                
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 800);
            } else {
                errorMessage.textContent = '✗ Access denied! Wrong password.';
                errorMessage.style.color = '#F44336';
                passwordInput.value = '';
                
                passwordForm.style.animation = 'shake 0.5s ease-in-out';
                setTimeout(() => {
                    passwordForm.style.animation = 'none';
                }, 500);
            }
        });

        if (sessionStorage.getItem('authenticated') === 'true') {
            window.location.href = 'dashboard.html';
        }
    }
}

// ===========================
// DASHBOARD PAGE FUNCTIONALITY
// ===========================

function checkAuthentication() {
    if (sessionStorage.getItem('authenticated') !== 'true' && window.location.pathname.includes('dashboard')) {
        window.location.href = 'index.html';
        return false;
    }
    return true;
}

function initializeDashboard() {
    if (!checkAuthentication()) return;

    initializeTheme();
    initializeCharts();
    redrawChartsOnThemeChange();

    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            sessionStorage.removeItem('authenticated');
            
            document.body.style.opacity = '0';
            document.body.style.transition = 'opacity 0.5s ease-out';
            
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 500);
        });
    }

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }

    startLiveDataUpdates();
}

// ===========================
// THEME MANAGEMENT
// ===========================

function initializeTheme() {
    const savedTheme = localStorage.getItem('dashboardTheme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    let isDarkMode = false;
    
    if (savedTheme) {
        isDarkMode = savedTheme === 'dark';
    } else {
        isDarkMode = prefersDark;
    }

    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        updateThemeIcon(true);
    } else {
        document.body.classList.remove('dark-mode');
        updateThemeIcon(false);
    }
}

function toggleTheme() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    
    localStorage.setItem('dashboardTheme', isDarkMode ? 'dark' : 'light');
    
    updateThemeIcon(isDarkMode);
    
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.style.transform = 'rotate(180deg)';
        setTimeout(() => {
            themeToggle.style.transition = 'transform 0.6s ease';
            themeToggle.style.transform = 'rotate(0deg)';
        }, 10);
    }
}

function updateThemeIcon(isDarkMode) {
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        const icon = themeToggle.querySelector('.theme-icon');
        if (icon) {
            icon.textContent = isDarkMode ? '☀️' : '🌙';
        }
    }
}

// ===========================
// LIVE DATA UPDATES
// ===========================

function startLiveDataUpdates() {
    setInterval(() => {
        updateMetrics();
    }, 5000);

    updateMetrics();
}

function updateMetrics() {
    const unitsElement = document.getElementById('metric-units');
    if (unitsElement) {
        const currentValue = parseInt(unitsElement.textContent.replace(/,/g, ''));
        const change = Math.floor(Math.random() * 100) - 50;
        const newValue = Math.max(15000, currentValue + change);
        unitsElement.textContent = newValue.toLocaleString();
    }

    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        if (Math.random() > 0.7) {
            card.style.transform = 'scale(1.01)';
            setTimeout(() => {
                card.style.transform = '';
            }, 200);
        }
    });
}

// ===========================
// PERFORMANCE MONITORING
// ===========================

function initializePerformanceMonitoring() {
    window.addEventListener('load', () => {
        console.log('✓ Dashboard fully loaded');
        console.log('✓ All resources loaded');
        
        if (window.performance && window.performance.timing) {
            const perfData = window.performance.timing;
            const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
            console.log(`Page Load Time: ${pageLoadTime}ms`);
        }
    });

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            console.log('Dashboard hidden - reducing update frequency');
        } else {
            console.log('Dashboard visible - resuming updates');
        }
    });
}

// ===========================
// EXPORT DATA FUNCTION
// ===========================

function exportDashboardData() {
    const data = {
        timestamp: new Date().toISOString(),
        theme: localStorage.getItem('dashboardTheme') || 'light',
        metrics: {
            totalUnits: document.getElementById('metric-units')?.textContent || 'N/A',
            exportTime: new Date().toLocaleString()
        }
    };

    console.log('Dashboard Data:', data);
    return data;
}

// ===========================
// KEYBOARD SHORTCUTS
// ===========================

function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            document.getElementById('logoutBtn')?.click();
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 't') {
            e.preventDefault();
            document.getElementById('themeToggle')?.click();
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
            e.preventDefault();
            exportDashboardData();
            console.log('✓ Dashboard data exported');
        }
    });
}

// ===========================
// PAGE INITIALIZATION
// ===========================

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('passwordForm')) {
        initializeLoginPage();
    } else if (document.querySelector('.dashboard-container')) {
        initializeDashboard();
        initializeKeyboardShortcuts();
        initializePerformanceMonitoring();
    }
});

// ===========================
// SERVICE WORKER REGISTRATION
// ===========================

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        console.log('✓ Service Worker ready for registration');
    });
}

// ===========================
// ERROR HANDLING
// ===========================

window.addEventListener('error', (event) => {
    console.error('Error:', event.message);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled Promise Rejection:', event.reason);
});

// ===========================
// UTILITY FUNCTIONS
// ===========================

function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

console.log('Manufacturing Dashboard Script Loaded ✓');
