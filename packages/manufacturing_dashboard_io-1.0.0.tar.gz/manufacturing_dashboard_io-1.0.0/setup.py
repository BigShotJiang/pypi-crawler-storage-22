#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Setup configuration for manufacturing-dashboard.io package
"""

from setuptools import setup, find_packages

# Read the contents of README file
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements from requirements.txt
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="manufacturing-dashboard-io",
    version="1.0.0",
    author="Manufacturing Systems",
    author_email="info@manufacturingdashboard.io",
    description="A professional manufacturing dashboard with real-time analytics, charts, and monitoring",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mahdi123-tech/manufacturing-dashboard-io",
    project_urls={
        "Bug Tracker": "https://github.com/mahdi123-tech/manufacturing-dashboard-io/issues",
        "Documentation": "https://github.com/mahdi123-tech/manufacturing-dashboard-io/wiki",
        "Source Code": "https://github.com/mahdi123-tech/manufacturing-dashboard-io",
    },
    packages=find_packages(),
    package_data={
        "manufacturing_dashboard": [
            "web/*.html",
            "web/css/*.css",
            "web/js/*.js",
        ]
    },
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Manufacturing",
        "Intended Audience :: System Administrators",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Internet :: WWW/HTTP :: Browsers",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "manufacturing=manufacturing_dashboard.cli:main",
            "manufacturing-dashboard=manufacturing_dashboard.cli:main",
        ]
    },
    keywords="manufacturing dashboard analytics monitoring charts real-time",
    license="MIT",
    zip_safe=False,
)
