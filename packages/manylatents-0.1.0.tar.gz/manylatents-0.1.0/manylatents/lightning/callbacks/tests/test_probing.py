# manylatents/lightning/callbacks/tests/test_probing.py
import pytest
import numpy as np
import torch
import torch.nn as nn
from unittest.mock import patch, MagicMock
from torch.utils.data import DataLoader, TensorDataset
from lightning import LightningModule, Trainer
from manylatents.lightning.callbacks.activation_tracker import (
    ProbeTrigger,
    ActivationTrajectoryCallback as RepresentationProbeCallback,
)
from manylatents.lightning.hooks import LayerSpec
from manylatents.callbacks.diffusion_operator import DiffusionGauge


def test_probe_trigger_step_based():
    trigger = ProbeTrigger(every_n_steps=100)

    assert trigger.should_fire(step=0, epoch=0) is True   # First step
    assert trigger.should_fire(step=50, epoch=0) is False
    assert trigger.should_fire(step=100, epoch=0) is True
    assert trigger.should_fire(step=200, epoch=0) is True


def test_probe_trigger_epoch_based():
    trigger = ProbeTrigger(every_n_epochs=2)

    assert trigger.should_fire(step=0, epoch=0, epoch_end=True) is True
    assert trigger.should_fire(step=0, epoch=1, epoch_end=True) is False
    assert trigger.should_fire(step=0, epoch=2, epoch_end=True) is True


def test_probe_trigger_combined():
    trigger = ProbeTrigger(every_n_steps=100, every_n_epochs=1)

    # Steps trigger
    assert trigger.should_fire(step=100, epoch=0) is True
    # Epoch also triggers
    assert trigger.should_fire(step=50, epoch=1, epoch_end=True) is True


def test_probe_trigger_disabled():
    trigger = ProbeTrigger()  # No triggers set

    assert trigger.should_fire(step=100, epoch=5) is False


# RepresentationProbeCallback tests


class TinyModel(LightningModule):
    """Minimal model for testing."""
    def __init__(self):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(10, 20),
            nn.ReLU(),
            nn.Linear(20, 5),
        )

    def forward(self, x):
        return self.network(x)

    def training_step(self, batch, batch_idx):
        x, y = batch
        out = self(x)
        loss = nn.functional.mse_loss(out, y)
        return loss

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=1e-3)


def make_probe_loader(n_samples=20, input_dim=10):
    x = torch.randn(n_samples, input_dim)
    y = torch.randn(n_samples, 5)
    return DataLoader(TensorDataset(x, y), batch_size=10)


def test_representation_probe_callback_captures():
    """Callback should capture activations and compute diffusion ops."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],  # Path relative to .network
        trigger=ProbeTrigger(every_n_steps=1),
        probe_loader=probe_loader,
        gauge=DiffusionGauge(),
    )

    train_loader = make_probe_loader(n_samples=40)

    trainer = Trainer(
        max_epochs=1,
        callbacks=[callback],
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
    )
    trainer.fit(model, train_loader)

    # Should have captured at least one trajectory point
    trajectory = callback.get_trajectory()
    assert len(trajectory) > 0

    # Each point should have step and diffusion operator
    step, diff_op = trajectory[0]
    assert isinstance(step, int)
    assert isinstance(diff_op, np.ndarray)
    assert diff_op.shape == (20, 20)  # probe_loader has 20 samples


def test_representation_probe_callback_multi_layer():
    """Should capture multiple layers."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[
            LayerSpec(path="0", reduce="none"),  # First linear
            LayerSpec(path="2", reduce="none"),  # Second linear
        ],
        trigger=ProbeTrigger(every_n_steps=2),
        probe_loader=probe_loader,
        gauge=DiffusionGauge(),
    )

    train_loader = make_probe_loader(n_samples=40)

    trainer = Trainer(
        max_epochs=1,
        callbacks=[callback],
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
    )
    trainer.fit(model, train_loader)

    trajectory = callback.get_trajectory()
    assert len(trajectory) > 0

    # Multi-layer returns dict
    step, ops = trajectory[0]
    assert isinstance(ops, dict)
    assert "0" in ops
    assert "2" in ops


def test_representation_probe_callback_epoch_trigger():
    """Should trigger at epoch end."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],
        trigger=ProbeTrigger(every_n_epochs=1),
        probe_loader=probe_loader,
        gauge=DiffusionGauge(),
    )

    train_loader = make_probe_loader(n_samples=40)

    trainer = Trainer(
        max_epochs=2,
        callbacks=[callback],
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
    )
    trainer.fit(model, train_loader)

    trajectory = callback.get_full_trajectory()
    # Should have captured at epoch 0 and epoch 1
    epochs = [p.epoch for p in trajectory]
    assert 0 in epochs
    assert 1 in epochs


def test_representation_probe_callback_with_wandb():
    """Should log to wandb when enabled."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],
        trigger=ProbeTrigger(every_n_steps=2),
        probe_loader=probe_loader,
        gauge=DiffusionGauge(),
        log_to_wandb=True,
    )

    train_loader = make_probe_loader(n_samples=40)

    with patch("wandb.run", MagicMock()), \
         patch("wandb.log") as mock_log:

        trainer = Trainer(
            max_epochs=1,
            callbacks=[callback],
            enable_progress_bar=False,
            enable_model_summary=False,
            logger=False,
        )
        trainer.fit(model, train_loader)

        # Should have logged at least once
        assert mock_log.called


def test_representation_probe_callback_save_raw(tmp_path):
    """Should save raw activations to disk when save_raw=True."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],
        trigger=ProbeTrigger(every_n_steps=1),
        probe_loader=probe_loader,
        save_raw=True,
        save_path=str(tmp_path / "activations"),
    )

    train_loader = make_probe_loader(n_samples=40)

    trainer = Trainer(
        max_epochs=1,
        callbacks=[callback],
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
    )
    trainer.fit(model, train_loader)

    # Should have saved .npy files
    saved_files = list((tmp_path / "activations").glob("*.npy"))
    assert len(saved_files) > 0

    # Verify saved arrays are correct shape
    arr = np.load(saved_files[0])
    assert arr.shape[0] == 20  # probe_loader samples
    assert arr.shape[1] == 20  # output dim of first linear layer


def test_representation_probe_callback_sanitizes_layer_names(tmp_path):
    """Layer paths with special chars should become safe filenames."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],
        trigger=ProbeTrigger(every_n_steps=1),
        probe_loader=probe_loader,
        save_raw=True,
        save_path=str(tmp_path / "activations"),
    )

    # Test sanitization directly
    assert callback._sanitize_layer_name("model.layers[-1]") == "model_layers_m1_"
    assert callback._sanitize_layer_name("transformer.h[0].attn") == "transformer_h_0__attn"


def test_representation_probe_callback_save_raw_without_gauge(tmp_path):
    """Should save activations without computing diffusion ops when gauge=None."""
    model = TinyModel()
    probe_loader = make_probe_loader()

    callback = RepresentationProbeCallback(
        layer_specs=[LayerSpec(path="0", reduce="none")],
        trigger=ProbeTrigger(every_n_steps=1),
        probe_loader=probe_loader,
        gauge=None,  # Explicitly no gauge
        save_raw=True,
        save_path=str(tmp_path / "activations"),
    )

    train_loader = make_probe_loader(n_samples=40)

    trainer = Trainer(
        max_epochs=1,
        callbacks=[callback],
        enable_progress_bar=False,
        enable_model_summary=False,
        logger=False,
    )
    trainer.fit(model, train_loader)

    # Should have saved files
    saved_files = list((tmp_path / "activations").glob("*.npy"))
    assert len(saved_files) > 0

    # Trajectory should be empty (no gauge)
    assert len(callback.get_trajectory()) == 0
