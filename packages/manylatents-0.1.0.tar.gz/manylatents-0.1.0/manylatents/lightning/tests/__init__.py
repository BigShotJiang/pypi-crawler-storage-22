# Tests for lightning module
