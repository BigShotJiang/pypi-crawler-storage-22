def main():
    print("Hello from map2poster!")


if __name__ == "__main__":
    main()
