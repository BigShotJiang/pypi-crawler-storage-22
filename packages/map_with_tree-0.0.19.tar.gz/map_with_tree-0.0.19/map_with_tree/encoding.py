import array
import collections.abc
import numbers
import struct


def get_encoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda v: struct.pack(fmt, *v)
    return ENCODING_MAP[type]


def get_decoding_function(type):
    if type.startswith("struct:"):
        fmt = type[len("struct:"):]
        return lambda b: struct.unpack(fmt, b)
    return DECODING_MAP[type]


def encode_binary_json(data):
    """
    None: 0
    Boolean:
        1 (if true)
        2 (if false)
    Integer:
        3 (if 0)
        4 (if 1)
        5 + u8 (if x >= 0 and x <= 255)
        6 + u16 (if x >= 0 and x <= 65535)
        7 + u32 (if x >= 0 and x <= 2^32-1)
        8 + u64 (otherwise if x >= 0)
        9 + i8 (if x < 0 and x >= -128)
        10 + i16 (if x < 0 and x >= -32768)
        11 + i32 (if x < 0 and x >= -2^31)
        12 + i64 (otherwise if x < 0)
    Float: 13 + f64
    Bytes:
        14 (if length == 0)
        15 + byte (if length <= 1)
        16 + u8 + bytes (if length <= 255)
        17 + u16 + bytes (if length <= 65535)
        18 + u32 + bytes (if length <= 2^32-1)
        19 + u64 + bytes (otherwise)
    String:
        20 (if length == 0)
        21 + utf-8 byte (if length == 1)
        22 + u8 + utf-8 bytes (if length <= 255)
        23 + u16 + utf-8 bytes (if length <= 65535)
        24 + u32 + utf-8 bytes (if length <= 2^32-1)
        25 + u64 + utf-8 bytes (otherwise)
    Mapping:
        26 (if length == 0)
        27 + (key, value) (if length == 1)
        28 + u8 + (key, value) * length (if length <= 255)
        29 + u16 + (key, value) * length (if length <= 65535)
        30 + u32 + (key, value) * length (if length <= 2^32-1)
        31 + u64 + (key, value) * length (otherwise)
    Collection:
        32 (if length == 0)
        33 + item (if length == 1)
        34 + u8 + item * length (if length <= 255)
        35 + u16 + item * length (if length <= 65535)
        36 + u32 + item * length (if length <= 2^32-1)
        37 + u64 + item * length (otherwise)
    Array:
        38 + u8 (type) (if length == 0)
        39 + u8 (type) + item * length (if length == 1)
        40 + u8 (type) + u8 + item * length (if length <= 255)
        41 + u8 (type) + u16 + item * length (if length <= 65535)
        42 + u8 (type) + u32 + item * length (if length <= 2^32-1)
        43 + u8 (type) + u64 + item * length (otherwise)
    """
    if data is None:
        return b"\x00"
    if isinstance(data, bool):
        return b"\x01" if data else b"\x02"
    if isinstance(data, numbers.Integral):
        if data == 0:
            return b"\x03"
        if data == 1:
            return b"\x04"
        if data >= 0:
            if data <= 255:
                return b"\x05" + STRUCT_UB.pack(data)
            if data <= 65535:
                return b"\x06" + STRUCT_UH.pack(data)
            if data <= 4294967295:
                return b"\x07" + STRUCT_UI.pack(data)
            return b"\x08" + STRUCT_UQ.pack(data)
        if data >= -128:
            return b"\x09" + STRUCT_B.pack(data)
        if data >= -32768:
            return b"\x0A" + STRUCT_H.pack(data)
        if data >= -2147483648:
            return b"\x0B" + STRUCT_I.pack(data)
        return b"\x0C" + STRUCT_Q.pack(data)
    if isinstance(data, numbers.Real):
        return b"\x0D" + STRUCT_D.pack(data)
    if isinstance(data, (bytes, bytearray)):
        length = len(data)
        if length == 0:
            return b"\x0E"
        if length == 1:
            return b"\x0F" + data
        if length <= 255:
            return b"\x10" + STRUCT_UB.pack(length) + data
        if length <= 65535:
            return b"\x11" + STRUCT_UH.pack(length) + data
        if length <= 4294967295:
            return b"\x12" + STRUCT_UI.pack(length) + data
        return b"\x13" + STRUCT_UQ.pack(length) + data
    if isinstance(data, str):
        encoded = data.encode()
        length = len(encoded)
        if length == 0:
            return b"\x14"
        if length == 1:
            return b"\x15" + encoded
        if length <= 255:
            return b"\x16" + STRUCT_UB.pack(length) + encoded
        if length <= 65535:
            return b"\x17" + STRUCT_UH.pack(length) + encoded
        if length <= 4294967295:
            return b"\x18" + STRUCT_UI.pack(length) + encoded
        return b"\x19" + STRUCT_UQ.pack(length) + encoded
    if isinstance(data, collections.abc.Mapping):
        length = len(data)
        if length == 0:
            return b"\x1A"
        if length == 1:
            buffer = [b"\x1B"]
        elif length <= 255:
            buffer = [b"\x1C", STRUCT_UB.pack(length)]
        elif length <= 65535:
            buffer = [b"\x1D", STRUCT_UH.pack(length)]
        elif length <= 4294967295:
            buffer = [b"\x1E", STRUCT_UI.pack(length)]
        else:
            buffer = [b"\x1F", STRUCT_UQ.pack(length)]
        for key, value in data.items():
            buffer.append(encode_binary_json(key))
            buffer.append(encode_binary_json(value))
        return b"".join(buffer)
    if isinstance(data, array.array):
        length = len(data)
        type_code = data.typecode
        if length == 0:
            return b"\x26" + STRUCT_UB.pack(ord(type_code))
        if length == 1:
            buffer = b"\x27" + STRUCT_UB.pack(ord(type_code))
        elif length <= 255:
            buffer = b"\x28" + STRUCT_UB.pack(ord(type_code)) + STRUCT_UB.pack(length)
        elif length <= 65535:
            buffer = b"\x29" + STRUCT_UB.pack(ord(type_code)) + STRUCT_UH.pack(length)
        elif length <= 4294967295:
            buffer = b"\x2A" + STRUCT_UB.pack(ord(type_code)) + STRUCT_UI.pack(length)
        else:
            buffer = b"\x2B" + STRUCT_UB.pack(ord(type_code)) + STRUCT_UQ.pack(length)
        return buffer + data.tobytes()
    if isinstance(data, collections.abc.Collection):
        length = len(data)
        if length == 0:
            return b"\x20"
        if length == 1:
            buffer = [b"\x21"]
        elif length <= 255:
            buffer = [b"\x22", STRUCT_UB.pack(length)]
        elif length <= 65535:
            buffer = [b"\x23", STRUCT_UH.pack(length)]
        elif length <= 4294967295:
            buffer = [b"\x24", STRUCT_UI.pack(length)]
        else:
            buffer = [b"\x25", STRUCT_UQ.pack(length)]
        for item in data:
            buffer.append(encode_binary_json(item))
        return b"".join(buffer)
    data = f"{repr(data)[:80]} ({type(data).__name__})"
    raise ValueError(f"type of {data} unsupported")


def decode_binary_json(buffer):
    def traverse(buffer, offset):
        type_byte = buffer[offset]
        offset += 1
        match type_byte:
            case 0: # null
                return None, offset
            case 1: # true
                return True, offset
            case 2: # false
                return False, offset
            case 3: # int 0
                return 0, offset
            case 4: # int 1
                return 1, offset
            case 5: # u8
                value = STRUCT_UB.unpack_from(buffer, offset)[0]
                return value, offset + 1
            case 6: # u16
                value = STRUCT_UH.unpack_from(buffer, offset)[0]
                return value, offset + 2
            case 7: # u32
                value = STRUCT_UI.unpack_from(buffer, offset)[0]
                return value, offset + 4
            case 8: # u64
                value = STRUCT_UQ.unpack_from(buffer, offset)[0]
                return value, offset + 8
            case 9: # i8
                value = STRUCT_UB.unpack_from(buffer, offset)[0]
                return value, offset + 1
            case 10: # i16
                value = STRUCT_UH.unpack_from(buffer, offset)[0]
                return value, offset + 2
            case 11: # i32
                value = STRUCT_UI.unpack_from(buffer, offset)[0]
                return value, offset + 4
            case 12: # i64
                value = STRUCT_Q.unpack_from(buffer, offset)[0]
                return value, offset + 8
            case 13: # f64
                value = STRUCT_D.unpack_from(buffer, offset)[0]
                return value, offset + 8
            case 14: # empty bytes
                return b"", offset
            case 15: # single byte
                value = buffer[offset:offset+1].tobytes()
                return value, offset + 1
            case 16: # bytes u8
                length = STRUCT_UB.unpack_from(buffer, offset)[0]
                offset += 1
                value = buffer[offset:offset + length].tobytes()
                return value, offset + length
            case 17: # bytes u16
                length = STRUCT_UH.unpack_from(buffer, offset)[0]
                offset += 2
                value = buffer[offset:offset + length].tobytes()
                return value, offset + length
            case 18: # bytes u32
                length = STRUCT_UI.unpack_from(buffer, offset)[0]
                offset += 4
                value = buffer[offset:offset + length].tobytes()
                return value, offset + length
            case 19: # bytes u64
                length = STRUCT_UQ.unpack_from(buffer, offset)[0]
                offset += 8
                value = buffer[offset:offset + length].tobytes()
                return value, offset + length
            case 20: # empty string
                return "", offset
            case 21: # single char
                value = str(buffer[offset:offset + 1], "utf-8")
                return value, offset + 1
            case 22: # string u8
                length = STRUCT_UB.unpack_from(buffer, offset)[0]
                offset += 1
                value = str(buffer[offset:offset + length], "utf-8")
                return value, offset + length
            case 23: # string u16
                length = STRUCT_UH.unpack_from(buffer, offset)[0]
                offset += 2
                value = str(buffer[offset:offset + length], "utf-8")
                return value, offset + length
            case 24: # string u32
                length = STRUCT_UI.unpack_from(buffer, offset)[0]
                offset += 4
                value = str(buffer[offset:offset + length], "utf-8")
                return value, offset + length
            case 25: # string u64
                length = STRUCT_UQ.unpack_from(buffer, offset)[0]
                offset += 8
                value = str(buffer[offset:offset + length], "utf-8")
                return value, offset + length
            case 26: # empty mapping
                return {}, offset
            case 27: # single mapping
                mapping = {}
                key, offset = traverse(buffer, offset)
                value, offset = traverse(buffer, offset)
                mapping[key] = value
                return mapping, offset
            case _ if 28 <= type_byte <= 31 : # mapping u8 to u64
                match type_byte:
                    case 28: # mapping u8
                        length = STRUCT_UB.unpack_from(buffer, offset)[0]
                        offset += 1
                    case 29: # mapping u16
                        length = STRUCT_UH.unpack_from(buffer, offset)[0]
                        offset += 2
                    case 30: # mapping u32
                        length = STRUCT_UI.unpack_from(buffer, offset)[0]
                        offset += 4
                    case 31: # mapping u64
                        length = STRUCT_UQ.unpack_from(buffer, offset)[0]
                        offset += 8
                mapping = {}
                for _ in range(length):
                    key, offset = traverse(buffer, offset)
                    value, offset = traverse(buffer, offset)
                    mapping[key] = value
                return mapping, offset
            case 32: # empty collection
                return [], offset
            case 33: # single collection
                collection = []
                item, offset = traverse(buffer, offset)
                collection.append(item)
                return collection, offset
            case _ if 34 <= type_byte <= 37 : # collection u8 to u64
                match type_byte:
                    case 34: # collection u8
                        length = STRUCT_UB.unpack_from(buffer, offset)[0]
                        offset += 1
                    case 35: # collection u16
                        length = STRUCT_UH.unpack_from(buffer, offset)[0]
                        offset += 2
                    case 36: # collection u32
                        length = STRUCT_UI.unpack_from(buffer, offset)[0]
                        offset += 4
                    case 37: # collection u64
                        length = STRUCT_UQ.unpack_from(buffer, offset)[0]
                        offset += 8
                collection = []
                for _ in range(length):
                    item, offset = traverse(buffer, offset)
                    collection.append(item)
                return collection, offset
            case 38: # empty array
                type_code = chr(STRUCT_UB.unpack_from(buffer, offset)[0])
                offset += 1
                return array.array(type_code), offset
            case 39: # single array
                type_code = chr(STRUCT_UB.unpack_from(buffer, offset)[0])
                offset += 1
                arr = array.array(type_code)
                itemsize = arr.itemsize
                arr.frombytes(buffer[offset:offset + itemsize])
                return arr, offset + itemsize
            case _ if 40 <= type_byte <= 43: # array u8 to u64
                type_code = chr(STRUCT_UB.unpack_from(buffer, offset)[0])
                offset += 1
                match type_byte:
                    case 40: # array u8
                        length = STRUCT_UB.unpack_from(buffer, offset)[0]
                        offset += 1
                    case 41: # array u16
                        length = STRUCT_UH.unpack_from(buffer, offset)[0]
                        offset += 2
                    case 42: # array u32
                        length = STRUCT_UI.unpack_from(buffer, offset)[0]
                        offset += 4
                    case 43: # array u64
                        length = STRUCT_UQ.unpack_from(buffer, offset)[0]
                        offset += 8
                arr = array.array(type_code)
                itemsize = arr.itemsize
                byte_length = length * itemsize
                arr.frombytes(buffer[offset:offset + byte_length])
                return arr, offset + byte_length
            case _:
                raise ValueError(f"type byte {type_byte} invalid")
    buffer = memoryview(buffer)
    return traverse(buffer, 0)[0]


STRUCT_B = struct.Struct("<b")
STRUCT_UB = struct.Struct("<B")
STRUCT_H = struct.Struct("<h")
STRUCT_UH = struct.Struct("<H")
STRUCT_I = struct.Struct("<i")
STRUCT_UI = struct.Struct("<I")
STRUCT_Q = struct.Struct("<q")
STRUCT_UQ = struct.Struct("<Q")
STRUCT_F = struct.Struct("<f")
STRUCT_D = struct.Struct("<d")


ENCODING_MAP = {
    "bytes": lambda v: v,
    "string": lambda v: v.encode(),
    "str": lambda v: v.encode(),
    "i8": lambda v: STRUCT_B.pack(v),
    "u8": lambda v: STRUCT_UB.pack(v),
    "i16": lambda v: STRUCT_H.pack(v),
    "u16": lambda v: STRUCT_UH.pack(v),
    "i32": lambda v: STRUCT_I.pack(v),
    "u32": lambda v: STRUCT_UI.pack(v),
    "i64": lambda v: STRUCT_Q.pack(v),
    "int": lambda v: STRUCT_Q.pack(v),
    "u64": lambda v: STRUCT_UQ.pack(v),
    "uint": lambda v: STRUCT_UQ.pack(v),
    "f32": lambda v: STRUCT_F.pack(v),
    "f64": lambda v: STRUCT_D.pack(v),
    "float": lambda v: STRUCT_D.pack(v),
    "json": lambda v: encode_binary_json(v)}


DECODING_MAP = {
    "bytes": lambda b: b.tobytes(),
    "string": lambda b: str(b, "utf-8"),
    "str": lambda b: str(b, "utf-8"),
    "i8": lambda b: STRUCT_UB.unpack(b)[0],
    "u8": lambda b: STRUCT_UB.unpack(b)[0],
    "i16": lambda b: STRUCT_UH.unpack(b)[0],
    "u16": lambda b: STRUCT_UH.unpack(b)[0],
    "i32": lambda b: STRUCT_UI.unpack(b)[0],
    "u32": lambda b: STRUCT_UI.unpack(b)[0],
    "i64": lambda b: STRUCT_Q.unpack(b)[0],
    "int": lambda b: STRUCT_Q.unpack(b)[0],
    "u64": lambda b: STRUCT_UQ.unpack(b)[0],
    "uint": lambda b: STRUCT_UQ.unpack(b)[0],
    "f32": lambda b: STRUCT_F.unpack(b)[0],
    "f64": lambda b: STRUCT_D.unpack(b)[0],
    "float": lambda b: STRUCT_D.unpack(b)[0],
    "json": lambda b: decode_binary_json(b)}
