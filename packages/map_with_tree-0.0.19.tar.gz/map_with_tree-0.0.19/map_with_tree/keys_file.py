import heapq
import shutil
import struct
import sys

from .util import try_remove_file


def read_entry(file):
    data = file.read(2 + 8)
    if not data:
        return None
    key_length, key_data_length = struct.unpack("<HQ", data)
    key = file.read(key_length)
    key_data = file.read(key_data_length)
    assert len(key) == key_length
    return key, key_data


def write_entry(file, key, key_data):
    file.write(struct.pack("<HQ", len(key), len(key_data)))
    file.write(key)
    file.write(key_data)


def merge_files(input_paths, output_path, remove_duplicates=False, list_duplicates=False):
    """
    Merge multiple sorted files into one sorted file using a min-heap.
    If remove_duplicates is True, keeps the last occurrence of duplicate keys.
    Returns the count of duplicates found during this merge.
    """
    file_handles = []
    heap = []
    
    # Variables for deduplication
    last_key = None
    last_key_data = None
    duplicate_count = 0
    
    try:
        # Initialize heap
        for index, path in enumerate(input_paths):
            file = open(path, "rb")
            file_handles.append(file)
            entry = read_entry(file)
            if entry:
                key, key_data = entry
                # (key, index) tuple ensures stability (lower index = earlier file)
                heapq.heappush(heap, (key, index, key_data))
        
        with open(output_path, "wb") as out_file:
            while heap:
                key, index, key_data = heapq.heappop(heap)
                
                if remove_duplicates:
                    # Check if this key matches the previous one
                    if last_key is not None and key == last_key:
                        # Found duplicate. Since sort is stable/index-ordered, 
                        # this occurrence is "later". Keep this data.
                        last_key_data = key_data
                        duplicate_count += 1
                        if list_duplicates:
                            sys.stderr.write(f"key {key!r} duplicated\n")
                    else:
                        # New key. Write the buffered previous key if it exists.
                        if last_key is not None:
                            write_entry(out_file, last_key, last_key_data)
                        last_key = key
                        last_key_data = key_data
                else:
                    # Standard behavior: write immediately
                    write_entry(out_file, key, key_data)

                # Refill heap from the file that just yielded an item
                entry = read_entry(file_handles[index])
                if entry:
                    next_key, next_key_data = entry
                    heapq.heappush(heap, (next_key, index, next_key_data))
            
            # Flush the final buffered key if deduplicating
            if remove_duplicates and last_key is not None:
                write_entry(out_file, last_key, last_key_data)
                
        return duplicate_count

    finally:
        for file in file_handles:
            file.close()


def sort_keys_file(
        input_path,
        output_path,
        tmp_dir,
        chunk_size=40*1024*1024,
        max_merge_way=200,
        remove_input=False,
        duplicates=""):
    """
    External merge sort for keys file with memory and file constraints.

    chunk_size: max memory to use for sorting (in bytes, default 40MB)
    max_merge_way: max number of files to merge at once (default 200)
    remove_input: whether to delete the input file after sorting
    duplicates: comma-separated string for handling duplicates:
        warn: log duplicate count to stderr if any
        list: log duplicate keys to stderr
        remove: remove duplicate keys (keep last occurrence)
    """
    
    # Phase 1: split into sorted chunks
    chunk_files = []
    with open(input_path, "rb") as file:
        chunk_index = 0
        while True:
            entries = []
            bytes_read = 0

            while bytes_read < chunk_size:
                entry = read_entry(file)
                if not entry:
                    break
                entries.append(entry)
                bytes_read += (2 + 8 + len(entry[0]) + len(entry[1]))
            if not entries:
                break

            # Sort by key (index 0)
            entries.sort(key=lambda x: x[0])

            chunk_path = tmp_dir.file(f"sort_chunk_{chunk_index}")
            with open(chunk_path, "wb") as chunk_file:
                for key, key_data in entries:
                    write_entry(chunk_file, key, key_data)
            chunk_files.append(chunk_path)
            chunk_index += 1
    
    if remove_input:
        try_remove_file(input_path)

    if not chunk_files:
        open(output_path, "wb").close()
        return

    # Phase 2: multi-level merge
    merge_level = 0
    total_duplicates = 0
    merges_performed = False
    
    while len(chunk_files) > 1:
        merges_performed = True
        next_chunks = []
        
        for i in range(0, len(chunk_files), max_merge_way):
            batch = chunk_files[i : i + max_merge_way]
            
            output = tmp_dir.file(f"sort_l{merge_level}_{len(next_chunks)}")
            next_chunks.append(output)
            
            # Accumulate duplicates found in this step
            count = merge_files(batch, output, "remove" in duplicates, "list" in duplicates)
            total_duplicates += count
            
            try_remove_file(*batch)
        
        chunk_files = next_chunks
        merge_level += 1
    
    if "remove" in duplicates and not merges_performed:
        count = merge_files(chunk_files, output_path, "remove" in duplicates, "list" in duplicates)
        total_duplicates += count
        try_remove_file(chunk_files[0])
    else:
        shutil.move(chunk_files[0], output_path)

    if total_duplicates and "warn" in duplicates:
        sys.stderr.write(f"warning: {total_duplicates} duplicated keys\n")
