import os
import tempfile


def try_remove_file(*paths):
    for path in paths:
        try:
            os.remove(path)
        except:
            pass


class TmpDir:
    def __init__(self, alongside):
        self.tmp_dir, self.cleaned = None, False
        parent = os.path.dirname(os.path.realpath(alongside))
        prefix = f"{os.path.basename(alongside)}.tmp."
        self.tmp_dir = tempfile.TemporaryDirectory(dir=parent, prefix=prefix)
        self.path = self.tmp_dir.name

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self.clean()

    def __del__(self):
        self.clean()

    def file(self, name):
        return os.path.join(self.path, name)

    def clean(self):
        if self.tmp_dir is not None and not self.cleaned:
            self.tmp_dir.cleanup()
            self.cleaned = True
