# Copyright (C) 2022-2025 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.
"""Numba-based distance matrix functions."""

from typing import Callable

import numba
import numpy as np


@numba.njit(parallel=True)
def get_distances(X: np.ndarray, metric: Callable) -> np.ndarray:
    N = X.shape[0]
    D = np.zeros((N, N), dtype=np.float32)

    for i in numba.prange(N):
        for j in range(i + 1, N):
            D[i, j] = metric(X[i], X[j])

    for i in numba.prange(N):
        for j in range(i):
            D[i, j] = D[j, i]

    return D


@numba.njit(parallel=True)
def get_distances_sparse(
    data: np.ndarray, indices: np.ndarray, indptr: np.ndarray, metric: Callable
) -> np.ndarray:
    N = indptr.shape[0] - 1
    D = np.zeros((N, N), dtype=np.float32)

    for i in numba.prange(N):
        data_i = data[indptr[i] : indptr[i + 1]]
        indices_i = indices[indptr[i] : indptr[i + 1]]
        for j in range(i + 1, N):
            data_j = data[indptr[j] : indptr[j + 1]]
            indices_j = indices[indptr[j] : indptr[j + 1]]
            D[i, j] = metric(indices_i, data_i, indices_j, data_j)

    for i in numba.prange(N):
        for j in range(i):
            D[i, j] = D[j, i]

    return D


@numba.njit(parallel=True)
def get_distances_sparse_n_features(
    data: np.ndarray,
    indices: np.ndarray,
    indptr: np.ndarray,
    n_features: int,
    metric: Callable,
) -> np.ndarray:
    N = indptr.shape[0] - 1
    D = np.zeros((N, N), dtype=np.float32)

    for i in numba.prange(N):
        data_i = data[indptr[i] : indptr[i + 1]]
        indices_i = indices[indptr[i] : indptr[i + 1]]
        for j in range(i + 1, N):
            data_j = data[indptr[j] : indptr[j + 1]]
            indices_j = indices[indptr[j] : indptr[j + 1]]
            D[i, j] = metric(indices_i, data_i, indices_j, data_j, n_features)

    for i in numba.prange(N):
        for j in range(i):
            D[i, j] = D[j, i]

    return D


@numba.njit(parallel=False)
def _neighbors_from_sparse_distance_matrix(
    data: np.ndarray,
    indices: np.ndarray,
    indptr: np.ndarray,
    n_neighbors: int,
    n_points: int,
):
    neighbors = np.full((n_points, n_neighbors), dtype=np.int32, fill_value=-1)
    distances = np.full((n_points, n_neighbors), dtype=np.float32, fill_value=np.inf)
    for i in range(n_points):
        i_start, i_end = indptr[i : i + 2]
        i_data = data[i_start:i_end]
        i_indices = indices[i_start:i_end]
        i_n_nbrs = min(n_neighbors, len(i_data))
        if i_n_nbrs > 0:
            if len(i_data) > i_n_nbrs:
                distance_sort = np.argpartition(i_data, i_n_nbrs - 1).astype(np.int32)
                unsorted_nbrs = distance_sort[:i_n_nbrs]
                unsorted_distances = i_data[unsorted_nbrs]
            else:
                unsorted_distances = i_data
                unsorted_nbrs = np.arange(i_n_nbrs, dtype=np.int32)

            nbrs_sorter = np.argsort(unsorted_distances)
            i_neighbors = i_indices[unsorted_nbrs[nbrs_sorter]]
            i_distances = unsorted_distances[nbrs_sorter]

            neighbors[i, : len(i_neighbors)] = i_neighbors
            distances[i, : len(i_distances)] = i_distances

    return neighbors, distances
