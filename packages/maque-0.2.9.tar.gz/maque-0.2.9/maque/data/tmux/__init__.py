# Oh my tmux! configuration files
# Source: https://github.com/gpakosz/.tmux
