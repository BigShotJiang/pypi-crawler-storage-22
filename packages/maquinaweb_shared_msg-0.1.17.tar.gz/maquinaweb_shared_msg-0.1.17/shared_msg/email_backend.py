from django.core.mail.backends.smtp import EmailBackend as SMTPEmailBackend
from django.conf import settings


class CustomEmailBackend(SMTPEmailBackend):
    """
    Custom email backend that adds default BCC to all outgoing emails.
    """

    def send_messages(self, email_messages):
        """
        Add default BCC to all email messages before sending.
        Supports DEFAULT_BCC_EMAIL as a list/tuple/set of emails (preferred) or a single string (backward-compatible).
        """
        default_bcc = getattr(settings, "DEFAULT_BCC_EMAIL", None)
        if default_bcc:
            if isinstance(default_bcc, (list, tuple, set)):
                default_bcc_list = list(default_bcc)
            else:
                default_bcc_list = [default_bcc]

            for message in email_messages:
                if not message.bcc:
                    message.bcc = list(default_bcc_list)
                else:
                    for addr in default_bcc_list:
                        if addr not in message.bcc:
                            message.bcc.append(addr)

        return super().send_messages(email_messages)
