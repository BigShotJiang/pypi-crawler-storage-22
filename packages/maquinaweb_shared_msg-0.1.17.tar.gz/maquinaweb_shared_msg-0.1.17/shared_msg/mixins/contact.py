from django.db import models

from shared_msg.conf import get_setting
from shared_msg.message.utils import MessageTypes
from shared_msg.models import Contact, Email, Phone


class ContactMixin(models.Model):
    contact_id = models.IntegerField(null=True, blank=True, db_index=True)

    class Meta:
        abstract = True

    def add_email(self, email: str) -> Email | None:
        if self.contact_id:
            return Email.objects.create(contact_id=self.contact_id, email=email)

    def add_phone(self, number: str, phone_type: Phone.PhoneType) -> Phone | None:
        if self.contact_id:
            return Phone.objects.create(
                contact_id=self.contact_id, number=number, phone_type=phone_type
            )

    @property
    def emails(self):
        return Email.objects.filter(contact_id=self.contact_id)

    @property
    def phones(self):
        return Phone.objects.filter(contact_id=self.contact_id)

    @property
    def contact(self):
        return Contact.objects.get(id=self.contact_id)

    def send_message(
        self,
        type: MessageTypes,
        template: str,
        context: dict = {},
        from_email: str = get_setting("DEFAULT_FROM_EMAIL", ""),
        subject: str = "",
        message_pk: str | None = None,
    ):
        from shared_msg.message.utils.send_message import (
            send_message as send_message_utils,
        )

        send_message_utils(
            [self.contact_id],
            type,
            template,
            context,
            from_email,
            subject,
            message_pk,
        )
