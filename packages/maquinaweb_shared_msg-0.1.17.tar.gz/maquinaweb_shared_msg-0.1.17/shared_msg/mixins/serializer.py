from rest_framework import serializers
from shared_msg.models import Contact, Email, Phone


class ContactSerializerMixin(serializers.ModelSerializer):
    """
    Mixin para serializers com suporte a contatos (emails/phones) do shared_msg.
    Pode ser usado com ModelSerializer ou WritableNestedModelSerializer.
    """
    emails = serializers.ListField(
        child=serializers.DictField(),
        required=False,
        write_only=True,
    )
    phones = serializers.ListField(
        child=serializers.DictField(),
        required=False,
        write_only=True,
    )

    def _ensure_contact(self, instance):
        if not instance.contact_id:
            contact = Contact.objects.create()
            instance.contact_id = contact.id
            instance.save(update_fields=["contact_id"])

    def _sync_related(self, *, instance, model, payload, fields):
        qs = model.objects.filter(contact_id=instance.contact_id)
        existing = {obj.id: obj for obj in qs}

        received_ids = set()

        for item in payload:
            obj_id = item.get("id")

            if obj_id and obj_id in existing:
                obj = existing[obj_id]
                for field in fields:
                    setattr(obj, field, item[field])
                obj.save(update_fields=fields)
                received_ids.add(obj_id)
            else:
                data = {field: item[field] for field in fields}
                data["contact_id"] = instance.contact_id
                model.objects.create(**data)

        to_delete = set(existing.keys()) - received_ids
        if to_delete:
            model.objects.filter(id__in=to_delete).delete()

    def create(self, validated_data):
        emails = validated_data.pop("emails", [])
        phones = validated_data.pop("phones", [])

        instance = super().create(validated_data)
        self._ensure_contact(instance)

        self._sync_related(
            instance=instance, model=Email, payload=emails, fields=["email"]
        )
        self._sync_related(
            instance=instance,
            model=Phone,
            payload=phones,
            fields=["number", "phone_type"],
        )

        return instance

    def update(self, instance, validated_data):
        emails = validated_data.pop("emails", None)
        phones = validated_data.pop("phones", None)

        instance = super().update(instance, validated_data)
        self._ensure_contact(instance)

        if emails is not None:
            self._sync_related(
                instance=instance, model=Email, payload=emails, fields=["email"]
            )

        if phones is not None:
            self._sync_related(
                instance=instance,
                model=Phone,
                payload=phones,
                fields=["number", "phone_type"],
            )

        return instance

    def to_representation(self, instance):
        data = super().to_representation(instance)

        if instance.contact_id:
            data["emails"] = list(
                Email.objects.filter(contact_id=instance.contact_id).values(
                    "id", "email"
                )
            )
            data["phones"] = list(
                Phone.objects.filter(contact_id=instance.contact_id).values(
                    "id", "number", "phone_type"
                )
            )
        else:
            data["emails"] = []
            data["phones"] = []

        return data
