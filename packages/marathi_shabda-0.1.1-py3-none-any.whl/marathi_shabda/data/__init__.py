"""Data package - contains dictionary database."""

# This package contains the SQLite database file
# The database should be placed at: src/marathi_pratham/data/dictionary.db
