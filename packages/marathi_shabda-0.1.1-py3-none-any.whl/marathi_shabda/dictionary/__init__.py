"""Dictionary adapter package."""

from marathi_shabda.dictionary.adapter import DictionaryAdapter

__all__ = ["DictionaryAdapter"]
