# MCP

Margarita has an MCP server that allows you to serve rendered prompts.

[Check it out here](http://github.com/Banyango/margarita-mcp)
