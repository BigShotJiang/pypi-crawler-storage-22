# MarginDash Python SDK

Track AI usage and revenue with [MarginDash](https://margindash.com).

## Installation

```bash
pip install margindash
```

## Quick Start

```python
import asyncio
from openai import AsyncOpenAI
from margindash import MarginDash, Event, Usage

async def main():
    openai = AsyncOpenAI()

    async with MarginDash(api_key="md_live_...") as md:
        response = await openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )

        md.add_usage("openai", Usage(
            model=response.model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
        ))
        md.track(Event(
            customer_id=user.id,
        ))

    # Events are automatically flushed when exiting the context manager.

asyncio.run(main())
```

Only the model name and token counts are sent to MarginDash — no request
or response content ever leaves your infrastructure.

## Tracking events

Record usage from each AI API call with `add_usage()`, then call
`track()` to flush them into an event.

### `track()` fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `customer_id` | `str` | **yes** | — | Your customer identifier |
| `revenue_amount_in_cents` | `int` | no | `0` | Revenue for this event in cents |
| `event_type` | `str` | no | `"ai_request"` | Category for this event |
| `unique_request_token` | `str` | no | auto-generated UUID | Idempotency key |
| `occurred_at` | `str` | no | current time (ISO 8601) | When the event occurred |
| `metadata` | `dict` | no | — | Arbitrary metadata |

### `add_usage()` fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `vendor_name` | `str` | **yes** | First argument — e.g. `"openai"`, `"anthropic"` |
| `model` | `str` | **yes** | AI model name |
| `input_tokens` | `int` | **yes** | Input/prompt token count |
| `output_tokens` | `int` | **yes** | Output/completion token count |

### Examples

```python
# Single call
r1 = await openai.chat.completions.create(model="gpt-4o", messages=messages)
md.add_usage("openai", Usage(
    model=r1.model,
    input_tokens=r1.usage.prompt_tokens,
    output_tokens=r1.usage.completion_tokens,
))
md.track(Event(customer_id=user.id))

# With revenue
md.track(Event(customer_id=user.id, revenue_amount_in_cents=500))

# Agent session with multiple AI calls
r2 = await openai.chat.completions.create(model="gpt-4o", messages=messages)
md.add_usage("openai", Usage(
    model=r2.model,
    input_tokens=r2.usage.prompt_tokens,
    output_tokens=r2.usage.completion_tokens,
))

r3 = await anthropic.messages.create(model="claude-3-opus-20240229", messages=messages)
md.add_usage("anthropic", Usage(
    model=r3.model,
    input_tokens=r3.usage.input_tokens,
    output_tokens=r3.usage.output_tokens,
))

r4 = await google.generate_content(model="gemini-1.5-pro", contents=contents)
md.add_usage("gemini", Usage(
    model="gemini-1.5-pro",
    input_tokens=r4.usage_metadata.prompt_token_count,
    output_tokens=r4.usage_metadata.candidates_token_count,
))

md.track(Event(customer_id=user.id, revenue_amount_in_cents=1200))
```

### Supported vendors

Any vendor name works with `add_usage()` as long as you have a matching
vendor rate configured in MarginDash. Common names: `openai`, `anthropic`,
`gemini`, `groq`, `azure`, `bedrock`.

## Configuration

```python
MarginDash(
    api_key="md_live_...",              # required
    base_url="https://...",             # default: https://margindash.com/api/v1
    flush_interval=5.0,                 # default: 5.0 seconds
    max_queue_size=1000,                # default: 1000
    batch_size=25,                      # default: 25
    max_retries=3,                      # default: 3
    default_event_type="ai_request",    # default: "ai_request"
    on_error=lambda err: print(err.message),  # optional error callback
)
```

## Manual Flush and Shutdown

If you are not using the async context manager, call `shutdown()` before
your application exits to ensure all buffered events are sent:

```python
md = MarginDash(api_key="md_live_...")
try:
    md.add_usage("openai", Usage(
        model="gpt-4o",
        input_tokens=100,
        output_tokens=50,
    ))
    md.track(event)
    await md.flush()   # flush immediately if needed
finally:
    await md.shutdown()
```

## License

MIT
