from __future__ import annotations

import logging
import threading
from typing import Any, Callable

logger = logging.getLogger("margindash.queue")


class EventQueue:
    """Internal thread-safe queue that batches events and flushes them periodically.

    Parameters
    ----------
    send_fn:
        A callable that receives a list of event dicts and sends them
        to the MarginDash API.
    flush_interval:
        Seconds between automatic flushes.  Defaults to ``5.0``.
    max_size:
        Maximum number of events to buffer.  Oldest events are dropped when
        this limit is exceeded.  Defaults to ``1000``.
    batch_size:
        Maximum number of events per batch sent to *send_fn*.
        Defaults to ``25``.
    """

    def __init__(
        self,
        send_fn: Callable[[list[dict[str, Any]]], None],
        *,
        flush_interval: float = 5.0,
        max_size: int = 1000,
        batch_size: int = 25,
    ) -> None:
        self._send_fn = send_fn
        self._flush_interval = flush_interval
        self._max_size = max_size
        self._batch_size = batch_size
        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def enqueue(self, event: dict[str, Any]) -> None:
        """Add *event* to the buffer.  Never raises."""
        try:
            with self._lock:
                self._buffer.append(event)
                # Drop oldest events if we exceed max size
                if len(self._buffer) > self._max_size:
                    self._buffer = self._buffer[-self._max_size:]
        except Exception:
            logger.exception("margindash: failed to enqueue event")

    def drain(self) -> list[list[dict[str, Any]]]:
        """Remove all buffered events and return them split into batches of
        up to :pyattr:`_batch_size` items each."""
        with self._lock:
            items = list(self._buffer)
            self._buffer.clear()

        batches: list[list[dict[str, Any]]] = []
        batch: list[dict[str, Any]] = []

        for item in items:
            batch.append(item)
            if len(batch) >= self._batch_size:
                batches.append(batch)
                batch = []

        if batch:
            batches.append(batch)
        return batches

    # ------------------------------------------------------------------
    # Flush loop
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the periodic flush loop as a daemon thread."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._thread.start()

    def _flush_loop(self) -> None:
        """Periodically flush buffered events."""
        while not self._stop_event.wait(self._flush_interval):
            self.flush()

    def flush(self) -> None:
        """Immediately flush all buffered events by sending them in batches."""
        batches = self.drain()
        for batch in batches:
            self._safe_send(batch)

    def _safe_send(self, batch: list[dict[str, Any]]) -> None:
        """Send a single batch, swallowing exceptions so one failure does not
        prevent other batches from being sent."""
        try:
            self._send_fn(batch)
        except Exception:
            logger.exception("margindash: failed to send batch of %d events", len(batch))

    def shutdown(self) -> None:
        """Stop the flush loop and perform a final flush."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=5.0)
        # Final flush to send any remaining events
        self.flush()
