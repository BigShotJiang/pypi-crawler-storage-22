from __future__ import annotations

import atexit
import logging
import threading
from typing import Any, Callable

import httpx

from margindash.queue import EventQueue
from margindash.retry import with_retry
from margindash.serializer import event_to_dict
from margindash.types import Event, MarginDashError, Usage

logger = logging.getLogger("margindash")

MAX_PENDING_USAGES = 1000


class MarginDash:
    """Synchronous client for the MarginDash event-tracking API.

    Usage::

        md = MarginDash(api_key="md_live_...")
        md.add_usage("openai", Usage(
            model="gpt-4o",
            input_tokens=1200,
            output_tokens=340,
        ))
        md.track(Event(customer_id=user.id))
        # background daemon thread flushes automatically
        md.shutdown()

    Parameters
    ----------
    api_key:
        Your MarginDash API key.
    base_url:
        API base URL.  Defaults to the production endpoint.
    flush_interval:
        Seconds between automatic background flushes.
    max_queue_size:
        Maximum events to buffer before the oldest are dropped.
    batch_size:
        Maximum events per HTTP request.
    max_retries:
        Number of retries after the initial attempt for each HTTP request.
    default_event_type:
        Default ``event_type`` applied when :pyattr:`Event.event_type` is
        ``None``.
    on_error:
        Optional callback invoked when a batch fails or partially fails.
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://margindash.com/api/v1",
        flush_interval: float = 5.0,
        max_queue_size: int = 1000,
        batch_size: int = 25,
        max_retries: int = 3,
        default_event_type: str = "ai_request",
        on_error: Callable[[MarginDashError], None] | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must be a non-empty string")
        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._default_event_type = default_event_type
        self._on_error = on_error
        self._is_shutdown = False
        self._pending_lock = threading.Lock()
        self._pending_responses: list[tuple[str, Any]] = []

        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"margindash-python/{self._get_version()}",
            },
            timeout=httpx.Timeout(30.0),
        )

        self._queue = EventQueue(
            send_fn=self._send_batch,
            flush_interval=flush_interval,
            max_size=max_queue_size,
            batch_size=batch_size,
        )

        self._queue.start()
        atexit.register(self.shutdown)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> MarginDash:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        self.shutdown()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add_usage(self, vendor_name: str, usage: Usage) -> None:
        """Record pre-normalized usage from a single AI API call.

        Call this once per AI API call, then call :meth:`track` once
        to attach all recorded usage entries to a single event.
        """
        with self._pending_lock:
            if len(self._pending_responses) >= MAX_PENDING_USAGES:
                logger.warning("margindash: pending usages limit reached (%d), dropping oldest entry", MAX_PENDING_USAGES)
                self._pending_responses.pop(0)
            self._pending_responses.append((vendor_name, {
                "ai_model_name": usage.model,
                "input_tokens": usage.input_tokens,
                "output_tokens": usage.output_tokens,
            }))

    def track(self, event: Event) -> None:
        """Enqueue an event for batch sending.

        This method is **synchronous** and never raises.  Events are buffered
        internally and sent in the background.

        All usage entries previously added via :meth:`add_usage` are drained
        and attached to the event.
        """
        if self._is_shutdown:
            logger.warning("margindash: track() called after shutdown — event discarded")
            return
        try:
            with self._pending_lock:
                responses = self._pending_responses
                self._pending_responses = []
            payload = event_to_dict(event, responses, self._default_event_type)
            self._queue.enqueue(payload)
            logger.debug("margindash: event enqueued customer_id=%s usages=%d", event.customer_id, len(responses))
        except Exception:
            logger.exception("margindash: failed to enqueue event")

    def flush(self) -> None:
        """Immediately flush all buffered events."""
        if self._is_shutdown:
            logger.warning("margindash: flush() called after shutdown — ignored")
            return
        logger.debug("margindash: flush requested")
        self._queue.flush()

    def shutdown(self) -> None:
        """Flush remaining events and close the HTTP client."""
        if self._is_shutdown:
            return
        atexit.unregister(self.shutdown)
        logger.debug("margindash: shutting down")
        self._is_shutdown = True
        self._queue.shutdown()
        self._http.close()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _get_version() -> str:
        from margindash import __version__
        return __version__

    def _send_batch(self, events: list[dict[str, Any]]) -> None:
        """Send a batch of events to the API with retry logic."""
        logger.debug("margindash: sending batch of %d events", len(events))
        try:
            def _post() -> httpx.Response:
                response = self._http.post(
                    "/events",
                    json={"events": events},
                )
                # Retry on 5xx server errors and 429 rate limits.
                if response.status_code >= 500 or response.status_code == 429:
                    response.raise_for_status()
                return response

            response = with_retry(_post, max_retries=self._max_retries)
            logger.debug("margindash: batch sent, status %d", response.status_code)

            # Handle partial failure (207 Multi-Status).
            if response.status_code == 207:
                try:
                    body = response.json()
                    failed = [r for r in body.get("results", []) if r.get("status") == "error"]
                    if failed:
                        self._report_error(MarginDashError(
                            message=f"Batch partially failed: {len(failed)} of {len(body['results'])} events had errors",
                            events=events,
                        ))
                except Exception:
                    pass
                return

            # Auth failure.
            if response.status_code == 401:
                self._report_error(MarginDashError(
                    message="Authentication failed — check your API key",
                    events=events,
                ))
                return

            # Total failure (4xx).
            if response.status_code >= 400:
                error_message = f"Batch request failed with status {response.status_code}"
                try:
                    body = response.json()
                    if body.get("error"):
                        error_message = body["error"]
                except Exception:
                    pass
                self._report_error(MarginDashError(
                    message=error_message,
                    events=events,
                ))

        except Exception as exc:
            self._report_error(MarginDashError(
                message="Batch request failed after retries",
                cause=exc,
                events=events,
            ))

    def _report_error(self, error: MarginDashError) -> None:
        """Log an error and call the on_error callback if configured."""
        logger.error("margindash: %s", error.message)
        if self._on_error is None:
            return
        try:
            self._on_error(error)
        except Exception:
            logger.exception("margindash: on_error callback raised")
