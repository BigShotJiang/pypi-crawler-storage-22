from __future__ import annotations

import logging
import random
import time
from typing import Callable, TypeVar

import httpx

T = TypeVar("T")

logger = logging.getLogger("margindash.retry")


class NonRetryableError(Exception):
    """Raised for errors that should not be retried (e.g. 401, 422)."""

    pass


def with_retry(
    fn: Callable[[], T],
    *,
    max_retries: int = 3,
) -> T:
    """Execute *fn* with exponential back-off and jitter.

    Strategy:
    - 1 initial attempt plus up to *max_retries* retries (default 3).
    - Delay between attempts: ``min(1s * 2^attempt, 30s)`` plus proportional
      jitter (up to 50% of the base delay).
    - Retries on 5xx, 429 HTTP status codes and network-level errors.
    - Immediately raises :class:`NonRetryableError` for 4xx responses that
      indicate a permanent client error (401 Unauthorized, 422 Unprocessable
      Entity).
    """

    last_exc: BaseException | None = None

    for attempt in range(max_retries + 1):
        try:
            return fn()
        except NonRetryableError:
            raise
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            if status in (401, 422):
                logger.warning("non-retryable HTTP %d, giving up", status)
                raise NonRetryableError(
                    f"Non-retryable HTTP {status}: {exc}"
                ) from exc
            # 5xx, 429, and other server errors are retryable
            last_exc = exc
            logger.warning("server error %d, attempt %d/%d", status, attempt + 1, max_retries + 1)
        except (httpx.TransportError, OSError) as exc:
            # Network-level failures are retryable
            last_exc = exc
            logger.warning("network error: %s, attempt %d/%d", exc, attempt + 1, max_retries + 1)

        if attempt < max_retries:
            base_delay = min(1.0 * (2**attempt), 30.0)
            jitter = random.uniform(0, base_delay * 0.5)
            delay = base_delay + jitter
            logger.debug("retrying in %.1fs", delay)
            time.sleep(delay)

    # All retries exhausted
    logger.warning("all %d attempts exhausted", max_retries + 1)
    raise last_exc  # type: ignore[misc]
