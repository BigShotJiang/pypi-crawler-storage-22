from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from margindash.types import Event


def event_to_dict(
    event: Event,
    responses: list[tuple[str, Any]],
    default_event_type: str,
) -> dict[str, Any]:
    """Convert an :class:`Event` dataclass + accumulated usage entries into
    the wire-format dict."""
    d: dict[str, Any] = {
        "customer_id": event.customer_id,
        "revenue_amount_in_cents": event.revenue_amount_in_cents,
        "vendor_responses": [
            {
                "vendor_name": vendor_name,
                "raw_response": raw_response,
            }
            for vendor_name, raw_response in responses
        ],
    }

    d["unique_request_token"] = (
        event.unique_request_token
        if event.unique_request_token is not None
        else str(uuid.uuid4())
    )
    d["occurred_at"] = (
        event.occurred_at
        if event.occurred_at is not None
        else datetime.now(timezone.utc).isoformat()
    )
    d["event_type"] = (
        event.event_type
        if event.event_type is not None
        else default_event_type
    )

    if event.metadata is not None:
        d["metadata"] = event.metadata

    return d
