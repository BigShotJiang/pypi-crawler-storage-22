"""MarginDash Python SDK — track AI usage and revenue."""

from margindash.client import MarginDash
from margindash.types import MarginDashError

__all__ = [
    "MarginDash",
    "MarginDashError",
]

__version__ = "1.1.6"
