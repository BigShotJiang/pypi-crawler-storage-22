"""MarginDash Python SDK — lightweight AI usage and revenue tracking."""

from __future__ import annotations

import atexit
import logging
import random
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable
from uuid import uuid4

import requests

from margindash.types import MarginDashError

logger = logging.getLogger("margindash")

_VERSION = "1.1.6"
_DEFAULT_BASE_URL = "https://margindash.com/api/v1"
_DEFAULT_FLUSH_INTERVAL = 5.0
_DEFAULT_MAX_RETRIES = 3
_DEFAULT_EVENT_TYPE = "ai_request"
_MAX_QUEUE_SIZE = 1000
_BATCH_SIZE = 50
_MAX_PENDING_USAGES = 1000
_HTTP_TIMEOUT = 10
_MAX_BACKOFF = 30.0


class MarginDash:
    """Track AI usage and revenue events.

    Usage::

        md = MarginDash(api_key="md_live_...")
        md.add_usage(vendor="openai", model="gpt-4o", input_tokens=1200, output_tokens=340)
        md.track(customer_id="cust_123")
        md.shutdown()
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        flush_interval: float = _DEFAULT_FLUSH_INTERVAL,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        default_event_type: str = _DEFAULT_EVENT_TYPE,
        on_error: Callable[[MarginDashError], None] | None = None,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError("api_key must be a non-empty string")

        self._api_key = api_key.strip()
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._default_event_type = default_event_type
        self._on_error = on_error

        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
            "User-Agent": f"margindash-python/{_VERSION}",
        })

        self._pending_usages: list[dict[str, Any]] = []
        self._queue: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()

        self._thread = threading.Thread(
            target=self._flush_loop, args=(flush_interval,), daemon=True
        )
        self._thread.start()
        atexit.register(self.shutdown)

    def __enter__(self) -> MarginDash:
        return self

    def __exit__(self, *_: Any) -> None:
        self.shutdown()

    # -- Public API -----------------------------------------------------------

    def add_usage(
        self, *, vendor: str, model: str, input_tokens: int, output_tokens: int
    ) -> None:
        """Record usage from a single AI API call."""
        with self._lock:
            if len(self._pending_usages) >= _MAX_PENDING_USAGES:
                self._pending_usages.pop(0)
                logger.warning("pending usages limit reached, dropping oldest")
            self._pending_usages.append({
                "vendor_name": vendor,
                "ai_model_name": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            })

    def track(
        self,
        *,
        customer_id: str,
        revenue_amount_in_cents: int | None = None,
        event_type: str | None = None,
        unique_request_token: str | None = None,
        occurred_at: str | None = None,
    ) -> None:
        """Enqueue an event with all buffered usage data. Never raises."""
        try:
            with self._lock:
                usages = self._pending_usages[:]
                self._pending_usages.clear()

                event: dict[str, Any] = {
                    "customer_id": customer_id,
                    "revenue_amount_in_cents": revenue_amount_in_cents,
                    "vendor_responses": usages,
                    "unique_request_token": unique_request_token or str(uuid4()),
                    "event_type": event_type or self._default_event_type,
                    "occurred_at": occurred_at or datetime.now(timezone.utc).isoformat(),
                }

                if len(self._queue) >= _MAX_QUEUE_SIZE:
                    self._queue.pop(0)
                    logger.warning("queue full, dropping oldest event")
                self._queue.append(event)
        except Exception:
            logger.exception("margindash: failed to enqueue event")

    def flush(self) -> None:
        """Send all queued events immediately."""
        with self._lock:
            events = self._queue[:]
            self._queue.clear()

        for i in range(0, len(events), _BATCH_SIZE):
            batch = events[i : i + _BATCH_SIZE]
            try:
                self._send(batch)
            except Exception as e:
                self._report_error(
                    "Request failed after retries", cause=e, events=batch
                )

    def shutdown(self) -> None:
        """Stop background flushing and send remaining events."""
        if self._stop.is_set():
            return
        atexit.unregister(self.shutdown)
        self._stop.set()
        self._thread.join(timeout=5.0)
        self.flush()
        self._session.close()

    # -- Internals ------------------------------------------------------------

    def _flush_loop(self, interval: float) -> None:
        while not self._stop.wait(interval):
            try:
                self.flush()
            except Exception as e:
                self._report_error(f"Flush error: {e}", cause=e)

    def _send(self, events: list[dict[str, Any]]) -> None:
        last_err: Exception | None = None

        for attempt in range(1 + self._max_retries):
            try:
                resp = self._session.post(
                    f"{self._base_url}/events",
                    json={"events": events},
                    timeout=_HTTP_TIMEOUT,
                )
                if resp.status_code == 429 or resp.status_code >= 500:
                    resp.raise_for_status()

                logger.debug("sent %d events (HTTP %d)", len(events), resp.status_code)

                if not resp.ok:
                    self._report_error(
                        f"Request failed with status {resp.status_code}: {resp.text}",
                        events=events,
                    )
                return
            except (requests.ConnectionError, requests.Timeout) as e:
                last_err = e
            except requests.HTTPError as e:
                last_err = e

            if attempt < self._max_retries:
                backoff = min(2.0 ** attempt, _MAX_BACKOFF)
                time.sleep(backoff + backoff * random.uniform(0, 0.5))

        if last_err:
            raise last_err

    def _report_error(
        self,
        message: str,
        *,
        cause: Exception | None = None,
        events: list | None = None,
    ) -> None:
        logger.error("margindash: %s", message)
        if self._on_error:
            try:
                self._on_error(MarginDashError(message=message, cause=cause, events=events))
            except Exception:
                pass

