from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MarginDashError:
    message: str
    cause: Exception | None = None
    events: list | None = None
