from marinerg_data_access.models import Dataset


def setup_default_datasets(creator):

    internal = Dataset.objects.create(
        creator=creator,
        title="Dataset 1",
        description="description of dataset",
        uri="http://doi.zenodo.org",
        is_public=True,
        public=False,
    )

    public = Dataset.objects.create(
        creator=creator,
        title="Dataset 2",
        description="description of dataset",
        uri="http://doi.zenodo.org",
        is_public=True,
        public=True,
    )
    return internal, public
