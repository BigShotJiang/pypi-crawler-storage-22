from .views import (
    DatasetViewSet,
    DatasetTagViewSet,
    DatasetTemplateViewSet,
    DatasetIdAuthorityViewSet,
    LicenseViewSet,
)


def register_drf_views(router):
    router.register(r"datasets", DatasetViewSet)
    router.register(r"dataset_tags", DatasetTagViewSet)
    router.register(r"dataset_templates", DatasetTemplateViewSet)
    router.register(r"dataset_id_authorities", DatasetIdAuthorityViewSet)
    router.register(r"licenses", LicenseViewSet)


urlpatterns: list = []
