from rest_framework import permissions

from ichec_django_core.views import SearchableModelViewSet

from marinerg_data_access.models import License
from marinerg_data_access.serializers import LicenseSerializer


class LicenseViewSet(SearchableModelViewSet):
    queryset = License.objects.all()
    serializer_class = LicenseSerializer
    permission_classes = [permissions.DjangoModelPermissions]

    ordering_fields = SearchableModelViewSet.ordering_fields
    ordering: tuple[str, ...] = ("full_name",)
    search_fields = ["full_name", "identifier"]
