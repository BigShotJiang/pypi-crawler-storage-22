from ichec_django_core.models import Member
from ichec_django_core.test import (
    AuthAPITestCase,
    setup_default_users_and_groups,
    add_group_permissions,
)

from marinerg_data_access.client.resources import create_datasets_no_template
from marinerg_data_access.models import Dataset
from marinerg_data_access.test import setup_default_datasets


class TestDatasetView(AuthAPITestCase):

    template = create_datasets_no_template(1)[0]
    update_template = {"title": "My Title Updated"}

    def setUp(self):
        self.url = "/api/datasets/"
        setup_default_users_and_groups()

        add_group_permissions(
            "admins",
            Dataset,
            ["view_dataset", "change_dataset", "add_dataset", "delete_dataset"],
        )

        add_group_permissions(
            "members",
            Dataset,
            ["view_dataset", "add_dataset"],
        )

        items = setup_default_datasets(Member.objects.get(username="other_user"))
        self.internal, self.public = items

    def test_list_access(self):

        scenarios = (
            ["", 1, 200, "Public can list public items"],
            ["regular_user", 1, 200, "Registered can list public items"],
            ["member", 2, 200, "Member can list all items"],
            ["other_user", 2, 200, "Item creator can list item"],
        )
        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            self.assertEqual(response.body.count, count, msg)

    def test_detail_access(self):

        public = self.public.id
        internal = self.internal.id
        scenarios = (
            ["", public, 200, "Public can view public item"],
            ["", internal, 404, "Public can't view internal item"],
            ["regular_user", public, 200, "Registered can view public item"],
            ["regular_user", internal, 404, "Registered can't view internal item"],
            ["member", public, 200, "Member can view public item"],
            ["member", internal, 200, "Member can view internal item"],
            ["other_user", internal, 200, "Item creator can view item"],
        )

        for user, item, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item), status, msg)
            else:
                self.assert_status(self.detail(item), status, msg)

    def test_create_permissions(self):

        scenarios = (
            ["", 401, "Public can't create, no auth"],
            ["regular_user", 403, "Registered can't create, no perm"],
            ["member", 201, "Member can create"],
            ["admin_user", 201, "Admin can create"],
        )

        for user, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_create(user, self.template), status, msg)
            else:
                self.assert_status(self.create(self.template), status, msg)

    def _create_for_update(self, creator):

        created = self.assert_201(self.auth_create(creator, self.template)).body
        return created.model_copy(update={"title": "Updated Title"})

    def _verify_update(self, updated):
        self.assertEqual(updated.body.title, "Updated Title")

    def test_update_permissions(self):

        scenarios = (
            ["", 401, False, "Public can't update, no auth"],
            ["regular_user", 403, False, "Registered can't update, no auth"],
            ["member", 200, True, "Item creator can update"],
            ["admin_user", 200, False, "Admin can update"],
        )

        for user, status, creator, msg in scenarios:
            if creator:
                created = self._create_for_update(user)
            else:
                created = self._create_for_update("admin_user")
            updated = None
            if user:
                updated = self.assert_status(
                    self.auth_update(user, created.id, created), status, msg
                )
            else:
                self.assert_status(self.update(created.id, created), status, msg)

            if updated:
                self._verify_update(updated)

    def test_delete_permissions(self):

        scenarios = (
            ["", 401, False, "Public can't delete, no auth"],
            ["regular_user", 403, False, "Registered can't delete"],
            #  ["member", 403, True, "Item creator can't delete"],
            ["admin_user", 204, False, "Admin can delete"],
        )

        for user, status, member, msg in scenarios:
            if member:
                created = self._create_for_update(user)
            else:
                created = self._create_for_update("admin_user")

            if user:
                self.assert_status(self.auth_delete(user, created.id), status, msg)
            else:
                self.assert_status(self.delete(created.id), status, msg)

    def test_filters(self):
        pass

    def test_fields(self):
        pass
