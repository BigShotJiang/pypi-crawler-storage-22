from rest_framework import permissions
from rest_framework.decorators import action

from ichec_django_core.views import ObjectFileUploadView
from ichec_django_core.views.core import SearchableModelViewSet
from ichec_django_core.views.files import DEFAULT_IMAGE_FORMATS
from ichec_django_core.views.permissions import MemberEditOrDjangoModelPermissions

from marinerg_facility.models import Facility, FacilityTag
from marinerg_facility.serializers import (
    FacilityListSerializer,
    FacilityDetailSerializer,
    FacilityTagSerializer,
)


class FacilityViewSet(SearchableModelViewSet):

    queryset = Facility.objects.all()
    serializer_class = FacilityListSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        MemberEditOrDjangoModelPermissions,
    ]
    ordering_fields = SearchableModelViewSet.ordering_fields + ("name",)
    ordering: tuple[str, ...] = ("name",)
    search_fields = ["name", "address__line1", "address__country", "address__region"]

    serializers = {
        "retrieve": FacilityDetailSerializer,
        "list": FacilityListSerializer,
        "create": FacilityDetailSerializer,
        "update": FacilityDetailSerializer,
        "partial_update": FacilityDetailSerializer,
    }
    filterset_fields = ("members__id",)

    @action(detail=True, url_path="image", url_name="image")
    def image(self, request, pk=None):
        return self.download(request, "image")

    @action(detail=True, url_path="thumbnail", url_name="thumbnail")
    def thumbnail(self, request, pk=None):
        return self.download(request, "thumbnail")

    def get_queryset(self):
        queryset = self.queryset
        choices = self.request.query_params.get("application_choices__id")
        if choices is not None:
            queryset = queryset.filter(application_choices__id=choices)
        return queryset


class FacilityTagViewSet(SearchableModelViewSet):
    queryset = FacilityTag.objects.all()
    serializer_class = FacilityTagSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]
    ordering_fields = ("value",)
    ordering: tuple[str, ...] = ("value",)
    search_fields = ["value"]
    filterset_fields = ("facilities__id",)


class FacilityImageUploadView(ObjectFileUploadView):
    model = Facility
    queryset = Facility.objects.all()
    file_field = "image"
    extensions = DEFAULT_IMAGE_FORMATS
    permission_classes = [
        permissions.IsAuthenticated,
        MemberEditOrDjangoModelPermissions,
    ]
