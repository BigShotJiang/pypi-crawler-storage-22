from rest_framework import serializers

from ichec_django_core.serializers.core import SERIALIZER_BASE_FIELDS

from marinerg_test_access.models import (
    FacilityTestReport,
    AccessApplicationFacilityReview,
    AccessApplicationBoardReview,
    AccessApplicationBoardDecision,
)


class FacilityTestReportSerializer(serializers.HyperlinkedModelSerializer):

    report = serializers.HyperlinkedIdentityField(
        read_only=True, view_name="facility_test_report-report"
    )

    class Meta:
        model = FacilityTestReport
        fields = SERIALIZER_BASE_FIELDS + (
            "creator",
            "report",
            "datasets",
            "confirmed_complies_data_mgmt",
            "application",
            "facility",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("creator", "report")

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        if not instance.report:
            rep["report"] = None
        return rep


class AccessApplicationFacilityReviewSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = AccessApplicationFacilityReview
        fields = SERIALIZER_BASE_FIELDS + (
            "confirmed_preapplication_discussion",
            "confirmed_app_info_in_line_with_discussion",
            "supporting_comments",
            "supporting_documents",
            "application",
            "facility",
        )


class AccessApplicationBoardReviewSerializer(serializers.HyperlinkedModelSerializer):

    supporting_document = serializers.HyperlinkedIdentityField(
        read_only=True, view_name="accessapplicationboardreview-supporting_document"
    )

    class Meta:
        model = AccessApplicationBoardReview
        fields = SERIALIZER_BASE_FIELDS + (
            "decision",
            "comments",
            "reviewer",
            "application",
            "supporting_document",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("reviewer",)

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        if not instance.supporting_document:
            rep["supporting_document"] = None
        return rep


class AccessApplicationBoardDecisionSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = AccessApplicationBoardDecision
        fields = SERIALIZER_BASE_FIELDS + (
            "decision",
            "comments",
            "reviewer",
            "application",
        )
        read_only_fields = SERIALIZER_BASE_FIELDS + ("reviewer",)
