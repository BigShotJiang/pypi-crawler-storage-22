from pathlib import Path

from django.utils import timezone

from ichec_django_core.models import (
    Member,
    Form,
    FormGroup,
    FormField,
    PopulatedForm,
    FormFieldValue,
)

from marinerg_test_access.models import AccessCall, AccessApplication


def _setup_access_call_members():

    coordinator = Member.objects.create(
        username="coordinator",
        first_name="Access Call",
        last_name="Coordinator",
        email="coordinator@example.com",
    )
    chair = Member.objects.create(
        username="chair",
        first_name="Access Call",
        last_name="Board Member",
        email="chair@example.com",
    )
    reviewer1 = Member.objects.create(
        username="reviewer1",
        first_name="Reviewer 1",
        last_name="Board Member",
        email="chair@example.com",
    )

    reviewer2 = Member.objects.create(
        username="reviewer2",
        first_name="Reviewer2",
        last_name="Board Member",
        email="chair@example.com",
    )

    reviewer3 = Member.objects.create(
        username="reviewer3",
        first_name="Reviewer3",
        last_name="Board Member",
        email="chair@example.com",
    )
    return coordinator, chair, reviewer1, reviewer2, reviewer3


def _setup_form():
    form = Form.objects.create()

    group = FormGroup.objects.create(form=form)

    FormField.objects.create(
        group=group,
        label="Sample Bool Field?",
        key="bool_field",
        required=True,
        field_type="BOOLEAN",
    )

    FormField.objects.create(
        group=group,
        label="Description of device",
        key="description",
        required=True,
        field_type="TEXT",
    )

    FormField.objects.create(
        group=group,
        label="Application Form",
        key="application_form",
        required=True,
        field_type="FILE",
    )

    FormField.objects.create(
        group=group,
        label="Application Form Docx",
        key="application_form_docx",
        required=True,
        field_type="FILE",
    )

    FormField.objects.create(
        group=group,
        label="Application Form Doc",
        key="application_form_doc",
        required=True,
        field_type="FILE",
    )
    return form


def _setup_access_call(public: bool, active: bool, members):

    coordinator, chair, reviewer1, reviewer2, reviewer3 = members

    call = AccessCall.objects.create(
        title="Access call",
        description="Description of access call",
        status="OPEN",
        closing_date=timezone.now(),
        coordinator=coordinator,
        board_chair=chair,
        form=_setup_form(),
        public=public,
        active=active,
    )
    call.board_members.set([reviewer1, reviewer2, reviewer3])
    return call


def setup_default_access_calls():

    members = _setup_access_call_members()
    internal = _setup_access_call(False, True, members)
    public = _setup_access_call(True, True, members)
    inactive = _setup_access_call(True, False, members)
    return internal, public, inactive


def _setup_appliction_form(call, assets: list[tuple[str, Path]] | None = None):

    form = PopulatedForm.objects.create()

    FormFieldValue.objects.create(
        value="TRUE", field=call.get_field_by_key("bool_field"), form=form
    )

    if assets:
        for key, path in assets:

            file_field = FormFieldValue.objects.create(
                field=call.get_field_by_key(key), form=form
            )
            file_field.asset.original_filename = path.name
            file_field.asset.name = str(path)
            file_field.save()
    return form


def setup_application(
    call, applicant="test_applicant", assets: list[tuple[str, Path]] | None = None
):

    applicant = Member.objects.create(
        username=applicant,
        first_name="Test",
        last_name="Applicant",
        email=applicant + "@example.com",
    )
    return AccessApplication.objects.create(
        applicant=applicant, call=call, form=_setup_appliction_form(call, assets)
    )
