from django.urls import path

from .views import (
    AccessApplicationViewSet,
    ApplicationFieldDownloadView,
    ApplicationFieldUploadView,
    AccessCallViewSet,
    AccessCallReviewTemplateUploadView,
    AccessCallFieldDownloadView,
    AccessCallFieldUploadView,
    AccessCallFacilityReviewViewSet,
    AccessApplicationFacilityReviewViewSet,
    AccessApplicationBoardReviewViewSet,
    AccessApplicationBoardReviewSupportingDocumentUploadView,
    AccessApplicationBoardDecisionViewSet,
    FacilityTestReportViewSet,
    TestReportUploadView,
)


def register_drf_views(router):
    router.register(r"access_calls", AccessCallViewSet)
    router.register(r"access_call_facility_reviews", AccessCallFacilityReviewViewSet)
    router.register(r"access_applications", AccessApplicationViewSet)
    router.register(
        r"access_application_facility_reviews", AccessApplicationFacilityReviewViewSet
    )
    router.register(
        r"access_application_board_reviews", AccessApplicationBoardReviewViewSet
    )
    router.register(
        r"access_application_board_decisions", AccessApplicationBoardDecisionViewSet
    )
    router.register(r"facility_test_reports", FacilityTestReportViewSet)


urlpatterns = [
    path(
        r"facility_test_reports/<int:pk>/report/upload",
        TestReportUploadView.as_view(),
        name="test_report_upload",
    ),
    path(
        r"access_application_board_reviews/<int:pk>/supporting_document/upload",
        AccessApplicationBoardReviewSupportingDocumentUploadView.as_view(),
        name="supporting_document_upload",
    ),
    path(
        r"access_applications/<int:pk>/fields/<int:value_id>",
        ApplicationFieldDownloadView.as_view(),
        name="application_field_download",
    ),
    path(
        r"access_applications/<int:pk>/fields/<int:value_id>/upload",
        ApplicationFieldUploadView.as_view(),
        name="application_field_upload",
    ),
    path(
        r"access_calls/<int:pk>/fields/<int:value_id>",
        AccessCallFieldDownloadView.as_view(),
        name="access_call_field_download",
    ),
    path(
        r"access_calls/<int:pk>/fields/<int:value_id>/upload",
        AccessCallFieldUploadView.as_view(),
        name="access_call_field_upload",
    ),
    path(
        r"access_calls/<int:pk>/review_template/upload",
        AccessCallReviewTemplateUploadView.as_view(),
        name="access_call_review_template_upload",
    ),
]
