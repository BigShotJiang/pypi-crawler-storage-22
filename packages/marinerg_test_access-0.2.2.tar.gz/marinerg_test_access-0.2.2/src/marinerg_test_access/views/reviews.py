from rest_framework import permissions, viewsets
from rest_framework.decorators import action

from ichec_django_core.models import Member
from ichec_django_core.views import ObjectFileUploadView, BaseModelViewSet

from ..models import (
    FacilityTestReport,
    AccessApplicationFacilityReview,
    AccessApplicationBoardReview,
    AccessApplicationBoardDecision,
)

from ..serializers import (
    FacilityTestReportSerializer,
    AccessApplicationFacilityReviewSerializer,
    AccessApplicationBoardReviewSerializer,
    AccessApplicationBoardDecisionSerializer,
)


class FacilityTestReportViewSet(BaseModelViewSet):
    queryset = FacilityTestReport.objects.all().order_by("id")
    serializer_class = FacilityTestReportSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]

    @action(detail=True, url_path="report", url_name="report")
    def report(self, request, pk=None):
        return self.download(request, "report")

    def perform_create(self, serializer):
        serializer.save(creator=Member.objects.get(id=self.request.user.id))


class TestReportUploadView(ObjectFileUploadView):
    model = FacilityTestReport
    queryset = FacilityTestReport.objects.all()
    file_field = "report"
    extensions = (".odt", ".doc", ".docx", ".pdf")
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]


class AccessApplicationFacilityReviewViewSet(viewsets.ModelViewSet):
    queryset = AccessApplicationFacilityReview.objects.all().order_by("id")
    serializer_class = AccessApplicationFacilityReviewSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]


class AccessApplicationBoardReviewViewSet(viewsets.ModelViewSet):
    queryset = AccessApplicationBoardReview.objects.all().order_by("id")
    serializer_class = AccessApplicationBoardReviewSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]

    @action(detail=True, url_path="supporting_document", url_name="supporting_document")
    def supporting_document(self, request, pk=None):
        return self.download(request, "supporting_document")

    def perform_create(self, serializer):
        serializer.save(reviewer=Member.objects.get(id=self.request.user.id))


class AccessApplicationBoardReviewSupportingDocumentUploadView(ObjectFileUploadView):
    model = AccessApplicationBoardReview
    queryset = AccessApplicationBoardReview.objects.all()
    file_field = "supporting_document"
    extensions = (".odt", ".doc", ".docx", ".pdf")
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]


class AccessApplicationBoardDecisionViewSet(viewsets.ModelViewSet):
    queryset = AccessApplicationBoardDecision.objects.all().order_by("id")
    serializer_class = AccessApplicationBoardDecisionSerializer
    permission_classes = [
        permissions.IsAuthenticated,
        permissions.DjangoModelPermissions,
    ]

    def perform_create(self, serializer):
        serializer.save(reviewer=Member.objects.get(id=self.request.user.id))
