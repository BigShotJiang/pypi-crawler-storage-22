from django.utils import timezone

from ichec_django_core.models import Member
from ichec_django_core.client import MemberDetail, FormFieldCreate

from ichec_django_core.test import (
    AuthAPITestCase,
    add_group_permissions,
    setup_default_users_and_groups,
)

from marinerg_test_access.client.resources import create_access_calls
from marinerg_test_access.models import AccessCall
from marinerg_test_access.test import setup_default_access_calls


class TestAccessCallView(AuthAPITestCase):

    def _get_review_board(self) -> list[MemberDetail]:
        return [
            self.get_member_detail(n).body
            for n in ["coordinator", "chair", "reviewer1", "reviewer2", "reviewer3"]
        ]

    def setUp(self):
        self.url = "/api/access_calls/"

        setup_default_users_and_groups()
        add_group_permissions(
            "admins",
            AccessCall,
            [
                "view_accesscall",
                "change_accesscall",
                "add_accesscall",
                "delete_accesscall",
            ],
        )
        add_group_permissions("members", AccessCall, ["view_accesscall"])

        self.internal, self.public, self.inactive = setup_default_access_calls()
        self.template = create_access_calls(1, members=self._get_review_board())[0]

    def get_template(self, username: str = "admin_user") -> dict:
        return self.template.model_copy(
            update={
                "coordinator": self.get_member_url(username),
                "board_chair": self.get_member_url(username),
            }
        )

    def test_list_access(self):

        scenarios = (
            ["", 1, 200, "Public can list public items"],
            ["regular_user", 1, 200, "Registered can list public items"],
            ["member", 2, 200, "Member can list all items"],
            ["coordinator", 2, 200, "Coordinator can list item"],
            ["reviewer1", 2, 200, "Reviewer can list item"],
            ["chair", 2, 200, "Chair can list item"],
        )
        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            self.assertEqual(response.body.count, count, msg)

    def xtest_detail_access(self):

        public = self.public.id
        internal = self.internal.id
        scenarios = (
            ["", public, "public", 200, "Public can view public item"],
            ["", internal, "public", 404, "Public can't view internal item"],
            ["regular_user", public, "public", 200, "Registered can view public item"],
            [
                "regular_user",
                internal,
                "public",
                404,
                "Registered can't view internal item",
            ],
            ["member", public, "public", 200, "Member can view public item"],
            ["member", internal, "public", 200, "Member can view internal item"],
            ["coordinator", internal, "", 200, "Coordinator can view internal item"],
            ["chair", internal, "", 200, "Chair can view internal item"],
            ["reviewer1", internal, "reviewer", 200, "Reviewer can view internal item"],
        )

        for user, item, role, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item, role), status, msg)
            else:
                self.assert_status(self.detail(item, role), status, msg)

    def test_create_permissions(self):

        scenarios = (
            ["", 401, "Public can't create, no auth"],
            ["regular_user", 403, "Registered can't create, no perm"],
            ["member", 403, "Member can't create, no perm"],
            ["admin_user", 201, "Admin can create"],
        )

        for user, status, msg in scenarios:
            if user:
                self.assert_status(
                    self.auth_create(user, self.get_template()), status, msg
                )
            else:
                self.assert_status(self.create(self.get_template()), status, msg)

    def test_update_permissions(self):
        created = self.assert_201(
            self.auth_create("admin_user", self.get_template())
        ).body

        new_field = FormFieldCreate(
            label="Requires More Support",
            key="requires_more_support",
            description="Do you require more facility support?",
            field_type="BOOLEAN",
            default="false",
        )
        updated_group = created.form.groups[0].model_copy(
            update={"fields": created.form.groups[0].fields + [new_field]}
        )

        updated = created.model_copy(
            update={
                "description": "Modified description of my access call",
                "form": created.form.model_copy(update={"groups": [updated_group]}),
            }
        )

        updated = self.assert_200(self.auth_update("admin_user", created.id, updated))

        self.assertTrue(
            updated.body.description == "Modified description of my access call"
        )
        self.assertTrue(len(updated.body.form.groups[0].fields) == 3)
