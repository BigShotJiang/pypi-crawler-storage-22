from ichec_django_core.test import (
    AuthAPITestCase,
    add_group_permissions,
    setup_default_users_and_groups,
)

from marinerg_test_access.models import AccessApplication
from marinerg_test_access.client import AccessCallPublicDetail
from marinerg_test_access.client.resources import create_applications
from marinerg_test_access.test import (
    setup_default_access_calls,
    setup_application,
)


class TestApplicationView(AuthAPITestCase):

    def setUp(self):
        self.url = "/api/access_applications/"
        setup_default_users_and_groups()

        add_group_permissions(
            "regular_users",
            AccessApplication,
            [
                "add_accessapplication",
            ],
        )

        add_group_permissions(
            "admins",
            AccessApplication,
            [
                "view_accessapplication",
                "add_accessapplication",
            ],
        )

        self.internal, self.public, _ = setup_default_access_calls()
        self.application1 = setup_application(self.public, "applicant")
        self.application2 = setup_application(self.public, "applicant2")

        call = self.raw_get(f"/api/access_calls/{self.public.id}/")
        call = AccessCallPublicDetail(**call.body)
        self.template = create_applications(call, 1)[0]

    def xtest_list_access(self):

        scenarios = (
            ["", 0, 401, "Public can't see any applications"],
            ["regular_user", 0, 200, "Registered user sees no applications"],
            ["member", 0, 200, "Member sees no applications"],
            ["coordinator", 2, 200, "Coordinator can list application"],
            ["reviewer1", 2, 200, "Reviewer can list application"],
            ["chair", 2, 200, "Chair can list application"],
            ["applicant", 1, 200, "Applicant can list application"],
            ["admin_user", 2, 200, "Admin can list application"],
        )
        for user, count, status, msg in scenarios:
            if user:
                response = self.assert_status(self.auth_list(user), status, msg)
            else:
                response = self.assert_status(self.public_list(), status, msg)

            if status < 400:
                self.assertEqual(response.body.count, count, msg)

    def xtest_detail_access(self):

        app = self.application1.id
        scenarios = (
            ["", app, 401, "Public can't view item"],
            ["regular_user", app, 404, "Registered can't view item"],
            ["member", app, 404, "Member can't view item"],
            ["applicant", app, 200, "Applicant can view item"],
            ["coordinator", app, 200, "Coordinator can view item"],
            ["chair", app, 200, "Chair can view item"],
            ["reviewer1", app, 200, "Reviewer can view item"],
            ["admin_user", app, 200, "Admin can view item"],
        )

        for user, item, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_detail(user, item), status, msg)
            else:
                self.assert_status(self.detail(item), status, msg)

    def xtest_create_permissions(self):

        scenarios = (
            ["", 401, "Public can't create, no auth"],
            ["regular_user", 201, "Registered can create"],
            ["admin_user", 201, "Admin can create"],
        )

        for user, status, msg in scenarios:
            if user:
                self.assert_status(self.auth_create(user, self.template), status, msg)
            else:
                self.assert_status(self.create(self.template), status, msg)

    def xtest_update_regular_user(self):
        response = self.auth_create("regular_user", self.template)
        self.assert_201(response)

        created = response.body
        updated = created.model_copy(update={"dates_flexible": False})

        updated = self.auth_update("regular_user", created.id, updated)
        # self.assert_200(updated)

    def xtest_submit(self):
        response = self.auth_create("regular_user", self.template)
        self.assert_201(response)
        created = response.body

        updated = created.model_copy(update={"status": "SUBMITTED"})
        updated = self.auth_update("regular_user", created.id, updated)
        # self.assert_200(updated)
