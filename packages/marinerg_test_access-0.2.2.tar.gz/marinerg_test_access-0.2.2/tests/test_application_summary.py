from pathlib import Path
from django.test import TestCase
from django.core import mail

from ichec_django_core.models import Member

from ichec_django_core.test import (
    setup_default_users_and_groups,
)

from marinerg_test_access.test import (
    setup_default_access_calls,
    setup_application,
)


class ApplicationSummaryTestCase(TestCase):

    def setUp(self):
        setup_default_users_and_groups()
        public, _, _ = setup_default_access_calls()

        test_data_dir = Path(__file__).parent / "data"
        self.application = setup_application(
            public,
            "test_application",
            [
                ("application_form", test_data_dir / "test_application.pdf"),
                ("application_form_docx", test_data_dir / "Sample_docx.docx"),
                ("application_form_doc", test_data_dir / "Sample_doc.doc"),
            ],
        )

    def test_summary_generation(self):
        self.application.status = "SUBMITTED"
        self.application.save()
