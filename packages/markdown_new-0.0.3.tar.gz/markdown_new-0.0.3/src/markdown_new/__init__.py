"""Top-level public interface for the markdown.new Python client package."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

_RE_EXPORTS = {
    "AsyncMarkdownNewClient": "markdown_new.client:AsyncMarkdownNewClient",
    "MarkdownNewAuthenticationError": "markdown_new.exceptions:MarkdownNewAuthenticationError",
    "MarkdownNewClient": "markdown_new.client:MarkdownNewClient",
    "MarkdownNewConversionError": "markdown_new.exceptions:MarkdownNewConversionError",
    "MarkdownNewHTTPError": "markdown_new.exceptions:MarkdownNewHTTPError",
    "MarkdownNewInvalidURLError": "markdown_new.exceptions:MarkdownNewInvalidURLError",
    "MarkdownNewRateLimitError": "markdown_new.exceptions:MarkdownNewRateLimitError",
    "MarkdownNewRequestError": "markdown_new.exceptions:MarkdownNewRequestError",
    "MarkdownResponse": "markdown_new.models:MarkdownResponse",
}


def _load(path: str):
    module_name, symbol_name = path.split(":")
    module = importlib.import_module(module_name)
    return getattr(module, symbol_name)


def create_client(*, async_client: bool = False, **kwargs):
    """Create a ready-to-use markdown.new client."""
    if async_client:
        cls = _load(_RE_EXPORTS["AsyncMarkdownNewClient"])
        return cls(**kwargs)

    cls = _load(_RE_EXPORTS["MarkdownNewClient"])
    return cls(**kwargs)


def __getattr__(name: str):
    if name == "__version__":
        module = importlib.import_module("markdown_new._version")
        return module.__version__
    path = _RE_EXPORTS.get(name)
    if path is None:
        raise AttributeError(name)
    return _load(path)


def __dir__() -> list[str]:
    return sorted(__all__)


__all__ = [
    "AsyncMarkdownNewClient",
    "MarkdownNewClient",
    "MarkdownResponse",
    "MarkdownNewAuthenticationError",
    "MarkdownNewConversionError",
    "MarkdownNewHTTPError",
    "MarkdownNewInvalidURLError",
    "MarkdownNewRateLimitError",
    "MarkdownNewRequestError",
    "create_client",
    "__version__",
]


if TYPE_CHECKING:
    from ._version import __version__
    from .client import AsyncMarkdownNewClient, MarkdownNewClient
    from .exceptions import (
        MarkdownNewAuthenticationError,
        MarkdownNewConversionError,
        MarkdownNewHTTPError,
        MarkdownNewInvalidURLError,
        MarkdownNewRateLimitError,
        MarkdownNewRequestError,
    )
    from .models import MarkdownResponse
