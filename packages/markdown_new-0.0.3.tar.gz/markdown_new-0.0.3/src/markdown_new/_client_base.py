"""Shared client helpers used by sync and async markdown.new clients."""

from __future__ import annotations

import json
import urllib.parse
from typing import Mapping

import httpx

from ._version import __version__
from .exceptions import (
    MarkdownNewAuthenticationError,
    MarkdownNewConversionError,
    MarkdownNewHTTPError,
    MarkdownNewInvalidURLError,
    MarkdownNewRateLimitError,
    MarkdownNewRequestError,
)
from .models import MarkdownResponse


def _from_chars(*codes: int) -> str:
    return "".join(chr(code) for code in codes)


_SCHEME = _from_chars(104, 116, 116, 112, 115)
_SEPARATOR = _from_chars(58, 47, 47)
MARKDOWN_NEW_DOMAIN = _from_chars(109, 97, 114, 107, 100, 111, 119, 110)
DEFAULT_BASE_URL = f"{_SCHEME}{_SEPARATOR}{MARKDOWN_NEW_DOMAIN}{_from_chars(46)}{_from_chars(110, 101, 119)}"
DEFAULT_TIMEOUT = 30.0
_SAFE_URL_CHARS = ":/[]@"


def _normalize_url(url: str) -> str:
    """Validate and percent-encode a target URL."""
    if not isinstance(url, str):
        raise MarkdownNewInvalidURLError("URL must be a string")

    target = url.strip()
    if not target:
        raise MarkdownNewInvalidURLError("URL must not be empty")

    parsed = urllib.parse.urlparse(target)
    if parsed.scheme.lower() not in {_SCHEME, f"{_SCHEME}s"}:
        raise MarkdownNewInvalidURLError("URL must include a scheme (http or https) and be publicly accessible")
    if not parsed.netloc:
        example_host = _from_chars(101, 120, 97, 109, 112, 108, 101)
        example_domain = _from_chars(99, 111, 109)
        raise MarkdownNewInvalidURLError(
            (
                "URL must include a network location, for example "
                f"{_SCHEME}{_SEPARATOR}{example_host}"
                f"{_from_chars(46)}{example_domain}"
            )
        )

    return urllib.parse.quote(target, safe=_SAFE_URL_CHARS)


def _to_int(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return None


class _BaseMarkdownClient:
    """Shared sync/async response parsing and error handling."""

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        api_key: str | None = None,
        api_key_header: str = "X-API-Key",
        api_key_prefix: str = "",
        headers: Mapping[str, str] | None = None,
        user_agent: str | None = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url cannot be empty")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.api_key_header = api_key_header
        self.api_key_prefix = api_key_prefix.strip()

        merged_headers = {
            "Accept": "text/markdown; charset=utf-8",
            "User-Agent": user_agent or f"markdown-new-python/{__version__}",
        }
        if headers:
            merged_headers.update(headers)
        if api_key:
            merged_headers[self.api_key_header] = f"{self.api_key_prefix} {api_key}" if self.api_key_prefix else api_key
        self.default_headers = merged_headers

    def _resolve_request_timeout(self, timeout: float | None, *, url: str) -> float:
        request_timeout = timeout if timeout is not None else self.timeout
        if not isinstance(request_timeout, (int, float)):
            raise MarkdownNewRequestError("timeout must be a number", url=url)
        return request_timeout

    @staticmethod
    def _extract_error_message(response: httpx.Response) -> str:
        if response.headers.get("content-type", "").lower().startswith("application/json"):
            try:
                payload = response.json()
            except (json.JSONDecodeError, ValueError):
                return response.text
            if isinstance(payload, dict):
                if isinstance(payload.get("error"), str):
                    return payload["error"]
                if isinstance(payload.get("message"), str):
                    return payload["message"]
        return response.text

    @staticmethod
    def _content_type(response: httpx.Response) -> str:
        return (response.headers.get("content-type") or "").split(";", 1)[0].strip().lower()

    @staticmethod
    def _build_response(
        response: httpx.Response,
        requested_url: str,
        normalized_url: str,
    ) -> MarkdownResponse:
        return MarkdownResponse(
            markdown=response.text,
            requested_url=requested_url,
            normalized_url=normalized_url,
            status_code=response.status_code,
            content_type=_BaseMarkdownClient._content_type(response),
            markdown_tokens=_to_int(response.headers.get("x-markdown-tokens")),
            headers=dict(response.headers),
        )

    def _handle_error(self, response: httpx.Response, requested_url: str) -> None:
        message = self._extract_error_message(response) or f"HTTP {response.status_code}"
        if response.status_code in {401, 403}:
            raise MarkdownNewAuthenticationError(message, url=requested_url)
        if response.status_code == 429:
            raise MarkdownNewRateLimitError(message, url=requested_url)
        if 400 <= response.status_code < 500:
            raise MarkdownNewConversionError(message, url=requested_url)
        raise MarkdownNewHTTPError(
            message,
            status_code=response.status_code,
            response_text=response.text,
            response_headers=dict(response.headers),
            url=requested_url,
        )

    def _full_request_url(self, target_url: str) -> str:
        encoded = _normalize_url(target_url)
        return f"{self.base_url}/{encoded}"

    def _send_headers(self, headers: Mapping[str, str] | None = None) -> dict[str, str]:
        if headers is None:
            return dict(self.default_headers)
        outgoing = dict(self.default_headers)
        outgoing.update(headers)
        return outgoing

    def _check_response(self, response: httpx.Response, requested_url: str) -> MarkdownResponse:
        if response.status_code >= 400:
            self._handle_error(response, requested_url)
        content_type = self._content_type(response)
        if not content_type.startswith("text/markdown"):
            message = self._extract_error_message(response)
            if not message:
                message = f"Unexpected response content-type '{content_type}'"
            raise MarkdownNewConversionError(message, url=requested_url)
        normalized_url = _normalize_url(requested_url)
        return self._build_response(response, requested_url, normalized_url)
