"""Public sync and async markdown.new client implementations."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable, Mapping

import httpx

from ._client_base import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, _BaseMarkdownClient
from .exceptions import MarkdownNewRequestError
from .models import MarkdownResponse


class _SharedMarkdownClient(_BaseMarkdownClient):
    """Base class for shared sync/async transport orchestration."""

    _client_factory = httpx.Client

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        api_key: str | None = None,
        api_key_header: str = "X-API-Key",
        api_key_prefix: str = "",
        headers: Mapping[str, str] | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        user_agent: str | None = None,
        client: object | None = None,
    ) -> None:
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            api_key_header=api_key_header,
            api_key_prefix=api_key_prefix,
            headers=headers,
            user_agent=user_agent,
        )
        self.timeout = timeout
        self._client = self._client_factory(timeout=timeout) if client is None else client

    def _convert_request(
        self,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        send_request: Callable[[str, Mapping[str, str], float], httpx.Response],
    ) -> MarkdownResponse:
        full_url = self._full_request_url(url)
        request_timeout = self._resolve_request_timeout(timeout, url=url)
        response = send_request(
            full_url,
            headers=self._send_headers(headers),
            timeout=request_timeout,
        )
        return self._check_response(response, url)

    async def _aconvert_request(
        self,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        send_request: Callable[[str, Mapping[str, str], float], Awaitable[httpx.Response]],
    ) -> MarkdownResponse:
        full_url = self._full_request_url(url)
        request_timeout = self._resolve_request_timeout(timeout, url=url)
        response = await send_request(
            full_url,
            headers=self._send_headers(headers),
            timeout=request_timeout,
        )
        return self._check_response(response, url)


class MarkdownNewClient(_SharedMarkdownClient):
    """Synchronous markdown.new client."""

    _client_factory = httpx.Client

    def __enter__(self) -> "MarkdownNewClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def convert(
        self,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> MarkdownResponse:
        try:
            return self._convert_request(
                url,
                headers=headers,
                timeout=timeout,
                send_request=self._client.get,
            )
        except httpx.RequestError as exc:
            raise MarkdownNewRequestError(str(exc), url=url) from exc

    def convert_many(
        self,
        urls: Iterable[str],
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> list[MarkdownResponse]:
        return [self.convert(url, headers=headers, timeout=timeout) for url in urls]


class AsyncMarkdownNewClient(_SharedMarkdownClient):
    """Asynchronous markdown.new client."""

    _client_factory = httpx.AsyncClient

    async def __aenter__(self) -> "AsyncMarkdownNewClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def convert(
        self,
        url: str,
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> MarkdownResponse:
        try:

            def async_sender(
                full_url: str,
                headers: Mapping[str, str],
                timeout: float,
            ) -> Awaitable[httpx.Response]:
                return self._client.get(
                    full_url,
                    headers=headers,
                    timeout=timeout,
                )

            return await self._aconvert_request(
                url,
                headers=headers,
                timeout=timeout,
                send_request=async_sender,
            )
        except httpx.RequestError as exc:
            raise MarkdownNewRequestError(str(exc), url=url) from exc

    async def convert_many(
        self,
        urls: Iterable[str],
        *,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
        concurrency: int = 10,
    ) -> list[MarkdownResponse]:
        semaphore = asyncio.Semaphore(max(1, concurrency))

        async def _worker(url: str):
            async with semaphore:
                return await self.convert(url, headers=headers, timeout=timeout)

        return await asyncio.gather(*[_worker(url) for url in urls])
