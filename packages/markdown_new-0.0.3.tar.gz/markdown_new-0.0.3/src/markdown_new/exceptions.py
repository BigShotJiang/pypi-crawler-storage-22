from __future__ import annotations

from typing import Mapping


class MarkdownNewError(Exception):
    """Base exception for all markdown.new client errors."""

    def __init__(self, message: str, *, url: str | None = None):
        self.url = url
        self.message = message
        super().__init__(message)

    def __str__(self) -> str:
        if self.url:
            return f"{self.message} (url={self.url})"
        return self.message


class MarkdownNewRequestError(MarkdownNewError):
    """Raised for transport errors and invalid status responses."""


class MarkdownNewAuthenticationError(MarkdownNewRequestError):
    """Raised when request authentication/authorization fails."""


class MarkdownNewRateLimitError(MarkdownNewRequestError):
    """Raised when API usage is throttled."""


class MarkdownNewConversionError(MarkdownNewRequestError):
    """Raised when the service returns an unprocessable conversion response."""


class MarkdownNewInvalidURLError(MarkdownNewConversionError, ValueError):
    """Raised when the caller supplied a malformed URL."""


class MarkdownNewHTTPError(MarkdownNewRequestError):
    """Raised for unexpected HTTP status codes."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response_text: str | None = None,
        response_headers: Mapping[str, str] | None = None,
        url: str | None = None,
    ) -> None:
        super().__init__(message, url=url)
        self.status_code = status_code
        self.response_text = response_text or ""
        self.response_headers = dict(response_headers or {})
