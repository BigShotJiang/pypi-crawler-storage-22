from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class MarkdownResponse:
    """Container for a successful markdown.new conversion result."""

    markdown: str
    requested_url: str
    normalized_url: str
    status_code: int
    content_type: str
    markdown_tokens: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
