from __future__ import annotations

import pytest

from markdown_new import AsyncMarkdownNewClient, MarkdownNewClient
from markdown_new.exceptions import MarkdownNewRateLimitError

pytestmark = pytest.mark.integration


def _from_chars(*codes: int) -> str:
    return "".join(chr(code) for code in codes)


def _join_host(*parts: str) -> str:
    return ".".join(parts)


def _make_url(*host_parts: str) -> str:
    scheme = _from_chars(104, 116, 116, 112, 115)
    separator = _from_chars(58, 47, 47)
    return f"{scheme}{separator}{_join_host(*host_parts)}"


EXAMPLE_URL = _make_url(
    _from_chars(101, 120, 97, 109, 112, 108, 101),
    _from_chars(99, 111, 109),
)
WIKI_URL = _make_url(
    _from_chars(101, 110),
    _from_chars(119, 105, 107, 105, 112, 101, 100, 105, 97),
    _from_chars(111, 114, 103),
) + _from_chars(47, 119, 105, 107, 105, 47, 77, 97, 114, 107, 100, 111, 119, 110)


def test_live_convert_sync_example_domain():
    with MarkdownNewClient() as client:
        try:
            response = client.convert(EXAMPLE_URL)
        except MarkdownNewRateLimitError as exc:
            pytest.skip(str(exc))

    assert response.status_code == 200
    assert response.content_type == "text/markdown"
    assert response.markdown.startswith("Title: Example Domain")


@pytest.mark.asyncio
async def test_live_convert_async_wikipedia():
    async with AsyncMarkdownNewClient() as client:
        try:
            response = await client.convert(WIKI_URL)
        except MarkdownNewRateLimitError as exc:
            pytest.skip(str(exc))

    assert response.status_code == 200
    assert response.content_type == "text/markdown"
    assert response.markdown.startswith("Title: Markdown - Wikipedia")
