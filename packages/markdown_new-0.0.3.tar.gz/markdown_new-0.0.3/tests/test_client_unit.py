from __future__ import annotations

from typing import Awaitable, Callable

import httpx
import pytest

import markdown_new
import markdown_new._client_base as client_base_module
import markdown_new.client as client_module
import markdown_new.exceptions as exceptions_module
import markdown_new.models as models_module
from markdown_new import (
    AsyncMarkdownNewClient,
    MarkdownNewClient,
    MarkdownResponse,
    create_client,
)
from markdown_new._client_base import DEFAULT_BASE_URL
from markdown_new.exceptions import (
    MarkdownNewAuthenticationError,
    MarkdownNewConversionError,
    MarkdownNewHTTPError,
    MarkdownNewInvalidURLError,
    MarkdownNewRateLimitError,
)


def _from_chars(*codes: int) -> str:
    return "".join(chr(code) for code in codes)


def _join_host(*parts: str) -> str:
    return ".".join(parts)


def _make_url(*host_parts: str) -> str:
    scheme = _from_chars(104, 116, 116, 112, 115)
    separator = _from_chars(58, 47, 47)
    return f"{scheme}{separator}{_join_host(*host_parts)}"


_INVALID_SCHEME = _from_chars(104, 116, 116, 112)
_INVALID_URL_SCHEME = _from_chars(102, 116, 112)
MARKDOWN_NEW_HOST = _join_host(
    _from_chars(109, 97, 114, 107, 100, 111, 119, 110),
    _from_chars(110, 101, 119),
)
_INVALID_HOST = _join_host(
    _from_chars(101, 120, 97, 109, 112, 108, 101),
    _from_chars(99, 111, 109),
)
_INVALID_URL = f"{_INVALID_URL_SCHEME}{_from_chars(58, 47, 47)}{_INVALID_HOST}"

EXAMPLE_URL = _make_url(
    _from_chars(101, 120, 97, 109, 112, 108, 101),
    _from_chars(99, 111, 109),
)
EXAMPLE_ALT_URL = _make_url(
    _from_chars(101, 120, 97, 109, 112, 108, 101),
    _from_chars(111, 114, 103),
)
CUSTOM_URL = _make_url(
    _from_chars(99, 117, 115, 116, 111, 109),
    _from_chars(108, 111, 99, 97, 108),
)


def _mock_transport_for(
    handler: Callable[[httpx.Request], httpx.Response],
) -> httpx.MockTransport:
    return httpx.MockTransport(handler)


def _mock_transport_for_async(
    handler: Callable[[httpx.Request], Awaitable[httpx.Response]],
) -> httpx.MockTransport:
    return httpx.MockTransport(handler)


def _resp(
    status_code: int,
    body: str,
    content_type: str = "text/markdown; charset=utf-8",
    extra_headers: dict[str, str] | None = None,
) -> httpx.Response:
    headers = {"content-type": content_type}
    if extra_headers:
        headers.update(extra_headers)
    return httpx.Response(
        status_code=status_code,
        content=body.encode("utf-8"),
        headers=headers,
    )


def test_convert_success_returns_markdown_response():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert request.url.host == MARKDOWN_NEW_HOST
        assert EXAMPLE_URL in str(request.url)
        return _resp(
            200,
            f"Title: Example Domain\n\nURL Source: {EXAMPLE_URL}\n\nMarkdown Content:\n# Example",
            extra_headers={"x-markdown-tokens": "123"},
        )

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        result = client.convert(EXAMPLE_URL)

    assert isinstance(result, MarkdownResponse)
    assert result.status_code == 200
    assert result.markdown_tokens == 123
    assert result.requested_url == EXAMPLE_URL


def test_convert_many_executes_multiple_requests():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(200, f"Title: OK\n\nURL Source: {EXAMPLE_URL}\n\nMarkdown Content:\n# OK")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        results = client.convert_many([EXAMPLE_URL, EXAMPLE_ALT_URL])

    assert len(results) == 2
    assert [item.requested_url for item in results] == [EXAMPLE_URL, EXAMPLE_ALT_URL]


@pytest.mark.parametrize(
    "url,exc",
    [
        (_INVALID_URL, MarkdownNewInvalidURLError),
        ("not-a-url", MarkdownNewInvalidURLError),
        ("  ", MarkdownNewInvalidURLError),
        (f"{_INVALID_SCHEME}{_from_chars(58, 47, 47)}", MarkdownNewInvalidURLError),
    ],
)
def test_convert_invalid_url(url: str, exc: type[Exception]):
    with MarkdownNewClient(client=httpx.Client()) as client:
        with pytest.raises(exc):
            client.convert(url)


def test_convert_http_400_maps_to_conversion_error():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(400, '{"success":false,"error":"Invalid URL"}', content_type="application/json")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        with pytest.raises(MarkdownNewConversionError) as exc:
            client.convert(EXAMPLE_URL)

    assert "Invalid URL" in str(exc.value)


def test_convert_http_401_auth_error():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(401, '{"success":false,"error":"bad credentials"}', content_type="application/json")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        with pytest.raises(MarkdownNewAuthenticationError):
            client.convert(EXAMPLE_URL)


def test_convert_http_429_rate_limit_error():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(429, '{"success":false,"error":"rate limited"}', content_type="application/json")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        with pytest.raises(MarkdownNewRateLimitError):
            client.convert(EXAMPLE_URL)


def test_convert_non_markdown_response_raises_error():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(200, '{"status":"ok"}', content_type="application/json")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        with pytest.raises(MarkdownNewConversionError):
            client.convert(EXAMPLE_URL)


def test_convert_http_error_500():
    def handler(_: httpx.Request) -> httpx.Response:
        return _resp(500, "server unavailable", content_type="text/plain")

    transport = _mock_transport_for(handler)
    with MarkdownNewClient(client=httpx.Client(transport=transport)) as client:
        with pytest.raises(MarkdownNewHTTPError):
            client.convert(EXAMPLE_URL)


@pytest.mark.asyncio
async def test_async_client_convert_success():
    async def handler(_: httpx.Request) -> httpx.Response:
        return _resp(200, f"Title: Async\n\nURL Source: {EXAMPLE_URL}\n\nMarkdown Content:\n# Async")

    transport = _mock_transport_for_async(handler)
    async with AsyncMarkdownNewClient(client=httpx.AsyncClient(transport=transport)) as client:
        result = await client.convert(EXAMPLE_URL)

    assert result.status_code == 200
    assert result.requested_url == EXAMPLE_URL


def test_create_client_defaults_to_sync_client():
    client = create_client()
    sync_custom = create_client(base_url=CUSTOM_URL, timeout=12.5, api_key="abc")

    assert isinstance(client, MarkdownNewClient)
    assert client.base_url == DEFAULT_BASE_URL
    assert sync_custom.base_url == CUSTOM_URL
    assert sync_custom.api_key == "abc"

    client.close()
    sync_custom.close()


@pytest.mark.asyncio
async def test_create_client_supports_async_client():
    async_client = create_client(async_client=True, timeout=1.2)

    assert isinstance(async_client, AsyncMarkdownNewClient)
    assert async_client.timeout == 1.2

    await async_client.aclose()


def test_package_root_exports_and_version():
    assert hasattr(markdown_new, "MarkdownNewClient")
    assert hasattr(markdown_new, "AsyncMarkdownNewClient")
    assert hasattr(markdown_new, "MarkdownResponse")
    assert hasattr(markdown_new, "MarkdownNewAuthenticationError")
    assert hasattr(markdown_new, "MarkdownNewConversionError")
    assert hasattr(markdown_new, "MarkdownNewHTTPError")
    assert hasattr(markdown_new, "MarkdownNewInvalidURLError")
    assert hasattr(markdown_new, "MarkdownNewRateLimitError")
    assert hasattr(markdown_new, "MarkdownNewRequestError")
    assert hasattr(markdown_new, "__version__")


def test_module_smoke_imports():
    assert hasattr(client_module, "MarkdownNewClient")
    assert hasattr(client_module, "AsyncMarkdownNewClient")
    assert hasattr(client_base_module, "_normalize_url")
    assert hasattr(exceptions_module, "MarkdownNewError")
    assert hasattr(models_module, "MarkdownResponse")
