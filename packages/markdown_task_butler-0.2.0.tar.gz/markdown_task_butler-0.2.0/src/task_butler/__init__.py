"""Task Butler - A task management tool that helps prioritize and recommend actions."""

__version__ = "0.1.0"
