#![allow(unsafe_op_in_unsafe_fn)]

use std::collections::HashSet;

use pyo3::ToPyObject;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBool, PyDict, PyFloat, PyInt, PyList, PyString};

use crate::xml_utils::{self, ObjectToXmlOptions, TagMatch, XmlToObjectOptions, XmlValue};
use crate::{
    HeadingStyle, MarkdownConverter, NewlineStyle, Options, StripMode, StripPreMode,
    markdown_utils, markdownify_batch_with_options,
};

// ---------------------------------------------------------------------------
// Markdownify bindings (existing)
// ---------------------------------------------------------------------------

#[pyclass(name = "MarkdownConverter")]
struct PyMarkdownConverter {
    inner: MarkdownConverter,
}

#[pymethods]
impl PyMarkdownConverter {
    #[new]
    #[pyo3(signature = (**kwargs))]
    fn new(kwargs: Option<Bound<'_, PyDict>>) -> PyResult<Self> {
        let options = options_from_kwargs(kwargs)?;
        Ok(Self {
            inner: MarkdownConverter::new(options),
        })
    }

    fn convert(&self, py: Python<'_>, html: &str) -> String {
        py.allow_threads(|| self.inner.convert(html))
    }
}

#[pyfunction(name = "markdownify")]
#[pyo3(signature = (html, **kwargs))]
fn markdownify(py: Python<'_>, html: &str, kwargs: Option<Bound<'_, PyDict>>) -> PyResult<String> {
    let options = options_from_kwargs(kwargs)?;
    Ok(py.allow_threads(|| markdownify_with_options(html, options)))
}

#[pyfunction(name = "markdownify_batch")]
#[pyo3(signature = (html_list, **kwargs))]
fn markdownify_batch(
    py: Python<'_>,
    html_list: Vec<String>,
    kwargs: Option<Bound<'_, PyDict>>,
) -> PyResult<Vec<String>> {
    let options = options_from_kwargs(kwargs)?;
    Ok(py.allow_threads(|| markdownify_batch_with_options(html_list, options)))
}

fn markdownify_with_options(html: &str, options: Options) -> String {
    MarkdownConverter::new(options).convert(html)
}

// ---------------------------------------------------------------------------
// markdown_utils bindings
// ---------------------------------------------------------------------------

#[pyfunction(name = "split_into_chunks")]
#[pyo3(signature = (markdown, how="sections"))]
fn py_split_into_chunks(py: Python<'_>, markdown: &str, how: &str) -> Vec<String> {
    py.allow_threads(|| markdown_utils::split_into_chunks(markdown, how))
}

#[pyfunction(name = "split_into_chunks_batch")]
#[pyo3(signature = (markdown_list, how="sections"))]
fn py_split_into_chunks_batch(
    py: Python<'_>,
    markdown_list: Vec<String>,
    how: &str,
) -> Vec<Vec<String>> {
    py.allow_threads(|| markdown_utils::split_into_chunks_batch(markdown_list, how))
}

#[pyfunction(name = "coalesce_small_chunks")]
#[pyo3(signature = (chunks, min_size=125))]
fn py_coalesce_small_chunks(py: Python<'_>, chunks: Vec<String>, min_size: usize) -> Vec<String> {
    py.allow_threads(|| markdown_utils::coalesce_small_chunks(chunks, min_size))
}

#[pyfunction(name = "cascading_split_text")]
#[pyo3(signature = (content, how, max_length=8_000, coalesce_min=225))]
fn py_cascading_split_text(
    py: Python<'_>,
    content: &str,
    how: Vec<String>,
    max_length: usize,
    coalesce_min: usize,
) -> Vec<String> {
    py.allow_threads(|| {
        markdown_utils::cascading_split_text(content, &how, max_length, coalesce_min)
    })
}

#[pyfunction(name = "cascading_split_text_batch")]
#[pyo3(signature = (contents, how, max_length=8_000, coalesce_min=225))]
fn py_cascading_split_text_batch(
    py: Python<'_>,
    contents: Vec<String>,
    how: Vec<String>,
    max_length: usize,
    coalesce_min: usize,
) -> Vec<Vec<String>> {
    py.allow_threads(|| {
        markdown_utils::cascading_split_text_batch(contents, how, max_length, coalesce_min)
    })
}

#[pyfunction(name = "split_on_dividers")]
fn py_split_on_dividers(py: Python<'_>, markdown: &str) -> Vec<String> {
    py.allow_threads(|| markdown_utils::split_on_dividers(markdown))
}

#[pyfunction(name = "link_percentage")]
fn py_link_percentage(py: Python<'_>, chunk: &str) -> f64 {
    py.allow_threads(|| markdown_utils::link_percentage(chunk))
}

#[pyfunction(name = "strip_links_with_substring")]
fn py_strip_links_with_substring(py: Python<'_>, text: &str, substring: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_links_with_substring(text, substring))
}

#[pyfunction(name = "remove_large_tables")]
#[pyo3(signature = (text, max_cells=400))]
fn py_remove_large_tables(py: Python<'_>, text: &str, max_cells: usize) -> String {
    py.allow_threads(|| markdown_utils::remove_large_tables(text, max_cells))
}

#[pyfunction(name = "strip_html_and_contents")]
fn py_strip_html_and_contents(py: Python<'_>, text: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_html_and_contents(text))
}

#[pyfunction(name = "strip_data_uri_images")]
fn py_strip_data_uri_images(py: Python<'_>, markdown: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_data_uri_images(markdown))
}

fn options_from_kwargs(kwargs: Option<Bound<'_, PyDict>>) -> PyResult<Options> {
    let mut options = Options::default();
    let mut strip_set: Option<HashSet<String>> = None;
    let mut convert_set: Option<HashSet<String>> = None;

    if let Some(kwargs) = kwargs {
        for (key, value) in kwargs {
            let key: String = key.extract()?;
            match key.as_str() {
                "autolinks" => options.autolinks = value.extract()?,
                "bullets" => options.bullets = value.extract()?,
                "code_language" => options.code_language = value.extract()?,
                "code_language_callback" => {
                    return Err(PyValueError::new_err(
                        "code_language_callback is not supported in the Python bindings",
                    ));
                }
                "convert" => {
                    if value.is_none() {
                        convert_set = None;
                    } else {
                        convert_set = Some(extract_str_set(&value)?);
                    }
                }
                "default_title" => options.default_title = value.extract()?,
                "escape_asterisks" => options.escape_asterisks = value.extract()?,
                "escape_underscores" => options.escape_underscores = value.extract()?,
                "escape_misc" => options.escape_misc = value.extract()?,
                "heading_style" => {
                    let raw: String = value.extract()?;
                    options.heading_style = parse_heading_style(&raw)?;
                }
                "keep_inline_images_in" => {
                    options.keep_inline_images_in = extract_str_set(&value)?;
                }
                "newline_style" => {
                    let raw: String = value.extract()?;
                    options.newline_style = parse_newline_style(&raw)?;
                }
                "strip" => {
                    if value.is_none() {
                        strip_set = None;
                    } else {
                        strip_set = Some(extract_str_set(&value)?);
                    }
                }
                "strip_document" => {
                    if value.is_none() {
                        options.strip_document = StripMode::None;
                    } else {
                        let raw: String = value.extract()?;
                        options.strip_document = parse_strip_document(&raw)?;
                    }
                }
                "strip_pre" => {
                    if value.is_none() {
                        options.strip_pre = StripPreMode::None;
                    } else {
                        let raw: String = value.extract()?;
                        options.strip_pre = parse_strip_pre(&raw)?;
                    }
                }
                "strong_em_symbol" => {
                    let raw: String = value.extract()?;
                    let mut chars = raw.chars();
                    let ch = chars.next().ok_or_else(|| {
                        PyValueError::new_err("strong_em_symbol must be non-empty")
                    })?;
                    options.strong_em_symbol = ch;
                }
                "sub_symbol" => options.sub_symbol = value.extract()?,
                "sup_symbol" => options.sup_symbol = value.extract()?,
                "table_infer_header" => options.table_infer_header = value.extract()?,
                "wrap" => options.wrap = value.extract()?,
                "wrap_width" => {
                    if value.is_none() {
                        options.wrap_width = None;
                    } else {
                        let width: usize = value.extract()?;
                        options.wrap_width = Some(width);
                    }
                }
                _ => {
                    return Err(PyValueError::new_err(format!("unknown option: {key}")));
                }
            }
        }
    }

    if strip_set.is_some() && convert_set.is_some() {
        return Err(PyValueError::new_err(
            "You may specify either tags to strip or tags to convert, but not both.",
        ));
    }
    options.strip = strip_set;
    options.convert = convert_set;

    Ok(options)
}

fn extract_str_set(value: &Bound<'_, PyAny>) -> PyResult<HashSet<String>> {
    if value.is_instance_of::<PyString>() {
        return Err(PyValueError::new_err(
            "expected an iterable of strings, got a string",
        ));
    }
    let mut set = HashSet::new();
    for item in value.iter()? {
        let item = item?;
        let s: String = item.extract()?;
        set.insert(s.to_ascii_lowercase());
    }
    Ok(set)
}

fn parse_heading_style(value: &str) -> PyResult<HeadingStyle> {
    match value.to_ascii_lowercase().as_str() {
        "atx" => Ok(HeadingStyle::Atx),
        "atx_closed" => Ok(HeadingStyle::AtxClosed),
        "underlined" | "setext" => Ok(HeadingStyle::Underlined),
        _ => Err(PyValueError::new_err("invalid heading_style")),
    }
}

fn parse_newline_style(value: &str) -> PyResult<NewlineStyle> {
    match value.to_ascii_lowercase().as_str() {
        "spaces" => Ok(NewlineStyle::Spaces),
        "backslash" => Ok(NewlineStyle::Backslash),
        _ => Err(PyValueError::new_err("invalid newline_style")),
    }
}

fn parse_strip_document(value: &str) -> PyResult<StripMode> {
    match value.to_ascii_lowercase().as_str() {
        "lstrip" => Ok(StripMode::LStrip),
        "rstrip" => Ok(StripMode::RStrip),
        "strip" => Ok(StripMode::Strip),
        _ => Err(PyValueError::new_err("invalid strip_document")),
    }
}

fn parse_strip_pre(value: &str) -> PyResult<StripPreMode> {
    match value.to_ascii_lowercase().as_str() {
        "strip" => Ok(StripPreMode::Strip),
        "strip_one" => Ok(StripPreMode::StripOne),
        _ => Err(PyValueError::new_err("invalid strip_pre")),
    }
}

// ---------------------------------------------------------------------------
// xml_utils bindings
// ---------------------------------------------------------------------------

#[pyfunction(name = "get_tag")]
#[pyo3(signature = (html_string, tag, return_attributes=false))]
fn py_get_tag(
    py: Python<'_>,
    html_string: &str,
    tag: &str,
    return_attributes: bool,
) -> PyResult<PyObject> {
    let result = py.allow_threads(|| xml_utils::get_tag(html_string, tag, return_attributes));
    match result {
        None => Ok(py.None()),
        Some(m) => tag_match_to_py(py, &m, return_attributes),
    }
}

#[pyfunction(name = "get_tags")]
#[pyo3(signature = (html_string, tag, return_attributes=false))]
fn py_get_tags(
    py: Python<'_>,
    html_string: &str,
    tag: &str,
    return_attributes: bool,
) -> PyResult<PyObject> {
    let results = py.allow_threads(|| xml_utils::get_tags(html_string, tag, return_attributes));
    let list = PyList::empty_bound(py);
    for m in &results {
        if return_attributes {
            let dict = PyDict::new_bound(py);
            dict.set_item("content", &m.content)?;
            let attrs = PyDict::new_bound(py);
            for (k, v) in &m.attributes {
                attrs.set_item(k, v)?;
            }
            dict.set_item("attributes", attrs)?;
            list.append(dict)?;
        } else {
            list.append(&m.content)?;
        }
    }
    Ok(list.unbind().into())
}

#[pyfunction(name = "strip_xml")]
fn py_strip_xml(py: Python<'_>, xml_string: &str) -> String {
    py.allow_threads(|| xml_utils::strip_xml(xml_string).to_string())
}

#[pyfunction(name = "remove_namespace_prefixes")]
fn py_remove_namespace_prefixes(py: Python<'_>, xml_string: &str) -> String {
    py.allow_threads(|| xml_utils::remove_namespace_prefixes(xml_string))
}

#[pyfunction(name = "object_to_xml")]
#[pyo3(signature = (
    obj,
    root_tag,
    ignore_dict_nulls=true,
    list_item_tag="li",
    include_list_index=true,
    index_attr="key",
    indent_str="  ",
))]
fn py_object_to_xml(
    py: Python<'_>,
    obj: &Bound<'_, PyAny>,
    root_tag: &str,
    ignore_dict_nulls: bool,
    list_item_tag: &str,
    include_list_index: bool,
    index_attr: &str,
    indent_str: &str,
) -> PyResult<String> {
    let value = xml_value_from_pyany(obj)?;
    let options = ObjectToXmlOptions {
        ignore_dict_nulls,
        list_item_tag: list_item_tag.to_string(),
        include_list_index,
        index_attr: index_attr.to_string(),
        indent_str: indent_str.to_string(),
    };
    let root_tag = root_tag.to_string();
    Ok(py.allow_threads(|| xml_utils::object_to_xml(&value, &root_tag, &options)))
}

#[pyfunction(name = "xml_to_object")]
#[pyo3(signature = (xml_string, parse_null_text_as_none=true, parse_empty_tags_as_none=false))]
fn py_xml_to_object(
    py: Python<'_>,
    xml_string: &str,
    parse_null_text_as_none: bool,
    parse_empty_tags_as_none: bool,
) -> PyResult<PyObject> {
    let options = XmlToObjectOptions {
        parse_null_text_as_none,
        parse_empty_tags_as_none,
    };
    let xml_string = xml_string.to_string();
    let result = py.allow_threads(|| xml_utils::xml_to_object(&xml_string, &options));
    match result {
        Ok(value) => xml_value_to_pyobject(py, &value),
        Err(e) => Err(PyValueError::new_err(e)),
    }
}

#[pyfunction(name = "parse_base_element")]
#[pyo3(signature = (elem_text, parse_empty_tags_as_none=false, parse_null_text_as_none=true))]
fn py_parse_base_element(
    py: Python<'_>,
    elem_text: Option<&str>,
    parse_empty_tags_as_none: bool,
    parse_null_text_as_none: bool,
) -> PyResult<PyObject> {
    let value =
        xml_utils::parse_base_element(elem_text, parse_empty_tags_as_none, parse_null_text_as_none);
    xml_value_to_pyobject(py, &value)
}

// --- Conversion helpers ---

fn tag_match_to_py(py: Python<'_>, m: &TagMatch, return_attributes: bool) -> PyResult<PyObject> {
    if return_attributes {
        let dict = PyDict::new_bound(py);
        dict.set_item("content", &m.content)?;
        let attrs = PyDict::new_bound(py);
        for (k, v) in &m.attributes {
            attrs.set_item(k, v)?;
        }
        dict.set_item("attributes", attrs)?;
        Ok(dict.unbind().into())
    } else {
        Ok(m.content.clone().to_object(py))
    }
}

fn xml_value_from_pyany(obj: &Bound<'_, PyAny>) -> PyResult<XmlValue> {
    if obj.is_none() {
        return Ok(XmlValue::Null);
    }
    // Check bool before int (Python bool is a subclass of int)
    if obj.is_instance_of::<PyBool>() {
        let b: bool = obj.extract()?;
        return Ok(XmlValue::String(
            if b { "True" } else { "False" }.to_string(),
        ));
    }
    if obj.is_instance_of::<PyInt>() {
        let i: i64 = obj.extract()?;
        return Ok(XmlValue::Int(i));
    }
    if obj.is_instance_of::<PyFloat>() {
        let f: f64 = obj.extract()?;
        return Ok(XmlValue::Float(f));
    }
    if obj.is_instance_of::<PyString>() {
        let s: String = obj.extract()?;
        return Ok(XmlValue::String(s));
    }
    if obj.is_instance_of::<PyDict>() {
        let dict = obj.downcast::<PyDict>()?;
        let mut entries = Vec::new();
        for (k, v) in dict {
            let key: String = k.extract()?;
            let val = xml_value_from_pyany(&v)?;
            entries.push((key, val));
        }
        return Ok(XmlValue::Dict(entries));
    }
    // Try as iterable (list, tuple, etc.)
    if let Ok(iter) = obj.iter() {
        let mut items = Vec::new();
        for item in iter {
            items.push(xml_value_from_pyany(&item?)?);
        }
        return Ok(XmlValue::List(items));
    }
    // Fallback: convert to string
    let s: String = obj.str()?.extract()?;
    Ok(XmlValue::String(s))
}

fn xml_value_to_pyobject(py: Python<'_>, value: &XmlValue) -> PyResult<PyObject> {
    match value {
        XmlValue::Null => Ok(py.None()),
        XmlValue::Int(i) => Ok(i.to_object(py)),
        XmlValue::Float(f) => Ok(f.to_object(py)),
        XmlValue::String(s) => Ok(s.to_object(py)),
        XmlValue::List(items) => {
            let list = PyList::empty_bound(py);
            for item in items {
                list.append(xml_value_to_pyobject(py, item)?)?;
            }
            Ok(list.unbind().into())
        }
        XmlValue::Dict(entries) => {
            let dict = PyDict::new_bound(py);
            for (k, v) in entries {
                dict.set_item(k, xml_value_to_pyobject(py, v)?)?;
            }
            Ok(dict.unbind().into())
        }
    }
}

// ---------------------------------------------------------------------------
// Module registration
// ---------------------------------------------------------------------------

#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Markdownify
    m.add_function(wrap_pyfunction!(markdownify, m)?)?;
    m.add_function(wrap_pyfunction!(markdownify_batch, m)?)?;
    m.add_class::<PyMarkdownConverter>()?;

    // markdown_utils
    m.add_function(wrap_pyfunction!(py_split_into_chunks, m)?)?;
    m.add_function(wrap_pyfunction!(py_split_into_chunks_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_coalesce_small_chunks, m)?)?;
    m.add_function(wrap_pyfunction!(py_cascading_split_text, m)?)?;
    m.add_function(wrap_pyfunction!(py_cascading_split_text_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_split_on_dividers, m)?)?;
    m.add_function(wrap_pyfunction!(py_link_percentage, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_links_with_substring, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_large_tables, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_html_and_contents, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_data_uri_images, m)?)?;

    m.add("ATX", "atx")?;
    m.add("ATX_CLOSED", "atx_closed")?;
    m.add("UNDERLINED", "underlined")?;
    m.add("SETEXT", "underlined")?;

    m.add("SPACES", "spaces")?;
    m.add("BACKSLASH", "backslash")?;

    m.add("ASTERISK", "*")?;
    m.add("UNDERSCORE", "_")?;

    m.add("LSTRIP", "lstrip")?;
    m.add("RSTRIP", "rstrip")?;
    m.add("STRIP", "strip")?;
    m.add("STRIP_ONE", "strip_one")?;

    // xml_utils
    m.add_function(wrap_pyfunction!(py_get_tag, m)?)?;
    m.add_function(wrap_pyfunction!(py_get_tags, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_xml, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_namespace_prefixes, m)?)?;
    m.add_function(wrap_pyfunction!(py_object_to_xml, m)?)?;
    m.add_function(wrap_pyfunction!(py_xml_to_object, m)?)?;
    m.add_function(wrap_pyfunction!(py_parse_base_element, m)?)?;

    Ok(())
}
