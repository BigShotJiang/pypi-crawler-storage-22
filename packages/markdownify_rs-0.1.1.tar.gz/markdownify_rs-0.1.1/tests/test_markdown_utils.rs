use markdownify_rs::markdown_utils::{
    cascading_split_text, coalesce_small_chunks, link_percentage, remove_large_tables,
    split_into_chunks, split_on_dividers, strip_data_uri_images, strip_html_and_contents,
    strip_links_with_substring,
};

#[test]
fn test_split_on_dividers() {
    let text = "A\n-----\nB\n=====\nC\n";
    let chunks = split_on_dividers(text);
    assert_eq!(chunks, vec!["A", "B", "C"]);
}

#[test]
fn test_link_percentage() {
    let ratio = link_percentage("[a](b) plain");
    assert!((ratio - 0.5).abs() < 1e-9);
}

#[test]
fn test_strip_links_with_substring() {
    let text = "See [one](javascript:alert(1)) and [two](https://x.com).";
    let cleaned = strip_links_with_substring(text, "javascript");
    assert_eq!(cleaned, "See one and [two](https://x.com).");
}

#[test]
fn test_remove_large_tables() {
    let text = "|a|b|\n|1|2|\ntext\n|a|b|c|\n|1|2|3|\n|4|5|6|\n";
    let cleaned = remove_large_tables(text, 4);
    assert_eq!(cleaned, "|a|b|\n|1|2|\ntext\n");
}

#[test]
fn test_strip_html_and_contents() {
    let text = "before <div><span>x</span> y</div> after <br/> tail";
    let cleaned = strip_html_and_contents(text);
    assert_eq!(cleaned, "before  after  tail");
}

#[test]
fn test_strip_html_does_not_mispair_br_with_closing_b() {
    let text = "A <br>(7%) text </b> B";
    let cleaned = strip_html_and_contents(text);
    assert_eq!(cleaned, "A (7%) text  B");
}

#[test]
fn test_coalesce_small_chunks() {
    let chunks = vec!["a".to_string(), "bbb".to_string(), "cccc".to_string()];
    let merged = coalesce_small_chunks(chunks, 4);
    assert_eq!(merged, vec!["a\n\nbbb".to_string(), "cccc".to_string()]);
}

#[test]
fn test_split_into_chunks_headings() {
    let md = "# One\nA\n# Two\nB";
    let chunks = split_into_chunks(md, "headings");
    assert_eq!(chunks, vec!["# One\nA".to_string(), "# Two\nB".to_string()]);
}

#[test]
fn test_split_into_chunks_sections() {
    let md = "## Chapter 1\nA\n## Chapter 2\nB";
    let chunks = split_into_chunks(md, "sections");
    assert_eq!(
        chunks,
        vec!["## Chapter 1\nA".to_string(), "## Chapter 2\nB".to_string()]
    );
}

#[test]
fn test_split_into_chunks_brute() {
    let line = "a".repeat(3_000);
    let md = format!("{line}\n{line}\n{line}\n{line}");
    let chunks = split_into_chunks(&md, "brute");
    assert_eq!(chunks.len(), 2);
}

#[test]
fn test_split_into_chunks_lists() {
    let md = "- a\n  - b\n- c";
    let chunks = split_into_chunks(md, "lists");
    assert_eq!(chunks, vec!["- a\n  - b".to_string(), "- c".to_string()]);
}

#[test]
fn test_strip_data_uri_images() {
    let md = "x ![img](data:image/png;base64,abc) y [ok](http://a) [d]( data:image/jpeg;base64,z )";
    let cleaned = strip_data_uri_images(md);
    assert_eq!(cleaned, "x  y [ok](http://a) ");
}

#[test]
fn test_cascading_split_text() {
    let content = "# H1\nA\n# H2\nB";
    let chunks = cascading_split_text(content, &["headings".to_string()], 1, 1);
    assert_eq!(chunks, vec!["# H1\nA".to_string(), "# H2\nB".to_string()]);
}
