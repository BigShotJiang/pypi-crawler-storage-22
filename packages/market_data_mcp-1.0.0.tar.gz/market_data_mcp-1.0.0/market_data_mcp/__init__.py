"""
Market Data MCP Server
======================
A Model Context Protocol server providing real-time financial market data
to any MCP-compatible AI assistant or agent.

No API keys required. All data sources are free and public.
"""

__version__ = "1.0.0"
