"""Allow running the server as `python -m market_data_mcp`."""

from market_data_mcp.server import main

if __name__ == "__main__":
    main()
