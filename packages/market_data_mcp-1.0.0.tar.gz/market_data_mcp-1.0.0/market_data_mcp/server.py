#!/usr/bin/env python3
"""
Market Data MCP Server
======================
A Model Context Protocol server providing real-time financial market data
to any MCP-compatible AI assistant or agent.

Tools:
    - get_stock_quote        Real-time stock price, change, and volume
    - get_crypto_price       Cryptocurrency prices via CoinGecko
    - get_market_movers      Top gainers and losers of the day
    - get_sector_performance Sector ETF performance breakdown
    - get_earnings_calendar  Upcoming earnings releases
    - get_technical_indicators RSI, MACD, and moving averages
    - get_fear_greed_index   CNN Fear & Greed market sentiment
    - get_fda_calendar       Upcoming FDA PDUFA dates
    - screen_stocks          TradingView stock screener with filters
    - screen_crypto          TradingView crypto screener with filters
    - top_movers             Top gainers, losers, and most active via TradingView

No API keys required. All data sources are free and public.

Usage:
    market-data-mcp                        # stdio transport (for Claude Desktop)
    market-data-mcp --transport sse        # SSE transport on port 8100
    market-data-mcp --transport streamable-http  # Streamable HTTP on port 8100
    python -m market_data_mcp              # alternative invocation

Author: Nate
License: MIT
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests
import yfinance as yf
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations
from tvscreener import (
    CryptoField,
    CryptoScreener,
    FilterOperator,
    Market,
    Sector,
    StockField,
    StockScreener,
)

from market_data_mcp import __version__

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SERVER_NAME = "Market Data"
SERVER_VERSION = __version__
DEFAULT_PORT = 8100

DATA_DIR = Path(__file__).parent / "data"

SECTOR_ETFS = {
    "XLK": "Technology",
    "XLF": "Financials",
    "XLE": "Energy",
    "XLV": "Health Care",
    "XLY": "Consumer Discretionary",
    "XLP": "Consumer Staples",
    "XLI": "Industrials",
    "XLB": "Materials",
    "XLRE": "Real Estate",
    "XLU": "Utilities",
    "XLC": "Communication Services",
}

COINGECKO_BASE = "https://api.coingecko.com/api/v3"

# Common crypto ID mappings (CoinGecko slug -> display name)
CRYPTO_ALIASES: dict[str, str] = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "ADA": "cardano",
    "DOT": "polkadot",
    "AVAX": "avalanche-2",
    "DOGE": "dogecoin",
    "SHIB": "shiba-inu",
    "MATIC": "matic-network",
    "LINK": "chainlink",
    "UNI": "uniswap",
    "XRP": "ripple",
    "LTC": "litecoin",
    "ATOM": "cosmos",
    "NEAR": "near",
    "APT": "aptos",
    "ARB": "arbitrum",
    "OP": "optimism",
    "SUI": "sui",
    "SEI": "sei-network",
    "TIA": "celestia",
    "PEPE": "pepe",
    "WIF": "dogwifcoin",
    "BONK": "bonk",
    "RENDER": "render-token",
    "FET": "artificial-superintelligence-alliance",
    "INJ": "injective-protocol",
    "TRX": "tron",
    "TON": "the-open-network",
}

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("market-data-mcp")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_http = requests.Session()
_http.headers.update({"User-Agent": "MarketDataMCP/1.0"})
_http.timeout = 15


def _safe_round(value: Any, decimals: int = 2) -> Any:
    """Round numeric values safely, pass through non-numerics."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    try:
        return round(float(value), decimals)
    except (TypeError, ValueError):
        return value


def _fmt_large_number(n: Any) -> str:
    """Format large numbers with B/M/K suffix for readability."""
    if n is None:
        return "N/A"
    try:
        n = float(n)
    except (TypeError, ValueError):
        return str(n)
    if abs(n) >= 1_000_000_000:
        return f"{n / 1_000_000_000:.2f}B"
    if abs(n) >= 1_000_000:
        return f"{n / 1_000_000:.2f}M"
    if abs(n) >= 1_000:
        return f"{n / 1_000:.1f}K"
    return f"{n:,.0f}"


def _pct(value: Any) -> str:
    """Format a numeric value as a human-readable percentage string.

    The value is used as-is (no auto-multiplication). Callers must ensure
    the value is already expressed as a percentage (e.g. 2.5 for 2.5%).
    """
    if value is None:
        return "N/A"
    try:
        v = float(value)
        return f"{v:+.2f}%"
    except (TypeError, ValueError):
        return "N/A"


# ---------------------------------------------------------------------------
# FastMCP Server
# ---------------------------------------------------------------------------

READ_ONLY = ToolAnnotations(readOnlyHint=True, destructiveHint=False)

mcp = FastMCP(
    SERVER_NAME,
    instructions=(
        "Provides real-time financial market data including stock quotes, "
        "crypto prices, sector performance, technical indicators, market "
        "sentiment, and upcoming catalysts. No API keys required."
    ),
)


# ---------------------------------------------------------------------------
# Tool 1: Stock Quote
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get a real-time stock quote including price, daily change, volume, "
        "market cap, 52-week range, and key stats. Accepts any valid ticker "
        "symbol (e.g. AAPL, MSFT, TSLA)."
    ),
    annotations=READ_ONLY,
)
def get_stock_quote(ticker: str) -> str:
    """Fetch current stock quote data for a given ticker symbol."""
    ticker = ticker.strip().upper()
    try:
        stock = yf.Ticker(ticker)
        info = stock.info

        if not info or info.get("regularMarketPrice") is None:
            # Try fast_info as fallback
            fi = stock.fast_info
            if fi is None:
                return json.dumps({"error": f"No data found for ticker '{ticker}'."})
            return json.dumps({
                "ticker": ticker,
                "price": _safe_round(fi.get("lastPrice")),
                "previous_close": _safe_round(fi.get("previousClose")),
                "source": "fast_info (limited data)",
            })

        price = info.get("regularMarketPrice") or info.get("currentPrice")
        prev_close = info.get("regularMarketPreviousClose") or info.get("previousClose")
        change = None
        change_pct = None
        if price and prev_close:
            change = _safe_round(price - prev_close)
            change_pct = _safe_round((price - prev_close) / prev_close * 100)

        result = {
            "ticker": ticker,
            "name": info.get("shortName") or info.get("longName", ticker),
            "price": _safe_round(price),
            "change": change,
            "change_percent": f"{change_pct:+.2f}%" if change_pct is not None else None,
            "previous_close": _safe_round(prev_close),
            "open": _safe_round(info.get("regularMarketOpen") or info.get("open")),
            "day_high": _safe_round(info.get("regularMarketDayHigh") or info.get("dayHigh")),
            "day_low": _safe_round(info.get("regularMarketDayLow") or info.get("dayLow")),
            "volume": _fmt_large_number(info.get("regularMarketVolume") or info.get("volume")),
            "avg_volume": _fmt_large_number(info.get("averageVolume")),
            "market_cap": _fmt_large_number(info.get("marketCap")),
            "pe_ratio": _safe_round(info.get("trailingPE")),
            "forward_pe": _safe_round(info.get("forwardPE")),
            "eps": _safe_round(info.get("trailingEps")),
            "dividend_yield": _pct(
                info.get("dividendYield") * 100
                if info.get("dividendYield") is not None
                else None
            ),
            "52w_high": _safe_round(info.get("fiftyTwoWeekHigh")),
            "52w_low": _safe_round(info.get("fiftyTwoWeekLow")),
            "beta": _safe_round(info.get("beta")),
            "sector": info.get("sector"),
            "industry": info.get("industry"),
        }
        return json.dumps(result, indent=2)

    except Exception as e:
        log.exception("get_stock_quote failed for %s", ticker)
        return json.dumps({"error": f"Failed to fetch quote for '{ticker}': {e}"})


# ---------------------------------------------------------------------------
# Tool 2: Crypto Price
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get the current price of a cryptocurrency in USD. Accepts ticker "
        "symbols (BTC, ETH, SOL) or CoinGecko IDs (bitcoin, ethereum). "
        "Includes 24h change, market cap, and volume."
    ),
    annotations=READ_ONLY,
)
def get_crypto_price(symbol: str) -> str:
    """Fetch cryptocurrency price from CoinGecko public API."""
    symbol = symbol.strip().upper()
    coin_id = CRYPTO_ALIASES.get(symbol, symbol.lower())

    try:
        resp = _http.get(
            f"{COINGECKO_BASE}/coins/{coin_id}",
            params={
                "localization": "false",
                "tickers": "false",
                "community_data": "false",
                "developer_data": "false",
            },
        )

        if resp.status_code == 429:
            return json.dumps({
                "error": "CoinGecko rate limit reached. Please wait a moment and try again."
            })
        resp.raise_for_status()
        data = resp.json()
        market = data.get("market_data", {})

        result = {
            "symbol": data.get("symbol", symbol).upper(),
            "name": data.get("name", coin_id),
            "price_usd": _safe_round(market.get("current_price", {}).get("usd"), 6),
            "change_24h": _pct(market.get("price_change_percentage_24h")),
            "change_7d": _pct(market.get("price_change_percentage_7d")),
            "change_30d": _pct(market.get("price_change_percentage_30d")),
            "market_cap": _fmt_large_number(market.get("market_cap", {}).get("usd")),
            "volume_24h": _fmt_large_number(market.get("total_volume", {}).get("usd")),
            "ath": _safe_round(market.get("ath", {}).get("usd"), 6),
            "ath_change": _pct(market.get("ath_change_percentage", {}).get("usd")),
            "circulating_supply": _fmt_large_number(market.get("circulating_supply")),
            "market_cap_rank": data.get("market_cap_rank"),
        }
        return json.dumps(result, indent=2)

    except requests.exceptions.RequestException as e:
        log.exception("get_crypto_price failed for %s", symbol)
        return json.dumps({"error": f"Failed to fetch crypto price for '{symbol}': {e}"})


# ---------------------------------------------------------------------------
# Tool 3: Market Movers
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get today's top stock market gainers and losers. Returns the biggest "
        "movers by percentage change from a curated universe of liquid stocks."
    ),
    annotations=READ_ONLY,
)
def get_market_movers() -> str:
    """Identify the day's top gaining and losing stocks."""
    # Broad universe of liquid, widely-followed tickers
    universe = [
        "AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA", "BRK-B",
        "JPM", "V", "JNJ", "UNH", "XOM", "MA", "PG", "HD", "CVX", "MRK",
        "ABBV", "PEP", "KO", "COST", "AVGO", "LLY", "TMO", "WMT", "MCD",
        "CRM", "ACN", "CSCO", "AMD", "INTC", "NFLX", "ADBE", "TXN", "QCOM",
        "AMGN", "AMAT", "BA", "CAT", "GE", "DIS", "PYPL", "SQ", "COIN",
        "RIVN", "PLTR", "SOFI", "MARA", "SMCI", "ARM", "CRWD", "SNOW",
        "NET", "DDOG", "ZS", "PANW", "ABNB", "UBER", "DASH", "RBLX",
    ]

    try:
        data = yf.download(
            universe,
            period="2d",
            progress=False,
            threads=True,
            group_by="ticker",
        )

        movers = []
        for tick in universe:
            try:
                if tick in data.columns.get_level_values(0):
                    ticker_data = data[tick]
                else:
                    continue

                closes = ticker_data["Close"].dropna()
                if len(closes) < 2:
                    continue

                prev = float(closes.iloc[-2])
                curr = float(closes.iloc[-1])
                if prev == 0:
                    continue

                change_pct = (curr - prev) / prev * 100
                movers.append({
                    "ticker": tick,
                    "price": _safe_round(curr),
                    "change_percent": _safe_round(change_pct),
                })
            except Exception:
                continue

        movers.sort(key=lambda x: x["change_percent"], reverse=True)

        result = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "top_gainers": movers[:10],
            "top_losers": movers[-10:][::-1],
            "universe_size": len(movers),
        }
        return json.dumps(result, indent=2)

    except Exception as e:
        log.exception("get_market_movers failed")
        return json.dumps({"error": f"Failed to fetch market movers: {e}"})


# ---------------------------------------------------------------------------
# Tool 4: Sector Performance
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get performance data for all 11 S&P 500 sector ETFs (XLK, XLF, XLE, "
        "XLV, etc.) including daily change, 5-day, and 1-month returns."
    ),
    annotations=READ_ONLY,
)
def get_sector_performance() -> str:
    """Fetch sector ETF performance across multiple timeframes."""
    tickers = list(SECTOR_ETFS.keys())

    try:
        data = yf.download(
            tickers,
            period="1mo",
            progress=False,
            threads=True,
            group_by="ticker",
        )

        sectors = []
        for etf, name in SECTOR_ETFS.items():
            try:
                if etf in data.columns.get_level_values(0):
                    ticker_data = data[etf]
                else:
                    continue

                closes = ticker_data["Close"].dropna()
                if len(closes) < 2:
                    continue

                current = float(closes.iloc[-1])
                prev_1d = float(closes.iloc[-2])
                prev_5d = float(closes.iloc[-6]) if len(closes) >= 6 else prev_1d
                prev_1mo = float(closes.iloc[0])

                sectors.append({
                    "etf": etf,
                    "sector": name,
                    "price": _safe_round(current),
                    "change_1d": f"{((current - prev_1d) / prev_1d * 100):+.2f}%",
                    "change_5d": f"{((current - prev_5d) / prev_5d * 100):+.2f}%",
                    "change_1mo": f"{((current - prev_1mo) / prev_1mo * 100):+.2f}%",
                })
            except Exception:
                continue

        # Sort by 1-day change (best first)
        sectors.sort(
            key=lambda x: float(x["change_1d"].replace("%", "").replace("+", "")),
            reverse=True,
        )

        return json.dumps({
            "date": datetime.now().strftime("%Y-%m-%d"),
            "sectors": sectors,
        }, indent=2)

    except Exception as e:
        log.exception("get_sector_performance failed")
        return json.dumps({"error": f"Failed to fetch sector performance: {e}"})


# ---------------------------------------------------------------------------
# Tool 5: Earnings Calendar
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get upcoming earnings reports for the next N days (default 7). "
        "Shows company name, ticker, report date, and expected EPS where available."
    ),
    annotations=READ_ONLY,
)
def get_earnings_calendar(days_ahead: int = 7) -> str:
    """Fetch upcoming earnings releases from yfinance."""
    days_ahead = max(1, min(days_ahead, 30))
    start = datetime.now().strftime("%Y-%m-%d")
    end = (datetime.now() + timedelta(days=days_ahead)).strftime("%Y-%m-%d")

    # Use a broad set of tickers to find upcoming earnings
    watchlist = [
        "AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA", "JPM",
        "V", "JNJ", "UNH", "XOM", "MA", "PG", "HD", "CVX", "MRK", "ABBV",
        "PEP", "KO", "COST", "AVGO", "LLY", "TMO", "WMT", "MCD", "CRM",
        "AMD", "INTC", "NFLX", "ADBE", "BA", "CAT", "DIS", "PYPL", "COIN",
        "PLTR", "SOFI", "SMCI", "ARM", "CRWD", "SNOW", "NET", "UBER",
        "ABNB", "RBLX", "SQ", "DDOG", "ZS", "PANW", "DASH", "RIVN",
    ]

    try:
        earnings = []
        for tick in watchlist:
            try:
                stock = yf.Ticker(tick)
                cal = stock.calendar
                if cal is None or (isinstance(cal, pd.DataFrame) and cal.empty):
                    continue
                if isinstance(cal, dict):
                    earn_date = cal.get("Earnings Date")
                    if earn_date is None:
                        continue
                    # Can be a list of dates
                    if isinstance(earn_date, list):
                        earn_date = earn_date[0]
                    if hasattr(earn_date, "strftime"):
                        earn_str = earn_date.strftime("%Y-%m-%d")
                    else:
                        earn_str = str(earn_date)[:10]

                    if start <= earn_str <= end:
                        earnings.append({
                            "ticker": tick,
                            "name": stock.info.get("shortName", tick),
                            "earnings_date": earn_str,
                            "eps_estimate": _safe_round(cal.get("EPS Estimate")),
                            "revenue_estimate": _fmt_large_number(cal.get("Revenue Estimate")),
                        })
            except Exception:
                continue

        earnings.sort(key=lambda x: x["earnings_date"])

        return json.dumps({
            "period": f"{start} to {end}",
            "count": len(earnings),
            "earnings": earnings,
        }, indent=2)

    except Exception as e:
        log.exception("get_earnings_calendar failed")
        return json.dumps({"error": f"Failed to fetch earnings calendar: {e}"})


# ---------------------------------------------------------------------------
# Tool 6: Technical Indicators
# ---------------------------------------------------------------------------

def _compute_rsi(series: pd.Series, period: int = 14) -> float | None:
    """Compute the Relative Strength Index."""
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    last = rsi.dropna()
    return _safe_round(float(last.iloc[-1])) if len(last) > 0 else None


def _compute_macd(
    series: pd.Series,
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> dict[str, float | None]:
    """Compute MACD line, signal line, and histogram."""
    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    return {
        "macd_line": _safe_round(float(macd_line.iloc[-1]), 4),
        "signal_line": _safe_round(float(signal_line.iloc[-1]), 4),
        "histogram": _safe_round(float(histogram.iloc[-1]), 4),
    }


def _interpret_rsi(rsi: float | None) -> str:
    """Provide a human-readable RSI interpretation."""
    if rsi is None:
        return "Insufficient data"
    if rsi >= 70:
        return "Overbought"
    if rsi >= 60:
        return "Bullish"
    if rsi >= 40:
        return "Neutral"
    if rsi >= 30:
        return "Bearish"
    return "Oversold"


@mcp.tool(
    description=(
        "Calculate technical indicators for any stock: RSI (14), MACD (12/26/9), "
        "SMA (20, 50, 200), EMA (12, 26), and Bollinger Bands. Includes signal "
        "interpretation."
    ),
    annotations=READ_ONLY,
)
def get_technical_indicators(ticker: str) -> str:
    """Compute common technical indicators from historical price data."""
    ticker = ticker.strip().upper()

    try:
        stock = yf.Ticker(ticker)
        hist = stock.history(period="6mo")

        if hist.empty:
            return json.dumps({"error": f"No historical data for '{ticker}'."})

        close = hist["Close"]
        current_price = _safe_round(float(close.iloc[-1]))

        # RSI
        rsi = _compute_rsi(close)

        # MACD
        macd = _compute_macd(close)

        # Simple Moving Averages
        sma_20 = _safe_round(float(close.rolling(20).mean().iloc[-1]))
        sma_50 = _safe_round(float(close.rolling(50).mean().iloc[-1]))
        sma_200 = None
        if len(close) >= 200:
            sma_200 = _safe_round(float(close.rolling(200).mean().iloc[-1]))

        # Exponential Moving Averages
        ema_12 = _safe_round(float(close.ewm(span=12, adjust=False).mean().iloc[-1]))
        ema_26 = _safe_round(float(close.ewm(span=26, adjust=False).mean().iloc[-1]))

        # Bollinger Bands (20, 2)
        bb_sma = close.rolling(20).mean()
        bb_std = close.rolling(20).std()
        bb_upper = _safe_round(float((bb_sma + 2 * bb_std).iloc[-1]))
        bb_lower = _safe_round(float((bb_sma - 2 * bb_std).iloc[-1]))

        # Volume analysis
        vol = hist["Volume"]
        avg_vol_20 = _safe_round(float(vol.rolling(20).mean().iloc[-1]))
        latest_vol = float(vol.iloc[-1])
        vol_ratio = _safe_round(latest_vol / avg_vol_20, 2) if avg_vol_20 else None

        # Trend signals
        signals = []
        if rsi is not None:
            signals.append(f"RSI {_interpret_rsi(rsi)} ({rsi})")
        if macd["histogram"] is not None:
            direction = "bullish" if macd["histogram"] > 0 else "bearish"
            signals.append(f"MACD {direction}")
        if sma_50 and sma_200:
            if sma_50 > sma_200:
                signals.append("Golden Cross (SMA 50 > 200)")
            else:
                signals.append("Death Cross (SMA 50 < 200)")
        if current_price and bb_upper and bb_lower:
            if current_price > bb_upper:
                signals.append("Above upper Bollinger Band")
            elif current_price < bb_lower:
                signals.append("Below lower Bollinger Band")

        result = {
            "ticker": ticker,
            "price": current_price,
            "rsi_14": rsi,
            "rsi_signal": _interpret_rsi(rsi),
            "macd": macd,
            "sma_20": sma_20,
            "sma_50": sma_50,
            "sma_200": sma_200,
            "ema_12": ema_12,
            "ema_26": ema_26,
            "bollinger_bands": {
                "upper": bb_upper,
                "middle": sma_20,
                "lower": bb_lower,
            },
            "volume": {
                "latest": _fmt_large_number(latest_vol),
                "avg_20d": _fmt_large_number(avg_vol_20),
                "ratio": vol_ratio,
            },
            "signals": signals,
            "data_points": len(close),
        }
        return json.dumps(result, indent=2)

    except Exception as e:
        log.exception("get_technical_indicators failed for %s", ticker)
        return json.dumps({"error": f"Failed to compute indicators for '{ticker}': {e}"})


# ---------------------------------------------------------------------------
# Tool 7: Fear & Greed Index
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get the CNN Fear & Greed Index, a composite measure of market sentiment "
        "ranging from 0 (Extreme Fear) to 100 (Extreme Greed). Useful for "
        "contrarian analysis and gauging overall market mood."
    ),
    annotations=READ_ONLY,
)
def get_fear_greed_index() -> str:
    """Fetch the CNN Fear & Greed Index."""
    try:
        resp = _http.get(
            "https://production.dataviz.cnn.io/index/fearandgreed/graphdata",
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
                "Accept": "application/json",
            },
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        fg = data.get("fear_and_greed", {})
        score = _safe_round(fg.get("score"))
        rating = fg.get("rating", "Unknown")
        previous_close = _safe_round(fg.get("previous_close"))
        previous_1_week = _safe_round(fg.get("previous_1_week"))
        previous_1_month = _safe_round(fg.get("previous_1_month"))
        previous_1_year = _safe_round(fg.get("previous_1_year"))

        # Classify
        def classify(s: float | None) -> str:
            if s is None:
                return "Unknown"
            if s <= 25:
                return "Extreme Fear"
            if s <= 45:
                return "Fear"
            if s <= 55:
                return "Neutral"
            if s <= 75:
                return "Greed"
            return "Extreme Greed"

        result = {
            "score": score,
            "rating": rating,
            "classification": classify(score),
            "previous_close": previous_close,
            "one_week_ago": previous_1_week,
            "one_month_ago": previous_1_month,
            "one_year_ago": previous_1_year,
            "timestamp": fg.get("timestamp"),
        }
        return json.dumps(result, indent=2)

    except requests.exceptions.RequestException as e:
        log.warning("CNN Fear & Greed API failed: %s", e)
        # Fallback: compute a proxy from VIX + market data
        try:
            vix = yf.Ticker("^VIX")
            vix_data = vix.history(period="5d")
            if not vix_data.empty:
                vix_level = _safe_round(float(vix_data["Close"].iloc[-1]))
                # Rough proxy: VIX 12=Extreme Greed, 35=Extreme Fear
                proxy_score = max(0, min(100, 100 - (vix_level - 12) * (100 / 23)))
                return json.dumps({
                    "score": _safe_round(proxy_score),
                    "classification": "Proxy (VIX-based)",
                    "vix_level": vix_level,
                    "note": "CNN API unavailable. Score estimated from VIX.",
                }, indent=2)
        except Exception:
            pass
        return json.dumps({"error": f"Failed to fetch Fear & Greed Index: {e}"})


# ---------------------------------------------------------------------------
# Tool 8: FDA PDUFA Calendar
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get upcoming FDA PDUFA (drug approval) dates. These are major binary "
        "catalysts for biotech/pharma stocks. Data sourced from a curated and "
        "regularly updated calendar."
    ),
    annotations=READ_ONLY,
)
def get_fda_calendar() -> str:
    """Return upcoming FDA PDUFA dates from the bundled calendar."""
    cal_path = DATA_DIR / "fda_calendar.json"

    try:
        if not cal_path.exists():
            return json.dumps({
                "error": "FDA calendar data file not found.",
                "expected_path": str(cal_path),
                "note": "Place a fda_calendar.json file in the data/ directory.",
            })

        with open(cal_path, "r", encoding="utf-8") as f:
            calendar = json.load(f)

        today = datetime.now().strftime("%Y-%m-%d")
        upcoming = [
            entry for entry in calendar
            if entry.get("pdufa_date", "") >= today
        ]
        upcoming.sort(key=lambda x: x.get("pdufa_date", ""))

        past_recent = [
            entry for entry in calendar
            if entry.get("pdufa_date", "") < today
            and entry.get("pdufa_date", "") >= (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        ]
        past_recent.sort(key=lambda x: x.get("pdufa_date", ""), reverse=True)

        return json.dumps({
            "as_of": today,
            "upcoming_count": len(upcoming),
            "upcoming": upcoming[:20],
            "recent_past": past_recent[:10],
        }, indent=2)

    except Exception as e:
        log.exception("get_fda_calendar failed")
        return json.dumps({"error": f"Failed to load FDA calendar: {e}"})


# ---------------------------------------------------------------------------
# TradingView Screener Helpers
# ---------------------------------------------------------------------------

# Map user-friendly sector names to tvscreener Sector enum values
_SECTOR_MAP: dict[str, Sector] = {
    "technology": Sector.ELECTRONIC_TECHNOLOGY,
    "tech": Sector.ELECTRONIC_TECHNOLOGY,
    "electronic_technology": Sector.ELECTRONIC_TECHNOLOGY,
    "tech_services": Sector.TECHNOLOGY_SERVICES,
    "technology_services": Sector.TECHNOLOGY_SERVICES,
    "finance": Sector.FINANCE,
    "financials": Sector.FINANCE,
    "health": Sector.HEALTH_TECHNOLOGY,
    "healthcare": Sector.HEALTH_TECHNOLOGY,
    "health_technology": Sector.HEALTH_TECHNOLOGY,
    "health_services": Sector.HEALTH_SERVICES,
    "energy": Sector.ENERGY_MINERALS,
    "energy_minerals": Sector.ENERGY_MINERALS,
    "consumer_services": Sector.CONSUMER_SERVICES,
    "consumer_discretionary": Sector.CONSUMER_DURABLES,
    "consumer_durables": Sector.CONSUMER_DURABLES,
    "consumer_staples": Sector.CONSUMER_NON_DURABLES,
    "consumer_non_durables": Sector.CONSUMER_NON_DURABLES,
    "industrials": Sector.PRODUCER_MANUFACTURING,
    "producer_manufacturing": Sector.PRODUCER_MANUFACTURING,
    "industrial_services": Sector.INDUSTRIAL_SERVICES,
    "communications": Sector.COMMUNICATIONS,
    "utilities": Sector.UTILITIES,
    "materials": Sector.NON_ENERGY_MINERALS,
    "non_energy_minerals": Sector.NON_ENERGY_MINERALS,
    "transportation": Sector.TRANSPORTATION,
    "retail": Sector.RETAIL_TRADE,
    "retail_trade": Sector.RETAIL_TRADE,
    "commercial_services": Sector.COMMERCIAL_SERVICES,
    "distribution": Sector.DISTRIBUTION_SERVICES,
    "distribution_services": Sector.DISTRIBUTION_SERVICES,
    "process_industries": Sector.PROCESS_INDUSTRIES,
    "miscellaneous": Sector.MISCELLANEOUS,
}

# Map user-friendly market names to tvscreener Market enum values
_MARKET_MAP: dict[str, Market] = {
    "america": Market.AMERICA,
    "us": Market.AMERICA,
    "usa": Market.AMERICA,
    "uk": Market.UK,
    "germany": Market.GERMANY,
    "france": Market.FRANCE,
    "japan": Market.JAPAN,
    "china": Market.CHINA,
    "india": Market.INDIA,
    "canada": Market.CANADA,
    "australia": Market.AUSTRALIA,
    "brazil": Market.BRAZIL,
    "korea": Market.KOREA,
    "all": Market.ALL,
}


def _df_to_records(df: "pd.DataFrame", max_rows: int = 50) -> list[dict]:
    """Convert a screener DataFrame to a list of clean dicts for JSON output.

    Drops the 'Update Mode' column, replaces NaN with None, formats large
    numbers where appropriate, and caps output to *max_rows*.
    """
    if df is None or df.empty:
        return []

    # Drop internal TradingView columns
    for col in ("Update Mode",):
        if col in df.columns:
            df = df.drop(columns=[col])

    # Truncate
    df = df.head(max_rows)

    records: list[dict] = []
    for _, row in df.iterrows():
        entry: dict[str, Any] = {}
        for col in df.columns:
            val = row[col]
            if val is None or (isinstance(val, float) and np.isnan(val)):
                entry[col] = None
            elif col in ("Volume", "Market Capitalization", "Average Volume"):
                entry[col] = _fmt_large_number(val)
            elif isinstance(val, float):
                entry[col] = _safe_round(val, 4)
            else:
                entry[col] = val
            # Clean up symbol prefix (e.g. "NASDAQ:AAPL" -> "AAPL")
            if col == "Symbol" and isinstance(val, str) and ":" in val:
                entry["Exchange"] = val.split(":")[0]
                entry[col] = val.split(":", 1)[1]
        records.append(entry)
    return records


# ---------------------------------------------------------------------------
# Tool 9: TradingView Stock Screener
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Screen stocks using TradingView's powerful screener engine. Filter by "
        "market (us, uk, japan, etc.), sector (technology, healthcare, finance, "
        "energy, etc.), minimum/maximum price, minimum volume, minimum market cap, "
        "and sort by change_percent, volume, market_cap, or technical_rating. "
        "Returns up to 25 results with price, change%, volume, market cap, sector, "
        "and TradingView's technical rating (-1 strong sell to +1 strong buy)."
    ),
    annotations=READ_ONLY,
)
def screen_stocks(
    market: str = "us",
    sector: str = "",
    min_price: float = 0,
    max_price: float = 0,
    min_volume: int = 0,
    min_market_cap: float = 0,
    sort_by: str = "change_percent",
    ascending: bool = False,
    limit: int = 25,
) -> str:
    """Screen stocks with filters using the TradingView screener.

    Args:
        market: Market/country to screen (us, uk, japan, all, etc.).
        sector: Sector filter (technology, healthcare, finance, energy, etc.).
                Leave empty for all sectors.
        min_price: Minimum stock price filter. 0 = no filter.
        max_price: Maximum stock price filter. 0 = no filter.
        min_volume: Minimum daily volume filter. 0 = no filter.
        min_market_cap: Minimum market cap in USD. 0 = no filter.
        sort_by: Sort field. One of: change_percent, volume, market_cap,
                 technical_rating, relative_volume, price.
        ascending: Sort direction. False = descending (default).
        limit: Maximum number of results (1-50, default 25).
    """
    limit = max(1, min(limit, 50))

    # Map sort_by to StockField
    sort_field_map = {
        "change_percent": StockField.CHANGE_PERCENT,
        "volume": StockField.VOLUME,
        "market_cap": StockField.MARKET_CAPITALIZATION,
        "technical_rating": StockField.TECHNICAL_RATING,
        "relative_volume": StockField.RELATIVE_VOLUME,
        "price": StockField.PRICE,
    }

    try:
        ss = StockScreener()

        # Set market
        mkt_key = market.strip().lower()
        mkt = _MARKET_MAP.get(mkt_key)
        if mkt is None:
            available = ", ".join(sorted(_MARKET_MAP.keys()))
            return json.dumps({
                "error": f"Unknown market '{market}'. Available: {available}"
            })
        ss.set_markets(mkt)

        # Select fields
        ss.select(
            StockField.NAME,
            StockField.PRICE,
            StockField.CHANGE_PERCENT,
            StockField.CHANGE_FROM_OPEN,
            StockField.VOLUME,
            StockField.MARKET_CAPITALIZATION,
            StockField.SECTOR,
            StockField.INDUSTRY,
            StockField.TECHNICAL_RATING,
            StockField.RELATIVE_VOLUME,
            StockField.WEEKLY_PERFORMANCE,
            StockField.MONTHLY_PERFORMANCE,
        )

        # Apply filters
        if sector:
            sec_key = sector.strip().lower().replace(" ", "_")
            sec = _SECTOR_MAP.get(sec_key)
            if sec is None:
                available = ", ".join(sorted(set(_SECTOR_MAP.keys())))
                return json.dumps({
                    "error": f"Unknown sector '{sector}'. Available: {available}"
                })
            ss.add_filter(StockField.SECTOR, FilterOperator.EQUAL, sec)

        if min_price > 0:
            ss.where(StockField.PRICE, FilterOperator.ABOVE, min_price)
        if max_price > 0:
            ss.where(StockField.PRICE, FilterOperator.BELOW, max_price)
        if min_volume > 0:
            ss.where(StockField.VOLUME, FilterOperator.ABOVE, min_volume)
        if min_market_cap > 0:
            ss.where(
                StockField.MARKET_CAPITALIZATION,
                FilterOperator.ABOVE,
                min_market_cap,
            )

        # Sort
        sf = sort_field_map.get(sort_by.strip().lower())
        if sf is None:
            available = ", ".join(sorted(sort_field_map.keys()))
            return json.dumps({
                "error": f"Unknown sort_by '{sort_by}'. Available: {available}"
            })
        ss.sort_by(sf, ascending=ascending)

        # Range
        ss.set_range(0, limit)

        # Execute
        df = ss.get()
        records = _df_to_records(df, max_rows=limit)

        return json.dumps({
            "market": market,
            "sector": sector or "all",
            "sort_by": sort_by,
            "ascending": ascending,
            "count": len(records),
            "results": records,
        }, indent=2)

    except Exception as e:
        log.exception("screen_stocks failed")
        return json.dumps({"error": f"Stock screening failed: {e}"})


# ---------------------------------------------------------------------------
# Tool 10: TradingView Crypto Screener
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Screen cryptocurrencies using TradingView's screener engine. Filter by "
        "minimum volume, minimum market cap, and sort by change_percent, volume, "
        "market_cap, or technical_rating. Returns up to 25 results with price, "
        "change%, volume, market cap, and TradingView's technical rating."
    ),
    annotations=READ_ONLY,
)
def screen_crypto(
    min_volume: float = 0,
    min_market_cap: float = 0,
    sort_by: str = "change_percent",
    ascending: bool = False,
    limit: int = 25,
) -> str:
    """Screen cryptocurrencies with filters using the TradingView screener.

    Args:
        min_volume: Minimum 24h volume in USD. 0 = no filter.
        min_market_cap: Minimum market cap in USD. 0 = no filter.
                        Tip: use 100000000 (100M) to filter out micro-cap
                        DEX pairs and get major coins.
        sort_by: Sort field. One of: change_percent, volume, market_cap,
                 technical_rating, price.
        ascending: Sort direction. False = descending (default).
        limit: Maximum number of results (1-50, default 25).
    """
    limit = max(1, min(limit, 50))

    sort_field_map = {
        "change_percent": CryptoField.CHANGE_PERCENT,
        "volume": CryptoField.VOLUME,
        "market_cap": CryptoField.MARKET_CAPITALIZATION,
        "technical_rating": CryptoField.TECHNICAL_RATING,
        "price": CryptoField.PRICE,
    }

    try:
        cs = CryptoScreener()

        # Select fields
        cs.select(
            CryptoField.NAME,
            CryptoField.PRICE,
            CryptoField.CHANGE_PERCENT,
            CryptoField.CHANGE_1H_PERCENT,
            CryptoField.CHANGE_1W_PERCENT,
            CryptoField.VOLUME,
            CryptoField.MARKET_CAPITALIZATION,
            CryptoField.TECHNICAL_RATING,
            CryptoField.EXCHANGE,
            CryptoField.RELATIVE_VOLUME,
        )

        # Apply filters
        if min_volume > 0:
            cs.where(CryptoField.VOLUME, FilterOperator.ABOVE, min_volume)
        if min_market_cap > 0:
            cs.where(
                CryptoField.MARKET_CAPITALIZATION,
                FilterOperator.ABOVE,
                min_market_cap,
            )

        # Sort
        sf = sort_field_map.get(sort_by.strip().lower())
        if sf is None:
            available = ", ".join(sorted(sort_field_map.keys()))
            return json.dumps({
                "error": f"Unknown sort_by '{sort_by}'. Available: {available}"
            })
        cs.sort_by(sf, ascending=ascending)

        # Range
        cs.set_range(0, limit)

        # Execute
        df = cs.get()
        records = _df_to_records(df, max_rows=limit)

        return json.dumps({
            "sort_by": sort_by,
            "ascending": ascending,
            "count": len(records),
            "results": records,
        }, indent=2)

    except Exception as e:
        log.exception("screen_crypto failed")
        return json.dumps({"error": f"Crypto screening failed: {e}"})


# ---------------------------------------------------------------------------
# Tool 11: Top Movers (TradingView)
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Get top stock market movers from TradingView: gainers, losers, and most "
        "active by volume. Unlike get_market_movers (which uses a fixed watchlist), "
        "this tool scans the ENTIRE market via TradingView's screener engine. "
        "Filter by market and optionally set a minimum price and volume floor "
        "to exclude penny stocks and illiquid names."
    ),
    annotations=READ_ONLY,
)
def top_movers(
    market: str = "us",
    min_price: float = 1.0,
    min_volume: int = 100000,
    count: int = 10,
) -> str:
    """Fetch top gainers, losers, and most active stocks from TradingView.

    Args:
        market: Market/country (us, uk, japan, all, etc.). Default: us.
        min_price: Minimum price to exclude penny stocks. Default: 1.0.
        min_volume: Minimum volume to exclude illiquid names. Default: 100000.
        count: Number of results per category (1-25). Default: 10.
    """
    count = max(1, min(count, 25))

    mkt_key = market.strip().lower()
    mkt = _MARKET_MAP.get(mkt_key)
    if mkt is None:
        available = ", ".join(sorted(_MARKET_MAP.keys()))
        return json.dumps({
            "error": f"Unknown market '{market}'. Available: {available}"
        })

    select_fields = (
        StockField.NAME,
        StockField.PRICE,
        StockField.CHANGE_PERCENT,
        StockField.CHANGE_FROM_OPEN,
        StockField.VOLUME,
        StockField.MARKET_CAPITALIZATION,
        StockField.SECTOR,
        StockField.RELATIVE_VOLUME,
    )

    def _build_screener(
        sort_field: StockField, asc: bool
    ) -> list[dict]:
        """Build, execute, and return records for one screener query."""
        ss = StockScreener()
        ss.set_markets(mkt)
        ss.select(*select_fields)
        if min_price > 0:
            ss.where(StockField.PRICE, FilterOperator.ABOVE, min_price)
        if min_volume > 0:
            ss.where(StockField.VOLUME, FilterOperator.ABOVE, min_volume)
        ss.sort_by(sort_field, ascending=asc)
        ss.set_range(0, count)
        df = ss.get()
        return _df_to_records(df, max_rows=count)

    try:
        gainers = _build_screener(StockField.CHANGE_PERCENT, asc=False)
        losers = _build_screener(StockField.CHANGE_PERCENT, asc=True)
        most_active = _build_screener(StockField.VOLUME, asc=False)

        return json.dumps({
            "market": market,
            "min_price": min_price,
            "min_volume": min_volume,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "top_gainers": gainers,
            "top_losers": losers,
            "most_active": most_active,
        }, indent=2)

    except Exception as e:
        log.exception("top_movers failed")
        return json.dumps({"error": f"Failed to fetch top movers: {e}"})


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

def main():
    """Run the MCP server with configurable transport."""
    transport = "stdio"
    port = DEFAULT_PORT

    # Simple arg parsing without adding dependencies
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--transport" and i + 1 < len(args):
            transport = args[i + 1]
        elif arg == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
        elif arg == "--help":
            print(f"Market Data MCP Server v{SERVER_VERSION}")
            print()
            print("Usage: market-data-mcp [OPTIONS]")
            print()
            print("Options:")
            print("  --transport TYPE   stdio (default), sse, or streamable-http")
            print(f"  --port PORT        Port for HTTP transports (default: {DEFAULT_PORT})")
            print("  --help             Show this help message")
            sys.exit(0)

    log.info("Starting %s v%s (transport=%s)", SERVER_NAME, SERVER_VERSION, transport)

    if transport == "stdio":
        mcp.run(transport="stdio")
    elif transport == "sse":
        mcp.run(transport="sse", host="0.0.0.0", port=port)
    elif transport in ("streamable-http", "http"):
        mcp.run(transport="streamable-http", host="0.0.0.0", port=port)
    else:
        log.error("Unknown transport: %s", transport)
        sys.exit(1)


if __name__ == "__main__":
    main()
