#!/bin/bash
uv build
