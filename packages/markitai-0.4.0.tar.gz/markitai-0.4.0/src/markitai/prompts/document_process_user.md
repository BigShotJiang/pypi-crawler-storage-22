请处理以下文档：

---

{content}
