#!/usr/bin/env python3
"""
MarkShark
score_core.py  —  Axis-based MarkShark grading engine

Features:
 - Multi-version exam support
 - Simplified CSV output: Page, Version, LastName, FirstName, StudentID,
   Correct, Incorrect, Blank, Multi, Percent, Flagged, FlagDetails, Q1-Qn
 - KEY row(s) at top for each version
 - Flagged column: Y if student has any flagged items, blank otherwise
 - FlagDetails column: coded flags like Q10:multi|Q5:blank|ID:orphan
 - Annotated PNGs:
     * Names/ID: blue circles, optional white % text
     * Answers: green=correct, red=incorrect, grey=blank, orange=multi
 - Optional % fill text via --label-density
 - Columns limited to len(key) when a key is provided
 - Stats and reports generated separately from this raw data output
"""

from __future__ import annotations
import os
import csv
import sys
from typing import Optional, List, Tuple, Dict


import numpy as np
import cv2
from .defaults import (
    ANNOTATION_DEFAULTS,
    AnnotationDefaults,
    SCORING_DEFAULTS,
    RENDER_DEFAULTS,
    resolve_scored_pdf_path,
)

from .tools.bubblemap_io import load_bublmap, Bubblemap, GridLayout, PageLayout, OutputZone
from .tools import io_pages as IO
from .tools.score_tools import (
    process_page_all,
    load_key_txt,
    load_multi_version_keys,
    score_against_multi_keys,
    grid_centers_axis_mode,
    centers_to_circle_rois,
    roi_fill_scores,
    calibrate_fixed_thresh_for_page,
    # Advanced key support
    load_advanced_key,
    is_advanced_key_format,
    score_with_advanced_key,
)


# ----------------------------
# Roster Loading and Matching
# ----------------------------

def load_roster(roster_path: str) -> Dict[str, Dict[str, str]]:
    """
    Load a roster CSV file.

    Expected columns: StudentID, FirstName, LastName (case-insensitive)
    Additional columns are preserved but not required.

    Returns:
        Dict mapping student_id -> {first_name, last_name, ...}
    """
    roster = {}

    with open(roster_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)

        # Normalize header names (case-insensitive)
        fieldnames_lower = {name.lower(): name for name in reader.fieldnames} if reader.fieldnames else {}

        id_col = fieldnames_lower.get('studentid') or fieldnames_lower.get('student_id') or fieldnames_lower.get('id')
        first_col = fieldnames_lower.get('firstname') or fieldnames_lower.get('first_name') or fieldnames_lower.get('first')
        last_col = fieldnames_lower.get('lastname') or fieldnames_lower.get('last_name') or fieldnames_lower.get('last')

        if not id_col:
            raise ValueError(f"Roster must have a StudentID column. Found: {reader.fieldnames}")

        for row in reader:
            sid = row.get(id_col, '').strip()
            if not sid:
                continue

            roster[sid] = {
                'first_name': row.get(first_col, '').strip() if first_col else '',
                'last_name': row.get(last_col, '').strip() if last_col else '',
                'full_name': f"{row.get(first_col, '').strip()} {row.get(last_col, '').strip()}".strip() if first_col else '',
            }

    return roster


def match_roster(
    scored_students: List[Dict],
    roster: Dict[str, Dict[str, str]],
) -> Tuple[List[Dict], List[Dict], List[str]]:
    """
    Match scored students against roster.

    Args:
        scored_students: List of scored student dicts with 'student_id' key
        roster: Dict from load_roster()

    Returns:
        Tuple of:
        - matched: Students found in roster
        - orphans: Students NOT found in roster (possible ID errors)
        - absent_ids: Roster IDs with no matching scan
    """
    matched = []
    orphans = []
    found_ids = set()

    for student in scored_students:
        sid = student.get('student_id', '').strip()
        if sid in roster:
            matched.append(student)
            found_ids.add(sid)
        else:
            orphans.append(student)

    # Find absent students (on roster but no scan)
    absent_ids = [sid for sid in roster.keys() if sid not in found_ids]

    return matched, orphans, absent_ids


def _id_edit_distance(a: str, b: str) -> int:
    """Levenshtein edit distance between two ID strings.

    Handles insertion, deletion, and substitution.
    Student IDs are typically 8-10 chars so this is trivially fast.
    """
    if len(a) < len(b):
        return _id_edit_distance(b, a)
    if not b:
        return len(a)

    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            cost = 0 if ca == cb else 1
            curr.append(min(
                curr[j] + 1,       # insert
                prev[j + 1] + 1,   # delete
                prev[j] + cost,    # substitute
            ))
        prev = curr
    return prev[-1]


def suggest_matches(
    orphan_id: str,
    orphan_name: str,
    absent_roster: Dict[str, Dict[str, str]],
    max_suggestions: int = 3
) -> List[Dict[str, str]]:
    """
    Suggest possible roster matches for an orphan scan.

    Uses a two-pass approach:
      1. Custom digit-focused analysis (transpositions, single-digit errors)
         that produces human-readable reasons.
      2. rapidfuzz fallback for roster entries that the custom pass missed,
         so the same matches available in the report are also surfaced here.

    Args:
        orphan_id: The student ID from the scan
        orphan_name: The student name from the scan
        absent_roster: Dict of absent students from roster
        max_suggestions: Maximum number of suggestions to return

    Returns:
        List of suggestions with {student_id, name, score, reason}
    """
    suggestions = []
    scored_ids: set = set()  # roster IDs that got a score > 0 from custom pass
    orphan_name_lower = orphan_name.lower().strip()

    for roster_id, roster_info in absent_roster.items():
        score = 0
        reasons = []

        # ── ID similarity scoring ──
        len_diff = abs(len(orphan_id) - len(roster_id))

        if len(orphan_id) == len(roster_id):
            # Same-length: positional digit comparison
            diff_count = sum(1 for a, b in zip(orphan_id, roster_id) if a != b)
            if diff_count == 1:
                score += 6
                reasons.append("1 digit off")
            elif diff_count == 2:
                # Check for adjacent-digit transposition
                for i in range(len(orphan_id) - 1):
                    swapped = orphan_id[:i] + orphan_id[i+1] + orphan_id[i] + orphan_id[i+2:]
                    if swapped == roster_id:
                        score += 7
                        reasons.append("digit swap")
                        break
                else:
                    score += 2
                    reasons.append("2 digits off")

        elif len_diff == 1:
            # One digit missing or extra — try single-char deletion
            longer = orphan_id if len(orphan_id) > len(roster_id) else roster_id
            shorter = roster_id if len(orphan_id) > len(roster_id) else orphan_id
            found_deletion = False
            for i in range(len(longer)):
                if longer[:i] + longer[i+1:] == shorter:
                    score += 5
                    reasons.append(
                        "1 extra digit" if len(orphan_id) > len(roster_id)
                        else "1 digit missing"
                    )
                    found_deletion = True
                    break
            if not found_deletion:
                # Fallback: edit distance for messier single-char-diff cases
                ed = _id_edit_distance(orphan_id, roster_id)
                if ed <= 2:
                    score += max(1, 4 - ed)
                    reasons.append(f"edit distance {ed}")

        elif len_diff <= 3:
            # Larger length difference — use edit distance
            ed = _id_edit_distance(orphan_id, roster_id)
            if ed <= 3:
                score += max(1, 4 - ed)
                reasons.append(f"edit distance {ed}")

        # Check for name similarity
        roster_name_lower = roster_info.get('full_name', '').lower().strip()
        if roster_name_lower and orphan_name_lower:
            # Simple substring match
            if orphan_name_lower in roster_name_lower or roster_name_lower in orphan_name_lower:
                score += 5
                reasons.append("name match")
            else:
                # Check individual name parts
                orphan_parts = set(orphan_name_lower.split())
                roster_parts = set(roster_name_lower.split())
                common = orphan_parts & roster_parts
                if common:
                    score += 2 * len(common)
                    reasons.append("partial name")

        if score > 0:
            scored_ids.add(roster_id)
            suggestions.append({
                'student_id': roster_id,
                'name': roster_info.get('full_name', ''),
                'score': score,
                'reason': ', '.join(reasons),
            })

    # ── Pass 2: rapidfuzz fallback for entries the custom pass missed ──
    try:
        from rapidfuzz import fuzz as _fuzz
    except ImportError:
        _fuzz = None

    if _fuzz is not None:
        for roster_id, roster_info in absent_roster.items():
            if roster_id in scored_ids:
                continue  # already handled by the custom pass

            reasons = []
            score = 0

            # Fuzzy ID similarity (0–100 scale)
            id_ratio = _fuzz.ratio(orphan_id, roster_id)
            if id_ratio >= 80:
                # Map 80→4, 90→4.5, 100→5  (keeps scores comparable to custom pass)
                score += id_ratio / 20.0
                reasons.append(f"fuzzy ID ({id_ratio:.0f}%)")

            # Fuzzy name similarity
            roster_name = roster_info.get('full_name', '').strip()
            if roster_name and orphan_name_lower:
                name_ratio = _fuzz.ratio(orphan_name_lower, roster_name.lower())
                if name_ratio >= 85:
                    score += name_ratio / 20.0
                    reasons.append(f"fuzzy name ({name_ratio:.0f}%)")

            if score >= 2:
                suggestions.append({
                    'student_id': roster_id,
                    'name': roster_info.get('full_name', ''),
                    'score': score,
                    'reason': ', '.join(reasons),
                })

    # Filter out very low-confidence suggestions, sort by score, take top N
    suggestions = [s for s in suggestions if s['score'] >= 2]
    suggestions.sort(key=lambda x: x['score'], reverse=True)
    return suggestions[:max_suggestions]


# ----------------------------
# Utilities
# ----------------------------

def _ensure_dir(path: str) -> None:
    if path and not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)


def _rowwise_scores(
    gray: np.ndarray,
    rois: List[Tuple[int, int, int, int]],
    rows: int,
    cols: int,
    fixed_thresh: Optional[int] = None,
) -> List[List[float]]:
    """Return a rows x cols matrix of fill scores (0-1)."""
    flat = roi_fill_scores(
        gray,
        rois,
        inner_radius_ratio=0.70,
        blur_ksize=5,
        fixed_thresh=fixed_thresh,
    )
    return [flat[r * cols:(r + 1) * cols] for r in range(rows)]

# ----------------------------
# Multi-page support helper
# ----------------------------

def _process_single_page(
    img_bgr: np.ndarray,
    page_layout: 'PageLayout',
    *,
    min_fill: float,
    fixed_thresh: Optional[int] = None,
) -> Tuple[dict, List[Optional[str]]]:
    """
    Process a single page using a specific PageLayout from a multi-page bubblemap.
    Returns (info_dict, answers_list) for this page only.
    """
    from .tools.score_tools import decode_layout, indices_to_text_col
    
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    
    info = {"last_name": "", "first_name": "", "student_id": "", "version": ""}
    
    # Decode name/ID from this page (if layouts are present)
    if page_layout.last_name_zone:
        picked, _, _ = decode_layout(
            gray,
            page_layout.last_name_zone,
            min_fill=min_fill,
            fixed_thresh=fixed_thresh,
        )
        info["last_name"] = indices_to_text_col(
            picked, page_layout.last_name_zone.labels or " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        ).strip()

    if page_layout.first_name_zone:
        picked, _, _ = decode_layout(
            gray,
            page_layout.first_name_zone,
            min_fill=min_fill,
            fixed_thresh=fixed_thresh,
        )
        info["first_name"] = indices_to_text_col(
            picked, page_layout.first_name_zone.labels or " ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        ).strip()

    if page_layout.id_zone:
        picked, _, _ = decode_layout(
            gray,
            page_layout.id_zone,
            min_fill=min_fill,
            fixed_thresh=fixed_thresh,
        )
        info["student_id"] = indices_to_text_col(
            picked, page_layout.id_zone.labels or "0123456789"
        ).strip()

    if page_layout.version_zone:
        # Version detection (usually only on page 1)
        picked, _, _ = decode_layout(
            gray,
            page_layout.version_zone,
            min_fill=min_fill,
            fixed_thresh=fixed_thresh,
        )
        if picked and len(picked) > 0 and picked[0] is not None:
            labels = page_layout.version_zone.labels or "ABCD"
            info["version"] = labels[picked[0]] if picked[0] < len(labels) else ""

    # Decode answers from this page
    answers: List[Optional[str]] = []
    for layout in page_layout.answer_zones:
        picked, _, scores = decode_layout(
            gray,
            layout,
            min_fill=min_fill,
            fixed_thresh=fixed_thresh,
        )
        choice_labels = list(layout.labels) if layout.labels else [chr(ord("A") + k) for k in range(layout.numcols)]
        if layout.selection_axis == "row":
            from .tools.score_tools import scores_to_labels_row
            answers.extend(
                scores_to_labels_row(
                    scores,
                    layout.numrows,
                    layout.numcols,
                    choice_labels,
                    min_fill=min_fill,
                )
            )
        else:
            from .tools.score_tools import indices_to_labels_row
            answers.extend(indices_to_labels_row(picked, layout.numcols, choice_labels))
    
    return info, answers


# ----------------------------
# Annotation helpers
# ----------------------------

def _annotate_names_ids(
    img_bgr: np.ndarray,
    bmap: Bubblemap,
    label_density: bool,
    color_zone=None,
    text_color=None,
    thickness: Optional[int] = None,
    font_scale: Optional[float] = None,
    label_thickness: Optional[int] = None,
    annotation_defaults: Optional[AnnotationDefaults] = None,
) -> np.ndarray:
    """
    Draw blue circles for Last/First Name and Student ID grids.
    If label_density=True, write white % fill text in each bubble.
    Returns a new image with drawings (does not modify input in place).
    """
    out = img_bgr.copy()
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    H, W = gray.shape[:2]

    ad = annotation_defaults or ANNOTATION_DEFAULTS
    if color_zone is None:
        color_zone = ad.color_zone
    if text_color is None:
        text_color = ad.percent_text_color
    if thickness is None:
        thickness = ad.thickness_names
    if font_scale is None:
        font_scale = ad.label_font_scale
    if label_thickness is None:
        label_thickness = ad.label_thickness

    def draw_layout(layout: GridLayout) -> None:
        centers = grid_centers_axis_mode(
            layout.x_topleft, layout.y_topleft,
            layout.x_bottomright, layout.y_bottomright,
            layout.numrows, layout.numcols
        )
        rois = centers_to_circle_rois(centers, W, H, layout.radius_pct)
        scores = roi_fill_scores(gray, rois, inner_radius_ratio=0.70, blur_ksize=5)
        for idx, (x, y, w, h) in enumerate(rois):
            cx, cy = x + w // 2, y + h // 2
            radius = min(w, h) // 2
            cv2.circle(out, (cx, cy), radius, color_zone, thickness, lineType=cv2.LINE_AA)
            if label_density:
                pct = int(round(100 * scores[idx]))
                # Position text in the top-left corner of the bubble's bounding box
                txt_x = x + 1
                txt_y = y + int(10 * font_scale / 0.28)  # scale offset with font size
                cv2.putText(out, f"{pct}", (txt_x, txt_y),
                            cv2.FONT_HERSHEY_SIMPLEX, float(font_scale), text_color, int(label_thickness), cv2.LINE_AA)

    for attr in ("last_name_zone", "first_name_zone", "id_zone"):
        lay = getattr(bmap, attr, None)
        if isinstance(lay, GridLayout):
            draw_layout(lay)

    return out


def _annotate_answers(
img_bgr: np.ndarray,
bmap: Bubblemap,
key_letters: Optional[List[str]],
label_density: bool,
annotate_all_cells: bool,
min_fill: float,
answers_for_annotation: Optional[List[Optional[str]]] = None,
fixed_thresh: Optional[int] = None,
calibrate_background: bool = False,
background_percentile: float = SCORING_DEFAULTS.background_percentile,
color_correct=None,
color_incorrect=None,
color_blank=None,
color_blank_answer_row=None,
color_multi=None,
thickness: Optional[int] = None,
pct_fill_font_color=None,
pct_fill_font_scale=None,
pct_fill_font_thickness=None,
pct_fill_font_position=None,
annotation_defaults: Optional[AnnotationDefaults] = None,
box_multi: Optional[bool] = None,
box_blank_answer_row: Optional[bool] = None,
box_color_multi=None,
box_color_blank_answer_row=None,
box_thickness: Optional[int] = None,
box_pad: Optional[int] = None,
box_top_extra: Optional[int] = None,
corrected_questions: Optional[set] = None,
) -> np.ndarray:
    """
    Draw per-bubble overlays for answer blocks:
      - green circle for correct,
      - red for incorrect,
      - grey for blank,
      - orange for multi,
      - teal diamond for corrected questions (when corrected_questions is provided).
    Optionally put % fill text in each bubble (label_density=True).

    corrected_questions : set of 0-indexed question numbers that were manually
        corrected by the teacher.  When a question is in this set, its selected
        bubble(s) are drawn as teal diamonds instead of the normal circles.
        The colour still reflects correct/incorrect, but the diamond shape
        signals "this answer was overridden by the teacher".

    Returns a new image with drawings (does not modify input in place).
    """
    out = img_bgr.copy()
    H, W = out.shape[:2]
    key_seq = [k.upper() for k in key_letters] if key_letters else None

    # Resolve annotation defaults
    ad = annotation_defaults or ANNOTATION_DEFAULTS
    if color_correct is None:
        color_correct = ad.color_correct
    if color_incorrect is None:
        color_incorrect = ad.color_incorrect
    if color_blank is None:
        color_blank = ad.color_blank
    if color_blank_answer_row is None:
        color_blank_answer_row = getattr(ad, "color_blank_answer_row", (255, 0, 255))
    if color_multi is None:
        color_multi = ad.color_multi
    if thickness is None:
        thickness = ad.thickness_answers

    # Resolve annotation defaults
    if pct_fill_font_color is None:
        pct_fill_font_color  = getattr(ad, "pct_fill_font_color", (255, 0, 255))
    if pct_fill_font_scale is None:
        pct_fill_font_scale = getattr(ad, "pct_fill_font_scale", 0.5)
    if pct_fill_font_thickness is None:
        pct_fill_font_thickness = getattr(ad, "pct_fill_font_thickness", 1)
    if pct_fill_font_position is None:
        pct_fill_font_position = getattr(ad, "pct_fill_font_position", 5)

    # Row box defaults
    if box_multi is None:
        box_multi = getattr(ad, "box_multi", False)
    if box_blank_answer_row is None:
        box_blank_answer_row = getattr(ad, "box_blank_answer_row", False)
    if box_color_multi is None:
        box_color_multi = getattr(ad, "box_color_multi", color_multi)
    if box_color_blank_answer_row is None:
        box_color_blank_answer_row = getattr(ad, "box_color_blank_answer_row", color_blank_answer_row)
    if box_thickness is None:
        box_thickness = getattr(ad, "box_thickness", thickness)
    if box_pad is None:
        box_pad = getattr(ad, "box_pad", 6)
    if box_top_extra is None:
        box_top_extra = getattr(ad, "box_top_extra", 0)

    # Corrected-question defaults (diamond shape in teal)
    color_corrected = getattr(ad, "color_corrected", (180, 130, 0))
    thickness_corrected = getattr(ad, "thickness_corrected", 3)
    corrected_set = corrected_questions or set()

    q_global = 0
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    for layout in bmap.answer_zones:
        centers = grid_centers_axis_mode(
            layout.x_topleft, layout.y_topleft,
            layout.x_bottomright, layout.y_bottomright,
            layout.numrows, layout.numcols
        )
        rois = centers_to_circle_rois(centers, W, H, layout.radius_pct)
        M = _rowwise_scores(gray, rois, layout.numrows, layout.numcols, fixed_thresh=fixed_thresh,)

        # Apply background calibration if enabled
        if calibrate_background and layout.numrows > 1:
            from .tools.score_tools import calibrate_column_backgrounds, subtract_column_backgrounds
            flat_scores = [score for row in M for score in row]  # Flatten to list
            backgrounds = calibrate_column_backgrounds(flat_scores, layout.numrows, layout.numcols, background_percentile)
            calibrated_flat = subtract_column_backgrounds(flat_scores, layout.numrows, layout.numcols, backgrounds)
            # Reshape back to rows x cols
            M = [calibrated_flat[r * layout.numcols:(r + 1) * layout.numcols] for r in range(layout.numrows)]

        choice_labels = list(layout.labels) if layout.labels else [chr(ord("A") + i) for i in range(layout.numcols)]
        label_to_idx = {str(lab).strip().upper(): i for i, lab in enumerate(choice_labels)}

        for r in range(layout.numrows):
            # Skip annotation for questions beyond the answer key length
            if answers_for_annotation is not None and q_global >= len(answers_for_annotation):
                q_global += 1
                continue
            
            row_scores = M[r]
            order = np.argsort(row_scores)[::-1]
            best = int(order[0])
            best_val = float(row_scores[best])
            second_val = float(row_scores[order[1]]) if layout.numcols > 1 else 0.0
            is_blank = best_val < min_fill
            is_multi = (not is_blank) and (layout.numcols > 1) and (second_val >= min_fill)

            # If available, drive annotation from the same scoring decisions used for the CSV.
            # This prevents borderline cases being labeled blank in the CSV but shown as selected in the PDF overlay.
            selected_labels = []  # type: List[str]
            selected_idx = set()

            if answers_for_annotation is not None and q_global < len(answers_for_annotation):
                ans = answers_for_annotation[q_global]
                if ans is None or ans == "":
                    is_blank, is_multi = True, False
                else:
                    ans_str = str(ans).strip().upper()
                    if "," in ans_str:
                        is_blank, is_multi = False, True
                        selected_labels = [p.strip() for p in ans_str.split(",") if p.strip()]
                    else:
                        is_blank, is_multi = False, False
                        selected_labels = [ans_str]

                for lab in selected_labels:
                    if lab in label_to_idx:
                        selected_idx.add(label_to_idx[lab])

            # Fallback: if we did not map any selected labels, use local score winners.
            if not selected_idx:
                if is_multi and layout.numcols > 1:
                    selected_idx = {best, int(order[1])}
                elif not is_blank:
                    selected_idx = {best}


            key_char = key_seq[q_global] if key_seq and q_global < len(key_seq) else None

            # For compound keys (AND "A&C", partial "A@B" / "A~B"), multiple
            # bubbles are the EXPECTED answer.  Don't flag them with the
            # orange multi box — colour each bubble correct/incorrect instead.
            is_and_key = bool(key_char and "&" in key_char)
            is_partial_key = bool(key_char and ("@" in key_char or "~" in key_char))
            expects_multi = is_and_key or is_partial_key
            if expects_multi and is_multi:
                is_multi = False  # suppress orange box; per-bubble colouring below

            answer_row_blank = bool(is_blank and key_char and (key_char in choice_labels))

            # Optional row-level boxes, draw these before circles and text
            if (is_multi and box_multi) or (answer_row_blank and box_blank_answer_row):
                row_rois = rois[r * layout.numcols:(r + 1) * layout.numcols]
                x0 = min(x for x, y, w, h in row_rois)
                y0 = min(y for x, y, w, h in row_rois)
                x1 = max(x + w for x, y, w, h in row_rois)
                y1 = max(y + h for x, y, w, h in row_rois)

                x0 = max(0, x0 - int(box_pad))
                y0 = max(0, y0 - int(box_pad) - int(box_top_extra))
                x1 = min(W - 1, x1 + int(box_pad))
                y1 = min(H - 1, y1 + int(box_pad))

                if is_multi and box_multi:
                    cv2.rectangle(out, (x0, y0), (x1, y1), box_color_multi, int(box_thickness), lineType=cv2.LINE_AA)
                if answer_row_blank and box_blank_answer_row:
                    cv2.rectangle(out, (x0, y0), (x1, y1), box_color_blank_answer_row, int(box_thickness), lineType=cv2.LINE_AA)


            for c in range(layout.numcols):
                x, y, w, h = rois[r * layout.numcols + c]
                cx, cy = x + w // 2, y + h // 2
                radius = min(w, h) // 2

                draw_this = annotate_all_cells or (c in selected_idx) or is_blank or is_multi
                if not draw_this:
                    continue

                if is_blank:
                    col = (color_blank_answer_row if answer_row_blank else color_blank)
                elif is_multi:
                    col = color_multi
                else:
                    if key_char:
                        is_selected = c in selected_idx

                        if is_and_key:
                            # AND key: compare student's label set vs key's required set
                            required = set(p.strip().upper() for p in key_char.split("&"))
                            student_set = set(lab.upper() for lab in selected_labels) if selected_labels else set()
                            and_correct = (student_set == required)
                            col = color_correct if (is_selected and and_correct) else (
                                color_incorrect if is_selected else (200, 200, 200)
                            )
                        elif is_partial_key:
                            # Partial credit (@/~): each bubble green if in correct set, red if not
                            op = "@" if "@" in key_char else "~"
                            correct_set = set(
                                p.split(":")[0].strip().upper()
                                for p in key_char.split(op)
                                if p.strip()
                            )
                            bubble_label = str(choice_labels[c]).strip().upper() if c < len(choice_labels) else ""
                            if is_selected:
                                col = color_correct if bubble_label in correct_set else color_incorrect
                            else:
                                col = (200, 200, 200)
                        elif "^" in key_char:
                            # OR key: any one of the accepted answers is correct
                            accepted = set(p.strip().upper() for p in key_char.split("^"))
                            selected_single = None
                            if selected_labels and len(selected_labels) == 1:
                                selected_single = selected_labels[0]
                            elif (not selected_labels) and (not is_blank) and (not is_multi) and len(selected_idx) == 1:
                                only_idx = next(iter(selected_idx))
                                selected_single = str(choice_labels[only_idx]).strip().upper()
                            or_correct = bool(selected_single and selected_single in accepted)
                            col = color_correct if (is_selected and or_correct) else (
                                color_incorrect if is_selected else (200, 200, 200)
                            )
                        else:
                            selected_single = None
                            if selected_labels and len(selected_labels) == 1:
                                selected_single = selected_labels[0]
                            elif (not selected_labels) and (not is_blank) and (not is_multi) and len(selected_idx) == 1:
                                only_idx = next(iter(selected_idx))
                                selected_single = str(choice_labels[only_idx]).strip().upper()

                            col = color_correct if (is_selected and selected_single == key_char) else (
                                color_incorrect if is_selected else (200, 200, 200)
                            )
                    else:
                        col = (0, 200, 200) if (c in selected_idx) else (200, 200, 200)

                # Corrected questions get a diamond shape in teal so they
                # stand out visually on the annotated sheet.  The colour
                # stays correct/incorrect but the shape signals "teacher
                # override".  Non-corrected questions keep the normal circle.
                if q_global in corrected_set and c in selected_idx:
                    # Diamond = rotated square whose inscribed circle has
                    # the same radius, so the diamond tips extend ~40% further.
                    d = int(radius * 1.1)  # half-diagonal of the diamond
                    pts = np.array([
                        [cx, cy - d],   # top
                        [cx + d, cy],   # right
                        [cx, cy + d],   # bottom
                        [cx - d, cy],   # left
                    ], dtype=np.int32)
                    cv2.polylines(out, [pts], isClosed=True, color=color_corrected,
                                  thickness=thickness_corrected, lineType=cv2.LINE_AA)
                else:
                    cv2.circle(out, (cx, cy), radius, col, thickness, lineType=cv2.LINE_AA)

                if label_density:
                    pct = int(round(100 * row_scores[c]))
                
                    # Put text above the circle
                    text = f"{pct}"
                    font = cv2.FONT_HERSHEY_SIMPLEX
                
                    (tw, th), baseline = cv2.getTextSize(text, font, pct_fill_font_scale, 
                    pct_fill_font_thickness)
                
                    # this formula sets text baseline position above or below circle
                    # pct_fill_font_position values correspond to pixels.
                    # these values should be set in the defaults.py script
                    # a value of zero puts the text right on top of the circle
                    # negative values pull the text into the circle.
                    # positive values push the text farther above the circle
                    tx = cx - tw // 2
                    ty = cy - radius - pct_fill_font_position  
                
                    # Keep text inside the image bounds
                    tx = max(0, min(tx, W - tw - 1))
                    ty = max(th + 1, ty)  # avoid going off the top
                
                    cv2.putText(out, text, (tx, ty),
                                font, pct_fill_font_scale, pct_fill_font_color,
                                pct_fill_font_thickness, cv2.LINE_AA)

            # Corrected-row indicator: draw a small filled teal dot to the
            # right of the last bubble so corrected rows pop visually even
            # when the diamond shape alone is hard to spot at a glance.
            if q_global in corrected_set:
                last_roi = rois[r * layout.numcols + (layout.numcols - 1)]
                lx, ly, lw, lh = last_roi
                dot_radius = max(3, radius // 3)  # small but visible
                dot_x = lx + lw + dot_radius + 4  # ~4 px pad from rightmost bubble
                dot_y = ly + lh // 2               # vertically centred
                cv2.circle(out, (dot_x, dot_y), dot_radius,
                           color_corrected, -1, lineType=cv2.LINE_AA)

            q_global += 1

    return out


def _annotate_output_zone(
    img_bgr: np.ndarray,
    output_zone: OutputZone,
    student_info: dict,
    score_info: dict,
    roster: Optional[dict] = None,
    flag_details: str = "",
    annotation_defaults: Optional[AnnotationDefaults] = None,
    corrections_applied: bool = False,
) -> np.ndarray:
    """Draw student name, score, and optional roster/flag text in the output zone.

    Parameters
    ----------
    img_bgr : BGR image (numpy array).
    output_zone : OutputZone with normalised 0-1 coordinates.
    student_info : dict with keys ``last_name``, ``first_name``, ``student_id``.
    score_info : dict with keys ``score``, ``total``, ``percent``, ``version``,
                 ``has_key`` (bool, True when a key was provided).
    roster : optional dict mapping student_id → {first_name, last_name, …}.
    flag_details : pipe-separated flag string, e.g. ``"Q5:blank|Q10:multi"``.
    annotation_defaults : colour / font overrides.

    Returns a new image with the text overlay drawn.

    Line 1: ``{LastName}, {FirstName}   ID: {StudentID}   Score: X/Y (pct%)   YYYY-MM-DD``
    Line 2: ``From Roster: {Last}, {First}`` (only if a roster match is found)
    Line 3: ``Flagged: Q5 (blank), Q10 (multi)`` (only if there are flagged questions)
    """
    import datetime

    out = img_bgr.copy()
    H, W = out.shape[:2]
    ad = annotation_defaults or ANNOTATION_DEFAULTS

    # Resolve annotation style from defaults
    font_scale = getattr(ad, "output_font_scale", 0.55)
    font_thickness = getattr(ad, "output_font_thickness", 1)
    font_color = getattr(ad, "output_font_color", (180, 0, 0))
    bg_color = getattr(ad, "output_bg_color", (255, 255, 255))
    bg_alpha = getattr(ad, "output_bg_alpha", 0.7)

    # Convert normalised coords → pixel rect
    x1 = int(output_zone.x_left * W)
    y1 = int(output_zone.y_top * H)
    x2 = int(output_zone.x_right * W)
    y2 = int(output_zone.y_bottom * H)

    # Semi-transparent white background so text is readable over the form
    overlay = out.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), bg_color, -1)
    cv2.addWeighted(overlay, bg_alpha, out, 1 - bg_alpha, 0, out)

    # ---- Build text lines ----
    last_name = student_info.get("last_name", "")
    first_name = student_info.get("first_name", "")
    student_id = student_info.get("student_id", "")
    date_str = datetime.date.today().strftime("%Y-%m-%d")

    name_part = last_name
    if first_name:
        name_part += f", {first_name}"

    has_key = score_info.get("has_key", True)
    if has_key:
        score_val = score_info.get("score", 0)
        total_val = score_info.get("total", 0)
        percent_val = score_info.get("percent", 0.0)
        # Format with appropriate precision (no decimal if whole number)
        s_str = str(int(score_val)) if score_val == int(score_val) else f"{score_val:.1f}"
        t_str = str(int(total_val)) if total_val == int(total_val) else f"{total_val:.1f}"
        line1 = f"{name_part}   ID: {student_id}   Score: {s_str}/{t_str} ({percent_val:.1f}%)   {date_str}"
    else:
        line1 = f"{name_part}   ID: {student_id}   {date_str}"

    # Line 2: roster match (simple dict lookup, not the full match_roster())
    # Show "No roster match" when a roster was provided but ID wasn't found,
    # so the teacher knows to investigate — but never show alternative names
    # (privacy: students shouldn't see other students' IDs on returned sheets).
    line2 = ""
    if roster and student_id:
        match = roster.get(student_id)
        if match:
            r_last = match.get("last_name", "")
            r_first = match.get("first_name", "")
            roster_name = r_last
            if r_first:
                roster_name += f", {r_first}"
            if roster_name:
                line2 = f"From Roster: {roster_name}"
        else:
            line2 = "No roster match"
    elif roster and not student_id:
        line2 = "No roster match (no ID detected)"

    # Line 3: flagged questions — convert pipe-delimited codes to readable text
    # e.g. "Q5:blank|Q10:multi|Version:blank" → "Flagged: Version (blank), Q5 (blank), Q10 (multi)"
    line3 = ""
    if flag_details:
        parts = []
        for flag in flag_details.split("|"):
            flag = flag.strip()
            if not flag:
                continue
            if ":" in flag:
                name, reason = flag.split(":", 1)
                parts.append(f"{name} ({reason})")
            else:
                parts.append(flag)
        if parts:
            line3 = "Flagged: " + ", ".join(parts)

    # ---- Collect non-empty lines for rendering ----
    lines = [line1]
    if line2:
        lines.append(line2)
    if line3:
        lines.append(line3)
    if corrections_applied:
        lines.append(f"Corrections applied: {date_str}")

    # ---- Draw text inside the rectangle ----
    font = cv2.FONT_HERSHEY_SIMPLEX
    margin_x = 5  # pixels from left edge of box

    box_width = x2 - x1 - 2 * margin_x
    box_height = y2 - y1

    # Measure line 1 at the default font scale (widest line drives auto-scaling)
    (tw1, th1), _ = cv2.getTextSize(line1, font, font_scale, font_thickness)

    # Auto-scale font down if the widest line exceeds the box width
    scale = font_scale
    max_tw = tw1
    for ln in lines[1:]:
        (tw, _), _ = cv2.getTextSize(ln, font, font_scale, font_thickness)
        max_tw = max(max_tw, tw)
    if max_tw > box_width and box_width > 0:
        scale = font_scale * (box_width / max_tw)
        (tw1, th1), _ = cv2.getTextSize(line1, font, scale, font_thickness)

    line_gap = 4  # pixels between lines

    # Vertical centering based on actual number of lines
    total_text_h = th1 * len(lines) + line_gap * (len(lines) - 1)
    y_start = y1 + max((box_height - total_text_h) // 2, 2) + th1

    for i, ln in enumerate(lines):
        y_pos = y_start + i * (th1 + line_gap)
        cv2.putText(out, ln, (x1 + margin_x, y_pos),
                    font, scale, font_color, font_thickness, cv2.LINE_AA)

    return out


# ----------------------------
# Main grading entry point
# ----------------------------

def score_pdf(
    input_path: str,
    bublmap_path: str,
    out_csv: str,
    min_fill: float,
    fixed_thresh: Optional[int] = None,
    key_txt: Optional[str] = None,
    out_annotated_dir: Optional[str] = None,
    out_pdf: Optional[str] = None,
    dpi: int = RENDER_DEFAULTS.dpi,
    pdf_quality: int = RENDER_DEFAULTS.pdf_quality,
    annotate_all_cells: bool = False,
    label_density: bool = False,
    pdf_renderer: str = "auto",
    auto_calibrate_thresh: bool = True,
    verbose_calibration: bool = False,
    # Background calibration
    calibrate_background: bool = SCORING_DEFAULTS.calibrate_background,
    background_percentile: float = SCORING_DEFAULTS.background_percentile,
    # Adaptive rescoring
    adaptive_rescoring: bool = SCORING_DEFAULTS.adaptive_rescoring,
    adaptive_max_adjustment: int = SCORING_DEFAULTS.adaptive_max_adjustment,
    adaptive_min_above_floor: float = SCORING_DEFAULTS.adaptive_min_above_floor,
    # Roster matching (for orphan detection - adds ID:orphan flags)
    roster_csv: Optional[str] = None,
    # Per-student corrections from the Review panel (dict of student_id → dict)
    # When provided, corrected answers override the scanned values and the
    # affected bubbles are drawn as teal diamonds instead of normal circles.
    corrections: Optional[dict] = None,
) -> str:

    """
    Grade a PDF or image stack using axis-based geometry.

    Produces a simplified CSV for downstream processing by the GUI or report tools.

    Behavior:
      - Supports single-page or multi-page bubble sheets
      - For multi-page: processes pages in groups (page 1+2 = student 1, page 3+4 = student 2, etc.)
      - Name/ID taken from page 1, answers combined from all pages
      - Detects version from version_zone bubbles
      - Loads multi-version keys if key file contains #Version headers
      - Scores each student against their version's key
      - If key is provided: limit output columns and scoring to first len(key) questions.

    CSV Output Format:
      - Header: Page, Version, LastName, FirstName, StudentID, Correct, Incorrect, Blank, Multi, Percent, Flagged, FlagDetails, Q1, Q2, ...
      - KEY rows at top (one per version, Page=KEY)
      - Student rows with scores and answers
      - Flagged column: "Y" if student has any flagged issues, blank otherwise
      - FlagDetails column: pipe-separated flags like "Q5:blank|Q10:multi|ID:orphan"
      - Page column references the annotated PDF page numbers for easy lookup

    Annotated PDF:
      - Generates an annotated PDF with overlays on each page
      - Blue circles for name/ID fields
      - Green/red/grey/orange circles for correct/incorrect/blank/multi answers
      - Teal diamonds for corrected answers (when corrections are provided)
      - Page numbers in CSV correspond to pages in this PDF
    """
    bmap: Bubblemap = load_bublmap(bublmap_path)
    pages = IO.load_pages(input_path, dpi=dpi, renderer=pdf_renderer)

    # Try loading keys - check for advanced format first
    keys_dict: Optional[Dict[str, List[str]]] = None
    single_key: Optional[List[str]] = None
    advanced_key_set = None  # AnswerKeySet for advanced scoring
    use_advanced_scoring = False

    if key_txt:
        # Check if this is an advanced key format
        if is_advanced_key_format(key_txt):
            advanced_key_set = load_advanced_key(key_txt)
            if advanced_key_set:
                use_advanced_scoring = True
                # Also create legacy keys_dict for backward compatibility (annotations, stats)
                from .key_parser import to_legacy_keys_dict
                keys_dict = to_legacy_keys_dict(advanced_key_set)
                print(f"[info] Using advanced key format with {len(advanced_key_set.keys)} version(s)", file=sys.stderr)

        # Fall back to legacy loading if advanced didn't work
        if not use_advanced_scoring:
            try:
                keys_dict = load_multi_version_keys(key_txt)
            except Exception:
                # Fall back to single-version key
                single_key = load_key_txt(key_txt)
                if single_key:
                    keys_dict = {"A": single_key}  # Default to version A

    # Calculate total questions across all pages, and per-page question counts
    questions_per_page = []
    for page in bmap.pages:
        page_q = sum(layout.numrows for layout in page.answer_zones)
        questions_per_page.append(page_q)
    total_q = sum(questions_per_page)

    if advanced_key_set:
        # Use first version's question count
        first_key = next(iter(advanced_key_set.keys.values()))
        q_out = first_key.num_questions
    elif keys_dict:
        # Use length of first version key
        first_version = sorted(keys_dict.keys())[0]
        q_out = len(keys_dict[first_version])
    else:
        q_out = total_q

    q_out = max(0, min(q_out, total_q))

    # Calculate how many active questions are on each page (for calibration)
    # e.g. 57 questions on a 2-page template with 32+32 rows -> page 1 uses 32, page 2 uses 25
    active_rows_per_page = []
    remaining = q_out
    for page_q in questions_per_page:
        active = min(remaining, page_q)
        active_rows_per_page.append(active)
        remaining -= active

    # Make the CSV header
    # Format: Page, Version, LastName, FirstName, StudentID, Score, Correct, Incorrect, Blank, Multi, Percent, Flagged, FlagDetails, Q1, Q2, ...
    header = ["Page", "Version", "LastName", "FirstName", "StudentID"]

    if keys_dict:
        header += ["Score", "Correct", "Incorrect", "Blank", "Multi", "Percent"]
    else:
        header += ["Blank"]

    # Add Flagged and FlagDetails columns
    header += ["Flagged", "FlagDetails"]

    header += [f"Q{i+1}" for i in range(q_out)]

    _ensure_dir(os.path.dirname(out_csv) or ".")
    if out_annotated_dir:
        _ensure_dir(out_annotated_dir)


    # If requested, write an annotated PDF (default) and optionally a PNG directory.
    out_pdf_path: Optional[str] = None
    pdf_writer = None
    annotated_pages: List[np.ndarray] = []  # fallback only (used if streaming writer is unavailable)


    # out_pdf None means use the default name from defaults.py
    if out_pdf is None:
        out_pdf = SCORING_DEFAULTS.out_pdf

    # out_pdf "" (empty string) means disable PDF output
    if out_pdf:
        out_pdf_path = resolve_scored_pdf_path(out_pdf, out_csv=out_csv, out_pdf_dir=SCORING_DEFAULTS.out_pdf_dir)
        _ensure_dir(os.path.dirname(out_pdf_path) or ".")
        # Prefer a streaming PDF writer (small PDFs via JPEG embedding). Falls back to PIL at end if needed.
        try:
            pdf_writer = IO.PdfPageWriter(out_pdf_path, dpi=dpi)
        except Exception:
            pdf_writer = None
    
    # ==================== FLAGGING HELPERS ====================

    def _expects_multi(key_letters: Optional[List[str]], q_idx: int) -> bool:
        """Return True if the key for question *q_idx* expects multiple bubbles.

        AND (&), partial-lenient (@) and partial-strict (~) keys all require
        the student to fill more than one bubble, so a comma-containing answer
        is *expected* and should not be flagged.
        """
        if not key_letters or q_idx >= len(key_letters):
            return False
        k = key_letters[q_idx]
        return bool(k and any(op in k for op in ("&", "@", "~")))

    # Helper to check if a student has any flagged answers
    def _has_flags(answers: List[Optional[str]],
                   key_letters: Optional[List[str]] = None,
                   version_used: str = "") -> bool:
        if version_used.endswith("*"):
            return True
        for q_idx, a in enumerate(answers):
            if a is None or a == "":  # blank
                return True
            if isinstance(a, str) and "," in a:  # multi
                if not _expects_multi(key_letters, q_idx):
                    return True
        return False

    # Helper to build FlagDetails string for a student
    def _build_flag_details(answers: List[Optional[str]],
                            key_letters: Optional[List[str]] = None,
                            is_orphan: bool = False,
                            version_used: str = "") -> str:
        """
        Build a pipe-separated flag details string.
        Format: Version:blank|Q5:blank|Q10:multi|ID:orphan

        Multi-marks that are *expected* by the key (AND, partial) are not flagged.
        """
        flags = []
        if version_used.endswith("*"):
            inferred = version_used.rstrip("*")
            # Include the inferred version so teachers know which key was used.
            # Format: "Version:blank, inferred B" → rendered as "Version (blank, inferred B)"
            flags.append(f"Version:blank, inferred {inferred}" if inferred else "Version:blank")
        for q_idx, ans in enumerate(answers):
            if ans is None or ans == "":
                flags.append(f"Q{q_idx + 1}:blank")
            elif isinstance(ans, str) and "," in ans:
                if not _expects_multi(key_letters, q_idx):
                    flags.append(f"Q{q_idx + 1}:multi")

        if is_orphan:
            flags.append("ID:orphan")

        return "|".join(flags)
    # ==================================================================
    
    # ==================== DATA COLLECTION ============================
    # Collect student data for CSV output
    all_student_data: List[Dict] = []  # {answers, csv_row, student_id}
    # ==================================================================

    # ==================== ROSTER LOADING ==============================
    roster = None
    if roster_csv:
        try:
            roster = load_roster(roster_csv)
            print(f"[info] Loaded roster with {len(roster)} students", file=sys.stderr)
        except Exception as e:
            print(f"[warn] Failed to load roster: {e}", file=sys.stderr)
    # ==================================================================
    
    # Store header for later use when writing grouped output
    csv_header = header
            
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        # We no longer write header/keys here - they'll be written grouped by version at the end
        # Just process all students and collect their data

        # Determine if multi-page mode
        pages_per_student = bmap.num_pages
        is_multipage = pages_per_student > 1
        
        if is_multipage:
            # MULTI-PAGE MODE: Process pages in groups
            num_students = len(pages) // pages_per_student
            
            # Check for incomplete students (odd number of pages)
            if len(pages) % pages_per_student != 0:
                raise ValueError(
                    f"ERROR: Input PDF has {len(pages)} pages, but template expects {pages_per_student} pages per student. "
                    f"Expected a multiple of {pages_per_student} pages (got {len(pages) % pages_per_student} extra pages). "
                    f"Please check your scans - each student should have exactly {pages_per_student} pages."
                )
            
            for student_idx in range(num_students):
                # Get all pages for this student
                start_page_idx = student_idx * pages_per_student
                student_pages = pages[start_page_idx:start_page_idx + pages_per_student]
                
                # Process each page and collect data
                all_answers = []
                student_info = {}
                page_thresholds = []
                
                for page_num, img_bgr in enumerate(student_pages, start=1):
                    page_layout = bmap.get_page(page_num)
                    _page_label = f"student {student_idx + 1}/{num_students} pg {page_num}/{pages_per_student}"

                    # Per-page calibration
                    page_fixed_thresh = fixed_thresh
                    if fixed_thresh is None and auto_calibrate_thresh:
                        # Use page 1 layout for calibration reference
                        calib_page = bmap.get_page(1)
                        if calib_page:
                            # Create temp bmap-like object for calibration
                            temp_bmap = type('TempBmap', (object,), {
                                'answer_zones': calib_page.answer_zones,
                                'last_name_zone': calib_page.last_name_zone,
                                'first_name_zone': calib_page.first_name_zone,
                                'id_zone': calib_page.id_zone,
                            })()
                            # Only calibrate on active rows (skip unused questions)
                            calib_max_rows = active_rows_per_page[page_num - 1] if page_num <= len(active_rows_per_page) else None
                            page_fixed_thresh, _calib_stats = calibrate_fixed_thresh_for_page(
                                img_bgr,
                                temp_bmap,
                                max_rows=calib_max_rows,
                                verbose=verbose_calibration,
                                page_label=_page_label,
                            )
                    
                    page_thresholds.append(page_fixed_thresh)
                    
                    # Process this page
                    info, answers = _process_single_page(
                        img_bgr, page_layout,
                        min_fill=min_fill,
                        fixed_thresh=page_fixed_thresh,
                    )
                    
                    # Take student info from page 1
                    if page_num == 1:
                        student_info = info
                    
                    # Accumulate all answers
                    all_answers.extend(answers)
                
                # Limit answers to key length
                answers_out = all_answers[:q_out]
                answers_csv = [a if a is not None else "" for a in answers_out]

                # Apply corrections: override scanned answers with teacher-corrected values.
                # This must happen before scoring so corrected answers affect the grades.
                # We modify all_answers (not just answers_out) so the annotation path
                # also picks up corrected values when it slices per-page answers.
                if corrections:
                    sid = student_info.get("student_id", "")
                    student_corrections = corrections.get(sid, {})
                    # StudentID correction — update info so roster/output zone use the corrected ID
                    if "student_id" in student_corrections:
                        student_info["student_id"] = student_corrections["student_id"]
                    # Answer corrections — override individual question answers
                    for field_name, corrected_value in student_corrections.items():
                        if field_name.startswith("Q"):
                            try:
                                q_idx = int(field_name[1:]) - 1  # "Q5" → index 4
                                if 0 <= q_idx < len(all_answers):
                                    all_answers[q_idx] = corrected_value if corrected_value else None
                            except ValueError:
                                pass
                    # Rebuild answers_out and answers_csv from the corrected all_answers
                    answers_out = all_answers[:q_out]
                    answers_csv = [a if a is not None else "" for a in answers_out]

                # Get detected version
                student_version = student_info.get("version", "")

                # Metrics
                blanks = sum(1 for a in answers_out if (a is None or a == ""))
                multi = sum(1 for a in answers_out if (isinstance(a, str) and "," in a))
                score = correct = incorrect = 0
                percent = 0.0
                total_scored = q_out
                version_used = student_version
                key_out = None

                if use_advanced_scoring and advanced_key_set:
                    # Advanced scoring with partial credit, OR, AND, etc.
                    student_code = student_info.get("test_id", "")
                    points, max_pts, version_used, status_counts = score_with_advanced_key(
                        answers_out,
                        student_version,
                        advanced_key_set,
                        code=student_code,
                    )
                    score = points      # Points earned (can differ from correct count when questions have different point values)
                    correct = status_counts.get("correct", 0)  # Raw count of correctly answered questions
                    total_scored = max_pts
                    # Calculate incorrect from status counts
                    incorrect = status_counts.get("incorrect", 0)
                    blanks = status_counts.get("blank", 0)
                    multi = status_counts.get("multi", 0) + status_counts.get("spam", 0)
                    percent = (100.0 * points / max(1, max_pts))

                    # Get the key for annotation (use legacy format)
                    key_version = version_used.rstrip("*")
                    key_out = keys_dict.get(key_version, [])[:q_out] if keys_dict else None

                elif keys_dict:
                    # Legacy multi-version scoring (1 point per question, so score == correct)
                    correct, total_scored, version_used = score_against_multi_keys(
                        answers_out,
                        student_version,
                        keys_dict,
                    )
                    score = correct  # Legacy: 1 point per question

                    # Count incorrect
                    answered = sum(1 for a in answers_out if a is not None and a != "")
                    incorrect = answered - correct

                    percent = (100.0 * correct / max(1, total_scored))

                    # Get the key for annotation
                    key_version = version_used.rstrip("*")
                    key_out = keys_dict.get(key_version, [])[:q_out]

                # Compose CSV row
                # Format: Page, Version, LastName, FirstName, StudentID, Score, Correct, Incorrect, Blank, Multi, Percent, Flagged, FlagDetails, Q1...
                # Page shows the actual PDF page number(s) for lookup in the annotated PDF
                page_range = f"{start_page_idx + 1}-{start_page_idx + pages_per_student}" if pages_per_student > 1 else str(start_page_idx + 1)

                # Build flag details for this student
                has_flags = _has_flags(answers_out, key_out, version_used=version_used)
                flag_details = _build_flag_details(answers_out, key_out, version_used=version_used) if has_flags else ""

                row = [
                    page_range,
                    version_used,
                    student_info.get("last_name", ""),
                    student_info.get("first_name", ""),
                    student_info.get("student_id", ""),
                ]

                if keys_dict or use_advanced_scoring:
                    # Score = points earned, Correct = number of right answers
                    score_str = str(int(score)) if score == int(score) else f"{score:.1f}"
                    correct_str = str(int(correct)) if correct == int(correct) else f"{correct:.1f}"
                    percent_str = f"{percent:.1f}"
                    row += [score_str, correct_str, str(incorrect), str(blanks), str(multi), percent_str]
                else:
                    row += [str(blanks)]

                # Add Flagged and FlagDetails columns
                row += ["Y" if has_flags else "", flag_details]

                row += answers_csv

                # (Flagging is now built inline in flag_details column)

                # Store student data for CSV output
                all_student_data.append({
                    "answers": answers_out,
                    "csv_row": row,
                    "student_id": student_info.get("student_id", ""),
                    "student_name": f"{student_info.get('last_name', '')} {student_info.get('first_name', '')}".strip(),
                    "key_letters": key_out,
                    "version_used": version_used,
                })

                # Annotate all pages for this student
                if out_annotated_dir or out_pdf_path:
                    for page_num, img_bgr in enumerate(student_pages, start=1):
                        page_layout = bmap.get_page(page_num)
                        
                        if page_layout is None:
                            raise ValueError(f"Could not get layout for page {page_num}")
                        
                        # DEBUG: Verify we have the right page
                        num_answer_zones_this_page = len(page_layout.answer_zones)
                        if verbose_calibration:
                            print(f"  Annotating page {page_num} with {num_answer_zones_this_page} answer zone(s)")
                            if num_answer_zones_this_page > 0:
                                first_zone = page_layout.answer_zones[0]
                                print(f"    First zone coords: ({first_zone.x_topleft:.4f}, {first_zone.y_topleft:.4f}) to ({first_zone.x_bottomright:.4f}, {first_zone.y_bottomright:.4f})")
                                print(f"    First zone: {first_zone.numrows} rows × {first_zone.numcols} cols")
                        
                        page_fixed_thresh = page_thresholds[page_num - 1]
                        
                        # Get answers for this page only
                        # Calculate which answers belong to this page
                        answers_before_page = sum(
                            sum(layout.numrows for layout in bmap.get_page(p).answer_zones)
                            for p in range(1, page_num)
                        )
                        answers_in_page = sum(layout.numrows for layout in page_layout.answer_zones)
                        
                        # For annotation, we need the answers specific to THIS page
                        # Slice from all_answers to get just this page's answers
                        page_answers = all_answers[answers_before_page:answers_before_page + answers_in_page]
                        
                        # Limit to key length - only annotate answers that are within the key
                        # But we need to account for the offset
                        if q_out > answers_before_page:
                            # Some or all of this page's questions are within the key
                            page_answers_limit = min(answers_in_page, q_out - answers_before_page)
                            page_answers_out = page_answers[:page_answers_limit]
                        else:
                            # This entire page is beyond the key length
                            page_answers_out = []
                        
                        # Annotate with name/ID zones
                        # Create a proper Bubblemap-like object from PageLayout
                        temp_bmap_names = type('TempBmap', (object,), {
                            'last_name_zone': page_layout.last_name_zone,
                            'first_name_zone': page_layout.first_name_zone,
                            'id_zone': page_layout.id_zone,
                        })()
                        
                        vis = _annotate_names_ids(
                            img_bgr,
                            temp_bmap_names,
                            label_density=label_density,
                            annotation_defaults=ANNOTATION_DEFAULTS,
                        )
                        
                        # Annotate with answer zones
                        # Create a proper Bubblemap-like object from PageLayout
                        temp_bmap_answers = type('TempBmap', (object,), {
                            'answer_zones': page_layout.answer_zones,
                        })()
                        
                        # Build set of corrected question indices for this page
                        # so _annotate_answers can draw diamonds instead of circles.
                        page_corrected = set()
                        if corrections:
                            sid = student_info.get("student_id", "")
                            student_corrections = corrections.get(sid, {})
                            for field_name in student_corrections:
                                if field_name.startswith("Q"):
                                    try:
                                        q_num = int(field_name[1:])  # "Q5" → 5
                                        # Convert 1-based question number to 0-based
                                        # page-local index (subtract questions on prior pages)
                                        local_idx = (q_num - 1) - answers_before_page
                                        if 0 <= local_idx < answers_in_page:
                                            page_corrected.add(local_idx)
                                    except ValueError:
                                        pass

                        vis = _annotate_answers(
                            vis,
                            temp_bmap_answers,
                            key_out[answers_before_page:answers_before_page + answers_in_page] if key_out else None,
                            answers_for_annotation=page_answers_out,
                            label_density=label_density,
                            annotate_all_cells=annotate_all_cells,
                            min_fill=min_fill,
                            fixed_thresh=page_fixed_thresh,
                            calibrate_background=calibrate_background,
                            background_percentile=background_percentile,
                            annotation_defaults=ANNOTATION_DEFAULTS,
                            corrected_questions=page_corrected if page_corrected else None,
                        )

                        # Output zone: print student name, score, roster, and flags
                        # (only rendered on pages that define an output_zone)
                        if page_layout.output_zone is not None:
                            vis = _annotate_output_zone(
                                vis,
                                page_layout.output_zone,
                                student_info={
                                    "last_name": student_info.get("last_name", ""),
                                    "first_name": student_info.get("first_name", ""),
                                    "student_id": student_info.get("student_id", ""),
                                },
                                score_info={
                                    "score": score,
                                    "total": total_scored,
                                    "percent": percent,
                                    "version": version_used,
                                    "has_key": bool(keys_dict or use_advanced_scoring),
                                },
                                roster=roster,
                                flag_details=flag_details,
                                annotation_defaults=ANNOTATION_DEFAULTS,
                                corrections_applied=bool(corrections),
                            )

                        # Save annotated page
                        if out_annotated_dir:
                            actual_page_num = start_page_idx + page_num
                            out_png = os.path.join(out_annotated_dir, f"page_{actual_page_num:03d}_overlay.png")
                            cv2.imwrite(out_png, vis)
                        
                        if out_pdf_path:
                            if pdf_writer is not None:
                                pdf_writer.add_page(vis)
                            else:
                                annotated_pages.append(vis)
                        
        
        else:
            # SINGLE-PAGE MODE: Original logic (unchanged)
            for page_idx, img_bgr in enumerate(pages, start=1):
                # Per-page calibration for lightly marked sheets
                page_fixed_thresh = fixed_thresh
                _page_label = f"{page_idx}/{len(pages)}"
                if fixed_thresh is None and auto_calibrate_thresh:
                    page_fixed_thresh, _calib_stats = calibrate_fixed_thresh_for_page(
                        img_bgr,
                        bmap,
                        max_rows=q_out if q_out < total_q else None,
                        verbose=verbose_calibration,
                        page_label=_page_label,
                    )
                # Decode all fields using the shared axis-mode pipeline
                info, answers, backgrounds = process_page_all(
                    img_bgr, bmap,
                    min_fill=min_fill,
                    fixed_thresh=page_fixed_thresh,
                    calibrate_background=calibrate_background,
                    background_percentile=background_percentile,
                    adaptive_min_above_floor=adaptive_min_above_floor,
                    verbose_calibration=verbose_calibration,
                    page_label=_page_label,
                )

                # Try adaptive rescoring if enabled and there are blanks
                if adaptive_rescoring:
                    from .tools.score_tools import adaptive_rescore_page
                    answers, page_fixed_thresh, adapted = adaptive_rescore_page(
                        img_bgr, bmap,
                        initial_threshold=page_fixed_thresh,
                        initial_answers=answers,
                        min_fill=min_fill,
                        calibrate_background=calibrate_background,
                        background_percentile=background_percentile,
                        adaptive_min_above_floor=adaptive_min_above_floor,
                        adaptive_max_adjustment=adaptive_max_adjustment,
                        max_questions=q_out if q_out < total_q else None,
                        verbose=verbose_calibration,
                        page_label=_page_label,
                    )

                # Limit answers to the Qs we output (based on key length if present)
                answers_out = answers[:q_out]
                answers_csv = [a if a is not None else "" for a in answers_out]

                # Apply corrections: override scanned answers with teacher-corrected values.
                # This must happen before scoring so corrected answers affect the grades.
                if corrections:
                    sid = info.get("student_id", "")
                    student_corrections = corrections.get(sid, {})
                    # StudentID correction — update info so roster/output zone use the corrected ID
                    if "student_id" in student_corrections:
                        info["student_id"] = student_corrections["student_id"]
                    # Answer corrections — override individual question answers
                    for field_name, corrected_value in student_corrections.items():
                        if field_name.startswith("Q"):
                            try:
                                q_idx = int(field_name[1:]) - 1  # "Q5" → index 4
                                if 0 <= q_idx < len(answers_out):
                                    answers_out[q_idx] = corrected_value if corrected_value else None
                            except ValueError:
                                pass
                    # Rebuild answers_csv from the (possibly corrected) answers
                    answers_csv = [a if a is not None else "" for a in answers_out]

                # Get detected version
                student_version = info.get("version", "")

                # Metrics
                blanks = sum(1 for a in answers_out if (a is None or a == ""))
                multi = sum(1 for a in answers_out if (isinstance(a, str) and "," in a))
                score = correct = incorrect = 0
                percent = 0.0
                total_scored = q_out
                version_used = student_version
                key_out = None

                if use_advanced_scoring and advanced_key_set:
                    # Advanced scoring with partial credit, OR, AND, etc.
                    student_code = info.get("test_id", "")
                    points, max_pts, version_used, status_counts = score_with_advanced_key(
                        answers_out,
                        student_version,
                        advanced_key_set,
                        code=student_code,
                    )
                    score = points      # Points earned (can differ from correct count when questions have different point values)
                    correct = status_counts.get("correct", 0)  # Raw count of correctly answered questions
                    total_scored = max_pts
                    # Calculate incorrect from status counts
                    incorrect = status_counts.get("incorrect", 0)
                    blanks = status_counts.get("blank", 0)
                    multi = status_counts.get("multi", 0) + status_counts.get("spam", 0)
                    percent = (100.0 * points / max(1, max_pts))

                    # Get the key for annotation (use legacy format)
                    key_version = version_used.rstrip("*")
                    key_out = keys_dict.get(key_version, [])[:q_out] if keys_dict else None

                elif keys_dict:
                    # Legacy multi-version scoring (1 point per question, so score == correct)
                    correct, total_scored, version_used = score_against_multi_keys(
                        answers_out,
                        student_version,
                        keys_dict,
                    )
                    score = correct  # Legacy: 1 point per question

                    # Count incorrect (total scored - blanks - multi - correct)
                    answered = sum(1 for a in answers_out if a is not None and a != "")
                    incorrect = answered - correct

                    percent = (100.0 * correct / max(1, total_scored))

                    # Get the key for annotation
                    key_version = version_used.rstrip("*")
                    key_out = keys_dict.get(key_version, [])[:q_out]

                # Compose CSV row
                # Format: Page, Version, LastName, FirstName, StudentID, Score, Correct, Incorrect, Blank, Multi, Percent, Flagged, FlagDetails, Q1...

                # Build flag details for this student
                has_flags = _has_flags(answers_out, key_out, version_used=version_used)
                flag_details = _build_flag_details(answers_out, key_out, version_used=version_used) if has_flags else ""

                row = [
                    str(page_idx),  # Page number for lookup in annotated PDF
                    version_used,
                    info.get("last_name", ""),
                    info.get("first_name", ""),
                    info.get("student_id", ""),
                ]

                if keys_dict or use_advanced_scoring:
                    # Score = points earned, Correct = number of right answers
                    score_str = str(int(score)) if score == int(score) else f"{score:.1f}"
                    correct_str = str(int(correct)) if correct == int(correct) else f"{correct:.1f}"
                    percent_str = f"{percent:.1f}"
                    row += [score_str, correct_str, str(incorrect), str(blanks), str(multi), percent_str]
                else:
                    row += [str(blanks)]

                # Add Flagged and FlagDetails columns
                row += ["Y" if has_flags else "", flag_details]

                row += answers_csv

                # (Flagging is now built inline in flag_details column)

                # Store student data for CSV output
                all_student_data.append({
                    "answers": answers_out,
                    "csv_row": row,
                    "student_id": info.get("student_id", ""),
                    "student_name": f"{info.get('last_name', '')} {info.get('first_name', '')}".strip(),
                    "key_letters": key_out,
                    "version_used": version_used,
                })

                # Annotated image: names/IDs in blue (with optional %), then answers overlay
                if out_annotated_dir or out_pdf_path:
                    vis = _annotate_names_ids(
                        img_bgr,
                        bmap,
                        label_density=label_density,
                        annotation_defaults=ANNOTATION_DEFAULTS,
                    )

                    # Build set of corrected question indices (0-based) for
                    # this student so diamonds are drawn for overridden answers.
                    student_corrected = set()
                    if corrections:
                        sid = info.get("student_id", "")
                        student_corrections = corrections.get(sid, {})
                        for field_name in student_corrections:
                            if field_name.startswith("Q"):
                                try:
                                    q_num = int(field_name[1:])  # "Q5" → 5
                                    student_corrected.add(q_num - 1)  # 0-indexed
                                except ValueError:
                                    pass

                    vis = _annotate_answers(
                        vis,
                        bmap,
                        key_out,
                        answers_for_annotation=answers_out,  # Only annotate questions in the key
                        label_density=label_density,
                        annotate_all_cells=annotate_all_cells,
                        min_fill=min_fill,
                        fixed_thresh=page_fixed_thresh,
                        calibrate_background=calibrate_background,
                        background_percentile=background_percentile,
                        annotation_defaults=ANNOTATION_DEFAULTS,
                        corrected_questions=student_corrected if student_corrected else None,
                    )

                    # Output zone: print student name, score, roster, and flags
                    page1_layout = bmap.pages[0] if bmap.pages else None
                    if page1_layout and page1_layout.output_zone is not None:
                        vis = _annotate_output_zone(
                            vis,
                            page1_layout.output_zone,
                            student_info={
                                "last_name": info.get("last_name", ""),
                                "first_name": info.get("first_name", ""),
                                "student_id": info.get("student_id", ""),
                            },
                            score_info={
                                "score": score,
                                "total": total_scored,
                                "percent": percent,
                                "version": version_used,
                                "has_key": bool(keys_dict or use_advanced_scoring),
                            },
                            roster=roster,
                            flag_details=flag_details,
                            annotation_defaults=ANNOTATION_DEFAULTS,
                            corrections_applied=bool(corrections),
                        )

                    if out_annotated_dir:
                        out_png = os.path.join(out_annotated_dir, f"page_{page_idx:03d}_overlay.png")
                        cv2.imwrite(out_png, vis)
                    if out_pdf_path:
                        if pdf_writer is not None:
                            pdf_writer.add_page(vis)
                        else:
                            annotated_pages.append(vis)

    if out_pdf_path:
        if pdf_writer is not None:
            pdf_writer.close(save=True)
        elif annotated_pages:
            IO.save_images_as_pdf(annotated_pages, out_pdf_path, dpi=dpi, quality=pdf_quality)

    # ==================== ROSTER MATCHING (for orphan detection) ====================
    # If roster provided, find orphan scans and mark them in FlagDetails
    orphan_ids = set()
    if roster:
        matched, orphans, absent_ids = match_roster(all_student_data, roster)

        # Log roster matching results
        print(f"[info] Roster matching: {len(matched)} matched, {len(orphans)} orphan scans, {len(absent_ids)} absent students", file=sys.stderr)

        if orphans:
            print(f"[warn] Orphan scans (ID not in roster):", file=sys.stderr)
            for o in orphans[:5]:  # Show first 5
                print(f"       - {o.get('student_id', '?')} ({o.get('student_name', 'unknown')})", file=sys.stderr)
            if len(orphans) > 5:
                print(f"       ... and {len(orphans) - 5} more", file=sys.stderr)

            # Track orphan IDs so we can add ID:orphan to their FlagDetails
            orphan_ids = {o.get('student_id', '') for o in orphans}

        if absent_ids:
            print(f"[info] Absent students (on roster, no scan):", file=sys.stderr)
            for sid in absent_ids[:5]:  # Show first 5
                info = roster[sid]
                print(f"       - {sid} ({info.get('full_name', 'unknown')})", file=sys.stderr)
            if len(absent_ids) > 5:
                print(f"       ... and {len(absent_ids) - 5} more", file=sys.stderr)
    # =================================================================

    # ==================== WRITE SIMPLIFIED CSV ====================
    # Format:
    # - Header row
    # - KEY row(s) for each version
    # - Student rows (all students, with Flagged/FlagDetails columns)
    # - No stats, no version grouping headers

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        # Write header
        writer.writerow(csv_header)

        # Write KEY row(s) and VALUE row(s) - one pair per version
        if keys_dict:
            for ver in sorted(keys_dict.keys()):
                key_answers = keys_dict[ver][:q_out]
                # KEY row format: Page=KEY, Version, LastName=KEY, FirstName=KEY, StudentID=KEY, ...
                key_row = ["KEY", ver, "KEY", "KEY", "KEY"]
                if keys_dict:
                    key_row += ["", "", "", "", "", ""]  # Score, Correct, Incorrect, Blank, Multi, Percent (empty for KEY)
                else:
                    key_row += [""]  # Just Blank column
                key_row += ["", ""]  # Flagged, FlagDetails (empty for KEY)
                key_row += key_answers
                writer.writerow(key_row)

                # VALUE row: max points per question
                value_row = ["VALUE", ver, "VALUE", "VALUE", "VALUE"]
                if keys_dict:
                    value_row += ["", "", "", "", "", ""]
                else:
                    value_row += [""]
                value_row += ["", ""]  # Flagged, FlagDetails (empty for VALUE)
                # Get per-question point values from advanced key, default 1
                if advanced_key_set and ver in advanced_key_set.keys:
                    vk = advanced_key_set.keys[ver]
                    pts = []
                    for qi in range(q_out):
                        if qi < len(vk.answers):
                            pts.append(vk.answers[qi].total_points)
                        else:
                            pts.append(vk.default_points)
                    value_row += [p if p != int(p) else int(p) for p in pts]
                else:
                    value_row += [1] * q_out
                writer.writerow(value_row)

        # Write student rows
        for student_data in all_student_data:
            row = student_data["csv_row"]

            # Check if this student is an orphan (not in roster) - add to FlagDetails
            student_id = student_data.get("student_id", "")
            if student_id in orphan_ids:
                # Find the FlagDetails column and append ID:orphan
                # Row format: Page, Version, LastName, FirstName, StudentID, [Score, Correct, Incorrect, Blank, Multi, Percent OR just Blank], Flagged, FlagDetails, Q1...
                flagged_col_idx = 5 + (6 if keys_dict else 1)  # Index of Flagged column
                flag_details_idx = flagged_col_idx + 1

                # Update Flagged to Y
                row[flagged_col_idx] = "Y"

                # Append ID:orphan to FlagDetails
                if row[flag_details_idx]:
                    row[flag_details_idx] += "|ID:orphan"
                else:
                    row[flag_details_idx] = "ID:orphan"

            writer.writerow(row)

    # Print summary
    n_students = len(all_student_data)
    n_flagged = sum(1 for d in all_student_data if _has_flags(d.get("answers", []), d.get("key_letters"), version_used=d.get("version_used", "")))
    print(f"[info] Wrote {n_students} students to {out_csv} ({n_flagged} with flags)", file=sys.stderr)
    # =================================================================

    # ==================== SAVE SCORING PARAMETERS ====================
    # Write a small JSON file alongside the CSV so the report generator
    # can record which parameters produced these results.
    import json as _json
    params_path = os.path.splitext(out_csv)[0] + "_params.json"
    _meta = bmap.metadata or {}
    scoring_params = {
        "input_path": str(input_path),
        "key_txt": str(key_txt) if key_txt else None,
        "roster_csv": str(roster_csv) if roster_csv else None,
        "template": {
            "name": _meta.get("display_name", os.path.basename(os.path.dirname(bublmap_path))),
            "description": _meta.get("description", ""),
            "bubblemap_path": str(bublmap_path),
            "pages": bmap.num_pages,
            "total_questions": bmap.total_questions,
        },
        "min_fill": round(min_fill * 100, 1),       # back to 0-100 for display
        "fixed_thresh": fixed_thresh if fixed_thresh is not None else "auto",
        "auto_calibrate_thresh": auto_calibrate_thresh,
        "calibrate_background": calibrate_background,
        "background_percentile": background_percentile,
        "adaptive_rescoring": adaptive_rescoring,
        "adaptive_max_adjustment": adaptive_max_adjustment,
        "adaptive_min_above_floor": adaptive_min_above_floor,
        "dpi": dpi,
    }
    try:
        with open(params_path, "w", encoding="utf-8") as pf:
            _json.dump(scoring_params, pf, indent=2)
    except Exception:
        pass  # non-critical
    # =================================================================

    return out_csv
