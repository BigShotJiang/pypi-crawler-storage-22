"""Dashboard API package."""

from marlo.api.dashboard.app import app

__all__ = ["app"]
