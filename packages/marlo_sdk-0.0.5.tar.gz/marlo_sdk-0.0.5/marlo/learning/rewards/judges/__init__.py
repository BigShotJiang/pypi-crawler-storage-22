"""Reward judges."""

from __future__ import annotations

