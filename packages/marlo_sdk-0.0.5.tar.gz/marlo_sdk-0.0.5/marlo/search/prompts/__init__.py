"""Prompts for deep search agents."""
