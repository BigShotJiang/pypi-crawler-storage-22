"""Simulation environments for controlled trajectory generation."""

from __future__ import annotations

