"""Replay and training-data access helpers for stored trajectories."""

from __future__ import annotations

