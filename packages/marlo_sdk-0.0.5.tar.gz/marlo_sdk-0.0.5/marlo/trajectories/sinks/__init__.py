"""Pluggable sinks/streamers for captured trajectory events."""

from __future__ import annotations

