# Marock
	Marock allows you to colour your texts
	Simple to use: just type marock.col("textYouWantsToColour", "colourYouWantsLowercased", bold=True/False, bg="colourYouWantTheBackgroundToBeLowercased"/None)
	Colours you can chooose from:
		"black": cool and shocking. 
		"red": elegant and energetic. 
		"green": natural and fresh. 
		"yellow": bright and popular. 
		"blue": melancholy and maturely.
		"magenta": exiting and passionate. 
		"cyan": peaceful and relaxing. 
		"white": classic and purely.
	After installing, use marock.help() for more info.  
