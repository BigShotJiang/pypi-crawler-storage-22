
class MarsBaseModelTuner():
    pass