"""algo-cli - CLI tool for managing hosting platform algorithm services."""

__version__ = "0.1.0"
