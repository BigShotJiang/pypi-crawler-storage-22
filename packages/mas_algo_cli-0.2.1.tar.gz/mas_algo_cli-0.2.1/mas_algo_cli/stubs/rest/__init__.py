"""Stub package for rest module (provided by hosting platform at runtime)."""
