"""Stub for rest.process_base module (provided by hosting platform at runtime)."""


class ProcessBase:
    def __init__(self, url: str = ""):
        self.url = url
