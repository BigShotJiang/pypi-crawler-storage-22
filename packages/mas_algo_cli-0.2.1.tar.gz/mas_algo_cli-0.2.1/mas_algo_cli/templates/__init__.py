"""algo-cli templates."""
