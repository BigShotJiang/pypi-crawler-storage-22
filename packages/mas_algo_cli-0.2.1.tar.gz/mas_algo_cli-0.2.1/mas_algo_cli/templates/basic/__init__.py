"""${name} algorithm service."""
