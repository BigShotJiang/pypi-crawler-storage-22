"""Example utility module for ${name}."""


def example_function(value: str) -> str:
    """Example utility function."""
    return f"Processed: {value}"
