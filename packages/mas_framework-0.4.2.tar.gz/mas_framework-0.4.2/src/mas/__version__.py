"""Package version for mas-framework."""

__version__ = "0.4.2"
