"""Core primitives."""

