from masfactory.adapters.context.types import ContextBlock, ContextQuery
from masfactory.components.agents.agent import Agent


class _DummyProvider:
    context_label = "MEM"

    def get_blocks(self, query: ContextQuery, *, top_k: int = 8) -> list[ContextBlock]:
        return [ContextBlock(text="memory snippet", score=0.9)]

    def insert(self, key: str, value: str):
        # Not used in this test.
        return None

    def reset(self):
        return None


def test_agent_observe_injects_context_into_user_prompt():
    agent = Agent(
        name="a",
        instructions="do",
        model=object(),
        memories=[_DummyProvider()],
    )

    _, user_prompt, _ = agent.observe({"input": "hello"})

    assert "CONTEXT:" in user_prompt
    assert "[Context]" in user_prompt
    assert "(MEM) memory snippet" in user_prompt

