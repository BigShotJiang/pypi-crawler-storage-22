from masfactory.adapters.context.renderer import DefaultContextRenderer
from masfactory.adapters.context.types import ContextBlock


def test_default_renderer_injects_context_field():
    renderer = DefaultContextRenderer()
    user_payload = {"MESSAGE TO YOU": {"input": "hello"}}

    provider_blocks = [
        ("MEM", [ContextBlock(text="m1"), ContextBlock(text="m2")]),
        ("RET", [ContextBlock(text="r1")]),
    ]

    injected = renderer.inject(user_payload, provider_blocks)

    assert injected is not user_payload
    assert "CONTEXT" in injected
    assert injected["CONTEXT"].startswith("[Context]")
    assert "(MEM) m1" in injected["CONTEXT"]
    assert "(RET) r1" in injected["CONTEXT"]


def test_default_renderer_noop_when_empty():
    renderer = DefaultContextRenderer()
    user_payload = {"MESSAGE TO YOU": "hello"}
    injected = renderer.inject(user_payload, [])
    assert injected == user_payload

