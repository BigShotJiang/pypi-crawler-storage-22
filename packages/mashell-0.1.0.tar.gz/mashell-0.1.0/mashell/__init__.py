"""MaShell - AI-powered command line assistant."""

__version__ = "0.1.0"
