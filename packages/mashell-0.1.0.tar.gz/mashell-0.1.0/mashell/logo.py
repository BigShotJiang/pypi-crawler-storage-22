"""ASCII art logo display."""

from rich.console import Console
from rich.text import Text

LOGO = r"""
███╗   ███╗ █████╗ ███████╗██╗  ██╗███████╗██╗     ██╗
████╗ ████║██╔══██╗██╔════╝██║  ██║██╔════╝██║     ██║
██╔████╔██║███████║███████╗███████║█████╗  ██║     ██║
██║╚██╔╝██║██╔══██║╚════██║██╔══██║██╔══╝  ██║     ██║
██║ ╚═╝ ██║██║  ██║███████║██║  ██║███████╗███████╗███████╗
╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝
"""

TAGLINE = "🐚 Your AI-Powered Command Line Assistant"


def display_logo(console: Console | None = None) -> None:
    """Display the MaShell logo."""
    if console is None:
        console = Console()

    console.print()
    logo_text = Text(LOGO, style="bold cyan")
    console.print(logo_text)
    console.print(f"  {TAGLINE}", style="dim")
    console.print()
