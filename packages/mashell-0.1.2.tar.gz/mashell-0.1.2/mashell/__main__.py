"""Entry point for python -m mashell."""

from mashell.cli import main

if __name__ == "__main__":
    main()
