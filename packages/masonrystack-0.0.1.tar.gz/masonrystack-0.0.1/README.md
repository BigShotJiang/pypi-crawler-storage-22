# MasonryStack

⚠️ **Placeholder package**

This package currently exists to reserve the PyPI name.
APIs are not yet stable and functionality will be added in the future.

Do not rely on this package yet.
