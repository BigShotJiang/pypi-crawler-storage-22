from PyQt5.QtWidgets import QPushButton, QToolTip
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon
from pathlib import Path


class HelpButton(QPushButton):
    def __init__(self, tooltip_text, icon_size=40, parent=None):
        super().__init__(parent)
        
        self.tooltip_text = tooltip_text
        
        gui_path = Path(__file__).resolve().parent.parent
        icon_path = f"{gui_path}/assets/icons/help-circle.svg"
        
        if Path(icon_path).exists():
            self.setIcon(QIcon(icon_path))
        else:
            self.setText("?")
        
        self.setIconSize(QSize(icon_size, icon_size))
        self.setFixedSize(icon_size + 16, icon_size + 16)
        self.setFlat(True)
        self.setCursor(Qt.WhatsThisCursor)
        self.setToolTip(tooltip_text)
        
        self.setStyleSheet("""
            QPushButton {
                border: none;
                background: transparent;
                padding: 0px;
            }
            QPushButton:hover {
                background: rgba(59, 130, 246, 0.1);
                border-radius: 6px;
            }
        """)
        
        self.clicked.connect(self._show_tooltip)
    
    def _show_tooltip(self):
        QToolTip.showText(
            self.mapToGlobal(self.rect().bottomLeft()), 
            self.tooltip_text, 
            self
        )
    
    def enterEvent(self, event):
        QToolTip.showText(
            self.mapToGlobal(self.rect().bottomLeft()), 
            self.tooltip_text, 
            self
        )
        super().enterEvent(event)
    
    def set_tooltip_text(self, text):
        self.tooltip_text = text
        self.setToolTip(text)