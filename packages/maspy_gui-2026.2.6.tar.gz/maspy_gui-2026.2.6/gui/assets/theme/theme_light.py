theme_colors = {
    "background_primary":"#F4F4F8",

    "background_secondary": "#ECEBF0",
    
    "background_tertiary": "#959598",

    "interactive_primary": "#3B82F6",
    "interactive_hover": "#60A5FA",
    "interactive_pressed": "#2563EB",
    "interactive_text": "#FFFFFF",

    # Texto Principal (Preto quase absoluto)
    "text_primary": "#000000",

    "text_secondary": "#000000",
    
    "text_disabled": "#9CA3AF",

    "success": "#059669",
    "warning": "#D97706",
    "warning_hover": "#F59E0B",
    "danger": "#DC2626",
    "info": "#0284C7",
}