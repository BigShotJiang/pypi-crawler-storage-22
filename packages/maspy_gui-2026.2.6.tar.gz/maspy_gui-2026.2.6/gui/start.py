import threading
import sys
import time
from queue import Empty
import multiprocessing

from maspy import Admin

from gui.app.main_process import InterfaceProcess

def run_mas_simulation():
    time.sleep(1) #delay necessario para dar tempo da interface iniciar
    Admin().start_system()

def start_interface():
    interface_process = InterfaceProcess()
    interface_process.start()

    simulation_thread = threading.Thread(target=run_mas_simulation, daemon=True)
    simulation_thread.start()

    while interface_process.process.is_alive(): #tem que ver com o alexandre se é possível voltar com o play, mas dai tem que repensar a questão do timer
        try:
            command_data = interface_process.command_queue.get(timeout=0.1)

            command = command_data[0] if isinstance(command_data, tuple) else command_data

            if command == 'TOGGLE_PAUSE':
                print("Comando recebido: PAUSAR/RETOMAR SIMULAÇÃO")
                Admin().pause_system()

        except Empty:
            continue
            
        except (KeyboardInterrupt, SystemExit):
            print("Interrupção recebida. Encerrando")
            break
        
        except Exception as e:
            print(f"Erro inesperado no loop principal: {e}")

    interface_process.process.join()

if __name__ == '__main__':
    multiprocessing.freeze_support() #coloquei a muito tempo atras, não sei se vai ser necessário, mas deixei ai
    start_interface()