from PyQt5.QtWidgets import QFrame, QVBoxLayout, QPushButton, QButtonGroup, QLabel
from PyQt5.QtCore import Qt

class SideBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.setProperty("class", "sidebar")

        self.setFixedWidth(180)
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)
        layout.setAlignment(Qt.AlignTop)

        self.button_group = QButtonGroup(self)
        self.button_group.setExclusive(True)

        self.buttons = {}
        button_names = ["Menu", "Agents", "Environment", "Messages", "Learning"]

        for text in button_names:
            btn = QPushButton(text)
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setProperty("class", "sidebar-button")
            
            self.buttons[text] = btn
            layout.addWidget(btn)
            self.button_group.addButton(btn)

        version = QLabel("ver.2026.02.06")
        version.setAlignment(Qt.AlignRight)
        version.setProperty("class", "text-secondary")
        layout.addStretch(1)
        layout.addWidget(version)

        self.setLayout(layout)

        