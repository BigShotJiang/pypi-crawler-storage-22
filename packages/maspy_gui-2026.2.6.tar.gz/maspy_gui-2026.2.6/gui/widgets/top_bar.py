from PyQt5.QtWidgets import QWidget, QLabel, QHBoxLayout, QPushButton
from PyQt5.QtCore import Qt, pyqtSignal, QSize
from PyQt5.QtGui import QFont, QIcon
from pathlib import Path

class TopBar(QWidget):
    settings_button_clicked = pyqtSignal()
    manual_button_clicked = pyqtSignal()

    def __init__(self, title="Menu"):
        super().__init__()
        self.setFixedHeight(60)
        self.setProperty("class", "topbar")

        self.title_label = QLabel(title)
        self.title_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.title_label.setProperty("class", "topbar-title")
        self.title_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        self.gui_path = Path(__file__).resolve().parent.parent

        self.manual_button = QPushButton()
        self.manual_button.setIcon(QIcon(f"{self.gui_path}/assets/icons/book-open.svg"))
        self.manual_button.setIconSize(QSize(24, 24))
        self.manual_button.setFlat(True)
        self.manual_button.setCursor(Qt.PointingHandCursor)
        self.manual_button.setObjectName("ManualButton")
        self.manual_button.setToolTip("User Manual")
        self.manual_button.clicked.connect(self.manual_button_clicked)

        self.settings_button = QPushButton()
        self.settings_button.setIcon(QIcon(f"{self.gui_path}/assets/icons/settings.svg"))
        self.settings_button.setIconSize(QSize(24, 24))
        self.settings_button.setFlat(True)
        self.settings_button.setCursor(Qt.PointingHandCursor)
        self.settings_button.setObjectName("SettingsButton")
        self.settings_button.setToolTip("Settings")
        self.settings_button.clicked.connect(self.settings_button_clicked)

        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(20, 0, 20, 0)
        
        main_layout.addWidget(self.title_label)
        main_layout.addStretch()
        main_layout.addWidget(self.manual_button)
        main_layout.addWidget(self.settings_button)
        
        self.setLayout(main_layout)

    def set_title(self, title):
        self.title_label.setText(title)