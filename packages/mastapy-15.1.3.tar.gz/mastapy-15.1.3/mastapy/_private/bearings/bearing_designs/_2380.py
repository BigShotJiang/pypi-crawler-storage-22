"""DetailedBearing"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from mastapy._private._internal.dataclasses import extended_dataclass
from mastapy._private._internal.exceptions import CastException
from mastapy._private._internal.python_net import python_net_import

from mastapy._private._internal import utility
from mastapy._private.bearings.bearing_designs import _2383

_DETAILED_BEARING = python_net_import(
    "SMT.MastaAPI.Bearings.BearingDesigns", "DetailedBearing"
)

if TYPE_CHECKING:
    from typing import Any, Type, TypeVar

    from mastapy._private.bearings.bearing_designs import _2379
    from mastapy._private.bearings.bearing_designs.fluid_film import (
        _2437,
        _2439,
        _2441,
        _2443,
        _2444,
        _2445,
    )
    from mastapy._private.bearings.bearing_designs.rolling import (
        _2384,
        _2385,
        _2386,
        _2387,
        _2388,
        _2389,
        _2391,
        _2397,
        _2398,
        _2399,
        _2403,
        _2408,
        _2409,
        _2410,
        _2411,
        _2414,
        _2416,
        _2419,
        _2420,
        _2421,
        _2422,
        _2423,
        _2424,
    )

    Self = TypeVar("Self", bound="DetailedBearing")
    CastSelf = TypeVar("CastSelf", bound="DetailedBearing._Cast_DetailedBearing")


__docformat__ = "restructuredtext en"
__all__ = ("DetailedBearing",)


@extended_dataclass(frozen=True, slots=True, weakref_slot=True)
class _Cast_DetailedBearing:
    """Special nested class for casting DetailedBearing to subclasses."""

    __parent__: "DetailedBearing"

    @property
    def non_linear_bearing(self: "CastSelf") -> "_2383.NonLinearBearing":
        return self.__parent__._cast(_2383.NonLinearBearing)

    @property
    def bearing_design(self: "CastSelf") -> "_2379.BearingDesign":
        from mastapy._private.bearings.bearing_designs import _2379

        return self.__parent__._cast(_2379.BearingDesign)

    @property
    def angular_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2384.AngularContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2384

        return self.__parent__._cast(_2384.AngularContactBallBearing)

    @property
    def angular_contact_thrust_ball_bearing(
        self: "CastSelf",
    ) -> "_2385.AngularContactThrustBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2385

        return self.__parent__._cast(_2385.AngularContactThrustBallBearing)

    @property
    def asymmetric_spherical_roller_bearing(
        self: "CastSelf",
    ) -> "_2386.AsymmetricSphericalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2386

        return self.__parent__._cast(_2386.AsymmetricSphericalRollerBearing)

    @property
    def axial_thrust_cylindrical_roller_bearing(
        self: "CastSelf",
    ) -> "_2387.AxialThrustCylindricalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2387

        return self.__parent__._cast(_2387.AxialThrustCylindricalRollerBearing)

    @property
    def axial_thrust_needle_roller_bearing(
        self: "CastSelf",
    ) -> "_2388.AxialThrustNeedleRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2388

        return self.__parent__._cast(_2388.AxialThrustNeedleRollerBearing)

    @property
    def ball_bearing(self: "CastSelf") -> "_2389.BallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2389

        return self.__parent__._cast(_2389.BallBearing)

    @property
    def barrel_roller_bearing(self: "CastSelf") -> "_2391.BarrelRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2391

        return self.__parent__._cast(_2391.BarrelRollerBearing)

    @property
    def crossed_roller_bearing(self: "CastSelf") -> "_2397.CrossedRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2397

        return self.__parent__._cast(_2397.CrossedRollerBearing)

    @property
    def cylindrical_roller_bearing(
        self: "CastSelf",
    ) -> "_2398.CylindricalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2398

        return self.__parent__._cast(_2398.CylindricalRollerBearing)

    @property
    def deep_groove_ball_bearing(self: "CastSelf") -> "_2399.DeepGrooveBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2399

        return self.__parent__._cast(_2399.DeepGrooveBallBearing)

    @property
    def four_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2403.FourPointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2403

        return self.__parent__._cast(_2403.FourPointContactBallBearing)

    @property
    def multi_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2408.MultiPointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2408

        return self.__parent__._cast(_2408.MultiPointContactBallBearing)

    @property
    def needle_roller_bearing(self: "CastSelf") -> "_2409.NeedleRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2409

        return self.__parent__._cast(_2409.NeedleRollerBearing)

    @property
    def non_barrel_roller_bearing(self: "CastSelf") -> "_2410.NonBarrelRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2410

        return self.__parent__._cast(_2410.NonBarrelRollerBearing)

    @property
    def roller_bearing(self: "CastSelf") -> "_2411.RollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2411

        return self.__parent__._cast(_2411.RollerBearing)

    @property
    def rolling_bearing(self: "CastSelf") -> "_2414.RollingBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2414

        return self.__parent__._cast(_2414.RollingBearing)

    @property
    def self_aligning_ball_bearing(self: "CastSelf") -> "_2416.SelfAligningBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2416

        return self.__parent__._cast(_2416.SelfAligningBallBearing)

    @property
    def spherical_roller_bearing(self: "CastSelf") -> "_2419.SphericalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2419

        return self.__parent__._cast(_2419.SphericalRollerBearing)

    @property
    def spherical_roller_thrust_bearing(
        self: "CastSelf",
    ) -> "_2420.SphericalRollerThrustBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2420

        return self.__parent__._cast(_2420.SphericalRollerThrustBearing)

    @property
    def taper_roller_bearing(self: "CastSelf") -> "_2421.TaperRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2421

        return self.__parent__._cast(_2421.TaperRollerBearing)

    @property
    def three_point_contact_ball_bearing(
        self: "CastSelf",
    ) -> "_2422.ThreePointContactBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2422

        return self.__parent__._cast(_2422.ThreePointContactBallBearing)

    @property
    def thrust_ball_bearing(self: "CastSelf") -> "_2423.ThrustBallBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2423

        return self.__parent__._cast(_2423.ThrustBallBearing)

    @property
    def toroidal_roller_bearing(self: "CastSelf") -> "_2424.ToroidalRollerBearing":
        from mastapy._private.bearings.bearing_designs.rolling import _2424

        return self.__parent__._cast(_2424.ToroidalRollerBearing)

    @property
    def pad_fluid_film_bearing(self: "CastSelf") -> "_2437.PadFluidFilmBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2437

        return self.__parent__._cast(_2437.PadFluidFilmBearing)

    @property
    def plain_grease_filled_journal_bearing(
        self: "CastSelf",
    ) -> "_2439.PlainGreaseFilledJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2439

        return self.__parent__._cast(_2439.PlainGreaseFilledJournalBearing)

    @property
    def plain_journal_bearing(self: "CastSelf") -> "_2441.PlainJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2441

        return self.__parent__._cast(_2441.PlainJournalBearing)

    @property
    def plain_oil_fed_journal_bearing(
        self: "CastSelf",
    ) -> "_2443.PlainOilFedJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2443

        return self.__parent__._cast(_2443.PlainOilFedJournalBearing)

    @property
    def tilting_pad_journal_bearing(
        self: "CastSelf",
    ) -> "_2444.TiltingPadJournalBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2444

        return self.__parent__._cast(_2444.TiltingPadJournalBearing)

    @property
    def tilting_pad_thrust_bearing(self: "CastSelf") -> "_2445.TiltingPadThrustBearing":
        from mastapy._private.bearings.bearing_designs.fluid_film import _2445

        return self.__parent__._cast(_2445.TiltingPadThrustBearing)

    @property
    def detailed_bearing(self: "CastSelf") -> "DetailedBearing":
        return self.__parent__

    def __getattr__(self: "CastSelf", name: str) -> "Any":
        try:
            return self.__getattribute__(name)
        except AttributeError:
            class_name = utility.camel(name)
            raise CastException(
                f'Detected an invalid cast. Cannot cast to type "{class_name}"'
            ) from None


@extended_dataclass(frozen=True, slots=True, weakref_slot=True, eq=False)
class DetailedBearing(_2383.NonLinearBearing):
    """DetailedBearing

    This is a mastapy class.
    """

    TYPE: ClassVar["Type"] = _DETAILED_BEARING

    wrapped: "Any"

    def __post_init__(self: "Self") -> None:
        """Override of the post initialisation magic method."""
        if not hasattr(self.wrapped, "reference_count"):
            self.wrapped.reference_count = 0

        self.wrapped.reference_count += 1

    @property
    def cast_to(self: "Self") -> "_Cast_DetailedBearing":
        """Cast to another type.

        Returns:
            _Cast_DetailedBearing
        """
        return _Cast_DetailedBearing(self)
