"""
MasDatabase module for MasWorks library.

Provides MasWorks-specific database functionality including session management
and ORM models for time series data. This module contains domain-specific
database operations, while generic database utilities are in utils/.
"""

from ..utils.database_connection import DatabaseManager
from .models import TimeSeriesData, TimeSeriesMeta, TimeSeriesSelector, RefData, TickerMapping, TimeSeriesScheduler
# Old SessionManager moved to recycle/ - use TimeSeriesSessionManager instead
from .generic_session import GenericSessionManager
from .time_series_session import TimeSeriesSessionManager
from .base import DatabaseBase
from .operations import SeriesOperationMixin, BloombergOperationsMixin
from .decorators import handle_series_operation_errors
from .utilities import update_threshold_daily_close, create_update_filter, parse_time_string
# TimeSeriesContext imported on demand to avoid circular imports

__all__ = [
    "DatabaseManager",
    "GenericSessionManager",
    "TimeSeriesSessionManager",
    "TimeSeriesData",
    "TimeSeriesMeta",
    "TimeSeriesSelector",
    "RefData",
    "TickerMapping",
    "TimeSeriesScheduler",
    "DatabaseBase",
    "SeriesOperationMixin",
    "BloombergOperationsMixin",
    "handle_series_operation_errors",
    "update_threshold_daily_close",
    "create_update_filter",
    "parse_time_string",
]
