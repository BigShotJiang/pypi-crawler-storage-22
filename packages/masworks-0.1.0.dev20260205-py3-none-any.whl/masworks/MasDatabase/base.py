"""
Database base functionality for MasWorks library.

Provides shared database infrastructure including connection management,
feed initialization, and common utilities used by both reader and admin classes.
"""
import logging
from typing import Dict, Any

from masworks.config import Config
from masworks.utils.database_connection import DatabaseManager
from .time_series_session import TimeSeriesSessionManager
from masworks.feeds import BridgeFeed, FredFeed, DatastreamFeed
from masworks.constants import SOURCE_ALIASES

logger = logging.getLogger(__name__)


class DatabaseBase:
    """
    Base class for database operations in MasWorks.
    
    Provides shared infrastructure including database connections and common utilities.
    This class is not meant to be used directly - use MasTimeSeriesReader for read 
    operations or MasTimeSeriesAdmin for write operations.
    
    Note: Feed operations are only available in MasTimeSeriesAdmin.
    """
    
    def __init__(self, config: Config, auto_create_tables: bool = True):
        """
        Initialize DatabaseBase.
        
        Args:
            config: Configuration object with database and feed settings
            auto_create_tables: If True, automatically create database tables if they don't exist
        """
        self.config = config
        
        # Initialize database components
        self.db_manager = DatabaseManager(config.database)
        
        # Check if this is a versioned class
        # Versioned classes should use create_version() for versioned tables,
        # not auto-create current tables
        is_versioned = self._is_versioned_class()
        
        # Create tables if requested and they don't exist
        # Skip for versioned classes (they should use create_version() explicitly)
        if auto_create_tables and not is_versioned:
            self.db_manager.create_tables_if_not_exist()
        
        # Session manager will be attached by subclasses as needed
        self.session_manager = None
    
    def _is_versioned_class(self) -> bool:
        """
        Check if this instance is a versioned class.
        
        Uses lazy import to avoid circular dependency issues.
        
        Returns:
            True if this is a VersionedTimeSeriesBase subclass, False otherwise
        """
        try:
            # Lazy import to avoid circular dependency
            # Use absolute import path to avoid issues
            from masworks.versioned_time_series_base import VersionedTimeSeriesBase
            return isinstance(self, VersionedTimeSeriesBase)
        except (ImportError, AttributeError):
            # Fallback: check class name if import fails
            # This handles edge cases but shouldn't normally be needed
            class_name = self.__class__.__name__
            return 'Versioned' in class_name and 'TimeSeries' in class_name
        
        # Note: Feed initialization moved to TimeSeriesAdmin
        # Feeds are only needed for admin operations, not read-only operations
    
    def test_connection(self) -> bool:
        """
        Test database connection.
        
        Returns:
            True if connection is successful, False otherwise
        """
        return self.db_manager.test_connection()
    
    def create_tables(self) -> bool:
        """
        Manually create all database tables.
        
        Returns:
            True if tables were created successfully, False otherwise
        """
        return self.db_manager.create_tables()
    
    def create_tables_if_not_exist(self) -> bool:
        """
        Create database tables only if they don't already exist.
        
        Returns:
            True if tables exist or were created successfully, False otherwise
        """
        return self.db_manager.create_tables_if_not_exist()
    
    def close(self):
        """
        Close database connections and cleanup resources.
        
        Should be called when done with the instance to properly cleanup resources.
        """
        self.db_manager.close()
    
    # Note: Feed-related methods (get_available_feeds, get_feed_info) 
    # have been moved to TimeSeriesAdmin where feeds are actually available.
    # DatabaseBase only provides database operations, not feed operations.
