"""
Context manager for MasWorks time series operations.

This module provides TimeSeriesContext which is a convenient context manager
for time series operations, specifically designed for MasWorks time series
database operations.
"""
from typing import Optional, Union

from masworks.config import Config


class TimeSeriesContext:
    """
    Context manager wrapper for time series operations.
    
    Provides a convenient way to use TimeSeriesReader or TimeSeriesAdmin with automatic
    resource cleanup using Python's 'with' statement.
    
    Example:
        # For read operations
        with TimeSeriesContext(config, mode="reader") as reader:
            data = reader.get_series_data(ticker='SPX Index', field='PX_LAST')
        
        # For admin operations
        with TimeSeriesContext(config, mode="admin") as admin:
            result = admin.upsert_series('SPX Index', 'PX_LAST')
    """
    
    def __init__(self, config: Config, mode: str = "admin"):
        """
        Initialize TimeSeriesContext.
        
        Args:
            config: Configuration object with database and feed settings
            mode: Operation mode - "reader" for read-only, "admin" for full access
        """
        self.config = config
        self.mode = mode
        self._instance: Optional[Union['MasTimeSeriesReader', 'MasTimeSeriesAdmin']] = None
    
    def __enter__(self) -> Union['MasTimeSeriesReader', 'MasTimeSeriesAdmin']:
        """Enter context manager and initialize the appropriate class."""
        # Import here to avoid circular imports
        from masworks.mas_time_series_reader import MasTimeSeriesReader
        from masworks.mas_time_series_admin import MasTimeSeriesAdmin
        
        if self.mode == "reader":
            self._instance = MasTimeSeriesReader(self.config)
        else:
            self._instance = MasTimeSeriesAdmin(self.config)
        return self._instance
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Exit context manager and cleanup resources."""
        if self._instance:
            self._instance.close()
        return False
