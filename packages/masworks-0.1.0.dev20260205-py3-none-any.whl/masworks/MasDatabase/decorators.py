"""
Database decorators for MasWorks library.
"""
import logging
from functools import wraps
from typing import Any, Callable

from ..feeds import DataFeedError
from ..constants import STATUS_CODES

logger = logging.getLogger(__name__)


def handle_series_operation_errors(func: Callable) -> Callable:
    """
    Decorator to standardize error handling for series operations.
    
    Args:
        func: The function to wrap
        
    Returns:
        Wrapped function with error handling
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs) -> Any:
        try:
            return func(self, *args, **kwargs)
        except DataFeedError as e:
            ticker = kwargs.get('ticker', args[0] if args else 'unknown')
            logger.error(f"Data feed error for {ticker}: {e}")
            return {"status": STATUS_CODES['FEED_ERROR'], "error": str(e)}
        except Exception as e:
            ticker = kwargs.get('ticker', args[0] if args else 'unknown')
            operation = func.__name__.replace('_series', '')
            logger.error(f"{operation.title()} failed for {ticker}: {e}")
            return {"status": STATUS_CODES['ERROR'], "error": str(e)}
    return wrapper
