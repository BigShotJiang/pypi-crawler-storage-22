"""
Generic session management for database operations.

This module provides a generic SessionManager that can work with any database
schema and table structure, without hardcoded dependencies.
"""

import logging
from typing import Optional, List, Dict, Any
import pandas as pd
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from contextlib import contextmanager

from ..utils.session_base import BaseSessionManager
from ..utils.database_connection import DatabaseManager

logger = logging.getLogger(__name__)


class GenericSessionManager(BaseSessionManager):
    """
    Generic session manager for database operations.
    
    Provides generic database session management that can work with any
    database schema and table structure without hardcoded dependencies.
    """
    
    def __init__(self, db_manager: DatabaseManager, chunk_size: int = 5000):
        """
        Initialize GenericSessionManager.
        
        Args:
            db_manager: DatabaseManager instance
            chunk_size: Size of chunks for bulk operations
        """
        super().__init__(db_manager, chunk_size)
        # Track temp tables for reuse within session
        self._temp_tables = {}  # {table_name: connection_id}
        self._conn = None
    
    def _get_connection(self):
        """
        Get the current connection or create a new one.
        
        Returns:
            Database connection object
        """
        if self._conn is None:
            self._conn = self.db_manager.engine.connect()
        return self._conn
    
    def _close_connection(self):
        """Close the current connection if it exists."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
    
    def _get_schema(self) -> str:
        """Get the database schema from config."""
        return self.db_manager.config.schema
    
    def _get_or_create_temp_table(self, temp_table: str, source_table: str = None, schema: str = None) -> str:
        """
        Get existing temp table or create new one for reuse within session.
        
        Args:
            temp_table: Name of temp table to create/reuse
            source_table: Source table to copy structure from (if None, defaults to "TS_Data")
            schema: Database schema name (if None, uses config schema)
            
        Returns:
            Name of temp table to use
        """
        # Generate temp table name if not provided
        if temp_table is None:
            import time
            import random
            timestamp = int(time.time() * 1000) % 10000
            random_suffix = random.randint(10, 99)
            temp_table = f"#tmp_{timestamp}_{random_suffix}"
        
        # Get connection
        conn = self._get_connection()
        
        # Get connection ID for tracking
        conn_id = id(conn)
        
        # Check if we can reuse an existing temp table
        if temp_table in self._temp_tables and self._temp_tables[temp_table] == conn_id:
            # Reuse existing temp table - just truncate it
            try:
                conn.execute(text(f"TRUNCATE TABLE {temp_table}"))
                logger.debug(f"Reusing existing temp table: {temp_table}")
                return temp_table
            except Exception as e:
                logger.warning(f"Failed to truncate temp table {temp_table}, will recreate: {e}")
                # Fall through to create new table
        
        # Get table name and schema from model if not provided
        if source_table is None or schema is None:
            # Default to TimeSeriesData table info, but allow override
            if source_table is None:
                source_table = "TS_Data"  # Default table name
            
            if schema is None:
                schema = self._get_schema()  # Use config schema
        
        # Create new temp table
        self.create_temp_table(conn, temp_table, source_table, schema)
        self._temp_tables[temp_table] = conn_id
        logger.debug(f"Created new temp table: {temp_table}")
        return temp_table
    
    def _get_or_create_temp_table_from_model(self, temp_table: str, model_class) -> str:
        """
        Get existing temp table or create new one using SQLAlchemy model information.
        
        Args:
            temp_table: Name of temp table to create/reuse
            model_class: SQLAlchemy model class to get table name and schema from
            
        Returns:
            Name of temp table to use
        """
        # Extract table name and schema from model
        source_table = model_class.__tablename__
        schema = model_class.__table_args__["schema"]
        
        # Use the main method with extracted parameters
        return self._get_or_create_temp_table(temp_table, source_table, schema)
    
    def _cleanup_temp_table(self, temp_table: str):
        """
        Clean up temp table, but keep it for reuse if possible.
        
        Args:
            temp_table: Name of temp table to clean up
        """
        try:
            # Get connection
            conn = self._get_connection()
            
            # Debug: Check connection type
            logger.debug(f"Cleaning up temp table {temp_table}, connection type: {type(conn)}")
            
            # Check if connection has execute method
            if not hasattr(conn, 'execute'):
                logger.warning(f"Connection object {type(conn)} does not have execute method, skipping cleanup for {temp_table}")
                return
            
            # Try to truncate first (for reuse)
            conn.execute(text(f"TRUNCATE TABLE {temp_table}"))
            logger.debug(f"Truncated temp table for reuse: {temp_table}")
        except Exception as e:
            # If truncate fails, try to drop
            try:
                logger.debug(f"Truncate failed for {temp_table}: {e}, trying drop")
                conn.execute(text(f"DROP TABLE {temp_table}"))
                logger.debug(f"Dropped temp table: {temp_table}")
                # Remove from tracking
                if temp_table in self._temp_tables:
                    del self._temp_tables[temp_table]
            except Exception as drop_error:
                logger.warning(f"Could not clean up {temp_table}: {drop_error}")
    
    def _cleanup_all_temp_tables(self):
        """
        Clean up all temp tables for the current connection.
        """
        # Get connection
        conn = self._get_connection()
        conn_id = id(conn)
        
        tables_to_remove = []
        
        for temp_table, tracked_conn_id in self._temp_tables.items():
            if tracked_conn_id == conn_id:
                try:
                    conn.execute(text(f"DROP TABLE {temp_table}"))
                    logger.debug(f"Dropped temp table: {temp_table}")
                    tables_to_remove.append(temp_table)
                except Exception as e:
                    logger.warning(f"Failed to clean up temp table {temp_table}: {e}")
        
        # Remove from tracking
        for temp_table in tables_to_remove:
            del self._temp_tables[temp_table]
    
    @contextmanager
    def bulk_operations_context(self):
        """
        Context manager for bulk operations that reuses connections and temp tables.
        
        This reuses an existing connection if available, or creates a new one and keeps it open.
        Optimized for sequences of operations where you want to reuse temp tables for better performance.
        
        Example:
            with session_manager.bulk_operations_context() as conn:
                result1 = session_manager.some_operation(df1, conn=conn)
                result2 = session_manager.some_operation(df2, conn=conn)
        """
        # If we already have a connection, use it
        if self._conn is not None:
            yield self._conn
        else:
            # Create new connection and keep it open
            conn = self.db_manager.engine.connect()
            try:
                self._conn = conn
                yield conn
            finally:
                # Don't close - let it stay in self._conn for future use
                # Just clean up temp tables
                self._cleanup_all_temp_tables()
    
    def close(self):
        """Close database connections and cleanup resources."""
        # Clean up any remaining temp tables
        if hasattr(self, '_temp_tables'):
            self._cleanup_all_temp_tables()
            self._temp_tables.clear()
        
        # Close current connection
        self._close_connection()
        
        # Close base class resources
        super().close()
