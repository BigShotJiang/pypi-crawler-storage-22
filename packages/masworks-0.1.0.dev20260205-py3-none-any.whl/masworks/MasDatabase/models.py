"""
SQLAlchemy ORM models for time series database tables.
"""
from datetime import datetime, date
from typing import Optional
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, Text, ForeignKey, Index, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()

def get_schema():
    """Get the database schema from config, defaulting to 'dev'."""
    try:
        from ..config import get_default_config
        config = get_default_config()
        return config.database.schema
    except Exception:
        # Fallback to 'dev' if config is not available
        return "dev"


class TimeSeriesData(Base):
    """
    Time series data points table (TS_Data).
    
    Stores the actual time series data with id, date, and value.
    """
    __tablename__ = "TS_Data"
    __table_args__ = {"schema": get_schema()}
    
    id = Column(Integer, ForeignKey(f"{get_schema()}.TS_Meta.id"), primary_key=True, nullable=False)
    date = Column(Date, primary_key=True, nullable=False)
    value = Column(Float, nullable=True)
    
    # Relationship to series metadata (foreign keys confirmed in database)
    series_metadata = relationship("TimeSeriesMeta", back_populates="data_points")
    
    def __repr__(self):
        return f"<TimeSeriesData(id={self.id}, date={self.date}, value={self.value})>"


class TimeSeriesMeta(Base):
    """
    Time series metadata table (TS_Meta).
    
    Stores information about each time series including source, ticker, field, etc.
    """
    __tablename__ = "TS_Meta"
    __table_args__ = (
        Index('idx_ts_meta_lookup', 'source', 'ticker', 'field', 'frequency', 'currency'),
        {"schema": get_schema()}
    )
    
    # Primary key (always first)
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Most frequently queried columns (high selectivity, small size)
    source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
    ticker = Column(String(62), nullable=False)  # Ticker symbol
    field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
    frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
    
    # Foreign key columns (for joins) - part of search index
    currency = Column(String(6), nullable=False, default="-")  # Currency
    
    # String ID (high priority, frequently used)
    sid = Column(String(62), nullable=True)  # String ID
    
    # Audit/system columns (frequently updated, small)
    start_date = Column(Date, nullable=True)  # First date of the time series
    
    # Business metadata (medium frequency, variable size)
    freq = Column(String(1), nullable=True)  # Alternative frequency field
    cat = Column(String(6), nullable=True)  # Category: Market, Econ
    daylag = Column(Integer, nullable=True)  # Data lag in days
    daylag2 = Column(Integer, nullable=True)  # Alternative lag field
    
    # Large/text columns (least frequently accessed)
    cname = Column(String(30), nullable=True)  # Short name
    cname2 = Column(String(62), nullable=True)  # Description
    note = Column(String(6), nullable=True)  # Notes
    tempflag = Column(String(6), nullable=True)  # Temporary flag
    created_at = Column(DateTime, nullable=True, default=datetime.now)  # Creation timestamp
    created_by = Column(String(50), nullable=True)  # Username who created the record
    json = Column(Text, nullable=True)  # JSON metadata for datastream
    
    # Relationships (foreign keys confirmed in database)
    data_points = relationship("TimeSeriesData", back_populates="series_metadata")
    selectors = relationship("TimeSeriesSelector", back_populates="series")
    
    def __repr__(self):
        return f"<TimeSeriesMeta(id={self.id}, source={self.source}, ticker={self.ticker}, field={self.field})>"


class TimeSeriesSelector(Base):
    """
    Time series selector table (TS_Selector).
    
    Groups time series into different sets for different projects.
    Now supports grouping within selections via the 'grp' column.
    """
    __tablename__ = "TS_Selector"
    __table_args__ = {"schema": get_schema()}
    
    sel = Column(String(30), primary_key=True, nullable=False)  # Selection name
    grp = Column(String(30), primary_key=True, nullable=False)  # Group within selection
    ord = Column(Integer, primary_key=True, nullable=False)  # Order within group
    id = Column(Integer, ForeignKey(f"{get_schema()}.TS_Meta.id"), nullable=False)  # Series ID
    colname = Column(String(62), nullable=True)  # Column name for DataFrame
    desname = Column(String(62), nullable=True)  # Descriptive name
    uselag = Column(Boolean, nullable=False, default=False)
    align = Column(String(6), nullable=True)
    
    # Relationship to series metadata
    series = relationship("TimeSeriesMeta", back_populates="selectors")
    
    def __repr__(self):
        return f"<TimeSeriesSelector(sel={self.sel}, grp={self.grp}, ord={self.ord}, id={self.id})>"


class RefData(Base):
    """
    Reference data table.
    
    Stores reference data (e.g., Bloomberg reference fields) for time series.
    """
    __tablename__ = "RefData"
    __table_args__ = {"schema": get_schema()}
    
    source = Column(String(6), primary_key=True, nullable=False)  # Source
    ticker = Column(String(62), primary_key=True, nullable=False)  # Ticker
    field = Column(String(62), primary_key=True, nullable=False)  # Field
    date = Column(DateTime, primary_key=True, nullable=False)  # Date
    
    dtype = Column(String(6), nullable=True)  # Data type
    fvalue = Column(Float, nullable=True)  # Float value
    svalue = Column(Text, nullable=True)  # String value
    upd = Column(DateTime, nullable=True)  # Update timestamp
    
    def __repr__(self):
        return f"<RefData(source={self.source}, ticker={self.ticker}, field={self.field})>"


class TickerMapping(Base):
    """
    Ticker mapping table.
    
    Maps tickers across different data sources (FRED, Datastream, Bloomberg, IBES).
    """
    __tablename__ = "TickerMapping"
    __table_args__ = {"schema": get_schema()}
    
    fred = Column(String(30), primary_key=True, nullable=False)
    ds = Column(String(30), primary_key=True, nullable=False)  # Datastream
    bb = Column(String(30), primary_key=True, nullable=False)  # Bloomberg
    ibes = Column(String(30), primary_key=True, nullable=False, default="-")  # IBES
    
    def __repr__(self):
        return f"<TickerMapping(fred={self.fred}, ds={self.ds}, bb={self.bb}, ibes={self.ibes})>"


class TimeSeriesScheduler(Base):
    """
    Time series refresh schedule table.
    
    Stores refresh schedules for time series updates (future implementation).
    """
    __tablename__ = "TS_Scheduler"
    __table_args__ = {"schema": get_schema()}
    
    sch = Column(String(6), primary_key=True, nullable=False)  # Schedule name
    id = Column(Integer, ForeignKey(f"{get_schema()}.TS_Meta.id"), primary_key=True, nullable=False)  # Series ID
    custom = Column(String(254), nullable=True)  # Custom settings
    upd = Column(DateTime, nullable=True)  # Update timestamp
    
    def __repr__(self):
        return f"<TimeSeriesScheduler(sch={self.sch}, id={self.id})>"


class ServiceRegistry(Base):
    """
    API service registry table.
    
    Stores information about Bridge API servers and their availability.
    Based on Bridge repository service registry pattern.
    """
    __tablename__ = "api_service_registry"
    __table_args__ = {"schema": get_schema()}
    
    service_name = Column(String(50), primary_key=True, nullable=False)  # Service name (e.g., 'bridge_api')
    host = Column(String(100), primary_key=True, nullable=False)  # Server hostname or IP
    port = Column(Integer, primary_key=True, nullable=False)  # Server port
    status = Column(String(20), nullable=False)  # Status: 'started', 'stopped', 'unknown'
    last_heartbeat = Column(DateTime, nullable=False)  # Last heartbeat from server
    pid = Column(Integer, nullable=False)  # Process ID
    details = Column(Text, nullable=True)  # Additional details (JSON or text)
    created_at = Column(DateTime, nullable=True, default=datetime.now)  # Registration timestamp
    updated_at = Column(DateTime, nullable=True, default=datetime.now, onupdate=datetime.now)  # Last update
    
    def __repr__(self):
        return f"<ServiceRegistry(service_name={self.service_name}, host={self.host}:{self.port}, status={self.status})>"
    
    @property
    def server_address(self) -> str:
        """Get full server address (host:port)."""
        return f"{self.host}:{self.port}"
    
    @property
    def health_url(self) -> str:
        """Get health check URL."""
        return f"http://{self.server_address}/health"
    
    @property
    def gd1_url(self) -> str:
        """Get Bridge API data endpoint URL."""
        return f"http://{self.server_address}/gd1"
    
    @property
    def is_online(self) -> bool:
        """Check if server is started."""
        return self.status.lower() == 'started'


class TimeSeriesStatus(Base):
    """
    Time series status table.
    
    Tracks when time series are updated, including the date range and user who performed the update.
    """
    __tablename__ = "TS_Status"
    __table_args__ = {"schema": get_schema()}
    
    id = Column(Integer, ForeignKey(f"{get_schema()}.TS_Meta.id"), primary_key=True, nullable=False)  # FK to TimeSeriesMeta.id
    upd = Column(DateTime, nullable=False, default=datetime.now)  # Datetime of the timeseries when updated
    upd_start = Column(Date, nullable=False)  # Start date of the time series from where the time series is updated
    upd_end = Column(Date, nullable=False)  # Last date of the time series after update
    upd_by = Column(String(50), nullable=True)  # User who updated the time series
    
    # Relationship to series metadata
    series = relationship("TimeSeriesMeta")
    
    def __repr__(self):
        return f"<TimeSeriesStatus(id={self.id}, upd={self.upd}, upd_start={self.upd_start}, upd_end={self.upd_end}, upd_by={self.upd_by})>"


class TimeSeriesMetaPlus(Base):
    """
    Database view that joins TS_Meta and TS_Status tables.
    
    This view provides a unified interface to access both metadata and status information
    for time series, including the last update time from TS_Status.
    """
    __tablename__ = "TS_MetaPlus"
    __table_args__ = {"schema": get_schema()}
    
    # Primary key from TS_Meta
    id = Column(Integer, primary_key=True, nullable=False)
    
    # TS_Meta columns (simplified to match SQL view)
    source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
    ticker = Column(String(62), nullable=False)  # Ticker symbol
    field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
    frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
    currency = Column(String(6), nullable=False, default="-")  # Currency
    sid = Column(String(62), nullable=True)  # String ID
    start_date = Column(Date, nullable=True)  # First date of the time series
    freq = Column(String(1), nullable=True)  # Alternative frequency field
    daylag = Column(Integer, nullable=True)  # Data lag in days
    note = Column(String(6), nullable=True)  # Notes
    
    # TS_Status columns (nullable since not all series may have status records)
    upd = Column(DateTime, nullable=True)  # Last update time from TS_Status
    upd_start = Column(Date, nullable=True)  # Start date of last update
    upd_end = Column(Date, nullable=True)  # End date of last update
    
    def __repr__(self):
        return f"<TimeSeriesMetaPlus(id={self.id}, ticker={self.ticker}, field={self.field}, source={self.source}, upd={self.upd})>"


class TimeSeriesSelectorMetaPlus(Base):
    """
    Database view that joins TS_Selector, TS_Meta, and TS_Status tables.
    
    This view provides a unified interface to access selector information along with
    metadata and status information for time series. It combines selector grouping
    information with the complete time series metadata and update status.
    """
    __tablename__ = "TS_SelectorMetaPlus"
    __table_args__ = {"schema": get_schema()}
    
    # Primary key from TS_Selector (composite key)
    sel = Column(String(30), primary_key=True, nullable=False)  # Selection name
    grp = Column(String(30), primary_key=True, nullable=False)  # Group within selection
    ord = Column(Integer, primary_key=True, nullable=False)  # Order within group
    
    # TS_Selector columns
    id = Column(Integer, nullable=False)  # Series ID (foreign key to TS_Meta)
    colname = Column(String(62), nullable=True)  # Column name for DataFrame
    desname = Column(String(62), nullable=True)  # Descriptive name
    
    # TS_Meta columns
    source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
    ticker = Column(String(62), nullable=False)  # Ticker symbol
    field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
    frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
    currency = Column(String(6), nullable=False, default="-")  # Currency
    sid = Column(String(62), nullable=True)  # String ID
    start_date = Column(Date, nullable=True)  # First date of the time series
    freq = Column(String(1), nullable=True)  # Alternative frequency field
    daylag = Column(Integer, nullable=True)  # Data lag in days
    note = Column(String(6), nullable=True)  # Notes
    
    # TS_Status columns (nullable since not all series may have status records)
    upd = Column(DateTime, nullable=True)  # Last update time from TS_Status
    upd_start = Column(Date, nullable=True)  # Start date of last update
    upd_end = Column(Date, nullable=True)  # End date of last update
    
    def __repr__(self):
        return f"<TimeSeriesSelectorMetaPlus(sel={self.sel}, grp={self.grp}, ord={self.ord}, id={self.id}, ticker={self.ticker}, field={self.field}, source={self.source})>"


class BbgTickerDetail(Base):
    """
    Bloomberg ticker detail table.
    
    Stores Bloomberg ticker detail information including canonical tickers, FIGI IDs,
    and other metadata retrieved from the Bridge API's ticker_detail endpoint.
    """
    __tablename__ = "BbgTickerDetail"
    __table_args__ = {"schema": get_schema()}
    
    # Primary key - ticker field
    ticker = Column(String(100), primary_key=True, nullable=False)
    
    # Bloomberg canonical ticker information
    canonical_ticker = Column(String(100), nullable=True)  # Bloomberg's canonical ticker
    ticker_symbol = Column(String(50), nullable=True)  # Ticker symbol
    id_bb_global = Column(String(50), nullable=True)  # Bloomberg FIGI ID
    exchange_code = Column(String(20), nullable=True)  # Exchange code
    primary_exchange = Column(String(20), nullable=True)  # Primary exchange
    currency = Column(String(10), nullable=True)  # Currency code
    description = Column(String(200), nullable=True)  # Description
    
    # Audit fields
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=True, default=datetime.now, onupdate=datetime.now)
    created_by = Column(String(50), nullable=True)  # User who created the record
    
    def __repr__(self):
        return f"<BbgTickerDetail(ticker='{self.ticker}', canonical_ticker='{self.canonical_ticker}')>"