"""
Database operations mixins for MasWorks library.
"""
import logging
import getpass
from typing import Optional, Dict, Any, List, Tuple
import pandas as pd
from datetime import datetime, date

from masworks.constants import (
    SOURCE_CODE_MAP, SOURCE_ALIASES, SUPPORTED_SOURCES,
    OPERATION_TYPES, STATUS_CODES
)

logger = logging.getLogger(__name__)


class SeriesOperationMixin:
    """Mixin class containing common series operation logic."""
    
    def _normalize_source(self, source: str) -> str:
        """Normalize source name and validate."""
        source = source.lower()
        if source in SOURCE_ALIASES:
            source = SOURCE_ALIASES[source]
        
        if source not in SUPPORTED_SOURCES:
            raise ValueError(f"Unknown data source: {source}")
        
        return source
    
    def _get_source_code(self, source: str) -> str:
        """
        Get source code for database storage.
        
        SOURCE_CODE_MAP is only for feed sources (BB, DS, FRED).
        Other sources are normalized to uppercase (up to column limit of 6 chars).
        """
        return SOURCE_CODE_MAP.get(source, source.upper()[:6])
    
    def _get_current_username(self) -> str:
        """Get current system username."""
        try:
            return getpass.getuser()
        except Exception:
            return "unknown"
    
    def _prepare_series_metadata_filters(self, ticker: str, field: str, 
                                       frequency: str, source: str, 
                                       currency: str) -> Dict[str, Any]:
        """Prepare metadata filters for series lookup."""
        src_code = self._get_source_code(source)
        
        # For FRED, force field, frequency, and currency to be '-'
        if src_code == 'FRED':
            field_value = '-'
            frequency_value = '-'
            currency_value = '-'
        else:
            field_value = field.upper() if field else '-'
            frequency_value = frequency.upper()
            currency_value = currency.upper() if currency else '-'
        
        # For Bloomberg (BB), use canonical ticker information if available
        if src_code == 'BB':
            # Check if we have canonical ticker info from Bridge feed
            if hasattr(self, 'feeds') and 'bloomberg' in self.feeds:
                bridge_feed = self.feeds['bloomberg']

                # Try to get canonical ticker first (preferred)
                canonical_ticker = bridge_feed.get_canonical_ticker(ticker)
                if canonical_ticker:
                    ticker = canonical_ticker
                    logger.debug(f"Using Bloomberg canonical ticker for TS_Meta: '{ticker}'")
                else:
                    # Fallback to response ticker if canonical not available
                    response_ticker = bridge_feed.get_last_response_ticker()
                    if response_ticker:
                        ticker = response_ticker
                        logger.debug(f"Using Bloomberg response ticker for TS_Meta: '{ticker}'")
        
        return {
            'source': src_code,
            'ticker': ticker.upper(),
            'field': field_value,
            'frequency': frequency_value,
            'currency': currency_value
        }
    
    def _get_or_create_series_metadata(self, ticker: str, field: str, 
                                     frequency: str, source: str, 
                                     currency: str, auto_create: bool = True, **kwargs) -> Tuple[int, bool]:
        """
        Get existing series metadata or create new one.
        
        Args:
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency
            source: Source name
            currency: Currency code
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional metadata fields
            
        Returns:
            Tuple of (series_id, is_new_series)
            
        Raises:
            ValueError: If auto_create=False and metadata doesn't exist
        """
        # Check if series already exists
        filters = self._prepare_series_metadata_filters(ticker, field, frequency, source, currency)
        existing = self.session_manager.get_ts_metadata(**filters)
        
        # Check if existing is None or empty DataFrame
        if existing is None or existing.empty:
            if not auto_create:
                # Build error message with filter details
                source_code = filters.get('source', '')
                normalized_ticker = filters.get('ticker', '')
                normalized_field = filters.get('field', '-')
                normalized_frequency = filters.get('frequency', '-')
                normalized_currency = filters.get('currency', '-')
                raise ValueError(
                    f"TS_Meta record does not exist for series: "
                    f"source={source_code}, ticker={normalized_ticker}, field={normalized_field}, "
                    f"frequency={normalized_frequency}, currency={normalized_currency}. "
                    f"Set auto_create=True to automatically create metadata."
                )
            
            # Create new series metadata using the same normalized values from filters
            username = self._get_current_username()
            
            # Generate SID if not provided in kwargs
            # SID format: "SOURCE::TICKER::FIELD::FREQUENCY::CURRENCY"
            if 'sid' not in kwargs:
                source_code = filters.get('source', '')
                normalized_ticker = filters.get('ticker', '')
                normalized_field = filters.get('field', '-')
                normalized_frequency = filters.get('frequency', '-')
                normalized_currency = filters.get('currency', '-')
                sid = f"{source_code}::{normalized_ticker}::{normalized_field}::{normalized_frequency}::{normalized_currency}"
                kwargs['sid'] = sid
                logger.debug(f"Generated SID for new series: {sid}")
            
            metadata = self.session_manager.create_ts_metadata(
                **filters,
                created_by=username,
                **kwargs
            )
            series_id = int(metadata.id)
            logger.info(f"Created new series metadata with ID: {series_id}")
            return series_id, True
        else:
            # Update existing metadata (upd is now auto-updated)
            # Get the first row from the DataFrame
            metadata = existing.iloc[0]
            # Convert numpy.int64 to Python int for compatibility
            series_id = metadata.id
            if hasattr(series_id, 'item'):
                series_id = series_id.item()
            else:
                series_id = int(series_id)
            self.session_manager.update_ts_metadata(series_id)
            logger.info(f"Updated existing series metadata for ID: {series_id}")
            return series_id, False
    
    def _validate_data_feed_parameters(self, ticker: str, field: str, frequency: str,
                                      source: str, currency: str, start_date: Optional[str],
                                      **kwargs) -> pd.DataFrame:
        """
        Validate data feed parameters by attempting to fetch data.
        
        This method fetches a small amount of data to verify that the parameters
        are correct before creating metadata entries.
        
        IMPORTANT: For FRED, this normalizes field, frequency, and currency to '-' before validation.
        
        Returns:
            DataFrame with fetched data (empty if validation fails)
        """
        try:
            # Normalize source first
            src_code = self._get_source_code(source)
            
            # For FRED, normalize parameters to match what will be stored in metadata
            if src_code == 'FRED':
                field = '-'
                frequency = '-'
                currency = '-'
                logger.info(f"Validating FRED parameters (normalized): {ticker} field='-', frequency='-', currency='-' from {source}")
            else:
                logger.info(f"Validating parameters for {ticker} {field} from {source}")
            
            # Use parameters for validation (now normalized for FRED)
            df = self._fetch_series_data(ticker, field, frequency, source, currency, start_date, **kwargs)
            
            # Check if df is None or not a DataFrame
            if df is None:
                logger.warning(f"Validation failed: No data returned for {ticker} {field} from {source}")
                return pd.DataFrame()
            
            if not isinstance(df, pd.DataFrame):
                logger.warning(f"Validation failed: Expected DataFrame but got {type(df)} for {ticker} {field} from {source}")
                return pd.DataFrame()
            
            if df.empty:
                logger.warning(f"Validation failed: No data available for {ticker} {field} from {source}")
            else:
                logger.info(f"Validation successful: Retrieved {len(df)} data points for {ticker} {field}")
            
            return df
            
        except Exception as e:
            logger.error(f"Validation failed for {ticker} {field} from {source}: {e}")
            # Return empty DataFrame to indicate validation failure
            return pd.DataFrame()
    
    def _fetch_series_data(self, ticker: str, field: str, frequency: str,
                          source: str, currency: str, start_date: Optional[str],
                          **kwargs) -> pd.DataFrame:
        """Fetch data from external source."""
        # Ensure feeds are initialized (for admin operations)
        if not hasattr(self, 'feeds') or not self.feeds:
            # Try lazy initialization if available
            if hasattr(self, '_ensure_feeds_initialized'):
                self._ensure_feeds_initialized()
            else:
                raise RuntimeError(
                    "Feeds not initialized. Use MasTimeSeriesAdmin for data operations. "
                    "MasTimeSeriesReader does not support data fetching operations."
                )
        
        if source not in self.feeds:
            raise ValueError(f"Data source '{source}' not available. Available sources: {list(self.feeds.keys())}")
        
        feed = self.feeds[source]
        
        # Prepare parameters for the feed
        feed_params = {
            'ticker': ticker,
            'field': field,
            'frequency': frequency,
            'start_date': start_date or self.config.default_start_date,
            **kwargs
        }
        
        # Only add currency if the feed supports it (not all feeds do)
        if currency and hasattr(feed, 'get_data'):
            # Check if the feed's get_data method accepts currency parameter
            import inspect
            sig = inspect.signature(feed.get_data)
            if 'currency' in sig.parameters:
                feed_params['currency'] = currency
        
        result = feed.get_data(**feed_params)
        
        # Ensure we always return a DataFrame
        if result is None:
            logger.warning(f"Feed {source} returned None for {ticker} {field}")
            return pd.DataFrame()
        
        if not isinstance(result, pd.DataFrame):
            logger.warning(f"Feed {source} returned {type(result)} instead of DataFrame for {ticker} {field}")
            return pd.DataFrame()
        
        return result
    
    def _prepare_dataframe_for_operation(self, df: pd.DataFrame, series_id: int) -> pd.DataFrame:
        """Prepare DataFrame for database operation."""
        df_prepared = df.reset_index()
        df_prepared['id'] = series_id
        return df_prepared[['id', 'date', 'value']]
    
    def _prepare_dataframe_for_operation_with_date(self, df: pd.DataFrame, series_id: int) -> pd.DataFrame:
        """
        Prepare DataFrame for database operation with date value conversion.
        
        This method converts date string values to Unix timestamps for storage
        in the TS_Data.value column (which is a FLOAT type).
        """
        df_prepared = df.reset_index()
        df_prepared['id'] = series_id
        
        # Convert date string values to Unix timestamps
        if 'value' in df_prepared.columns:
            df_prepared['value'] = df_prepared['value'].apply(self._convert_date_to_timestamp)
        
        return df_prepared[['id', 'date', 'value']]
    
    def _convert_date_to_timestamp(self, date_value) -> float:
        """
        Convert date string to Unix timestamp (seconds since epoch).
        
        Args:
            date_value: Date string in various formats or pandas Timestamp
            
        Returns:
            Unix timestamp as float
        """
        if pd.isna(date_value):
            return None
        
        try:
            # If it's already a pandas Timestamp, convert to Unix timestamp
            if isinstance(date_value, pd.Timestamp):
                return date_value.timestamp()
            
            # If it's a string, try to parse it
            if isinstance(date_value, str):
                # Try common date formats
                date_formats = [
                    '%Y-%m-%d',           # 2024-01-01
                    '%Y%m%d',             # 20240101
                    '%m/%d/%Y',          # 01/01/2024
                    '%Y-%m-%d %H:%M:%S',  # 2024-01-01 12:00:00
                    '%d/%m/%Y',          # 01/01/2024
                    '%d-%m-%Y'          # 01-01-2024
                ]
                
                for fmt in date_formats:
                    try:
                        dt = datetime.strptime(date_value, fmt)
                        return dt.timestamp()
                    except ValueError:
                        continue
                
                # If no format matches, try pandas to_datetime
                dt = pd.to_datetime(date_value)
                return dt.timestamp()
            
            # If it's already a datetime object
            if isinstance(date_value, datetime):
                return date_value.timestamp()
            
            # If it's already a date object
            if isinstance(date_value, date):
                return datetime.combine(date_value, datetime.min.time()).timestamp()
            
            # If it's already a number (Unix timestamp), return as float
            if isinstance(date_value, (int, float)):
                return float(date_value)
            
            logger.warning(f"Could not convert date value '{date_value}' to timestamp")
            return None
            
        except Exception as e:
            logger.error(f"Error converting date value '{date_value}' to timestamp: {e}")
            return None
    
    def _execute_series_operation(self, df: pd.DataFrame, operation_type: str) -> Tuple[int, int]:
        """Execute the actual database operation (upsert or replace)."""
        if operation_type == OPERATION_TYPES['UPSERT']:
            return self.session_manager.upsert_ts_data(df)
        elif operation_type == OPERATION_TYPES['REPLACE']:
            return self.session_manager.replace_ts_data(df)
        else:
            raise ValueError(f"Unknown operation type: {operation_type}")


class BloombergOperationsMixin:
    """Mixin class for Bloomberg-specific operations."""
    
    def _process_bloomberg_combinations(self, tickers: List[str], fields: List[str],
                                      frequency: str, start_date: Optional[str],
                                      operation_type: str, **kwargs) -> Dict[str, Any]:
        """Process all combinations of Bloomberg tickers and fields."""
        logger.info(f"Starting auto {operation_type} for Bloomberg data: {len(tickers)} tickers, {len(fields)} fields")
        
        results = {
            'total_combinations': len(tickers) * len(fields),
            'new_series_created': 0,
            'existing_series_updated': 0,
            'errors': [],
            'successful_operations': []
        }
        
        # Update key name based on operation type
        if operation_type == OPERATION_TYPES['REPLACE']:
            results['existing_series_replaced'] = results.pop('existing_series_updated')
        
        for field in fields:
            for ticker in tickers:
                try:
                    result = self._process_single_bloomberg_series(
                        ticker, field, frequency, start_date, operation_type, **kwargs
                    )
                    
                    # Update counters based on result
                    if result['is_new_series']:
                        results['new_series_created'] += 1
                        operation_desc = 'created'
                    else:
                        if operation_type == OPERATION_TYPES['REPLACE']:
                            results['existing_series_replaced'] += 1
                            operation_desc = 'replaced'
                        else:
                            results['existing_series_updated'] += 1
                            operation_desc = 'updated'
                    
                    results['successful_operations'].append({
                        'ticker': ticker,
                        'field': field,
                        'frequency': frequency,
                        'operation_type': operation_desc,
                        'result': result['operation_result']
                    })
                    
                except Exception as e:
                    error_msg = f"Error processing Bloomberg series {ticker} {field}: {e}"
                    logger.error(error_msg)
                    results['errors'].append({
                        'ticker': ticker,
                        'field': field,
                        'frequency': frequency,
                        'error': str(e)
                    })
        
        # Log summary
        if operation_type == OPERATION_TYPES['REPLACE']:
            logger.info(f"Auto replace completed: {results['new_series_created']} created, "
                       f"{results['existing_series_replaced']} replaced, {len(results['errors'])} errors")
        else:
            logger.info(f"Auto upsert completed: {results['new_series_created']} created, "
                       f"{results['existing_series_updated']} updated, {len(results['errors'])} errors")
        
        return results
    
    def _process_single_bloomberg_series(self, ticker: str, field: str, frequency: str,
                                       start_date: Optional[str], operation_type: str,
                                       **kwargs) -> Dict[str, Any]:
        """Process a single Bloomberg series."""
        logger.debug(f"Processing Bloomberg series: {ticker} {field} {frequency}")
        
        # Execute the operation (validation happens in the main methods)
        if operation_type == OPERATION_TYPES['REPLACE']:
            operation_result = self.replace_series(
                ticker=ticker, field=field, frequency=frequency,
                source='bloomberg', start_date=start_date, **kwargs
            )
        else:
            operation_result = self.upsert_series(
                ticker=ticker, field=field, frequency=frequency,
                source='bloomberg', start_date=start_date, **kwargs
            )
        
        # Extract is_new_series from the operation result
        is_new_series = operation_result.get('is_new_series', False)
        
        return {
            'is_new_series': is_new_series,
            'operation_result': operation_result
        }
