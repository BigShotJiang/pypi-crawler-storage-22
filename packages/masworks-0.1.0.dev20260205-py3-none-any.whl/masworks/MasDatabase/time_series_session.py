"""
Time Series specific session management.

This module provides TimeSeriesSessionManager which extends the generic SessionManager
with time series specific functionality, keeping the base SessionManager generic.
"""

import logging
from typing import List, Dict, Any, Optional, Union
import pandas as pd
import numpy as np
from sqlalchemy import text, select
from sqlalchemy.exc import SQLAlchemyError

from .generic_session import GenericSessionManager
from .models import TimeSeriesData, TimeSeriesMeta

logger = logging.getLogger(__name__)


class TimeSeriesSessionManager(GenericSessionManager):
    """
    Time Series specific session manager.
    
    Extends the generic SessionManager with time series specific functionality
    while keeping the base SessionManager completely generic.
    """
    
    def __init__(self, db_manager, chunk_size: int = 5000):
        """Initialize TimeSeriesSessionManager."""
        super().__init__(db_manager, chunk_size)
    
    def _get_or_create_ts_data_temp_table(self, temp_table: str = None) -> str:
        """
        Get or create temp table specifically for TimeSeriesData operations.
        
        Args:
            temp_table: Name of temp table to create/reuse
            
        Returns:
            Name of temp table to use
        """
        return self._get_or_create_temp_table_from_model(temp_table, TimeSeriesData)
    
    def _get_or_create_ts_meta_temp_table(self, temp_table: str = None) -> str:
        """
        Get or create temp table specifically for TimeSeriesMeta operations.
        
        Args:
            temp_table: Name of temp table to create/reuse
            
        Returns:
            Name of temp table to use
        """
        return self._get_or_create_temp_table_from_model(temp_table, TimeSeriesMeta)
    
    def upsert_ts_data(self, df: pd.DataFrame, temp_table: str = None, conn=None) -> tuple:
        """
        Upsert time series data using TimeSeriesData table structure.
        
        Args:
            df: DataFrame with columns [id, date, value]
            temp_table: Name of temporary table to use (if None, generates unique name)
            conn: Optional database connection (if None, creates new connection)
            
        Returns:
            Tuple of (updated_rows, inserted_rows)
        """
        # Check if df is None or not a DataFrame
        if df is None:
            logger.warning("DataFrame is None, returning (0, 0)")
            return (0, 0)
        
        if not isinstance(df, pd.DataFrame):
            logger.warning(f"Expected DataFrame but got {type(df)}, returning (0, 0)")
            return (0, 0)
        
        if df.empty:
            return (0, 0)
        
        # Generate unique temporary table name if not provided
        if temp_table is None:
            import time
            import random
            # Use very short name to avoid SQL Server 128 char limit
            timestamp = int(time.time() * 1000) % 10000  # Last 4 digits
            random_suffix = random.randint(10, 99)  # 2 digits
            temp_table = f"#tmp_{timestamp}_{random_suffix}"
        
        # Ensure required columns
        required_cols = ['id', 'date', 'value']
        if not all(col in df.columns for col in required_cols):
            raise ValueError(f"DataFrame must contain columns: {required_cols}")
        
        try:
            logger.info(f"Starting upsert operation for {len(df)} rows")
            
            # Use provided connection or create new one
            if conn is not None:
                # Use provided connection (for bulk operations)
                return self._execute_upsert_with_conn(conn, df, temp_table, required_cols)
            else:
                # Create new connection and manage it properly
                new_conn = self.db_manager.engine.connect()
                try:
                    # Set the current connection so temp table creation uses the same connection
                    self._conn = new_conn
                    return self._execute_upsert_with_conn(new_conn, df, temp_table, required_cols)
                finally:
                    self._conn = None
                    new_conn.close()
                    
        except SQLAlchemyError as e:
            logger.error(f"Upsert operation failed: {e}")
            raise
    
    def _execute_upsert_with_conn(self, conn, df: pd.DataFrame, temp_table: str, required_cols: List[str]) -> tuple:
        """Execute upsert operation with a specific connection using TimeSeriesData structure."""
        try:
            # Get or create temp table (reuse if possible) - using TimeSeriesData model
            temp_table = self._get_or_create_ts_data_temp_table(temp_table)
            
            # Prepare data for bulk insert
            df_clean = df[required_cols].copy()
            insert_sql = f"INSERT INTO {temp_table} (id, date, value) VALUES (:id, :date, :value)"
            batch_data = [{'id': row['id'], 'date': row['date'], 'value': row['value']} for _, row in df_clean.iterrows()]
            
            # Insert data into temp table
            self.execute_chunked_bulk_insert(conn, insert_sql, batch_data, "temp_ts_data")
            
            # Perform upsert using MERGE statement
            merge_sql = f"""
            MERGE {self._get_schema()}.TS_Data AS target
            USING {temp_table} AS source
            ON target.id = source.id AND target.date = source.date
            WHEN MATCHED THEN
                UPDATE SET value = source.value
            WHEN NOT MATCHED THEN
                INSERT (id, date, value) VALUES (source.id, source.date, source.value);
            """
            
            result = conn.execute(text(merge_sql))
            conn.commit()
            
            # Get counts (approximate)
            upserted_rows = len(df_clean)
            
            logger.info(f"Upsert completed: {upserted_rows} rows processed")
            
            return (upserted_rows, 0)  # Return 0 for second parameter to maintain tuple format
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Upsert operation failed: {e}")
            raise
        finally:
            # Clean up temp table
            self._cleanup_temp_table(temp_table)
    
    def replace_ts_data(self, df: pd.DataFrame, temp_table: str = None) -> tuple:
        """
        Replace time series data using TimeSeriesData table structure.
        
        This function deletes all existing data for the series and re-inserts fresh data.
        Unlike upsert, this ensures complete data replacement.
        
        Args:
            df: DataFrame with columns [id, date, value]
            temp_table: Name of temporary table to use (if None, generates unique name)
            
        Returns:
            Tuple of (deleted_rows, inserted_rows)
        """
        # Check if df is None or not a DataFrame
        if df is None:
            logger.warning("DataFrame is None, returning (0, 0)")
            return (0, 0)
        
        if not isinstance(df, pd.DataFrame):
            logger.warning(f"Expected DataFrame but got {type(df)}, returning (0, 0)")
            return (0, 0)
        
        if df.empty:
            return (0, 0)
        
        # Generate unique temporary table name if not provided
        if temp_table is None:
            import time
            import random
            # Use very short name to avoid SQL Server 128 char limit
            timestamp = int(time.time() * 1000) % 10000  # Last 4 digits
            random_suffix = random.randint(10, 99)  # 2 digits
            temp_table = f"#tmp_{timestamp}_{random_suffix}"
        
        # Ensure required columns
        required_cols = ['id', 'date', 'value']
        if not all(col in df.columns for col in required_cols):
            raise ValueError(f"DataFrame must contain columns: {required_cols}")
        
        try:
            logger.info(f"Starting replace operation for {len(df)} rows")
            
            with self.db_manager.engine.connect() as conn:
                try:
                    # Get the series ID from the first row (assuming all rows have same ID)
                    series_id = df['id'].iloc[0]
                    
                    # Get or create temp table (reuse if possible) - using TimeSeriesData model
                    temp_table = self._get_or_create_ts_data_temp_table(temp_table)
                    
                    # Prepare data for bulk insert
                    df_clean = df[required_cols].copy()
                    insert_sql = f"INSERT INTO {temp_table} (id, date, value) VALUES (:id, :date, :value)"
                    batch_data = [{'id': row['id'], 'date': row['date'], 'value': row['value']} for _, row in df_clean.iterrows()]
                    
                    # Insert data into temp table
                    self.execute_chunked_bulk_insert(conn, insert_sql, batch_data, "temp_ts_data")
                    
                    # Delete existing data for this series
                    delete_sql = f"DELETE FROM {self._get_schema()}.TS_Data WHERE id = :series_id"
                    delete_result = conn.execute(text(delete_sql), {'series_id': series_id})
                    deleted_rows = delete_result.rowcount
                    
                    # Insert new data
                    insert_final_sql = f"""
                    INSERT INTO {self._get_schema()}.TS_Data (id, date, value)
                    SELECT id, date, value FROM {temp_table}
                    """
                    insert_result = conn.execute(text(insert_final_sql))
                    inserted_rows = insert_result.rowcount
                    
                    conn.commit()
                    
                    logger.info(f"Replace completed: {deleted_rows} rows deleted, {inserted_rows} rows inserted")
                    
                    return (deleted_rows, inserted_rows)
                    
                except Exception as e:
                    conn.rollback()
                    logger.error(f"Replace operation failed: {e}")
                    raise
                finally:
                    # Clean up temp table
                    self._cleanup_temp_table(temp_table)
                    
        except SQLAlchemyError as e:
            logger.error(f"Replace operation failed: {e}")
            raise
    
    def get_ts_metadata(self, **filters) -> pd.DataFrame:
        """
        Get time series metadata with optional filters.
        
        Args:
            **filters: Filter criteria (id, source, ticker, field, etc.)
                      Values can be single values or lists for IN operations
            
        Returns:
            DataFrame with time series metadata
        """
        # Build optimized query using direct SQL
        stmt = select(TimeSeriesMeta)
        
        for key, value in filters.items():
            if hasattr(TimeSeriesMeta, key) and value is not None:
                # Handle both single values and lists
                if isinstance(value, list):
                    # Use IN operator for lists
                    stmt = stmt.where(getattr(TimeSeriesMeta, key).in_(value))
                else:
                    # Use equality for single values
                    stmt = stmt.where(getattr(TimeSeriesMeta, key) == value)
        
        # Execute using optimized pandas wrapper
        df = self.pd_read_sql(stmt)
        
        return df
    
    def get_ts_data(self, series_id: Union[int, List[int]], start_date: Optional[str] = None, 
                    end_date: Optional[str] = None) -> pd.DataFrame:
        """
        Get time series data for one or more series IDs.
        
        Args:
            series_id: Single series ID (int) or list of series IDs (List[int])
            start_date: Start date filter (YYYY-MM-DD format)
            end_date: End date filter (YYYY-MM-DD format)
            
        Returns:
            DataFrame with time series data
            - For single series: date index, value column
            - For multiple series: columns id, date, value
        """
        # Convert numpy types to Python native types for compatibility
        def _convert_id(id_val):
            """Convert numpy types to Python int."""
            if hasattr(id_val, 'item'):
                return id_val.item()
            elif isinstance(id_val, (int, np.integer)):
                return int(id_val)
            return id_val
        
        # Convert single int to list for consistency
        if isinstance(series_id, int):
            series_ids = [_convert_id(series_id)]
            single_series = True
        else:
            series_ids = [_convert_id(sid) for sid in series_id]
            single_series = False
        
        if not series_ids:
            return pd.DataFrame()

        # Build SQL query
        if single_series:
            # Single series: return with date index
            stmt = (
                select(TimeSeriesData.date, TimeSeriesData.value)
                .where(TimeSeriesData.id == series_ids[0])
            )
            
            if start_date:
                stmt = stmt.where(TimeSeriesData.date >= start_date)
            if end_date:
                stmt = stmt.where(TimeSeriesData.date <= end_date)
                
            stmt = stmt.order_by(TimeSeriesData.date)
            
            # Use pd.read_sql with date index
            df = self.pd_read_sql(stmt, parse_dates=['date'], index_col='date')
            
        else:
            # Multiple series: return with id, date, value columns
            stmt = (
                select(TimeSeriesData.id, TimeSeriesData.date, TimeSeriesData.value)
                .where(TimeSeriesData.id.in_(series_ids))
            )
            
            if start_date:
                stmt = stmt.where(TimeSeriesData.date >= start_date)
            if end_date:
                stmt = stmt.where(TimeSeriesData.date <= end_date)
                
            stmt = stmt.order_by(TimeSeriesData.id, TimeSeriesData.date)
            
            # Use pd.read_sql without index
            df = self.pd_read_sql(stmt, parse_dates=['date'])
        
        return df
    
    def create_ts_metadata(self, source: str, ticker: str, field: str, frequency: str, 
                          currency: str = "-", **kwargs) -> TimeSeriesMeta:
        """
        Create new time series metadata record.
        
        Args:
            source: Source code (BB, FRED, DS)
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency (D, W, M, Q, A)
            currency: Currency code
            **kwargs: Additional metadata fields
            
        Returns:
            Created TimeSeriesMeta object (detached from session)
        """
        with self.get_session() as session:
            metadata = TimeSeriesMeta(
                source=source.upper(),
                ticker=ticker.upper(),
                field=field.upper() if field else '-',
                frequency=frequency.upper(),
                currency=currency.upper() if currency else '-',
                **kwargs
            )
            
            session.add(metadata)
            session.commit()
            session.refresh(metadata)
            
            # Detach from session
            session.expunge(metadata)
            
            logger.info(f"Created metadata for {source}:{ticker}:{field}:{frequency}")
            return metadata
    
    def create_ts_metadata_with_id(self, series_id: int, source: str, ticker: str, field: str, 
                                   frequency: str, currency: str = "-", **kwargs) -> TimeSeriesMeta:
        """
        Create new time series metadata record with a specific ID (including negative IDs).
        
        This method allows you to specify the series ID manually, which is useful for
        creating entries with negative IDs or other custom ID values.
        
        Note: In SQL Server, this requires using IDENTITY_INSERT to insert specific ID values
        into an IDENTITY column.
        
        Args:
            series_id: Specific series ID to use (can be negative)
            source: Source code (BB, FRED, DS)
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency (D, W, M, Q, A)
            currency: Currency code
            **kwargs: Additional metadata fields
            
        Returns:
            Created TimeSeriesMeta object (detached from session)
            
        Raises:
            ValueError: If series_id already exists in TS_Meta
        """
        schema = self._get_schema()
        table_name = f"{schema}.TS_Meta"
        
        # Check if ID already exists
        with self.get_session() as session:
            existing = session.query(TimeSeriesMeta).filter(TimeSeriesMeta.id == series_id).first()
            if existing:
                raise ValueError(f"Series ID {series_id} already exists in TS_Meta")
        
        # Prepare metadata values
        metadata_dict = {
            'id': series_id,
            'source': source.upper(),
            'ticker': ticker.upper(),
            'field': field.upper() if field else '-',
            'frequency': frequency.upper(),
            'currency': currency.upper() if currency else '-',
        }
        
        # Add optional fields from kwargs
        optional_fields = ['sid', 'start_date', 'freq', 'cat', 'daylag', 'daylag2', 
                          'cname', 'cname2', 'note', 'tempflag', 'created_by', 'json']
        for field_name in optional_fields:
            if field_name in kwargs:
                metadata_dict[field_name] = kwargs[field_name]
        
        # Add created_at if not provided
        if 'created_at' not in metadata_dict:
            from datetime import datetime
            metadata_dict['created_at'] = datetime.now()
        
        # Build column and value lists for INSERT
        columns = list(metadata_dict.keys())
        placeholders = ', '.join([f':{col}' for col in columns])
        column_list = ', '.join(columns)
        
        # Use raw SQL with IDENTITY_INSERT to insert specific ID
        # Note: SQL Server requires brackets around schema.table names for IDENTITY_INSERT
        # Note: SQL Server requires separate execute calls for each statement
        table_name_bracketed = f"[{schema}].[TS_Meta]"
        enable_identity_sql = f"SET IDENTITY_INSERT {table_name_bracketed} ON"
        insert_sql = f"INSERT INTO {table_name_bracketed} ({column_list}) VALUES ({placeholders})"
        disable_identity_sql = f"SET IDENTITY_INSERT {table_name_bracketed} OFF"
        
        try:
            with self.db_manager.engine.connect() as conn:
                # Enable IDENTITY_INSERT
                conn.execute(text(enable_identity_sql))
                
                # Insert the record
                conn.execute(text(insert_sql), metadata_dict)
                
                # Disable IDENTITY_INSERT
                conn.execute(text(disable_identity_sql))
                
                conn.commit()
            
            logger.info(f"Created metadata with ID {series_id} for {source}:{ticker}:{field}:{frequency}")
            
            # Retrieve the created record
            with self.get_session() as session:
                metadata = session.query(TimeSeriesMeta).filter(TimeSeriesMeta.id == series_id).first()
                if metadata:
                    session.expunge(metadata)
                    return metadata
                else:
                    raise RuntimeError(f"Failed to retrieve created metadata with ID {series_id}")
                    
        except Exception as e:
            logger.error(f"Failed to create metadata with ID {series_id}: {e}")
            raise
    
    def update_ts_metadata(self, series_id: int, **updates) -> bool:
        """
        Update time series metadata record.
        
        Args:
            series_id: ID of the metadata record to update
            **updates: Fields to update
            
        Returns:
            True if update was successful, False otherwise
        """
        with self.get_session() as session:
            metadata = session.query(TimeSeriesMeta).filter(TimeSeriesMeta.id == series_id).first()
            
            if not metadata:
                logger.warning(f"Metadata record with ID {series_id} not found")
                return False
            
            # Update fields
            for key, value in updates.items():
                if hasattr(metadata, key):
                    setattr(metadata, key, value)
                else:
                    logger.warning(f"Unknown field '{key}' for TimeSeriesMeta")
            
            session.commit()
            logger.info(f"Updated metadata for series ID {series_id}")
            return True
