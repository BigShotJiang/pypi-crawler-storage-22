"""
Utility functions for MasDatabase module.

This module contains utility functions for time series data processing,
including update filters and time string parsing.
"""

from datetime import datetime, timedelta, time as dt_time
from typing import Optional, Union, Callable
import pandas as pd
import re


def update_threshold_daily_close() -> datetime:
    """
    Get the threshold time for determining if series need updating.
    
    Returns:
        datetime: The threshold time - 4pm yesterday or 4pm today if current time is after 4pm
    """
    now = datetime.now()
    today_4pm = datetime.combine(now.date(), dt_time(16, 0))  # 4:00 PM today
    
    if now >= today_4pm:
        # If it's after 4pm today, use 4pm today as threshold
        return today_4pm
    else:
        # Otherwise, use 4pm yesterday
        yesterday = now.date() - timedelta(days=1)
        return datetime.combine(yesterday, dt_time(16, 0))


def create_update_filter(threshold_input=None):
    """
    Create a callable filter function for determining which series need updating.
    
    Args:
        threshold_input: Flexible input for threshold:
            - None: Use default 4pm threshold
            - datetime: Use specific datetime
            - str: Parse time strings like '1D', '1 day ago', '6H', '2 hours ago'
            - callable: Use the callable directly as filter
            
    Returns:
        Callable that takes a pandas Series and returns True if series should be updated
    """
    # Handle different input types
    if threshold_input is None:
        threshold_time = update_threshold_daily_close()
    elif isinstance(threshold_input, datetime):
        threshold_time = threshold_input
    elif isinstance(threshold_input, str):
        threshold_time = parse_time_string(threshold_input)
    elif callable(threshold_input):
        # Return the callable directly
        return threshold_input
    else:
        raise ValueError(f"Unsupported threshold_input type: {type(threshold_input)}")
    
    def update_filter(series_row):
        """
        Filter function that determines if a series should be updated.
        
        Args:
            series_row: pandas Series with 'upd' column containing last update time
            
        Returns:
            True if series should be updated, False otherwise
        """
        upd_time = series_row.get('upd')
        if pd.isna(upd_time):
            # Series has never been updated
            return True
        else:
            # Series should be updated if last update was before threshold
            return upd_time < threshold_time
    
    return update_filter


def parse_time_string(time_str: str) -> datetime:
    """
    Parse time strings like '1D', '1 day ago', '6H', '2 hours ago' into datetime.
    
    Args:
        time_str: Time string to parse
        
    Returns:
        datetime: Parsed datetime
    """
    time_str = time_str.strip()
    now = datetime.now()
    
    # Match days: '1d', '1D', '1 day', '1 days', '1 day ago', '1 days ago', etc.
    day_match = re.match(r'(\d+)\s*[dD](?:ays?)?(?:\s+ago)?\s*$', time_str, re.IGNORECASE)
    if day_match:
        days = int(day_match.group(1))
        return now - timedelta(days=days)
    
    # Match hours: '1h', '1H', '1 hour', '1 hours', '1 hour ago', '1 hours ago', etc.
    hour_match = re.match(r'(\d+)\s*[hH](?:ours?)?(?:\s+ago)?\s*$', time_str, re.IGNORECASE)
    if hour_match:
        hours = int(hour_match.group(1))
        return now - timedelta(hours=hours)
    
    # Match minutes: '1m', '1M', '1 min', '1 mins', '1 minute', '1 minutes', '1 minute ago', '1 minutes ago', etc.
    minute_match = re.match(r'(\d+)\s*[mM](?:in(?:s|utes?)?)?(?:\s+ago)?\s*$', time_str, re.IGNORECASE)
    if minute_match:
        minutes = int(minute_match.group(1))
        return now - timedelta(minutes=minutes)
    
    raise ValueError(f"Could not parse time string: '{time_str}'")


__all__ = [
    "update_threshold_daily_close",
    "create_update_filter", 
    "parse_time_string",
]
