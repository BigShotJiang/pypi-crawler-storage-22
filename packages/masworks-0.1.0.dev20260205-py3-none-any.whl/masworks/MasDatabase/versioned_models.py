#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Versioned SQLAlchemy ORM models for time series database tables.

This module provides a flexible approach to handle multiple versions of the same
table sets (e.g., TS_Data_v1, TS_Data_v2, TS_Meta_v1, TS_Meta_v2) by creating
model factories that can generate models for different versions.

IMPORTANT: This module uses a two-phase approach to avoid SQLAlchemy mapper
initialization failures:

1. Models are created WITHOUT relationships during class definition
2. Relationships are added programmatically AFTER all models exist

This prevents "failed to locate a name" errors when relationships try to resolve
before all related classes are registered. See get_models() method for details.

For development history and what was tried, see docs/VERSIONED_MODELS_DEVELOPMENT.md
"""

from datetime import datetime, date
from typing import Optional, Dict, Any, Type, Tuple
import threading
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, Text, ForeignKey, Index, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, configure_mappers

# Create a base for versioned models
VersionedBase = declarative_base()

# Module-level cache for model classes: (schema, prefix) -> Dict[str, Type]
_MODEL_CACHE: Dict[Tuple[str, str], Dict[str, Type]] = {}
_MODEL_CACHE_LOCK = threading.Lock()


def get_schema():
    """Get the database schema from config, defaulting to 'dev'."""
    try:
        from ..config import get_default_config
        config = get_default_config()
        return config.database.schema
    except Exception:
        # Fallback to 'dev' if config is not available
        return "dev"


def normalize_version_prefix(version: Optional[str]) -> str:
    """
    Normalize a version identifier into the canonical prefix format used in table names.
    
    Table names will be: {prefix}TS_Data (e.g., 'xyz_TS_Data', 'v2_TS_Data')
    For current version, returns empty string (no prefix): 'TS_Data'

    Logic:
        - None / '' / 'current' -> '' (current/non-versioned tables: TS_Data)
        - Numeric (e.g., 2, '2') -> 'v2_' (versioned tables: v2_TS_Data)
        - Custom (e.g., 'computed', 'xyz') -> 'computed_' or 'xyz_' (custom versions: computed_TS_Data)

    Examples:
        None / '' / 'current' -> '' (table: TS_Data)
        2 / '2'               -> 'v2_' (table: v2_TS_Data)
        'computed'            -> 'computed_' (table: computed_TS_Data)
        'xyz'                 -> 'xyz_' (table: xyz_TS_Data)
    """
    if version is None:
        return ""

    if isinstance(version, int):
        return f"v{version}_"

    version_str = str(version).strip()
    if not version_str:
        return ""

    lowered = version_str.lower()
    if lowered in {"current", "latest", "none"}:
        return ""

    # Check if it's a pure number (numeric version)
    try:
        num = int(version_str)
        return f"v{num}_"
    except ValueError:
        # Not a number - treat as custom prefix
        pass

    # For custom prefixes: ensure it ends with underscore
    if version_str.endswith("_"):
        return version_str
    else:
        return f"{version_str}_"


def denormalize_version_prefix(prefix: Optional[str]) -> str:
    """
    Convert a normalized prefix to a user-facing label.
    
    Examples:
        '' -> '' (current)
        'v2_' -> '2' (numeric version)
        'computed_' -> 'computed' (custom prefix)
    """
    if not prefix:
        return ""

    prefix_str = str(prefix).strip()
    if not prefix_str:
        return ""

    # Remove trailing underscore if present
    if prefix_str.endswith("_"):
        prefix_str = prefix_str[:-1]
    
    # Handle numeric versions: 'v2' -> '2'
    if prefix_str.startswith("v") and len(prefix_str) > 1:
        try:
            num = int(prefix_str[1:])
            return str(num)
        except ValueError:
            pass
    
    return prefix_str


# Backward compatibility aliases (will be removed in future)
def normalize_version_suffix(version: Optional[str]) -> str:
    """Deprecated: Use normalize_version_prefix instead. Returns prefix format."""
    return normalize_version_prefix(version)


def denormalize_version_suffix(suffix: Optional[str]) -> str:
    """Deprecated: Use denormalize_version_prefix instead."""
    return denormalize_version_prefix(suffix)


def canonical_version_label(version: Optional[str]) -> str:
    """
    Get the canonical label for a version identifier ('' for current, '1' for v1, etc.).
    """
    return denormalize_version_prefix(normalize_version_prefix(version))


def is_current_version(version: Optional[str]) -> bool:
    """Return True if the version identifier maps to the current (non-versioned) tables."""
    return normalize_version_prefix(version) == ""


def _table_exists_in_metadata(table_name: str, schema: str) -> bool:
    """
    Check if a table already exists in VersionedBase.metadata.
    
    Args:
        table_name: Name of the table (e.g., 'buf_TS_Data')
        schema: Database schema
        
    Returns:
        bool: True if table exists in metadata
    """
    full_table_key = f"{schema}.{table_name}" if schema else table_name
    return full_table_key in VersionedBase.metadata.tables


def _find_existing_model_class(table_name: str, schema: str) -> Optional[Type]:
    """
    Find an existing model class that owns a table in metadata.
    
    Args:
        table_name: Name of the table (e.g., 'buf_TS_Data')
        schema: Database schema
        
    Returns:
        Type: Existing model class if found, None otherwise
    """
    full_table_key = f"{schema}.{table_name}" if schema else table_name
    
    # First check if table exists in metadata
    if full_table_key not in VersionedBase.metadata.tables:
        return None
    
    existing_table = VersionedBase.metadata.tables[full_table_key]
    
    # Find the class that owns this table
    # SQLAlchemy stores class registry in declarative_base
    for cls in VersionedBase.registry._class_registry.values():
        if hasattr(cls, '__table__') and cls.__table__ is existing_table:
            return cls
    
    return None


def _find_existing_model_by_class_name(class_name: str) -> Optional[Type]:
    """
    Find an existing model class by its class name.
    
    Args:
        class_name: Name of the class (e.g., 'TimeSeriesMetabuf')
        
    Returns:
        Type: Existing model class if found, None otherwise
    """
    # Check registry for class with matching name
    # Note: registry may contain _ModuleMarker objects that don't have __name__
    for cls in VersionedBase.registry._class_registry.values():
        # Only check classes that have __name__ attribute (skip _ModuleMarker objects)
        if hasattr(cls, '__name__') and cls.__name__ == class_name:
            return cls
    
    return None


class ModelFactory:
    """
    Factory class for creating versioned models.
    
    This class provides methods to create model classes for different versions
    of the same table structure, allowing you to work with multiple versions
    simultaneously.
    """
    
    @staticmethod
    def create_time_series_data_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesData model for a specific version.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        table_name = f"{prefix}TS_Data" if prefix else "TS_Data"
        meta_table_name = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        
        class TimeSeriesDataVersioned(VersionedBase):
            """
            Time series data points table (versioned).
            
            Stores the actual time series data with id, date, and value.
            """
            __tablename__ = table_name
            __table_args__ = {"schema": schema}

            id = Column(Integer, ForeignKey(f"{schema}.{meta_table_name}.id"), primary_key=True, nullable=False)
            date = Column(Date, primary_key=True, nullable=False)
            value = Column(Float, nullable=True)
            
            # Relationships are not defined here to avoid mapper initialization failures during class creation.
            # They are added programmatically after all models are created (see get_models() method).
            # Foreign keys are still defined above for database constraints.

            def __repr__(self):
                return f"<TimeSeriesData{prefix.replace('_', '') if prefix else ''}(id={self.id}, date={self.date}, value={self.value})>"
        
        # Set the class name dynamically (use prefix without underscore for class name)
        class_suffix = prefix.replace('_', '') if prefix else ''
        TimeSeriesDataVersioned.__name__ = f"TimeSeriesData{class_suffix}"
        return TimeSeriesDataVersioned
    
    @staticmethod
    def create_time_series_meta_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesMeta model for a specific version.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        table_name = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        class_suffix = prefix.replace('_', '') if prefix else ''
        
        class TimeSeriesMetaVersioned(VersionedBase):
            """
            Time series metadata table (versioned).
            
            Stores information about each time series including source, ticker, field, etc.
            """
            __tablename__ = table_name
            __table_args__ = (
                Index(f'idx_ts_meta_lookup_{class_suffix}' if class_suffix else 'idx_ts_meta_lookup', 'source', 'ticker', 'field', 'frequency', 'currency'),
                {"schema": schema}
            )
            
            # Primary key (always first)
            id = Column(Integer, primary_key=True, autoincrement=True)
            
            # Most frequently queried columns (high selectivity, small size)
            source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
            ticker = Column(String(62), nullable=False)  # Ticker symbol
            field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
            frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
            
            # Foreign key columns (for joins) - part of search index
            currency = Column(String(6), nullable=False, default="-")  # Currency
            
            # String ID (high priority, frequently used)
            sid = Column(String(62), nullable=True)  # String ID
            
            # Audit/system columns (frequently updated, small)
            start_date = Column(Date, nullable=True)  # First date of the time series
            
            # Business metadata (medium frequency, variable size)
            freq = Column(String(1), nullable=True)  # Alternative frequency field
            cat = Column(String(6), nullable=True)  # Category: Market, Econ
            daylag = Column(Integer, nullable=True)  # Data lag in days
            daylag2 = Column(Integer, nullable=True)  # Alternative lag field
            
            # Large/text columns (least frequently accessed)
            cname = Column(String(30), nullable=True)  # Short name
            cname2 = Column(String(62), nullable=True)  # Description
            note = Column(String(6), nullable=True)  # Notes
            tempflag = Column(String(6), nullable=True)  # Temporary flag
            created_at = Column(DateTime, nullable=True, default=datetime.now)  # Creation timestamp
            created_by = Column(String(50), nullable=True)  # Username who created the record
            json = Column(Text, nullable=True)  # JSON metadata for datastream
            
            # Relationships are not defined here to avoid mapper initialization failures during class creation.
            # They are added programmatically after all models are created (see get_models() method).
            # Foreign keys are still defined above for database constraints.

            def __repr__(self):
                return f"<TimeSeriesMeta{class_suffix}(id={self.id}, source={self.source}, ticker={self.ticker}, field={self.field})>"
        
        # Set the class name dynamically
        TimeSeriesMetaVersioned.__name__ = f"TimeSeriesMeta{class_suffix}"
        return TimeSeriesMetaVersioned
    
    @staticmethod
    def create_time_series_selector_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesSelector model for a specific version.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        table_name = f"{prefix}TS_Selector" if prefix else "TS_Selector"
        meta_table_name = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        class_suffix = prefix.replace('_', '') if prefix else ''
        
        class TimeSeriesSelectorVersioned(VersionedBase):
            """
            Time series selector table (versioned).
            
            Stores selector information for grouping time series.
            Now supports grouping within selections via the 'grp' column.
            """
            __tablename__ = table_name
            __table_args__ = (
                Index(f'idx_ts_selector_lookup_{class_suffix}' if class_suffix else 'idx_ts_selector_lookup', 'sel', 'ord'),
                {"schema": schema, "extend_existing": True}
            )
            
            sel = Column(String(30), primary_key=True, nullable=False)  # Selection name
            grp = Column(String(30), primary_key=True, nullable=False)  # Group within selection
            ord = Column(Integer, primary_key=True, nullable=False)  # Order within group
            id = Column(Integer, ForeignKey(f"{schema}.{meta_table_name}.id"), nullable=False)  # Series ID
            colname = Column(String(62), nullable=True)  # Column name for DataFrame
            desname = Column(String(62), nullable=True)  # Descriptive name
            uselag = Column(Boolean, nullable=False, default=False)
            align = Column(String(6), nullable=True)
            
            # Relationships are not defined here to avoid mapper initialization failures during class creation.
            # They are added programmatically after all models are created (see get_models() method).
            # Foreign keys are still defined above for database constraints.

            def __repr__(self):
                return f"<TimeSeriesSelector{class_suffix}(sel={self.sel}, grp={self.grp}, ord={self.ord}, id={self.id})>"
        
        # Set the class name dynamically
        TimeSeriesSelectorVersioned.__name__ = f"TimeSeriesSelector{class_suffix}"
        return TimeSeriesSelectorVersioned
    
    @staticmethod
    def create_time_series_status_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesStatus model for a specific version.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        table_name = f"{prefix}TS_Status" if prefix else "TS_Status"
        meta_table_name = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        class_suffix = prefix.replace('_', '') if prefix else ''
        
        class TimeSeriesStatusVersioned(VersionedBase):
            """
            Time series status table (versioned).
            
            Stores status information for time series including last update time.
            """
            __tablename__ = table_name
            __table_args__ = {"schema": schema}

            id = Column(Integer, ForeignKey(f"{schema}.{meta_table_name}.id"), primary_key=True, nullable=False)
            upd = Column(DateTime, nullable=False, default=datetime.now)  # Datetime of the timeseries when updated
            upd_start = Column(Date, nullable=False)  # Start date of the time series from where the time series is updated
            upd_end = Column(Date, nullable=False)  # Last date of the time series after update
            upd_by = Column(String(50), nullable=True)  # User who updated the time series
            
            def __repr__(self):
                return f"<TimeSeriesStatus{class_suffix}(id={self.id}, upd={self.upd}, upd_start={self.upd_start}, upd_end={self.upd_end}, upd_by={self.upd_by})>"
        
        # Set the class name dynamically
        TimeSeriesStatusVersioned.__name__ = f"TimeSeriesStatus{class_suffix}"
        return TimeSeriesStatusVersioned
    
    @staticmethod
    def create_time_series_meta_plus_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesMetaPlus view model for a specific version.
        
        This view joins TS_Meta and TS_Status tables to provide a unified interface
        for accessing both metadata and status information.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        view_name = f"{prefix}TS_MetaPlus" if prefix else "TS_MetaPlus"
        class_suffix = prefix.replace('_', '') if prefix else ''
        
        class TimeSeriesMetaPlusVersioned(VersionedBase):
            """
            Database view that joins TS_Meta and TS_Status tables (versioned).
            
            This view provides a unified interface to access both metadata and status information
            for time series, including the last update time from TS_Status.
            """
            __tablename__ = view_name
            __table_args__ = {"schema": schema, "extend_existing": True}
            
            # Primary key from TS_Meta
            id = Column(Integer, primary_key=True, nullable=False)
            
            # TS_Meta columns (simplified to match SQL view)
            source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
            ticker = Column(String(62), nullable=False)  # Ticker symbol
            field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
            frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
            currency = Column(String(6), nullable=False, default="-")  # Currency
            sid = Column(String(62), nullable=True)  # String ID
            start_date = Column(Date, nullable=True)  # First date of the time series
            freq = Column(String(1), nullable=True)  # Alternative frequency field
            daylag = Column(Integer, nullable=True)  # Data lag in days
            note = Column(String(6), nullable=True)  # Notes
            
            # TS_Status columns (nullable since not all series may have status records)
            upd = Column(DateTime, nullable=True)  # Last update time from TS_Status
            upd_start = Column(Date, nullable=True)  # Start date of last update
            upd_end = Column(Date, nullable=True)  # End date of last update
            
            def __repr__(self):
                return f"<TimeSeriesMetaPlus{class_suffix}(id={self.id}, ticker={self.ticker}, field={self.field}, source={self.source}, upd={self.upd})>"
        
        # Set the class name dynamically
        TimeSeriesMetaPlusVersioned.__name__ = f"TimeSeriesMetaPlus{class_suffix}"
        return TimeSeriesMetaPlusVersioned
    
    @staticmethod
    def create_time_series_selector_meta_plus_model(version: str = "", schema: str = None) -> Type:
        """
        Create a TimeSeriesSelectorMetaPlus view model for a specific version.
        
        This view joins TS_Selector, TS_Meta, and TS_Status tables to provide a unified
        interface for accessing selector information along with metadata and status.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            schema: Database schema (defaults to config schema)
            
        Returns:
            Type: SQLAlchemy model class
        """
        if schema is None:
            schema = get_schema()

        prefix = normalize_version_prefix(version)
        view_name = f"{prefix}TS_SelectorMetaPlus" if prefix else "TS_SelectorMetaPlus"
        class_suffix = prefix.replace('_', '') if prefix else ''
        
        class TimeSeriesSelectorMetaPlusVersioned(VersionedBase):
            """
            Database view that joins TS_Selector, TS_Meta, and TS_Status tables (versioned).
            
            This view provides a unified interface to access selector information along with
            metadata and status information for time series. It combines selector grouping
            information with the complete time series metadata and update status.
            """
            __tablename__ = view_name
            __table_args__ = {"schema": schema, "extend_existing": True}
            
            # Primary key from TS_Selector (composite key)
            sel = Column(String(30), primary_key=True, nullable=False)  # Selection name
            grp = Column(String(30), primary_key=True, nullable=False)  # Group within selection
            ord = Column(Integer, primary_key=True, nullable=False)  # Order within group
            
            # TS_Selector columns
            id = Column(Integer, nullable=False)  # Series ID (foreign key to TS_Meta)
            colname = Column(String(62), nullable=True)  # Column name for DataFrame
            desname = Column(String(62), nullable=True)  # Descriptive name
            
            # TS_Meta columns
            source = Column(String(6), nullable=False)  # Source: BB, FRED, DS
            ticker = Column(String(62), nullable=False)  # Ticker symbol
            field = Column(String(62), nullable=False, default="-")  # Field: PX_LAST, etc.
            frequency = Column(String(1), nullable=False, default="-")  # Frequency: D, W, M, Q, A
            currency = Column(String(6), nullable=False, default="-")  # Currency
            sid = Column(String(62), nullable=True)  # String ID
            start_date = Column(Date, nullable=True)  # First date of the time series
            freq = Column(String(1), nullable=True)  # Alternative frequency field
            daylag = Column(Integer, nullable=True)  # Data lag in days
            note = Column(String(6), nullable=True)  # Notes
            
            # TS_Status columns (nullable since not all series may have status records)
            upd = Column(DateTime, nullable=True)  # Last update time from TS_Status
            upd_start = Column(Date, nullable=True)  # Start date of last update
            upd_end = Column(Date, nullable=True)  # End date of last update
            
            def __repr__(self):
                return f"<TimeSeriesSelectorMetaPlus{class_suffix}(sel={self.sel}, grp={self.grp}, ord={self.ord}, id={self.id}, ticker={self.ticker}, field={self.field}, source={self.source})>"
        
        # Set the class name dynamically
        TimeSeriesSelectorMetaPlusVersioned.__name__ = f"TimeSeriesSelectorMetaPlus{class_suffix}"
        return TimeSeriesSelectorMetaPlusVersioned


class VersionedModelRegistry:
    """
    Registry for managing versioned models.
    
    This class provides a centralized way to manage and access different
    versions of the same model types.
    """
    
    def __init__(self, schema: str = None):
        """
        Initialize the registry.
        
        Args:
            schema: Database schema (defaults to config schema)
        """
        self.schema = schema or get_schema()
        self._models: Dict[str, Dict[str, Type]] = {}
        self._factory = ModelFactory()
    
    def get_models(self, version: str = "") -> Dict[str, Type]:
        """
        Get or create model classes for a specific version.
        
        This method implements a two-phase approach to avoid SQLAlchemy mapper initialization failures:
        
        1. **Phase 1: Create models without relationships**
           - Models are created with ForeignKey() definitions (for database constraints)
           - Relationships are NOT defined during class creation
           - This prevents mapper initialization failures when related classes don't exist yet
        
        2. **Phase 2: Add relationships programmatically**
           - After all models are created and registered, relationships are added using mapper.add_property()
           - This allows relationships to be available for ORM usage without causing initialization failures
        
        The method uses a module-level cache with thread-safe locking to prevent duplicate model creation
        when multiple VersionedTimeSeriesAdmin instances are created concurrently for the same version.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            
        Returns:
            Dict[str, Type]: Dictionary mapping model names to model classes
        """
        """
        Get all models for a specific version.
        
        Uses module-level cache to prevent concurrent metadata conflicts when
        multiple admin instances are created simultaneously.
        
        Args:
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            
        Returns:
            Dict[str, Type]: Dictionary of model name to model class
        """
        prefix = normalize_version_prefix(version)
        cache_key = (self.schema, prefix)
        
        # Check module-level cache first (fast path, no lock needed for read)
        if cache_key in _MODEL_CACHE:
            # Also update instance cache for backward compatibility
            self._models[prefix] = _MODEL_CACHE[cache_key]
            return _MODEL_CACHE[cache_key]
        
        # Slow path: create models (thread-safe)
        with _MODEL_CACHE_LOCK:
            # Double-check after acquiring lock (another thread might have created it)
            if cache_key in _MODEL_CACHE:
                self._models[prefix] = _MODEL_CACHE[cache_key]
                return _MODEL_CACHE[cache_key]
            
            # Check if models already exist in registry (from previous creation attempt)
            # This is the most reliable way to find existing models
            # Calculate expected class names
            class_suffix = prefix.replace('_', '') if prefix else ''
            expected_class_names = {
                'TimeSeriesMeta': f"TimeSeriesMeta{class_suffix}",
                'TimeSeriesData': f"TimeSeriesData{class_suffix}",
                'TimeSeriesSelector': f"TimeSeriesSelector{class_suffix}",
                'TimeSeriesStatus': f"TimeSeriesStatus{class_suffix}",
            }
            
            # Try to find existing models by class name
            existing_models = {}
            for model_name, class_name in expected_class_names.items():
                existing_class = _find_existing_model_by_class_name(class_name)
                if existing_class:
                    existing_models[model_name] = existing_class
            
            # If we found all core models, use them
            if len(existing_models) >= 4:
                # Try to find or create view models
                try:
                    meta_plus_class = _find_existing_model_by_class_name(f"TimeSeriesMetaPlus{class_suffix}")
                    if meta_plus_class:
                        existing_models['TimeSeriesMetaPlus'] = meta_plus_class
                    else:
                        existing_models['TimeSeriesMetaPlus'] = self._factory.create_time_series_meta_plus_model(version, self.schema)
                except:
                    pass  # View might already exist or creation might fail
                
                try:
                    selector_meta_plus_class = _find_existing_model_by_class_name(f"TimeSeriesSelectorMetaPlus{class_suffix}")
                    if selector_meta_plus_class:
                        existing_models['TimeSeriesSelectorMetaPlus'] = selector_meta_plus_class
                    else:
                        existing_models['TimeSeriesSelectorMetaPlus'] = self._factory.create_time_series_selector_meta_plus_model(version, self.schema)
                except:
                    pass  # View might already exist or creation might fail
                
                # Configure mappers to ensure relationships are resolved
                try:
                    configure_mappers()
                except:
                    pass  # Mappers might already be configured
                
                # Store in cache
                _MODEL_CACHE[cache_key] = existing_models
                self._models[prefix] = existing_models
                return existing_models
            
            # Create all model classes
            # NOTE: Models are created WITHOUT relationships to avoid mapper initialization failures.
            # Relationships are added programmatically after all models exist (see below).
            # Order matters: Meta first (no dependencies), then Data/Selector/Status (depend on Meta)
            import logging
            logger = logging.getLogger(__name__)
            
            # Create all models - relationships are not defined, so this should succeed
            meta_model = self._factory.create_time_series_meta_model(version, self.schema)
            data_model = self._factory.create_time_series_data_model(version, self.schema)
            selector_model = self._factory.create_time_series_selector_model(version, self.schema)
            status_model = self._factory.create_time_series_status_model(version, self.schema)
            meta_plus_model = self._factory.create_time_series_meta_plus_model(version, self.schema)
            selector_meta_plus_model = self._factory.create_time_series_selector_meta_plus_model(version, self.schema)
            
            # Configure mappers for basic column access
            # Since models don't have relationships defined, this should succeed
            try:
                configure_mappers()
            except Exception as e:
                logger.debug(f"Mapper configuration had issues (may be expected): {e}")
            
            # Ensure all models are registered in VersionedBase.registry
            # This is required for relationship resolution when we add them below
            for model_class in [meta_model, data_model, selector_model, status_model, meta_plus_model, selector_meta_plus_model]:
                if model_class:
                    try:
                        registry = VersionedBase.registry._class_registry
                        class_key = model_class.__name__
                        if class_key not in registry:
                            logger.warning(f"Class {class_key} not found in registry, attempting to register...")
                            registry[class_key] = model_class
                    except Exception as reg_error:
                        logger.debug(f"Could not verify/register {model_class.__name__}: {reg_error}")
            
            # Add relationships after all models are created and registered
            # This allows relationships to be available for ORM usage without causing
            # mapper initialization failures during class creation
            try:
                from sqlalchemy.orm import class_mapper
                
                # Add relationship from TimeSeriesData to TimeSeriesMeta
                # TimeSeriesData.id -> TimeSeriesMeta.id (one-to-one via foreign key)
                if data_model and meta_model:
                    try:
                        data_mapper = class_mapper(data_model)
                        meta_class_name = meta_model.__name__
                        # Use the actual class, not just the name, for better resolution
                        data_mapper.add_property(
                            'series_metadata',
                            relationship(meta_class_name, foreign_keys=[data_mapper.c.id], uselist=False, lazy='select')
                        )
                    except Exception as e:
                        logger.debug(f"Could not add series_metadata relationship to {data_model.__name__}: {e}")
                
                # Add relationships from TimeSeriesMeta to TimeSeriesData and TimeSeriesSelector
                # TimeSeriesMeta.id -> TimeSeriesData.id (one-to-many)
                # TimeSeriesMeta.id -> TimeSeriesSelector.series_id (one-to-many)
                if meta_model:
                    try:
                        meta_mapper = class_mapper(meta_model)
                        if data_model:
                            data_class_name = data_model.__name__
                            meta_mapper.add_property(
                                'data_points',
                                relationship(data_class_name, foreign_keys=[data_mapper.c.id], lazy='select')
                            )
                        if selector_model:
                            selector_class_name = selector_model.__name__
                            selector_mapper = class_mapper(selector_model)
                            meta_mapper.add_property(
                                'selectors',
                                relationship(selector_class_name, foreign_keys=[selector_mapper.c.series_id], lazy='select')
                            )
                    except Exception as e:
                        logger.debug(f"Could not add relationships to {meta_model.__name__}: {e}")
                
                # Add relationship from TimeSeriesSelector to TimeSeriesMeta
                # TimeSeriesSelector.series_id -> TimeSeriesMeta.id (many-to-one)
                if selector_model and meta_model:
                    try:
                        selector_mapper = class_mapper(selector_model)
                        meta_class_name = meta_model.__name__
                        selector_mapper.add_property(
                            'series',
                            relationship(meta_class_name, foreign_keys=[selector_mapper.c.series_id], lazy='select')
                        )
                    except Exception as e:
                        logger.debug(f"Could not add series relationship to {selector_model.__name__}: {e}")
                
                # Reconfigure mappers after adding relationships
                configure_mappers()
            except Exception as rel_error:
                logger.debug(f"Could not add relationships to versioned models: {rel_error}")
                # Relationships are optional - continue without them
            
            # Mappers should now be properly configured with relationships
            # Models are ready for use with both basic column access and ORM relationships
            
            # Build models dictionary
            models = {
                'TimeSeriesMeta': meta_model,
                'TimeSeriesData': data_model,
                'TimeSeriesSelector': selector_model,
                'TimeSeriesStatus': status_model,
                'TimeSeriesMetaPlus': meta_plus_model,
                'TimeSeriesSelectorMetaPlus': selector_meta_plus_model,
            }
            
            # Store in module-level cache
            _MODEL_CACHE[cache_key] = models
            
            # Also update instance cache for backward compatibility
            self._models[prefix] = models
            
            return models
    
    def get_model(self, model_name: str, version: str = "") -> Type:
        """
        Get a specific model for a specific version.
        
        Args:
            model_name: Name of the model (e.g., 'TimeSeriesData', 'TimeSeriesMeta')
            version: Version identifier (e.g., "v1", "2", "computed", or "" for current)
            
        Returns:
            Type: SQLAlchemy model class
        """
        models = self.get_models(version)
        return models.get(model_name)

    def get_models_for_version(self, version: Optional[str] = None) -> Dict[str, Type]:
        """Alias for compatibility with VersionedTimeSeriesBase."""
        return self.get_models(version)

    def create_models_for_version(self, version: str) -> Dict[str, Type]:
        """Create (or retrieve) models for a specific version."""
        return self.get_models(version)
    
    def get_current_models(self) -> Dict[str, Type]:
        """Get models for the current version (no suffix)."""
        return self.get_models("")
    
    def get_v1_models(self) -> Dict[str, Type]:
        """Get models for version 1."""
        return self.get_models("1")
    
    def get_v2_models(self) -> Dict[str, Type]:
        """Get models for version 2."""
        return self.get_models("2")
    
    def list_available_versions(self) -> list:
        """List all available versions in the registry."""
        versions = []
        for prefix in self._models.keys():
            versions.append(denormalize_version_prefix(prefix))
        return versions
    
    def create_custom_version(self, version: str) -> Dict[str, Type]:
        """
        Create models for a custom version.
        
        Args:
            version: Custom version identifier (e.g., "prod", "test", "computed")
            
        Returns:
            Dict[str, Type]: Dictionary of model name to model class
        """
        return self.get_models(version)


# Convenience functions for common use cases
def get_current_models(schema: str = None) -> Dict[str, Type]:
    """Get models for the current version."""
    registry = VersionedModelRegistry(schema)
    return registry.get_current_models()


def get_v1_models(schema: str = None) -> Dict[str, Type]:
    """Get models for version 1."""
    registry = VersionedModelRegistry(schema)
    return registry.get_models("1")


def get_v2_models(schema: str = None) -> Dict[str, Type]:
    """Get models for version 2."""
    registry = VersionedModelRegistry(schema)
    return registry.get_models("2")


def get_models_for_version(version: str, schema: str = None) -> Dict[str, Type]:
    """Get models for a specific version."""
    registry = VersionedModelRegistry(schema)
    return registry.get_models(version)
