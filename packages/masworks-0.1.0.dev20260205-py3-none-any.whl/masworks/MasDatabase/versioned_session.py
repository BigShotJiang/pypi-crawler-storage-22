"""
Versioned session manager for time series database operations.

Provides session management for versioned database operations, allowing
queries and operations across different versions of the same table sets.
"""
import logging
from typing import Optional, Dict, Any, List, Type, Union
from sqlalchemy.orm import Session
from sqlalchemy import text
import pandas as pd
import numpy as np

from .time_series_session import TimeSeriesSessionManager
from .versioned_models import (
    VersionedModelRegistry,
    normalize_version_prefix,
    normalize_version_suffix,  # For backward compatibility
    is_current_version,
)

logger = logging.getLogger(__name__)


def _ensure_python_type(value: Any) -> Union[int, float, str, List, None]:
    """
    Convert numpy types to Python native types for pyodbc compatibility.
    
    Args:
        value: Value that might be a numpy type
        
    Returns:
        Python native type (int, float, str, list, or None)
    """
    if value is None:
        return None
    
    # Handle numpy scalars
    if hasattr(value, 'item'):
        return value.item()
    
    # Handle numpy integer types
    if isinstance(value, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(value)
    
    # Handle numpy float types
    if isinstance(value, (np.floating, np.float64, np.float32)):
        return float(value)
    
    # Handle lists/tuples (recursively convert elements)
    if isinstance(value, (list, tuple)):
        return [_ensure_python_type(v) for v in value]
    
    # Already a Python native type
    return value


def _ensure_python_int(value: Any) -> int:
    """
    Convert value to Python native int for pyodbc compatibility.
    
    Args:
        value: Value that might be numpy.int64 or other numeric type
        
    Returns:
        Python native int
    """
    if value is None:
        raise ValueError("Cannot convert None to int")
    
    # Handle numpy scalars
    if hasattr(value, 'item'):
        return int(value.item())
    
    # Handle numpy integer types
    if isinstance(value, (np.integer, np.int64, np.int32, np.int16, np.int8)):
        return int(value)
    
    # Handle other numeric types
    return int(value)


class VersionedSessionManager:
    """
    Session manager for versioned time series operations.
    
    Provides session management for versioned database operations, allowing
    queries and operations across different versions of the same table sets.
    """
    
    def __init__(self, db_manager, model_registry: VersionedModelRegistry, chunk_size: int = 1000):
        """
        Initialize VersionedSessionManager.
        
        Args:
            db_manager: Database manager instance
            model_registry: Versioned model registry
            chunk_size: Chunk size for bulk operations
        """
        self.db_manager = db_manager
        self.model_registry = model_registry
        self.chunk_size = chunk_size
        
        # Initialize standard session manager for current version
        self.standard_session_manager = TimeSeriesSessionManager(db_manager, chunk_size)
        
        logger.info("Initialized VersionedSessionManager")
    
    def get_session(self, version: Optional[str] = None) -> Session:
        """
        Get database session for specific version.
        
        Args:
            version: Version to get session for (None for current)
            
        Returns:
            Session: SQLAlchemy session
        """
        if is_current_version(version):
            return self.standard_session_manager.get_session()
        else:
            # For versioned operations, we use the same session but with versioned models
            return self.db_manager.get_session()
    
    def get_models_for_version(self, version: Optional[str] = None) -> Dict[str, Type]:
        """
        Get model classes for a specific version.
        
        Args:
            version: Version to get models for (None for current)
            
        Returns:
            Dict[str, Type]: Dictionary of model classes
        """
        if is_current_version(version):
            # Return current models
            from .models import (
                TimeSeriesData, TimeSeriesMeta, TimeSeriesStatus, TimeSeriesSelector,
                TimeSeriesMetaPlus, TimeSeriesSelectorMetaPlus
            )
            return {
                'TimeSeriesData': TimeSeriesData,
                'TimeSeriesMeta': TimeSeriesMeta,
                'TimeSeriesStatus': TimeSeriesStatus,
                'TimeSeriesSelector': TimeSeriesSelector,
                'TimeSeriesMetaPlus': TimeSeriesMetaPlus,
                'TimeSeriesSelectorMetaPlus': TimeSeriesSelectorMetaPlus
            }
        else:
            # Return versioned models
            return self.model_registry.get_models_for_version(version)
    
    def get_table_name_for_version(self, base_table: str, version: Optional[str] = None) -> str:
        """
        Get the actual table name for a specific version.
        
        Args:
            base_table: Base table name (e.g., 'TS_Data')
            version: Version to get table name for (None for current)
            
        Returns:
            str: Full table name with version prefix (e.g., 'dev.xyz_TS_Data')
        """
        schema = self.db_manager.config.schema
        prefix = normalize_version_prefix(version)

        if not prefix:
            return f"{schema}.{base_table}"
        else:
            return f"{schema}.{prefix}{base_table}"
    
    def execute_versioned_query(self, sql: str, version: Optional[str] = None, params: Dict[str, Any] = None) -> Any:
        """
        Execute a SQL query for a specific version.
        
        Args:
            sql: SQL query to execute
            version: Version to execute query for (None for current)
            params: Query parameters
            
        Returns:
            Query result
        """
        try:
            # Replace table names with versioned names
            versioned_sql = self._replace_table_names(sql, version)
            
            with self.get_session(version) as session:
                if params:
                    result = session.execute(text(versioned_sql), params)
                else:
                    result = session.execute(text(versioned_sql))
                
                return result.fetchall()
                
        except Exception as e:
            logger.error(f"Failed to execute versioned query for version {version}: {e}")
            raise
    
    def _replace_table_names(self, sql: str, version: Optional[str] = None) -> str:
        """
        Replace table names in SQL with versioned names.
        
        Args:
            sql: Original SQL query
            version: Version to use for table names
            
        Returns:
            str: SQL with versioned table names (prefix format)
        """
        if is_current_version(version):
            return sql
        
        prefix = normalize_version_prefix(version)

        if not prefix:
            return sql

        # Define table mappings (prefix format: xyz_TS_Data)
        table_mappings = {
            'TS_Data': f'{prefix}TS_Data',
            'TS_Meta': f'{prefix}TS_Meta',
            'TS_Status': f'{prefix}TS_Status',
            'TS_Selector': f'{prefix}TS_Selector',
            'TS_MetaPlus': f'{prefix}TS_MetaPlus',
            'TS_SelectorMetaPlus': f'{prefix}TS_SelectorMetaPlus'
        }
        
        versioned_sql = sql
        for original, versioned in table_mappings.items():
            versioned_sql = versioned_sql.replace(original, versioned)
        
        return versioned_sql
    
    def get_ts_data_versioned(self, series_id: int, version: Optional[str] = None, 
                            start_date: Optional[str] = None, end_date: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get time series data for a specific version.
        
        Args:
            series_id: Series ID to retrieve
            version: Version to get data from (None for current)
            start_date: Start date filter
            end_date: End date filter
            
        Returns:
            List[Dict[str, Any]]: Time series data
        """
        try:
            # Convert numpy types to Python native types for pyodbc compatibility
            series_id = _ensure_python_int(series_id)
            
            table_name = self.get_table_name_for_version('TS_Data', version)
            
            sql = f"SELECT * FROM {table_name} WHERE id = :series_id"
            params = {'series_id': series_id}
            
            if start_date:
                sql += " AND date >= :start_date"
                params['start_date'] = start_date
            
            if end_date:
                sql += " AND date <= :end_date"
                params['end_date'] = end_date
            
            sql += " ORDER BY date"
            
            with self.get_session(version) as session:
                result = session.execute(text(sql), params).fetchall()
                return [dict(row._mapping) for row in result]
                
        except Exception as e:
            logger.error(f"Failed to get time series data for version {version}: {e}")
            raise
    
    def get_ts_metadata_versioned(self, version: Optional[str] = None, **filters) -> List[Dict[str, Any]]:
        """
        Get time series metadata for a specific version.
        
        Args:
            version: Version to get metadata from (None for current)
            **filters: Metadata filters
            
        Returns:
            List[Dict[str, Any]]: Time series metadata
        """
        try:
            table_name = self.get_table_name_for_version('TS_Meta', version)
            
            sql = f"SELECT * FROM {table_name}"
            params = {}
            
            if filters:
                conditions = []
                for key, value in filters.items():
                    if value is not None:
                        conditions.append(f"{key} = :{key}")
                        params[key] = value
                
                if conditions:
                    sql += " WHERE " + " AND ".join(conditions)
            
            with self.get_session(version) as session:
                result = session.execute(text(sql), params).fetchall()
                return [dict(row._mapping) for row in result]
                
        except Exception as e:
            logger.error(f"Failed to get time series metadata for version {version}: {e}")
            raise
    
    def create_version_tables(self, version: str) -> bool:
        """
        Create tables for a new version.
        
        Tables are created in dependency order:
        1. TS_Meta (no dependencies)
        2. TS_Data (depends on TS_Meta)
        3. TS_Selector (depends on TS_Meta)
        4. TS_Status (depends on TS_Meta)
        
        Args:
            version: Version name to create tables for
            
        Returns:
            bool: True if tables were created successfully
        """
        try:
            # Get model classes for the new version
            models = self.model_registry.create_models_for_version(version)
            
            # Define creation order to respect foreign key dependencies
            creation_order = ['TimeSeriesMeta', 'TimeSeriesData', 'TimeSeriesSelector', 'TimeSeriesStatus']
            
            with self.db_manager.get_session() as session:
                # Create tables in dependency order
                for model_name in creation_order:
                    if model_name in models:
                        model_class = models[model_name]
                        model_class.__table__.create(session.bind, checkfirst=True)
                        logger.info(f"Created table for {model_name} version {version}")
                    else:
                        logger.warning(f"Model {model_name} not found in registry for version {version}")
                
                session.commit()
                logger.info(f"Successfully created tables for version {version}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to create tables for version {version}: {e}")
            return False
    
    def migrate_data(self, from_version: str, to_version: str, 
                    table_names: Optional[List[str]] = None) -> Dict[str, int]:
        """
        Migrate data from one version to another.
        
        Args:
            from_version: Source version
            to_version: Target version
            table_names: List of table names to migrate (None for all)
            
        Returns:
            Dict[str, int]: Number of records migrated per table
        """
        try:
            if table_names is None:
                table_names = ['TS_Data', 'TS_Meta', 'TS_Status', 'TS_Selector']
            
            results = {}
            
            with self.db_manager.get_session() as session:
                for table_name in table_names:
                    try:
                        source_table = self.get_table_name_for_version(table_name, from_version)
                        target_table = self.get_table_name_for_version(table_name, to_version)
                        
                        # Check if target table exists
                        check_sql = f"""
                            SELECT COUNT(*) 
                            FROM INFORMATION_SCHEMA.TABLES 
                            WHERE TABLE_NAME = '{target_table.split('.')[-1]}'
                            AND TABLE_SCHEMA = '{target_table.split('.')[0]}'
                        """
                        
                        if session.execute(text(check_sql)).scalar() == 0:
                            logger.warning(f"Target table {target_table} does not exist, skipping")
                            results[table_name] = 0
                            continue
                        
                        # Migrate data
                        migrate_sql = f"""
                            INSERT INTO {target_table} 
                            SELECT * FROM {source_table}
                        """
                        
                        result = session.execute(text(migrate_sql))
                        session.commit()
                        
                        results[table_name] = result.rowcount
                        logger.info(f"Migrated {result.rowcount} records from {source_table} to {target_table}")
                        
                    except Exception as e:
                        logger.error(f"Failed to migrate {table_name} from {from_version} to {to_version}: {e}")
                        results[table_name] = 0
            
            return results
            
        except Exception as e:
            logger.error(f"Failed to migrate data from {from_version} to {to_version}: {e}")
            raise
    
    def get_version_statistics(self, version: Optional[str] = None) -> Dict[str, Any]:
        """
        Get statistics for a specific version.
        
        Args:
            version: Version to get statistics for (None for current)
            
        Returns:
            Dict[str, Any]: Version statistics
        """
        try:
            stats = {
                'version': version or 'current',
                'tables': {},
                'total_records': 0
            }
            
            table_names = ['TS_Data', 'TS_Meta', 'TS_Status', 'TS_Selector']
            
            with self.get_session(version) as session:
                for table_name in table_names:
                    try:
                        full_table_name = self.get_table_name_for_version(table_name, version)
                        count_sql = f"SELECT COUNT(*) FROM {full_table_name}"
                        count = session.execute(text(count_sql)).scalar()
                        stats['tables'][table_name] = count
                        stats['total_records'] += count
                    except Exception as e:
                        logger.warning(f"Could not get count for {table_name}: {e}")
                        stats['tables'][table_name] = 0
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get statistics for version {version}: {e}")
            return {
                'version': version or 'current',
                'error': str(e)
            }
    
    def create_ts_metadata_versioned(self, version: Optional[str], source: str, ticker: str, 
                                     field: str, frequency: str, currency: str = "-", **kwargs) -> Dict[str, Any]:
        """
        Create new time series metadata record in a versioned table.
        
        Args:
            version: Version to create metadata in (None for current)
            source: Source code (BB, FRED, DS)
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency (D, W, M, Q, A)
            currency: Currency code
            **kwargs: Additional metadata fields
            
        Returns:
            Dict with created metadata including 'id'
        """
        try:
            models = self.model_registry.get_models_for_version(version)
            TimeSeriesMeta = models.get('TimeSeriesMeta')
            
            if not TimeSeriesMeta:
                raise ValueError(f"TimeSeriesMeta model not found for version {version}")
            
            # Create the metadata instance
            # Mappers should be properly configured by get_models_for_version()
            with self.get_session(version) as session:
                metadata = TimeSeriesMeta(
                    source=source.upper(),
                    ticker=ticker.upper(),
                    field=field.upper() if field else '-',
                    frequency=frequency.upper(),
                    currency=currency.upper() if currency else '-',
                    **kwargs
                )
                
                session.add(metadata)
                session.commit()
                session.refresh(metadata)
                
                # Convert to dict
                result = {
                    'id': metadata.id,
                    'source': metadata.source,
                    'ticker': metadata.ticker,
                    'field': metadata.field,
                    'frequency': metadata.frequency,
                    'currency': metadata.currency
                }
                
                logger.info(f"Created metadata for {source}:{ticker}:{field}:{frequency} in version {version}")
                return result
                
        except Exception as e:
            logger.error(f"Failed to create metadata for version {version}: {e}")
            raise
    
    def create_ts_metadata_with_id_versioned(self, version: Optional[str], series_id: int, 
                                              source: str, ticker: str, field: str, 
                                              frequency: str, currency: str = "-", **kwargs) -> Dict[str, Any]:
        """
        Create new time series metadata record with a specific ID (including negative IDs) in a versioned table.
        
        This method allows you to specify the series ID manually, which is useful for
        creating entries with negative IDs or other custom ID values in versioned tables.
        
        Note: In SQL Server, this requires using IDENTITY_INSERT to insert specific ID values
        into an IDENTITY column.
        
        Args:
            version: Version to create metadata in (None for current)
            series_id: Specific series ID to use (can be negative)
            source: Source code (BB, FRED, DS, CALC, etc.)
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency (D, W, M, Q, A)
            currency: Currency code
            **kwargs: Additional metadata fields
            
        Returns:
            Dict with created metadata including 'id'
            
        Raises:
            ValueError: If series_id already exists in the versioned TS_Meta table
        """
        table_name = self.get_table_name_for_version('TS_Meta', version)
        
        # Convert numpy types to Python native types for pyodbc compatibility
        series_id = _ensure_python_int(series_id)
        
        # Check if ID already exists
        check_sql = f"SELECT id FROM {table_name} WHERE id = :series_id"
        with self.get_session(version) as session:
            result = session.execute(text(check_sql), {'series_id': series_id}).fetchone()
            if result:
                raise ValueError(f"Series ID {series_id} already exists in TS_Meta for version {version}")
        
        # Prepare metadata values
        metadata_dict = {
            'id': series_id,
            'source': source.upper(),
            'ticker': ticker.upper(),
            'field': field.upper() if field else '-',
            'frequency': frequency.upper(),
            'currency': currency.upper() if currency else '-',
        }
        
        # Add optional fields from kwargs
        optional_fields = ['sid', 'start_date', 'freq', 'cat', 'daylag', 'daylag2', 
                          'cname', 'cname2', 'note', 'tempflag', 'created_by', 'json']
        for field_name in optional_fields:
            if field_name in kwargs:
                metadata_dict[field_name] = kwargs[field_name]
        
        # Add created_at if not provided
        if 'created_at' not in metadata_dict:
            from datetime import datetime
            metadata_dict['created_at'] = datetime.now()
        
        # Build column and value lists for INSERT
        columns = list(metadata_dict.keys())
        placeholders = ', '.join([f':{col}' for col in columns])
        column_list = ', '.join(columns)
        
        # Use raw SQL with IDENTITY_INSERT to insert specific ID
        # Note: SQL Server requires brackets around schema.table names for IDENTITY_INSERT
        # Note: SQL Server requires separate execute calls for each statement
        # table_name already includes schema, so we need to bracket it properly
        # table_name format: "schema.table" or "schema.prefix_table"
        # Split and bracket each part
        if '.' in table_name:
            schema_part, table_part = table_name.split('.', 1)
            table_name_bracketed = f"[{schema_part}].[{table_part}]"
        else:
            table_name_bracketed = f"[{table_name}]"
        
        enable_identity_sql = f"SET IDENTITY_INSERT {table_name_bracketed} ON"
        insert_sql = f"INSERT INTO {table_name_bracketed} ({column_list}) VALUES ({placeholders})"
        disable_identity_sql = f"SET IDENTITY_INSERT {table_name_bracketed} OFF"
        
        try:
            with self.get_session(version) as session:
                # Enable IDENTITY_INSERT
                session.execute(text(enable_identity_sql))
                
                # Insert the record
                session.execute(text(insert_sql), metadata_dict)
                
                # Disable IDENTITY_INSERT
                session.execute(text(disable_identity_sql))
                
                session.commit()
            
            logger.info(f"Created metadata with ID {series_id} for {source}:{ticker}:{field}:{frequency} in version {version}")
            
            # Retrieve the created record
            created = self.get_ts_metadata_versioned(version, id=series_id)
            if created and len(created) > 0:
                return created[0]
            else:
                raise RuntimeError(f"Failed to retrieve created metadata with ID {series_id} in version {version}")
                
        except Exception as e:
            logger.error(f"Failed to create metadata with ID {series_id} for version {version}: {e}")
            raise
    
    def update_ts_metadata_versioned(self, version: Optional[str], series_id: int, **updates) -> bool:
        """
        Update time series metadata record in a versioned table.
        
        Args:
            version: Version to update metadata in (None for current)
            series_id: ID of the metadata record to update
            **updates: Fields to update
            
        Returns:
            True if update was successful, False otherwise
        """
        try:
            models = self.model_registry.get_models_for_version(version)
            TimeSeriesMeta = models.get('TimeSeriesMeta')
            
            if not TimeSeriesMeta:
                logger.error(f"TimeSeriesMeta model not found for version {version}")
                return False
            
            with self.get_session(version) as session:
                metadata = session.query(TimeSeriesMeta).filter(TimeSeriesMeta.id == series_id).first()
                
                if not metadata:
                    logger.warning(f"Metadata record with ID {series_id} not found in version {version}")
                    return False
                
                # Update fields
                for key, value in updates.items():
                    if hasattr(metadata, key):
                        setattr(metadata, key, value)
                    else:
                        logger.warning(f"Unknown field '{key}' for TimeSeriesMeta")
                
                session.commit()
                logger.info(f"Updated metadata for series ID {series_id} in version {version}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to update metadata for version {version}: {e}")
            return False
    
    def upsert_ts_data_versioned(self, version: Optional[str], df: pd.DataFrame) -> tuple:
        """
        Upsert time series data in a versioned table.
        
        Args:
            version: Version to upsert data to (None for current)
            df: DataFrame with columns [id, date, value]
            
        Returns:
            Tuple of (updated_rows, inserted_rows)
        """
        try:
            import pandas as pd
            from sqlalchemy import text
            
            if df is None or df.empty:
                return (0, 0)
            
            # Ensure required columns
            required_cols = ['id', 'date', 'value']
            if not all(col in df.columns for col in required_cols):
                raise ValueError(f"DataFrame must contain columns: {required_cols}")
            
            table_name = self.get_table_name_for_version('TS_Data', version)
            
            # Generate unique temporary table name
            import time
            import random
            timestamp = int(time.time() * 1000) % 10000
            random_suffix = random.randint(10, 99)
            temp_table = f"#tmp_{timestamp}_{random_suffix}"
            
            schema = self._get_schema()
            
            with self.db_manager.engine.connect() as conn:
                try:
                    # Create temp table
                    create_temp_sql = f"""
                        CREATE TABLE {temp_table} (
                            id INT NOT NULL,
                            date DATE NOT NULL,
                            value FLOAT NULL
                        )
                    """
                    conn.execute(text(create_temp_sql))
                    
                    # Insert data into temp table in chunks
                    df_clean = df[required_cols].copy()
                    insert_sql = f"INSERT INTO {temp_table} (id, date, value) VALUES (:id, :date, :value)"
                    
                    # Prepare batch data
                    batch_data = [
                        {
                            'id': int(row['id']),
                            'date': pd.to_datetime(row['date']).date() if isinstance(row['date'], str) else row['date'],
                            'value': float(row['value']) if pd.notna(row['value']) else None
                        }
                        for _, row in df_clean.iterrows()
                    ]
                    
                    # Insert in chunks
                    chunk_size = self.chunk_size
                    for i in range(0, len(batch_data), chunk_size):
                        chunk = batch_data[i:i + chunk_size]
                        conn.execute(text(insert_sql), chunk)
                    
                    # Perform MERGE - table_name already includes schema
                    merge_sql = f"""
                    MERGE {table_name} AS target
                    USING {temp_table} AS source
                    ON target.id = source.id AND target.date = source.date
                    WHEN MATCHED THEN
                        UPDATE SET value = source.value
                    WHEN NOT MATCHED THEN
                        INSERT (id, date, value) VALUES (source.id, source.date, source.value);
                    """
                    
                    result = conn.execute(text(merge_sql))
                    conn.commit()
                    
                    upserted_rows = len(df_clean)
                    logger.info(f"Upserted {upserted_rows} rows to {table_name}")
                    
                    return (upserted_rows, 0)
                    
                finally:
                    # Clean up temp table
                    try:
                        conn.execute(text(f"DROP TABLE IF EXISTS {temp_table}"))
                    except Exception as e:
                        logger.warning(f"Failed to drop temp table {temp_table}: {e}")
                        
        except Exception as e:
            logger.error(f"Failed to upsert data for version {version}: {e}")
            raise
    
    def replace_ts_data_versioned(self, version: Optional[str], df: pd.DataFrame, series_id: int) -> tuple:
        """
        Replace time series data in a versioned table (delete existing and insert new).
        
        Args:
            version: Version to replace data in (None for current)
            df: DataFrame with columns [id, date, value]
            series_id: Series ID to replace data for
            
        Returns:
            Tuple of (deleted_rows, inserted_rows)
        """
        try:
            import pandas as pd
            from sqlalchemy import text
            
            table_name = self.get_table_name_for_version('TS_Data', version)
            schema = self._get_schema()
            
            with self.get_session(version) as session:
                # Delete existing data for this series
                delete_sql = text(f"DELETE FROM {table_name} WHERE id = :series_id")
                result = session.execute(delete_sql, {'series_id': series_id})
                deleted_rows = result.rowcount
                
                # Insert new data
                if not df.empty:
                    df_clean = df[['id', 'date', 'value']].copy()
                    insert_data = [
                        {
                            'id': int(row['id']),
                            'date': pd.to_datetime(row['date']).date() if isinstance(row['date'], str) else row['date'],
                            'value': float(row['value']) if pd.notna(row['value']) else None
                        }
                        for _, row in df_clean.iterrows()
                    ]
                    
                    models = self.model_registry.get_models_for_version(version)
                    TimeSeriesData = models.get('TimeSeriesData')
                    if not TimeSeriesData:
                        raise ValueError(f"TimeSeriesData model not found for version {version}")
                    session.bulk_insert_mappings(TimeSeriesData, insert_data)
                    inserted_rows = len(insert_data)
                else:
                    inserted_rows = 0
                
                session.commit()
                logger.info(f"Replaced data for series {series_id} in {table_name}: {deleted_rows} deleted, {inserted_rows} inserted")
                
                return (deleted_rows, inserted_rows)
                
        except Exception as e:
            logger.error(f"Failed to replace data for version {version}: {e}")
            raise
    
    def _get_meta_plus_view_sql(self, version: Optional[str] = None) -> str:
        """
        Get SQL DDL for creating TS_MetaPlus view for a specific version.
        
        Args:
            version: Version identifier (None for current)
            
        Returns:
            str: CREATE VIEW SQL statement
        """
        schema = self._get_schema()
        prefix = normalize_version_prefix(version) if version else ""
        
        meta_table = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        status_table = f"{prefix}TS_Status" if prefix else "TS_Status"
        view_name = f"{prefix}TS_MetaPlus" if prefix else "TS_MetaPlus"
        
        sql = f"""
        CREATE VIEW [{schema}].[{view_name}] AS
        SELECT 
            m.id,
            m.source,
            m.ticker,
            m.field,
            m.frequency,
            m.currency,
            m.sid,
            m.start_date,
            m.freq,
            m.daylag,
            m.note,
            s.upd,
            s.upd_start,
            s.upd_end
        FROM [{schema}].[{meta_table}] m
        LEFT JOIN [{schema}].[{status_table}] s ON m.id = s.id;
        """
        return sql.strip()
    
    def _get_selector_meta_plus_view_sql(self, version: Optional[str] = None) -> str:
        """
        Get SQL DDL for creating TS_SelectorMetaPlus view for a specific version.
        
        Args:
            version: Version identifier (None for current)
            
        Returns:
            str: CREATE VIEW SQL statement
        """
        schema = self._get_schema()
        prefix = normalize_version_prefix(version) if version else ""
        
        selector_table = f"{prefix}TS_Selector" if prefix else "TS_Selector"
        meta_table = f"{prefix}TS_Meta" if prefix else "TS_Meta"
        status_table = f"{prefix}TS_Status" if prefix else "TS_Status"
        view_name = f"{prefix}TS_SelectorMetaPlus" if prefix else "TS_SelectorMetaPlus"
        
        sql = f"""
        CREATE VIEW [{schema}].[{view_name}] AS
        SELECT 
            sel.sel,
            sel.grp,
            sel.ord,
            sel.id,
            sel.colname,
            sel.desname,
            m.source,
            m.ticker,
            m.field,
            m.frequency,
            m.currency,
            m.sid,
            m.start_date,
            m.freq,
            m.daylag,
            m.note,
            s.upd,
            s.upd_start,
            s.upd_end
        FROM [{schema}].[{selector_table}] sel
        INNER JOIN [{schema}].[{meta_table}] m ON sel.id = m.id
        LEFT JOIN [{schema}].[{status_table}] s ON m.id = s.id;
        """
        return sql.strip()
    
    def view_exists(self, view_name: str, version: Optional[str] = None) -> bool:
        """
        Check if a view exists in the database.
        
        Args:
            view_name: Base view name (e.g., 'TS_MetaPlus')
            version: Version identifier (None for current)
            
        Returns:
            bool: True if view exists, False otherwise
        """
        schema = self._get_schema()
        prefix = normalize_version_prefix(version) if version else ""
        full_view_name = f"{prefix}{view_name}" if prefix else view_name
        
        try:
            with self.get_session(version) as session:
                sql = text("""
                    SELECT COUNT(*) 
                    FROM INFORMATION_SCHEMA.VIEWS 
                    WHERE TABLE_SCHEMA = :schema 
                    AND TABLE_NAME = :view_name
                """)
                result = session.execute(sql, {"schema": schema, "view_name": full_view_name}).scalar()
                return result > 0
        except Exception as e:
            logger.error(f"Error checking if view {full_view_name} exists: {e}")
            return False
    
    def create_views_for_version(self, version: Optional[str] = None, if_not_exists: bool = True) -> Dict[str, bool]:
        """
        Create database views for a specific version.
        
        Args:
            version: Version identifier (None for current)
            if_not_exists: If True, skip creation if view already exists
            
        Returns:
            Dict[str, bool]: Dictionary mapping view names to creation success status
        """
        results = {}
        schema = self._get_schema()
        prefix = normalize_version_prefix(version) if version else ""
        
        # Create TS_MetaPlus view
        meta_plus_view = f"{prefix}TS_MetaPlus" if prefix else "TS_MetaPlus"
        if if_not_exists and self.view_exists("TS_MetaPlus", version):
            logger.info(f"View {meta_plus_view} already exists, skipping creation")
            results[meta_plus_view] = True
        else:
            try:
                with self.get_session(version) as session:
                    # Drop view if it exists (handle SQL Server compatibility)
                    try:
                        drop_sql = text(f"DROP VIEW [{schema}].[{meta_plus_view}]")
                        session.execute(drop_sql)
                        session.commit()
                    except Exception:
                        # View doesn't exist, which is fine
                        pass
                    
                    # Create view
                    create_sql = text(self._get_meta_plus_view_sql(version))
                    session.execute(create_sql)
                    session.commit()
                    logger.info(f"Created view {meta_plus_view}")
                    results[meta_plus_view] = True
            except Exception as e:
                logger.error(f"Failed to create view {meta_plus_view}: {e}")
                results[meta_plus_view] = False
        
        # Create TS_SelectorMetaPlus view
        selector_meta_plus_view = f"{prefix}TS_SelectorMetaPlus" if prefix else "TS_SelectorMetaPlus"
        if if_not_exists and self.view_exists("TS_SelectorMetaPlus", version):
            logger.info(f"View {selector_meta_plus_view} already exists, skipping creation")
            results[selector_meta_plus_view] = True
        else:
            try:
                with self.get_session(version) as session:
                    # Drop view if it exists (handle SQL Server compatibility)
                    try:
                        drop_sql = text(f"DROP VIEW [{schema}].[{selector_meta_plus_view}]")
                        session.execute(drop_sql)
                        session.commit()
                    except Exception:
                        # View doesn't exist, which is fine
                        pass
                    
                    # Create view
                    create_sql = text(self._get_selector_meta_plus_view_sql(version))
                    session.execute(create_sql)
                    session.commit()
                    logger.info(f"Created view {selector_meta_plus_view}")
                    results[selector_meta_plus_view] = True
            except Exception as e:
                logger.error(f"Failed to create view {selector_meta_plus_view}: {e}")
                results[selector_meta_plus_view] = False
        
        return results
    
    def drop_views_for_version(self, version: Optional[str] = None) -> Dict[str, bool]:
        """
        Drop database views for a specific version.
        
        Args:
            version: Version identifier (None for current)
            
        Returns:
            Dict[str, bool]: Dictionary mapping view names to drop success status
        """
        results = {}
        schema = self._get_schema()
        prefix = normalize_version_prefix(version) if version else ""
        
        views = [
            f"{prefix}TS_MetaPlus" if prefix else "TS_MetaPlus",
            f"{prefix}TS_SelectorMetaPlus" if prefix else "TS_SelectorMetaPlus"
        ]
        
        for view_name in views:
            try:
                with self.get_session(version) as session:
                    drop_sql = text(f"DROP VIEW [{schema}].[{view_name}]")
                    session.execute(drop_sql)
                    session.commit()
                    logger.info(f"Dropped view {view_name}")
                    results[view_name] = True
            except Exception as e:
                # View might not exist, log but don't fail
                logger.warning(f"Could not drop view {view_name} (may not exist): {e}")
                results[view_name] = False
        
        return results
    
    def _get_schema(self) -> str:
        """Get the database schema."""
        try:
            from ..config import get_default_config
            config = get_default_config()
            return config.database.schema
        except Exception:
            return "dev"
    
    def close(self):
        """Close database connections and cleanup resources."""
        if hasattr(self, 'standard_session_manager'):
            self.standard_session_manager.close()
        logger.info("VersionedSessionManager closed")
