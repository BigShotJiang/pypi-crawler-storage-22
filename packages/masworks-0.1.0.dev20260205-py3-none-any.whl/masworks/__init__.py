"""
MasWorks - Financial Time Series Library

A comprehensive library for managing financial time series data with support
for multiple data sources and SQL Server storage.
"""

__version__ = "0.1.0.dev20260205"
__author__ = "Internal Team"

from .mas_time_series_reader import MasTimeSeriesReader
from .mas_time_series_admin import MasTimeSeriesAdmin
from .MasDatabase.context import TimeSeriesContext
from .config import Config, get_default_config
from .types import DateInput, DateString, DateObject, DateOutput, DateFormat

__all__ = [
    "MasTimeSeriesReader",
    "MasTimeSeriesAdmin", 
    "TimeSeriesContext",
    "Config", 
    "get_default_config",
    "DateInput",
    "DateString", 
    "DateObject",
    "DateOutput",
    "DateFormat",
]
