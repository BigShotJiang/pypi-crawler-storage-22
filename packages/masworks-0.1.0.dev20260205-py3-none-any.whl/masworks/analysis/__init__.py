"""
Analysis module for MasWorks library.

Provides time series analysis, backtesting, and modeling utilities.
"""

from .backtesting import ModelBacktester, TimeSeriesDataIterator
from .modeling import TimeSeriesModelExecutor

__all__ = [
    "ModelBacktester",
    "TimeSeriesDataIterator", 
    "TimeSeriesModelExecutor",
]
