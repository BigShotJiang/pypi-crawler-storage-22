"""
Backtesting and model evaluation utilities.
"""
import pandas as pd
import numpy as np
from typing import Optional, Any, Callable, Generator, Tuple
import logging

logger = logging.getLogger(__name__)


class TimeSeriesDataIterator:
    """Iterator for time series data with expanding or rolling windows."""
    
    def __init__(self, X: pd.DataFrame, y: pd.Series, 
                 initial_window: int = 12, window_type: str = 'expanding',
                 rolling_window: int = 12):
        """
        Initialize data iterator.
        
        Args:
            X: Feature matrix
            y: Target series
            initial_window: Initial training window size
            window_type: 'expanding' or 'rolling'
            rolling_window: Window size for rolling (if window_type='rolling')
        """
        # Align X and y on common index
        common_index = X.index.intersection(y.index)
        self.X = X.loc[common_index].values
        self.y = y.loc[common_index].values
        self.dates = common_index
        
        self.initial_window = initial_window
        self.window_type = window_type
        self.rolling_window = rolling_window
        
        self.current_index = initial_window
        self.max_index = len(self.X)
    
    def __iter__(self):
        """Reset iterator."""
        self.current_index = self.initial_window
        return self
    
    def __next__(self) -> Tuple[np.ndarray, np.ndarray, Any]:
        """
        Get next training set.
        
        Returns:
            Tuple of (X_train, y_train, current_date)
        """
        if self.current_index >= self.max_index:
            raise StopIteration
        
        # Get training data based on window type
        if self.window_type == 'expanding':
            X_train = self.X[:self.current_index]
            y_train = self.y[:self.current_index]
        elif self.window_type == 'rolling':
            start_idx = max(0, self.current_index - self.rolling_window)
            X_train = self.X[start_idx:self.current_index]
            y_train = self.y[start_idx:self.current_index]
        else:
            raise ValueError(f"Unknown window_type: {self.window_type}")
        
        current_date = self.dates[self.current_index - 1]
        
        self.current_index += 1
        
        return X_train, y_train, current_date
    
    def peek_next(self) -> Tuple[Optional[np.ndarray], Optional[Any], Optional[Any]]:
        """
        Peek at next prediction point without advancing iterator.
        
        Returns:
            Tuple of (X_next, y_next, date_next) or (None, None, None) if at end
        """
        if self.current_index >= self.max_index:
            return None, None, None
        
        X_next = self.X[self.current_index].reshape(1, -1)
        y_next = self.y[self.current_index]
        date_next = self.dates[self.current_index]
        
        return X_next, y_next, date_next


class ModelBacktester:
    """Backtesting framework for time series models."""
    
    def __init__(self, X: pd.DataFrame, y: pd.Series, 
                 algorithm: Optional[Callable] = None):
        """
        Initialize backtester.
        
        Args:
            X: Feature matrix
            y: Target series
            algorithm: Model algorithm class (default: LinearRegression)
        """
        self.X = X
        self.y = y
        
        if algorithm is None:
            from sklearn.linear_model import LinearRegression
            self.algorithm = LinearRegression
        else:
            self.algorithm = algorithm
    
    def preprocess_data(self, missing_value: float = -1000) -> 'ModelBacktester':
        """
        Preprocess data by handling missing values.
        
        Args:
            missing_value: Value to replace NaN with
            
        Returns:
            Self for method chaining
        """
        # Align X and y on common index
        common_index = self.y.index.intersection(self.X.index)
        self.y = self.y.loc[common_index]
        self.X = self.X.loc[common_index]
        
        # Fill missing values
        self.X = self.X.fillna(missing_value)
        
        return self
    
    def expanding_window_backtest(self, initial_window: int, 
                                 gap: int = 0) -> Tuple[pd.DataFrame, Any]:
        """
        Run expanding window backtest.
        
        Args:
            initial_window: Initial training window size
            gap: Gap between training and prediction (for avoiding look-ahead bias)
            
        Returns:
            Tuple of (results_df, final_model)
        """
        # Align data
        common_index = self.y.index.intersection(self.X.index)
        y_aligned = self.y.loc[common_index]
        X_aligned = self.X.loc[common_index]
        
        predictions = []
        
        for end_idx in range(initial_window, len(y_aligned)):
            # Training data (with gap)
            train_end = end_idx - gap
            if train_end <= 0:
                continue
            
            X_train = X_aligned.iloc[:train_end]
            y_train = y_aligned.iloc[:train_end]
            
            # Prediction point
            X_pred = X_aligned.iloc[[end_idx]]
            y_actual = y_aligned.iloc[end_idx]
            
            # Fit model and predict
            model = self.algorithm()
            model.fit(X_train, y_train)
            y_pred = model.predict(X_pred)[0]
            
            predictions.append({
                'date': X_aligned.index[end_idx],
                'actual': y_actual,
                'predicted': y_pred
            })
            
            logger.debug(f"Backtest step {end_idx}/{len(y_aligned)}")
        
        # Create results DataFrame
        results_df = pd.DataFrame(predictions).set_index('date')
        
        # Fit final model on all available data
        final_model = self.algorithm()
        final_model.fit(X_aligned, y_aligned)
        
        # Add out-of-sample predictions if X extends beyond y
        X_future = self.X.loc[self.X.index > X_aligned.index[-1]]
        if not X_future.empty:
            future_preds = pd.DataFrame({
                'predicted': final_model.predict(X_future),
                'actual': np.nan
            }, index=X_future.index)
            
            results_df = pd.concat([results_df, future_preds])
        
        return results_df, final_model
    
    def rolling_window_backtest(self, window_size: int, 
                               gap: int = 0) -> Tuple[pd.DataFrame, Any]:
        """
        Run rolling window backtest.
        
        Args:
            window_size: Size of rolling training window
            gap: Gap between training and prediction
            
        Returns:
            Tuple of (results_df, final_model)
        """
        # Align data
        common_index = self.y.index.intersection(self.X.index)
        y_aligned = self.y.loc[common_index]
        X_aligned = self.X.loc[common_index]
        
        predictions = []
        
        for end_idx in range(window_size, len(y_aligned)):
            # Training data (rolling window with gap)
            train_end = end_idx - gap
            train_start = max(0, train_end - window_size)
            
            if train_end <= train_start:
                continue
            
            X_train = X_aligned.iloc[train_start:train_end]
            y_train = y_aligned.iloc[train_start:train_end]
            
            # Prediction point
            X_pred = X_aligned.iloc[[end_idx]]
            y_actual = y_aligned.iloc[end_idx]
            
            # Fit model and predict
            model = self.algorithm()
            model.fit(X_train, y_train)
            y_pred = model.predict(X_pred)[0]
            
            predictions.append({
                'date': X_aligned.index[end_idx],
                'actual': y_actual,
                'predicted': y_pred
            })
        
        # Create results DataFrame
        results_df = pd.DataFrame(predictions).set_index('date')
        
        # Fit final model on last window
        final_X = X_aligned.iloc[-window_size:]
        final_y = y_aligned.iloc[-window_size:]
        final_model = self.algorithm()
        final_model.fit(final_X, final_y)
        
        return results_df, final_model
    
    def all_sample_fit(self) -> Tuple[pd.DataFrame, Any]:
        """
        Fit model on all available data (no backtesting).
        
        Returns:
            Tuple of (results_df, model)
        """
        # Align data
        common_index = self.y.index.intersection(self.X.index)
        y_aligned = self.y.loc[common_index]
        X_aligned = self.X.loc[common_index]
        
        # Fit model
        model = self.algorithm()
        model.fit(X_aligned, y_aligned)
        
        # Predict on all data (including out-of-sample)
        predictions = model.predict(self.X)
        
        results_df = pd.DataFrame({
            'predicted': predictions,
            'actual': self.y.reindex(self.X.index)
        }, index=self.X.index)
        
        return results_df, model
    
    def calculate_metrics(self, results_df: pd.DataFrame) -> dict:
        """
        Calculate performance metrics from backtest results.
        
        Args:
            results_df: DataFrame with 'actual' and 'predicted' columns
            
        Returns:
            Dictionary of performance metrics
        """
        # Filter to in-sample data only
        in_sample = results_df.dropna()
        
        if in_sample.empty:
            return {}
        
        actual = in_sample['actual']
        predicted = in_sample['predicted']
        
        # Calculate metrics
        mse = np.mean((actual - predicted) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(actual - predicted))
        
        # R-squared
        ss_res = np.sum((actual - predicted) ** 2)
        ss_tot = np.sum((actual - np.mean(actual)) ** 2)
        r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        
        # Directional accuracy
        actual_direction = np.sign(actual.diff().dropna())
        pred_direction = np.sign(predicted.diff().dropna())
        directional_accuracy = np.mean(actual_direction == pred_direction)
        
        return {
            'mse': mse,
            'rmse': rmse,
            'mae': mae,
            'r_squared': r2,
            'directional_accuracy': directional_accuracy,
            'n_observations': len(in_sample)
        }
