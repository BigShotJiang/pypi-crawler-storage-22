"""
Time series modeling utilities.
"""
import pandas as pd
import numpy as np
from typing import Optional, Any, Dict, List
import logging
from sklearn.linear_model import LinearRegression

from .backtesting import TimeSeriesDataIterator

logger = logging.getLogger(__name__)


class TimeSeriesModelExecutor:
    """Execute time series models with different prediction strategies."""
    
    def __init__(self, model_class: Optional[Any] = None, 
                 model_args: Optional[Dict] = None,
                 data_iterator: Optional[TimeSeriesDataIterator] = None):
        """
        Initialize model executor.
        
        Args:
            model_class: Model class to use (default: LinearRegression)
            model_args: Arguments for model initialization
            data_iterator: Data iterator for training/prediction
        """
        self.model_class = model_class or LinearRegression
        self.model_args = model_args or {}
        self.data_iterator = data_iterator
    
    def run_predictions(self, prediction_point: str = 'next') -> List[List]:
        """
        Run model predictions using the data iterator.
        
        Args:
            prediction_point: 'next' for next period, 'current' for current period
            
        Returns:
            List of [actual, predicted, date] for each prediction
        """
        if self.data_iterator is None:
            raise ValueError("Data iterator not set")
        
        results = []
        
        for X_train, y_train, current_date in self.data_iterator:
            # Initialize and fit model
            if self.model_args:
                model = self.model_class(**self.model_args)
            else:
                model = self.model_class()
            
            model.fit(X_train, y_train)
            
            if prediction_point == 'next':
                # Predict next period
                X_next, y_next, date_next = self.data_iterator.peek_next()
                if y_next is not None:
                    y_pred = model.predict(X_next)[0]
                    results.append([y_next, y_pred, date_next])
            
            elif prediction_point == 'current':
                # Predict current period (last training point)
                X_current = X_train[-1:].reshape(1, -1)
                y_current = y_train[-1]
                y_pred = model.predict(X_current)[0]
                results.append([y_current, y_pred, current_date])
            
            else:
                raise ValueError(f"Unknown prediction_point: {prediction_point}")
        
        return results
    
    def run_predictions_df(self, prediction_point: str = 'next') -> pd.DataFrame:
        """
        Run predictions and return as DataFrame.
        
        Args:
            prediction_point: 'next' for next period, 'current' for current period
            
        Returns:
            DataFrame with actual, predicted, and date columns
        """
        results = self.run_predictions(prediction_point)
        
        if not results:
            return pd.DataFrame(columns=['actual', 'predicted', 'date'])
        
        df = pd.DataFrame(results, columns=['actual', 'predicted', 'date'])
        df = df.set_index('date')
        
        return df


class YeoJohnsonTransformer:
    """Yeo-Johnson power transformation for time series."""
    
    def __init__(self):
        """Initialize transformer."""
        try:
            from sklearn.preprocessing import PowerTransformer
            self.transformer = PowerTransformer(method='yeo-johnson')
        except ImportError:
            raise ImportError("sklearn required for YeoJohnsonTransformer")
    
    def fit_transform(self, series: pd.Series) -> pd.Series:
        """
        Fit transformer and transform series.
        
        Args:
            series: Input time series
            
        Returns:
            Transformed series
        """
        if not isinstance(series, pd.Series):
            raise ValueError("Input must be pandas Series")
        
        values = series.values.reshape(-1, 1)
        self.transformer.fit(values)
        transformed = self.transformer.transform(values)
        
        return pd.Series(transformed.flatten(), index=series.index, name=series.name)
    
    def inverse_transform(self, series: pd.Series) -> pd.Series:
        """
        Inverse transform series back to original scale.
        
        Args:
            series: Transformed series
            
        Returns:
            Series in original scale
        """
        if not hasattr(self.transformer, 'lambdas_'):
            raise ValueError("Transformer must be fitted first")
        
        values = series.values.reshape(-1, 1)
        inverse_transformed = self.transformer.inverse_transform(values)
        
        return pd.Series(inverse_transformed.flatten(), index=series.index, name=series.name)


class TimeSeriesFeatureGenerator:
    """Generate features for time series modeling."""
    
    @staticmethod
    def add_lags(df: pd.DataFrame, columns: List[str], 
                lags: List[int]) -> pd.DataFrame:
        """
        Add lagged features to DataFrame.
        
        Args:
            df: Input DataFrame
            columns: Columns to lag
            lags: List of lag periods
            
        Returns:
            DataFrame with added lag features
        """
        df_with_lags = df.copy()
        
        for lag in lags:
            for col in columns:
                df_with_lags[f"{col}_lag_{lag}"] = df[col].shift(lag)
        
        return df_with_lags
    
    @staticmethod
    def add_rolling_features(df: pd.DataFrame, columns: List[str],
                           windows: List[int], 
                           functions: List[str] = ['mean', 'std']) -> pd.DataFrame:
        """
        Add rolling window features.
        
        Args:
            df: Input DataFrame
            columns: Columns to create rolling features for
            windows: List of window sizes
            functions: List of functions to apply ('mean', 'std', 'min', 'max')
            
        Returns:
            DataFrame with added rolling features
        """
        df_with_rolling = df.copy()
        
        for window in windows:
            for col in columns:
                for func in functions:
                    if func == 'mean':
                        df_with_rolling[f"{col}_roll_{window}_mean"] = df[col].rolling(window).mean()
                    elif func == 'std':
                        df_with_rolling[f"{col}_roll_{window}_std"] = df[col].rolling(window).std()
                    elif func == 'min':
                        df_with_rolling[f"{col}_roll_{window}_min"] = df[col].rolling(window).min()
                    elif func == 'max':
                        df_with_rolling[f"{col}_roll_{window}_max"] = df[col].rolling(window).max()
        
        return df_with_rolling
    
    @staticmethod
    def add_technical_indicators(df: pd.DataFrame, price_col: str) -> pd.DataFrame:
        """
        Add common technical indicators.
        
        Args:
            df: DataFrame with price data
            price_col: Name of price column
            
        Returns:
            DataFrame with technical indicators
        """
        df_tech = df.copy()
        
        # Simple moving averages
        for window in [5, 10, 20, 50]:
            df_tech[f"sma_{window}"] = df[price_col].rolling(window).mean()
        
        # Exponential moving averages
        for span in [5, 10, 20]:
            df_tech[f"ema_{span}"] = df[price_col].ewm(span=span).mean()
        
        # Returns
        df_tech['return_1d'] = df[price_col].pct_change()
        df_tech['return_5d'] = df[price_col].pct_change(5)
        df_tech['return_20d'] = df[price_col].pct_change(20)
        
        # Volatility
        df_tech['volatility_20d'] = df_tech['return_1d'].rolling(20).std()
        
        # RSI (simplified)
        delta = df[price_col].diff()
        gain = (delta.where(delta > 0, 0)).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / loss
        df_tech['rsi'] = 100 - (100 / (1 + rs))
        
        return df_tech
    
    @staticmethod
    def create_feature_matrix(df: pd.DataFrame, target_col: str,
                            lag_features: Optional[Dict] = None,
                            rolling_features: Optional[Dict] = None,
                            technical_indicators: bool = False) -> tuple:
        """
        Create comprehensive feature matrix for modeling.
        
        Args:
            df: Input DataFrame
            target_col: Name of target column
            lag_features: Dict with 'columns' and 'lags' keys
            rolling_features: Dict with 'columns', 'windows', 'functions' keys
            technical_indicators: Whether to add technical indicators
            
        Returns:
            Tuple of (X, y) where X is feature matrix and y is target
        """
        feature_df = df.copy()
        
        # Add lag features
        if lag_features:
            feature_df = TimeSeriesFeatureGenerator.add_lags(
                feature_df, 
                lag_features['columns'], 
                lag_features['lags']
            )
        
        # Add rolling features
        if rolling_features:
            feature_df = TimeSeriesFeatureGenerator.add_rolling_features(
                feature_df,
                rolling_features['columns'],
                rolling_features['windows'],
                rolling_features.get('functions', ['mean', 'std'])
            )
        
        # Add technical indicators
        if technical_indicators and target_col in feature_df.columns:
            feature_df = TimeSeriesFeatureGenerator.add_technical_indicators(
                feature_df, target_col
            )
        
        # Separate features and target
        y = feature_df[target_col]
        X = feature_df.drop(columns=[target_col])
        
        # Remove rows with NaN values
        valid_idx = X.dropna().index.intersection(y.dropna().index)
        X = X.loc[valid_idx]
        y = y.loc[valid_idx]
        
        return X, y
