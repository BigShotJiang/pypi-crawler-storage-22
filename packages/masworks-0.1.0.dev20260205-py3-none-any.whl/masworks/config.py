"""
Configuration management for MasWorks library.
"""
import os
import socket
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)


@dataclass
class DatabaseConfig:
    """Database connection configuration."""
    server: str = "nylim-qadbmdl1.nylim.nt.newyorklife.com"
    database: str = "SourceData"
    driver: str = "ODBC Driver 17 for SQL Server"
    trusted_connection: bool = False
    username: str = "cyclecloud"
    password: str = "cycle#cloud10"
    schema: str = "dev"
    chunk_size: int = 5000  # Default chunk size for bulk operations
    
    def get_connection_string(self) -> str:
        """Generate ODBC connection string."""
        if self.trusted_connection:
            conn_str = (
                f"DRIVER={{{self.driver}}};"
                f"SERVER={self.server};"
                f"DATABASE={self.database};"
                f"Trusted_Connection=Yes;"
            )
        else:
            # Username/password authentication
            conn_str = (
                f"DRIVER={{{self.driver}}};"
                f"SERVER={self.server};"
                f"DATABASE={self.database};"
                f"uid={self.username};"
                f"pwd={self.password};"
                f"Trusted_Connection=No;"
            )
        
        return conn_str
    
    def get_sqlalchemy_url(self) -> str:
        """Generate SQLAlchemy connection URL."""
        conn_str = self.get_connection_string()
        return f"mssql+pyodbc:///?odbc_connect={quote_plus(conn_str)}"
    
    def __repr__(self):
        """Secure string representation that hides sensitive information."""
        return (f"DatabaseConfig(server='{self.server}', database='{self.database}', "
                f"driver='{self.driver}', trusted_connection={self.trusted_connection}, "
                f"username='***', password='***', schema='{self.schema}')")


@dataclass
class BridgeConfig:
    """Bridge API data feed configuration."""
    servers: Dict[int, str] = None
    default_server: int = 0
    timeout: int = 30
    use_database_servers: bool = True
    allowed_server_types: List[str] = None  # ['localhost', 'remote', 'all']
    allowed_hosts: List[str] = None  # Specific hostnames/IPs to allow
    blocked_hosts: List[str] = None  # Specific hostnames/IPs to block
    domain_suffix: str = ".nylim.nt.newyorklife.com"  # Domain suffix for internal servers
    # Proxy mode configuration
    use_proxy: bool = False  # Enable proxy mode
    proxy_service_name: str = 'bridge_proxy'  # Service name for proxy in database
    proxy_priority: int = 0  # Priority: 0 = try proxy first, 1 = try proxy as fallback
    proxy_failover: bool = False  # Allow failover to direct servers when proxy fails (only applies when use_proxy=True)
    
    def __post_init__(self):
        if self.servers is None:
            # Default to only localhost:8961 for security
            self.servers = {
                0: "localhost:8961",
            }
        
        # Default to localhost-only for security
        if self.allowed_server_types is None:
            self.allowed_server_types = ['localhost']
        
        # Default to only allow localhost:8961 for security
        if self.allowed_hosts is None:
            self.allowed_hosts = ['localhost:8961']
        
        if self.blocked_hosts is None:
            self.blocked_hosts = []
    
    def __repr__(self):
        """Secure string representation."""
        return (f"BridgeConfig(servers={self.servers}, default_server={self.default_server}, "
                f"timeout={self.timeout}, use_database_servers={self.use_database_servers}, "
                f"allowed_server_types={self.allowed_server_types}, "
                f"allowed_hosts={self.allowed_hosts}, blocked_hosts={self.blocked_hosts}, "
                f"domain_suffix='{self.domain_suffix}', "
                f"use_proxy={self.use_proxy}, proxy_service_name='{self.proxy_service_name}', "
                f"proxy_priority={self.proxy_priority}, proxy_failover={self.proxy_failover})")
    


@dataclass
class FredConfig:
    """FRED data feed configuration."""
    api_key: str = "e03559024ce79bf47c37689584f5cf53"
    base_url: str = "https://api.stlouisfed.org/fred"
    csv_url: str = "https://fred.stlouisfed.org/graph/fredgraph.csv?id="
    
    def __repr__(self):
        """Secure string representation that hides API key."""
        return (f"FredConfig(api_key='***', base_url='{self.base_url}', "
                f"csv_url='{self.csv_url}')")


@dataclass
class DatastreamConfig:
    """Datastream configuration."""
    username: str = "ZNYI010"
    password: str = "PEACH345"
    proxy_host: str = "zproxy.newyorklife.com"
    proxy_port: int = 80
    
    def __repr__(self):
        """Secure string representation that hides credentials."""
        return (f"DatastreamConfig(username='***', password='***', "
                f"proxy_host='{self.proxy_host}', proxy_port={self.proxy_port})")


@dataclass
class Config:
    """Main configuration class."""
    database: DatabaseConfig
    bridge: BridgeConfig
    fred: FredConfig
    datastream: DatastreamConfig
    
    # Table names
    ts_data_table: str = "TS_Data"
    ts_id_map_table: str = "TS_Meta"
    ts_selector_table: str = "TS_Selector"
    ref_data_table: str = "RefData"
    
    # Default settings
    default_start_date: str = "19300101"
    fast_executemany: bool = True
    
    def __repr__(self):
        """Secure string representation that hides sensitive information."""
        return (f"Config(database={self.database}, bridge={self.bridge}, "
                f"fred={self.fred}, datastream={self.datastream}, "
                f"ts_data_table='{self.ts_data_table}', ts_id_map_table='{self.ts_id_map_table}', "
                f"ts_selector_table='{self.ts_selector_table}', ref_data_table='{self.ref_data_table}', "
                f"default_start_date='{self.default_start_date}', fast_executemany={self.fast_executemany})")


def get_default_config(**db_overrides) -> Config:
    """
    Get default configuration with environment variable overrides.
    
    Args:
        **db_overrides: Database configuration overrides. Supported parameters:
            - server: Database server name
            - database: Database name
            - driver: ODBC driver name
            - trusted_connection: Use Windows authentication (bool)
            - username: Database username
            - password: Database password
            - schema: Database schema name
            - chunk_size: Chunk size for bulk operations (int)
    
    Returns:
        Config: Complete configuration object
        
    Example:
        # Use trusted connection
        config = get_default_config(trusted_connection=True)
        
        # Override multiple parameters
        config = get_default_config(
            server="my-server",
            database="my-db",
            trusted_connection=True,
            schema="prod"
        )
        
    Environment Variables:
        ClintonDB_SERVER, ClintonDB_DATABASE, ClintonDB_DRIVER, ClintonDB_TRUSTED_CONNECTION,
        ClintonDB_USERNAME, ClintonDB_PASSWORD, ClintonDB_SCHEMA, ClintonDB_CHUNK_SIZE
    """
    
    # Database config with environment overrides and parameter overrides
    db_config = DatabaseConfig(
        server=db_overrides.get("server", os.getenv("ClintonDB_SERVER", "nylim-qadbmdl1.nylim.nt.newyorklife.com")),
        database=db_overrides.get("database", os.getenv("ClintonDB_DATABASE", "SourceData")),
        driver=db_overrides.get("driver", os.getenv("ClintonDB_DRIVER", "ODBC Driver 17 for SQL Server")),
        trusted_connection=db_overrides.get("trusted_connection", 
                                          os.getenv("ClintonDB_TRUSTED_CONNECTION", "False").lower() == "true"),
        username=db_overrides.get("username", os.getenv("ClintonDB_USERNAME", "cyclecloud")),
        password=db_overrides.get("password", os.getenv("ClintonDB_PASSWORD", "cycle#cloud10")),
        schema=db_overrides.get("schema", os.getenv("ClintonDB_SCHEMA", "dev")),
        chunk_size=db_overrides.get("chunk_size", int(os.getenv("ClintonDB_CHUNK_SIZE", "5000"))),
    )
    
    # Bridge config
    bridge_config = BridgeConfig()
    
    # FRED config with environment override
    fred_config = FredConfig(
        api_key=os.getenv("FRED_API_KEY", "e03559024ce79bf47c37689584f5cf53")
    )
    
    # Datastream config
    ds_config = DatastreamConfig(
        username=os.getenv("DS_USERNAME", "ZNYI010"),
        password=os.getenv("DS_PASSWORD", "PEACH345"),
    )
    
    return Config(
        database=db_config,
        bridge=bridge_config,
        fred=fred_config,
        datastream=ds_config,
    )


def setup_proxy():
    """Setup proxy settings for external data sources."""
    os.environ["HTTP_PROXY"] = "zproxy.newyorklife.com:80"
    os.environ["HTTPS_PROXY"] = "zproxy.newyorklife.com:80"


def setup_ssl():
    """Setup SSL settings for external connections."""
    import ssl
    if (not os.environ.get('PYTHONHTTPSVERIFY', '') and
            getattr(ssl, '_create_unverified_context', None)):
        ssl._create_default_https_context = ssl._create_unverified_context
