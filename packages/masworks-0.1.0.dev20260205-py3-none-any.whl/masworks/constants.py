"""
Constants and configuration values for MasWorks library.
"""

from typing import Dict, List

# Data source mappings
SOURCE_CODE_MAP: Dict[str, str] = {
    'bloomberg': 'BB',
    'fred': 'FRED', 
    'datastream': 'DS'
}

# Source aliases
SOURCE_ALIASES: Dict[str, str] = {
    'bb': 'bloomberg',
    'ds': 'datastream'
}

# Default values
DEFAULT_FREQUENCY: str = "D"
DEFAULT_SOURCE: str = "bloomberg"
DEFAULT_CURRENCY: str = "-"

# Supported frequencies
SUPPORTED_FREQUENCIES: List[str] = ['D', 'W', 'M', 'Q', 'A']

# Supported sources
SUPPORTED_SOURCES: List[str] = ['bloomberg', 'fred', 'datastream', 'bb', 'ds']

# Database table names
TEMP_TABLE_PREFIX: str = "#tmpTS2"

# Operation types
OPERATION_TYPES = {
    'UPSERT': 'upsert',
    'REPLACE': 'replace',
    'CREATE': 'create',
    'UPDATE': 'update',
    'DELETE': 'delete'
}

# Result status codes
STATUS_CODES = {
    'SUCCESS': 'success',
    'ERROR': 'error',
    'NO_DATA': 'no_data',
    'FEED_ERROR': 'feed_error'
}
