"""
Core module for MasWorks library.

This module provides the main entry points for the MasWorks library.
Import the classes you need directly from their respective modules.
"""

# Main classes
from .mas_time_series_reader import MasTimeSeriesReader
from .mas_time_series_admin import MasTimeSeriesAdmin
# Import TimeSeriesContext on demand to avoid circular imports
def get_time_series_context():
    """Get TimeSeriesContext class, importing it on demand to avoid circular imports."""
    from .MasDatabase.context import TimeSeriesContext
    return TimeSeriesContext

# For backward compatibility, we can still provide it as an attribute
# but it will be imported on demand
class _TimeSeriesContextProxy:
    def __getattr__(self, name):
        TimeSeriesContext = get_time_series_context()
        return getattr(TimeSeriesContext, name)
    
    def __call__(self, *args, **kwargs):
        TimeSeriesContext = get_time_series_context()
        return TimeSeriesContext(*args, **kwargs)

TimeSeriesContext = _TimeSeriesContextProxy()

# Mixins (for advanced usage)
from .MasDatabase import SeriesOperationMixin, BloombergOperationsMixin

# Decorators (for advanced usage)
from .MasDatabase import handle_series_operation_errors

# Constants (for advanced usage)
from .constants import (
    SOURCE_CODE_MAP, SOURCE_ALIASES, DEFAULT_FREQUENCY, DEFAULT_SOURCE,
    DEFAULT_CURRENCY, SUPPORTED_FREQUENCIES, SUPPORTED_SOURCES,
    TEMP_TABLE_PREFIX, OPERATION_TYPES, STATUS_CODES
)

__all__ = [
    # Main classes
    'MasTimeSeriesReader',
    'MasTimeSeriesAdmin',
    'TimeSeriesContext',
    
    # Mixins
    'SeriesOperationMixin',
    'BloombergOperationsMixin',
    
    # Decorators
    'handle_series_operation_errors',
    
    # Constants
    'SOURCE_CODE_MAP',
    'SOURCE_ALIASES', 
    'DEFAULT_FREQUENCY',
    'DEFAULT_SOURCE',
    'DEFAULT_CURRENCY',
    'SUPPORTED_FREQUENCIES',
    'SUPPORTED_SOURCES',
    'TEMP_TABLE_PREFIX',
    'OPERATION_TYPES',
    'STATUS_CODES',
]
