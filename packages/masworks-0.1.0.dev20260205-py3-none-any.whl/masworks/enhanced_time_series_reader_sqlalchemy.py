#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enhanced TimeSeriesReader with SQLAlchemy ORM integration.

This module provides an enhanced version of TimeSeriesReader using SQLAlchemy ORM
and query builder tools instead of raw SQL statements for better performance,
type safety, and maintainability.
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Union, Dict, Any
from datetime import datetime
import logging
from sqlalchemy import select, func, and_, or_, text
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select

from .mas_time_series_reader import MasTimeSeriesReader
from .MasDatabase.models import TimeSeriesData, TimeSeriesMeta, TimeSeriesStatus

logger = logging.getLogger(__name__)


class EnhancedTimeSeriesReader(MasTimeSeriesReader):
    """
    Enhanced TimeSeriesReader using SQLAlchemy ORM and query builder tools.
    
    This class extends MasTimeSeriesReader with advanced time series operations
    using SQLAlchemy ORM for better performance, type safety, and maintainability.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the EnhancedTimeSeriesReader.
        
        Args:
            config: Configuration dictionary for database connection
        """
        super().__init__(config)
        self._lag = 'Lag2'  # Default lag setting
    
    def get_ts_by_id(self, tid: Union[int, str], name: str = 'value', 
                     condition: str = '1=1') -> pd.Series:
        """
        Retrieve time series by ID with optional conditions using SQLAlchemy ORM.
        
        Args:
            tid: Time series ID (int) or series ID string
            name: Name for the series
            condition: SQL condition for filtering (legacy support)
            
        Returns:
            pd.Series: Time series data
        """
        try:
            if isinstance(tid, str):
                # Get ID from series ID using ORM
                tid = self._get_tid_from_sid(tid)
            
            # Build query using SQLAlchemy ORM
            query = select(TimeSeriesData.date, TimeSeriesData.value).where(
                TimeSeriesData.id == tid
            ).order_by(TimeSeriesData.date)
            
            # Execute query using session
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.Series(dtype=float, name=name)
                
                # Convert to DataFrame and then Series
                df = pd.DataFrame(result, columns=['date', 'value'])
                df['date'] = pd.to_datetime(df['date'])
                ts = df.set_index('date')['value']
                ts.name = name
                ts.TsId = tid
                return ts
                
        except Exception as e:
            logger.error(f"Failed to get time series {tid}: {e}")
            raise
    
    def get_ts_with_lag(self, tid: Union[int, str], name: str = 'value', 
                       use_lag: bool = True, align: str = None) -> pd.DataFrame:
        """
        Retrieve time series with lag and alignment options using SQLAlchemy.
        
        Args:
            tid: Time series ID
            name: Name for the series
            use_lag: Whether to apply lag
            align: Alignment option ('EOM' for end of month)
            
        Returns:
            pd.DataFrame: Time series data with date and value columns
        """
        try:
            if isinstance(tid, str):
                tid = self._get_tid_from_sid(tid)
            
            # Build date expression using SQLAlchemy functions
            if use_lag:
                # Use SQLAlchemy functions for date manipulation
                date_expr = func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date)
            else:
                date_expr = TimeSeriesData.date
            
            if align == 'EOM':
                date_expr = func.EOMONTH(date_expr)
            
            # Build query with joins for metadata
            query = select(
                date_expr.label('date'),
                TimeSeriesData.value.label(name)
            ).select_from(
                TimeSeriesData.__table__.join(
                    TimeSeriesMeta.__table__,
                    TimeSeriesData.id == TimeSeriesMeta.id
                )
            ).where(
                TimeSeriesData.id == tid
            ).order_by(date_expr)
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                df = pd.DataFrame(result)
                df['date'] = pd.to_datetime(df['date'])
                return df.set_index('date')
                
        except Exception as e:
            logger.error(f"Failed to get time series with lag {tid}: {e}")
            raise
    
    def collect_series_by_selector(self, selector: str, condition: str = '1=1') -> List[pd.Series]:
        """
        Collect multiple series by selector using SQLAlchemy ORM.
        
        Args:
            selector: Selector name
            condition: SQL condition for filtering (legacy support)
            
        Returns:
            List[pd.Series]: List of time series
        """
        try:
            # Get selector information using ORM
            selector_info = self._get_selector_series_info(selector)
            if not selector_info:
                return []
            
            # Collect series using ORM
            series_list = []
            for series_id, colname in selector_info.items():
                try:
                    ts = self.get_ts_by_id(series_id, colname, condition)
                    series_list.append(ts)
                except Exception as e:
                    logger.warning(f"Failed to get series {series_id} ({colname}): {e}")
                    continue
            
            return series_list
            
        except Exception as e:
            logger.error(f"Failed to collect series for selector {selector}: {e}")
            raise
    
    def merge_series(self, tids: List[int], condition: str = '1=1') -> pd.DataFrame:
        """
        Merge multiple time series into a DataFrame using SQLAlchemy ORM.
        
        Args:
            tids: List of time series IDs
            condition: SQL condition for filtering (legacy support)
            
        Returns:
            pd.DataFrame: Merged time series data
        """
        try:
            # Get metadata using ORM
            metadata = self._get_metadata_by_ids(tids)
            if not metadata:
                return pd.DataFrame()
            
            # Create name mapping
            name_map = {row['id']: row.get('ticker') or row.get('tkr') for row in metadata}
            
            # Collect and merge series
            series_list = []
            for tid in tids:
                if tid in name_map:
                    name = name_map[tid]
                    ts = self.get_ts_by_id(tid, name, condition)
                    series_list.append(ts)
            
            if not series_list:
                return pd.DataFrame()
            
            return pd.concat(series_list, axis=1)
            
        except Exception as e:
            logger.error(f"Failed to merge series {tids}: {e}")
            raise
    
    def pivot_series(self, tids: List[int], start_date: str = '1950-01-01', 
                    freq: str = 'M', ffill_limit: int = None) -> pd.DataFrame:
        """
        Pivot multiple series into a DataFrame with frequency conversion using SQLAlchemy.
        
        Args:
            tids: List of time series IDs
            start_date: Start date for the data
            freq: Target frequency ('M' for monthly, 'Q' for quarterly)
            ffill_limit: Forward fill limit
            
        Returns:
            pd.DataFrame: Pivoted time series data
        """
        try:
            # Get metadata using ORM
            metadata = self._get_metadata_by_ids(tids)
            if not metadata:
                return pd.DataFrame()
            
            # Create name mapping
            name_map = {row['id']: row.get('ticker') or row.get('tkr') for row in metadata}
            
            # Build pivot query using SQLAlchemy
            if freq == 'M':
                date_expr = func.EOMONTH(func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date))
            elif freq == 'Q':
                date_expr = func.EOMONTH(func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date))
            else:
                date_expr = func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date)
            
            # Build query with joins
            query = select(
                date_expr.label('date'),
                TimeSeriesData.id,
                TimeSeriesData.value
            ).select_from(
                TimeSeriesData.__table__.join(
                    TimeSeriesMeta.__table__,
                    TimeSeriesData.id == TimeSeriesMeta.id
                )
            ).where(
                and_(
                    TimeSeriesData.id.in_(tids),
                    TimeSeriesData.date >= start_date
                )
            ).order_by(date_expr, TimeSeriesData.id)
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                # Convert to DataFrame and pivot
                df = pd.DataFrame(result, columns=['date', 'id', 'value'])
                df['date'] = pd.to_datetime(df['date'])
                
                # Pivot the data
                pivot_df = df.pivot(index='date', columns='id', values='value')
                
                # Rename columns using metadata
                pivot_df.columns = [name_map.get(col, f'Series_{col}') for col in pivot_df.columns]
                
                # Apply forward fill if specified
                if ffill_limit is not None:
                    pivot_df = pivot_df.asfreq('M').ffill(limit=ffill_limit)
                
                return pivot_df
                
        except Exception as e:
            logger.error(f"Failed to pivot series {tids}: {e}")
            raise
    
    def convert_to_monthly(self, tid: Union[int, str], name: str = None, 
                          use_lag: bool = True) -> pd.DataFrame:
        """
        Convert time series to monthly frequency using SQLAlchemy.
        
        Args:
            tid: Time series ID
            name: Name for the series
            use_lag: Whether to apply lag
            
        Returns:
            pd.DataFrame: Monthly time series data
        """
        try:
            if isinstance(tid, str):
                tid = self._get_tid_from_sid(tid)
            
            # Get series metadata using ORM
            metadata = self._get_metadata_by_ids([tid])
            if not metadata:
                return pd.DataFrame()
            
            if name is None:
                name = metadata[0].get('ticker') or metadata[0].get('tkr')
            
            # Build date expression
            if use_lag:
                date_expr = func.EOMONTH(func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date))
            else:
                date_expr = func.EOMONTH(TimeSeriesData.date)
            
            # Get frequency information
            freq = metadata[0].get('frequency') or metadata[0].get('frq', 'M')
            
            # Build query based on frequency
            if freq and freq != 'M':
                # Need to aggregate higher frequency data
                query = select(
                    date_expr.label('date'),
                    TimeSeriesData.value,
                    func.ROW_NUMBER().over(
                        partition_by=date_expr,
                        order_by=TimeSeriesData.date.desc()
                    ).label('rn')
                ).select_from(
                    TimeSeriesData.__table__.join(
                        TimeSeriesMeta.__table__,
                        TimeSeriesData.id == TimeSeriesMeta.id
                    )
                ).where(
                    TimeSeriesData.id == tid
                )
                
                # Execute and filter
                with self.db_manager.get_session() as session:
                    result = session.execute(query).fetchall()
                    
                    if not result:
                        return pd.DataFrame()
                    
                    # Filter for rn = 1 (latest value per month)
                    filtered_result = [row for row in result if row.rn == 1]
                    
                    if not filtered_result:
                        return pd.DataFrame()
                    
                    df = pd.DataFrame(filtered_result, columns=['date', 'value'])
                    df['date'] = pd.to_datetime(df['date'])
                    return df.set_index('date')
            else:
                # Already monthly or lower frequency
                query = select(
                    date_expr.label('date'),
                    TimeSeriesData.value.label(name)
                ).select_from(
                    TimeSeriesData.__table__.join(
                        TimeSeriesMeta.__table__,
                        TimeSeriesData.id == TimeSeriesMeta.id
                    )
                ).where(
                    TimeSeriesData.id == tid
                ).order_by(date_expr)
                
                with self.db_manager.get_session() as session:
                    result = session.execute(query).fetchall()
                    
                    if not result:
                        return pd.DataFrame()
                    
                    df = pd.DataFrame(result)
                    df['date'] = pd.to_datetime(df['date'])
                    return df.set_index('date')
                
        except Exception as e:
            logger.error(f"Failed to convert to monthly {tid}: {e}")
            raise
    
    def convert_to_quarterly(self, tid: Union[int, str], name: str = None, 
                           use_lag: bool = True) -> pd.DataFrame:
        """
        Convert time series to quarterly frequency using SQLAlchemy.
        
        Args:
            tid: Time series ID
            name: Name for the series
            use_lag: Whether to apply lag
            
        Returns:
            pd.DataFrame: Quarterly time series data
        """
        try:
            if isinstance(tid, str):
                tid = self._get_tid_from_sid(tid)
            
            # Get series metadata using ORM
            metadata = self._get_metadata_by_ids([tid])
            if not metadata:
                return pd.DataFrame()
            
            if name is None:
                name = metadata[0].get('ticker') or metadata[0].get('tkr')
            
            # Build quarterly date expression
            if use_lag:
                base_date = func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date)
            else:
                base_date = TimeSeriesData.date
            
            date_expr = func.CONVERT('date', func.DATEADD('q', func.DATEDIFF('q', -1, base_date), -1))
            
            # Get frequency information
            freq = metadata[0].get('frequency') or metadata[0].get('frq', 'Q')
            
            # Build query based on frequency
            if freq and freq not in ['Q', 'A']:
                # Need to aggregate higher frequency data
                query = select(
                    date_expr.label('date'),
                    TimeSeriesData.value,
                    func.ROW_NUMBER().over(
                        partition_by=date_expr,
                        order_by=TimeSeriesData.date.desc()
                    ).label('rn')
                ).select_from(
                    TimeSeriesData.__table__.join(
                        TimeSeriesMeta.__table__,
                        TimeSeriesData.id == TimeSeriesMeta.id
                    )
                ).where(
                    TimeSeriesData.id == tid
                )
                
                # Execute and filter
                with self.db_manager.get_session() as session:
                    result = session.execute(query).fetchall()
                    
                    if not result:
                        return pd.DataFrame()
                    
                    # Filter for rn = 1 (latest value per quarter)
                    filtered_result = [row for row in result if row.rn == 1]
                    
                    if not filtered_result:
                        return pd.DataFrame()
                    
                    df = pd.DataFrame(filtered_result, columns=['date', 'value'])
                    df['date'] = pd.to_datetime(df['date'])
                    return df.set_index('date')
            else:
                # Already quarterly or lower frequency
                query = select(
                    date_expr.label('date'),
                    TimeSeriesData.value.label(name)
                ).select_from(
                    TimeSeriesData.__table__.join(
                        TimeSeriesMeta.__table__,
                        TimeSeriesData.id == TimeSeriesMeta.id
                    )
                ).where(
                    TimeSeriesData.id == tid
                ).order_by(date_expr)
                
                with self.db_manager.get_session() as session:
                    result = session.execute(query).fetchall()
                    
                    if not result:
                        return pd.DataFrame()
                    
                    df = pd.DataFrame(result)
                    df['date'] = pd.to_datetime(df['date'])
                    return df.set_index('date')
                
        except Exception as e:
            logger.error(f"Failed to convert to quarterly {tid}: {e}")
            raise
    
    def match_series_by_ticker(self, ticker: str, **kwargs) -> pd.DataFrame:
        """
        Match series by ticker and additional criteria using SQLAlchemy ORM.
        
        Args:
            ticker: Ticker symbol to match
            **kwargs: Additional criteria for matching
            
        Returns:
            pd.DataFrame: Matching series metadata
        """
        try:
            # Build query using SQLAlchemy ORM
            query = select(TimeSeriesMeta).where(TimeSeriesMeta.ticker == ticker)
            
            # Add additional criteria
            for key, value in kwargs.items():
                if hasattr(TimeSeriesMeta, key):
                    query = query.where(getattr(TimeSeriesMeta, key) == value)
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                # Convert to DataFrame
                df = pd.DataFrame([row._asdict() for row in result])
                return df
                
        except Exception as e:
            logger.error(f"Failed to match series by ticker {ticker}: {e}")
            raise
    
    def search_series(self, *args, **kwargs) -> pd.DataFrame:
        """
        Search series by multiple criteria using LIKE patterns with SQLAlchemy.
        
        Args:
            *args: Tuples of (column, pattern) for LIKE searches
            **kwargs: Additional criteria for LIKE searches
            
        Returns:
            pd.DataFrame: Matching series metadata
        """
        try:
            # Build query using SQLAlchemy ORM
            query = select(TimeSeriesMeta)
            conditions = []
            
            # Process positional arguments
            for column, pattern in args:
                if hasattr(TimeSeriesMeta, column):
                    conditions.append(getattr(TimeSeriesMeta, column).like(pattern))
            
            # Process keyword arguments
            for key, value in kwargs.items():
                if hasattr(TimeSeriesMeta, key):
                    conditions.append(getattr(TimeSeriesMeta, key).like(value))
            
            if conditions:
                query = query.where(or_(*conditions))
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                # Convert to DataFrame
                df = pd.DataFrame([row._asdict() for row in result])
                return df
                
        except Exception as e:
            logger.error(f"Failed to search series: {e}")
            raise
    
    def get_series_description(self, tid: Union[int, str], include_status: bool = False) -> Dict[str, Any]:
        """
        Get series description/metadata using SQLAlchemy ORM.
        
        Args:
            tid: Time series ID
            include_status: Whether to include status information (upd, upd_start, upd_end)
            
        Returns:
            Dict[str, Any]: Series metadata
        """
        try:
            if isinstance(tid, str):
                tid = self._get_tid_from_sid(tid)
            
            # Get series metadata using ORM
            metadata = self._get_metadata_by_ids([tid])
            if not metadata:
                return {}
            
            # Extract metadata
            series_info = metadata[0]
            
            # Build description dictionary
            description = {
                'id': series_info['id'],
                'ticker': series_info.get('ticker') or series_info.get('tkr'),
                'field': series_info.get('field') or series_info.get('fld'),
                'frequency': series_info.get('frequency') or series_info.get('frq'),
                'currency': series_info.get('currency') or series_info.get('ccy'),
                'source': series_info.get('source') or series_info.get('src'),
                'start_date': series_info.get('start_date'),
                'note': series_info.get('note')
            }
            
            # Optionally include status information
            if include_status:
                status_info = self._get_status_info(tid)
                if status_info:
                    description.update({
                        'last_update': status_info.get('upd'),
                        'update_start': status_info.get('upd_start'),
                        'update_end': status_info.get('upd_end'),
                        'updated_by': status_info.get('upd_by')
                    })
                else:
                    description.update({
                        'last_update': None,
                        'update_start': None,
                        'update_end': None,
                        'updated_by': None
                    })
            else:
                description['last_update'] = None  # upd field is in TS_Status table, not TS_Meta
            
            return description
            
        except Exception as e:
            logger.error(f"Failed to get series description {tid}: {e}")
            raise
    
    # Helper methods using SQLAlchemy ORM
    
    def _get_tid_from_sid(self, sid: str) -> int:
        """
        Get time series ID from series ID string using SQLAlchemy ORM.
        
        Args:
            sid: Series ID string
            
        Returns:
            int: Time series ID
        """
        try:
            query = select(TimeSeriesMeta.id).where(TimeSeriesMeta.sid == sid)
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchone()
                if not result:
                    raise ValueError(f"Series ID {sid} not found")
                return result[0]
                
        except Exception as e:
            logger.error(f"Failed to get ID for series {sid}: {e}")
            raise
    
    def _get_selector_series_info(self, selector: str) -> Dict[int, str]:
        """
        Get selector series information using SQLAlchemy ORM.
        
        Args:
            selector: Selector name
            
        Returns:
            Dict[int, str]: Mapping of series ID to column name
        """
        try:
            # Import the TimeSeriesSelector model
            from .MasDatabase.models import TimeSeriesSelector
            
            # Build query to get series information for the selector
            query = select(
                TimeSeriesSelector.id,
                TimeSeriesSelector.colname
            ).where(
                TimeSeriesSelector.sel == selector
            ).order_by(TimeSeriesSelector.ord)
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    logger.warning(f"No series found for selector '{selector}'")
                    return {}
                
                # Convert to dictionary mapping series ID to column name
                return {row[0]: row[1] for row in result}
                
        except Exception as e:
            logger.error(f"Failed to get selector info for {selector}: {e}")
            raise
    
    def _get_metadata_by_ids(self, tids: List[int]) -> List[Dict[str, Any]]:
        """
        Get metadata for multiple series IDs using SQLAlchemy ORM.
        
        Args:
            tids: List of time series IDs
            
        Returns:
            List[Dict[str, Any]]: List of metadata dictionaries
        """
        try:
            query = select(TimeSeriesMeta).where(TimeSeriesMeta.id.in_(tids))
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return []
                
                # Convert to list of dictionaries
                return [row._asdict() for row in result]
                
        except Exception as e:
            logger.error(f"Failed to get metadata for IDs {tids}: {e}")
            raise
    
    def _get_status_info(self, tid: int) -> Optional[Dict[str, Any]]:
        """
        Get status information for a series ID using SQLAlchemy ORM.
        
        Args:
            tid: Time series ID
            
        Returns:
            Optional[Dict[str, Any]]: Status information or None if not found
        """
        try:
            from .MasDatabase.models import TimeSeriesStatus
            
            query = select(TimeSeriesStatus).where(TimeSeriesStatus.id == tid)
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchone()
                
                if not result:
                    return None
                
                # Convert to dictionary
                return result._asdict()
                
        except Exception as e:
            logger.error(f"Failed to get status info for ID {tid}: {e}")
            return None
