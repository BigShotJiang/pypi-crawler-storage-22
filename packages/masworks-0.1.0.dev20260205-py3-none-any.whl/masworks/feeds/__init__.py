"""
Data feeds module for MasWorks library.

Provides interfaces to external data sources like Bridge API (Bloomberg wrapper), FRED, and Datastream.
"""

from .bridge import BridgeFeed
from .fred import FredFeed
from .datastream import DatastreamFeed
from .base import DataFeedBase, DataFeedError
from .factory import create_bridge_feed, create_datastream_feed, create_fred_feed, get_config

__all__ = [
    "BridgeFeed",
    "FredFeed", 
    "DatastreamFeed",
    "DataFeedBase",
    "DataFeedError",
    "create_bridge_feed",
    "create_datastream_feed",
    "create_fred_feed",
    "get_config",
]
