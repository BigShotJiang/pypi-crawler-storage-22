"""
Base classes and interfaces for data feeds.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import pandas as pd


class DataFeedError(Exception):
    """Base exception for data feed errors."""
    pass


class DataFeedBase(ABC):
    """Abstract base class for data feeds."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
    
    @abstractmethod
    def get_data(self, ticker: str, **kwargs) -> pd.DataFrame:
        """
        Retrieve time series data.
        
        Args:
            ticker: Security ticker/identifier
            **kwargs: Feed-specific parameters including:
                - field: Data field to retrieve (feed-specific)
                - frequency: Data frequency (feed-specific)
                - start_date: Start date (YYYY-MM-DD format)
                - end_date: End date (YYYY-MM-DD format)
                - Additional feed-specific parameters
                
        Returns:
            DataFrame with date index and value column
            
        Raises:
            DataFeedError: If data retrieval fails
        """
        pass
    
    @abstractmethod
    def get_reference_data(self, ticker: str, fields: list, **kwargs) -> Dict[str, Any]:
        """
        Retrieve reference data.
        
        Args:
            ticker: Security ticker/identifier
            fields: List of reference fields to retrieve
            **kwargs: Additional parameters
            
        Returns:
            Dictionary mapping field names to values
            
        Raises:
            DataFeedError: If reference data retrieval fails
        """
        pass
    
    def validate_frequency(self, frequency: str) -> str:
        """Validate and normalize frequency parameter."""
        freq_map = {
            'DAILY': 'D',
            'WEEKLY': 'W', 
            'MONTHLY': 'M',
            'QUARTERLY': 'Q',
            'SEMI_ANNUAL': 'S',
            'SEMI_ANNUALLY': 'S',
            'ANNUAL': 'A',
            'YEARLY': 'A'
        }
        
        freq = frequency.upper()
        return freq_map.get(freq, freq)
    
    def format_date(self, date_str: str) -> str:
        """Format date string to YYYYMMDD format."""
        if not date_str:
            return date_str
            
        # Handle various date formats
        date_str = date_str.replace('-', '').replace('/', '')
        
        # Ensure 8-digit format
        if len(date_str) == 8:
            return date_str
        elif len(date_str) == 6:  # YYMMDD -> YYYYMMDD
            year = int(date_str[:2])
            if year > 50:  # Assume 1950-1999
                return f"19{date_str}"
            else:  # Assume 2000-2049
                return f"20{date_str}"
        else:
            raise ValueError(f"Invalid date format: {date_str}")
    
    def clean_ts_dataframe(self, df: pd.DataFrame, date_format: str = None) -> pd.DataFrame:
        """
        Clean and standardize DataFrame output.
        
        Handles both numeric and timestamp data in the 'value' column:
        - If values are numeric: converts to float
        - If values are date strings: converts to Unix timestamps
        - Assumes no mixed types in the value column
        
        Args:
            df: DataFrame to clean
            date_format: Optional date format string (e.g., '%Y-%m-%d') to avoid format inference warnings
        """
        from ..utils.data_utils import clean_ts_dataframe as clean_ts_dataframe_helper
        return clean_ts_dataframe_helper(df, date_format)
