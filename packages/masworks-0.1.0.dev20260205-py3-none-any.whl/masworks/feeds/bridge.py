"""
Bridge API data feed implementation with optimized HTTP connection pooling.
"""
import logging
import time
from typing import Dict, Any, Optional, List, Union
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime
from io import StringIO

from .base import DataFeedBase, DataFeedError
from .bridge_service_manager import BridgeServiceManager
from masworks.config import BridgeConfig
from .bridge_server_filter import BridgeServerFilter
from masworks.utils.bbg_ticker_detail import BbgTickerDetail

logger = logging.getLogger(__name__)


class BridgeFeed(DataFeedBase):
    """Bridge API data feed using HTTP API."""
    
    def __init__(self, config: BridgeConfig, db_manager=None):
        super().__init__()
        self.config = config
        self.db_manager = db_manager
        
        # Phase 1: Initialize components
        self._init_optimized_session()
        self.service_manager = BridgeServiceManager(config, db_manager)
        self.server_filter = BridgeServerFilter(
            allowed_server_types=config.allowed_server_types,
            allowed_hosts=config.allowed_hosts,
            blocked_hosts=config.blocked_hosts
        )
        
        # Phase 2: Load servers from database (proxy and direct servers in single query)
        proxy, direct_servers = self._load_servers_from_database(config, db_manager)
        self.proxy_address = proxy  # Store for backward compatibility
        
        # Phase 3: Build final server list
        self.config.servers = self._build_server_list(proxy, direct_servers, config, db_manager)
        
        # Phase 4: Finalize initialization (validation and conditional best server check)
        self._finalize_initialization(config, db_manager, proxy)
    
    def _init_optimized_session(self):
        """Initialize optimized HTTP session with connection pooling."""
        try:
            # Create session with connection pooling
            self.session = requests.Session()
            
            # Configure retry strategy
            retry_strategy = Retry(
                total=3,
                backoff_factor=0.1,
                status_forcelist=[429, 500, 502, 503, 504],
            )
            
            # Configure connection pooling with retry strategy
            adapter = HTTPAdapter(
                pool_connections=10,  # Number of connection pools
                pool_maxsize=20,      # Maximum connections per pool
                max_retries=retry_strategy,
                pool_block=False      # Don't block when pool is full
            )
            
            # Mount adapters to session
            self.session.mount("http://", adapter)
            self.session.mount("https://", adapter)
            
            # Set default headers
            self.session.headers.update({
                'Content-Type': 'application/json',
                'Connection': 'keep-alive'
            })
            
            logger.info("Initialized optimized HTTP session with connection pooling")
            
        except Exception as e:
            logger.warning(f"Failed to initialize optimized session, falling back to default: {e}")
            self.session = None
    
    def _load_servers_from_database(self, config: BridgeConfig, db_manager) -> tuple:
        """
        Load both proxy and direct servers from database.
        Delegates to BridgeServiceManager for database operations and only handles filtering.
        
        Args:
            config: BridgeConfig instance
            db_manager: Database manager instance
            
        Returns:
            Tuple of (proxy_address: Optional[str], direct_servers: Dict[int, str])
        """
        # Only query database if configured to use it
        if not (config.use_database_servers and db_manager):
            return None, {}
        
        # Delegate to service manager for database operations
        proxy, direct_servers = self.service_manager.load_all_servers_from_database()
        
        # Apply server filter to proxy if needed
        if proxy and config.use_proxy:
            if self.server_filter.is_server_allowed(proxy):
                logger.info(f"Proxy loaded: {proxy}")
            else:
                logger.warning(f"Proxy {proxy} filtered out by configuration")
                proxy = None
        
        # Filter direct servers based on configuration
        if direct_servers:
            direct_servers = self.server_filter.filter_allowed_servers(direct_servers)
            logger.info(f"Direct servers loaded: {len(direct_servers)}")
        
        return proxy, direct_servers
    
    def _build_server_list(self, proxy: Optional[str], direct_servers: Dict[int, str], 
                          config: BridgeConfig, db_manager) -> Dict[int, str]:
        """
        Build final server list based on configuration.
        
        Args:
            proxy: Proxy server address or None
            direct_servers: Dictionary of direct server addresses
            config: BridgeConfig instance
            db_manager: Database manager instance
            
        Returns:
            Dictionary mapping server IDs to server addresses
        """
        # Case 1: No proxy - use direct servers or defaults
        if not proxy or not config.use_proxy:
            if direct_servers:
                logger.info(f"Bridge API servers loaded from database: {len(direct_servers)} allowed")
                return direct_servers
            
            # Fall back to filtered default servers
            filtered_defaults = self.server_filter.filter_allowed_servers(self.config.servers)
            if not filtered_defaults:
                logger.warning("No servers from database passed the filter, using default servers")
            return filtered_defaults
        
        # Case 2: Proxy first (priority == 0)
        if config.proxy_priority == 0:
            servers = {0: proxy}
            
            # Add direct servers as fallback ONLY if proxy_failover is True
            if config.proxy_failover and direct_servers:
                for server_id, server_addr in direct_servers.items():
                    servers[len(servers)] = server_addr
                logger.info(f"Proxy mode with failover: {len(servers)} servers (1 proxy + {len(direct_servers)} direct)")
            else:
                logger.info(f"Proxy mode without failover: using proxy only (proxy_failover={config.proxy_failover})")
            
            return servers
        
        # Case 3: Proxy as fallback (priority == 1)
        if direct_servers:
            servers = {}
            server_id = 0
            
            # Add direct servers first
            for srv_id, server_addr in direct_servers.items():
                servers[server_id] = server_addr
                server_id += 1
            
            # Add proxy at end if proxy_failover is True
            if config.proxy_failover:
                servers[server_id] = proxy
                logger.info(f"Proxy as fallback with failover: {len(servers)} servers ({len(direct_servers)} direct + 1 proxy)")
            else:
                logger.info(f"Proxy as fallback without failover: using direct servers only (proxy_failover={config.proxy_failover})")
            
            return servers
        
        # Case 4: No direct servers available
        # Fall back to proxy only if proxy_failover is False
        if not config.proxy_failover:
            logger.info("Using proxy only (no direct servers, failover disabled)")
            return {0: proxy}
        
        # Edge case: proxy fallback with failover but no direct servers
        logger.warning("Proxy fallback mode but no direct servers available, using proxy only")
        return {0: proxy}
    
    def _finalize_initialization(self, config: BridgeConfig, db_manager, proxy: Optional[str]):
        """
        Finalize initialization with validation and best server check.
        
        Find best server only when:
        - Proxy is NOT used (use_proxy=False), OR
        - Proxy is used but failed (proxy=None when use_proxy=True)
        
        Args:
            config: BridgeConfig instance
            db_manager: Database manager instance
            proxy: Proxy server address or None
        """
        # Validate server list is not empty
        if not self.config.servers:
            raise DataFeedError("No Bridge API servers available in configuration")
        
        # Set current server
        self.current_server = config.default_server
        self.last_check = {srv: datetime.now() for srv in config.servers.keys()}
        
        # Initialize Bloomberg ticker detail helper with BridgeFeed (preferred)
        self.bbg_ticker_detail = BbgTickerDetail(bridge_feed=self)
        self.last_server_check = datetime.now()  # Track when we last checked server usability
        self.server_check_interval = 300  # Check server usability every 5 minutes
        
        # Find best server only when proxy not used OR proxy failed
        should_find_best = (
            config.use_database_servers and 
            db_manager and
            (
                not config.use_proxy or  # No proxy mode - find best direct server
                (config.use_proxy and proxy is None)  # Proxy mode but proxy failed to load
            )
        )
        
        if should_find_best:
            logger.debug("Finding best server from available direct servers")
            self._find_best_server()
        else:
            logger.debug("Skipping server availability check: using proxy or proxy-only mode")
    
    def _find_best_server(self):
        """Find and set the best available server from the database."""
        try:
            usable_server_info = self.service_manager.find_usable_server(
                timeout=self.config.timeout,
                attempt_recovery=True
            )
            
            if usable_server_info:
                server = usable_server_info['server']
                # Find the server ID in our config that matches this server
                for server_id, server_addr in self.config.servers.items():
                    print(server_addr, server.server_address)
                    if server_addr == server.server_address:
                        self.current_server = server_id
                        logger.info(f"Selected best available server: {server.server_address} (ID: {server_id})")
                        break
                else:
                    logger.warning(f"Found usable server {server.server_address} but it's not in our config")
            else:
                logger.warning("No usable servers found, using default server")
                
        except Exception as e:
            logger.error(f"Failed to find best server: {e}")
            logger.info("Using default server")
        
    def _get_server_url(self, server_id: Optional[int] = None) -> str:
        """Get server URL for the specified or current server."""
        srv_id = server_id if server_id is not None else self.current_server
        
        # Check if server ID exists in config
        if srv_id not in self.config.servers:
            # Try to find any available server if the requested one doesn't exist
            if self.config.servers:
                available_server_id = next(iter(self.config.servers.keys()))
                logger.warning(f"Server ID {srv_id} not found, using available server {available_server_id}")
                srv_id = available_server_id
            else:
                raise DataFeedError(f"No servers available in configuration")
        
        server = self.config.servers.get(srv_id)
        if not server:
            raise DataFeedError(f"Invalid server ID: {srv_id}")
        return f"http://{server}"
    
    def _parse_bridge_response(self, response: Any, ticker: str, field: str) -> pd.DataFrame:
        """
        Parse Bridge API response, handling standard, compact, and legacy formats.
        
        Args:
            response: Bridge API response
            ticker: Requested ticker
            field: Requested field
            
        Returns:
            DataFrame with parsed data
        """
        try:
            # Check if this is a list response
            if isinstance(response, list) and len(response) > 0:
                first_item = response[0]
                
                # Standard format: [{'ticker': 'spx index', 'date': '2025-09-17', 'PX_LAST': 6600.35}, ...]
                if isinstance(first_item, dict) and 'ticker' in first_item and 'date' in first_item:
                    logger.debug("Parsing Bridge API standard response format")
                    
                    # Filter for the requested ticker
                    ticker_data = [item for item in response if item.get('ticker', '').lower() == ticker.lower()]
                    
                    if not ticker_data:
                        raise DataFeedError(f"No data found for ticker {ticker}")
                    
                    # Store the ticker from the response (Bloomberg-normalized)
                    response_ticker = ticker_data[0].get('ticker', ticker)
                    self._last_response_ticker = response_ticker
                    logger.debug(f"Stored response ticker: '{response_ticker}' (input was: '{ticker}')")
                    
                    # Convert to DataFrame
                    df = pd.DataFrame(ticker_data)
                    
                    # Convert date column to datetime
                    if 'date' in df.columns:
                        df['date'] = pd.to_datetime(df['date'])
                        df = df.set_index('date')
                    
                    # Rename field column to 'value' (case-insensitive)
                    field_upper = field.upper()
                    for col in df.columns:
                        if col.upper() == field_upper:
                            df = df.rename(columns={col: 'value'})
                            break
                    
                    return df
                
                # Legacy format: [{'data': 'json_string'}, ...]
                elif isinstance(first_item, dict) and 'data' in first_item:
                    logger.debug("Parsing Bridge API legacy response format")
                    
                    if not first_item.get('data'):
                        raise DataFeedError(f"No data returned for {ticker} {field}")
                    
                    # Parse JSON string
                    df = pd.read_json(StringIO(first_item['data']), orient='split', date_unit='ms')
                    
                    # Handle date column
                    if 'date' in df.columns and df['date'].dtype == 'int64':
                        df['date'] = pd.to_datetime(df['date'], unit='ms')
                    
                    # Rename field column to 'value' (case-insensitive)
                    field_upper = field.upper()
                    for col in df.columns:
                        if col.upper() == field_upper:
                            df = df.rename(columns={col: 'value'})
                            break
                    
                    return df
            
            # Check if this is a compact format response (single object with structured data)
            elif isinstance(response, dict) and 'fields' in response and 'data' in response:
                logger.debug("Parsing Bridge API compact response format")
                
                # Extract data for the requested ticker
                ticker_key = ticker.upper()  # Use uppercase to match response
                if ticker_key not in response['data']:
                    raise DataFeedError(f"No data found for ticker {ticker}")
                
                # Store the ticker from the response (Bloomberg-normalized)
                # In compact format, the ticker key is the normalized ticker
                self._last_response_ticker = ticker_key
                logger.debug(f"Stored response ticker: '{ticker_key}' (input was: '{ticker}')")
                
                # Get field index
                fields = response['fields']
                field_upper = field.upper()
                if field_upper not in fields:
                    raise DataFeedError(f"Field {field} not found in response")
                
                field_index = fields.index(field_upper)
                
                # Extract dates and values from the ticker data
                ticker_data = response['data'][ticker_key]
                dates = ticker_data['dates']
                values = ticker_data['data']
                
                # Create DataFrame
                data = []
                for i, date_str in enumerate(dates):
                    if i < len(values) and field_index < len(values[i]):
                        data.append({
                            'date': pd.to_datetime(date_str),
                            'value': values[i][field_index]
                        })
                
                if not data:
                    raise DataFeedError(f"No data found for {ticker} {field}")
                
                df = pd.DataFrame(data)
                df = df.set_index('date')
                
                return df
            
            # If we get here, the response format is unexpected
            raise DataFeedError(f"Unexpected response format for {ticker} {field}")
            
        except Exception as e:
            logger.error(f"Failed to parse Bridge API response: {e}")
            raise DataFeedError(f"Failed to parse Bridge API response: {e}")
    
    def _parse_bridge_reference_response(self, response: List[Dict[str, Any]], ticker: str) -> Dict[str, Any]:
        """
        Parse Bridge API reference data response, handling compact format and legacy formats.
        
        Args:
            response: Bridge API response
            ticker: Requested ticker
            
        Returns:
            Dictionary mapping field names to values
        """
        try:
            result = {}
            
            # Check if this is the compact format (list of dictionaries directly)
            if isinstance(response, list) and len(response) > 0:
                first_item = response[0]
                
                # Compact format: [{'ticker': 'spx index', 'field': 'PX_LAST', 'value': 6600.35}, ...]
                if isinstance(first_item, dict) and 'ticker' in first_item:
                    logger.debug("Parsing Bridge API compact reference response format")
                    
                    # Filter for the requested ticker
                    ticker_data = [item for item in response if item.get('ticker', '').lower() == ticker.lower()]
                    
                    if ticker_data:
                        # Store the ticker from the response (Bloomberg-normalized)
                        response_ticker = ticker_data[0].get('ticker', ticker)
                        self._last_response_ticker = response_ticker
                        logger.debug(f"Stored response ticker: '{response_ticker}' (input was: '{ticker}')")
                    
                    for item in ticker_data:
                        if 'field' in item and 'value' in item:
                            result[item['field']] = item['value']
                    
                    return result
                
                # Legacy format: [{'data': 'json_string'}, ...]
                elif isinstance(first_item, dict) and 'data' in first_item:
                    logger.debug("Parsing Bridge API legacy reference response format")
                    
                    for item in response:
                        if 'data' in item:
                            data = pd.read_json(StringIO(item['data']), orient='split')
                            for _, row in data.iterrows():
                                if 'fld' in row and 'value' in row:
                                    result[row['fld']] = row['value']
                    
                    return result
            
            # If we get here, the response format is unexpected
            raise DataFeedError(f"Unexpected reference response format for {ticker}")
            
        except Exception as e:
            logger.error(f"Failed to parse Bridge API reference response: {e}")
            raise DataFeedError(f"Failed to parse Bridge API reference response: {e}")
    
    def _make_request(self, endpoint: str, payload: Dict[str, Any], 
                     server_id: Optional[int] = None) -> Dict[str, Any]:
        """Make HTTP request to Bridge API with optimized connection pooling."""
        url = f"{self._get_server_url(server_id)}/{endpoint}"
        
        start_time = time.time()
        
        try:
            logger.debug(f"Bridge API request to {url}: {payload}")
            
            # Use optimized session if available, otherwise fall back to requests.post
            if self.session:
                response = self.session.post(
                    url, 
                    json=payload, 
                    timeout=self.config.timeout,
                    proxies={'http': None, 'https': None}  # Disable proxy for Bridge API
                )
            else:
                # Fallback to direct requests.post
                response = requests.post(
                    url, 
                    json=payload, 
                    timeout=self.config.timeout,
                    proxies={'http': None, 'https': None}  # Disable proxy for Bridge API
                )
            
            response.raise_for_status()
            
            # Log timing for performance monitoring
            end_time = time.time()
            timing_ms = (end_time - start_time) * 1000
            logger.debug(f"Bridge API request completed in {timing_ms:.2f} ms")
            
            # Also log at INFO level for performance monitoring
            if timing_ms > 1000:  # Log slow requests at INFO level
                logger.info(f"🐌 SLOW Bridge API request: {timing_ms:.1f}ms to {url}")
            elif timing_ms > 500:  # Log moderate requests at INFO level
                logger.info(f"⏱️ Bridge API request: {timing_ms:.1f}ms to {url}")
            else:
                logger.debug(f"⚡ Fast Bridge API request: {timing_ms:.1f}ms to {url}")
            
            return response.json()
            
        except requests.RequestException as e:
            end_time = time.time()
            timing_ms = (end_time - start_time) * 1000
            logger.error(f"Bridge API request failed after {timing_ms:.2f} ms: {e}")
            raise DataFeedError(f"Bridge API request failed: {e}")
    
    def _make_request_auto(self, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a request with automatic fallback to all servers.
        
        Args:
            endpoint: API endpoint (e.g., "gd1")
            payload: Request payload containing ticker and other parameters
            
        Returns:
            API response data
            
        Raises:
            DataFeedError: If all servers fail
        """
        # Extract ticker from payload for logging
        ticker = payload.get('tkr', 'unknown')
        
        try:
            # Use current server directly since _ensure_usable_server() already found the best one
            response = self._make_request(endpoint, payload)
            
            if not response:
                raise DataFeedError(f"No data returned for ticker {ticker}")
            
            return response
            
        except DataFeedError:
            # If current server fails, fall back to trying all servers
            logger.warning(f"Current server failed, trying all servers for ticker {ticker}")
            try:
                response = self._try_all_servers(endpoint, payload)
                
                if not response:
                    raise DataFeedError(f"No data returned for ticker {ticker}")
                
                return response
                
            except Exception as e:
                logger.error(f"Bridge API request failed for ticker {ticker}: {e}")
                raise DataFeedError(f"Bridge API request failed: {e}")
        except Exception as e:
            logger.error(f"Bridge API request failed for ticker {ticker}: {e}")
            raise DataFeedError(f"Bridge API request failed: {e}")

    def _try_all_servers(self, endpoint: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Try request on all available servers with smart fallback to service registry.
        
        If use_proxy=True and proxy_failover=False, fail fast (raise error) instead of trying other servers.
        """
        servers = list(self.config.servers.keys())
        
        # Check if proxy-only mode (no failover)
        if self.config.use_proxy and not self.config.proxy_failover:
            # Only try the proxy (should be server_id 0)
            if 0 in self.config.servers:
                try:
                    self.current_server = 0
                    return self._make_request(endpoint, payload, 0)
                except DataFeedError as e:
                    error_msg = f"Proxy server failed and failover is disabled (proxy_failover=False): {e}"
                    logger.error(error_msg)
                    raise DataFeedError(error_msg)
            else:
                raise DataFeedError("Proxy mode enabled but proxy not found in server list")
        
        # Try current server first, then others
        server_order = [self.current_server] + [s for s in servers if s != self.current_server]
        
        last_error = None
        
        for server_id in server_order:
            try:
                self.current_server = server_id
                return self._make_request(endpoint, payload, server_id)
            except DataFeedError as e:
                last_error = e
                logger.warning(f"Server {server_id} failed: {e}")
                continue
        
        # If all configured servers failed and we have service manager, try to find new servers
        # Skip this if proxy-only mode (proxy_failover=False)
        if self.service_manager and self.db_manager and not (self.config.use_proxy and not self.config.proxy_failover):
            logger.info("All configured servers failed, searching service registry for alternatives...")
            try:
                usable_server_info = self.service_manager.find_usable_server(
                    timeout=10,
                    attempt_recovery=True  # Attempt recovery when all servers fail
                )
                
                if usable_server_info:
                    server = usable_server_info['server']
                    logger.info(f"Found alternative server: {server.server_address}")
                    
                    # Check if this server is allowed by configuration
                    if self.server_filter.is_server_allowed(server.server_address):
                        # Add this server to our config and try it
                        new_server_id = max(self.config.servers.keys()) + 1 if self.config.servers else 0
                        self.config.servers[new_server_id] = server.server_address
                        self.current_server = new_server_id
                        self.last_check[new_server_id] = datetime.now()
                        
                        try:
                            return self._make_request(endpoint, payload, new_server_id)
                        except DataFeedError as e:
                            logger.error(f"Alternative server also failed: {e}")
                            last_error = e
                    else:
                        logger.warning(f"Alternative server {server.server_address} is not allowed by configuration")
                else:
                    logger.error("No usable servers found in service registry")
            except Exception as e:
                logger.error(f"Failed to search service registry: {e}")
        
        # If we get here, all servers failed
        error_msg = "All Bridge API servers failed"
        if last_error:
            error_msg += f" (last error: {last_error})"
        raise DataFeedError(error_msg)
    
    def _ensure_usable_server(self, server_id: Optional[int] = None, force_check: bool = False) -> bool:
        """
        Ensure we have a usable server, finding alternatives from service registry if needed.
        
        Args:
            server_id: Specific server ID to check, or None for current server
            force_check: Force a server check even if recently checked
            
        Returns:
            True if we have a usable server, False otherwise
        """
        srv_id = server_id if server_id is not None else self.current_server
        
        # Only check server usability periodically to avoid performance impact
        now = datetime.now()
        if not force_check and (now - self.last_server_check).seconds < self.server_check_interval:
            return True  # Skip check if we checked recently
        
        self.last_server_check = now
        
        # Check if we need to refresh server list (every 5 minutes)
        if (now - self.last_check.get(srv_id, datetime.min)).seconds > 300:
            if self.config.use_database_servers and self.db_manager:
                self.refresh_servers_from_database()
            self.last_check[srv_id] = now
        
        # If we have a service manager, use it to find a usable server
        if self.service_manager and self.db_manager:
            try:
                usable_server_info = self.service_manager.find_usable_server(
                    timeout=5,  # Quick check
                    attempt_recovery=False  # Don't attempt recovery during normal operation
                )
                
                if usable_server_info:
                    server = usable_server_info['server']
                    
                    # Check if this server is allowed by configuration
                    if not self.server_filter.is_server_allowed(server.server_address):
                        logger.debug(f"Usable server {server.server_address} is not allowed by configuration")
                        return False
                    
                    # Update current server if we found a better one
                    for srv_id, server_addr in self.config.servers.items():
                        if server_addr == server.server_address:
                            self.current_server = srv_id
                            logger.debug(f"Selected usable server: {server.server_address}")
                            return True
                    
                    # If the usable server is not in our config, add it
                    new_server_id = max(self.config.servers.keys()) + 1 if self.config.servers else 0
                    self.config.servers[new_server_id] = server.server_address
                    self.current_server = new_server_id
                    self.last_check[new_server_id] = now
                    logger.info(f"Added new usable server to config: {server.server_address}")
                    return True
                else:
                    logger.warning("No usable servers found in service registry")
                    return False
                    
            except Exception as e:
                logger.warning(f"Failed to check service registry: {e}")
                # Fall back to trying current server
        
        # If no service manager or check failed, assume current server is usable
        return True
    
    def refresh_servers_from_database(self):
        """Refresh server list from database."""
        if self.config.use_database_servers and self.db_manager and self.service_manager:
            try:
                old_servers = self.config.servers.copy()
                # Load both proxy and direct servers, but only use direct servers for refresh
                _, loaded_servers = self.service_manager.load_all_servers_from_database()
                # Filter servers based on configuration
                self.config.servers = self.server_filter.filter_allowed_servers(loaded_servers)
                
                # Update last_check for new servers
                for server_id in self.config.servers.keys():
                    if server_id not in self.last_check:
                        self.last_check[server_id] = datetime.now()
                
                # Remove old servers from last_check
                for server_id in list(self.last_check.keys()):
                    if server_id not in self.config.servers:
                        del self.last_check[server_id]
                
                logger.info(f"Bridge API servers refreshed from database: {len(self.config.servers)} allowed")
                return True
            except Exception as e:
                logger.error(f"Failed to refresh servers from database: {e}")
                return False
        return False
    
    def _build_bridge_payload(self, 
                             function: str,
                             tickers: List[str], 
                             fields: List[str],
                             start_date: Optional[str] = None,
                             end_date: Optional[str] = None,
                             frequency: Optional[str] = None,
                             currency: Optional[str] = None,
                             response_format: str = "compact",
                             **kwargs) -> Dict[str, Any]:
        """
        Build Bridge API payload with common parameters.
        
        Args:
            function: Bridge API function ('bdh', 'ref', 'bulk', 'canonical')
            tickers: List of ticker symbols
            fields: List of field names
            start_date: Start date in YYYY-MM-DD format (for historical data)
            end_date: End date in YYYY-MM-DD format (for historical data)
            frequency: Data frequency (D, W, M, Q, A) (for historical data)
            currency: Currency override
            response_format: Response format ('compact' or 'default')
            **kwargs: Additional parameters
            
        Returns:
            Dictionary containing Bridge API payload
        """
        # Base payload
        payload = {
            "fun": function,
            "tickers": [ticker.upper() for ticker in tickers],
            "fields": [field.upper() for field in fields],
            "response_format": response_format
        }
        
        # Add date parameters for historical data
        if start_date:
            payload["startDate"] = self.format_date(start_date)
        if end_date:
            payload["endDate"] = self.format_date(end_date)
        
        # Build elements (elms) array for Bloomberg parameters
        elms = []
        
        # Add frequency for historical data
        if frequency and frequency.upper() != 'D':  # Only add if not default daily
            frequency_map = {
                'D': 'DAILY',
                'W': 'WEEKLY', 
                'M': 'MONTHLY',
                'Q': 'QUARTERLY',
                'S': 'SEMI_ANNUALLY',
                'A': 'YEARLY'
            }
            bridge_freq = frequency_map.get(frequency.upper(), 'DAILY')
            elms.append(("periodicitySelection", bridge_freq))
        
        # Add currency (only if provided and not '-')
        if currency and currency.strip() and currency.upper() != '-':
            elms.append(("currency", currency.upper()))
        
        # Add elements to payload if any
        if elms:
            payload["elms"] = elms
        
        # Add any additional parameters
        payload.update(kwargs)
        
        return payload
    
    def get_last_response_ticker(self) -> Optional[str]:
        """
        Get the ticker from the last Bridge API response.
        
        Returns:
            Ticker from the last response or None if no call made yet
        """
        return getattr(self, '_last_response_ticker', None)
    
    def get_ticker_detail(self, ticker: str) -> Optional[Dict[str, Any]]:
        """
        Get ticker detail information for Meta table entry.
        
        Args:
            ticker: Bloomberg ticker (e.g., 'SPY US Equity', 'AAPL')
            
        Returns:
            Dictionary with ticker detail information or None if failed
        """
        return self.bbg_ticker_detail.get_ticker_detail(ticker)
    
    def get_canonical_ticker(self, ticker: str) -> Optional[str]:
        """
        Get the canonical ticker for Meta table entry.
        
        Args:
            ticker: Bloomberg ticker (e.g., 'SPY US Equity', 'AAPL')
            
        Returns:
            Canonical ticker string or None if failed
        """
        return self.bbg_ticker_detail.get_canonical_ticker(ticker)
    
    def get_data(self, ticker: str, currency: str = None, **kwargs) -> pd.DataFrame:
        """
        Retrieve Bloomberg historical data via Bridge API.
        
        Args:
            ticker: Bloomberg ticker (e.g., 'SPX Index')
            **kwargs: Bridge-specific parameters including:
                - field: Bloomberg field (e.g., 'PX_LAST')
                - frequency: Data frequency (D, W, M, Q, A)
                - start_date: Start date (YYYY-MM-DD or YYYYMMDD)
                - end_date: End date (YYYY-MM-DD or YYYYMMDD)
                - currency: Currency override
                - Additional Bloomberg parameters
                
        Returns:
            DataFrame with date index and value column
        """
        # Extract common parameters with defaults
        field = kwargs.pop('field', 'PX_LAST')
        frequency = kwargs.pop('frequency', 'D')
        start_date = kwargs.pop('start_date', None)
        end_date = kwargs.pop('end_date', None)
        # currency is now an explicit parameter, not from kwargs
        
        # Only check for usable server periodically, not before every call
        self._ensure_usable_server()
        
        # Build request payload using centralized builder
        payload = self._build_bridge_payload(
            function="bdh",
            tickers=[ticker],
            fields=[field],
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            currency=currency,
            response_format="compact",
            **kwargs
        )
        
        # Make request with automatic fallback to all servers
        response = self._make_request_auto("gd1", payload)
        
        # Parse response - handle standard, compact, and legacy formats
        df = self._parse_bridge_response(response, ticker, field)
        
        return self.clean_ts_dataframe(df)
    
    def get_reference_data(self, ticker: str, fields: List[str], **kwargs) -> Dict[str, Any]:
        """
        Retrieve Bloomberg reference data via Bridge API.
        
        Args:
            ticker: Bloomberg ticker
            fields: List of Bloomberg reference fields
            **kwargs: Additional parameters including currency override
            
        Returns:
            Dictionary mapping field names to values
        """
        # Only check for usable server periodically, not before every call
        self._ensure_usable_server()
        
        # Extract currency from kwargs
        currency = kwargs.pop('currency', None)
        
        # Build request payload using centralized builder
        payload = self._build_bridge_payload(
            function="ref",
            tickers=[ticker],
            fields=fields if isinstance(fields, list) else [fields],
            currency=currency,
            response_format="compact",
            **kwargs
        )
        
        # Make request with automatic fallback to all servers
        response = self._make_request_auto("gd1", payload)
        
        # Parse response - handle compact format and legacy formats
        result = self._parse_bridge_reference_response(response, ticker)
        
        return result
    
    def bulk_data_request(self, requests: List[Dict[str, Any]]) -> List[pd.DataFrame]:
        """
        Make multiple data requests efficiently.
        
        Args:
            requests: List of request dictionaries
            
        Returns:
            List of DataFrames corresponding to each request
        """
        results = []
        
        for req in requests:
            try:
                df = self.get_data(**req)
                results.append(df)
            except DataFeedError as e:
                logger.warning(f"Bulk request failed for {req}: {e}")
                results.append(pd.DataFrame())  # Empty DataFrame for failed requests
        
        return results
    
    def bulk_get_historical(self, tickers: List[str], field: str, 
                           start_date: str, end_date: Optional[str] = None,
                           frequency: str = 'D', currency: Optional[str] = None,
                           **kwargs) -> Dict[str, Any]:
        """
        Get historical data for multiple tickers and single field using Bridge API.
        
        This method efficiently retrieves data for multiple tickers in a single API call,
        rather than making individual requests for each ticker.
        
        Args:
            tickers: List of Bloomberg tickers (e.g., ['SPX Index', 'NDX Index'])
            field: Single field name to retrieve (e.g., 'PX_LAST', 'AF3MN')
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format (optional)
            frequency: Data frequency (D, W, M, Q, A)
            currency: Currency override (optional)
            **kwargs: Additional Bloomberg parameters
            
        Returns:
            Dictionary containing:
            - 'data': List of data records from Bridge API
            - 'metadata': Dictionary with field, frequency, currency, and other parameters
            
        Raises:
            DataFeedError: If the request fails
        """
        # Only check for usable server periodically, not before every call
        self._ensure_usable_server()
        
        # Build request payload using centralized builder
        payload = self._build_bridge_payload(
            function="bdh",
            tickers=tickers,
            fields=[field],
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            currency=currency,
            response_format="default",  # Use default format for bulk operations
            **kwargs
        )
        
        try:
            logger.info(f"Bulk historical data request for {len(tickers)} tickers, field: {field}")
            logger.debug(f"Date range: {start_date} to {end_date or 'today'}")
            
            # Make request with automatic fallback to all servers
            response = self._make_request_auto("gd1", payload)
            
            if not response:
                raise DataFeedError('No data returned from Bridge API')
            
            # Return the data with metadata for future mapping
            if isinstance(response, list):
                logger.info(f"Successfully retrieved {len(response)} records for {len(tickers)} tickers")
                
                # Create metadata for future mapping
                metadata = {
                    'field': field,
                    'frequency': frequency,
                    'currency': currency if currency is not None else '-',
                    'source': 'BB',
                    'start_date': start_date,
                    'end_date': end_date,
                    'tickers': tickers,
                    'ticker_count': len(tickers),
                    'record_count': len(response),
                    'kwargs': kwargs
                }
                
                return {
                    'data': response,
                    'metadata': metadata
                }
            else:
                raise DataFeedError('Unexpected response format from Bridge API')
            
        except Exception as e:
            error_msg = f"Bulk historical data request failed: {e}"
            logger.error(error_msg)
            raise DataFeedError(error_msg)
    
    def bulk_get_reference(self, tickers: List[str], field: str,
                          currency: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        """
        Get reference data for multiple tickers and single field using Bridge API.
        
        This method efficiently retrieves reference data for multiple tickers in a single API call,
        rather than making individual requests for each ticker.
        
        Args:
            tickers: List of Bloomberg tickers (e.g., ['SPX Index', 'NDX Index'])
            field: Single field name to retrieve (e.g., 'CUR_MKT_CAP', 'AF3MN')
            currency: Currency override (optional)
            **kwargs: Additional Bloomberg parameters
            
        Returns:
            Dictionary containing:
            - 'data': List of data records from Bridge API
            - 'metadata': Dictionary with field, currency, and other parameters
            
        Raises:
            DataFeedError: If the request fails
        """
        # Only check for usable server periodically, not before every call
        self._ensure_usable_server()
        
        # Build request payload using centralized builder
        payload = self._build_bridge_payload(
            function="ref",
            tickers=tickers,
            fields=[field],
            currency=currency,
            response_format="default",  # Use default format for bulk operations
            **kwargs
        )
        
        try:
            logger.info(f"Bulk reference data request for {len(tickers)} tickers, field: {field}")
            
            # Make request with automatic fallback to all servers
            response = self._make_request_auto("gd1", payload)
            
            if not response:
                raise DataFeedError('No data returned from Bridge API')
            
            # Return the data with metadata for future mapping
            if isinstance(response, list):
                logger.info(f"Successfully retrieved {len(response)} records for {len(tickers)} tickers")
                
                # Create metadata for future mapping
                metadata = {
                    'field': field,
                    'currency': currency if currency is not None else '-',
                    'source': 'BB',
                    'tickers': tickers,
                    'ticker_count': len(tickers),
                    'record_count': len(response),
                    'kwargs': kwargs
                }
                
                return {
                    'data': response,
                    'metadata': metadata
                }
            else:
                raise DataFeedError('Unexpected response format from Bridge API')
            
        except Exception as e:
            error_msg = f"Bulk reference data request failed: {e}"
            logger.error(error_msg)
            raise DataFeedError(error_msg)
    
    def process_bulk_data(self, bulk_response: Dict[str, Any]) -> Dict[str, pd.DataFrame]:
        """
        Process bulk data into DataFrames with meta as combo key.
        
        This method takes the response from bulk_get_historical or bulk_get_reference
        and processes it into a dictionary of DataFrames suitable for data analysis.
        
        Args:
            bulk_response: Response from bulk_get_historical or bulk_get_reference
                          Must contain 'data' and 'metadata' keys
            
        Returns:
            Dictionary mapping ticker to DataFrame with meta as combo key
        """
        import pandas as pd
        from datetime import datetime
        
        # Extract data and metadata from response
        bulk_data = bulk_response['data']
        metadata = bulk_response['metadata']
        field = metadata.get('field')
        frequency = metadata.get('frequency', 'D')
        currency = metadata.get('currency', None)
        use_historical = 'frequency' in metadata
        
        if not bulk_data:
            logger.warning("No data to process")
            return {}
        
        # Extract metadata for combo key
        field_name = field or 'unknown_field'
        combo_key = f"{field_name}_{frequency}_{currency or 'no_ccy'}"
        
        try:
            # Convert to DataFrame once for efficient processing
            df = pd.DataFrame(bulk_data)
            
            if df.empty:
                logger.warning("No data to process")
                return {}
            
            # Find the field column (case-insensitive)
            field_col = None
            for col in df.columns:
                if col.upper() == field.upper():
                    field_col = col
                    break
            
            if field_col is None:
                logger.warning(f"Field {field} not found in response data")
                return {}
            
            # Process data into ticker DataFrames
            ticker_dataframes = {}
            
            for ticker, group_df in df.groupby('ticker'):
                try:
                    if use_historical:
                        # Historical data processing
                        if 'date' in group_df.columns:
                            # Convert date column and set as index
                            group_df = group_df.copy()
                            group_df['date'] = pd.to_datetime(group_df['date'])
                            result_df = group_df.set_index('date')[[field_col]]
                        else:
                            # No date column, use row index
                            result_df = group_df[[field_col]].copy()
                            result_df.index = pd.RangeIndex(len(result_df))
                        
                        # Rename field column to match requested field name
                        result_df = result_df.rename(columns={field_col: field})
                        
                    else:
                        # Reference data processing - create single row with current date
                        current_date = datetime.now().strftime('%Y-%m-%d')
                        
                        # Get the field value from the first record
                        field_value = group_df[field_col].iloc[0] if not group_df.empty else None
                        
                        if field_value is not None:
                            result_df = pd.DataFrame({
                                field: [field_value]
                            }, index=[pd.to_datetime(current_date)])
                        else:
                            logger.warning(f"Field {field} not found in reference data for ticker {ticker}")
                            continue
                    
                    # Use combo key for ticker identification
                    combo_ticker = f"{ticker}_{combo_key}"
                    ticker_dataframes[combo_ticker] = result_df
                    logger.debug(f"Processed {len(result_df)} records for ticker {ticker} (combo: {combo_ticker})")
                    
                except Exception as e:
                    logger.error(f"Error processing ticker {ticker}: {e}")
                    continue
            
            logger.info(f"Successfully processed data for {len(ticker_dataframes)} tickers")
            return ticker_dataframes
            
        except Exception as e:
            logger.error(f"Failed to process bulk data: {e}")
            return {}
    
    def check_server_health(self, server_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Manually check the health of a specific server or current server.
        
        Args:
            server_id: Server ID to check, or None for current server
            
        Returns:
            Dictionary with health status information
        """
        srv_id = server_id if server_id is not None else self.current_server
        
        # Check if server ID exists in config
        if srv_id not in self.config.servers:
            # Try to find any available server if the requested one doesn't exist
            if self.config.servers:
                available_server_id = next(iter(self.config.servers.keys()))
                logger.warning(f"Server ID {srv_id} not found, using available server {available_server_id}")
                srv_id = available_server_id
            else:
                return {
                    'usable': False,
                    'error': f'No servers available in configuration',
                    'server_address': None
                }
        
        server_addr = self.config.servers.get(srv_id)
        if not server_addr:
            return {
                'usable': False,
                'error': f'Invalid server ID: {srv_id}',
                'server_address': None
            }
        
        if self.service_manager and self.db_manager:
            try:
                # Create a temporary ServiceRegistry-like object for health checking
                from masworks.MasDatabase.models import ServiceRegistry
                temp_server = type('TempServer', (), {
                    'server_address': server_addr,
                    'health_url': f'http://{server_addr}/health'
                })()
                
                health_result = self.service_manager.check_server_status(temp_server, timeout=10)
                health_result['server_address'] = server_addr
                return health_result
                
            except Exception as e:
                return {
                    'usable': False,
                    'error': f'Health check failed: {e}',
                    'server_address': server_addr
                }
        else:
            return {
                'usable': True,  # Assume usable if no service manager
                'server_address': server_addr,
                'note': 'No service manager available for detailed health check'
            }
    
    def force_server_refresh(self):
        """Force a refresh of server list and usability check."""
        self.last_server_check = datetime.min  # Force check on next call
        if self.config.use_database_servers and self.db_manager:
            self.refresh_servers_from_database()
        self._ensure_usable_server(force_check=True)
    
    def get_server_filtering_info(self) -> Dict[str, Any]:
        """
        Get information about server filtering configuration.
        
        Returns:
            Dictionary with filtering configuration details
        """
        filtering_info = self.server_filter.get_filtering_info()
        filtering_info.update({
            'current_servers': dict(self.config.servers),
            'current_server': self.current_server,
            'server_count': len(self.config.servers)
        })
        return filtering_info
    
    def validate_server_configuration(self) -> Dict[str, Any]:
        """
        Validate the current server configuration against filtering rules.
        
        Returns:
            Dictionary with validation results
        """
        results = {
            'valid': True,
            'allowed_servers': [],
            'blocked_servers': [],
            'errors': []
        }
        
        if not self.config.servers:
            results['valid'] = False
            results['errors'].append("No servers configured")
            return results
        
        for server_id, server_address in self.config.servers.items():
            if self.server_filter.is_server_allowed(server_address):
                results['allowed_servers'].append({
                    'id': server_id,
                    'address': server_address
                })
            else:
                results['blocked_servers'].append({
                    'id': server_id,
                    'address': server_address
                })
        
        if not results['allowed_servers']:
            results['valid'] = False
            results['errors'].append("No allowed servers found")
        
        return results
    
    def close(self):
        """Close the optimized HTTP session and clean up resources."""
        try:
            if hasattr(self, 'session') and self.session:
                self.session.close()
                logger.info("Closed optimized HTTP session")
        except Exception as e:
            logger.warning(f"Error closing HTTP session: {e}")
    
    def __del__(self):
        """Destructor to ensure session is closed."""
        try:
            self.close()
        except:
            pass
