"""
Bridge API server filtering utility.
Handles server filtering logic based on configuration.
"""

import socket
import logging
from typing import Dict, List

logger = logging.getLogger(__name__)


class BridgeServerFilter:
    """
    Utility class for filtering Bridge API servers based on configuration.
    
    Provides server filtering functionality specifically for Bridge API servers,
    including localhost detection, wildcard matching, and server type filtering.
    """
    
    def __init__(self, allowed_server_types: List[str] = None, 
                 allowed_hosts: List[str] = None, 
                 blocked_hosts: List[str] = None):
        """
        Initialize server filter.
        
        Args:
            allowed_server_types: List of allowed server types ['localhost', 'remote', 'all']
            allowed_hosts: List of specific hostnames/IPs to allow
            blocked_hosts: List of specific hostnames/IPs to block
        """
        self.allowed_server_types = allowed_server_types or ['localhost']
        self.allowed_hosts = allowed_hosts or []
        self.blocked_hosts = blocked_hosts or []
    
    def is_server_allowed(self, server_address: str) -> bool:
        """
        Check if a server address is allowed based on configuration.
        
        Args:
            server_address: Server address in format 'host:port'
            
        Returns:
            True if server is allowed, False otherwise
        """
        try:
            host, port = server_address.split(':')
        except ValueError:
            logger.warning(f"Invalid server address format: {server_address}")
            return False
        
        logger.debug(f"Checking if server {server_address} is allowed")
        logger.debug(f"  allowed_server_types: {self.allowed_server_types}")
        logger.debug(f"  allowed_hosts: {self.allowed_hosts}")
        logger.debug(f"  blocked_hosts: {self.blocked_hosts}")
        
        # Check blocked hosts first
        if self.blocked_hosts:
            for blocked_host in self.blocked_hosts:
                if self._host_matches(host, blocked_host):
                    logger.debug(f"Server {server_address} blocked by blocked_hosts: {blocked_host}")
                    return False
        
        # Check allowed hosts if specified
        if self.allowed_hosts:
            for allowed_host in self.allowed_hosts:
                # Check both host:port format and host-only format
                if (self._host_matches(server_address, allowed_host) or 
                    self._host_matches(host, allowed_host)):
                    logger.debug(f"Server {server_address} allowed by allowed_hosts: {allowed_host}")
                    return True
            logger.debug(f"Server {server_address} not in allowed_hosts list")
            return False
        # If no allowed_hosts specified, fall through to server type checking
        
        # Check server types
        if 'all' in self.allowed_server_types:
            return True
        
        # Check if it's localhost
        is_localhost = self._is_localhost(host)
        
        if 'localhost' in self.allowed_server_types and is_localhost:
            logger.debug(f"Server {server_address} allowed as localhost")
            return True
        
        if 'remote' in self.allowed_server_types and not is_localhost:
            logger.debug(f"Server {server_address} allowed as remote")
            return True
        
        logger.debug(f"Server {server_address} not allowed by server types: {self.allowed_server_types}")
        logger.debug(f"  is_localhost: {is_localhost}")
        return False
    
    def _host_matches(self, host: str, pattern: str) -> bool:
        """Check if host matches a pattern (supports wildcards)."""
        if pattern == host:
            return True
        
        # Simple wildcard support
        if '*' in pattern:
            import fnmatch
            return fnmatch.fnmatch(host.lower(), pattern.lower())
        
        return False
    
    def _is_localhost(self, host: str) -> bool:
        """Check if host is localhost."""
        localhost_names = ['localhost', '127.0.0.1', '::1']
        
        if host.lower() in localhost_names:
            return True
        
        try:
            # Get machine hostname and compare
            hostname = socket.gethostname()
            if host.lower() == hostname.lower():
                return True
            
            # Get FQDN and compare
            fqdn = socket.getfqdn()
            if host.lower() == fqdn.lower():
                return True
            
            # Check if it resolves to localhost
            try:
                resolved = socket.gethostbyname(host)
                if resolved in ['127.0.0.1', '::1']:
                    return True
            except socket.gaierror:
                pass
                
        except Exception as e:
            logger.debug(f"Error checking localhost status for {host}: {e}")
        
        return False
    
    def filter_allowed_servers(self, servers: Dict[int, str]) -> Dict[int, str]:
        """
        Filter a server dictionary to only include allowed servers.
        
        Args:
            servers: Dictionary of server_id -> server_address
            
        Returns:
            Filtered dictionary with only allowed servers
        """
        filtered_servers = {}
        
        for server_id, server_address in servers.items():
            if self.is_server_allowed(server_address):
                filtered_servers[server_id] = server_address
                logger.debug(f"Server {server_id}: {server_address} - ALLOWED")
            else:
                logger.debug(f"Server {server_id}: {server_address} - BLOCKED")
        
        logger.info(f"Filtered servers: {len(filtered_servers)}/{len(servers)} allowed")
        return filtered_servers
    
    def get_filtering_info(self) -> Dict[str, any]:
        """
        Get information about the current filtering configuration.
        
        Returns:
            Dictionary with filtering configuration details
        """
        return {
            'allowed_server_types': self.allowed_server_types,
            'allowed_hosts': self.allowed_hosts,
            'blocked_hosts': self.blocked_hosts
        }
