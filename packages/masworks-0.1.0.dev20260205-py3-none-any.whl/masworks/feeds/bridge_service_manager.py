"""
Bridge API Service Manager
Handles service discovery, health checking, and server selection for Bridge API.
"""

import os
import socket
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)


class BridgeServiceManager:
    """
    Manages Bridge API service discovery, health checking, and server selection.
    Separated from BridgeConfig to maintain single responsibility principle.
    """
    
    def __init__(self, config, db_manager=None):
        """
        Initialize Bridge Service Manager.
        
        Args:
            config: BridgeConfig instance
            db_manager: DatabaseManager instance (optional)
        """
        self.config = config
        self.db_manager = db_manager
    
    def load_all_servers_from_database(self) -> tuple:
        """
        Load both proxy and direct servers from database in a single query.
        This is more efficient than separate queries and eliminates duplication.
        
        Returns:
            Tuple of (proxy_address: Optional[str], direct_servers: Dict[int, str])
        """
        proxy = None
        direct_servers = {}
        
        if not self.db_manager:
            return None, {}
        
        try:
            from ..MasDatabase.models import ServiceRegistry
            
            with self.db_manager.get_session() as session:
                # Single query to get both proxy and direct servers
                services = session.query(ServiceRegistry).filter(
                    ServiceRegistry.status == 'started',
                    ServiceRegistry.service_name.in_(['bridge_api', self.config.proxy_service_name])
                ).order_by(ServiceRegistry.last_heartbeat.desc()).all()
                
                if not services:
                    logger.warning("No started Bridge API services found in database")
                    return None, {}
                
                # Get localhost machine names for server prioritization
                localhost_names = self._get_localhost_names()
                
                # Separate proxy and direct servers
                localhost_servers = []
                remote_servers = []
                
                for service in services:
                    server_addr = service.server_address
                    
                    if service.service_name == self.config.proxy_service_name:
                        # This is the proxy
                        proxy = server_addr
                        logger.debug(f"Found proxy: {proxy}")
                    elif service.service_name == 'bridge_api':
                        # This is a direct server
                        # Check if it's localhost for prioritization
                        is_localhost = any(
                            service.host.lower() in localhost_name.lower() or
                            localhost_name.lower() in service.host.lower()
                            for localhost_name in localhost_names
                        )
                        
                        if is_localhost:
                            localhost_servers.append(server_addr)
                        else:
                            remote_servers.append(server_addr)
                
                # Build direct servers dictionary (localhost first)
                server_id = 0
                for server_addr in localhost_servers:
                    direct_servers[server_id] = server_addr
                    server_id += 1
                for server_addr in remote_servers:
                    direct_servers[server_id] = server_addr
                    server_id += 1
                
                logger.info(f"Loaded proxy and {len(direct_servers)} direct servers from database")
                logger.info(f"Localhost servers: {len(localhost_servers)}, Remote servers: {len(remote_servers)}")
                return proxy, direct_servers
                
        except Exception as e:
            logger.error(f"Failed to load servers from database: {e}")
            return None, {}
    
    def _get_localhost_names(self) -> List[str]:
        """Get various localhost machine names for matching."""
        localhost_names = ['localhost', '127.0.0.1']
        
        try:
            # Get machine hostname
            hostname = socket.gethostname()
            localhost_names.append(hostname)
            
            # Get fully qualified domain name
            fqdn = socket.getfqdn()
            if fqdn != hostname:
                localhost_names.append(fqdn)
            
            # Get machine name (Windows)
            if os.name == 'nt':
                try:
                    import platform
                    machine_name = platform.node()
                    if machine_name:
                        localhost_names.append(machine_name)
                except:
                    pass
                    
        except Exception as e:
            logger.debug(f"Could not get additional localhost names: {e}")
        
        return list(set(localhost_names))  # Remove duplicates
    
    def check_server_status(self, server, timeout: int = 10, attempt_recovery: bool = True) -> Dict[str, Any]:
        """
        Check if a server is usable by calling the /health endpoint.
        If Bloomberg is down, attempts recovery using /health/ensure.
        
        Args:
            server: ServiceRegistry instance
            timeout: Request timeout in seconds
            attempt_recovery: Whether to attempt recovery if Bloomberg is down
            
        Returns:
            Dictionary with usability status and details
        """
        try:
            import requests
            
            # First attempt recovery if needed
            if attempt_recovery:
                self._attempt_recovery(server, timeout)
            
            # Then check current health
            health_result = self._check_bridge_api_health(server, timeout)
            
            # If API is not running or has connection issues, it's not usable
            if 'error' in health_result:
                return health_result
            
            # If Bloomberg is up and session is healthy, it's usable
            if health_result['usable']:
                return {
                    **health_result,
                    'recovery_attempted': False,
                    'recovery_successful': None
                }
            
            # If Bloomberg is down but API is healthy, attempt recovery
            if attempt_recovery and health_result['api_healthy'] and not health_result['bloomberg_up']:
                logger.info(f"Bloomberg is down on {server.server_address}, attempting recovery...")
                recovery_result = self._attempt_recovery(server, timeout)
                
                if recovery_result['recovery_successful']:
                    # Check health again after recovery attempt
                    logger.info(f"Recovery attempted on {server.server_address}, checking health again...")
                    health_after_recovery = self._check_bridge_api_health(server, timeout)
                    
                    return {
                        **health_after_recovery,
                        'recovery_attempted': True,
                        'recovery_successful': True,
                        'recovery_message': recovery_result['message']
                    }
                else:
                    return {
                        **health_result,
                        'recovery_attempted': True,
                        'recovery_successful': False,
                        'recovery_error': recovery_result['error']
                    }
            
            # If API is unhealthy, it's not usable
            return {
                **health_result,
                'recovery_attempted': False,
                'recovery_successful': None
            }
                
        except Exception as e:
            logger.debug(f"Health check failed for {server.server_address}: {e}")
            return {
                'usable': False,
                'error': f'Unexpected error: {str(e)}',
                'raw_response': None
            }
    
    def _check_bridge_api_health(self, server, timeout: int = 10) -> Dict[str, Any]:
        """
        Check Bridge API health and determine if it's usable.
        
        Args:
            server: ServiceRegistry instance
            timeout: Request timeout in seconds
            
        Returns:
            Dictionary with health status and details
        """
        try:
            import requests
            
            # Database now stores FQDN, use server_address directly
            server_address = server.server_address
            health_url = f"http://{server_address}/health"
            
            # Call health endpoint
            response = requests.get(
                health_url,
                timeout=timeout,
                proxies={'http': None, 'https': None}  # Disable proxy for internal servers
            )
            
            if response.status_code == 200:
                health_data = response.json()
                
                # Check if API is healthy
                api_healthy = health_data.get('status') == 'healthy'
                
                # Check if Bloomberg session is usable
                session_info = health_data.get('session', {})
                bloomberg_info = health_data.get('bloomberg', {})
                
                session_healthy = session_info.get('is_healthy', False)
                session_exists = session_info.get('exist', False)
                bloomberg_up = bloomberg_info.get('status') == 'up'
                
                # Determine if API is usable
                is_usable = api_healthy and session_healthy and session_exists and bloomberg_up
                
                return {
                    'usable': is_usable,
                    'api_healthy': api_healthy,
                    'session_healthy': session_healthy,
                    'session_exists': session_exists,
                    'bloomberg_up': bloomberg_up,
                    'uptime_seconds': health_data.get('uptime_seconds'),
                    'reconnection_count': session_info.get('reconnection_count', 0),
                    'total_requests': session_info.get('total_requests_processed', 0),
                    'failed_requests': session_info.get('failed_requests', 0),
                    'raw_response': health_data
                }
            else:
                return {
                    'usable': False,
                    'error': f'HTTP {response.status_code}: {response.text}',
                    'raw_response': None
                }
                
        except requests.exceptions.ConnectionError:
            return {
                'usable': False,
                'error': 'Connection failed - Bridge API not running',
                'raw_response': None
            }
        except requests.exceptions.Timeout:
            return {
                'usable': False,
                'error': 'Request timeout - Bridge API not responding',
                'raw_response': None
            }
        except Exception as e:
            return {
                'usable': False,
                'error': f'Unexpected error: {str(e)}',
                'raw_response': None
            }
    
    def _attempt_recovery(self, server, timeout: int = 30) -> Dict[str, Any]:
        """
        Attempt to recover Bloomberg session using /health/ensure.
        
        Args:
            server: ServiceRegistry instance
            timeout: Request timeout in seconds
            
        Returns:
            Dictionary with recovery status
        """
        try:
            import requests
            
            # Database now stores FQDN, use server_address directly
            server_address = server.server_address
            recovery_url = f"http://{server_address}/health/ensure"
            response = requests.post(
                recovery_url,
                timeout=timeout,
                proxies={'http': None, 'https': None}  # Disable proxy for internal servers
            )
            
            if response.status_code == 200:
                return {
                    'recovery_successful': True,
                    'message': 'Session recovery attempted successfully'
                }
            else:
                return {
                    'recovery_successful': False,
                    'error': f'Recovery failed: HTTP {response.status_code}: {response.text}'
                }
                
        except requests.exceptions.Timeout:
            return {
                'recovery_successful': False,
                'error': 'Recovery timeout - Bloomberg may be down'
            }
        except Exception as e:
            return {
                'recovery_successful': False,
                'error': f'Recovery error: {str(e)}'
            }
    
    def find_usable_server(self, timeout: int = 10, attempt_recovery: bool = True) -> Optional[Dict[str, Any]]:
        """
        Find the first usable Bridge API server from the database.
        
        Args:
            timeout: Request timeout in seconds
            attempt_recovery: Whether to attempt recovery if Bloomberg is down
            
        Returns:
            Dictionary with server info and health status, or None if no usable server found
        """
        if not self.db_manager:
            logger.warning("No database manager provided, cannot find servers from database")
            return None
            
        try:
            from ..MasDatabase.models import ServiceRegistry
            
            with self.db_manager.get_session() as session:
                # Query started Bridge API servers (exact match for bridge_api, excludes proxy)
                servers = session.query(ServiceRegistry).filter(
                    ServiceRegistry.service_name == 'bridge_api',
                    ServiceRegistry.status == 'started'
                ).order_by(ServiceRegistry.last_heartbeat.desc()).all()
                
                if not servers:
                    logger.warning("No started Bridge API servers found in database")
                    return None
                
                # Detach objects from session so they can be used after session closes
                for server in servers:
                    session.expunge(server)
                
                # Get localhost machine name for comparison
                localhost_names = self._get_localhost_names()
                
                # Separate localhost and remote servers
                localhost_servers = []
                remote_servers = []
                
                for server in servers:
                    # Database now stores FQDN, use server_address directly
                    
                    # Check if this is a localhost server
                    is_localhost = any(
                        server.host.lower() in localhost_name.lower() or
                        localhost_name.lower() in server.host.lower()
                        for localhost_name in localhost_names
                    )
                    
                    if is_localhost:
                        # Change host to 'localhost' for localhost servers
                        server.host = 'localhost'
                        localhost_servers.append(server)
                    else:
                        remote_servers.append(server)
                
                # Check localhost servers first, then remote servers
                servers_to_check = localhost_servers + remote_servers
                
                for server in servers_to_check:
                    logger.info(f"Checking server {server.server_address}...")
                    health_result = self.check_server_status(server, timeout, attempt_recovery)
                    
                    if health_result['usable']:
                        # Database now stores FQDN, use server_address directly
                        server_address = server.server_address
                        logger.info(f"Found usable server: {server_address}")
                        return {
                            'server': server,
                            'server_address': server_address,
                            'health_result': health_result,
                            'is_localhost': server in localhost_servers
                        }
                    else:
                        logger.warning(f"Server {server.server_address} not usable: {health_result.get('error', 'Unknown error')}")
                
                logger.error("No usable Bridge API servers found")
                return None
                
        except Exception as e:
            logger.error(f"Failed to find usable server: {e}")
            return None
