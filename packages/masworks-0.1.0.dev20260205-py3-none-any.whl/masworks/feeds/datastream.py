"""
Datastream data feed implementation.
"""
import logging
import os
from typing import Dict, Any, Optional, List
import pandas as pd
from pandas.tseries.offsets import MonthEnd

from .base import DataFeedBase, DataFeedError
from ..config import DatastreamConfig

logger = logging.getLogger(__name__)


class DatastreamFeed(DataFeedBase):
    """Datastream data feed using DatastreamPy library."""
    
    def __init__(self, config: DatastreamConfig):
        super().__init__()
        self.config = config
        self._ds_client = None
        self._setup_proxy()
    
    def _setup_proxy(self):
        """Setup proxy settings for Datastream."""
        os.environ['HTTP_PROXY'] = f"{self.config.proxy_host}:{self.config.proxy_port}"
        os.environ['HTTPS_PROXY'] = f"{self.config.proxy_host}:{self.config.proxy_port}"
    
    @property
    def ds_client(self):
        """Lazy initialization of Datastream client."""
        if self._ds_client is None:
            try:
                import DatastreamPy as dsweb
                self._ds_client = dsweb.DataClient(
                    None,  # No config file
                    username=self.config.username,
                    password=self.config.password
                )
            except ImportError:
                raise DataFeedError(
                    "DatastreamPy library not installed. "
                    "Install with: pip install DatastreamPy"
                )
            except Exception as e:
                raise DataFeedError(f"Failed to initialize Datastream client: {e}")
        
        return self._ds_client
    
    def get_data(self, ticker: str, **kwargs) -> pd.DataFrame:
        """
        Retrieve Datastream time series data.
        
        Args:
            ticker: Datastream ticker/mnemonic
            **kwargs: Datastream-specific parameters including:
                - field: Datastream field (optional, can be part of ticker)
                - frequency: Data frequency (D, W, M, Q, A)
                - start_date: Start date (YYYY-MM-DD format)
                - end_date: End date (YYYY-MM-DD format)
                - Additional Datastream parameters
                
        Returns:
            DataFrame with date index and value column
        """
        # Extract common parameters with defaults
        field = kwargs.pop('field', '')
        frequency = kwargs.pop('frequency', 'M')
        start_date = kwargs.pop('start_date', None)
        end_date = kwargs.pop('end_date', None)
        
        try:
            # Prepare parameters for Datastream
            ds_params = {
                'tickers': ticker,
                'freq': self._map_frequency(frequency),
            }
            
            # Add fields if specified
            if field:
                ds_params['fields'] = [field] if isinstance(field, str) else field
            
            # Add date range
            if start_date:
                ds_params['start'] = self._format_ds_date(start_date)
            if end_date:
                ds_params['end'] = self._format_ds_date(end_date)
            
            # Filter out metadata parameters that DatastreamPy doesn't expect
            metadata_fields = {'description', 'category', 'cname', 'cname2', 'cat', 'note', 'Lag', 'Lag2', 'tempflag', 'sid', 'json',
                              'updated_by', 'auto_create'}
            filtered_kwargs = {k: v for k, v in kwargs.items() if k not in metadata_fields}
            
            # Add additional parameters (excluding metadata)
            ds_params.update(filtered_kwargs)
            
            logger.info(f"Datastream request: {ds_params}")
            
            # Make request using DatastreamPy format
            # DatastreamPy uses kind=1 for timeseries data
            ds_params['kind'] = 1
            df = self.ds_client.get_data(**ds_params)
            
            logger.info(f"DatastreamPy returned DataFrame with shape: {df.shape}, columns: {df.columns.tolist()}")
            
            if df.empty:
                raise DataFeedError(f"No data returned for {ticker}")
            
            # Process the data
            df = self._process_datastream_response(df, frequency)
            
            return self.clean_ts_dataframe(df)
            
        except Exception as e:
            logger.error(f"Datastream data retrieval failed for {ticker}: {e}")
            raise DataFeedError(f"Datastream data retrieval failed: {e}")
    
    def _map_frequency(self, frequency: str) -> str:
        """Map standard frequency codes to Datastream format."""
        freq_map = {
            'D': 'D',
            'W': 'W', 
            'M': 'M',
            'Q': 'Q',
            'A': 'Y'  # Datastream uses Y for annual
        }
        
        freq = self.validate_frequency(frequency)
        return freq_map.get(freq, freq)
    
    def _format_ds_date(self, date_str: str) -> str:
        """Format date for Datastream API."""
        if not date_str:
            return date_str
        
        # Convert YYYY-MM-DD to YYYYMMDD
        return date_str.replace('-', '')
    
    def _process_datastream_response(self, df: pd.DataFrame, frequency: str) -> pd.DataFrame:
        """Process DatastreamPy response DataFrame."""
        if df.empty:
            return df
        
        logger.debug(f"Raw DatastreamPy response shape: {df.shape}")
        logger.debug(f"Raw DatastreamPy columns: {df.columns}")
        logger.debug(f"Raw DatastreamPy index: {df.index}")
        
        # Handle MultiIndex columns if present
        if isinstance(df.columns, pd.MultiIndex):
            logger.debug(f"Found MultiIndex columns with names: {df.columns.names}")
            # Flatten MultiIndex columns by joining non-empty levels with underscores
            df.columns = ['_'.join(filter(None, [str(level).strip() for level in col])).strip() 
                         for col in df.columns.values]
            logger.debug(f"Flattened columns: {df.columns.tolist()}")
        
        # DatastreamPy returns data with dates as index
        # Reset index to get dates as a column
        df_processed = df.reset_index()
        
        # Handle different possible column names from DatastreamPy
        date_column = None
        value_column = None
        
        # Find the date column
        for col in df_processed.columns:
            col_lower = str(col).lower()
            if 'date' in col_lower or col_lower in ['dates', 'index']:
                date_column = col
                break
        
        # If no date column found, use the index
        if date_column is None and hasattr(df, 'index') and not df.index.empty:
            df_processed['date'] = df.index
            date_column = 'date'
        
        # Find the value column (first non-date column)
        for col in df_processed.columns:
            col_lower = str(col).lower()
            if col != date_column and col_lower not in ['index']:
                value_column = col
                break
        
        if date_column is None:
            raise DataFeedError("No date column found in DatastreamPy response")
        if value_column is None:
            raise DataFeedError("No value column found in DatastreamPy response")
        
        # Create clean DataFrame with date and value columns
        result_df = df_processed[[date_column, value_column]].copy()
        result_df.columns = ['date', 'value']
        
        # Convert date column to datetime
        result_df['date'] = pd.to_datetime(result_df['date'])
        
        # For monthly data, adjust dates to month end
        if frequency.upper() == 'M':
            result_df['date'] = result_df['date'] + MonthEnd(0)
        
        return result_df
    
    def get_snapshot(self, tickers, fields: List[str], raw_data: bool = False) -> pd.DataFrame:
        """
        Retrieve Datastream snapshot data for tickers.
        
        Args:
            tickers: Datastream tickers as list or string
                - List: ['@:USSP500', '@:CHMSCIP'] 
                - String (single): '@:USSP500'
                - String (multiple): '@:USSP500, @:CHMSCIP'
            fields: List of snapshot fields (e.g., 'DSCD', 'NAME', 'RI')
            raw_data: If True, return raw data from ds_client without processing
                     If False, return processed data with tickers as index
            
        Returns:
            DataFrame with snapshot data for each ticker
        """
        # Initialize tickers_list to avoid scope issues
        tickers_list = []
        
        try:
            # Normalize tickers input to list
            if isinstance(tickers, str):
                # String input - split by comma if multiple, otherwise single
                if ',' in tickers:
                    tickers_list = [t.strip() for t in tickers.split(',')]
                else:
                    tickers_list = [tickers.strip()]
            elif isinstance(tickers, list):
                # List input - use as is
                tickers_list = tickers
            else:
                raise ValueError(f"tickers must be a string or list, got {type(tickers)}")
            
            logger.info(f"Datastream snapshot request for tickers: {tickers_list}, fields: {fields}")
            
            # Use the documentation approach: comma-separated string for multiple tickers
            if len(tickers_list) == 1:
                # Single ticker - use directly
                tickers_param = tickers_list[0]
            else:
                # Multiple tickers - convert to comma-separated string (documentation approach)
                tickers_param = ', '.join(tickers_list)
                logger.info(f"Using comma-separated string format: {tickers_param}")
            
            # Use kind=0 for snapshot data (works for both single and multiple tickers)
            df = self.ds_client.get_data(
                tickers=tickers_param, 
                fields=fields, 
                kind=0
            )
            
            logger.info(f"DatastreamPy snapshot returned DataFrame with shape: {df.shape}")
            
            if df.empty:
                logger.warning(f"No snapshot data returned for tickers: {tickers_list}")
                return pd.DataFrame()
            
            # Return raw data or processed data based on raw_data parameter
            if raw_data:
                logger.info("Returning raw snapshot data from ds_client")
                return df
            else:
                # Process the snapshot response
                df_processed = self._process_snapshot_response(df, tickers_list, fields)
                return df_processed
            
        except Exception as e:
            logger.error(f"Datastream snapshot retrieval failed for {tickers}: {e}")
            # Fallback to individual requests if the documentation approach fails
            logger.info("Falling back to individual requests...")
            return self._get_snapshot_individual_requests(tickers_list, fields)
    
    def _get_snapshot_individual_requests(self, tickers: List[str], fields: List[str]) -> pd.DataFrame:
        """Fallback method using individual requests for each ticker-field combination."""
        result_data = {}
        
        for ticker in tickers:
            result_data[ticker] = {}
            
            for field in fields:
                try:
                    # Make individual request for each ticker-field combination
                    # Use kind=0 for metadata requests
                    df = self.ds_client.get_data(
                        tickers=ticker,
                        fields=[field],
                        kind=0
                    )
                    
                    if not df.empty:
                        # Extract the metadata value from the 'Value' column
                        if 'Value' in df.columns:
                            value = df['Value'].iloc[0]
                            result_data[ticker][field] = value
                            logger.debug(f"Retrieved {ticker}~{field}: {value}")
                        else:
                            # Fallback to first non-null value if 'Value' column not found
                            value = None
                            for col in df.columns:
                                if not df[col].empty:
                                    non_null_values = df[col].dropna()
                                    if not non_null_values.empty:
                                        value = non_null_values.iloc[0]
                                        break
                            result_data[ticker][field] = value
                            logger.debug(f"Retrieved {ticker}~{field}: {value}")
                    else:
                        result_data[ticker][field] = None
                        logger.warning(f"No data for {ticker}~{field}")
                        
                except Exception as e:
                    logger.warning(f"Failed to get {ticker}~{field}: {e}")
                    result_data[ticker][field] = None
        
        # Convert to DataFrame
        df_result = pd.DataFrame.from_dict(result_data, orient='index')
        
        logger.info(f"Individual requests returned DataFrame with shape: {df_result.shape}")
        
        return df_result
    
    def _process_snapshot_response(self, df: pd.DataFrame, tickers: List[str], fields: List[str]) -> pd.DataFrame:
        """Process DatastreamPy snapshot response DataFrame."""
        if df.empty:
            return df
        
        logger.debug(f"Raw snapshot response shape: {df.shape}")
        logger.debug(f"Raw snapshot columns: {df.columns}")
        
        # Handle MultiIndex columns if present
        if isinstance(df.columns, pd.MultiIndex):
            logger.debug(f"Found MultiIndex columns with names: {df.columns.names}")
            # Flatten MultiIndex columns by joining non-empty levels with underscores
            df.columns = ['_'.join(filter(None, [str(level).strip() for level in col])).strip() 
                         for col in df.columns.values]
            logger.debug(f"Flattened columns: {df.columns.tolist()}")
        
        # For snapshot with kind=0, the response format is:
        # Columns: ['Instrument', 'Datatype', 'Value', 'Currency']
        # We need to pivot this to get tickers as index and fields as columns
        
        if 'Instrument' in df.columns and 'Datatype' in df.columns and 'Value' in df.columns:
            # This is the kind=0 response format
            logger.debug("Processing kind=0 response format")
            
            # Create a result DataFrame with tickers as index and fields as columns
            result_df = pd.DataFrame(index=tickers, columns=fields)
            
        # Extract snapshot values from the response
        for ticker in tickers:
            for field in fields:
                # Find rows for this ticker and field
                # Use strip() to handle potential spacing differences
                mask = (df['Instrument'].str.strip() == ticker.strip()) & (df['Datatype'].str.strip() == field.strip())
                matching_rows = df[mask]
                
                if not matching_rows.empty:
                    # Get the value from the first matching row
                    value = matching_rows['Value'].iloc[0]
                    result_df.loc[ticker, field] = value
                    logger.debug(f"Retrieved {ticker}~{field}: {value}")
                else:
                    result_df.loc[ticker, field] = None
                    logger.debug(f"No data for {ticker}~{field}")
        
        logger.debug(f"Processed snapshot shape: {result_df.shape}")
        logger.debug(f"Processed snapshot columns: {result_df.columns.tolist()}")
        
        return result_df
    
    def get_reference_data(self, ticker: str, fields: List[str], **kwargs) -> Dict[str, Any]:
        """
        Retrieve Datastream reference data.
        
        Note: Datastream reference data capabilities are limited.
        This method provides basic metadata where available.
        
        Args:
            ticker: Datastream ticker
            fields: List of reference fields (limited support)
            **kwargs: Additional parameters
            
        Returns:
            Dictionary mapping field names to values
        """
        try:
            # Use the new get_snapshot method for better metadata support
            snapshot_df = self.get_snapshot(ticker, fields)
            
            if snapshot_df.empty:
                # Fallback to basic series information
                result = {}
                df = self.get_data(ticker, start_date="20200101", end_date="20200102")
                
                if not df.empty:
                    result['ticker'] = ticker
                    result['last_date'] = df.index.max().strftime('%Y-%m-%d') if not df.empty else None
                    result['first_date'] = df.index.min().strftime('%Y-%m-%d') if not df.empty else None
                    result['count'] = len(df)
                
                return {field: result.get(field) for field in fields if field in result}
            else:
                # Return snapshot data as dictionary
                row = snapshot_df.iloc[0]
                return {field: row.get(field) for field in fields if field in row.index}
            
        except Exception as e:
            logger.error(f"Datastream reference data retrieval failed for {ticker}: {e}")
            raise DataFeedError(f"Datastream reference data retrieval failed: {e}")
    
    def check_frequency(self, tickers: List[str], start_date: str = "20001101") -> Dict[str, str]:
        """
        Check the frequency of multiple Datastream series.
        
        Args:
            tickers: List of Datastream tickers
            start_date: Start date for frequency check
            
        Returns:
            Dictionary mapping tickers to inferred frequencies
        """
        results = {}
        
        for ticker in tickers:
            try:
                df = self.get_data(ticker, start_date=start_date)
                if not df.empty:
                    freq = pd.infer_freq(df.index)
                    results[ticker] = freq
                else:
                    results[ticker] = None
                    
            except Exception as e:
                logger.warning(f"Frequency check failed for {ticker}: {e}")
                results[ticker] = None
        
        return results
    
    def get_monthly_data(self, ticker: str, start_date: str = "20001101") -> pd.DataFrame:
        """
        Convenience method to get monthly data with proper date alignment.
        
        Args:
            ticker: Datastream ticker
            start_date: Start date
            
        Returns:
            DataFrame with month-end dates
        """
        df = self.get_data(ticker, frequency='M', start_date=start_date)
        
        if not df.empty:
            # Ensure dates are month-end
            df.index = df.index + MonthEnd(0)
            df.index.name = 'date'
        
        return df
    
    def bulk_data_request(self, tickers: List[str], **kwargs) -> Dict[str, pd.DataFrame]:
        """
        Retrieve multiple Datastream series.
        
        Args:
            tickers: List of Datastream tickers
            **kwargs: Common parameters for all requests
            
        Returns:
            Dictionary mapping tickers to DataFrames
        """
        results = {}
        
        for ticker in tickers:
            try:
                df = self.get_data(ticker, **kwargs)
                results[ticker] = df
            except DataFeedError as e:
                logger.warning(f"Bulk request failed for {ticker}: {e}")
                results[ticker] = pd.DataFrame()
        
        return results
    
    def bulk_get_data(self, tickers: List[str], field: str, frequency: str = 'M',
                     start_date: str = None, end_date: str = None, **kwargs) -> Dict[str, Any]:
        """
        Retrieve Datastream data for multiple tickers in a single request.
        
        Args:
            tickers: List of Datastream tickers
            field: Datastream field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            start_date: Start date (YYYY-MM-DD format)
            end_date: End date (YYYY-MM-DD format)
            **kwargs: Additional parameters
            
        Returns:
            Dictionary containing 'data' (List[Dict]) and 'metadata' (Dict)
        """
        try:
            # Convert tickers list to comma-separated string for Datastream API
            tickers_string = ','.join(tickers)
            
            logger.info(f"Datastream bulk data request for {len(tickers)} tickers, field: {field}")
            logger.info(f"Tickers: {tickers_string}")
            
            # Prepare parameters for Datastream
            ds_params = {
                'tickers': tickers_string,  # Use comma-separated string
                'freq': self._map_frequency(frequency),
            }
            
            # Add fields if specified
            if field:
                ds_params['fields'] = [field] if isinstance(field, str) else field
            
            # Add date range
            if start_date:
                ds_params['start'] = self._format_ds_date(start_date)
            if end_date:
                ds_params['end'] = self._format_ds_date(end_date)
            
            # Add additional parameters
            # ds_params.update(kwargs)
            
            logger.info(f"Datastream bulk request: {ds_params}")
            
            # Make request using DatastreamPy format
            # DatastreamPy uses kind=1 for timeseries data
            ds_params['kind'] = 1
            df = self.ds_client.get_data(**ds_params)
            
            # Prepare metadata
            metadata = {
                'field': field,
                'frequency': frequency,
                'currency': '-',  # Datastream doesn't use currency override
                'source': 'DS',
                'start_date': start_date,
                'end_date': end_date,
                'tickers': tickers,
                'ticker_count': len(tickers),
                'record_count': len(df),
                'kwargs': kwargs
            }
            
            logger.info(f"Successfully retrieved {len(df)} records for {len(tickers)} tickers")
            
            return {
                'data': df,
                'metadata': metadata
            }
            
        except Exception as e:
            logger.error(f"Datastream bulk data retrieval failed: {e}")
            raise DataFeedError(f"Datastream bulk data retrieval failed: {e}")