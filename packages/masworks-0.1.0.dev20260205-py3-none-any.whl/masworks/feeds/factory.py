"""
Feed Factory Module

This module provides functions to create and configure feed objects for different data sources:
1. Bridge (Bloomberg) - with optional proxy support
2. Datastream (DS)
3. FRED (Federal Reserve Economic Data)

Usage:
    from masworks.feeds.factory import create_bridge_feed, create_datastream_feed, create_fred_feed
    
    # Create Bridge feed with proxy
    bridge_feed = create_bridge_feed(use_proxy=True, proxy_fallback=False, no_failover=False)
    df = bridge_feed.get_data(ticker="SPX Index", field="PX_LAST", frequency="D")
    
    # Create Datastream feed
    ds_feed = create_datastream_feed()
    df = ds_feed.get_data(ticker="SPX", field="P", frequency="D")
    
    # Create FRED feed
    fred_feed = create_fred_feed()
    df = fred_feed.get_data(ticker="GDP", field="-", frequency="-")
"""

from typing import Optional
import pandas as pd

from ..config import get_default_config, Config
from .bridge import BridgeFeed
from .fred import FredFeed
from .datastream import DatastreamFeed
from ..MasDatabase.base import DatabaseManager
from ..logging_config import setup_balanced_logging

# Configure logging (only if not already configured)
try:
    setup_balanced_logging()
except:
    pass

# Configure pandas display options
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 50)

# Global config instance (lazy initialization)
_config: Optional[Config] = None


def get_config() -> Config:
    """
    Get or create the global configuration instance.
    
    Returns:
        Config object
    """
    global _config
    if _config is None:
        _config = get_default_config()
    return _config


def create_bridge_feed(use_proxy: bool = False, no_failover: bool = False,
                      proxy_fallback: bool = False, config: Optional[Config] = None) -> BridgeFeed:
    """
    Create and configure a Bridge (Bloomberg) feed object.
    
    Args:
        use_proxy: If True, use HAProxy (bridge_proxy)
        no_failover: If True, disable failover (fail fast if proxy fails)
        proxy_fallback: If True, use proxy as fallback (direct servers first)
        config: Optional Config object (uses global config if not provided)
        
    Returns:
        BridgeFeed object configured and ready to use
    """
    if config is None:
        config = get_config()
    
    # Configure proxy if requested
    if use_proxy:
        config.bridge.use_proxy = True
        config.bridge.proxy_service_name = 'bridge_proxy'
        config.bridge.proxy_priority = 1 if proxy_fallback else 0
        config.bridge.proxy_failover = not no_failover
        config.bridge.use_database_servers = True
        # Allow remote servers for proxy
        config.bridge.allowed_server_types = ['all']
        config.bridge.allowed_hosts = None
    else:
        config.bridge.use_proxy = False
    
    # Initialize database manager if using proxy
    db_manager = None
    if use_proxy:
        db_manager = DatabaseManager(config.database)
    
    # Create and return Bridge feed
    bridge_feed = BridgeFeed(config.bridge, db_manager)
    return bridge_feed


def create_datastream_feed(config: Optional[Config] = None) -> DatastreamFeed:
    """
    Create and configure a Datastream (DS) feed object.
    
    Args:
        config: Optional Config object (uses global config if not provided)
        
    Returns:
        DatastreamFeed object configured and ready to use
    """
    if config is None:
        config = get_config()
    
    # Create and return Datastream feed
    ds_feed = DatastreamFeed(config.datastream)
    return ds_feed


def create_fred_feed(config: Optional[Config] = None) -> FredFeed:
    """
    Create and configure a FRED (Federal Reserve Economic Data) feed object.
    
    Args:
        config: Optional Config object (uses global config if not provided)
        
    Returns:
        FredFeed object configured and ready to use
    """
    if config is None:
        config = get_config()
    
    # Create and return FRED feed
    fred_feed = FredFeed(config.fred)
    return fred_feed
