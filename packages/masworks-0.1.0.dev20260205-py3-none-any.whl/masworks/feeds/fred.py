"""
FRED (Federal Reserve Economic Data) feed implementation.
"""
import logging
from typing import Dict, Any, Optional, List
import pandas as pd
import requests
import json
import warnings
from urllib.parse import urlencode
import io

from .base import DataFeedBase, DataFeedError
from ..config import FredConfig
from ..utils.data_utils import clean_missing_values

logger = logging.getLogger(__name__)


class FredFeed(DataFeedBase):
    """FRED data feed using official API and CSV endpoints."""
    
    def __init__(self, config: FredConfig):
        super().__init__()
        self.config = config
        self.session = requests.Session()
    
    def _build_url(self, path: str, **params) -> str:
        """Build FRED API URL with parameters."""
        base_params = {
            'api_key': self.config.api_key,
            'file_type': 'json'
        }
        base_params.update(params)
        
        return f"{self.config.base_url}{path}?{urlencode(base_params)}"
    
    def _make_api_request(self, path: str, **params) -> pd.DataFrame:
        """Make request to FRED API and return DataFrame."""
        url = self._build_url(path, **params)
        
        try:
            logger.debug(f"FRED API request: {url}")
            response = self.session.get(url)
            response.raise_for_status()
            
            data = response.json()
            return self._parse_api_response(data)
            
        except requests.RequestException as e:
            logger.error(f"FRED API request failed: {e}")
            raise DataFeedError(f"FRED API request failed: {e}")
        except (json.JSONDecodeError, KeyError) as e:
            logger.error(f"FRED API response parsing failed: {e}")
            raise DataFeedError(f"FRED API response parsing failed: {e}")
    
    
    def _parse_api_response(self, data: Dict[str, Any]) -> pd.DataFrame:
        """Parse FRED API JSON response into DataFrame."""
        # Identify the data key
        response_keys = ['observations', 'seriess', 'categories', 'tags', 
                        'releases', 'release_dates', 'sources', 'vintage_dates']
        
        data_key = None
        for key in response_keys:
            if key in data:
                data_key = key
                break
        
        if not data_key:
            raise DataFeedError("No recognized data key in FRED response")
        
        # Create DataFrame
        df = pd.DataFrame(data[data_key])
        
        # Convert date columns
        date_cols = ['realtime_start', 'realtime_end', 'date', 'vintage_dates', 
                    'last_updated', 'observation_start', 'observation_end', 'created']
        
        for col in df.columns:
            if col in date_cols:
                # Suppress mixed timezone warning while preserving original behavior
                # This avoids timezone conversion complexity in the rest of the codebase
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore', category=FutureWarning, 
                                          message='.*mixed time zones.*')
                    df[col] = pd.to_datetime(df[col], errors='coerce')
            elif col == 'value':
                # Handle FRED-specific missing values (including '.' for missing data)
                df = clean_missing_values(df, col, extra_missing_values=['.'])
                df[col] = pd.to_numeric(df[col], errors='coerce')
            else:
                # Convert to numeric, handle common missing value representations
                try:
                    df[col] = pd.to_numeric(df[col])
                except (ValueError, TypeError):
                    # Replace common missing value representations with NaN, then convert
                    df = clean_missing_values(df, col)
                    try:
                        df[col] = pd.to_numeric(df[col])
                    except (ValueError, TypeError):
                        # If still can't convert, keep original but log warning
                        logger.debug(f"Column {col} contains non-numeric values that couldn't be converted")
        
        return df
    
    def _get_csv_data(self, series_id: str) -> pd.DataFrame:
        """Get data using FRED CSV endpoint (faster for time series data)."""
        url = f"{self.config.csv_url}{series_id}"
        
        try:
            logger.debug(f"FRED CSV request: {url}")
            # Define comprehensive missing values for FRED CSV data
            na_values = ['.', 'NA', 'NaN', 'None', 'null', 'NULL', '', ' ', 
                        'n/a', 'N/A', '#N/A', '#NULL!', '#VALUE!', 'nan']
            df = pd.read_csv(url, na_values=na_values)
            df.columns = ['date', 'value']
            df['date'] = pd.to_datetime(df['date'])
            return df
            
        except Exception as e:
            logger.error(f"FRED CSV request failed for {series_id}: {e}")
            raise DataFeedError(f"FRED CSV request failed: {e}")
    
    def _build_api_params(self, series_id: str, start_date: Optional[str] = None, 
                         end_date: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        """Build API parameters for FRED requests."""
        api_params = {'series_id': series_id}
        
        if start_date:
            api_params['observation_start'] = start_date
        if end_date:
            api_params['observation_end'] = end_date
        
        api_params.update(kwargs)
        return api_params
    
    def get_data(self, ticker: str, **kwargs) -> pd.DataFrame:
        """
        Retrieve FRED time series data.
        
        Args:
            ticker: FRED series ID (e.g., 'GDP', 'UNRATE')
            **kwargs: FRED-specific parameters including:
                - field: Data field (not used for FRED, should be '-')
                - frequency: Data frequency (not used for FRED, should be '-')
                - start_date: Start date (YYYY-MM-DD format)
                - end_date: End date (YYYY-MM-DD format)
                - use_api: If True, force use of API endpoint instead of CSV (default: False)
                - Additional FRED API parameters
                
        Returns:
            DataFrame with date index and value column
        """
        # Extract parameters we actually use
        start_date = kwargs.pop('start_date', None)
        end_date = kwargs.pop('end_date', None)
        use_api = kwargs.pop('use_api', False)
        
        # For FRED, ticker is the series ID
        series_id = ticker.upper()
        
        # Try CSV first unless API is forced
        if not use_api:
            try:
                df = self._get_csv_data(series_id)
            except DataFeedError:
                use_api = True  # Fall back to API
        
        # Use API if forced or CSV failed
        if use_api:
            api_params = self._build_api_params(series_id, start_date, end_date, **kwargs)
            df = self._make_api_request('/series/observations', **api_params)
        
        # Filter by date range if specified and not already filtered
        if start_date and 'observation_start' not in kwargs:
            df = df[df['date'] >= pd.to_datetime(start_date)]
        if end_date and 'observation_end' not in kwargs:
            df = df[df['date'] <= pd.to_datetime(end_date)]
        
        return self.clean_ts_dataframe(df)
    
    def get_series_info(self, series_id: str) -> Dict[str, Any]:
        """
        Get metadata for a FRED series.
        
        Args:
            series_id: FRED series ID
            
        Returns:
            Dictionary with series metadata
        """
        df = self._make_api_request('/series', series_id=series_id.upper())
        
        if df.empty:
            raise DataFeedError(f"No metadata found for series {series_id}")
        
        return df.iloc[0].to_dict()
    
    def get_reference_data(self, ticker: str, fields: List[str], **kwargs) -> Dict[str, Any]:
        """
        Retrieve FRED series metadata as reference data.
        
        Args:
            ticker: FRED series ID
            fields: List of metadata fields to retrieve
            **kwargs: Additional parameters
            
        Returns:
            Dictionary mapping field names to values
        """
        try:
            metadata = self.get_series_info(ticker)
            return {field: metadata.get(field) for field in fields if field in metadata}
        except Exception as e:
            logger.error(f"FRED reference data retrieval failed for {ticker}: {e}")
            raise DataFeedError(f"FRED reference data retrieval failed: {e}")
    
    def search_series(self, search_text: str, limit: int = 100) -> pd.DataFrame:
        """
        Search for FRED series by text.
        
        Args:
            search_text: Search query
            limit: Maximum number of results
            
        Returns:
            DataFrame with search results
        """
        return self._make_api_request('/series/search', 
                                    search_text=search_text, 
                                    limit=limit)
    
    def get_categories(self, category_id: Optional[int] = None) -> pd.DataFrame:
        """
        Get FRED categories.
        
        Args:
            category_id: Specific category ID, or None for root categories
            
        Returns:
            DataFrame with category information
        """
        params = {}
        if category_id is not None:
            params['category_id'] = category_id
            
        return self._make_api_request('/category', **params)
    
    def bulk_data_request(self, series_ids: List[str], **kwargs) -> Dict[str, pd.DataFrame]:
        """
        Retrieve multiple FRED series efficiently.
        
        Args:
            series_ids: List of FRED series IDs
            **kwargs: Common parameters for all requests
            
        Returns:
            Dictionary mapping series IDs to DataFrames
        """
        results = {}
        
        for series_id in series_ids:
            try:
                df = self.get_data(series_id, **kwargs)
                results[series_id] = df
            except DataFeedError as e:
                logger.warning(f"Bulk request failed for {series_id}: {e}")
                results[series_id] = pd.DataFrame()
        
        return results
