#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Centralized logging configuration for DCF examples.

This module provides easy-to-use functions for configuring logging
across all DCF examples and tests.
"""

import logging
from typing import Optional, Dict, List


def setup_dcf_logging(
    level: int = logging.INFO,
    format_string: str = '%(levelname)-8s %(message)s',
    compress_bridge: bool = True,
    compress_datastream: bool = False,
    compress_database: bool = False,
    compress_urllib3: bool = False,
    custom_compressions: Optional[Dict[str, int]] = None
) -> None:
    """
    Set up logging configuration for DCF examples.
    
    Args:
        level: Logging level (default: INFO)
        format_string: Log format string (default: aligned format)
        compress_bridge: Compress masworks.feeds.bridge logging (default: True)
        compress_datastream: Compress masworks.feeds.datastream logging (default: False)
        compress_database: Compress masworks.MasDatabase logging (default: False)
        compress_urllib3: Compress urllib3 HTTP logging (default: False)
        custom_compressions: Dict of logger_name -> level for custom compressions
    """
    # Configure basic logging
    logging.basicConfig(
        level=level,
        format=format_string,
        force=True  # Override any existing configuration
    )
    
    # Apply compressions
    compressions = []
    
    if compress_bridge:
        compressions.extend([
            ('masworks.feeds.bridge', logging.WARNING),
            ('masworks.feeds.bridge_server_filter', logging.WARNING),
            ('masworks.feeds.bridge_service_manager', logging.WARNING)
        ])
    
    if compress_datastream:
        compressions.append(('masworks.feeds.datastream', logging.WARNING))
    
    if compress_database:
        compressions.extend([
            ('masworks.MasDatabase', logging.WARNING),
            ('masworks.utils.database_connection', logging.WARNING)
        ])
    
    if compress_urllib3:
        compressions.append(('urllib3', logging.WARNING))
    
    # Add custom compressions
    if custom_compressions:
        compressions.extend(custom_compressions.items())
    
    # Apply all compressions
    for logger_name, log_level in compressions:
        logging.getLogger(logger_name).setLevel(log_level)
    
    # Log the configuration
    logger = logging.getLogger(__name__)
    logger.info(f"Logging configured: level={logging.getLevelName(level)}, format='{format_string}'")
    if compressions:
        compressed_loggers = [name for name, _ in compressions]
        logger.info(f"Compressed loggers: {', '.join(compressed_loggers)}")


def setup_quiet_logging() -> None:
    """Set up quiet logging with minimal output."""
    setup_dcf_logging(
        level=logging.WARNING,
        compress_bridge=True,
        compress_datastream=True,
        compress_database=True,
        compress_urllib3=True
    )


def setup_verbose_logging() -> None:
    """Set up verbose logging with all details."""
    setup_dcf_logging(
        level=logging.DEBUG,
        compress_bridge=False,
        compress_datastream=False,
        compress_database=False,
        compress_urllib3=False
    )


def setup_balanced_logging() -> None:
    """Set up balanced logging - quiet bridge and database, normal everything else."""
    setup_dcf_logging(
        level=logging.INFO,
        compress_bridge=True,
        compress_datastream=False,
        compress_database=True,
        compress_urllib3=False
    )


# Predefined configurations
LOGGING_CONFIGS = {
    'quiet': setup_quiet_logging,
    'verbose': setup_verbose_logging,
    'balanced': setup_balanced_logging,
    'default': lambda: setup_dcf_logging()
}


def setup_logging_by_name(config_name: str) -> None:
    """
    Set up logging using a predefined configuration name.
    
    Args:
        config_name: One of 'quiet', 'verbose', 'balanced', 'default'
    """
    if config_name not in LOGGING_CONFIGS:
        raise ValueError(f"Unknown config name: {config_name}. Available: {list(LOGGING_CONFIGS.keys())}")
    
    LOGGING_CONFIGS[config_name]()


if __name__ == "__main__":
    # Demo the different configurations
    print("Available logging configurations:")
    for name, func in LOGGING_CONFIGS.items():
        print(f"  {name}: {func.__doc__ or 'Custom configuration'}")
