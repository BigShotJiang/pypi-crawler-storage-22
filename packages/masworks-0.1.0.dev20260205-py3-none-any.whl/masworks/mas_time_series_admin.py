"""
Administrative interface for time series data management.

Inherits all read capabilities from TimeSeriesReader and adds
data modification, selector management, and bulk operations.
"""
import logging
from typing import Optional, Dict, Any, List, Union, Tuple

import pandas as pd

from .MasDatabase import SeriesOperationMixin, BloombergOperationsMixin, handle_series_operation_errors
from .constants import (
    DEFAULT_FREQUENCY, DEFAULT_SOURCE, DEFAULT_CURRENCY,
    OPERATION_TYPES, STATUS_CODES, SOURCE_CODE_MAP
)
from .mas_time_series_reader import MasTimeSeriesReader
from .types import DateInput
from .utils.date_utils import normalize_date_input

logger = logging.getLogger(__name__)


class MasTimeSeriesAdmin(MasTimeSeriesReader, SeriesOperationMixin, BloombergOperationsMixin):
    """
    Administrative interface for time series data management.
    
    Inherits all read capabilities from MasTimeSeriesReader and adds
    data modification, selector management, and bulk operations.
    This class provides full administrative control over time series data.
    """

    # Field-specific configurations for special handling
    FIELD_SPECIFIC_CONFIG = {
        'TOT_RETURN_INDEX_GROSS_DVDS': {
            'start_date': '1930-01-01',
            'reason': 'Total return indices require maximum historical coverage for accurate performance calculation',
            'applies_to': ['upsert', 'replace', 'bulk']  # Which operations this applies to
        }
    }

    def __init__(self, config, auto_create_tables: bool = True, lazy_feeds: bool = False):
        """
        Initialize MasTimeSeriesAdmin with feed support.
        
        Args:
            config: Configuration object with database and feed settings
            auto_create_tables: If True, automatically create database tables if they don't exist
            lazy_feeds: If True, initialize feeds only when first needed (default: False)
        """
        super().__init__(config, auto_create_tables)

        self._feeds_initialized = False
        self._lazy_feeds = lazy_feeds

        if not lazy_feeds:
            # Initialize data feeds immediately
            self._initialize_feeds()

    def _get_field_specific_start_date(self, field: str, provided_start_date: str) -> str:
        """Get the appropriate start date for a specific field."""
        if field in self.FIELD_SPECIFIC_CONFIG:
            config = self.FIELD_SPECIFIC_CONFIG[field]
            logger.info(f"Using field-specific start date for {field}: {config['start_date']} ({config['reason']})")
            return config['start_date']
        return provided_start_date

    def _should_use_field_specific_start_date(self, field: str) -> bool:
        """Check if a field should use field-specific start date logic."""
        return field in self.FIELD_SPECIFIC_CONFIG

    def _initialize_feeds(self):
        """Initialize data feeds for admin operations."""
        if self._feeds_initialized:
            return

        from masworks.feeds import BridgeFeed, FredFeed, DatastreamFeed
        from masworks.constants import SOURCE_ALIASES

        logger.info("Initializing data feeds for admin operations...")

        self.feeds = {
            'bloomberg': BridgeFeed(self.config.bridge, self.db_manager),
            'fred': FredFeed(self.config.fred),
            'datastream': DatastreamFeed(self.config.datastream),
        }

        # Add aliases for convenience
        for alias, source in SOURCE_ALIASES.items():
            self.feeds[alias] = self.feeds[source]

        self._feeds_initialized = True
        logger.info(f"Initialized {len(self.feeds)} data feeds: {list(self.feeds.keys())}")

    def _ensure_feeds_initialized(self):
        """Ensure feeds are initialized (for lazy initialization)."""
        if not self._feeds_initialized:
            if self._lazy_feeds:
                logger.info("Lazy initializing feeds on first use...")
                self._initialize_feeds()
            else:
                raise RuntimeError("Feeds not initialized and lazy initialization is disabled")

    def get_available_feeds(self) -> Dict[str, Any]:
        """
        Get information about available data feeds.
        
        Returns:
            Dictionary with feed names as keys and feed instances as values
        """
        self._ensure_feeds_initialized()
        return self.feeds.copy()

    def get_feed_info(self, source: str) -> Dict[str, Any]:
        """
        Get information about a specific data feed.
        
        Args:
            source: Data source name ('bloomberg', 'fred', 'datastream', etc.)
            
        Returns:
            Dictionary with feed information
            
        Raises:
            ValueError: If source is not available
        """
        self._ensure_feeds_initialized()

        from masworks.constants import SOURCE_ALIASES

        source = source.lower()
        if source in SOURCE_ALIASES:
            source = SOURCE_ALIASES[source]

        if source not in self.feeds:
            raise ValueError(f"Unknown data source: {source}")

        feed = self.feeds[source]
        return {
            'name': source,
            'class': feed.__class__.__name__,
            'available': True
        }

    @handle_series_operation_errors
    def upsert_series(self, ticker: str, field: str, frequency: str = DEFAULT_FREQUENCY,
                      source: str = DEFAULT_SOURCE, currency: str = DEFAULT_CURRENCY,
                      start_date: DateInput = None, updated_by: Optional[str] = None, 
                      auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Upsert (insert or update) time series data from external source.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source ('bloomberg', 'fred', 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        # Apply field-specific date logic
        adjusted_start_date = self._get_field_specific_start_date(field, start_date)

        # Normalize adjusted date
        adjusted_start_date = normalize_date_input(adjusted_start_date, '%Y-%m-%d')

        return self._execute_series_operation_base(
            ticker, field, frequency, source, currency, adjusted_start_date,
            OPERATION_TYPES['UPSERT'], updated_by=updated_by, auto_create=auto_create, **kwargs
        )

    @handle_series_operation_errors
    def replace_series(self, ticker: str, field: str, frequency: str = DEFAULT_FREQUENCY,
                       source: str = DEFAULT_SOURCE, currency: str = DEFAULT_CURRENCY,
                       start_date: DateInput = None, updated_by: Optional[str] = None, 
                       auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Replace (delete and re-insert) time series data from external source.
        
        This function deletes all existing data for the series and re-inserts fresh data.
        Unlike upsert, this ensures complete data replacement.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source ('bloomberg', 'fred', 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        # Apply field-specific date logic
        adjusted_start_date = self._get_field_specific_start_date(field, start_date)

        # Normalize adjusted date
        adjusted_start_date = normalize_date_input(adjusted_start_date, '%Y-%m-%d')

        return self._execute_series_operation_base(
            ticker, field, frequency, source, currency, adjusted_start_date,
            OPERATION_TYPES['REPLACE'], updated_by=updated_by, auto_create=auto_create, **kwargs
        )

    @handle_series_operation_errors
    def upsert_series_with_date(self, ticker: str, field: str, frequency: str = DEFAULT_FREQUENCY,
                                source: str = 'datastream', currency: str = DEFAULT_CURRENCY,
                                start_date: DateInput = None, updated_by: Optional[str] = None, **kwargs) -> Dict[
        str, Any]:
        """
        Upsert time series data with date values (as strings) for Datastream feeds.
        
        This method is specifically designed for Datastream feeds where the time series
        values are dates represented as strings. The dates are converted to Unix timestamps
        for storage in the TS_Data.value column and marked with 'Date' in the note column.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source (must be 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        # Validate source is datastream
        if source.lower() != 'datastream':
            raise ValueError("upsert_series_with_date is only supported for 'datastream' source")

        # Normalize date input
        start_date = normalize_date_input(start_date, '%Y-%m-%d')

        return self._execute_series_operation_base_with_date(
            ticker, field, frequency, source, currency, start_date,
            OPERATION_TYPES['UPSERT'], **kwargs
        )

    def _execute_series_operation_base(self, ticker: str, field: str, frequency: str,
                                       source: str, currency: str, start_date: Optional[str],
                                       operation_type: str, **kwargs) -> Dict[str, Any]:
        """Base method for executing series operations (upsert or replace)."""
        # Normalize and validate source
        source = self._normalize_source(source)

        # Separate parameters that must not go to the feed from actual feed parameters.
        # Excluded: TS_Meta-related fields (cname, note, etc.) and operation-only flags
        # (updated_by, auto_create) — feeds (e.g. Datastream DataClient) don't accept these.
        metadata_params = {}
        feed_params = {}
        params_not_for_feed = {'cname', 'cname2', 'cat', 'note', 'Lag', 'freq', 'Lag2', 'tempflag', 'sid', 'json',
                               'updated_by', 'auto_create'}

        for key, value in kwargs.items():
            if key in params_not_for_feed:
                metadata_params[key] = value
            else:
                feed_params[key] = value

        # IMPORTANT: Validate parameters by fetching data FIRST
        # This prevents creating invalid metadata entries for non-existent series
        df = self._validate_data_feed_parameters(ticker, field, frequency, source, currency, start_date, **feed_params)

        # Additional safety check for DataFrame
        if df is None:
            logger.warning(f"Data validation returned None for {ticker} {field} - parameters may be invalid")
            no_data_result = {
                "status": STATUS_CODES['NO_DATA'],
                "rows_updated": 0,
                "rows_inserted": 0,
                "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
            }
            if operation_type == OPERATION_TYPES['REPLACE']:
                no_data_result["rows_deleted"] = 0
            return no_data_result

        if df.empty:
            logger.warning(f"No data retrieved for {ticker} {field} - parameters may be invalid")
            no_data_result = {
                "status": STATUS_CODES['NO_DATA'],
                "rows_updated": 0,
                "rows_inserted": 0,
                "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
            }
            if operation_type == OPERATION_TYPES['REPLACE']:
                no_data_result["rows_deleted"] = 0
            return no_data_result

        logger.info(f"Successfully fetched {len(df)} data points for {ticker} {field}")

        # Only create metadata if data fetch was successful (exclude operation-only keys from **kwargs)
        meta_for_create = {k: v for k, v in metadata_params.items() if k not in ('auto_create', 'updated_by')}
        series_id, is_new_series = self._get_or_create_series_metadata(
            ticker, field, frequency, source, currency, auto_create=kwargs.get('auto_create', True), **meta_for_create
        )

        # Prepare data for operation
        df_operation = self._prepare_dataframe_for_operation(df, series_id)

        # Execute the operation
        if operation_type == OPERATION_TYPES['UPSERT']:
            upserted, _ = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_upserted": upserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Upserted {ticker} {field}: {upserted} rows processed")
        else:  # REPLACE
            deleted, inserted = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_deleted": deleted,
                "rows_inserted": inserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Replaced {ticker} {field}: {deleted} deleted, {inserted} inserted")

        # Create/update TimeSeriesStatus record for successful operations
        if result["status"] == STATUS_CODES['SUCCESS'] and not df_operation.empty:
            try:
                # Get date range from the data
                upd_start = df_operation['date'].min()
                upd_end = df_operation['date'].max()

                # Get user for status tracking (use provided or default to OS user)
                upd_by = kwargs.get('updated_by') or self._get_current_user()

                # Create/update status record
                status_success = self.upsert_series_status(
                    series_id=series_id,
                    upd_start=upd_start,
                    upd_end=upd_end,
                    upd_by=upd_by
                )

                if status_success:
                    result["status_record_created"] = True
                    logger.debug(f"Upserted TimeSeriesStatus for series {series_id}")
                else:
                    result["status_record_created"] = False
                    logger.warning(f"Failed to upsert TimeSeriesStatus for series {series_id}")

            except Exception as e:
                logger.error(f"Error upserting TimeSeriesStatus for series {series_id}: {e}")
                result["status_record_created"] = False

        return result

    def _execute_series_operation_base_with_date(self, ticker: str, field: str, frequency: str,
                                                 source: str, currency: str, start_date: Optional[str],
                                                 operation_type: str, **kwargs) -> Dict[str, Any]:
        """
        Base method for executing series operations with date values (for Datastream feeds).
        
        This method handles time series where values are date strings that need to be
        converted to Unix timestamps for storage in TS_Data.value column.
        """
        # Normalize and validate source
        source = self._normalize_source(source)

        # Separate parameters that must not go to the feed from actual feed parameters.
        # Excluded: TS_Meta-related fields and operation-only flags (updated_by, auto_create).
        metadata_params = {}
        feed_params = {}
        params_not_for_feed = {'cname', 'cname2', 'cat', 'note', 'Lag', 'freq', 'Lag2', 'tempflag', 'sid', 'json',
                               'updated_by', 'auto_create'}

        for key, value in kwargs.items():
            if key in params_not_for_feed:
                metadata_params[key] = value
            else:
                feed_params[key] = value

        # IMPORTANT: Validate parameters by fetching data FIRST
        # This prevents creating invalid metadata entries for non-existent series
        df = self._validate_data_feed_parameters(ticker, field, frequency, source, currency, start_date, **feed_params)

        # Additional safety check for DataFrame
        if df is None:
            logger.warning(f"Data validation returned None for {ticker} {field} - parameters may be invalid")
            no_data_result = {
                "status": STATUS_CODES['NO_DATA'],
                "rows_updated": 0,
                "rows_inserted": 0,
                "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
            }
            if operation_type == OPERATION_TYPES['REPLACE']:
                no_data_result["rows_deleted"] = 0
            return no_data_result

        if df.empty:
            logger.warning(f"No data retrieved for {ticker} {field} - parameters may be invalid")
            no_data_result = {
                "status": STATUS_CODES['NO_DATA'],
                "rows_updated": 0,
                "rows_inserted": 0,
                "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
            }
            if operation_type == OPERATION_TYPES['REPLACE']:
                no_data_result["rows_deleted"] = 0
            return no_data_result

        logger.info(f"Successfully fetched {len(df)} data points for {ticker} {field}")

        # Only create metadata if data fetch was successful
        # Add 'Date' to note for date-type series
        if 'note' not in metadata_params:
            metadata_params['note'] = 'Date'
        else:
            # Append 'Date' to existing note if not already present
            existing_note = metadata_params.get('note', '')
            if 'Date' not in existing_note:
                metadata_params['note'] = f"{existing_note},Date" if existing_note else 'Date'

        series_id, is_new_series = self._get_or_create_series_metadata(
            ticker, field, frequency, source, currency, **metadata_params
        )

        # Prepare data for operation with date conversion
        df_operation = self._prepare_dataframe_for_operation_with_date(df, series_id)

        # Execute the operation
        if operation_type == OPERATION_TYPES['UPSERT']:
            upserted, _ = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_upserted": upserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Upserted {ticker} {field} with date values: {upserted} rows processed")
        else:  # REPLACE
            deleted, inserted = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_deleted": deleted,
                "rows_inserted": inserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Replaced {ticker} {field} with date values: {deleted} deleted, {inserted} inserted")

        # Create/update TimeSeriesStatus record for successful operations
        if result["status"] == STATUS_CODES['SUCCESS'] and not df_operation.empty:
            try:
                # Get date range from the data
                upd_start = df_operation['date'].min()
                upd_end = df_operation['date'].max()

                # Get user for status tracking (use provided or default to OS user)
                upd_by = kwargs.get('updated_by') or self._get_current_user()

                # Create/update status record
                status_success = self.upsert_series_status(
                    series_id=series_id,
                    upd_start=upd_start,
                    upd_end=upd_end,
                    upd_by=upd_by
                )

                if status_success:
                    result["status_record_created"] = True
                    logger.debug(f"Upserted TimeSeriesStatus for series {series_id}")
                else:
                    result["status_record_created"] = False
                    logger.warning(f"Failed to upsert TimeSeriesStatus for series {series_id}")

            except Exception as e:
                logger.error(f"Error upserting TimeSeriesStatus for series {series_id}: {e}")
                result["status_record_created"] = False

        return result

    def upsert_multiple_series(self, series_specs: List[Dict[str, Any]], **common_kwargs) -> List[Dict[str, Any]]:
        """
        Upsert multiple time series sequentially.
        
        Args:
            series_specs: List of series specifications (ticker, field, etc.)
            **common_kwargs: Common parameters applied to all series
            
        Returns:
            List of operation results for each series
        """
        return self._execute_multiple_series_operation(series_specs, OPERATION_TYPES['UPSERT'], **common_kwargs)

    def replace_multiple_series(self, series_specs: List[Dict[str, Any]], **common_kwargs) -> List[Dict[str, Any]]:
        """
        Replace multiple time series sequentially.
        
        Args:
            series_specs: List of series specifications (ticker, field, etc.)
            **common_kwargs: Common parameters applied to all series
            
        Returns:
            List of operation results for each series
        """
        return self._execute_multiple_series_operation(series_specs, OPERATION_TYPES['REPLACE'], **common_kwargs)

    def _execute_multiple_series_operation(self, series_specs: List[Dict[str, Any]],
                                           operation_type: str, **common_kwargs) -> List[Dict[str, Any]]:
        """Execute multiple series operations (upsert or replace)."""
        results = []

        for spec in series_specs:
            # Merge common kwargs with individual spec
            full_spec = {**common_kwargs, **spec}

            try:
                if operation_type == OPERATION_TYPES['REPLACE']:
                    result = self.replace_series(**full_spec)
                else:
                    result = self.upsert_series(**full_spec)
                results.append(result)
            except Exception as e:
                logger.error(f"Multiple series {operation_type} failed for {spec}: {e}")
                results.append({"status": STATUS_CODES['ERROR'], "error": str(e), "spec": spec})

        return results

    def auto_upsert_bloomberg(self, tickers: List[str], fields: List[str],
                              frequency: str = DEFAULT_FREQUENCY, start_date: Optional[str] = None,
                              **kwargs) -> Dict[str, Any]:
        """
        Automatically upsert Bloomberg data for multiple ticker/field combinations.
        
        This method processes all combinations of tickers and fields, checking if each
        series already exists in the database. For new series, it creates metadata and
        fetches data. For existing series, it updates the data.
        
        Args:
            tickers: List of Bloomberg tickers (e.g., ['SPX Index', 'VIX Index'])
            fields: List of Bloomberg fields (e.g., ['PX_LAST', 'VOLATILITY_30D'])
            frequency: Data frequency ('D', 'W', 'M', 'Q', 'A')
            start_date: Start date for data retrieval (defaults to config default)
            **kwargs: Additional parameters passed to Bloomberg feed
            
        Returns:
            Dict with summary of operations performed
        """
        return self._process_bloomberg_combinations(
            tickers, fields, frequency, start_date, OPERATION_TYPES['UPSERT'], **kwargs
        )

    def replace_auto_bloomberg(self, tickers: List[str], fields: List[str],
                               frequency: str = DEFAULT_FREQUENCY, start_date: Optional[str] = None,
                               **kwargs) -> Dict[str, Any]:
        """
        Automatically replace Bloomberg data for multiple ticker/field combinations.
        
        This method processes all combinations of tickers and fields, replacing all existing data
        for each series with fresh data from Bloomberg.
        
        Args:
            tickers: List of Bloomberg tickers (e.g., ['SPX Index', 'VIX Index'])
            fields: List of Bloomberg fields (e.g., ['PX_LAST', 'VOLATILITY_30D'])
            frequency: Data frequency ('D', 'W', 'M', 'Q', 'A')
            start_date: Start date for data retrieval (defaults to config default)
            **kwargs: Additional parameters passed to Bloomberg feed
            
        Returns:
            Dict with summary of operations performed
        """
        return self._process_bloomberg_combinations(
            tickers, fields, frequency, start_date, OPERATION_TYPES['REPLACE'], **kwargs
        )

    def refresh_series(self, series_id: int, **kwargs) -> Dict[str, Any]:
        """
        Refresh data for an existing series.
        
        Args:
            series_id: Series ID to refresh
            **kwargs: Additional parameters for data retrieval
            
        Returns:
            Dictionary with refresh results
        """
        # Get series metadata
        metadata_list = self.session_manager.get_ts_metadata(id=series_id)
        if not metadata_list:
            return {"status": STATUS_CODES['ERROR'], "error": f"Series {series_id} not found"}

        metadata = metadata_list[0]

        # Map source code to feed name
        source_map = {v: k for k, v in SOURCE_CODE_MAP.items()}
        source = source_map.get(metadata.source)

        if not source:
            return {"status": STATUS_CODES['ERROR'], "error": f"Unknown source: {metadata.source}"}

        # Refresh the series
        return self.upsert_series(
            ticker=metadata.ticker,
            field=metadata.field,
            frequency=metadata.frequency,
            source=source,
            currency=metadata.currency,
            **kwargs
        )

    def create_selector(self, selector_name: str, series_specs: List[Dict[str, Any]]) -> bool:
        """
        Create a new selector group.
        
        Each spec must include 'group' or 'grp' key. If missing, session.add will raise an error.
        This allows multiple groups in one call when different specs have different groups.
        
        Args:
            selector_name: Name for the selector group
            series_specs: List of series specifications with order.
                         Each spec must include 'group' or 'grp' key.
            
        Returns:
            True if successful
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesSelector

                # Clear existing selector entries (delete all groups for this selector)
                session.query(TimeSeriesSelector).filter_by(sel=selector_name).delete()
                
                # Add new entries (group must be in spec, will raise error if missing)
                for i, spec in enumerate(series_specs):
                    spec_group = spec.get('group') or spec.get('grp')
                    selector_entry = TimeSeriesSelector(
                        sel=selector_name,
                        grp=spec_group,  # Will raise error if None
                        ord=spec.get('order', i + 1),
                        id=spec['series_id'],
                        colname=spec.get('colname'),
                        desname=spec.get('desname')
                    )
                    session.add(selector_entry)
                
                session.commit()
                logger.info(f"Created selector '{selector_name}' with {len(series_specs)} series")
                return True

        except Exception as e:
            logger.error(f"Failed to create selector '{selector_name}': {e}")
            return False

    def _get_ticker_from_meta(self, series_ids: Union[int, List[int]]) -> Union[Optional[str], Dict[int, str]]:
        """
        Get the ticker(s) for series from the Meta table.
        
        Args:
            series_ids: Single series ID (int) or list of series IDs
            
        Returns:
            For single ID: Ticker string or None if not found
            For list of IDs: Dictionary mapping series_id -> ticker
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesMeta

                # Handle single series ID
                if isinstance(series_ids, int):
                    metadata = session.query(TimeSeriesMeta).filter_by(id=series_ids).first()

                    if metadata:
                        logger.debug(f"Found ticker '{metadata.ticker}' for series {series_ids}")
                        return metadata.ticker
                    else:
                        logger.warning(f"Series ID {series_ids} not found in TS_Meta table")
                        return None

                # Handle list of series IDs
                elif isinstance(series_ids, list):
                    if not series_ids:
                        return {}

                    # Query all series at once for efficiency
                    metadata_list = session.query(TimeSeriesMeta).filter(
                        TimeSeriesMeta.id.in_(series_ids)
                    ).all()

                    # Create mapping from series_id to canonical ticker
                    result = {}
                    found_ids = set()

                    for metadata in metadata_list:
                        result[metadata.id] = metadata.ticker
                        found_ids.add(metadata.id)
                        logger.debug(f"Found ticker '{metadata.ticker}' for series {metadata.id}")

                    # Log missing series IDs
                    missing_ids = set(series_ids) - found_ids
                    if missing_ids:
                        logger.warning(f"Series IDs not found in TS_Meta table: {sorted(missing_ids)}")

                    logger.debug(f"Retrieved tickers for {len(result)}/{len(series_ids)} series")
                    return result

                else:
                    raise ValueError(f"series_ids must be int or list, got {type(series_ids)}")

        except Exception as e:
            logger.error(f"Failed to get ticker(s) for series {series_ids}: {e}")
            if isinstance(series_ids, int):
                return None
            else:
                return {}

    def generate_selector(self, selector_name: str, series_list: List[Dict[str, Any]],
                          group: str = 'X') -> bool:
        """
        Generate a selector from a list of series information.
        
        This is a convenience function that automatically handles ID lookup and selector creation.
        
        Args:
            selector_name: Name for the selector group
            series_list: List of dictionaries with keys:
                - 'id' or 'sid': Series ID (int) or String ID (str) from TSIdMap
                - 'colname': Column name for DataFrame (optional)
                - 'desname': Descriptive name (optional)
                - 'order': Order in selector (optional, defaults to list order)
            group: Group name within the selector (default: 'X', added to each spec)
        
        Returns:
            True if successful
        """
        """
        Generate a selector by providing selection name, id/sid, colname, and desname.
        
        This is a convenience function that automatically handles ID lookup and selector creation.
        
        Args:
            selector_name: Name for the selector group
            series_list: List of dictionaries with keys:
                - 'id' or 'sid': Series ID (int) or String ID (str) from TSIdMap
                - 'colname': Column name for DataFrame (optional)
                - 'desname': Descriptive name (optional)
                - 'order': Order in selector (optional, defaults to list order)
            group: Group name within the selector (default: 'X')
        
        Returns:
            True if successful
        """
        try:
            processed_specs = []

            for i, series_info in enumerate(series_list):
                series_id = self._extract_series_id_from_spec(series_info)
                if series_id is None:
                    continue

                # Create spec for create_selector
                spec = {
                    'series_id': series_id,
                    'order': series_info.get('order', i + 1),
                    'colname': series_info.get('colname'),
                    'desname': series_info.get('desname')
                }
                processed_specs.append(spec)

            if not processed_specs:
                logger.error(f"No valid series found for selector '{selector_name}'")
                return False

            # Add group to each spec if provided
            if group:
                for spec in processed_specs:
                    spec['group'] = group
            
            # Use existing create_selector method
            return self.create_selector(selector_name, processed_specs)

        except Exception as e:
            logger.error(f"Failed to generate selector '{selector_name}' group '{group}': {e}")
            return False

    def delete_selector(self, selector_name: str) -> bool:
        """
        Delete a selector (all groups).
        
        Args:
            selector_name: Name of the selector to delete (deletes all groups)
            
        Returns:
            True if successful
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesSelector

                # Delete all groups for this selector
                deleted_count = session.query(TimeSeriesSelector).filter_by(sel=selector_name).delete()
                logger.info(f"Deleted selector '{selector_name}' (all groups) with {deleted_count} entries")
                return True

        except Exception as e:
            logger.error(f"Failed to delete selector '{selector_name}': {e}")
            return False

    def update_selector(self, selector_name: str, series_specs: List[Dict[str, Any]],
                        group: str = 'X') -> bool:
        """
        Update an existing selector group.
        
        Args:
            selector_name: Name of the selector to update
            series_specs: List of series specifications with order
            group: Group name within the selector (default: 'X', added to each spec if not in spec)
            
        Returns:
            True if successful
        """
        # Add group to each spec if not already present
        for spec in series_specs:
            if 'group' not in spec and 'grp' not in spec:
                spec['group'] = group
        
        # This is essentially the same as create_selector since it clears and recreates
        return self.create_selector(selector_name, series_specs)

    def _extract_series_id_from_spec(self, series_info: Dict[str, Any]) -> Optional[int]:
        """Extract series ID from series specification."""
        if 'id' in series_info:
            return series_info['id']
        elif 'sid' in series_info:
            # Look up ID by SID
            series_id = self._get_id_by_sid(series_info['sid'])
            if series_id is None:
                logger.warning(f"Series with SID '{series_info['sid']}' not found in TSIdMap")
            return series_id
        else:
            logger.error(f"Series specification must include either 'id' or 'sid': {series_info}")
            return None

    def _get_id_by_sid(self, sid: str) -> Optional[int]:
        """
        Get series ID by String ID (SID).
        
        Args:
            sid: String ID from TSIdMap
            
        Returns:
            Series ID if found, None otherwise
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesMeta

                result = session.query(TimeSeriesMeta.id).filter_by(sid=sid).first()
                return result[0] if result else None

        except Exception as e:
            logger.error(f"Error looking up SID '{sid}': {e}")
            return None

    def _get_current_user(self) -> str:
        """
        Get the current OS user for TimeSeriesStatus tracking.
        
        Returns:
            Current username or 'system' if unable to determine
        """
        try:
            import getpass
            return getpass.getuser()
        except Exception:
            try:
                import os
                return os.getlogin()
            except Exception:
                logger.warning("Could not determine current user, using 'system'")
                return 'system'

    def batch_update_series_status(self, series_stats: pd.DataFrame, upd_by: Optional[str] = None) -> bool:
        """
        Batch update TimeSeriesStatus records for multiple series using multiple queries.
        
        Args:
            series_stats: DataFrame with columns ['id', 'min', 'max'] containing series_id and date ranges
            upd_by: User who performed the update (optional, defaults to current OS user)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            from .utils.date_utils import normalize_date_input
            from datetime import datetime

            if series_stats.empty:
                logger.warning("No series status data to update")
                return False

            # Use current user if none provided
            if upd_by is None:
                upd_by = self._get_current_user()

            current_time = datetime.now()

            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesStatus

                # Prepare batch updates
                updates_by_id = {}
                for _, row in series_stats.iterrows():
                    series_id = row['id']
                    upd_start = normalize_date_input(row['min'], '%Y-%m-%d')
                    upd_end = normalize_date_input(row['max'], '%Y-%m-%d')

                    updates_by_id[series_id] = {
                        'upd': current_time,
                        'upd_start': upd_start,
                        'upd_end': upd_end,
                        'upd_by': upd_by
                    }

                # Perform batch updates using multiple SQLAlchemy queries
                for series_id, updates in updates_by_id.items():
                    session.query(TimeSeriesStatus).filter(
                        TimeSeriesStatus.id == series_id
                    ).update(updates)

                session.commit()
                logger.info(f"Batch updated {len(updates_by_id)} TimeSeriesStatus records")
                return True

        except Exception as e:
            logger.error(f"Failed to batch update TimeSeriesStatus records: {e}")
            return False

    def upsert_series_status(self, series_id: int, upd_start: DateInput, upd_end: DateInput,
                             upd_by: Optional[str] = None) -> bool:
        """
        Upsert (create or update) a TimeSeriesStatus record for a series.
        
        Args:
            series_id: Series ID to upsert status for
            upd_start: Start date of the time series update
            upd_end: End date of the time series update  
            upd_by: User who performed the update (optional, defaults to current OS user)
            
        Returns:
            True if successful
        """
        try:
            from .utils.date_utils import normalize_date_input
            from datetime import datetime

            # Normalize date inputs
            upd_start = normalize_date_input(upd_start, '%Y-%m-%d')
            upd_end = normalize_date_input(upd_end, '%Y-%m-%d')

            # Use current user if none provided
            if upd_by is None:
                upd_by = self._get_current_user()

            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesStatus

                # Check if status record already exists
                existing_status = session.query(TimeSeriesStatus).filter_by(id=series_id).first()

                if existing_status:
                    # Update existing record
                    existing_status.upd = datetime.now()
                    existing_status.upd_start = upd_start
                    existing_status.upd_end = upd_end
                    if upd_by:
                        existing_status.upd_by = upd_by
                    logger.info(f"Updated TimeSeriesStatus for series {series_id}")
                else:
                    # Create new record
                    status_record = TimeSeriesStatus(
                        id=series_id,
                        upd=datetime.now(),
                        upd_start=upd_start,
                        upd_end=upd_end,
                        upd_by=upd_by
                    )
                    session.add(status_record)
                    logger.info(f"Created TimeSeriesStatus for series {series_id}")

                return True

        except Exception as e:
            logger.error(f"Failed to create/update TimeSeriesStatus for series {series_id}: {e}")
            return False

    def get_series_status(self, series_id: int) -> Optional[Dict[str, Any]]:
        """
        Get TimeSeriesStatus information for a series.
        
        Args:
            series_id: Series ID to get status for
            
        Returns:
            Dictionary with status information or None if not found
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesStatus

                status = session.query(TimeSeriesStatus).filter_by(id=series_id).first()

                if not status:
                    return None

                return {
                    'series_id': status.id,
                    'last_update': status.upd,
                    'update_start': status.upd_start,
                    'update_end': status.upd_end,
                    'updated_by': status.upd_by
                }

        except Exception as e:
            logger.error(f"Error getting TimeSeriesStatus for series {series_id}: {e}")
            return None

    def delete_series_status(self, series_id: int) -> bool:
        """
        Delete TimeSeriesStatus record for a series.
        
        Args:
            series_id: Series ID to delete status for
            
        Returns:
            True if successful
        """
        try:
            with self.session_manager.get_session() as session:
                from .MasDatabase.models import TimeSeriesStatus

                deleted_count = session.query(TimeSeriesStatus).filter_by(id=series_id).delete()
                logger.info(f"Deleted TimeSeriesStatus for series {series_id}")
                return True

        except Exception as e:
            logger.error(f"Failed to delete TimeSeriesStatus for series {series_id}: {e}")
            return False

    def _process_bulk_data_for_upsert(self, bulk_response: Dict[str, Any]) -> pd.DataFrame:
        """
        Process bulk data for database upsert operations.
        
        This method takes the response from bulk_get_historical or bulk_get_reference
        and processes it into a DataFrame ready for TS_Data insertion.
        
        Args:
            bulk_response: Response from bulk_get_historical or bulk_get_reference
                          Must contain 'data' and 'metadata' keys
            
        Returns:
            DataFrame with columns (id, date, value) ready for TS_Data insertion
        """
        import pandas as pd

        # Extract data and metadata from response
        bulk_data = bulk_response['data']
        if bulk_data is None or (hasattr(bulk_data, 'empty') and bulk_data.empty) or (
                not hasattr(bulk_data, 'empty') and not bulk_data):
            logger.warning("No data to process")
            return pd.DataFrame()

        metadata = bulk_response['metadata']

        # Extract variables from metadata early
        field = metadata['field']
        frequency = metadata['frequency']
        currency = metadata['currency']
        source = metadata['source']

        try:
            # Handle different data formats based on source
            if source == 'DS':
                # Datastream data comes as a DataFrame with multi-level columns
                df, tickers, _ = self._reshape_datastream_dataframe(bulk_data, metadata)

            else:
                # Bloomberg data comes as a list of dictionaries
                df, tickers, _ = self._reshape_bloomberg_data(bulk_data, metadata)

            # Get TS_Meta data for these tickers with field, frequency, currency, source
            # Use the existing session_manager.get_ts_metadata method

            # print(df)

            meta_df = self.session_manager.get_ts_metadata(
                ticker=tickers,
                field=field,
                frequency=frequency,
                currency=currency,
                source=source
            )

            if meta_df.empty:
                logger.warning(
                    f"No TS_Meta entries found for tickers {tickers} with field={field}, frequency={frequency}, currency={currency}, source={source}")
                return pd.DataFrame()

            # Left join data with meta to get series_id
            data_with_meta = df.merge(
                meta_df[['ticker', 'id']],
                on='ticker',
                how='left'
            )

            # Check for rows missing series_id and warn
            missing_id_count = data_with_meta['id'].isna().sum()
            if missing_id_count > 0:
                logger.warning(
                    f"{missing_id_count} rows missing series_id in TS_Meta (out of {len(data_with_meta)} total rows)")

            # Filter out rows without series_id
            data_with_meta = data_with_meta.dropna(subset=['id'])

            if data_with_meta.empty:
                logger.warning("No data rows have matching series_id in TS_Meta")
                return pd.DataFrame()

            # Prepare final DataFrame with (id, date, value)
            # TimeSeriesAdmin assumes all data is time series data
            if 'date' not in data_with_meta.columns:
                raise ValueError("Time series data must contain 'date' column. Data without dates is not supported.")

            # Historical time series data
            result_df = data_with_meta[['id', 'date', 'value']].copy()
            result_df['date'] = pd.to_datetime(result_df['date']).dt.strftime('%Y-%m-%d')

            # Note: TS_Status updates are now handled explicitly in the calling method
            # to provide better error handling and logging

            logger.info(f"Prepared {len(result_df)} records for TS_Data insertion")
            return result_df

        except Exception as e:
            logger.error(f"Error processing data for upsert: {e}")
            return pd.DataFrame()

    def _reshape_datastream_dataframe(self, bulk_data: pd.DataFrame, metadata: Dict[str, Any]) -> Tuple[
        pd.DataFrame, List[str], str]:
        """
        Reshape Datastream DataFrame from wide format to long format.
        
        Datastream data comes as a wide DataFrame with multi-level columns:
        Instrument -> Field -> Currency -> Dates
        
        This method converts it to long format: (ticker, date, value)
        
        Args:
            bulk_data: Wide format DataFrame from Datastream
            metadata: Metadata dictionary containing field and other info
            
        Returns:
            Tuple of (DataFrame in long format, tickers list, field_col)
        """
        import pandas as pd

        field = metadata['field']

        df = bulk_data
        if df.empty:
            logger.warning("No data to process")
            return pd.DataFrame(), [], field

        # Extract tickers from the multi-level DataFrame
        # The DataFrame has structure: Instrument -> Field -> Currency -> Dates
        if hasattr(df.columns, 'levels'):
            # Multi-level columns
            instruments = df.columns.get_level_values(0).unique()
            tickers = [inst for inst in instruments if inst.startswith('@:')]
        else:
            # Single level columns - extract from column names
            tickers = [col for col in df.columns if col.startswith('@:')]

        if not tickers:
            raise ValueError(
                f"No valid Datastream tickers found in DataFrame. Expected tickers starting with '@:', but found: {list(df.columns) if not hasattr(df.columns, 'levels') else [col[0] for col in df.columns]}")

        # For DS, we'll use the field from metadata
        field_col = field

        # Verify that all columns have the same field as in metadata
        field_level = df.columns.get_level_values(1).unique()
        if len(field_level) > 1:
            logger.warning(f"Multiple fields found in data: {field_level}, using metadata field: {field}")
        elif len(field_level) == 1 and field_level[0] != field:
            logger.warning(f"Field mismatch: data has {field_level[0]}, metadata has {field}")

        # Extract tickers from multi-level columns and verify they match metadata
        extracted_tickers = [col[0] for col in df.columns]
        metadata_tickers = metadata.get('tickers', [])

        if set(extracted_tickers) != set(metadata_tickers):
            raise ValueError(f"Ticker mismatch: extracted {extracted_tickers} vs metadata {metadata_tickers}")

        # Flatten multi-level columns to use tickers as column names
        df.columns = extracted_tickers

        # Reset index to get dates as a column
        df_reset = df.reset_index()
        date_col = df_reset.columns[0]  # First column should be the date index

        # Melt the DataFrame to long format
        df_long = df_reset.melt(id_vars=[date_col], var_name='ticker', value_name='value')

        # Rename date column
        df_long = df_long.rename(columns={date_col: 'date'})

        # Filter out rows with NaN values
        df_long = df_long.dropna(subset=['value'])

        # Clean the DataFrame to convert date strings to timestamps if needed
        from .utils.data_utils import clean_ts_dataframe
        df_long = clean_ts_dataframe(df_long)

        return df_long, tickers, field_col

    def _reshape_bloomberg_data(self, bulk_data: List[Dict[str, Any]], metadata: Dict[str, Any]) -> Tuple[
        pd.DataFrame, List[str], str]:
        """
        Process Bloomberg data from list of dictionaries to DataFrame.
        
        Bloomberg data comes as a list of dictionaries with structure:
        [{'ticker': 'AAPL', 'date': '2025-01-01', 'PX_LAST': 150.0}, ...]
        
        This method converts it to DataFrame and extracts tickers and field column.
        
        Args:
            bulk_data: List of dictionaries from Bloomberg API
            metadata: Metadata dictionary containing field and other info
            
        Returns:
            Tuple of (DataFrame, tickers list, field_col)
        """
        import pandas as pd

        field = metadata['field']

        if not bulk_data:
            logger.warning("No data to process")
            return pd.DataFrame(), [], field

        # Convert to DataFrame
        df = pd.DataFrame(bulk_data)

        if df.empty:
            logger.warning("No data to process")
            return pd.DataFrame(), [], field

        # Find the field column (case-insensitive)
        field_col = None
        for col in df.columns:
            if col.upper() == field.upper():
                field_col = col
                break

        if field_col is None:
            raise ValueError(f"Field {field} not found in response data")

        # Rename the field column to 'value' for consistency
        df = df.rename(columns={field_col: 'value'})

        # Get unique tickers from data
        tickers = df['ticker'].unique().tolist()

        return df, tickers, field_col

    def upsert_bulk_data(self, bulk_response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Public method to upsert bulk data into the database.
        
        This method processes bulk data and inserts it into TS_Data table.
        It provides a clean, high-level interface for bulk data operations.
        
        Args:
            bulk_response: Response from bulk_get_historical or bulk_get_reference
                          Must contain 'data' and 'metadata' keys
            
        Returns:
            Dict with 'success' (bool) and 'processed_df' (DataFrame) keys
        """
        try:
            # Process data for upsert mode
            upsert_df = self._process_bulk_data_for_upsert(bulk_response)

            if upsert_df.empty:
                logger.warning("No data to upsert")
                return {'success': False, 'processed_df': upsert_df}

            # Insert data into TS_Data
            self.session_manager.upsert_ts_data(upsert_df)

            logger.info(f"Successfully upserted {len(upsert_df)} records to TS_Data")
            return {'success': True, 'processed_df': upsert_df}

        except Exception as e:
            logger.error(f"Failed to upsert bulk data: {e}")
            return {'success': False, 'processed_df': None}

    def upsert_bulk_data_with_status(self, bulk_response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Upsert bulk data and update TS_Status records.
        
        This method combines data upsert with TS_Status updates for complete
        bulk processing operations.
        
        Args:
            bulk_response: Response from bulk_get_historical or bulk_get_reference
                          Must contain 'data' and 'metadata' keys
            
        Returns:
            Dict with 'success', 'status_updated', 'status_count', and 'errors' keys
        """
        try:
            # Use the main upsert method to get processed data
            upsert_result = self.upsert_bulk_data(bulk_response)
            
            if not upsert_result['success']:
                return {'success': False, 'status_updated': False, 'status_count': 0, 'errors': ['Data upsert failed']}

            upsert_df = upsert_result['processed_df']
            logger.info(f"Successfully upserted {len(upsert_df)} records to TS_Data")

            # Update TS_Status for the processed series
            status_update_success = False
            status_update_count = 0
            try:
                if not upsert_df.empty:
                    # Group by series ID to get date ranges for each series
                    series_stats = upsert_df.groupby('id')['date'].agg(['min', 'max']).reset_index()
                    status_update_count = len(series_stats)
                    
                    # Update TS_Status for all series
                    status_success = self.batch_update_series_status(series_stats)
                    if status_success:
                        status_update_success = True
                        logger.info(f"✅ TS_Status updated for {len(series_stats)} series")
                    else:
                        logger.warning("⚠️ Failed to update TS_Status")
                else:
                    logger.warning("⚠️ No data available for TS_Status update")
            except Exception as status_error:
                logger.error(f"❌ Error updating TS_Status: {status_error}")

            return {
                'success': True,
                'status_updated': status_update_success,
                'status_count': status_update_count,
                'errors': []
            }

        except Exception as e:
            logger.error(f"Failed to upsert bulk data with status: {e}")
            return {'success': False, 'status_updated': False, 'status_count': 0, 'errors': [str(e)]}

    def get_field_specific_start_date(self, field: str, provided_start_date: str) -> str:
        """
        Public method to get field-specific start date.
        
        This method can be used by external scripts to get the appropriate
        start date for a specific field before making bulk data requests.
        
        Args:
            field: Field name to check
            provided_start_date: Original start date provided
            
        Returns:
            str: Adjusted start date if field-specific logic applies, otherwise original date
        """
        return self._get_field_specific_start_date(field, provided_start_date)

    def group_upsert(self, group_info: Dict[str, Any], start_date: str, chunk_size: int = 20) -> Dict[str, Any]:
        """
        Process bulk data for a group using the appropriate feed based on source.
        For large ticker lists, processes data in chunks to avoid API limits.
        
        Args:
            group_info: Group information for bulk processing containing:
                - tickers: List of tickers
                - field: Field name
                - frequency: Data frequency
                - currency: Currency (optional)
                - source: Source code ('BB' or 'DS')
            start_date: Start date for data retrieval
            chunk_size: Maximum number of tickers to process in each chunk (default: 20)
            
        Returns:
            Dictionary with processing results
        """

        def process_ticker_chunk(chunk_tickers: List[str]) -> Dict[str, Any]:
            """Helper function to process a single chunk of tickers."""
            try:
                # Call the appropriate feed method based on source
                if source == 'BB':
                    result = feed.bulk_get_historical(
                        tickers=chunk_tickers,
                        field=field,
                        start_date=start_date,
                        frequency=frequency,
                        currency=None if currency == '-' else currency
                    )
                    data_valid = result and 'data' in result
                elif source == 'DS':
                    result = feed.bulk_get_data(
                        tickers=chunk_tickers,
                        field=field,
                        frequency=frequency,
                        start_date=start_date,
                        end_date=None  # Use default end date
                    )
                    data_valid = result and 'data' in result and result['data'] is not None and not result['data'].empty
                else:
                    raise ValueError(f"Unsupported source: {source}")

                if not data_valid:
                    logger.warning(f"⚠️ No data returned for {source} bulk: {field}")
                    return {'success': 0, 'failed': len(chunk_tickers), 'errors': [f"No data for {field}"]}

                # Use self.upsert_bulk_data_with_status for complete bulk processing
                try:
                    upsert_result = self.upsert_bulk_data_with_status(result)
                    if upsert_result['success']:
                        record_count = result['metadata'].get('record_count', 0) if 'metadata' in result else 0
                        
                        logger.info(
                            f"✅ {source} bulk upsert successful: {len(chunk_tickers)} tickers, field: {field}, records: {record_count}")
                        return {
                            'success': len(chunk_tickers), 
                            'failed': 0, 
                            'errors': [],
                            'status_updated': upsert_result['status_updated'],
                            'status_count': upsert_result['status_count']
                        }
                    else:
                        logger.warning(f"⚠️ {source} bulk upsert returned no data: {field}")
                        return {'success': 0, 'failed': len(chunk_tickers), 'errors': [f"No data for {field}"]}
                except Exception as e:
                    logger.error(f"❌ {source} bulk upsert error: {e}")
                    return {'success': 0, 'failed': len(chunk_tickers), 'errors': [str(e)]}

            except Exception as e:
                logger.error(f"❌ {source} chunk processing error: {e}")
                return {'success': 0, 'failed': len(chunk_tickers), 'errors': [str(e)]}

        try:
            tickers = group_info['tickers']
            field = group_info['field']
            frequency = group_info['frequency']
            source = group_info['source']
            currency = group_info.get('currency')

            logger.info(f"🚀 Processing {source} bulk: {len(tickers)} tickers, field: {field}")

            # Get the appropriate feed (common setup)
            feeds = self.get_available_feeds()
            if source == 'BB':
                feed = feeds['bloomberg']
            elif source == 'DS':
                feed = feeds['datastream']
            else:
                raise ValueError(f"Unsupported source: {source}")

            # If ticker list is small, process all at once
            if len(tickers) <= chunk_size:
                return process_ticker_chunk(tickers)

            # For large ticker lists, process in chunks
            logger.info(f"📦 Chunking {len(tickers)} tickers into chunks of {chunk_size}")

            total_success = 0
            total_failed = 0
            all_errors = []

            # Process tickers in chunks
            for i in range(0, len(tickers), chunk_size):
                chunk_tickers = tickers[i:i + chunk_size]

                logger.info(
                    f"🔄 Processing chunk {i // chunk_size + 1}/{(len(tickers) + chunk_size - 1) // chunk_size}: {len(chunk_tickers)} tickers")

                try:
                    chunk_result = process_ticker_chunk(chunk_tickers)
                    total_success += chunk_result['success']
                    total_failed += chunk_result['failed']
                    all_errors.extend(chunk_result['errors'])

                    logger.info(
                        f"✅ Chunk {i // chunk_size + 1} completed: {chunk_result['success']} success, {chunk_result['failed']} failed")

                except Exception as e:
                    logger.error(f"❌ Chunk {i // chunk_size + 1} failed: {e}")
                    total_failed += len(chunk_tickers)
                    all_errors.append(f"Chunk {i // chunk_size + 1} error: {str(e)}")

            logger.info(f"🎉 All chunks completed: {total_success} total success, {total_failed} total failed")
            return {'success': total_success, 'failed': total_failed, 'errors': all_errors}

        except Exception as e:
            logger.error(f"❌ {source} bulk processing error: {e}")
            return {'success': 0, 'failed': len(group_info['tickers']), 'errors': [str(e)]}
