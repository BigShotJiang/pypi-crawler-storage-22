"""
Base class for time series operations.

Provides shared infrastructure for database connections, feed initialization,
and common utilities used by both reader and admin classes.
"""
import logging
from typing import Dict, Any

from .config import Config
from .MasDatabase import DatabaseBase
from .MasDatabase.time_series_session import TimeSeriesSessionManager

logger = logging.getLogger(__name__)


class TimeSeriesBase(DatabaseBase):
    """
    Base class for time series operations.
    
    Provides shared infrastructure including database connections, feed initialization,
    and common utilities. This class is not meant to be used directly - use
    MasTimeSeriesReader for read operations or MasTimeSeriesAdmin for write operations.
    """
    
    def __init__(self, config: Config, auto_create_tables: bool = True):
        """
        Initialize TimeSeriesBase.
        
        Args:
            config: Configuration object with database and feed settings
            auto_create_tables: If True, automatically create database tables if they don't exist
        """
        super().__init__(config, auto_create_tables)
        
        # Initialize time series specific session manager
        self.session_manager = TimeSeriesSessionManager(
            self.db_manager, 
            chunk_size=config.database.chunk_size
        )
