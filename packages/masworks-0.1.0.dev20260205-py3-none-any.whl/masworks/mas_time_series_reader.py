"""
Read-only interface for time series data retrieval.

Provides methods for querying time series data, metadata, and selectors
without the ability to modify data.
"""
import logging
from tkinter import NONE
from typing import Optional, Dict, Any, List, Union, Protocol, Generator
import pandas as pd
from sqlalchemy import select, text

from .mas_time_series_base import TimeSeriesBase
from .MasDatabase import TimeSeriesMeta
from .constants import SOURCE_ALIASES, SOURCE_CODE_MAP
from .types import DateInput
from .utils.date_utils import normalize_date_input

logger = logging.getLogger(__name__)

_FREQUENCY_WEIGHTS = {
    'D': 1,
    'W': 7,
    'M': 30,
    'Q': 90,
    'Y': 365,
    'A': 365,
}


def _normalize_frequency_value(freq: Optional[str]) -> Optional[str]:
    if freq is None:
        return None
    freq_str = str(freq).strip().upper()
    return freq_str or None


def _needs_monthly_collapse(freq: Optional[str], target: str = 'M') -> bool:
    freq_norm = _normalize_frequency_value(freq)
    target_norm = _normalize_frequency_value(target) or 'M'
    freq_weight = _FREQUENCY_WEIGHTS.get(freq_norm, _FREQUENCY_WEIGHTS[target_norm])
    target_weight = _FREQUENCY_WEIGHTS.get(target_norm, 30)
    return freq_weight < target_weight


def _build_date_expression_sql(use_lag: bool, align: Optional[str]) -> str:
    base_expr = "d.date"
    if use_lag:
        base_expr = "DATEADD(day, COALESCE(m.daylag, 0), d.date)"
    align_norm = _normalize_frequency_value(align)
    if align_norm == 'EOM':
        base_expr = f"EOMONTH({base_expr})"
    return base_expr


def _build_lagged_query_sql(
    date_expr: str,
    data_table: str,
    meta_table: str,
    where_clause: str,
    collapse_to_month: bool,
) -> str:
    if collapse_to_month:
        return f"""
WITH lagged AS (
    SELECT
        {date_expr} AS adj_date,
        d.value,
        ROW_NUMBER() OVER (
            PARTITION BY {date_expr}
            ORDER BY d.date DESC
        ) AS rn
    FROM {data_table} AS d
    JOIN {meta_table} AS m ON d.id = m.id
    WHERE {where_clause}
)
SELECT
    adj_date AS date,
    value
FROM lagged
WHERE rn = 1
ORDER BY adj_date;
"""
    return f"""
SELECT
    {date_expr} AS date,
    d.value
FROM {data_table} AS d
JOIN {meta_table} AS m ON d.id = m.id
WHERE {where_clause}
ORDER BY {date_expr};
"""


class ReturnHandler(Protocol):
    """Protocol for return type handlers."""
    def __call__(self, data: Dict[str, pd.Series]) -> Any: ...


class MasTimeSeriesReader(TimeSeriesBase):
    """
    Read-only interface for time series data retrieval.
    
    Provides methods for querying time series data, metadata, and selectors
    without the ability to modify data. This class is safe for read-only
    operations and can be used in environments where data modification
    should be restricted.
    """
    
    def _get_schema(self) -> str:
        """Get the database schema from config."""
        return self.db_manager.config.schema
    
    def get_series_data(self, series_id: Optional[Union[int, List[int], Dict[int, str]]] = None, 
                       ticker: Optional[str] = None, field: Optional[str] = None,
                       source: Optional[str] = None, frequency: Optional[str] = None,
                       start_date: DateInput = None, end_date: DateInput = None,
                       return_as: str = 'df') -> Union[pd.DataFrame, Dict[str, pd.Series]]:
        """
        Retrieve time series data from database.
        
        Args:
            series_id: Series ID specification:
                - int: Single series ID
                - List[int]: List of series IDs
                - Dict[int, str]: Dict mapping series IDs to column names
            ticker: Filter by ticker (if series_id not provided)
            field: Filter by field (if series_id not provided)
            source: Filter by source (if series_id not provided)
            frequency: Filter by frequency (if series_id not provided)
            start_date: Start date filter (str, datetime, pd.Timestamp, or None)
            end_date: End date filter (str, datetime, pd.Timestamp, or None)
            return_as: Return format - 'df' for DataFrame, 'dict' for dict of series
            
        Returns:
            DataFrame or dict of series based on return_as parameter
        """
        # Normalize date inputs
        start_date = normalize_date_input(start_date, '%Y-%m-%d')
        end_date = normalize_date_input(end_date, '%Y-%m-%d')
        
        if series_id is None:
            series_id = self._find_series_id_by_metadata(ticker, field, source, frequency)
            if series_id is None:
                return pd.DataFrame() if return_as == 'df' else {}
        
        # Handle different input types
        if isinstance(series_id, dict):
            # Dictionary input: {series_id: column_name}
            series_ids = series_id
        elif isinstance(series_id, int):
            # Single int: convert to dict
            series_ids = {series_id: f"series_{series_id}"}
        else:
            # List input: convert to dict with default names
            series_ids = {sid: f"series_{sid}" for sid in series_id}
        
        # Get data for each series and combine
        all_data = {}
        for sid, col_name in series_ids.items():
            series_data = self.session_manager.get_ts_data(sid, start_date, end_date)
            if not series_data.empty:
                all_data[col_name] = series_data['value']

        # Handle return_as parameter
        if return_as == 'dict':
            return all_data
        else:
            # Combine all series into a single DataFrame
            result = pd.DataFrame(all_data)
            result.index.name = 'date'
            return result
    
    def get_series_metadata(self, **filters) -> pd.DataFrame:
        """
        Get time series metadata with optional filters.
        
        Args:
            **filters: Filter criteria (id, source, ticker, field, etc.)
                - source: Will be normalized and converted to source code
                - ticker: Will be normalized to uppercase
                - field: Will be normalized to uppercase
                - Other filters passed directly to database query
            
        Returns:
            List of TimeSeriesMeta objects
        """
        # Process parameters that need normalization
        processed_filters = filters.copy()
        
        # Process source parameter
        if 'source' in processed_filters:
            source = processed_filters.pop('source')
            source = self._normalize_source(source)
            processed_filters['source'] = self._get_source_code(source)
        
        # Process ticker parameter
        if 'ticker' in processed_filters:
            ticker = processed_filters.pop('ticker')
            processed_filters['ticker'] = ticker.upper()
        
        # Process field parameter
        if 'field' in processed_filters:
            field = processed_filters.pop('field')
            processed_filters['field'] = field.upper()
        
        return self.session_manager.get_ts_metadata(**processed_filters)
    
    def get_selector_data(self, selector_name: str, start_date: DateInput = None,
                         end_date: DateInput = None, 
                         return_as: Union[str, ReturnHandler] = "auto",
                         verbose: bool = False) -> Any:
        """
        Get data for all series in a selector group.
        
        Args:
            selector_name: Name of the selector group
            start_date: Start date filter (str, datetime, pd.Timestamp, or None)
            end_date: End date filter (str, datetime, pd.Timestamp, or None)
            return_as: Return format - either:
                - String: "auto", "dataframe", "dict", "dictionary", "df", "group", "grp", "group.df", "group.dataframe"
                - Callable: Function that takes Dict[str, pd.Series] and returns Any
            verbose: If True, print progress information during data retrieval
            
        Returns:
            Data in the requested format:
            - "auto": DataFrame if all series have same frequency, dict if mixed
            - "dataframe"/"df": DataFrame with all series data (wide format)
            - "dict"/"dictionary": Dictionary with column names as keys and Series as values
            - "group"/"grp": Dictionary with group names as keys and dict of series as values
            - "group.df"/"group.dataframe": Dictionary with group names as keys and DataFrames as values
            - Callable: Result of calling the function with the data dictionary
        """
        # Normalize date inputs
        start_date = normalize_date_input(start_date, '%Y-%m-%d')
        end_date = normalize_date_input(end_date, '%Y-%m-%d')
        
        selector_info = self.get_selector_series_info(selector_name)
        
        if selector_info.empty:
            logger.warning(f"No series found in selector: {selector_name}")
            return None
        
        return_parts = return_as.split('.')
        base_format = return_parts[0]
        sub_format = return_parts[1] if len(return_parts) > 1 else None

        if base_format in ["grp", "group"]:
            return self._build_selector_dataset_by_group(selector_info, start_date, end_date, sub_format, verbose)
        else:
            return self._build_selector_dataset(selector_info, start_date, end_date, return_as, verbose)
        
    
    def list_available_series(self, source: Optional[str] = None, 
                             frequency: Optional[str] = None, 
                             limit: int = 100) -> pd.DataFrame:
        """
        List available series with optional filters.
        
        Args:
            source: Filter by data source
            frequency: Filter by frequency
            limit: Maximum number of results to return
            
        Returns:
            DataFrame with series metadata
        """
        filters = {}
        if source:
            source = self._normalize_source(source)
            filters['source'] = self._get_source_code(source)
        if frequency:
            filters['frequency'] = frequency.upper()
        
        df = self.session_manager.get_ts_metadata(**filters)
        
        if df.empty:
            return pd.DataFrame()
        

        df = df.head(limit)
        
        return df

    def query_series_with_lag(
        self,
        series_id: Optional[int] = None,
        ticker: Optional[str] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        frequency: Optional[str] = None,
        start_date: DateInput = None,
        end_date: DateInput = None,
        use_lag: bool = True,
        align: Optional[str] = None,
        label: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Query a single time series applying metadata lag offsets and alignment rules.

        Args:
            series_id: Series identifier. If not provided, ticker/field/source/frequency
                filters are used to locate the series.
            ticker: Ticker filter when series_id is not provided.
            field: Field filter when series_id is not provided.
            source: Source filter when series_id is not provided.
            frequency: Frequency filter when series_id is not provided.
            start_date: Optional start date filter.
            end_date: Optional end date filter.
            use_lag: Apply COALESCE(daylag2, daylag) to dates when True.
            align: Alignment option. Currently supports 'EOM' for end-of-month alignment.
            label: Optional column label; defaults to metadata cname/fld.

        Returns:
            pd.DataFrame: Indexed by date with a single value column.
        """
        align_norm = _normalize_frequency_value(align)
        if align_norm not in (None, 'EOM'):
            raise ValueError("align must be None or 'EOM'")

        start_date = normalize_date_input(start_date, '%Y-%m-%d')
        end_date = normalize_date_input(end_date, '%Y-%m-%d')

        metadata_filters: Dict[str, Any] = {}
        if series_id is not None:
            metadata_filters['id'] = series_id
        else:
            if ticker:
                metadata_filters['ticker'] = ticker
            if field:
                metadata_filters['field'] = field
            if source:
                metadata_filters['source'] = source
            if frequency:
                metadata_filters['frequency'] = frequency

        metadata = self.get_series_metadata(**metadata_filters)
        if metadata.empty:
            raise ValueError("Unable to locate series metadata with provided filters.")

        meta_row = metadata.iloc[0]
        resolved_series_id = int(meta_row['id'])
        freq_code = meta_row.get('frequency') or meta_row.get('frq')  # Prefer full name, fallback to abbreviated
        column_label = label or meta_row.get('cname') or meta_row.get('field') or meta_row.get('fld') or f"series_{resolved_series_id}"

        data_table = f"{self._get_schema()}.TS_Data"
        meta_table = f"{self._get_schema()}.TS_Meta"

        where_clauses = ["d.id = :series_id"]
        params: Dict[str, Any] = {'series_id': resolved_series_id}

        if start_date:
            where_clauses.append("d.date >= :start_date")
            params['start_date'] = start_date
        if end_date:
            where_clauses.append("d.date <= :end_date")
            params['end_date'] = end_date

        where_clause = " AND ".join(where_clauses)
        date_expr = _build_date_expression_sql(use_lag, align_norm)
        collapse_to_month = _needs_monthly_collapse(freq_code, target='M')
        sql = _build_lagged_query_sql(date_expr, data_table, meta_table, where_clause, collapse_to_month)

        with self.db_manager.get_session() as session:
            result = session.execute(text(sql), params).fetchall()

        if not result:
            empty_df = pd.DataFrame(columns=[column_label])
            empty_df.index.name = 'date'
            return empty_df

        df = pd.DataFrame(result, columns=['date', column_label])
        df['date'] = pd.to_datetime(df['date'])
        return df.set_index('date')
    
    def search_series(self, query: str, **filters) -> pd.DataFrame:
        """
        Search series by ticker, field, or description.
        
        Args:
            query: Search query string
            **filters: Additional filter criteria
            
        Returns:
            DataFrame with matching series
        """
        # Get all metadata first
        df = self.session_manager.get_ts_metadata(**filters)
        
        if df.empty:
            return pd.DataFrame()
        
        # Filter by query string (case-insensitive)
        query_lower = query.lower()
        ticker_col = 'ticker' if 'ticker' in df.columns else 'tkr'
        field_col = 'field' if 'field' in df.columns else 'fld'
        mask = (
            df[ticker_col].str.lower().str.contains(query_lower, na=False) |
            df[field_col].str.lower().str.contains(query_lower, na=False)
        )
        
        # Add desname filter if column exists
        if 'desname' in df.columns:
            mask = mask | df['desname'].str.lower().str.contains(query_lower, na=False)
        
        matching_df = df[mask].copy()
        

        return matching_df
    
    def get_series_info(self, series_id: int) -> pd.DataFrame:
        """
        Get detailed information about a specific series.
        
        Args:
            series_id: Series ID to get information for
            
        Returns:
            DataFrame with series information (empty if not found)
        """
        df = self.session_manager.get_ts_metadata(id=series_id)
        return df
    
    def get_selector_list(self) -> List[str]:
        """
        List all available selectors.
        
        Returns:
            List of selector names
        """
        schema = self._get_schema()
        sql = f"""
            SELECT DISTINCT sel 
            FROM {schema}.TS_Selector 
            ORDER BY sel
        """
        result = self.session_manager.execute_sql(sql)
        return result['sel'].tolist() if not result.empty else []
    
    def _find_series_id_by_metadata(self, ticker: Optional[str], field: Optional[str],
                                   source: Optional[str], frequency: Optional[str]) -> Optional[int]:
        """Find series ID by metadata filters."""
        filters = {}
        if ticker:
            filters['ticker'] = ticker.upper()
        if field:
            filters['field'] = field.upper()
        if source:
            source = self._normalize_source(source)
            filters['source'] = self._get_source_code(source)
        if frequency:
            filters['frequency'] = frequency.upper()
        
        df = self.session_manager.get_ts_metadata(**filters)
        
        if df.empty:
            logger.warning(f"No series found matching criteria: {filters}")
            return None
        elif len(df) > 1:
            logger.warning(f"Multiple series found, using first: {df.iloc[0].id}")
        
        # Convert numpy.int64 to Python int for pyodbc compatibility
        series_id = df.iloc[0].id
        if hasattr(series_id, 'item'):
            return series_id.item()
        else:
            return int(series_id)
    
    def get_selector_series_info(self, selector_names: Union[str, List[str]]) -> pd.DataFrame:
        """
        Get series information for one or more selectors using TimeSeriesSelectorMetaPlus view.
        
        Args:
            selector_names: Single selector name or list of selector names
            
        Returns:
            DataFrame with series information including metadata and status
        """
        from masworks.MasDatabase.models import TimeSeriesSelectorMetaPlus
        from sqlalchemy import select
        
        # Normalize to list
        if isinstance(selector_names, str):
            selector_names = [selector_names]
        
        # Build SQLAlchemy query using TimeSeriesSelectorMetaPlus view (no joins needed)
        stmt = (
            select(TimeSeriesSelectorMetaPlus)
            .where(TimeSeriesSelectorMetaPlus.sel.in_(selector_names))
            .order_by(TimeSeriesSelectorMetaPlus.sel, TimeSeriesSelectorMetaPlus.grp, TimeSeriesSelectorMetaPlus.ord)
        )
        
        return self.session_manager.pd_read_sql(stmt)
    
    def get_available_selectors(self) -> List[str]:
        """
        Get list of available selector names from the database.
        
        Returns:
            List of selector names sorted alphabetically
        """
        from masworks.MasDatabase.models import TimeSeriesSelector
        from sqlalchemy import select, distinct
        
        stmt = select(distinct(TimeSeriesSelector.sel)).order_by(TimeSeriesSelector.sel)
        result_df = self.session_manager.pd_read_sql(stmt)
        return result_df['sel'].tolist() if not result_df.empty else []
    
    def _analyze_selector_frequencies(self, selector_info: pd.DataFrame) -> tuple[bool, str]:
        """
        Analyze frequency consistency in selector series.
        
        Args:
            selector_info: DataFrame with selector series information including 'frequency' column
            
        Returns:
            Tuple of (is_same_frequency, dominant_frequency)
        """
        if selector_info.empty:
            return True, 'unknown'
        
        frequencies = selector_info['frequency'].unique()
        is_same_frequency = len(frequencies) == 1
        dominant_frequency = frequencies[0] if is_same_frequency else 'mixed'
        
        return is_same_frequency, dominant_frequency
    
    def _build_selector_dataset(self, selector_info: pd.DataFrame, 
                               start_date: Optional[str], end_date: Optional[str],
                               return_as: Union[str, ReturnHandler] = "auto",
                               verbose: bool = False) -> Any:
        """Build dataset from selector series data.
        
        Args:
            selector_info: DataFrame with selector series information
            start_date: Optional start date filter
            end_date: Optional end date filter
            return_as: Return format specification
            verbose: If True, print progress information during data retrieval
            
        Returns:
            Data in the requested format
        """
        all_data = {}
        total_series = len(selector_info)
        
        for i, (_, row) in enumerate(selector_info.iterrows(), 1):
            if verbose:
                col_name = row['colname'] or f"{row['ticker']}_{row['field']}"
                print(f"  [{i:3d}/{total_series:3d}] Retrieving {col_name} (ID: {row['id']})...")
            
            series_data = self.get_series_data(
                series_id=row['id'],
                start_date=start_date,
                end_date=end_date
            )
            
            if not series_data.empty:
                col_name = row['colname'] or f"{row['ticker']}_{row['field']}"
                # For single series, get_ts_data returns DataFrame with date index and value column
                if 'value' in series_data.columns:
                    all_data[col_name] = series_data['value']
                else:
                    # If no 'value' column, use the first (and only) column
                    all_data[col_name] = series_data.iloc[:, 0]
                
                if verbose:
                    print(f"      ✓ Retrieved {len(series_data)} observations")
            else:
                if verbose:
                    print(f"      ⚠ No data found")
        
        if verbose:
            print(f"Completed: {len(all_data)}/{total_series} series retrieved successfully")
        
        if not all_data:
            return self._process_return_as({}, return_as)
        
        return self._process_return_as(all_data, return_as)
    
    def _build_selector_dataset_by_group(self, selector_info: pd.DataFrame, 
                                        start_date: Optional[str], end_date: Optional[str],
                                        return_as: str, verbose: bool = False) -> Dict[str, Any]:
        """Build dataset from selector series data organized by group.
        
        Args:
            selector_info: DataFrame with selector series information
            start_date: Optional start date filter
            end_date: Optional end date filter
            return_as: Return format specification 
            verbose: If True, print progress information during data retrieval
            
        Returns:
            Dictionary with group names as keys and data as values
        """        
        # Get groups
        groups = selector_info['grp'].unique()
        if verbose:
            print(f"Found {len(groups)} groups: {list(groups)}")
        
        # Process all groups using the same logic
        group_data = {}
        
        for group in groups:
            if verbose:
                print(f"\nProcessing Group: {group}")
            
            # Get series for this group
            group_series = selector_info[selector_info['grp'] == group]
            
            # Create column mapping for all formats
            col_mapping = {row['id']: row['colname'] or f"series_{row['id']}" 
                          for _, row in group_series.iterrows()}
            
            if verbose:
                print(f"  Retrieving {len(col_mapping)} series in single request...")
            
            # Handle different sub-formats
            if return_as in ["df", "dataframe"]:
                # DataFrame format - use get_ts_data with pivot for wide format
                all_data = self.session_manager.get_ts_data(
                    series_id=list(col_mapping.keys()),
                    start_date=start_date,
                    end_date=end_date
                )
                
                if all_data.empty:
                    logger.warning(f"No data found for group '{group}' in date range {start_date} to {end_date}")
                    continue
                
                # Pivot to wide format
                group_data_df = all_data.pivot(index='date', columns='id', values='value')
                group_data_df = group_data_df.rename(columns=col_mapping)                
                group_data[group] = group_data_df
                
            elif return_as == "dict":
                # Dict format - use get_series_data() with custom column names
                group_series_data = self.get_series_data(
                    series_id=col_mapping,
                    start_date=start_date,
                    end_date=end_date,
                    return_as='dict'
                )
                
                group_data[group] = group_series_data
                
            else:
                # Long format - return data without pivot + series info
                # Use get_ts_data for long format (id, date, value columns)
                all_data = self.session_manager.get_ts_data(
                    series_id=list(col_mapping.keys()),
                    start_date=start_date,
                    end_date=end_date
                )
                
                group_data[group] = {'data': all_data, 'info': group_series.copy()}
                
        
        
        return group_data
    
    def _process_return_as(self, all_data: Dict[str, pd.Series], 
                          return_as: Union[str, ReturnHandler]) -> Any:
        """
        Process the return_as parameter and return data in requested format.
        
        Args:
            all_data: Dictionary of series data
            return_as: Return format specification
            
        Returns:
            Data in the requested format
        """
        if callable(return_as):
            # Direct callable handler
            return return_as(all_data)
        
        # String-based handlers
        if return_as in ["dataframe", "df"]:
            if not all_data:
                return pd.DataFrame()
            result = pd.DataFrame(all_data)
            result.index.name = 'date'
            return result
        elif return_as in ["dict", "dictionary"]:
            return all_data
        else:
            valid_types = ["auto", "dataframe", "df", "dict", "dictionary"]
            raise ValueError(f"Invalid return_as: {return_as}. Must be callable or one of: {valid_types}")
    
    def _normalize_source(self, source: str) -> str:
        """Normalize source name and validate."""
        source = source.lower()
        if source in SOURCE_ALIASES:
            source = SOURCE_ALIASES[source]
        
        if source not in ['bloomberg', 'fred', 'datastream']:
            raise ValueError(f"Unknown data source: {source}")
        
        return source
    
    def _get_source_code(self, source: str) -> str:
        """
        Get source code for database storage.
        
        SOURCE_CODE_MAP is only for feed sources (BB, DS, FRED).
        Other sources are normalized to uppercase (up to column limit of 6 chars).
        """
        return SOURCE_CODE_MAP.get(source, source.upper()[:6])
    
    def get_meta_plus_data(self, series_ids: Optional[List[int]] = None, 
                          sources: Optional[List[str]] = None, 
                          tickers: Optional[List[str]] = None,
                          fields: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Get data from TS_MetaPlus view using SQLAlchemy model.
        
        This method queries the TS_MetaPlus database view which joins TS_Meta and TS_Status tables.
        
        Args:
            series_ids: List of series IDs to filter by (optional)
            sources: List of sources to filter by (e.g., ['BB', 'DS', 'FRED']) (optional)
            tickers: List of ticker symbols to filter by (optional)
            fields: List of fields to filter by (optional)
            
        Returns:
            DataFrame with columns from both TS_Meta and TS_Status tables
        """
        try:
            from .MasDatabase.models import TimeSeriesMetaPlus
            
            # Build optimized query using direct SQL
            stmt = select(TimeSeriesMetaPlus)
            
            # Apply filters using 'in_' for all filters
            if series_ids:
                stmt = stmt.where(TimeSeriesMetaPlus.id.in_(series_ids))
            
            if sources:
                stmt = stmt.where(TimeSeriesMetaPlus.source.in_(sources))
            
            if tickers:
                stmt = stmt.where(TimeSeriesMetaPlus.ticker.in_(tickers))
            
            if fields:
                stmt = stmt.where(TimeSeriesMetaPlus.field.in_(fields))
            
            # Execute query using optimized pandas wrapper
            result_df = self.session_manager.pd_read_sql(stmt)
            return result_df
                
        except Exception as e:
            logger.error(f"Failed to get TS_MetaPlus data: {e}")
            return pd.DataFrame()
    
    def get_meta_plus_by_selector(self, selector_name: str) -> pd.DataFrame:
        """
        Get TS_MetaPlus data for all series in a specific selector.
        
        Args:
            selector_name: Name of the selector
            
        Returns:
            DataFrame with metadata and status information for selector series
        """
        try:
            # First get the series IDs from the selector
            selector_info = self.get_selector_series_info(selector_name)
            
            if selector_info.empty:
                logger.warning(f"No series found in selector '{selector_name}'")
                return pd.DataFrame()
            
            series_ids = selector_info['id'].tolist()
            
            # Get the metadata plus data for these series
            return self.get_meta_plus_data(series_ids=series_ids)
            
        except Exception as e:
            logger.error(f"Failed to get TS_MetaPlus data for selector '{selector_name}': {e}")
            return pd.DataFrame()

    def gen_upsert_group(self, selector_names: Union[str, List[str]] = 'DCF', 
                        force_update: bool = False, 
                        update_filter: Optional[callable] = None) -> Generator[Dict[str, Any], None, None]:
        """
        Generator that yields selector series grouped by data source for bulk upsert operations.
        
        Args:
            selector_names: Name(s) of the selector(s) to use (string or list of strings)
            force_update: If True, include all series regardless of last update time
            update_filter: Optional callable that takes a pandas Series (with 'upd' column) 
                          and returns True/False to determine if series should be updated
                          
        Yields:
            Dictionary with 'tickers', 'series_ids', 'source', 'frequency', 'field', 'currency'
        """
        # Normalize selector_names to a list
        if isinstance(selector_names, str):
            selector_names = [selector_names]

        try:
            logger.info(f"🔍 Getting series from selector(s) '{', '.join(selector_names)}' grouped by source")
            
            # Get selector series information for all selectors at once
            selector_info = self.get_selector_series_info(selector_names)
            
            if selector_info.empty:
                logger.warning(f"❌ No series found in any of the selectors: {', '.join(selector_names)}")
                return
            
            # Count series per selector for logging
            for selector_name in selector_names:
                count = len(selector_info[selector_info['sel'] == selector_name])
                logger.info(f"📊 Found {count} series in selector '{selector_name}'")
            
            logger.info(f"📊 Total series across all selectors: {len(selector_info)}")
            
            # Apply update filtering if not forcing update
            if not force_update:
                if update_filter is not None:
                    # Use provided filter
                    mask = selector_info.apply(update_filter, axis=1)
                    selector_info = selector_info[mask]
                    logger.info(f"📊 After update filter: {len(selector_info)} series")
                else:
                    # Use default update filter (4pm threshold)
                    from .MasDatabase.utilities import create_update_filter
                    default_filter = create_update_filter()  # Uses 4pm threshold
                    mask = selector_info.apply(default_filter, axis=1)
                    selector_info = selector_info[mask]
                    logger.info(f"📊 After default update filter (4pm threshold): {len(selector_info)} series")
            else:
                logger.info("📊 Force update mode: including all series")
            
            # Keep only relevant columns and remove duplicates
            selector_info = selector_info[['id', 'ticker', 'source', 'field', 'frequency', 'currency']].drop_duplicates()
            
            # Group by source, field, frequency, and currency (keep '-' as is for grouping)
            for (source_code, field, frequency, currency), group_df in selector_info.groupby(['source', 'field', 'frequency', 'currency']):
                # Yield clean structure with tickers and series IDs
                group_data = {
                    'tickers': group_df['ticker'].tolist(),
                    'series_ids': group_df['id'].tolist(),
                    'source': source_code,
                    'frequency': frequency,
                    'field': field,
                    'currency': currency
                }
                
                logger.info(f"📋 {source_code} {field} {frequency} {currency}: {len(group_df)} tickers")
                
                yield group_data
                
        except Exception as e:
            logger.error(f"❌ Error getting selector series: {e}")
            return