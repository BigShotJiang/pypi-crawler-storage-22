#!/usr/bin/env python3
"""
Test script to reproduce and verify fix for versioned model relationship resolution.

This script tests creating multiple VersionedTimeSeriesAdmin instances concurrently
to verify that the module-level cache and relationship resolution work correctly.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from masworks.config import get_default_config
from masworks.versioned_time_series_admin import VersionedTimeSeriesAdmin
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_versioned_admin_creation():
    """Test creating VersionedTimeSeriesAdmin instances for version 'buf'."""
    config = get_default_config()
    
    logger.info("=" * 60)
    logger.info("Test 1: Create first admin instance for version 'buf'")
    logger.info("=" * 60)
    
    try:
        admin1 = VersionedTimeSeriesAdmin(config, version='buf', lazy_feeds=True)
        logger.info("✅ Admin 1 created successfully")
        
        # Try to get models to trigger relationship resolution
        models1 = admin1.get_models_for_version('buf')
        logger.info(f"✅ Models retrieved: {list(models1.keys())}")
        
    except Exception as e:
        logger.error(f"❌ Failed to create admin 1: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    logger.info("\n" + "=" * 60)
    logger.info("Test 2: Create second admin instance for version 'buf' (should reuse models)")
    logger.info("=" * 60)
    
    try:
        admin2 = VersionedTimeSeriesAdmin(config, version='buf', lazy_feeds=True)
        logger.info("✅ Admin 2 created successfully")
        
        # Try to get models
        models2 = admin2.get_models_for_version('buf')
        logger.info(f"✅ Models retrieved: {list(models2.keys())}")
        
        # Verify they're the same classes
        if models1['TimeSeriesMeta'] is models2['TimeSeriesMeta']:
            logger.info("✅ Models are reused (same class instances)")
        else:
            logger.warning("⚠️  Models are different instances (might be OK)")
        
    except Exception as e:
        logger.error(f"❌ Failed to create admin 2: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    logger.info("\n" + "=" * 60)
    logger.info("Test 3: Try to use admin to get metadata (triggers mapper usage)")
    logger.info("=" * 60)
    
    try:
        metadata = admin1.get_metadata(version='buf')
        logger.info(f"✅ Metadata query successful, got {len(metadata)} rows")
    except Exception as e:
        logger.error(f"❌ Failed to query metadata: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    logger.info("\n" + "=" * 60)
    logger.info("✅ All tests passed!")
    logger.info("=" * 60)
    return True

if __name__ == "__main__":
    success = test_versioned_admin_creation()
    sys.exit(0 if success else 1)

