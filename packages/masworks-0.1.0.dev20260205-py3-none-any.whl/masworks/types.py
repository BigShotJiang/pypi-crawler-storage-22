"""
Type definitions for MasWorks library.
"""
from typing import Union, Literal
from datetime import datetime
import pandas as pd

# General date input (accepts anything)
DateInput = Union[str, datetime, pd.Timestamp, None]

# Specific input types for different contexts
DateString = Union[str, None]  # For functions that only want strings
DateObject = Union[datetime, pd.Timestamp, None]  # For functions that only want objects

# Output types
DateOutput = Union[str, datetime, pd.Timestamp, None]
DateFormat = Union[str, type, Literal['auto']]

# Export for use throughout the package
__all__ = ['DateInput', 'DateString', 'DateObject', 'DateOutput', 'DateFormat']
