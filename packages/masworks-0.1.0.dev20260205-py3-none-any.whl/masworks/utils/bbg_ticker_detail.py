"""
Ticker detail utilities for Bloomberg data.

This module provides functions to get Bloomberg's ticker detail information
for use in Meta table entries, ensuring consistency and proper ticker normalization.
"""

import logging
import requests
from typing import Dict, Any, Optional, List
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

logger = logging.getLogger(__name__)


class BbgTickerDetail:
    """
    Helper class for getting Bloomberg ticker detail information.
    
    This class provides methods to retrieve ticker detail information from
    the Bridge API's ticker_detail endpoint, which returns Bloomberg's normalized
    ticker format along with additional metadata like FIGI IDs.
    
    Features:
    - Single cache loaded from database on first access
    - Automatic fallback to Bridge API for missing tickers
    - 20-day TTL for cache entries
    - Automatic database insertion for new valid tickers
    - Ticker normalization (trim spaces, uppercase) for consistency
    - Session-level performance optimization
    """
    
    def __init__(self, bridge_config=None, db_manager=None, bridge_feed=None):
        """
        Initialize the ticker detail helper.
        
        Args:
            bridge_config: Bridge configuration object with server information (optional if bridge_feed provided)
            db_manager: Database manager object (optional)
            bridge_feed: BridgeFeed instance (optional, preferred over bridge_config)
        """
        if bridge_feed:
            # Use BridgeFeed if provided (preferred)
            self.bridge_feed = bridge_feed
            self.db_manager = bridge_feed.db_manager
        else:
            # Construct BridgeFeed from bridge_config
            if bridge_config is None:
                from masworks.config import get_default_config
                config = get_default_config()
                bridge_config = config.bridge
            
            if db_manager is None:
                from masworks.config import get_default_config
                config = get_default_config()
                from ..MasDatabase.base import DatabaseManager
                db_manager = DatabaseManager(config.database)
            
            # Create BridgeFeed from config
            from ..feeds.bridge import BridgeFeed
            self.bridge_feed = BridgeFeed(bridge_config, db_manager)
            self.db_manager = db_manager
        
        self._ticker_detail_cache = {}  # Cache for ticker detail lookups (loaded from database)
        self._cache_loaded = False  # Flag to track if database cache is loaded
    
    def _load_database_to_cache(self) -> None:
        """
        Load all ticker details from BbgTickerDetail table into _ticker_detail_cache.
        This provides fast lookup without database queries for subsequent calls.
        """
        if self._cache_loaded or not self.db_manager:
            return
        
        try:
            from ..MasDatabase.models import BbgTickerDetail as BbgTickerDetailModel
            
            # Use db_manager to get session
            session = self.db_manager.get_session()
            
            try:
                # Load all records from BbgTickerDetail table
                records = session.query(BbgTickerDetailModel).all()
                
                for record in records:
                    # Cache simplified data: only canonical_ticker and id_bb_global
                    simplified_data = {
                        'canonical_ticker': record.canonical_ticker,
                        'id_bb_global': record.id_bb_global
                    }
                    
                    # Cache in _ticker_detail_cache with timestamp (20-day TTL)
                    # Use normalized ticker for cache key
                    normalized_ticker = record.ticker.strip().upper()
                    self._ticker_detail_cache[normalized_ticker] = {
                        'data': simplified_data,
                        'timestamp': datetime.now()
                    }
                
                self._cache_loaded = True
                logger.info(f"Loaded {len(records)} ticker details from database into cache")
                
            finally:
                session.close()
                
        except Exception as e:
            logger.warning(f"Failed to load database cache: {e}")
            self._cache_loaded = True  # Mark as loaded to avoid repeated attempts
    
    def _insert_ticker_to_database(self, ticker: str, ticker_detail: Dict[str, Any]) -> None:
        """
        Insert new ticker detail into BbgTickerDetail database table.
        
        Args:
            ticker: Original ticker (normalized)
            ticker_detail: Ticker detail data from API
        """
        try:
            from ..MasDatabase.models import BbgTickerDetail as BbgTickerDetailModel
            import getpass
            import os
            
            # Get current user for audit trail
            try:
                created_by = getpass.getuser()
            except Exception:
                try:
                    created_by = os.getlogin()
                except Exception:
                    created_by = 'system'
            
            # Use db_manager to get session
            session = self.db_manager.get_session()
            
            try:
                # Check if ticker already exists in database (ticker is already normalized)
                existing = session.query(BbgTickerDetailModel).filter(
                    BbgTickerDetailModel.ticker == ticker
                ).first()
                
                if not existing:
                    # Create new record (ticker is already normalized)
                    # Strip extra spaces from canonical ticker before inserting
                    canonical_ticker = ticker_detail.get('canonical_ticker')
                    if canonical_ticker:
                        canonical_ticker = canonical_ticker.strip()
                    
                    new_record = BbgTickerDetailModel(
                        ticker=ticker,
                        canonical_ticker=canonical_ticker,
                        ticker_symbol=ticker_detail.get('ticker_symbol'),
                        id_bb_global=ticker_detail.get('id_bb_global'),
                        exchange_code=ticker_detail.get('exchange_code'),
                        primary_exchange=ticker_detail.get('primary_exchange'),
                        currency=ticker_detail.get('currency'),
                        description=ticker_detail.get('description'),
                        created_by=created_by
                    )
                    
                    session.add(new_record)
                    session.commit()
                    
                    logger.info(f"Inserted new ticker '{ticker}' into BbgTickerDetail database")
                else:
                    logger.debug(f"Ticker '{ticker}' already exists in database")
                    
            finally:
                session.close()
                
        except Exception as e:
            logger.warning(f"Failed to insert ticker '{ticker}' into database: {e}")
    
    def get_ticker_detail(self, ticker: str, use_cache: bool = True) -> Optional[Dict[str, Any]]:
        """
        Get ticker detail information for a single ticker.
        
        Args:
            ticker: Bloomberg ticker (e.g., 'SPY US Equity', 'AAPL')
            use_cache: Whether to use cached results
            
        Returns:
            Dictionary with ticker detail information or None if failed
        """
        # Normalize ticker: trim spaces and convert to uppercase
        normalized_ticker = ticker.strip().upper()
        
        # Load database cache if not loaded yet
        if use_cache and not self._cache_loaded and self.db_manager:
            self._load_database_to_cache()
        
        # Check cache first (using normalized ticker)
        if use_cache and normalized_ticker in self._ticker_detail_cache:
            cached_result = self._ticker_detail_cache[normalized_ticker]
            # Check if cache is still valid (cache for 20 days)
            if (datetime.now() - cached_result['timestamp']).days < 20:
                logger.debug(f"Using cached ticker detail info for '{normalized_ticker}'")
                return cached_result['data']
        
        # Get ticker detail info from Bridge API (use original ticker for API call)
        ticker_detail_info = self._fetch_ticker_detail([ticker])
        
        if ticker_detail_info and len(ticker_detail_info) > 0:
            result = ticker_detail_info[0]
        else:
            # API call failed or returned no data - cache None result to avoid repeated API calls
            result = None
            
        # Cache the result (including None for failed API calls) using normalized ticker
        if use_cache:
            self._ticker_detail_cache[normalized_ticker] = {
                'data': result,
                'timestamp': datetime.now()
            }
            
            # Insert new ticker into database if we have a valid result (use normalized ticker)
            if result and self.db_manager:
                self._insert_ticker_to_database(normalized_ticker, result)
        
        return result
    
    def get_canonical_ticker(self, ticker: str, use_cache: bool = True) -> Optional[str]:
        """
        Get the canonical ticker for a Bloomberg ticker.
        
        Args:
            ticker: Bloomberg ticker (e.g., 'SPY US Equity', 'AAPL')
            use_cache: Whether to use cached results
            
        Returns:
            Canonical ticker string or None if failed
        """
        # Normalize ticker: trim spaces and convert to uppercase
        normalized_ticker = ticker.strip().upper()
        
        # Load database cache if not loaded yet
        if use_cache and not self._cache_loaded and self.db_manager:
            self._load_database_to_cache()
        
        # Check cache first (using normalized ticker)
        if use_cache and normalized_ticker in self._ticker_detail_cache:
            cached_result = self._ticker_detail_cache[normalized_ticker]
            # Check if cache is still valid (cache for 20 days)
            if (datetime.now() - cached_result['timestamp']).days < 20:
                logger.debug(f"Using cached canonical ticker for '{normalized_ticker}'")
                return cached_result['data'].get('canonical_ticker')
        
        # If not in cache, get from API and cache the result
        ticker_detail_info = self.get_ticker_detail(ticker, use_cache)
        if ticker_detail_info:
            return ticker_detail_info.get('canonical_ticker')
        return None
    
    def _fetch_ticker_detail(self, tickers: List[str]) -> Optional[List[Dict[str, Any]]]:
        """
        Fetch ticker detail information from Bridge API.
        
        Args:
            tickers: List of Bloomberg tickers
            
        Returns:
            List of ticker detail information dictionaries or None if failed
        """
        # Use BridgeFeed if available (preferred)
        if self.bridge_feed:
            try:
                # Use BridgeFeed's robust request handling
                payload = {"tickers": tickers}
                response = self.bridge_feed._make_request_auto("ticker_detail", payload)
                
                if response and isinstance(response, list):
                    logger.debug(f"Successfully fetched ticker detail info for {len(response)} tickers via BridgeFeed")
                    return response
                else:
                    logger.warning(f"BridgeFeed returned unexpected data format for tickers {tickers}: {response}")
                    return None
                    
            except Exception as e:
                logger.error(f"BridgeFeed ticker_detail request failed for tickers {tickers}: {e}")
                return None
        
        # This should not happen since we always create BridgeFeed
        logger.error("BridgeFeed not available - this should not happen")
        return None
    
    def clear_cache(self):
        """Clear the ticker detail cache."""
        self._ticker_detail_cache.clear()
        logger.debug("Ticker detail cache cleared")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            'cached_tickers': len(self._ticker_detail_cache),
            'cache_keys': list(self._ticker_detail_cache.keys())
        }


def normalize_bbg_tickers(tickers: List[str], bridge_config=None, db_manager=None, bridge_feed=None, created_by: str = None) -> List[str]:
    """
    Normalize Bloomberg tickers with database caching.
    
    For each ticker, if it exists in BbgTickerDetail table, return canonical ticker from database.
    If doesn't exist, fetch details from Bridge API and insert into database.
    
    Args:
        tickers: List of Bloomberg tickers to normalize (e.g., ['SPY US Equity', 'AAPL'])
        bridge_config: Bridge configuration object (optional, will use default if not provided)
        db_manager: Database manager object (optional, will use default if not provided)
        bridge_feed: BridgeFeed instance (optional, preferred over bridge_config)
        created_by: Username for audit trail (optional, defaults to current login ID)
        
    Returns:
        List of canonical tickers in the same order as input tickers:
        ['SPY EQUITY', 'AAPL EQUITY', ...]
    """
    try:
        # Import here to avoid circular imports
        from ..config import get_default_config
        from ..MasDatabase.models import BbgTickerDetail as BbgTickerDetailModel
        import getpass
        import os
        
        # Normalize input tickers: trim spaces and make uppercase
        normalized_tickers = [ticker.strip().upper() for ticker in tickers]
        
        # Get default configs if not provided
        if bridge_feed is None:
            if bridge_config is None or db_manager is None:
                config = get_default_config()
                if bridge_config is None:
                    bridge_config = config.bridge
                if db_manager is None:
                    from ..MasDatabase.base import DatabaseManager
                    db_manager = DatabaseManager(config.database)
        
        # Get current user if not provided
        if created_by is None:
            try:
                created_by = getpass.getuser()
            except Exception:
                try:
                    created_by = os.getlogin()
                except Exception:
                    created_by = 'system'
        
        # Create database engine and session
        # Use db_manager to get session
        session = db_manager.get_session()
        
        try:
            # Check which tickers exist in database
            existing_records = session.query(BbgTickerDetailModel).filter(
                BbgTickerDetailModel.ticker.in_(normalized_tickers)
            ).all()
            
            existing_tickers = {record.ticker: record.canonical_ticker for record in existing_records}
            missing_tickers = [ticker for ticker in normalized_tickers if ticker not in existing_tickers]
            
            # Initialize result dictionary with existing tickers
            ticker_results = existing_tickers.copy()
            
            # Fetch missing tickers from Bridge API
            if missing_tickers:
                logger.debug(f"Fetching {len(missing_tickers)} tickers from Bridge API: {missing_tickers}")
                helper = BbgTickerDetail(bridge_config=bridge_config, db_manager=db_manager, bridge_feed=bridge_feed)
                
                # Process each missing ticker individually to handle individual failures
                for ticker in missing_tickers:
                    try:
                        api_data_list = helper._fetch_ticker_detail([ticker])
                        
                        if api_data_list and len(api_data_list) > 0:
                            api_data = api_data_list[0]
                            canonical_ticker = api_data.get('canonical_ticker')
                            
                            if canonical_ticker:
                                # Strip extra spaces from canonical ticker before inserting
                                canonical_ticker = canonical_ticker.strip()
                                
                                # Insert new record into database
                                new_record = BbgTickerDetailModel(
                                    ticker=ticker,
                                    canonical_ticker=canonical_ticker,
                                    ticker_symbol=api_data.get('ticker_symbol'),
                                    id_bb_global=api_data.get('id_bb_global'),
                                    exchange_code=api_data.get('exchange_code'),
                                    primary_exchange=api_data.get('primary_exchange'),
                                    currency=api_data.get('currency'),
                                    description=api_data.get('description'),
                                    created_by=created_by
                                )
                                
                                session.add(new_record)
                                
                                logger.info(f"Inserted ticker '{ticker}' into BbgTickerDetail table")
                                
                                # Add to results
                                ticker_results[ticker] = canonical_ticker
                            else:
                                logger.error(f"No canonical ticker returned for '{ticker}' from Bridge API")
                                ticker_results[ticker] = None
                        else:
                            logger.error(f"No data returned for ticker '{ticker}' from Bridge API")
                            ticker_results[ticker] = None
                            
                    except Exception as ticker_error:
                        # Handle individual ticker failures (invalid ticker, etc.)
                        logger.error(f"Failed to fetch ticker detail for '{ticker}' from Bridge API: {ticker_error}")
                        ticker_results[ticker] = None
            
            # Commit all database changes
            session.commit()
            
            # Build final result list in input order
            final_canonical_tickers = [ticker_results.get(ticker) for ticker in normalized_tickers]
            
            return final_canonical_tickers
                
        finally:
            session.close()
            
    except Exception as e:
        logger.error(f"Error normalizing Bloomberg tickers {tickers}: {e}")
        # Return None for all tickers on error
        return [None] * len(normalized_tickers)


