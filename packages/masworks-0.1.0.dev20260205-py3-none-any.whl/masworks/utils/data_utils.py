"""
Data manipulation utilities.
"""
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Union
import itertools
from collections import OrderedDict


# Global configuration for missing values
class MissingValueConfig:
    """Global configuration for missing value patterns."""
    
    # Standard missing value patterns
    STANDARD = ['NA', 'NaN', 'None', 'null', 'NULL', '', ' ', 
               'n/a', 'N/A', '#N/A', '#NULL!', '#VALUE!', 'nan']
    
    # Data source specific patterns
    FRED_SPECIFIC = ['.']  # FRED uses '.' for missing values
    EXCEL_SPECIFIC = ['#DIV/0!', '#REF!', '#NAME?']
    DATABASE_SPECIFIC = ['<null>', 'nil']
    
    # Default global missing values (can be modified)
    _global_missing_values = STANDARD.copy()
    _global_extra_values = []
    
    @classmethod
    def set_global_missing_values(cls, missing_values: List[str]) -> None:
        """Set the global default missing values."""
        cls._global_missing_values = missing_values.copy()
    
    @classmethod
    def add_global_missing_values(cls, extra_values: List[str]) -> None:
        """Add additional missing values to global defaults."""
        cls._global_extra_values.extend(extra_values)
    
    @classmethod
    def reset_global_missing_values(cls) -> None:
        """Reset to standard missing values."""
        cls._global_missing_values = cls.STANDARD.copy()
        cls._global_extra_values = []
    
    @classmethod
    def get_global_missing_values(cls) -> List[str]:
        """Get current global missing values."""
        return cls._global_missing_values + cls._global_extra_values


def missing_value_profile(profile_name: str):
    """
    Decorator to set missing value profile for a function.
    
    This decorator sets the global missing value configuration temporarily
    for the duration of the function call.
    
    Args:
        profile_name: Name of the profile ('fred', 'excel', 'database', 'standard')
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Save current global state
            original_global = MissingValueConfig._global_missing_values.copy()
            original_extra = MissingValueConfig._global_extra_values.copy()
            
            try:
                # Get the appropriate profile
                if profile_name.lower() == 'fred':
                    extra_values = MissingValueConfig.FRED_SPECIFIC
                elif profile_name.lower() == 'excel':
                    extra_values = MissingValueConfig.EXCEL_SPECIFIC
                elif profile_name.lower() == 'database':
                    extra_values = MissingValueConfig.DATABASE_SPECIFIC
                else:
                    extra_values = []
                
                # Temporarily add profile-specific values to global config
                MissingValueConfig.add_global_missing_values(extra_values)
                
                # Call the function
                return func(*args, **kwargs)
                
            finally:
                # Restore original global state
                MissingValueConfig._global_missing_values = original_global
                MissingValueConfig._global_extra_values = original_extra
        
        return wrapper
    return decorator


def clean_missing_values(
    df: pd.DataFrame, 
    col: str, 
    missing_values: Optional[List[str]] = None,
    extra_missing_values: Optional[List[str]] = None,
    inplace: bool = True
) -> pd.DataFrame:
    """
    Clean missing value representations from a DataFrame column with flexible configuration.
    
    This function replaces various string representations of missing values 
    with pandas NA, making them suitable for numeric conversion.
    
    Args:
        df: Input DataFrame
        col: Column name to clean
        missing_values: Custom list of missing values. If None, uses global defaults.
        extra_missing_values: Additional missing values to append to the base list.
        inplace: Whether to modify DataFrame in place (default True)
        
    Returns:
        DataFrame with cleaned column (modified in place if inplace=True)
        
    Examples:
        >>> # Use global defaults
        >>> df = clean_missing_values(df, 'values')
        
        >>> # Add custom missing values
        >>> df = clean_missing_values(df, 'values', extra_missing_values=['.', 'missing'])
        
        >>> # Completely custom missing values
        >>> df = clean_missing_values(df, 'values', missing_values=['NA', 'NULL', ''])
        
        >>> # Use with decorator for FRED data
        >>> @missing_value_profile('fred')
        >>> def process_fred_data(df, col):
        ...     return clean_missing_values(df, col)
    """
    # Determine which missing values to use
    if missing_values is None:
        missing_values = MissingValueConfig.get_global_missing_values()
    else:
        missing_values = missing_values.copy()
    
    # Add extra missing values if specified
    if extra_missing_values:
        missing_values.extend(extra_missing_values)
    
    # Remove duplicates while preserving order
    missing_values = list(dict.fromkeys(missing_values))
    
    # Work on copy if not inplace
    if not inplace:
        df = df.copy()
    
    # Replace missing values
    df[col] = df[col].replace(missing_values, pd.NA)
    
    return df


def trim_na(series: pd.Series) -> pd.Series:
    """
    Remove leading and trailing NaN values from a series.
    
    Args:
        series: Input pandas Series
        
    Returns:
        Series with leading/trailing NaNs removed
    """
    return series.loc[series.first_valid_index():series.last_valid_index()]


def concat_dict(data_dict: Dict[str, pd.DataFrame], 
               filter_func: Optional[callable] = None) -> pd.DataFrame:
    """
    Concatenate dictionary of DataFrames with keys as column names.
    
    Args:
        data_dict: Dictionary mapping names to DataFrames
        filter_func: Optional function to apply to each DataFrame
        
    Returns:
        Concatenated DataFrame with dictionary keys as column names
    """
    if filter_func is None:
        df = pd.concat(data_dict.values(), axis=1)
    else:
        df = pd.concat([filter_func(x) for x in data_dict.values()], axis=1)
    
    df.columns = data_dict.keys()
    return df


def merge_list(*args: List) -> List:
    """
    Merge multiple lists removing duplicates while preserving order.
    
    Args:
        *args: Variable number of lists to merge
        
    Returns:
        Merged list with unique elements in order
    """
    return list(OrderedDict.fromkeys(itertools.chain.from_iterable(args)))


def merge_dict(dict_list: List[Dict]) -> Dict:
    """
    Merge a list of dictionaries into a single dictionary.
    
    Args:
        dict_list: List of dictionaries to merge
        
    Returns:
        Merged dictionary
    """
    result = {}
    for d in dict_list:
        result.update(d)
    return result


def rows_between(df: pd.DataFrame, date_range: Optional[List] = None) -> pd.DataFrame:
    """
    Filter DataFrame rows between two dates.
    
    Args:
        df: Input DataFrame with date index
        date_range: List with [start_date, end_date], or None for no filtering
        
    Returns:
        Filtered DataFrame
    """
    if date_range is None or len(date_range) != 2:
        return df
    
    return df.loc[(df.index >= date_range[0]) & (df.index <= date_range[1])]


def no_na_columns(df: pd.DataFrame) -> tuple:
    """
    Get columns and DataFrame without any NaN values.
    
    Args:
        df: Input DataFrame
        
    Returns:
        Tuple of (filtered_dataframe, column_names)
    """
    cols = df.columns[~df.isna().any()].tolist()
    return df.loc[:, cols], cols


def add_simple_lag(df: pd.DataFrame, cols: List[str], lags: List[int]) -> pd.DataFrame:
    """
    Add lagged versions of specified columns to DataFrame.
    
    Args:
        df: Input DataFrame (modified in place)
        cols: Column names to lag
        lags: List of lag periods
        
    Returns:
        DataFrame with added lag columns
    """
    for lag in lags:
        for col in cols:
            df.loc[:, f"{col}_L{lag}"] = df[col].shift(lag)
    
    return df


def grep(lst: List[str], pattern: str) -> List[str]:
    """
    Filter list of strings by regex pattern.
    
    Args:
        lst: List of strings to search
        pattern: Regex pattern to match
        
    Returns:
        List of matching strings
    """
    import re
    from itertools import compress
    
    def matches(x):
        return matcher.search(x) is not None
    
    matcher = re.compile(pattern)
    return list(compress(lst, map(matches, lst)))


def list_diff(list1: List, list2: List) -> List:
    """
    Get elements in list1 that are not in list2.
    
    Args:
        list1: First list
        list2: Second list
        
    Returns:
        List of elements in list1 but not in list2
    """
    return [x for x in list1 if x not in list2]


def winsorize_by_value(series: pd.Series, min_val: float, max_val: float) -> pd.Series:
    """
    Winsorize series by capping values at specified limits.
    
    Args:
        series: Input series
        min_val: Minimum value (values below this are set to min_val)
        max_val: Maximum value (values above this are set to max_val)
        
    Returns:
        Winsorized series
    """
    series = series.copy()
    series.loc[series < min_val] = min_val
    series.loc[series > max_val] = max_val
    return series


def has_mid_null(df: pd.DataFrame) -> List[str]:
    """
    Find columns that have null values in the middle (after trimming leading/trailing nulls).
    
    Args:
        df: Input DataFrame
        
    Returns:
        List of column names with mid-nulls
    """
    return [col for col in df.columns if not trim_na(df[col]).isnull().values.any()]


def sporadic(series: pd.Series, margin: int = 1) -> np.ndarray:
    """
    Find sporadic (isolated) non-null values in a series.
    
    Args:
        series: Input series
        margin: Margin for isolation check
        
    Returns:
        Array of indices for sporadic values
    """
    is_null = series.isnull()
    rolling_nulls = is_null.rolling(margin).sum()
    
    conditions = pd.concat([
        is_null, 
        rolling_nulls.shift(1), 
        rolling_nulls.shift(-margin)
    ], axis=1)
    
    # Non-null values surrounded by nulls
    sporadic_mask = (
        (~conditions.iloc[:, 0]) & 
        (conditions.iloc[:, 1] != 0) & 
        (conditions.iloc[:, 2] != 0)
    )
    
    return np.where(sporadic_mask)[0]


def zeros_ones(n: int, n_ones: int) -> np.ndarray:
    """
    Create array of zeros and ones with specified number of ones.
    
    Args:
        n: Total length of array
        n_ones: Number of ones to include
        
    Returns:
        Array with n_ones randomly placed ones and rest zeros
    """
    arr = np.zeros(n, dtype=int)
    arr[np.random.choice(range(n), n_ones, replace=False)] = 1
    return arr


class Dict(dict):
    """Enhanced dictionary with additional utility methods."""
    
    def drop(self, keys: List[str]) -> 'Dict':
        """Remove keys from dictionary (in place)."""
        for key in keys:
            self.pop(key, None)
        return self
    
    def update(self, other: dict) -> 'Dict':
        """Update dictionary and return self for chaining."""
        super().update(other)
        return self
    
    def mutate(self, **kwargs) -> 'Dict':
        """Create new dictionary with additional/updated keys."""
        return Dict({**self, **kwargs})
    
    def subset(self, keys: List[str]) -> 'Dict':
        """Get subset of dictionary with specified keys."""
        return Dict({k: self[k] for k in keys if k in self})
    
    def extract(self, keys: List[str], defaults: Optional[Dict] = None) -> 'Dict':
        """Extract keys with optional defaults."""
        defaults = defaults or {}
        result = {}
        
        for key in keys:
            if key in self:
                result[key] = self[key]
            elif key in defaults:
                result[key] = defaults[key]
        
        return Dict(result)
    
    def gets(self, keys: List[str], default_val: Any = None) -> 'Dict':
        """Get multiple keys with default value."""
        return Dict({k: self.get(k, default_val) for k in keys})
    
    def merge(self, dict_list: List[dict], inplace: bool = False) -> 'Dict':
        """Merge with list of dictionaries."""
        if inplace:
            for d in dict_list:
                self.update(d)
            return self
        else:
            result = Dict(self.copy())
            for d in dict_list:
                result.update(d)
            return result


class NamedSet:
    """Dictionary-like object with attribute access."""
    
    def __init__(self, **kwargs):
        object.__setattr__(self, '_data', kwargs)
    
    def __getattribute__(self, item):
        if item.startswith('_'):
            return object.__getattribute__(self, item)
        data = object.__getattribute__(self, '_data')
        return data.get(item)
    
    def __call__(self):
        return object.__getattribute__(self, '_data')
    
    def __repr__(self):
        return object.__getattribute__(self, '_data').__repr__()
    
    def __iter__(self):
        data = object.__getattribute__(self, '_data')
        for k, v in data.items():
            yield k, v
    
    def __len__(self):
        return len(object.__getattribute__(self, '_data'))
    
    def __getitem__(self, item):
        return object.__getattribute__(self, '_data').get(item)


def _process_timestamp_columns(
    df: pd.DataFrame,
    timestamp_columns: Optional[Union[List[str], str]]
) -> List[str]:
    """
    Process timestamp_columns argument and return list of column names to convert.
    
    Args:
        df: Input DataFrame
        timestamp_columns: Column specification:
            - List[str]: List of column names to convert
            - '*': Convert all columns
            - Pattern string: Regex pattern to match column names
            - None: Auto-detect (handled by caller)
        
    Returns:
        List of column names to convert
        
    Raises:
        ValueError: If timestamp_columns is an invalid string
    """
    import re
    
    if timestamp_columns == '*':
        # Convert all columns
        return list(df.columns)
    elif isinstance(timestamp_columns, str):
        # Check if it's a regex pattern
        try:
            # Test if it's a valid regex pattern
            pattern = re.compile(timestamp_columns)
            # Find columns matching the pattern
            matching_columns = [col for col in df.columns if pattern.search(col)]
            if not matching_columns:
                print(f"Warning: No columns found matching pattern '{timestamp_columns}'")
            return matching_columns
        except re.error as e:
            # Not a valid regex
            raise ValueError(f"Invalid timestamp_columns value: '{timestamp_columns}'. "
                            f"Must be a list of column names, '*', a regex pattern, or None.")
    else:
        # timestamp_columns is a list, use it as is
        return timestamp_columns


def _auto_detect_float_timestamps(df: pd.DataFrame, unit: str = 's') -> List[str]:
    """
    Auto-detect columns that look like float timestamps.
    
    Args:
        df: Input DataFrame
        unit: Unit of the timestamp ('s', 'ms', 'us')
        
    Returns:
        List of column names that look like timestamps
    """
    timestamp_columns = []
    for col in df.columns:
        if df[col].dtype in ['float64', 'float32', 'int64', 'int32']:
            # Check if values look like timestamps (Unix timestamp range)
            non_null_values = df[col].dropna()
            if len(non_null_values) > 0:
                # Unix timestamp range: 1970-01-01 to 2100-01-01
                min_timestamp = 0  # 1970-01-01
                max_timestamp = 4102444800  # 2100-01-01
                
                # For milliseconds, adjust the range
                if unit == 'ms':
                    min_timestamp *= 1000
                    max_timestamp *= 1000
                elif unit == 'us':
                    min_timestamp *= 1000000
                    max_timestamp *= 1000000
                
                # Check if values are in reasonable timestamp range
                if (non_null_values.min() >= min_timestamp and 
                    non_null_values.max() <= max_timestamp):
                    timestamp_columns.append(col)
    return timestamp_columns


def _auto_detect_datetime_columns(df: pd.DataFrame) -> List[str]:
    """
    Auto-detect columns that are datetime types.
    
    Args:
        df: Input DataFrame
        
    Returns:
        List of column names that are datetime types
    """
    timestamp_columns = []
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            timestamp_columns.append(col)
    return timestamp_columns


def convert_float_timestamps_to_datetime(
    df: pd.DataFrame, 
    timestamp_columns: Optional[Union[List[str], str]] = None,
    unit: str = 's',
    errors: str = 'coerce',
    inplace: bool = False
) -> pd.DataFrame:
    """
    Convert DataFrame columns containing timestamps as float to pd.Timestamp.
    
    This function is particularly useful for DataFrames retrieved from databases
    where timestamps are stored as Unix timestamps (float values) and need to be
    converted to proper datetime objects.
    
    Args:
        df: Input DataFrame
        timestamp_columns: Column specification:
            - List[str]: List of column names to convert
            - '*': Convert all columns
            - Pattern string: Regex pattern to match column names
            - None: Auto-detect columns that look like timestamps (default behavior)
        unit: Unit of the timestamp ('s' for seconds, 'ms' for milliseconds, 'us' for microseconds)
        errors: How to handle conversion errors ('coerce', 'raise', 'ignore')
        inplace: Whether to modify DataFrame in place (default False)
        
    Returns:
        DataFrame with converted timestamp columns
        
    Examples:
        >>> # Auto-detect and convert timestamp columns
        >>> df_converted = convert_float_timestamps_to_datetime(df)
        
        >>> # Convert specific columns
        >>> df_converted = convert_float_timestamps_to_datetime(
        ...     df, 
        ...     timestamp_columns=['date', 'created_at', 'updated_at']
        ... )
        
        >>> # Convert all columns
        >>> df_converted = convert_float_timestamps_to_datetime(df, timestamp_columns='*')
        
        >>> # Convert milliseconds timestamps
        >>> df_converted = convert_float_timestamps_to_datetime(
        ...     df, 
        ...     unit='ms'
        ... )
        
        >>> # Convert in place
        >>> convert_float_timestamps_to_datetime(df, inplace=True)
    """
    # Work on copy if not inplace
    if not inplace:
        df = df.copy()
    
    # Handle auto-detection directly
    if timestamp_columns is None:
        timestamp_columns = _auto_detect_float_timestamps(df, unit)
    else:
        timestamp_columns = _process_timestamp_columns(df, timestamp_columns)
    
    # Convert each timestamp column
    for col in timestamp_columns:
        if col in df.columns:
            try:
                # Convert float timestamps to datetime
                df[col] = pd.to_datetime(df[col], unit=unit, errors=errors)
            except Exception as e:
                print(f"Warning: Could not convert column '{col}' to datetime: {e}")
                continue
    
    return df


def convert_timestamp_columns_to_float(
    df: pd.DataFrame,
    timestamp_columns: Optional[Union[List[str], str]] = None,
    unit: str = 's',
    inplace: bool = False
) -> pd.DataFrame:
    """
    Convert DataFrame columns containing pd.Timestamp to float (Unix timestamps).
    
    This is the reverse operation of convert_float_timestamps_to_datetime.
    Useful for preparing data for database storage where timestamps are stored as float.
    
    Args:
        df: Input DataFrame
        timestamp_columns: Column specification:
            - List[str]: List of column names to convert
            - '*': Convert all columns
            - Pattern string: Regex pattern to match column names
            - None: Auto-detect datetime columns (default behavior)
        unit: Unit of the output timestamp ('s' for seconds, 'ms' for milliseconds, 'us' for microseconds)
        inplace: Whether to modify DataFrame in place (default False)
        
    Returns:
        DataFrame with converted timestamp columns as float
        
    Examples:
        >>> # Auto-detect and convert datetime columns
        >>> df_converted = convert_timestamp_columns_to_float(df)
        
        >>> # Convert specific columns to milliseconds
        >>> df_converted = convert_timestamp_columns_to_float(
        ...     df, 
        ...     timestamp_columns=['date', 'created_at'],
        ...     unit='ms'
        ... )
        
        >>> # Convert all columns
        >>> df_converted = convert_timestamp_columns_to_float(df, timestamp_columns='*')
    """
    # Work on copy if not inplace
    if not inplace:
        df = df.copy()
    
    # Handle auto-detection directly
    if timestamp_columns is None:
        timestamp_columns = _auto_detect_datetime_columns(df)
    else:
        timestamp_columns = _process_timestamp_columns(df, timestamp_columns)
    
    # Convert each timestamp column
    for col in timestamp_columns:
        if col in df.columns and pd.api.types.is_datetime64_any_dtype(df[col]):
            try:
                # Convert datetime to Unix timestamp
                if unit == 's':
                    df[col] = df[col].astype('int64') // 10**9
                elif unit == 'ms':
                    df[col] = df[col].astype('int64') // 10**6
                elif unit == 'us':
                    df[col] = df[col].astype('int64') // 10**3
                else:
                    raise ValueError(f"Unsupported unit: {unit}")
            except Exception as e:
                print(f"Warning: Could not convert column '{col}' to float: {e}")
                continue
    
    return df


def clean_ts_dataframe(df: pd.DataFrame, date_format: str = None) -> pd.DataFrame:
    """
    Clean and standardize DataFrame output.
    
    Handles both numeric and timestamp data in the 'value' column:
    - If values are numeric: converts to float
    - If values are date strings: converts to Unix timestamps
    - Assumes no mixed types in the value column
    
    Args:
        df: DataFrame to clean
        date_format: Optional date format string (e.g., '%Y-%m-%d') to avoid format inference warnings
        
    Returns:
        Cleaned DataFrame
    """
    if df.empty:
        return df
        
    # Ensure date column is datetime
    if 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        #df = df.set_index('date')
    
    # Handle value column - determine if it's numeric or timestamp data
    if 'value' in df.columns:
        # Try to convert to numeric first
        numeric_values = pd.to_numeric(df['value'], errors='coerce')
        
        # Check if conversion was successful (not all NaN)
        if not numeric_values.isna().all():
            # Successfully converted to numeric
            df['value'] = numeric_values
        else:
            # Failed numeric conversion, try timestamp conversion
            try:
                # Convert date strings to Unix timestamps
                if date_format:
                    # Use provided format to avoid format inference warnings
                    df['value'] = pd.to_datetime(df['value'], format=date_format, errors='coerce')
                else:
                    # Try common date formats first to avoid format inference warnings
                    common_formats = [
                        '%Y-%m-%d',           # 2024-01-01
                        '%Y-%m-%d %H:%M:%S', # 2024-01-01 12:00:00
                        '%m/%d/%Y',          # 01/01/2024
                        '%Y-%m-%d %H:%M:%S.%f', # 2024-01-01 12:00:00.000000
                        '%d/%m/%Y',          # 01/01/2024
                    ]
                    
                    parsed = False
                    for fmt in common_formats:
                        try:
                            df['value'] = pd.to_datetime(df['value'], format=fmt, errors='coerce')
                            parsed = True
                            break
                        except (ValueError, TypeError):
                            continue
                    
                    # If no format worked, fall back to automatic parsing
                    if not parsed:
                        df['value'] = pd.to_datetime(df['value'], errors='coerce')
                
                df['value'] = df['value'].astype('int64') // 10**9  # Convert to Unix timestamp (seconds)
            except Exception:
                # If timestamp conversion fails, keep as string
                df['value'] = df['value'].astype(str)
    
    # Remove rows with null values
    df = df.dropna()
    
    # Sort by date
    #df = df.sort_index()
    
    return df