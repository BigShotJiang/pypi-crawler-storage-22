"""
Generic database connection management utilities.

Provides reusable SQLAlchemy connection management that can be used
across different projects and modules.
"""
import logging
from typing import Optional, List, Any, Iterator
from sqlalchemy import create_engine, Engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)


def chunks(seq: List[Any], size: int) -> Iterator[List[Any]]:
    """
    Yield successive chunks from a sequence.
    
    Args:
        seq: The sequence to chunk
        size: The size of each chunk
        
    Yields:
        List of items in each chunk
    """
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


class DatabaseManager:
    """
    Generic database connection manager for SQLAlchemy.
    
    Provides reusable database connection management that can be used
    across different projects and modules. This class is database-agnostic
    and works with any SQLAlchemy-supported database.
    """
    
    def __init__(self, config):
        """
        Initialize DatabaseManager.
        
        Args:
            config: Configuration object with database settings.
                   Must have get_sqlalchemy_url() method and server attribute.
        """
        self.config = config
        self._engine: Optional[Engine] = None
        self._session_factory: Optional[sessionmaker] = None
    
    @property
    def engine(self) -> Engine:
        """Get or create database engine."""
        if self._engine is None:
            self._engine = self._create_engine()
        return self._engine
    
    @property
    def session_factory(self) -> sessionmaker:
        """Get or create session factory."""
        if self._session_factory is None:
            self._session_factory = sessionmaker(bind=self.engine)
        return self._session_factory
    
    def _create_engine(self) -> Engine:
        """Create SQLAlchemy engine with proper configuration."""
        url = self.config.get_sqlalchemy_url()
        
        engine_kwargs = {
            "fast_executemany": True,
            "echo": False,  # Set to True for SQL debugging
            "pool_pre_ping": True,  # Verify connections before use
            "pool_recycle": 3600,   # Recycle connections after 1 hour
        }
        
        logger.info(f"Creating database engine for server: {self.config.server}")
        return create_engine(url, **engine_kwargs)
    
    def test_connection(self) -> bool:
        """Test database connection."""
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text("SELECT 1")).scalar()
                return result == 1
        except SQLAlchemyError as e:
            logger.error(f"Database connection test failed: {e}")
            return False
    
    def get_session(self) -> Session:
        """Create a new database session."""
        return self.session_factory()
    
    def execute_sql(self, sql: str, params: Optional[dict] = None) -> any:
        """Execute raw SQL and return results."""
        with self.engine.connect() as conn:
            if params:
                result = conn.execute(text(sql), params)
            else:
                result = conn.execute(text(sql))
            # Don't commit for SELECT queries - this causes HY010 error
            # conn.commit()  # Only needed for INSERT/UPDATE/DELETE
            return result
    
    def create_tables(self, models_module=None):
        """
        Create all database tables if they don't exist.
        
        Args:
            models_module: Optional module containing SQLAlchemy models.
                          If None, will attempt to import from MasDatabase.models
        """
        try:
            if models_module is None:
                # Import MasWorks models
                from ..MasDatabase.models import Base
            else:
                # Use provided models module
                Base = models_module.Base
            
            logger.info("Creating database tables...")
            Base.metadata.create_all(self.engine)
            logger.info("Database tables created successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create database tables: {e}")
            return False
    
    def create_tables_if_not_exist(self, models_module=None):
        """
        Create database tables only if they don't already exist.
        
        Args:
            models_module: Optional module containing SQLAlchemy models.
                          If None, will attempt to import from MasDatabase.models
        """
        try:
            if models_module is None:
                # Import MasWorks models
                from ..MasDatabase.models import Base
            else:
                # Use provided models module
                Base = models_module.Base
            
            # Check if tables exist by trying to query one of them
            with self.engine.connect() as conn:
                try:
                    # Get schema from config
                    schema = self.config.schema
                    # Try to query the TS_Meta table to see if it exists
                    conn.execute(text(f"SELECT TOP 1 * FROM {schema}.TS_Meta"))
                    logger.info("Database tables already exist, skipping creation")
                    return True
                except SQLAlchemyError:
                    # Table doesn't exist, create all tables
                    logger.info("Database tables not found, creating them...")
                    Base.metadata.create_all(self.engine)
                    logger.info("Database tables created successfully")
                    return True
                    
        except Exception as e:
            logger.error(f"Failed to create database tables: {e}")
            return False
    
    
    def close(self):
        """Close database connections."""
        if self._engine:
            self._engine.dispose()
            self._engine = None
            self._session_factory = None
