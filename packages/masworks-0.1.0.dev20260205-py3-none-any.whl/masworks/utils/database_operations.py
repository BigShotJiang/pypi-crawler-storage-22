#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comprehensive database operations manager for MasWorks.

This module provides a DatabaseOperationsManager class for performing various
database operations including upserts, table management, and data manipulation.
Based on patterns from old/Db.py and optimized for SQLAlchemy engine usage.
"""

from typing import List, Tuple, Optional, Union, Dict, Any
import logging
import pandas as pd
import numpy as np
from datetime import datetime
from sqlalchemy import Engine, text
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)


class DatabaseOperationsManager:
    """
    Comprehensive manager for database operations with accurate row counting.
    
    This class provides methods for performing various database operations including
    upserts, table management, data insertion, and query execution using SQLAlchemy Engine.
    Based on patterns from old/Db.py and optimized for modern usage.
    
    Note: Some methods overlap with standard Pandas/SQLAlchemy functionality:
    - execute_query() -> pd.read_sql() (wrapper for convenience)
    - fetch_value() -> conn.scalar() (wrapper for convenience)
    - fetch_all() -> conn.execute().fetchall() (wrapper for convenience)
    
    Custom implementations are used for:
    - insert_dataframe() -> Custom SQL Server optimized type mapping
    - create_table_from_dataframe() -> Custom SQL Server optimized type mapping
    
    These custom implementations provide optimized SQL Server type mapping and string length calculation.
    """
    
    def __init__(self, engine: Engine, schema: Optional[str] = None):
        """
        Initialize the DatabaseOperationsManager.
        
        Args:
            engine: SQLAlchemy engine instance
            schema: Optional schema name (e.g., 'dev', 'prod')
        """
        self.engine = engine
        self.schema = schema
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
    
    def _get_table_name(self, table: str) -> str:
        """
        Get fully qualified table name with schema if specified.
        
        Args:
            table: Table name
            
        Returns:
            str: Fully qualified table name
        """
        if self.schema and '.' not in table:
            return f"{self.schema}.{table}"
        return table
    
    def _get_column_type(self, dtype: str, max_length: int = None) -> str:
        """
        Get SQL Server column type from pandas dtype.
        
        Args:
            dtype: Pandas data type
            max_length: Maximum length for string columns
            
        Returns:
            str: SQL Server column type
        """
        if dtype == 'object':
            length = max_length + 1 if max_length else 255
            return f'NVARCHAR({length})'
        elif dtype == 'float64':
            return 'FLOAT'
        elif dtype == 'int64':
            return 'INT'
        elif dtype == 'datetime64[ns]':
            return 'DATETIME2'
        elif dtype == 'bool':
            return 'BIT'
        else:
            return 'NVARCHAR(MAX)'
    
    # =============================================================================
    # UPSERT OPERATIONS (UNIQUE VALUE - No standard alternatives)
    # =============================================================================
    
    def generate_upsert_sql(self, src_table: str, tgt_table: str, 
                           keys: List[str], values: List[str]) -> str:
        """
        Generate SQL statement for upsert operation with accurate row counting.
        
        Args:
            src_table: Source table name (e.g., temp table)
            tgt_table: Target table name (e.g., main data table)
            keys: List of key column names for matching records
            values: List of value column names to update/insert
            
        Returns:
            str: Complete SQL statement for upsert operation
        """
        # Get fully qualified table names
        src_table = self._get_table_name(src_table)
        tgt_table = self._get_table_name(tgt_table)
        
        # Build ON clause for matching records
        on_stmt = ' AND '.join([f't.{k} = s.{k}' for k in keys])
        
        # Build UPDATE SET clause
        up_stmt = ','.join([f't.{v} = s.{v}' for v in values])
        
        # Build column list for INSERT
        cols = ','.join(keys + values)
        
        # Build WHERE clause for INSERT (records that don't exist)
        where_stmt = ' AND '.join([f't.{k} = s.{k}' for k in keys])
        
        sql = f"""
        SET NOCOUNT ON;
        DECLARE @rows_updated INT = 0;
        DECLARE @rows_inserted INT = 0;
        
        -- Update existing rows
        UPDATE t SET {up_stmt} 
        FROM {tgt_table} t 
        INNER JOIN {src_table} s ON {on_stmt};
        SELECT @rows_updated = @@ROWCOUNT;
        
        -- Insert new rows
        INSERT INTO {tgt_table} ({cols}) 
        SELECT {cols} 
        FROM {src_table} s 
        WHERE NOT EXISTS (
            SELECT * FROM {tgt_table} t 
            WHERE {where_stmt}
        );
        SELECT @rows_inserted = @@ROWCOUNT;
        
        -- Return the counts
        SELECT @rows_updated AS rows_updated, @rows_inserted AS rows_inserted;
        """
        
        return sql.strip()
    
    def upsert_table(self, src_table: str, tgt_table: str, keys: List[str], 
                    values: List[str]) -> Tuple[int, int]:
        """
        Perform upsert operation with accurate row counting.
        
        Args:
            src_table: Source table name (e.g., temp table)
            tgt_table: Target table name (e.g., main data table)
            keys: List of key column names for matching records
            values: List of value column names to update/insert
            
        Returns:
            Tuple[int, int]: (rows_updated, rows_inserted)
            
        Raises:
            SQLAlchemyError: If SQL execution fails
        """
        try:
            # Generate the SQL statement
            sql = self.generate_upsert_sql(src_table, tgt_table, keys, values)
            
            # Execute the SQL statement
            with self.engine.connect() as conn:
                result = conn.execute(text(sql))
                
                # Get the row counts from the result
                count_row = result.fetchone()
                if count_row:
                    rows_updated = count_row[0] if count_row[0] is not None else 0
                    rows_inserted = count_row[1] if count_row[1] is not None else 0
                else:
                    raise SQLAlchemyError("No result returned from upsert SQL")
                
                # Commit the transaction
                conn.commit()
                
                self.logger.info(f"Upsert completed: {rows_updated} rows updated, {rows_inserted} rows inserted")
                
                return (rows_updated, rows_inserted)
                
        except SQLAlchemyError as e:
            self.logger.error(f"Upsert operation failed: {e}")
            raise
    
    def upsert_dataframe(self, df: pd.DataFrame, tgt_table: str, keys: List[str], 
                        values: List[str], temp_table: str = None) -> Tuple[int, int]:
        """
        Upsert data from a DataFrame with accurate row counting.
        
        Args:
            df: DataFrame containing data to upsert
            tgt_table: Target table name
            keys: List of key column names for matching records
            values: List of value column names to update/insert
            temp_table: Optional temp table name (auto-generated if None)
            
        Returns:
            Tuple[int, int]: (rows_updated, rows_inserted)
        """
        if df.empty:
            return (0, 0)
        
        # Generate temp table name if not provided
        if temp_table is None:
            import time
            import random
            timestamp = int(time.time() * 1000) % 10000
            random_suffix = random.randint(10, 99)
            temp_table = f"#tmp_{timestamp}_{random_suffix}"
        
        try:
            # Create temp table and insert data
            self._create_temp_table_from_df(df, temp_table, keys + values)
            
            # Perform upsert
            return self.upsert_table(temp_table, tgt_table, keys, values)
            
        finally:
            # Clean up temp table
            self._cleanup_temp_table(temp_table)
    
    # =============================================================================
    # TABLE MANAGEMENT OPERATIONS (CONVENIENCE WRAPPERS)
    # =============================================================================
    
    def drop_table(self, table: str, confirm: bool = False) -> bool:
        """
        Safely drop a table with optional confirmation.
        
        Args:
            table: Table name to drop
            confirm: If True, requires confirmation for non-temp tables
            
        Returns:
            bool: True if table was dropped, False if it didn't exist
        """
        try:
            # Check if it's a temp table (starts with #)
            if not table.startswith('#') and confirm:
                # For non-temp tables, we would normally ask for confirmation
                # In this implementation, we'll log a warning
                self.logger.warning(f"Dropping non-temp table: {table}")
            
            with self.engine.connect() as conn:
                conn.execute(text(f"DROP TABLE {self._get_table_name(table)}"))
                conn.commit()
                self.logger.info(f"Table {table} dropped successfully")
                return True
                
        except SQLAlchemyError as e:
            if "doesn't exist" in str(e).lower() or "not found" in str(e).lower():
                self.logger.info(f"Table {table} doesn't exist, nothing to drop")
                return False
            else:
                self.logger.error(f"Failed to drop table {table}: {e}")
                raise
    
    def create_table_from_dataframe(self, df: pd.DataFrame, table_name: str, 
                                   drop_if_exists: bool = True) -> bool:
        """
        Create a table from DataFrame structure and insert data.
        
        Note: Uses custom implementation for optimized SQL Server type mapping.
        Alternative: df.to_sql(table_name, engine, if_exists='replace', index=False, schema=schema)
        
        Args:
            df: DataFrame to create table from
            table_name: Name of table to create
            drop_if_exists: If True, drop table if it exists
            
        Returns:
            bool: True if table was created successfully
        """
        try:
            # Drop table if it exists and requested
            if drop_if_exists:
                self.drop_table(table_name, confirm=False)
            
            # Generate column definitions with optimized types
            column_defs = []
            for col, dtype in df.dtypes.items():
                if dtype == 'object':
                    # Calculate max length for string columns
                    max_len = df[col].astype(str).str.len().max()
                    sql_type = self._get_column_type(str(dtype), max_len)
                else:
                    sql_type = self._get_column_type(str(dtype))
                
                column_defs.append(f"{col} {sql_type}")
            
            # Create table
            create_sql = f"""
            CREATE TABLE {self._get_table_name(table_name)} (
                {', '.join(column_defs)}
            )
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(create_sql))
                conn.commit()
                
                # Insert data
                self.insert_dataframe(df, table_name)
                
                self.logger.info(f"Table {table_name} created successfully with {len(df)} rows")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to create table {table_name}: {e}")
            raise
    
    def truncate_table(self, table: str) -> bool:
        """
        Truncate a table (remove all data but keep structure).
        
        Args:
            table: Table name to truncate
            
        Returns:
            bool: True if table was truncated successfully
        """
        try:
            with self.engine.connect() as conn:
                conn.execute(text(f"TRUNCATE TABLE {self._get_table_name(table)}"))
                conn.commit()
                self.logger.info(f"Table {table} truncated successfully")
                return True
                
        except SQLAlchemyError as e:
            self.logger.error(f"Failed to truncate table {table}: {e}")
            raise
    
    # =============================================================================
    # DATA INSERTION OPERATIONS (OVERLAP WITH PANDAS)
    # =============================================================================
    
    def insert_dataframe(self, df: pd.DataFrame, table: str, columns: List[str] = None) -> int:
        """
        Insert DataFrame data into a table.
        
        Note: Uses custom implementation for optimized SQL Server type mapping.
        Alternative: df.to_sql(table, engine, if_exists='append', index=False, schema=schema)
        
        Args:
            df: DataFrame containing data to insert
            table: Target table name
            columns: List of columns to insert (uses all columns if None)
            
        Returns:
            int: Number of rows inserted
        """
        if df.empty:
            return 0
        
        # Use specified columns or all columns
        if columns is None:
            columns = df.columns.tolist()
        else:
            df = df[columns]
        
        try:
            # Prepare data for insertion
            data_to_insert = df.where(pd.notnull(df), None).values.tolist()
            
            # Generate INSERT statement
            placeholders = ', '.join([':' + col for col in columns])
            insert_sql = f"INSERT INTO {self._get_table_name(table)} ({', '.join(columns)}) VALUES ({placeholders})"
            
            with self.engine.connect() as conn:
                # Execute in chunks for large datasets
                chunk_size = 1000
                total_inserted = 0
                
                for i in range(0, len(data_to_insert), chunk_size):
                    chunk = data_to_insert[i:i + chunk_size]
                    chunk_data = [dict(zip(columns, row)) for row in chunk]
                    conn.execute(text(insert_sql), chunk_data)
                    total_inserted += len(chunk)
                
                conn.commit()
                self.logger.info(f"Inserted {total_inserted} rows into {table}")
                return total_inserted
                
        except Exception as e:
            self.logger.error(f"Failed to insert data into {table}: {e}")
            raise
    
    def _create_temp_table_from_df(self, df: pd.DataFrame, temp_table: str, columns: List[str]):
        """
        Create temporary table from DataFrame and insert data.
        
        Args:
            df: DataFrame containing data
            temp_table: Name of temporary table to create
            columns: List of column names to include
        """
        # Ensure we have the required columns
        if not all(col in df.columns for col in columns):
            missing_cols = [col for col in columns if col not in df.columns]
            raise ValueError(f"DataFrame missing required columns: {missing_cols}")
        
        # Select only the required columns
        df_clean = df[columns].copy()
        
        # Create temp table structure
        column_defs = []
        for col in columns:
            if df_clean[col].dtype == 'object':
                max_len = df_clean[col].astype(str).str.len().max()
                sql_type = self._get_column_type('object', max_len)
            else:
                sql_type = self._get_column_type(str(df_clean[col].dtype))
            column_defs.append(f"{col} {sql_type}")
        
        create_sql = f"""
        CREATE TABLE {self._get_table_name(temp_table)} (
            {', '.join(column_defs)}
        )
        """
        
        with self.engine.connect() as conn:
            # Create temp table
            conn.execute(text(create_sql))
            
            # Insert data
            self.insert_dataframe(df_clean, temp_table, columns)
            conn.commit()
    
    def _cleanup_temp_table(self, temp_table: str):
        """
        Clean up temporary table.
        
        Args:
            temp_table: Name of temporary table to drop
        """
        try:
            self.drop_table(temp_table, confirm=False)
        except Exception as e:
            self.logger.warning(f"Failed to cleanup temp table {temp_table}: {e}")
    
    # =============================================================================
    # QUERY OPERATIONS (OVERLAP WITH PANDAS/SQLALCHEMY)
    # =============================================================================
    
    def execute_query(self, sql: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """
        Execute a SQL query and return results as DataFrame.
        
        Note: This is a wrapper over pd.read_sql() for convenience.
        
        Args:
            sql: SQL query to execute
            params: Optional parameters for the query
            
        Returns:
            pd.DataFrame: Query results
        """
        try:
            # Use pandas read_sql for better performance and functionality
            df = pd.read_sql(sql, self.engine, params=params)
            self.logger.info(f"Query executed successfully, returned {len(df)} rows")
            return df
                
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}")
            raise
    
    def fetch_value(self, sql: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        Execute a SQL query and return a single value.
        
        Note: This is a wrapper over conn.scalar() for convenience.
        
        Args:
            sql: SQL query to execute
            params: Optional parameters for the query
            
        Returns:
            Any: Single value from query result
        """
        try:
            with self.engine.connect() as conn:
                # Use SQLAlchemy scalar for better performance
                if params:
                    return conn.scalar(text(sql), params)
                else:
                    return conn.scalar(text(sql))
                
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}")
            raise
    
    def fetch_all(self, sql: str, params: Optional[Dict[str, Any]] = None) -> List[Tuple]:
        """
        Execute a SQL query and return all results as list of tuples.
        
        Note: This is a wrapper over conn.execute().fetchall() for convenience.
        
        Args:
            sql: SQL query to execute
            params: Optional parameters for the query
            
        Returns:
            List[Tuple]: Query results as list of tuples
        """
        try:
            with self.engine.connect() as conn:
                # Use SQLAlchemy execute for better performance
                if params:
                    result = conn.execute(text(sql), params)
                else:
                    result = conn.execute(text(sql))
                
                return result.fetchall()
                
        except Exception as e:
            self.logger.error(f"Query execution failed: {e}")
            raise
    
    # =============================================================================
    # UTILITY METHODS
    # =============================================================================
    
    def remove_duplicates(self, table: str, keys: List[str], orderby: List[str] = None) -> bool:
        """
        Remove duplicates from a table using ROW_NUMBER().
        
        Args:
            table: Table name to remove duplicates from
            keys: List of columns to use for duplicate detection
            orderby: List of columns to use for ordering (uses first key if None)
            
        Returns:
            bool: True if duplicates were removed successfully
        """
        try:
            k = ','.join(keys)
            if not orderby:
                orderby = [keys[0]]
            orderby = ','.join(orderby)
            
            remove_sql = f"""
            WITH cte(rn) AS (
                SELECT ROW_NUMBER() OVER (PARTITION BY {k} ORDER BY {orderby}) 
                FROM {self._get_table_name(table)}
            ) 
            DELETE FROM cte WHERE rn > 1
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(remove_sql))
                conn.commit()
                
                self.logger.info(f"Removed duplicates from {table}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to remove duplicates from {table}: {e}")
            raise
    
    def create_optimized_table(self, table_name: str, df: pd.DataFrame = None, 
                              dtype: Dict[str, str] = None) -> bool:
        """
        Create table with optimized column types and length calculation.
        
        Args:
            table_name: Name of table to create
            df: DataFrame to infer types from (optional)
            dtype: Dictionary of column types (optional)
            
        Returns:
            bool: True if table was created successfully
        """
        try:
            if df is not None:
                dtype = df.dtypes.to_dict()
            elif dtype is None:
                raise ValueError("Either df or dtype must be provided")
            
            # Generate optimized column definitions
            column_defs = []
            for col, col_type in dtype.items():
                if col_type == 'object':
                    if df is not None:
                        # Calculate optimal length (rounded up to nearest 8)
                        max_len = df[col].astype(str).str.len().max()
                        optimal_len = int(((max_len + 2) // 8) * 8)
                        sql_type = f'NVARCHAR({optimal_len}) COLLATE SQL_Latin1_General_CP1_CS_AS'
                    else:
                        sql_type = 'NVARCHAR(255)'
                elif col_type == 'float64':
                    sql_type = 'FLOAT'
                elif col_type == 'int64':
                    sql_type = 'INT'
                elif col_type == 'datetime64[ns]':
                    sql_type = 'DATETIME2'
                elif col_type == 'bool':
                    sql_type = 'BIT'
                elif col_type.startswith('varchar') or col_type in ('real', 'float', 'date', 'datetime2'):
                    sql_type = col_type
                else:
                    sql_type = 'NVARCHAR(MAX)'
                
                column_defs.append(f"{col} {sql_type}")
            
            # Create table
            create_sql = f"""
            CREATE TABLE {self._get_table_name(table_name)} (
                {', '.join(column_defs)}
            )
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(create_sql))
                conn.commit()
                
                self.logger.info(f"Created optimized table {table_name}")
                return True
                
        except Exception as e:
            self.logger.error(f"Failed to create optimized table {table_name}: {e}")
            raise
    
    def generate_merge_sql(self, target_table: str, source_table: str, 
                          keys: List[str], values: List[str], 
                          not_in_source: str = None, main_key: str = None) -> str:
        """
        Generate advanced MERGE statement with full SQL Server functionality.
        
        Args:
            target_table: Target table name
            source_table: Source table name
            keys: List of key columns for matching
            values: List of value columns to update
            not_in_source: Action when not matched by source (optional)
            main_key: Main key for not_in_source condition (optional)
            
        Returns:
            str: MERGE SQL statement
        """
        # Build ON clause
        on_stmt = ' AND '.join([f't.{k} = s.{k}' for k in keys])
        
        # Build UPDATE clause
        upd_stmt = ', '.join([f't.{v} = s.{v}' for v in values])
        
        # Build column lists
        vals_nms = ', '.join(keys + values)
        vals_src = ', '.join([f's.{v}' for v in keys + values])
        
        # Build test statement for conditional update
        test_stmt = ' AND '.join([f't.{v} <> s.{v}' for v in values])
        
        # Build not_in_source clause if provided
        not_in_src_stmt = ''
        if not_in_source and len(not_in_source) > 0:
            if main_key is None:
                main_key = keys[0]
            cond = f't.{main_key} IN (SELECT {main_key} FROM s)'
            not_in_src_stmt = f' WHEN NOT MATCHED BY SOURCE AND ({cond}) THEN {not_in_source}'
        
        # Build complete MERGE statement
        merge_sql = f"""
        MERGE INTO {self._get_table_name(target_table)} AS t
        USING {self._get_table_name(source_table)} AS s
        ON {on_stmt}
        WHEN NOT MATCHED BY TARGET THEN
            INSERT ({vals_nms}) VALUES ({vals_src})
        WHEN MATCHED AND ({test_stmt}) THEN
            UPDATE SET {upd_stmt}{not_in_src_stmt};
        """
        
        return merge_sql.strip()
    
    def format_sql_values(self, values: List[Any], add_parentheses: bool = True) -> str:
        """
        Format list of values for SQL statements.
        
        Args:
            values: List of values to format
            add_parentheses: Whether to add parentheses around the values
            
        Returns:
            str: Formatted values string
        """
        def convert_value(val):
            if isinstance(val, str):
                return f"'{val}'"
            elif val is None:
                return 'NULL'
            else:
                return str(val)
        
        formatted_values = ', '.join([convert_value(v) for v in values])
        
        if add_parentheses:
            return f'({formatted_values})'
        else:
            return formatted_values
    
    def build_insert_statement(self, table: str, columns: List[str], 
                              use_placeholders: bool = True) -> str:
        """
        Build INSERT statement with column names and placeholders.
        
        Args:
            table: Target table name
            columns: List of column names
            use_placeholders: Whether to use placeholders (?) or named parameters (:col)
            
        Returns:
            str: INSERT SQL statement
        """
        cols_str = ', '.join(columns)
        
        if use_placeholders:
            placeholders = ', '.join(['?' for _ in columns])
        else:
            placeholders = ', '.join([f':{col}' for col in columns])
        
        return f"INSERT INTO {self._get_table_name(table)} ({cols_str}) VALUES ({placeholders})"
    
    def create_temp_table(self, temp_table: str, source: str = None, 
                         columns: List[str] = None, df: pd.DataFrame = None) -> str:
        """
        Create temporary table from source or DataFrame.
        
        Args:
            temp_table: Name of temporary table (must start with #)
            source: Source table/query (optional)
            columns: List of columns to select (optional)
            df: DataFrame to create table from (optional)
            
        Returns:
            str: SQL statement for creating temporary table
        """
        if not temp_table.startswith('#'):
            raise ValueError("Temporary table name must start with #")
        
        if df is not None:
            # Create table from DataFrame
            return self.create_optimized_table(temp_table, df=df)
        elif source:
            # Create table from source
            cols_str = ', '.join(columns) if columns else '*'
            return f"SELECT {cols_str} INTO {temp_table} FROM {source} WHERE 1=0"
        else:
            raise ValueError("Either source or df must be provided")
    
    def format_result(self, rows_updated: int, rows_inserted: int) -> str:
        """
        Format upsert result for logging or display.
        
        Args:
            rows_updated: Number of rows updated
            rows_inserted: Number of rows inserted
            
        Returns:
            str: Formatted result string
        """
        return f"{rows_updated} row(s) updated, {rows_inserted} row(s) inserted"
    
    
    def test_connection(self) -> bool:
        """
        Test database connection.
        
        Returns:
            bool: True if connection is successful
        """
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
                self.logger.info("Database connection test successful")
                return True
        except Exception as e:
            self.logger.error(f"Database connection test failed: {e}")
            return False
