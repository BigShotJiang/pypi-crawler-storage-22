"""
Date utility functions for MasWorks library.
"""
from typing import Union, Literal
from datetime import datetime
import pandas as pd
from masworks.types import DateInput, DateOutput, DateFormat


def normalize_date_input(
    date_input: DateInput,
    date_format: DateFormat = '%Y-%m-%d'
) -> DateOutput:
    """
    Convert various date inputs to specified format.
    
    Args:
        date_input: Date as string, datetime, pd.Timestamp, or None
        date_format: Either a string format (e.g., '%Y-%m-%d') or a type (datetime, pd.Timestamp) or 'auto'
        
    Returns:
        Date in specified format or None
        
    Examples:
        >>> normalize_date_input('2023-01-01', '%Y-%m-%d')
        '2023-01-01'
        >>> normalize_date_input('20230101', '%Y%m%d')
        '20230101'
        >>> normalize_date_input('2023-01-01', datetime)
        datetime(2023, 1, 1)
        >>> normalize_date_input('2023-01-01', pd.Timestamp)
        Timestamp('2023-01-01 00:00:00')
        >>> normalize_date_input('2023-01-01', 'auto')  # Returns same type as input
        '2023-01-01'
    """
    if date_input is None:
        return None
    
    # Convert to pandas Timestamp first (handles all input types)
    if isinstance(date_input, str):
        # Handle various string formats
        if len(date_input) == 8 and date_input.isdigit():  # YYYYMMDD
            date_input = f"{date_input[:4]}-{date_input[4:6]}-{date_input[6:8]}"
        elif len(date_input) == 10 and '-' in date_input:  # YYYY-MM-DD
            pass  # Already in correct format
        else:
            # Try pandas parsing for other formats
            date_input = pd.to_datetime(date_input)
    
    # Convert to pandas Timestamp for consistent processing
    if not isinstance(date_input, pd.Timestamp):
        timestamp = pd.to_datetime(date_input)
    else:
        timestamp = date_input
    
    # Return in requested format
    if date_format == datetime:
        return timestamp.to_pydatetime()
    elif date_format == pd.Timestamp:
        return timestamp
    elif date_format == 'auto':
        # Return in same type as input
        if isinstance(date_input, str):
            return timestamp.strftime('%Y-%m-%d')
        elif isinstance(date_input, datetime):
            return timestamp.to_pydatetime()
        elif isinstance(date_input, pd.Timestamp):
            return timestamp
        else:
            return timestamp.strftime('%Y-%m-%d')  # Default to string
    else:
        # Treat as string format
        return timestamp.strftime(date_format)


# Convenience functions for common use cases
def to_date_string(date_input: DateInput, fmt: str = '%Y-%m-%d') -> Union[str, None]:
    """Convert to date string with specified format."""
    return normalize_date_input(date_input, fmt)


def to_datetime(date_input: DateInput) -> Union[datetime, None]:
    """Convert to Python datetime object."""
    return normalize_date_input(date_input, datetime)


def to_pandas_timestamp(date_input: DateInput) -> Union[pd.Timestamp, None]:
    """Convert to pandas Timestamp."""
    return normalize_date_input(date_input, pd.Timestamp)


def to_bloomberg_format(date_input: DateInput) -> Union[str, None]:
    """Convert to Bloomberg YYYYMMDD format."""
    return normalize_date_input(date_input, '%Y%m%d')


def to_fred_format(date_input: DateInput) -> Union[str, None]:
    """Convert to FRED YYYY-MM-DD format."""
    return normalize_date_input(date_input, '%Y-%m-%d')


def to_auto_format(date_input: DateInput) -> DateOutput:
    """Convert preserving input type."""
    return normalize_date_input(date_input, 'auto')
