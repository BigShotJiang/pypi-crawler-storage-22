"""
General utility functions.
"""
import os
import time
import pickle
from datetime import datetime
from typing import Any, List, Optional, Union
import pandas as pd
from dateutil.relativedelta import relativedelta


def cmd_confirm(question: str = "Confirm? [Y/N] ") -> bool:
    """
    Ask user for confirmation via command line.
    
    Args:
        question: Question to ask user
        
    Returns:
        True if user confirms, False otherwise
    """
    answer = input(question).lower()
    return answer in ('y', 'yes')


def date_str_fmt(date_str: str, src_fmt: str = '%m/%d/%Y', 
                target_fmt: str = '%Y-%m-%d') -> str:
    """
    Convert date string from one format to another.
    
    Args:
        date_str: Input date string
        src_fmt: Source date format
        target_fmt: Target date format
        
    Returns:
        Formatted date string
    """
    return datetime.strftime(datetime.strptime(date_str, src_fmt), target_fmt)


def date_add(date_str: str, period: callable, n: int, 
            fmt: str = '%Y-%m-%d') -> str:
    """
    Add period to date string.
    
    Args:
        date_str: Input date string
        period: Period function (e.g., relativedelta)
        n: Number of periods to add
        fmt: Date format
        
    Returns:
        New date string
    """
    return (pd.to_datetime(date_str) + period(n)).strftime(fmt)


def as_list(obj: Any) -> List:
    """
    Convert object to list if it isn't already.
    
    Args:
        obj: Object to convert
        
    Returns:
        List containing the object or the object itself if already a list
    """
    if not isinstance(obj, list):
        return [obj]
    return obj


def len_safe(obj: Any) -> int:
    """
    Get length of object, returning 0 if None.
    
    Args:
        obj: Object to get length of
        
    Returns:
        Length of object or 0 if None
    """
    return 0 if obj is None else len(obj)


def shift_bit_length(x: int) -> int:
    """
    Get next power of 2 greater than or equal to x.
    
    Args:
        x: Input integer
        
    Returns:
        Next power of 2
    """
    return 1 << (x - 1).bit_length()


def peek_first(iterable):
    """
    Get first element from iterable.
    
    Args:
        iterable: Any iterable object
        
    Returns:
        First element
    """
    gen = iter(iterable)
    return next(gen)


def wait_for_file(filename: str, max_seconds: int = 100):
    """
    Wait for file to exist.
    
    Args:
        filename: Path to file
        max_seconds: Maximum time to wait
        
    Raises:
        Exception: If file doesn't exist after timeout
    """
    elapsed = 0
    while not os.path.exists(filename) and elapsed < max_seconds:
        time.sleep(1)
        elapsed += 1
    
    if not os.path.isfile(filename):
        raise Exception(f"{filename} isn't a file!")


def remove_file(file_path: str):
    """
    Remove file if it exists, ignoring errors.
    
    Args:
        file_path: Path to file to remove
    """
    import contextlib
    with contextlib.suppress(FileNotFoundError):
        os.remove(file_path)


def pickle_save(filename: str, **kwargs):
    """
    Save objects to pickle file.
    
    Args:
        filename: Output filename
        **kwargs: Objects to save (name=object pairs)
    """
    with open(filename, 'wb') as f:
        pickle.dump(kwargs, f)


def pickle_load(filename: str) -> dict:
    """
    Load objects from pickle file.
    
    Args:
        filename: Input filename
        
    Returns:
        Dictionary of loaded objects
    """
    with open(filename, 'rb') as f:
        return pickle.load(f)


def write_df(df: pd.DataFrame, excel_file: str, sheet_name: str = 'Sheet1'):
    """
    Write DataFrame to Excel file.
    
    Args:
        df: DataFrame to write
        excel_file: Output Excel filename
        sheet_name: Sheet name
    """
    with pd.ExcelWriter(excel_file) as writer:
        df.to_excel(writer, sheet_name)


def write_dfs(dataframes: List[pd.DataFrame], excel_file: str, 
             sheet_names: Optional[List[str]] = None):
    """
    Write multiple DataFrames to Excel file with different sheets.
    
    Args:
        dataframes: List of DataFrames to write
        excel_file: Output Excel filename
        sheet_names: List of sheet names (auto-generated if None)
    """
    n = len(dataframes)
    if sheet_names is None:
        sheet_names = [f'Sheet{i+1}' for i in range(n)]
    
    with pd.ExcelWriter(excel_file) as writer:
        for i in range(n):
            dataframes[i].to_excel(writer, sheet_names[i])


def if_null(series_a: pd.Series, series_b: pd.Series) -> List:
    """
    Replace null values in series_a with corresponding values from series_b.
    
    Args:
        series_a: Primary series
        series_b: Fallback series
        
    Returns:
        List with null values replaced
    """
    return [b if pd.isna(a) else a for a, b in zip(series_a, series_b)]


def if_not_null(series_a: pd.Series, series_b: pd.Series) -> List:
    """
    Use series_b values where series_a is not null, otherwise use series_a.
    
    Args:
        series_a: Condition series
        series_b: Value series
        
    Returns:
        List with conditional values
    """
    return [b if pd.notna(a) else a for a, b in zip(series_a, series_b)]


def if_else(condition: pd.Series, true_values: pd.Series, 
           false_values: pd.Series) -> List:
    """
    Vectorized if-else operation.
    
    Args:
        condition: Boolean condition series
        true_values: Values to use when condition is True
        false_values: Values to use when condition is False
        
    Returns:
        List with conditional values
    """
    return [t if c else f for c, t, f in zip(condition, true_values, false_values)]


def sub_dict(dictionary: dict, keys: List[str]) -> dict:
    """
    Get subset of dictionary with specified keys.
    
    Args:
        dictionary: Input dictionary
        keys: Keys to extract
        
    Returns:
        Dictionary subset
    """
    return {k: dictionary[k] for k in keys if k in dictionary}


def get_dict(dictionary: dict, keys: List[str], 
            default_val: Any = None) -> dict:
    """
    Get dictionary values for keys with default fallback.
    
    Args:
        dictionary: Input dictionary
        keys: Keys to get
        default_val: Default value for missing keys
        
    Returns:
        Dictionary with requested keys
    """
    return {k: dictionary.get(k, default_val) for k in keys}


def str_dict(dictionary: dict) -> str:
    """
    Convert dictionary to compact string representation.
    
    Args:
        dictionary: Input dictionary
        
    Returns:
        Compact string representation
    """
    import json
    return json.dumps(dictionary).replace('"', '').replace(' ', '')


class AlgoDecorator:
    """Decorator for machine learning algorithms with default parameters."""
    
    def __init__(self, algorithm_class, **default_kwargs):
        self.algorithm_class = algorithm_class
        self.default_kwargs = default_kwargs
    
    def __call__(self):
        return self.algorithm_class(**self.default_kwargs)
    
    @classmethod
    def create(cls, algorithm_class, **kwargs):
        """Create decorator for algorithm class."""
        if hasattr(algorithm_class, '__name__'):
            if algorithm_class.__name__ in ['RandomForestRegressor', 'LGBMRegressor', 'XGBRegressor']:
                return cls(algorithm_class, **kwargs)
        return None


# Global variable storage
_global_vars = {}


def set_global_var(name: str, value: Any):
    """
    Set global variable.
    
    Args:
        name: Variable name
        value: Variable value
    """
    global _global_vars
    _global_vars[name] = value


def get_global_var(name: str) -> Any:
    """
    Get global variable.
    
    Args:
        name: Variable name
        
    Returns:
        Variable value
        
    Raises:
        KeyError: If variable doesn't exist
    """
    global _global_vars
    return _global_vars[name]


def clear_global_vars():
    """Clear all global variables."""
    global _global_vars
    _global_vars.clear()
