"""
Model utility functions for SQLAlchemy operations.
"""

from typing import List, Any, Union
from sqlalchemy.inspection import inspect as sa_inspect


def records_to_dicts(records: List[Any], keys: Union[List[str], tuple] = None) -> List[dict]:
    """
    Convert SQLAlchemy model records to list of dictionaries.
    
    Args:
        records: List of SQLAlchemy model instances
        keys: Optional tuple or list of attribute names to extract.
              If None, will automatically detect all column attributes.
        
    Returns:
        List of dictionaries with the specified keys
    """
    if not records:
        return []
    
    # If no keys specified, get all column attributes from the first record
    if keys is None:
        keys = [c.key for c in sa_inspect(records[0]).mapper.column_attrs]
    
    return [{k: getattr(r, k) for k in keys} for r in records]


def get_model_keys(model_class):
    """
    Get all column attribute keys from a SQLAlchemy model class.
    
    Args:
        model_class: SQLAlchemy model class
        
    Returns:
        List of column attribute keys
    """
    return [c.key for c in sa_inspect(model_class).mapper.column_attrs]
