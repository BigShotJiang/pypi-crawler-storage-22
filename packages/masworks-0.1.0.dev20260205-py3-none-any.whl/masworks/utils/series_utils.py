"""
Shared utility functions for series key parsing and source normalization.

This module provides utilities used by both tsdata-api and tsdata-worker
for parsing API series keys and normalizing data source names.
"""
from typing import Optional, Tuple

from masworks.constants import SOURCE_ALIASES, SUPPORTED_SOURCES, SOURCE_CODE_MAP


def normalize_source_to_code(source: str) -> str:
    """
    Normalize source name to database code format (uppercase).
    
    Returns uppercase codes that match database storage format:
    - 'bridge', 'bloomberg', or 'bb' -> 'BB'
    - 'datastream' or 'ds' -> 'DS'
    - 'fred' -> 'FRED'
    - 'mdl' -> 'MDL'
    - Other sources converted to uppercase (up to 6 chars)
    
    This matches the format stored in TS_Meta.source column.
    
    Args:
        source: Source name (case-insensitive)
        
    Returns:
        Normalized source code in uppercase (database format)
    """
    source_lower = source.lower()
    if source_lower in ['bridge', 'bloomberg', 'bb']:
        return 'BB'
    elif source_lower in ['datastream', 'ds']:
        return 'DS'
    elif source_lower == 'fred':
        return 'FRED'
    elif source_lower == 'mdl':
        return 'MDL'
    # For other sources, convert to uppercase (up to 6 chars to match database column)
    return source_lower.upper()[:6]


def normalize_source_to_name(source: str) -> str:
    """
    Normalize source name to full name format (for masworks internal use).
    
    Returns full names used internally by masworks:
    - 'bb' or 'bloomberg' -> 'bloomberg'
    - 'ds' or 'datastream' -> 'datastream'
    - 'fred' -> 'fred'
    - Validates against SUPPORTED_SOURCES
    
    Args:
        source: Source name (case-insensitive)
        
    Returns:
        Normalized source name (full format)
        
    Raises:
        ValueError: If source is not in SUPPORTED_SOURCES
    """
    source = source.lower()
    if source in SOURCE_ALIASES:
        source = SOURCE_ALIASES[source]
    
    if source not in SUPPORTED_SOURCES:
        raise ValueError(f"Unknown data source: {source}")
    
    return source


def parse_series_api_key(series_key: str) -> Tuple[str, str, Optional[str], Optional[str], Optional[str]]:
    """
    Parse API series_key format into components.
    
    Parses the API-specific series_key format used by REST endpoints:
    Format: "source::ticker::field::frequency::currency"
    - Use '::' as separator (since tickers might contain ':')
    - Use '-' for empty field, frequency, or currency
    - Field cannot be empty for 'bb' source
    
    Args:
        series_key: Series key in format "source::ticker::field::frequency::currency"
        
    Returns:
        tuple: (source, ticker, field, frequency, currency)
        - source: Normalized source code (lowercase, e.g., 'bb', 'ds', 'fred')
        - ticker: Ticker symbol
        - field: Field name (None if '-' or missing)
        - frequency: Frequency code (None if '-' or missing)
        - currency: Currency code (None if '-' or missing)
        
    Raises:
        ValueError: If series_key format is invalid or required fields are missing
    """
    parts = series_key.split('::')
    
    # Ensure we have at least source and ticker
    if len(parts) < 2:
        raise ValueError(
            f"Invalid series_key format. Expected 'source::ticker::field::frequency::currency', "
            f"got: {series_key}"
        )
    
    # Parse parts - use None for missing or empty optional fields, or if explicitly set to '-'
    source = parts[0].strip().lower() if len(parts) > 0 and parts[0].strip() else None
    ticker = parts[1].strip() if len(parts) > 1 and parts[1].strip() else None
    field = parts[2].strip() if len(parts) > 2 and parts[2].strip() else None
    frequency = parts[3].strip() if len(parts) > 3 and parts[3].strip() else None
    currency = parts[4].strip() if len(parts) > 4 and parts[4].strip() else None
    
    # Convert '-' to None for optional fields
    if field == '-':
        field = None
    if frequency == '-':
        frequency = None
    if currency == '-':
        currency = None
    
    # Validate required fields
    if not source:
        raise ValueError("Source is required in series_key and cannot be empty")
    if not ticker:
        raise ValueError("Ticker is required in series_key and cannot be empty")
    
    # Validate field for 'bb' source (field cannot be None for bb)
    normalized_source = normalize_source_to_code(source)
    if normalized_source == 'BB' and not field:
        raise ValueError("Field cannot be empty for 'bb' (Bloomberg/Bridge) source")
    
    return source, ticker, field, frequency, currency

