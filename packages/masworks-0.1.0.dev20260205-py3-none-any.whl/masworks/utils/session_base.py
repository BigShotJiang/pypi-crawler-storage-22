"""
Generic database session management utilities.

Provides reusable SQLAlchemy session management that can be used
across different projects and modules.
"""
import logging
from contextlib import contextmanager
from typing import Generator, Optional, List, Dict, Any, Iterator
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import text
import pandas as pd

from .database_connection import DatabaseManager, chunks

logger = logging.getLogger(__name__)


class BaseSessionManager:
    """
    Generic base class for database session management.
    
    Provides reusable session management functionality that can be extended
    by domain-specific session managers. This class handles the core
    SQLAlchemy session operations and basic database utilities.
    """
    
    def __init__(self, db_manager: DatabaseManager, chunk_size: int = 5000):
        """
        Initialize BaseSessionManager.
        
        Args:
            db_manager: DatabaseManager instance
            chunk_size: Size of chunks for bulk operations
        """
        self.db_manager = db_manager
        self.chunk_size = chunk_size
    
    @contextmanager
    def get_session(self) -> Generator[Session, None, None]:
        """
        Context manager for database sessions with automatic cleanup.
        
        Yields:
            SQLAlchemy Session object
        """
        session = self.db_manager.get_session()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            session.close()
    
    def execute_sql(self, sql: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """
        Execute raw SQL and return results as DataFrame.
        
        Args:
            sql: SQL query string
            params: Optional parameters for the query
            
        Returns:
            DataFrame with query results
        """
        try:
            with self.db_manager.engine.connect() as conn:
                if params:
                    result = conn.execute(text(sql), params)
                else:
                    result = conn.execute(text(sql))
                
                # Convert to DataFrame
                df = pd.DataFrame(result.fetchall(), columns=result.keys())
                return df
        except SQLAlchemyError as e:
            logger.error(f"SQL execution error: {e}")
            raise
    
    def pd_read_sql(self, stmt, params: Optional[Dict[str, Any]] = None, 
                   parse_dates: Optional[List[str]] = None, 
                   index_col: Optional[str] = None) -> pd.DataFrame:
        """
        Execute SQL statement using pandas.read_sql for optimized performance.
        
        This method provides a consistent interface for direct SQL execution
        with pandas, offering better performance than ORM queries for read operations.
        
        Args:
            stmt: SQLAlchemy select statement or raw SQL string
            params: Optional parameters for the query
            parse_dates: List of column names to parse as dates
            index_col: Column name to use as index
            
        Returns:
            DataFrame with query results
        """
        try:
            with self.get_session() as session:
                conn = session.connection()
                
                # Use pandas.read_sql for optimized performance
                df = pd.read_sql(stmt, conn, params=params, 
                               parse_dates=parse_dates, index_col=index_col)
                
                return df
                
        except SQLAlchemyError as e:
            logger.error(f"Pandas SQL execution error: {e}")
            raise
    
    
    def execute_chunked_bulk_insert(self, conn, insert_sql: str, batch_data: List[Dict[str, Any]], 
                                  table_name: str = "table") -> int:
        """
        Execute chunked bulk insert for better performance and memory management.
        
        Args:
            conn: Database connection
            insert_sql: SQL insert statement with named parameters
            batch_data: List of dictionaries containing data to insert
            table_name: Name of table for logging purposes
            
        Returns:
            Total number of rows inserted
        """
        logger.info(f"Inserting {len(batch_data)} rows using chunked bulk insert (chunk_size={self.chunk_size})")
        
        total_inserted = 0
        for chunk in chunks(batch_data, self.chunk_size):
            conn.execute(text(insert_sql), chunk)
            total_inserted += len(chunk)
            logger.debug(f"Inserted chunk of {len(chunk)} rows into {table_name} (total: {total_inserted}/{len(batch_data)})")
        
        logger.debug(f"Successfully inserted {total_inserted} rows using chunked bulk insert")
        return total_inserted
    
    def create_temp_table(self, conn, temp_table: str, source_table: str, schema: str):
        """
        Create a temporary table with the same structure as the source table.
        
        Args:
            conn: Database connection
            temp_table: Name of temporary table to create
            source_table: Name of source table to copy structure from
            schema: Database schema name
        """
        # Drop temp table if exists
        conn.execute(text(f"IF OBJECT_ID('{temp_table}') IS NOT NULL DROP TABLE {temp_table}"))
        
        # Create temp table with same structure as source table
        conn.execute(text(f"""
            SELECT * 
            INTO {temp_table} 
            FROM {schema}.{source_table} 
            WHERE 1=0
        """))
    
    def close(self):
        """Close database connections."""
        if hasattr(self.db_manager, 'close'):
            self.db_manager.close()
