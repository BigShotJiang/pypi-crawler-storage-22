"""
Time series analysis utilities.
"""
import pandas as pd
import numpy as np
import math
from typing import Optional, List
from pandas.tseries.offsets import MonthEnd, QuarterEnd, Week
import statsmodels.api as sm
from dateutil.relativedelta import relativedelta


def last_of_months(ts: pd.Series) -> pd.Series:
    """
    Convert time series to month-end frequency, keeping last value of each month.
    
    Args:
        ts: Input time series
        
    Returns:
        Series with month-end dates
    """
    month_ends = pd.Series(ts.index + pd.offsets.MonthEnd(1))
    mask = month_ends != month_ends.shift(-1)
    
    result = ts[mask.values]
    result.index = result.index + pd.offsets.MonthEnd(1)
    
    return result


def last_of_quarters(ts: pd.Series) -> pd.Series:
    """
    Convert time series to quarter-end frequency, keeping last value of each quarter.
    
    Args:
        ts: Input time series
        
    Returns:
        Series with quarter-end dates
    """
    quarter_ends = pd.Series(ts.index + pd.offsets.QuarterEnd(1))
    mask = quarter_ends != quarter_ends.shift(-1)
    
    result = ts[mask.values]
    result.index = result.index + pd.offsets.QuarterEnd(1)
    
    return result


def to_period_end(dates: pd.DatetimeIndex, period: str) -> pd.DatetimeIndex:
    """
    Convert dates to period end dates.
    
    Args:
        dates: Input datetime index
        period: Period type ('Q' for quarter, 'M' for month, 'W' for week)
        
    Returns:
        DatetimeIndex with period end dates
    """
    if period == 'Q':
        return dates + pd.tseries.offsets.QuarterEnd(n=0)
    elif period == 'M':
        return dates + pd.tseries.offsets.MonthEnd(n=0)
    elif period == 'W':
        return dates + pd.tseries.offsets.Week(weekday=4)
    else:
        return dates


def index_to_rolling_vol(ts: pd.Series, vol_window: int = 20, 
                        return_window: int = 1) -> pd.Series:
    """
    Calculate rolling volatility from price index.
    
    Args:
        ts: Price time series
        vol_window: Window for volatility calculation
        return_window: Window for return calculation
        
    Returns:
        Rolling volatility series
    """
    ts_clean = ts.dropna()
    returns = (ts_clean / ts_clean.shift(return_window) - 1).dropna()
    return returns.rolling(vol_window).std().dropna()


def yield_to_rolling_vol(ts: pd.Series, vol_window: int = 20, 
                        diff_window: int = 1) -> pd.Series:
    """
    Calculate rolling volatility from yield series using differences.
    
    Args:
        ts: Yield time series
        vol_window: Window for volatility calculation
        diff_window: Window for difference calculation
        
    Returns:
        Rolling volatility series
    """
    ts_clean = ts.dropna()
    diffs = (ts_clean - ts_clean.shift(diff_window)).dropna()
    return diffs.rolling(vol_window).std().dropna()


def rolling_drawdown(ts: pd.Series, window: int) -> pd.Series:
    """
    Calculate rolling drawdown from peak.
    
    Args:
        ts: Price time series
        window: Rolling window size
        
    Returns:
        Rolling drawdown series
    """
    rolling_max = ts.rolling(window=window).max()
    return ts / rolling_max - 1


def rolling_zscore(ts: pd.Series, window: int, 
                  regression_model: Optional[callable] = None) -> pd.Series:
    """
    Calculate rolling z-score with optional detrending.
    
    Args:
        ts: Input time series
        window: Rolling window size
        regression_model: Optional regression model for detrending (default: RLM)
        
    Returns:
        Rolling z-score series
    """
    if regression_model is None:
        regression_model = sm.RLM
    
    # Trim NAs
    from .data_utils import trim_na
    s = trim_na(ts)
    
    # Create time trend
    t = np.linspace(0, 1, len(s))
    t_with_const = sm.add_constant(t)
    
    # Fit regression model
    model = regression_model(s, t_with_const)
    result = model.fit()
    
    # Calculate detrended series
    detrended = s - result.params.const - result.params.x1 * t
    
    # Calculate initial z-scores for first window
    initial_window = detrended.iloc[:window + 1]
    initial_zscore = initial_window / np.std(initial_window)
    
    # Calculate rolling z-scores
    rolling_mean = s.rolling(window=window).mean()
    rolling_std = s.rolling(window=window).std()
    z_scores = (s - rolling_mean) / rolling_std
    
    # Replace initial values with detrended z-scores
    z_scores.iloc[:window] = (
        initial_zscore.iloc[:window] + 
        z_scores.iloc[window] - 
        initial_zscore.iloc[window]
    )
    
    return z_scores


def resample_to_monthly(df: pd.DataFrame) -> pd.DataFrame:
    """
    Resample DataFrame to monthly frequency using last values.
    
    Args:
        df: Input DataFrame with datetime index
        
    Returns:
        Monthly resampled DataFrame
    """
    monthly = df.resample('ME').last()
    monthly.index = monthly.index + MonthEnd(0)
    return monthly


def rolling_windows(date_index: pd.DatetimeIndex, 
                   window_sizes: List[int] = [15, 20, 25]) -> List[List[pd.Timestamp]]:
    """
    Generate rolling windows for backtesting.
    
    Args:
        date_index: DatetimeIndex for the time series
        window_sizes: List of window sizes in years
        
    Returns:
        List of [start_date, end_date] pairs for each window
    """
    windows = []
    start_date = date_index[0]
    
    for window_size in window_sizes:
        # Generate quarterly start dates
        end_date = date_index[-1] + relativedelta(years=-window_size)
        start_dates = pd.date_range(start_date, end_date, freq='1Q')
        
        for start in start_dates:
            window_end = start + relativedelta(years=window_size)
            windows.append([start, window_end])
    
    return windows


class TimeSeriesTransformer:
    """Class for time series transformations and analysis."""
    
    def __init__(self, ts: pd.Series, frequency: Optional[str] = None):
        """
        Initialize with time series data.
        
        Args:
            ts: Input time series (Series or single-column DataFrame)
            frequency: Frequency of the data (inferred if None)
        """
        if isinstance(ts, pd.DataFrame):
            self.ts = ts.iloc[:, 0]
        else:
            self.ts = ts
            
        if frequency is None:
            self.frequency = pd.infer_freq(ts.index)
        else:
            self.frequency = frequency
    
    def crossover(self, ma_windows: List[int], output_name: Optional[str] = None) -> pd.Series:
        """
        Calculate moving average crossover indicator.
        
        Args:
            ma_windows: List of two moving average windows [short, long]
            output_name: Name for output series
            
        Returns:
            Crossover indicator series
        """
        if len(ma_windows) != 2:
            raise ValueError("ma_windows must contain exactly 2 values")
        
        short_ma = self.ts.rolling(window=ma_windows[0]).mean()
        long_ma = self.ts.rolling(window=ma_windows[1]).mean()
        
        crossover = (short_ma - long_ma) / long_ma
        
        if output_name:
            crossover.name = output_name
        
        return crossover
    
    def frequency_convert(self, target_freq: str, window: int = 1, 
                         agg_method: str = 'mean', 
                         output_name: Optional[str] = None) -> pd.Series:
        """
        Convert time series frequency.
        
        Args:
            target_freq: Target frequency ('M', 'Q', etc.)
            window: Rolling window size for aggregation
            agg_method: Aggregation method ('mean', 'last', etc.)
            output_name: Name for output series
            
        Returns:
            Frequency-converted series
        """
        # Apply rolling aggregation if window > 1
        if window > 1:
            if agg_method == 'mean':
                ts = self.ts.rolling(window=window).mean()
            elif agg_method == 'last':
                ts = self.ts.rolling(window=window).apply(lambda x: x.iloc[-1])
            else:
                raise ValueError(f"Unsupported aggregation method: {agg_method}")
        else:
            ts = self.ts
        
        # Convert frequency
        if target_freq == 'M':
            result = last_of_months(ts)
        elif target_freq == 'Q':
            result = last_of_quarters(ts)
        else:
            # Use pandas resample for other frequencies
            result = ts.resample(target_freq).last()
        
        if output_name:
            result.name = output_name
        
        return result
    
    def rolling_volatility(self, vol_window: int, scale: Optional[float] = None,
                          output_name: Optional[str] = None) -> pd.Series:
        """
        Calculate rolling volatility.
        
        Args:
            vol_window: Window size for volatility calculation
            scale: Scaling factor (e.g., sqrt(252) for daily to annual)
            output_name: Name for output series
            
        Returns:
            Rolling volatility series
        """
        if scale is None and self.frequency == 'D':
            scale = math.sqrt(252)  # Annualize daily volatility
        elif scale is None:
            scale = 1
        
        vol = index_to_rolling_vol(self.ts, vol_window) * scale
        
        if output_name:
            vol.name = output_name
        
        return vol
