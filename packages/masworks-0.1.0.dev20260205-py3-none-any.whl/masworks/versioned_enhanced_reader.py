#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Versioned Enhanced TimeSeriesReader with support for multiple table versions.

This module provides an enhanced version of TimeSeriesReader that can work
with multiple versions of the same table sets (e.g., TS_Data_v1, TS_Data_v2)
using the versioned models factory.
"""

import pandas as pd
import numpy as np
from typing import List, Optional, Union, Dict, Any, Type
from datetime import datetime
import logging
from sqlalchemy import select, func, and_, or_, text
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select

from .versioned_time_series_reader import VersionedTimeSeriesReader
from .MasDatabase.versioned_models import VersionedModelRegistry, get_models_for_version

logger = logging.getLogger(__name__)


class VersionedEnhancedTimeSeriesReader(VersionedTimeSeriesReader):
    """
    Versioned Enhanced TimeSeriesReader with support for multiple table versions.
    
    This class extends VersionedTimeSeriesReader with enhanced SQLAlchemy ORM capabilities
    and the ability to work with different versions of the same table sets, allowing you 
    to query data from multiple versions simultaneously or switch between versions as needed.
    """
    
    def __init__(self, config: Dict[str, Any], version: Optional[str] = None, auto_create_tables: bool = True):
        """
        Initialize the VersionedEnhancedTimeSeriesReader.
        
        Args:
            config: Configuration dictionary for database connection
            version: Default version to use (None for current)
            auto_create_tables: If True, automatically create database tables if they don't exist
        """
        super().__init__(config, version, auto_create_tables)
        self._lag = 'Lag2'  # Default lag setting
        
        # Set default_version for compatibility (normalized by base)
        self.default_version = self.version
        
        # Initialize model classes as properties for efficiency
        self._init_model_properties()
    
    def _init_model_properties(self):
        """
        Initialize model classes as properties for efficiency.
        
        This method sets up model classes as instance properties to avoid
        repeated calls to get_models_for_version() during operations.
        
        Raises:
            RuntimeError: If model initialization fails
        """
        try:
            # Get models for the current version
            models = self.get_models_for_version(self.version)
            
            # Validate that all required models are available
            required_models = ['TimeSeriesData', 'TimeSeriesMeta', 'TimeSeriesStatus', 'TimeSeriesSelector']
            missing_models = []
            
            for model_name in required_models:
                if model_name not in models or models[model_name] is None:
                    missing_models.append(model_name)
            
            if missing_models:
                raise RuntimeError(f"Missing models for version {self.version or 'current'}: {missing_models}")
            
            # Set as instance properties
            self.TimeSeriesData = models['TimeSeriesData']
            self.TimeSeriesMeta = models['TimeSeriesMeta']
            self.TimeSeriesStatus = models['TimeSeriesStatus']
            self.TimeSeriesSelector = models['TimeSeriesSelector']
            
            logger.debug(f"Successfully initialized model properties for version: {self.version or 'current'}")
            
        except Exception as e:
            logger.error(f"Failed to initialize model properties for version {self.version or 'current'}: {e}")
            raise RuntimeError(f"Model initialization failed: {e}") from e
    
    def refresh_model_properties(self, version: Optional[str] = None):
        """
        Refresh model properties for a different version.
        
        Args:
            version: Version to refresh properties for (None for current)
        """
        if version is not None:
            self._set_version(version)
            self.default_version = self.version
        self._init_model_properties()
    
    def _validate_model_properties(self):
        """
        Validate that all model properties are properly initialized.
        
        Raises:
            RuntimeError: If any model property is None
        """
        if self.TimeSeriesData is None:
            raise RuntimeError("TimeSeriesData not initialized")
        if self.TimeSeriesMeta is None:
            raise RuntimeError("TimeSeriesMeta not initialized")
        if self.TimeSeriesStatus is None:
            raise RuntimeError("TimeSeriesStatus not initialized")
        if self.TimeSeriesSelector is None:
            raise RuntimeError("TimeSeriesSelector not initialized")
    
    def get_models(self, version: Optional[str] = None) -> Dict[str, Type]:
        """
        Get models for the current version.
        
        Returns:
            Dict[str, Type]: Dictionary of model name to model class
        """
        target_version = version if version is not None else self.default_version
        return self.model_registry.get_models(target_version)
    
    def get_model(self, model_name: str, version: Optional[str] = None) -> Type:
        """
        Get a specific model for the current version.
        
        Args:
            model_name: Name of the model (e.g., 'TimeSeriesData', 'TimeSeriesMeta')
            
        Returns:
            Type: SQLAlchemy model class
        """
        target_version = version if version is not None else self.default_version
        return self.model_registry.get_model(model_name, target_version)
    
    def get_ts_by_id(self, tid: Union[int, str], name: str = 'value', 
                     condition: str = '1=1') -> pd.Series:
        """
        Retrieve time series by ID with optional conditions using versioned models.
        
        Args:
            tid: Time series ID (int) or series ID string
            name: Name for the series
            condition: SQL condition for filtering (legacy support)
            
        Returns:
            pd.Series: Time series data
        """
        try:
            if isinstance(tid, str):
                # Get ID from series ID
                tid = self._get_tid_from_sid(tid)
            
            # Use the pre-initialized model property for efficiency
            TimeSeriesData = self.TimeSeriesData
            
            # Build query using SQLAlchemy ORM
            query = select(TimeSeriesData.date, TimeSeriesData.value).where(
                TimeSeriesData.id == tid
            ).order_by(TimeSeriesData.date)
            
            # Execute query using session
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.Series(dtype=float, name=name)
                
                # Convert to DataFrame and then Series
                df = pd.DataFrame(result, columns=['date', 'value'])
                df['date'] = pd.to_datetime(df['date'])
                ts = df.set_index('date')['value']
                ts.name = name
                ts.TsId = tid
                return ts
                
        except Exception as e:
            logger.error(f"Failed to get time series {tid}: {e}")
            raise
    
    def get_ts_with_lag(self, tid: Union[int, str], name: str = 'value', 
                       use_lag: bool = True, align: str = None) -> pd.DataFrame:
        """
        Retrieve time series with lag and alignment options using versioned models.
        
        Args:
            tid: Time series ID
            name: Name for the series
            use_lag: Whether to apply lag
            align: Alignment option ('EOM' for end of month)
            version: Version to use (defaults to default_version)
            
        Returns:
            pd.DataFrame: Time series data with date and value columns
        """
        try:
            if isinstance(tid, str):
                tid = self._get_tid_from_sid(tid)
            
            # Use pre-initialized model properties for efficiency
            TimeSeriesData = self.TimeSeriesData
            TimeSeriesMeta = self.TimeSeriesMeta
            
            # Build date expression using SQLAlchemy functions
            if use_lag:
                # Use SQLAlchemy functions for date manipulation
                date_expr = func.DATEADD('day', func.ISNULL(TimeSeriesMeta.Lag2, 0), TimeSeriesData.date)
            else:
                date_expr = TimeSeriesData.date
            
            if align == 'EOM':
                date_expr = func.EOMONTH(date_expr)
            
            # Build query with joins for metadata
            query = select(
                date_expr.label('date'),
                TimeSeriesData.value.label(name)
            ).select_from(
                TimeSeriesData.__table__.join(
                    TimeSeriesMeta.__table__,
                    TimeSeriesData.id == TimeSeriesMeta.id
                )
            ).where(
                TimeSeriesData.id == tid
            ).order_by(date_expr)
            
            # Execute query
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                df = pd.DataFrame(result)
                df['date'] = pd.to_datetime(df['date'])
                return df.set_index('date')
                
        except Exception as e:
            logger.error(f"Failed to get time series with lag {tid}: {e}")
            raise
    
    def collect_series_by_selector(self, selector: str, condition: str = '1=1') -> List[pd.Series]:
        """
        Collect multiple series by selector using versioned models.
        
        Args:
            selector: Selector name
            condition: SQL condition for filtering (legacy support)
            version: Version to use (defaults to default_version)
            
        Returns:
            List[pd.Series]: List of time series
        """
        try:
            # Get selector information
            selector_info = self._get_selector_series_info(selector)
            if not selector_info:
                return []
            
            # Collect series
            series_list = []
            for series_id, colname in selector_info.items():
                try:
                    ts = self.get_ts_by_id(series_id, colname, condition)
                    series_list.append(ts)
                except Exception as e:
                    logger.warning(f"Failed to get series {series_id} ({colname}): {e}")
                    continue
            
            return series_list
            
        except Exception as e:
            logger.error(f"Failed to collect series for selector {selector}: {e}")
            raise
    
    def merge_series(self, tids: List[int], condition: str = '1=1') -> pd.DataFrame:
        """
        Merge multiple time series into a DataFrame using versioned models.
        
        Args:
            tids: List of time series IDs
            condition: SQL condition for filtering (legacy support)
            version: Version to use (defaults to default_version)
            
        Returns:
            pd.DataFrame: Merged time series data
        """
        try:
            # Get metadata
            metadata = self._get_metadata_by_ids(tids)
            if not metadata:
                return pd.DataFrame()
            
            # Create name mapping
            name_map = {row['id']: row.get('ticker') or row.get('tkr') for row in metadata}
            
            # Collect and merge series
            series_list = []
            for tid in tids:
                if tid in name_map:
                    name = name_map[tid]
                    ts = self.get_ts_by_id(tid, name, condition)
                    series_list.append(ts)
            
            if not series_list:
                return pd.DataFrame()
            
            return pd.concat(series_list, axis=1)
            
        except Exception as e:
            logger.error(f"Failed to merge series {tids}: {e}")
            raise
    
    def compare_versions(self, tid: Union[int, str], versions: List[str] = None) -> pd.DataFrame:
        """
        Compare the same time series across different versions.
        
        Args:
            tid: Time series ID
            versions: List of versions to compare (defaults to available versions)
            
        Returns:
            pd.DataFrame: Combined data from all versions with version labels
        """
        try:
            if versions is None:
                versions = self.model_registry.list_available_versions()
            
            combined_data = []
            
            for version in versions:
                try:
                    # Get data for this version
                    ts = self.get_ts_by_id(tid, f'v{version}')
                    if not ts.empty:
                        ts.name = f'version_{version}' if version else 'current'
                        combined_data.append(ts)
                except Exception as e:
                    logger.warning(f"Failed to get data for version {version}: {e}")
                    continue
            
            if not combined_data:
                return pd.DataFrame()
            
            return pd.concat(combined_data, axis=1)
            
        except Exception as e:
            logger.error(f"Failed to compare versions for series {tid}: {e}")
            raise
    
    def get_metadata(self) -> pd.DataFrame:
        """
        Get metadata for the current version.
        
        Returns:
            pd.DataFrame: Metadata for the current version
        """
        try:
            
            # Use pre-initialized model property for efficiency
            TimeSeriesMeta = self.TimeSeriesMeta
            
            query = select(TimeSeriesMeta)
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return pd.DataFrame()
                
                # Convert to DataFrame
                df = pd.DataFrame([row._asdict() for row in result])
                return df
                
        except Exception as e:
            logger.error(f"Failed to get metadata for version {self.version or 'current'}: {e}")
            raise
    
    def migrate_data(self, from_version: str, to_version: str, 
                    series_ids: List[int] = None) -> Dict[str, Any]:
        """
        Migrate data from one version to another.
        
        Args:
            from_version: Source version
            to_version: Target version
            series_ids: List of series IDs to migrate (None for all)
            
        Returns:
            Dict[str, Any]: Migration results
        """
        try:
            # Get source and target models
            source_models = self.get_models(from_version)
            target_models = self.get_models(to_version)
            
            results = {
                'migrated_series': [],
                'failed_series': [],
                'total_series': 0,
                'success_count': 0,
                'error_count': 0
            }
            
            # Get series to migrate
            if series_ids is None:
                source_meta = source_models['TimeSeriesMeta']
                with self.db_manager.get_session() as session:
                    query = select(source_meta.id)
                    series_ids = [row[0] for row in session.execute(query).fetchall()]
            
            results['total_series'] = len(series_ids)
            
            # Migrate each series
            for series_id in series_ids:
                try:
                    # Get source data
                    source_data = self.get_ts_by_id(series_id, version=from_version)
                    if source_data.empty:
                        continue
                    
                    # Insert into target version
                    # Note: This would need to be implemented based on your specific requirements
                    # For now, just track the series
                    results['migrated_series'].append(series_id)
                    results['success_count'] += 1
                    
                except Exception as e:
                    logger.error(f"Failed to migrate series {series_id}: {e}")
                    results['failed_series'].append(series_id)
                    results['error_count'] += 1
            
            return results
            
        except Exception as e:
            logger.error(f"Failed to migrate data from {from_version} to {to_version}: {e}")
            raise
    
    # Helper methods
    
    def _get_tid_from_sid(self, sid: str) -> int:
        """
        Get time series ID from series ID string.
        
        Args:
            sid: Series ID string
            
        Returns:
            int: Time series ID
        """
        try:
            
            # Use pre-initialized model property for efficiency
            TimeSeriesMeta = self.TimeSeriesMeta
            query = select(TimeSeriesMeta.id).where(TimeSeriesMeta.sid == sid)
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchone()
                if not result:
                    raise ValueError(f"Series ID {sid} not found")
                return result[0]
                
        except Exception as e:
            logger.error(f"Failed to get ID for series {sid}: {e}")
            raise
    
    def _get_selector_series_info(self, selector: str) -> Dict[int, str]:
        """
        Get selector series information.
        
        Args:
            selector: Selector name
            
        Returns:
            Dict[int, str]: Mapping of series ID to column name
        """
        try:
            
            # Use pre-initialized model property for efficiency
            TimeSeriesSelector = self.TimeSeriesSelector
            query = select(TimeSeriesSelector.id, TimeSeriesSelector.colname).where(
                TimeSeriesSelector.sel == selector
            ).order_by(TimeSeriesSelector.ord)
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return {}
                
                return {row[0]: row[1] for row in result}
                
        except Exception as e:
            logger.error(f"Failed to get selector info for {selector}: {e}")
            raise
    
    def _get_metadata_by_ids(self, tids: List[int]) -> List[Dict[str, Any]]:
        """
        Get metadata for multiple series IDs.
        
        Args:
            tids: List of time series IDs
            
        Returns:
            List[Dict[str, Any]]: List of metadata dictionaries
        """
        try:
            
            # Use pre-initialized model property for efficiency
            TimeSeriesMeta = self.TimeSeriesMeta
            query = select(
                TimeSeriesMeta.id,
                TimeSeriesMeta.source,
                TimeSeriesMeta.ticker,
                TimeSeriesMeta.field,
                TimeSeriesMeta.frequency,
                TimeSeriesMeta.currency,
                TimeSeriesMeta.sid
            ).where(TimeSeriesMeta.id.in_(tids))
            
            with self.db_manager.get_session() as session:
                result = session.execute(query).fetchall()
                
                if not result:
                    return []
                
                # Convert to list of dictionaries
                return [dict(row._mapping) for row in result]
                
        except Exception as e:
            logger.error(f"Failed to get metadata for IDs {tids}: {e}")
            raise
