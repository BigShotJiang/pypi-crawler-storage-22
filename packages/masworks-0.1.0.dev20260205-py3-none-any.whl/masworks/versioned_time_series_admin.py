"""
Versioned administrative interface for time series data management.

Inherits all read capabilities from VersionedTimeSeriesReader and adds
versioned data modification, selector management, and bulk operations.
"""
import logging
from typing import Optional, Dict, Any, List, Union
import pandas as pd
from datetime import datetime

from .versioned_time_series_reader import VersionedTimeSeriesReader
from .MasDatabase import SeriesOperationMixin, BloombergOperationsMixin, handle_series_operation_errors
from .MasDatabase.versioned_models import is_current_version
from .constants import (
    SOURCE_ALIASES, DEFAULT_FREQUENCY, DEFAULT_SOURCE, DEFAULT_CURRENCY,
    OPERATION_TYPES, STATUS_CODES, SOURCE_CODE_MAP
)
from .types import DateInput
from .utils.date_utils import normalize_date_input

logger = logging.getLogger(__name__)


class VersionedTimeSeriesAdmin(VersionedTimeSeriesReader, SeriesOperationMixin, BloombergOperationsMixin):
    """
    Versioned administrative interface for time series data management.
    
    Inherits all read capabilities from VersionedTimeSeriesReader and adds
    versioned data modification, selector management, and bulk operations.
    This class provides full administrative control over versioned time series data.
    
    Features:
    - Version-aware data modification
    - Cross-version data migration
    - Version creation and management
    - Bulk operations across versions
    - Data ingestion (upsert/replace) for any version including current
    """
    
    # Field-specific configurations for special handling
    FIELD_SPECIFIC_CONFIG = {
        'TOT_RETURN_INDEX_GROSS_DVDS': {
            'start_date': '1901-01-01',
            'reason': 'Total return indices require maximum historical coverage for accurate performance calculation',
            'applies_to': ['upsert', 'replace', 'bulk']
        }
    }
    
    def __init__(self, config, version: Optional[str] = None, lazy_feeds: bool = False):
        """
        Initialize VersionedTimeSeriesAdmin with feed support.
        
        Args:
            config: Configuration object with database and feed settings
            version: Default version to use for operations (None or '' for current)
            lazy_feeds: If True, initialize feeds only when first needed (default: False)
        """
        super().__init__(config, version)
        
        self._feeds_initialized = False
        self._lazy_feeds = lazy_feeds
        
        if not lazy_feeds:
            # Initialize data feeds immediately
            self._initialize_feeds()
    
    def _initialize_feeds(self):
        """Initialize data feeds for admin operations."""
        if self._feeds_initialized:
            return
        
        from masworks.feeds import BridgeFeed, FredFeed, DatastreamFeed
        from masworks.constants import SOURCE_ALIASES
        
        logger.info("Initializing data feeds for versioned admin operations...")
        
        self.feeds = {
            'bloomberg': BridgeFeed(self.config.bridge, self.db_manager),
            'fred': FredFeed(self.config.fred),
            'datastream': DatastreamFeed(self.config.datastream),
        }
        
        # Add aliases for convenience
        for alias, source in SOURCE_ALIASES.items():
            self.feeds[alias] = self.feeds[source]
        
        self._feeds_initialized = True
        logger.info(f"Initialized {len(self.feeds)} data feeds: {list(self.feeds.keys())}")
    
    def _ensure_feeds_initialized(self):
        """Ensure feeds are initialized (for lazy initialization)."""
        if not self._feeds_initialized:
            if self._lazy_feeds:
                logger.info("Lazy initializing feeds on first use...")
                self._initialize_feeds()
            else:
                raise RuntimeError("Feeds not initialized and lazy initialization is disabled")
    
    def _get_field_specific_start_date(self, field: str, provided_start_date: str) -> str:
        """Get the appropriate start date for a specific field."""
        if field in self.FIELD_SPECIFIC_CONFIG:
            config = self.FIELD_SPECIFIC_CONFIG[field]
            logger.info(f"Using field-specific start date for {field}: {config['start_date']} ({config['reason']})")
            return config['start_date']
        return provided_start_date
    
    @handle_series_operation_errors
    def _update_series(self, ticker: str, field: str, operation: str = OPERATION_TYPES['UPSERT'],
                      frequency: str = DEFAULT_FREQUENCY, source: str = DEFAULT_SOURCE, 
                      currency: str = DEFAULT_CURRENCY, start_date: DateInput = None, 
                      updated_by: Optional[str] = None, version: Optional[str] = None, 
                      auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Update time series data from external source (upsert or replace).
        
        This is the unified method for both upsert and replace operations.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            operation: Operation type - 'upsert' (update existing, insert new) or 'replace' (delete all, insert new)
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source ('bloomberg', 'fred', 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            version: Version to update in (None uses default version from initialization)
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        # Validate operation type
        if operation not in [OPERATION_TYPES['UPSERT'], OPERATION_TYPES['REPLACE']]:
            raise ValueError(f"Invalid operation '{operation}'. Must be '{OPERATION_TYPES['UPSERT']}' or '{OPERATION_TYPES['REPLACE']}'")
        
        # Use provided version or default
        target_version = version if version is not None else self.version
        
        # Apply field-specific date logic
        adjusted_start_date = self._get_field_specific_start_date(field, start_date)
        
        # Normalize adjusted date
        adjusted_start_date = normalize_date_input(adjusted_start_date, '%Y-%m-%d')
        
        # For current version (empty suffix), use standard admin methods
        if is_current_version(target_version):
            # Delegate to standard admin functionality (uses current/non-versioned tables)
            return self._execute_series_operation_base(
                ticker, field, frequency, source, currency, adjusted_start_date,
                operation, updated_by=updated_by, auto_create=auto_create, **kwargs
            )
        else:
            # For versioned tables, use versioned helper methods
            return self._execute_series_operation_versioned(
                ticker, field, frequency, source, currency, adjusted_start_date,
                operation, target_version, updated_by=updated_by, auto_create=auto_create, **kwargs
            )
    
    @handle_series_operation_errors
    def upsert_series(self, ticker: str, field: str, frequency: str = DEFAULT_FREQUENCY,
                      source: str = DEFAULT_SOURCE, currency: str = DEFAULT_CURRENCY,
                      start_date: DateInput = None, updated_by: Optional[str] = None, 
                      version: Optional[str] = None, auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Upsert (insert or update) time series data from external source.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source ('bloomberg', 'fred', 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            version: Version to upsert to (None uses default version from initialization)
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        return self._update_series(
            ticker=ticker, field=field, operation=OPERATION_TYPES['UPSERT'],
            frequency=frequency, source=source, currency=currency,
            start_date=start_date, updated_by=updated_by, version=version, auto_create=auto_create, **kwargs
        )
    
    @handle_series_operation_errors
    def replace_series(self, ticker: str, field: str, frequency: str = DEFAULT_FREQUENCY,
                      source: str = DEFAULT_SOURCE, currency: str = DEFAULT_CURRENCY,
                      start_date: DateInput = None, updated_by: Optional[str] = None, 
                      version: Optional[str] = None, auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Replace (delete and re-insert) time series data from external source.
        
        This function deletes all existing data for the series and re-inserts fresh data.
        Unlike upsert, this ensures complete data replacement.
        
        Args:
            ticker: Security ticker/identifier
            field: Data field to retrieve
            frequency: Data frequency (D, W, M, Q, A)
            source: Data source ('bloomberg', 'fred', 'datastream')
            currency: Currency code
            start_date: Start date for data retrieval (str, datetime, pd.Timestamp, or None)
            updated_by: User who performed the update (optional, for TimeSeriesStatus tracking)
            version: Version to replace data in (None uses default version from initialization)
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional parameters for data feed
            
        Returns:
            Dictionary with operation results including status_record_created flag
        """
        return self._update_series(
            ticker=ticker, field=field, operation=OPERATION_TYPES['REPLACE'],
            frequency=frequency, source=source, currency=currency,
            start_date=start_date, updated_by=updated_by, version=version, auto_create=auto_create, **kwargs
        )
    
    def _execute_series_operation_base(self, ticker: str, field: str, frequency: str,
                                       source: str, currency: str, start_date: Optional[str],
                                       operation_type: str, updated_by: Optional[str] = None, 
                                       auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """Base method for executing series operations (upsert or replace) - delegates to mixin."""
        # Ensure feeds are initialized
        self._ensure_feeds_initialized()
        
        # Normalize and validate source
        source = self._normalize_source(source)
        
        # Separate metadata parameters from feed parameters
        metadata_params = {}
        feed_params = {}
        
        # Known metadata fields that should not be passed to feeds
        metadata_fields = {'cname', 'cname2', 'cat', 'note', 'Lag', 'freq', 'Lag2', 'tempflag', 'sid', 'json'}
        
        for key, value in kwargs.items():
            if key in metadata_fields:
                metadata_params[key] = value
            else:
                feed_params[key] = value
        
        # IMPORTANT: Validate parameters by fetching data FIRST
        df = self._validate_data_feed_parameters(ticker, field, frequency, source, currency, start_date, **feed_params)
        
        # Additional safety check for DataFrame
        if df is None or df.empty:
            logger.warning(f"Data validation returned None/empty for {ticker} {field} - parameters may be invalid")
            no_data_result = {
                "status": STATUS_CODES['NO_DATA'],
                "rows_updated": 0,
                "rows_inserted": 0,
                "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
            }
            if operation_type == OPERATION_TYPES['REPLACE']:
                no_data_result["rows_deleted"] = 0
            return no_data_result
        
        logger.info(f"Successfully fetched {len(df)} data points for {ticker} {field}")
        
        # Only create metadata if data fetch was successful
        series_id, is_new_series = self._get_or_create_series_metadata(
            ticker, field, frequency, source, currency, auto_create=auto_create, **metadata_params
        )
        
        # Prepare data for operation
        df_operation = self._prepare_dataframe_for_operation(df, series_id)
        
        # Execute the operation
        if operation_type == OPERATION_TYPES['UPSERT']:
            upserted, _ = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_upserted": upserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Upserted {ticker} {field}: {upserted} rows processed")
        else:  # REPLACE
            deleted, inserted = self._execute_series_operation(df_operation, operation_type)
            result = {
                "status": STATUS_CODES['SUCCESS'],
                "series_id": series_id,
                "rows_deleted": deleted,
                "rows_inserted": inserted,
                "total_rows": len(df_operation)
            }
            logger.info(f"Replaced {ticker} {field}: {deleted} deleted, {inserted} inserted")
        
        # Create/update TimeSeriesStatus record for successful operations
        if result["status"] == STATUS_CODES['SUCCESS'] and not df_operation.empty:
            try:
                upd_start = df_operation['date'].min()
                upd_end = df_operation['date'].max()
                upd_by = updated_by or self._get_current_user()
                
                status_success = self.upsert_series_status(
                    series_id=series_id,
                    upd_start=upd_start,
                    upd_end=upd_end,
                    upd_by=upd_by
                )
                
                if status_success:
                    result["status_record_created"] = True
                    logger.debug(f"Upserted TimeSeriesStatus for series {series_id}")
                else:
                    result["status_record_created"] = False
                    logger.warning(f"Failed to upsert TimeSeriesStatus for series {series_id}")
                    
            except Exception as e:
                logger.error(f"Error upserting TimeSeriesStatus for series {series_id}: {e}")
                result["status_record_created"] = False
        
        return result
    
    def _get_current_user(self) -> str:
        """Get the current OS user for TimeSeriesStatus tracking."""
        try:
            import getpass
            return getpass.getuser()
        except Exception:
            try:
                import os
                return os.getlogin()
            except Exception:
                logger.warning("Could not determine current user, using 'system'")
                return 'system'
    
    def _get_or_create_series_metadata_versioned(self, version: str, ticker: str, field: str,
                                                 frequency: str, source: str, currency: str, 
                                                 auto_create: bool = True, **kwargs) -> tuple:
        """
        Get existing series metadata or create new one in a versioned table.
        
        Args:
            version: Version to work with
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency
            source: Source code
            currency: Currency code
            auto_create: If True, automatically create TS_Meta record if it doesn't exist. If False, raise error if metadata doesn't exist.
            **kwargs: Additional metadata fields
            
        Returns:
            Tuple of (series_id, is_new_series)
            
        Raises:
            ValueError: If auto_create=False and metadata doesn't exist
        """
        try:
            # Normalize source
            source = self._normalize_source(source)
            # Get source code - SOURCE_CODE_MAP keys are lowercase
            # SOURCE_CODE_MAP is only for feed sources (BB, DS, FRED)
            # Other sources are normalized to uppercase (up to column limit of 6 chars)
            source_code = SOURCE_CODE_MAP.get(source, source.upper()[:6])
            
            # For FRED, normalize parameters
            if source_code == 'FRED':
                field = '-'
                frequency = '-'
                currency = '-'
            
            # Check if series already exists
            filters = {
                'ticker': ticker.upper(),
                'field': field.upper() if field else '-',
                'frequency': frequency.upper(),
                'source': source_code,
                'currency': currency.upper() if currency else '-'
            }
            
            existing = self.versioned_session_manager.get_ts_metadata_versioned(version, **filters)
            
            if existing and len(existing) > 0:
                # Update existing metadata
                series_id = existing[0]['id']
                self.versioned_session_manager.update_ts_metadata_versioned(version, series_id)
                logger.info(f"Updated existing series metadata for ID: {series_id} in version {version}")
                return series_id, False
            else:
                if not auto_create:
                    # Build error message with filter details
                    normalized_ticker = ticker.upper()
                    normalized_field = field.upper() if field else '-'
                    normalized_frequency = frequency.upper()
                    normalized_currency = currency.upper() if currency else '-'
                    raise ValueError(
                        f"TS_Meta record does not exist for series in version '{version}': "
                        f"source={source_code}, ticker={normalized_ticker}, field={normalized_field}, "
                        f"frequency={normalized_frequency}, currency={normalized_currency}. "
                        f"Set auto_create=True to automatically create metadata."
                    )
                
                # Create new series metadata
                username = self._get_current_user()
                
                # Prepare normalized values for SID generation
                normalized_ticker = ticker.upper()
                normalized_field = field.upper() if field else '-'
                normalized_frequency = frequency.upper()
                normalized_currency = currency.upper() if currency else '-'
                
                # Generate SID if not provided in kwargs
                # SID format: "SOURCE::TICKER::FIELD::FREQUENCY::CURRENCY"
                if 'sid' not in kwargs:
                    sid = f"{source_code}::{normalized_ticker}::{normalized_field}::{normalized_frequency}::{normalized_currency}"
                    kwargs['sid'] = sid
                    logger.debug(f"Generated SID for new series: {sid}")
                
                metadata = self.versioned_session_manager.create_ts_metadata_versioned(
                    version=version,
                    source=source_code,
                    ticker=normalized_ticker,
                    field=normalized_field,
                    frequency=normalized_frequency,
                    currency=normalized_currency,
                    created_by=username,
                    **kwargs
                )
                # Convert numpy.int64 to Python int for pyodbc compatibility
                series_id = metadata['id']
                if hasattr(series_id, 'item'):
                    series_id = series_id.item()
                else:
                    series_id = int(series_id)
                logger.info(f"Created new series metadata with ID: {series_id} in version {version}")
                return series_id, True
                
        except Exception as e:
            logger.error(f"Failed to get or create series metadata for version {version}: {e}")
            raise
    
    def _execute_series_operation_versioned(self, ticker: str, field: str, frequency: str,
                                            source: str, currency: str, start_date: Optional[str],
                                            operation_type: str, version: str,
                                            updated_by: Optional[str] = None, auto_create: bool = True, **kwargs) -> Dict[str, Any]:
        """
        Execute series operation (upsert or replace) for versioned tables.
        
        Args:
            ticker: Ticker symbol
            field: Field name
            frequency: Frequency
            source: Source code
            currency: Currency code
            start_date: Start date
            operation_type: Operation type (UPSERT or REPLACE)
            version: Version to operate on
            updated_by: User who performed the update
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with operation results
        """
        try:
            # Ensure feeds are initialized
            self._ensure_feeds_initialized()
            
            # Normalize and validate source
            source = self._normalize_source(source)
            
            # Separate metadata parameters from feed parameters
            metadata_params = {}
            feed_params = {}
            
            # Known metadata fields that should not be passed to feeds
            metadata_fields = {'cname', 'cname2', 'cat', 'note', 'Lag', 'freq', 'Lag2', 'tempflag', 'sid', 'json'}
            
            for key, value in kwargs.items():
                if key in metadata_fields:
                    metadata_params[key] = value
                else:
                    feed_params[key] = value
            
            # IMPORTANT: Validate parameters by fetching data FIRST
            df = self._validate_data_feed_parameters(ticker, field, frequency, source, currency, start_date, **feed_params)
            
            # Additional safety check for DataFrame
            if df is None or df.empty:
                logger.warning(f"Data validation returned None/empty for {ticker} {field} - parameters may be invalid")
                no_data_result = {
                    "status": STATUS_CODES['NO_DATA'],
                    "rows_updated": 0,
                    "rows_inserted": 0,
                    "error": f"No data available for {ticker} {field} from {source}. Please verify ticker, field, and frequency parameters."
                }
                if operation_type == OPERATION_TYPES['REPLACE']:
                    no_data_result["rows_deleted"] = 0
                return no_data_result
            
            logger.info(f"Successfully fetched {len(df)} data points for {ticker} {field}")
            
            # Get or create metadata in versioned table
            series_id, is_new_series = self._get_or_create_series_metadata_versioned(
                version, ticker, field, frequency, source, currency, auto_create=auto_create, **metadata_params
            )
            
            # Prepare data for operation
            df_operation = self._prepare_dataframe_for_operation(df, series_id)
            
            # Execute the operation using versioned session manager
            if operation_type == OPERATION_TYPES['UPSERT']:
                upserted, _ = self.versioned_session_manager.upsert_ts_data_versioned(version, df_operation)
                result = {
                    "status": STATUS_CODES['SUCCESS'],
                    "series_id": series_id,
                    "rows_upserted": upserted,
                    "total_rows": len(df_operation)
                }
                logger.info(f"Upserted {ticker} {field} to version {version}: {upserted} rows processed")
            else:  # REPLACE
                deleted, inserted = self.versioned_session_manager.replace_ts_data_versioned(version, df_operation, series_id)
                result = {
                    "status": STATUS_CODES['SUCCESS'],
                    "series_id": series_id,
                    "rows_deleted": deleted,
                    "rows_inserted": inserted,
                    "total_rows": len(df_operation)
                }
                logger.info(f"Replaced {ticker} {field} in version {version}: {deleted} deleted, {inserted} inserted")
            
            # Create/update TimeSeriesStatus record for successful operations
            if result["status"] == STATUS_CODES['SUCCESS'] and not df_operation.empty:
                try:
                    upd_start = df_operation['date'].min()
                    upd_end = df_operation['date'].max()
                    upd_by = updated_by or self._get_current_user()
                    
                    status_success = self.upsert_series_status(
                        series_id=series_id,
                        upd_start=upd_start,
                        upd_end=upd_end,
                        upd_by=upd_by,
                        version=version
                    )
                    
                    if status_success:
                        result["status_record_created"] = True
                        logger.debug(f"Upserted TimeSeriesStatus for series {series_id} in version {version}")
                    else:
                        result["status_record_created"] = False
                        logger.warning(f"Failed to upsert TimeSeriesStatus for series {series_id} in version {version}")
                        
                except Exception as e:
                    logger.error(f"Error upserting TimeSeriesStatus for series {series_id} in version {version}: {e}")
                    result["status_record_created"] = False
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to execute series operation for version {version}: {e}")
            raise
    
    def upsert_series_status(self, series_id: int, upd_start: DateInput, upd_end: DateInput,
                             upd_by: Optional[str] = None, version: Optional[str] = None) -> bool:
        """
        Upsert (create or update) a TimeSeriesStatus record for a series.
        
        Args:
            series_id: Series ID to upsert status for
            upd_start: Start date of the time series update
            upd_end: End date of the time series update  
            upd_by: User who performed the update (optional, defaults to current OS user)
            version: Version to upsert status to (None uses default version from initialization)
            
        Returns:
            True if successful
        """
        try:
            # Use provided version or default
            target_version = version if version is not None else self.version
            
            # Normalize date inputs
            upd_start = normalize_date_input(upd_start, '%Y-%m-%d')
            upd_end = normalize_date_input(upd_end, '%Y-%m-%d')
            
            # Use current user if none provided
            if upd_by is None:
                upd_by = self._get_current_user()
            
            # For current version, use standard session manager
            if is_current_version(target_version):
                with self.db_manager.get_session() as session:
                    from .MasDatabase.models import TimeSeriesStatus
                    
                    # Check if status record already exists
                    existing_status = session.query(TimeSeriesStatus).filter_by(id=series_id).first()
                    
                    if existing_status:
                        # Update existing record
                        existing_status.upd = datetime.now()
                        existing_status.upd_start = upd_start
                        existing_status.upd_end = upd_end
                        if upd_by:
                            existing_status.upd_by = upd_by
                        logger.info(f"Updated TimeSeriesStatus for series {series_id}")
                    else:
                        # Create new record
                        status_record = TimeSeriesStatus(
                            id=series_id,
                            upd=datetime.now(),
                            upd_start=upd_start,
                            upd_end=upd_end,
                            upd_by=upd_by
                        )
                        session.add(status_record)
                        logger.info(f"Created TimeSeriesStatus for series {series_id}")
                    
                    return True
            else:
                # For versioned tables, use versioned session manager
                if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                    models = self.get_models_for_version(target_version)
                    TimeSeriesStatus = models.get('TimeSeriesStatus')
                    
                    if not TimeSeriesStatus:
                        logger.error(f"TimeSeriesStatus model not found for version {target_version}")
                        return False
                    
                    session = self.versioned_session_manager.get_session(target_version)
                    try:
                        # Check if status record already exists
                        existing_status = session.query(TimeSeriesStatus).filter_by(id=series_id).first()
                        
                        if existing_status:
                            # Update existing record
                            existing_status.upd = datetime.now()
                            existing_status.upd_start = upd_start
                            existing_status.upd_end = upd_end
                            if upd_by:
                                existing_status.upd_by = upd_by
                            logger.info(f"Updated TimeSeriesStatus for series {series_id} in version {target_version}")
                        else:
                            # Create new record
                            status_record = TimeSeriesStatus(
                                id=series_id,
                                upd=datetime.now(),
                                upd_start=upd_start,
                                upd_end=upd_end,
                                upd_by=upd_by
                            )
                            session.add(status_record)
                            logger.info(f"Created TimeSeriesStatus for series {series_id} in version {target_version}")
                        
                        # Explicitly commit the transaction
                        session.commit()
                        return True
                    except Exception as e:
                        session.rollback()
                        logger.error(f"Error in TS_Status update transaction: {e}")
                        raise
                    finally:
                        session.close()
                else:
                    logger.error("Versioned session manager not available")
                    return False
                    
        except Exception as e:
            logger.error(f"Failed to create/update TimeSeriesStatus for series {series_id}: {e}")
            return False
    
    def create_version(self, version_name: str, copy_from: Optional[str] = None) -> bool:
        """
        Create a new version of the database tables.
        
        Args:
            version_name: Name of the new version
            copy_from: Version to copy data from (None for empty version)
            
        Returns:
            bool: True if version was created successfully
        """
        try:
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                # Create tables for the new version
                success = self.versioned_session_manager.create_version_tables(version_name)
                
                if not success:
                    logger.error(f"Failed to create tables for version {version_name}")
                    return False
                
                # Create views for the new version
                view_results = self.versioned_session_manager.create_views_for_version(version_name, if_not_exists=True)
                if not all(view_results.values()):
                    logger.warning(f"Some views failed to create for version {version_name}: {view_results}")
                else:
                    logger.info(f"Successfully created views for version {version_name}")
                
                # Copy data if specified
                if copy_from:
                    logger.info(f"Copying data from {copy_from} to {version_name}")
                    results = self.versioned_session_manager.migrate_data(copy_from, version_name)
                    
                    total_migrated = sum(results.values())
                    logger.info(f"Migrated {total_migrated} records to version {version_name}")
                
                # Update available versions
                self._available_versions = self._discover_versions()
                
                logger.info(f"Successfully created version {version_name}")
                return True
            else:
                logger.error("Versioned session manager not available")
                return False
                
        except Exception as e:
            logger.error(f"Failed to create version {version_name}: {e}")
            return False
    
    def delete_version(self, version_name: str, confirm: bool = False) -> bool:
        """
        Delete a version and its associated tables.
        
        Args:
            version_name: Name of the version to delete
            confirm: Confirmation flag (must be True to proceed)
            
        Returns:
            bool: True if version was deleted successfully
        """
        if not confirm:
            logger.warning(f"Delete operation not confirmed for version {version_name}")
            return False
        
        try:
            if version_name == "current":
                logger.error("Cannot delete current version")
                return False
            
            table_names = ['TS_Data', 'TS_Meta', 'TS_Status', 'TS_Selector']
            
            with self.db_manager.get_session() as session:
                for table_name in table_names:
                    try:
                        full_table_name = self.get_table_name_for_version(table_name, version_name)
                        drop_sql = f"DROP TABLE IF EXISTS {full_table_name}"
                        session.execute(drop_sql)
                        logger.info(f"Dropped table {full_table_name}")
                    except Exception as e:
                        logger.warning(f"Failed to drop table {table_name} for version {version_name}: {e}")
                
                session.commit()
                
                # Update available versions
                self._available_versions = self._discover_versions()
                
                logger.info(f"Successfully deleted version {version_name}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to delete version {version_name}: {e}")
            return False
    
    def migrate_data(self, from_version: str, to_version: str, 
                    table_names: Optional[List[str]] = None) -> Dict[str, int]:
        """
        Migrate data from one version to another.
        
        Args:
            from_version: Source version
            to_version: Target version
            table_names: List of table names to migrate (None for all)
            
        Returns:
            Dict[str, int]: Number of records migrated per table
        """
        try:
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                results = self.versioned_session_manager.migrate_data(from_version, to_version, table_names)
                
                total_migrated = sum(results.values())
                logger.info(f"Migrated {total_migrated} records from {from_version} to {to_version}")
                
                return results
            else:
                logger.error("Versioned session manager not available")
                return {}
                
        except Exception as e:
            logger.error(f"Failed to migrate data from {from_version} to {to_version}: {e}")
            raise
    
    def merge_versions(self, source_versions: List[str], target_version: str,
                      merge_strategy: str = 'append') -> Dict[str, int]:
        """
        Merge multiple versions into a target version.
        
        Args:
            source_versions: List of source versions to merge
            target_version: Target version to merge into
            merge_strategy: Strategy for merging ('append', 'replace', 'update')
            
        Returns:
            Dict[str, int]: Number of records processed per table
        """
        try:
            results = {}
            
            for source_version in source_versions:
                logger.info(f"Merging {source_version} into {target_version}")
                
                if merge_strategy == 'append':
                    # Simple append - just migrate data
                    version_results = self.migrate_data(source_version, target_version)
                    for table, count in version_results.items():
                        results[table] = results.get(table, 0) + count
                
                elif merge_strategy == 'replace':
                    # Replace target with source data
                    # First clear target version
                    self._clear_version_data(target_version)
                    # Then migrate
                    version_results = self.migrate_data(source_version, target_version)
                    results.update(version_results)
                
                elif merge_strategy == 'update':
                    # Update strategy - more complex, would need conflict resolution
                    logger.warning("Update merge strategy not fully implemented")
                    version_results = self.migrate_data(source_version, target_version)
                    for table, count in version_results.items():
                        results[table] = results.get(table, 0) + count
            
            total_processed = sum(results.values())
            logger.info(f"Merged {total_processed} records into {target_version}")
            
            return results
            
        except Exception as e:
            logger.error(f"Failed to merge versions into {target_version}: {e}")
            raise
    
    def _clear_version_data(self, version: str) -> bool:
        """
        Clear all data from a version.
        
        Args:
            version: Version to clear
            
        Returns:
            bool: True if data was cleared successfully
        """
        try:
            table_names = ['TS_Data', 'TS_Meta', 'TS_Status', 'TS_Selector']
            
            with self.db_manager.get_session() as session:
                for table_name in table_names:
                    try:
                        full_table_name = self.get_table_name_for_version(table_name, version)
                        truncate_sql = f"TRUNCATE TABLE {full_table_name}"
                        session.execute(truncate_sql)
                        logger.info(f"Cleared table {full_table_name}")
                    except Exception as e:
                        logger.warning(f"Failed to clear table {table_name} for version {version}: {e}")
                
                session.commit()
                logger.info(f"Successfully cleared version {version}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to clear version {version}: {e}")
            return False
    
    def validate_version(self, version: str) -> Dict[str, Any]:
        """
        Validate a version for data integrity and consistency.
        
        Args:
            version: Version to validate
            
        Returns:
            Dict[str, Any]: Validation results
        """
        try:
            validation_results = {
                'version': version,
                'timestamp': datetime.now().isoformat(),
                'valid': True,
                'issues': [],
                'statistics': {}
            }
            
            # Get version statistics
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                stats = self.versioned_session_manager.get_version_statistics(version)
                validation_results['statistics'] = stats
                
                # Check for common issues
                if stats.get('total_records', 0) == 0:
                    validation_results['issues'].append("No data found in version")
                
                # Check for orphaned data
                try:
                    with self.versioned_session_manager.get_session(version) as session:
                        # Check for orphaned TS_Data records
                        orphaned_data = session.execute(f"""
                            SELECT COUNT(*) FROM {self.get_table_name_for_version('TS_Data', version)} d
                            LEFT JOIN {self.get_table_name_for_version('TS_Meta', version)} m ON d.id = m.id
                            WHERE m.id IS NULL
                        """).scalar()
                        
                        if orphaned_data > 0:
                            validation_results['issues'].append(f"Found {orphaned_data} orphaned data records")
                            validation_results['valid'] = False
                        
                        # Check for orphaned TS_Status records
                        orphaned_status = session.execute(f"""
                            SELECT COUNT(*) FROM {self.get_table_name_for_version('TS_Status', version)} s
                            LEFT JOIN {self.get_table_name_for_version('TS_Meta', version)} m ON s.id = m.id
                            WHERE m.id IS NULL
                        """).scalar()
                        
                        if orphaned_status > 0:
                            validation_results['issues'].append(f"Found {orphaned_status} orphaned status records")
                            validation_results['valid'] = False
                
                except Exception as e:
                    validation_results['issues'].append(f"Could not perform integrity checks: {e}")
                    validation_results['valid'] = False
            
            return validation_results
            
        except Exception as e:
            logger.error(f"Failed to validate version {version}: {e}")
            return {
                'version': version,
                'valid': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def get_version_comparison_report(self, version1: str, version2: str) -> Dict[str, Any]:
        """
        Generate a detailed comparison report between two versions.
        
        Args:
            version1: First version to compare
            version2: Second version to compare
            
        Returns:
            Dict[str, Any]: Detailed comparison report
        """
        try:
            # Get basic comparison
            basic_comparison = self.compare_versions(version1, version2)
            
            # Get detailed statistics
            stats1 = self.get_version_summary(version1)
            stats2 = self.get_version_summary(version2)
            
            # Get validation results
            validation1 = self.validate_version(version1)
            validation2 = self.validate_version(version2)
            
            report = {
                'comparison_timestamp': datetime.now().isoformat(),
                'version1': version1,
                'version2': version2,
                'basic_comparison': basic_comparison,
                'version1_summary': stats1,
                'version2_summary': stats2,
                'version1_validation': validation1,
                'version2_validation': validation2,
                'recommendations': []
            }
            
            # Generate recommendations
            if not validation1.get('valid', False):
                report['recommendations'].append(f"Version {version1} has data integrity issues")
            
            if not validation2.get('valid', False):
                report['recommendations'].append(f"Version {version2} has data integrity issues")
            
            if stats1.get('statistics', {}).get('total_records', 0) == 0:
                report['recommendations'].append(f"Version {version1} appears to be empty")
            
            if stats2.get('statistics', {}).get('total_records', 0) == 0:
                report['recommendations'].append(f"Version {version2} appears to be empty")
            
            return report
            
        except Exception as e:
            logger.error(f"Failed to generate comparison report for {version1} and {version2}: {e}")
            return {
                'version1': version1,
                'version2': version2,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def backup_version(self, version: str, backup_name: Optional[str] = None) -> bool:
        """
        Create a backup of a version.
        
        Args:
            version: Version to backup
            backup_name: Name for the backup (defaults to version_backup_timestamp)
            
        Returns:
            bool: True if backup was created successfully
        """
        try:
            if backup_name is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_name = f"{version}_backup_{timestamp}"
            
            logger.info(f"Creating backup of version {version} as {backup_name}")
            
            # Create backup version
            success = self.create_version(backup_name, copy_from=version)
            
            if success:
                logger.info(f"Successfully created backup {backup_name} of version {version}")
            else:
                logger.error(f"Failed to create backup {backup_name} of version {version}")
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to backup version {version}: {e}")
            return False
    
    def restore_version(self, backup_name: str, target_version: str, 
                      overwrite: bool = False) -> bool:
        """
        Restore a version from a backup.
        
        Args:
            backup_name: Name of the backup to restore
            target_version: Target version to restore to
            overwrite: Whether to overwrite existing target version
            
        Returns:
            bool: True if restore was successful
        """
        try:
            # Check if target version exists
            if target_version in self.get_available_versions() and not overwrite:
                logger.error(f"Target version {target_version} already exists and overwrite is False")
                return False
            
            # If target exists and overwrite is True, clear it first
            if target_version in self.get_available_versions() and overwrite:
                logger.info(f"Clearing existing version {target_version}")
                self._clear_version_data(target_version)
            
            # Restore from backup
            logger.info(f"Restoring backup {backup_name} to version {target_version}")
            results = self.migrate_data(backup_name, target_version)
            
            total_restored = sum(results.values())
            logger.info(f"Restored {total_restored} records to version {target_version}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to restore backup {backup_name} to {target_version}: {e}")
            return False
    
    def delete_selector(self, selector_name: str, version: Optional[str] = None) -> bool:
        """
        Delete a selector (all groups) for a specific version.
        
        Args:
            selector_name: Name of the selector to delete (deletes all groups)
            version: Version to delete selector from (None uses admin's default version)
            
        Returns:
            True if successful
        """
        try:
            # Use admin's default version if not specified
            if version is None:
                version_prefix = getattr(self, '_default_version_prefix', '')
                from .MasDatabase.versioned_models import denormalize_version_prefix, is_current_version
                if version_prefix == '' or is_current_version(version_prefix):
                    version = None
                else:
                    version = denormalize_version_prefix(version_prefix)
            
            # Get versioned models
            models = self.get_models_for_version(version)
            TimeSeriesSelector = models.get('TimeSeriesSelector')
            
            if not TimeSeriesSelector:
                logger.error(f"TimeSeriesSelector model not found for version {version}")
                return False
            
            # Use versioned session manager
            with self.versioned_session_manager.get_session(version) as session:
                # Delete all groups for this selector
                deleted_count = session.query(TimeSeriesSelector).filter_by(sel=selector_name).delete()
                session.commit()
                logger.info(f"Deleted selector '{selector_name}' (all groups) with {deleted_count} entries in version {version or 'current'}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to delete selector '{selector_name}': {e}")
            return False
    
    def create_selector(self, selector_name: str, series_specs: List[Dict[str, Any]], 
                       version: Optional[str] = None) -> bool:
        """
        Create a new selector for a specific version.
        
        Each spec must include 'group' or 'grp' key. If missing, session.add will raise an error.
        This allows multiple groups in one call when different specs have different groups.
        
        Args:
            selector_name: Name for the selector group
            series_specs: List of series specifications with order.
                         Each spec must include 'group' or 'grp' key.
            version: Version to create selector in (None uses admin's default version)
            
        Returns:
            True if successful
        """
        try:
            # Use admin's default version if not specified
            if version is None:
                version_prefix = getattr(self, '_default_version_prefix', '')
                from .MasDatabase.versioned_models import denormalize_version_prefix, is_current_version
                if version_prefix == '' or is_current_version(version_prefix):
                    version = None
                else:
                    version = denormalize_version_prefix(version_prefix)
            
            # Get versioned models
            models = self.get_models_for_version(version)
            TimeSeriesSelector = models.get('TimeSeriesSelector')
            
            if not TimeSeriesSelector:
                logger.error(f"TimeSeriesSelector model not found for version {version}")
                return False
            
            # Use versioned session manager
            with self.versioned_session_manager.get_session(version) as session:
                # Clear existing selector entries (delete all groups for this selector)
                session.query(TimeSeriesSelector).filter_by(sel=selector_name).delete()
                
                # Add new entries (group must be in spec, will raise error if missing)
                for i, spec in enumerate(series_specs):
                    spec_group = spec.get('group') or spec.get('grp')
                    selector_entry = TimeSeriesSelector(
                        sel=selector_name,
                        grp=spec_group,  # Will raise error if None
                        ord=spec.get('order', i + 1),
                        id=spec['series_id'],
                        colname=spec.get('colname'),
                        desname=spec.get('desname')
                    )
                    session.add(selector_entry)
                
                session.commit()
                logger.info(f"Created selector '{selector_name}' with {len(series_specs)} series in version {version or 'current'}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to create selector '{selector_name}': {e}")
            return False