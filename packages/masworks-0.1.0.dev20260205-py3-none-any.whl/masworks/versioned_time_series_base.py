"""
Base class for versioned time series operations.

Provides shared infrastructure for versioned database connections, model management,
and common utilities used by both versioned reader and admin classes.
"""
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from sqlalchemy import text

from .mas_time_series_base import TimeSeriesBase
from .MasDatabase.versioned_models import (
    VersionedModelRegistry,
    ModelFactory,
    normalize_version_prefix,
    denormalize_version_prefix,
    normalize_version_suffix,  # For backward compatibility
    denormalize_version_suffix,  # For backward compatibility
    is_current_version,
)

logger = logging.getLogger(__name__)


class VersionedTimeSeriesBase(TimeSeriesBase):
    """
    Base class for versioned time series operations.
    
    Provides shared infrastructure for versioned database connections, model management,
    and common utilities. This class is not meant to be used directly - use
    VersionedTimeSeriesReader for read operations or VersionedTimeSeriesAdmin for write operations.
    
    Features:
    - Version-aware model management
    - Cross-version data operations
    - Version comparison utilities
    - Schema evolution support
    """
    
    def __init__(self, config, version: Optional[str] = None):
        """
        Initialize VersionedTimeSeriesBase.
        
        Args:
            config: Configuration object with database and feed settings
            version: Default version to use for operations (None for current)
        """
        # Pass False for auto_create_tables since versioned classes should use create_version() explicitly
        super().__init__(config, auto_create_tables=False)
        
        # Version management
        self.model_registry = VersionedModelRegistry()
        self.model_factory = ModelFactory()
        self._default_version_prefix = ""
        self._set_version(version)
        
        # Initialize versioned session manager
        self._init_versioned_session_manager()
        
        # Track available versions
        self._available_versions = self._discover_versions()
        
        logger.info(f"Initialized VersionedTimeSeriesBase with version: {version}")
    
    def _init_versioned_session_manager(self):
        """Initialize the versioned session manager."""
        try:
            from .MasDatabase.versioned_session import VersionedSessionManager
            self.versioned_session_manager = VersionedSessionManager(
                self.db_manager,
                self.model_registry,
                chunk_size=self.config.database.chunk_size
            )
        except ImportError:
            logger.warning("VersionedSessionManager not available, using standard session manager")
            self.versioned_session_manager = None
    
    def _discover_versions(self) -> List[str]:
        """
        Discover available versions in the database.
        
        Returns:
            List[str]: List of available version names
        """
        try:
            # Query the database to find existing versioned tables
            with self.db_manager.get_session() as session:
                # Look for tables with version prefixes (e.g., v2_TS_Data, xyz_TS_Data)
                # Also check for old suffix format for backward compatibility
                stmt = text("""
                    SELECT TABLE_NAME 
                    FROM INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_SCHEMA = :schema 
                    AND (TABLE_NAME LIKE '%_TS_Data' OR TABLE_NAME LIKE 'TS_Data_%')
                """)
                result = session.execute(stmt, {"schema": self._get_schema()}).fetchall()
                
                versions = set()
                for row in result:
                    table_name = row[0]
                    # Extract version from table name
                    # New format: prefix_TS_Data (e.g., v2_TS_Data, xyz_TS_Data)
                    if table_name.endswith('_TS_Data'):
                        # Extract prefix (everything before _TS_Data)
                        prefix_part = table_name[:-8]  # Remove '_TS_Data'
                        if prefix_part and prefix_part != 'TS':
                            # Remove trailing underscore if present
                            if prefix_part.endswith('_'):
                                prefix_part = prefix_part[:-1]
                            label = denormalize_version_prefix(prefix_part + '_')
                            if label:
                                versions.add(label)
                    # Old format: TS_Data_suffix (for backward compatibility)
                    elif table_name.startswith('TS_Data_'):
                        suffix_part = table_name[8:]  # Remove 'TS_Data_'
                        label = denormalize_version_prefix(normalize_version_prefix(suffix_part))
                        if label:
                            versions.add(label)
                
                return sorted(list(versions))
                
        except Exception as e:
            logger.warning(f"Could not discover versions: {e}")
            return []
    
    def _get_schema(self) -> str:
        """Get the database schema from config."""
        return self.config.database.schema
    
    def get_available_versions(self) -> List[str]:
        """
        Get list of available versions.
        
        Returns:
            List[str]: List of available version names
        """
        return self._available_versions.copy()
    
    def get_current_version(self) -> str:
        """
        Get the current version (no suffix).
        
        Returns:
            str: Current version identifier
        """
        return "current"
    
    def is_version_available(self, version: str) -> bool:
        """
        Check if a specific version is available.
        
        Args:
            version: Version to check
            
        Returns:
            bool: True if version is available
        """
        if is_current_version(version):
            return True
        label = denormalize_version_prefix(normalize_version_prefix(version))
        return label in self._available_versions
    
    def get_models_for_version(self, version: Optional[str] = None):
        """
        Get model classes for a specific version.
        
        Args:
            version: Version to get models for (None for current)
            
        Returns:
            Dict[str, Type]: Dictionary of model classes
        """
        prefix = normalize_version_prefix(version)
        
        if prefix == "":
            # Return current models
            from .MasDatabase.models import (
                TimeSeriesData, TimeSeriesMeta, TimeSeriesStatus, TimeSeriesSelector
            )
            return {
                'TimeSeriesData': TimeSeriesData,
                'TimeSeriesMeta': TimeSeriesMeta,
                'TimeSeriesStatus': TimeSeriesStatus,
                'TimeSeriesSelector': TimeSeriesSelector
            }
        else:
            # Return versioned models
            return self.model_registry.get_models_for_version(version)
    
    def get_table_name_for_version(self, base_table: str, version: Optional[str] = None) -> str:
        """
        Get the actual table name for a specific version.
        
        Args:
            base_table: Base table name (e.g., 'TS_Data')
            version: Version to get table name for (None for current)
            
        Returns:
            str: Full table name with version prefix (e.g., 'dev.xyz_TS_Data')
        """
        prefix = normalize_version_prefix(version)
        schema = self._get_schema()
        
        if prefix == "":
            return f"{schema}.{base_table}"
        else:
            return f"{schema}.{prefix}{base_table}"
    
    def compare_versions(self, version1: str, version2: str) -> Dict[str, Any]:
        """
        Compare two versions of the database.
        
        Args:
            version1: First version to compare
            version2: Second version to compare
            
        Returns:
            Dict[str, Any]: Comparison results
        """
        try:
            comparison = {
                'version1': version1,
                'version2': version2,
                'timestamp': datetime.now().isoformat(),
                'schema_differences': [],
                'data_differences': [],
                'table_counts': {}
            }
            
            # Compare schema
            models1 = self.get_models_for_version(version1)
            models2 = self.get_models_for_version(version2)
            
            for table_name in set(models1.keys()) | set(models2.keys()):
                if table_name not in models1:
                    comparison['schema_differences'].append(f"Table {table_name} missing in {version1}")
                elif table_name not in models2:
                    comparison['schema_differences'].append(f"Table {table_name} missing in {version2}")
                else:
                    # Compare column structures
                    table1 = models1[table_name].__table__
                    table2 = models2[table_name].__table__
                    
                    if len(table1.columns) != len(table2.columns):
                        comparison['schema_differences'].append(
                            f"Table {table_name} has different column counts: {len(table1.columns)} vs {len(table2.columns)}"
                        )
            
            # Compare data counts
            with self.db_manager.get_session() as session:
                for table_name in ['TimeSeriesData', 'TimeSeriesMeta', 'TimeSeriesStatus', 'TimeSeriesSelector']:
                    try:
                        table1_name = self.get_table_name_for_version(table_name, version1)
                        table2_name = self.get_table_name_for_version(table_name, version2)
                        
                        count1 = session.execute(f"SELECT COUNT(*) FROM {table1_name}").scalar()
                        count2 = session.execute(f"SELECT COUNT(*) FROM {table2_name}").scalar()
                        
                        comparison['table_counts'][table_name] = {
                            version1: count1,
                            version2: count2,
                            'difference': count2 - count1
                        }
                        
                    except Exception as e:
                        logger.warning(f"Could not compare table {table_name}: {e}")
            
            return comparison
            
        except Exception as e:
            logger.error(f"Failed to compare versions {version1} and {version2}: {e}")
            return {
                'version1': version1,
                'version2': version2,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def get_version_info(self, version: Optional[str] = None) -> Dict[str, Any]:
        """
        Get information about a specific version.
        
        Args:
            version: Version to get info for (None for current)
            
        Returns:
            Dict[str, Any]: Version information
        """
        display_version = self._display_version(version)
        
        try:
            info = {
                'version': display_version,
                'timestamp': datetime.now().isoformat(),
                'tables': {},
                'total_records': 0
            }
            
            models = self.get_models_for_version(version)
            
            with self.db_manager.get_session() as session:
                for table_name, model_class in models.items():
                    try:
                        table_name_full = self.get_table_name_for_version(table_name, version)
                        count = session.execute(f"SELECT COUNT(*) FROM {table_name_full}").scalar()
                        info['tables'][table_name] = count
                        info['total_records'] += count
                    except Exception as e:
                        logger.warning(f"Could not get count for {table_name}: {e}")
                        info['tables'][table_name] = 0
            
            return info
            
        except Exception as e:
            logger.error(f"Failed to get version info for {version}: {e}")
            return {
                'version': display_version,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def close(self):
        """
        Close database connections and cleanup resources.
        
        Should be called when done with the instance to properly cleanup resources.
        """
        if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
            self.versioned_session_manager.close()
        super().close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _set_version(self, version: Optional[str]) -> None:
        """
        Normalize and store the default version information.
        """
        prefix = normalize_version_prefix(version)
        self._default_version_prefix = prefix
        self.version = denormalize_version_prefix(prefix)

    def _normalize_version_suffix_value(self, version: Optional[str]) -> str:
        """
        Resolve a version argument to its normalized prefix ('', 'v2_', etc.).
        Deprecated: Use normalize_version_prefix directly.
        """
        if version is None:
            return getattr(self, '_default_version_prefix', '')
        return normalize_version_prefix(version)

    def _display_version(self, version: Optional[str]) -> str:
        """
        Produce a user-facing version label ('current' or '1', etc.).
        """
        prefix = normalize_version_prefix(version) if version is not None else getattr(self, '_default_version_prefix', '')
        label = denormalize_version_prefix(prefix)
        return label or 'current'
