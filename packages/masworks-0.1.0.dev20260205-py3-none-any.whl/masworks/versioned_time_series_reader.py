"""
Versioned read-only interface for time series data retrieval.

Provides methods for querying time series data, metadata, and selectors
across different versions without the ability to modify data.
"""
import logging
from typing import Optional, Dict, Any, List, Union
import pandas as pd
from sqlalchemy import text, select

from .versioned_time_series_base import VersionedTimeSeriesBase
from .constants import SOURCE_ALIASES, SOURCE_CODE_MAP
from .MasDatabase.versioned_models import is_current_version
from .mas_time_series_reader import (
    ReturnHandler,
    _build_date_expression_sql,
    _build_lagged_query_sql,
    _needs_monthly_collapse,
    _normalize_frequency_value,
)
from .types import DateInput
from .utils.date_utils import normalize_date_input

logger = logging.getLogger(__name__)


class VersionedTimeSeriesReader(VersionedTimeSeriesBase):
    """
    Versioned read-only interface for time series data retrieval.
    
    Provides methods for querying time series data, metadata, and selectors
    across different versions without the ability to modify data. This class
    is safe for read-only operations and can be used to compare data across
    different versions.
    
    Features:
    - Version-aware data retrieval
    - Cross-version data comparison
    - Version-specific metadata queries
    - Historical data analysis
    """
    
    def get_series_data(self, series_id: Optional[int] = None, 
                       ticker: Optional[str] = None, field: Optional[str] = None,
                       source: Optional[str] = None, frequency: Optional[str] = None,
                       start_date: DateInput = None, end_date: DateInput = None,
                       version: Optional[str] = None) -> pd.DataFrame:
        """
        Retrieve time series data from a specific version.
        
        Args:
            series_id: Specific series ID to retrieve
            ticker: Filter by ticker (if series_id not provided)
            field: Filter by field (if series_id not provided)
            source: Filter by source (if series_id not provided)
            frequency: Filter by frequency (if series_id not provided)
            start_date: Start date for data retrieval
            end_date: End date for data retrieval
            version: Version to retrieve data from (None for current)
            
        Returns:
            pd.DataFrame: Time series data
        """
        try:
            # Use versioned session manager if available
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                if series_id is None:
                    # Need to find series_id from metadata
                    metadata = self.get_metadata(
                        ticker=ticker, field=field, source=source, 
                        frequency=frequency, version=version
                    )
                    if metadata.empty:
                        return pd.DataFrame()
                    # Convert numpy.int64 to Python int for pyodbc compatibility
                    series_id = metadata.iloc[0]['id']
                    if hasattr(series_id, 'item'):
                        series_id = series_id.item()
                    else:
                        series_id = int(series_id)
                
                # Get data using versioned session manager
                data = self.versioned_session_manager.get_ts_data_versioned(
                    series_id, version, start_date, end_date
                )
                
                if not data:
                    return pd.DataFrame()
                
                df = pd.DataFrame(data)
                df['date'] = pd.to_datetime(df['date'])
                return df.set_index('date')
            else:
                # Fallback to standard session manager
                return self.session_manager.get_ts_data(
                    series_id, ticker, field, source, frequency, start_date, end_date
                )
                
        except Exception as e:
            logger.error(f"Failed to get series data for version {version}: {e}")
            raise
    
    def get_metadata(self, id: Optional[int] = None, ticker: Optional[str] = None,
                    field: Optional[str] = None, source: Optional[str] = None,
                    frequency: Optional[str] = None, currency: Optional[str] = None,
                    version: Optional[str] = None) -> pd.DataFrame:
        """
        Retrieve time series metadata from a specific version.
        
        Args:
            id: Specific series ID to retrieve
            ticker: Filter by ticker
            field: Filter by field
            source: Filter by source
            frequency: Filter by frequency
            currency: Filter by currency
            version: Version to retrieve metadata from (None for current)
            
        Returns:
            pd.DataFrame: Time series metadata
        """
        try:
            # Use versioned session manager if available
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                # Build filters using full column names (not abbreviated)
                filters = {}
                if id is not None:
                    filters['id'] = id
                if ticker is not None:
                    filters['ticker'] = ticker.upper()
                if field is not None:
                    filters['field'] = field.upper()
                if source is not None:
                    # Normalize source to source code
                    # SOURCE_CODE_MAP is only for feed sources (BB, DS, FRED)
                    # Other sources are normalized to uppercase (up to column limit of 6 chars)
                    source_lower = source.lower()
                    if source_lower in SOURCE_ALIASES:
                        source_lower = SOURCE_ALIASES[source_lower]
                    filters['source'] = SOURCE_CODE_MAP.get(source_lower, source_lower.upper()[:6])
                if frequency is not None:
                    filters['frequency'] = frequency.upper()
                if currency is not None:
                    filters['currency'] = currency.upper()
                
                # Get metadata using versioned session manager
                metadata = self.versioned_session_manager.get_ts_metadata_versioned(version, **filters)
                
                if not metadata:
                    return pd.DataFrame()
                
                return pd.DataFrame(metadata)
            else:
                # Fallback to standard session manager
                return self.session_manager.get_ts_metadata(
                    id=id, ticker=ticker, field=field, source=source,
                    frequency=frequency, currency=currency
                )
                
        except Exception as e:
            logger.error(f"Failed to get metadata for version {version}: {e}")
            raise
    
    def get_selector_data(self, selector_name: str, start_date: DateInput = None,
                         end_date: DateInput = None, return_as: Union[str, ReturnHandler] = "auto",
                         version: Optional[str] = None, verbose: bool = False) -> Any:
        """
        Get data for all series in a selector from a specific version.
        
        Args:
            selector_name: Name of the selector
            start_date: Start date filter (optional)
            end_date: End date filter (optional)
            return_as: Return format string or callable (see MasTimeSeriesReader)
            version: Version to retrieve data from (None for current)
            verbose: If True, print progress info
            
        Returns:
            Data in requested format (DataFrame/dict/grouped/etc.)
        """
        try:
            if callable(return_as):
                return_handler = return_as
                return_format = "dict"
            else:
                return_handler = None
                return_format = return_as or "auto"

            start_date = normalize_date_input(start_date, '%Y-%m-%d')
            end_date = normalize_date_input(end_date, '%Y-%m-%d')

            selector_info = self.get_selector_info(selector_name, version)
            if selector_info.empty:
                logger.warning(f"No series found in selector: {selector_name} (version={version})")
                return None

            selector_info = selector_info.copy()
            selector_info.columns = [str(col).lower() for col in selector_info.columns]

            return_parts = return_format.split('.')
            base_format = return_parts[0]
            sub_format = return_parts[1] if len(return_parts) > 1 else None

            if base_format in ["grp", "group"]:
                result = self._build_selector_dataset_by_group_versioned(
                    selector_info,
                    version,
                    start_date,
                    end_date,
                    sub_format or "df",
                    verbose
                )
            else:
                result = self._build_selector_dataset_versioned(
                    selector_info,
                    version,
                    start_date,
                    end_date,
                    return_format,
                    verbose
                )

            if return_handler:
                return return_handler(result)

            return result

        except Exception as e:
            logger.error(f"Failed to get selector data for {selector_name} version {version}: {e}")
            raise

    def query_series_with_lag(
        self,
        series_id: Optional[int] = None,
        ticker: Optional[str] = None,
        field: Optional[str] = None,
        source: Optional[str] = None,
        frequency: Optional[str] = None,
        start_date: DateInput = None,
        end_date: DateInput = None,
        version: Optional[str] = None,
        use_lag: bool = True,
        align: Optional[str] = None,
        label: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Query a versioned time series applying lag offsets and alignment rules.
        """
        align_norm = _normalize_frequency_value(align)
        if align_norm not in (None, 'EOM'):
            raise ValueError("align must be None or 'EOM'")

        start_date = normalize_date_input(start_date, '%Y-%m-%d')
        end_date = normalize_date_input(end_date, '%Y-%m-%d')

        metadata_filters: Dict[str, Any] = {}
        if series_id is not None:
            metadata_filters['id'] = series_id
        else:
            if ticker:
                metadata_filters['ticker'] = ticker
            if field:
                metadata_filters['field'] = field
            if source:
                metadata_filters['source'] = source
            if frequency:
                metadata_filters['frequency'] = frequency

        metadata = self.get_metadata(version=version, **metadata_filters)
        if metadata.empty:
            raise ValueError("Unable to locate series metadata with provided filters for the specified version.")

        meta_row = metadata.iloc[0]
        resolved_series_id = int(meta_row['id'])
        freq_code = meta_row.get('frequency') or meta_row.get('frq')  # Prefer full name, fallback to abbreviated
        column_label = label or meta_row.get('cname') or meta_row.get('field') or meta_row.get('fld') or f"series_{resolved_series_id}"

        data_table = self.get_table_name_for_version('TS_Data', version)
        meta_table = self.get_table_name_for_version('TS_Meta', version)

        where_clauses = ["d.id = :series_id"]
        params: Dict[str, Any] = {'series_id': resolved_series_id}

        if start_date:
            where_clauses.append("d.date >= :start_date")
            params['start_date'] = start_date
        if end_date:
            where_clauses.append("d.date <= :end_date")
            params['end_date'] = end_date

        where_clause = " AND ".join(where_clauses)
        date_expr = _build_date_expression_sql(use_lag, align_norm)
        collapse_to_month = _needs_monthly_collapse(freq_code, target='M')
        sql = _build_lagged_query_sql(date_expr, data_table, meta_table, where_clause, collapse_to_month)

        with self.db_manager.get_session() as session:
            result = session.execute(text(sql), params).fetchall()

        if not result:
            empty_df = pd.DataFrame(columns=[column_label])
            empty_df.index.name = 'date'
            return empty_df

        df = pd.DataFrame(result, columns=['date', column_label])
        df['date'] = pd.to_datetime(df['date'])
        return df.set_index('date')
    
    def get_selector_info(self, selector_name: str, version: Optional[str] = None) -> pd.DataFrame:
        """
        Get selector information from a specific version.
        
        Args:
            selector_name: Name of the selector
            version: Version to retrieve selector info from (None for current)
            
        Returns:
            pd.DataFrame: Selector information
        """
        try:
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                # Use versioned session manager
                from sqlalchemy import text

                table_name = self.versioned_session_manager.get_table_name_for_version('TS_Selector', version)
                
                sql = text(f"SELECT * FROM {table_name} WHERE sel = :selector_name ORDER BY ord")
                
                with self.versioned_session_manager.get_session(version) as session:
                    result = session.execute(sql, {'selector_name': selector_name}).fetchall()
                    
                    if not result:
                        return pd.DataFrame()
                    
                    return pd.DataFrame([dict(row._mapping) for row in result])
            else:
                # Fallback to standard session manager
                return self.session_manager.execute_sql(
                    "SELECT * FROM TS_Selector WHERE sel = :selector_name ORDER BY ord",
                    {"selector_name": selector_name}
                )
                
        except Exception as e:
            logger.error(f"Failed to get selector info for {selector_name} version {version}: {e}")
            raise
    
    def compare_series_across_versions(self, series_id: int, version1: str, version2: str) -> Dict[str, Any]:
        """
        Compare a series across two versions.
        
        Args:
            series_id: Series ID to compare
            version1: First version
            version2: Second version
            
        Returns:
            Dict[str, Any]: Comparison results
        """
        try:
            # Get data from both versions
            data1 = self.get_series_data(series_id=series_id, version=version1)
            data2 = self.get_series_data(series_id=series_id, version=version2)
            
            # Get metadata from both versions
            meta1 = self.get_metadata(id=series_id, version=version1)
            meta2 = self.get_metadata(id=series_id, version=version2)
            
            comparison = {
                'series_id': series_id,
                'version1': version1,
                'version2': version2,
                'data_comparison': {
                    'version1_records': len(data1),
                    'version2_records': len(data2),
                    'common_dates': len(data1.index.intersection(data2.index)),
                    'version1_only_dates': len(data1.index.difference(data2.index)),
                    'version2_only_dates': len(data2.index.difference(data1.index))
                },
                'metadata_comparison': {
                    'version1_metadata': meta1.to_dict('records')[0] if not meta1.empty else {},
                    'version2_metadata': meta2.to_dict('records')[0] if not meta2.empty else {}
                }
            }
            
            # Compare values for common dates
            if not data1.empty and not data2.empty:
                common_dates = data1.index.intersection(data2.index)
                if len(common_dates) > 0:
                    common_data1 = data1.loc[common_dates]
                    common_data2 = data2.loc[common_dates]
                    
                    # Calculate differences
                    if len(common_data1.columns) > 0 and len(common_data2.columns) > 0:
                        col1 = common_data1.columns[0]
                        col2 = common_data2.columns[0]
                        
                        differences = (common_data1[col1] - common_data2[col2]).dropna()
                        comparison['data_comparison']['value_differences'] = {
                            'mean_absolute_difference': float(differences.abs().mean()) if len(differences) > 0 else 0,
                            'max_absolute_difference': float(differences.abs().max()) if len(differences) > 0 else 0,
                            'total_differences': len(differences)
                        }
            
            return comparison
            
        except Exception as e:
            logger.error(f"Failed to compare series {series_id} across versions {version1} and {version2}: {e}")
            raise
    
    def get_version_summary(self, version: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a summary of data in a specific version.
        
        Args:
            version: Version to get summary for (None for current)
            
        Returns:
            Dict[str, Any]: Version summary
        """
        try:
            if hasattr(self, 'versioned_session_manager') and self.versioned_session_manager:
                stats = self.versioned_session_manager.get_version_statistics(version)
                
                # Get additional metadata
                metadata = self.get_metadata(version=version)
                
                summary = {
                    'version': self._display_version(version),
                    'statistics': stats,
                    'metadata_summary': {
                        'total_series': len(metadata),
                        'sources': (metadata['source'].value_counts().to_dict() 
                                   if not metadata.empty and 'source' in metadata.columns 
                                   else (metadata['src'].value_counts().to_dict() if 'src' in metadata.columns else {})),
                        'frequencies': (metadata['frequency'].value_counts().to_dict() 
                                      if not metadata.empty and 'frequency' in metadata.columns 
                                      else (metadata['frq'].value_counts().to_dict() if 'frq' in metadata.columns else {})),
                        'currencies': (metadata['currency'].value_counts().to_dict() 
                                      if not metadata.empty and 'currency' in metadata.columns 
                                      else (metadata['ccy'].value_counts().to_dict() if 'ccy' in metadata.columns else {}))
                    }
                }
                
                return summary
            else:
                # Fallback to standard approach
                return {
                    'version': self._display_version(version),
                    'error': 'Versioned session manager not available'
                }
                
        except Exception as e:
            logger.error(f"Failed to get version summary for {version}: {e}")
            return {
                'version': self._display_version(version),
                'error': str(e)
            }
    
    def list_available_versions(self) -> List[str]:
        """
        List all available versions.
        
        Returns:
            List[str]: List of available versions
        """
        return self.get_available_versions()
    
    def get_version_info(self, version: Optional[str] = None) -> Dict[str, Any]:
        """
        Get detailed information about a specific version.
        
        Args:
            version: Version to get info for (None for current)
            
        Returns:
            Dict[str, Any]: Version information
        """
        return super().get_version_info(version)

    # ------------------------------------------------------------------
    # Internal helpers for selector data assembly
    # ------------------------------------------------------------------
    def _build_selector_dataset_versioned(
        self,
        selector_info: pd.DataFrame,
        version: Optional[str],
        start_date: Optional[str],
        end_date: Optional[str],
        return_as: str = "auto",
        verbose: bool = False,
    ) -> Any:
        """Assemble selector data for a single group."""
        data = {}
        total_series = len(selector_info)

        for i, row in enumerate(selector_info.itertuples(index=False), start=1):
            series_id = getattr(row, 'id', getattr(row, 'ID', None))
            if series_id is None:
                continue

            colname = getattr(row, 'colname', None) or getattr(row, 'COLNAME', None) or f"series_{series_id}"

            if verbose:
                print(f"  [{i:3d}/{total_series:3d}] Retrieving {colname} (ID: {series_id})...")

            series_df = self.get_series_data(
                series_id=series_id,
                start_date=start_date,
                end_date=end_date,
                version=version
            )

            if series_df.empty:
                if verbose:
                    print("      ⚠ No data found")
                continue

            series = series_df['value'] if 'value' in series_df.columns else series_df.iloc[:, 0]
            data[colname] = series

            if verbose:
                print(f"      ✓ Retrieved {len(series)} observations")

        if not data:
            return {} if return_as in ("dict", "dictionary") else pd.DataFrame()

        if return_as in ("dict", "dictionary"):
            return data

        # Default to DataFrame (auto/df/dataframe)
        return pd.DataFrame(data)

    def _build_selector_dataset_by_group_versioned(
        self,
        selector_info: pd.DataFrame,
        version: Optional[str],
        start_date: Optional[str],
        end_date: Optional[str],
        sub_format: Optional[str] = "df",
        verbose: bool = False,
    ) -> Dict[str, Any]:
        """Assemble selector data grouped by the selector grp column."""
        grp_column = 'grp' if 'grp' in selector_info.columns else ('GRP' if 'GRP' in selector_info.columns else None)

        if grp_column is None:
            # Fallback: treat entire selector as one group
            return {
                'default': self._build_selector_dataset_versioned(
                    selector_info, version, start_date, end_date, sub_format or "df", verbose
                )
            }

        result = {}
        for grp_value, group_df in selector_info.groupby(grp_column):
            result[str(grp_value)] = self._build_selector_dataset_versioned(
                group_df,
                version,
                start_date,
                end_date,
                sub_format or "df",
                verbose
            )

        return result
    
    def get_meta_plus_data(self, series_ids: Optional[List[int]] = None, 
                          sources: Optional[List[str]] = None, 
                          tickers: Optional[List[str]] = None,
                          fields: Optional[List[str]] = None,
                          version: Optional[str] = None) -> pd.DataFrame:
        """
        Get data from TS_MetaPlus view using SQLAlchemy model for a specific version.
        
        This method queries the TS_MetaPlus database view which joins TS_Meta and TS_Status tables.
        
        Args:
            series_ids: List of series IDs to filter by (optional)
            sources: List of sources to filter by (e.g., ['BB', 'DS', 'FRED']) (optional)
            tickers: List of ticker symbols to filter by (optional)
            fields: List of fields to filter by (optional)
            version: Version identifier (None for current)
            
        Returns:
            DataFrame with columns from both TS_Meta and TS_Status tables
        """
        try:
            models = self.versioned_session_manager.get_models_for_version(version)
            TimeSeriesMetaPlus = models.get('TimeSeriesMetaPlus')
            
            if TimeSeriesMetaPlus is None:
                logger.error(f"TimeSeriesMetaPlus model not found for version {version}")
                return pd.DataFrame()
            
            # Build optimized query using direct SQL
            stmt = select(TimeSeriesMetaPlus)
            
            # Apply filters using 'in_' for all filters
            if series_ids:
                stmt = stmt.where(TimeSeriesMetaPlus.id.in_(series_ids))
            
            if sources:
                stmt = stmt.where(TimeSeriesMetaPlus.source.in_(sources))
            
            if tickers:
                stmt = stmt.where(TimeSeriesMetaPlus.ticker.in_(tickers))
            
            if fields:
                stmt = stmt.where(TimeSeriesMetaPlus.field.in_(fields))
            
            # Execute query using versioned session manager
            with self.versioned_session_manager.get_session(version) as session:
                result_df = pd.read_sql(stmt, session.bind)
            
            return result_df
                
        except Exception as e:
            logger.error(f"Failed to get TS_MetaPlus data for version {version}: {e}")
            return pd.DataFrame()
    
    def get_meta_plus_by_selector(self, selector_name: str, version: Optional[str] = None) -> pd.DataFrame:
        """
        Get TS_MetaPlus data for all series in a specific selector for a specific version.
        
        Args:
            selector_name: Name of the selector
            version: Version identifier (None for current)
            
        Returns:
            DataFrame with metadata and status information for selector series
        """
        try:
            # First get the series IDs from the selector
            selector_info = self.get_selector_series_info(selector_name, version=version)
            
            if selector_info.empty:
                logger.warning(f"No series found in selector '{selector_name}' for version {version}")
                return pd.DataFrame()
            
            series_ids = selector_info['id'].tolist()
            
            # Get the metadata plus data for these series
            return self.get_meta_plus_data(series_ids=series_ids, version=version)
            
        except Exception as e:
            logger.error(f"Failed to get TS_MetaPlus data for selector '{selector_name}' (version {version}): {e}")
            return pd.DataFrame()
    
    def get_selector_meta_plus_data(self, selector_names: Union[str, List[str]], 
                                   version: Optional[str] = None) -> pd.DataFrame:
        """
        Get series information for one or more selectors using TimeSeriesSelectorMetaPlus view.
        
        This method queries the TS_SelectorMetaPlus database view which joins TS_Selector,
        TS_Meta, and TS_Status tables, providing a unified interface for accessing
        selector information along with metadata and status.
        
        Args:
            selector_names: Single selector name or list of selector names
            version: Version identifier (None for current)
            
        Returns:
            DataFrame with selector, metadata, and status information
        """
        try:
            # Handle both single string and list of strings
            if isinstance(selector_names, str):
                selector_names = [selector_names]
            
            # Get versioned model
            models = self.versioned_session_manager.get_models_for_version(version)
            TimeSeriesSelectorMetaPlus = models.get('TimeSeriesSelectorMetaPlus')
            
            if TimeSeriesSelectorMetaPlus is None:
                logger.error(f"TimeSeriesSelectorMetaPlus model not found for version {version}")
                return pd.DataFrame()
            
            # Build SQLAlchemy query using TimeSeriesSelectorMetaPlus view (no joins needed)
            with self.versioned_session_manager.get_session(version) as session:
                stmt = (
                    select(TimeSeriesSelectorMetaPlus)
                    .where(TimeSeriesSelectorMetaPlus.sel.in_(selector_names))
                    .order_by(TimeSeriesSelectorMetaPlus.sel, TimeSeriesSelectorMetaPlus.grp, TimeSeriesSelectorMetaPlus.ord)
                )
                result_df = pd.read_sql(stmt, session.bind)
            
            return result_df
            
        except Exception as e:
            logger.error(f"Failed to get selector meta plus data for version {version}: {e}")
            return pd.DataFrame()
