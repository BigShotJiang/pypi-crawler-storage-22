use std::fmt::{self, Write};
use std::ops::Range;

use strum_macros::IntoStaticStr;

// use no_panic::no_panic;

use crate::MathDisplay;
use crate::environments::Env;
use crate::html_utils::{escape_double_quoted_html_attribute, escape_html_content};
use crate::token::EndToken;

/// Represents an error that occurred during LaTeX parsing or rendering.
#[derive(Debug, Clone)]
pub struct LatexError(pub Range<usize>, pub LatexErrKind);

#[derive(Debug, Clone)]
#[non_exhaustive]
pub enum LatexErrKind {
    UnclosedGroup(EndToken),
    UnmatchedClose(EndToken),
    ExpectedArgumentGotClose,
    ExpectedArgumentGotEOF,
    ExpectedDelimiter(DelimiterModifier),
    DisallowedChar(char),
    UnknownEnvironment(Box<str>),
    UnknownCommand(Box<str>),
    UnknownColor(Box<str>),
    MismatchedEnvironment {
        expected: Env,
        got: Env,
    },
    CannotBeUsedHere {
        got: LimitedUsabilityToken,
        correct_place: Place,
    },
    ExpectedRelation,
    BoundFollowedByBound,
    DuplicateSubOrSup,
    ExpectedText(&'static str),
    ExpectedLength(Box<str>),
    ExpectedColSpec(Box<str>),
    ExpectedNumber(Box<str>),
    NotValidInTextMode,
    InvalidMacroName(String),
    InvalidParameterNumber,
    MacroParameterOutsideCustomCommand,
    ExpectedParamNumberGotEOF,
    HardLimitExceeded,
    Internal,
}

#[derive(Debug, Clone, Copy, PartialEq, IntoStaticStr)]
pub enum DelimiterModifier {
    #[strum(serialize = r"\left")]
    Left,
    #[strum(serialize = r"\right")]
    Right,
    #[strum(serialize = r"\middle")]
    Middle,
    #[strum(serialize = r"\big, \Big, ...")]
    Big,
}

#[derive(Debug, Clone, Copy, PartialEq, IntoStaticStr)]
#[repr(u32)] // A different value here somehow increases code size on WASM enormously.
pub enum Place {
    #[strum(serialize = r"after \int, \sum, ...")]
    AfterBigOp,
    #[strum(serialize = r"in a table-like environment")]
    TableEnv,
    #[strum(serialize = r"in a numbered equation environment")]
    NumberedEnv,
}

#[derive(Debug, Clone, Copy, PartialEq, IntoStaticStr)]
pub enum LimitedUsabilityToken {
    #[strum(serialize = "&")]
    Ampersand,
    #[strum(serialize = r"\tag")]
    Tag,
    #[strum(serialize = r"\limits")]
    Limits,
}

impl LatexErrKind {
    /// Returns the error message as a string.
    ///
    /// This serves the same purpose as the `Display` implementation,
    /// but produces more compact WASM code.
    pub fn string(&self) -> String {
        match self {
            LatexErrKind::UnclosedGroup(expected) => {
                "Expected token \"".to_string() + <&str>::from(expected) + "\", but not found."
            }
            LatexErrKind::UnmatchedClose(got) => {
                "Unmatched closing token: \"".to_string() + <&str>::from(got) + "\"."
            }
            LatexErrKind::ExpectedArgumentGotClose => {
                r"Expected argument but got closing token (`}`, `\end`, `\right`).".to_string()
            }
            LatexErrKind::ExpectedArgumentGotEOF => "Expected argument but reached end of input.".to_string(),
            LatexErrKind::ExpectedDelimiter(location) => {
                "There must be a parenthesis after \"".to_string()
                    + <&str>::from(*location)
                    + "\", but not found."
            }
            LatexErrKind::DisallowedChar(got) => {
                let mut text = "Disallowed character in text group: '".to_string();
                text.push(*got);
                text += "'.";
                text
            }
            LatexErrKind::UnknownEnvironment(environment) => {
                "Unknown environment \"".to_string() + environment + "\"."
            }
            LatexErrKind::UnknownCommand(cmd) => "Unknown command \"\\".to_string() + cmd + "\".",
            LatexErrKind::UnknownColor(color) => "Unknown color \"".to_string() + color + "\".",
            LatexErrKind::MismatchedEnvironment { expected, got } => {
                "Expected \"\\end{".to_string()
                    + expected.as_str()
                    + "}\", but got \"\\end{"
                    + got.as_str()
                    + "}\"."
            }
            LatexErrKind::CannotBeUsedHere { got, correct_place } => {
                "Got \"".to_string()
                    + <&str>::from(got)
                    + "\", which may only appear "
                    + <&str>::from(correct_place)
                    + "."
            }
            LatexErrKind::ExpectedRelation => {
                "Expected a relation after \\not.".to_string()
            }
            LatexErrKind::BoundFollowedByBound => {
                "'^' or '_' directly followed by '^', '_' or prime.".to_string()
            }
            LatexErrKind::DuplicateSubOrSup => {
                "Duplicate subscript or superscript.".to_string()
            }
            LatexErrKind::ExpectedText(place) => "Expected text in ".to_string() + place + ".",
            LatexErrKind::ExpectedLength(got) => {
                "Expected length with units, got \"".to_string() + got + "\"."
            }
            LatexErrKind::ExpectedNumber(got) => "Expected a number, got \"".to_string() + got + "\".",
            LatexErrKind::ExpectedColSpec(got) => {
                "Expected column specification, got \"".to_string() + got + "\"."
            }
            LatexErrKind::NotValidInTextMode => {
                "Not valid in text mode.".to_string()
            }
            LatexErrKind::InvalidMacroName(name) => {
                "Invalid macro name: \"\\".to_string() + name + "\"."
            }
            LatexErrKind::InvalidParameterNumber => {
                "Invalid parameter number. Must be 1-9.".to_string()
            }
            LatexErrKind::MacroParameterOutsideCustomCommand => {
                "Macro parameter found outside of custom command definition.".to_string()
            }
            LatexErrKind::ExpectedParamNumberGotEOF => {
                "Expected parameter number after '#', but got end of input.".to_string()
            }
            LatexErrKind::HardLimitExceeded => {
                "Hard limit exceeded. Please simplify your equation.".to_string()
            }
            LatexErrKind::Internal => {
                "Internal parser error. Please report this bug at https://github.com/tmke8/math-core/issues".to_string()
            },
        }
    }
}

impl LatexError {
    /// Format a LaTeX error as an HTML snippet.
    ///
    /// # Arguments
    /// - `latex`: The original LaTeX input that caused the error.
    /// - `display`: The display mode of the equation (inline or block).
    /// - `css_class`: An optional CSS class to apply to the error element. If `None`,
    ///   defaults to `"math-core-error"`.
    pub fn to_html(&self, latex: &str, display: MathDisplay, css_class: Option<&str>) -> String {
        let mut output = String::new();
        let tag = if matches!(display, MathDisplay::Block) {
            "p"
        } else {
            "span"
        };
        let css_class = css_class.unwrap_or("math-core-error");
        let _ = write!(
            output,
            r#"<{} class="{}" title="{}: "#,
            tag, css_class, self.0.start
        );
        escape_double_quoted_html_attribute(&mut output, &self.1.string());
        output.push_str(r#""><code>"#);
        escape_html_content(&mut output, latex);
        let _ = write!(output, "</code></{tag}>");
        output
    }
}

impl fmt::Display for LatexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.0.start, self.1.string())
    }
}

impl std::error::Error for LatexError {}

pub trait GetUnwrap {
    /// `str::get` with `Option::unwrap`.
    fn get_unwrap(&self, range: std::ops::Range<usize>) -> &str;
}

impl GetUnwrap for str {
    #[cfg(target_arch = "wasm32")]
    #[inline]
    fn get_unwrap(&self, range: std::ops::Range<usize>) -> &str {
        // On WASM, panics are really expensive in terms of code size,
        // so we use an unchecked get here.
        unsafe { self.get_unchecked(range) }
    }
    #[cfg(not(target_arch = "wasm32"))]
    #[inline]
    fn get_unwrap(&self, range: std::ops::Range<usize>) -> &str {
        self.get(range).expect("valid range")
    }
}

/* fn itoa(val: u64, buf: &mut [u8; 20]) -> &str {
    let start = if val == 0 {
        buf[19] = b'0';
        19
    } else {
        let mut val = val;
        let mut i = 20;

        // The `i > 0` check is technically redundant but it allows the compiler to
        // prove that `buf` is always validly indexed.
        while val != 0 && i > 0 {
            i -= 1;
            buf[i] = (val % 10) as u8 + b'0';
            val /= 10;
        }
        i
    };

    // This is safe because we know the buffer contains valid ASCII.
    // This unsafe block wouldn't be necessary if the `ascii_char` feature were stable.
    unsafe { std::str::from_utf8_unchecked(&buf[start..]) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn itoa_test() {
        let mut buf = [0u8; 20];
        assert_eq!(itoa(0, &mut buf), "0");
        assert_eq!(itoa(1, &mut buf), "1");
        assert_eq!(itoa(10, &mut buf), "10");
        assert_eq!(itoa(1234567890, &mut buf), "1234567890");
        assert_eq!(itoa(u64::MAX, &mut buf), "18446744073709551615");
    }
} */
