# MathDB 内存库持久化设计文档 v2.0

> **文档版本**: v2.0  
> **编写日期**: 2026-01-31  
> **状态**: 待评审  
> **更新说明**: 借鉴 memdb Java 项目设计，增加 YAML 配置管理、容器化 MathDB、一站式恢复

---

## 1. 设计目标

### 1.1 核心目标

将 **Polars DataFrame** 或 **Pandas DataFrame** 作为**内存数据库**使用，提供类似 memdb 的一站式使用体验：

| 特性 | 说明 |
|------|------|
| **读性能** | 所有读请求直接走内存，利用 Polars/Pandas 的查询能力 |
| **写一致性** | 单表内写入顺序一致，采用单写入者模式串行化 |
| **持久化** | WAL 段 + 快照机制，保证已落盘数据可恢复 |
| **丢失窗口** | 可容忍最多 **≤3秒** 的最新写入丢失（异步刷盘） |
| **配置化** | YAML 配置文件统一管理 schema 和运行时参数 |
| **容器化** | 全局 MathDB 管理器，统一管理多表生命周期 |
| **一站式恢复** | 启动时自动恢复，无需手动调用恢复方法 |
| **双后端支持** | 支持 Polars 和 Pandas 两种底层数据分析容器 |
| **Schema 反向生成** | 从已有表数据反向生成 YAML Schema 定义 |

### 1.2 双后端支持 (Polars / Pandas)

MathDB 2.0 支持两种底层数据分析容器，用户可根据需求选择：

| 后端 | 优势 | 适用场景 |
|--------|------|----------|
| **Polars** | 列式存储、高性能、多线程并行、低内存占用 | 大数据量、高性能计算、ETL 管道 |
| **Pandas** | 生态成熟、兼容性强、学习曲线低 | 现有 Pandas 项目迁移、快速原型 | 

#### 1.2.1 后端抽象设计

```
┌─────────────────────────────────────────────────────────────┐
│                        Table API                            │
│   insert() / update() / delete() / upsert()                 │
│   get() / query() / to_dataframe() / scan()                 │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Backend Protocol                          │
│   抽象接口: DataFrame 操作、序列化、反序列化                  │
└─────────────────────────────────────────────────────────────┘
                              │
          ┌─────────────────┴─────────────────┐
          ▼                                   ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│     PolarsBackend         │     │     PandasBackend         │
│   pl.DataFrame            │     │   pd.DataFrame            │
│   pl.LazyFrame            │     │   原生 Pandas API          │
│   Arrow IPC 序列化          │     │   Parquet/Arrow 序列化     │
└─────────────────────────┘     └─────────────────────────┘
```

#### 1.2.2 后端配置

```yaml
mathdb:
  # 后端选择: polars | pandas
  backend: "polars"
  
  # 其他配置...
```

```python
from mathdb import MathDB, BackendType

# 方式 1: YAML 配置
MathDB.init("mathdb.yaml")  # backend: polars 在 YAML 中配置

# 方式 2: 编程方式
MathDB.init(backend=BackendType.PANDAS)
MathDB.init(backend=BackendType.POLARS)  # 默认
```

### 1.3 借鉴 memdb 的设计理念

从 memdb Java 项目中借鉴以下核心设计：

1. **统一配置管理**: 类似 `MemDBConfig`，通过 YAML 配置文件集中管理所有配置
2. **Schema 文件加载**: 类似 `loadSchema()`，从 YAML 加载表结构定义
3. **全局管理器**: 类似 `MemDB` 静态类，提供 `MathDB` 全局入口
4. **容器化获取表**: 类似 `MemDB.getTable()`，通过表名或类型获取表实例
5. **一站式初始化与恢复**: `init()` 自动完成恢复，用户无感知

---

## 2. 架构设计

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────────────────────┐
│                           MathDB (全局管理器)                       │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │                      MathDBConfig                          │     │
│  │   - YAML 加载配置                                             │     │
│  │   - WAL/Snapshot/Recovery 配置                                │     │
│  │   - Schema 定义路径                                           │     │
│  └─────────────────────────────────────────────────────────────┘     │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │                      表容器 (tables_by_name)                  │     │
│  │   "users" -> Table<users>                               │     │
│  │   "orders" -> Table<orders>                             │     │
│  │   "products" -> Table<products>                         │     │
│  └─────────────────────────────────────────────────────────────┘     │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │                      共享组件                                 │     │
│  │   - SnapshotManager (快照管理)                                │     │
│  │   - RecoveryManager (恢复管理)                                │     │
│  └─────────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │   磁盘: WAL + Snapshots       │
              │   ./data/{table_name}/        │
              │     ├── wal/                  │
              │     ├── snapshots/            │
              │     └── metadata.json         │
              └───────────────────────────────┘
```

### 2.2 核心组件

| 组件 | 职责 | 对应 memdb |
|------|------|-----------|
| `MathDB` | 全局管理器，表容器，统一入口 | `MemDB` |
| `MathDBConfig` | 配置对象，支持 YAML 加载 | `MemDBConfig` |
| `Table` | 单表实例，CRUD + 查询 | `MemTable` |
| `TableSchema` | 表结构定义（列、主键） | `TableSchema` || `Backend` | 后端抽象层 (Polars/Pandas) | - |
| `PolarsBackend` | Polars 后端实现 | - |
| `PandasBackend` | Pandas 后端实现 | - || `TableInfo` | 表配置信息（用于 YAML） | `TableInfo` |
| `SchemaInfo` | Schema 配置文件结构 | `SchemaInfo` |
| `Flusher` | WAL 刷盘器 | `WALWriter` |
| `Snapshotter` | 快照管理 | `SnapshotManager` |
| `Recovery` | 恢复管理 | 内置于 `MemDB.init()` |

---

## 3. 配置管理

### 3.1 配置文件结构

**polarsdb.yaml** - 主配置文件：

```yaml
mathdb:
  # 数据库名称
  name: "my-mathdb"
  
  # 后端选择: polars | pandas
  backend: "polars"
  
  # 数据存储目录
  data_dir: "./data"
  
  # Schema 配置文件路径（从此文件加载表结构）
  schema_path: "schema.yaml"
  
  # WAL 配置
  wal:
    enabled: true
    flush_interval: 3.0  # 刷盘间隔（秒）
    sync_on_flush: false  # 是否每次刷盘都 fsync
  
  # 快照配置
  snapshot:
    enabled: true
    auto_compact: true  # 自动压实
    compact_threshold: 100  # 达到多少个 WAL 段后压实
    max_snapshots: 3  # 保留的快照数量
  
  # 恢复配置
  recovery:
    enabled: true  # 启动时自动恢复
    mode: "auto"  # auto | snapshot_wal | snapshot_only
```

**schema.yaml** - 表结构定义：

```yaml
version: "1.0"

tables:
  # 用户表
  - table_name: users
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: username
        dtype: Utf8
      - name: email
        dtype: Utf8
      - name: age
        dtype: Int32
        nullable: true
      - name: created_at
        dtype: Datetime
        nullable: true
    metadata:
      description: "用户信息表"
      owner: "core-team"

  # 订单表
  - table_name: orders
    columns:
      - name: order_id
        dtype: Int64
        primary_key: true
      - name: user_id
        dtype: Int64
      - name: product_id
        dtype: Int64
      - name: quantity
        dtype: Int32
      - name: total_price
        dtype: Float64
      - name: status
        dtype: Utf8
      - name: order_time
        dtype: Datetime
    metadata:
      description: "订单表"
```

### 3.2 配置类设计

```python
from enum import Enum

class BackendType(Enum):
    """DataFrame 后端类型。"""
    POLARS = "polars"
    PANDAS = "pandas"


@dataclass
class MathDBConfig:
    """MathDB 统一配置。"""
    name: str = "mathdb"
    backend: BackendType = BackendType.POLARS  # 后端类型
    data_dir: Path = Path("./data")
    schema_path: Optional[str] = None
    
    # WAL 配置
    wal: WALConfig = field(default_factory=WALConfig)
    
    # 快照配置
    snapshot: SnapshotConfig = field(default_factory=SnapshotConfig)
    
    # 恢复配置
    recovery: RecoveryConfig = field(default_factory=RecoveryConfig)
    
    @classmethod
    def load(cls, config_path: str) -> "MathDBConfig":
        """从 YAML 文件加载配置。"""
        ...
    
    @classmethod
    def defaults(cls) -> "MathDBConfig":
        """创建默认配置。"""
        return cls()


@dataclass
class WALConfig:
    enabled: bool = True
    flush_interval: float = 3.0
    sync_on_flush: bool = False


@dataclass
class SnapshotConfig:
    enabled: bool = True
    auto_compact: bool = True
    compact_threshold: int = 100
    max_snapshots: int = 3


@dataclass  
class RecoveryConfig:
    enabled: bool = True
    mode: str = "auto"  # auto | snapshot_wal | snapshot_only
```

---

## 4. MathDB 全局管理器

### 4.1 设计理念

借鉴 memdb 的 `MemDB` 静态类设计，`MathDB` 作为全局入口：

- **单例模式**: 全局唯一实例
- **容器化管理**: 统一管理所有表的生命周期
- **一站式初始化**: `init()` 完成配置加载、Schema 加载、自动恢复
- **优雅关闭**: `close()` 刷盘所有待处理操作

### 4.2 API 设计

```python
class MathDB:
    """MathDB 全局管理器。
    
    使用方式类似 memdb 的 MemDB：
    
    ```python
    # 一站式初始化（自动恢复）
    MathDB.init("polarsdb.yaml")
    
    # 获取表
    users = MathDB.get_table("users")
    orders = MathDB.get_table("orders")
    
    # CRUD 操作
    users.insert({"id": 1, "username": "alice"})
    
    # 手动创建快照
    MathDB.create_snapshot()
    
    # 优雅关闭
    MathDB.close()
    ```
    """
    
    # ==================== 初始化 ====================
    
    @classmethod
    def init(cls, config: str | MathDBConfig = None) -> None:
        """初始化 MathDB。
        
        Args:
            config: 配置文件路径或配置对象。如果为 None，使用默认配置。
        
        功能：
        1. 加载配置
        2. 加载 Schema（如果配置了 schema_path）
        3. 自动恢复（如果配置了 recovery.enabled=True）
        """
        ...
    
    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化。"""
        ...
    
    # ==================== 表管理 ====================
    
    @classmethod
    def create_table(cls, schema: TableSchema) -> Table:
        """创建表。
        
        如果表已存在，抛出异常。
        """
        ...
    
    @classmethod
    def get_table(cls, name: str) -> Table:
        """获取表。
        
        Args:
            name: 表名
            
        Returns:
            Table 实例
            
        Raises:
            KeyError: 表不存在
        """
        ...
    
    @classmethod
    def get_table_or_none(cls, name: str) -> Optional[Table]:
        """获取表，不存在返回 None。"""
        ...
    
    @classmethod
    def table_exists(cls, name: str) -> bool:
        """检查表是否存在。"""
        ...
    
    @classmethod
    def drop_table(cls, name: str) -> bool:
        """删除表。"""
        ...
    
    @classmethod
    def list_tables(cls) -> list[str]:
        """列出所有表名。"""
        ...
    
    @classmethod
    def get_table_count(cls) -> int:
        """获取表数量。"""
        ...
    
    # ==================== Schema 管理 ====================
    
    @classmethod
    def load_schema(cls, schema_path: str) -> int:
        """从 YAML 文件加载 Schema 并创建表。
        
        Args:
            schema_path: Schema 文件路径
            
        Returns:
            创建的表数量
        """
        ...
    
    @classmethod
    def export_schema(cls, output_path: str = None, table_names: list[str] = None) -> str:
        """从已有表反向生成 YAML Schema 定义。
        
        类似 memdb 的 Schema 反向生成功能，根据现有表结构自动生成
        符合 MathDB 规范的 YAML Schema 文件。
        
        Args:
            output_path: 输出文件路径。如果为 None，仅返回 YAML 字符串不写入文件。
            table_names: 要导出的表名列表。如果为 None，导出所有表。
            
        Returns:
            生成的 YAML Schema 字符串
            
        Example:
            # 导出所有表 Schema 到文件
            MathDB.export_schema("schema_backup.yaml")
            
            # 仅获取特定表的 Schema 字符串
            yaml_str = MathDB.export_schema(table_names=["users", "orders"])
        """
        ...
    
    # ==================== 快照管理 ====================
    
    @classmethod
    def create_snapshot(cls, table_names: list[str] = None) -> Snapshot:
        """创建快照。
        
        Args:
            table_names: 要快照的表名列表。如果为 None，快照所有表。
            
        Returns:
            快照对象
        """
        ...
    
    @classmethod
    def restore_snapshot(cls, snapshot_id: str) -> RestoreResult:
        """恢复快照。"""
        ...
    
    @classmethod
    def list_snapshots(cls) -> list[SnapshotMetadata]:
        """列出所有快照。"""
        ...
    
    # ==================== 统计与管理 ====================
    
    @classmethod
    def get_statistics(cls) -> str:
        """获取数据库统计信息。"""
        ...
    
    @classmethod
    def close(cls) -> None:
        """关闭 MathDB。
        
        刷盘所有待处理操作，释放资源。
        """
        ...
    
    @classmethod
    def clear_all_data(cls) -> None:
        """清空所有表数据（保留表结构）。"""
        ...
    
    @classmethod
    def drop_all_tables(cls) -> None:
        """删除所有表。"""
        ...
```

### 4.3 使用示例

#### 方式 1：配置文件初始化（推荐）

```python
from mathdb import MathDB

# 一站式初始化（自动加载 Schema + 自动恢复）
MathDB.init("polarsdb.yaml")

# 直接使用表
users = MathDB.get_table("users")
users.insert({"id": 1, "username": "alice", "email": "alice@example.com", "age": 25})

# 查询
df = users.to_dataframe()
print(df.filter(pl.col("age") > 20))

# 优雅关闭
MathDB.close()
```

#### 方式 2：编程方式初始化

```python
from mathdb import MathDB, MathDBConfig, TableSchema, ColumnDef

# 编程方式配置
config = MathDBConfig(
    name="my-db",
    data_dir=Path("./data"),
    wal=WALConfig(flush_interval=1.0),
    recovery=RecoveryConfig(enabled=True),
)

MathDB.init(config)

# 手动创建表
schema = TableSchema(
    name="users",
    columns=[
        ColumnDef("id", "Int64", primary_key=True),
        ColumnDef("username", "Utf8"),
        ColumnDef("age", "Int32"),
    ],
)
users = MathDB.create_table(schema)

# 使用表...
users.insert({"id": 1, "username": "alice", "age": 25})

MathDB.close()
```

#### 方式 3：上下文管理器

```python
from mathdb import MathDB

with MathDB.context("polarsdb.yaml") as db:
    users = db.get_table("users")
    users.insert({"id": 1, "username": "alice"})
    
# 自动 close()
```

---

## 5. 数据恢复

### 5.1 恢复模式

| 模式 | 说明 |
|------|------|
| `auto` | 自动选择最佳恢复方式 |
| `snapshot_wal` | 先加载快照，再重放 WAL |
| `snapshot_only` | 只从快照恢复 |

### 5.2 自动恢复流程

```
MathDB.init("polarsdb.yaml")
         │
         ▼
┌─────────────────────┐
│  加载配置文件       │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  recovery.enabled?  │──No──▶ 加载 Schema 并创建空表
└─────────────────────┘
         │Yes
         ▼
┌─────────────────────┐
│  检查磁盘是否有     │
│  持久化数据         │
└─────────────────────┘
         │
    ┌────┴────┐
    │         │
  有数据    无数据
    │         │
    ▼         ▼
┌────────┐ ┌────────────┐
│ 恢复   │ │ 加载Schema │
│ 数据   │ │ 创建空表   │
└────────┘ └────────────┘
    │
    ▼
┌─────────────────────┐
│  1. 加载 Metadata   │
│  2. 加载 Snapshot   │
│  3. 重放 WAL 段     │
│  4. 验证 Schema     │
└─────────────────────┘
         │
         ▼
    恢复完成，表可用
```

### 5.3 1:1 落盘与恢复

每个表独立管理自己的持久化数据：

```
data/
├── users/               # users 表数据目录
│   ├── wal/
│   │   ├── seg_0001.arrow
│   │   └── seg_0002.arrow
│   ├── snapshots/
│   │   └── snapshot_0001.parquet
│   └── metadata.json
│
├── orders/              # orders 表数据目录
│   ├── wal/
│   │   └── seg_0001.arrow
│   ├── snapshots/
│   └── metadata.json
│
└── products/            # products 表数据目录
    ├── wal/
    ├── snapshots/
    └── metadata.json
```

**好处：**
- 表级别的独立恢复
- 表级别的独立快照
- 表级别的独立压实
- 便于备份和迁移单个表

---

## 6. 现有设计保留

### 6.1 继续保留的核心设计

以下来自 v1.0 设计的核心内容保持不变：

1. **单写入者模式** (WriterActor)
2. **WAL 段格式** (Arrow IPC)
3. **快照格式** (Parquet)
4. **CRUD 合并算法** (LWW + Anti-Join)
5. **原子写入** (tmp + rename)

### 6.2 Table API 保持兼容

```python
# CRUD API 与后端无关，始终一致
table = MathDB.get_table("users")

table.insert({"id": 1, "name": "Alice"})
table.update(pk=1, row={"id": 1, "name": "Alice Updated"})
table.delete(pk=1)
table.upsert({"id": 2, "name": "Bob"})

# 查询 API 根据后端返回不同类型
df = table.to_dataframe()  # Polars: pl.DataFrame, Pandas: pd.DataFrame

# Polars 后端特有
lf = table.scan()  # 返回 pl.LazyFrame
result = table.query(pl.col("age") > 25)

# Pandas 后端特有
result = table.query(lambda df: df[df["age"] > 25])
```

### 6.3 Table 级别 Schema 导出

```python
# 单表 Schema 导出
table = MathDB.get_table("users")

# 获取表的 Schema 定义
schema = table.export_schema()
print(schema)
# TableSchema(name='users', columns=[...], primary_key='id')

# 导出为 YAML 字符串
yaml_str = table.to_yaml_schema()
print(yaml_str)
```

---

## 7. Schema 反向生成

MathDB 2.0 借鉴 memdb 的设计，提供从已有表数据反向生成 Schema 定义的能力。

### 7.1 设计目标

| 目标 | 说明 |
|------|------|
| **Schema 导出** | 从已有表结构导出 YAML Schema 定义 |
| **迁移辅助** | 帮助现有项目生成初始 Schema 文件 |
| **版本控制** | Schema 文件可纳入 Git 版本管理 |
| **备份恢复** | Schema 独立于数据，便于灾难恢复 |

### 7.2 使用场景

1. **现有项目迁移**: 从编程方式创建的表生成 Schema 文件
2. **Schema 备份**: 定期导出 Schema 用于版本控制
3. **跨环境部署**: 从开发环境导出 Schema 到生产环境
4. **文档生成**: 自动生成表结构文档

### 7.3 API 设计

#### 7.3.1 MathDB 全局导出

```python
from mathdb import MathDB

# 导出所有表的 Schema 到文件
MathDB.export_schema("schema.yaml")

# 仅导出指定表
MathDB.export_schema("users_schema.yaml", table_names=["users", "orders"])

# 仅获取 YAML 字符串（不写入文件）
yaml_content = MathDB.export_schema()
print(yaml_content)
```

#### 7.3.2 Table 单表导出

```python
# 获取单表的 TableSchema 对象
table = MathDB.get_table("users")
schema = table.export_schema()

# 转换为 YAML 字符串
yaml_str = table.to_yaml_schema()
```

### 7.4 生成的 YAML 格式

```yaml
# 由 MathDB.export_schema() 自动生成
# 生成时间: 2026-01-31T10:30:00
# 后端类型: polars

tables:
  - table_name: users
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: username
        dtype: Utf8
        nullable: false
      - name: email
        dtype: Utf8
        nullable: true
      - name: age
        dtype: Int32
        nullable: true
      - name: created_at
        dtype: Datetime
        nullable: true
    metadata:
      row_count: 10000
      backend: polars
      export_time: "2026-01-31T10:30:00"

  - table_name: orders
    columns:
      - name: order_id
        dtype: Int64
        primary_key: true
      - name: user_id
        dtype: Int64
        nullable: false
      - name: total_price
        dtype: Float64
        nullable: false
    metadata:
      row_count: 50000
      backend: polars
      export_time: "2026-01-31T10:30:00"
```

### 7.5 类型映射

从 DataFrame 列类型到 YAML dtype 的映射：

#### 7.5.1 Polars 类型映射

| Polars 类型 | YAML dtype |
|------------|------------|
| `pl.Int8` | `Int8` |
| `pl.Int16` | `Int16` |
| `pl.Int32` | `Int32` |
| `pl.Int64` | `Int64` |
| `pl.UInt8` | `UInt8` |
| `pl.UInt16` | `UInt16` |
| `pl.UInt32` | `UInt32` |
| `pl.UInt64` | `UInt64` |
| `pl.Float32` | `Float32` |
| `pl.Float64` | `Float64` |
| `pl.Boolean` | `Boolean` |
| `pl.Utf8` | `Utf8` |
| `pl.Date` | `Date` |
| `pl.Datetime` | `Datetime` |
| `pl.Duration` | `Duration` |
| `pl.Binary` | `Binary` |
| `pl.List(inner)` | `List[inner]` |

#### 7.5.2 Pandas 类型映射

| Pandas 类型 | YAML dtype |
|------------|------------|
| `int8` | `Int8` |
| `int16` | `Int16` |
| `int32` | `Int32` |
| `int64` | `Int64` |
| `float32` | `Float32` |
| `float64` | `Float64` |
| `bool` | `Boolean` |
| `object` (str) | `Utf8` |
| `datetime64` | `Datetime` |
| `timedelta64` | `Duration` |

### 7.6 实现细节

```python
class SchemaExporter:
    """Schema 导出器。"""
    
    def __init__(self, backend: BackendType):
        self.backend = backend
    
    def export_table(self, table: Table) -> dict:
        """导出单表 Schema。"""
        schema = table._schema
        columns = []
        
        for col in schema.columns:
            col_def = {
                "name": col.name,
                "dtype": self._dtype_to_yaml(col.dtype),
            }
            if col.primary_key:
                col_def["primary_key"] = True
            if col.nullable:
                col_def["nullable"] = True
            if col.default is not None:
                col_def["default"] = col.default
            columns.append(col_def)
        
        return {
            "table_name": schema.name,
            "columns": columns,
            "metadata": {
                "row_count": len(table),
                "backend": self.backend.value,
                "export_time": datetime.now().isoformat(),
            }
        }
    
    def export_all(self, tables: list[Table]) -> str:
        """导出所有表为 YAML。"""
        result = {
            "tables": [self.export_table(t) for t in tables]
        }
        return yaml.dump(result, allow_unicode=True, sort_keys=False)
    
    def _dtype_to_yaml(self, dtype) -> str:
        """类型转换为 YAML 字符串。"""
        # 根据后端类型进行映射
        ...
```

### 7.7 与 memdb 的对比

| 功能 | memdb (Java) | MathDB (Python) |
|------|-------------|-----------------|
| 全局导出 | `MemDB.exportSchema()` | `MathDB.export_schema()` |
| 单表导出 | `table.getSchema()` | `table.export_schema()` |
| 导出格式 | JSON | YAML |
| 类型映射 | Java → JSON | Polars/Pandas → YAML |
| 元数据 | 包含 | 包含 (row_count, export_time) |

---

## 8. 后端抽象层设计

### 7.1 Backend Protocol

```python
from abc import ABC, abstractmethod
from typing import Any, TypeVar, Generic

DataFrameT = TypeVar("DataFrameT")  # pl.DataFrame | pd.DataFrame
LazyFrameT = TypeVar("LazyFrameT")  # pl.LazyFrame | None


class Backend(ABC, Generic[DataFrameT, LazyFrameT]):
    """DataFrame 后端抽象基类。"""
    
    # ==================== 工厂方法 ====================
    
    @abstractmethod
    def create_empty_dataframe(self, schema: TableSchema) -> DataFrameT:
        """创建空 DataFrame。"""
        ...
    
    @abstractmethod
    def from_dict(self, data: dict[str, list]) -> DataFrameT:
        """从字典创建 DataFrame。"""
        ...
    
    # ==================== CRUD 操作 ====================
    
    @abstractmethod
    def insert_row(self, df: DataFrameT, row: dict[str, Any]) -> DataFrameT:
        """插入一行。"""
        ...
    
    @abstractmethod
    def update_row(self, df: DataFrameT, pk_col: str, pk_val: Any, row: dict[str, Any]) -> DataFrameT:
        """更新一行。"""
        ...
    
    @abstractmethod
    def delete_row(self, df: DataFrameT, pk_col: str, pk_val: Any) -> DataFrameT:
        """删除一行。"""
        ...
    
    @abstractmethod
    def get_row(self, df: DataFrameT, pk_col: str, pk_val: Any) -> dict[str, Any] | None:
        """获取一行。"""
        ...
    
    @abstractmethod
    def count(self, df: DataFrameT) -> int:
        """获取行数。"""
        ...
    
    # ==================== 序列化 ====================
    
    @abstractmethod
    def to_arrow(self, df: DataFrameT) -> bytes:
        """序列化为 Arrow IPC 格式（用于 WAL）。"""
        ...
    
    @abstractmethod
    def from_arrow(self, data: bytes, schema: TableSchema) -> DataFrameT:
        """从 Arrow IPC 格式反序列化。"""
        ...
    
    @abstractmethod
    def to_parquet(self, df: DataFrameT, path: str) -> None:
        """保存为 Parquet 格式（用于快照）。"""
        ...
    
    @abstractmethod
    def from_parquet(self, path: str) -> DataFrameT:
        """从 Parquet 格式加载。"""
        ...
    
    # ==================== 查询 ====================
    
    @abstractmethod
    def to_lazy(self, df: DataFrameT) -> LazyFrameT:
        """转换为延迟求值形式（Pandas 返回 None）。"""
        ...
    
    @abstractmethod
    def apply_ops(self, df: DataFrameT, ops: list["Op"]) -> DataFrameT:
        """批量应用 CRUD 操作。"""
        ...


class PolarsBackend(Backend[pl.DataFrame, pl.LazyFrame]):
    """Polars 后端实现。"""
    
    def create_empty_dataframe(self, schema: TableSchema) -> pl.DataFrame:
        return pl.DataFrame(schema=schema.to_polars_schema())
    
    def to_lazy(self, df: pl.DataFrame) -> pl.LazyFrame:
        return df.lazy()
    
    # ... 其他方法实现


class PandasBackend(Backend[pd.DataFrame, None]):
    """Pandas 后端实现。"""
    
    def create_empty_dataframe(self, schema: TableSchema) -> pd.DataFrame:
        return pd.DataFrame(columns=[col.name for col in schema.columns])
    
    def to_lazy(self, df: pd.DataFrame) -> None:
        return None  # Pandas 不支持 LazyFrame
    
    # ... 其他方法实现
```

### 7.2 后端工厂

```python
class BackendFactory:
    """后端工厂。"""
    
    _backends: dict[BackendType, type[Backend]] = {
        BackendType.POLARS: PolarsBackend,
        BackendType.PANDAS: PandasBackend,
    }
    
    @classmethod
    def create(cls, backend_type: BackendType) -> Backend:
        """Create a backend instance."""
        backend_cls = cls._backends.get(backend_type)
        if backend_cls is None:
            raise ValueError(f"Unknown backend type: {backend_type}")
        return backend_cls()
    
    @classmethod
    def register(cls, backend_type: BackendType, backend_cls: type[Backend]) -> None:
        """注册自定义后端。"""
        cls._backends[backend_type] = backend_cls
```

### 7.3 后端特性对比

| 特性 | Polars | Pandas |
|------|--------|--------|
| `to_dataframe()` | `pl.DataFrame` | `pd.DataFrame` |
| `scan()` | `pl.LazyFrame` | `None` (不支持) |
| `query(expr)` | Polars 表达式 | Lambda/函数 |
| WAL 格式 | Arrow IPC | Arrow IPC |
| 快照格式 | Parquet | Parquet |
| 多线程并行 | ✓ 原生支持 | ✗ GIL 限制 |
| 内存效率 | ✓ 列式存储 | ○ 行式存储 |
| 生态兼容 | 归档新 | ✓ 成熟生态 |

---

## 9. 实现计划

### 9.1 阶段划分

| 阶段 | 内容 | 优先级 |
|------|------|--------|
| **M0** | 后端抽象层 (Backend Protocol, Polars/Pandas 实现) | 高 |
| **M1** | 配置管理 (MathDBConfig, YAML 加载) | 高 |
| **M2** | Schema 管理 (TableInfo, SchemaInfo, YAML 加载) | 高 |
| **M2.5** | Schema 反向生成 (export_schema, 类型映射) | 中 |
| **M3** | MathDB 管理器 (表容器, 生命周期管理) | 高 |
| **M4** | 一站式恢复 (init 自动恢复) | 高 |
| **M5** | 全局快照管理 | 中 |
| **M6** | 统计信息和监控 | 低 |

### 9.2 M0: 后端抽象层

**目标**: 实现后端抽象和 Polars/Pandas 实现

**文件**:
- `src/mathdb/backend/__init__.py`
- `src/mathdb/backend/base.py`
- `src/mathdb/backend/polars_backend.py`
- `src/mathdb/backend/pandas_backend.py`
- `tests/test_backend.py`

**类**:
- `BackendType` (枚举)
- `Backend` (抽象基类)
- `PolarsBackend`
- `PandasBackend`
- `BackendFactory`

### 9.3 M1: 配置管理

**目标**: 实现 YAML 配置加载

**文件**:
- `src/mathdb/config.py`
- `tests/test_config.py`

**类**:
- `MathDBConfig`
- `WALConfig`
- `SnapshotConfig`
- `RecoveryConfig`
- `BackendType`

### 9.4 M2: Schema 管理

**目标**: 从 YAML 加载表结构

**文件**:
- `src/mathdb/schema_loader.py`
- `tests/test_schema_loader.py`

**类**:
- `TableInfo` (表配置信息)
- `SchemaInfo` (Schema 配置文件结构)
- `SchemaLoader` (加载器)

### 9.5 M2.5: Schema 反向生成

**目标**: 从已有表反向生成 YAML Schema 定义

**文件**:
- `src/mathdb/schema_exporter.py`
- `tests/test_schema_exporter.py`

**类**:
- `SchemaExporter` (导出器)
- `TypeMapper` (类型映射)

**功能**:
- MathDB.export_schema() 全局导出
- Table.export_schema() 单表导出
- Table.to_yaml_schema() 转换为 YAML 字符串
- Polars/Pandas 类型到 YAML dtype 映射

### 9.6 M3: MathDB 管理器

**目标**: 全局表容器

**文件**:
- `src/mathdb/mathdb.py`
- `tests/test_mathdb.py`

**功能**:
- 表注册与获取
- 生命周期管理
- 统计信息
- 后端选择

### 9.7 M4: 一站式恢复

**目标**: `init()` 自动完成恢复

**功能**:
- 检测持久化数据
- 自动恢复或创建空表
- Schema 验证
- 后端一致性检查

---

## 10. 总结

### 10.1 与 memdb 的对比

| 特性 | memdb (Java) | MathDB (Python) |
|------|-------------|---------------------|
| 全局管理器 | `MemDB` | `MathDB` |
| 配置管理 | `MemDBConfig` + YAML | `MathDBConfig` + YAML |
| Schema 加载 | `loadSchema()` | `load_schema()` |
| Schema 导出 | `exportSchema()` | `export_schema()` |
| 表获取 | `getTable()` | `get_table()` |
| 自动恢复 | `init()` 内置 | `init()` 内置 |
| 数据存储 | Java 序列化 | Arrow IPC + Parquet |
| 查询引擎 | 自定义 Query DSL | Polars/Pandas 原生 API |
| 后端支持 | 固定 | Polars / Pandas 可选 |

### 10.2 设计优势

1. **一站式使用体验**: 类似磁盘数据库，启动即可用
2. **配置化管理**: 通过 YAML 文件统一管理
3. **1:1 落盘恢复**: 每个表独立管理，便于运维
4. **双后端支持**: Polars 高性能 + Pandas 生态兼容
5. **渐进式采用**: 可以只使用部分功能
6. **无缝迁移**: 现有 Pandas 项目可平滑迁移到 MathDB
7. **Schema 反向生成**: 从已有表自动生成 YAML Schema 定义

### 10.3 后端选择建议

| 场景 | 推荐后端 | 说明 |
|------|----------|------|
| 新项目 | Polars | 高性能、现代化 API |
| 现有 Pandas 项目迁移 | Pandas | 减少代码改动 |
| 大数据量 (>1GB) | Polars | 内存效率高 |
| 需要特定 Pandas 库 | Pandas | 生态兼容 |
| 实时数据分析 | Polars | 多线程并行 |
| 原型开发 | Pandas | 学习曲线低 |

---

**文档结束**
