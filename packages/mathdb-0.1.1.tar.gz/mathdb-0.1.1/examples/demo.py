#!/usr/bin/env python3
"""
MathDB 2.0 Demo
===============

演示 MathDB 2.0 的核心功能：
- 从 YAML 文件加载 Schema
- 全局 MathDB 管理器
- Polars/Pandas 双后端
- Schema 加载与导出
- WAL 持久化与恢复
"""

import tempfile
import shutil
from pathlib import Path

# 导入 MathDB 2.0
from mathdb import (
    MathDB,
    Table,
    BackendType,
    PolarsBackend,
    PandasBackend,
    SchemaExporter,
    SchemaLoader,
)
from mathdb.schema import TableSchema, ColumnDef

# Schema 文件目录
SCHEMA_DIR = Path(__file__).parent / "schemas"


def demo_yaml_schema():
    """从 YAML 文件加载 Schema 示例。"""
    print("\n" + "=" * 60)
    print("🔷 从 YAML 文件加载 Schema")
    print("=" * 60)

    # 加载 users.yaml
    loader = SchemaLoader()
    users_schema = loader.load_as_schemas(SCHEMA_DIR / "users.yaml")[0]
    
    print(f"\n📄 加载 users.yaml:")
    print(f"   表名: {users_schema.name}")
    print(f"   主键: {users_schema.pk_name}")
    print(f"   列: {[c.name for c in users_schema.columns]}")

    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir)

        # 使用加载的 Schema 创建表
        with Table(users_schema, data_dir, flush_interval=0) as table:
            # 插入数据
            table.insert({"id": 1, "name": "Alice", "age": 28, "email": "alice@example.com"})
            table.insert({"id": 2, "name": "Bob", "age": 32, "email": "bob@example.com"})
            table.insert({"id": 3, "name": "Charlie", "age": 25, "email": "charlie@example.com"})

            print(f"\n📊 表中共有 {table.count()} 行数据")

            user = table.get(1)
            print(f"✅ 获取 id=1: {user}")

            # 更新数据
            table.update(2, {"id": 2, "name": "Bob Updated", "age": 33, "email": "bob.updated@example.com"})
            print(f"✅ 更新 id=2: {table.get(2)}")

            # Upsert 操作
            table.upsert({"id": 4, "name": "David", "age": 29, "email": "david@example.com"})
            print(f"✅ Upsert id=4: {table.get(4)}")

            # 刷盘
            table.flush()
            print("\n💾 数据已刷盘到 WAL")

            # 统计信息
            stats = table.get_stats()
            print(f"\n📈 统计信息: {stats}")

        # 重新打开验证恢复
        print("\n🔄 重新打开表验证恢复...")
        with Table(users_schema, data_dir, flush_interval=0) as table:
            print(f"✅ 恢复后行数: {table.count()}")
            print(f"✅ 恢复后 id=2: {table.get(2)}")


def demo_mathdb_manager():
    """MathDB 管理器 + YAML Schema 示例。"""
    print("\n" + "=" * 60)
    print("🔷 MathDB 管理器 + YAML Schema")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir)

        # 创建配置
        from mathdb.config import MathDBConfig
        config = MathDBConfig(data_dir=data_dir, backend="polars")

        # 使用上下文管理器
        with MathDB.context(config):
            # 从 YAML 文件加载 Schema
            loader = SchemaLoader()
            products_schema = loader.load_as_schemas(SCHEMA_DIR / "products.yaml")[0]

            print(f"\n📄 加载 products.yaml:")
            print(f"   表名: {products_schema.name}")

            table = MathDB.create_table(products_schema)
            print(f"\n✅ 创建表: {table.name}")

            # 插入数据
            table.insert({"id": 1, "name": "Laptop", "price": 999.99, "stock": 50})
            table.insert({"id": 2, "name": "Mouse", "price": 29.99, "stock": 200})
            table.insert({"id": 3, "name": "Keyboard", "price": 79.99, "stock": 100})

            # 获取表
            products = MathDB.get_table("products")
            print(f"📊 产品数量: {products.count()}")

            # 列出所有表
            table_names = MathDB.list_tables()
            print(f"📋 所有表: {table_names}")

            # 导出 Schema
            yaml_schema = MathDB.export_schema("products")
            print(f"\n📄 导出的 YAML Schema:\n{yaml_schema}")


def demo_dual_backend():
    """双后端 + YAML Schema 示例。"""
    print("\n" + "=" * 60)
    print("🔷 双后端示例")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir)

        # 加载简单 Schema (用 orders.yaml 演示)
        loader = SchemaLoader()
        
        # 创建一个简单的 test schema YAML
        test_yaml = data_dir / "test.yaml"
        test_yaml.write_text("""tables:
  - table_name: test
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: value
        dtype: Utf8
""")
        schema = loader.load_as_schemas(test_yaml)[0]
        print(f"\n📄 动态创建并加载 test.yaml")

        # Polars 后端
        print("\n🐻‍❄️ Polars 后端:")
        with Table(schema, data_dir / "polars", backend=PolarsBackend(), enable_persistence=False) as table:
            table.insert({"id": 1, "value": "polars"})
            df = table.to_dataframe()
            print(f"   类型: {type(df)}")
            print(f"   数据: {df}")

        # Pandas 后端
        print("\n🐼 Pandas 后端:")
        with Table(schema, data_dir / "pandas", backend=PandasBackend(), enable_persistence=False) as table:
            table.insert({"id": 1, "value": "pandas"})
            df = table.to_dataframe()
            print(f"   类型: {type(df)}")
            print(f"   数据:\n{df}")


def demo_schema_export():
    """Schema 反向生成示例。"""
    print("\n" + "=" * 60)
    print("🔷 Schema 反向生成示例")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir)

        # 从 YAML 文件加载 orders Schema
        loader = SchemaLoader()
        orders_schema = loader.load_as_schemas(SCHEMA_DIR / "orders.yaml")[0]
        
        print(f"\n📄 加载 orders.yaml:")
        print(f"   表名: {orders_schema.name}")
        print(f"   主键: {orders_schema.pk_name}")
        print(f"   列: {[c.name for c in orders_schema.columns]}")

        with Table(orders_schema, data_dir, enable_persistence=False) as table:
            # 从表反向生成 Schema
            exported_schema = table.export_schema()
            print(f"\n✅ 导出的 TableSchema:")
            print(f"   name: {exported_schema.name}")
            print(f"   pk: {exported_schema.pk_name}")
            print(f"   columns: {[c.name for c in exported_schema.columns]}")

            # 导出为 YAML
            yaml_str = table.to_yaml_schema()
            print(f"\n📄 YAML 格式:\n{yaml_str}")

            # 使用 SchemaExporter 导出到文件
            exporter = SchemaExporter()
            schema_file = data_dir / "orders_exported.yaml"
            exporter.export_to_file([orders_schema], schema_file)
            print(f"✅ 已导出到文件: {schema_file}")
            
            # 验证导出内容
            print(f"\n📄 导出文件内容:\n{schema_file.read_text()}")


def main():
    """运行所有示例。"""
    print("\n" + "=" * 60)
    print("🚀 MathDB 2.0 演示")
    print("=" * 60)

    demo_yaml_schema()
    demo_mathdb_manager()
    demo_dual_backend()
    demo_schema_export()

    print("\n" + "=" * 60)
    print("✅ 所有演示完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
