"""MathDB - 基于 Polars/Pandas 的持久化内存数据库。

MathDB 2.0 版本，支持双后端、YAML 配置、一站式管理。
"""

from mathdb.schema import TableSchema, ColumnDef
from mathdb.backend import Backend, BackendType, PolarsBackend, PandasBackend, BackendFactory
from mathdb.config import MathDBConfig, WALConfig, SnapshotConfig, RecoveryConfig, load_config
from mathdb.schema_loader import SchemaLoader, TableInfo
from mathdb.schema_exporter import SchemaExporter
from mathdb.table import Table
from mathdb.mathdb import MathDB

__version__ = "2.0.0"

__all__ = [
    # 核心接口
    "MathDB",
    "Table",
    "TableSchema",
    "ColumnDef",
    # 后端
    "Backend",
    "BackendType",
    "PolarsBackend",
    "PandasBackend",
    "BackendFactory",
    # 配置
    "MathDBConfig",
    "WALConfig",
    "SnapshotConfig",
    "RecoveryConfig",
    "load_config",
    # Schema
    "SchemaLoader",
    "SchemaExporter",
    "TableInfo",
]
