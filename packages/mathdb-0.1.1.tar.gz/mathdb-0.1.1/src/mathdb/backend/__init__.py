"""Backend 模块 - DataFrame 后端抽象层。"""

from mathdb.backend.base import Backend, BackendType
from mathdb.backend.polars_backend import PolarsBackend
from mathdb.backend.pandas_backend import PandasBackend
from mathdb.backend.factory import BackendFactory

__all__ = [
    "Backend",
    "BackendType",
    "PolarsBackend",
    "PandasBackend",
    "BackendFactory",
]
