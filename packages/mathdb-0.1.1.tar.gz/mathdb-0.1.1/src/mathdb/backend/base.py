"""Backend 抽象基类定义。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, TypeVar, Generic

import pyarrow as pa

# 避免循环导入
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from mathdb.schema import TableSchema


class BackendType(Enum):
    """DataFrame 后端类型。"""
    POLARS = "polars"
    PANDAS = "pandas"


# 泛型类型变量
DataFrameT = TypeVar("DataFrameT")


class Backend(ABC, Generic[DataFrameT]):
    """DataFrame 后端抽象基类。
    
    定义了所有后端必须实现的操作接口。
    """

    @property
    @abstractmethod
    def backend_type(self) -> BackendType:
        """返回后端类型。"""
        ...

    # ==================== 工厂方法 ====================

    @abstractmethod
    def create_empty_dataframe(self, schema: "TableSchema") -> DataFrameT:
        """根据 Schema 创建空 DataFrame。"""
        ...

    @abstractmethod
    def from_dict(self, data: dict[str, list]) -> DataFrameT:
        """从字典创建 DataFrame。"""
        ...

    # ==================== CRUD 操作 ====================

    @abstractmethod
    def insert_row(self, df: DataFrameT, row: dict[str, Any], schema: "TableSchema") -> DataFrameT:
        """插入一行。"""
        ...

    @abstractmethod
    def update_row(
        self, df: DataFrameT, pk_col: str, pk_val: Any, row: dict[str, Any], schema: "TableSchema"
    ) -> DataFrameT:
        """更新一行。"""
        ...

    @abstractmethod
    def delete_row(self, df: DataFrameT, pk_col: str, pk_val: Any) -> DataFrameT:
        """删除一行。"""
        ...

    @abstractmethod
    def get_row(self, df: DataFrameT, pk_col: str, pk_val: Any) -> dict[str, Any] | None:
        """根据主键获取一行。"""
        ...

    # ==================== 查询操作 ====================

    @abstractmethod
    def row_count(self, df: DataFrameT) -> int:
        """获取行数。"""
        ...

    # ==================== 序列化 ====================

    @abstractmethod
    def to_arrow(self, df: DataFrameT) -> pa.Table:
        """转换为 Arrow Table（用于 WAL 序列化）。"""
        ...

    @abstractmethod
    def from_arrow(self, table: pa.Table) -> DataFrameT:
        """从 Arrow Table 恢复。"""
        ...
