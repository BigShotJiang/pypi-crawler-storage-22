"""Backend 工厂。"""

from __future__ import annotations

from mathdb.backend.base import Backend, BackendType
from mathdb.backend.polars_backend import PolarsBackend
from mathdb.backend.pandas_backend import PandasBackend


class BackendFactory:
    """Backend 工厂类。"""

    @staticmethod
    def create(backend_type: BackendType | str | None = None) -> Backend:
        """创建 Backend 实例。
        
        Args:
            backend_type: 后端类型。默认为 Polars。
            
        Returns:
            Backend 实例。
        """
        if backend_type is None:
            backend_type = BackendType.POLARS
        
        if isinstance(backend_type, str):
            backend_type = BackendType(backend_type)
        
        if backend_type == BackendType.POLARS:
            return PolarsBackend()
        elif backend_type == BackendType.PANDAS:
            return PandasBackend()
        else:
            raise ValueError(f"未知的后端类型: {backend_type}")
