"""Pandas 后端实现。"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

import pandas as pd
import pyarrow as pa
import numpy as np

from mathdb.backend.base import Backend, BackendType

if TYPE_CHECKING:
    from mathdb.schema import TableSchema


# MathDB dtype 到 Pandas dtype 的映射
DTYPE_TO_PANDAS: dict[str, str | type] = {
    "Int8": "Int8",
    "Int16": "Int16",
    "Int32": "Int32",
    "Int64": "Int64",
    "UInt8": "UInt8",
    "UInt16": "UInt16",
    "UInt32": "UInt32",
    "UInt64": "UInt64",
    "Float32": "float32",
    "Float64": "float64",
    "Utf8": "string",
    "String": "string",
    "Boolean": "boolean",
    "Bool": "boolean",
    "Date": "datetime64[ns]",
    "Datetime": "datetime64[ns]",
    "Duration": "timedelta64[ns]",
}


class PandasBackend(Backend[pd.DataFrame]):
    """Pandas DataFrame 后端。
    
    兼容性强的后端，适用于现有 Pandas 项目迁移。
    """

    @property
    def backend_type(self) -> BackendType:
        return BackendType.PANDAS

    def _schema_to_pandas_dtypes(self, schema: "TableSchema") -> dict[str, Any]:
        """将 MathDB Schema 转换为 Pandas dtypes。"""
        dtypes = {}
        for col in schema.columns:
            pandas_dtype = DTYPE_TO_PANDAS.get(col.dtype, "object")
            dtypes[col.name] = pandas_dtype
        return dtypes

    # ==================== 工厂方法 ====================

    def create_empty_dataframe(self, schema: "TableSchema") -> pd.DataFrame:
        """根据 Schema 创建空 DataFrame。"""
        dtypes = self._schema_to_pandas_dtypes(schema)
        df = pd.DataFrame(columns=schema.column_names)
        # 设置列类型
        for col_name, dtype in dtypes.items():
            df[col_name] = df[col_name].astype(dtype)
        return df

    def from_dict(self, data: dict[str, list]) -> pd.DataFrame:
        """从字典创建 DataFrame。"""
        return pd.DataFrame(data)

    # ==================== CRUD 操作 ====================

    def insert_row(self, df: pd.DataFrame, row: dict[str, Any], schema: "TableSchema") -> pd.DataFrame:
        """插入一行。"""
        new_row_df = pd.DataFrame([row])
        # 确保列顺序一致
        new_row_df = new_row_df.reindex(columns=df.columns)
        return pd.concat([df, new_row_df], ignore_index=True)

    def update_row(
        self, df: pd.DataFrame, pk_col: str, pk_val: Any, row: dict[str, Any], schema: "TableSchema"
    ) -> pd.DataFrame:
        """更新一行（通过删除旧行+插入新行实现）。"""
        df = self.delete_row(df, pk_col, pk_val)
        return self.insert_row(df, row, schema)

    def delete_row(self, df: pd.DataFrame, pk_col: str, pk_val: Any) -> pd.DataFrame:
        """删除一行。"""
        return df[df[pk_col] != pk_val].reset_index(drop=True)

    def get_row(self, df: pd.DataFrame, pk_col: str, pk_val: Any) -> dict[str, Any] | None:
        """根据主键获取一行。"""
        filtered = df[df[pk_col] == pk_val]
        if len(filtered) == 0:
            return None
        return filtered.iloc[0].to_dict()

    # ==================== 查询操作 ====================

    def row_count(self, df: pd.DataFrame) -> int:
        """获取行数。"""
        return len(df)

    # ==================== 序列化 ====================

    def to_arrow(self, df: pd.DataFrame) -> pa.Table:
        """转换为 Arrow Table。"""
        return pa.Table.from_pandas(df)

    def from_arrow(self, table: pa.Table) -> pd.DataFrame:
        """从 Arrow Table 恢复。"""
        return table.to_pandas()
