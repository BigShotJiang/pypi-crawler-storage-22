"""Polars 后端实现。"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

import polars as pl
import pyarrow as pa

from mathdb.backend.base import Backend, BackendType

if TYPE_CHECKING:
    from mathdb.schema import TableSchema


class PolarsBackend(Backend[pl.DataFrame]):
    """Polars DataFrame 后端。
    
    高性能列式存储后端，适用于大数据量场景。
    """

    @property
    def backend_type(self) -> BackendType:
        return BackendType.POLARS

    # ==================== 工厂方法 ====================

    def create_empty_dataframe(self, schema: "TableSchema") -> pl.DataFrame:
        """根据 Schema 创建空 DataFrame。"""
        return schema.create_empty_dataframe()

    def from_dict(self, data: dict[str, list]) -> pl.DataFrame:
        """从字典创建 DataFrame。"""
        return pl.DataFrame(data)

    # ==================== CRUD 操作 ====================

    def insert_row(self, df: pl.DataFrame, row: dict[str, Any], schema: "TableSchema") -> pl.DataFrame:
        """插入一行。"""
        # 创建包含新行的 DataFrame
        new_row_df = pl.DataFrame([row], schema=schema.to_polars_schema())
        return pl.concat([df, new_row_df])

    def update_row(
        self, df: pl.DataFrame, pk_col: str, pk_val: Any, row: dict[str, Any], schema: "TableSchema"
    ) -> pl.DataFrame:
        """更新一行（通过删除旧行+插入新行实现）。"""
        # 删除旧行
        df = self.delete_row(df, pk_col, pk_val)
        # 插入新行
        return self.insert_row(df, row, schema)

    def delete_row(self, df: pl.DataFrame, pk_col: str, pk_val: Any) -> pl.DataFrame:
        """删除一行。"""
        return df.filter(pl.col(pk_col) != pk_val)

    def get_row(self, df: pl.DataFrame, pk_col: str, pk_val: Any) -> dict[str, Any] | None:
        """根据主键获取一行。"""
        filtered = df.filter(pl.col(pk_col) == pk_val)
        if len(filtered) == 0:
            return None
        return filtered.row(0, named=True)

    # ==================== 查询操作 ====================

    def row_count(self, df: pl.DataFrame) -> int:
        """获取行数。"""
        return len(df)

    # ==================== 序列化 ====================

    def to_arrow(self, df: pl.DataFrame) -> pa.Table:
        """转换为 Arrow Table。"""
        return df.to_arrow()

    def from_arrow(self, table: pa.Table) -> pl.DataFrame:
        """从 Arrow Table 恢复。"""
        return pl.from_arrow(table)
