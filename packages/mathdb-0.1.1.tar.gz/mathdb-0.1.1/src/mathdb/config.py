"""Config 配置管理模块。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from mathdb.backend import BackendType


@dataclass
class WALConfig:
    """WAL 配置。"""
    enabled: bool = True
    flush_interval: float = 3.0
    sync_on_flush: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "flush_interval": self.flush_interval,
            "sync_on_flush": self.sync_on_flush,
        }


@dataclass
class SnapshotConfig:
    """快照配置。"""
    enabled: bool = True
    auto_compact: bool = True
    compact_threshold: int = 100
    max_snapshots: int = 3

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "auto_compact": self.auto_compact,
            "compact_threshold": self.compact_threshold,
            "max_snapshots": self.max_snapshots,
        }


@dataclass
class RecoveryConfig:
    """恢复配置。"""
    enabled: bool = True
    mode: str = "auto"  # auto | snapshot_wal | snapshot_only

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "mode": self.mode,
        }


@dataclass
class MathDBConfig:
    """MathDB 主配置。
    
    Attributes:
        name: 数据库名称。
        data_dir: 数据目录路径。
        backend: 后端类型 (polars/pandas)。
        schema_path: Schema 文件路径（可选）。
        wal: WAL 配置。
        snapshot: 快照配置。
        recovery: 恢复配置。
    """
    name: str = "mathdb"
    data_dir: Path = field(default_factory=lambda: Path("./data"))
    backend: BackendType = BackendType.POLARS
    schema_path: str | None = None
    wal: WALConfig = field(default_factory=WALConfig)
    snapshot: SnapshotConfig = field(default_factory=SnapshotConfig)
    recovery: RecoveryConfig = field(default_factory=RecoveryConfig)

    def __post_init__(self):
        # 自动转换字符串路径
        if isinstance(self.data_dir, str):
            self.data_dir = Path(self.data_dir)
        # 自动转换字符串后端类型
        if isinstance(self.backend, str):
            self.backend = BackendType(self.backend)

    def to_dict(self) -> dict[str, Any]:
        """转换为字典。"""
        return {
            "name": self.name,
            "data_dir": str(self.data_dir),
            "backend": self.backend.value,
            "schema_path": self.schema_path,
            "wal": self.wal.to_dict(),
            "snapshot": self.snapshot.to_dict(),
            "recovery": self.recovery.to_dict(),
        }


def load_config(config_path: Path | str) -> MathDBConfig:
    """从 YAML 文件加载配置。
    
    Args:
        config_path: YAML 配置文件路径。
        
    Returns:
        MathDBConfig 实例。
        
    Raises:
        FileNotFoundError: 配置文件不存在。
    """
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")
    
    with open(config_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    
    if "mathdb" not in data:
        raise ValueError("配置文件必须包含 'mathdb' 根节点")
    
    cfg = data["mathdb"]
    
    # 解析子配置
    wal_cfg = WALConfig(**cfg.get("wal", {})) if "wal" in cfg else WALConfig()
    snapshot_cfg = SnapshotConfig(**cfg.get("snapshot", {})) if "snapshot" in cfg else SnapshotConfig()
    recovery_cfg = RecoveryConfig(**cfg.get("recovery", {})) if "recovery" in cfg else RecoveryConfig()
    
    # 处理后端类型
    backend = cfg.get("backend", "polars")
    if isinstance(backend, str):
        backend = BackendType(backend)
    
    return MathDBConfig(
        name=cfg.get("name", "mathdb"),
        data_dir=Path(cfg.get("data_dir", "./data")),
        backend=backend,
        schema_path=cfg.get("schema_path"),
        wal=wal_cfg,
        snapshot=snapshot_cfg,
        recovery=recovery_cfg,
    )
