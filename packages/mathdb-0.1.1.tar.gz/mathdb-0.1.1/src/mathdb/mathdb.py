"""MathDB 全局管理器。"""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, TYPE_CHECKING

from mathdb.backend import Backend, BackendType, BackendFactory
from mathdb.config import MathDBConfig, load_config
from mathdb.schema import TableSchema
from mathdb.schema_loader import SchemaLoader
from mathdb.schema_exporter import SchemaExporter

if TYPE_CHECKING:
    from mathdb.table import Table


class _MathDBState:
    """MathDB 内部状态。"""

    def __init__(self):
        self.initialized: bool = False
        self.config: MathDBConfig | None = None
        self.backend: Backend | None = None
        self.tables: dict[str, "Table"] = {}


# 全局状态（单例）
_state = _MathDBState()


class MathDB:
    """MathDB 全局管理器。
    
    类似 MemDB 的静态类设计，提供全局入口：
    
    ```python
    # 一站式初始化
    MathDB.init("config.yaml")
    
    # 获取表
    users = MathDB.get_table("users")
    
    # CRUD 操作
    users.insert({"id": 1, "name": "Alice"})
    
    # 关闭
    MathDB.close()
    ```
    """

    # ==================== 初始化 ====================

    @classmethod
    def init(cls, config: str | Path | MathDBConfig | None = None) -> None:
        """初始化 MathDB。
        
        Args:
            config: 配置文件路径、配置对象或 None（使用默认配置）。
            
        Raises:
            RuntimeError: 如果已初始化。
        """
        global _state

        if _state.initialized:
            raise RuntimeError("MathDB 已初始化。请先调用 close() 关闭。")

        # 解析配置
        if config is None:
            cfg = MathDBConfig()
        elif isinstance(config, (str, Path)):
            cfg = load_config(config)
        else:
            cfg = config

        # 创建数据目录
        cfg.data_dir.mkdir(parents=True, exist_ok=True)

        # 初始化后端
        backend = BackendFactory.create(cfg.backend)

        # 设置状态
        _state.config = cfg
        _state.backend = backend
        _state.tables = {}
        _state.initialized = True

        # 如果配置了 schema_path，自动加载
        if cfg.schema_path:
            cls.load_schema(cfg.schema_path)

    @classmethod
    def is_initialized(cls) -> bool:
        """检查是否已初始化。"""
        return _state.initialized

    @classmethod
    def get_config(cls) -> MathDBConfig:
        """获取当前配置。"""
        cls._check_initialized()
        return _state.config

    @classmethod
    def get_backend(cls) -> Backend:
        """获取当前后端。"""
        cls._check_initialized()
        return _state.backend

    # ==================== 表管理 ====================

    @classmethod
    def create_table(cls, schema: TableSchema) -> "Table":
        """创建表。
        
        Args:
            schema: 表结构定义。
            
        Returns:
            Table 实例。
            
        Raises:
            ValueError: 如果表已存在。
        """
        from mathdb.table import Table

        cls._check_initialized()

        if schema.name in _state.tables:
            raise ValueError(f"表 '{schema.name}' 已存在。")

        # 创建表实例
        table = Table(
            schema=schema,
            data_dir=_state.config.data_dir,
            backend=_state.backend,
            flush_interval=_state.config.wal.flush_interval,
        )
        _state.tables[schema.name] = table
        return table

    @classmethod
    def get_table(cls, name: str) -> "Table":
        """获取表。
        
        Args:
            name: 表名。
            
        Returns:
            Table 实例。
            
        Raises:
            KeyError: 如果表不存在。
        """
        cls._check_initialized()
        if name not in _state.tables:
            raise KeyError(f"表 '{name}' 不存在。")
        return _state.tables[name]

    @classmethod
    def get_table_or_none(cls, name: str) -> "Table | None":
        """获取表，不存在返回 None。"""
        cls._check_initialized()
        return _state.tables.get(name)

    @classmethod
    def table_exists(cls, name: str) -> bool:
        """检查表是否存在。"""
        cls._check_initialized()
        return name in _state.tables

    @classmethod
    def drop_table(cls, name: str) -> bool:
        """删除表。
        
        Returns:
            True 如果成功删除，False 如果表不存在。
        """
        cls._check_initialized()
        if name not in _state.tables:
            return False

        table = _state.tables.pop(name)
        table.close()
        return True

    @classmethod
    def list_tables(cls) -> list[str]:
        """列出所有表名。"""
        cls._check_initialized()
        return list(_state.tables.keys())

    @classmethod
    def get_table_count(cls) -> int:
        """获取表数量。"""
        cls._check_initialized()
        return len(_state.tables)

    # ==================== Schema 管理 ====================

    @classmethod
    def load_schema(cls, schema_path: str | Path) -> int:
        """从 YAML 文件加载 Schema 并创建表。
        
        Args:
            schema_path: Schema 文件路径。
            
        Returns:
            创建的表数量。
        """
        cls._check_initialized()

        loader = SchemaLoader()
        schemas = loader.load_as_schemas(schema_path)

        count = 0
        for schema in schemas:
            if not cls.table_exists(schema.name):
                cls.create_table(schema)
                count += 1
        return count

    @classmethod
    def export_schema(
        cls,
        output_path: str | Path | None = None,
        table_names: list[str] | None = None,
    ) -> str:
        """导出 Schema 到 YAML。
        
        Args:
            output_path: 输出文件路径。如果为 None，仅返回字符串。
            table_names: 要导出的表名列表。如果为 None，导出所有表。
            
        Returns:
            YAML 格式字符串。
        """
        cls._check_initialized()

        # 确定要导出的表
        if table_names is None:
            tables = list(_state.tables.values())
        else:
            tables = [_state.tables[name] for name in table_names if name in _state.tables]

        # 获取 schemas
        schemas = [t.schema for t in tables]

        # 导出
        exporter = SchemaExporter(backend_type=_state.config.backend)
        yaml_str = exporter.export_all(schemas)

        # 写入文件
        if output_path:
            Path(output_path).write_text(yaml_str, encoding="utf-8")

        return yaml_str

    # ==================== 生命周期 ====================

    @classmethod
    def close(cls) -> None:
        """关闭 MathDB。"""
        global _state

        if not _state.initialized:
            return

        # 关闭所有表
        for table in _state.tables.values():
            table.close()

        # 重置状态
        _state = _MathDBState()

    @classmethod
    @contextmanager
    def context(cls, config: str | Path | MathDBConfig | None = None) -> Iterator["MathDB"]:
        """上下文管理器。
        
        ```python
        with MathDB.context("config.yaml") as db:
            users = MathDB.get_table("users")
            ...
        # 自动关闭
        ```
        """
        try:
            cls.init(config)
            yield cls
        finally:
            cls.close()

    # ==================== 私有方法 ====================

    @classmethod
    def _check_initialized(cls) -> None:
        """检查是否已初始化。"""
        if not _state.initialized:
            raise RuntimeError("MathDB 未初始化。请先调用 init()。")
