"""操作类型和 Op 数据类，用于 CRUD 操作。"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class OpType(Enum):
    """操作类型枚举。"""

    INSERT = "I"
    UPDATE = "U"
    DELETE = "D"
    UPSERT = "P"  # P for "Put"

    @classmethod
    def from_string(cls, value: str) -> OpType:
        """从字符串创建 OpType。

        Args:
            value: 单字符字符串 ("I", "U", 或 "D")。

        Returns:
            对应的 OpType。

        Raises:
            ValueError: 如果值不是有效的操作类型。
        """
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"无效的操作类型: '{value}'。必须是: I, U, D, P 之一")


def _current_timestamp_ms() -> int:
    """获取当前时间戳（毫秒）。"""
    return int(time.time() * 1000)


@dataclass
class Op:
    """表示单个 CRUD 操作。

    Attributes:
        op_type: 操作类型 (INSERT, UPDATE, DELETE)。
        pk: 主键值。
        ts: 时间戳（毫秒），用于 LWW 排序。
        row: 行数据字典（DELETE 时为 None）。
    """

    op_type: OpType
    pk: Any
    ts: int = field(default_factory=_current_timestamp_ms)
    row: dict[str, Any] | None = None

    @classmethod
    def insert(cls, pk: Any, row: dict[str, Any]) -> Op:
        """创建 INSERT 操作。

        Args:
            pk: 主键值。
            row: 完整的行数据（包含主键）。

        Returns:
            INSERT 类型的新 Op。
        """
        return cls(op_type=OpType.INSERT, pk=pk, row=row)

    @classmethod
    def update(cls, pk: Any, row: dict[str, Any]) -> Op:
        """创建 UPDATE 操作。

        Args:
            pk: 主键值。
            row: 完整的行数据（包含主键）。

        Returns:
            UPDATE 类型的新 Op。
        """
        return cls(op_type=OpType.UPDATE, pk=pk, row=row)

    @classmethod
    def delete(cls, pk: Any) -> Op:
        """创建 DELETE 操作。

        Args:
            pk: 主键值。

        Returns:
            DELETE 类型的新 Op（无行数据）。
        """
        return cls(op_type=OpType.DELETE, pk=pk, row=None)

    def to_dict(self) -> dict[str, Any]:
        """将 Op 转换为字典用于序列化。

        Returns:
            包含 op, pk, ts, row 字段的字典。
        """
        return {
            "op": self.op_type.value,
            "pk": self.pk,
            "ts": self.ts,
            "row": self.row,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Op:
        """从字典创建 Op。

        Args:
            data: 包含 op, pk, ts, row 字段的字典。

        Returns:
            新的 Op 实例。
        """
        return cls(
            op_type=OpType.from_string(data["op"]),
            pk=data["pk"],
            ts=data["ts"],
            row=data.get("row"),
        )

    def __eq__(self, other: object) -> bool:
        """基于所有字段检查相等性。"""
        if not isinstance(other, Op):
            return NotImplemented
        return (
            self.op_type == other.op_type
            and self.pk == other.pk
            and self.ts == other.ts
            and self.row == other.row
        )
