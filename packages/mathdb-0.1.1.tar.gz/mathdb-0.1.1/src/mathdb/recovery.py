"""Recovery 2.0 模块 - 数据恢复。

从 WAL 日志恢复表数据。
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, TYPE_CHECKING

from mathdb.backend import Backend
from mathdb.ops import OpType
from mathdb.wal import WALReader

if TYPE_CHECKING:
    from mathdb.schema import TableSchema


class Recovery:
    """数据恢复器。
    
    从 WAL 日志重放操作，恢复表数据。
    """

    def __init__(
        self,
        data_dir: Path,
        schema: "TableSchema",
        backend: Backend,
    ) -> None:
        """初始化。
        
        Args:
            data_dir: 表数据目录。
            schema: 表结构。
            backend: DataFrame 后端。
        """
        self._data_dir = Path(data_dir)
        self._schema = schema
        self._backend = backend
        self._last_segment_id = 0

    @property
    def last_segment_id(self) -> int:
        """获取恢复的最后段 ID。"""
        return self._last_segment_id

    def recover(self) -> Any:
        """执行恢复。
        
        Returns:
            恢复后的 DataFrame。
        """
        # 创建空 DataFrame
        df = self._backend.create_empty_dataframe(self._schema)
        
        # 检查 WAL 目录
        wal_dir = self._data_dir / "wal"
        if not wal_dir.exists():
            return df

        # 读取所有 WAL 段
        reader = WALReader(wal_dir, self._schema)
        segments = reader.read_all()
        
        if not segments:
            return df

        # 重放操作
        pk_col = self._schema.pk_name
        for segment in segments:
            self._last_segment_id = segment.segment_id
            
            for op in segment.ops:
                if op.op_type == OpType.INSERT:
                    df = self._backend.insert_row(df, op.row, self._schema)
                elif op.op_type == OpType.UPDATE:
                    df = self._backend.update_row(df, pk_col, op.pk, op.row, self._schema)
                elif op.op_type == OpType.DELETE:
                    df = self._backend.delete_row(df, pk_col, op.pk)
                elif op.op_type == OpType.UPSERT:
                    existing = self._backend.get_row(df, pk_col, op.pk)
                    if existing is not None:
                        df = self._backend.update_row(df, pk_col, op.pk, op.row, self._schema)
                    else:
                        df = self._backend.insert_row(df, op.row, self._schema)

        return df
