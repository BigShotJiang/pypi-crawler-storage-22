"""表结构定义模块。"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any

import polars as pl


# 字符串类型到 Polars 类型的映射
DTYPE_MAP: dict[str, pl.DataType] = {
    "Int8": pl.Int8,
    "Int16": pl.Int16,
    "Int32": pl.Int32,
    "Int64": pl.Int64,
    "UInt8": pl.UInt8,
    "UInt16": pl.UInt16,
    "UInt32": pl.UInt32,
    "UInt64": pl.UInt64,
    "Float32": pl.Float32,
    "Float64": pl.Float64,
    "Utf8": pl.Utf8,
    "String": pl.Utf8,  # Alias
    "Boolean": pl.Boolean,
    "Bool": pl.Boolean,  # Alias
    "Date": pl.Date,
    "Datetime": pl.Datetime,
    "Time": pl.Time,
    "Duration": pl.Duration,
    "Binary": pl.Binary,
}


@dataclass
class ColumnDef:
    """表列定义。

    Attributes:
        name: 列名。
        dtype: 数据类型字符串（如 "Int64", "Utf8"）。
        primary_key: 是否为主键列。
        nullable: 是否允许空值。
    """

    name: str
    dtype: str
    primary_key: bool = False
    nullable: bool = True

    def __post_init__(self) -> None:
        """验证并规范化列定义。"""
        # 主键列不允许为空
        if self.primary_key:
            self.nullable = False

        # 验证数据类型
        if self.dtype not in DTYPE_MAP:
            raise ValueError(
                f"未知的数据类型 '{self.dtype}'。"
                f"支持的类型: {list(DTYPE_MAP.keys())}"
            )

    def to_polars_dtype(self) -> pl.DataType:
        """将数据类型字符串转换为 Polars DataType。"""
        return DTYPE_MAP[self.dtype]


@dataclass
class TableSchema:
    """表结构定义。

    Attributes:
        name: 表名。
        columns: 列定义列表。
    """

    name: str
    columns: list[ColumnDef] = field(default_factory=list)

    def __post_init__(self) -> None:
        """验证表结构。"""
        self._validate_primary_key()

    def _validate_primary_key(self) -> None:
        """确保定义了且仅定义了一个主键。"""
        pk_columns = [col for col in self.columns if col.primary_key]

        if len(pk_columns) == 0:
            raise ValueError(
                f"表 '{self.name}' 必须有一个主键列。"
                "请在某一列上设置 primary_key=True。"
            )

        if len(pk_columns) > 1:
            names = [col.name for col in pk_columns]
            raise ValueError(
                f"表 '{self.name}' 只能有一个主键。"
                f"发现多个主键: {names}"
            )

    def get_primary_key(self) -> ColumnDef | None:
        """获取主键列定义。"""
        for col in self.columns:
            if col.primary_key:
                return col
        return None

    @property
    def pk_name(self) -> str:
        """获取主键列名。"""
        pk = self.get_primary_key()
        if pk is None:
            raise ValueError(f"表 '{self.name}' 没有主键")
        return pk.name

    @property
    def column_names(self) -> list[str]:
        """获取列名列表。"""
        return [col.name for col in self.columns]

    def to_polars_schema(self) -> dict[str, pl.DataType]:
        """转换为 Polars schema 字典。"""
        return {col.name: col.to_polars_dtype() for col in self.columns}

    def create_empty_dataframe(self) -> pl.DataFrame:
        """创建一个空的 DataFrame。"""
        return pl.DataFrame(schema=self.to_polars_schema())

    def compute_hash(self) -> str:
        """计算表结构的确定性哈希值。

        用于检测重启后表结构是否发生变化。
        """
        # 构建规范化字符串表示
        parts = [f"table:{self.name}"]
        for col in self.columns:
            parts.append(f"col:{col.name}:{col.dtype}:pk={col.primary_key}")

        canonical = "|".join(parts)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def validate_row(self, row: dict[str, Any]) -> None:
        """验证行数据是否符合表结构。

        Args:
            row: 表示一行数据的字典。

        Raises:
            ValueError: 如果行数据无效。
        """
        # 检查主键是否存在
        pk_name = self.pk_name
        if pk_name not in row:
            raise ValueError(f"行数据必须包含主键列 '{pk_name}'")

        # 检查未知列
        valid_columns = set(self.column_names)
        row_columns = set(row.keys())
        unknown = row_columns - valid_columns
        if unknown:
            raise ValueError(f"行数据包含未知列: {unknown}")

        # 检查非空约束
        for col in self.columns:
            if not col.nullable and col.name in row and row[col.name] is None:
                raise ValueError(f"列 '{col.name}' 不能为空")
