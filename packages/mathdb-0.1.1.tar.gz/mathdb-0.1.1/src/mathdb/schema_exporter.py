"""Schema 导出器模块。"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, TYPE_CHECKING

import yaml

from mathdb.backend import BackendType

if TYPE_CHECKING:
    from mathdb.schema import TableSchema


class SchemaExporter:
    """Schema 导出器。
    
    从已有表反向生成 YAML Schema 定义。
    """

    def __init__(self, backend_type: BackendType = BackendType.POLARS):
        """初始化导出器。
        
        Args:
            backend_type: 后端类型（用于元数据）。
        """
        self.backend_type = backend_type

    def export_table(
        self,
        schema: "TableSchema",
        row_count: int | None = None,
    ) -> dict[str, Any]:
        """导出单表 Schema。
        
        Args:
            schema: 表结构。
            row_count: 表行数（可选，用于元数据）。
            
        Returns:
            表定义字典。
        """
        columns = []
        for col in schema.columns:
            col_def: dict[str, Any] = {
                "name": col.name,
                "dtype": col.dtype,
            }
            if col.primary_key:
                col_def["primary_key"] = True
            # 非主键的非空约束显式输出
            if not col.primary_key and not col.nullable:
                col_def["nullable"] = False
            columns.append(col_def)

        result: dict[str, Any] = {
            "table_name": schema.name,
            "columns": columns,
        }

        # 添加元数据
        if row_count is not None:
            result["metadata"] = {
                "row_count": row_count,
                "backend": self.backend_type.value,
                "export_time": datetime.now().isoformat(),
            }

        return result

    def export_all(
        self,
        schemas: list["TableSchema"],
        include_metadata: bool = False,
    ) -> str:
        """导出所有表为 YAML 字符串。
        
        Args:
            schemas: 表结构列表。
            include_metadata: 是否包含元数据。
            
        Returns:
            YAML 格式字符串。
        """
        tables = []
        for schema in schemas:
            if include_metadata:
                tables.append(self.export_table(schema, row_count=0))
            else:
                tables.append(self.export_table(schema))

        result = {"tables": tables}
        return yaml.dump(result, allow_unicode=True, sort_keys=False, default_flow_style=False)

    def export_to_file(
        self,
        schemas: list["TableSchema"],
        output_path: Path | str,
        include_metadata: bool = False,
    ) -> None:
        """导出到文件。
        
        Args:
            schemas: 表结构列表。
            output_path: 输出文件路径。
            include_metadata: 是否包含元数据。
        """
        yaml_str = self.export_all(schemas, include_metadata)
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(yaml_str, encoding="utf-8")
