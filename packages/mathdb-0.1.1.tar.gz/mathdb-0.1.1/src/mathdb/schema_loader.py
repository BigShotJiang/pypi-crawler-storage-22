"""Schema 加载器模块。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from mathdb.schema import TableSchema, ColumnDef


@dataclass
class TableInfo:
    """表信息（从 YAML 加载的原始数据）。
    
    Attributes:
        table_name: 表名。
        columns: 列定义列表。
        metadata: 表元数据（可选）。
    """
    table_name: str
    columns: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_table_schema(self) -> TableSchema:
        """转换为 TableSchema。"""
        column_defs = []
        for col in self.columns:
            column_defs.append(
                ColumnDef(
                    name=col["name"],
                    dtype=col["dtype"],
                    primary_key=col.get("primary_key", False),
                    nullable=col.get("nullable", True),
                )
            )
        return TableSchema(name=self.table_name, columns=column_defs)


class SchemaLoader:
    """Schema 加载器。
    
    从 YAML 文件加载表结构定义。
    """

    def load(self, schema_path: Path | str) -> list[TableInfo]:
        """从 YAML 文件加载 Schema。
        
        Args:
            schema_path: Schema 文件路径。
            
        Returns:
            TableInfo 列表。
            
        Raises:
            FileNotFoundError: 文件不存在。
        """
        schema_path = Path(schema_path)
        if not schema_path.exists():
            raise FileNotFoundError(f"Schema 文件不存在: {schema_path}")

        with open(schema_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        return self._parse_tables(data)

    def load_from_string(self, yaml_content: str) -> list[TableInfo]:
        """从 YAML 字符串加载 Schema。
        
        Args:
            yaml_content: YAML 格式的字符串。
            
        Returns:
            TableInfo 列表。
        """
        data = yaml.safe_load(yaml_content)
        return self._parse_tables(data)

    def load_as_schemas(self, schema_path: Path | str) -> list[TableSchema]:
        """从 YAML 文件加载并转换为 TableSchema 列表。
        
        Args:
            schema_path: Schema 文件路径。
            
        Returns:
            TableSchema 列表。
        """
        table_infos = self.load(schema_path)
        return [info.to_table_schema() for info in table_infos]

    def _parse_tables(self, data: dict) -> list[TableInfo]:
        """解析表定义数据。"""
        if data is None or "tables" not in data:
            return []

        tables = data.get("tables", [])
        if tables is None:
            return []

        result = []
        for table_data in tables:
            info = TableInfo(
                table_name=table_data["table_name"],
                columns=table_data.get("columns", []),
                metadata=table_data.get("metadata", {}),
            )
            result.append(info)
        return result
