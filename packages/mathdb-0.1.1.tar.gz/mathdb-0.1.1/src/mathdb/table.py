"""Table - 持久化内存表。

MathDB 2.0 重构版本，支持 Polars/Pandas 双后端。
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any, Union

from mathdb.backend import Backend, BackendType, PolarsBackend
from mathdb.schema import TableSchema
from mathdb.ops import Op, OpType
from mathdb.wal import WALWriter
from mathdb.recovery import Recovery


# 类型别名
DataFrameT = Any  # pl.DataFrame | pd.DataFrame


class Table:
    """持久化内存表。
    
    将 DataFrame 作为内存数据库使用，提供:
    - CRUD 操作 (insert, update, delete, upsert)
    - 后端无关的查询能力
    - 周期性持久化到磁盘
    
    Attributes:
        schema: 表结构定义。
        data_dir: 数据目录路径。
    """

    def __init__(
        self,
        schema: TableSchema,
        data_dir: str | Path = "./data",
        backend: Backend | None = None,
        flush_interval: float = 3.0,
        enable_persistence: bool = True,
    ) -> None:
        """初始化表。
        
        Args:
            schema: 表结构定义。
            data_dir: 数据存储目录。
            backend: DataFrame 后端。默认使用 Polars。
            flush_interval: 刷盘间隔（秒）。设为 0 禁用自动刷盘。
            enable_persistence: 是否启用持久化。
        """
        self._schema = schema
        self._base_data_dir = Path(data_dir)
        self._data_dir = self._base_data_dir / schema.name
        self._data_dir.mkdir(parents=True, exist_ok=True)
        
        # 后端
        self._backend = backend or PolarsBackend()
        
        # 持久化设置
        self._enable_persistence = enable_persistence
        self._flush_interval = flush_interval
        
        # WAL
        self._wal_dir = self._data_dir / "wal"
        self._wal_writer: WALWriter | None = None
        self._op_buffer: list[Op] = []
        self._lock = threading.RLock()
        
        if enable_persistence:
            self._wal_dir.mkdir(parents=True, exist_ok=True)
            self._wal_writer = WALWriter(self._wal_dir, schema)
        
        # 恢复数据
        if enable_persistence:
            recovery = Recovery(self._data_dir, schema, self._backend)
            self._df = recovery.recover()
        else:
            self._df = self._backend.create_empty_dataframe(schema)
        
        self._closed = False
        
        # 自动刷盘定时器
        self._flush_timer: threading.Timer | None = None
        if enable_persistence and flush_interval > 0:
            self._start_flush_timer()

    def _start_flush_timer(self) -> None:
        """启动刷盘定时器。"""
        self._flush_timer = threading.Timer(self._flush_interval, self._auto_flush)
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _auto_flush(self) -> None:
        """自动刷盘回调。"""
        if self._closed:
            return
        self.flush()
        self._start_flush_timer()

    @property
    def name(self) -> str:
        """获取表名。"""
        return self._schema.name

    @property
    def schema(self) -> TableSchema:
        """获取表结构。"""
        return self._schema

    @property
    def data_dir(self) -> Path:
        """获取数据目录。"""
        return self._data_dir

    @property
    def backend_type(self) -> BackendType:
        """获取后端类型。"""
        return self._backend.backend_type

    @property
    def pending_op_count(self) -> int:
        """获取待刷盘的操作数量。"""
        with self._lock:
            return len(self._op_buffer)

    # ==================== CRUD 操作 ====================

    def insert(self, row: dict[str, Any]) -> None:
        """插入一行新数据。
        
        Args:
            row: 行数据字典（必须包含主键）。
        """
        self._check_closed()
        self._schema.validate_row(row)
        
        with self._lock:
            self._df = self._backend.insert_row(self._df, row, self._schema)
            if self._enable_persistence:
                pk = row[self._schema.pk_name]
                self._op_buffer.append(Op(OpType.INSERT, pk=pk, row=row))

    def update(self, pk: Any, row: dict[str, Any]) -> None:
        """更新现有行。
        
        Args:
            pk: 主键值。
            row: 完整的行数据（必须包含主键）。
        """
        self._check_closed()
        self._schema.validate_row(row)
        pk_col = self._schema.pk_name
        
        with self._lock:
            self._df = self._backend.update_row(self._df, pk_col, pk, row, self._schema)
            if self._enable_persistence:
                self._op_buffer.append(Op(OpType.UPDATE, pk=pk, row=row))

    def delete(self, pk: Any) -> None:
        """根据主键删除一行。
        
        Args:
            pk: 主键值。
        """
        self._check_closed()
        pk_col = self._schema.pk_name
        
        with self._lock:
            self._df = self._backend.delete_row(self._df, pk_col, pk)
            if self._enable_persistence:
                self._op_buffer.append(Op(OpType.DELETE, pk=pk))

    def upsert(self, row: dict[str, Any]) -> None:
        """插入或更新一行 (upsert)。
        
        如果行存在（根据 pk），则更新。否则插入。
        
        Args:
            row: 行数据字典（必须包含主键）。
        """
        self._check_closed()
        self._schema.validate_row(row)
        pk_col = self._schema.pk_name
        pk = row[pk_col]
        
        with self._lock:
            existing = self._backend.get_row(self._df, pk_col, pk)
            if existing is not None:
                self._df = self._backend.update_row(self._df, pk_col, pk, row, self._schema)
            else:
                self._df = self._backend.insert_row(self._df, row, self._schema)
            if self._enable_persistence:
                self._op_buffer.append(Op(OpType.UPSERT, pk=pk, row=row))

    # ==================== 查询操作 ====================

    def get(self, pk: Any) -> dict[str, Any] | None:
        """根据主键获取一行。
        
        Args:
            pk: 主键值。
            
        Returns:
            行数据字典，如果未找到则返回 None。
        """
        self._check_closed()
        pk_col = self._schema.pk_name
        with self._lock:
            return self._backend.get_row(self._df, pk_col, pk)

    def count(self) -> int:
        """获取表中的行数。"""
        self._check_closed()
        with self._lock:
            return self._backend.row_count(self._df)

    def to_dataframe(self) -> DataFrameT:
        """获取表的 DataFrame 副本。
        
        返回当前表数据的副本。
        
        注意: 对返回的 DataFrame 的修改不会被持久化。
        需要持久化的修改请使用 insert/update/delete/upsert 方法。
        
        Returns:
            表的 DataFrame 副本。
        """
        self._check_closed()
        with self._lock:
            # 根据后端类型返回副本
            if self._backend.backend_type == BackendType.POLARS:
                return self._df.clone()
            else:
                return self._df.copy()

    # ==================== Schema 导出 ====================

    def export_schema(self) -> TableSchema:
        """获取表的 Schema 定义。"""
        return self._schema

    def to_yaml_schema(self) -> str:
        """导出表结构为 YAML 字符串。"""
        from mathdb.schema_exporter import SchemaExporter
        exporter = SchemaExporter(backend_type=self._backend.backend_type)
        result = exporter.export_all([self._schema])
        return result

    # ==================== 管理操作 ====================

    def get_stats(self) -> dict[str, Any]:
        """获取表的统计信息。"""
        return {
            "table_name": self._schema.name,
            "row_count": self.count(),
            "pending_ops": self.pending_op_count,
            "data_dir": str(self._data_dir),
            "backend": self._backend.backend_type.value,
        }

    def flush(self) -> None:
        """手动刷盘。"""
        if not self._enable_persistence or self._wal_writer is None:
            return
        
        with self._lock:
            if self._op_buffer:
                self._wal_writer.write(self._op_buffer)
                self._op_buffer.clear()

    def close(self) -> None:
        """关闭表。"""
        if self._closed:
            return
        
        # 停止定时器
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None
        
        # 刷盘
        self.flush()
        self._closed = True

    def __enter__(self) -> "Table":
        """上下文管理器入口。"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """上下文管理器退出。"""
        self.close()

    def __len__(self) -> int:
        """返回行数。"""
        return self.count()

    def _check_closed(self) -> None:
        """检查表是否已关闭。"""
        if self._closed:
            raise RuntimeError(f"表 '{self._schema.name}' 已关闭。")
