"""WAL 2.0 模块 - 适配新架构的 Write-Ahead Log。

简化的 WAL 实现，使用 Arrow IPC 格式存储操作日志。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import polars as pl
import pyarrow as pa
import pyarrow.ipc as ipc

from mathdb.ops import Op, OpType
from mathdb.schema import TableSchema


# WAL 段文件名格式: seg_XXXX.arrow
SEGMENT_PATTERN = re.compile(r"seg_(\d+)\.arrow$")


@dataclass
class WALSegment:
    """WAL 段数据。
    
    Attributes:
        segment_id: 段 ID。
        ops: 操作列表。
        schema: 表结构。
    """
    segment_id: int
    ops: list[Op]
    schema: TableSchema

    def to_dataframe(self) -> pl.DataFrame:
        """转换为 DataFrame（用于序列化）。"""
        if not self.ops:
            return self._empty_dataframe()

        op_list: list[str] = []
        pk_list: list[Any] = []
        ts_list: list[int] = []
        row_data: dict[str, list[Any]] = {col.name: [] for col in self.schema.columns}

        for op in self.ops:
            op_list.append(op.op_type.value)
            pk_list.append(op.pk)
            ts_list.append(op.ts)

            if op.row is not None:
                for col in self.schema.columns:
                    row_data[col.name].append(op.row.get(col.name))
            else:
                for col in self.schema.columns:
                    row_data[col.name].append(None)

        data: dict[str, Any] = {
            "op": op_list,
            "pk": pk_list,
            "ts": ts_list,
        }
        data.update(row_data)
        return pl.DataFrame(data)

    def _empty_dataframe(self) -> pl.DataFrame:
        """创建空 DataFrame。"""
        base_schema: dict[str, pl.DataType] = {
            "op": pl.Utf8,
            "pk": self.schema.get_primary_key().to_polars_dtype(),
            "ts": pl.Int64,
        }
        for col in self.schema.columns:
            base_schema[col.name] = col.to_polars_dtype()
        return pl.DataFrame(schema=base_schema)

    @classmethod
    def from_dataframe(cls, segment_id: int, df: pl.DataFrame, schema: TableSchema) -> "WALSegment":
        """从 DataFrame 恢复。"""
        ops = []
        for row in df.iter_rows(named=True):
            op_type = OpType(row["op"])
            pk = row["pk"]
            ts = row["ts"]
            
            # 提取行数据
            row_data = {col.name: row[col.name] for col in schema.columns}
            
            ops.append(Op(op_type=op_type, pk=pk, row=row_data if op_type != OpType.DELETE else None, ts=ts))
        
        return cls(segment_id=segment_id, ops=ops, schema=schema)


class WALWriter:
    """WAL 写入器。"""

    def __init__(self, wal_dir: Path, schema: TableSchema) -> None:
        """初始化。
        
        Args:
            wal_dir: WAL 目录。
            schema: 表结构。
        """
        self._wal_dir = wal_dir
        self._schema = schema
        self._wal_dir.mkdir(parents=True, exist_ok=True)
        self._next_segment_id = self._find_next_segment_id()

    def write(self, ops: list[Op]) -> int:
        """写入一批操作。
        
        Args:
            ops: 操作列表。
            
        Returns:
            写入的段 ID，如果没有写入则返回 0。
        """
        if not ops:
            return 0

        segment_id = self._next_segment_id
        segment = WALSegment(segment_id=segment_id, ops=ops, schema=self._schema)
        
        # 转换为 Arrow 并写入
        df = segment.to_dataframe()
        arrow_table = df.to_arrow()
        
        # 使用 tmp + rename 保证原子性
        segment_file = self._wal_dir / f"seg_{segment_id:04d}.arrow"
        tmp_file = self._wal_dir / f"seg_{segment_id:04d}.arrow.tmp"
        
        with open(tmp_file, "wb") as f:
            writer = ipc.new_file(f, arrow_table.schema)
            writer.write_table(arrow_table)
            writer.close()
        
        tmp_file.rename(segment_file)
        self._next_segment_id += 1
        
        return segment_id

    @property
    def last_segment_id(self) -> int:
        """获取最后写入的段 ID。"""
        return self._next_segment_id - 1

    def _find_next_segment_id(self) -> int:
        """查找下一个可用的段 ID。"""
        max_id = 0
        for path in self._wal_dir.glob("seg_*.arrow"):
            match = SEGMENT_PATTERN.match(path.name)
            if match:
                seg_id = int(match.group(1))
                max_id = max(max_id, seg_id)
        return max_id + 1


class WALReader:
    """WAL 读取器。"""

    def __init__(self, wal_dir: Path, schema: TableSchema) -> None:
        """初始化。
        
        Args:
            wal_dir: WAL 目录。
            schema: 表结构。
        """
        self._wal_dir = wal_dir
        self._schema = schema

    def read_segment(self, segment_id: int) -> WALSegment | None:
        """读取指定段。
        
        Args:
            segment_id: 段 ID。
            
        Returns:
            WAL 段，如果不存在则返回 None。
        """
        segment_file = self._wal_dir / f"seg_{segment_id:04d}.arrow"
        if not segment_file.exists():
            return None

        with open(segment_file, "rb") as f:
            reader = ipc.open_file(f)
            arrow_table = reader.read_all()

        df = pl.from_arrow(arrow_table)
        return WALSegment.from_dataframe(segment_id, df, self._schema)

    def read_all(self) -> list[WALSegment]:
        """读取所有段。"""
        segments = []
        for seg_id in self.list_segment_ids():
            segment = self.read_segment(seg_id)
            if segment:
                segments.append(segment)
        return segments

    def read_after(self, after_segment_id: int) -> list[WALSegment]:
        """读取指定 ID 之后的段。
        
        Args:
            after_segment_id: 起始段 ID（不包含）。
            
        Returns:
            段列表。
        """
        segments = []
        for seg_id in self.list_segment_ids():
            if seg_id > after_segment_id:
                segment = self.read_segment(seg_id)
                if segment:
                    segments.append(segment)
        return segments

    def list_segment_ids(self) -> list[int]:
        """列出所有段 ID。"""
        ids = []
        for path in self._wal_dir.glob("seg_*.arrow"):
            match = SEGMENT_PATTERN.match(path.name)
            if match:
                ids.append(int(match.group(1)))
        return sorted(ids)
