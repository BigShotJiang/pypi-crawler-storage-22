"""Backend 抽象层测试 - TDD 先行。"""

import pytest
import polars as pl
import pandas as pd

from mathdb.backend import (
    Backend,
    BackendType,
    PolarsBackend,
    PandasBackend,
    BackendFactory,
)
from mathdb.schema import TableSchema, ColumnDef


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("name", "Utf8"),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


class TestBackendType:
    """BackendType 枚举测试。"""

    def test_polars_value(self):
        assert BackendType.POLARS.value == "polars"

    def test_pandas_value(self):
        assert BackendType.PANDAS.value == "pandas"

    def test_from_string(self):
        assert BackendType("polars") == BackendType.POLARS
        assert BackendType("pandas") == BackendType.PANDAS


class TestPolarsBackend:
    """PolarsBackend 测试。"""

    @pytest.fixture
    def backend(self) -> PolarsBackend:
        return PolarsBackend()

    def test_backend_type(self, backend: PolarsBackend):
        assert backend.backend_type == BackendType.POLARS

    def test_create_empty_dataframe(self, backend: PolarsBackend, user_schema: TableSchema):
        df = backend.create_empty_dataframe(user_schema)
        assert isinstance(df, pl.DataFrame)
        assert len(df) == 0
        assert df.columns == ["id", "name", "age"]

    def test_from_dict(self, backend: PolarsBackend):
        data = {"id": [1, 2], "name": ["Alice", "Bob"]}
        df = backend.from_dict(data)
        assert isinstance(df, pl.DataFrame)
        assert len(df) == 2

    def test_insert_row(self, backend: PolarsBackend, user_schema: TableSchema):
        df = backend.create_empty_dataframe(user_schema)
        row = {"id": 1, "name": "Alice", "age": 25}
        new_df = backend.insert_row(df, row, user_schema)
        assert len(new_df) == 1
        assert new_df["id"][0] == 1
        assert new_df["name"][0] == "Alice"

    def test_update_row(self, backend: PolarsBackend, user_schema: TableSchema):
        # 使用 schema 创建 DataFrame 确保类型正确
        df = backend.create_empty_dataframe(user_schema)
        df = backend.insert_row(df, {"id": 1, "name": "Alice", "age": 25}, user_schema)
        row = {"id": 1, "name": "Alice Updated", "age": 26}
        new_df = backend.update_row(df, "id", 1, row, user_schema)
        assert len(new_df) == 1
        assert new_df["name"][0] == "Alice Updated"
        assert new_df["age"][0] == 26

    def test_delete_row(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1, 2], "name": ["Alice", "Bob"], "age": [25, 30]})
        new_df = backend.delete_row(df, "id", 1)
        assert len(new_df) == 1
        assert new_df["id"][0] == 2

    def test_get_row(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1, 2], "name": ["Alice", "Bob"], "age": [25, 30]})
        row = backend.get_row(df, "id", 1)
        assert row is not None
        assert row["id"] == 1
        assert row["name"] == "Alice"

    def test_get_row_not_found(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        row = backend.get_row(df, "id", 999)
        assert row is None

    def test_row_count(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1, 2, 3], "name": ["A", "B", "C"], "age": [1, 2, 3]})
        assert backend.row_count(df) == 3

    def test_to_arrow(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        arrow_table = backend.to_arrow(df)
        assert arrow_table is not None
        assert arrow_table.num_rows == 1

    def test_from_arrow(self, backend: PolarsBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        arrow_table = backend.to_arrow(df)
        restored = backend.from_arrow(arrow_table)
        assert isinstance(restored, pl.DataFrame)
        assert len(restored) == 1


class TestPandasBackend:
    """PandasBackend 测试。"""

    @pytest.fixture
    def backend(self) -> PandasBackend:
        return PandasBackend()

    def test_backend_type(self, backend: PandasBackend):
        assert backend.backend_type == BackendType.PANDAS

    def test_create_empty_dataframe(self, backend: PandasBackend, user_schema: TableSchema):
        df = backend.create_empty_dataframe(user_schema)
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 0
        assert list(df.columns) == ["id", "name", "age"]

    def test_from_dict(self, backend: PandasBackend):
        data = {"id": [1, 2], "name": ["Alice", "Bob"]}
        df = backend.from_dict(data)
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2

    def test_insert_row(self, backend: PandasBackend, user_schema: TableSchema):
        df = backend.create_empty_dataframe(user_schema)
        row = {"id": 1, "name": "Alice", "age": 25}
        new_df = backend.insert_row(df, row, user_schema)
        assert len(new_df) == 1
        assert new_df["id"].iloc[0] == 1
        assert new_df["name"].iloc[0] == "Alice"

    def test_update_row(self, backend: PandasBackend, user_schema: TableSchema):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        row = {"id": 1, "name": "Alice Updated", "age": 26}
        new_df = backend.update_row(df, "id", 1, row, user_schema)
        assert len(new_df) == 1
        assert new_df["name"].iloc[0] == "Alice Updated"
        assert new_df["age"].iloc[0] == 26

    def test_delete_row(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1, 2], "name": ["Alice", "Bob"], "age": [25, 30]})
        new_df = backend.delete_row(df, "id", 1)
        assert len(new_df) == 1
        assert new_df["id"].iloc[0] == 2

    def test_get_row(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1, 2], "name": ["Alice", "Bob"], "age": [25, 30]})
        row = backend.get_row(df, "id", 1)
        assert row is not None
        assert row["id"] == 1
        assert row["name"] == "Alice"

    def test_get_row_not_found(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        row = backend.get_row(df, "id", 999)
        assert row is None

    def test_row_count(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1, 2, 3], "name": ["A", "B", "C"], "age": [1, 2, 3]})
        assert backend.row_count(df) == 3

    def test_to_arrow(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        arrow_table = backend.to_arrow(df)
        assert arrow_table is not None
        assert arrow_table.num_rows == 1

    def test_from_arrow(self, backend: PandasBackend):
        df = backend.from_dict({"id": [1], "name": ["Alice"], "age": [25]})
        arrow_table = backend.to_arrow(df)
        restored = backend.from_arrow(arrow_table)
        assert isinstance(restored, pd.DataFrame)
        assert len(restored) == 1


class TestBackendFactory:
    """BackendFactory 测试。"""

    def test_create_polars_backend(self):
        backend = BackendFactory.create(BackendType.POLARS)
        assert isinstance(backend, PolarsBackend)

    def test_create_pandas_backend(self):
        backend = BackendFactory.create(BackendType.PANDAS)
        assert isinstance(backend, PandasBackend)

    def test_create_from_string(self):
        backend = BackendFactory.create("polars")
        assert isinstance(backend, PolarsBackend)
        
        backend = BackendFactory.create("pandas")
        assert isinstance(backend, PandasBackend)

    def test_default_is_polars(self):
        backend = BackendFactory.create()
        assert isinstance(backend, PolarsBackend)
