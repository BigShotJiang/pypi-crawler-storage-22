"""Config 配置管理模块测试 - TDD 先行。"""

import pytest
import tempfile
from pathlib import Path
import yaml

from mathdb.config import (
    MathDBConfig,
    WALConfig,
    SnapshotConfig,
    RecoveryConfig,
    load_config,
)
from mathdb.backend import BackendType


class TestWALConfig:
    """WAL 配置测试。"""

    def test_default_values(self):
        config = WALConfig()
        assert config.enabled is True
        assert config.flush_interval == 3.0
        assert config.sync_on_flush is False

    def test_custom_values(self):
        config = WALConfig(
            enabled=False,
            flush_interval=1.0,
            sync_on_flush=True,
        )
        assert config.enabled is False
        assert config.flush_interval == 1.0
        assert config.sync_on_flush is True


class TestSnapshotConfig:
    """快照配置测试。"""

    def test_default_values(self):
        config = SnapshotConfig()
        assert config.enabled is True
        assert config.auto_compact is True
        assert config.compact_threshold == 100
        assert config.max_snapshots == 3

    def test_custom_values(self):
        config = SnapshotConfig(
            enabled=False,
            auto_compact=False,
            compact_threshold=50,
            max_snapshots=5,
        )
        assert config.enabled is False
        assert config.auto_compact is False
        assert config.compact_threshold == 50
        assert config.max_snapshots == 5


class TestRecoveryConfig:
    """恢复配置测试。"""

    def test_default_values(self):
        config = RecoveryConfig()
        assert config.enabled is True
        assert config.mode == "auto"

    def test_custom_values(self):
        config = RecoveryConfig(
            enabled=False,
            mode="snapshot_only",
        )
        assert config.enabled is False
        assert config.mode == "snapshot_only"


class TestMathDBConfig:
    """MathDB 主配置测试。"""

    def test_default_values(self):
        config = MathDBConfig()
        assert config.name == "mathdb"
        assert config.data_dir == Path("./data")
        assert config.backend == BackendType.POLARS
        assert config.schema_path is None
        assert isinstance(config.wal, WALConfig)
        assert isinstance(config.snapshot, SnapshotConfig)
        assert isinstance(config.recovery, RecoveryConfig)

    def test_custom_values(self):
        config = MathDBConfig(
            name="my-db",
            data_dir=Path("/tmp/mydb"),
            backend=BackendType.PANDAS,
            schema_path="schema.yaml",
        )
        assert config.name == "my-db"
        assert config.data_dir == Path("/tmp/mydb")
        assert config.backend == BackendType.PANDAS
        assert config.schema_path == "schema.yaml"

    def test_string_data_dir(self):
        """测试字符串路径自动转换。"""
        config = MathDBConfig(data_dir="./my-data")
        assert config.data_dir == Path("./my-data")

    def test_string_backend(self):
        """测试字符串后端类型自动转换。"""
        config = MathDBConfig(backend="pandas")
        assert config.backend == BackendType.PANDAS


class TestLoadConfig:
    """配置加载测试。"""

    def test_load_from_yaml(self, tmp_path: Path):
        """测试从 YAML 文件加载配置。"""
        yaml_content = """
mathdb:
  name: test-db
  data_dir: ./test-data
  backend: polars
  schema_path: schema.yaml
  
  wal:
    enabled: true
    flush_interval: 1.0
    sync_on_flush: true
    
  snapshot:
    enabled: true
    auto_compact: false
    compact_threshold: 50
    max_snapshots: 5
    
  recovery:
    enabled: true
    mode: snapshot_wal
"""
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text(yaml_content)

        config = load_config(yaml_file)

        assert config.name == "test-db"
        assert config.data_dir == Path("./test-data")
        assert config.backend == BackendType.POLARS
        assert config.schema_path == "schema.yaml"
        
        assert config.wal.enabled is True
        assert config.wal.flush_interval == 1.0
        assert config.wal.sync_on_flush is True
        
        assert config.snapshot.enabled is True
        assert config.snapshot.auto_compact is False
        assert config.snapshot.compact_threshold == 50
        assert config.snapshot.max_snapshots == 5
        
        assert config.recovery.enabled is True
        assert config.recovery.mode == "snapshot_wal"

    def test_load_minimal_yaml(self, tmp_path: Path):
        """测试加载最小配置。"""
        yaml_content = """
mathdb:
  name: minimal-db
"""
        yaml_file = tmp_path / "minimal.yaml"
        yaml_file.write_text(yaml_content)

        config = load_config(yaml_file)

        assert config.name == "minimal-db"
        # 其他使用默认值
        assert config.backend == BackendType.POLARS
        assert config.wal.flush_interval == 3.0

    def test_load_with_pandas_backend(self, tmp_path: Path):
        """测试 Pandas 后端配置。"""
        yaml_content = """
mathdb:
  name: pandas-db
  backend: pandas
"""
        yaml_file = tmp_path / "pandas.yaml"
        yaml_file.write_text(yaml_content)

        config = load_config(yaml_file)
        assert config.backend == BackendType.PANDAS

    def test_load_nonexistent_file(self):
        """测试加载不存在的文件。"""
        with pytest.raises(FileNotFoundError):
            load_config(Path("/nonexistent/config.yaml"))

    def test_config_to_dict(self):
        """测试配置转换为字典。"""
        config = MathDBConfig(name="test")
        d = config.to_dict()
        assert d["name"] == "test"
        assert "wal" in d
        assert "snapshot" in d
        assert "recovery" in d
