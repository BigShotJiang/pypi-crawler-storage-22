"""MathDB 全局管理器测试 - TDD 先行。"""

import pytest
from pathlib import Path
import tempfile
import shutil

from mathdb.mathdb import MathDB
from mathdb.config import MathDBConfig
from mathdb.schema import TableSchema, ColumnDef
from mathdb.backend import BackendType


@pytest.fixture
def temp_data_dir(tmp_path: Path) -> Path:
    """临时数据目录。"""
    return tmp_path / "mathdb_data"


@pytest.fixture
def sample_config(temp_data_dir: Path) -> MathDBConfig:
    """示例配置。"""
    return MathDBConfig(
        name="test-db",
        data_dir=temp_data_dir,
        backend=BackendType.POLARS,
    )


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("name", "Utf8"),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


@pytest.fixture(autouse=True)
def reset_mathdb():
    """每个测试后重置 MathDB。"""
    yield
    if MathDB.is_initialized():
        MathDB.close()


class TestMathDBLifecycle:
    """MathDB 生命周期测试。"""

    def test_init_with_config_object(self, sample_config: MathDBConfig):
        """测试使用配置对象初始化。"""
        MathDB.init(sample_config)
        assert MathDB.is_initialized()

    def test_init_with_yaml_file(self, tmp_path: Path):
        """测试使用 YAML 文件初始化。"""
        yaml_content = f"""
mathdb:
  name: yaml-test-db
  data_dir: {tmp_path / "data"}
  backend: polars
"""
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text(yaml_content)

        MathDB.init(str(yaml_file))
        assert MathDB.is_initialized()
        assert MathDB.get_config().name == "yaml-test-db"

    def test_init_default(self, temp_data_dir: Path):
        """测试默认初始化。"""
        MathDB.init(MathDBConfig(data_dir=temp_data_dir))
        assert MathDB.is_initialized()

    def test_double_init_raises(self, sample_config: MathDBConfig):
        """测试重复初始化抛出异常。"""
        MathDB.init(sample_config)
        with pytest.raises(RuntimeError, match="已初始化"):
            MathDB.init(sample_config)

    def test_close(self, sample_config: MathDBConfig):
        """测试关闭。"""
        MathDB.init(sample_config)
        MathDB.close()
        assert not MathDB.is_initialized()

    def test_is_initialized_before_init(self):
        """测试初始化前状态。"""
        assert not MathDB.is_initialized()


class TestMathDBTableManagement:
    """MathDB 表管理测试。"""

    def test_create_table(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试创建表。"""
        MathDB.init(sample_config)
        table = MathDB.create_table(user_schema)

        assert table is not None
        assert table.schema.name == "users"

    def test_get_table(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试获取表。"""
        MathDB.init(sample_config)
        MathDB.create_table(user_schema)

        table = MathDB.get_table("users")
        assert table is not None
        assert table.schema.name == "users"

    def test_get_nonexistent_table_raises(self, sample_config: MathDBConfig):
        """测试获取不存在的表抛出异常。"""
        MathDB.init(sample_config)
        with pytest.raises(KeyError):
            MathDB.get_table("nonexistent")

    def test_get_table_or_none(self, sample_config: MathDBConfig):
        """测试获取表或返回 None。"""
        MathDB.init(sample_config)
        table = MathDB.get_table_or_none("nonexistent")
        assert table is None

    def test_table_exists(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试表是否存在。"""
        MathDB.init(sample_config)
        assert not MathDB.table_exists("users")

        MathDB.create_table(user_schema)
        assert MathDB.table_exists("users")

    def test_drop_table(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试删除表。"""
        MathDB.init(sample_config)
        MathDB.create_table(user_schema)
        assert MathDB.table_exists("users")

        result = MathDB.drop_table("users")
        assert result is True
        assert not MathDB.table_exists("users")

    def test_drop_nonexistent_table(self, sample_config: MathDBConfig):
        """测试删除不存在的表。"""
        MathDB.init(sample_config)
        result = MathDB.drop_table("nonexistent")
        assert result is False

    def test_list_tables(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试列出所有表。"""
        MathDB.init(sample_config)
        assert MathDB.list_tables() == []

        MathDB.create_table(user_schema)
        tables = MathDB.list_tables()
        assert "users" in tables

    def test_get_table_count(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试获取表数量。"""
        MathDB.init(sample_config)
        assert MathDB.get_table_count() == 0

        MathDB.create_table(user_schema)
        assert MathDB.get_table_count() == 1

    def test_create_duplicate_table_raises(
        self, sample_config: MathDBConfig, user_schema: TableSchema
    ):
        """测试创建重复表抛出异常。"""
        MathDB.init(sample_config)
        MathDB.create_table(user_schema)

        with pytest.raises(ValueError, match="已存在"):
            MathDB.create_table(user_schema)


class TestMathDBSchemaManagement:
    """MathDB Schema 管理测试。"""

    def test_load_schema(self, sample_config: MathDBConfig, tmp_path: Path):
        """测试加载 Schema。"""
        yaml_content = """
tables:
  - table_name: products
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: name
        dtype: Utf8
"""
        schema_file = tmp_path / "schema.yaml"
        schema_file.write_text(yaml_content)

        MathDB.init(sample_config)
        count = MathDB.load_schema(str(schema_file))

        assert count == 1
        assert MathDB.table_exists("products")

    def test_export_schema(
        self, sample_config: MathDBConfig, user_schema: TableSchema, tmp_path: Path
    ):
        """测试导出 Schema。"""
        MathDB.init(sample_config)
        MathDB.create_table(user_schema)

        output_file = tmp_path / "exported_schema.yaml"
        yaml_str = MathDB.export_schema(str(output_file))

        assert yaml_str is not None
        assert output_file.exists()
        assert "users" in output_file.read_text()

    def test_export_schema_to_string_only(
        self, sample_config: MathDBConfig, user_schema: TableSchema
    ):
        """测试仅导出为字符串。"""
        MathDB.init(sample_config)
        MathDB.create_table(user_schema)

        yaml_str = MathDB.export_schema()
        assert "users" in yaml_str

    def test_export_schema_specific_tables(
        self, sample_config: MathDBConfig, user_schema: TableSchema
    ):
        """测试导出指定表。"""
        order_schema = TableSchema(
            name="orders",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("total", "Float64"),
            ],
        )

        MathDB.init(sample_config)
        MathDB.create_table(user_schema)
        MathDB.create_table(order_schema)

        yaml_str = MathDB.export_schema(table_names=["orders"])
        assert "orders" in yaml_str
        assert "users" not in yaml_str


class TestMathDBContextManager:
    """MathDB 上下文管理器测试。"""

    def test_context_manager(self, sample_config: MathDBConfig):
        """测试上下文管理器。"""
        with MathDB.context(sample_config) as db:
            assert MathDB.is_initialized()

        assert not MathDB.is_initialized()

    def test_context_manager_with_exception(self, sample_config: MathDBConfig):
        """测试上下文管理器异常处理。"""
        try:
            with MathDB.context(sample_config):
                raise ValueError("Test error")
        except ValueError:
            pass

        # 即使出现异常也应该正确关闭
        assert not MathDB.is_initialized()


class TestMathDBCRUD:
    """MathDB CRUD 操作测试（通过表）。"""

    def test_insert_and_get(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试插入和获取。"""
        MathDB.init(sample_config)
        table = MathDB.create_table(user_schema)

        table.insert({"id": 1, "name": "Alice", "age": 25})
        row = table.get(1)

        assert row is not None
        assert row["id"] == 1
        assert row["name"] == "Alice"
        assert row["age"] == 25

    def test_update(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试更新。"""
        MathDB.init(sample_config)
        table = MathDB.create_table(user_schema)

        table.insert({"id": 1, "name": "Alice", "age": 25})
        table.update(1, {"id": 1, "name": "Alice Updated", "age": 26})

        row = table.get(1)
        assert row["name"] == "Alice Updated"
        assert row["age"] == 26

    def test_delete(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试删除。"""
        MathDB.init(sample_config)
        table = MathDB.create_table(user_schema)

        table.insert({"id": 1, "name": "Alice", "age": 25})
        table.delete(1)

        row = table.get(1)
        assert row is None

    def test_count(self, sample_config: MathDBConfig, user_schema: TableSchema):
        """测试行数。"""
        MathDB.init(sample_config)
        table = MathDB.create_table(user_schema)

        assert table.count() == 0

        table.insert({"id": 1, "name": "Alice", "age": 25})
        table.insert({"id": 2, "name": "Bob", "age": 30})

        assert table.count() == 2
