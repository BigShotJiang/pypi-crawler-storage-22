"""Tests for Op and OpType."""

import pytest
import time

from mathdb.ops import Op, OpType


class TestOpType:
    """Tests for OpType enum."""

    def test_op_types_exist(self):
        """Test that all operation types exist."""
        assert OpType.INSERT.value == "I"
        assert OpType.UPDATE.value == "U"
        assert OpType.DELETE.value == "D"

    def test_from_string(self):
        """Test creating OpType from string."""
        assert OpType.from_string("I") == OpType.INSERT
        assert OpType.from_string("U") == OpType.UPDATE
        assert OpType.from_string("D") == OpType.DELETE

    def test_from_invalid_string(self):
        """Test that invalid string raises error."""
        with pytest.raises(ValueError):
            OpType.from_string("X")


class TestOp:
    """Tests for Op dataclass."""

    def test_create_insert_op(self):
        """Test creating an insert operation."""
        op = Op.insert(pk=1, row={"id": 1, "name": "Alice", "age": 30})
        assert op.op_type == OpType.INSERT
        assert op.pk == 1
        assert op.row == {"id": 1, "name": "Alice", "age": 30}
        assert op.ts > 0

    def test_create_update_op(self):
        """Test creating an update operation."""
        op = Op.update(pk=1, row={"id": 1, "name": "Alice", "age": 31})
        assert op.op_type == OpType.UPDATE
        assert op.pk == 1
        assert op.row == {"id": 1, "name": "Alice", "age": 31}

    def test_create_delete_op(self):
        """Test creating a delete operation."""
        op = Op.delete(pk=1)
        assert op.op_type == OpType.DELETE
        assert op.pk == 1
        assert op.row is None

    def test_op_timestamp_is_monotonic(self):
        """Test that operation timestamps are monotonically increasing."""
        op1 = Op.insert(pk=1, row={"id": 1})
        time.sleep(0.001)
        op2 = Op.insert(pk=2, row={"id": 2})
        assert op2.ts >= op1.ts

    def test_op_with_custom_timestamp(self):
        """Test creating an op with custom timestamp."""
        custom_ts = 1234567890000
        op = Op(op_type=OpType.INSERT, pk=1, ts=custom_ts, row={"id": 1})
        assert op.ts == custom_ts

    def test_op_to_dict(self):
        """Test converting op to dictionary."""
        op = Op.insert(pk=1, row={"id": 1, "name": "Alice"})
        d = op.to_dict()
        assert d["op"] == "I"
        assert d["pk"] == 1
        assert d["ts"] == op.ts
        assert d["row"] == {"id": 1, "name": "Alice"}

    def test_op_from_dict(self):
        """Test creating op from dictionary."""
        d = {"op": "I", "pk": 1, "ts": 1234567890000, "row": {"id": 1, "name": "Alice"}}
        op = Op.from_dict(d)
        assert op.op_type == OpType.INSERT
        assert op.pk == 1
        assert op.ts == 1234567890000
        assert op.row == {"id": 1, "name": "Alice"}

    def test_delete_op_to_dict(self):
        """Test converting delete op to dictionary."""
        op = Op.delete(pk=1)
        d = op.to_dict()
        assert d["op"] == "D"
        assert d["pk"] == 1
        assert d["row"] is None

    def test_op_equality(self):
        """Test op equality based on all fields."""
        ts = 1234567890000
        op1 = Op(op_type=OpType.INSERT, pk=1, ts=ts, row={"id": 1})
        op2 = Op(op_type=OpType.INSERT, pk=1, ts=ts, row={"id": 1})
        assert op1 == op2

    def test_op_with_string_pk(self):
        """Test op with string primary key."""
        op = Op.insert(pk="uuid-123", row={"id": "uuid-123", "name": "Alice"})
        assert op.pk == "uuid-123"
        assert op.row["id"] == "uuid-123"
