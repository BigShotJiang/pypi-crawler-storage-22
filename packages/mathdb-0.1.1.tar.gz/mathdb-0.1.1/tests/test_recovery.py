"""Recovery 2.0 模块测试 - TDD 先行。"""

import pytest
from pathlib import Path

from mathdb.recovery import Recovery
from mathdb.schema import TableSchema, ColumnDef
from mathdb.backend import BackendType, PolarsBackend, PandasBackend
from mathdb.wal import WALWriter
from mathdb.ops import Op, OpType


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("name", "Utf8"),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


@pytest.fixture
def data_dir(tmp_path: Path) -> Path:
    """数据目录。"""
    return tmp_path / "data" / "users"


class TestRecoveryPolars:
    """Polars 后端恢复测试。"""

    @pytest.fixture
    def backend(self) -> PolarsBackend:
        return PolarsBackend()

    def test_recover_empty(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试空目录恢复。"""
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 0

    def test_recover_from_wal(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试从 WAL 恢复。"""
        # 写入 WAL
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30}),
        ]
        writer.write(ops)
        
        # 恢复
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 2
        
        row1 = backend.get_row(df, "id", 1)
        assert row1["name"] == "Alice"
        
        row2 = backend.get_row(df, "id", 2)
        assert row2["name"] == "Bob"

    def test_recover_with_update(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试恢复包含更新的 WAL。"""
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.UPDATE, pk=1, row={"id": 1, "name": "Alice Updated", "age": 26}),
        ]
        writer.write(ops)
        
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 1
        row = backend.get_row(df, "id", 1)
        assert row["name"] == "Alice Updated"
        assert row["age"] == 26

    def test_recover_with_delete(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试恢复包含删除的 WAL。"""
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30}),
            Op(OpType.DELETE, pk=1),
        ]
        writer.write(ops)
        
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 1
        assert backend.get_row(df, "id", 1) is None
        assert backend.get_row(df, "id", 2) is not None

    def test_recover_multiple_segments(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试从多个 WAL 段恢复。"""
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        writer.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        writer.write([Op(OpType.UPDATE, pk=1, row={"id": 1, "name": "Alice V2", "age": 26})])
        
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 2
        row1 = backend.get_row(df, "id", 1)
        assert row1["name"] == "Alice V2"


class TestRecoveryPandas:
    """Pandas 后端恢复测试。"""

    @pytest.fixture
    def backend(self) -> PandasBackend:
        return PandasBackend()

    def test_recover_empty(self, data_dir: Path, user_schema: TableSchema, backend: PandasBackend):
        """测试空目录恢复。"""
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 0

    def test_recover_from_wal(self, data_dir: Path, user_schema: TableSchema, backend: PandasBackend):
        """测试从 WAL 恢复（Pandas）。"""
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30}),
        ]
        writer.write(ops)
        
        recovery = Recovery(data_dir, user_schema, backend)
        df = recovery.recover()
        
        assert backend.row_count(df) == 2


class TestRecoveryMetadata:
    """恢复元数据测试。"""

    @pytest.fixture
    def backend(self) -> PolarsBackend:
        return PolarsBackend()

    def test_get_last_segment_id(self, data_dir: Path, user_schema: TableSchema, backend: PolarsBackend):
        """测试获取最后段 ID。"""
        wal_dir = data_dir / "wal"
        wal_dir.mkdir(parents=True)
        writer = WALWriter(wal_dir, user_schema)
        
        writer.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        
        recovery = Recovery(data_dir, user_schema, backend)
        recovery.recover()
        
        assert recovery.last_segment_id == 2
