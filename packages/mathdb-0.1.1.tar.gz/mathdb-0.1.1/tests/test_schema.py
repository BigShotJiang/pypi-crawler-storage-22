"""Tests for TableSchema and ColumnDef."""

import pytest
import polars as pl

from mathdb.schema import TableSchema, ColumnDef


class TestColumnDef:
    """Tests for ColumnDef dataclass."""

    def test_create_column_def(self):
        """Test creating a basic column definition."""
        col = ColumnDef(name="id", dtype="Int64")
        assert col.name == "id"
        assert col.dtype == "Int64"
        assert col.primary_key is False
        assert col.nullable is True

    def test_create_primary_key_column(self):
        """Test creating a primary key column."""
        col = ColumnDef(name="id", dtype="Int64", primary_key=True)
        assert col.primary_key is True
        assert col.nullable is False  # PK should not be nullable

    def test_create_non_nullable_column(self):
        """Test creating a non-nullable column."""
        col = ColumnDef(name="name", dtype="Utf8", nullable=False)
        assert col.nullable is False

    def test_to_polars_dtype(self):
        """Test converting dtype string to Polars dtype."""
        test_cases = [
            ("Int64", pl.Int64),
            ("Int32", pl.Int32),
            ("Utf8", pl.Utf8),
            ("Float64", pl.Float64),
            ("Boolean", pl.Boolean),
            ("Date", pl.Date),
            ("Datetime", pl.Datetime),
        ]
        for dtype_str, expected in test_cases:
            col = ColumnDef(name="test", dtype=dtype_str)
            assert col.to_polars_dtype() == expected


class TestTableSchema:
    """Tests for TableSchema."""

    def test_create_schema(self):
        """Test creating a table schema."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
                ColumnDef("age", "Int32"),
            ],
        )
        assert schema.name == "users"
        assert len(schema.columns) == 3

    def test_get_primary_key(self):
        """Test getting primary key column."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        pk = schema.get_primary_key()
        assert pk is not None
        assert pk.name == "id"

    def test_schema_requires_primary_key(self):
        """Test that schema requires at least one primary key."""
        with pytest.raises(ValueError, match="主键"):
            TableSchema(
                name="users",
                columns=[
                    ColumnDef("name", "Utf8"),
                    ColumnDef("age", "Int32"),
                ],
            )

    def test_schema_single_primary_key(self):
        """Test that schema allows only one primary key."""
        with pytest.raises(ValueError, match="只能有一个主键"):
            TableSchema(
                name="users",
                columns=[
                    ColumnDef("id", "Int64", primary_key=True),
                    ColumnDef("uuid", "Utf8", primary_key=True),
                ],
            )

    def test_schema_hash(self):
        """Test that schema hash is deterministic."""
        schema1 = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        schema2 = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        assert schema1.compute_hash() == schema2.compute_hash()

    def test_schema_hash_differs_on_change(self):
        """Test that schema hash changes when schema changes."""
        schema1 = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        schema2 = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
                ColumnDef("age", "Int32"),  # Added column
            ],
        )
        assert schema1.compute_hash() != schema2.compute_hash()

    def test_to_polars_schema(self):
        """Test converting to Polars schema dict."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
                ColumnDef("age", "Int32"),
            ],
        )
        pl_schema = schema.to_polars_schema()
        assert pl_schema == {"id": pl.Int64, "name": pl.Utf8, "age": pl.Int32}

    def test_create_empty_dataframe(self):
        """Test creating an empty DataFrame with schema."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
                ColumnDef("age", "Int32"),
            ],
        )
        df = schema.create_empty_dataframe()
        assert isinstance(df, pl.DataFrame)
        assert len(df) == 0
        assert df.columns == ["id", "name", "age"]
        assert df.schema == {"id": pl.Int64, "name": pl.Utf8, "age": pl.Int32}

    def test_column_names(self):
        """Test getting column names."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        assert schema.column_names == ["id", "name"]

    def test_pk_name(self):
        """Test getting primary key name."""
        schema = TableSchema(
            name="users",
            columns=[
                ColumnDef("id", "Int64", primary_key=True),
                ColumnDef("name", "Utf8"),
            ],
        )
        assert schema.pk_name == "id"
