"""Schema 导出器测试 - TDD 先行。"""

import pytest
from datetime import datetime

import yaml

from mathdb.schema import TableSchema, ColumnDef
from mathdb.schema_exporter import SchemaExporter
from mathdb.backend import BackendType


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("username", "Utf8", nullable=False),
            ColumnDef("email", "Utf8", nullable=True),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


@pytest.fixture
def order_schema() -> TableSchema:
    """订单表 Schema。"""
    return TableSchema(
        name="orders",
        columns=[
            ColumnDef("order_id", "Int64", primary_key=True),
            ColumnDef("user_id", "Int64", nullable=False),
            ColumnDef("total_price", "Float64", nullable=False),
            ColumnDef("status", "Utf8", nullable=True),
        ],
    )


class TestSchemaExporter:
    """SchemaExporter 测试。"""

    def test_export_single_table(self, user_schema: TableSchema):
        """测试导出单个表。"""
        exporter = SchemaExporter()
        result = exporter.export_table(user_schema)

        assert result["table_name"] == "users"
        assert len(result["columns"]) == 4
        
        # 验证主键列
        id_col = result["columns"][0]
        assert id_col["name"] == "id"
        assert id_col["dtype"] == "Int64"
        assert id_col["primary_key"] is True

        # 验证普通列
        username_col = result["columns"][1]
        assert username_col["name"] == "username"
        assert username_col["dtype"] == "Utf8"
        assert "primary_key" not in username_col  # 非主键不包含此字段

    def test_export_nullable(self, user_schema: TableSchema):
        """测试 nullable 字段导出。"""
        exporter = SchemaExporter()
        result = exporter.export_table(user_schema)

        # username 是 nullable=False
        username_col = next(c for c in result["columns"] if c["name"] == "username")
        assert username_col.get("nullable") is False

        # email 是 nullable=True（默认值，不需要显式输出）
        email_col = next(c for c in result["columns"] if c["name"] == "email")
        # nullable=True 时可以省略
        assert email_col.get("nullable", True) is True

    def test_export_multiple_tables(self, user_schema: TableSchema, order_schema: TableSchema):
        """测试导出多个表。"""
        exporter = SchemaExporter()
        yaml_str = exporter.export_all([user_schema, order_schema])

        assert yaml_str is not None
        data = yaml.safe_load(yaml_str)

        assert "tables" in data
        assert len(data["tables"]) == 2
        assert data["tables"][0]["table_name"] == "users"
        assert data["tables"][1]["table_name"] == "orders"

    def test_export_with_metadata(self, user_schema: TableSchema):
        """测试带元数据导出。"""
        exporter = SchemaExporter(backend_type=BackendType.POLARS)
        result = exporter.export_table(user_schema, row_count=1000)

        assert "metadata" in result
        assert result["metadata"]["row_count"] == 1000
        assert result["metadata"]["backend"] == "polars"
        assert "export_time" in result["metadata"]

    def test_export_to_yaml_string(self, user_schema: TableSchema):
        """测试导出为 YAML 字符串。"""
        exporter = SchemaExporter()
        yaml_str = exporter.export_all([user_schema])

        # 应该是有效的 YAML
        data = yaml.safe_load(yaml_str)
        assert data is not None
        assert "tables" in data

    def test_export_to_file(self, user_schema: TableSchema, tmp_path):
        """测试导出到文件。"""
        exporter = SchemaExporter()
        output_file = tmp_path / "schema.yaml"
        
        exporter.export_to_file([user_schema], output_file)

        assert output_file.exists()
        content = output_file.read_text()
        data = yaml.safe_load(content)
        assert data["tables"][0]["table_name"] == "users"

    def test_roundtrip(self, user_schema: TableSchema):
        """测试导出后再导入（往返测试）。"""
        from mathdb.schema_loader import SchemaLoader

        exporter = SchemaExporter()
        yaml_str = exporter.export_all([user_schema])

        loader = SchemaLoader()
        schemas = loader.load_from_string(yaml_str)
        restored_schemas = [info.to_table_schema() for info in schemas]

        assert len(restored_schemas) == 1
        restored = restored_schemas[0]
        assert restored.name == user_schema.name
        assert restored.pk_name == user_schema.pk_name
        assert len(restored.columns) == len(user_schema.columns)

    def test_export_empty_list(self):
        """测试导出空表列表。"""
        exporter = SchemaExporter()
        yaml_str = exporter.export_all([])

        data = yaml.safe_load(yaml_str)
        assert data["tables"] == []

    def test_pandas_backend_type(self, user_schema: TableSchema):
        """测试 Pandas 后端类型。"""
        exporter = SchemaExporter(backend_type=BackendType.PANDAS)
        result = exporter.export_table(user_schema, row_count=100)

        assert result["metadata"]["backend"] == "pandas"
