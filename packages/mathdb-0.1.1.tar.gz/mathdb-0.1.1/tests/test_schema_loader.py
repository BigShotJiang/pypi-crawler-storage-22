"""Schema 加载器测试 - TDD 先行。"""

import pytest
from pathlib import Path

from mathdb.schema_loader import SchemaLoader, TableInfo
from mathdb.schema import TableSchema, ColumnDef


class TestTableInfo:
    """TableInfo 测试。"""

    def test_basic_creation(self):
        info = TableInfo(
            table_name="users",
            columns=[
                {"name": "id", "dtype": "Int64", "primary_key": True},
                {"name": "name", "dtype": "Utf8"},
            ],
        )
        assert info.table_name == "users"
        assert len(info.columns) == 2

    def test_to_table_schema(self):
        info = TableInfo(
            table_name="users",
            columns=[
                {"name": "id", "dtype": "Int64", "primary_key": True},
                {"name": "name", "dtype": "Utf8"},
                {"name": "age", "dtype": "Int32", "nullable": True},
            ],
        )
        schema = info.to_table_schema()
        assert isinstance(schema, TableSchema)
        assert schema.name == "users"
        assert schema.pk_name == "id"
        assert len(schema.columns) == 3

    def test_with_metadata(self):
        info = TableInfo(
            table_name="users",
            columns=[
                {"name": "id", "dtype": "Int64", "primary_key": True},
            ],
            metadata={"description": "用户表", "owner": "core-team"},
        )
        assert info.metadata["description"] == "用户表"


class TestSchemaLoader:
    """SchemaLoader 测试。"""

    @pytest.fixture
    def sample_schema_yaml(self, tmp_path: Path) -> Path:
        """创建示例 Schema YAML 文件。"""
        yaml_content = """
tables:
  - table_name: users
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: username
        dtype: Utf8
      - name: email
        dtype: Utf8
        nullable: true
      - name: age
        dtype: Int32
        nullable: true
    metadata:
      description: "用户信息表"
      owner: "core-team"

  - table_name: orders
    columns:
      - name: order_id
        dtype: Int64
        primary_key: true
      - name: user_id
        dtype: Int64
      - name: total_price
        dtype: Float64
      - name: status
        dtype: Utf8
    metadata:
      description: "订单表"
"""
        yaml_file = tmp_path / "schema.yaml"
        yaml_file.write_text(yaml_content)
        return yaml_file

    def test_load_from_file(self, sample_schema_yaml: Path):
        """测试从文件加载 Schema。"""
        loader = SchemaLoader()
        table_infos = loader.load(sample_schema_yaml)

        assert len(table_infos) == 2
        assert table_infos[0].table_name == "users"
        assert table_infos[1].table_name == "orders"

    def test_load_to_table_schemas(self, sample_schema_yaml: Path):
        """测试加载并转换为 TableSchema 列表。"""
        loader = SchemaLoader()
        schemas = loader.load_as_schemas(sample_schema_yaml)

        assert len(schemas) == 2
        assert all(isinstance(s, TableSchema) for s in schemas)
        
        # 验证 users 表
        users_schema = schemas[0]
        assert users_schema.name == "users"
        assert users_schema.pk_name == "id"
        assert len(users_schema.columns) == 4

        # 验证 orders 表
        orders_schema = schemas[1]
        assert orders_schema.name == "orders"
        assert orders_schema.pk_name == "order_id"

    def test_load_nonexistent_file(self):
        """测试加载不存在的文件。"""
        loader = SchemaLoader()
        with pytest.raises(FileNotFoundError):
            loader.load(Path("/nonexistent/schema.yaml"))

    def test_load_empty_tables(self, tmp_path: Path):
        """测试空表列表。"""
        yaml_content = """
tables: []
"""
        yaml_file = tmp_path / "empty.yaml"
        yaml_file.write_text(yaml_content)

        loader = SchemaLoader()
        table_infos = loader.load(yaml_file)
        assert len(table_infos) == 0

    def test_load_single_table(self, tmp_path: Path):
        """测试单表 Schema。"""
        yaml_content = """
tables:
  - table_name: products
    columns:
      - name: id
        dtype: Int64
        primary_key: true
      - name: name
        dtype: Utf8
      - name: price
        dtype: Float64
"""
        yaml_file = tmp_path / "single.yaml"
        yaml_file.write_text(yaml_content)

        loader = SchemaLoader()
        schemas = loader.load_as_schemas(yaml_file)

        assert len(schemas) == 1
        assert schemas[0].name == "products"
        assert len(schemas[0].columns) == 3

    def test_get_table_info_by_name(self, sample_schema_yaml: Path):
        """测试按名称获取表信息。"""
        loader = SchemaLoader()
        table_infos = loader.load(sample_schema_yaml)

        users_info = next((t for t in table_infos if t.table_name == "users"), None)
        assert users_info is not None
        assert users_info.metadata["owner"] == "core-team"

    def test_load_from_string(self):
        """测试从字符串加载。"""
        yaml_content = """
tables:
  - table_name: test
    columns:
      - name: id
        dtype: Int64
        primary_key: true
"""
        loader = SchemaLoader()
        table_infos = loader.load_from_string(yaml_content)
        
        assert len(table_infos) == 1
        assert table_infos[0].table_name == "test"
