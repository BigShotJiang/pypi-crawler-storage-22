"""Table 2.0 集成测试 - 包含持久化功能。"""

import pytest
import time
from pathlib import Path

from mathdb.table import Table
from mathdb.schema import TableSchema, ColumnDef
from mathdb.backend import PolarsBackend, PandasBackend, BackendType


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("name", "Utf8"),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


class TestTableCRUD:
    """Table CRUD 操作测试。"""

    def test_insert_and_get(self, user_schema: TableSchema, tmp_path: Path):
        """测试插入和获取。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            
            row = table.get(1)
            assert row is not None
            assert row["id"] == 1
            assert row["name"] == "Alice"
            assert row["age"] == 25

    def test_update(self, user_schema: TableSchema, tmp_path: Path):
        """测试更新。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.update(1, {"id": 1, "name": "Alice Updated", "age": 26})
            
            row = table.get(1)
            assert row["name"] == "Alice Updated"
            assert row["age"] == 26

    def test_delete(self, user_schema: TableSchema, tmp_path: Path):
        """测试删除。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.delete(1)
            
            assert table.get(1) is None
            assert table.count() == 0

    def test_upsert_insert(self, user_schema: TableSchema, tmp_path: Path):
        """测试 upsert 插入。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.upsert({"id": 1, "name": "Alice", "age": 25})
            
            assert table.count() == 1
            assert table.get(1)["name"] == "Alice"

    def test_upsert_update(self, user_schema: TableSchema, tmp_path: Path):
        """测试 upsert 更新。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.upsert({"id": 1, "name": "Alice V2", "age": 26})
            
            assert table.count() == 1
            assert table.get(1)["name"] == "Alice V2"

    def test_count(self, user_schema: TableSchema, tmp_path: Path):
        """测试行数。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            assert table.count() == 0
            
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.insert({"id": 2, "name": "Bob", "age": 30})
            
            assert table.count() == 2

    def test_to_dataframe(self, user_schema: TableSchema, tmp_path: Path):
        """测试获取 DataFrame。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.insert({"id": 2, "name": "Bob", "age": 30})
            
            df = table.to_dataframe()
            assert len(df) == 2


class TestTablePersistence:
    """Table 持久化测试。"""

    def test_flush_writes_wal(self, user_schema: TableSchema, tmp_path: Path):
        """测试刷盘写入 WAL。"""
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            assert table.pending_op_count == 1
            
            table.flush()
            assert table.pending_op_count == 0
            
            # 验证 WAL 文件存在
            wal_dir = tmp_path / "users" / "wal"
            assert wal_dir.exists()
            assert len(list(wal_dir.glob("seg_*.arrow"))) == 1

    def test_recovery_on_reopen(self, user_schema: TableSchema, tmp_path: Path):
        """测试重新打开时恢复数据。"""
        # 写入数据并关闭
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.insert({"id": 2, "name": "Bob", "age": 30})
            table.flush()
        
        # 重新打开，数据应该恢复
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            assert table.count() == 2
            assert table.get(1)["name"] == "Alice"
            assert table.get(2)["name"] == "Bob"

    def test_recovery_with_updates(self, user_schema: TableSchema, tmp_path: Path):
        """测试包含更新的恢复。"""
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.update(1, {"id": 1, "name": "Alice Updated", "age": 26})
            table.flush()
        
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            assert table.count() == 1
            row = table.get(1)
            assert row["name"] == "Alice Updated"
            assert row["age"] == 26

    def test_recovery_with_deletes(self, user_schema: TableSchema, tmp_path: Path):
        """测试包含删除的恢复。"""
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.insert({"id": 2, "name": "Bob", "age": 30})
            table.delete(1)
            table.flush()
        
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            assert table.count() == 1
            assert table.get(1) is None
            assert table.get(2)["name"] == "Bob"

    def test_multiple_sessions(self, user_schema: TableSchema, tmp_path: Path):
        """测试多次会话的累积数据。"""
        # 第一次会话
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.flush()
        
        # 第二次会话
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            table.insert({"id": 2, "name": "Bob", "age": 30})
            table.flush()
        
        # 第三次会话验证
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            assert table.count() == 2


class TestTablePandasBackend:
    """Pandas 后端测试。"""

    def test_pandas_crud(self, user_schema: TableSchema, tmp_path: Path):
        """测试 Pandas 后端 CRUD。"""
        backend = PandasBackend()
        with Table(user_schema, tmp_path, backend=backend, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            
            row = table.get(1)
            assert row["name"] == "Alice"
            
            assert table.backend_type == BackendType.PANDAS

    def test_pandas_persistence(self, user_schema: TableSchema, tmp_path: Path):
        """测试 Pandas 后端持久化。"""
        backend = PandasBackend()
        
        with Table(user_schema, tmp_path, backend=backend, flush_interval=0) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            table.flush()
        
        # 重新打开（使用 Polars 后端）—— WAL 格式是通用的
        with Table(user_schema, tmp_path, flush_interval=0) as table:
            assert table.count() == 1
            assert table.get(1)["name"] == "Alice"


class TestTableStats:
    """Table 统计信息测试。"""

    def test_get_stats(self, user_schema: TableSchema, tmp_path: Path):
        """测试获取统计信息。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            table.insert({"id": 1, "name": "Alice", "age": 25})
            
            stats = table.get_stats()
            assert stats["table_name"] == "users"
            assert stats["row_count"] == 1
            assert stats["backend"] == "polars"


class TestTableSchemaExport:
    """Table Schema 导出测试。"""

    def test_export_schema(self, user_schema: TableSchema, tmp_path: Path):
        """测试导出 Schema。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            schema = table.export_schema()
            assert schema.name == "users"
            assert schema.pk_name == "id"

    def test_to_yaml_schema(self, user_schema: TableSchema, tmp_path: Path):
        """测试导出 YAML Schema。"""
        with Table(user_schema, tmp_path, enable_persistence=False) as table:
            yaml_str = table.to_yaml_schema()
            assert "users" in yaml_str
            assert "id" in yaml_str
