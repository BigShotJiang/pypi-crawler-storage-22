"""WAL 2.0 模块测试 - TDD 先行。"""

import pytest
from pathlib import Path

import polars as pl

from mathdb.wal import WALWriter, WALReader, WALSegment
from mathdb.schema import TableSchema, ColumnDef
from mathdb.ops import Op, OpType
from mathdb.backend import BackendType


@pytest.fixture
def user_schema() -> TableSchema:
    """用户表 Schema。"""
    return TableSchema(
        name="users",
        columns=[
            ColumnDef("id", "Int64", primary_key=True),
            ColumnDef("name", "Utf8"),
            ColumnDef("age", "Int32", nullable=True),
        ],
    )


@pytest.fixture
def wal_dir(tmp_path: Path) -> Path:
    """WAL 目录。"""
    wal_path = tmp_path / "wal"
    wal_path.mkdir()
    return wal_path


class TestWALWriter:
    """WAL 写入器测试。"""

    def test_write_segment(self, wal_dir: Path, user_schema: TableSchema):
        """测试写入段。"""
        writer = WALWriter(wal_dir, user_schema)
        
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30}),
        ]
        
        segment_id = writer.write(ops)
        assert segment_id == 1
        
        # 验证文件存在
        segment_file = wal_dir / "seg_0001.arrow"
        assert segment_file.exists()

    def test_write_multiple_segments(self, wal_dir: Path, user_schema: TableSchema):
        """测试写入多个段。"""
        writer = WALWriter(wal_dir, user_schema)
        
        ops1 = [Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})]
        ops2 = [Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})]
        
        seg1 = writer.write(ops1)
        seg2 = writer.write(ops2)
        
        assert seg1 == 1
        assert seg2 == 2

    def test_write_empty_ops(self, wal_dir: Path, user_schema: TableSchema):
        """测试写入空操作列表。"""
        writer = WALWriter(wal_dir, user_schema)
        segment_id = writer.write([])
        # 空操作不应该写入
        assert segment_id == 0

    def test_resume_segment_id(self, wal_dir: Path, user_schema: TableSchema):
        """测试恢复段 ID。"""
        writer1 = WALWriter(wal_dir, user_schema)
        writer1.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer1.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        
        # 新建写入器应该继续之前的段 ID
        writer2 = WALWriter(wal_dir, user_schema)
        seg_id = writer2.write([Op(OpType.INSERT, pk=3, row={"id": 3, "name": "Charlie", "age": 35})])
        assert seg_id == 3


class TestWALReader:
    """WAL 读取器测试。"""

    def test_read_segment(self, wal_dir: Path, user_schema: TableSchema):
        """测试读取段。"""
        writer = WALWriter(wal_dir, user_schema)
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.UPDATE, pk=1, row={"id": 1, "name": "Alice Updated", "age": 26}),
        ]
        writer.write(ops)
        
        reader = WALReader(wal_dir, user_schema)
        segment = reader.read_segment(1)
        
        assert segment is not None
        assert segment.segment_id == 1
        assert len(segment.ops) == 2

    def test_read_all_segments(self, wal_dir: Path, user_schema: TableSchema):
        """测试读取所有段。"""
        writer = WALWriter(wal_dir, user_schema)
        writer.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        
        reader = WALReader(wal_dir, user_schema)
        segments = reader.read_all()
        
        assert len(segments) == 2

    def test_read_segments_after(self, wal_dir: Path, user_schema: TableSchema):
        """测试读取指定 ID 之后的段。"""
        writer = WALWriter(wal_dir, user_schema)
        writer.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        writer.write([Op(OpType.INSERT, pk=3, row={"id": 3, "name": "Charlie", "age": 35})])
        
        reader = WALReader(wal_dir, user_schema)
        segments = reader.read_after(1)
        
        assert len(segments) == 2
        assert segments[0].segment_id == 2
        assert segments[1].segment_id == 3

    def test_read_nonexistent_segment(self, wal_dir: Path, user_schema: TableSchema):
        """测试读取不存在的段。"""
        reader = WALReader(wal_dir, user_schema)
        segment = reader.read_segment(999)
        assert segment is None

    def test_list_segment_ids(self, wal_dir: Path, user_schema: TableSchema):
        """测试列出所有段 ID。"""
        writer = WALWriter(wal_dir, user_schema)
        writer.write([Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25})])
        writer.write([Op(OpType.INSERT, pk=2, row={"id": 2, "name": "Bob", "age": 30})])
        
        reader = WALReader(wal_dir, user_schema)
        ids = reader.list_segment_ids()
        
        assert ids == [1, 2]


class TestWALSegment:
    """WAL 段测试。"""

    def test_collect_ops(self, user_schema: TableSchema):
        """测试收集操作。"""
        ops = [
            Op(OpType.INSERT, pk=1, row={"id": 1, "name": "Alice", "age": 25}),
            Op(OpType.DELETE, pk=1),
        ]
        segment = WALSegment(segment_id=1, ops=ops, schema=user_schema)
        
        assert len(segment.ops) == 2
        assert segment.ops[0].op_type == OpType.INSERT
        assert segment.ops[1].op_type == OpType.DELETE
