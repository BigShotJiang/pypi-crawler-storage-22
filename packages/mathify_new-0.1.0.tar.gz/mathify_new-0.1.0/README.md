# mathify

A simple math utility package for Python.

## Installation

pip install mathify

## Usage

```python
from mathify import add, solve_linear

print(add(2, 3))          # 5
print(solve_linear(2, 4)) # -2