from .arithmetic import add, subtract, multiply, divide
from .algebra import solve_linear