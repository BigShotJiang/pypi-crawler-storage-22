def solve_linear(a, b):
    if a == 0:
        raise ValueError("a cannot be zero")
    return -b / a