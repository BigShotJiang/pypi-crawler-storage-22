from setuptools import setup, find_packages

setup(
    name="mathify-new",
    version="0.1.0",
    author="Your Name",
    description="A simple math utility package",
    packages=find_packages(),
    python_requires=">=3.8",
)