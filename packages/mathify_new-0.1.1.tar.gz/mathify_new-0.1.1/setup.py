from setuptools import setup, find_packages

setup(
    name="mathify_new",
    version="0.1.1",
    author="Your Name",
    description="A simple math utility package",
    packages=find_packages(),
    python_requires=">=3.8",
)