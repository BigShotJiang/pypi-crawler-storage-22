# mathlib

A minimal Python math calculation library.
