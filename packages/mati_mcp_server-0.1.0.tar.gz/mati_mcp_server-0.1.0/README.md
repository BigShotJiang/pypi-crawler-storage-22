# Mati MCP Server

MCP server that connects Cursor, Claude, and other AI tools to the Mati content API. Create drafts, schedule posts, and publish to Twitter—all from your AI assistant.

## Install

**From PyPI** (once published):
```bash
pip install mati-mcp-server
```

**From source** (development):
```bash
cd mati-mcp-server
make install   # creates venv, installs deps
make run       # or: source venv/bin/activate && mati-mcp-server
```

## Configure

Set these environment variables (or add to your shell profile):

| Variable | Default | Description |
|----------|---------|-------------|
| `MATI_API_BASE_URL` | `https://api.dev.hiremati.ai` | Mati API base URL |
| `MATI_API_KEY` | `HireMatiAi` | Your API key (linked to your Mati user) |

## Add to Cursor

1. Open **Cursor** → **Settings** → **Features** → **MCP**
2. Click **Add New MCP Server**
3. Configure:
   - **Name**: `Mati` (or any name)
   - **Type**: `stdio`
   - **Command**: `mati-mcp-server`

4. If you need to pass env vars, use a command like:
   ```
   env MATI_API_BASE_URL=https://api.dev.hiremati.ai MATI_API_KEY=your-key mati-mcp-server
   ```

5. Save and refresh

## Add to Claude Desktop / Claude Code

```bash
claude mcp add mati mati-mcp-server
```

Or with env vars:
```bash
env MATI_API_KEY=your-key claude mcp add mati mati-mcp-server
```

## Tools

- **create_draft** – Create or update a content draft
- **list_drafts** – List your drafts
- **list_scheduled** – List scheduled content
- **update_draft** – Update an existing draft
- **schedule_post** – Schedule content for publishing
- **post_content** – Post content to Twitter

All content is linked to your Mati user (via your API key).

## Optional: Run as HTTP server

To run a standalone HTTP server (e.g. for remote connections):

```bash
mati-mcp-server --http
```

Server runs at `http://localhost:8000/mcp`.

---

## Publishing to PyPI (for maintainers)

```bash
# 1. Install build tools
pip install build twine

# 2. Build the package (creates dist/*.whl and dist/*.tar.gz)
python -m build

# 3. Upload to PyPI (prompts for username/password or token)
twine upload dist/*
```
