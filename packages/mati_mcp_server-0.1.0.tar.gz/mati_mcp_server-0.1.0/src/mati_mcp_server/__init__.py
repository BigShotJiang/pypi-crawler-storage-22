"""Mati MCP Server - connects AI tools to Mati content API."""
