"""Entry point for running the Mati MCP server."""

from mati_mcp_server.server import main

if __name__ == "__main__":
    main()
