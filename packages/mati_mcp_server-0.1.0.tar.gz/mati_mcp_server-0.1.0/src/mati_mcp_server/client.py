"""HTTP client for Mati API."""

import os
from typing import Any, Optional

import httpx

BASE_URL = os.environ.get("MATI_API_BASE_URL", "https://api.dev.hiremati.ai")
API_KEY = os.environ.get("MATI_API_KEY", "HireMatiAi")
DEFAULT_TIMEOUT = 30.0


def _headers() -> dict[str, str]:
    return {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json",
    }


def _url(path: str) -> str:
    base = BASE_URL.rstrip("/")
    path = path if path.startswith("/") else f"/{path}"
    return f"{base}{path}"


def create_draft(
    content: str,
    title: str = "",
    content_type: str = "post",
    tags: Optional[list[str]] = None,
    rag_summary: str = "",
    content_id: Optional[str] = None,
) -> dict[str, Any]:
    """Create or update a draft. User is resolved from API key."""
    payload: dict[str, Any] = {
        "content": content,
        "title": title,
        "content_type": content_type,
        "rag_summary": rag_summary,
    }
    if tags is not None:
        payload["tags"] = tags
    if content_id is not None:
        payload["content_id"] = content_id

    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.post(_url("/api/v1/mcp/drafts"), json=payload, headers=_headers())
        r.raise_for_status()
        return r.json()


def list_drafts(limit: int = 100) -> dict[str, Any]:
    """List drafts. User is resolved from API key."""
    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.get(
            _url("/api/v1/mcp/drafts"),
            params={"limit": limit},
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


def list_scheduled(limit: int = 100) -> dict[str, Any]:
    """List scheduled content. User is resolved from API key."""
    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.get(
            _url("/api/v1/mcp/scheduled"),
            params={"limit": limit},
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


def update_draft(
    content_id: str,
    content: Optional[str] = None,
    title: Optional[str] = None,
    tags: Optional[list[str]] = None,
    rag_summary: Optional[str] = None,
) -> dict[str, Any]:
    """Update an existing draft. User is resolved from API key."""
    payload: dict[str, Any] = {"content_id": content_id}
    if content is not None:
        payload["content"] = content
    if title is not None:
        payload["title"] = title
    if tags is not None:
        payload["tags"] = tags
    if rag_summary is not None:
        payload["rag_summary"] = rag_summary

    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.put(
            _url(f"/api/v1/mcp/drafts/{content_id}"),
            json=payload,
            headers=_headers(),
        )
        r.raise_for_status()
        return r.json()


def schedule_post(
    content_ids: list[str],
    scheduled_at: str,
) -> dict[str, Any]:
    """Schedule content for publishing. User is resolved from API key."""
    payload = {
        "content_ids": content_ids,
        "scheduled_at": scheduled_at,
    }
    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.post(_url("/api/v1/mcp/schedule"), json=payload, headers=_headers())
        r.raise_for_status()
        return r.json()


def post_content(
    content_id: str,
    text_override: Optional[str] = None,
) -> dict[str, Any]:
    """Post content to Twitter. User is resolved from API key."""
    payload: dict[str, Any] = {"content_id": content_id}
    if text_override is not None:
        payload["text_override"] = text_override
    with httpx.Client(timeout=DEFAULT_TIMEOUT) as client:
        r = client.post(_url("/api/v1/mcp/post"), json=payload, headers=_headers())
        r.raise_for_status()
        return r.json()
