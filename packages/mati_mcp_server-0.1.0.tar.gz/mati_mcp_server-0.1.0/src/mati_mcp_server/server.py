"""MCP server exposing Mati content tools."""

import argparse
import json
from typing import Optional

from fastmcp import FastMCP

from mati_mcp_server.client import (
    create_draft as api_create_draft,
    list_drafts as api_list_drafts,
    list_scheduled as api_list_scheduled,
    post_content as api_post_content,
    schedule_post as api_schedule_post,
    update_draft as api_update_draft,
)

mcp = FastMCP(
    "Mati",
    description="Mati content operations - create drafts, schedule posts, publish to Twitter",
)


@mcp.tool()
def create_draft(
    content: str,
    title: str = "",
    content_type: str = "post",
    tags: Optional[str] = None,
    rag_summary: str = "",
    content_id: Optional[str] = None,
) -> str:
    """Create or update a content draft. User is linked to your API key.

    Args:
        content: Content body text
        title: Optional title
        content_type: post, article, carousel, etc. (default: post)
        tags: Comma-separated hashtags (e.g. "AI,productivity,tech")
        rag_summary: Short context summary
        content_id: Existing content ID to update (omit for new draft)
    """
    tag_list = [t.strip() for t in (tags or "").split(",") if t.strip()] if tags else None
    result = api_create_draft(
        content=content,
        title=title,
        content_type=content_type,
        tags=tag_list,
        rag_summary=rag_summary,
        content_id=content_id,
    )
    return json.dumps(result, indent=2)


@mcp.tool()
def list_drafts(limit: int = 100) -> str:
    """List your content drafts. User is linked to your API key.

    Args:
        limit: Max items to return (default 100)
    """
    result = api_list_drafts(limit=limit)
    return json.dumps(result, indent=2)


@mcp.tool()
def list_scheduled(limit: int = 100) -> str:
    """List your scheduled content. User is linked to your API key.

    Args:
        limit: Max items to return (default 100)
    """
    result = api_list_scheduled(limit=limit)
    return json.dumps(result, indent=2)


@mcp.tool()
def update_draft(
    content_id: str,
    content: Optional[str] = None,
    title: Optional[str] = None,
    tags: Optional[str] = None,
    rag_summary: Optional[str] = None,
) -> str:
    """Update an existing draft. User is linked to your API key.

    Args:
        content_id: Content ID to update
        content: New content body (optional)
        title: New title (optional)
        tags: Comma-separated hashtags (optional)
        rag_summary: New summary (optional)
    """
    tag_list = [t.strip() for t in (tags or "").split(",") if t.strip()] if tags else None
    result = api_update_draft(
        content_id=content_id,
        content=content,
        title=title,
        tags=tag_list,
        rag_summary=rag_summary,
    )
    return json.dumps(result, indent=2)


@mcp.tool()
def schedule_post(
    content_ids: str,
    scheduled_at: str,
) -> str:
    """Schedule content for future publishing. User is linked to your API key.

    Args:
        content_ids: Comma-separated content IDs
        scheduled_at: ISO datetime (e.g. 2025-02-15T09:00:00Z)
    """
    ids = [x.strip() for x in content_ids.split(",") if x.strip()]
    if not ids:
        return json.dumps(
            {"status": "error", "message": "At least one content_id is required"},
            indent=2,
        )
    result = api_schedule_post(
        content_ids=ids,
        scheduled_at=scheduled_at,
    )
    return json.dumps(result, indent=2)


@mcp.tool()
def post_content(
    content_id: str,
    text_override: Optional[str] = None,
) -> str:
    """Post content to Twitter. User is linked to your API key. Must have Twitter linked.

    Args:
        content_id: Content draft ID to post
        text_override: Override tweet text (uses draft content if omitted)
    """
    result = api_post_content(
        content_id=content_id,
        text_override=text_override,
    )
    return json.dumps(result, indent=2)


def main() -> None:
    """Run the MCP server. Default: stdio (for Cursor). Use --http for standalone HTTP server."""
    parser = argparse.ArgumentParser(description="Mati MCP Server")
    parser.add_argument(
        "--http",
        action="store_true",
        help="Run HTTP server at localhost:8000/mcp (default: stdio for Cursor)",
    )
    args = parser.parse_args()
    if args.http:
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
