#!/usr/bin/env python3
"""
Test script for MCP API - calls backend directly.
Run with: python test_mcp_api.py
Requires: backend running at MATI_API_BASE_URL (default http://localhost:8080)
"""
import os
import sys

try:
    import httpx
except ImportError:
    print("Install httpx: pip install httpx")
    sys.exit(1)

BASE_URL = os.environ.get("MATI_API_BASE_URL", "http://localhost:8080")
API_KEY = os.environ.get("MATI_API_KEY", "HireMatiAi")
TIMEOUT = 10.0


def headers():
    return {"X-API-Key": API_KEY, "Content-Type": "application/json"}


def url(path):
    return f"{BASE_URL.rstrip('/')}{path}"


def test_create_draft():
    """Test POST /api/v1/mcp/drafts"""
    r = httpx.post(
        url("/api/v1/mcp/drafts"),
        json={"content": "MCP API test draft", "title": "Test"},
        headers=headers(),
        timeout=TIMEOUT,
    )
    assert r.status_code == 200, f"create_draft: {r.status_code} {r.text}"
    data = r.json()
    assert data.get("status") == "saved"
    assert "draft_id" in data
    print("✓ create_draft")
    return data.get("draft_id")


def test_list_drafts():
    """Test GET /api/v1/mcp/drafts"""
    r = httpx.get(url("/api/v1/mcp/drafts"), params={"limit": 5}, headers=headers(), timeout=TIMEOUT)
    assert r.status_code == 200, f"list_drafts: {r.status_code} {r.text}"
    data = r.json()
    assert "drafts" in data
    print("✓ list_drafts")
    return data


def test_list_scheduled():
    """Test GET /api/v1/mcp/scheduled"""
    r = httpx.get(url("/api/v1/mcp/scheduled"), params={"limit": 5}, headers=headers(), timeout=TIMEOUT)
    assert r.status_code == 200, f"list_scheduled: {r.status_code} {r.text}"
    data = r.json()
    assert "items" in data
    print("✓ list_scheduled")
    return data


def test_update_draft(draft_id):
    """Test PUT /api/v1/mcp/drafts/{content_id}"""
    r = httpx.put(
        url(f"/api/v1/mcp/drafts/{draft_id}"),
        json={"content_id": draft_id, "content": "Updated content", "title": "Updated"},
        headers=headers(),
        timeout=TIMEOUT,
    )
    assert r.status_code == 200, f"update_draft: {r.status_code} {r.text}"
    data = r.json()
    assert data.get("status") == "saved"
    print("✓ update_draft")


def test_invalid_api_key():
    """Test that invalid API key returns 401"""
    r = httpx.post(
        url("/api/v1/mcp/drafts"),
        json={"content": "test"},
        headers={"X-API-Key": "invalid", "Content-Type": "application/json"},
        timeout=TIMEOUT,
    )
    assert r.status_code == 401, f"Expected 401, got {r.status_code}"
    print("✓ invalid_api_key (401)")


def main():
    print(f"Testing MCP API at {BASE_URL} with API key {API_KEY[:8]}...")
    print()
    try:
        test_invalid_api_key()
        draft_id = test_create_draft()
        test_list_drafts()
        test_list_scheduled()
        if draft_id:
            test_update_draft(draft_id)
        print()
        print("All MCP API tests passed.")
    except httpx.ConnectError as e:
        print(f"\n✗ Connection failed: {e}")
        print("  Ensure backend is running: cd mati-ai-backend && make dev")
        sys.exit(1)
    except AssertionError as e:
        print(f"\n✗ {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
