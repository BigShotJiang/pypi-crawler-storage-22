from matplotlabs import main

main()
