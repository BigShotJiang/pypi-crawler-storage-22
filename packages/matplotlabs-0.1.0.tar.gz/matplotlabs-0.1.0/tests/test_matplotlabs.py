import matplotlabs


def test_import():
    """Verify that the package is importable."""
    assert hasattr(matplotlabs, "main")


def test_main(capsys):
    """Verify that main() produces expected output."""
    matplotlabs.main()
    captured = capsys.readouterr()
    assert "Hello from matplotlabs!" in captured.out
