from __future__ import annotations
import math

from ..error import IndexError as MatPyIndexError


class Vector:
    """
    A 3D vector class with support for common vector operations and Python dunder methods.
    
    Attributes:
        x (float): The x-component of the vector
        y (float): The y-component of the vector
        z (float): The z-component of the vector
    """
    
    # ==================== Initialization ====================
    
    def __init__(self, x: float = 0, y: float = 0, z: float = 0) -> None:
        """Initialize a 3D vector with x, y, z components."""
        self.x = x
        self.y = y
        self.z = z
    
    # ==================== String Representation ====================
    
    def __str__(self) -> str:
        """Return informal string representation: (x, y, z)"""
        return f"({self.x}, {self.y}, {self.z})"
    
    def __repr__(self) -> str:
        """Return official string representation: <x, y, z>"""
        return f"<{self.x}, {self.y}, {self.z}>"
    
    def __format__(self, format_spec: str) -> str:
        """Return custom formatted string representation."""
        return f"({format(self.x, format_spec)}, {format(self.y, format_spec)}, {format(self.z, format_spec)})"
    
    # ==================== Arithmetic Operators ====================
    
    def __add__(self, other: Vector) -> Vector:
        """Add two vectors: v1 + v2"""
        return Vector(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __radd__(self, other: Vector) -> Vector:
        """Reflected addition: other + v1"""
        return self.__add__(other)
    
    def __sub__(self, other: Vector) -> Vector:
        """Subtract two vectors: v1 - v2"""
        return Vector(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def __mul__(self, scalar: float) -> Vector:
        """Multiply vector by scalar: v * scalar"""
        return Vector(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def __rmul__(self, scalar: float) -> Vector:
        """Reflected multiplication: scalar * v"""
        return self.__mul__(scalar)
    
    def __truediv__(self, scalar: float) -> Vector:
        """Divide vector by scalar: v / scalar"""
        return Vector(self.x / scalar, self.y / scalar, self.z / scalar)
    
    # ==================== Unary Operators ====================
    
    def __neg__(self) -> Vector:
        """Negate vector: -v"""
        return Vector(-self.x, -self.y, -self.z)
    
    def __pos__(self) -> Vector:
        """Unary plus: +v"""
        return Vector(self.x, self.y, self.z)
    
    def __abs__(self) -> float:
        """Return magnitude of vector: abs(v)"""
        return self.magnitude()
    
    # ==================== Type Conversion ====================
    
    def __bool__(self) -> bool:
        """Return True if vector is non-zero."""
        return self.x != 0 or self.y != 0 or self.z != 0
    
    def __round__(self, n: int = 0) -> Vector:
        """Round vector components to n digits."""
        return Vector(
            round(self.x, n), 
            round(self.y, n), 
            round(self.z, n)
        )
    
    # ==================== Container/Sequence Methods ====================
    
    def __len__(self) -> int:
        """Return the number of components (always 3)."""
        return 3
    
    def __getitem__(self, index: int) -> float:
        """Get component by index: v[0], v[1], v[2]"""
        if index == 0:
            return self.x
        elif index == 1:
            return self.y
        elif index == 2:
            return self.z
        else:
            raise MatPyIndexError(index, "0-2", "Index out of range for Vector (valid indices: 0, 1, 2)")
    
    def __iter__(self):
        """Iterate over vector components."""
        yield self.x
        yield self.y
        yield self.z
    
    def __contains__(self, value: float) -> bool:
        """Check if value exists in any component: value in v"""
        return self.x == value or self.y == value or self.z == value
    
    # ==================== Copying ====================
    
    def __copy__(self) -> Vector:
        """Create a shallow copy of the vector."""
        return Vector(self.x, self.y, self.z)
    
    # ==================== Vector Operations ====================
    
    def magnitude(self) -> float:
        """Calculate and return the magnitude (length) of the vector."""
        return math.sqrt(self.x ** 2 + self.y ** 2 + self.z ** 2)
    
    def dot(self, other: Vector) -> float:
        """Calculate dot product with another vector."""
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other: Vector) -> Vector:
        """Calculate cross product with another vector."""
        return Vector(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def normalize(self) -> Vector:
        """Return a normalized (unit) vector in the same direction."""
        mag = self.magnitude()
        if mag == 0:
            return Vector(0, 0, 0)
        return self / mag