"""
Vector operations module.

This module provides standalone functions for common vector operations.
These functions complement the Vector class methods in core.py.
"""

from __future__ import annotations
import math

from .core import Vector


# ==================== Basic Vector Operations ====================

def dot(v1: Vector, v2: Vector) -> float:
    """
    Calculate the dot product of two vectors.
    
    Args:
        v1: First vector
        v2: Second vector
    
    Returns:
        The dot product (scalar value)
    """
    return v1.dot(v2)


def cross(v1: Vector, v2: Vector) -> Vector:
    """
    Calculate the cross product of two vectors.
    
    Args:
        v1: First vector
        v2: Second vector
    
    Returns:
        A new vector perpendicular to both input vectors
    """
    return v1.cross(v2)


def magnitude(v: Vector) -> float:
    """
    Calculate the magnitude (length) of a vector.
    
    Args:
        v: The vector
    
    Returns:
        The magnitude of the vector
    """
    return abs(v)


def normalize(v: Vector) -> Vector:
    """
    Return a normalized (unit) vector in the same direction.
    
    Args:
        v: The vector to normalize
    
    Returns:
        A unit vector in the same direction, or zero vector if input is zero
    """
    return v.normalize()


# ==================== Advanced Vector Operations ====================

def angle_between(v1: Vector, v2: Vector) -> float:
    """
    Calculate the angle between two vectors in radians.
    
    Args:
        v1: First vector
        v2: Second vector
    
    Returns:
        The angle between the vectors in radians [0, π]
    
    Note:
        Returns 0.0 if either vector has zero magnitude
    """
    dot_prod = v1.dot(v2)
    mag_v1 = abs(v1)
    mag_v2 = abs(v2)
    
    if mag_v1 == 0 or mag_v2 == 0:
        return 0.0
    
    # Clamp to [-1, 1] to handle floating-point errors
    cos_angle = max(min(dot_prod / (mag_v1 * mag_v2), 1.0), -1.0)
    return math.acos(cos_angle)


def projection(v1: Vector, v2: Vector) -> Vector:
    """
    Project vector v1 onto vector v2.
    
    Args:
        v1: The vector to be projected
        v2: The vector to project onto
    
    Returns:
        The projection of v1 onto v2
    
    Note:
        Returns zero vector if v2 has zero magnitude
    """
    mag_v2 = abs(v2)
    if mag_v2 == 0:
        return Vector(0, 0, 0)
    
    scale = v1.dot(v2) / (mag_v2 ** 2)
    return v2 * scale


def rejection(v1: Vector, v2: Vector) -> Vector:
    """
    Calculate the rejection of v1 from v2.
    
    The rejection is the component of v1 perpendicular to v2.
    
    Args:
        v1: The vector to be rejected
        v2: The vector to reject from
    
    Returns:
        The component of v1 perpendicular to v2
    
    Note:
        projection(v1, v2) + rejection(v1, v2) = v1
    """
    return v1 - projection(v1, v2)


def reflect(v: Vector, normal: Vector) -> Vector:
    """
    Reflect a vector across a surface defined by its normal.
    
    Args:
        v: The vector to reflect
        normal: The surface normal vector
    
    Returns:
        The reflected vector
    
    Note:
        The normal vector is automatically normalized
    """
    normal = normal.normalize()
    return v - 2 * v.dot(normal) * normal


def lerp(v1: Vector, v2: Vector, t: float) -> Vector:
    """
    Linear interpolation between two vectors.
    
    Args:
        v1: Start vector (when t=0)
        v2: End vector (when t=1)
        t: Interpolation parameter
    
    Returns:
        Interpolated vector
    
    Note:
        - t=0 returns v1
        - t=1 returns v2
        - t=0.5 returns the midpoint
        - t can be outside [0, 1] for extrapolation
    """
    return v1 * (1 - t) + v2 * t


