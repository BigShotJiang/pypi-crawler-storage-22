
# matrice\_inference