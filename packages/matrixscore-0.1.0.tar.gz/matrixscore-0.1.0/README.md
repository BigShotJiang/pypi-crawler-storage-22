# MatrixScore
Domain-agnostic rating engine for matrix-driven coverage, gaps, and overlap risk.
