import torch
import matplotlib.pyplot as plt
from matterhorn_pytorch.util.plotter import init_figure, event_plot_tx, event_plot_yx, event_plot_tyx


if __name__ == "__main__":
    a = (torch.randint(0, 10, (16, 2, 60, 80)) // 9).float()
    # fig, ax = init_figure(3)# , figsize = (7, 6))
    ax = event_plot_tyx(a)
    plt.show()