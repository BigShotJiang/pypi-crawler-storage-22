# maxgentic

[![Release](https://img.shields.io/github/v/release/mmaung/maxgentic)](https://img.shields.io/github/v/release/mmaung/maxgentic)
[![Build status](https://img.shields.io/github/actions/workflow/status/mmaung/maxgentic/main.yml?branch=main)](https://github.com/mmaung/maxgentic/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/mmaung/maxgentic)](https://img.shields.io/github/commit-activity/m/mmaung/maxgentic)
[![License](https://img.shields.io/github/license/mmaung/maxgentic)](https://img.shields.io/github/license/mmaung/maxgentic)

This project contains various agentic workflows.
