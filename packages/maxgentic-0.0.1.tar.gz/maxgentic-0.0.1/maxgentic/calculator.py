"""Simple calculator module to demonstrate code coverage."""


def add(a: float, b: float) -> float:
    """Add two numbers.

    Args:
        a: First number
        b: Second number

    Returns:
        Sum of a and b
    """
    return a + b


def subtract(a: float, b: float) -> float:
    """Subtract b from a.

    Args:
        a: First number
        b: Second number

    Returns:
        Difference of a and b
    """
    return a - b


def multiply(a: float, b: float) -> float:
    """Multiply two numbers.

    Args:
        a: First number
        b: Second number

    Returns:
        Product of a and b
    """
    return a * b


def divide(a: float, b: float) -> float:
    """Divide a by b.

    Args:
        a: Numerator
        b: Denominator

    Returns:
        Quotient of a and b

    Raises:
        ValueError: If b is zero
    """
    if b == 0:
        msg = "Cannot divide by zero"
        raise ValueError(msg)
    return a / b


def is_even(n: int) -> bool:
    """Check if a number is even.

    Args:
        n: Number to check

    Returns:
        True if n is even, False otherwise
    """
    return n % 2 == 0


def factorial(n: int) -> int:
    """Calculate factorial of n.

    Args:
        n: Non-negative integer

    Returns:
        Factorial of n

    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        msg = "Factorial is not defined for negative numbers"
        raise ValueError(msg)
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)


def power(base: float, exponent: int) -> float:
    """Calculate base raised to exponent.

    Args:
        base: Base number
        exponent: Exponent (integer)

    Returns:
        base ** exponent
    """
    if exponent == 0:
        return 1
    if exponent < 0:
        return 1 / power(base, -exponent)
    return base * power(base, exponent - 1)
