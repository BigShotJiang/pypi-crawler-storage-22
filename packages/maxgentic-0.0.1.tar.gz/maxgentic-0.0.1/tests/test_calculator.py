"""Tests for calculator module."""

import pytest

from maxgentic.calculator import add, divide, factorial, is_even, multiply, power, subtract


def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    assert add(0, 0) == 0
    assert add(1.5, 2.5) == 4.0


def test_subtract():
    assert subtract(5, 3) == 2
    assert subtract(0, 5) == -5
    assert subtract(10, 10) == 0
    assert subtract(3.5, 1.5) == 2.0


def test_multiply():
    assert multiply(2, 3) == 6
    assert multiply(-2, 3) == -6
    assert multiply(0, 5) == 0
    assert multiply(2.5, 4) == 10.0


def test_divide():
    assert divide(6, 2) == 3
    assert divide(5, 2) == 2.5
    assert divide(0, 5) == 0
    assert divide(-10, 2) == -5


def test_divide_by_zero():
    with pytest.raises(ValueError, match="Cannot divide by zero"):
        divide(5, 0)


def test_is_even():
    assert is_even(2) is True
    assert is_even(4) is True
    assert is_even(0) is True
    assert is_even(1) is False
    assert is_even(3) is False
    assert is_even(-2) is True
    assert is_even(-1) is False


def test_factorial():
    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(5) == 120
    assert factorial(3) == 6


def test_factorial_negative():
    with pytest.raises(ValueError, match="Factorial is not defined for negative numbers"):
        factorial(-1)


def test_power():
    assert power(2, 3) == 8
    assert power(5, 0) == 1
    assert power(10, 1) == 10
    assert power(2, -2) == 0.25
    assert power(3, 2) == 9
