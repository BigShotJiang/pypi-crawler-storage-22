class MaXMLError(Exception):
    pass
