srcdir = @srcdir@
VPATH  = @srcdir@
HOST   = @HOST@
EXEEXT = @EXEEXT@

define TEMPLATE
VAR1       = value1
INLINE_VAR = embedded  # nested assign
  $(eval ANOTHER=here)
endef

script:
	if [ $$? -eq 0 ]; then \
		FOO=bar; \
		BAR=$$FOO baz; \
	fi
