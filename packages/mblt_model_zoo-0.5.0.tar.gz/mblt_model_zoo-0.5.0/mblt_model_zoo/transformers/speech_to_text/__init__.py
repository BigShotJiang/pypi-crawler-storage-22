from .whisper import whisper_small

__all__ = ["whisper_small"]
