from .yolo11_seg import YOLO11lSeg, YOLO11mSeg, YOLO11nSeg, YOLO11sSeg, YOLO11xSeg
from .yolov5_seg import YOLOv5lSeg, YOLOv5mSeg, YOLOv5nSeg, YOLOv5sSeg, YOLOv5xSeg
from .yolov8_seg import YOLOv8lSeg, YOLOv8mSeg, YOLOv8nSeg, YOLOv8sSeg, YOLOv8xSeg
from .yolov9_seg import YOLOv9cSeg, YOLOv9eSeg
