from .yolo11_pose import YOLO11lPose, YOLO11mPose, YOLO11nPose, YOLO11sPose, YOLO11xPose
from .yolov8_pose import YOLOv8lPose, YOLOv8mPose, YOLOv8nPose, YOLOv8sPose, YOLOv8xPose
