# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : __init__.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Modern Combat 5 API Client Package
# ────────────────★─────────────────────────────────

"""
Modern Combat 5 API Client

A comprehensive Python library for interacting with the Modern Combat 5 API.
Provides easy access to authentication, profile management, clan operations,
messaging, and more.
"""

from typing import Optional, Dict, Any

__version__ = "1.0.14"
__author__ = "Chizoba"
__email__ = "chizoba2026@hotmail.com"
__license__ = "MIT"

from .simple_client import (
    SimpleMC5Client,
    batch_search_players,
    clan_cleanup,
    monitor_clan_activity,
    quick_search,
    quick_kick
)
from .client import MC5Client
from .auth import TokenGenerator
from .exceptions import MC5APIError, AuthenticationError, RateLimitError
from .help import help, examples, quick_reference
from .admin_client import (
    AdminMC5Client,
    create_admin_client,
    create_user_client,
    quick_add_squad_rating,
    quick_update_player_score
)

# Encrypted token convenience functions
from .auth import TokenGenerator

def quick_generate_encrypted_token(
    username: str,
    password: str,
    device_id: Optional[str] = None,
    scope: str = "alert auth chat leaderboard_ro lobby message session social config storage_ro tracking_bi feed storage leaderboard_admin social_eve social soc transaction schedule lottery voice matchmaker",
    nonce: str = "*"
) -> Dict[str, Any]:
    """
    Quick function to generate and encrypt an access token.
    
    Args:
        username: MC5 username
        password: Account password
        device_id: Device ID (generated if not provided)
        scope: Permission scopes
        nonce: Nonce value for encryption
        
    Returns:
        Dictionary containing encrypted token information
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.generate_encrypted_token(username, password, device_id, scope, nonce)
        return result
    finally:
        token_gen.close()

def quick_encrypt_token(
    access_token: str,
    nonce: str = "*"
) -> str:
    """
    Quick function to encrypt an existing access token.
    
    Args:
        access_token: Raw access token string
        nonce: Nonce value for encryption
        
    Returns:
        Encrypted token string
    """
    token_gen = TokenGenerator()
    try:
        result = token_gen.encrypt_token(access_token, nonce)
        return result
    finally:
        token_gen.close()

__all__ = [
    "MC5Client",
    "SimpleMC5Client",
    "AdminMC5Client",
    "batch_search_players",
    "clan_cleanup",
    "monitor_clan_activity",
    "quick_search",
    "quick_kick",
    "create_admin_client",
    "create_user_client",
    "quick_add_squad_rating",
    "quick_update_player_score",
    "TokenGenerator", 
    "MC5APIError",
    "AuthenticationError",
    "RateLimitError",
    "help",
    "examples",
    "quick_reference",
    "quick_generate_encrypted_token",
    "quick_encrypt_token"
]
