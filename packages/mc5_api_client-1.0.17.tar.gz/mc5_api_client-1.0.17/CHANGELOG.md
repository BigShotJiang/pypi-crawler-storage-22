# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.8] - 2026-02-03

### 🤖 Major Release - Advanced Automation & Loop-Based Operations

#### 🔄 Revolutionary Loop-Based Operations
- ✅ **Batch Search**: Search multiple players with automatic loops and conditional processing
- ✅ **Smart Clan Cleanup**: Intelligent member management with safety checks and conditional logic
- ✅ **Real-time Monitoring**: While loops for continuous clan activity tracking with alerts
- ✅ **Automated Workflows**: Complete automation sequences with decision-making capabilities
- ✅ **Conditional Processing**: Smart filtering based on player stats, level, and activity

#### 🧠 Advanced Conditional Logic System
- ✅ **Safety Checks**: Protect high-level members (configurable level thresholds)
- ✅ **Role Protection**: Safeguard leaders, admins, and officers from automated actions
- ✅ **Dynamic Decisions**: Make intelligent choices based on clan composition and statistics
- ✅ **Error Recovery**: Graceful handling of failures with continue/break logic
- ✅ **Smart Filtering**: Categorize members automatically (elite, active, veterans, newbies, inactive)

#### 📊 New Advanced Functions
- ✅ **batch_search_players()**: Search multiple dogtags with loop and conditional processing
- ✅ **clan_cleanup()**: Comprehensive clan analysis with intelligent recommendations
- ✅ **monitor_clan_activity()**: Real-time monitoring with while loops and conditional alerts
- ✅ **get_inactive_members()**: Identify inactive members with configurable criteria
- ✅ **auto_kick_inactive_members()**: Safe automated kicking with dry-run mode

#### 🎯 Advanced Use Cases Enabled
- ✅ **Elite Player Recruitment**: Batch search and filter for high-kill players
- ✅ **Clan Health Analysis**: Calculate health scores and provide recommendations
- ✅ **Activity Trend Monitoring**: Track clan activity patterns over time
- ✅ **Automated Member Management**: Smart categorization and processing
- ✅ **Performance Metrics**: Statistical analysis and reporting

#### 🔧 Technical Improvements
- ✅ **Enhanced Error Handling**: Robust try-catch blocks with graceful recovery
- ✅ **Memory Management**: Automatic cleanup and resource management
- ✅ **Performance Optimization**: Efficient batch processing and lazy loading
- ✅ **Safety Features**: Dry-run modes and protection mechanisms
- ✅ **Documentation**: Complete examples and advanced usage guides

#### 📚 Comprehensive Documentation
- ✅ **Advanced Examples**: Complete automation examples with loops and conditionals
- ✅ **Use Case Scenarios**: Real-world applications for clan management
- ✅ **Safety Guidelines**: Best practices for automated operations
- ✅ **Technical Reference**: Detailed function documentation

#### 🎮 Real-World Automation Examples
```python
# Batch search with conditional logic
results = batch_search_players(['f55f', '9gg9', '218f'], username, password)
for player in results['found']:
    if player['kills'] > 10000:
        print(f"🌟 Elite: {player['dogtag']} - {player['kills']:,} kills")

# Smart clan cleanup with safety
results = clan_cleanup(username, password, inactive_days=30, min_level=15, dry_run=True)
if results['would_kick'] > 0:
    print("⚠️ Consider removing inactive members")

# Real-time monitoring with while loops
monitor_clan_activity(username, password, check_interval=60, max_checks=10)
```

#### 🛡️ Safety & Protection Features
- ✅ **Dry Run Mode**: Test operations without executing actual changes
- ✅ **Level Thresholds**: Configurable minimum level protection
- ✅ **Role Protection**: Automatic safeguarding of important clan roles
- ✅ **Conditional Logic**: Smart decision-making to prevent mistakes
- ✅ **Error Boundaries**: Isolated failure handling for individual operations

---

### 🎮 Major Release - User-Friendly Interface for Non-Developers

#### 🌟 SimpleMC5Client - Revolutionary Easy Interface
- ✅ **New SimpleMC5Client**: Designed specifically for non-developers
- ✅ **Auto-Clan Detection**: Automatically finds clan ID from user profile
- ✅ **Simplified Method Names**: `search_player()` instead of `get_player_stats_by_dogtag()`
- ✅ **One-Liner Functions**: `quick_search()` and `quick_kick()` for instant results
- ✅ **Context Manager Support**: Automatic cleanup with `with` statements
- ✅ **Lazy Authentication**: Only connects when needed, not on initialization
- ✅ **User-Friendly Error Messages**: Clear, helpful explanations for beginners

#### 📚 Comprehensive Documentation for Beginners
- ✅ **User Friendly Guide**: Complete beginner's guide with step-by-step instructions
- ✅ **Simple Usage Examples**: Copy-paste ready code for common tasks
- ✅ **Syntax Comparison Table**: Simple vs Advanced methods side-by-side
- ✅ **FAQ Section**: Common questions and answers for non-developers
- ✅ **Real-World Examples**: Clan management, player search, messaging

#### 🎯 Perfect for Non-Technical Users
- ✅ **Clan Leaders**: Easy member management without technical knowledge
- ✅ **Players**: Quick stats lookup with just a dogtag
- ✅ **Beginners**: No programming experience required
- ✅ **Quick Tasks**: One-liner functions for common operations

#### 📊 Simple vs Advanced Comparison
| Task | Simple Version | Advanced Version |
|------|----------------|------------------|
| Search Player | `client.search_player('f55f')` | `client.get_player_stats_by_dogtag('f55f')` |
| Get Clan Members | `client.get_clan_members()` | `client.get_clan_members(clan_id)` |
| Kick Member | `client.kick_member('9gg9')` | `client.kick_clan_member_by_dogtag('9gg9', clan_id)` |
| Connect | `client.connect()` | Manual authentication |

#### 🔧 Technical Improvements
- ✅ **Backward Compatibility**: All existing advanced features still available
- ✅ **Graceful Error Handling**: User-friendly error messages
- ✅ **Memory Management**: Automatic connection cleanup
- ✅ **Import Updates**: SimpleMC5Client added to main package exports

#### 🎮 Real-World Usage Examples
```python
# Super simple - just 3 lines!
from mc5_api_client import SimpleMC5Client
client = SimpleMC5Client('YOUR_USERNAME', 'YOUR_PASSWORD')
client.connect()
player = client.search_player('f55f')

# One-liner search
from mc5_api_client import quick_search
player = quick_search('218f', 'YOUR_USERNAME', 'YOUR_PASSWORD')

# Easy clan management
with SimpleMC5Client('YOUR_USERNAME', 'YOUR_PASSWORD') as client:
    client.connect()  # Auto-finds your clan!
    members = client.get_clan_members()
    client.kick_member('9gg9', 'Inactive for 30 days')
```

---

## [1.0.5] - 2026-02-03

### 🔧 Critical Bug Fix

#### 🌐 Fixed Missing API Endpoint
- ✅ Added missing `janus` URL to BASE_URLS configuration
- ✅ Fixed player lookup by alias/dogtag functionality
- ✅ Resolved `'janus'` KeyError in alias lookup methods
- ✅ All batch profile functionality now working correctly

#### 🧪 Verified Functionality
- ✅ Dogtag to alias conversion: f55f → d33d ✅
- ✅ Player lookup by alias: Working perfectly ✅
- ✅ Batch profile retrieval: Successfully tested ✅
- ✅ Dogtag search with stats: Rating 800, K/D 14.75 ✅
- ✅ Statistics parsing: All data structured correctly ✅

#### 📚 Updated Documentation
- ✅ Added dogtag search example to quick start guide
- ✅ Enhanced README with working batch profile examples
- ✅ Updated feature list with verified functionality
- ✅ Added real test results to documentation

#### 🎯 Real-World Test Results
- **Test Player**: Dogtag f55f → Alias d33d
- **Rating**: 800
- **K/D Ratio**: 14.75 (Excellent!)
- **Total Kills**: 59
- **Total Headshots**: 16
- **XP**: 4,439
- **Account ID**: 9f2905fe-d346-11ef-8471-b8ca3a67cd10

## [1.0.4] - 2026-02-03

### 🚀 Player Statistics & Batch Profiles Feature

#### 📊 Batch Profile System (6+ Methods)
- ✅ Get batch player profiles with detailed statistics and game save data
- ✅ Search players by dogtag (in-game ID) with automatic alias conversion
- ✅ Get detailed player statistics using credentials
- ✅ Parse and structure player statistics for easy consumption
- ✅ Combine alias lookup with stats retrieval
- ✅ Support for multiple player batch operations
- ✅ Access detailed game save data including progress, loadouts, weapons
- ✅ Weapon statistics and performance analysis
- ✅ Campaign progress tracking
- ✅ Overall statistics calculation (K/D ratios, accuracy, etc.)
- ✅ Player performance analysis tools

#### 🏷️ Enhanced Alias/Dogtags Integration
- ✅ Seamless integration between dogtag conversion and player lookup
- ✅ Automatic dogtag to alias conversion for API calls
- ✅ Combined dogtag search with detailed statistics retrieval
- ✅ Enhanced error handling for invalid dogtags
- ✅ Support for all dogtag formats with validation

#### 📚 New Example Script
- ✅ Added `examples/player_stats.py` with comprehensive demonstrations
- ✅ Real-world usage scenarios for player analytics
- ✅ Performance analysis and weapon statistics examples
- ✅ Batch operations and multi-player lookup examples
- ✅ Advanced usage patterns for player data analysis

#### 📖 Enhanced Documentation
- ✅ Added Player Statistics section to README
- ✅ Detailed usage examples for batch profiles
- ✅ Integration examples with alias/dogtag system
- ✅ Performance analysis and statistics parsing examples
- ✅ Updated feature list with new batch profile methods

#### 🔧 Code Quality Improvements
- ✅ Comprehensive error handling for batch operations
- ✅ Robust data parsing and validation
- ✅ Type hints for all new methods
- ✅ Detailed docstrings with examples
- ✅ Support for edge cases and malformed data

#### 🧪 Testing & Validation
- ✅ All new methods tested with real API endpoints
- ✅ Error scenarios handled gracefully
- ✅ Performance optimization for batch operations
- ✅ Memory-efficient data parsing

### 📋 Technical Details

#### 🌐 New API Endpoint Integration
- **Endpoint**: `https://app-468561b3-9ecd-4d21-8241-30ed288f4d8b.gold0009.gameloft.com/1875/windows/09/public/OfficialScripts/mc5Portal.wsgi`
- **Method**: POST with form-encoded data
- **Operation**: `get_batch_profiles`
- **Fields**: `_game_save`, `inventory` (configurable)
- **Authentication**: Uses existing client authentication

#### 🔄 Dogtag to Alias Conversion
- **Mathematical Algorithm**: Letters (ASCII -2), Digits (mod 10 arithmetic)
- **Validation**: Automatic format detection and error handling
- **Integration**: Seamless conversion for API compatibility
- **Examples**: f55f → d33d, ff11 → dd99, g6765 → e4543

#### 📊 Data Structure Parsing
- **Game Save Data**: Rating, progress, loadouts, statistics
- **Inventory Data**: XP, VIP points, weapon statistics
- **Weapon Stats**: Kills, shots, hits, accuracy, time used
- **Overall Stats**: K/D ratios, headshot percentages, time played

## [1.0.3] - 2026-02-02

### Added
- Initial release of MC5 API Client by Chizoba
- Comprehensive authentication system with token generation
- Support for both user and admin authentication
- Modern CLI interface with Rich formatting and debug capabilities
- Full API coverage including:
  - Profile management
  - Clan operations
  - Friend management
  - Messaging system
  - Events and tasks
  - Leaderboard access
  - Game objects
  - Asset metadata
  - Alias lookup
- Automatic token refresh functionality
- Comprehensive error handling with custom exceptions
- Type hints throughout the codebase
- Extensive documentation and examples
- Unit test coverage
- PyPI package configuration
- Development environment setup
- Python 3.11+ support (beta version)

### Features
- **Authentication**: Easy token generation and management
- **CLI**: Rich command-line interface with progress indicators
- **Auto-refresh**: Automatic token renewal
- **Error Handling**: Comprehensive exception hierarchy
- **Type Safety**: Full type annotation support
- **Documentation**: Detailed README and examples
- **Testing**: Unit tests with mocking
- **Configuration**: Persistent config and token storage

### CLI Commands
- `generate-token` - Generate user access tokens
- `generate-admin-token` - Generate admin access tokens
- `validate-token` - Validate saved tokens
- `show-config` - Display configuration
- `clear-config` - Clear saved data

### API Endpoints Supported
- Authentication (Janus)
- Profile management (Osiris)
- Clan operations (Osiris)
- Friend system (Osiris)
- Messaging (Osiris)
- Events (Osiris)
- Leaderboards (Osiris/Olympus)
- Game objects (Iris)
- Asset metadata (Iris)
- Alias lookup (Janus)

### Installation
```bash
pip install mc5-api-client
```

### Development Installation
```bash
pip install mc5-api-client[dev]
```

### Example Usage
```python
from mc5_api_client import MC5Client

with MC5Client(username="user", password="pass") as client:
    profile = client.get_profile()
    events = client.get_events()
    client.send_private_message("target", "Hello!")
```

### CLI Usage
```bash
mc5 generate-token --username "user" --password "pass" --save
mc5 validate-token
mc5 show-config
```

---

## [Unreleased]

### Planned
- Additional API endpoints
- Enhanced CLI features
- Performance optimizations
- More examples and tutorials
