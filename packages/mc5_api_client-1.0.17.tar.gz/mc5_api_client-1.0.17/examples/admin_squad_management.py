#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : admin_squad_management.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Admin squad management examples
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Admin Squad Management Examples

This example demonstrates admin capabilities for squad management:
- Adding rating to squad
- Updating player scores
- Managing squad members
- Automatic squad detection
"""

from mc5_api_client import (
    AdminMC5Client,
    create_admin_client,
    create_user_client,
    quick_add_squad_rating,
    quick_update_player_score
)

def example_1_admin_add_rating():
    """Example 1: Add 5200 rating using admin credentials."""
    print("🎮 Example 1: Admin Add 5200 Rating")
    print("=" * 40)
    
    try:
        # Quick method
        result = quick_add_squad_rating(
            username="game:mc5_system",
            password="admin",
            rating=5200,
            use_admin=True
        )
        
        if 'error' in result:
            print(f"❌ Failed: {result['error']}")
        else:
            print("✅ Success! 5200 rating added to squad!")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def example_2_user_add_rating():
    """Example 2: Add rating using user credentials."""
    print("\n🎮 Example 2: User Add Rating")
    print("=" * 35)
    
    # Your credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    try:
        result = quick_add_squad_rating(
            username=username,
            password=password,
            rating=1000,
            use_admin=False
        )
        
        if 'error' in result:
            print(f"❌ Failed: {result['error']}")
        else:
            print("✅ Success! Rating added to your squad!")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def example_3_admin_client_usage():
    """Example 3: Using AdminMC5Client directly."""
    print("\n🎮 Example 3: Admin Client Usage")
    print("=" * 38)
    
    try:
        # Create admin client
        client = create_admin_client()
        
        print("🔌 Connecting with admin...")
        if client.connect():
            print("✅ Admin connected!")
            print(f"🏰 Squad ID: {client.squad_id}")
            
            # Get squad members
            members = client.get_squad_members()
            if members:
                print(f"👥 Squad has {len(members)} members")
                
                # Show top members
                print("\n📊 Top Squad Members:")
                sorted_members = sorted(members, key=lambda x: x.get('_score', 0), reverse=True)
                for i, member in enumerate(sorted_members[:3], 1):
                    name = member.get('name', 'Unknown')
                    score = member.get('_score', 0)
                    level = member.get('level', 0)
                    print(f"   {i}. {name} - Level {level}, Score: {score:,}")
            
            # Add rating
            print(f"\n⭐ Adding 5200 rating...")
            result = client.add_squad_rating(5200)
            
            if 'error' not in result:
                print("✅ Rating added successfully!")
            
            client.close()
        else:
            print("❌ Failed to connect")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def example_4_update_player_score():
    """Example 4: Update player score (admin only)."""
    print("\n🎮 Example 4: Update Player Score")
    print("=" * 38)
    
    # Target player (your user ID)
    target_user_id = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    
    try:
        print(f"🎯 Updating player {target_user_id}...")
        
        result = quick_update_player_score(
            target_user_id=target_user_id,
            score=1204,
            xp=2037745,
            killsig_color="-974646126",
            killsig_id="default_killsig_80"
        )
        
        if 'error' in result:
            print(f"❌ Failed: {result['error']}")
        else:
            print("✅ Player updated successfully!")
            print(f"   📊 Score: {result.get('score_updated', 'N/A')}")
            print(f"   📈 XP: {result.get('xp_updated', 'N/A')}")
            print(f"   🎨 Kill Signature Color: {result.get('killsig_color_updated', 'N/A')}")
            print(f"   🎯 Kill Signature ID: {result.get('killsig_id_updated', 'N/A')}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def example_5_user_client_with_squad():
    """Example 5: User client with automatic squad detection."""
    print("\n🎮 Example 5: User Client with Squad Detection")
    print("=" * 50)
    
    # Your credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="
    password = "sSJKzhQ5l4vrFgov"
    
    try:
        # Create user client
        client = create_user_client(username, password)
        
        print("🔌 Connecting with user credentials...")
        if client.connect():
            print("✅ User connected!")
            print(f"🏰 Auto-detected Squad ID: {client.squad_id}")
            
            # Get user stats
            stats = client.get_user_stats()
            if stats:
                name = stats.get('name', 'Unknown')
                score = stats.get('_score', 0)
                level = stats.get('level', 0)
                print(f"👤 User: {name} - Level {level}, Score: {score:,}")
            
            # Add rating to squad
            print(f"\n⭐ Adding 500 rating to squad...")
            result = client.add_squad_rating(500)
            
            if 'error' not in result:
                print("✅ Rating added successfully!")
            
            client.close()
        else:
            print("❌ Failed to connect")
        
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    """Run all admin squad management examples."""
    print("🚀 MC5 API Client - Admin Squad Management Examples")
    print("=" * 55)
    print("📝 Demonstrating admin capabilities and squad management")
    print()
    
    examples = [
        ("Admin Add 5200 Rating", example_1_admin_add_rating),
        ("User Add Rating", example_2_user_add_rating),
        ("Admin Client Usage", example_3_admin_client_usage),
        ("Update Player Score", example_4_update_player_score),
        ("User Client with Squad", example_5_user_client_with_squad)
    ]
    
    for example_name, example_func in examples:
        print(f"\n{'='*60}")
        try:
            example_func()
            print(f"✅ {example_name} completed")
        except Exception as e:
            print(f"❌ {example_name} failed: {e}")
    
    print(f"\n{'='*60}")
    print("🎉 All admin examples completed!")
    print("💡 Key Features Demonstrated:")
    print("   ✅ Admin credentials usage")
    print("   ✅ Automatic squad detection")
    print("   ✅ Rating addition to squad")
    print("   ✅ Player score updates")
    print("   ✅ User-friendly interfaces")
    print("   ✅ Error handling")

if __name__ == "__main__":
    main()
