#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : admin_tools.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Simple admin tools for MC5 squad management
# ────────────────★─────────────────────────────────

"""
MC5 Admin Tools - Simple Squad Management
==========================================

This script provides easy-to-use admin functions for managing MC5 squads.
Perfect for clan leaders and admins who want to:

- Update player scores (add rating to squad)
- Manage squad members
- Check squad statistics
- Handle clan requests

What makes this special:
- No complex API knowledge needed
- Clear error messages
- Safe operations with confirmations
- Works with real MC5 data
"""

from mc5_api_client import quick_update_player_score, create_admin_client
import time

def update_player_score():
    """Update a player's score to add rating to squad."""
    print("🎯 Update Player Score")
    print("=" * 25)
    
    # Get player info
    player_id = input("Enter player user ID (e.g., anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c=): ").strip()
    
    if not player_id:
        print("❌ Player ID is required")
        return
    
    # Get score to set
    try:
        score = int(input("Enter score to set (e.g., 5200): ").strip() or "5200")
    except ValueError:
        print("❌ Invalid score - must be a number")
        return
    
    # Optional: XP
    xp_input = input("Enter XP (optional, press Enter to skip): ").strip()
    xp = int(xp_input) if xp_input else None
    
    # Optional: Kill signature
    killsig_color = input("Enter kill signature color (optional, press Enter to skip): ").strip() or None
    killsig_id = input("Enter kill signature ID (optional, press Enter to skip): ").strip() or None
    
    print(f"\n🔄 Updating player {player_id[:30]}...")
    print(f"📊 Score: {score}")
    if xp:
        print(f"⭐ XP: {xp}")
    if killsig_color:
        print(f"🎨 Kill signature color: {killsig_color}")
    if killsig_id:
        print(f"🎯 Kill signature ID: {killsig_id}")
    
    # Confirm before updating
    confirm = input("\n⚠️ This will update the player's score. Continue? (y/n): ").strip().lower()
    
    if confirm != 'y':
        print("❌ Cancelled")
        return
    
    # Update the score
    result = quick_update_player_score(
        target_user_id=player_id,
        score=score,
        xp=xp,
        killsig_color=killsig_color,
        killsig_id=killsig_id
    )
    
    if result.get('success'):
        print("✅ Success! Player score updated:")
        print(f"   📊 New score: {result.get('score_updated')}")
        if result.get('xp_updated'):
            print(f"   ⭐ New XP: {result.get('xp_updated')}")
        if result.get('killsig_color_updated'):
            print(f"   🎨 New kill signature color: {result.get('killsig_color_updated')}")
        if result.get('killsig_id_updated'):
            print(f"   🎯 New kill signature ID: {result.get('killsig_id_updated')}")
    else:
        print(f"❌ Error: {result.get('error', 'Unknown error')}")

def manage_squad_members():
    """Manage squad members with admin client."""
    print("👥 Manage Squad Members")
    print("=" * 25)
    
    try:
        # Create admin client
        client = create_admin_client()
        
        if not client.connect():
            print("❌ Failed to connect as admin")
            return
        
        print("✅ Connected as admin")
        
        # Get squad members
        print("\n📋 Getting squad members...")
        members = client.get_squad_members()
        
        if not members:
            print("❌ No squad members found")
            return
        
        print(f"✅ Found {len(members)} squad members:")
        
        # Show member list with numbers
        for i, member in enumerate(members, 1):
            name = member.get('name', 'Unknown')
            score = member.get('_score', 0)
            online = "🟢 Online" if member.get('online', False) else "🔴 Offline"
            print(f"   {i}. {name} - Score: {score:,} - {online}")
        
        print("\n🔧 Admin Options:")
        print("1. Kick a member")
        print("2. Show member details")
        print("3. Back to main menu")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            kick_member(client, members)
        elif choice == '2':
            show_member_details(members)
        else:
            print("🔙 Returning to main menu")
        
        client.close()
        
    except Exception as e:
        print(f"❌ Error managing squad members: {e}")

def kick_member(client, members):
    """Kick a member from the squad."""
    print("\n🚪 Kick Member")
    print("-" * 15)
    
    try:
        member_num = int(input("Enter member number to kick: ").strip())
        
        if member_num < 1 or member_num > len(members):
            print("❌ Invalid member number")
            return
        
        member = members[member_num - 1]
        member_name = member.get('name', 'Unknown')
        member_credential = member.get('credential', '')
        
        if not member_credential:
            print("❌ Member credential not found")
            return
        
        print(f"\n⚠️ About to kick: {member_name}")
        reason = input("Enter reason for kick: ").strip() or "Kicked by admin"
        
        confirm = input(f"\n⚠️ Kick {member_name} for '{reason}'? (y/n): ").strip().lower()
        
        if confirm != 'y':
            print("❌ Cancelled")
            return
        
        result = client.kick_member(member_credential, reason)
        
        if result.get('success'):
            print(f"✅ Successfully kicked {member_name}")
        else:
            print(f"❌ Error kicking member: {result.get('error', 'Unknown error')}")
            
    except ValueError:
        print("❌ Invalid number")
    except Exception as e:
        print(f"❌ Error kicking member: {e}")

def show_member_details(members):
    """Show detailed information about a member."""
    print("\n📊 Member Details")
    print("-" * 18)
    
    try:
        member_num = int(input("Enter member number: ").strip())
        
        if member_num < 1 or member_num > len(members):
            print("❌ Invalid member number")
            return
        
        member = members[member_num - 1]
        
        print(f"\n👤 Name: {member.get('name', 'Unknown')}")
        print(f"📊 Score: {member.get('_score', 0):,}")
        print(f"⭐ XP: {member.get('_xp', 0):,}")
        print(f"🎯 Level: {member.get('level', 'Unknown')}")
        print(f"🟢 Online: {'Yes' if member.get('online', False) else 'No'}")
        print(f"📅 Joined: {member.get('join_date', 'Unknown')}")
        print(f"🔑 Credential: {member.get('credential', 'Unknown')}")
        
        # Kill signature info
        killsig = member.get('_killsig', {})
        if killsig:
            print(f"🎨 Kill Signature: {killsig.get('id', 'Unknown')}")
            print(f"🎯 Kill Color: {killsig.get('color', 'Unknown')}")
        
    except ValueError:
        print("❌ Invalid number")
    except Exception as e:
        print(f"❌ Error showing member details: {e}")

def check_clan_requests():
    """Check and respond to clan requests."""
    print("📋 Clan Requests")
    print("=" * 18)
    
    try:
        client = create_admin_client()
        
        if not client.connect():
            print("❌ Failed to connect as admin")
            return
        
        print("✅ Connected as admin")
        
        # Get clan requests
        print("\n📋 Getting clan requests...")
        requests = client.get_clan_requests()
        
        if not requests:
            print("ℹ️ No clan requests found")
            return
        
        print(f"✅ Found {len(requests)} clan requests:")
        
        # Show requests
        for i, request in enumerate(requests, 1):
            request_id = request.get('id', 'Unknown')
            player_name = request.get('player_name', 'Unknown')
            message = request.get('message', 'No message')
            print(f"   {i}. {player_name} - {message[:50]}... (ID: {request_id[:20]}...)")
        
        print("\n🔧 Request Options:")
        print("1. Accept a request")
        print("2. Reject a request")
        print("3. Back to main menu")
        
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == '1':
            handle_request(client, requests, 'accept')
        elif choice == '2':
            handle_request(client, requests, 'reject')
        else:
            print("🔙 Returning to main menu")
        
        client.close()
        
    except Exception as e:
        print(f"❌ Error checking clan requests: {e}")

def handle_request(client, requests, action):
    """Handle accepting or rejecting a clan request."""
    action_word = 'accept' if action == 'accept' else 'reject'
    
    try:
        request_num = int(input(f"\nEnter request number to {action_word}: ").strip())
        
        if request_num < 1 or request_num > len(requests):
            print("❌ Invalid request number")
            return
        
        request = requests[request_num - 1]
        request_id = request.get('id', '')
        player_name = request.get('player_name', 'Unknown')
        
        if not request_id:
            print("❌ Request ID not found")
            return
        
        message = input(f"Enter message for {action_word}ance (optional): ").strip()
        
        print(f"\n⚠️ About to {action_word} request from: {player_name}")
        confirm = input(f"Continue? (y/n): ").strip().lower()
        
        if confirm != 'y':
            print("❌ Cancelled")
            return
        
        result = client.respond_to_clan_request(request_id, action, message)
        
        if result.get('success'):
            print(f"✅ Successfully {action_word}ed request from {player_name}")
        else:
            print(f"❌ Error {action_word}ing request: {result.get('error', 'Unknown error')}")
            
    except ValueError:
        print("❌ Invalid number")
    except Exception as e:
        print(f"❌ Error handling request: {e}")

def main():
    """Main admin menu."""
    print("🛡️ MC5 Admin Tools")
    print("=" * 20)
    print("Simple squad management for MC5 admins")
    print()
    
    while True:
        print("\n🔧 Admin Menu:")
        print("1. Update Player Score")
        print("2. Manage Squad Members")
        print("3. Check Clan Requests")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            update_player_score()
        elif choice == '2':
            manage_squad_members()
        elif choice == '3':
            check_clan_requests()
        elif choice == '4':
            print("👋 Goodbye!")
            break
        else:
            print("❌ Invalid choice. Please enter 1-4.")
        
        print("\n" + "=" * 40)
        time.sleep(1)  # Small delay between operations

if __name__ == "__main__":
    main()
