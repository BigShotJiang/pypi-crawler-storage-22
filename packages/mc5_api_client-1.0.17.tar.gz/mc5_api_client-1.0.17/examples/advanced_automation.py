#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : advanced_automation.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : Advanced automation examples with loops and conditionals
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Advanced Automation Examples

This file demonstrates advanced usage with loops, conditional logic,
and automation features for clan management and player monitoring.
"""

from mc5_api_client.simple_client import (
    SimpleMC5Client, 
    batch_search_players, 
    clan_cleanup, 
    monitor_clan_activity
)

# Your credentials
USERNAME = "YOUR_USERNAME_HERE"
PASSWORD = "YOUR_PASSWORD_HERE"

def example_1_batch_player_search():
    """Example 1: Search for multiple players with loop"""
    print("🔍 Example 1: Batch Player Search")
    print("=" * 40)
    
    # List of dogtags to search
    dogtags_to_search = ["f55f", "9gg9", "78d7", "218f", "abcd", "1234"]
    
    print(f"Searching for {len(dogtags_to_search)} players...")
    
    # Batch search with automatic loop
    results = batch_search_players(dogtags_to_search, USERNAME, PASSWORD)
    
    print(f"\n📊 Results:")
    print(f"   Found: {len(results['found'])} players")
    print(f"   Not found: {len(results['not_found'])} dogtags")
    print(f"   Errors: {len(results['errors'])} errors")
    
    # Conditional processing of results
    if results['found']:
        print(f"\n✅ Found Players:")
        for player in results['found']:
            kills = player['kills']
            rating = player['rating']
            
            # Conditional formatting based on stats
            if kills > 10000:
                print(f"   🌟 {player['dogtag']}: {kills:,} kills (ELITE!)")
            elif kills > 1000:
                print(f"   ⭐ {player['dogtag']}: {kills:,} kills (Skilled)")
            else:
                print(f"   👤 {player['dogtag']}: {kills:,} kills (Beginner)")
    
    if results['not_found']:
        print(f"\n❌ Not Found:")
        for dogtag in results['not_found']:
            print(f"   {dogtag}")

def example_2_intelligent_clan_cleanup():
    """Example 2: Smart clan cleanup with conditional logic"""
    print("\n🧹 Example 2: Intelligent Clan Cleanup")
    print("=" * 45)
    
    # Run cleanup with different conditions
    print("🔍 Running cleanup simulation...")
    
    results = clan_cleanup(
        username=USERNAME,
        password=PASSWORD,
        inactive_days=30,
        min_level=15,  # Protect players level 15+
        dry_run=True  # Simulation only
    )
    
    print(f"\n📊 Cleanup Analysis:")
    print(f"   Total members: {results['total_members']}")
    print(f"   Active members: {results['active_members']}")
    print(f"   Inactive members: {results['inactive_members']}")
    print(f"   Protected members: {results['protected']}")
    print(f"   Would kick: {results['would_kick']}")
    
    # Conditional recommendations
    if results['would_kick'] > 0:
        print(f"\n⚠️ Recommendations:")
        print(f"   Consider kicking {results['would_kick']} inactive members")
        print(f"   This could free up {results['would_kick']} clan slots")
    else:
        print(f"\n✅ Clan looks healthy!")
        print(f"   No members need to be kicked")
    
    if results['protected'] > results['inactive_members']:
        print(f"\n🛡️ Good protection: More members protected than inactive")
    
    # Show detailed actions
    print(f"\n📋 Detailed Actions:")
    for action in results['actions'][:10]:  # Show first 10
        print(f"   {action}")
    
    if len(results['actions']) > 10:
        print(f"   ... and {len(results['actions']) - 10} more actions")

def example_3_conditional_member_management():
    """Example 3: Advanced member management with if/else logic"""
    print("\n👥 Example 3: Conditional Member Management")
    print("=" * 50)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if not client.connect():
            print("❌ Failed to connect")
            return
        
        members = client.get_clan_members()
        print(f"Analyzing {len(members)} clan members...")
        
        # Categorize members with conditional logic
        categories = {
            'elite': [],      # High level, high XP
            'active': [],      # Currently online
            'veterans': [],    # Medium level, good XP
            'newbies': [],     # Low level
            'inactive': []    # Offline
        }
        
        for member in members:
            level = member.get('level', 0)
            xp = member.get('_xp', 0)
            online = member.get('online', False)
            
            # Conditional categorization
            if online:
                categories['active'].append(member)
            elif level >= 50 and xp > 1000000:
                categories['elite'].append(member)
            elif level >= 25 and xp > 500000:
                categories['veterans'].append(member)
            elif level < 10:
                categories['newbies'].append(member)
            else:
                categories['inactive'].append(member)
        
        # Display results with conditional formatting
        print(f"\n📊 Clan Composition:")
        
        for category, member_list in categories.items():
            if member_list:
                print(f"\n{category.upper()} ({len(member_list)} members):")
                
                for member in member_list[:3]:  # Show first 3 of each category
                    level = member.get('level', 0)
                    xp = member.get('_xp', 0)
                    name = member.get('name', 'Unknown')
                    
                    # Conditional formatting based on category
                    if category == 'elite':
                        print(f"   🌟 {name} - Level {level}, {xp:,} XP (ELITE)")
                    elif category == 'active':
                        print(f"   🟢 {name} - Level {level}, {xp:,} XP (ONLINE)")
                    elif category == 'veterans':
                        print(f"   ⭐ {name} - Level {level}, {xp:,} XP (VETERAN)")
                    elif category == 'newbies':
                        print(f"   🆕 {name} - Level {level}, {xp:,} XP (NEW)")
                    else:
                        print(f"   🔴 {name} - Level {level}, {xp:,} XP (INACTIVE)")
                
                if len(member_list) > 3:
                    print(f"   ... and {len(member_list) - 3} more")
        
        # Conditional recommendations
        total_members = len(members)
        active_percentage = (len(categories['active']) / total_members) * 100
        
        print(f"\n💡 Recommendations:")
        
        if active_percentage < 30:
            print("   ⚠️ Low activity! Consider recruiting more active players")
        elif active_percentage > 70:
            print("   🎉 High activity! Your clan is very active!")
        else:
            print("   ✅ Good activity balance")
        
        if len(categories['newbies']) > len(categories['elite']):
            print("   📈 Consider mentoring new players to build elite members")

def example_4_monitoring_with_while_loop():
    """Example 4: Real-time monitoring with while loop"""
    print("\n🔍 Example 4: Real-time Clan Monitoring")
    print("=" * 45)
    
    print("Starting clan activity monitor (short demo)...")
    print("This will check clan activity every 5 seconds for 3 checks")
    
    # Run monitoring with short intervals for demo
    monitor_clan_activity(
        username=USERNAME,
        password=PASSWORD,
        check_interval=5,  # 5 seconds between checks
        max_checks=3       # Only 3 checks for demo
    )

def example_5_automated_workflows():
    """Example 5: Complete automated workflow"""
    print("\n🤖 Example 5: Complete Automated Workflow")
    print("=" * 45)
    
    with SimpleMC5Client(USERNAME, PASSWORD) as client:
        if not client.connect():
            print("❌ Failed to connect")
            return
        
        print("🚀 Starting automated clan management workflow...")
        
        # Step 1: Get clan overview
        members = client.get_clan_members()
        print(f"📊 Clan has {len(members)} members")
        
        # Step 2: Analyze member levels
        level_stats = {'low': 0, 'medium': 0, 'high': 0}
        
        for member in members:
            level = member.get('level', 0)
            if level < 20:
                level_stats['low'] += 1
            elif level < 50:
                level_stats['medium'] += 1
            else:
                level_stats['high'] += 1
        
        print(f"📈 Level Distribution:")
        print(f"   Low (1-19): {level_stats['low']} members")
        print(f"   Medium (20-49): {level_stats['medium']} members")
        print(f"   High (50+): {level_stats['high']} members")
        
        # Step 3: Conditional actions based on clan composition
        if level_stats['low'] > level_stats['high']:
            print("💡 Recommendation: Focus on training low-level members")
        elif level_stats['high'] > len(members) * 0.5:
            print("🌟 Excellent! Your clan has many high-level members")
        else:
            print("✅ Good balance of member levels")
        
        # Step 4: Search for potential recruits (example dogtags)
        print("\n🔍 Searching for potential elite players...")
        elite_dogtags = ["218f", "f55f", "9gg9"]  # Known high-kill players
        
        for dogtag in elite_dogtags:
            player = client.search_player(dogtag)
            if player:
                kills = player['kills']
                if kills > 10000:
                    print(f"   🌟 Found elite player: {dogtag} ({kills:,} kills)")
                elif kills > 1000:
                    print(f"   ⭐ Found skilled player: {dogtag} ({kills:,} kills)")
                else:
                    print(f"   👤 Found player: {dogtag} ({kills:,} kills)")
            else:
                print(f"   ❌ Player not found: {dogtag}")
        
        print("\n✅ Automated workflow completed!")

def main():
    """Run all advanced examples"""
    print("🤖 MC5 API Client - Advanced Automation Examples")
    print("=" * 55)
    print("📝 These examples demonstrate loops, conditionals, and automation")
    print("🔧 Replace YOUR_USERNAME_HERE and YOUR_PASSWORD_HERE with your credentials")
    print()
    
    try:
        # Run examples (comment out ones you don't want to run)
        example_1_batch_player_search()
        example_2_intelligent_clan_cleanup()
        example_3_conditional_member_management()
        # example_4_monitoring_with_while_loop()  # Uncomment for real-time monitoring
        example_5_automated_workflows()
        
    except Exception as e:
        print(f"❌ Error running examples: {e}")
        print("💡 Make sure you've entered your correct MC5 credentials")

if __name__ == "__main__":
    main()
