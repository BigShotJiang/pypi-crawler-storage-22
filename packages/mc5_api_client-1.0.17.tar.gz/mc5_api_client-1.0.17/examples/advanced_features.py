#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : advanced_features.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Advanced MC5 API features demonstration
# ────────────────★─────────────────────────────────

"""
Advanced MC5 API Features Demonstration
This script showcases the new advanced features:
- Events API (daily tasks, squad events, milestones)
- Account Management (import, link, migrate)
- Alias/Dogtags System (player ID conversion)
- Game Configuration (assets, catalogs, URLs)
"""

import time
from datetime import datetime
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main demonstration of advanced MC5 API features."""
    
    print("🚀 MC5 API Advanced Features Demonstration")
    print("=" * 60)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # 1. Events API Demonstration
    print("\n📅 Events API Demonstration")
    print("-" * 40)
    
    try:
        # Get all events
        events = client.get_events()
        print(f"📊 Found {len(events)} active events")
        
        # Get daily tasks
        daily_tasks = client.get_daily_tasks()
        if daily_tasks:
            print(f"🎯 Daily Tasks Event: {daily_tasks.get('name', 'Unknown')}")
            print(f"📝 Tasks: {len(daily_tasks.get('tasks', []))}")
            print(f"🏆 Milestones: {len(daily_tasks.get('milestones', []))}")
            
            # Show first few tasks
            for i, task in enumerate(daily_tasks.get('tasks', [])[:3], 1):
                print(f"   {i}. {task.get('condition_type', 'unknown')} - {task.get('points', 0)} points")
        
        # Get squad events
        squad_events = client.get_squad_events()
        print(f"👥 Squad Events: {len(squad_events)}")
        
        for event in squad_events[:2]:  # Show first 2 squad events
            print(f"   🎮 {event.get('name', 'Unknown')}")
            print(f"   📅 Status: {event.get('status', 'unknown')}")
            if event.get('tournament_info'):
                print(f"   🏆 Tournament: {event.get('tournament_info', {}).get('type', 'unknown')}")
        
        # Calculate rewards for an event
        if daily_tasks:
            rewards = client.calculate_event_rewards(daily_tasks.get('name', ''), 50)
            print(f"💰 Rewards at 50 points: {len(rewards.get('available_milestones', []))} milestones")
            
    except Exception as e:
        print(f"❌ Events API error: {e}")
    
    # 2. Account Management Demonstration
    print("\n👤 Account Management Demonstration")
    print("-" * 40)
    
    try:
        # Get account info
        account_info = client.get_account_info()
        print(f"📊 Account Name: {account_info.get('name', 'Unknown')}")
        print(f"🎮 Level: {account_info.get('level', 'Unknown')}")
        print(f"💰 Credits: {account_info.get('credits', 'Unknown')}")
        
        # Demonstrate account linking (placeholder)
        print("🔗 Account Linking:")
        print("   ✅ Link account functionality available")
        print("   ✅ Account migration functionality available")
        print("   ✅ Account unlink functionality available")
        
        # Note: Actual linking would require real credentials and secrets
        print("   ⚠️  Actual linking requires valid platform credentials")
        
    except Exception as e:
        print(f"❌ Account management error: {e}")
    
    # 3. Alias/Dogtags System Demonstration
    print("\n🏷️ Alias/Dogtags System Demonstration")
    print("-" * 40)
    
    try:
        # Demonstrate dogtag to alias conversion
        test_dogtags = ["f55f", "ff11", "g6765", "1234", "abcd"]
        
        print("🔄 Dogtag to Alias Conversion:")
        for dogtag in test_dogtags:
            alias = client.convert_dogtag_to_alias(dogtag)
            print(f"   {dogtag} → {alias}")
        
        print("\n🔄 Alias to Dogtag Conversion:")
        for dogtag in test_dogtags:
            alias = client.convert_dogtag_to_alias(dogtag)
            back_to_dogtag = client.convert_alias_to_dogtag(alias)
            print(f"   {alias} → {back_to_dogtag}")
        
        # Test alias lookup (with a common alias)
        test_alias = "d33d"  # Common test alias
        print(f"\n🔍 Looking up alias: {test_alias}")
        
        try:
            alias_info = client.get_alias_info(test_alias)
            print(f"   📊 Type: {alias_info.get('type', 'Unknown')}")
            print(f"   🆔 Account: {alias_info.get('account', 'Unknown')}")
            print(f"   👤 Credential: {alias_info.get('credential', 'Unknown')[:20]}...")
        except Exception as e:
            print(f"   ⚠️  Alias lookup failed: {e}")
        
    except Exception as e:
        print(f"❌ Alias system error: {e}")
    
    # 4. Game Configuration Demonstration
    print("\n⚙️ Game Configuration Demonstration")
    print("-" * 40)
    
    try:
        # Get service URLs
        service_urls = client.get_service_urls()
        print("🌐 Service URLs:")
        for service, url in service_urls.items():
            print(f"   {service}: {url}")
        
        # Get basic game config
        basic_config = client.get_game_config("basic")
        print(f"\n📊 Basic Config:")
        print(f"   🆔 Client ID: {basic_config.get('client_id', 'Unknown')}")
        print(f"   🌐 Services: {len(basic_config.get('service_urls', {}))}")
        
        # Get asset metadata (example)
        asset_path = "videos_HD_UPD18_pvx"
        print(f"\n📹 Asset Metadata for: {asset_path}")
        
        try:
            asset_metadata = client.get_asset_metadata(asset_path)
            print(f"   🔑 Hash: {asset_metadata.get('hash', 'Unknown')}")
        except Exception as e:
            print(f"   ⚠️  Asset metadata not available: {e}")
        
        # Get game object catalog
        print(f"\n📦 Game Object Catalog:")
        try:
            game_objects = client.get_game_object_catalog()
            print(f"   📊 Total Objects: {len(game_objects)}")
            
            # Show first few object types
            object_types = set()
            for obj in game_objects[:10]:  # First 10 objects
                object_types.add(obj.get('category', 'unknown'))
            
            print(f"   🏷️  Object Types: {', '.join(list(object_types)[:5])}")
            
        except Exception as e:
            print(f"   ⚠️  Game object catalog not available: {e}")
        
    except Exception as e:
        print(f"❌ Game configuration error: {e}")
    
    # 5. Advanced Usage Examples
    print("\n🎯 Advanced Usage Examples")
    print("-" * 40)
    
    try:
        # Example 1: Event Progress Tracker
        print("📈 Event Progress Tracker:")
        if daily_tasks:
            current_points = 75  # Simulated current points
            rewards = client.calculate_event_rewards(daily_tasks.get('name', ''), current_points)
            
            print(f"   📊 Current Points: {current_points}")
            print(f"   🏆 Available Milestones: {len(rewards.get('available_milestones', []))}")
            
            next_milestone = rewards.get('next_milestone', {})
            if next_milestone:
                needed = next_milestone.get('condition', 0) - current_points
                print(f"   🎯 Next Milestone: {needed} points needed")
        
        # Example 2: Player Search System
        print("\n🔍 Player Search System:")
        test_aliases = ["d33d", "e44e", "f55f"]  # Test aliases
        
        for alias in test_aliases:
            try:
                player_info = client.search_player_by_alias(alias)
                if player_info.get('account'):
                    print(f"   ✅ Found player: {player_info.get('account', 'Unknown')}")
                else:
                    print(f"   ❌ Player not found: {alias}")
            except:
                print(f"   ⚠️  Could not search: {alias}")
        
        # Example 3: Configuration Monitor
        print("\n🔧 Configuration Monitor:")
        config = client.get_game_config("all")
        print(f"   🌐 Active Services: {len(config.get('service_urls', {}))}")
        print(f"   📦 Game Objects: {'Available' if config.get('game_objects') else 'Not Available'}")
        print(f"   📹 Asset Metadata: {config.get('asset_metadata', 'Not Available')}")
        
    except Exception as e:
        print(f"❌ Advanced usage error: {e}")
    
    # 6. Performance Tips
    print("\n💡 Performance Tips")
    print("-" * 40)
    print("🚀 Use context managers for automatic cleanup:")
    print("   with MC5Client(username, password) as client:")
    print("       # Your code here")
    print("       # Automatically closes connection")
    print()
    print("📊 Cache event data to avoid repeated API calls:")
    print("   events = client.get_events()  # Call once")
    print("   # Use cached events_data for operations")
    print()
    print("🔄 Use batch operations where possible:")
    print("   # Process multiple aliases in one loop")
    print("   # Calculate rewards for multiple events")
    print()
    print("⚡ Handle errors gracefully:")
    print("   try:")
    print("       result = client.get_events()")
    print("   except MC5APIError as e:")
    print("       print(f\"API Error: {e}\")")
    print("       # Fallback handling")
    
    # Clean up
    print("\n🧹 Cleaning up...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️  Error during cleanup: {e}")
    
    print("\n🎉 Advanced Features Demonstration Complete!")
    print("\n📚 What You Learned:")
    print("   📅 Events API - Daily tasks, squad events, milestones")
    print("   👤 Account Management - Import, link, migrate accounts")
    print("   🏷️ Alias System - Convert dogtags, search players")
    print("   ⚙️ Game Config - Assets, catalogs, service URLs")
    print("   🎯 Advanced Usage - Progress tracking, search, monitoring")
    print("   💡 Performance Tips - Best practices for efficient usage")
    
    print("\n🎮 Ready to build advanced MC5 applications!")

if __name__ == "__main__":
    main()
