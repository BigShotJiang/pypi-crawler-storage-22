#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : basic_usage.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Basic usage examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Basic usage examples for the MC5 API Client.
Demonstrates authentication, profile access, and basic operations.
"""

import os
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError, AuthenticationError


def main():
    """Demonstrate basic MC5 API client usage."""
    
    print("🎮 MC5 API Client - Basic Usage Example")
    print("=" * 50)
    
    # Get credentials from environment or use demo values
    username = os.getenv("MC5_USERNAME", "anonymous:d2luOF92M18xNzU4NjQxNTE3Xy9bF5EFTbvwR7w1nqg2JnI=")
    password = os.getenv("MC5_PASSWORD", "your_password_here")
    
    if password == "your_password_here":
        print("⚠️  Please set MC5_PASSWORD environment variable with your actual password")
        print("   Or modify the script to include your credentials")
        return
    
    try:
        # Initialize client with credentials
        print("🔐 Initializing client...")
        client = MC5Client(
            username=username,
            password=password,
            auto_refresh=True  # Automatically refresh expired tokens
        )
        
        print("✅ Authentication successful!")
        
        # Get token information
        token_info = client.get_token_info()
        print(f"📋 Token ID: {token_info['token_id']}")
        print(f"⏰ Expires in: {token_info['expires_in']:.0f} seconds")
        print(f"🎯 Scopes: {', '.join(token_info['scopes'][:3])}...")
        
        # Get player profile
        print("\n👤 Getting player profile...")
        profile = client.get_profile()
        
        if profile:
            print(f"📛 Player Name: {profile.get('name', 'Unknown')}")
            print(f"📊 Level: {profile.get('level', 'Unknown')}")
            print(f"🏆 XP: {profile.get('xp', 'Unknown')}")
            print(f"💰 Credits: {profile.get('credits', 'Unknown')}")
        
        # Get events
        print("\n📅 Getting active events...")
        events = client.get_events()
        print(f"🎯 Found {len(events)} active events")
        
        # Show first few events
        for i, event in enumerate(events[:3]):
            print(f"  {i+1}. {event.get('name', 'Unknown')} - {event.get('status', 'Unknown')}")
        
        # Get game object catalog
        print("\n🎮 Getting game object catalog...")
        catalog = client.get_game_object_catalog()
        print(f"📦 Found {len(catalog)} game objects")
        
        # Show some object categories
        categories = set()
        for obj in catalog[:20]:  # Check first 20 objects
            if 'category' in obj:
                categories.add(obj['category'])
        
        print(f"🏷️  Categories: {', '.join(list(categories)[:5])}...")
        
        # Example: Get alias information
        print("\n🏷️  Getting alias information...")
        try:
            alias_info = client.get_alias_info("d33d")
            print(f"🆔 Account: {alias_info.get('account', 'Unknown')}")
            print(f"👤 Type: {alias_info.get('type', 'Unknown')}")
        except MC5APIError as e:
            print(f"⚠️  Could not get alias info: {e}")
        
        print("\n✅ Example completed successfully!")
        
    except AuthenticationError as e:
        print(f"🔴 Authentication failed: {e}")
        print("   Please check your username and password")
        
    except MC5APIError as e:
        print(f"🔴 API error: {e}")
        if e.status_code:
            print(f"   Status code: {e.status_code}")
        
    except Exception as e:
        print(f"🔴 Unexpected error: {e}")
        
    finally:
        # Clean up
        if 'client' in locals():
            client.close()
            print("🧹 Client closed")


if __name__ == "__main__":
    main()
