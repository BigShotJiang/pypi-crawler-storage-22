#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : clan_management.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Clan management examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Clan management examples for the MC5 API Client.
Demonstrates clan operations, member management, and communication.
"""

import os
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError, AuthenticationError


def main():
    """Demonstrate clan management functionality."""
    
    print("🏰 MC5 API Client - Clan Management Example")
    print("=" * 50)
    
    # Get credentials from environment
    username = os.getenv("MC5_USERNAME")
    password = os.getenv("MC5_PASSWORD")
    
    if not username or not password:
        print("⚠️  Please set MC5_USERNAME and MC5_PASSWORD environment variables")
        return
    
    # Example clan ID (replace with actual clan ID)
    clan_id = "04db8e74-22c7-11f0-a77c-b8ca3a7095d0"
    
    try:
        # Initialize client
        print("🔐 Connecting to MC5 API...")
        client = MC5Client(username=username, password=password)
        
        # Get clan settings
        print(f"\n🏰 Getting clan settings for {clan_id}...")
        try:
            clan_settings = client.get_clan_settings(clan_id)
            
            print(f"📛 Clan Name: {clan_settings.get('name', 'Unknown')}")
            print(f"📝 Description: {clan_settings.get('description', 'No description')}")
            print(f"👥 Members: {clan_settings.get('member_count', 'Unknown')}")
            print(f"🏷️  Tag: {clan_settings.get('tag', 'Unknown')}")
            print(f"🔓 Membership: {clan_settings.get('membership_type', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"⚠️  Could not access clan settings: {e}")
            print("   This might require admin permissions or clan membership")
        
        # Send squad wall message
        print(f"\n💬 Sending message to squad wall...")
        try:
            result = client.send_squad_wall_message(
                clan_id=clan_id,
                message="Hello from MC5 API Client! 🎮"
            )
            print("✅ Message sent successfully!")
            
        except MC5APIError as e:
            print(f"⚠️  Could not send message: {e}")
            print("   This might require clan membership or appropriate permissions")
        
        # Example: Update clan settings (requires admin permissions)
        print(f"\n🔧 Attempting to update clan settings...")
        try:
            new_settings = {
                "description": "Updated via MC5 API Client - " + str(os.time.time())[-6:],
                "membership_type": "open"
            }
            
            updated_settings = client.update_clan_settings(clan_id, new_settings)
            print("✅ Clan settings updated successfully!")
            print(f"📝 New description: {updated_settings.get('description', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"⚠️  Could not update clan settings: {e}")
            print("   This requires clan admin permissions")
        
        # Get friends list
        print(f"\n👥 Getting friends list...")
        try:
            friends = client.get_friends()
            print(f"📊 Found {len(friends)} friends")
            
            # Show first few friends
            for i, friend in enumerate(friends[:3]):
                name = friend.get('name', 'Unknown')
                status = friend.get('status', 'Unknown')
                print(f"  {i+1}. {name} - {status}")
                
        except MC5APIError as e:
            print(f"⚠️  Could not get friends list: {e}")
        
        # Example: Send friend request
        print(f"\n🤝 Example: Sending friend request...")
        target_credential = "anonymous:example_credential"  # Replace with actual credential
        
        try:
            result = client.send_friend_request(target_credential)
            print("✅ Friend request sent!")
            
        except MC5APIError as e:
            print(f"⚠️  Could not send friend request: {e}")
            print("   Using example credential - replace with actual player credential")
        
        # Example: Check friend status
        print(f"\n🔍 Checking friend status...")
        try:
            status = client.check_friend_status(target_credential)
            print(f"📊 Status: {status.get('status', 'Unknown')}")
            print(f"📅 Since: {status.get('since', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"⚠️  Could not check friend status: {e}")
        
        print("\n✅ Clan management example completed!")
        
    except AuthenticationError as e:
        print(f"🔴 Authentication failed: {e}")
        
    except MC5APIError as e:
        print(f"🔴 API error: {e}")
        
    except Exception as e:
        print(f"🔴 Unexpected error: {e}")
        
    finally:
        if 'client' in locals():
            client.close()
            print("🧹 Client closed")


def demonstrate_admin_clan_management():
    """Demonstrate admin-level clan operations."""
    
    print("\n🔧 Admin Clan Management Example")
    print("=" * 40)
    
    # Use admin authentication
    try:
        client = MC5Client()
        client.authenticate_admin()
        
        print("🔑 Admin authentication successful!")
        
        # Get admin leaderboard
        print("\n🏆 Getting admin leaderboard...")
        leaderboard = client.get_leaderboard("admin")
        print(f"📊 Leaderboard type: {leaderboard.get('type', 'Unknown')}")
        print(f"👥 Players: {len(leaderboard.get('players', []))}")
        
        # Example: Kick member (use with caution!)
        clan_id = "04db8e74-22c7-11f0-a77c-b8ca3a7095d0"
        member_credential = "anonymous:member_to_kick"  # Replace with actual member
        
        print(f"\n⚠️  Example: Kicking clan member...")
        print("   This is a demonstration - actual kick is commented out")
        print("   Uncomment the code below to perform actual kick")
        
        # Uncomment to actually kick member:
        # try:
        #     result = client.kick_clan_member(clan_id, member_credential)
        #     print("✅ Member kicked successfully!")
        # except MC5APIError as e:
        #     print(f"⚠️  Could not kick member: {e}")
        
        client.close()
        
    except AuthenticationError as e:
        print(f"🔴 Admin authentication failed: {e}")


if __name__ == "__main__":
    main()
    
    # Uncomment to run admin examples
    # demonstrate_admin_clan_management()
