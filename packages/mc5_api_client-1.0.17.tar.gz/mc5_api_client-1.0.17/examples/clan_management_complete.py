#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : clan_management_complete.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Complete clan management examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Complete clan management examples for MC5 API Client.
This script demonstrates all the powerful clan management features.
"""

import sys
import time
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main clan management demonstration."""
    
    print("🏰 MC5 Clan Management System")
    print("=" * 50)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # Example 1: Search for clans
    print("\n🔍 Searching for clans...")
    try:
        clans = client.search_clans("Elite", limit=5)
        print(f"Found {len(clans)} clans matching 'Elite':")
        
        for i, clan in enumerate(clans, 1):
            print(f"  {i}. {clan.get('name', 'Unknown')} [{clan.get('tag', 'N/A')}]")
            print(f"     Members: {clan.get('member_count', 'Unknown')}")
            print(f"     Type: {clan.get('membership_type', 'Unknown')}")
            print(f"     Description: {clan.get('description', 'No description')[:50]}...")
            print()
            
    except MC5APIError as e:
        print(f"❌ Error searching clans: {e}")
    
    # Example 2: Create a new clan (if you want)
    print("🏗️ Creating a new clan...")
    try:
        new_clan = client.create_clan(
            name="Python Warriors",
            tag="PYW",
            description="A clan for Python developers who love MC5!",
            membership_type="open"
        )
        print(f"✅ Clan created successfully!")
        print(f"   Clan ID: {new_clan.get('id', 'Unknown')}")
        print(f"   Name: {new_clan.get('name', 'Unknown')}")
        clan_id = new_clan.get('id')
        
    except MC5APIError as e:
        print(f"⚠️ Could not create clan (might already exist): {e}")
        # Use a sample clan ID for demonstration
        clan_id = "sample-clan-id"
        print(f"📝 Using sample clan ID for demonstration: {clan_id}")
    
    # Example 3: Get clan information
    if clan_id:
        print(f"\n📋 Getting clan information for {clan_id}...")
        try:
            clan_info = client.get_clan_settings(clan_id)
            print(f"🏰 Clan: {clan_info.get('name', 'Unknown')}")
            print(f"📝 Description: {clan_info.get('description', 'No description')}")
            print(f"👥 Members: {clan_info.get('member_count', 'Unknown')}")
            print(f"🏷️ Tag: {clan_info.get('tag', 'N/A')}")
            print(f"🔓 Membership: {clan_info.get('membership_type', 'Unknown')}")
            print(f"👑 Leader: {clan_info.get('leader', {}).get('name', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"❌ Error getting clan info: {e}")
    
    # Example 4: Get clan members
    if clan_id:
        print(f"\n👥 Getting clan members...")
        try:
            members = client.get_clan_members(clan_id)
            print(f"Found {len(members)} members:")
            
            for i, member in enumerate(members[:5], 1):  # Show first 5
                print(f"  {i}. {member.get('name', 'Unknown')} [{member.get('role', 'Member')}]")
                print(f"     Level: {member.get('level', 'Unknown')}")
                print(f"     Joined: {member.get('joined_date', 'Unknown')}")
                print()
                
        except MC5APIError as e:
            print(f"❌ Error getting clan members: {e}")
    
    # Example 5: Invite a member
    if clan_id:
        print("📤 Inviting a member to the clan...")
        try:
            # Note: Replace with actual credential
            target_credential = "anonymous:sample_player_credential"
            invitation = client.invite_clan_member(clan_id, target_credential, role="member")
            print(f"✅ Invitation sent to {target_credential}")
            
        except MC5APIError as e:
            print(f"⚠️ Could not send invitation: {e}")
    
    # Example 6: Get clan applications
    if clan_id:
        print(f"\n📄 Getting clan applications...")
        try:
            applications = client.get_clan_applications(clan_id)
            print(f"Found {len(applications)} pending applications:")
            
            for i, app in enumerate(applications[:3], 1):  # Show first 3
                print(f"  {i}. {app.get('player_name', 'Unknown')} ({app.get('credential', 'Unknown')})")
                print(f"     Message: {app.get('message', 'No message')}")
                print(f"     Applied: {app.get('applied_date', 'Unknown')}")
                print()
                
        except MC5APIError as e:
            print(f"❌ Error getting applications: {e}")
    
    # Example 7: Get clan statistics
    if clan_id:
        print(f"\n📊 Getting clan statistics...")
        try:
            stats = client.get_clan_statistics(clan_id)
            print(f"🏆 Clan Statistics:")
            print(f"   Total Wins: {stats.get('total_wins', 'Unknown')}")
            print(f"   Total Losses: {stats.get('total_losses', 'Unknown')}")
            print(f"   Win Rate: {stats.get('win_rate', 'Unknown')}%")
            print(f"   Average Level: {stats.get('average_level', 'Unknown')}")
            print(f"   Total XP: {stats.get('total_xp', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"❌ Error getting clan statistics: {e}")
    
    # Example 8: Get clan leaderboard
    if clan_id:
        print(f"\n🏅 Getting clan leaderboard...")
        try:
            leaderboard = client.get_clan_leaderboard(clan_id)
            print(f"🏆 Top {len(leaderboard)} members:")
            
            for i, player in enumerate(leaderboard[:5], 1):  # Show top 5
                print(f"  {i}. {player.get('name', 'Unknown')} - {player.get('score', 'Unknown')} points")
                print(f"     K/D Ratio: {player.get('kd_ratio', 'Unknown')}")
                print(f"     Matches: {player.get('matches_played', 'Unknown')}")
                print()
                
        except MC5APIError as e:
            print(f"❌ Error getting clan leaderboard: {e}")
    
    # Example 9: Update clan settings
    if clan_id:
        print(f"\n⚙️ Updating clan settings...")
        try:
            updated_settings = client.update_clan_settings(clan_id, {
                "description": "Updated description - Best clan for Python developers! 🐍",
                "membership_type": "invite_only"
            })
            print("✅ Clan settings updated successfully!")
            print(f"   New description: {updated_settings.get('description', 'Unknown')}")
            print(f"   New membership type: {updated_settings.get('membership_type', 'Unknown')}")
            
        except MC5APIError as e:
            print(f"⚠️ Could not update clan settings: {e}")
    
    # Example 10: Apply to join a clan
    print("\n📝 Applying to join a clan...")
    try:
        # Note: Replace with actual clan ID
        target_clan_id = "target-clan-id"
        application = client.apply_to_clan(
            target_clan_id, 
            message="I'm a Python developer looking for an active clan!"
        )
        print(f"✅ Application sent to clan {target_clan_id}")
        
    except MC5APIError as e:
        print(f"⚠️ Could not apply to clan: {e}")
    
    # Example 11: Check your own applications
    print("\n📋 Checking your clan applications...")
    try:
        my_applications = client.get_my_clan_applications()
        print(f"You have {len(my_applications)} pending applications:")
        
        for i, app in enumerate(my_applications, 1):
            print(f"  {i}. {app.get('clan_name', 'Unknown')} ({app.get('clan_id', 'Unknown')})")
            print(f"     Status: {app.get('status', 'Unknown')}")
            print(f"     Applied: {app.get('applied_date', 'Unknown')}")
            print()
            
    except MC5APIError as e:
        print(f"❌ Error getting your applications: {e}")
    
    # Example 12: Clan member management (if you're a leader)
    if clan_id:
        print(f"\n👑 Demonstrating member management...")
        try:
            # Note: These would require actual member credentials
            member_credential = "anonymous:sample_member"
            
            # Promote a member
            print("📈 Promoting member to officer...")
            promotion = client.promote_clan_member(clan_id, member_credential, "officer")
            print(f"✅ Member promoted to officer")
            
            # Demote back to member
            print("📉 Demoting member back to regular member...")
            demotion = client.demote_clan_member(clan_id, member_credential, "member")
            print(f"✅ Member demoted back to member")
            
        except MC5APIError as e:
            print(f"⚠️ Member management requires proper permissions: {e}")
    
    # Example 13: Clan ownership transfer
    if clan_id:
        print(f"\n🔄 Demonstrating ownership transfer...")
        try:
            # Note: This requires actual member credential
            new_leader = "anonymous:future_leader"
            transfer = client.transfer_clan_ownership(clan_id, new_leader)
            print(f"✅ Clan ownership transferred to {new_leader}")
            
        except MC5APIError as e:
            print(f"⚠️ Ownership transfer requires leader permissions: {e}")
    
    # Clean up
    print("\n🧹 Cleaning up...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️ Error closing connection: {e}")
    
    print("\n🎉 Clan management demonstration complete!")
    print("\n📚 What you learned:")
    print("   🔍 Search for clans")
    print("   🏗️ Create new clans")
    print("   📋 Get clan information")
    print("   👥 Manage clan members")
    print("   📤 Send invitations")
    print("   📄 Handle applications")
    print("   📊 View statistics")
    print("   🏅 Check leaderboards")
    print("   ⚙️ Update settings")
    print("   📝 Apply to clans")
    print("   👑 Member management")
    print("   🔄 Transfer ownership")

if __name__ == "__main__":
    main()
