#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : events_and_tasks.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Events and tasks examples for MC5 API Client
# ────────────────★─────────────────────────────────

"""
Events and tasks examples for the MC5 API Client.
Demonstrates accessing daily tasks, events, milestones, and rewards.
"""

import os
import json
from datetime import datetime
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError, AuthenticationError


def print_event_summary(event):
    """Print a summary of an event."""
    name = event.get('name', 'Unknown')
    status = event.get('status', 'Unknown')
    category = event.get('category', 'Unknown')
    description = event.get('description', 'No description')
    
    print(f"📅 Event: {name}")
    print(f"   Status: {status}")
    print(f"   Category: {category}")
    print(f"   Description: {description}")
    
    # Parse dates if available
    start_date = event.get('start_date')
    end_date = event.get('end_date')
    
    if start_date:
        try:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            print(f"   Starts: {start_dt.strftime('%Y-%m-%d %H:%M:%S')}")
        except:
            print(f"   Starts: {start_date}")
    
    if end_date:
        try:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            print(f"   Ends: {end_dt.strftime('%Y-%m-%d %H:%M:%S')}")
        except:
            print(f"   Ends: {end_date}")


def print_event_tasks(event):
    """Print tasks and milestones from an event template."""
    template = event.get('_template')
    if not template:
        return
    
    tuning = template.get('event_tuning', {})
    tasks = tuning.get('_tasks', {}).get('value', [])
    milestones = tuning.get('milestones', {}).get('value', [])
    
    print(f"\n   📋 Tasks ({len(tasks)}):")
    for i, task in enumerate(tasks[:5]):  # Show first 5 tasks
        points = task.get('points', 0)
        milestone_id = task.get('_milestone_id', 'Unknown')[:8] + '...'
        
        # Parse condition
        condition = task.get('condition', {}).get('value', {})
        if condition:
            # Try to extract the main condition
            for key, value in condition.items():
                if isinstance(value, dict) and 'value' in value:
                    condition_type = value.get('id', key)
                    condition_value = value.get('value', 'Unknown')
                    print(f"     {i+1}. {condition_type} - {condition_value} pts ({points})")
                    break
        else:
            print(f"     {i+1}. Task {milestone_id} - {points} pts")
    
    if len(tasks) > 5:
        print(f"     ... and {len(tasks) - 5} more tasks")
    
    print(f"\n   🏆 Milestones ({len(milestones)}):")
    for i, milestone in enumerate(milestones[:3]):  # Show first 3 milestones
        condition = milestone.get('condition', 0)
        milestone_id = milestone.get('_milestone_id', 'Unknown')[:8] + '...'
        
        # Parse award
        award = milestone.get('award', {}).get('value', [])
        rewards = []
        
        for award_item in award:
            if isinstance(award_item, dict):
                for reward_key, reward_value in award_item.items():
                    if isinstance(reward_value, dict) and 'value' in reward_value:
                        reward_name = reward_value.get('id', reward_key)
                        reward_amount = reward_value.get('value', 0)
                        rewards.append(f"{reward_amount} {reward_name}")
        
        reward_str = ", ".join(rewards) if rewards else "No rewards"
        print(f"     {i+1}. {condition} points - {reward_str}")
    
    if len(milestones) > 3:
        print(f"     ... and {len(milestones) - 3} more milestones")


def main():
    """Demonstrate events and tasks functionality."""
    
    print("📅 MC5 API Client - Events and Tasks Example")
    print("=" * 50)
    
    # Get credentials from environment
    username = os.getenv("MC5_USERNAME")
    password = os.getenv("MC5_PASSWORD")
    
    if not username or not password:
        print("⚠️  Please set MC5_USERNAME and MC5_PASSWORD environment variables")
        return
    
    try:
        # Initialize client
        print("🔐 Connecting to MC5 API...")
        client = MC5Client(username=username, password=password)
        
        # Get all events
        print("\n📅 Getting all events...")
        events = client.get_events()
        print(f"🎯 Found {len(events)} events")
        
        # Separate events by status
        active_events = [e for e in events if e.get('status') == 'active']
        ended_events = [e for e in events if e.get('status') == 'ended']
        upcoming_events = [e for e in events if e.get('status') == 'upcoming']
        
        print(f"🟢 Active events: {len(active_events)}")
        print(f"🔴 Ended events: {len(ended_events)}")
        print(f"🔵 Upcoming events: {len(upcoming_events)}")
        
        # Show active events in detail
        if active_events:
            print(f"\n🟢 Active Events:")
            print("-" * 30)
            
            for event in active_events:
                print_event_summary(event)
                print_event_tasks(event)
                print()
        
        # Look for daily tasks specifically
        print("🎯 Looking for Daily Tasks event...")
        daily_tasks = None
        for event in events:
            if 'daily' in event.get('name', '').lower() or 'activities' in event.get('name', '').lower():
                daily_tasks = event
                break
        
        if daily_tasks:
            print(f"\n📋 Daily Tasks Found:")
            print("-" * 25)
            print_event_summary(daily_tasks)
            print_event_tasks(daily_tasks)
        else:
            print("⚠️  No daily tasks event found")
        
        # Show squad events
        squad_events = [e for e in events if 'squad' in e.get('name', '').lower()]
        if squad_events:
            print(f"\n👥 Squad Events ({len(squad_events)}):")
            print("-" * 30)
            
            for event in squad_events[:2]:  # Show first 2 squad events
                print_event_summary(event)
                
                # Show tournament info if available
                tournament = event.get('tournament', {})
                if tournament:
                    leaderboard = tournament.get('leaderboard', {})
                    print(f"   🏆 Leaderboard: {leaderboard.get('name', 'Unknown')}")
                    print(f"   📊 Order: {leaderboard.get('order', 'Unknown')}")
                
                print()
        
        # Get specific event details
        if events:
            first_event_name = events[0].get('name')
            if first_event_name:
                print(f"🔍 Getting details for event: {first_event_name}")
                try:
                    event_details = client.get_event_details(first_event_name)
                    print(f"✅ Retrieved details for {event_details.get('name', 'Unknown')}")
                except MC5APIError as e:
                    print(f"⚠️  Could not get event details: {e}")
        
        # Save events data to file for analysis
        print(f"\n💾 Saving events data to events.json...")
        try:
            with open('events.json', 'w') as f:
                json.dump(events, f, indent=2, default=str)
            print("✅ Events data saved!")
        except Exception as e:
            print(f"⚠️  Could not save events data: {e}")
        
        print("\n✅ Events and tasks example completed!")
        
    except AuthenticationError as e:
        print(f"🔴 Authentication failed: {e}")
        
    except MC5APIError as e:
        print(f"🔴 API error: {e}")
        
    except Exception as e:
        print(f"🔴 Unexpected error: {e}")
        
    finally:
        if 'client' in locals():
            client.close()
            print("🧹 Client closed")


def analyze_event_rewards():
    """Analyze rewards from all events."""
    
    print("\n🎁 Event Rewards Analysis")
    print("=" * 30)
    
    username = os.getenv("MC5_USERNAME")
    password = os.getenv("MC5_PASSWORD")
    
    if not username or not password:
        print("⚠️  Please set MC5_USERNAME and MC5_PASSWORD environment variables")
        return
    
    try:
        client = MC5Client(username=username, password=password)
        events = client.get_events()
        
        # Collect all rewards
        all_rewards = {}
        
        for event in events:
            template = event.get('_template')
            if not template:
                continue
            
            tuning = template.get('event_tuning', {})
            
            # Task rewards
            tasks = tuning.get('_tasks', {}).get('value', [])
            for task in tasks:
                award = task.get('award', {}).get('value', [])
                for award_item in award:
                    if isinstance(award_item, dict):
                        for reward_key, reward_value in award_item.items():
                            if isinstance(reward_value, dict) and 'value' in reward_value:
                                reward_name = reward_value.get('id', reward_key)
                                reward_amount = reward_value.get('value', 0)
                                
                                if reward_name not in all_rewards:
                                    all_rewards[reward_name] = 0
                                all_rewards[reward_name] += reward_amount
            
            # Milestone rewards
            milestones = tuning.get('milestones', {}).get('value', [])
            for milestone in milestones:
                award = milestone.get('award', {}).get('value', [])
                for award_item in award:
                    if isinstance(award_item, dict):
                        for reward_key, reward_value in award_item.items():
                            if isinstance(reward_value, dict) and 'value' in reward_value:
                                reward_name = reward_value.get('id', reward_key)
                                reward_amount = reward_value.get('value', 0)
                                
                                if reward_name not in all_rewards:
                                    all_rewards[reward_name] = 0
                                all_rewards[reward_name] += reward_amount
        
        # Display rewards summary
        print("🎁 Total Rewards Across All Events:")
        for reward_name, total_amount in sorted(all_rewards.items()):
            print(f"   {reward_name}: {total_amount}")
        
        client.close()
        
    except Exception as e:
        print(f"🔴 Error analyzing rewards: {e}")


if __name__ == "__main__":
    main()
    
    # Uncomment to analyze rewards
    # analyze_event_rewards()
