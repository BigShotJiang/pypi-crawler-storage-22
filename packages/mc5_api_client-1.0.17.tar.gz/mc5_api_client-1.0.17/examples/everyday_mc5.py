#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : everyday_mc5.py
# | License  | MIT License © 2026 Chizoba
# | Brief    | Everyday MC5 tasks made simple
# ────────────────★─────────────────────────────────

"""
Everyday MC5 Tasks Made Simple
============================

This script shows the most common MC5 tasks that players actually use every day.
No complex setup, no confusing API calls - just simple functions that work.

What you can do:
- Check your daily tasks and rewards
- Search for players by dogtag
- Manage your clan members
- Send messages to friends
- Check your stats and profile
"""

from mc5_api_client import SimpleMC5Client

def main():
    """Main function for everyday MC5 tasks."""
    print("🎮 MC5 Everyday Tasks")
    print("=" * 30)
    
    # Your MC5 credentials
    # Your MC5 credentials
    username = "anonymous:d2luOF92M18xNzcwMDUxNjkwXy7H33aeTVB4YZictyDq48c="  # Real MC5 username
    password = "sSJKzhQ5l4vrFgov"  # Real MC5 password
    
    # Connect to MC5
    client = SimpleMC5Client(username, password)
    
    if not client.connect():
        print("❌ Failed to connect to MC5")
        return
    
    print("✅ Connected to MC5 successfully!")
    print()
    
    # === EVERYDAY TASKS ===
    
    # 1. Check your daily tasks
    print("📅 Checking your daily tasks...")
    try:
        # Get events (includes daily tasks)
        events = client.client.get_events()
        daily_tasks = [e for e in events if 'daily' in e.get('name', '').lower() or 'activities' in e.get('name', '').lower()]
        
        if daily_tasks:
            print(f"✅ Found {len(daily_tasks)} daily task(s)")
            for task in daily_tasks:
                print(f"   📋 {task.get('name', 'Unknown Task')} - Status: {task.get('status', 'Unknown')}")
        else:
            print("ℹ️ No daily tasks found right now")
    except Exception as e:
        print(f"❌ Error checking daily tasks: {e}")
    
    print()
    
    # 2. Check your profile stats
    print("👤 Checking your profile...")
    try:
        profile = client.client.get_profile()
        print(f"✅ Name: {profile.get('name', 'Unknown')}")
        
        # Try different field names for level
        level = profile.get('level') or profile.get('_level') or profile.get('player_level') or 'Unknown'
        print(f"🎯 Level: {level}")
        
        # Try different field names for XP
        xp = profile.get('xp') or profile.get('_xp') or profile.get('experience') or 0
        if xp > 0:
            print(f"⭐ XP: {xp:,}")
        else:
            print(f"⭐ XP: {xp}")
        
        # Try different field names for score
        score = profile.get('score') or profile.get('_score') or profile.get('player_score') or 0
        if score > 0:
            print(f"💰 Score: {score:,}")
        else:
            print(f"💰 Score: {score}")
        
        # Check clan if you have one
        groups = profile.get('groups', [])
        if groups:
            clan_id = groups[0]
            print(f"🏰 Clan ID: {clan_id}")
        else:
            print("ℹ️ No clan found")
    except Exception as e:
        print(f"❌ Error checking profile: {e}")
    
    print()
    
    # 3. Search for a player
    print("🔍 Searching for players...")
    dogtag = input("Enter player dogtag (4-8 characters, e.g., f55f): ").strip()
    if dogtag:
        try:
            player = client.search_player(dogtag)
            if player and 'kills' in player:
                print(f"✅ Found player: {dogtag}")
                print(f"🎯 Kills: {player['kills']:,}")
                
                # Try different field names for level
                level = player.get('level') or player.get('_level') or player.get('player_level') or 'Unknown'
                print(f"⭐ Level: {level}")
                
                # Try different field names for score
                score = player.get('score') or player.get('_score') or player.get('player_score') or 0
                if score > 0:
                    print(f"💰 Score: {score:,}")
                else:
                    print(f"💰 Score: {score}")
                
                # Add new fields
                print(f"📊 Wins: {player.get('wins', 0)}")
                print(f"📊 Losses: {player.get('losses', 0)}")
                print(f"📊 Draws: {player.get('draws', 0)}")
            else:
                print(f"❌ Player {dogtag} not found")
        except Exception as e:
            print(f"❌ Error searching for player: {e}")
    
    print()
    
    # 4. Check clan members (if in a clan)
    if hasattr(client, '_clan_id') and client._clan_id:
        print("👥 Checking clan members...")
        try:
            members = client.get_clan_members()
            print(f"✅ Your clan has {len(members)} members")
            
            # Show online members
            online_count = len([m for m in members if m.get('online', False)])
            print(f"🟢 {online_count} members online right now")
            
            # Show top 5 members by score
            sorted_members = sorted(members, key=lambda x: int(x.get('_score', 0) or x.get('score', 0) or 0), reverse=True)[:5]
            print("🏆 Top 5 members by score:")
            for i, member in enumerate(sorted_members, 1):
                name = member.get('name', 'Unknown')
                score = int(member.get('_score') or member.get('score') or 0)
                if score > 0:
                    print(f"   {i}. {name}: {score:,}")
                else:
                    print(f"   {i}. {name}: {score}")
                
        except Exception as e:
            print(f"❌ Error checking clan members: {e}")
    else:
        print("ℹ️ Not in a clan - skipping member check")
    
    print()
    
    # 5. Send a message (optional)
    send_message = input("Send a message to a friend? (y/n): ").strip().lower()
    
    if send_message == 'y':
        friend_dogtag = input("Enter friend's dogtag: ").strip()
        message = input("Enter your message: ").strip()
        
        if friend_dogtag and message:
            try:
                result = client.send_message(friend_dogtag, message)
                if result:
                    print(f"✅ Message sent to {friend_dogtag}")
                else:
                    print("❌ Failed to send message")
            except Exception as e:
                print(f"❌ Error sending message: {e}")
    
    print()
    print("🎉 All everyday tasks completed!")
    print("💡 Tip: Run this script daily to check your tasks and stay updated!")

if __name__ == "__main__":
    main()
