#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : help_system.py
# | License  | MIT License © 2026 Chizoba
# | Brief    : Comprehensive help system for MC5 API Client
# ────────────────★─────────────────────────────────

"""
MC5 API Client - Comprehensive Help System

This module provides extensive help commands and documentation
for users at all levels - from beginners to advanced users.
"""

from mc5_api_client import SimpleMC5Client, MC5Client
from typing import Dict, List, Any

class MC5Helper:
    """Comprehensive help system for MC5 API Client."""
    
    def __init__(self):
        self.help_topics = {
            'basic': {
                'title': '🎮 Basic Usage',
                'description': 'Get started with MC5 API Client',
                'commands': [
                    'quick_search - Search player by dogtag',
                    'quick_kick - Kick member by dogtag', 
                    'SimpleMC5Client - User-friendly interface',
                    'connect() - Connect to MC5',
                    'search_player() - Find player stats'
                ]
            },
            'clan': {
                'title': '🏰 Clan Management',
                'description': 'Manage your clan effectively',
                'commands': [
                    'get_clan_members() - List all members',
                    'kick_member() - Remove member',
                    'update_clan_settings() - Change clan info',
                    'clan_cleanup() - Smart cleanup',
                    'get_inactive_members() - Find inactive players'
                ]
            },
            'advanced': {
                'title': '🤖 Advanced Features',
                'description': 'Automation and advanced operations',
                'commands': [
                    'batch_search_players() - Search multiple players',
                    'monitor_clan_activity() - Real-time monitoring',
                    'auto_kick_inactive_members() - Automated cleanup',
                    'Conditional logic - Smart decision making',
                    'Loop operations - Batch processing'
                ]
            },
            'examples': {
                'title': '📚 Examples',
                'description': 'Real-world usage examples',
                'commands': [
                    'basic_usage.py - Core functionality',
                    'simple_usage.py - User-friendly examples',
                    'advanced_automation.py - Automation examples',
                    'clan_management.py - Clan operations',
                    'player_stats.py - Statistics examples'
                ]
            },
            'troubleshooting': {
                'title': '🔧 Troubleshooting',
                'description': 'Common issues and solutions',
                'commands': [
                    '401 Error - Check credentials',
                    '404 Error - Player not found',
                    'Connection issues - Network problems',
                    'Token expiry - Re-authenticate',
                    'Permission denied - Check clan role'
                ]
            }
        }
    
    def show_help(self, topic: str = None) -> None:
        """
        Display help information.
        
        Args:
            topic: Specific help topic or None for overview
        """
        if topic is None:
            self.show_overview()
        elif topic.lower() in self.help_topics:
            self.show_topic(topic.lower())
        else:
            print(f"❌ Unknown topic: {topic}")
            print(f"📋 Available topics: {', '.join(self.help_topics.keys())}")
            self.show_overview()
    
    def show_overview(self) -> None:
        """Show help overview."""
        print("🎮 MC5 API Client - Help System")
        print("=" * 50)
        print("📚 Available Help Topics:")
        print()
        
        for topic_id, topic_data in self.help_topics.items():
            print(f"🔸 {topic_id}: {topic_data['title']}")
            print(f"   {topic_data['description']}")
            print()
        
        print("💡 Usage: help('topic_name') for specific help")
        print("💡 Examples: help('basic'), help('clan'), help('advanced')")
    
    def show_topic(self, topic: str) -> None:
        """Show specific help topic."""
        if topic not in self.help_topics:
            print(f"❌ Topic '{topic}' not found")
            return
        
        topic_data = self.help_topics[topic]
        
        print(f"{topic_data['title']}")
        print("=" * len(topic_data['title']))
        print(f"📝 {topic_data['description']}")
        print()
        
        print("🔧 Available Commands:")
        for i, command in enumerate(topic_data['commands'], 1):
            print(f"   {i}. {command}")
        
        # Add specific examples for each topic
        if topic == 'basic':
            self.show_basic_examples()
        elif topic == 'clan':
            self.show_clan_examples()
        elif topic == 'advanced':
            self.show_advanced_examples()
        elif topic == 'troubleshooting':
            self.show_troubleshooting_examples()
    
    def show_basic_examples(self) -> None:
        """Show basic usage examples."""
        print("\n💡 Basic Examples:")
        print("```python")
        print("# Quick player search")
        print("from mc5_api_client import quick_search")
        print("player = quick_search('f55f', 'username', 'password')")
        print("print(f'Kills: {player[\"kills\"]:,}')")
        print()
        print("# Simple client usage")
        print("client = SimpleMC5Client('username', 'password')")
        print("client.connect()")
        print("player = client.search_player('218f')")
        print("```")
    
    def show_clan_examples(self) -> None:
        """Show clan management examples."""
        print("\n💡 Clan Management Examples:")
        print("```python")
        print("# Get clan members")
        print("with SimpleMC5Client('username', 'password') as client:")
        print("    client.connect()")
        print("    members = client.get_clan_members()")
        print("    print(f'Clan has {len(members)} members')")
        print()
        print("# Smart clan cleanup")
        print("from mc5_api_client.simple_client import clan_cleanup")
        print("results = clan_cleanup('username', 'password', dry_run=True)")
        print("print(f'Would kick: {results[\"would_kick\"]} members')")
        print("```")
    
    def show_advanced_examples(self) -> None:
        """Show advanced automation examples."""
        print("\n💡 Advanced Automation Examples:")
        print("```python")
        print("# Batch search with conditional logic")
        print("from mc5_api_client.simple_client import batch_search_players")
        print("dogtags = ['f55f', '9gg9', '218f']")
        print("results = batch_search_players(dogtags, 'username', 'password')")
        print()
        print("for player in results['found']:")
        print("    if player['kills'] > 10000:")
        print("        print(f'🌟 Elite: {player[\"dogtag\"]}')")
        print("    else:")
        print("        print(f'👤 Regular: {player[\"dogtag\"]}')")
        print()
        print("# Real-time monitoring")
        print("from mc5_api_client.simple_client import monitor_clan_activity")
        print("monitor_clan_activity('username', 'password', check_interval=60)")
        print("```")
    
    def show_troubleshooting_examples(self) -> None:
        """Show troubleshooting examples."""
        print("\n💡 Troubleshooting Examples:")
        print("```python")
        print("# Handle 401 Authentication Error")
        print("try:")
        print("    client = SimpleMC5Client('username', 'password')")
        print("    client.connect()")
        print("except AuthenticationError:")
        print("    print('❌ Check your username and password')")
        print()
        print("# Handle 404 Player Not Found")
        print("player = client.search_player('invalid_dogtag')")
        print("if not player:")
        print("    print('❌ Player not found - check dogtag')")
        print()
        print("# Safe operations with error handling")
        print("try:")
        print("    client.kick_member('9gg9', 'Inactive')")")
        print("except Exception as e:")
        print("    print(f'❌ Error: {e}')")
        print("```")
    
    def show_quick_reference(self) -> None:
        """Show quick reference card."""
        print("🎯 MC5 API Client - Quick Reference")
        print("=" * 45)
        print()
        print("🔹 Simple Usage:")
        print("   quick_search(dogtag, user, pass)")
        print("   quick_kick(dogtag, user, pass, reason)")
        print()
        print("🔹 Client Methods:")
        print("   client.connect()")
        print("   client.search_player(dogtag)")
        print("   client.get_clan_members()")
        print("   client.kick_member(dogtag, reason)")
        print()
        print("🔹 Advanced Functions:")
        print("   batch_search_players(dogtags, user, pass)")
        print("   clan_cleanup(user, pass, dry_run=True)")
        print("   monitor_clan_activity(user, pass)")
        print()
        print("🔹 Error Handling:")
        print("   try: except AuthenticationError:")
        print("   try: except MC5APIError:")
        print()
        print("💡 For detailed help: help('topic_name')")


# Global help function for easy access
def help(topic: str = None) -> None:
    """
    Global help function for MC5 API Client.
    
    Args:
        topic: Help topic (basic, clan, advanced, examples, troubleshooting)
    """
    helper = MC5Helper()
    helper.show_help(topic)


def show_examples() -> None:
    """Show available example files."""
    examples = [
        ('basic_usage.py', 'Core functionality and basic operations'),
        ('simple_usage.py', 'User-friendly interface examples'),
        ('advanced_automation.py', 'Loops, conditionals, and automation'),
        ('clan_management.py', 'Complete clan management examples'),
        ('player_stats.py', 'Player statistics and dogtag search'),
        ('private_messaging.py', 'Direct messaging features'),
        ('squad_management.py', 'Squad and group management'),
        ('message_management.py', 'Communication features'),
        ('events_and_tasks.py', 'Daily tasks and events'),
        ('squad_wall_management.py', 'Wall post management'),
        ('advanced_features.py', 'Advanced capabilities'),
        ('clan_management_complete.py', 'Comprehensive clan operations')
    ]
    
    print("📚 Available Example Files:")
    print("=" * 30)
    
    for filename, description in examples:
        print(f"🔸 {filename}")
        print(f"   {description}")
        print()
    
    print("💡 Run examples with: python examples/filename.py")


def show_cheat_sheet() -> None:
    """Show comprehensive cheat sheet."""
    print("🎮 MC5 API Client - Cheat Sheet")
    print("=" * 40)
    print()
    
    print("🚀 QUICK START:")
    print("   pip install mc5_api_client")
    print()
    print("🔹 ONE-LINERS:")
    print("   quick_search('f55f', 'user', 'pass')")
    print("   quick_kick('9gg9', 'user', 'pass', 'reason')")
    print()
    print("🔹 SIMPLE CLIENT:")
    print("   client = SimpleMC5Client('user', 'pass')")
    print("   client.connect()")
    print("   player = client.search_player('f55f')")
    print()
    print("🔹 CLAN MANAGEMENT:")
    print("   members = client.get_clan_members()")
    print("   client.kick_member('9gg9', 'inactive')")
    print("   client.update_clan_settings(name='New Name')")
    print()
    print("🔹 ADVANCED:")
    print("   batch_search_players(['f55f','9gg9'], 'user', 'pass')")
    print("   clan_cleanup('user', 'pass', dry_run=True)")
    print("   monitor_clan_activity('user', 'pass')")
    print()
    print("🔹 ERROR HANDLING:")
    print("   try: except AuthenticationError:")
    print("   try: except MC5APIError:")
    print()
    print("💡 For more help: help('topic_name')")


def main():
    """Demonstrate help system."""
    print("🎮 MC5 API Client - Help System Demo")
    print("=" * 45)
    print()
    
    # Show overview
    help()
    
    print("\n" + "="*60)
    print("📋 Available Help Commands:")
    print("   help('basic')        - Basic usage")
    print("   help('clan')         - Clan management")
    print("   help('advanced')     - Advanced features")
    print("   help('examples')     - Example files")
    print("   help('troubleshooting') - Common issues")
    print("   show_examples()      - List example files")
    print("   show_cheat_sheet()   - Quick reference")
    print()
    print("💡 Try: help('basic') to see basic usage examples")


if __name__ == "__main__":
    main()
