#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : message_management.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Complete message management examples
# ────────────────★─────────────────────────────────

"""
Complete message management examples for MC5 API Client.
This script demonstrates advanced message operations including bulk deletion.
"""

import sys
import time
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main message management demonstration."""
    
    print("💬 MC5 Message Management System")
    print("=" * 50)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # Example 1: Send test messages for deletion demo
    print(f"\n📧 Sending test messages...")
    test_message_ids = []
    
    try:
        test_messages = [
            "Test message 1 for deletion demo 🗑️",
            "Test message 2 for bulk deletion 🗑️", 
            "Test message 3 for inbox management 🗑️",
            "Test message 4 for cleanup demo 🗑️",
            "Test message 5 for batch operations 🗑️"
        ]
        
        for i, message in enumerate(test_messages):
            try:
                result = client.send_private_message(
                    credential="anonymous:d2luOF92M18xNzA2NzI4MDAwX5YFN58RRn2gkCTJnVIozuw%3D",
                    message=message,
                    kill_sign_color="-974646126",
                    kill_sign_name="default_killsig_80"
                )
                message_id = result.get("id", f"test_msg_{i}")
                test_message_ids.append(message_id)
                print(f"✅ Sent test message {i+1}: {message_id}")
                time.sleep(0.5)  # Small delay between messages
                
            except MC5APIError as e:
                print(f"⚠️ Could not send test message {i+1}: {e}")
        
        print(f"✅ Sent {len(test_message_ids)} test messages for deletion demo")
        
    except Exception as e:
        print(f"❌ Error sending test messages: {e}")
    
    # Example 2: Delete single message
    print(f"\n🗑️ Deleting single message...")
    try:
        if test_message_ids:
            message_id = test_message_ids[0]
            print(f"Deleting message: {message_id}")
            
            result = client.delete_inbox_message(message_id)
            print(f"✅ Single message deleted successfully!")
            print(f"   Message ID: {message_id}")
            print(f"   Status: {result.get('status', 'Unknown')}")
        else:
            print("No test messages available for single deletion")
            
    except MC5APIError as e:
        print(f"❌ Single message deletion error: {e}")
    
    # Example 3: Delete multiple messages (bulk deletion)
    print(f"\n🗑️ Deleting multiple messages (bulk deletion)...")
    try:
        if len(test_message_ids) >= 2:
            # Delete messages 2 and 3
            bulk_ids = test_message_ids[1:3]
            print(f"Deleting {len(bulk_ids)} messages: {bulk_ids}")
            
            result = client.delete_multiple_inbox_messages(bulk_ids)
            print(f"✅ Bulk deletion successful!")
            print(f"   Deleted {len(bulk_ids)} messages")
            print(f"   Message IDs: {bulk_ids}")
            print(f"   Status: {result.get('status', 'Unknown')}")
        else:
            print("Not enough test messages for bulk deletion")
            
    except MC5APIError as e:
        print(f"❌ Bulk deletion error: {e}")
    
    # Example 4: Message cleanup utility
    print(f"\n🧹 Message cleanup utility...")
    try:
        # Simulate cleanup of old messages
        remaining_messages = test_message_ids[3:] if len(test_message_ids) > 3 else []
        
        if remaining_messages:
            print(f"Cleaning up {len(remaining_messages)} remaining test messages...")
            
            for msg_id in remaining_messages:
                try:
                    result = client.delete_inbox_message(msg_id)
                    print(f"✅ Cleaned up message: {msg_id}")
                    time.sleep(0.2)  # Small delay between deletions
                    
                except MC5APIError as e:
                    print(f"⚠️ Could not delete {msg_id}: {e}")
            
            print(f"✅ Message cleanup completed!")
        else:
            print("No remaining messages to clean up")
            
    except Exception as e:
        print(f"❌ Cleanup error: {e}")
    
    # Example 5: Safe inbox management
    print(f"\n🛡️ Safe inbox management...")
    try:
        # This would clear the entire inbox - commented out for safety
        print("⚠️ Full inbox clear available but commented for safety:")
        print("   # client.clear_inbox()  # Uncomment with caution!")
        print("   # This would delete ALL messages in your inbox")
        
        # Instead, show how to delete specific message types
        print("✅ Safe deletion strategies:")
        print("   • Delete messages older than specific date")
        print("   • Delete messages from specific senders")
        print("   • Delete messages containing specific keywords")
        print("   • Delete test/demo messages only")
        
    except Exception as e:
        print(f"❌ Safe management error: {e}")
    
    # Example 6: Message statistics and reporting
    print(f"\n📊 Message management report...")
    try:
        print("📈 Message Operations Summary:")
        print(f"   📧 Test messages sent: {len(test_message_ids)}")
        print(f"   🗑️ Single deletions: 1")
        print(f"   🗑️ Bulk deletions: {len(test_message_ids[1:3]) if len(test_message_ids) >= 3 else 0}")
        print(f"   🧹 Cleanup operations: {len(test_message_ids[3:]) if len(test_message_ids) > 3 else 0}")
        print(f"   📊 Total operations: {len(test_message_ids) + 2}")
        
        print("\n🎯 Message Management Features:")
        print("   ✅ Single message deletion")
        print("   ✅ Bulk message deletion")
        print("   ✅ Inbox clearing")
        print("   ✅ Safe cleanup strategies")
        print("   ✅ Message tracking")
        print("   ✅ Batch operations")
        
    except Exception as e:
        print(f"❌ Report generation error: {e}")
    
    # Example 7: Automated message management bot
    print(f"\n🤖 Automated message management bot...")
    try:
        print("🔧 Bot Features Available:")
        print("   🕐 Scheduled message cleanup")
        print("   🎯 Keyword-based filtering")
        print("   📅 Date-based deletion")
        print("   👤 Sender-based management")
        print("   📊 Automated reporting")
        print("   🔄 Continuous monitoring")
        
        print("\n📝 Example Bot Logic:")
        print("   while True:")
        print("       messages = get_inbox_messages(limit=50)")
        print("       old_messages = filter_old_messages(messages, days=7)")
        print("       if old_messages:")
        print("           delete_multiple_inbox_messages(old_messages)")
        print("           log_deletion(old_messages)")
        print("       time.sleep(3600)  # Check every hour")
        
    except Exception as e:
        print(f"❌ Bot setup error: {e}")
    
    # Clean up
    print("\n🧹 Final cleanup...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️ Error closing connection: {e}")
    
    print("\n🎉 Message management demonstration complete!")
    print("\n📚 What you learned:")
    print("   📧 Send test messages")
    print("   🗑️ Delete single messages")
    print("   🗑️ Delete multiple messages (bulk)")
    print("   🧹 Safe cleanup strategies")
    print("   📊 Message management reporting")
    print("   🤖 Automated bot setup")
    print("   🛡️ Safe inbox management")
    
    print("\n🎮 Use Cases:")
    print("   📱 Inbox maintenance")
    print("   🧹 Automated cleanup")
    print("   📊 Message analytics")
    print("   🤖 Bot development")
    print("   🛡️ Privacy management")
    print("   📈 Storage optimization")

if __name__ == "__main__":
    main()
