#!/usr/bin/env python3
# ────────────[ CHIZOBA ]────────────────────────────
# | Email    : chizoba2026@hotmail.com
# | File     : player_stats.py
# | License  : MIT License © 2026 Chizoba
# | Brief    : Player statistics and batch profile demonstration
# ────────────────★─────────────────────────────────

"""
Player Statistics and Batch Profile Demonstration
This script showcases the new batch profile functionality:
- Get detailed player statistics using dogtags
- Search players by their in-game ID
- Parse and analyze player data
- Batch operations for multiple players
"""

import time
from mc5_api_client import MC5Client
from mc5_api_client.exceptions import MC5APIError

def main():
    """Main player statistics demonstration."""
    
    print("🎮 MC5 Player Statistics Demonstration")
    print("=" * 60)
    
    # Initialize client with your credentials
    try:
        client = MC5Client(
            username="YOUR_USERNAME_HERE",
            password="YOUR_PASSWORD_HERE"
        )
        print("✅ Successfully connected to MC5 API!")
        
    except Exception as e:
        print(f"❌ Failed to connect: {e}")
        return
    
    # 1. Test dogtag to alias conversion
    print("\n🏷️ Dogtag to Alias Conversion Examples:")
    print("-" * 40)
    
    test_dogtags = ["f55f", "ff11", "g6765", "1234", "abcd"]
    
    for dogtag in test_dogtags:
        alias = client.convert_dogtag_to_alias(dogtag)
        back_to_dogtag = client.convert_alias_to_dogtag(alias)
        print(f"   {dogtag} → {alias} → {back_to_dogtag}")
    
    # 2. Search player by dogtag (this will show their detailed stats)
    print("\n🔍 Search Player by Dogtag:")
    print("-" * 40)
    
    # Example dogtag (replace with actual player's dogtag)
    test_dogtag = "f55f"  # This is an example - replace with real dogtag
    
    print(f"🔍 Searching for player with dogtag: {test_dogtag}")
    player_stats = client.get_player_stats_by_dogtag(test_dogtag)
    
    if 'error' in player_stats:
        print(f"❌ {player_stats['error']}")
        print(f"   Dogtag: {player_stats.get('dogtag', 'Unknown')}")
        print(f"   Alias: {player_stats.get('alias', 'Unknown')}")
    else:
        # Get the first player's data
        player_credential = list(player_stats.keys())[0]
        player_data = player_stats[player_credential]
        
        print(f"✅ Player found!")
        print(f"   Dogtag: {player_data.get('dogtag', 'Unknown')}")
        print(f"   Alias: {player_data.get('alias', 'Unknown')}")
        print(f"   Account: {player_data.get('player_info', {}).get('account', 'Unknown')}")
        
        # Parse the stats for easier reading
        parsed_stats = client.parse_player_stats(player_stats)
        
        print(f"\n📊 Player Statistics:")
        print(f"   Rating: {parsed_stats.get('rating', 'Unknown')}")
        print(f"   Current Skill: {parsed_stats.get('current_skill', 'Unknown')}")
        print(f"   Current Weapon: {parsed_stats.get('current_weapon', 'Unknown')}")
        print(f"   XP: {parsed_stats.get('xp', 0):,}")
        print(f"   VIP Points: {parsed_stats.get('vip_points', 0):,}")
        
        # Show top weapons
        weapon_stats = parsed_stats.get('weapon_stats', [])
        if weapon_stats:
            print(f"\n🔫 Top 5 Weapons by Kills:")
            for i, weapon in enumerate(weapon_stats[:5], 1):
                print(f"   {i}. {weapon['id']}: {weapon['kills']:,} kills")
        
        # Show overall stats
        overall_stats = parsed_stats.get('overall_stats', {})
        if overall_stats:
            print(f"\n📈 Overall Statistics:")
            print(f"   Total Kills: {overall_stats.get('total_kills', 0):,}")
            print(f"   Total Deaths: {overall_stats.get('total_deaths', 0):,}")
            print(f"   Total Headshots: {overall_stats.get('total_headshots', 0):,}")
            print(f"   Total Assists: {overall_stats.get('total_assists', 0):,}")
            print(f"   Time Played: {overall_stats.get('total_time_played', 0):,} seconds")
            
            if overall_stats.get('total_kills', 0) > 0:
                kd_ratio = overall_stats['total_kills'] / max(overall_stats.get('total_deaths', 1), 1)
                print(f"   K/D Ratio: {kd_ratio:.2f}")
    
    # 3. Batch operations example
    print("\n📦 Batch Operations Example:")
    print("-" * 40)
    
    # Example credentials (replace with real ones)
    test_credentials = [
        "anonymous:player1_credential_here",
        "anonymous:player2_credential_here",
        "anonymous:player3_credential_here"
    ]
    
    print("📊 Getting batch profiles for multiple players...")
    
    # Note: This will likely fail with placeholder credentials
    try:
        batch_stats = client.get_batch_profiles(test_credentials)
        
        if isinstance(batch_stats, dict) and batch_stats:
            print(f"✅ Retrieved stats for {len(batch_stats)} players")
            
            for credential, data in batch_stats.items():
                if isinstance(data, dict):
                    game_save = data.get('_game_save', {})
                    rating = game_save.get('rating', 0)
                    print(f"   Player: {credential[:20]}... - Rating: {rating}")
        else:
            print("⚠️ Batch profiles returned empty data (expected with placeholder credentials)")
            
    except Exception as e:
        print(f"⚠️ Batch profile request failed: {e}")
        print("   This is expected with placeholder credentials")
    
    # 4. Advanced usage example
    print("\n🎯 Advanced Usage Example:")
    print("-" * 40)
    
    print("💡 Combining dogtag search with stats parsing:")
    
    def analyze_player_performance(client, dogtag):
        """Analyze a player's performance in detail."""
        print(f"\n🔍 Analyzing player: {dogtag}")
        
        # Get player stats
        stats = client.get_player_stats_by_dogtag(dogtag)
        
        if 'error' in stats:
            print(f"❌ {stats['error']}")
            return None
        
        # Parse stats
        parsed = client.parse_player_stats(stats)
        
        # Performance analysis
        overall = parsed.get('overall_stats', {})
        weapons = parsed.get('weapon_stats', [])
        
        print(f"📊 Performance Summary:")
        print(f"   Rating: {parsed.get('rating', 0)}")
        print(f"   K/D Ratio: {overall.get('total_kills', 0) / max(overall.get('total_deaths', 1), 1):.2f}")
        print(f"   Headshot %: {(overall.get('total_headshots', 0) / max(overall.get('total_kills', 1), 1) * 100):.1f}%")
        print(f"   Accuracy: {(overall.get('bullet.hits', 0) / max(overall.get('bullet.shots', 1), 1) * 100):.1f}%")
        
        # Weapon analysis
        if weapons:
            print(f"\n🔫 Weapon Analysis:")
            total_kills = sum(w['kills'] for w in weapons)
            print(f"   Total Weapon Kills: {total_kills:,}")
            
            # Find favorite weapon
            if weapons:
                favorite = max(weapons, key=lambda x: x['kills'])
                print(f"   Favorite Weapon: {favorite['id']} ({favorite['kills']:,} kills)")
                
                # Calculate weapon efficiency
                if favorite['shots'] > 0:
                    accuracy = (favorite['hits'] / favorite['shots']) * 100
                    print(f"   Favorite Weapon Accuracy: {accuracy:.1f}%")
        
        # Progress analysis
        progress = parsed.get('progress', [])
        if progress:
            completed_levels = len([p for p in progress if p.get('objective3', False) == False])
            total_levels = len(progress)
            completion_rate = (completed_levels / total_levels * 100) if total_levels > 0 else 0
            print(f"\n🎮 Campaign Progress:")
            print(f"   Completed Levels: {completed_levels}/{total_levels}")
            print(f"   Completion Rate: {completion_rate:.1f}%")
        
        return parsed
    
    # Try to analyze a player (will fail with placeholder)
    try:
        analyze_player_performance(client, "f55f")
    except Exception as e:
        print(f"⚠️ Analysis failed: {e}")
        print("   This is expected with placeholder credentials")
    
    # 5. Dogtag conversion utility
    print("\n🔧 Dogtag Conversion Utility:")
    print("-" * 40)
    
    def dogtag_info(dogtag):
        """Provide information about a dogtag."""
        alias = client.convert_dogtag_to_alias(dogtag)
        print(f"🏷️ Dogtag: {dogtag}")
        print(f"   Alias: {alias}")
        print(f"   Format: {'Valid' if len(dogtag) == 4 and all(c in '0123456789abcdefABCDEF' for c in dogtag) else 'Invalid'}")
        
        # Try to get player info
        try:
            player_info = client.get_alias_info(alias)
            if player_info.get('account'):
                print(f"   Account ID: {player_info.get('account')}")
                print(f"   Type: {player_info.get('type')}")
            else:
                print("   Status: Not found in database")
        except:
            print("   Status: Unable to lookup")
    
    # Show info for example dogtags
    for dogtag in test_dogtags:
        dogtag_info(dogtag)
        print()
    
    # Clean up
    print("🧹 Cleaning up...")
    try:
        client.close()
        print("✅ Connection closed successfully!")
        
    except Exception as e:
        print(f"⚠️ Error during cleanup: {e}")
    
    print("\n🎉 Player Statistics Demonstration Complete!")
    print("\n📚 What You Learned:")
    print("   🏷️ Dogtag/alias conversion system")
    print("   🔍 Player search by dogtag")
    print("   📊 Detailed statistics retrieval")
    print("   📦 Batch profile operations")
    print("   📈 Performance analysis tools")
    print("   🔧 Utility functions for dogtag management")
    print("   🎮 Campaign progress tracking")
    print("   🔫 Weapon statistics analysis")
    
    print("\n🎮 Ready to build advanced player analytics!")

if __name__ == "__main__":
    main()
